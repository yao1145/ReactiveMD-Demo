import { t as e } from "./data-table-O05FXwNw.js";
import { a as t, o as n } from "./visuals-DyY5n3wb.js";
import { o as r } from "./layout-DN3YCrn1.js";
import { t as i } from "./plugin-packs-B1XPWcFs.js";
import { t as a } from "./mount-preset-Do9PaArW.js";
import { t as o } from "./visuals-B5KSafVk.js";
// src/components/plugins/data.ts
var s = {
	column: r,
	"data-table": e,
	table: t,
	timeline: n
}, c = i("reactive-md/data", Object.keys(s)), l = a(c, s, [{
	id: "reactive-md/visuals.css",
	css: o
}]);
export { l as default };
