import { C as e, E as t, I as n, L as r, M as i, P as a, R as o, U as s, V as c, f as l, j as u, l as d, m as f, s as p, u as m, z as h } from "./sdk-core-C9QyFVPw.js";
import { c as g, s as _ } from "./visuals-DyY5n3wb.js";
import { useEffect as v, useId as y, useRef as b, useState as x } from "react";
import { jsx as S, jsxs as C } from "react/jsx-runtime";
// src/components/plot/coordinate.tsx
function w({ id: e, label: t, value: n, min: r, max: a, step: o, disabled: s, onCommit: c, reset: l }) {
	let [u, d] = x(() => String(n)), [p, m] = x(!1), h = b(n);
	v(() => {
		d(String(n)), m(!1);
	}, [l]), v(() => {
		h.current !== n && (h.current = n, p || d(String(n)));
	}, [n, p]);
	let g = (e) => {
		let t = e.trim();
		if (t === "" || t === "-" || t === "." || t === "-.") return null;
		let n = Number(t);
		return Number.isFinite(n) ? i(f(n, r, a), r, a, o) : null;
	};
	return /* @__PURE__ */ C("div", {
		className: "local-number-field",
		children: [/* @__PURE__ */ S("label", {
			className: "md-label",
			htmlFor: e,
			children: t
		}), /* @__PURE__ */ S("input", {
			id: e,
			className: "md-text-input",
			type: "text",
			inputMode: "decimal",
			value: u,
			disabled: s,
			onFocus: () => m(!0),
			onBlur: () => {
				m(!1);
				let e = g(u);
				d(String(e ?? n));
			},
			onChange: (e) => {
				let t = e.target.value;
				d(t);
				let n = g(t);
				n !== null && c(n);
			}
		})]
	});
}
function T(v) {
	let x = n(v), T = r(v), E = y(), { content: D, mode: O, resetToken: k, t: A } = T, { write: j, writeMany: ee, error: te, setError: ne } = s(v), M = a(v, "label", A("Coordinate", "坐标")), { disabled: N, invalid: re } = o(v), P = c(v), F = t(v, "x-min", "x-max", -5, 5, 1), I = t(v, "y-min", "y-max", -5, 5, 1), L = i(0, F.min, F.max, F.step), R = i(0, I.min, I.max, I.step), z = i(u(v, "x", L), F.min, F.max, F.step), B = i(u(v, "y", R), I.min, I.max, I.step), V = b(null), H = b(!1), U = _();
	h(v, () => ne(null));
	let W = `X: ${z} · Y: ${B}`;
	if (O === "static") return /* @__PURE__ */ S(m, {
		authorRoot: x(),
		className: "local-coordinate",
		label: M,
		value: W
	});
	let G = (e) => F.max > F.min ? 40 + (e - F.min) / (F.max - F.min) * 320 : 200, K = (e) => I.max > I.min ? 360 - (e - I.min) / (I.max - I.min) * 320 : 200, q = G(z), J = K(B), Y = G(f(0, F.min, F.max)), X = K(f(0, I.min, I.max)), Z = (e) => {
		let t = e.step * Math.max(1, Math.ceil((e.max - e.min) / (e.step * 10))), n = Math.min(11, Math.floor((e.max - e.min) / t) + 1);
		return Array.from({ length: n }, (n, r) => e.min + r * t);
	}, Q = (e) => {
		let t = V.current?.getBoundingClientRect();
		if (!t || t.width === 0 || t.height === 0) return null;
		let n = f(((e.clientX - t.left) / t.width - .1) / .8, 0, 1), r = f(((e.clientY - t.top) / t.height - .1) / .8, 0, 1);
		return {
			x: i(F.min + n * (F.max - F.min), F.min, F.max, F.step),
			y: i(I.min + (1 - r) * (I.max - I.min), I.min, I.max, I.step)
		};
	}, $ = (e, t) => {
		(e !== z || t !== B) && ee({
			x: e,
			y: t
		});
	}, ie = (e) => {
		if (N) return;
		let t = z, n = B;
		switch (e.key) {
			case "ArrowLeft":
				t = i(z - F.step, F.min, F.max, F.step);
				break;
			case "ArrowRight":
				t = i(z + F.step, F.min, F.max, F.step);
				break;
			case "ArrowDown":
				n = i(B - I.step, I.min, I.max, I.step);
				break;
			case "ArrowUp":
				n = i(B + I.step, I.min, I.max, I.step);
				break;
			case "Home":
				t = F.min, n = I.min;
				break;
			case "End":
				t = i(F.max, F.min, F.max, F.step), n = i(I.max, I.min, I.max, I.step);
				break;
			default: return;
		}
		e.preventDefault(), e.stopPropagation(), $(t, n);
	};
	return /* @__PURE__ */ C("div", {
		className: "local-coordinate",
		...x(l(e(D))),
		role: "group",
		"aria-label": M,
		"data-rmd-component": "coordinate",
		"aria-invalid": P.invalid || void 0,
		"aria-describedby": P.describedBy,
		children: [
			/* @__PURE__ */ S("span", {
				className: "md-label",
				children: M
			}),
			/* @__PURE__ */ C("div", {
				className: `local-coordinate-surface${U ? " local-mafs-surface" : ""}`,
				children: [/* @__PURE__ */ S("div", {
					ref: V,
					className: `local-coordinate-pad${U ? " local-mafs-coordinate" : ""}`,
					role: "group",
					"aria-label": A(`${M} drag area`, `${M} 拖拽区`),
					"aria-disabled": N || void 0,
					tabIndex: N ? -1 : 0,
					onKeyDownCapture: ie,
					onPointerDown: U ? void 0 : (e) => {
						if (N) return;
						e.preventDefault(), H.current = !0, V.current?.focus({ preventScroll: !0 });
						try {
							e.currentTarget.setPointerCapture(e.pointerId);
						} catch {}
						let t = Q(e);
						t && $(t.x, t.y);
					},
					onPointerMove: U ? void 0 : (e) => {
						if (!H.current || N) return;
						let t = Q(e);
						t && $(t.x, t.y);
					},
					onPointerUp: U ? void 0 : (e) => {
						H.current = !1;
						try {
							e.currentTarget.releasePointerCapture(e.pointerId);
						} catch {}
					},
					onPointerCancel: U ? void 0 : () => {
						H.current = !1;
					},
					children: U ? /* @__PURE__ */ S(g, {
						x: z,
						y: B,
						xRange: F,
						yRange: I,
						step: F.step,
						disabled: N,
						accent: "var(--local-accent, var(--coordinate-point))",
						onMove: $
					}) : /* @__PURE__ */ C("svg", {
						className: "local-coordinate-svg",
						viewBox: "0 0 400 400",
						"aria-hidden": "true",
						focusable: "false",
						children: [
							/* @__PURE__ */ S("defs", { children: /* @__PURE__ */ S("marker", {
								id: `${E}-coordinate-arrow`,
								markerWidth: "8",
								markerHeight: "8",
								refX: "6",
								refY: "4",
								orient: "auto",
								viewBox: "0 0 8 8",
								children: /* @__PURE__ */ S("path", {
									className: "local-coordinate-arrow",
									d: "M1 1 L6 4 L1 7"
								})
							}) }),
							/* @__PURE__ */ C("g", {
								className: "local-coordinate-grid",
								children: [
									/* @__PURE__ */ S("rect", {
										x: "40",
										y: "40",
										width: "320",
										height: "320"
									}),
									Z(F).map((e, t) => /* @__PURE__ */ S("line", {
										x1: G(e),
										y1: "40",
										x2: G(e),
										y2: "360"
									}, `x-${t}`)),
									Z(I).map((e, t) => /* @__PURE__ */ S("line", {
										x1: "40",
										y1: K(e),
										x2: "360",
										y2: K(e)
									}, `y-${t}`))
								]
							}),
							/* @__PURE__ */ C("g", {
								className: "local-coordinate-axes",
								children: [/* @__PURE__ */ S("line", {
									className: "local-coordinate-horizontal",
									x1: "26",
									y1: X,
									x2: "372",
									y2: X,
									markerEnd: `url(#${E}-coordinate-arrow)`
								}), /* @__PURE__ */ S("line", {
									className: "local-coordinate-vertical",
									x1: Y,
									y1: "374",
									x2: Y,
									y2: "24",
									markerEnd: `url(#${E}-coordinate-arrow)`
								})]
							}),
							/* @__PURE__ */ C("g", {
								className: "local-coordinate-axis-label",
								children: [/* @__PURE__ */ S("text", {
									x: "358",
									y: X - 14,
									children: "x"
								}), /* @__PURE__ */ S("text", {
									x: Y + 12,
									y: "40",
									children: "y"
								})]
							}),
							/* @__PURE__ */ C("g", {
								className: "local-coordinate-projection",
								children: [/* @__PURE__ */ S("line", {
									x1: q,
									y1: J,
									x2: q,
									y2: X
								}), /* @__PURE__ */ S("line", {
									x1: q,
									y1: J,
									x2: Y,
									y2: J
								})]
							}),
							/* @__PURE__ */ S("circle", {
								className: "local-coordinate-dot",
								cx: q,
								cy: J,
								r: "10"
							}),
							/* @__PURE__ */ S("text", {
								className: "local-coordinate-value",
								x: q,
								y: J > 330 ? J - 22 : J + 30,
								textAnchor: q < 80 ? "start" : q > 320 ? "end" : "middle",
								children: `(${z}, ${B})`
							})
						]
					})
				}), /* @__PURE__ */ S("span", {
					className: "local-coordinate-caption",
					children: A("Draggable coordinate plane", "可拖动的坐标平面")
				})]
			}),
			/* @__PURE__ */ S("span", {
				className: "md-hint local-hint",
				children: A("Arrow keys adjust the point; Home and End jump to the lower or upper bounds.", "方向键调整坐标；Home 和 End 跳到最小或最大边界。")
			}),
			/* @__PURE__ */ C("div", {
				className: "local-coordinate-fields",
				children: [/* @__PURE__ */ S(w, {
					id: `${E}-coordinate-x`,
					reset: k,
					label: `${M} X`,
					value: z,
					min: F.min,
					max: F.max,
					step: F.step,
					disabled: N,
					onCommit: (e) => j(e, "x")
				}), /* @__PURE__ */ S(w, {
					id: `${E}-coordinate-y`,
					reset: k,
					label: `${M} Y`,
					value: B,
					min: I.min,
					max: I.max,
					step: I.step,
					disabled: N,
					onCommit: (e) => j(e, "y")
				})]
			}),
			/* @__PURE__ */ S(d, { value: W }),
			/* @__PURE__ */ S(p, { message: re ? A("Cannot compute", "无法计算") : te })
		]
	});
}
export { T as t };
