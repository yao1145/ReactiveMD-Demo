import { n as e } from "./sdk-core-C9QyFVPw.js";
import { a as t } from "./LocalDocumentView-1jhz-csf.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
