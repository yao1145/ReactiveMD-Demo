import { z as e } from "./preset-core-CKc5YXSM.js";
import t from "./reactive-md-default-preset.js";
import { G as n } from "./sdk-core-C9QyFVPw.js";
import { _ as r, a as ee, c as te, d as ne, f as re, g as ie, h as ae, i as oe, l as i, m as a, n as o, o as s, p as c, r as l, s as u, t as d, u as f } from "./controls-UPeBVv80.js";
import { t as p } from "./data-table-O05FXwNw.js";
import { a as m, i as h, n as g, o as _, r as v, t as y } from "./visuals-DyY5n3wb.js";
import { t as b } from "./coordinate-C_C4nw-d.js";
import { _ as x, a as S, b as C, c as w, d as T, f as E, g as D, h as se, i as O, l as k, m as A, n as j, o as M, p as N, r as P, s as F, t as I, u as L, v as R, x as z, y as B } from "./layout-DN3YCrn1.js";
import { n as V, t as H } from "./gallery-Bknllymf.js";
import { r as U, t as W } from "./package-core-DxZqaY2u.js";
import { t as G } from "./LocalDocumentViewCore-fyNnGPpH.js";
import { t as K } from "./LocalReactiveDocumentCore-KdmnUkz-.js";
import { jsx as q } from "react/jsx-runtime";
// src/components/default-preset.ts
function J() {
	return null;
}
var ce = Object.freeze({
	input: s,
	textarea: c,
	number: te,
	slider: r,
	"range-slider": ie,
	coordinate: b,
	toggle: ae,
	checkbox: d,
	date: ee,
	select: re,
	choices: l,
	"radio-group": ne,
	"multi-select": u,
	option: E,
	counter: oe,
	timer: a,
	checklist: o,
	progress: i,
	jump: T,
	anchor: P,
	text: B,
	section: A,
	quiz: f,
	panel: N,
	card: S,
	grid: k,
	gallery: V,
	"gallery-item": H,
	tabs: R,
	tab: x,
	steps: D,
	step: se,
	accordion: I,
	disclosure: F,
	if: L,
	alert: j,
	badge: O,
	tooltip: C,
	validation: z,
	"data-table": p,
	column: M,
	table: m,
	chart: y,
	plot: h,
	timeline: _,
	diagram: g,
	node: v,
	edge: w,
	computed: J,
	const: J,
	external: J
}), Y = null;
function X() {
	if (Y) return Y;
	let e = [];
	for (let r of t.components) {
		let t = ce[r.name];
		if (!t) throw Error(`Default React preset has no implementation for builtin component <${r.name}>.`);
		e.push(n(r, { render: t }));
	}
	return Y = Object.freeze({
		id: t.id,
		version: t.version,
		components: Object.freeze(e)
	}), Y;
}
X();
// src/react/package.ts
var Z = U({
	protocol: e,
	preset: t,
	components: X().components
});
function Q(e = {}) {
	return W(e, Z);
}
// src/local/rendering/document/LocalDocumentView.tsx
var le, $ = () => le ??= Q().reactConfig;
function ue(e) {
	return /* @__PURE__ */ q(G, {
		...e,
		getBaseConfig: $
	});
}
function de(e) {
	return /* @__PURE__ */ q(K, {
		...e,
		getBaseConfig: $
	});
}
export { X as a, Z as i, de as n, Q as r, ue as t };
