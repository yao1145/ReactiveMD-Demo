import { z as e } from "./preset-core-CKc5YXSM.js";
import { G as t } from "./sdk-core-C9QyFVPw.js";
import { r as n } from "./package-core-DxZqaY2u.js";
// src/components/mount-preset.ts
function r(r, i, a = []) {
	return n({
		protocol: e,
		preset: r,
		components: r.components.map((e) => t(e, { render: i[e.name] })),
		resources: a
	});
}
export { r as t };
