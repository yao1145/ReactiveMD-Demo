import { r as e, t } from "./display-lw3BT1TA.js";
import { createElement as n, useId as r } from "react";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
// src/local/rendering/math-view.tsx
var o = (e, t, ...r) => n(e, t, ...r);
function s({ source: n, display: r = !1 }) {
	let i = e(n, r), a = r ? "local-math local-math-block" : "local-math";
	if (i.html !== null) return o("span", {
		className: a,
		"data-local-math": "katex",
		dangerouslySetInnerHTML: { __html: i.html }
	});
	let s = t(n);
	return o("span", {
		className: `${a} local-math-fallback`,
		"data-local-math": "fallback",
		role: "math",
		"aria-label": s
	}, s);
}
// src/local/rendering/table/data-table.tsx
function c({ children: e, className: t = "", scrollClassName: n = "", tableProps: r = {} }) {
	return /* @__PURE__ */ i("div", {
		className: `local-visual-table-scroll${n ? ` ${n}` : ""}`,
		children: /* @__PURE__ */ i("table", {
			...r,
			className: `local-visual-table${t ? ` ${t}` : ""}`,
			children: e
		})
	});
}
// src/components/shared/visual-frame.tsx
function l({ className: e, label: t, children: n, component: o }) {
	let s = r();
	return /* @__PURE__ */ a("figure", {
		className: `local-visual ${e}`,
		"aria-labelledby": s,
		"data-rmd-component": o,
		children: [/* @__PURE__ */ i("figcaption", {
			id: s,
			className: "local-visual-title",
			"data-rmd-part": "title",
			children: t
		}), n]
	});
}
export { c as n, s as r, l as t };
