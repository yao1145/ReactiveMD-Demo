import { n as e } from "./sdk-core-BJLJaVR5.js";
import { a as t } from "./LocalDocumentView-CAPxgzi1.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
