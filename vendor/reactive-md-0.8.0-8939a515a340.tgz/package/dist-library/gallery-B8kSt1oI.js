import { useCallback as e, useEffect as t, useId as n, useRef as r, useState as i } from "react";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
// src/components/gallery/gallery.tsx
var s = 280, c = 180, l = 480, u = 24, d = 28, f = 700;
function p(e) {
	return Math.round(Math.min(l, Math.max(c, typeof e == "number" && Number.isFinite(e) ? e : s)));
}
function m() {
	return typeof window < "u" && typeof window.matchMedia == "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function h(e) {
	return e.children.items().filter((e) => e.kind === "component" && e.name === "gallery-item");
}
function g(e) {
	let t = e.props.label;
	return typeof t == "string" ? t.trim() : "";
}
function _(s) {
	let c = h(s), l = c.length, _ = p(s.props["item-width"]), v = typeof s.props.label == "string" ? s.props.label.trim() : "", y = n(), b = r(null), x = r(null), S = r(null), C = r(null), w = r(null), T = r(void 0), E = r(""), [D, O] = i(() => ({
		start: +(l > 0),
		end: l,
		prev: !1,
		next: !1
	})), k = e(() => {
		let e = x.current, t = b.current;
		if (!e || !t || e.clientWidth === 0) return;
		let n = Math.max(0, e.scrollWidth - e.clientWidth), r = Math.max(0, e.scrollLeft), i = r > .5, a = n - r > .5;
		t.setAttribute("data-rmd-gallery-ready", ""), t.setAttribute("data-rmd-gallery-overflow", n > .5 ? "true" : "false"), e.style.setProperty("--rmd-gallery-fade-left", `${i ? Math.min(u, r) : 0}px`), e.style.setProperty("--rmd-gallery-fade-right", `${a ? Math.min(u, n - r) : 0}px`);
		let o = e.getBoundingClientRect(), s = window.getComputedStyle(e), c = o.left + e.clientLeft + (parseFloat(s.paddingLeft) || 0), l = o.left + e.clientLeft + e.clientWidth - (parseFloat(s.paddingRight) || 0), f = 0, p = 0, m = 0;
		for (let t of Array.from(e.children)) {
			if (!t.classList.contains("rmd-gallery-item")) continue;
			m += 1;
			let e = t.getBoundingClientRect();
			e.right > c + .5 && e.left < l - .5 && (f === 0 && (f = m), p = m);
		}
		let h = f === 0 ? +(m > 0) : f, g = p === 0 ? m : p, _ = `${h}|${g}|${i}|${a}`;
		_ !== E.current && (E.current = _, O({
			start: h,
			end: g,
			prev: i,
			next: a
		}));
		let v = S.current, y = C.current;
		if (!v || !y) return;
		let w = n > .5;
		if (v.toggleAttribute("data-hidden", !w), !w) return;
		let T = v.clientWidth, D = Math.min(T, Math.max(d, T * e.clientWidth / Math.max(1, e.scrollWidth))), k = Math.max(0, Math.min(T - D, (T - D) * (r / n)));
		y.style.width = `${D}px`, y.style.transform = `translateX(${k}px)`;
	}, []), A = e(() => {
		let e = b.current;
		e && (e.setAttribute("data-rmd-gallery-scrolling", ""), T.current !== void 0 && window.clearTimeout(T.current), T.current = window.setTimeout(() => {
			T.current = void 0, e.removeAttribute("data-rmd-gallery-scrolling");
		}, f));
	}, []);
	t(() => {
		let e = x.current;
		if (!e) return;
		let t = 0, n = () => {
			t === 0 && (t = window.requestAnimationFrame(() => {
				t = 0, k();
			}));
		}, r = () => {
			n(), A();
		};
		e.addEventListener("scroll", r, { passive: !0 }), k();
		let i;
		if (typeof ResizeObserver < "u") {
			i = new ResizeObserver(n), i.observe(e);
			for (let t of Array.from(e.children)) i.observe(t);
		}
		let a = typeof MutationObserver > "u" ? void 0 : new MutationObserver(() => {
			if (i?.disconnect(), i) {
				i.observe(e);
				for (let t of Array.from(e.children)) i.observe(t);
			}
			n();
		});
		return a?.observe(e, { childList: !0 }), () => {
			e.removeEventListener("scroll", r), t !== 0 && window.cancelAnimationFrame(t), i?.disconnect(), a?.disconnect(), T.current !== void 0 && (window.clearTimeout(T.current), T.current = void 0);
		};
	}, [
		k,
		A,
		l
	]), t(() => {
		let e = x.current;
		if (!e) return;
		e.scrollLeft = 0;
		let t = window.requestAnimationFrame(() => k());
		return () => window.cancelAnimationFrame(t);
	}, [
		s.resetToken,
		s.visible,
		k
	]), t(() => {
		let e = x.current;
		if (!e) return;
		let t = (t) => {
			if (t.defaultPrevented || t.ctrlKey || t.metaKey || t.altKey) return;
			let n = e.scrollWidth - e.clientWidth;
			if (n <= .5) return;
			let r = t.deltaMode === 1 ? 16 : t.deltaMode === 2 ? e.clientWidth : 1, i = t.deltaX * r, a = t.deltaY * r;
			if (Math.abs(i) > Math.abs(a) || a === 0) return;
			let o = e.scrollLeft;
			a < 0 && o <= .5 || a > 0 && o >= n - .5 || (t.preventDefault(), e.scrollBy({
				left: a,
				behavior: m() ? "auto" : "smooth"
			}));
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let j = (e) => {
		let t = x.current;
		t && !s.disabled && t.scrollBy({
			left: e * t.clientWidth * .9,
			behavior: m() ? "auto" : "smooth"
		});
	}, M = (e) => {
		if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
		let t = e.target instanceof Element ? e.target : null;
		if (t && t !== e.currentTarget && t.closest("input, textarea, select, button, a[href], [contenteditable=\"true\"], [role=\"textbox\"], [role=\"slider\"]")) return;
		let n = x.current;
		if (!n) return;
		let r = Math.max(0, n.scrollWidth - n.clientWidth), i = n.scrollLeft, a = m() ? "auto" : "smooth";
		if (e.key === "ArrowRight") {
			if (i >= r - .5) return;
			e.preventDefault(), n.scrollBy({
				left: n.clientWidth * .9,
				behavior: a
			});
		} else if (e.key === "ArrowLeft") {
			if (i <= .5) return;
			e.preventDefault(), n.scrollBy({
				left: -n.clientWidth * .9,
				behavior: a
			});
		} else if (e.key === "Home") {
			if (i <= .5) return;
			e.preventDefault(), n.scrollTo({
				left: 0,
				behavior: a
			});
		} else if (e.key === "End") {
			if (i >= r - .5) return;
			e.preventDefault(), n.scrollTo({
				left: r,
				behavior: a
			});
		}
	}, N = (e) => {
		let t = x.current, n = S.current, r = C.current;
		if (!t || !n || !r || e.button !== 0) return;
		e.preventDefault(), e.stopPropagation(), e.currentTarget.setPointerCapture(e.pointerId);
		let i = t.scrollWidth - t.clientWidth, a = Math.max(1, n.clientWidth - r.offsetWidth);
		w.current = {
			startX: e.clientX,
			scroll: t.scrollLeft,
			ratio: i / a
		}, b.current?.setAttribute("data-rmd-gallery-dragging", ""), t.style.scrollSnapType = "none";
	}, P = (e) => {
		let t = w.current, n = x.current;
		if (!t || !n) return;
		let r = Math.max(0, n.scrollWidth - n.clientWidth), i = t.scroll + (e.clientX - t.startX) * t.ratio;
		n.scrollLeft = Math.max(0, Math.min(r, i));
	}, F = (e) => {
		if (!w.current) return;
		w.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId), b.current?.removeAttribute("data-rmd-gallery-dragging");
		let t = x.current;
		t && (t.style.scrollSnapType = ""), A();
	}, I = (e) => {
		if (e.button !== 0 || e.target !== e.currentTarget) return;
		let t = x.current, n = C.current;
		if (!t) return;
		e.preventDefault();
		let r = n?.getBoundingClientRect(), i = r ? e.clientX > r.left + r.width / 2 : e.clientX > t.getBoundingClientRect().left + t.clientWidth / 2;
		t.scrollBy({
			left: (i ? 1 : -1) * t.clientWidth * .9,
			behavior: m() ? "auto" : "smooth"
		});
	}, L = l === 0 ? 0 : Math.min(l, Math.max(1, D.start || 1)), R = l === 0 ? 0 : Math.min(l, Math.max(L, D.end || l)), z = { "--rmd-gallery-item-width": `${_}px` }, B = v ? s.locale.t(`Browse ${v}`, `浏览${v}`) : s.locale.t("Gallery items", "画廊项目");
	return /* @__PURE__ */ o("section", {
		ref: b,
		className: "rmd-gallery",
		style: z,
		"aria-label": v || void 0,
		children: [
			/* @__PURE__ */ o("div", {
				className: "rmd-gallery-head",
				children: [/* @__PURE__ */ a("h3", {
					className: "rmd-gallery-title",
					title: v || void 0,
					children: v
				}), /* @__PURE__ */ o("div", {
					className: "rmd-gallery-controls",
					children: [
						l > 0 ? /* @__PURE__ */ o("span", {
							className: "rmd-gallery-count",
							"aria-live": "polite",
							"aria-atomic": "true",
							children: [
								L,
								"–",
								R,
								" / ",
								l
							]
						}) : null,
						/* @__PURE__ */ a("button", {
							type: "button",
							className: "rmd-gallery-button",
							"data-direction": "previous",
							"data-rmd-appearance": "custom",
							"aria-label": s.locale.t("Previous items", "上一组"),
							"aria-controls": y,
							disabled: s.disabled || !D.prev,
							onClick: () => j(-1),
							children: /* @__PURE__ */ a("svg", {
								width: "22",
								height: "22",
								viewBox: "0 0 24 24",
								fill: "none",
								"aria-hidden": "true",
								children: /* @__PURE__ */ a("path", {
									d: "m14.5 5.5-6.5 6.5 6.5 6.5",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round"
								})
							})
						}),
						/* @__PURE__ */ a("button", {
							type: "button",
							className: "rmd-gallery-button",
							"data-direction": "next",
							"data-rmd-appearance": "custom",
							"aria-label": s.locale.t("Next items", "下一组"),
							"aria-controls": y,
							disabled: s.disabled || !D.next,
							onClick: () => j(1),
							children: /* @__PURE__ */ a("svg", {
								width: "22",
								height: "22",
								viewBox: "0 0 24 24",
								fill: "none",
								"aria-hidden": "true",
								children: /* @__PURE__ */ a("path", {
									d: "m9.5 5.5 6.5 6.5-6.5 6.5",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round"
								})
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ a("ul", {
				id: y,
				ref: x,
				className: "rmd-gallery-viewport",
				role: "list",
				tabIndex: 0,
				"aria-label": B,
				onKeyDown: M,
				children: c.map((e) => {
					let t = g(e);
					return /* @__PURE__ */ a("li", {
						className: "rmd-gallery-item",
						children: /* @__PURE__ */ o("figure", {
							className: "rmd-gallery-figure",
							children: [t ? /* @__PURE__ */ a("figcaption", { children: /* @__PURE__ */ a("h3", {
								className: "rmd-gallery-caption",
								title: t,
								children: t
							}) }) : null, /* @__PURE__ */ a("div", {
								className: "rmd-gallery-body",
								children: s.children.renderItems(e.children, e.visible)
							})]
						})
					}, e.id);
				})
			}),
			/* @__PURE__ */ a("div", {
				className: "rmd-gallery-track",
				ref: S,
				"aria-hidden": "true",
				onPointerDown: I,
				children: /* @__PURE__ */ a("div", {
					className: "rmd-gallery-thumb",
					ref: C,
					onPointerDown: N,
					onPointerMove: P,
					onPointerUp: F,
					onPointerCancel: F
				})
			})
		]
	});
}
function v(e) {
	let t = h(e), n = p(e.props["item-width"]), r = typeof e.props.label == "string" ? e.props.label.trim() : "", i = { "--rmd-gallery-item-width": `${n}px` };
	return /* @__PURE__ */ o("section", {
		className: "rmd-gallery rmd-gallery-static",
		style: i,
		"aria-label": r || void 0,
		children: [/* @__PURE__ */ a("div", {
			className: "rmd-gallery-head",
			children: /* @__PURE__ */ a("h3", {
				className: "rmd-gallery-title",
				title: r || void 0,
				children: r
			})
		}), /* @__PURE__ */ a("ul", {
			className: "rmd-gallery-static-grid",
			role: "list",
			children: t.map((t) => {
				let n = g(t);
				return /* @__PURE__ */ a("li", {
					className: "rmd-gallery-static-item",
					children: /* @__PURE__ */ o("figure", {
						className: "rmd-gallery-figure",
						children: [n ? /* @__PURE__ */ a("figcaption", { children: /* @__PURE__ */ a("h3", {
							className: "rmd-gallery-caption",
							title: n,
							children: n
						}) }) : null, /* @__PURE__ */ a("div", {
							className: "rmd-gallery-body",
							children: e.children.renderItems(t.children, t.visible)
						})]
					})
				}, t.id);
			})
		})]
	});
}
function y(e) {
	let t = typeof e.props.label == "string" ? e.props.label.trim() : "";
	return /* @__PURE__ */ o("section", {
		className: "rmd-gallery-item-standalone",
		"aria-label": t || void 0,
		children: [t ? /* @__PURE__ */ a("h3", {
			className: "rmd-gallery-caption",
			title: t,
			children: t
		}) : null, /* @__PURE__ */ a("div", {
			className: "rmd-gallery-body",
			children: e.children.render()
		})]
	});
}
function b(e) {
	return e.mode === "static" ? /* @__PURE__ */ a(v, { ...e }) : /* @__PURE__ */ a(_, { ...e });
}
export { b as n, y as t };
