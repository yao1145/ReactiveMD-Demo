import { a as e, i as t, s as n } from "./latex-1w7aQgD5.js";
import { t as r } from "./compiler-core-DTxY-qYz.js";
import { v as i } from "./validation-BlDL2uD9.js";
import { n as a } from "./display-lw3BT1TA.js";
import { o, t as s } from "./parser-standard-OToYcOBL.js";
import c from "./reactive-md-default-preset.js";
import { i as l, r as u, t as d } from "./types-BFC5rzC4.js";
// src/compiler/standard.ts
function f(e) {
	let t = i(e, c.components, s);
	if (t.ok) return t;
	throw new d(t.message, {
		code: t.key,
		...t.detail === void 0 ? {} : { detail: t.detail }
	});
}
function p(e) {
	return e === void 0 ? void 0 : Object.freeze({ ...e });
}
function m(i) {
	let s = f(i), c = p(i), d = {
		display: a,
		htmlDocument: o,
		plotMath: {
			kind: n,
			gridSize: e,
			compile: t
		}
	};
	return { compile(e) {
		return l(r(e, c, s, d), u);
	} };
}
export { d as CompilerConfigurationError, m as createStandardCompiler };
