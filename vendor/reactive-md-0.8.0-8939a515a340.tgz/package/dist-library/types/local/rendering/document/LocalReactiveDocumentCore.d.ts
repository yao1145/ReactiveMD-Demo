import { type BaseConfigProps, type LocalReactiveDocumentProps } from './LocalDocumentViewCore.js';
type LocalReactiveDocumentCoreProps = LocalReactiveDocumentProps & BaseConfigProps & {
    readonly useBaseCompileConfig?: boolean;
};
export declare function LocalReactiveDocumentCore({ source, onDiagnostics, urlPolicy, locale, themes, colorScheme, mode, staticFirst, imageResolver, hostData, hostRenderer, reactConfig, useBaseCompileConfig, externalValues, network, documentId, randomSeed, componentState, componentStateStorage, componentStateWriteDelayMs, onComponentStateChange, initialParameters, onParametersChange, onSourceNavigate, compileOptions, getBaseConfig, }: LocalReactiveDocumentCoreProps): import("react").JSX.Element;
export {};
