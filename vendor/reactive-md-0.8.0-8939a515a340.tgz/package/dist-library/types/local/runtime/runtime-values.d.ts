import type { Diagnostic, LocalBinding, LocalDocument, LocalNode, LocalValue, LocalValueKind } from '../types.js';
import { type LocalDiagnosticDetails } from '../configuration/diagnostics.js';
import { type KernelValueRule } from '../configuration/kernel-value-rules.js';
import { LocalExpressionError } from '../evaluation/expression/compile.js';
type ValidationResult = {
    ok: true;
    value: LocalValue;
    detail?: undefined;
} | {
    ok: false;
    detail: LocalDiagnosticDetails;
};
export type DynamicRead = {
    present: false;
} | {
    present: true;
    ok: true;
    value: LocalValue;
} | {
    present: true;
    ok: false;
};
export declare function validateValue(binding: LocalBinding, nodes: LocalNode[], value: LocalValue, readDynamic: (node: LocalNode, attribute: 'min' | 'max' | 'required') => DynamicRead, valueRules?: ReadonlyMap<string, readonly KernelValueRule[]>, legacyMode?: boolean): ValidationResult;
export declare function normalizeComputationError(error: unknown): LocalExpressionError;
type ExternalCheck = {
    ok: true;
    value: LocalValue;
} | {
    ok: false;
    key: string;
    params?: Record<string, string | number | boolean | null>;
};
/** Validate one host external value against its declared type and budgets. */
export declare function validateExternalValue(kind: LocalValueKind, value: LocalValue): ExternalCheck;
export declare function cloneValue(value: LocalValue): LocalValue;
export declare function onStep(value: number, base: number, step: number): boolean;
export declare function diagnosticFor(document: LocalDocument, node: LocalNode, code: string, detail: LocalDiagnosticDetails): Diagnostic;
export declare function parameterDiagnostic(code: string, message: string, detail?: LocalDiagnosticDetails): Diagnostic;
export {};
