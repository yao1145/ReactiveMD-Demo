import { rt as e } from "./preset-core-CKc5YXSM.js";
import { t } from "./compile-LhpTKqCR.js";
import { A as n, O as r } from "./component-utils-BvHL8VGt.js";
import { jsx as i, jsxs as a } from "react/jsx-runtime";
// src/components/table/data-table.tsx
var o = class extends Error {
	failure;
	constructor(e) {
		super(e), this.name = "DataTableFailureError", this.failure = e;
	}
};
function s(e) {
	return e === null ? "" : typeof e == "string" ? e : typeof e == "number" ? Number.isFinite(e) ? String(e) : null : typeof e == "boolean" ? e ? "true" : "false" : null;
}
function c(e) {
	return typeof e == "string" ? e === "" ? null : `s:${e}` : typeof e == "number" && Number.isFinite(e) ? `n:${e === 0 ? 0 : e}` : null;
}
function l(e, t, n) {
	let r = { ...n };
	for (let i of t) Object.hasOwn(n, i) || Object.defineProperty(r, i, {
		enumerable: !0,
		configurable: !0,
		get() {
			return e.evaluate(i);
		}
	});
	return r;
}
function u(e) {
	if (e.length === 0) return null;
	let t = typeof e[0];
	if (t !== "string" && t !== "number") return "rows";
	for (let n of e) if (typeof n !== t || typeof n == "number" && !Number.isFinite(n)) return "rows";
	return null;
}
function d(e, n) {
	let r;
	try {
		r = t(n);
	} catch {
		throw new o("rows");
	}
	let i;
	try {
		i = r.evaluate(l(e, r.dependencies, {}));
	} catch {
		throw new o("rows");
	}
	if (!Array.isArray(i)) throw new o("rows");
	let a = u(i);
	if (a) throw new o(a);
	return i;
}
function f(e) {
	let { rows: n, columns: r, keyExpression: i, runtime: a } = e, d = e.maxRows ?? 100, f = e.budget ?? 1e5;
	if (!Number.isSafeInteger(d) || d <= 0 || d > 1e3) return {
		ok: !1,
		failure: "max-rows"
	};
	if (r.length < 1 || r.length > 20) return {
		ok: !1,
		failure: "columns"
	};
	let p = u(n);
	if (p) return {
		ok: !1,
		failure: p
	};
	if (n.length > d) return {
		ok: !1,
		failure: "rows-budget"
	};
	let m;
	try {
		m = t(i);
	} catch {
		return {
			ok: !1,
			failure: "key"
		};
	}
	let h = m.dependencies;
	if (h.length !== 1 || h[0] !== "item") return {
		ok: !1,
		failure: "key"
	};
	let g = r.map((e) => {
		try {
			return {
				spec: e,
				expression: t(e.value)
			};
		} catch {
			return {
				spec: e,
				expression: null
			};
		}
	}), _ = 0;
	for (let e of r) _ += e.label.length;
	if (n.length === 0 && (_ += 7), _ > f) return {
		ok: !1,
		failure: "text-budget"
	};
	let v = (e) => {
		if (_ += e, _ > f) throw new o("text-budget");
	}, y = /* @__PURE__ */ new Set(), b = [];
	try {
		for (let e = 0; e < n.length; e += 1) {
			let t = {
				item: n[e],
				index: e
			}, r = null;
			try {
				r = c(m.evaluate(t));
			} catch {
				return {
					ok: !1,
					failure: "key"
				};
			}
			if (r === null || y.has(r)) return {
				ok: !1,
				failure: "key"
			};
			v(r.length), y.add(r);
			let i = [];
			for (let e of g) {
				if (!e.expression) {
					v(14), i.push({
						ok: !1,
						text: ""
					});
					continue;
				}
				let n = null;
				try {
					n = s(e.expression.evaluate(l(a, e.expression.dependencies, t)));
				} catch {
					n = null;
				}
				n === null ? (v(14), i.push({
					ok: !1,
					text: ""
				})) : (v(n.length), i.push({
					ok: !0,
					text: n
				}));
			}
			b.push({
				key: r,
				cells: i
			});
		}
	} catch (e) {
		return e instanceof o ? {
			ok: !1,
			failure: e.failure
		} : {
			ok: !1,
			failure: "rows"
		};
	}
	return {
		ok: !0,
		model: {
			columns: r.map((e) => e.label),
			rows: b,
			empty: n.length === 0
		}
	};
}
function p(t, n) {
	switch (n) {
		case "label": return t("Data table requires a label.", "数据表需要标签。");
		case "columns": return t("Data table requires between 1 and 20 column definitions.", "数据表需要 1 到 20 个列定义。");
		case "max-rows": return t(`max-rows must be a positive integer no greater than ${e}.`, `max-rows 必须是 1 到 ${e} 之间的整数。`);
		case "rows": return t("Rows must evaluate to a list.", "行数据必须计算为列表。");
		case "rows-budget": return t("Too many rows for this table.", "此数据表的行数超过上限。");
		case "key": return t("Every row needs a unique, non-empty key.", "每一行都需要唯一且非空的键。");
		case "text-budget": return t("The table content exceeds the text budget.", "数据表内容超过文本上限。");
	}
}
var m = /^\s*\{\{([\s\S]*)\}\}\s*$/;
function h(e) {
	if (e === void 0) return null;
	let t = m.exec(e), n = t ? t[1].trim() : "";
	return n === "" ? null : n;
}
function g(e) {
	return e.kind === "comment" || e.kind === "text" && e.text.trim() === "" || e.kind === "paragraph" && e.children.length === 0 && e.text.trim() === "";
}
function _(e) {
	let t = r(e, "label", "").trim();
	if (t === "") return {
		ok: !1,
		failure: "label"
	};
	let n = h(e.content.attrs.rows);
	if (!n) return {
		ok: !1,
		failure: "rows"
	};
	let i = h(e.content.attrs.key);
	if (!i) return {
		ok: !1,
		failure: "key"
	};
	let a = e.content.attrs["max-rows"], o = 100;
	if (a !== void 0 && (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(a.trim()) || (o = Number(a.trim()), !Number.isSafeInteger(o) || o <= 0 || o > 1e3))) return {
		ok: !1,
		failure: "max-rows"
	};
	let s = e.content.children.filter((e) => !g(e)), c = [];
	for (let e of s) {
		let t = e.children.filter((e) => !g(e));
		if (e.kind !== "component" || e.name !== "column" || t.length > 0) return {
			ok: !1,
			failure: "columns"
		};
		let n = (e.attrs.label ?? "").trim(), r = h(e.attrs.value);
		if (n === "" || !r) return {
			ok: !1,
			failure: "columns"
		};
		c.push({
			label: n,
			value: r
		});
	}
	return c.length < 1 || c.length > 20 ? {
		ok: !1,
		failure: "columns"
	} : {
		ok: !0,
		table: {
			label: t,
			rows: n,
			key: i,
			maxRows: o,
			columns: c
		}
	};
}
function v(e) {
	let t = n(e), r = _(e);
	if (!r.ok) return /* @__PURE__ */ i("div", {
		className: "local-error local-data-table-error",
		role: "alert",
		children: p(t.t, r.failure)
	});
	let s = { evaluate: (t) => e.runtime.evaluate(t) }, c;
	try {
		c = f({
			rows: d(s, r.table.rows),
			columns: r.table.columns,
			keyExpression: r.table.key,
			maxRows: r.table.maxRows,
			runtime: s
		});
	} catch (e) {
		c = {
			ok: !1,
			failure: e instanceof o ? e.failure : "rows"
		};
	}
	if (!c.ok) return /* @__PURE__ */ i("div", {
		className: "local-error local-data-table-error",
		role: "alert",
		children: p(t.t, c.failure)
	});
	let { model: l } = c;
	return /* @__PURE__ */ i("div", {
		className: "md-table-scroll local-data-table-scroll",
		"data-local-data-table": "",
		children: /* @__PURE__ */ a("table", {
			className: "md-table local-data-table",
			"aria-label": r.table.label,
			children: [/* @__PURE__ */ i("thead", { children: /* @__PURE__ */ i("tr", { children: l.columns.map((e, t) => /* @__PURE__ */ i("th", {
				scope: "col",
				children: e
			}, `column-${t}`)) }) }), /* @__PURE__ */ i("tbody", { children: l.empty ? /* @__PURE__ */ i("tr", { children: /* @__PURE__ */ i("td", {
				className: "local-data-table-empty",
				colSpan: l.columns.length,
				children: t.t("No rows", "没有数据")
			}) }) : l.rows.map((e) => /* @__PURE__ */ i("tr", { children: e.cells.map((e, n) => /* @__PURE__ */ i("td", { children: e.ok ? e.text : /* @__PURE__ */ i("span", {
				className: "local-error local-data-table-cell-error",
				children: t.t("Cannot compute", "无法计算")
			}) }, `cell-${n}`)) }, e.key)) })]
		})
	});
}
export { v as t };
