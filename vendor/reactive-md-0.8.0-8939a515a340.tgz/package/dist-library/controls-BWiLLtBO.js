import { dt as e, lt as t } from "./preset-core-CKc5YXSM.js";
import { B as n, M as r } from "./config-validation-C5kJYk-J.js";
import { a as i, c as a, d as o, f as s, i as c, l, n as u, o as d, p as f, r as p, s as m, t as h, u as g } from "./react-BbyAgeXc.js";
import { A as _, C as v, D as y, E as b, I as x, M as S, N as C, O as w, P as T, S as E, T as D, _ as O, b as k, c as A, d as j, i as M, j as N, l as P, m as F, n as I, o as L, p as R, r as z, t as B, u as ee, v as V, x as H, y as te } from "./component-utils-BvHL8VGt.js";
import * as U from "react";
import { Children as ne, createContext as re, createElement as W, forwardRef as ie, isValidElement as ae, useCallback as oe, useContext as se, useEffect as ce, useId as le, useInsertionEffect as ue, useLayoutEffect as de, useMemo as fe, useRef as G, useState as K, useSyncExternalStore as pe } from "react";
import { Fragment as me, jsx as q, jsxs as J } from "react/jsx-runtime";
import * as he from "react-dom";
// node_modules/framer-motion/dist/es/utils/use-composed-ref.mjs
function ge(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
function _e(...e) {
	return (t) => {
		let n = !1, r = e.map((e) => {
			let r = ge(e, t);
			return !n && typeof r == "function" && (n = !0), r;
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				typeof n == "function" ? n() : ge(e[t], null);
			}
		};
	};
}
function ve(...e) {
	return U.useCallback(_e(...e), e);
}
// node_modules/framer-motion/dist/es/components/AnimatePresence/PopChild.mjs
var ye = (e) => {
	let { width: t, height: n } = e?.getBoundingClientRect() || {};
	return [t / e?.offsetWidth || 1, n / e?.offsetHeight || 1];
}, be = (e) => {
	let { left: t, top: n } = e.getBoundingClientRect(), r = e;
	for (; r = r.parentElement || r.parentNode?.host;) {
		let { scrollLeft: e, scrollTop: i } = r;
		if (e || i) {
			let [a, o] = ye(r);
			t += e * a, n += i * o;
		}
		if (getComputedStyle(r).position === "fixed") break;
	}
	let [i, a] = ye(e.offsetParent);
	return [t / i, n / a];
}, xe = class extends U.Component {
	getSnapshotBeforeUpdate(e) {
		let t = this.props.getElement();
		if (l(t) && e.isPresent && !this.props.isPresent && this.props.pop !== !1) {
			let e = t.offsetParent, n = l(e) && e.offsetWidth || 0, r = l(e) && e.offsetHeight || 0, i = getComputedStyle(t), a = this.props.sizeRef.current;
			a.height = parseFloat(i.height), a.width = parseFloat(i.width), a.top = t.offsetTop, a.left = t.offsetLeft, a.right = n - a.width - a.left, a.bottom = r - a.height - a.top, a.direction = i.direction, a.point = be(t);
		}
		return null;
	}
	componentDidUpdate() {}
	render() {
		return this.props.children;
	}
};
function Se({ children: e, isPresent: t, anchorX: n, anchorY: r, root: i, pop: o, popNode: s }) {
	let c = le(), l = G(null), u = G({
		width: 0,
		height: 0,
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		direction: "ltr"
	}), { nonce: d } = se(m), f = ve(l, o === !1 ? void 0 : e.props?.ref ?? e?.ref), p = () => l.current || s?.current?.current, h = (e) => {
		let { width: t, height: i, top: a, left: o, right: s, bottom: l, direction: d } = u.current, f = d === "rtl", p = n === "left" ? f ? `right:${s}` : `left:${o}` : f ? `left:${o}` : `right:${s}`, m = r === "bottom" ? `bottom:${l}` : `top:${a}`;
		e?.insertRule(`[data-motion-pop-id="${c}"]{position:absolute!important;width:${t}px!important;height:${i}px!important;${p}px!important;${m}px!important}`);
	};
	return ue(() => {
		let { width: e, height: n } = u.current, r = p();
		if (t || o === !1 || !r || !e || !n) return;
		r.dataset.motionPopId = c;
		let s = r.ownerDocument, l = s.createElement("style");
		d && (l.nonce = d);
		let f = i ?? s.head;
		f.appendChild(l), h(l.sheet);
		let m = 0, g = 0;
		return a.setup(() => {
			let [e, t] = be(r);
			m = u.current.point[0] - e, g = u.current.point[1] - t;
		}), a.read(() => {
			let { sheet: e } = l;
			if (!e || !m && !g) return;
			let t = u.current;
			t.left += m, t.right -= m, t.top += g, t.bottom -= g, e.deleteRule(0), h(e);
		}), () => {
			r.removeAttribute("data-motion-pop-id"), f.contains(l) && f.removeChild(l);
		};
	}, [t]), q(xe, {
		isPresent: t,
		getElement: p,
		sizeRef: u,
		pop: o,
		children: o === !1 ? e : U.cloneElement(e, { ref: f })
	});
}
// node_modules/framer-motion/dist/es/components/AnimatePresence/PresenceChild.mjs
var Ce = ({ children: e, initial: t, isPresent: n, onExitComplete: r, custom: i, presenceAffectsLayout: a, mode: c, anchorX: l, anchorY: u, root: d }) => {
	let f = s(we), p = le(), m = G(), h = G(n), _ = G(r);
	o(() => {
		h.current = n, _.current = r;
	});
	let v = !0, y = fe(() => (v = !1, {
		id: p,
		initial: t,
		isPresent: n,
		custom: i,
		onExitComplete: (e) => {
			f.set(e, !0);
			for (let e of f.values()) if (!e) return;
			r && r();
		},
		register: (e, t) => (f.set(e, !1), t && t.parent?.presenceContext?.id !== p && (m.current = t), () => {
			f.delete(e), !h.current && !f.size && _.current?.();
		})
	}), [
		n,
		f,
		r
	]);
	return a && v && (y = { ...y }), fe(() => {
		f.forEach((e, t) => f.set(t, !1));
	}, [n]), U.useEffect(() => {
		!n && !f.size && r && r();
	}, [n]), e = q(Se, {
		pop: c === "popLayout",
		isPresent: n,
		anchorX: l,
		anchorY: u,
		root: d,
		popNode: m,
		children: e
	}), q(g.Provider, {
		value: y,
		children: e
	});
};
function we() {
	return /* @__PURE__ */ new Map();
}
// node_modules/framer-motion/dist/es/components/AnimatePresence/utils.mjs
var Te = (e) => e.key || "";
function Ee(e) {
	let t = [];
	return ne.forEach(e, (e) => {
		ae(e) && t.push(e);
	}), t;
}
// node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs
var De = ({ children: e, custom: t, initial: n = !0, onExitComplete: r, presenceAffectsLayout: i = !0, mode: a = "sync", propagate: c = !1, anchorX: l = "left", anchorY: u = "top", root: p }) => {
	let [m, h] = d(c), g = fe(() => Ee(e), [e]), _ = c && !m ? [] : g.map(Te), v = G(!0), y = s(() => /* @__PURE__ */ new Map()), b = G(/* @__PURE__ */ new Set()), [x, S] = K(g), [C, w] = K(g);
	o(() => {
		c && !m && !C.length && h?.();
	}, [
		m,
		c,
		C.length,
		h
	]);
	let T = G();
	ce(() => () => {
		let e = T.current;
		T.current = void 0, e?.();
	}, [C]), o(() => {
		v.current = !1;
		for (let e = 0; e < C.length; e++) {
			let t = Te(C[e]);
			_.includes(t) ? (y.delete(t), b.current.delete(t)) : y.get(t) !== !0 && y.set(t, !1);
		}
	}, [
		C,
		_.length,
		_.join("-")
	]);
	let E = [];
	if (g !== x) {
		let e = [...g], t = 0;
		for (let n of C) {
			let r = _.indexOf(Te(n));
			r === -1 ? (e.splice(t++, 0, n), E.push(n)) : t = r + E.length + 1;
		}
		return E.every((e) => y.get(Te(e))) ? e = g : a === "wait" && (e = E), w(Ee(e)), S(g), null;
	}
	process.env.NODE_ENV !== "production" && a === "wait" && C.length > 1 && console.warn("You're attempting to animate multiple children within AnimatePresence, but its mode is set to \"wait\". This will lead to odd visual behaviour.");
	let { forceRender: D } = se(f);
	return q(me, { children: C.map((e) => {
		let o = Te(e), s = c && !m ? !1 : g === C || _.includes(o);
		return q(Ce, {
			isPresent: s,
			initial: !v.current || n ? void 0 : !1,
			custom: t,
			presenceAffectsLayout: i,
			mode: a,
			root: p,
			onExitComplete: s ? void 0 : () => {
				if (b.current.has(o)) return;
				if (y.has(o)) b.current.add(o), y.set(o, !0);
				else return;
				let e = !0;
				y.forEach((t) => {
					t || (e = !1);
				}), e && (D?.(), S([]), c && h?.(), T.current = r);
			},
			anchorX: l,
			anchorY: u,
			children: e
		}, o);
	}) });
};
// node_modules/framer-motion/dist/es/utils/use-motion-value-event.mjs
function Oe(e, t, n) {
	ue(() => e.on(t, n), [
		e,
		t,
		n
	]);
}
// node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs
var ke = (e) => e?.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
// node_modules/lucide-react/dist/esm/shared/src/utils/toLucideIconData.mjs
function Ae(e, t, n = []) {
	if (t == null) throw Error("[lucide]: iconNode is required when icon name is used");
	return {
		name: ke(e),
		size: 24,
		node: t,
		...n.length > 0 ? { aliases: n } : {}
	};
}
// node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs
var je = (e) => {
	let t = "", n = !1;
	for (let r of e) r === "-" || r === "_" || r <= " " ? n = t.length > 0 : (t.length === 0 ? t += r.toLowerCase() : t += n ? r.toUpperCase() : r, n = !1);
	return t;
}, Me = (e) => {
	let t = je(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, Ne = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), Pe = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	"stroke-width": 2,
	"stroke-linecap": "round",
	"stroke-linejoin": "round"
};
// node_modules/lucide-react/dist/esm/shared/src/build/buildLucideIconNode.mjs
function Fe(e) {
	return e != null;
}
function Ie(e, t = {}) {
	let n = t.attributeNames ?? {}, r = (e) => n[e] ?? e, i = e.size ?? e.width ?? Pe.width, a = e.size ?? e.height ?? Pe.height, o = e.aliases?.filter((e) => typeof e == "string" && e.trim() !== "").map((e) => `lucide-${e}`) ?? [], s = [...e.name ? [`lucide-${e.name}`] : [], ...o], c = t.className?.split(" ").filter(Boolean) ?? [], l = t.includeDefaultClasses === !1 ? Ne(...c) : Ne("lucide", ...s, ...c), u = t.absoluteStrokeWidth ? Number(t.strokeWidth ?? Pe["stroke-width"]) * Number(e.size ?? e.width ?? Pe.width) / Number(t.size ?? t.width ?? Pe.width) : t.strokeWidth ?? Pe["stroke-width"];
	return [
		"svg",
		{
			...Object.entries(Pe).reduce((e, [t, n]) => (e[r(t)] = n, e), {}),
			..."color" in t && t.color && { [r("stroke")]: t.color },
			..."size" in t && Fe(t.size) && {
				[r("width")]: t.size,
				[r("height")]: t.size
			},
			..."width" in t && Fe(t.width) && { [r("width")]: t.width },
			..."height" in t && Fe(t.height) && { [r("height")]: t.height },
			[r("stroke-width")]: u,
			...l && { [r("class")]: l },
			[r("viewBox")]: `0 0 ${i} ${a}`,
			...t.hasA11yProp === !1 ? { [r("aria-hidden")]: "true" } : {},
			..."attributes" in t && t.attributes
		},
		e.node.map((e) => {
			let [n, i, a] = e, o = t.nonScalingStroke ? {
				[r("vector-effect")]: "non-scaling-stroke",
				...i
			} : i;
			return a ? [
				n,
				o,
				a
			] : [n, o];
		})
	];
}
// node_modules/lucide-react/dist/esm/shared/src/build/buildLucideIconForReact.mjs
function Le(e, t = {}) {
	return Ie(e, {
		...t,
		attributeNames: {
			...t.attributeNames,
			class: "className",
			"stroke-width": "strokeWidth",
			"stroke-linecap": "strokeLinecap",
			"stroke-linejoin": "strokeLinejoin",
			"vector-effect": "vectorEffect"
		}
	});
}
// node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs
var Re = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, ze = re({}), Be = () => se(ze), Ve = ie(({ color: e, size: t, width: n, height: r, strokeWidth: i, absoluteStrokeWidth: a, nonScalingStroke: o, className: s = "", children: c, iconNode: l = [], icon: u = {
	node: l,
	aliases: [],
	size: 24
}, ...d }, f) => {
	let { size: p = 24, strokeWidth: m = 2, absoluteStrokeWidth: h = !1, nonScalingStroke: g = !1, color: _ = "currentColor", className: v = "" } = Be() ?? {}, y = !!c || Re(d), [b, x, S = []] = Le(u, {
		color: e ?? _,
		width: n ?? t ?? p,
		height: r ?? t ?? p,
		strokeWidth: i ?? m,
		absoluteStrokeWidth: a ?? h,
		nonScalingStroke: o ?? g,
		className: Ne(v, s),
		hasA11yProp: y,
		attributes: d
	});
	return W(b, {
		ref: f,
		...x
	}, [...S.map(([e, t]) => W(e, t)), ...Array.isArray(c) ? c : [c]]);
});
// node_modules/lucide-react/dist/esm/createLucideIcon.mjs
function He(e, t = [], n = []) {
	let r = typeof e == "string" ? Ae(e, t, n) : e, i = ie(({ className: e, ...t }, n) => W(Ve, {
		ref: n,
		icon: r,
		className: e,
		...t
	}));
	return r.name && (i.displayName = Me(r.name)), i;
}
// node_modules/lucide-react/dist/esm/icons/calendar-days.mjs
var Ue = {
	name: "calendar-days",
	size: 24,
	node: [
		["path", {
			d: "M8 2v3",
			key: "1ioesn"
		}],
		["path", {
			d: "M16 2v3",
			key: "otl347"
		}],
		["rect", {
			x: "3",
			y: "3",
			width: "18",
			height: "18",
			rx: "2",
			key: "h1oib"
		}],
		["path", {
			d: "M3 9h18",
			key: "1pudct"
		}],
		["path", {
			d: "M8 13h.01",
			key: "1sbv64"
		}],
		["path", {
			d: "M12 13h.01",
			key: "y0uutt"
		}],
		["path", {
			d: "M16 13h.01",
			key: "wip0gl"
		}],
		["path", {
			d: "M8 17h.01",
			key: "p3bg7i"
		}],
		["path", {
			d: "M12 17h.01",
			key: "p32p05"
		}],
		["path", {
			d: "M16 17h.01",
			key: "ql8jdd"
		}]
	]
};
Ue.node;
var We = He(Ue), Ge = {
	name: "check",
	size: 24,
	node: [["path", {
		d: "M20 6 9 17l-5-5",
		key: "1gmf2c"
	}]]
};
Ge.node;
var Ke = He(Ge), qe = {
	name: "chevron-down",
	size: 24,
	node: [["path", {
		d: "m6 9 6 6 6-6",
		key: "qrunsl"
	}]]
};
qe.node;
var Je = He(qe), Ye = {
	name: "chevron-left",
	size: 24,
	node: [["path", {
		d: "m15 18-6-6 6-6",
		key: "1wnfg3"
	}]]
};
Ye.node;
var Xe = He(Ye), Ze = {
	name: "chevron-right",
	size: 24,
	node: [["path", {
		d: "m9 18 6-6-6-6",
		key: "mthhwq"
	}]]
};
Ze.node;
var Qe = He(Ze), $e = {
	name: "chevron-up",
	size: 24,
	node: [["path", {
		d: "m18 15-6-6-6 6",
		key: "153udz"
	}]]
};
$e.node;
var et = He($e), tt = {
	duration: {
		instant: .12,
		fast: .16,
		exit: .18,
		standard: .24,
		considered: .48
	},
	ease: {
		enter: [
			.16,
			1,
			.3,
			1
		],
		exit: [
			.7,
			0,
			.84,
			0
		],
		standard: [
			.22,
			1,
			.36,
			1
		],
		inOut: [
			.65,
			0,
			.35,
			1
		]
	},
	spring: {
		responsive: {
			type: "spring",
			stiffness: 520,
			damping: 44
		},
		gentle: {
			type: "spring",
			stiffness: 340,
			damping: 34
		},
		snappy: {
			type: "spring",
			visualDuration: .26,
			bounce: 0
		},
		smooth: {
			type: "spring",
			visualDuration: .4,
			bounce: 0
		},
		morph: {
			type: "spring",
			visualDuration: .42,
			bounce: 0
		}
	},
	stagger: {
		char: .016,
		word: .04,
		line: .08,
		item: .035
	},
	blur: {
		subtle: 2,
		soft: 4,
		text: 8
	}
}, nt = (e) => `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`, rt = (e) => {
	let [t = 1970, n = 1, r = 1] = e.split("-").map(Number);
	return new Date(t, n - 1, r);
}, it = (e) => {
	let t = 0, n = () => {
		let r = /* @__PURE__ */ new Date(), i = new Date(r.getFullYear(), r.getMonth(), r.getDate() + 1);
		t = window.setTimeout(() => {
			e(), n();
		}, i.getTime() - r.getTime() + 1e3);
	}, r = () => {
		document.visibilityState === "visible" && e();
	};
	return n(), document.addEventListener("visibilitychange", r), window.addEventListener("focus", e), () => {
		window.clearTimeout(t), document.removeEventListener("visibilitychange", r), window.removeEventListener("focus", e);
	};
}, at = () => nt(/* @__PURE__ */ new Date()), ot = () => "";
function st() {
	let e = pe(it, at, ot);
	return fe(() => e ? rt(e) : void 0, [e]);
}
var Y = {
	calendar: "_calendar_1xv46_7",
	header: "_header_1xv46_9",
	heading: "_heading_1xv46_10",
	navigation: "_navigation_1xv46_10",
	title: "_title_1xv46_13",
	titleRow: "_titleRow_1xv46_15",
	srOnly: "_srOnly_1xv46_17",
	navButton: "_navButton_1xv46_20",
	todayButton: "_todayButton_1xv46_20",
	weekdays: "_weekdays_1xv46_26",
	week: "_week_1xv46_26",
	monthViewport: "_monthViewport_1xv46_30",
	monthBody: "_monthBody_1xv46_31",
	grid: "_grid_1xv46_33",
	placeholderDay: "_placeholderDay_1xv46_34",
	day: "_day_1xv46_35",
	dayNumber: "_dayNumber_1xv46_38",
	highlight: "_highlight_1xv46_40",
	highlightFill: "_highlightFill_1xv46_41",
	selected: "_selected_1xv46_42",
	outside: "_outside_1xv46_45",
	today: "_today_1xv46_20"
}, ct = (e, t, n) => {
	let r = /* @__PURE__ */ new Date(0);
	return r.setFullYear(e, t, n), r.setHours(0, 0, 0, 0), r;
}, lt = (e) => ct(e.getFullYear(), e.getMonth(), e.getDate()), ut = (e) => ct(e.getFullYear(), e.getMonth(), 1), dt = (e, t) => !!(e && t && e.getFullYear() === t.getFullYear() && e.getMonth() === t.getMonth() && e.getDate() === t.getDate()), ft = (e, t) => !!(e && t && e.getFullYear() === t.getFullYear() && e.getMonth() === t.getMonth()), pt = (e, t) => ct(e.getFullYear(), e.getMonth(), e.getDate() + t), mt = (e, t) => ct(e.getFullYear(), e.getMonth() + t, 1), ht = (e, t) => ct(e.getFullYear(), e.getMonth() + t, Math.min(e.getDate(), ct(e.getFullYear(), e.getMonth() + t + 1, 0).getDate())), gt = (e, t) => !!(t && lt(e).getTime() < lt(t).getTime()), _t = (e, t) => !!(t && lt(e).getTime() > lt(t).getTime()), vt = (e) => `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`, yt = (e) => {
	let t = pt(e, -e.getDay());
	return Array.from({ length: 6 }, (e, n) => Array.from({ length: 7 }, (e, r) => pt(t, n * 7 + r)));
}, bt = () => () => {}, xt = () => !0, St = () => !1, { spring: Ct, duration: wt, ease: Tt } = tt, Et = {
	type: "spring",
	visualDuration: .36,
	bounce: 0,
	restDelta: .002
}, Dt = (e) => e.getFullYear() * 12 + e.getMonth(), Ot = (e) => ct(Math.floor(e / 12), (e % 12 + 12) % 12, 1), kt = {
	enter: (e) => ({
		opacity: 0,
		x: e * 12
	}),
	center: {
		opacity: 1,
		x: 0,
		transition: {
			duration: wt.standard,
			ease: Tt.enter
		}
	},
	exit: (e) => ({
		opacity: 0,
		x: e * -12,
		transition: {
			duration: .14,
			ease: Tt.standard
		}
	})
}, At = {
	enter: {
		opacity: 1,
		x: 0
	},
	center: {
		opacity: 1,
		x: 0,
		transition: { duration: 0 }
	},
	exit: {
		opacity: 0,
		transition: { duration: 0 }
	}
};
function jt({ cell: e, reduced: t }) {
	let n = e >= 0, r = i(n ? e % 7 : 0), a = i(n ? Math.floor(e / 7) : 0), o = i(+!!n), s = i(n ? 1 : .6), l = c(() => `translate(calc(${r.get()} * (100% + var(--rmd-calendar-gap))), calc(${a.get()} * (100% + var(--rmd-calendar-gap)))) scale(${s.get()})`), d = G(!n);
	return de(() => {
		if (!n) {
			d.current = !0;
			let e = t ? { duration: 0 } : {
				duration: .14,
				ease: Tt.standard
			}, n = [u(o, 0, e), u(s, .6, e)];
			return () => n.forEach((e) => e.stop());
		}
		let i = e % 7, c = Math.floor(e / 7), l = [];
		return d.current || t ? (r.jump(i), a.jump(c)) : l.push(u(r, i, Ct.morph), u(a, c, Ct.morph)), d.current = !1, l.push(u(o, 1, t ? { duration: 0 } : {
			duration: wt.fast,
			ease: Tt.enter
		}), u(s, 1, t ? { duration: 0 } : Ct.snappy)), () => l.forEach((e) => e.stop());
	}, [
		e,
		n,
		t,
		r,
		a,
		o,
		s
	]), /* @__PURE__ */ q(h.span, {
		className: Y.highlight,
		"data-rmd-part": "selection",
		style: {
			transform: l,
			opacity: o
		},
		"aria-hidden": "true",
		children: /* @__PURE__ */ q("span", { className: Y.highlightFill })
	});
}
function Mt({ index: e, position: t, present: n, children: r }) {
	let i = c(t, (t) => `calc(${(e - t) * 100}% + ${(e - t) * 16}px)`), a = c(t, (t) => 1 - Math.min(1, Math.abs(e - t)) * .6);
	return /* @__PURE__ */ q(h.div, {
		className: Y.monthBody,
		style: {
			x: i,
			opacity: a
		},
		"data-present": n || void 0,
		"aria-hidden": !n || void 0,
		inert: !n,
		children: r
	});
}
function Nt({ value: e, onChange: t, month: n, onMonthChange: r, minDate: a, maxDate: o, disabledDates: s, locale: c = "en-US", className: l, showToday: d = !1, todayLabel: f = "Today", previousMonthLabel: m = "Previous month", nextMonthLabel: g = "Next month" }) {
	let _ = le(), v = st(), y = pe(bt, xt, St), b = (p() ?? !1) && y, [x, S] = K(() => e ? ut(e) : void 0), [C, w] = K(e), T = G(null), E = G(null), D = e ?? v, O = n ? ut(n) : x ?? (D && ut(D));
	!n && !x && O && S(O);
	let k = O?.getTime(), A = O ? vt(O) : "pending", [j, M] = K(k), [N, P] = K(0);
	j !== k && (M(k), P(j === void 0 || k === void 0 ? 0 : k > j ? 1 : -1));
	let F = fe(() => k === void 0 ? [] : yt(new Date(k)), [k]), I = O ? Dt(O) : 0, L = i(I), [R, z] = K([I, I]);
	Oe(L, "change", (e) => {
		let t = [Math.floor(e + .001), Math.ceil(e - .001)];
		z((e) => e[0] === t[0] && e[1] === t[1] ? e : t);
	});
	let B = O !== void 0, ee = G(B);
	de(() => {
		if (!B) return;
		let e = L.get();
		if (e === I) return;
		if (!ee.current || b) {
			ee.current = !0, L.jump(I);
			return;
		}
		Math.abs(I - e) > 2 && L.jump(I - Math.sign(I - e));
		let t = u(L, I, Et);
		return () => t.stop();
	}, [
		B,
		I,
		b,
		L
	]);
	let V = Array.from(/* @__PURE__ */ new Set([
		R[0],
		R[1],
		I
	])).sort((e, t) => e - t), H = fe(() => new Intl.DateTimeFormat(c, {
		month: "long",
		year: "numeric"
	}), [c]), te = fe(() => new Intl.DateTimeFormat(c, { weekday: "short" }), [c]), U = fe(() => Array.from({ length: 7 }, (e, t) => te.format(new Date(2024, 0, 7 + t))), [te]), ne = O ? H.format(O) : "", re = e ? vt(e) : "", [W, ie] = K({
		key: re,
		date: e
	}), [ae, oe] = K({
		from: "",
		to: "",
		distance: 0
	});
	if (W.key !== re) {
		let t = W.date && e ? Math.round((lt(e).getTime() - lt(W.date).getTime()) / 864e5) : 0, n = W.date && e ? e.getDay() - W.date.getDay() : 0;
		ie({
			key: re,
			date: e
		}), oe({
			from: W.key,
			to: re,
			distance: Math.hypot(n, (t - n) / 7)
		});
	}
	let se = (e) => {
		if (!ae.distance || b || e !== ae.to && e !== ae.from) return;
		let t = e === ae.to ? Math.min(260, 95 + 85 * Math.log(ae.distance)) : Math.max(20, 130 / ae.distance);
		return { "--number-delay": `${Math.round(t)}ms` };
	}, ce = (e) => gt(e, a) || _t(e, o) || !!s?.(e), ue = O && mt(O, -1), he = O && mt(O, 1), ge = !!(ue && a && ue.getTime() < ut(a).getTime()), _e = !!(he && o && he.getTime() > ut(o).getTime()), ve = !!(v && !ce(v) && t), ye = !(!v || !ft(O, v) || ve && !dt(e, v)), be = (() => {
		let t = (e) => e && ft(e, O) && !ce(e) ? vt(e) : "";
		return t(C) || t(e) || t(v) || vt(F.flat().find((e) => ft(e, O) && !ce(e)) ?? /* @__PURE__ */ new Date(0));
	})(), xe = (e) => {
		let t = ut(e);
		n || S(t), r?.(t);
	};
	de(() => {
		let e = E.current;
		if (!e) return;
		let t = T.current?.querySelector(`[data-present] [data-date="${e}"]`);
		t && (E.current = null, t.focus({ preventScroll: !0 }));
	});
	let Se = (e, t, n) => {
		let r = gt(t, a) && a ? lt(a) : _t(t, o) && o ? lt(o) : t;
		for (let e = 0; e < 42 && ce(r); e += 1) r = pt(r, n);
		ce(r) || dt(r, e) || (w(r), E.current = vt(r), ft(r, O) || xe(r));
	}, Ce = (e, n) => {
		if (e.key === "Enter" || e.key === " ") {
			e.preventDefault(), ce(n) || t?.(n);
			return;
		}
		let r = {
			ArrowLeft: [pt(n, -1), -1],
			ArrowRight: [pt(n, 1), 1],
			ArrowUp: [pt(n, -7), -1],
			ArrowDown: [pt(n, 7), 1],
			Home: [pt(n, -n.getDay()), 1],
			End: [pt(n, 6 - n.getDay()), -1],
			PageUp: [ht(n, e.shiftKey ? -12 : -1), -1],
			PageDown: [ht(n, e.shiftKey ? 12 : 1), 1]
		}[e.key];
		r && (e.preventDefault(), Se(n, r[0], r[1]));
	}, we = () => {
		v && O && !ye && (w(v), ft(v, O) || xe(v), ve && !dt(e, v) && t?.(v));
	}, Te = (...e) => e.filter(Boolean).join(" "), Ee = (t) => {
		if (!e) return -1;
		let n = pt(t, -t.getDay()), r = Math.round((lt(e).getTime() - n.getTime()) / 864e5);
		return r >= 0 && r < 42 ? r : -1;
	}, ke = (n, r) => /* @__PURE__ */ J(me, { children: [/* @__PURE__ */ q(jt, {
		cell: Ee(n),
		reduced: b
	}), /* @__PURE__ */ q("div", {
		className: Y.grid,
		role: "grid",
		"aria-label": H.format(n),
		"data-rmd-part": "grid",
		children: yt(n).map((i) => /* @__PURE__ */ q("div", {
			className: Y.week,
			role: "row",
			"data-rmd-part": "week",
			children: i.map((i) => {
				let a = vt(i), o = dt(i, e), s = dt(i, v);
				return /* @__PURE__ */ q("button", {
					type: "button",
					role: "gridcell",
					"data-date": a,
					"data-rmd-part": "day",
					"aria-label": i.toLocaleDateString(c, { dateStyle: "full" }),
					"aria-selected": o,
					"aria-current": s ? "date" : void 0,
					tabIndex: r && a === be ? 0 : -1,
					disabled: ce(i),
					style: r ? se(a) : void 0,
					className: Te(Y.day, !ft(i, n) && Y.outside, o && Y.selected, s && Y.today),
					onFocus: () => w(i),
					onKeyDown: (e) => Ce(e, i),
					onClick: () => t?.(i),
					children: /* @__PURE__ */ q("span", {
						className: Y.dayNumber,
						"data-rmd-part": "day-number",
						children: i.getDate()
					})
				}, a);
			})
		}, vt(i[0])))
	})] });
	return /* @__PURE__ */ J("section", {
		className: Te(Y.calendar, l),
		"aria-labelledby": _,
		"data-rmd-component": "calendar",
		"data-rmd-part": "root",
		children: [
			/* @__PURE__ */ J("div", {
				className: Y.header,
				"data-rmd-part": "header",
				children: [
					/* @__PURE__ */ J("h2", {
						id: _,
						className: Y.heading,
						"data-rmd-part": "heading",
						children: [/* @__PURE__ */ q("span", {
							className: Y.srOnly,
							children: ne
						}), /* @__PURE__ */ q("span", {
							className: Y.title,
							"aria-hidden": "true",
							children: /* @__PURE__ */ q(De, {
								initial: !1,
								custom: N,
								children: O && /* @__PURE__ */ q(h.span, {
									className: Y.titleRow,
									custom: N,
									variants: b || !N ? At : kt,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: ne
								}, A)
							})
						})]
					}),
					/* @__PURE__ */ q("span", {
						className: Y.srOnly,
						"aria-live": "polite",
						children: N ? ne : ""
					}),
					/* @__PURE__ */ J("div", {
						className: Y.navigation,
						"data-rmd-part": "navigation",
						children: [
							d && /* @__PURE__ */ q("button", {
								type: "button",
								className: Y.todayButton,
								"data-rmd-part": "today",
								"aria-disabled": ye || void 0,
								"aria-label": v ? `${f}, ${v.toLocaleDateString(c, { dateStyle: "full" })}` : f,
								onClick: we,
								children: f
							}),
							/* @__PURE__ */ q("button", {
								type: "button",
								className: Y.navButton,
								"data-rmd-part": "previous-month",
								"aria-label": m,
								"aria-disabled": ge || void 0,
								onClick: () => {
									!ge && ue && xe(ue);
								},
								children: /* @__PURE__ */ q(Xe, {
									size: 16,
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ q("button", {
								type: "button",
								className: Y.navButton,
								"data-rmd-part": "next-month",
								"aria-label": g,
								"aria-disabled": _e || void 0,
								onClick: () => {
									!_e && he && xe(he);
								},
								children: /* @__PURE__ */ q(Qe, {
									size: 16,
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							})
						]
					})
				]
			}),
			/* @__PURE__ */ q("div", {
				className: Y.weekdays,
				"data-rmd-part": "weekdays",
				"aria-hidden": "true",
				children: U.map((e, t) => /* @__PURE__ */ q("span", { children: e.slice(0, 2) }, `${e}-${t}`))
			}),
			/* @__PURE__ */ q("div", {
				className: Y.monthViewport,
				"data-rmd-part": "viewport",
				ref: T,
				children: O ? V.map((e) => /* @__PURE__ */ q(Mt, {
					index: e,
					position: L,
					present: e === I,
					children: ke(Ot(e), e === I)
				}, e)) : /* @__PURE__ */ q("div", {
					className: Y.monthBody,
					"aria-hidden": "true",
					children: /* @__PURE__ */ q("div", {
						className: Y.grid,
						children: Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ q("div", {
							className: Y.week,
							children: Array.from({ length: 7 }, (e, t) => /* @__PURE__ */ q("span", { className: Y.placeholderDay }, t))
						}, t))
					})
				})
			})
		]
	});
}
var Pt = {
	field: "_field_odvga_7",
	label: "_label_odvga_8",
	anchor: "_anchor_odvga_9",
	trigger: "_trigger_odvga_11",
	valueText: "_valueText_odvga_17",
	value: "_value_odvga_17",
	part: "_part_odvga_18",
	partValue: "_partValue_odvga_20",
	placeholder: "_placeholder_odvga_21",
	srOnly: "_srOnly_odvga_22",
	chevron: "_chevron_odvga_23",
	popover: "_popover_odvga_26",
	footer: "_footer_odvga_29",
	status: "_status_odvga_31",
	description: "_description_odvga_37"
}, Ft = (e) => {
	let t = new Date(e);
	return t.setDate(1), t.setHours(0, 0, 0, 0), t;
}, { spring: It, duration: Lt, ease: Rt, blur: zt } = tt, Bt = { duration: Lt.instant }, Vt = {
	enter: (e) => ({
		opacity: 0,
		y: `${e * .35}em`,
		filter: `blur(${zt.soft}px)`
	}),
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: {
			duration: Lt.standard,
			ease: Rt.enter
		}
	},
	exit: (e) => ({
		opacity: 0,
		y: `${e * -.3}em`,
		filter: `blur(${zt.subtle}px)`,
		transition: {
			duration: .14,
			ease: Rt.standard
		}
	})
}, Ht = {
	enter: { opacity: 0 },
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: Bt
	},
	exit: {
		opacity: 0,
		transition: Bt
	}
}, Ut = {
	enter: {
		opacity: 0,
		y: "0.3em",
		filter: `blur(${zt.soft}px)`
	},
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: {
			duration: Lt.standard,
			ease: Rt.enter
		}
	},
	exit: {
		opacity: 0,
		y: "-0.3em",
		filter: `blur(${zt.subtle}px)`,
		transition: {
			duration: .14,
			ease: Rt.standard
		}
	}
};
function Wt({ label: e, value: t, onChange: n, description: r, placeholder: i = "Select a date", minDate: a, maxDate: o, disabledDates: s, locale: c = "en-US", format: l = {
	month: "short",
	day: "numeric",
	year: "numeric"
}, showToday: u, invalid: d, describedBy: f, todayLabel: m, previousMonthLabel: g, nextMonthLabel: _, clearLabel: v = "Clear", calendarLabel: y, statusLabel: b, id: x, className: S, disabled: C, ...w }) {
	let T = le(), E = x ?? T, D = r ? `${E}-description` : void 0, O = [D, f].filter(Boolean).join(" ") || void 0, [k, A] = K(!1);
	ce(() => {
		C && A(!1);
	}, [C]);
	let [j, M] = K(Ft(t ?? /* @__PURE__ */ new Date())), N = G(null), P = G(null), F = G(null), I = G(void 0), L = new Intl.DateTimeFormat(c, l), R = p() ?? !1, z = t?.getTime() ?? null, [B, ee] = K(z), [V, H] = K(1);
	B !== z && (ee(z), H(z === null || B === null || z >= B ? 1 : -1));
	let te = t ? L.format(t) : null, U = te ?? i;
	ce(() => {
		let e = (e) => {
			N.current?.contains(e.target) || (window.clearTimeout(I.current), A(!1));
		};
		return document.addEventListener("pointerdown", e), () => {
			document.removeEventListener("pointerdown", e), window.clearTimeout(I.current);
		};
	}, []), ce(() => {
		k && F.current?.querySelector("[data-present] [data-date][tabindex=\"0\"]")?.focus({ preventScroll: !0 });
	}, [k]);
	let ne = () => {
		window.clearTimeout(I.current), F.current?.contains(document.activeElement) && P.current?.focus(), A(!1);
	}, re = () => {
		window.clearTimeout(I.current), M(Ft(t ?? /* @__PURE__ */ new Date())), A(!0);
	}, W = (e) => {
		n?.(e), window.clearTimeout(I.current), R || !e ? ne() : I.current = window.setTimeout(ne, 300);
	}, ie = (e) => {
		e.key !== "ArrowDown" && e.key !== "Enter" && e.key !== " " || k || (e.preventDefault(), re()), e.key === "Escape" && ne();
	};
	return /* @__PURE__ */ J("div", {
		className: [Pt.field, S].filter(Boolean).join(" "),
		ref: N,
		onBlur: (e) => {
			let t = e.relatedTarget;
			k && t && !N.current?.contains(t) && (window.clearTimeout(I.current), A(!1));
		},
		"data-rmd-component": "date-picker",
		"data-rmd-part": "field",
		children: [
			/* @__PURE__ */ q("label", {
				className: Pt.label,
				htmlFor: E,
				"data-rmd-part": "label",
				children: e
			}),
			/* @__PURE__ */ J("div", {
				className: Pt.anchor,
				"data-rmd-part": "anchor",
				children: [/* @__PURE__ */ J("button", {
					...w,
					ref: P,
					id: E,
					type: "button",
					disabled: C,
					"aria-haspopup": "dialog",
					"aria-expanded": k,
					"aria-describedby": O,
					"aria-invalid": d || void 0,
					"data-rmd-part": "trigger",
					className: Pt.trigger,
					onClick: () => k ? ne() : re(),
					onKeyDown: ie,
					children: [
						/* @__PURE__ */ q(We, {
							size: 16,
							strokeWidth: 1.75,
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ q("span", {
							className: Pt.srOnly,
							children: U
						}),
						/* @__PURE__ */ q("span", {
							className: Pt.valueText,
							"data-rmd-part": "value",
							"aria-hidden": "true",
							children: /* @__PURE__ */ q(De, {
								mode: "popLayout",
								initial: !1,
								custom: 1,
								children: t ? /* @__PURE__ */ q(h.span, {
									className: Pt.value,
									custom: V,
									variants: R ? Ht : Vt,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: U
								}, z) : /* @__PURE__ */ q(h.span, {
									className: Pt.placeholder,
									custom: -1,
									variants: R ? Ht : Vt,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: i
								}, "placeholder")
							})
						}),
						/* @__PURE__ */ q(Je, {
							className: Pt.chevron,
							"data-rmd-part": "chevron",
							size: 16,
							strokeWidth: 1.75,
							"aria-hidden": "true"
						})
					]
				}), /* @__PURE__ */ q(De, { children: k && /* @__PURE__ */ J(h.div, {
					ref: F,
					className: Pt.popover,
					"data-rmd-part": "popover",
					role: "dialog",
					"data-rmd-date-popover": "",
					"aria-label": y ?? `${e} calendar`,
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), ne());
					},
					initial: R ? { opacity: 0 } : {
						opacity: 0,
						y: -8,
						scale: .95
					},
					animate: {
						opacity: 1,
						y: 0,
						scale: 1,
						transition: R ? Bt : {
							...It.snappy,
							opacity: {
								duration: Lt.fast,
								ease: Rt.enter
							}
						}
					},
					exit: {
						opacity: 0,
						...R ? {} : {
							y: -6,
							scale: .97
						},
						transition: {
							duration: .14,
							ease: Rt.standard
						}
					},
					children: [/* @__PURE__ */ q(Nt, {
						value: t,
						onChange: W,
						month: j,
						onMonthChange: M,
						minDate: a,
						maxDate: o,
						disabledDates: s,
						locale: c,
						showToday: u,
						todayLabel: m,
						previousMonthLabel: g,
						nextMonthLabel: _
					}), /* @__PURE__ */ J("div", {
						className: Pt.footer,
						"data-rmd-part": "footer",
						children: [/* @__PURE__ */ q("button", {
							type: "button",
							"data-rmd-part": "clear",
							onClick: () => W(void 0),
							disabled: !t,
							children: v
						}), /* @__PURE__ */ q("span", {
							className: Pt.status,
							"data-rmd-part": "status",
							children: /* @__PURE__ */ q(De, {
								initial: !1,
								children: /* @__PURE__ */ q(h.span, {
									variants: R ? Ht : Ut,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: b ? b(te) : te ? `Selected ${te}` : "Choose a day"
								}, z ?? "none")
							})
						})]
					})]
				}) })]
			}),
			r && /* @__PURE__ */ q("span", {
				id: D,
				className: Pt.description,
				"data-rmd-part": "description",
				children: r
			})
		]
	});
}
// src/components/uiarc/rmd-motion.ts
var Gt = [
	.22,
	.61,
	.36,
	1
], Kt = {
	fast: {
		type: "tween",
		duration: .15,
		ease: Gt
	},
	base: {
		type: "tween",
		duration: .22,
		ease: Gt
	}
}, qt = Object.defineProperty, Jt = (e, t) => qt(e, "name", {
	value: t,
	configurable: !0
});
function Yt(e, [t, n]) {
	return Math.min(n, Math.max(t, e));
}
Jt(Yt, "clamp");
// node_modules/@radix-ui/primitive/dist/index.mjs
var Xt = Object.defineProperty, Zt = (e, t) => Xt(e, "name", {
	value: t,
	configurable: !0
}), Qt = !!(typeof window < "u" && window.document && window.document.createElement);
function X(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
	return /* @__PURE__ */ Zt(function(r) {
		if (e?.(r), n === !1 || !r || !r.defaultPrevented) return t?.(r);
	}, "handleEvent");
}
Zt(X, "composeEventHandlers");
function $t(e) {
	if (!Qt) throw Error("Cannot access window outside of the DOM");
	return e?.ownerDocument?.defaultView ?? window;
}
Zt($t, "getOwnerWindow");
function en(e) {
	if (!Qt) throw Error("Cannot access document outside of the DOM");
	return e?.ownerDocument ?? document;
}
Zt(en, "getOwnerDocument");
function tn(e, t = !1) {
	let { activeElement: n } = en(e);
	if (!n?.nodeName) return null;
	if (nn(n) && n.contentDocument) return tn(n.contentDocument.body, t);
	if (t) {
		let e = n.getAttribute("aria-activedescendant");
		if (e) {
			let t = en(n).getElementById(e);
			if (t) return t;
		}
	}
	return n;
}
Zt(tn, "getActiveElement");
function nn(e) {
	return e.tagName === "IFRAME";
}
Zt(nn, "isFrame");
// node_modules/@radix-ui/react-context/dist/index.mjs
var rn = Object.defineProperty, an = (e, t) => rn(e, "name", {
	value: t,
	configurable: !0
});
// @__NO_SIDE_EFFECTS__
function on(e, t) {
	let n = U.createContext(t);
	n.displayName = e + "Context";
	let r = /* @__PURE__ */ an((e) => {
		let { children: t, ...r } = e, i = U.useMemo(() => r, Object.values(r));
		return /* @__PURE__ */ q(n.Provider, {
			value: i,
			children: t
		});
	}, "Provider");
	r.displayName = e + "Provider";
	function i(r, i = {}) {
		let { optional: a = !1 } = i, o = U.useContext(n);
		if (o) return o;
		if (t !== void 0) return t;
		if (!a) throw Error(`\`${r}\` must be used within \`${e}\``);
	}
	return an(i, "useContext"), [r, i];
}
an(on, "createContext");
// @__NO_SIDE_EFFECTS__
function sn(e, t = []) {
	let n = [];
	function r(t, r) {
		let i = U.createContext(r);
		i.displayName = t + "Context";
		let a = n.length;
		n = [...n, r];
		let o = /* @__PURE__ */ an((t) => {
			let { scope: n, children: r, ...o } = t, s = n?.[e]?.[a] || i, c = U.useMemo(() => o, Object.values(o));
			return /* @__PURE__ */ q(s.Provider, {
				value: c,
				children: r
			});
		}, "Provider");
		o.displayName = t + "Provider";
		function s(n, o, s = {}) {
			let { optional: c = !1 } = s, l = o?.[e]?.[a] || i, u = U.useContext(l);
			if (u) return u;
			if (r !== void 0) return r;
			if (!c) throw Error(`\`${n}\` must be used within \`${t}\``);
		}
		return an(s, "useContext"), [o, s];
	}
	an(r, "createContext");
	let i = /* @__PURE__ */ an(() => {
		let t = n.map((e) => U.createContext(e));
		return /* @__PURE__ */ an(function(n) {
			let r = n?.[e] || t;
			return U.useMemo(() => ({ [`__scope${e}`]: {
				...n,
				[e]: r
			} }), [n, r]);
		}, "useScope");
	}, "createScope");
	return i.scopeName = e, [r, cn(i, ...t)];
}
an(sn, "createContextScope");
function cn(...e) {
	let t = e[0];
	if (e.length === 1) return t;
	let n = /* @__PURE__ */ an(() => {
		let n = e.map((e) => ({
			useScope: e(),
			scopeName: e.scopeName
		}));
		return /* @__PURE__ */ an(function(e) {
			let r = n.reduce((t, { useScope: n, scopeName: r }) => {
				let i = n(e)[`__scope${r}`];
				return {
					...t,
					...i
				};
			}, {});
			return U.useMemo(() => ({ [`__scope${t.scopeName}`]: r }), [r]);
		}, "useComposedScopes");
	}, "createScope");
	return n.scopeName = t.scopeName, n;
}
an(cn, "composeContextScopes");
// node_modules/@radix-ui/react-compose-refs/dist/index.mjs
var ln = Object.defineProperty, un = (e, t) => ln(e, "name", {
	value: t,
	configurable: !0
});
function dn(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
un(dn, "setRef");
function fn(...e) {
	return (t) => {
		let n = !1, r = e.map((e) => {
			let r = dn(e, t);
			return !n && typeof r == "function" && (n = !0), r;
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				typeof n == "function" ? n() : dn(e[t], null);
			}
		};
	};
}
un(fn, "composeRefs");
function Z(...e) {
	return U.useCallback(fn(...e), e);
}
un(Z, "useComposedRefs");
// node_modules/@radix-ui/react-slot/dist/index.mjs
var pn = Object.defineProperty, mn = (e, t) => pn(e, "name", {
	value: t,
	configurable: !0
});
// @__NO_SIDE_EFFECTS__
function hn(e) {
	let t = U.forwardRef((t, n) => {
		let { children: r, ...i } = t, a = null, o = !1, s = [];
		r = Tn(r), U.Children.forEach(r, (e) => {
			if (xn(e)) {
				o = !0;
				let t = e, n = "child" in t.props ? t.props.child : t.props.children;
				for (; Cn(n) && typeof kn == "function";) n = kn(n._payload);
				a = vn(t, n), s.push(a?.props?.children);
			} else s.push(e);
		}), a ? a = U.cloneElement(a, void 0, s) : !o && U.Children.count(r) === 1 && U.isValidElement(r) && (a = r);
		let c = a ? bn(a) : void 0, l = Z(n, c);
		if (!a) {
			if (r || r === 0) throw Error(o ? On(e) : Dn(e));
			return r;
		}
		let u = yn(i, a.props ?? {});
		return a.type !== U.Fragment && (u.ref = n ? l : c), U.cloneElement(a, u);
	});
	return t.displayName = `${e}.Slot`, t;
}
mn(hn, "createSlot");
var gn = Symbol.for("radix.slottable");
// @__NO_SIDE_EFFECTS__
function _n(e) {
	let t = /* @__PURE__ */ mn((e) => "child" in e ? e.children(e.child) : e.children, "Slottable");
	return t.displayName = `${e}.Slottable`, t.__radixId = gn, t;
}
mn(_n, "createSlottable");
var vn = /* @__PURE__ */ mn((e, t) => "child" in e.props ? U.isValidElement(t) ? U.cloneElement(t, void 0, e.props.children(t.props.children)) : null : U.isValidElement(t) ? t : null, "getSlottableElementFromSlottable");
function yn(e, t) {
	let n = { ...t };
	for (let r in t) {
		let i = e[r], a = t[r];
		/^on[A-Z]/.test(r) ? i && a ? n[r] = (...e) => {
			let t = a(...e);
			return i(...e), t;
		} : i && (n[r] = i) : r === "style" ? n[r] = {
			...i,
			...a
		} : r === "className" ? n[r] = [i, a].filter(Boolean).join(" ") : r === "aria-describedby" && (n[r] = En(a, i));
	}
	return {
		...e,
		...n
	};
}
mn(yn, "mergeProps");
function bn(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
mn(bn, "getElementRef");
function xn(e) {
	return U.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === gn;
}
mn(xn, "isSlottable");
var Sn = Symbol.for("react.lazy");
function Cn(e) {
	return typeof e == "object" && !!e && "$$typeof" in e && e.$$typeof === Sn && "_payload" in e && wn(e._payload);
}
mn(Cn, "isLazyComponent");
function wn(e) {
	return typeof e == "object" && !!e && "then" in e;
}
mn(wn, "isPromiseLike");
function Tn(e) {
	let t = e;
	for (; Cn(t) && typeof kn == "function";) t = kn(t._payload);
	return t;
}
mn(Tn, "useUnwrappedLazy");
function En(...e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) if (typeof n == "string") for (let e of String(n).trim().split(/\s+/)) e && t.add(e);
	return t.size > 0 ? Array.from(t).join(" ") : void 0;
}
mn(En, "concatAriaDescribedby");
var Dn = /* @__PURE__ */ mn((e) => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`, "createSlotError"), On = /* @__PURE__ */ mn((e) => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`, "createSlottableError"), kn = U.use, An = globalThis?.document ? U.useLayoutEffect : () => {}, jn = Object.defineProperty, Mn = (e, t) => jn(e, "name", {
	value: t,
	configurable: !0
});
// @__NO_SIDE_EFFECTS__
function Nn(e) {
	let t = e + "CollectionProvider", [n, r] = /* @__PURE__ */ sn(t), [i, a] = n(t, {
		collectionRef: { current: null },
		itemMap: /* @__PURE__ */ new Map()
	}), o = /* @__PURE__ */ Mn((e) => {
		let { scope: t, children: n } = e, r = U.useRef(null), a = U.useRef(/* @__PURE__ */ new Map()).current;
		return /* @__PURE__ */ q(i, {
			scope: t,
			itemMap: a,
			collectionRef: r,
			children: n
		});
	}, "CollectionProvider");
	o.displayName = t;
	let s = e + "CollectionSlot", c = /* @__PURE__ */ hn(s), l = U.forwardRef((e, t) => {
		let { scope: n, children: r } = e, i = Z(t, a(s, n).collectionRef);
		return /* @__PURE__ */ q(c, {
			ref: i,
			children: r
		});
	});
	l.displayName = s;
	let u = e + "CollectionItemSlot", d = "data-radix-collection-item", f = /* @__PURE__ */ hn(u), p = U.forwardRef((e, t) => {
		let { scope: n, children: r, ...i } = e, o = U.useRef(null), s = Z(t, o), c = a(u, n);
		return U.useEffect(() => (c.itemMap.set(o, {
			ref: o,
			...i
		}), () => void c.itemMap.delete(o))), /* @__PURE__ */ q(f, {
			[d]: "",
			ref: s,
			children: r
		});
	});
	p.displayName = u;
	function m(t) {
		let n = a(e + "CollectionConsumer", t);
		return U.useCallback(() => {
			let e = n.collectionRef.current;
			if (!e) return [];
			let t = Array.from(e.querySelectorAll(`[${d}]`));
			return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current));
		}, [n.collectionRef, n.itemMap]);
	}
	return Mn(m, "useCollection"), [
		{
			Provider: o,
			Slot: l,
			ItemSlot: p
		},
		m,
		r
	];
}
Mn(Nn, "createCollection");
var Pn = /* @__PURE__ */ new WeakMap(), Fn = class e extends Map {
	static {
		Mn(this, "OrderedDict");
	}
	#e;
	constructor(e) {
		super(e), this.#e = [...super.keys()], Pn.set(this, !0);
	}
	set(e, t) {
		return Pn.get(this) && !this.has(e) && this.#e.push(e), super.set(e, t), this;
	}
	insert(e, t, n) {
		let r = this.has(t), i = r ? this.size : this.size + 1, a = Rn(e), o = a >= 0 ? Math.min(a, i - 1) : Math.max(i + a, 0);
		if (r ? this.#e.indexOf(t) === o : o === this.size) return this.set(t, n), this;
		let s = this.#e.filter((e) => e !== t);
		s.splice(o, 0, t);
		let c = s.map((e) => [e, e === t ? n : this.get(e)]);
		this.clear();
		for (let [e, t] of c) this.set(e, t);
		return this;
	}
	with(t, n, r) {
		let i = new e(this);
		return i.insert(t, n, r), i;
	}
	before(e) {
		let t = this.#e.indexOf(e) - 1;
		if (!(t < 0)) return this.entryAt(t);
	}
	setBefore(e, t, n) {
		let r = this.#e.indexOf(e);
		if (r === -1) return this;
		let i = this.#e.indexOf(t), a = i !== -1 && i < r ? r - 1 : r;
		return this.insert(a, t, n);
	}
	after(e) {
		let t = this.#e.indexOf(e);
		if (t = t === -1 || t === this.size - 1 ? -1 : t + 1, t !== -1) return this.entryAt(t);
	}
	setAfter(e, t, n) {
		let r = this.#e.indexOf(e);
		if (r === -1) return this;
		let i = this.#e.indexOf(t), a = i !== -1 && i <= r ? r : r + 1;
		return this.insert(a, t, n);
	}
	first() {
		return this.entryAt(0);
	}
	last() {
		return this.entryAt(-1);
	}
	clear() {
		return this.#e = [], super.clear();
	}
	delete(e) {
		let t = super.delete(e);
		return t && this.#e.splice(this.#e.indexOf(e), 1), t;
	}
	deleteAt(e) {
		let t = this.keyAt(e);
		return t !== void 0 && this.delete(t);
	}
	at(e) {
		let t = In(this.#e, e);
		if (t !== void 0) return this.get(t);
	}
	entryAt(e) {
		let t = In(this.#e, e);
		if (t !== void 0) return [t, this.get(t)];
	}
	indexOf(e) {
		return this.#e.indexOf(e);
	}
	keyAt(e) {
		return In(this.#e, e);
	}
	from(e, t) {
		let n = this.indexOf(e);
		if (n === -1) return;
		let r = n + t;
		return r < 0 && (r = 0), r >= this.size && (r = this.size - 1), this.at(r);
	}
	keyFrom(e, t) {
		let n = this.indexOf(e);
		if (n === -1) return;
		let r = n + t;
		return r < 0 && (r = 0), r >= this.size && (r = this.size - 1), this.keyAt(r);
	}
	find(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return r;
			n++;
		}
	}
	findIndex(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return n;
			n++;
		}
		return -1;
	}
	filter(t, n) {
		let r = [], i = 0;
		for (let e of this) Reflect.apply(t, n, [
			e,
			i,
			this
		]) && r.push(e), i++;
		return new e(r);
	}
	map(t, n) {
		let r = [], i = 0;
		for (let e of this) r.push([e[0], Reflect.apply(t, n, [
			e,
			i,
			this
		])]), i++;
		return new e(r);
	}
	reduce(...e) {
		let [t, n] = e, r = e.length > 1;
		if (!r && this.size === 0) throw TypeError("Reduce of empty OrderedDict with no initial value");
		let i = 0, a = n;
		for (let e of this) a = i === 0 && !r ? e : Reflect.apply(t, this, [
			a,
			e,
			i,
			this
		]), i++;
		return a;
	}
	reduceRight(...e) {
		let [t, n] = e, r = e.length > 1;
		if (!r && this.size === 0) throw TypeError("Reduce of empty OrderedDict with no initial value");
		let i = n;
		for (let e = this.size - 1; e >= 0; e--) {
			let n = this.entryAt(e);
			i = e === this.size - 1 && !r ? n : Reflect.apply(t, this, [
				i,
				n,
				e,
				this
			]);
		}
		return i;
	}
	sort(e) {
		if (typeof e != "function") throw TypeError("OrderedDict.sort requires a compare function");
		let t = [...this.entries()].sort(e);
		this.clear();
		for (let [e, n] of t) this.set(e, n);
		return this;
	}
	toSorted(t) {
		if (typeof t != "function") throw TypeError("OrderedDict.toSorted requires a compare function");
		let n = [...this.entries()].sort(t);
		return new e(n);
	}
	toReversed() {
		let t = new e();
		for (let e = this.size - 1; e >= 0; e--) {
			let n = this.keyAt(e), r = this.get(n);
			t.set(n, r);
		}
		return t;
	}
	toSpliced(...t) {
		let n = [...this.entries()];
		return n.splice(...t), new e(n);
	}
	slice(t, n) {
		let r = new e();
		for (let e of this.#e.slice(t, n)) r.set(e, this.get(e));
		return r;
	}
	every(e, t) {
		let n = 0;
		for (let r of this) {
			if (!Reflect.apply(e, t, [
				r,
				n,
				this
			])) return !1;
			n++;
		}
		return !0;
	}
	some(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return !0;
			n++;
		}
		return !1;
	}
};
function In(e, t) {
	if ("at" in Array.prototype) return Array.prototype.at.call(e, t);
	let n = Ln(e, t);
	return n === -1 ? void 0 : e[n];
}
Mn(In, "at");
function Ln(e, t) {
	let n = e.length, r = Rn(t), i = r >= 0 ? r : n + r;
	return i < 0 || i >= n ? -1 : i;
}
Mn(Ln, "toSafeIndex");
function Rn(e) {
	return e !== e || e === 0 ? 0 : Math.trunc(e);
}
Mn(Rn, "toSafeInteger");
// @__NO_SIDE_EFFECTS__
function zn(e) {
	let t = e + "CollectionProvider", [n, r] = /* @__PURE__ */ sn(t), [i, a] = n(t);
	i.displayName = e + "CollectionStableContextProvider";
	let [o, s] = n(t);
	o.displayName = e + "CollectionStatefulContextProvider";
	let c = /* @__PURE__ */ Mn(({ state: e, ...t }) => e ? /* @__PURE__ */ q(u, {
		...t,
		state: e
	}) : /* @__PURE__ */ q(l, { ...t }), "CollectionProvider");
	c.displayName = t;
	let l = /* @__PURE__ */ Mn((e) => {
		let t = _();
		return /* @__PURE__ */ q(u, {
			...e,
			state: t
		});
	}, "CollectionInit");
	l.displayName = e + "CollectionInit";
	let u = /* @__PURE__ */ Mn((e) => {
		let { scope: t, children: n, state: r } = e, a = U.useRef(null), [s, c] = U.useState(null), l = Z(a, c), [u, d] = r, f = U.useRef(new Fn()), p = U.useCallback(() => {
			let e = f.current;
			return Hn(e) || e.sort(Un), e;
		}, []);
		return U.useEffect(() => {
			if (!s) return;
			let e = Wn(() => {
				d((e) => {
					let t = e.toSorted(Un);
					return t.some(([t], n) => e.keyAt(n) !== t) ? t : e;
				});
			});
			return e.observe(s, {
				childList: !0,
				subtree: !0
			}), () => {
				e.disconnect();
			};
		}, [s, d]), /* @__PURE__ */ q(i, {
			scope: t,
			collectionElementRef: l,
			collectionElementRefObject: a,
			getCollection: p,
			setCollection: d,
			registryRef: f,
			children: /* @__PURE__ */ q(o, {
				scope: t,
				collectionElement: s,
				collection: u,
				children: n
			})
		});
	}, "CollectionProviderImpl");
	u.displayName = e + "CollectionProviderImpl";
	let d = e + "CollectionSlot", f = /* @__PURE__ */ hn(d), p = U.forwardRef((e, t) => {
		let { scope: n, children: r } = e, i = Z(t, a(d, n).collectionElementRef);
		return /* @__PURE__ */ q(f, {
			ref: i,
			children: r
		});
	});
	p.displayName = d;
	let m = e + "CollectionItemSlot", h = /* @__PURE__ */ hn(m), g = U.forwardRef((e, t) => {
		let { scope: n, children: r, ...i } = e, o = U.useRef(null), { setCollection: s, registryRef: c } = a(m, n), l = U.useRef(i);
		Bn(l.current, i) || (l.current = i);
		let u = l.current, d = Z(t, U.useCallback((e) => {
			let t = c.current;
			e ? t.set(e, {
				...l.current,
				element: e
			}) : o.current && t.delete(o.current);
		}, [c]), o);
		An(() => {
			let e = o.current, t = c.current;
			e && t.has(e) && t.set(e, {
				...u,
				element: e
			});
		}, [u, c]);
		let f = U.useRef(null);
		return U.useEffect(() => {
			let e = o.current, t = f.current;
			((t?.element ?? null) !== e || e && t?.itemData !== u) && (f.current = e ? {
				element: e,
				itemData: u
			} : null, s((n) => {
				let r = new Fn(n);
				return t && t.element !== e && r.delete(t.element), e && r.set(e, {
					...u,
					element: e
				}), r.sort(Un);
			}));
		}), U.useEffect(() => () => {
			let e = f.current;
			f.current = null, e && s((t) => {
				if (!t.has(e.element)) return t;
				let n = new Fn(t);
				return n.delete(e.element), n;
			});
		}, [s]), /* @__PURE__ */ q(h, {
			"data-radix-collection-item": "",
			ref: d,
			children: r
		});
	});
	g.displayName = m;
	function _() {
		return U.useState(new Fn());
	}
	Mn(_, "useInitCollection");
	function v(t) {
		let { collection: n } = s(e + "CollectionConsumer", t);
		return n;
	}
	Mn(v, "useCollection");
	function y(t) {
		let { getCollection: n } = a(e + "CollectionConsumer", t);
		return n;
	}
	return Mn(y, "useGetCollection"), [{
		Provider: c,
		Slot: p,
		ItemSlot: g
	}, {
		createCollectionScope: r,
		useCollection: v,
		useGetCollection: y,
		useInitCollection: _
	}];
}
Mn(zn, "createCollection");
function Bn(e, t) {
	if (e === t) return !0;
	if (typeof e != "object" || typeof t != "object" || e == null || t == null) return !1;
	let n = Object.keys(e), r = Object.keys(t);
	if (n.length !== r.length) return !1;
	for (let r of n) if (!Object.prototype.hasOwnProperty.call(t, r) || e[r] !== t[r]) return !1;
	return !0;
}
Mn(Bn, "shallowEqual");
function Vn(e, t) {
	return !!(t.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_PRECEDING);
}
Mn(Vn, "isElementPreceding");
function Hn(e) {
	let t;
	for (let n of e.keys()) {
		if (t) {
			let e = t.compareDocumentPosition(n);
			if (!(e & Node.DOCUMENT_POSITION_DISCONNECTED) && e & Node.DOCUMENT_POSITION_PRECEDING) return !1;
		}
		t = n;
	}
	return !0;
}
Mn(Hn, "isInDocumentOrder");
function Un(e, t) {
	return !e[1].element || !t[1].element ? 0 : Vn(e[1].element, t[1].element) ? -1 : 1;
}
Mn(Un, "sortByDocumentPosition");
function Wn(e) {
	return new MutationObserver((t) => {
		for (let n of t) if (n.type === "childList") {
			e();
			return;
		}
	});
}
Mn(Wn, "getChildListObserver");
// node_modules/@radix-ui/react-direction/dist/index.mjs
var Gn = Object.defineProperty, Kn = (e, t) => Gn(e, "name", {
	value: t,
	configurable: !0
}), qn = {
	LTR: "ltr",
	RTL: "rtl"
}, Jn = U.createContext(void 0);
function Yn(e) {
	let t = U.useContext(Jn);
	return e || t || qn.LTR;
}
Kn(Yn, "useDirection");
// node_modules/@radix-ui/react-primitive/dist/index.mjs
var Xn = Object.defineProperty, Zn = (e, t) => Xn(e, "name", {
	value: t,
	configurable: !0
}), Qn = [
	"a",
	"button",
	"div",
	"form",
	"h2",
	"h3",
	"img",
	"input",
	"label",
	"li",
	"nav",
	"ol",
	"p",
	"select",
	"span",
	"svg",
	"ul"
].reduce((e, t) => {
	let n = /* @__PURE__ */ hn(`Primitive.${t}`), r = U.forwardRef((e, r) => {
		let { asChild: i, ...a } = e, o = i ? n : t;
		return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ q(o, {
			...a,
			ref: r
		});
	});
	return r.displayName = `Primitive.${t}`, {
		...e,
		[t]: r
	};
}, {});
function $n(e, t) {
	e && he.flushSync(() => e.dispatchEvent(t));
}
Zn($n, "dispatchDiscreteCustomEvent");
// node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
var er = Object.defineProperty, tr = (e, t) => er(e, "name", {
	value: t,
	configurable: !0
}), nr = U.useInsertionEffect;
function rr(e) {
	let t = U.useRef(e);
	return typeof nr == "function" ? nr(() => {
		t.current = e;
	}) : An(() => {
		t.current = e;
	}), U.useMemo(() => ((...e) => t.current?.(...e)), []);
}
tr(rr, "useCallbackRef");
// node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
var ir = Object.defineProperty, ar = (e, t) => ir(e, "name", {
	value: t,
	configurable: !0
}), or = "dismissableLayer.update", sr = "dismissableLayer.pointerDownOutside", cr = "dismissableLayer.focusOutside", lr, ur = U.createContext({
	layers: /* @__PURE__ */ new Set(),
	layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
	branches: /* @__PURE__ */ new Set(),
	dismissableSurfaces: /* @__PURE__ */ new Set()
}), dr = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ ar(function(e, t) {
	let { disableOutsidePointerEvents: n = !1, deferPointerDownOutside: r = !1, onEscapeKeyDown: i, onPointerDownOutside: a, onFocusOutside: o, onInteractOutside: s, onDismiss: c, ...l } = e, u = U.useContext(ur), [d, f] = U.useState(null), p = d?.ownerDocument ?? globalThis?.document, [, m] = U.useState({}), h = Z(t, f), g = Array.from(u.layers), [_] = [...u.layersWithOutsidePointerEventsDisabled].slice(-1), v = _ ? g.indexOf(_) : -1, y = d ? g.indexOf(d) : -1, b = u.layersWithOutsidePointerEventsDisabled.size > 0, x = y >= v, S = U.useRef(!1), C = mr((e) => {
		a?.(e), s?.(e), e.defaultPrevented || c?.();
	}, {
		ownerDocument: p,
		deferPointerDownOutside: r,
		isDeferredPointerDownOutsideRef: S,
		dismissableSurfaces: u.dismissableSurfaces,
		shouldHandlePointerDownOutside: U.useCallback((e) => {
			if (!(e instanceof Node)) return !1;
			let t = [...u.branches].some((t) => t.contains(e));
			return x && !t;
		}, [u.branches, x])
	}), w = hr((e) => {
		if (r && S.current) return;
		let t = e.target;
		[...u.branches].some((e) => e.contains(t)) || (o?.(e), s?.(e), e.defaultPrevented || c?.());
	}, p), T = d ? y === g.length - 1 : !1, E = rr((e) => {
		e.key === "Escape" && (i?.(e), !e.defaultPrevented && c && (e.preventDefault(), c()));
	});
	return U.useEffect(() => {
		if (T) return p.addEventListener("keydown", E, { capture: !0 }), () => p.removeEventListener("keydown", E, { capture: !0 });
	}, [
		p,
		T,
		E
	]), U.useEffect(() => {
		if (d) return n && (u.layersWithOutsidePointerEventsDisabled.size === 0 && (lr = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), u.layersWithOutsidePointerEventsDisabled.add(d)), u.layers.add(d), gr(), () => {
			n && (u.layersWithOutsidePointerEventsDisabled.delete(d), u.layersWithOutsidePointerEventsDisabled.size === 0 && (p.body.style.pointerEvents = lr));
		};
	}, [
		d,
		p,
		n,
		u
	]), U.useEffect(() => () => {
		d && (u.layers.delete(d), u.layersWithOutsidePointerEventsDisabled.delete(d), gr());
	}, [d, u]), U.useEffect(() => {
		let e = /* @__PURE__ */ ar(() => m({}), "handleUpdate");
		return document.addEventListener(or, e), () => document.removeEventListener(or, e);
	}, []), /* @__PURE__ */ q(Qn.div, {
		...l,
		ref: h,
		style: {
			pointerEvents: b ? x ? "auto" : "none" : void 0,
			...e.style
		},
		onFocusCapture: X(e.onFocusCapture, w.onFocusCapture),
		onBlurCapture: X(e.onBlurCapture, w.onBlurCapture),
		onPointerDownCapture: X(e.onPointerDownCapture, C.onPointerDownCapture)
	});
}, "DismissableLayer"));
function fr() {
	let e = U.useContext(ur), [t, n] = U.useState(null);
	return U.useEffect(() => {
		if (t) return e.dismissableSurfaces.add(t), () => {
			e.dismissableSurfaces.delete(t);
		};
	}, [t, e.dismissableSurfaces]), n;
}
ar(fr, "useDismissableLayerSurface");
var pr = /* @__PURE__ */ ar(() => !0, "IS_TRUE");
function mr(e, t) {
	let { ownerDocument: n = globalThis?.document, deferPointerDownOutside: r = !1, isDeferredPointerDownOutsideRef: i, dismissableSurfaces: a, shouldHandlePointerDownOutside: o = pr } = t, s = rr(e), c = U.useRef(!1), l = U.useRef(!1), u = U.useRef(/* @__PURE__ */ new Map()), d = U.useRef(() => {});
	return U.useEffect(() => {
		function e() {
			l.current = !1, i.current = !1, u.current.clear();
		}
		ar(e, "resetOutsideInteraction");
		function t() {
			return Array.from(u.current.values()).some(Boolean);
		}
		ar(t, "isOutsideInteractionIntercepted");
		function f(e) {
			if (!l.current) return;
			let t = e.target;
			t instanceof Node && [...a].some((e) => e.contains(t)) || u.current.set(e.type, !0), e.type === "click" && window.setTimeout(() => {
				l.current && d.current();
			}, 0);
		}
		ar(f, "handleInteractionCapture");
		function p(e) {
			l.current && u.current.set(e.type, !1);
		}
		ar(p, "handleInteractionBubble");
		let m = /* @__PURE__ */ ar((a) => {
			if (a.target && !c.current) {
				let f = function() {
					n.removeEventListener("click", d.current);
					let r = t();
					e(), r || _r(sr, s, p, { discrete: !0 });
				};
				if (ar(f, "handleAndDispatchPointerDownOutsideEvent"), !o(a.target)) {
					n.removeEventListener("click", d.current), e(), c.current = !1;
					return;
				}
				let p = { originalEvent: a };
				l.current = !0, i.current = r && a.button === 0, u.current.clear(), !r || a.button !== 0 ? f() : (n.removeEventListener("click", d.current), d.current = f, n.addEventListener("click", d.current, { once: !0 }));
			} else n.removeEventListener("click", d.current), e();
			c.current = !1;
		}, "handlePointerDown"), h = [
			"pointerup",
			"mousedown",
			"mouseup",
			"touchstart",
			"touchend",
			"click"
		];
		for (let e of h) n.addEventListener(e, f, !0), n.addEventListener(e, p);
		let g = window.setTimeout(() => {
			n.addEventListener("pointerdown", m);
		}, 0);
		return () => {
			window.clearTimeout(g), n.removeEventListener("pointerdown", m), n.removeEventListener("click", d.current);
			for (let e of h) n.removeEventListener(e, f, !0), n.removeEventListener(e, p);
		};
	}, [
		n,
		s,
		r,
		i,
		a,
		o
	]), { onPointerDownCapture: /* @__PURE__ */ ar(() => c.current = !0, "onPointerDownCapture") };
}
ar(mr, "usePointerDownOutside");
function hr(e, t = globalThis?.document) {
	let n = rr(e), r = U.useRef(!1);
	return U.useEffect(() => {
		let e = /* @__PURE__ */ ar((e) => {
			e.target && !r.current && _r(cr, n, { originalEvent: e }, { discrete: !1 });
		}, "handleFocus");
		return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e);
	}, [t, n]), {
		onFocusCapture: /* @__PURE__ */ ar(() => r.current = !0, "onFocusCapture"),
		onBlurCapture: /* @__PURE__ */ ar(() => r.current = !1, "onBlurCapture")
	};
}
ar(hr, "useFocusOutside");
function gr() {
	let e = new CustomEvent(or);
	document.dispatchEvent(e);
}
ar(gr, "dispatchUpdate");
function _r(e, t, n, { discrete: r }) {
	let i = n.originalEvent.target, a = new CustomEvent(e, {
		bubbles: !1,
		cancelable: !0,
		detail: n
	});
	t && i.addEventListener(e, t, { once: !0 }), r ? $n(i, a) : i.dispatchEvent(a);
}
ar(_r, "handleAndDispatchCustomEvent");
// node_modules/@radix-ui/react-focus-guards/dist/index.mjs
var vr = Object.defineProperty, yr = (e, t) => vr(e, "name", {
	value: t,
	configurable: !0
}), br = 0, xr = null;
function Sr(e) {
	return Cr(), e.children;
}
yr(Sr, "FocusGuards");
function Cr() {
	U.useEffect(() => {
		xr ||= {
			start: wr(),
			end: wr()
		};
		let { start: e, end: t } = xr;
		return document.body.firstElementChild !== e && document.body.insertAdjacentElement("afterbegin", e), document.body.lastElementChild !== t && document.body.insertAdjacentElement("beforeend", t), br++, () => {
			br === 1 && (xr?.start.remove(), xr?.end.remove(), xr = null), br = Math.max(0, br - 1);
		};
	}, []);
}
yr(Cr, "useFocusGuards");
function wr() {
	let e = document.createElement("span");
	return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
yr(wr, "createFocusGuard");
// node_modules/@radix-ui/react-focus-scope/dist/index.mjs
var Tr = Object.defineProperty, Er = (e, t) => Tr(e, "name", {
	value: t,
	configurable: !0
}), Dr = "focusScope.autoFocusOnMount", Or = "focusScope.autoFocusOnUnmount", kr = {
	bubbles: !1,
	cancelable: !0
}, Ar = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Er(function(e, t) {
	let { loop: n = !1, trapped: r = !1, branches: i, onMountAutoFocus: a, onUnmountAutoFocus: o, ...s } = e, [c, l] = U.useState(null), u = rr(a), d = rr(o), f = U.useRef(null), p = Z(t, l), m = U.useRef(i);
	U.useEffect(() => {
		m.current = i;
	});
	let h = U.useCallback((e) => e ? c?.contains(e) ? !0 : !!m.current?.some((t) => t.contains(e)) : !1, [c]), g = U.useRef({
		paused: !1,
		pause() {
			this.paused = !0;
		},
		resume() {
			this.paused = !1;
		}
	}).current;
	U.useEffect(() => {
		if (r) {
			let e = function(e) {
				if (g.paused || !c) return;
				let t = e.target;
				h(t) ? f.current = t : Vr(f.current, { select: !0 });
			}, t = function(e) {
				if (g.paused || !c) return;
				let t = e.relatedTarget;
				t !== null && (h(t) || Vr(f.current, { select: !0 }));
			}, n = function(e) {
				if (document.activeElement === document.body) for (let t of e) t.removedNodes.length > 0 && Vr(c);
			};
			Er(e, "handleFocusIn"), Er(t, "handleFocusOut"), Er(n, "handleMutations"), document.addEventListener("focusin", e), document.addEventListener("focusout", t);
			let r = new MutationObserver(n);
			return c && r.observe(c, {
				childList: !0,
				subtree: !0
			}), () => {
				document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), r.disconnect();
			};
		}
	}, [
		r,
		c,
		g.paused,
		h
	]), U.useEffect(() => {
		if (c) {
			Hr.add(g);
			let e = document.activeElement;
			if (!c.contains(e)) {
				let t = new CustomEvent(Dr, kr);
				c.addEventListener(Dr, u), c.dispatchEvent(t), t.defaultPrevented || (Fr(Gr(Lr(c)), { select: !0 }), document.activeElement === e && Vr(c));
			}
			return () => {
				c.removeEventListener(Dr, u);
				let t = c.ownerDocument, n = CustomEvent;
				setTimeout(() => {
					let r = new n(Or, kr);
					c.addEventListener(Or, d), c.dispatchEvent(r), r.defaultPrevented || Vr(e ?? t.body, { select: !0 }), c.removeEventListener(Or, d), Hr.remove(g);
				}, 0);
			};
		}
	}, [
		c,
		u,
		d,
		g
	]);
	let _ = U.useCallback((e) => {
		if (!n && !r || g.paused) return;
		let t = e.key === "Tab" && !e.altKey && !e.ctrlKey && !e.metaKey, i = document.activeElement;
		if (t && i) {
			let t = e.currentTarget, [r, a] = Ir(t);
			r && a ? !e.shiftKey && i === a ? (e.preventDefault(), n && Vr(r, { select: !0 })) : e.shiftKey && i === r && (e.preventDefault(), n && Vr(a, { select: !0 })) : i === t && e.preventDefault();
		}
	}, [
		n,
		r,
		g.paused
	]);
	return /* @__PURE__ */ q(Qn.div, {
		tabIndex: -1,
		...s,
		ref: p,
		onKeyDown: _
	});
}, "FocusScope")), jr = U.createContext(null);
function Mr({ registry: e, children: t }) {
	return e ? /* @__PURE__ */ q(jr.Provider, {
		value: e,
		children: t
	}) : t;
}
Er(Mr, "FocusScopeBranchProvider");
function Nr() {
	let [e, t] = U.useState([]);
	return {
		nodes: e,
		registry: U.useMemo(() => ({
			add: /* @__PURE__ */ Er((e) => t((t) => t.includes(e) ? t : [...t, e]), "add"),
			remove: /* @__PURE__ */ Er((e) => t((t) => t.filter((t) => t !== e)), "remove")
		}), [])
	};
}
Er(Nr, "useFocusScopeBranchRegistry");
function Pr(e) {
	let t = U.useContext(jr);
	U.useEffect(() => {
		if (e && t) return t.add(e), () => t.remove(e);
	}, [e, t]);
}
Er(Pr, "useFocusScopeBranch");
function Fr(e, { select: t = !1 } = {}) {
	let n = document.activeElement;
	for (let r of e) if (Vr(r, { select: t }), document.activeElement !== n) return;
}
Er(Fr, "focusFirst");
function Ir(e) {
	let t = Lr(e);
	return [Rr(t, e), Rr(t.reverse(), e)];
}
Er(Ir, "getTabbableEdges");
function Lr(e) {
	let t = [], n = e.ownerDocument.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: /* @__PURE__ */ Er((e) => {
		let t = e.tagName === "INPUT" && e.type === "hidden";
		return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	}, "acceptNode") });
	for (; n.nextNode();) t.push(n.currentNode);
	return t;
}
Er(Lr, "getTabbableCandidates");
function Rr(e, t) {
	let n = typeof t.checkVisibility == "function" && t.checkVisibility({ checkVisibilityCSS: !0 });
	for (let r of e) if (!(n ? !r.checkVisibility({ checkVisibilityCSS: !0 }) : zr(r, { upTo: t }))) return r;
}
Er(Rr, "findVisible");
function zr(e, { upTo: t }) {
	if (getComputedStyle(e).visibility === "hidden") return !0;
	for (; e;) {
		if (t !== void 0 && e === t) return !1;
		if (getComputedStyle(e).display === "none") return !0;
		e = e.parentElement;
	}
	return !1;
}
Er(zr, "isHidden");
function Br(e) {
	return e.tagName === "INPUT" && typeof e.select == "function";
}
Er(Br, "isSelectableInput");
function Vr(e, { select: t = !1 } = {}) {
	if (e && e.focus) {
		let n = (e.ownerDocument ?? document).activeElement;
		e.focus({ preventScroll: !0 }), e !== n && Br(e) && t && e.select();
	}
}
Er(Vr, "focus");
var Hr = Ur();
function Ur() {
	let e = [];
	return {
		add(t) {
			let n = e[0];
			t !== n && n?.pause(), e = Wr(e, t), e.unshift(t);
		},
		remove(t) {
			e = Wr(e, t), e[0]?.resume();
		}
	};
}
Er(Ur, "createFocusScopesStack");
function Wr(e, t) {
	let n = [...e], r = n.indexOf(t);
	return r !== -1 && n.splice(r, 1), n;
}
Er(Wr, "arrayRemove");
function Gr(e) {
	return e.filter((e) => e.tagName !== "A");
}
Er(Gr, "removeLinks");
// node_modules/@radix-ui/react-id/dist/index.mjs
var Kr = Object.defineProperty, qr = (e, t) => Kr(e, "name", {
	value: t,
	configurable: !0
}), Jr = U.useId || (() => void 0), Yr = 0;
function Xr(e) {
	let [t, n] = U.useState(Jr());
	return An(() => {
		e || n((e) => e ?? String(Yr++));
	}, [e]), e || (t ? `radix-${t}` : "");
}
qr(Xr, "useId");
// node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
var Zr = [
	"top",
	"right",
	"bottom",
	"left"
], Qr = Math.min, $r = Math.max, ei = Math.round, ti = Math.floor, ni = (e) => ({
	x: e,
	y: e
}), ri = {
	left: "right",
	right: "left",
	bottom: "top",
	top: "bottom"
};
function ii(e, t, n) {
	return $r(e, Qr(t, n));
}
function ai(e, t) {
	return typeof e == "function" ? e(t) : e;
}
function oi(e) {
	return e.split("-")[0];
}
function si(e) {
	return e.split("-")[1];
}
function ci(e) {
	return e === "x" ? "y" : "x";
}
function li(e) {
	return e === "y" ? "height" : "width";
}
function ui(e) {
	let t = e[0];
	return t === "t" || t === "b" ? "y" : "x";
}
function di(e) {
	return ci(ui(e));
}
function fi(e, t, n) {
	n === void 0 && (n = !1);
	let r = si(e), i = di(e), a = li(i), o = i === "x" ? r === (n ? "end" : "start") ? "right" : "left" : r === "start" ? "bottom" : "top";
	return t.reference[a] > t.floating[a] && (o = xi(o)), [o, xi(o)];
}
function pi(e) {
	let t = xi(e);
	return [
		mi(e),
		t,
		mi(t)
	];
}
function mi(e) {
	return e.includes("start") ? e.replace("start", "end") : e.replace("end", "start");
}
var hi = ["left", "right"], gi = ["right", "left"], _i = ["top", "bottom"], vi = ["bottom", "top"];
function yi(e, t, n) {
	switch (e) {
		case "top":
		case "bottom": return n ? t ? gi : hi : t ? hi : gi;
		case "left":
		case "right": return t ? _i : vi;
		default: return [];
	}
}
function bi(e, t, n, r) {
	let i = si(e), a = yi(oi(e), n === "start", r);
	return i && (a = a.map((e) => e + "-" + i), t && (a = a.concat(a.map(mi)))), a;
}
function xi(e) {
	let t = oi(e);
	return ri[t] + e.slice(t.length);
}
function Si(e) {
	return {
		top: e.top ?? 0,
		right: e.right ?? 0,
		bottom: e.bottom ?? 0,
		left: e.left ?? 0
	};
}
function Ci(e) {
	return typeof e == "number" ? {
		top: e,
		right: e,
		bottom: e,
		left: e
	} : Si(e);
}
function wi(e) {
	let { x: t, y: n, width: r, height: i } = e;
	return {
		width: r,
		height: i,
		top: n,
		left: t,
		right: t + r,
		bottom: n + i,
		x: t,
		y: n
	};
}
// node_modules/@floating-ui/core/dist/floating-ui.core.mjs
function Ti(e, t, n) {
	let { reference: r, floating: i } = e, a = ui(t), o = di(t), s = li(o), c = oi(t), l = a === "y", u = r.x + r.width / 2 - i.width / 2, d = r.y + r.height / 2 - i.height / 2, f = r[s] / 2 - i[s] / 2, p;
	switch (c) {
		case "top":
			p = {
				x: u,
				y: r.y - i.height
			};
			break;
		case "bottom":
			p = {
				x: u,
				y: r.y + r.height
			};
			break;
		case "right":
			p = {
				x: r.x + r.width,
				y: d
			};
			break;
		case "left":
			p = {
				x: r.x - i.width,
				y: d
			};
			break;
		default: p = {
			x: r.x,
			y: r.y
		};
	}
	let m = si(t);
	return m && (p[o] += f * (m === "end" ? 1 : -1) * (n && l ? -1 : 1)), p;
}
async function Ei(e, t) {
	t === void 0 && (t = {});
	let { x: n, y: r, platform: i, rects: a, elements: o, strategy: s } = e, { boundary: c = "clippingAncestors", rootBoundary: l = "viewport", elementContext: u = "floating", altBoundary: d = !1, padding: f = 0 } = ai(t, e), p = Ci(f), m = o[d ? u === "floating" ? "reference" : "floating" : u], h = wi(await i.getClippingRect({
		element: await (i.isElement == null ? void 0 : i.isElement(m)) ?? !0 ? m : m.contextElement || await (i.getDocumentElement == null ? void 0 : i.getDocumentElement(o.floating)),
		boundary: c,
		rootBoundary: l,
		strategy: s
	})), g = u === "floating" ? {
		x: n,
		y: r,
		width: a.floating.width,
		height: a.floating.height
	} : a.reference, _ = await (i.getOffsetParent == null ? void 0 : i.getOffsetParent(o.floating)), v = await (i.isElement == null ? void 0 : i.isElement(_)) && await (i.getScale == null ? void 0 : i.getScale(_)) || {
		x: 1,
		y: 1
	}, y = wi(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
		elements: o,
		rect: g,
		offsetParent: _,
		strategy: s
	}) : g);
	return {
		top: (h.top - y.top + p.top) / v.y,
		bottom: (y.bottom - h.bottom + p.bottom) / v.y,
		left: (h.left - y.left + p.left) / v.x,
		right: (y.right - h.right + p.right) / v.x
	};
}
var Di = 50, Oi = async (e, t, n) => {
	let { placement: r = "bottom", strategy: i = "absolute", middleware: a = [], platform: o } = n, s = o.detectOverflow ? o : {
		...o,
		detectOverflow: Ei
	}, c = await (o.isRTL == null ? void 0 : o.isRTL(t)), l = await o.getElementRects({
		reference: e,
		floating: t,
		strategy: i
	}), { x: u, y: d } = Ti(l, r, c), f = r, p = 0, m = {};
	for (let n = 0; n < a.length; n++) {
		let h = a[n];
		if (!h) continue;
		let { name: g, fn: _ } = h, { x: v, y, data: b, reset: x } = await _({
			x: u,
			y: d,
			initialPlacement: r,
			placement: f,
			strategy: i,
			middlewareData: m,
			rects: l,
			platform: s,
			elements: {
				reference: e,
				floating: t
			}
		});
		u = v ?? u, d = y ?? d, m[g] = {
			...m[g],
			...b
		}, x && p < Di && (p++, typeof x == "object" && (x.placement && (f = x.placement), x.rects && (l = x.rects === !0 ? await o.getElementRects({
			reference: e,
			floating: t,
			strategy: i
		}) : x.rects), {x: u, y: d} = Ti(l, f, c)), n = -1);
	}
	return {
		x: u,
		y: d,
		placement: f,
		strategy: i,
		middlewareData: m
	};
}, ki = (e) => ({
	name: "arrow",
	options: e,
	async fn(t) {
		let { x: n, y: r, placement: i, rects: a, platform: o, elements: s, middlewareData: c } = t, { element: l, padding: u = 0 } = ai(e, t) || {};
		if (l == null) return {};
		let d = Ci(u), f = {
			x: n,
			y: r
		}, p = di(i), m = li(p), h = await o.getDimensions(l), g = p === "y", _ = g ? "top" : "left", v = g ? "bottom" : "right", y = g ? "clientHeight" : "clientWidth", b = a.reference[m] + a.reference[p] - f[p] - a.floating[m], x = f[p] - a.reference[p], S = await (o.getOffsetParent == null ? void 0 : o.getOffsetParent(l)), C = S ? S[y] : 0;
		C && await (o.isElement == null ? void 0 : o.isElement(S)) || (C = s.floating[y] || a.floating[m]);
		let w = b / 2 - x / 2, T = C / 2 - h[m] / 2 - 1, E = Qr(d[_], T), D = Qr(d[v], T), O = C - h[m] - D, k = C / 2 - h[m] / 2 + w, A = ii(E, k, O), j = !c.arrow && si(i) != null && k !== A && a.reference[m] / 2 - (k < E ? E : D) - h[m] / 2 < 0, M = j ? k < E ? k - E : k - O : 0;
		return {
			[p]: f[p] + M,
			data: {
				[p]: A,
				centerOffset: k - A - M,
				...j && { alignmentOffset: M }
			},
			reset: j
		};
	}
}), Ai = function(e) {
	return e === void 0 && (e = {}), {
		name: "flip",
		options: e,
		async fn(t) {
			var n;
			let { placement: r, middlewareData: i, rects: a, initialPlacement: o, platform: s, elements: c } = t, { mainAxis: l = !0, crossAxis: u = !0, fallbackPlacements: d, fallbackStrategy: f = "bestFit", fallbackAxisSideDirection: p = "none", flipAlignment: m = !0, ...h } = ai(e, t);
			if ((n = i.arrow) != null && n.alignmentOffset) return {};
			let g = oi(r), _ = ui(o), v = oi(o) === o, y = await (s.isRTL == null ? void 0 : s.isRTL(c.floating)), b = d || (v || !m ? [xi(o)] : pi(o)), x = p !== "none";
			!d && x && b.push(...bi(o, m, p, y));
			let S = [o, ...b], C = await s.detectOverflow(t, h), w = [], T = i.flip?.overflows || [];
			if (l && w.push(C[g]), u) {
				let e = fi(r, a, y);
				w.push(C[e[0]], C[e[1]]);
			}
			if (T = [...T, {
				placement: r,
				overflows: w
			}], !w.every((e) => e <= 0)) {
				let e = (i.flip?.index || 0) + 1, t = S[e];
				if (t && (u !== "alignment" || _ === ui(t) || T.every((e) => ui(e.placement) !== _ || e.overflows[0] > 0))) return {
					data: {
						index: e,
						overflows: T
					},
					reset: { placement: t }
				};
				let n = T.filter((e) => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0]?.placement;
				if (!n) switch (f) {
					case "bestFit": {
						let e = T.filter((e) => {
							if (x) {
								let t = ui(e.placement);
								return t === _ || t === "y";
							}
							return !0;
						}).map((e) => [e.placement, e.overflows.filter((e) => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0]?.[0];
						e && (n = e);
						break;
					}
					case "initialPlacement": n = o;
				}
				if (r !== n) return { reset: { placement: n } };
			}
			return {};
		}
	};
};
function ji(e, t) {
	return {
		top: e.top - t.height,
		right: e.right - t.width,
		bottom: e.bottom - t.height,
		left: e.left - t.width
	};
}
function Mi(e) {
	return Zr.some((t) => e[t] >= 0);
}
var Ni = function(e) {
	return e === void 0 && (e = {}), {
		name: "hide",
		options: e,
		async fn(t) {
			let { rects: n, platform: r } = t, { strategy: i = "referenceHidden", ...a } = ai(e, t);
			switch (i) {
				case "referenceHidden": {
					let e = ji(await r.detectOverflow(t, {
						...a,
						elementContext: "reference"
					}), n.reference);
					return { data: {
						referenceHiddenOffsets: e,
						referenceHidden: Mi(e)
					} };
				}
				case "escaped": {
					let e = ji(await r.detectOverflow(t, {
						...a,
						altBoundary: !0
					}), n.floating);
					return { data: {
						escapedOffsets: e,
						escaped: Mi(e)
					} };
				}
				default: return {};
			}
		}
	};
}, Pi = /*#__PURE__*/ new Set(["left", "top"]);
async function Fi(e, t) {
	let { placement: n, platform: r, elements: i } = e, a = await (r.isRTL == null ? void 0 : r.isRTL(i.floating)), o = oi(n), s = si(n), c = ui(n) === "y", l = Pi.has(o) ? -1 : 1, u = a && c ? -1 : 1, d = ai(t, e), { mainAxis: f, crossAxis: p, alignmentAxis: m } = typeof d == "number" ? {
		mainAxis: d,
		crossAxis: 0,
		alignmentAxis: null
	} : {
		mainAxis: d.mainAxis || 0,
		crossAxis: d.crossAxis || 0,
		alignmentAxis: d.alignmentAxis
	};
	return s && typeof m == "number" && (p = s === "end" ? m * -1 : m), c ? {
		x: p * u,
		y: f * l
	} : {
		x: f * l,
		y: p * u
	};
}
var Ii = function(e) {
	return e === void 0 && (e = 0), {
		name: "offset",
		options: e,
		async fn(t) {
			var n;
			let { x: r, y: i, placement: a, middlewareData: o } = t, s = await Fi(t, e);
			return a === o.offset?.placement && (n = o.arrow) != null && n.alignmentOffset ? {} : {
				x: r + s.x,
				y: i + s.y,
				data: {
					...s,
					placement: a
				}
			};
		}
	};
}, Li = function(e) {
	return e === void 0 && (e = {}), {
		name: "shift",
		options: e,
		async fn(t) {
			let { x: n, y: r, placement: i, platform: a } = t, { mainAxis: o = !0, crossAxis: s = !1, limiter: c = { fn: (e) => {
				let { x: t, y: n } = e;
				return {
					x: t,
					y: n
				};
			} }, ...l } = ai(e, t), u = {
				x: n,
				y: r
			}, d = await a.detectOverflow(t, l), f = ui(i), p = ci(f), m = u[p], h = u[f], g = (e, t) => ii(t + d[e === "y" ? "top" : "left"], t, t - d[e === "y" ? "bottom" : "right"]);
			o && (m = g(p, m)), s && (h = g(f, h));
			let _ = c.fn({
				...t,
				[p]: m,
				[f]: h
			});
			return {
				..._,
				data: {
					x: _.x - n,
					y: _.y - r,
					enabled: {
						[p]: o,
						[f]: s
					}
				}
			};
		}
	};
}, Ri = function(e) {
	return e === void 0 && (e = {}), {
		options: e,
		fn(t) {
			let { x: n, y: r, placement: i, rects: a, middlewareData: o } = t, { offset: s = 0, mainAxis: c = !0, crossAxis: l = !0 } = ai(e, t), u = {
				x: n,
				y: r
			}, d = ui(i), f = ci(d), p = u[f], m = u[d], h = ai(s, t), g = typeof h == "number" ? {
				mainAxis: h,
				crossAxis: 0
			} : {
				mainAxis: h.mainAxis ?? 0,
				crossAxis: h.crossAxis ?? 0
			};
			if (c) {
				let e = f === "y" ? "height" : "width", t = a.reference[f] - a.floating[e] + g.mainAxis, n = a.reference[f] + a.reference[e] - g.mainAxis;
				p < t ? p = t : p > n && (p = n);
			}
			if (l) {
				let e = f === "y" ? "width" : "height", t = Pi.has(oi(i)), n = a.reference[d] - a.floating[e] + (t && o.offset?.[d] || 0) + (t ? 0 : g.crossAxis), r = a.reference[d] + a.reference[e] + (t ? 0 : o.offset?.[d] || 0) - (t ? g.crossAxis : 0);
				m < n ? m = n : m > r && (m = r);
			}
			return {
				[f]: p,
				[d]: m
			};
		}
	};
}, zi = function(e) {
	return e === void 0 && (e = {}), {
		name: "size",
		options: e,
		async fn(t) {
			let { placement: n, rects: r, platform: i, elements: a } = t, { apply: o = () => {}, ...s } = ai(e, t), c = await i.detectOverflow(t, s), l = oi(n), u = si(n), d = ui(n) === "y", { width: f, height: p } = r.floating, m, h;
			l === "top" || l === "bottom" ? (m = l, h = u === (await (i.isRTL == null ? void 0 : i.isRTL(a.floating)) ? "start" : "end") ? "left" : "right") : (h = l, m = u === "end" ? "top" : "bottom");
			let g = p - c.top - c.bottom, _ = f - c.left - c.right, v = Qr(p - c[m], g), y = Qr(f - c[h], _), b = t.middlewareData.shift, x = !b, S = v, C = y;
			b != null && b.enabled.x && (C = _), b != null && b.enabled.y && (S = g), x && !u && (d ? C = f - 2 * $r(c.left, c.right) : S = p - 2 * $r(c.top, c.bottom)), await o({
				...t,
				availableWidth: C,
				availableHeight: S
			});
			let w = await i.getDimensions(a.floating);
			return f !== w.width || p !== w.height ? { reset: { rects: !0 } } : {};
		}
	};
};
// node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function Bi() {
	return typeof window < "u";
}
function Vi(e) {
	return Wi(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function Hi(e) {
	var t;
	return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Ui(e) {
	return ((Wi(e) ? e.ownerDocument : e.document) || window.document)?.documentElement;
}
function Wi(e) {
	return Bi() ? e instanceof Node || e instanceof Hi(e).Node : !1;
}
function Gi(e) {
	return Bi() ? e instanceof Element || e instanceof Hi(e).Element : !1;
}
function Ki(e) {
	return Bi() ? e instanceof HTMLElement || e instanceof Hi(e).HTMLElement : !1;
}
function qi(e) {
	return !Bi() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof Hi(e).ShadowRoot;
}
function Ji(e) {
	let { overflow: t, overflowX: n, overflowY: r, display: i } = aa(e);
	return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && i !== "inline" && i !== "contents";
}
function Yi(e) {
	return /^(table|td|th)$/.test(Vi(e));
}
function Xi(e) {
	try {
		if (e.matches(":popover-open")) return !0;
	} catch {}
	try {
		return e.matches(":modal");
	} catch {
		return !1;
	}
}
var Zi = /transform|translate|scale|rotate|perspective|filter/, Qi = /paint|layout|strict|content/, $i = (e) => !!e && e !== "none", ea;
function ta(e) {
	let t = Gi(e) ? aa(e) : e;
	return $i(t.transform) || $i(t.translate) || $i(t.scale) || $i(t.rotate) || $i(t.perspective) || !ra() && ($i(t.backdropFilter) || $i(t.filter)) || Zi.test(t.willChange || "") || Qi.test(t.contain || "");
}
function na(e) {
	let t = sa(e);
	for (; Ki(t) && !ia(t);) {
		if (ta(t)) return t;
		if (Xi(t)) return null;
		t = sa(t);
	}
	return null;
}
function ra() {
	return ea ??= typeof CSS < "u" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none"), ea;
}
function ia(e) {
	return /^(html|body|#document)$/.test(Vi(e));
}
function aa(e) {
	return Hi(e).getComputedStyle(e);
}
function oa(e) {
	return Gi(e) ? {
		scrollLeft: e.scrollLeft,
		scrollTop: e.scrollTop
	} : {
		scrollLeft: e.scrollX,
		scrollTop: e.scrollY
	};
}
function sa(e) {
	if (Vi(e) === "html") return e;
	let t = e.assignedSlot || e.parentNode || qi(e) && e.host || Ui(e);
	return qi(t) ? t.host : t;
}
function ca(e) {
	let t = sa(e);
	return ia(t) ? (e.ownerDocument || e).body : Ki(t) && Ji(t) ? t : ca(t);
}
function la(e, t, n) {
	t === void 0 && (t = []), n === void 0 && (n = !0);
	let r = ca(e), i = r === e.ownerDocument?.body, a = Hi(r);
	if (i) {
		let e = ua(a);
		return t.concat(a, a.visualViewport || [], Ji(r) ? r : [], e && n ? la(e) : []);
	}
	return t.concat(r, la(r, [], n));
}
function ua(e) {
	return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
// node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
function da(e) {
	let t = aa(e), n = parseFloat(t.width) || 0, r = parseFloat(t.height) || 0, i = Ki(e), a = i ? e.offsetWidth : n, o = i ? e.offsetHeight : r, s = ei(n) !== a || ei(r) !== o;
	return s && (n = a, r = o), {
		width: n,
		height: r,
		$: s
	};
}
function fa(e) {
	return Gi(e) ? e : e.contextElement;
}
function pa(e) {
	let t = fa(e);
	if (!Ki(t)) return ni(1);
	let n = t.getBoundingClientRect(), { width: r, height: i, $: a } = da(t), o = (a ? ei(n.width) : n.width) / r, s = (a ? ei(n.height) : n.height) / i;
	return o && Number.isFinite(o) || (o = 1), s && Number.isFinite(s) || (s = 1), {
		x: o,
		y: s
	};
}
var ma = /*#__PURE__*/ ni(0);
function ha(e) {
	let t = Hi(e);
	return !ra() || !t.visualViewport ? ma : {
		x: t.visualViewport.offsetLeft,
		y: t.visualViewport.offsetTop
	};
}
function ga(e, t, n) {
	return t === void 0 && (t = !1), !!n && t && n === Hi(e);
}
function _a(e, t, n, r) {
	t === void 0 && (t = !1), n === void 0 && (n = !1);
	let i = e.getBoundingClientRect(), a = fa(e), o = ni(1);
	t && (r ? Gi(r) && (o = pa(r)) : o = pa(e));
	let s = ga(a, n, r) ? ha(a) : ni(0), c = (i.left + s.x) / o.x, l = (i.top + s.y) / o.y, u = i.width / o.x, d = i.height / o.y;
	if (a && r) {
		let e = Hi(a), t = Gi(r) ? Hi(r) : r, n = e, i = ua(n);
		for (; i && t !== n;) {
			let e = pa(i), t = i.getBoundingClientRect(), r = aa(i), a = t.left + (i.clientLeft + parseFloat(r.paddingLeft)) * e.x, o = t.top + (i.clientTop + parseFloat(r.paddingTop)) * e.y;
			c *= e.x, l *= e.y, u *= e.x, d *= e.y, c += a, l += o, n = Hi(i), i = ua(n);
		}
	}
	return wi({
		width: u,
		height: d,
		x: c,
		y: l
	});
}
function va(e, t) {
	let n = oa(e).scrollLeft;
	return t ? t.left + n : _a(Ui(e)).left + n;
}
function ya(e, t) {
	let n = e.getBoundingClientRect();
	return {
		x: n.left + t.scrollLeft - va(e, n),
		y: n.top + t.scrollTop
	};
}
function ba(e) {
	let { elements: t, rect: n, offsetParent: r, strategy: i } = e, a = i === "fixed", o = Ui(r), s = t ? Xi(t.floating) : !1;
	if (r === o || s && a) return n;
	let c = {
		scrollLeft: 0,
		scrollTop: 0
	}, l = ni(1), u = ni(0), d = Ki(r);
	if ((d || !a) && ((Vi(r) !== "body" || Ji(o)) && (c = oa(r)), d)) {
		let e = _a(r);
		l = pa(r), u.x = e.x + r.clientLeft, u.y = e.y + r.clientTop;
	}
	let f = o && !d && !a ? ya(o, c) : ni(0);
	return {
		width: n.width * l.x,
		height: n.height * l.y,
		x: n.x * l.x - c.scrollLeft * l.x + u.x + f.x,
		y: n.y * l.y - c.scrollTop * l.y + u.y + f.y
	};
}
function xa(e) {
	return e.getClientRects ? Array.from(e.getClientRects()) : [];
}
function Sa(e) {
	let t = oa(e), n = e.ownerDocument.body, r = $r(e.scrollWidth, e.clientWidth, n.scrollWidth, n.clientWidth), i = $r(e.scrollHeight, e.clientHeight, n.scrollHeight, n.clientHeight), a = -t.scrollLeft + va(e), o = -t.scrollTop;
	return aa(n).direction === "rtl" && (a += $r(e.clientWidth, n.clientWidth) - r), {
		width: r,
		height: i,
		x: a,
		y: o
	};
}
var Ca = 25;
function wa(e, t, n) {
	n === void 0 && (n = "viewport");
	let r = n === "layoutViewport", i = Hi(e), a = Ui(e), o = i.visualViewport, s = a.clientWidth, c = a.clientHeight, l = 0, u = 0;
	if (o) {
		let e = !ra() || t === "fixed";
		r ? e || (l = -o.offsetLeft, u = -o.offsetTop) : (s = o.width, c = o.height, e && (l = o.offsetLeft, u = o.offsetTop));
	}
	if (va(a) <= 0) {
		let e = a.ownerDocument, t = e.body, n = getComputedStyle(t), r = e.compatMode === "CSS1Compat" && parseFloat(n.marginLeft) + parseFloat(n.marginRight) || 0, i = Math.abs(a.clientWidth - t.clientWidth - r), o = getComputedStyle(a).scrollbarGutter === "stable both-edges" ? i / 2 : i;
		o <= Ca && (s -= o);
	}
	return {
		width: s,
		height: c,
		x: l,
		y: u
	};
}
function Ta(e, t) {
	let n = _a(e, !0, t === "fixed"), r = n.top + e.clientTop, i = n.left + e.clientLeft, a = pa(e);
	return {
		width: e.clientWidth * a.x,
		height: e.clientHeight * a.y,
		x: i * a.x,
		y: r * a.y
	};
}
function Ea(e, t, n) {
	let r;
	if (t === "viewport" || t === "layoutViewport") r = wa(e, n, t);
	else if (t === "document") r = Sa(Ui(e));
	else if (Gi(t)) r = Ta(t, n);
	else {
		let n = ha(e);
		r = {
			x: t.x - n.x,
			y: t.y - n.y,
			width: t.width,
			height: t.height
		};
	}
	return wi(r);
}
function Da(e, t) {
	let n = t.get(e);
	if (n) return n;
	let r = la(e, [], !1).filter((e) => Gi(e) && Vi(e) !== "body"), i = null, a = aa(e).position === "fixed", o = a ? sa(e) : e;
	for (; Gi(o) && !ia(o);) {
		let e = aa(o), t = ta(o), n = i ? i.position : a ? "fixed" : "";
		!t && (n === "fixed" || n === "absolute" && e.position === "static") ? r = r.filter((e) => e !== o) : i = e, o = sa(o);
	}
	return t.set(e, r), r;
}
function Oa(e) {
	let { element: t, boundary: n, rootBoundary: r, strategy: i } = e, a = [...n === "clippingAncestors" ? Xi(t) ? [] : Da(t, this._c) : [].concat(n), r], o = Ea(t, a[0], i), s = o.top, c = o.right, l = o.bottom, u = o.left;
	for (let e = 1; e < a.length; e++) {
		let n = Ea(t, a[e], i);
		s = $r(n.top, s), c = Qr(n.right, c), l = Qr(n.bottom, l), u = $r(n.left, u);
	}
	return {
		width: c - u,
		height: l - s,
		x: u,
		y: s
	};
}
function ka(e) {
	let { width: t, height: n } = da(e);
	return {
		width: t,
		height: n
	};
}
function Aa(e, t, n) {
	let r = Ki(t), i = Ui(t), a = n === "fixed", o = _a(e, !0, a, t), s = {
		scrollLeft: 0,
		scrollTop: 0
	}, c = ni(0);
	if ((r || !a) && ((Vi(t) !== "body" || Ji(i)) && (s = oa(t)), r)) {
		let e = _a(t, !0, a, t);
		c.x = e.x + t.clientLeft, c.y = e.y + t.clientTop;
	}
	!r && i && (c.x = va(i));
	let l = i && !r && !a ? ya(i, s) : ni(0);
	return {
		x: o.left + s.scrollLeft - c.x - l.x,
		y: o.top + s.scrollTop - c.y - l.y,
		width: o.width,
		height: o.height
	};
}
function ja(e) {
	return aa(e).position === "static";
}
function Ma(e, t) {
	if (!Ki(e) || aa(e).position === "fixed") return null;
	if (t) return t(e);
	let n = e.offsetParent;
	return Ui(e) === n && (n = n.ownerDocument.body), n;
}
function Na(e, t) {
	let n = Hi(e);
	if (Xi(e)) return n;
	if (!Ki(e)) {
		let t = sa(e);
		for (; t && !ia(t);) {
			if (Gi(t) && !ja(t)) return t;
			t = sa(t);
		}
		return n;
	}
	let r = Ma(e, t);
	for (; r && Yi(r) && ja(r);) r = Ma(r, t);
	return r && ia(r) && ja(r) && !ta(r) ? n : r || na(e) || n;
}
var Pa = async function(e) {
	let t = this.getOffsetParent || Na, n = this.getDimensions, r = await n(e.floating);
	return {
		reference: Aa(e.reference, await t(e.floating), e.strategy),
		floating: {
			x: 0,
			y: 0,
			width: r.width,
			height: r.height
		}
	};
};
function Fa(e) {
	return aa(e).direction === "rtl";
}
var Ia = {
	convertOffsetParentRelativeRectToViewportRelativeRect: ba,
	getDocumentElement: Ui,
	getClippingRect: Oa,
	getOffsetParent: Na,
	getElementRects: Pa,
	getClientRects: xa,
	getDimensions: ka,
	getScale: pa,
	isElement: Gi,
	isRTL: Fa
};
function La(e, t) {
	return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
}
function Ra(e, t, n) {
	let r = null, i, a = Ui(e);
	function o() {
		var e;
		clearTimeout(i), (e = r) == null || e.disconnect(), r = null;
	}
	function s(n, c) {
		n === void 0 && (n = !1), c === void 0 && (c = 1), o();
		let l = e.getBoundingClientRect(), { left: u, top: d, width: f, height: p } = l;
		if (n || t(), !f || !p) return;
		let m = ti(d), h = ti(a.clientWidth - (u + f)), g = ti(a.clientHeight - (d + p)), _ = ti(u), v = {
			rootMargin: -m + "px " + -h + "px " + -g + "px " + -_ + "px",
			threshold: $r(0, Qr(1, c)) || 1
		}, y = !0;
		function b(t) {
			let n = t[0].intersectionRatio;
			if (!La(l, e.getBoundingClientRect())) return s();
			if (n !== c) {
				if (!y) return s();
				n ? s(!1, n) : i = setTimeout(() => {
					s(!1, 1e-7);
				}, 1e3);
			}
			y = !1;
		}
		try {
			r = new IntersectionObserver(b, {
				...v,
				root: a.ownerDocument
			});
		} catch {
			r = new IntersectionObserver(b, v);
		}
		r.observe(e);
	}
	let c = Hi(e), l = () => s(n);
	return c.addEventListener("resize", l), s(!0), () => {
		c.removeEventListener("resize", l), o();
	};
}
function za(e, t, n, r) {
	r === void 0 && (r = {});
	let { ancestorScroll: i = !0, ancestorResize: a = !0, elementResize: o = typeof ResizeObserver == "function", layoutShift: s = typeof IntersectionObserver == "function", animationFrame: c = !1 } = r, l = fa(e), u = i || a ? [...l ? la(l) : [], ...t ? la(t) : []] : [];
	u.forEach((e) => {
		i && e.addEventListener("scroll", n), a && e.addEventListener("resize", n);
	});
	let d = l && s ? Ra(l, n, a) : null, f = -1, p = null;
	o && (p = new ResizeObserver((e) => {
		let [r] = e;
		r && r.target === l && p && t && (p.unobserve(t), cancelAnimationFrame(f), f = requestAnimationFrame(() => {
			var e;
			(e = p) == null || e.observe(t);
		})), n();
	}), l && !c && p.observe(l), t && p.observe(t));
	let m, h = c ? _a(e) : null;
	c && g();
	function g() {
		let t = _a(e);
		h && !La(h, t) && n(), h = t, m = requestAnimationFrame(g);
	}
	return n(), () => {
		var e;
		u.forEach((e) => {
			i && e.removeEventListener("scroll", n), a && e.removeEventListener("resize", n);
		}), d?.(), (e = p) == null || e.disconnect(), p = null, c && cancelAnimationFrame(m);
	};
}
var Ba = Ii, Va = Li, Ha = Ai, Ua = zi, Wa = Ni, Ga = ki, Ka = Ri, qa = (e, t, n) => {
	let r = /* @__PURE__ */ new Map(), i = n ?? {}, a = {
		...Ia,
		...i.platform,
		_c: r
	};
	return Oi(e, t, {
		...i,
		platform: a
	});
}, Ja = typeof document < "u" ? de : function() {};
function Ya(e, t) {
	if (e === t) return !0;
	if (typeof e != typeof t) return !1;
	if (typeof e == "function" && e.toString() === t.toString()) return !0;
	let n, r, i;
	if (e && t && typeof e == "object") {
		if (Array.isArray(e)) {
			if (n = e.length, n !== t.length) return !1;
			for (r = n; r-- !== 0;) if (!Ya(e[r], t[r])) return !1;
			return !0;
		}
		if (i = Object.keys(e), n = i.length, n !== Object.keys(t).length) return !1;
		for (r = n; r-- !== 0;) if (!{}.hasOwnProperty.call(t, i[r])) return !1;
		for (r = n; r-- !== 0;) {
			let n = i[r];
			if (!(n === "_owner" && e.$$typeof) && !Ya(e[n], t[n])) return !1;
		}
		return !0;
	}
	return e !== e && t !== t;
}
function Xa(e) {
	return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function Za(e, t) {
	let n = Xa(e);
	return Math.round(t * n) / n;
}
function Qa(e) {
	let t = U.useRef(e);
	return Ja(() => {
		t.current = e;
	}), t;
}
function $a(e) {
	e === void 0 && (e = {});
	let { placement: t = "bottom", strategy: n = "absolute", middleware: r = [], platform: i, elements: { reference: a, floating: o } = {}, transform: s = !0, whileElementsMounted: c, open: l } = e, [u, d] = U.useState({
		x: 0,
		y: 0,
		strategy: n,
		placement: t,
		middlewareData: {},
		isPositioned: !1
	}), [f, p] = U.useState(r);
	Ya(f, r) || p(r);
	let [m, h] = U.useState(null), [g, _] = U.useState(null), v = U.useCallback((e) => {
		e !== S.current && (S.current = e, h(e));
	}, []), y = U.useCallback((e) => {
		e !== C.current && (C.current = e, _(e));
	}, []), b = a || m, x = o || g, S = U.useRef(null), C = U.useRef(null), w = U.useRef(u), T = c != null, E = Qa(c), D = Qa(i), O = Qa(l), k = U.useCallback(() => {
		if (!S.current || !C.current) return;
		let e = {
			placement: t,
			strategy: n,
			middleware: f
		};
		D.current && (e.platform = D.current), qa(S.current, C.current, e).then((e) => {
			let t = {
				...e,
				isPositioned: O.current !== !1
			};
			A.current && !Ya(w.current, t) && (w.current = t, he.flushSync(() => {
				d(t);
			}));
		});
	}, [
		f,
		t,
		n,
		D,
		O
	]);
	Ja(() => {
		l === !1 && w.current.isPositioned && (w.current.isPositioned = !1, d((e) => ({
			...e,
			isPositioned: !1
		})));
	}, [l]);
	let A = U.useRef(!1);
	Ja(() => (A.current = !0, () => {
		A.current = !1;
	}), []), Ja(() => {
		if (b && (S.current = b), x && (C.current = x), b && x) {
			if (E.current) return E.current(b, x, k);
			k();
		}
	}, [
		b,
		x,
		k,
		E,
		T
	]);
	let j = U.useMemo(() => ({
		reference: S,
		floating: C,
		setReference: v,
		setFloating: y
	}), [v, y]), M = U.useMemo(() => ({
		reference: b,
		floating: x
	}), [b, x]), N = U.useMemo(() => {
		let e = {
			position: n,
			left: 0,
			top: 0
		};
		if (!M.floating) return e;
		let t = Za(M.floating, u.x), r = Za(M.floating, u.y);
		return s ? {
			...e,
			transform: "translate(" + t + "px, " + r + "px)",
			...Xa(M.floating) >= 1.5 && { willChange: "transform" }
		} : {
			position: n,
			left: t,
			top: r
		};
	}, [
		n,
		s,
		M.floating,
		u.x,
		u.y
	]);
	return U.useMemo(() => ({
		...u,
		update: k,
		refs: j,
		elements: M,
		floatingStyles: N
	}), [
		u,
		k,
		j,
		M,
		N
	]);
}
var eo = (e) => {
	function t(e) {
		return {}.hasOwnProperty.call(e, "current");
	}
	return {
		name: "arrow",
		options: e,
		fn(n) {
			let { element: r, padding: i } = typeof e == "function" ? e(n) : e;
			return r && t(r) ? r.current == null ? {} : Ga({
				element: r.current,
				padding: i
			}).fn(n) : r ? Ga({
				element: r,
				padding: i
			}).fn(n) : {};
		}
	};
}, to = (e, t) => {
	let n = Ba(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, no = (e, t) => {
	let n = Va(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, ro = (e, t) => ({
	fn: Ka(e).fn,
	options: [e, t]
}), io = (e, t) => {
	let n = Ha(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, ao = (e, t) => {
	let n = Ua(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, oo = (e, t) => {
	let n = Wa(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, so = (e, t) => {
	let n = eo(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, co = Object.defineProperty, lo = (e, t) => co(e, "name", {
	value: t,
	configurable: !0
});
function uo(e) {
	let [t, n] = U.useState(void 0);
	return An(() => {
		if (e) {
			n({
				width: e.offsetWidth,
				height: e.offsetHeight
			});
			let t = 0, r = new ResizeObserver((r) => {
				if (!Array.isArray(r) || !r.length) return;
				let i = r[0];
				window.cancelAnimationFrame(t), t = window.requestAnimationFrame(() => {
					let t, r;
					if ("borderBoxSize" in i) {
						let e = i.borderBoxSize, n = Array.isArray(e) ? e[0] : e;
						t = n.inlineSize, r = n.blockSize;
					} else t = e.offsetWidth, r = e.offsetHeight;
					n({
						width: t,
						height: r
					});
				});
			});
			return r.observe(e, { box: "border-box" }), () => {
				window.cancelAnimationFrame(t), r.unobserve(e);
			};
		}
		n(void 0);
	}, [e]), t;
}
lo(uo, "useSize");
// node_modules/@radix-ui/react-popper/dist/index.mjs
var fo = Object.defineProperty, po = (e, t) => fo(e, "name", {
	value: t,
	configurable: !0
}), mo = {
	Partial: "partial",
	Always: "always"
}, ho = {
	Optimized: "optimized",
	Always: "always"
}, go = "Popper", [_o, vo] = /* @__PURE__ */ sn(go), [yo, bo] = _o(go), xo = /* @__PURE__ */ po((e) => {
	let { __scopePopper: t, children: n } = e, [r, i] = U.useState(null), [a, o] = U.useState(void 0);
	return /* @__PURE__ */ q(yo, {
		scope: t,
		anchor: r,
		onAnchorChange: i,
		placementState: a,
		setPlacementState: o,
		children: n
	});
}, "Popper"), So = "PopperAnchor", Co = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ po(function(e, t) {
	let { __scopePopper: n, virtualRef: r, ...i } = e, a = bo(So, n), o = U.useRef(null), s = a.onAnchorChange, c = Z(t, U.useCallback((e) => {
		o.current = e, e && s(e);
	}, [s])), l = U.useRef(null);
	U.useEffect(() => {
		if (!r) return;
		let e = l.current;
		l.current = r.current, e !== l.current && s(l.current);
	});
	let u = a.placementState && Ao(a.placementState), d = u?.[0], f = u?.[1];
	return r ? null : /* @__PURE__ */ q(Qn.div, {
		"data-radix-popper-side": d,
		"data-radix-popper-align": f,
		...i,
		ref: c
	});
}, "PopperAnchor")), wo = "PopperContent", [To, Eo] = _o(wo), Do = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ po(function(e, t) {
	let { __scopePopper: n, side: r = "bottom", sideOffset: i = 0, align: a = "center", alignOffset: o = 0, arrowPadding: s = 0, avoidCollisions: c = !0, collisionBoundary: l = [], collisionPadding: u = 0, sticky: d = mo.Partial, hideWhenDetached: f = !1, updatePositionStrategy: p = ho.Optimized, onPlaced: m, ...h } = e, g = bo(wo, n), [_, v] = U.useState(null), y = Z(t, v), [b, x] = U.useState(null), S = uo(b), C = S?.width ?? 0, w = S?.height ?? 0, T = r + (a === "center" ? "" : "-" + a), E = typeof u == "number" ? u : {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		...u
	}, D = Array.isArray(l) ? l : [l], O = D.length > 0, k = {
		padding: E,
		boundary: D.filter(Oo),
		altBoundary: O
	}, { refs: A, floatingStyles: j, placement: M, isPositioned: N, middlewareData: P } = $a({
		strategy: "fixed",
		placement: T,
		whileElementsMounted: /* @__PURE__ */ po((...e) => za(...e, { animationFrame: p === ho.Always }), "whileElementsMounted"),
		elements: { reference: g.anchor },
		middleware: [
			to({
				mainAxis: i + w,
				alignmentAxis: o
			}),
			c && no({
				mainAxis: !0,
				crossAxis: !1,
				...d === mo.Partial ? { limiter: ro() } : {},
				...k
			}),
			c && io({ ...k }),
			ao({
				...k,
				apply: /* @__PURE__ */ po(({ elements: e, rects: t, availableWidth: n, availableHeight: r }) => {
					let { width: i, height: a } = t.reference, o = e.floating.style;
					o.setProperty("--radix-popper-available-width", `${n}px`), o.setProperty("--radix-popper-available-height", `${r}px`), o.setProperty("--radix-popper-anchor-width", `${i}px`), o.setProperty("--radix-popper-anchor-height", `${a}px`);
				}, "apply")
			}),
			b && so({
				element: b,
				padding: s
			}),
			ko({
				arrowWidth: C,
				arrowHeight: w
			}),
			f && oo(O ? {
				strategy: "referenceHidden",
				...k
			} : {
				strategy: "referenceHidden",
				padding: k.padding,
				altBoundary: k.altBoundary
			})
		]
	}), F = g.setPlacementState;
	An(() => (F(M), () => {
		F(void 0);
	}), [M, F]);
	let [I, L] = Ao(M), R = rr(m);
	An(() => {
		N && R?.();
	}, [N, R]);
	let z = P.arrow?.x, B = P.arrow?.y, ee = P.arrow?.centerOffset !== 0, [V, H] = U.useState();
	return An(() => {
		_ && H(window.getComputedStyle(_).zIndex);
	}, [_]), /* @__PURE__ */ q("div", {
		ref: A.setFloating,
		"data-radix-popper-content-wrapper": "",
		style: {
			...j,
			transform: N ? j.transform : "translate(0, -200%)",
			minWidth: "max-content",
			zIndex: V,
			"--radix-popper-transform-origin": [P.transformOrigin?.x, P.transformOrigin?.y].join(" "),
			...P.hide?.referenceHidden && {
				visibility: "hidden",
				pointerEvents: "none"
			}
		},
		dir: e.dir,
		children: /* @__PURE__ */ q(To, {
			scope: n,
			placedSide: I,
			placedAlign: L,
			onArrowChange: x,
			arrowX: z,
			arrowY: B,
			shouldHideArrow: ee,
			children: /* @__PURE__ */ q(Qn.div, {
				"data-side": I,
				"data-align": L,
				...h,
				ref: y,
				style: {
					...h.style,
					animation: N ? h.style?.animation : "none"
				}
			})
		})
	});
}, "PopperContent"));
function Oo(e) {
	return e !== null;
}
po(Oo, "isNotNull");
var ko = /* @__PURE__ */ po((e) => ({
	name: "transformOrigin",
	options: e,
	fn(t) {
		let { placement: n, rects: r, middlewareData: i } = t, a = i.arrow?.centerOffset !== 0, o = a ? 0 : e.arrowWidth, s = a ? 0 : e.arrowHeight, [c, l] = Ao(n), u = {
			start: "0%",
			center: "50%",
			end: "100%"
		}[l], d = (i.arrow?.x ?? 0) + o / 2, f = (i.arrow?.y ?? 0) + s / 2, p = "", m = "";
		return c === "bottom" ? (p = a ? u : `${d}px`, m = `${-s}px`) : c === "top" ? (p = a ? u : `${d}px`, m = `${r.floating.height + s}px`) : c === "right" ? (p = `${-s}px`, m = a ? u : `${f}px`) : c === "left" && (p = `${r.floating.width + s}px`, m = a ? u : `${f}px`), { data: {
			x: p,
			y: m
		} };
	}
}), "transformOrigin");
function Ao(e) {
	let [t, n = "center"] = e.split("-");
	return [t, n];
}
po(Ao, "getSideAndAlignFromPlacement");
// node_modules/@radix-ui/react-portal/dist/index.mjs
var jo = Object.defineProperty, Mo = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ ((e, t) => jo(e, "name", {
	value: t,
	configurable: !0
}))(function(e, t) {
	let { container: n, ...r } = e, [i, a] = U.useState(!1);
	An(() => a(!0), []);
	let o = n || i && globalThis?.document?.body;
	return o ? he.createPortal(/* @__PURE__ */ q(Qn.div, {
		...r,
		ref: t
	}), o) : null;
}, "Portal")), No = Object.defineProperty, Po = (e, t) => No(e, "name", {
	value: t,
	configurable: !0
});
function Fo(e, t) {
	return U.useReducer((e, n) => t[e][n] ?? e, e);
}
Po(Fo, "useStateMachine");
var Io = /* @__PURE__ */ Po((e) => {
	let { present: t, children: n } = e, r = Lo(t), i = typeof n == "function" ? n({ present: r.isPresent }) : U.Children.only(n), a = zo(r.ref, Vo(i));
	return typeof n == "function" || r.isPresent ? U.cloneElement(i, { ref: a }) : null;
}, "Presence");
function Lo(e) {
	let [t, n] = U.useState(), r = U.useRef(null), i = U.useRef(e), a = U.useRef("none"), o = U.useRef(void 0), [s, c] = Fo(e ? "mounted" : "unmounted", {
		mounted: {
			UNMOUNT: "unmounted",
			ANIMATION_OUT: "unmountSuspended"
		},
		unmountSuspended: {
			MOUNT: "mounted",
			ANIMATION_END: "unmounted"
		},
		unmounted: { MOUNT: "mounted" }
	});
	return U.useEffect(() => {
		s === "mounted" ? (a.current = o.current ?? Bo(r.current), o.current = void 0) : a.current = "none";
	}, [s]), An(() => {
		let t = r.current, n = i.current;
		if (n !== e) {
			let r = a.current, s = Bo(t);
			e ? (o.current = s, c("MOUNT")) : s === "none" || t?.display === "none" ? c("UNMOUNT") : c(n && r !== s ? "ANIMATION_OUT" : "UNMOUNT"), i.current = e;
		}
	}, [e, c]), An(() => {
		if (t) {
			let e, n = t.ownerDocument.defaultView ?? window, o = /* @__PURE__ */ Po((a) => {
				let o = Bo(r.current).includes(CSS.escape(a.animationName));
				if (a.target === t && o && (c("ANIMATION_END"), !i.current)) {
					let r = t.style.animationFillMode;
					t.style.animationFillMode = "forwards", e = n.setTimeout(() => {
						t.style.animationFillMode === "forwards" && (t.style.animationFillMode = r);
					});
				}
			}, "handleAnimationEnd"), s = /* @__PURE__ */ Po((e) => {
				e.target === t && (a.current = Bo(r.current));
			}, "handleAnimationStart");
			return t.addEventListener("animationstart", s), t.addEventListener("animationcancel", o), t.addEventListener("animationend", o), () => {
				n.clearTimeout(e), t.removeEventListener("animationstart", s), t.removeEventListener("animationcancel", o), t.removeEventListener("animationend", o);
			};
		}
		c("ANIMATION_END");
	}, [t, c]), {
		isPresent: ["mounted", "unmountSuspended"].includes(s),
		ref: U.useCallback((e) => {
			if (e) {
				let t = getComputedStyle(e);
				r.current = t, o.current = Bo(t);
			} else r.current = null;
			n(e);
		}, [])
	};
}
Po(Lo, "usePresence");
function Ro(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
Po(Ro, "setRef");
function zo(...e) {
	let t = U.useRef(e);
	return t.current = e, U.useCallback((e) => {
		let n = t.current, r = !1, i = n.map((t) => {
			let n = Ro(t, e);
			return !r && typeof n == "function" && (r = !0), n;
		});
		if (r) return () => {
			for (let e = 0; e < i.length; e++) {
				let t = i[e];
				typeof t == "function" ? t() : Ro(n[e], null);
			}
		};
	}, []);
}
Po(zo, "useStableComposedRefs");
function Bo(e) {
	return e?.animationName || "none";
}
Po(Bo, "getAnimationName");
function Vo(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
Po(Vo, "getElementRef");
// node_modules/@radix-ui/react-use-effect-event/dist/index.mjs
var Ho = Object.defineProperty, Uo = (e, t) => Ho(e, "name", {
	value: t,
	configurable: !0
}), Wo = U.useEffectEvent, Go = U.useInsertionEffect;
function Ko(e) {
	if (typeof Wo == "function") return Wo(e);
	let t = U.useRef(() => {
		throw Error("Cannot call an event handler while rendering.");
	});
	return typeof Go == "function" ? Go(() => {
		t.current = e;
	}) : An(() => {
		t.current = e;
	}), U.useMemo(() => ((...e) => t.current?.(...e)), []);
}
Uo(Ko, "useEffectEvent");
// node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var qo = Object.defineProperty, Jo = (e, t) => qo(e, "name", {
	value: t,
	configurable: !0
}), Yo = U.useInsertionEffect || An;
function Xo({ prop: e, defaultProp: t, onChange: n = /* @__PURE__ */ Jo(() => {}, "onChange"), caller: r }) {
	let [i, a, o] = Zo({
		defaultProp: t,
		onChange: n
	}), s = e !== void 0;
	return [s ? e : i, U.useCallback((t) => {
		if (s) {
			let n = Qo(t) ? t(e) : t;
			n !== e && o.current?.(n);
		} else a(t);
	}, [
		s,
		e,
		a,
		o
	])];
}
Jo(Xo, "useControllableState");
function Zo({ defaultProp: e, onChange: t }) {
	let [n, r] = U.useState(e), i = U.useRef(n), a = U.useRef(t);
	return Yo(() => {
		a.current = t;
	}, [t]), U.useEffect(() => {
		i.current !== n && (a.current?.(n), i.current = n);
	}, [n, i]), [
		n,
		r,
		a
	];
}
Jo(Zo, "useUncontrolledState");
function Qo(e) {
	return typeof e == "function";
}
Jo(Qo, "isFunction");
var $o = Symbol("RADIX:SYNC_STATE");
function es(e, t, n, r) {
	let { prop: i, defaultProp: a, onChange: o, caller: s } = t, c = i !== void 0, l = Ko(o), u = [{
		...n,
		state: a
	}];
	r && u.push(r);
	let [d, f] = U.useReducer((t, n) => {
		if (n.type === $o) return {
			...t,
			state: n.state
		};
		let r = e(t, n);
		return c && !Object.is(r.state, t.state) && l(r.state), r;
	}, ...u), p = d.state, m = U.useRef(p);
	U.useEffect(() => {
		m.current !== p && (m.current = p, c || l(p));
	}, [
		p,
		m,
		c
	]);
	let h = U.useMemo(() => i === void 0 ? d : {
		...d,
		state: i
	}, [d, i]);
	return U.useEffect(() => {
		c && !Object.is(i, d.state) && f({
			type: $o,
			state: i
		});
	}, [
		i,
		d.state,
		c
	]), [h, f];
}
Jo(es, "useControllableStateReducer");
// node_modules/@radix-ui/react-visually-hidden/dist/index.mjs
var ts = Object.freeze({
	position: "absolute",
	border: 0,
	width: 1,
	height: 1,
	padding: 0,
	margin: -1,
	overflow: "hidden",
	clip: "rect(0, 0, 0, 0)",
	whiteSpace: "nowrap",
	wordWrap: "normal"
}), ns = function(e) {
	return typeof document > "u" ? null : (Array.isArray(e) ? e[0] : e).ownerDocument.body;
}, rs = /* @__PURE__ */ new WeakMap(), is = /* @__PURE__ */ new WeakMap(), as = {}, os = 0, ss = function(e) {
	return e && (e.host || ss(e.parentNode));
}, cs = function(e, t) {
	return t.map(function(t) {
		if (e.contains(t)) return t;
		var n = ss(t);
		return n && e.contains(n) ? n : (console.error("aria-hidden", t, "in not contained inside", e, ". Doing nothing"), null);
	}).filter(function(e) {
		return !!e;
	});
}, ls = function(e, t, n, r) {
	var i = cs(t, Array.isArray(e) ? e : [e]);
	as[n] || (as[n] = /* @__PURE__ */ new WeakMap());
	var a = as[n], o = [], s = /* @__PURE__ */ new Set(), c = new Set(i), l = function(e) {
		e && !s.has(e) && (s.add(e), l(e.parentNode));
	};
	i.forEach(l);
	var u = function(e) {
		e && !c.has(e) && Array.prototype.forEach.call(e.children, function(e) {
			if (s.has(e)) u(e);
			else try {
				var t = e.getAttribute(r), i = t !== null && t !== "false", c = (rs.get(e) || 0) + 1, l = (a.get(e) || 0) + 1;
				rs.set(e, c), a.set(e, l), o.push(e), c === 1 && i && is.set(e, !0), l === 1 && e.setAttribute(n, "true"), i || e.setAttribute(r, "true");
			} catch (t) {
				console.error("aria-hidden: cannot operate on ", e, t);
			}
		});
	};
	return u(t), s.clear(), os++, function() {
		o.forEach(function(e) {
			var t = rs.get(e) - 1, i = a.get(e) - 1;
			rs.set(e, t), a.set(e, i), t || (is.has(e) || e.removeAttribute(r), is.delete(e)), i || e.removeAttribute(n);
		}), os--, os || (rs = /* @__PURE__ */ new WeakMap(), rs = /* @__PURE__ */ new WeakMap(), is = /* @__PURE__ */ new WeakMap(), as = {});
	};
}, us = function(e, t, n) {
	n === void 0 && (n = "data-aria-hidden");
	var r = Array.from(Array.isArray(e) ? e : [e]), i = t || ns(e);
	return i ? (r.push.apply(r, Array.from(i.querySelectorAll("[aria-live], script"))), ls(r, i, n, "aria-hidden")) : function() {
		return null;
	};
}, ds = function() {
	return ds = Object.assign || function(e) {
		for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n], t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
		return e;
	}, ds.apply(this, arguments);
};
function fs(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
function ps(e, t, n) {
	if (n || arguments.length === 2) for (var r = 0, i = t.length, a; r < i; r++) (a || !(r in t)) && (a ||= Array.prototype.slice.call(t, 0, r), a[r] = t[r]);
	return e.concat(a || Array.prototype.slice.call(t));
}
// node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var ms = "right-scroll-bar-position", hs = "width-before-scroll-bar", gs = "with-scroll-bars-hidden", _s = "--removed-body-scroll-bar-size";
// node_modules/use-callback-ref/dist/es2015/assignRef.js
function vs(e, t) {
	return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
// node_modules/use-callback-ref/dist/es2015/useRef.js
function ys(e, t) {
	var n = K(function() {
		return {
			value: e,
			callback: t,
			facade: {
				get current() {
					return n.value;
				},
				set current(e) {
					var t = n.value;
					t !== e && (n.value = e, n.callback(e, t));
				}
			}
		};
	})[0];
	return n.callback = t, n.facade;
}
// node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var bs = typeof window < "u" ? U.useLayoutEffect : U.useEffect, xs = /* @__PURE__ */ new WeakMap();
function Ss(e, t) {
	var n = ys(t || null, function(t) {
		return e.forEach(function(e) {
			return vs(e, t);
		});
	});
	return bs(function() {
		var t = xs.get(n);
		if (t) {
			var r = new Set(t), i = new Set(e), a = n.current;
			r.forEach(function(e) {
				i.has(e) || vs(e, null);
			}), i.forEach(function(e) {
				r.has(e) || vs(e, a);
			});
		}
		xs.set(n, e);
	}, [e]), n;
}
// node_modules/use-sidecar/dist/es2015/medium.js
function Cs(e) {
	return e;
}
function ws(e, t) {
	t === void 0 && (t = Cs);
	var n = [], r = !1;
	return {
		read: function() {
			if (r) throw Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			return n.length ? n[n.length - 1] : e;
		},
		useMedium: function(e) {
			var i = t(e, r);
			return n.push(i), function() {
				n = n.filter(function(e) {
					return e !== i;
				});
			};
		},
		assignSyncMedium: function(e) {
			for (r = !0; n.length;) {
				var t = n;
				n = [], t.forEach(e);
			}
			n = {
				push: function(t) {
					return e(t);
				},
				filter: function() {
					return n;
				}
			};
		},
		assignMedium: function(e) {
			r = !0;
			var t = [];
			if (n.length) {
				var i = n;
				n = [], i.forEach(e), t = n;
			}
			var a = function() {
				var n = t;
				t = [], n.forEach(e);
			}, o = function() {
				return Promise.resolve().then(a);
			};
			o(), n = {
				push: function(e) {
					t.push(e), o();
				},
				filter: function(e) {
					return t = t.filter(e), n;
				}
			};
		}
	};
}
function Ts(e) {
	e === void 0 && (e = {});
	var t = ws(null);
	return t.options = ds({
		async: !0,
		ssr: !1
	}, e), t;
}
// node_modules/use-sidecar/dist/es2015/exports.js
var Es = function(e) {
	var t = e.sideCar, n = fs(e, ["sideCar"]);
	if (!t) throw Error("Sidecar: please provide `sideCar` property to import the right car");
	var r = t.read();
	if (!r) throw Error("Sidecar medium not found");
	return U.createElement(r, ds({}, n));
};
Es.isSideCarExport = !0;
function Ds(e, t) {
	return e.useMedium(t), Es;
}
// node_modules/react-remove-scroll/dist/es2015/medium.js
var Os = Ts(), ks = function() {}, As = U.forwardRef(function(e, t) {
	var n = U.useRef(null), r = U.useState({
		onScrollCapture: ks,
		onWheelCapture: ks,
		onTouchMoveCapture: ks
	}), i = r[0], a = r[1], o = e.forwardProps, s = e.children, c = e.className, l = e.removeScrollBar, u = e.enabled, d = e.shards, f = e.sideCar, p = e.noRelative, m = e.noIsolation, h = e.inert, g = e.allowPinchZoom, _ = e.as, v = _ === void 0 ? "div" : _, y = e.gapMode, b = fs(e, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]), x = f, S = Ss([n, t]), C = ds(ds({}, b), i);
	return U.createElement(U.Fragment, null, u && U.createElement(x, {
		sideCar: Os,
		removeScrollBar: l,
		shards: d,
		noRelative: p,
		noIsolation: m,
		inert: h,
		setCallbacks: a,
		allowPinchZoom: !!g,
		lockRef: n,
		gapMode: y
	}), o ? U.cloneElement(U.Children.only(s), ds(ds({}, C), { ref: S })) : U.createElement(v, ds({}, C, {
		className: c,
		ref: S
	}), s));
});
As.defaultProps = {
	enabled: !0,
	removeScrollBar: !0,
	inert: !1
}, As.classNames = {
	fullWidth: hs,
	zeroRight: ms
};
// node_modules/get-nonce/dist/es2015/index.js
var js = function() {
	if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
// node_modules/react-style-singleton/dist/es2015/singleton.js
function Ms() {
	if (!document) return null;
	var e = document.createElement("style");
	e.type = "text/css";
	var t = js();
	return t && e.setAttribute("nonce", t), e;
}
function Ns(e, t) {
	e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function Ps(e) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(e);
}
var Fs = function() {
	var e = 0, t = null;
	return {
		add: function(n) {
			e == 0 && (t = Ms()) && (Ns(t, n), Ps(t)), e++;
		},
		remove: function() {
			e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
		}
	};
}, Is = function() {
	var e = Fs();
	return function(t, n) {
		U.useEffect(function() {
			return e.add(t), function() {
				e.remove();
			};
		}, [t && n]);
	};
}, Ls = function() {
	var e = Is();
	return function(t) {
		var n = t.styles, r = t.dynamic;
		return e(n, r), null;
	};
}, Rs = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
}, zs = function(e) {
	return parseInt(e || "", 10) || 0;
}, Bs = function(e) {
	var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
	return [
		zs(n),
		zs(r),
		zs(i)
	];
}, Vs = function(e) {
	if (e === void 0 && (e = "margin"), typeof window > "u") return Rs;
	var t = Bs(e), n = document.documentElement.clientWidth, r = window.innerWidth;
	return {
		left: t[0],
		top: t[1],
		right: t[2],
		gap: Math.max(0, r - n + t[2] - t[0])
	};
}, Hs = Ls(), Us = "data-scroll-locked", Ws = function(e, t, n, r) {
	var i = e.left, a = e.top, o = e.right, s = e.gap;
	return n === void 0 && (n = "margin"), `
  .${gs} {
   overflow: hidden ${r};
   padding-right: ${s}px ${r};
  }
  body[${Us}] {
    overflow: hidden ${r};
    overscroll-behavior: contain;
    ${[
		t && `position: relative ${r};`,
		n === "margin" && `
    padding-left: ${i}px;
    padding-top: ${a}px;
    padding-right: ${o}px;
    margin-left:0;
    margin-top:0;
    margin-right: ${s}px ${r};
    `,
		n === "padding" && `padding-right: ${s}px ${r};`
	].filter(Boolean).join("")}
  }
  
  .${ms} {
    right: ${s}px ${r};
  }
  
  .${hs} {
    margin-right: ${s}px ${r};
  }
  
  .${ms} .${ms} {
    right: 0 ${r};
  }
  
  .${hs} .${hs} {
    margin-right: 0 ${r};
  }
  
  body[${Us}] {
    ${_s}: ${s}px;
  }
`;
}, Gs = function() {
	var e = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(e) ? e : 0;
}, Ks = function() {
	U.useEffect(function() {
		return document.body.setAttribute(Us, (Gs() + 1).toString()), function() {
			var e = Gs() - 1;
			e <= 0 ? document.body.removeAttribute(Us) : document.body.setAttribute(Us, e.toString());
		};
	}, []);
}, qs = function(e) {
	var t = e.noRelative, n = e.noImportant, r = e.gapMode, i = r === void 0 ? "margin" : r;
	Ks();
	var a = U.useMemo(function() {
		return Vs(i);
	}, [i]);
	return U.createElement(Hs, { styles: Ws(a, !t, i, n ? "" : "!important") });
}, Js = !1;
if (typeof window < "u") try {
	var Ys = Object.defineProperty({}, "passive", { get: function() {
		return Js = !0, !0;
	} });
	window.addEventListener("test", Ys, Ys), window.removeEventListener("test", Ys, Ys);
} catch {
	Js = !1;
}
var Xs = Js ? { passive: !1 } : !1, Zs = function(e) {
	return e.tagName === "TEXTAREA";
}, Qs = function(e, t) {
	if (!(e instanceof Element)) return !1;
	var n = window.getComputedStyle(e);
	return n[t] !== "hidden" && !(n.overflowY === n.overflowX && !Zs(e) && n[t] === "visible");
}, $s = function(e) {
	return Qs(e, "overflowY");
}, ec = function(e) {
	return Qs(e, "overflowX");
}, tc = function(e, t) {
	var n = t.ownerDocument, r = t;
	do {
		if (typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host), ic(e, r)) {
			var i = ac(e, r);
			if (i[1] > i[2]) return !0;
		}
		r = r.parentNode;
	} while (r && r !== n.body);
	return !1;
}, nc = function(e) {
	return [
		e.scrollTop,
		e.scrollHeight,
		e.clientHeight
	];
}, rc = function(e) {
	return [
		e.scrollLeft,
		e.scrollWidth,
		e.clientWidth
	];
}, ic = function(e, t) {
	return e === "v" ? $s(t) : ec(t);
}, ac = function(e, t) {
	return e === "v" ? nc(t) : rc(t);
}, oc = function(e, t) {
	return e === "h" && t === "rtl" ? -1 : 1;
}, sc = function(e, t, n, r, i) {
	var a = oc(e, window.getComputedStyle(t).direction), o = a * r, s = n.target, c = t.contains(s), l = !1, u = o > 0, d = 0, f = 0;
	do {
		if (!s) break;
		var p = ac(e, s), m = p[0], h = p[1] - p[2] - a * m;
		(m || h) && ic(e, s) && (d += h, f += m);
		var g = s.parentNode;
		s = g && g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? g.host : g;
	} while (!c && s !== document.body || c && (t.contains(s) || t === s));
	return (u && (i && Math.abs(d) < 1 || !i && o > d) || !u && (i && Math.abs(f) < 1 || !i && -o > f)) && (l = !0), l;
}, cc = function(e) {
	return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, lc = function(e) {
	return [e.deltaX, e.deltaY];
}, uc = function(e) {
	return e && "current" in e ? e.current : e;
}, dc = function(e, t) {
	return e[0] === t[0] && e[1] === t[1];
}, fc = function(e) {
	return `
  .block-interactivity-${e} {pointer-events: none;}
  .allow-interactivity-${e} {pointer-events: all;}
`;
}, pc = 0, mc = [];
function hc(e) {
	var t = U.useRef([]), n = U.useRef([0, 0]), r = U.useRef(), i = U.useState(pc++)[0], a = U.useState(Ls)[0], o = U.useRef(e);
	U.useEffect(function() {
		o.current = e;
	}, [e]), U.useEffect(function() {
		if (e.inert) {
			document.body.classList.add(`block-interactivity-${i}`);
			var t = ps([e.lockRef.current], (e.shards || []).map(uc), !0).filter(Boolean);
			return t.forEach(function(e) {
				return e.classList.add(`allow-interactivity-${i}`);
			}), function() {
				document.body.classList.remove(`block-interactivity-${i}`), t.forEach(function(e) {
					return e.classList.remove(`allow-interactivity-${i}`);
				});
			};
		}
	}, [
		e.inert,
		e.lockRef.current,
		e.shards
	]);
	var s = U.useCallback(function(e, t) {
		if ("touches" in e && e.touches.length === 2 || e.type === "wheel" && e.ctrlKey) return !o.current.allowPinchZoom;
		var i = cc(e), a = n.current, s = "deltaX" in e ? e.deltaX : a[0] - i[0], c = "deltaY" in e ? e.deltaY : a[1] - i[1], l, u = e.target, d = Math.abs(s) > Math.abs(c) ? "h" : "v";
		if ("touches" in e && d === "h" && u.type === "range") return !1;
		var f = window.getSelection(), p = f && f.anchorNode;
		if (p && (p === u || p.contains(u))) return !1;
		var m = tc(d, u);
		if (!m) return !0;
		if (m ? l = d : (l = d === "v" ? "h" : "v", m = tc(d, u)), !m) return !1;
		if (!r.current && "changedTouches" in e && (s || c) && (r.current = l), !l) return !0;
		var h = r.current || l;
		return sc(h, t, e, h === "h" ? s : c, !0);
	}, []), c = U.useCallback(function(e) {
		var n = e;
		if (mc.length && mc[mc.length - 1] === a) {
			var r = "deltaY" in n ? lc(n) : cc(n), i = t.current.filter(function(e) {
				return e.name === n.type && (e.target === n.target || n.target === e.shadowParent) && dc(e.delta, r);
			})[0];
			if (i && i.should) n.cancelable && n.preventDefault();
			else if (!i) {
				var c = (o.current.shards || []).map(uc).filter(Boolean).filter(function(e) {
					return e.contains(n.target);
				});
				(c.length > 0 ? s(n, c[0]) : !o.current.noIsolation) && n.cancelable && n.preventDefault();
			}
		}
	}, []), l = U.useCallback(function(e, n, r, i) {
		var a = {
			name: e,
			delta: n,
			target: r,
			should: i,
			shadowParent: gc(r)
		};
		t.current.push(a), setTimeout(function() {
			t.current = t.current.filter(function(e) {
				return e !== a;
			});
		}, 1);
	}, []), u = U.useCallback(function(e) {
		n.current = cc(e), r.current = void 0;
	}, []), d = U.useCallback(function(t) {
		l(t.type, lc(t), t.target, s(t, e.lockRef.current));
	}, []), f = U.useCallback(function(t) {
		l(t.type, cc(t), t.target, s(t, e.lockRef.current));
	}, []);
	U.useEffect(function() {
		return mc.push(a), e.setCallbacks({
			onScrollCapture: d,
			onWheelCapture: d,
			onTouchMoveCapture: f
		}), document.addEventListener("wheel", c, Xs), document.addEventListener("touchmove", c, Xs), document.addEventListener("touchstart", u, Xs), function() {
			mc = mc.filter(function(e) {
				return e !== a;
			}), document.removeEventListener("wheel", c, Xs), document.removeEventListener("touchmove", c, Xs), document.removeEventListener("touchstart", u, Xs);
		};
	}, []);
	var p = e.removeScrollBar, m = e.inert;
	return U.createElement(U.Fragment, null, m ? U.createElement(a, { styles: fc(i) }) : null, p ? U.createElement(qs, {
		noRelative: e.noRelative,
		gapMode: e.gapMode
	}) : null);
}
function gc(e) {
	for (var t = null; e !== null;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
	return t;
}
// node_modules/react-remove-scroll/dist/es2015/sidecar.js
var _c = Ds(Os, hc), vc = U.forwardRef(function(e, t) {
	return U.createElement(As, ds({}, e, {
		ref: t,
		sideCar: _c
	}));
});
vc.classNames = As.classNames;
// node_modules/@radix-ui/react-select/dist/index.mjs
var yc = Object.defineProperty, Q = (e, t) => yc(e, "name", {
	value: t,
	configurable: !0
}), bc = {
	ItemAligned: "item-aligned",
	Popper: "popper"
}, xc = {
	LTR: "ltr",
	RTL: "rtl"
}, Sc = [
	" ",
	"Enter",
	"ArrowUp",
	"ArrowDown"
], Cc = [" ", "Enter"], wc = "Select", [Tc, Ec, Dc] = /* @__PURE__ */ Nn(wc), [Oc, kc] = /* @__PURE__ */ sn(wc, [Dc, vo]), Ac = vo(), [jc, Mc] = Oc(wc), [Nc, Pc] = Oc(wc);
function Fc(e) {
	let { __scopeSelect: t, children: n, open: r, defaultOpen: i, onOpenChange: a, value: o, defaultValue: s, onValueChange: c, dir: l, name: u, autoComplete: d, disabled: f, required: p, form: m, internal_do_not_use_render: h } = e, g = Ac(t), [_, v] = U.useState(null), [y, b] = U.useState(null), [x, S] = U.useState(!1), C = Yn(l), [w, T] = Xo({
		prop: r,
		defaultProp: i ?? !1,
		onChange: a,
		caller: wc
	}), [E, D] = Xo({
		prop: o,
		defaultProp: s,
		onChange: c,
		caller: wc
	}), O = U.useRef(null), k = U.useRef(!1), [A, j] = U.useState(null), M = /* @__PURE__ */ Q((e) => {
		j({
			value: e,
			hasConsumerStoppedPropagation: k.current
		}), D(e);
	}, "handleUserSelect"), N = U.useRef(E);
	U.useEffect(() => {
		let e = m ? _?.ownerDocument.getElementById(m) : _?.form;
		if (e instanceof HTMLFormElement) {
			let t = /* @__PURE__ */ Q(() => D(N.current), "reset");
			return e.addEventListener("reset", t), () => e.removeEventListener("reset", t);
		}
	}, [
		m,
		_,
		D
	]);
	let P = !_ || !!m || !!_.closest("form"), [F, I] = U.useState(/* @__PURE__ */ new Set()), L = Xr(), R = Array.from(F).map((e) => e.props.value).join(";"), z = U.useCallback((e) => {
		I((t) => new Set(t).add(e));
	}, []), B = U.useCallback((e) => {
		I((t) => {
			let n = new Set(t);
			return n.delete(e), n;
		});
	}, []), ee = {
		required: p,
		trigger: _,
		onTriggerChange: v,
		valueNode: y,
		onValueNodeChange: b,
		valueNodeHasChildren: x,
		onValueNodeHasChildrenChange: S,
		contentId: L,
		value: E,
		onValueChange: D,
		hasConsumerStoppedPropagationRef: k,
		userSelection: A,
		onUserSelect: M,
		open: w,
		onOpenChange: T,
		dir: C,
		triggerPointerDownPosRef: O,
		disabled: f,
		name: u,
		autoComplete: d,
		form: m,
		nativeOptions: F,
		nativeSelectKey: R,
		isFormControl: P
	};
	return /* @__PURE__ */ q(xo, {
		...g,
		children: /* @__PURE__ */ q(jc, {
			scope: t,
			...ee,
			children: /* @__PURE__ */ q(Tc.Provider, {
				scope: t,
				children: /* @__PURE__ */ q(Nc, {
					scope: t,
					onNativeOptionAdd: z,
					onNativeOptionRemove: B,
					children: Sl(h) ? h(ee) : n
				})
			})
		})
	});
}
Q(Fc, "SelectProvider");
var Ic = /* @__PURE__ */ Q((e) => {
	let { __scopeSelect: t, children: n, ...r } = e;
	return /* @__PURE__ */ q(Fc, {
		__scopeSelect: t,
		...r,
		internal_do_not_use_render: ({ isFormControl: e }) => /* @__PURE__ */ J(me, { children: [n, e ? /* @__PURE__ */ q(xl, { __scopeSelect: t }) : null] })
	});
}, "Select"), Lc = "SelectTrigger", Rc = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, disabled: r = !1, ...i } = e, a = Ac(n), o = Mc(Lc, n), s = o.disabled || r, c = Z(t, o.onTriggerChange), l = Ec(n), u = U.useRef("touch"), [d, f, p] = wl((e) => {
		let t = l().filter((e) => !e.disabled), n = Tl(t, e, t.find((e) => e.value === o.value));
		n !== void 0 && o.onUserSelect(n.value);
	}), m = /* @__PURE__ */ Q((e) => {
		s || (o.onOpenChange(!0), p()), e && (o.triggerPointerDownPosRef.current = {
			x: Math.round(e.pageX),
			y: Math.round(e.pageY)
		});
	}, "handleOpen");
	return /* @__PURE__ */ q(Co, {
		asChild: !0,
		...a,
		children: /* @__PURE__ */ q(Qn.button, {
			type: "button",
			role: "combobox",
			"aria-controls": o.open ? o.contentId : void 0,
			"aria-expanded": o.open,
			"aria-required": o.required,
			"aria-autocomplete": "none",
			dir: o.dir,
			"data-state": o.open ? "open" : "closed",
			disabled: s,
			"data-disabled": s ? "" : void 0,
			"data-placeholder": Cl(o.value) ? "" : void 0,
			...i,
			ref: c,
			onClick: X(i.onClick, (e) => {
				e.currentTarget.focus(), u.current !== "mouse" && m(e);
			}),
			onPointerDown: X(i.onPointerDown, (e) => {
				u.current = e.pointerType;
				let t = e.target;
				t.hasPointerCapture(e.pointerId) && t.releasePointerCapture(e.pointerId), e.button === 0 && e.ctrlKey === !1 && e.pointerType === "mouse" && (m(e), e.preventDefault());
			}),
			onKeyDown: X(i.onKeyDown, (e) => {
				let t = d.current !== "";
				!(e.ctrlKey || e.altKey || e.metaKey) && e.key.length === 1 && (o.hasConsumerStoppedPropagationRef.current = e.isPropagationStopped(), f(e.key)), !(t && e.key === " ") && Sc.includes(e.key) && (m(), e.preventDefault());
			})
		})
	});
}, "SelectTrigger")), zc = "SelectValue", Bc = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, className: r, style: i, children: a, placeholder: o = "", ...s } = e, c = Mc(zc, n), { onValueNodeHasChildrenChange: l } = c, u = a !== void 0, d = Z(t, c.onValueNodeChange);
	An(() => {
		l(u);
	}, [l, u]);
	let f = Cl(c.value);
	return /* @__PURE__ */ q(Qn.span, {
		...s,
		asChild: !f && s.asChild,
		ref: d,
		style: { pointerEvents: "none" },
		children: /* @__PURE__ */ q(U.Fragment, { children: f ? o : a }, f ? "placeholder" : "value")
	});
}, "SelectValue")), Vc = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, children: r, ...i } = e;
	return /* @__PURE__ */ q(Qn.span, {
		"aria-hidden": !0,
		...i,
		ref: t,
		children: r || "▼"
	});
}, "SelectIcon")), [Hc, Uc] = Oc("SelectPortal", { forceMount: void 0 }), Wc = /* @__PURE__ */ Q((e) => {
	let { __scopeSelect: t, forceMount: n, ...r } = e;
	return /* @__PURE__ */ q(Hc, {
		scope: e.__scopeSelect,
		forceMount: n,
		children: /* @__PURE__ */ q(Mo, {
			asChild: !0,
			...r
		})
	});
}, "SelectPortal"), Gc = "SelectContent", Kc = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let n = Uc(Gc, e.__scopeSelect), { forceMount: r = n.forceMount, ...i } = e, a = Mc(Gc, e.__scopeSelect), [o, s] = U.useState();
	return An(() => {
		s(new DocumentFragment());
	}, []), /* @__PURE__ */ q(Io, {
		present: r || a.open,
		children: ({ present: e }) => e ? /* @__PURE__ */ q(Qc, {
			...i,
			ref: t
		}) : /* @__PURE__ */ q(qc, {
			...i,
			fragment: o
		})
	});
}, "SelectContent")), qc = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, children: r, fragment: i } = e;
	return i ? he.createPortal(/* @__PURE__ */ q(Yc, {
		scope: n,
		children: /* @__PURE__ */ q(Tc.Slot, {
			scope: n,
			children: /* @__PURE__ */ q("div", {
				ref: t,
				children: r
			})
		})
	}), i) : null;
}, "SelectContentFragment")), Jc = 10, [Yc, Xc] = Oc(Gc), Zc = /* @__PURE__ */ hn("SelectContent.RemoveScroll"), Qc = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n } = e, { position: r = bc.ItemAligned, onCloseAutoFocus: i, onEscapeKeyDown: a, onPointerDownOutside: o, side: s, sideOffset: c, align: l, alignOffset: u, arrowPadding: d, collisionBoundary: f, collisionPadding: p, sticky: m, hideWhenDetached: h, avoidCollisions: g, ..._ } = e, v = Mc(Gc, n), [y, b] = U.useState(null), [x, S] = U.useState(null), C = Z(t, b), [w, T] = U.useState(null), [E, D] = U.useState(null), O = Ec(n), [k, A] = U.useState(!1), j = U.useRef(!1), M = U.useRef(!1), N = U.useRef(!1);
	U.useEffect(() => {
		if (y) return us(y);
	}, [y]), Cr();
	let P = U.useCallback((e) => {
		let [t, ...n] = O().map((e) => e.ref.current), [r] = n.slice(-1), i = document.activeElement;
		for (let n of e) if (n === i || (n?.scrollIntoView({ block: "nearest" }), n === t && x && (x.scrollTop = 0), n === r && x && (x.scrollTop = x.scrollHeight), n?.focus(), document.activeElement !== i)) return;
	}, [O, x]), F = U.useCallback(() => P([w, y]), [
		P,
		w,
		y
	]);
	U.useEffect(() => {
		k && F();
	}, [k, F]);
	let { onOpenChange: I, triggerPointerDownPosRef: L } = v;
	U.useEffect(() => {
		if (y) {
			let e = {
				x: 0,
				y: 0
			}, t = /* @__PURE__ */ Q((t) => {
				e = {
					x: Math.abs(Math.round(t.pageX) - (L.current?.x ?? 0)),
					y: Math.abs(Math.round(t.pageY) - (L.current?.y ?? 0))
				};
			}, "handlePointerMove"), n = /* @__PURE__ */ Q((n) => {
				e.x <= 10 && e.y <= 10 ? n.preventDefault() : n.composedPath().includes(y) || I(!1), document.removeEventListener("pointermove", t), L.current = null;
			}, "handlePointerUp");
			return L.current !== null && (document.addEventListener("pointermove", t), document.addEventListener("pointerup", n, {
				capture: !0,
				once: !0
			})), () => {
				document.removeEventListener("pointermove", t), document.removeEventListener("pointerup", n, { capture: !0 });
			};
		}
	}, [
		y,
		I,
		L
	]), U.useEffect(() => {
		let e = /* @__PURE__ */ Q(() => I(!1), "close");
		return window.addEventListener("blur", e), window.addEventListener("resize", e), () => {
			window.removeEventListener("blur", e), window.removeEventListener("resize", e);
		};
	}, [I]);
	let [R, z] = wl((e) => {
		let t = O().filter((e) => !e.disabled), n = Tl(t, e, t.find((e) => e.ref.current === document.activeElement));
		n && setTimeout(() => n.ref.current?.focus());
	}), B = U.useCallback((e, t, n) => {
		let r = !M.current;
		r && (M.current = !0);
		let i = !j.current && !n;
		v.value !== void 0 && v.value === t || i ? (T(e), i && (j.current = !0)) : r && T(e);
	}, [v.value]), ee = U.useCallback(() => y?.focus(), [y]), V = U.useCallback((e, t, n) => {
		if (!e) return;
		let r = !N.current;
		r && (N.current = !0);
		let i = !j.current && !n;
		(v.value !== void 0 && v.value === t || i || r) && D(e);
	}, [v.value]), H = r === bc.Popper ? el : $c, te = H === el ? {
		side: s,
		sideOffset: c,
		align: l,
		alignOffset: u,
		arrowPadding: d,
		collisionBoundary: f,
		collisionPadding: p,
		sticky: m,
		hideWhenDetached: h,
		avoidCollisions: g
	} : {};
	return /* @__PURE__ */ q(Yc, {
		scope: n,
		content: y,
		viewport: x,
		onViewportChange: S,
		itemRefCallback: B,
		selectedItem: w,
		onItemLeave: ee,
		itemTextRefCallback: V,
		focusSelectedItem: F,
		selectedItemText: E,
		position: r,
		isPositioned: k,
		searchRef: R,
		children: /* @__PURE__ */ q(vc, {
			as: Zc,
			allowPinchZoom: !0,
			children: /* @__PURE__ */ q(Ar, {
				asChild: !0,
				trapped: v.open,
				onMountAutoFocus: (e) => {
					e.preventDefault();
				},
				onUnmountAutoFocus: X(i, (e) => {
					v.trigger?.focus({ preventScroll: !0 }), e.preventDefault();
				}),
				children: /* @__PURE__ */ q(dr, {
					asChild: !0,
					disableOutsidePointerEvents: !0,
					onEscapeKeyDown: a,
					onPointerDownOutside: o,
					onFocusOutside: (e) => e.preventDefault(),
					onDismiss: () => v.onOpenChange(!1),
					children: /* @__PURE__ */ q(H, {
						role: "listbox",
						id: v.contentId,
						"data-state": v.open ? "open" : "closed",
						dir: v.dir,
						onContextMenu: (e) => e.preventDefault(),
						..._,
						...te,
						onPlaced: () => A(!0),
						ref: C,
						style: {
							display: "flex",
							flexDirection: "column",
							outline: "none",
							..._.style
						},
						onKeyDown: X(_.onKeyDown, (e) => {
							let t = e.ctrlKey || e.altKey || e.metaKey;
							if (e.key === "Tab" && e.preventDefault(), !t && e.key.length === 1 && z(e.key), [
								"ArrowUp",
								"ArrowDown",
								"Home",
								"End"
							].includes(e.key)) {
								let t = O().filter((e) => !e.disabled).map((e) => e.ref.current);
								if (["ArrowUp", "End"].includes(e.key) && (t = t.slice().reverse()), ["ArrowUp", "ArrowDown"].includes(e.key)) {
									let n = e.target, r = t.indexOf(n);
									t = t.slice(r + 1);
								}
								setTimeout(() => P(t)), e.preventDefault();
							}
						})
					})
				})
			})
		})
	});
}, "SelectContentImpl")), $c = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, onPlaced: r, ...i } = e, a = Mc(Gc, n), o = Xc(Gc, n), [s, c] = U.useState(null), [l, u] = U.useState(null), d = Z(t, u), f = Ec(n), p = U.useRef(!1), m = U.useRef(!0), { viewport: h, selectedItem: g, selectedItemText: _, focusSelectedItem: v } = o, y = U.useCallback(() => {
		if (a.trigger && a.valueNode && s && l && h && g && _) {
			let e = a.trigger.getBoundingClientRect(), t = l.getBoundingClientRect(), n = a.valueNode.getBoundingClientRect(), i = _.getBoundingClientRect();
			if (a.dir !== xc.RTL) {
				let r = i.left - t.left, a = n.left - r, o = e.left - a, c = e.width + o, l = Math.max(c, t.width), u = window.innerWidth - Jc, d = Yt(a, [Jc, Math.max(Jc, u - l)]);
				s.style.minWidth = c + "px", s.style.left = d + "px";
			} else {
				let r = t.right - i.right, a = window.innerWidth - n.right - r, o = window.innerWidth - e.right - a, c = e.width + o, l = Math.max(c, t.width), u = window.innerWidth - Jc, d = Yt(a, [Jc, Math.max(Jc, u - l)]);
				s.style.minWidth = c + "px", s.style.right = d + "px";
			}
			let o = f(), c = window.innerHeight - Jc * 2, u = h.scrollHeight, d = window.getComputedStyle(l), m = parseInt(d.borderTopWidth, 10), v = parseInt(d.paddingTop, 10), y = parseInt(d.borderBottomWidth, 10), b = parseInt(d.paddingBottom, 10), x = m + v + u + b + y, S = Math.min(g.offsetHeight * 5, x), C = window.getComputedStyle(h), w = parseInt(C.paddingTop, 10), T = parseInt(C.paddingBottom, 10), E = e.top + e.height / 2 - Jc, D = c - E, O = g.offsetHeight / 2, k = g.offsetTop + O, A = m + v + k, j = x - A;
			if (A <= E) {
				let e = o.length > 0 && g === o[o.length - 1].ref.current;
				s.style.bottom = "0px";
				let t = l.clientHeight - h.offsetTop - h.offsetHeight, n = A + Math.max(D, O + (e ? T : 0) + t + y);
				s.style.height = n + "px";
			} else {
				let e = o.length > 0 && g === o[0].ref.current;
				s.style.top = "0px";
				let t = Math.max(E, m + h.offsetTop + (e ? w : 0) + O) + j;
				s.style.height = t + "px", h.scrollTop = A - E + h.offsetTop;
			}
			s.style.margin = `${Jc}px 0`, s.style.minHeight = S + "px", s.style.maxHeight = c + "px", r?.(), requestAnimationFrame(() => p.current = !0);
		}
	}, [
		f,
		a.trigger,
		a.valueNode,
		s,
		l,
		h,
		g,
		_,
		a.dir,
		r
	]);
	An(() => y(), [y]);
	let [b, x] = U.useState();
	An(() => {
		l && x(window.getComputedStyle(l).zIndex);
	}, [l]);
	let S = U.useCallback((e) => {
		e && m.current === !0 && (y(), v?.(), m.current = !1);
	}, [y, v]);
	return /* @__PURE__ */ q(tl, {
		scope: n,
		contentWrapper: s,
		shouldExpandOnScrollRef: p,
		onScrollButtonChange: S,
		children: /* @__PURE__ */ q("div", {
			ref: c,
			style: {
				display: "flex",
				flexDirection: "column",
				position: "fixed",
				zIndex: b
			},
			children: /* @__PURE__ */ q(Qn.div, {
				...i,
				ref: d,
				style: {
					boxSizing: "border-box",
					maxHeight: "100%",
					...i.style
				}
			})
		})
	});
}, "SelectItemAlignedPosition")), el = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, align: r = "start", collisionPadding: i = Jc, ...a } = e, o = Ac(n);
	return /* @__PURE__ */ q(Do, {
		...o,
		...a,
		ref: t,
		align: r,
		collisionPadding: i,
		style: {
			boxSizing: "border-box",
			...a.style,
			"--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-select-content-available-width": "var(--radix-popper-available-width)",
			"--radix-select-content-available-height": "var(--radix-popper-available-height)",
			"--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
}, "SelectPopperPosition")), [tl, nl] = Oc(Gc, {}), rl = "SelectViewport", il = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, nonce: r, ...i } = e, a = Xc(rl, n), o = nl(rl, n), s = Z(t, a.onViewportChange), c = U.useRef(0);
	return /* @__PURE__ */ J(me, { children: [/* @__PURE__ */ q("style", {
		dangerouslySetInnerHTML: { __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}" },
		nonce: r
	}), /* @__PURE__ */ q(Tc.Slot, {
		scope: n,
		children: /* @__PURE__ */ q(Qn.div, {
			"data-radix-select-viewport": "",
			role: "presentation",
			...i,
			ref: s,
			style: {
				position: "relative",
				flex: 1,
				overflow: "hidden auto",
				...i.style
			},
			onScroll: X(i.onScroll, (e) => {
				let t = e.currentTarget, { contentWrapper: n, shouldExpandOnScrollRef: r } = o;
				if (r?.current && n) {
					let e = Math.abs(c.current - t.scrollTop);
					if (e > 0) {
						let r = window.innerHeight - Jc * 2, i = parseFloat(n.style.minHeight), a = parseFloat(n.style.height), o = Math.max(i, a);
						if (o < r) {
							let i = o + e, a = Math.min(r, i), s = i - a;
							n.style.height = a + "px", n.style.bottom === "0px" && (t.scrollTop = s > 0 ? s : 0, n.style.justifyContent = "flex-end");
						}
					}
				}
				c.current = t.scrollTop;
			})
		})
	})] });
}, "SelectViewport")), [al, ol] = Oc("SelectGroup"), sl = "SelectItem", [cl, ll] = Oc(sl), ul = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, value: r, disabled: i = !1, textValue: a, ...o } = e, s = Mc(sl, n), c = Xc(sl, n), l = s.value === r, [u, d] = U.useState(a ?? ""), [f, p] = U.useState(!1), m = Z(t, rr((e) => c.itemRefCallback?.(e, r, i))), h = Xr(), g = U.useRef("touch");
	function _(e) {
		s.hasConsumerStoppedPropagationRef.current = e.isPropagationStopped(), s.onUserSelect(r), s.onOpenChange(!1);
	}
	return Q(_, "handleSelect"), /* @__PURE__ */ q(cl, {
		scope: n,
		value: r,
		disabled: i,
		textId: h,
		isSelected: l,
		onItemTextChange: U.useCallback((e) => {
			d((t) => t || (e?.textContent ?? "").trim());
		}, []),
		children: /* @__PURE__ */ q(Tc.ItemSlot, {
			scope: n,
			value: r,
			disabled: i,
			textValue: u,
			children: /* @__PURE__ */ q(Qn.div, {
				role: "option",
				"aria-labelledby": h,
				"data-highlighted": f ? "" : void 0,
				"aria-selected": l && f,
				"data-state": l ? "checked" : "unchecked",
				"aria-disabled": i || void 0,
				"data-disabled": i ? "" : void 0,
				tabIndex: i ? void 0 : -1,
				...o,
				ref: m,
				onFocus: X(o.onFocus, () => p(!0)),
				onBlur: X(o.onBlur, () => p(!1)),
				onClick: X(o.onClick, (e) => {
					i || g.current !== "mouse" && _(e);
				}),
				onPointerUp: X(o.onPointerUp, (e) => {
					i || g.current === "mouse" && _(e);
				}),
				onPointerDown: X(o.onPointerDown, (e) => {
					g.current = e.pointerType;
				}),
				onPointerMove: X(o.onPointerMove, (e) => {
					g.current = e.pointerType, i ? c.onItemLeave?.() : g.current === "mouse" && e.currentTarget.focus({ preventScroll: !0 });
				}),
				onPointerLeave: X(o.onPointerLeave, (e) => {
					e.currentTarget === document.activeElement && c.onItemLeave?.();
				}),
				onKeyDown: X(o.onKeyDown, (e) => {
					i || e.target !== e.currentTarget || (c.searchRef?.current === "" || e.key !== " ") && (Cc.includes(e.key) && _(e), e.key === " " && e.preventDefault());
				})
			})
		})
	});
}, "SelectItem")), dl = "SelectItemText", fl = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, className: r, style: i, ...a } = e, o = Mc(dl, n), s = Xc(dl, n), c = ll(dl, n), l = Pc(dl, n), [u, d] = U.useState(null), f = rr((e) => s.itemTextRefCallback?.(e, c.value, c.disabled)), p = Z(t, d, c.onItemTextChange, f), m = u?.textContent, h = U.useMemo(() => /* @__PURE__ */ q("option", {
		value: c.value,
		disabled: c.disabled,
		children: m
	}, c.value), [
		c.disabled,
		c.value,
		m
	]), { onNativeOptionAdd: g, onNativeOptionRemove: _ } = l;
	return An(() => (g(h), () => _(h)), [
		g,
		_,
		h
	]), /* @__PURE__ */ J(me, { children: [/* @__PURE__ */ q(Qn.span, {
		id: c.textId,
		...a,
		ref: p
	}), c.isSelected && o.valueNode && !o.valueNodeHasChildren && !Cl(o.value) ? he.createPortal(a.children, o.valueNode) : null] });
}, "SelectItemText")), pl = "SelectItemIndicator", ml = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, ...r } = e;
	return ll(pl, n).isSelected ? /* @__PURE__ */ q(Qn.span, {
		"aria-hidden": !0,
		...r,
		ref: t
	}) : null;
}, "SelectItemIndicator")), hl = "SelectScrollUpButton", gl = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let n = Xc(hl, e.__scopeSelect), r = nl(hl, e.__scopeSelect), [i, a] = U.useState(!1), o = Z(t, r.onScrollButtonChange);
	return An(() => {
		if (n.viewport && n.isPositioned) {
			let e = function() {
				let e = t.scrollTop > 0;
				a(e);
			};
			Q(e, "handleScroll");
			let t = n.viewport;
			return e(), t.addEventListener("scroll", e), () => t.removeEventListener("scroll", e);
		}
	}, [n.viewport, n.isPositioned]), i ? /* @__PURE__ */ q(yl, {
		...e,
		ref: o,
		onAutoScroll: () => {
			let { viewport: e, selectedItem: t } = n;
			e && t && (e.scrollTop -= t.offsetHeight);
		}
	}) : null;
}, "SelectScrollUpButton")), _l = "SelectScrollDownButton", vl = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let n = Xc(_l, e.__scopeSelect), r = nl(_l, e.__scopeSelect), [i, a] = U.useState(!1), o = Z(t, r.onScrollButtonChange);
	return An(() => {
		if (n.viewport && n.isPositioned) {
			let e = function() {
				let e = t.scrollHeight - t.clientHeight, n = Math.ceil(t.scrollTop) < e;
				a(n);
			};
			Q(e, "handleScroll");
			let t = n.viewport;
			return e(), t.addEventListener("scroll", e), () => t.removeEventListener("scroll", e);
		}
	}, [n.viewport, n.isPositioned]), i ? /* @__PURE__ */ q(yl, {
		...e,
		ref: o,
		onAutoScroll: () => {
			let { viewport: e, selectedItem: t } = n;
			e && t && (e.scrollTop += t.offsetHeight);
		}
	}) : null;
}, "SelectScrollDownButton")), yl = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, onAutoScroll: r, ...i } = e, a = Xc("SelectScrollButton", n), o = U.useRef(null), s = Ec(n), c = U.useCallback(() => {
		o.current !== null && (window.clearInterval(o.current), o.current = null);
	}, []);
	return U.useEffect(() => () => c(), [c]), An(() => {
		s().find((e) => e.ref.current === document.activeElement)?.ref.current?.scrollIntoView({ block: "nearest" });
	}, [s]), /* @__PURE__ */ q(Qn.div, {
		"aria-hidden": !0,
		...i,
		ref: t,
		style: {
			flexShrink: 0,
			...i.style
		},
		onPointerDown: X(i.onPointerDown, () => {
			o.current === null && (o.current = window.setInterval(r, 50));
		}),
		onPointerMove: X(i.onPointerMove, () => {
			a.onItemLeave?.(), o.current === null && (o.current = window.setInterval(r, 50));
		}),
		onPointerLeave: X(i.onPointerLeave, () => {
			c();
		})
	});
}, "SelectScrollButtonImpl")), bl = "SelectBubbleInput", xl = /* @__PURE__ */ U.forwardRef(/* @__PURE__ */ Q(function({ __scopeSelect: e, ...t }, n) {
	let r = Mc(bl, e), { value: i, onValueChange: a, required: o, disabled: s, name: c, autoComplete: l, form: u, userSelection: d } = r, { nativeOptions: f, nativeSelectKey: p } = r, m = U.useRef(null), h = Z(n, m), g = i ?? "", _ = U.useRef(g), v = U.useRef(d), y = U.useRef(!1), b = Array.from(f).some((e) => (e.props.value ?? "") === "");
	return U.useEffect(() => {
		let e = m.current;
		if (!e) return;
		let t = window.HTMLSelectElement.prototype, n = Object.getOwnPropertyDescriptor(t, "value").set, r = d !== null && d !== v.current;
		v.current = d;
		let i = _.current !== g;
		_.current = g;
		let a = r && i;
		if (r && !i && d.value !== g && !d.hasConsumerStoppedPropagation && n) {
			y.current = !0;
			try {
				n.call(e, d.value), e.dispatchEvent(new Event("change", { bubbles: !0 }));
			} finally {
				y.current = !1, n.call(e, g);
			}
			return;
		}
		let o = a && !d.hasConsumerStoppedPropagation;
		if (i && n) {
			let t = new Event("change", { bubbles: o });
			n.call(e, g), e.dispatchEvent(t);
		}
	}, [g, d]), /* @__PURE__ */ J(Qn.select, {
		"aria-hidden": !0,
		required: o,
		tabIndex: -1,
		name: c,
		autoComplete: l,
		disabled: s,
		form: u,
		onChange: (e) => {
			y.current || a(e.target.value);
		},
		...t,
		style: {
			...ts,
			...t.style
		},
		ref: h,
		defaultValue: g,
		children: [Cl(i) && !b ? /* @__PURE__ */ q("option", { value: "" }) : null, Array.from(f)]
	}, p);
}, "SelectBubbleInput"));
function Sl(e) {
	return typeof e == "function";
}
Q(Sl, "isFunction");
function Cl(e) {
	return e === "" || e === void 0;
}
Q(Cl, "shouldShowPlaceholder");
function wl(e) {
	let t = rr(e), n = U.useRef(""), r = U.useRef(0), i = U.useCallback((e) => {
		let i = n.current + e;
		t(i);
		function a(e) {
			n.current = e, window.clearTimeout(r.current), e !== "" && (r.current = window.setTimeout(() => a(""), 1e3));
		}
		Q(a, "updateSearch"), a(i);
	}, [t]), a = U.useCallback(() => {
		n.current = "", window.clearTimeout(r.current);
	}, []);
	return U.useEffect(() => () => window.clearTimeout(r.current), []), [
		n,
		i,
		a
	];
}
Q(wl, "useTypeaheadSearch");
function Tl(e, t, n) {
	let r = t.length > 1 && Array.from(t).every((e) => e === t[0]) ? t[0] : t, i = n ? e.indexOf(n) : -1, a = El(e, Math.max(i, 0));
	r.length === 1 && (a = a.filter((e) => e !== n));
	let o = a.find((e) => e.textValue.toLowerCase().startsWith(r.toLowerCase()));
	return o === n ? void 0 : o;
}
Q(Tl, "findNextItem");
function El(e, t) {
	return e.map((n, r) => e[(t + r) % e.length]);
}
Q(El, "wrapArray");
var Dl = {
	field: "_field_19mpc_8",
	trigger: "_trigger_19mpc_11",
	valueText: "_valueText_19mpc_16",
	srOnly: "_srOnly_19mpc_19",
	chevron: "_chevron_19mpc_20",
	hint: "_hint_19mpc_22",
	content: "_content_19mpc_24",
	"select-in": "_select-in_19mpc_1",
	"select-out": "_select-out_19mpc_1",
	viewport: "_viewport_19mpc_29",
	item: "_item_19mpc_30",
	itemLabel: "_itemLabel_19mpc_34",
	indicator: "_indicator_19mpc_36",
	"indicator-in": "_indicator-in_19mpc_1",
	scrollButton: "_scrollButton_19mpc_37",
	"select-fade": "_select-fade_19mpc_1",
	"select-fade-out": "_select-fade-out_19mpc_1"
}, Ol = {
	enter: (e) => ({
		opacity: 0,
		y: `${e * .35}em`,
		filter: `blur(${tt.blur.soft}px)`
	}),
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: {
			duration: tt.duration.standard,
			ease: [...tt.ease.enter]
		}
	},
	exit: (e) => ({
		opacity: 0,
		y: `${e * -.3}em`,
		filter: `blur(${tt.blur.subtle}px)`,
		transition: {
			duration: tt.duration.fast,
			ease: [...tt.ease.standard]
		}
	})
}, kl = {
	enter: { opacity: 0 },
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: { duration: tt.duration.instant }
	},
	exit: {
		opacity: 0,
		transition: { duration: tt.duration.instant }
	}
}, Al = ie(function({ label: e, description: t, placeholder: n = "Select an option", options: r, id: i, className: a, disabled: o, invalid: s, describedBy: c, portalContainer: l, onValueChange: u, open: d, defaultOpen: f, onOpenChange: m, ...g }, _) {
	let v = le(), y = i ?? v, b = t ? `${y}-description` : void 0, x = [b, c].filter(Boolean).join(" ") || void 0, [S, C] = K(null), w = l ?? S?.closest(".local-select") ?? S?.closest("[data-rmd-theme]") ?? void 0, T = p(), [E, D] = K(g.defaultValue ?? ""), O = g.value ?? E, [k, A] = K(f ?? !1), j = G(O);
	ce(() => {
		(o || j.current !== O) && A(!1), j.current = O;
	}, [O, o]);
	let M = r.findIndex((e) => e.value === O), N = O ? r[M]?.label ?? "" : n, [P, F] = K(M), [I, L] = K(1);
	return P !== M && (F(M), L(M > P ? 1 : -1)), /* @__PURE__ */ J("div", {
		className: Dl.field,
		ref: C,
		"data-rmd-component": "select",
		"data-rmd-part": "field",
		children: [
			/* @__PURE__ */ q("label", {
				htmlFor: y,
				"data-rmd-part": "label",
				children: e
			}),
			/* @__PURE__ */ J(Ic, {
				...g,
				disabled: o,
				open: !o && (d ?? k),
				onOpenChange: (e) => {
					A(e), m?.(e);
				},
				onValueChange: (e) => {
					D(e), u?.(e);
				},
				children: [/* @__PURE__ */ J(Rc, {
					ref: _,
					id: y,
					"aria-describedby": x,
					"aria-invalid": s || void 0,
					"data-rmd-part": "trigger",
					className: [Dl.trigger, a].filter(Boolean).join(" "),
					children: [
						/* @__PURE__ */ q("span", {
							className: Dl.srOnly,
							children: /* @__PURE__ */ q(Bc, {
								placeholder: n,
								children: O ? N : void 0
							})
						}),
						/* @__PURE__ */ q("span", {
							className: Dl.valueText,
							"data-rmd-part": "value",
							"aria-hidden": "true",
							children: /* @__PURE__ */ q(De, {
								initial: !1,
								custom: I,
								children: /* @__PURE__ */ q(h.span, {
									"data-placeholder": O ? void 0 : "",
									custom: I,
									variants: T ? kl : Ol,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: N
								}, O ? `value-${O}` : "placeholder")
							})
						}),
						/* @__PURE__ */ q(Vc, {
							className: Dl.chevron,
							"data-rmd-part": "chevron",
							children: /* @__PURE__ */ q(Je, {
								size: 16,
								strokeWidth: 1.75,
								"aria-hidden": "true"
							})
						})
					]
				}), /* @__PURE__ */ q(Wc, {
					container: w,
					children: /* @__PURE__ */ J(Kc, {
						className: Dl.content,
						"data-rmd-part": "menu",
						position: "popper",
						sideOffset: 4,
						collisionPadding: 12,
						children: [
							/* @__PURE__ */ q(gl, {
								className: Dl.scrollButton,
								"data-rmd-part": "scroll-up",
								children: /* @__PURE__ */ q(et, {
									size: 16,
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ q(il, {
								className: Dl.viewport,
								"data-rmd-part": "viewport",
								children: r.map((e) => /* @__PURE__ */ J(ul, {
									value: e.value,
									disabled: e.disabled,
									className: Dl.item,
									"data-rmd-part": "item",
									children: [/* @__PURE__ */ q(fl, { children: /* @__PURE__ */ q("span", {
										className: Dl.itemLabel,
										children: e.label
									}) }), /* @__PURE__ */ q(ml, {
										className: Dl.indicator,
										"data-rmd-part": "indicator",
										children: /* @__PURE__ */ q(Ke, {
											size: 16,
											strokeWidth: 1.75,
											"aria-hidden": "true"
										})
									})]
								}, e.value))
							}),
							/* @__PURE__ */ q(vl, {
								className: Dl.scrollButton,
								"data-rmd-part": "scroll-down",
								children: /* @__PURE__ */ q(Je, {
									size: 16,
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							})
						]
					})
				})]
			}),
			t && /* @__PURE__ */ q("span", {
				id: b,
				className: Dl.hint,
				"data-rmd-part": "hint",
				children: t
			})
		]
	});
});
// src/react/field-validation.ts
function jl(r, i, a) {
	if (i.required && r.length === 0) return a("This field is required", "请填写此字段");
	if (r.length > 1e5) return a(`At most ${t} characters`, `最多允许 ${t} 个字符`);
	if (i.email && r !== "" && !e(r)) return a("Enter a valid email address", "请输入有效的邮箱地址");
	let o = n(r);
	return i.minLength !== void 0 && i.minLength > 0 && r !== "" && o < i.minLength ? a(`At least ${i.minLength} characters`, `至少需要 ${i.minLength} 个字符`) : i.maxLength !== void 0 && i.maxLength >= 0 && o > i.maxLength ? a(`At most ${i.maxLength} characters`, `最多允许 ${i.maxLength} 个字符`) : null;
}
// src/react/use-draft-field.ts
function Ml(e, t) {
	let n = G(t);
	de(() => {
		n.current = t;
	});
	let { runtime: r, mode: i, content: a } = e, o = a.attrs.bind;
	de(() => {
		if (i !== "static" && o !== void 0) return r.registerSubmissionField?.(a, (e) => n.current(e));
	}, [
		r.identity,
		a.id,
		o,
		i
	]);
}
function Nl(e, t, n) {
	let [r, i] = K(t), [a, o] = K(!1), [s, c] = K(!1), [l, u] = K(null), d = G(!1), f = G(void 0), p = G(t), m = G(t);
	return m.current = t, ce(() => {
		p.current !== t && (p.current = t, !a && !d.current && (f.current = void 0, i(t)));
	}, [t, a]), S(e, () => {
		d.current = !1, f.current = void 0, i(m.current), c(!1), u(null), n(null);
	}), {
		draft: r,
		focused: a,
		touched: s,
		draftError: l,
		composing: d,
		pendingDraft: f,
		setDraft(e) {
			f.current = e, i(e);
		},
		setFocused: o,
		setTouched: c,
		setDraftError: u
	};
}
var $ = {
	root: "_root_15jrj_11",
	header: "_header_15jrj_12",
	label: "_label_15jrj_13",
	readout: "_readout_15jrj_14",
	dash: "_dash_15jrj_15",
	body: "_body_15jrj_17",
	start: "_start_15jrj_18",
	end: "_end_15jrj_19",
	control: "_control_15jrj_23",
	track: "_track_15jrj_24",
	fill: "_fill_15jrj_26",
	tick: "_tick_15jrj_27",
	thumbs: "_thumbs_15jrj_29",
	thumbLayer: "_thumbLayer_15jrj_31",
	thumb: "_thumb_15jrj_29",
	bubbleAnchor: "_bubbleAnchor_15jrj_50",
	bubble: "_bubble_15jrj_50",
	marks: "_marks_15jrj_54",
	markLabel: "_markLabel_15jrj_55",
	number: "_number_15jrj_62"
}, { spring: Pl, duration: Fl, blur: Il } = tt, Ll = [...tt.ease.enter], Rl = [...tt.ease.standard], zl = ({ visualDuration: e, bounce: t }) => {
	let n = 2 * Math.PI / (e * 1.2);
	return {
		type: "spring",
		stiffness: n * n,
		damping: 2 * (1 - t) * n,
		restDelta: .002,
		restSpeed: .02
	};
}, Bl = zl(Pl.snappy), Vl = zl(Pl.morph), Hl = 9, Ul = 150, Wl = 12, Gl = (e, t = Hl) => Math.sign(e) * (1 - 1 / (Math.abs(e) * .55 / t + 1)) * t, Kl = (e) => e * .099, ql = (e, t) => `inset(0 ${(100 - t).toFixed(3)}% 0 ${e.toFixed(3)}% round var(--rmd-slider-track-radius))`, Jl = (e) => (String(e).split(".")[1] ?? "").length, Yl = (e, t, n) => Math.min(n, Math.max(t, e)), Xl = {
	opacity: 0,
	scale: .6,
	y: 6,
	filter: `blur(${Il.subtle}px)`
}, Zl = {
	opacity: 1,
	scale: 1,
	y: 0,
	filter: "blur(0px)",
	transitionEnd: { filter: "none" }
}, Ql = {
	opacity: 0,
	scale: .8,
	y: 4,
	filter: `blur(${Il.subtle}px)`,
	transition: {
		duration: Fl.instant,
		ease: Rl
	}
}, $l = {
	...Pl.snappy,
	opacity: {
		duration: Fl.fast,
		ease: Ll
	},
	filter: {
		duration: Fl.fast,
		ease: Ll
	}
};
function eu({ quiet: e, index: t, shown: n, value: r, text: i, low: a, high: o, ariaLabel: s, labelledBy: l, describedBy: u, invalid: d, active: f, lifted: m, bubble: g, disabled: _, onKeyDown: v, onFocus: y, onBlur: b }) {
	let x = p(), S = c(n, (e) => `${e - 100}%`);
	return /* @__PURE__ */ J(h.div, {
		className: $.thumbLayer,
		"data-rmd-part": "thumb-layer",
		style: {
			x: S,
			zIndex: f ? 2 : 1,
			"--at": n
		},
		children: [/* @__PURE__ */ q(h.div, {
			role: "slider",
			"data-rmd-part": "thumb",
			"data-thumb": "",
			"data-index": t,
			"data-active": m || void 0,
			"data-quiet": e || void 0,
			className: $.thumb,
			tabIndex: _ ? -1 : 0,
			"aria-label": s,
			"aria-labelledby": s ? void 0 : l,
			"aria-valuemin": a,
			"aria-valuemax": o,
			"aria-valuenow": r,
			"aria-valuetext": i,
			"aria-orientation": "horizontal",
			"aria-disabled": _ || void 0,
			"aria-describedby": u,
			"aria-invalid": d || void 0,
			initial: !1,
			animate: { scale: m ? 1.16 : 1 },
			transition: x ? { duration: 0 } : Pl.snappy,
			onKeyDown: v,
			onFocus: y,
			onBlur: b
		}), /* @__PURE__ */ q(h.span, {
			className: $.bubbleAnchor,
			"data-rmd-part": "bubble-anchor",
			children: /* @__PURE__ */ q(De, { children: g && /* @__PURE__ */ q(h.span, {
				className: $.bubble,
				"data-rmd-part": "bubble",
				"aria-hidden": "true",
				initial: x ? { opacity: 0 } : Xl,
				animate: Zl,
				exit: x ? {
					opacity: 0,
					transition: { duration: Fl.instant }
				} : Ql,
				transition: x ? { duration: Fl.instant } : $l,
				children: /* @__PURE__ */ q("span", {
					className: $.number,
					children: i
				})
			}, "bubble") })
		})]
	});
}
function tu({ label: e, value: t, defaultValue: n, onValueChange: r, onValueCommit: a, min: o = 0, max: s = 100, step: l = 1, largeStep: d, marks: f, minStepsBetweenThumbs: m = 0, format: g, showValue: _ = !0, thumbLabels: v, start: y, end: b, readout: x, invalid: S, describedBy: C, resetSignal: w, name: T, disabled: E, className: D }) {
	let O = p(), k = le(), A = l > 0 ? l : 1, j = s - o || 1, M = Array.isArray(t ?? n), N = (e) => e === void 0 ? [o, s].slice(0, M ? 2 : 1) : Array.isArray(e) ? [e[0], e[1]] : [e], [P, F] = K(() => N(n)), I = t === void 0 ? P : N(t), L = Math.max(Jl(A), Jl(o)), R = g ?? ((e) => e.toLocaleString("en-US", {
		minimumFractionDigits: L,
		maximumFractionDigits: L
	})), z = M ? m * A : 0, B = (e) => (e - o) / j * 100, ee = (e) => o + e / 100 * j, V = (e) => Number((o + Math.round((e - o) / A) * A).toFixed(L)), H = (e, t) => e === 1 ? t[0] + z : o, te = (e, t) => e === 0 && M ? t[1] - z : s, U = (e, t, n) => Yl(V(Yl(t, o, s)), H(e, n), te(e, n)), ne = G(null), re = G(null), W = G(I), ie = G(I.map(B)), ae = G(null), oe = G(!1), se = G(void 0), [ue, fe] = K(null), [pe, he] = K(null), [ge, _e] = K(null), [ve, ye] = K(+!!M), [be, xe] = K(null), Se = i(B(I[0])), Ce = i(B(I[1] ?? I[0])), we = i(0), Te = i(0), Ee = c(() => Se.get() + we.get()), De = c(() => Ce.get() + Te.get()), Oe = c(() => ql(M ? Yl(Ee.get(), 0, 100) : 0, Yl((M ? De : Ee).get(), 0, 100))), ke = [{
		pos: Se,
		lag: we,
		shown: Ee
	}, {
		pos: Ce,
		lag: Te,
		shown: De
	}], Ae = (e) => M ? [e[0], e[1]] : e[0];
	function je(e, n) {
		let i = W.current;
		if (i[e] === n) return;
		let a = i.map((t, r) => r === e ? n : t);
		W.current = a, t === void 0 && F(a), r?.(Ae(a));
	}
	de(() => {
		W.current = I, I.forEach((e, t) => {
			let n = B(e), r = ke[t];
			if (ae.current?.index === t || ie.current[t] === n) return;
			ie.current[t] = n;
			let i = r.pos.get() + r.lag.get();
			r.lag.jump(0), r.pos.jump(i), O ? r.pos.jump(n) : u(r.pos, n, Bl);
		});
	}), ce(() => () => window.clearTimeout(se.current), []), ce(() => {
		E && (ae.current = null, fe(null), _e(null), he(null), xe(null), window.clearTimeout(se.current));
	}, [E]), ce(() => {
		ae.current = null, fe(null), _e(null), he(null), xe(null), window.clearTimeout(se.current);
	}, [w]);
	let Me = (e) => re.current?.querySelector(`[data-index="${e}"]`);
	function Ne(e) {
		let t = Me(e);
		t && document.activeElement !== t && (xe(e), oe.current = !0, t.focus({ preventScroll: !0 }), oe.current = !1);
	}
	let Pe = () => ne.current?.getBoundingClientRect().width || 1;
	function Fe(e, t) {
		if (!M) return 0;
		let n = Math.abs(e - B(t[0])), r = Math.abs(e - B(t[1]));
		return n === r ? e < B(t[0]) ? 0 : 1 : n < r ? 0 : 1;
	}
	function Ie(e) {
		window.clearTimeout(se.current), _e(e), se.current = window.setTimeout(() => _e(null), 700);
	}
	function Le(e, t, n, r) {
		let i = ke[t], a = i.pos.get() + i.lag.get();
		e.index = t, e.grab = r ? 0 : n - a, e.raw = a, i.lag.jump(0), i.pos.jump(a), fe(t), ye(t), window.clearTimeout(se.current), _e(null), Ne(t), r && Re(e, n, 0, !0);
	}
	function Re(e, t, n, r = !1) {
		let i = e.index;
		if (i === null) return;
		let a = ke[i], o = W.current, s = Pe(), c = t - e.grab, l = Yl(c, B(H(i, o)), B(te(i, o))), d = O ? l : l + Gl((c - l) / 100 * s) / s * 100;
		if (r && !O) {
			let e = a.pos.get();
			a.pos.jump(d), a.lag.jump(e - d), u(a.lag, 0, Bl);
		} else a.pos.set(d);
		e.raw = c, e.samples.push({
			t: n,
			p: d
		}), e.samples.length > 6 && e.samples.shift(), je(i, U(i, ee(c), o));
	}
	function ze(e) {
		if (E || e.button !== 0 || !e.isPrimary) return;
		let t = ne.current?.getBoundingClientRect();
		if (!t) return;
		let n = (e.clientX - t.left) / (t.width || 1) * 100, r = e.target.closest("[data-thumb]"), i = W.current;
		try {
			e.currentTarget.setPointerCapture(e.pointerId);
		} catch {}
		let a = {
			pointer: e.pointerId,
			index: null,
			grab: 0,
			x: e.clientX,
			raw: n,
			samples: []
		};
		ae.current = a, r && M && i[0] === i[1] ? Ne(Number(r.dataset.index)) : (Le(a, r ? Number(r.dataset.index) : Fe(n, i), n, !r), a.samples = [{
			t: e.timeStamp,
			p: ke[a.index ?? 0].pos.get()
		}]);
	}
	function Be(e) {
		let t = ae.current;
		if (!t || t.pointer !== e.pointerId) return;
		if (E) {
			ae.current = null, fe(null);
			return;
		}
		let n = ne.current?.getBoundingClientRect();
		if (!n) return;
		let r = (e.clientX - n.left) / (n.width || 1) * 100;
		if (t.index === null) {
			let i = e.clientX - t.x;
			if (Math.abs(i) < 2) return;
			Le(t, i < 0 ? 0 : 1, r - i / (n.width || 1) * 100, !1);
		}
		Re(t, r, e.timeStamp);
	}
	function Ve(e) {
		let t = ae.current;
		if (!t || t.pointer !== e.pointerId) return;
		if (ae.current = null, E) {
			fe(null);
			return;
		}
		let n = t.index;
		if (n === null) return;
		let r = ke[n], i = W.current, o = Pe(), s = t.samples, c = s[0], l = s[s.length - 1], d = l && c ? (l.t - c.t) / 1e3 : 0, f = (l && c && d > .008 && e.timeStamp - l.t < 60 ? (l.p - c.p) / d : 0) + r.lag.getVelocity(), p = A / j * 100, m = e.type === "pointerup" && p / 100 * o >= Wl ? Yl(Kl(f), -p, p) : 0, h = U(n, ee(t.raw + m), i), g = r.pos.get() + r.lag.get(), _ = B(h);
		r.lag.jump(0), r.pos.jump(g), ie.current[n] = _, O ? r.pos.jump(_) : u(r.pos, _, {
			...Bl,
			velocity: f
		}), je(n, h), fe(null), e.type === "pointerup" && Ie(n), a?.(Ae(W.current));
	}
	function He(e, t) {
		if (E) return;
		let n = W.current, r = n[e], i = d ?? Math.max(A, V(o + j / 10) - o), s = {
			ArrowRight: A,
			ArrowUp: A,
			ArrowLeft: -A,
			ArrowDown: -A,
			PageUp: i,
			PageDown: -i
		}, c;
		if (t.key === "Home") c = H(e, n);
		else if (t.key === "End") c = te(e, n);
		else if (t.key in s) c = r + (t.shiftKey && /^Arrow/.test(t.key) ? Math.sign(s[t.key]) * i : s[t.key]);
		else return;
		t.preventDefault(), he(e), xe(null), ye(e);
		let l = U(e, c, n);
		if (l === r) {
			let t = Math.sign(c - r);
			t && !O && u(ke[e].pos, ie.current[e], {
				...Vl,
				velocity: t * Ul / Pe() * 100
			});
		} else je(e, l), a?.(Ae(W.current));
	}
	function Ue(e) {
		if (E) return;
		let t = W.current, n = Fe(B(e), t), r = U(n, e, t);
		ye(n), Ne(n), r !== t[n] && (je(n, r), a?.(Ae(W.current)));
	}
	let We = (f ?? []).map((e) => typeof e == "number" ? { value: e } : e).filter((e) => e.value >= o && e.value <= s), Ge = We.filter((e) => e.value > o && e.value < s), Ke = We.filter((e) => e.label), qe = (e) => M ? e >= I[0] && e <= I[1] : e <= I[0], Je = v ?? [`${e}, minimum`, `${e}, maximum`];
	return /* @__PURE__ */ J("div", {
		className: [$.root, D].filter(Boolean).join(" "),
		"data-rmd-component": "slider",
		"data-rmd-part": "root",
		"data-rmd-slider": "arc",
		"data-disabled": E || void 0,
		"data-dragging": ue !== null || void 0,
		"data-invalid": S || void 0,
		"data-marks": Ke.length > 0 || void 0,
		children: [
			/* @__PURE__ */ J("div", {
				className: $.header,
				"data-rmd-part": "header",
				children: [/* @__PURE__ */ q("span", {
					id: k,
					className: $.label,
					"data-rmd-part": "label",
					children: e
				}), (x !== void 0 || _) && /* @__PURE__ */ q("span", {
					className: $.readout,
					"data-rmd-part": "readout",
					"aria-hidden": "true",
					children: x ?? /* @__PURE__ */ J(me, { children: [/* @__PURE__ */ q("span", {
						className: $.number,
						children: R(I[0])
					}), M && /* @__PURE__ */ J(me, { children: [/* @__PURE__ */ q("span", {
						className: $.dash,
						children: "–"
					}), /* @__PURE__ */ q("span", {
						className: $.number,
						children: R(I[1])
					})] })] })
				})]
			}),
			/* @__PURE__ */ J("div", {
				className: $.body,
				children: [
					y && /* @__PURE__ */ q("div", {
						className: $.start,
						"data-rmd-part": "start",
						children: y
					}),
					/* @__PURE__ */ J("div", {
						className: $.control,
						"data-rmd-part": "control",
						onPointerDown: ze,
						onPointerMove: Be,
						onPointerUp: Ve,
						onPointerCancel: Ve,
						onLostPointerCapture: Ve,
						onMouseDown: (e) => e.preventDefault(),
						children: [/* @__PURE__ */ J("div", {
							ref: ne,
							className: $.track,
							"data-rmd-part": "track",
							children: [Ge.map((e) => /* @__PURE__ */ q("span", {
								className: $.tick,
								"data-rmd-part": "tick",
								style: { left: `${B(e.value)}%` }
							}, e.value)), /* @__PURE__ */ q(h.div, {
								className: $.fill,
								"data-rmd-part": "fill",
								style: { clipPath: Oe },
								children: Ge.map((e) => /* @__PURE__ */ q("span", {
									className: $.tick,
									"data-rmd-part": "tick",
									style: { left: `${B(e.value)}%` }
								}, e.value))
							})]
						}), /* @__PURE__ */ q("div", {
							ref: re,
							className: $.thumbs,
							"data-rmd-part": "thumbs",
							children: I.map((e, t) => /* @__PURE__ */ q(eu, {
								quiet: be === t,
								index: t,
								shown: ke[t].shown,
								value: e,
								text: R(e),
								low: H(t, I),
								high: te(t, I),
								ariaLabel: M ? Je[t] : void 0,
								labelledBy: k,
								describedBy: C,
								invalid: S,
								active: ve === t,
								lifted: ue === t,
								bubble: ue === t || pe === t || ge === t,
								disabled: E,
								onKeyDown: (e) => He(t, e),
								onFocus: (e) => {
									!oe.current && e.currentTarget.matches(":focus-visible") && he(t);
								},
								onBlur: () => {
									he((e) => e === t ? null : e), xe((e) => e === t ? null : e);
								}
							}, t))
						})]
					}),
					b && /* @__PURE__ */ q("div", {
						className: $.end,
						"data-rmd-part": "end",
						children: b
					}),
					Ke.length > 0 && /* @__PURE__ */ q("div", {
						className: $.marks,
						"data-rmd-part": "marks",
						"aria-hidden": "true",
						children: Ke.map((e) => /* @__PURE__ */ q("span", {
							className: $.markLabel,
							"data-rmd-part": "mark",
							"data-on": qe(e.value) || void 0,
							"data-edge": e.value === o ? "start" : e.value === s ? "end" : void 0,
							style: { left: `${B(e.value)}%` },
							onClick: () => Ue(e.value),
							children: e.label
						}, e.value))
					})
				]
			}),
			T && I.map((e, t) => /* @__PURE__ */ q("input", {
				type: "hidden",
				name: T,
				value: e,
				disabled: E
			}, t))
		]
	});
}
// src/components/controls/numeric-sliders.tsx
function nu(e) {
	return String(Number(e.toFixed(12)));
}
function ru({ value: e }) {
	return /* @__PURE__ */ q("span", {
		className: "md-slider-value",
		"aria-hidden": "true",
		children: e
	});
}
function iu(e) {
	let t = _(e), n = le(), r = C(e), { content: i, mode: a, t: o } = t, { write: s, error: c } = x(e), l = w(e, "label", o("Slider", "滑块")), { disabled: u, invalid: d } = N(e), f = T(e), p = te(e, "min"), m = te(e, "max"), h = p.present && !p.error ? p.value : 0, g = m.present && !m.error ? m.value : 100, v = p.error || m.error, y = V(e, "step", 1), b = P(e), S = typeof b == "number" && Number.isFinite(b) ? b : h, E = Math.min(g, Math.max(h, S)), D = typeof b == "number" && Number.isFinite(b) ? b < h ? o(`Must be at least ${h}`, `不能小于 ${h}`) : b > g ? o(`Must be at most ${g}`, `不能大于 ${g}`) : null : null, k = !!(f.invalid || D || v);
	return a === "static" ? /* @__PURE__ */ q(M, {
		className: "md-slider local-slider",
		label: l,
		value: String(S)
	}) : /* @__PURE__ */ J("div", {
		className: "md-control md-slider local-slider",
		style: L(O(i)),
		...r,
		"data-rmd-part": "control",
		"aria-invalid": k || void 0,
		"aria-describedby": f.describedBy,
		children: [
			/* @__PURE__ */ q(tu, {
				label: l,
				value: E,
				min: h,
				max: g,
				step: y,
				disabled: u,
				className: "local-slider-arc",
				readout: /* @__PURE__ */ q(ru, { value: String(S) }),
				format: nu,
				invalid: k,
				describedBy: f.describedBy,
				resetSignal: t.resetToken,
				onValueChange: (e) => {
					s(e);
				}
			}),
			/* @__PURE__ */ q("input", {
				id: `${n}-slider`,
				type: "range",
				min: h,
				max: g,
				step: y,
				value: E,
				disabled: u,
				tabIndex: -1,
				"aria-hidden": "true",
				"data-rmd-native-proxy": "",
				style: { display: "none" },
				onChange: () => {}
			}),
			/* @__PURE__ */ q(z, { value: String(S) }),
			/* @__PURE__ */ q(B, { message: d || v ? o("Cannot compute", "无法计算") : c ?? D })
		]
	});
}
function au(e) {
	let t = _(e), { content: n, mode: r, t: i } = t, { writeMany: a, error: o, setError: s } = x(e), c = w(e, "label", i("Range", "范围")), { disabled: l, invalid: u } = N(e), d = T(e), { min: f, max: p, step: m } = k(e, "min", "max", 0, 100, 1), h = Math.floor((p - f) / m + 1e-9), g = f, v = A(f + Math.max(0, h) * m, f, p), y = b(D(e, "start", g), f, p, m), C = b(D(e, "end", v), f, p, m);
	y > C && (y = C), S(e, () => {
		s(null);
	});
	let E = i("Start", "起点"), j = i("End", "终点"), P = `${E}: ${y} · ${j}: ${C}`, F = p - f, I = F > 0 ? (y - f) / F * 100 : 0, R = F > 0 ? (C - f) / F * 100 : 100;
	return r === "static" ? /* @__PURE__ */ q(M, {
		className: "local-range-slider",
		label: c,
		value: P
	}) : /* @__PURE__ */ J("div", {
		className: "md-control local-range-slider",
		style: {
			...L(O(n)) ?? {},
			"--local-range-start": I,
			"--local-range-end": R
		},
		"data-rmd-part": "control",
		role: "group",
		"aria-label": c,
		"aria-invalid": d.invalid || void 0,
		"aria-describedby": d.describedBy,
		children: [
			/* @__PURE__ */ q(tu, {
				label: c,
				value: [y, C],
				min: f,
				max: p,
				step: m,
				disabled: l,
				className: "local-slider-arc",
				thumbLabels: [`${c} ${E}`, `${c} ${j}`],
				readout: /* @__PURE__ */ q(ru, { value: `${y} – ${C}` }),
				format: nu,
				invalid: d.invalid,
				describedBy: d.describedBy,
				resetSignal: t.resetToken,
				onValueChange: (e) => {
					let [t, n] = e;
					(t !== y || n !== C) && a({
						start: t,
						end: n
					});
				}
			}),
			/* @__PURE__ */ q("input", {
				type: "range",
				className: "local-range-input local-range-input-start",
				min: f,
				max: p,
				step: m,
				value: y,
				disabled: l,
				"aria-label": `${c} ${E}`,
				tabIndex: -1,
				"aria-hidden": "true",
				"data-rmd-native-proxy": "",
				style: { display: "none" },
				onChange: () => {}
			}),
			/* @__PURE__ */ q("input", {
				type: "range",
				className: "local-range-input local-range-input-end",
				min: f,
				max: p,
				step: m,
				value: C,
				disabled: l,
				"aria-label": `${c} ${j}`,
				tabIndex: -1,
				"aria-hidden": "true",
				"data-rmd-native-proxy": "",
				style: { display: "none" },
				onChange: () => {}
			}),
			/* @__PURE__ */ q(z, { value: P }),
			/* @__PURE__ */ q(B, { message: u ? i("Cannot compute", "无法计算") : o })
		]
	});
}
// src/components/controls/controls.tsx
function ou(e, t) {
	if (e.content.attrs[t] !== void 0) return Math.max(0, Math.floor(V(e, t, 0)));
}
function su(e) {
	let t = _(e), n = w(e, "label", t.content.name || t.t("Input", "输入")), r = (E(t.content, "type") ?? "text") === "email";
	return /* @__PURE__ */ q(lu, {
		context: e,
		label: n,
		email: r
	});
}
function cu(e) {
	let t = _(e), n = w(e, "label", t.t("Text", "文本")), r = Math.min(40, Math.max(1, Math.floor(V(e, "rows", 4))));
	return /* @__PURE__ */ q(lu, {
		context: e,
		label: n,
		multiline: !0,
		rows: r
	});
}
function lu({ context: e, label: t, email: n = !1, multiline: r = !1, rows: i }) {
	let a = _(e), o = le(), s = C(e), { content: c, mode: l, t: u } = a, { write: d, error: f, setError: p } = x(e), m = w(e, "placeholder", ""), h = v(e, "required", !1), g = h.ok ? h.value : !1, b = (E(c, "required") ?? "").includes("{{"), { disabled: S, invalid: D } = N(e), O = T(e), k = ou(e, "min-length"), A = ou(e, "max-length"), F = j(P(e)), I = r ? "local-textarea" : `local-input${n ? " local-input-email" : ""}`, { draft: L, setDraft: R, setFocused: ee, touched: V, setTouched: H, draftError: te, setDraftError: U, composing: ne, pendingDraft: re } = Nl(e, F, p), W = (e) => jl(e, {
		required: g,
		minLength: k,
		maxLength: A,
		email: n
	}, u);
	if (Ml(e, (e) => {
		if (ne.current) return "invalid";
		let t = j(e), n = re.current ?? t;
		if (g && n === "") return "required";
		if (n !== t) return "invalid";
	}), l === "static") return /* @__PURE__ */ q(M, {
		className: I,
		label: t,
		value: y(F),
		multiline: r
	});
	let ie = (e) => {
		d(e) && (re.current = void 0);
	}, ae = {
		id: `${o}-${r ? "textarea" : "input"}`,
		className: "md-text-input",
		value: L,
		placeholder: m || void 0,
		disabled: S,
		"aria-required": g || void 0,
		"aria-invalid": te || f || O.invalid || !h.ok ? !0 : void 0,
		"aria-describedby": O.describedBy,
		onFocus: () => ee(!0),
		onBlur: () => {
			ee(!1), H(!0);
			let e = W(L);
			U(e), !e && L !== F && ie(L);
		},
		onChange: (e) => {
			let t = e.target.value;
			R(t), p(null), V && U(W(t)), !ne.current && W(t) === null && ie(t);
		},
		onCompositionStart: () => {
			ne.current = !0;
		},
		onCompositionEnd: (e) => {
			ne.current = !1;
			let t = e.currentTarget.value;
			R(t), V && U(W(t)), W(t) === null && ie(t);
		}
	};
	return /* @__PURE__ */ J("div", {
		className: `md-control ${I}`,
		"data-rmd-component": r ? "textarea" : "input",
		...s,
		children: [
			/* @__PURE__ */ q("label", {
				className: "md-label",
				htmlFor: ae.id,
				children: t
			}),
			r ? /* @__PURE__ */ q("textarea", {
				...ae,
				rows: i
			}) : /* @__PURE__ */ q("input", {
				...ae,
				type: n ? "email" : "text"
			}),
			/* @__PURE__ */ q(z, {
				value: y(F),
				block: r
			}),
			/* @__PURE__ */ q(B, { message: D || !h.ok ? u("Cannot compute", "无法计算") : te ?? f ?? (b && g && F === "" ? u("This field is required", "请填写此字段") : null) })
		]
	});
}
function uu(e) {
	let t = e.trim();
	if (t === "" || t === "-" || t === "+" || t === "." || t === "-.") return { kind: "empty" };
	let n = Number(t);
	return Number.isFinite(n) ? {
		kind: "valid",
		value: n
	} : { kind: "invalid" };
}
function du(e, t, n, r, i) {
	let a = 1e-9 * Math.max(1, Math.abs(e));
	if (t !== void 0 && e < t - a) return i(`Must be at least ${t}`, `不能小于 ${t}`);
	if (n !== void 0 && e > n + a) return i(`Must be at most ${n}`, `不能大于 ${n}`);
	if (!Number.isFinite(r) || r <= 0) return i("Step must be greater than 0", "步长必须大于 0");
	let o = (e - (t ?? 0)) / r;
	return Math.abs(o - Math.round(o)) > 1e-9 * Math.max(1, Math.abs(o)) ? i(`Must be a multiple of ${r}`, `需要按步长 ${r} 取值`) : null;
}
function fu(e) {
	let t = _(e), n = le(), r = C(e), { mode: i, t: a } = t, { write: o, error: s, setError: c } = x(e), l = w(e, "label", a("Number", "数字")), { disabled: u, invalid: d } = N(e), f = T(e), p = te(e, "min"), m = te(e, "max"), h = p.present && !p.error ? p.value : void 0, g = m.present && !m.error ? m.value : void 0, v = p.error || m.error, b = V(e, "step", 1), S = P(e), E = typeof S == "number" && Number.isFinite(S) ? String(S) : "", D = typeof S == "number" && Number.isFinite(S) ? du(S, h, g, b, a) : null, { draft: O, setDraft: k, focused: A, setFocused: j, touched: F, setTouched: I, draftError: L, setDraftError: R, composing: ee, pendingDraft: H } = Nl(e, E, c);
	Ml(e, (e) => {
		if (ee.current) return "invalid";
		let t = H.current;
		if (t !== void 0) {
			let n = uu(t);
			if (n.kind !== "valid" || n.value !== e) return "invalid";
		}
	});
	let U = /* @__PURE__ */ J(me, { children: [
		h === void 0 ? "" : a(`Min ${h}`, `最小 ${h}`),
		h !== void 0 && g !== void 0 ? " · " : "",
		g === void 0 ? "" : a(`Max ${g}`, `最大 ${g}`),
		b === void 0 ? "" : a(` · Step ${b}`, ` · 步长 ${b}`)
	] });
	if (i === "static") return /* @__PURE__ */ q(M, {
		className: "local-number",
		label: l,
		value: y(E),
		hint: U
	});
	let ne = (e, t) => {
		let n = uu(e);
		if (n.kind !== "valid") return t && R(a("Enter a valid number", "请输入有效数字")), !1;
		let r = du(n.value, h, g, b, a);
		if (r) return t && R(r), !1;
		R(null);
		let i = o(n.value);
		return i && (H.current = void 0), i;
	};
	return /* @__PURE__ */ J("div", {
		className: "md-control local-number",
		"data-rmd-component": "number",
		...r,
		children: [
			/* @__PURE__ */ q("label", {
				className: "md-label",
				htmlFor: `${n}-number`,
				children: l
			}),
			/* @__PURE__ */ q("input", {
				id: `${n}-number`,
				className: "md-text-input",
				type: "text",
				inputMode: "decimal",
				value: O,
				min: h,
				max: g,
				step: b,
				disabled: u,
				"aria-invalid": L || s || f.invalid || v || !A && D ? !0 : void 0,
				"aria-describedby": f.describedBy,
				onFocus: () => j(!0),
				onBlur: () => {
					j(!1), I(!0), ne(O, !0);
				},
				onChange: (e) => {
					let t = e.target.value;
					k(t), c(null), ee.current || ne(t, F);
				},
				onCompositionStart: () => {
					ee.current = !0;
				},
				onCompositionEnd: (e) => {
					ee.current = !1, k(e.currentTarget.value), ne(e.currentTarget.value, F);
				}
			}),
			/* @__PURE__ */ q(z, { value: y(E) }),
			h !== void 0 || g !== void 0 || b !== void 0 ? /* @__PURE__ */ q("span", {
				className: "md-hint",
				children: U
			}) : null,
			/* @__PURE__ */ q(B, { message: d || v ? a("Cannot compute", "无法计算") : L ?? s ?? (A ? null : D) })
		]
	});
}
function pu(e) {
	let t = _(e), n = le(), r = C(e), { content: i, mode: a, t: o } = t, { write: s, error: c } = x(e), l = w(e, "label", o("Toggle", "开关")), { disabled: u, invalid: d } = N(e), f = T(e), p = P(e) === !0, m = p ? o("On", "开") : o("Off", "关");
	return a === "static" ? /* @__PURE__ */ q(M, {
		className: "md-toggle local-toggle",
		label: l,
		value: m
	}) : /* @__PURE__ */ J("div", {
		className: "md-control md-toggle local-toggle",
		style: L(O(i)),
		"data-rmd-component": "toggle",
		...r,
		children: [
			/* @__PURE__ */ J("label", {
				className: "md-toggle-label",
				htmlFor: `${n}-toggle`,
				children: [/* @__PURE__ */ q("input", {
					id: `${n}-toggle`,
					type: "checkbox",
					checked: p,
					disabled: u,
					"aria-invalid": f.invalid || void 0,
					"aria-describedby": f.describedBy,
					onChange: (e) => s(e.target.checked)
				}), /* @__PURE__ */ q("span", { children: l })]
			}),
			/* @__PURE__ */ q(z, { value: m }),
			/* @__PURE__ */ q(B, { message: d ? o("Cannot compute", "无法计算") : c })
		]
	});
}
function mu(e) {
	let t = _(e), n = le(), r = C(e), { content: i, mode: a, t: o } = t, { write: s, error: c } = x(e), l = w(e, "label", o("Checkbox", "勾选")), { disabled: u, invalid: d } = N(e), f = T(e), p = P(e) === !0, m = p ? o("Checked", "已勾选") : o("Unchecked", "未勾选");
	return a === "static" ? /* @__PURE__ */ q(M, {
		className: "local-checkbox",
		label: l,
		value: m
	}) : /* @__PURE__ */ J("div", {
		className: "md-control local-checkbox",
		style: L(O(i)),
		"data-rmd-component": "checkbox",
		...r,
		children: [
			/* @__PURE__ */ J("label", {
				className: "md-toggle-label",
				htmlFor: `${n}-checkbox`,
				children: [/* @__PURE__ */ q("input", {
					id: `${n}-checkbox`,
					type: "checkbox",
					checked: p,
					disabled: u,
					"aria-invalid": f.invalid || void 0,
					"aria-describedby": f.describedBy,
					onChange: (e) => s(e.target.checked)
				}), /* @__PURE__ */ q("span", { children: l })]
			}),
			/* @__PURE__ */ q(z, { value: m }),
			/* @__PURE__ */ q(B, { message: d ? o("Cannot compute", "无法计算") : c })
		]
	});
}
var hu = /^(\d{4})-(\d{2})-(\d{2})$/;
function gu(e) {
	let t = hu.exec(e);
	if (!t) return;
	let [n, r, i] = [
		Number(t[1]),
		Number(t[2]),
		Number(t[3])
	];
	if (n < 1 || n > 9999) return;
	let a = /* @__PURE__ */ new Date(0);
	return a.setFullYear(n, r - 1, i), a.setHours(0, 0, 0, 0), a.getFullYear() === n && a.getMonth() === r - 1 && a.getDate() === i ? a : void 0;
}
function _u(e) {
	return `${String(e.getFullYear()).padStart(4, "0")}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`;
}
function vu(e) {
	let t = _(e), n = le(), r = C(e), { content: i, mode: a, locale: o, t: s } = t, { write: c, error: l } = x(e), u = w(e, "label", s("Date", "日期")), { disabled: d, invalid: f } = N(e), p = T(e), m = v(e, "required", !1), h = m.ok ? m.value : !1, g = (E(i, "required") ?? "").includes("{{"), b = ee(e, "min"), D = ee(e, "max"), O = b.present && !b.error ? b.value : "", k = D.present && !D.error ? D.value : "", A = b.error || D.error || !m.ok, j = P(e), F = typeof j == "string" ? j : "", [I, L] = K(!1);
	S(e, () => L(!1));
	let R = F !== "" && (O !== "" && F < O || k !== "" && F > k) ? s(`Date must be between ${O || "…"} and ${k || "…"}`, `日期必须在 ${O || "…"} 与 ${k || "…"} 之间`) : null, V = (h && F === "" && (I || g) ? s("Select a date", "请选择日期") : null) ?? R;
	if (a === "static") return /* @__PURE__ */ q(M, {
		className: "local-date",
		label: u,
		value: y(F)
	});
	let H = f || A ? s("Cannot compute", "无法计算") : V ?? l, te = H ? `${n}-date-error` : void 0;
	return /* @__PURE__ */ J("div", {
		className: "md-control local-date local-date-picker",
		"data-rmd-part": "control",
		...r,
		children: [
			/* @__PURE__ */ q(Wt, {
				id: `${n}-date`,
				label: u,
				value: gu(F),
				onChange: (e) => {
					L(!0), c(e ? _u(e) : "");
				},
				onBlur: () => L(!0),
				minDate: gu(O),
				maxDate: gu(k),
				locale: o === "zh" ? "zh-CN" : "en-US",
				placeholder: s("Select a date", "请选择日期"),
				todayLabel: s("Today", "今天"),
				previousMonthLabel: s("Previous month", "上个月"),
				nextMonthLabel: s("Next month", "下个月"),
				clearLabel: s("Clear", "清除"),
				calendarLabel: s(`${u} calendar`, `${u} 日历`),
				statusLabel: (e) => e ? s(`Selected ${e}`, `已选择 ${e}`) : s("Choose a day", "请选择日期"),
				showToday: !0,
				disabled: d,
				"aria-required": h || void 0,
				invalid: !!H || p.invalid,
				describedBy: [p.describedBy, te].filter(Boolean).join(" ") || void 0
			}, t.resetToken),
			/* @__PURE__ */ q(B, {
				id: te,
				message: H
			}),
			/* @__PURE__ */ q(z, { value: y(F) })
		]
	});
}
function yu(e) {
	let t = _(e), n = le(), { content: r, mode: i, t: a } = t, { write: o, error: s } = x(e), c = w(e, "label", a("Select", "选择")), { disabled: l, invalid: u } = N(e), d = T(e), f = e.children.options(), p = P(e), m = typeof p == "string" ? p : "", h = f.some((e) => e.value === m) ? m : f[0]?.value ?? "", g = f.find((e) => e.value === h), v = g ? H(e, g) || h : "";
	if (f.length === 0) return /* @__PURE__ */ q(I, { message: a("Missing options", "缺少选项") });
	if (i === "static") return /* @__PURE__ */ q(M, {
		className: "md-select local-select",
		label: c,
		value: y(v)
	});
	let b = f.map((t, r) => ({
		value: `${n}-option-${r}`,
		label: H(e, t) || t.value
	})), S = b[Math.max(0, f.findIndex((e) => e.value === h))]?.value ?? "", C = u ? a("Cannot compute", "无法计算") : s, E = C ? `${n}-select-error` : void 0;
	return /* @__PURE__ */ J("div", {
		className: "md-control md-select local-select",
		style: L(O(r)),
		"data-rmd-part": "control",
		children: [
			/* @__PURE__ */ q(Al, {
				id: `${n}-select`,
				label: c,
				options: b,
				value: S,
				placeholder: a("Select an option", "请选择选项"),
				onValueChange: (e) => {
					let t = b.findIndex((t) => t.value === e), n = f[t];
					n && o(n.value);
				},
				disabled: l,
				invalid: !!C || d.invalid,
				describedBy: [d.describedBy, E].filter(Boolean).join(" ") || void 0
			}, t.resetToken),
			/* @__PURE__ */ q(B, {
				id: E,
				message: C
			}),
			/* @__PURE__ */ q(z, { value: y(v) })
		]
	});
}
function bu(e) {
	let t = _(e), n = le(), { content: r, mode: a, visible: o, t: s } = t, { write: c, error: l } = x(e), d = w(e, "label", s("Options", "选项")), { disabled: f, invalid: m } = N(e), g = T(e), v = e.children.options(), b = P(e), S = typeof b == "string" ? b : "", C = v.findIndex((e) => e.value === S), E = C >= 0 ? C : 0, D = C >= 0 ? v[C] : void 0, k = D ? H(e, D) : "", A = G([]), j = p() ?? !1, F = v.length >= 2 && v.length <= 4, R = i(E);
	if (ce(() => {
		let e = C >= 0 ? C : 0;
		if (!F || j) {
			R.jump(e);
			return;
		}
		let t = u(R, e, Kt.base);
		return () => t.stop();
	}, [
		R,
		j,
		F,
		C
	]), v.length === 0) return /* @__PURE__ */ q(I, { message: s("Missing options", "缺少选项") });
	if (a === "static") return /* @__PURE__ */ q(M, {
		className: "local-choices",
		label: d,
		value: y(k)
	});
	let ee = (e) => {
		let t = v[e];
		t && (c(t.value), A.current[e]?.focus());
	}, V = (e, t) => {
		let n = -1;
		e.key === "ArrowRight" || e.key === "ArrowDown" ? n = (t + 1) % v.length : e.key === "ArrowLeft" || e.key === "ArrowUp" ? n = (t - 1 + v.length) % v.length : e.key === "Home" ? n = 0 : e.key === "End" && (n = v.length - 1), !(n < 0) && (e.preventDefault(), ee(n));
	};
	return /* @__PURE__ */ J("div", {
		className: "md-control local-choices",
		style: L(O(r)),
		"data-rmd-component": "choices",
		children: [
			/* @__PURE__ */ q("span", {
				className: "md-label",
				id: `${n}-choices-label`,
				children: d
			}),
			/* @__PURE__ */ q(h.div, {
				className: "local-choice-list",
				role: "radiogroup",
				"aria-labelledby": `${n}-choices-label`,
				"aria-disabled": f || void 0,
				"aria-invalid": g.invalid || void 0,
				"aria-describedby": g.describedBy,
				"data-rmd-choices": F ? "uiarc" : void 0,
				"data-rmd-part": "list",
				"data-rmd-segments": F ? "" : void 0,
				style: F ? { "--pu-choice-index": R } : void 0,
				children: v.map((e, n) => {
					let r = e.value === S;
					return /* @__PURE__ */ q("button", {
						ref: (e) => {
							A.current[n] = e;
						},
						type: "button",
						role: "radio",
						"aria-checked": r,
						tabIndex: n === E ? 0 : -1,
						disabled: f,
						className: `local-choice${r ? " is-selected" : ""}`,
						"data-rmd-appearance": "custom",
						"data-rmd-part": "segment",
						onClick: () => c(e.value),
						onKeyDown: (e) => V(e, n),
						children: t.renderInline(e.content.children, o)
					}, e.content.id);
				})
			}),
			/* @__PURE__ */ q(z, { value: y(k) }),
			/* @__PURE__ */ q(B, { message: m ? s("Cannot compute", "无法计算") : l })
		]
	});
}
function xu(e) {
	let t = _(e), n = le(), { content: r, mode: i, visible: a, t: o } = t, { write: s, error: c } = x(e), l = w(e, "label", o("Options", "选项")), { disabled: u, invalid: d } = N(e), f = T(e), p = e.children.options(), m = P(e), h = typeof m == "string" ? m : "", g = n, v = p.find((e) => e.value === h), b = v ? H(e, v) : "";
	return p.length === 0 ? /* @__PURE__ */ q(I, { message: o("Missing options", "缺少选项") }) : i === "static" ? /* @__PURE__ */ q(M, {
		className: "local-radio-group",
		label: l,
		value: y(b)
	}) : /* @__PURE__ */ J("fieldset", {
		className: "md-control local-radio-group",
		style: L(O(r)),
		"data-rmd-component": "radio-group",
		disabled: u,
		"aria-invalid": f.invalid || void 0,
		"aria-describedby": f.describedBy,
		children: [
			/* @__PURE__ */ q("legend", {
				className: "md-label",
				children: l
			}),
			p.map((e) => /* @__PURE__ */ J("label", {
				className: "local-radio-option",
				children: [/* @__PURE__ */ q("input", {
					type: "radio",
					name: g,
					value: e.value,
					checked: h === e.value,
					onChange: () => s(e.value)
				}), /* @__PURE__ */ q("span", { children: t.renderInline(e.content.children, a) })]
			}, e.content.id)),
			/* @__PURE__ */ q(z, { value: y(b) }),
			/* @__PURE__ */ q(B, { message: d ? o("Cannot compute", "无法计算") : c })
		]
	});
}
function Su(e) {
	return (e.children.find((e) => e.kind === "list")?.children ?? []).filter((e) => e.kind === "listItem").map((e, t) => ({
		id: `item-${t + 1}`,
		content: e
	}));
}
function Cu(e) {
	let t = _(e), n = le(), { content: r, mode: i, visible: a, t: o } = t, { write: s, error: c } = x(e), l = w(e, "label", o("Checklist", "清单")), { disabled: u, invalid: d } = N(e), f = T(e), p = Su(r), m = P(e), h = Array.isArray(m) ? m.filter((e) => typeof e == "string") : [];
	if (p.length === 0) return /* @__PURE__ */ q(I, { message: o("Checklist requires a task list", "清单需要任务列表") });
	let g = (e) => e ? o("Checked", "已勾选") : o("Unchecked", "未勾选");
	if (i === "static") return /* @__PURE__ */ J("div", {
		className: "local-checklist local-static-checklist",
		style: L(O(r)),
		role: "group",
		"aria-label": l,
		children: [/* @__PURE__ */ q("span", {
			className: "md-label",
			children: l
		}), /* @__PURE__ */ q("ul", {
			className: "local-static-list",
			children: p.map((e) => {
				let n = h.includes(e.id);
				return /* @__PURE__ */ J("li", {
					className: "local-static-list-item",
					children: [/* @__PURE__ */ q("span", {
						className: "local-static-state",
						children: g(n)
					}), /* @__PURE__ */ q("span", {
						className: `local-static-item${n ? " is-checked" : ""}`,
						children: t.renderInline(e.content.children, a)
					})]
				}, e.id);
			})
		})]
	});
	let v = (e, t) => {
		let n = new Set(h);
		t ? n.add(e) : n.delete(e), s(p.filter((e) => n.has(e.id)).map((e) => e.id));
	};
	return /* @__PURE__ */ J("fieldset", {
		className: "local-checklist",
		style: L(O(r)),
		"data-rmd-component": "checklist",
		disabled: u,
		"aria-invalid": f.invalid || void 0,
		"aria-describedby": f.describedBy,
		children: [
			/* @__PURE__ */ q("legend", {
				className: "md-label",
				children: l
			}),
			p.map((e) => {
				let r = h.includes(e.id);
				return /* @__PURE__ */ J("div", {
					className: "local-checklist-item",
					children: [/* @__PURE__ */ q("input", {
						id: `${n}-${e.id}`,
						type: "checkbox",
						checked: r,
						onChange: (t) => v(e.id, t.target.checked)
					}), /* @__PURE__ */ q("label", {
						className: `local-checklist-text${r ? " is-checked" : ""}`,
						htmlFor: `${n}-${e.id}`,
						children: t.renderInline(e.content.children, a)
					})]
				}, e.id);
			}),
			/* @__PURE__ */ q(z, {
				block: !0,
				value: /* @__PURE__ */ q("ul", {
					className: "local-static-list",
					children: p.map((t) => {
						let n = h.includes(t.id);
						return /* @__PURE__ */ J("li", {
							className: "local-static-list-item",
							children: [/* @__PURE__ */ q("span", {
								className: "local-static-state",
								children: g(n)
							}), /* @__PURE__ */ q("span", {
								className: `local-static-item${n ? " is-checked" : ""}`,
								children: F(e, t.content.children)
							})]
						}, t.id);
					})
				})
			}),
			/* @__PURE__ */ q(B, { message: d ? o("Cannot compute", "无法计算") : c })
		]
	});
}
function wu(e) {
	let { content: t, runtime: n, mode: r, t: i } = _(e), { write: a, error: o } = x(e), s = w(e, "label", i("Counter", "计数")), { disabled: c, invalid: l } = N(e), u = T(e), d = V(e, "min", 0), f = E(t, "max") === void 0 ? void 0 : V(e, "max", 0), p = V(e, "step", 1), m = P(e), h = typeof m == "number" && Number.isFinite(m) ? m : d, g = Number.isFinite(p) && p > 0 ? p : 1, v = 1e-9 * Math.max(1, Math.abs(h)), y = h - g >= d - v, b = f === void 0 || h + g <= f + v;
	if (r === "static") return /* @__PURE__ */ q(M, {
		className: "local-counter",
		label: s,
		value: String(h)
	});
	let S = (e) => {
		let t = Number((h + e * g).toFixed(12));
		a(t);
	};
	return /* @__PURE__ */ J("div", {
		className: "local-counter",
		role: "group",
		"aria-label": s,
		"data-rmd-component": "counter",
		"aria-invalid": u.invalid || void 0,
		"aria-describedby": u.describedBy,
		children: [
			/* @__PURE__ */ q("span", {
				className: "md-label",
				children: s
			}),
			/* @__PURE__ */ J("div", {
				className: "local-counter-row",
				children: [
					/* @__PURE__ */ q("button", {
						type: "button",
						className: "md-button md-button-secondary local-counter-button",
						"aria-label": `${s} ${i("decrease", "减少")}`,
						disabled: c || !y,
						onClick: () => S(-1),
						children: "−"
					}),
					/* @__PURE__ */ q("span", {
						className: "local-counter-value",
						"aria-live": "polite",
						children: /* @__PURE__ */ q("span", {
							className: "local-counter-value-pop",
							children: h
						}, h)
					}),
					/* @__PURE__ */ q("button", {
						type: "button",
						className: "md-button md-button-secondary local-counter-button",
						"aria-label": `${s} ${i("increase", "增加")}`,
						disabled: c || !b,
						onClick: () => S(1),
						children: "+"
					}),
					/* @__PURE__ */ q("button", {
						type: "button",
						className: "md-button md-button-quiet local-counter-reset",
						disabled: c,
						onClick: () => {
							n.reset(t);
						},
						children: i("Reset", "恢复初值")
					})
				]
			}),
			/* @__PURE__ */ q(z, { value: String(h) }),
			/* @__PURE__ */ q(B, { message: l ? i("Cannot compute", "无法计算") : o })
		]
	});
}
function Tu(e) {
	let { content: t, runtime: n, mode: i, visible: a, locale: o, t: s } = _(e), c = w(e, "label", s("Timer", "计时器")), l = T(e), u = V(e, "duration", 60), d = Math.floor(u), f = P(e), p = typeof f == "number" && Number.isFinite(f) ? Math.max(0, Math.ceil(f)) : d, [m, h] = K(!1), [g, v] = K(!1), y = G(0), b = G(p);
	b.current = p;
	let [x, C] = K(null), E = oe((e) => {
		let i = n.set(t, e);
		i.length && C(i.map((e) => r(e, o)).join("; "));
	}, [
		t,
		o,
		n
	]);
	return ce(() => {
		if (!m) return;
		let e = window.setInterval(() => {
			let e = Math.max(0, Math.ceil((y.current - performance.now()) / 1e3));
			e !== b.current && (b.current = e, E(e)), e <= 0 && (h(!1), v(!0));
		}, 200);
		return () => window.clearInterval(e);
	}, [m, E]), ce(() => {
		if (a || !m) return;
		let e = Math.max(0, Math.ceil((y.current - performance.now()) / 1e3));
		b.current = e, E(e), h(!1);
	}, [
		a,
		m,
		E
	]), S(e, () => {
		h(!1), v(!1), C(null);
	}), !Number.isFinite(u) || d <= 0 ? /* @__PURE__ */ q(I, { message: s("Timer duration must be a positive number of seconds", "计时时长必须是大于 0 的秒数") }) : i === "static" ? /* @__PURE__ */ q(M, {
		className: "local-timer",
		label: c,
		value: R(p, s)
	}) : /* @__PURE__ */ J("div", {
		className: "local-timer",
		role: "group",
		"aria-label": c,
		"data-rmd-component": "timer",
		"aria-invalid": l.invalid || void 0,
		"aria-describedby": l.describedBy,
		children: [
			/* @__PURE__ */ J("div", {
				className: "local-timer-head",
				children: [/* @__PURE__ */ q("span", {
					className: "md-label",
					children: c
				}), /* @__PURE__ */ q("span", {
					className: "local-timer-value",
					role: "timer",
					"aria-label": s(`${p} seconds remaining`, `剩余 ${p} 秒`),
					children: R(p, s)
				})]
			}),
			/* @__PURE__ */ J("div", {
				className: "local-timer-controls",
				children: [
					/* @__PURE__ */ q("button", {
						type: "button",
						className: "md-button md-button-primary",
						onClick: () => {
							if (m) return;
							let e = p > 0 ? p : d;
							p <= 0 && (b.current = d, E(d)), y.current = performance.now() + e * 1e3, v(!1), C(null), h(!0);
						},
						disabled: m,
						children: s("Start", "开始")
					}),
					/* @__PURE__ */ q("button", {
						type: "button",
						className: "md-button md-button-secondary",
						onClick: () => {
							if (!m) return;
							let e = Math.max(0, Math.ceil((y.current - performance.now()) / 1e3));
							b.current = e, E(e), h(!1);
						},
						disabled: !m,
						children: s("Pause", "暂停")
					}),
					/* @__PURE__ */ q("button", {
						type: "button",
						className: "md-button md-button-quiet",
						onClick: () => {
							h(!1), v(!1), C(null), b.current = d, n.reset(t);
						},
						children: s("Reset", "重置")
					})
				]
			}),
			/* @__PURE__ */ q("span", {
				className: "local-timer-status",
				role: "status",
				"aria-live": "polite",
				children: g ? s("Completed", "计时完成") : m ? s("Running", "计时中") : s("Paused", "已暂停")
			}),
			/* @__PURE__ */ q(z, { value: R(p, s) }),
			/* @__PURE__ */ q(B, { message: x })
		]
	});
}
function Eu(e) {
	let { content: t, t: n } = _(e), r = w(e, "label", n("Progress", "进度")), i = V(e, "max", 100), a = e.props.value;
	if (!Number.isFinite(i) || i <= 0) return /* @__PURE__ */ q(I, { message: n("Progress maximum must be positive", "进度上限必须是正数") });
	if (a == null) return /* @__PURE__ */ q(I, { message: n("Cannot compute", "无法计算") });
	let o = typeof a == "number" ? a : typeof a == "string" && a.trim() !== "" ? Number(a) : NaN;
	if (!Number.isFinite(o)) return /* @__PURE__ */ q(I, { message: n("Cannot compute", "无法计算") });
	if (o < 0 || o > i) return /* @__PURE__ */ q(I, { message: n(`Progress value must be between 0 and ${i}`, `进度值需要在 0 到 ${i} 之间`) });
	let s = o / i * 100, c = O(t);
	return /* @__PURE__ */ J("div", {
		className: "local-progress",
		"data-rmd-component": "progress",
		style: c ? { "--local-progress-color": c } : void 0,
		children: [/* @__PURE__ */ J("div", {
			className: "local-progress-head",
			children: [/* @__PURE__ */ q("span", {
				className: "md-label",
				children: r
			}), /* @__PURE__ */ J("span", {
				className: "local-progress-value",
				children: [Math.round(s), "%"]
			})]
		}), /* @__PURE__ */ q("div", {
			className: "local-progress-track",
			role: "progressbar",
			"aria-label": r || n("Progress", "进度"),
			"aria-valuemin": 0,
			"aria-valuemax": i,
			"aria-valuenow": o,
			children: /* @__PURE__ */ q("div", {
				className: "local-progress-fill",
				style: { width: `${s}%` }
			})
		})]
	});
}
function Du(e) {
	let t = _(e), n = le(), { content: r, mode: i, visible: a, t: o } = t, { write: s, error: c, setError: l } = x(e), u = w(e, "label", o("Multi select", "多选")), { disabled: d, invalid: f } = N(e), p = T(e), m = e.children.options(), h = P(e), g = Array.isArray(h) ? h.filter((e) => typeof e == "string") : [], v = m.filter((e) => g.includes(e.value)).map((t) => H(e, t) || t.value), b = V(e, "max-selected", m.length), C = Number.isFinite(b) ? Math.max(0, Math.floor(b)) : m.length, [E, D] = K("");
	if (S(e, () => {
		D(""), l(null);
	}), m.length === 0) return /* @__PURE__ */ q(I, { message: o("Missing options", "缺少选项") });
	if (i === "static") return /* @__PURE__ */ q(M, {
		className: "local-multi-select",
		label: u,
		value: y(v.join(", "))
	});
	let k = new Set(g), A = g.length >= C, j = E.trim().toLocaleLowerCase(), R = j ? m.filter((t) => `${F(e, t.content.children)} ${t.value}`.toLocaleLowerCase().includes(j)) : m, ee = (e, t) => {
		let n = new Set(k);
		if (t) {
			if (!n.has(e) && n.size >= C) return;
			n.add(e);
		} else n.delete(e);
		s(m.filter((e) => n.has(e.value)).map((e) => e.value));
	};
	return /* @__PURE__ */ J("fieldset", {
		className: "local-multi-select",
		style: L(O(r)),
		"data-rmd-component": "multi-select",
		disabled: d,
		"aria-invalid": p.invalid || void 0,
		"aria-describedby": p.describedBy,
		children: [
			/* @__PURE__ */ q("legend", {
				className: "md-label",
				children: u
			}),
			/* @__PURE__ */ J("div", {
				className: "local-multi-toolbar",
				children: [/* @__PURE__ */ q("input", {
					id: `${n}-multi-search`,
					type: "search",
					className: "md-text-input local-multi-search",
					value: E,
					placeholder: o("Search options", "搜索选项"),
					"aria-label": o(`Search ${u}`, `搜索${u}`),
					onChange: (e) => D(e.target.value)
				}), /* @__PURE__ */ q("button", {
					type: "button",
					className: "md-button md-button-quiet local-multi-clear",
					onClick: () => {
						D(""), g.length > 0 && s([]);
					},
					children: o("Clear", "清除")
				})]
			}),
			/* @__PURE__ */ q("div", {
				className: "local-multi-list",
				role: "group",
				"aria-label": u,
				children: R.length === 0 ? /* @__PURE__ */ q("span", {
					className: "local-multi-empty",
					children: o("No matching options", "没有匹配选项")
				}) : R.map((e) => {
					let n = k.has(e.value);
					return /* @__PURE__ */ J("label", {
						className: `local-multi-option${n ? " is-selected" : ""}`,
						children: [/* @__PURE__ */ q("input", {
							type: "checkbox",
							checked: n,
							disabled: !n && A,
							onChange: (t) => ee(e.value, t.target.checked)
						}), /* @__PURE__ */ q("span", { children: t.renderInline(e.content.children, a) })]
					}, e.content.id);
				})
			}),
			/* @__PURE__ */ q("span", {
				className: "local-multi-count",
				role: "status",
				"aria-live": "polite",
				children: o(`${g.length} of ${C} selected`, `已选 ${g.length}/${C}`)
			}),
			/* @__PURE__ */ q(z, { value: y(v.join(", ")) }),
			/* @__PURE__ */ q(B, { message: f ? o("Cannot compute", "无法计算") : c })
		]
	});
}
function Ou(e) {
	let t = _(e), n = le(), { content: r, mode: i, visible: a, t: o } = t, s = w(e, "label", o("Quiz", "测验")), c = E(r, "type") === "number" ? "number" : "choice", l = (E(r, "answer") ?? "").trim(), u = V(e, "tolerance", 0), d = Number.isFinite(u) && u >= 0 ? u : 0, { disabled: f, invalid: p } = N(e), m = e.children.options(), h = w(e, "explanation", ""), [g, v] = K(""), [y, b] = K(null);
	S(e, () => {
		v(""), b(null);
	});
	let x = c === "number" ? Number(l) : NaN;
	if (c === "number" && !Number.isFinite(x)) return /* @__PURE__ */ q(I, { message: o("Quiz answer must be a number", "测验答案必须是数字") });
	if (c === "choice" && m.length === 0) return /* @__PURE__ */ q(I, { message: o("Missing options", "缺少选项") });
	let C = m.map((e) => e.label || e.value);
	if (i === "static") return /* @__PURE__ */ J("div", {
		className: "local-quiz local-static-quiz",
		role: "group",
		"aria-label": s,
		children: [/* @__PURE__ */ q("span", {
			className: "md-label",
			children: s
		}), c === "choice" ? /* @__PURE__ */ q("ul", {
			className: "local-static-list local-static-quiz-options",
			children: m.map((e) => /* @__PURE__ */ q("li", {
				className: "local-static-list-item",
				children: t.renderInline(e.content.children, a)
			}, e.content.id))
		}) : /* @__PURE__ */ q("span", {
			className: "local-static-value",
			children: o("Numeric answer", "数字作答")
		})]
	});
	let T = () => {
		if (c === "choice") {
			if (g === "") {
				b("incomplete");
				return;
			}
			b(g === l ? "correct" : "incorrect");
			return;
		}
		let e = g.trim(), t = e === "" ? NaN : Number(e);
		b(Number.isFinite(t) ? Math.abs(t - x) <= d ? "correct" : "incorrect" : "incomplete");
	}, D = () => {
		v(""), b(null);
	}, O = y === null ? null : y === "correct" ? `${o("Correct", "回答正确")}` : y === "incorrect" ? `${o("Not quite", "回答不正确")}` : c === "number" ? o("Enter a number first", "请先输入数字") : o("Choose an answer first", "请先选择答案"), k = y === "correct" ? " is-correct" : y === "incorrect" ? " is-incorrect" : "";
	return /* @__PURE__ */ J("div", {
		className: "local-quiz",
		role: "group",
		"aria-label": s,
		"data-rmd-component": "quiz",
		children: [
			c === "choice" ? /* @__PURE__ */ J("fieldset", {
				className: "local-quiz-options",
				disabled: f,
				children: [/* @__PURE__ */ q("legend", {
					className: "md-label",
					children: s
				}), m.map((e) => /* @__PURE__ */ J("label", {
					className: "local-radio-option",
					children: [/* @__PURE__ */ q("input", {
						type: "radio",
						name: `${n}-quiz`,
						value: e.value,
						checked: g === e.value,
						onChange: () => {
							v(e.value), b(null);
						}
					}), /* @__PURE__ */ q("span", { children: t.renderInline(e.content.children, a) })]
				}, e.content.id))]
			}) : /* @__PURE__ */ J("div", {
				className: "local-quiz-number",
				children: [/* @__PURE__ */ q("label", {
					className: "md-label",
					htmlFor: `${n}-quiz`,
					children: s
				}), /* @__PURE__ */ q("input", {
					id: `${n}-quiz`,
					className: "md-text-input local-quiz-input",
					type: "text",
					inputMode: "decimal",
					value: g,
					disabled: f,
					"aria-label": s,
					onChange: (e) => {
						v(e.target.value), b(null);
					}
				})]
			}),
			/* @__PURE__ */ J("div", {
				className: "local-quiz-actions",
				children: [/* @__PURE__ */ q("button", {
					type: "button",
					className: "md-button md-button-primary local-quiz-check",
					disabled: f,
					onClick: T,
					children: o("Check answer", "检查答案")
				}), /* @__PURE__ */ q("button", {
					type: "button",
					className: "md-button md-button-secondary local-quiz-again",
					disabled: f,
					onClick: D,
					children: o("Try again", "再试一次")
				})]
			}),
			/* @__PURE__ */ q("span", {
				className: `local-quiz-feedback${k}`,
				role: "status",
				"aria-live": "polite",
				children: O ? `${y === "correct" ? "✓ " : y === "incorrect" ? "✗ " : ""}${O}` : ""
			}),
			y !== null && h ? /* @__PURE__ */ q("div", {
				className: "local-quiz-explanation",
				children: h
			}) : null,
			/* @__PURE__ */ q(z, {
				block: !0,
				value: c === "choice" ? `${O ? `${O} · ` : ""}${C.join(" · ")}` : O || o("No answer yet", "尚未作答")
			}),
			/* @__PURE__ */ q(B, { message: p ? o("Cannot compute", "无法计算") : null })
		]
	});
}
export { iu as _, vu as a, fu as c, xu as d, yu as f, au as g, pu as h, wu as i, Eu as l, Tu as m, Cu as n, su as o, cu as p, bu as r, Du as s, mu as t, Ou as u };
