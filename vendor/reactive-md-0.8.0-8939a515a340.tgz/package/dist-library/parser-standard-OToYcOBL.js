import { D as e, E as t, O as n, P as r, T as i, k as a } from "./config-validation-C5kJYk-J.js";
import { $ as o, A as s, D as c, E as l, F as u, G as d, I as f, J as p, K as m, M as h, N as g, O as _, P as v, R as y, S as ee, T as b, V as x, X as S, Y as C, Z as te, et as ne, j as w, k as re, q as T, w as ie, z as ae } from "./validation-BlDL2uD9.js";
// node_modules/parse5/dist/common/unicode.js
var oe = /* @__PURE__ */ new Set([
	65534,
	65535,
	131070,
	131071,
	196606,
	196607,
	262142,
	262143,
	327678,
	327679,
	393214,
	393215,
	458750,
	458751,
	524286,
	524287,
	589822,
	589823,
	655358,
	655359,
	720894,
	720895,
	786430,
	786431,
	851966,
	851967,
	917502,
	917503,
	983038,
	983039,
	1048574,
	1048575,
	1114110,
	1114111
]), E;
(function(e) {
	e[e.EOF = -1] = "EOF", e[e.NULL = 0] = "NULL", e[e.TABULATION = 9] = "TABULATION", e[e.CARRIAGE_RETURN = 13] = "CARRIAGE_RETURN", e[e.LINE_FEED = 10] = "LINE_FEED", e[e.FORM_FEED = 12] = "FORM_FEED", e[e.SPACE = 32] = "SPACE", e[e.EXCLAMATION_MARK = 33] = "EXCLAMATION_MARK", e[e.QUOTATION_MARK = 34] = "QUOTATION_MARK", e[e.AMPERSAND = 38] = "AMPERSAND", e[e.APOSTROPHE = 39] = "APOSTROPHE", e[e.HYPHEN_MINUS = 45] = "HYPHEN_MINUS", e[e.SOLIDUS = 47] = "SOLIDUS", e[e.DIGIT_0 = 48] = "DIGIT_0", e[e.DIGIT_9 = 57] = "DIGIT_9", e[e.SEMICOLON = 59] = "SEMICOLON", e[e.LESS_THAN_SIGN = 60] = "LESS_THAN_SIGN", e[e.EQUALS_SIGN = 61] = "EQUALS_SIGN", e[e.GREATER_THAN_SIGN = 62] = "GREATER_THAN_SIGN", e[e.QUESTION_MARK = 63] = "QUESTION_MARK", e[e.LATIN_CAPITAL_A = 65] = "LATIN_CAPITAL_A", e[e.LATIN_CAPITAL_Z = 90] = "LATIN_CAPITAL_Z", e[e.RIGHT_SQUARE_BRACKET = 93] = "RIGHT_SQUARE_BRACKET", e[e.GRAVE_ACCENT = 96] = "GRAVE_ACCENT", e[e.LATIN_SMALL_A = 97] = "LATIN_SMALL_A", e[e.LATIN_SMALL_Z = 122] = "LATIN_SMALL_Z";
})(E ||= {});
var D = {
	DASH_DASH: "--",
	CDATA_START: "[CDATA[",
	DOCTYPE: "doctype",
	SCRIPT: "script",
	PUBLIC: "public",
	SYSTEM: "system"
};
function se(e) {
	return e >= 55296 && e <= 57343;
}
function ce(e) {
	return e >= 56320 && e <= 57343;
}
function le(e, t) {
	return (e - 55296) * 1024 + 9216 + t;
}
function ue(e) {
	return e !== 32 && e !== 10 && e !== 13 && e !== 9 && e !== 12 && e >= 1 && e <= 31 || e >= 127 && e <= 159;
}
function de(e) {
	return e >= 64976 && e <= 65007 || oe.has(e);
}
// node_modules/parse5/dist/common/error-codes.js
var O;
(function(e) {
	e.controlCharacterInInputStream = "control-character-in-input-stream", e.noncharacterInInputStream = "noncharacter-in-input-stream", e.surrogateInInputStream = "surrogate-in-input-stream", e.nonVoidHtmlElementStartTagWithTrailingSolidus = "non-void-html-element-start-tag-with-trailing-solidus", e.endTagWithAttributes = "end-tag-with-attributes", e.endTagWithTrailingSolidus = "end-tag-with-trailing-solidus", e.unexpectedSolidusInTag = "unexpected-solidus-in-tag", e.unexpectedNullCharacter = "unexpected-null-character", e.unexpectedQuestionMarkInsteadOfTagName = "unexpected-question-mark-instead-of-tag-name", e.invalidFirstCharacterOfTagName = "invalid-first-character-of-tag-name", e.unexpectedEqualsSignBeforeAttributeName = "unexpected-equals-sign-before-attribute-name", e.missingEndTagName = "missing-end-tag-name", e.unexpectedCharacterInAttributeName = "unexpected-character-in-attribute-name", e.unknownNamedCharacterReference = "unknown-named-character-reference", e.missingSemicolonAfterCharacterReference = "missing-semicolon-after-character-reference", e.unexpectedCharacterAfterDoctypeSystemIdentifier = "unexpected-character-after-doctype-system-identifier", e.unexpectedCharacterInUnquotedAttributeValue = "unexpected-character-in-unquoted-attribute-value", e.eofBeforeTagName = "eof-before-tag-name", e.eofInTag = "eof-in-tag", e.missingAttributeValue = "missing-attribute-value", e.missingWhitespaceBetweenAttributes = "missing-whitespace-between-attributes", e.missingWhitespaceAfterDoctypePublicKeyword = "missing-whitespace-after-doctype-public-keyword", e.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers = "missing-whitespace-between-doctype-public-and-system-identifiers", e.missingWhitespaceAfterDoctypeSystemKeyword = "missing-whitespace-after-doctype-system-keyword", e.missingQuoteBeforeDoctypePublicIdentifier = "missing-quote-before-doctype-public-identifier", e.missingQuoteBeforeDoctypeSystemIdentifier = "missing-quote-before-doctype-system-identifier", e.missingDoctypePublicIdentifier = "missing-doctype-public-identifier", e.missingDoctypeSystemIdentifier = "missing-doctype-system-identifier", e.abruptDoctypePublicIdentifier = "abrupt-doctype-public-identifier", e.abruptDoctypeSystemIdentifier = "abrupt-doctype-system-identifier", e.cdataInHtmlContent = "cdata-in-html-content", e.incorrectlyOpenedComment = "incorrectly-opened-comment", e.eofInScriptHtmlCommentLikeText = "eof-in-script-html-comment-like-text", e.eofInDoctype = "eof-in-doctype", e.nestedComment = "nested-comment", e.abruptClosingOfEmptyComment = "abrupt-closing-of-empty-comment", e.eofInComment = "eof-in-comment", e.incorrectlyClosedComment = "incorrectly-closed-comment", e.eofInCdata = "eof-in-cdata", e.absenceOfDigitsInNumericCharacterReference = "absence-of-digits-in-numeric-character-reference", e.nullCharacterReference = "null-character-reference", e.surrogateCharacterReference = "surrogate-character-reference", e.characterReferenceOutsideUnicodeRange = "character-reference-outside-unicode-range", e.controlCharacterReference = "control-character-reference", e.noncharacterCharacterReference = "noncharacter-character-reference", e.missingWhitespaceBeforeDoctypeName = "missing-whitespace-before-doctype-name", e.missingDoctypeName = "missing-doctype-name", e.invalidCharacterSequenceAfterDoctypeName = "invalid-character-sequence-after-doctype-name", e.duplicateAttribute = "duplicate-attribute", e.nonConformingDoctype = "non-conforming-doctype", e.missingDoctype = "missing-doctype", e.misplacedDoctype = "misplaced-doctype", e.endTagWithoutMatchingOpenElement = "end-tag-without-matching-open-element", e.closingOfElementWithOpenChildElements = "closing-of-element-with-open-child-elements", e.disallowedContentInNoscriptInHead = "disallowed-content-in-noscript-in-head", e.openElementsLeftAfterEof = "open-elements-left-after-eof", e.abandonedHeadElementChild = "abandoned-head-element-child", e.misplacedStartTagForHeadElement = "misplaced-start-tag-for-head-element", e.nestedNoscriptInHead = "nested-noscript-in-head", e.eofInElementThatCanContainOnlyText = "eof-in-element-that-can-contain-only-text";
})(O ||= {});
// node_modules/parse5/dist/tokenizer/preprocessor.js
var fe = 65536, pe = class {
	constructor(e) {
		this.handler = e, this.html = "", this.pos = -1, this.lastGapPos = -2, this.gapStack = [], this.skipNextNewLine = !1, this.lastChunkWritten = !1, this.endOfChunkHit = !1, this.bufferWaterline = fe, this.isEol = !1, this.lineStartPos = 0, this.droppedBufferSize = 0, this.line = 1, this.lastErrOffset = -1;
	}
	get col() {
		return this.pos - this.lineStartPos + Number(this.lastGapPos !== this.pos);
	}
	get offset() {
		return this.droppedBufferSize + this.pos;
	}
	getError(e, t) {
		let { line: n, col: r, offset: i } = this, a = r + t, o = i + t;
		return {
			code: e,
			startLine: n,
			endLine: n,
			startCol: a,
			endCol: a,
			startOffset: o,
			endOffset: o
		};
	}
	_err(e) {
		this.handler.onParseError && this.lastErrOffset !== this.offset && (this.lastErrOffset = this.offset, this.handler.onParseError(this.getError(e, 0)));
	}
	_addGap() {
		this.gapStack.push(this.lastGapPos), this.lastGapPos = this.pos;
	}
	_processSurrogate(e) {
		if (this.pos !== this.html.length - 1) {
			let t = this.html.charCodeAt(this.pos + 1);
			if (ce(t)) return this.pos++, this._addGap(), le(e, t);
		} else if (!this.lastChunkWritten) return this.endOfChunkHit = !0, E.EOF;
		return this._err(O.surrogateInInputStream), e;
	}
	willDropParsedChunk() {
		return this.pos > this.bufferWaterline;
	}
	dropParsedChunk() {
		this.willDropParsedChunk() && (this.html = this.html.substring(this.pos), this.lineStartPos -= this.pos, this.droppedBufferSize += this.pos, this.pos = 0, this.lastGapPos = -2, this.gapStack.length = 0);
	}
	write(e, t) {
		this.html.length > 0 ? this.html += e : this.html = e, this.endOfChunkHit = !1, this.lastChunkWritten = t;
	}
	insertHtmlAtCurrentPos(e) {
		this.html = this.html.substring(0, this.pos + 1) + e + this.html.substring(this.pos + 1), this.endOfChunkHit = !1;
	}
	startsWith(e, t) {
		if (this.pos + e.length > this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, !1;
		if (t) return this.html.startsWith(e, this.pos);
		for (let t = 0; t < e.length; t++) if ((this.html.charCodeAt(this.pos + t) | 32) !== e.charCodeAt(t)) return !1;
		return !0;
	}
	peek(e) {
		let t = this.pos + e;
		if (t >= this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, E.EOF;
		let n = this.html.charCodeAt(t);
		return n === E.CARRIAGE_RETURN ? E.LINE_FEED : n;
	}
	advance() {
		if (this.pos++, this.isEol && (this.isEol = !1, this.line++, this.lineStartPos = this.pos), this.pos >= this.html.length) return this.endOfChunkHit = !this.lastChunkWritten, E.EOF;
		let e = this.html.charCodeAt(this.pos);
		return e === E.CARRIAGE_RETURN ? (this.isEol = !0, this.skipNextNewLine = !0, E.LINE_FEED) : e === E.LINE_FEED && (this.isEol = !0, this.skipNextNewLine) ? (this.line--, this.skipNextNewLine = !1, this._addGap(), this.advance()) : (this.skipNextNewLine = !1, se(e) && (e = this._processSurrogate(e)), this.handler.onParseError === null || e > 31 && e < 127 || e === E.LINE_FEED || e === E.CARRIAGE_RETURN || e > 159 && e < 64976 || this._checkForProblematicCharacters(e), e);
	}
	_checkForProblematicCharacters(e) {
		ue(e) ? this._err(O.controlCharacterInInputStream) : de(e) && this._err(O.noncharacterInInputStream);
	}
	retreat(e) {
		for (this.pos -= e; this.pos < this.lastGapPos;) this.lastGapPos = this.gapStack.pop(), this.pos--;
		this.isEol = !1;
	}
}, k;
(function(e) {
	e[e.CHARACTER = 0] = "CHARACTER", e[e.NULL_CHARACTER = 1] = "NULL_CHARACTER", e[e.WHITESPACE_CHARACTER = 2] = "WHITESPACE_CHARACTER", e[e.START_TAG = 3] = "START_TAG", e[e.END_TAG = 4] = "END_TAG", e[e.COMMENT = 5] = "COMMENT", e[e.DOCTYPE = 6] = "DOCTYPE", e[e.EOF = 7] = "EOF", e[e.HIBERNATION = 8] = "HIBERNATION";
})(k ||= {});
function me(e, t) {
	for (let n = e.attrs.length - 1; n >= 0; n--) if (e.attrs[n].name === t) return e.attrs[n].value;
	return null;
}
// node_modules/entities/dist/decode-codepoint.js
var he = [
	8364,
	0,
	8218,
	402,
	8222,
	8230,
	8224,
	8225,
	710,
	8240,
	352,
	8249,
	338,
	0,
	381,
	0,
	0,
	8216,
	8217,
	8220,
	8221,
	8226,
	8211,
	8212,
	732,
	8482,
	353,
	8250,
	339,
	0,
	382,
	376
];
function ge(e) {
	return e === 0 || e >= 55296 && e <= 57343 || e > 1114111;
}
function _e(e) {
	return ge(e) ? 65533 : e >= 128 && e <= 159 && he[e - 128] || e;
}
function ve(e) {
	return ge(e) ? 65533 : e;
}
// node_modules/entities/dist/internal/decode-shared.js
var ye = /* #__PURE__ */ (() => {
	let e = /* @__PURE__ */ new Uint8Array(127), t = 0;
	for (let n = 33; n <= 126; n++) n !== 34 && n !== 36 && n !== 92 && (e[n] = t++);
	return e;
})();
function be(e, t, n, r, i, a) {
	let o = e.length, s = a * 90, c = 0, l = () => {
		let t = ye[e.charCodeAt(c++)];
		return t < a ? t : t * 91 - s + ye[e.charCodeAt(c++)];
	}, u = n - r, d = n + i, f = new Int32Array(d);
	f.fill(-1, r, a), f.fill(-1, a + u, d);
	let p = new Int32Array(d), m = new Int32Array(d);
	function h(t, n) {
		let r = 0, i = n, a = n + t;
		for (; i < a;) {
			let t = ye[e.charCodeAt(c++)];
			if (t < 89) r += t, f[i++] = r;
			else if (t === 89) {
				let t = ye[e.charCodeAt(c++)] + 2;
				for (; t--;) f[i++] = ++r;
			} else {
				let t = ye[e.charCodeAt(c++)];
				r += 89 + (t < 90 ? t * 91 + ye[e.charCodeAt(c++)] : ye[e.charCodeAt(c++)] * 8281 + ye[e.charCodeAt(c++)] * 91 + ye[e.charCodeAt(c++)]), f[i++] = r;
			}
		}
	}
	h(r, 0), h(u, a);
	let g = new Int32Array(i * 2), _ = 0, v = 0;
	function y(e, t) {
		for (let n = 0; n < e; n++) {
			let e = t + n, r = l(), i = l();
			g[v * 2] = r, g[v * 2 + 1] = i, v += 1, p[e] = _;
			let a = (f[r] < 0 ? m[r] : 1) + (f[i] < 0 ? m[i] : 1);
			m[e] = a, _ += a;
		}
	}
	y(i - a + r, a + u), y(a - r, r);
	let ee = new Uint16Array(_), b = 0;
	for (let e = 0; e < v; e++) for (let t = 0; t < 2; t++) {
		let n = g[e * 2 + t], r = f[n];
		if (r < 0) {
			let e = p[n], t = e + m[n];
			for (; e < t;) ee[b++] = ee[e++];
		} else ee[b++] = r;
	}
	let x = new Uint16Array(t), S = 0;
	for (; c < o;) {
		let t = ye[e.charCodeAt(c++)];
		t >= a && (t = t * 91 - s + ye[e.charCodeAt(c++)]);
		let n = f[t];
		if (n < 0) {
			let e = p[t], n = e + m[t];
			for (; e < n;) x[S++] = ee[e++];
		} else x[S++] = n;
	}
	return x;
}
// node_modules/entities/dist/generated/decode-data-html.js
var xe = /* #__PURE__ */ be("!}.&u%}'&}*'~!6*)%&,~!J~!J~%L~y<~!R,~~%Lu~~#GD~~#|)1#%}^%}2%+#.##%##%}&%##%'#%##&%#%#'%#&#%#&#'#%%#&#%##%#)%''%&%#%#'%#%%#%%}%%%#%#&(23#%%#&-%0%('1#(##%#'##+%'*.:1}#%#6-+(%'%%#%%%}#L'2351&('%}&/N'(0(/*-%(%%}#'+&T%7.2}#&%&#%#36/5##%&%%#&#%%#))2%%##%&&'0~!#*+&'%1~!%).'3q?&%'1~!.##%6(~!+%%%(Gw'rT~!E#<nA%#jZ~!H%(~!42##~!*31&~!G%U~#)5~#`3~!J~!Z~%]~%Y~%C~!q~!u~#kz~%#~!6'~!D~!U~!?~#T~!c%~!G#'~%7|~!G~!J~!G&~#pb~(Df}#%}*&}#%##%##%##&#-}&'#'&%#.++}%mI,#,@&(}*%}*'%&##&#%##%}&0}#.},U},%}+%}&%}#%##&}B%(}(%}+%)})%##%#&}&%##%&}<%}>%#%&}*%}(%}9%}/%})%}*%}*%}?&}&%}3%}&*#%})%#%#)}#&#-#+*%E%%'%'#%}#*V##&##I}#&&##%&%#&&Qf%%))w/0+&%#(#.%-''''++++7}>%4'',##1,#%#&%##&#'##&#*#9)%&%}#*}%,#+P(%A&%#'&##wSD',9E00#y#@}(+}&%&>~!#~!X}#*}(&&}(&}(,%}%&#+&}#&}I%#%}%)#(},'%#*}4%%#%}(''}#/##(##),%-##%%)#&}(.}&%#&}%%}*&#%},&&}&%}#%*'#%})%}D&}&%}-&}6&#&}-,%}#%})-(~+`~,=?~I9'9%~!,#%})%})%}@%}?%}(~!?~#<~#pP~#BG~#=1#%K+~#?#~%;)~#A~#mF1~#A'~'X%'~#lR~#N~'N~#r~#m#-~#i'?%#'%~#B%##%,%#~#_%#0%~#]732~,w~2+#:&#%&'0%&>%}#>##F+)#%&&#(+_}4&}-%}(&}@&}O7Fdf0@+/v4}&WU##&/0#&'('B#%}.%}'+#%}#%%&#&%#%##+#&#)#6#'#.},%}c%},%#%##%&#&%#&~#>'*-.%##%##%}#%%}%'~#)D1}#%*&~#_%%'(~#S2%'.}#~#=##*'*-%}&'%'##&&~'E%.#&~#M4}%%##&'%#~#O1##%&#'+~#<B%##%%'%+~#;#@%}#&%#&&%#(~#H1}'%'##&&~#?A}&'~#D#%32}'&&&&~#[}'(#%}'~#;C})&}%%#%~#=&%,3}%'(#%%~#^'#&&)#%'~#Y%-~#d-%'~#^%%&#&&&}#~#b~2t*&'~&(~&@~0%~e~3}%*''0})&}+~!9##-}#%-hD*)1fC#%/&/fB#40~!+#)*4~!+~!K'&:~!/*7~!.#~!H~!L':~%x&~!H#~!*~%1~!I#~!+A~#p'~!F~~#-#~,,(~.Z~!V~%;'B'mq-W~!N~%I%#&&#&}#%},%%}'%}+X#%}#&}(%}'%}<%}#%}%%'}'%}:~![)9@~%>~#UA%-%##&~!C%~!-.9:~!1~!-^2/:a~!y,D*J#-5)/4~%23,~#G~!L1~!0X3`~!2+~!!0-~&E~!W~!o,>Y&]~%cZx_&~#O*9#A#'#+I'%#)~!0B*-5A+-((F&*M#)(-7-5+'-3a5Vi~!Y~!?+[)%3),ERHm~!+:D,VG.+)?fB%%*(%)'(#&80%1'8`K8?`+'Z#&O&'H5#*9)A%%5&3))0%39+.*7#()&&*=4@**L)<'_&*+..;(#*+)./&0#3)%')-8(4ixD(&.}%,('aI:,)%,k2231T)I'#/-W7,/'Q#.'Y24+h')37</31&83##&0#),H(?'&?/1##%#&&#%''-%&&&#(&''&#.-'%#%%(,')*'&#&#'##%(%(#%('#&##%%%%('%#%#%%#%#&%##h>w+v<ayvyvcg.uuhKr}g/v|g>u9i[~>g5uI~=RvdwEg;v/g;uk!!TTSx]@RT!U!#!@VBRUU!'UTe-d0c`e&gSdicedFcrdTaqb.kYcAohdYd@a3e+d}dMdtd.aJ#bqcK`dle/e.e'dwdPdodddjbEb}ogd^ofdpduc6j?l%d{drdqc)d7bacOdQ%T#Y)X.sR[yH>6Vyv3[xwLu>vo'!*.[yBacahoj>6Rew3[xqdZa#!a&#^(X-[yG>6Vyu3[xvg3sEr|g.u/Ri9db0T#^(Xa)!-[y;>6Vylg4wKs{JwNZt3@3r=c4Z([xlg;wKt!cpq's@v7A'*a(a+!-a#[y<3Dt?3Dt'>6Vym3[xmg9rxsNJwLZt4~?r?db1T#`-!(Xa,!0[yS>6Vz%NuQs.g4wKtnJwNZtS@3r>c4Z([y%g;wKtrdga8!a(!#&T*Y-Xa#!a0<or[yc3Dtq>6Vz43[y3JwNZtf@3s!Ju}!%Dti:pm3c_%X#tjB5pkd6q!r]u?voC'*-a.a2!0a&a+[yI3DtI3Ds~3DtH>6Vyw3[xx;:s#~<5pKJwNZtE@3r~d`a)!a2T#a.(!+U.X1[yT3Dt`3Dtv>6Vz&3[y&g9rxwzcxstPu.<rAJwLZtT~?r@dZa%!a.&^*Za(/Reu[ya>6Vz23[y1g3sEr}wkg{NuQRg{ci(U#5@b`~,cg#U(2WnH5wugcRh7dX#T(Y,a'Ta!!a,[yZ<]mj>6Vz,3[y+Pv#5ReZKu+=,%!H}7ABwkaS?Rh:BcW(X#<]mrj:ubv/ARekdg%!(!a.*Ta(Y.X1!#sP>Rl*Dt6[y>>6Vyo3Wf*jOvuumvuRgRJuq*!:9<B@bX~3jVv&v@s@5Re[d/rQt{uAvo&a&a*)a2!,0Wf!3Dt0=Bs'>6Re}3[xy~<5s%JwJZt1~Gs)c;&!#2sJkNuXvzq7rxu,Re8dka4!a8(aEZ+a@Y.X1Xa)[yd=Bs(3DtP>6Vz53[y4cX#X&Re:avRe9~<5s&JwJZtQ~Gs*i^rzvdRg+Jv{%!2sbB@bX}kdga,!Za?&^*T1/!a'Dt+[y6>6Vyf3Wf%g/u;s4hGu6?Rh-JvZ,!c%#&RoX54Rivj7uyvf8RgTKvZB%*!2sGh<vu5Rgq<=C::9bb~#dZ#T&Ta6Y.X*Dt>[y93Wf)coZ(T,6VyifluvRgC@95@B@bX~/hFu34cC#T,k/unq8w8Q5RkUklwQuzunq8w8Q5Rk8d/rJu?v8w9)-&!a0a;a&aIWejg3sEr/h1s<DtDJvyZqY5aws3Jvy!&Wei~Hr1:au5@Bag>23E~5c:Z&bX};kKv?w&unuVu5Rjc;>bs)#~@:Rh.=ay<a]C;b`}Vd6s/t{uAvoaxa()!a,a7%-a#a2Dt,[yF2Wo[>6Vyt3[xuNuPRi&NuPwpi#RoWh?vf8Ri%Jv]!%Ri:KvxD!.'2WeAjZu`q9rxu,Re7woeAg-unLq(qA_/*2Wg_g3u5q^9:4E}/jTrxrzv=Wkkd~0UX#^^Xa-a1a5T&a=U1a'*aEa]!a*aPaA-adok[y54Rn>;:p3~Dp5g9rpsFNvZqjg3uJp4~<5p0Pw;5qlJwNZt*@3p1Pw:5p/Ou!5p2JvG'!6Vye=<qnJvh_[xhg3v,Rh3kOwOw-sDuev/Re^dha[a%!%!a+#Ta7)-5TaCaO!aka!a)sf[yb2>Rl!9ARiq5E}Qg=ucRkBE|oJrJ_@Wk~@Wk{JrJ_@Wk|@WkyJrJ_@Wk}@WkzJvO_[y2g-vMRmiKuYC!)&>Ri;>Ri<@3RkNc](X#@9Rk=g5vuRmhKvDB!+'=]meg3u4Rmgd)#Y'Vz3CARmfd`a+!%T'!+#Ta1Ta6TaM-sTDt9[yA9sYd'%Y#s[[xpj:ueunaXRgEjRq,v-vuqdd2'`#6Rev<32@5>:2<E}5xIo9a*X#Y(;5RePJvD_g>vyRgNj8w)v8<wggs:RgXiZt|vjx,hSq3ah!-(~@:Ro/Ou!5RhWj^v(pyw8unRhUdx-UY#^Ua.a3a70!)%UX1TaDa)'omRiRRhE[y:3Dsz=Br,>6Vyj3[xkg6ruwjcqsrPw;5r*Ku]D'Zt-@3r(~?r.i[vwv]dU1a--U#`a4(g/vsRhPOu!5RhLj:rmu9Wo!~@:wdh@g/vsRiTjXuvvNr}:RhBj^v(pyw8unRn]dz1UYa'a+^Y(!aETZalaRY.Ta?a4[yDJw1!#qLsW>6Vyrfzq-pLflpwRe|Js>%!Dt@3Dt&Jvy_[xs~HrnjMuwpsw'RecKu+D#'!t<~Grl~?rjg5u-x,gwp{ah!-(~@:Rg~Ou!5Rh'jXuvvNr}:Rh#cW#X/c;&!#2sLi[v7u7RgpJv)(!iLrxu,Re6j7v@s@5Se[e7d`aW!Za(a`T.a#!a3!&aDa-!9)Dt_=6s+3[x~~DR|h~DS6avhGun5RkZj3w)v-]mkKunB!&*]kb97R|i<ARk<c:Z(6Vy}Juh'!wziMRoS:F|vkLuauJv5vtvQRh1d='T+Y#VyO~DR|jcF#T'7R|g97R|kJv3'!ay<Rj,Jvh&!:ReXcsa6*a+#a#_aIRf9aLRf?c,Z&Rf5Rf7c.Z&Rf;Rf>cQ#%T'p-Rf8Rf=ct#%'(*!,p,Rf4p+Rf6Rf:Rf<d~'Ua%U*^UYa(!a,-!#a4YaTalaEX0a8a<Weo3Dt/3Dsx=Br93Wen~Dr;~<5p<JwNZt2@3p=Pw:5p;Ou!5r3c7&!#:p>3Ds}KvGB)_6Vyk2sM=<r7x'eovA(!hFu1ARf}cV#X&@r5j6rvwQa^Rf3c=Za'wkghJv__g;unRggA53B9=b^}%j6uduo5Jq;!(hIv%2Re`Ou4ARe_e%a#^^^Xa&!a*a2!&a6YaP!*ad!#a:aE/5Rn?[y@>6Vyp;:pE~DrY~<5pBJwNZt8@3pCh=rt3rWPw:5pAJup_[xoNuPpF9c!#'45pD5ARn)d8#X'X*3@rU72s]h>v<<sSjJpqvewOJq/(!hNw'5ReBk0s2u3w/w'5ReE5@Jq.!a+JQ!&WeU23d(#Y&RjG5]jBk!u7w&u0udARjEe#+^^^Ub#!a2/a`Z(agT1!a-a;|@TaG!aS[yV=Re~fow'RguNuPRe?bz#'>RoUWeL>:Cbb|?JwPZtVg6ruRmzJvD'!6Vz(g/vmRh~Jvy_[y(g9voRgyx*cy(#2>Ri2B9b]~9kIw9u7rluJu3Rg]dI#a%UY'@=p%CAx.gQZ&RhwwygtRm{x5g_Z'+ABqR9Woa=Bp&dV#^*Xa'!&@o{g4v]Rk;Jv{!%Rk[wkkiA5RkiwwfUB=x,fUuqC&*!>RfTg8v0RfV~ARfSd;rJsAuAv9wR'ae+/aO!a@aza/a#[yQ@Wg!2Wemg3sEr0JvB_g>uvReWg2v+Re=KupB_+[y!2AbY~-~Hr2AJwD!(h<~El>h<~El?Kun@+_:9b`}Kg-v/Ri3g;vtwyk_9]k_d=&T#*U.6qh@Ab`|K9:H|CJv[!&3Dtex'fDwC%!Rf[9WlMd[(^X,!a%Z06Vz!@WgBg=v~Rgvg,QRe@awd,#Y+jTv|Q~EfWj]uNr|~FRfXdy#Y&^Ua%!aO.!(a)Ua;=!a@aKap!a-,a!Ta]a[rSa]p?[y82sK=Bq~;:p:~<5p8Pw:5p7d'#Y'Wf(;RnRi[u4w&RgJJvG'!6Vyh=<r#ijuuv/sIKuYD'ZtG@3p9~Gr&d2#`(g<vtRgFj`u5w&rqpxRf2CJuY!+:wfnTOu!5Rg}jNs1ucv&RfwJvA!&3@q|BDcC#T,k/unq8w8Q5RkTklwQuzunq8w8Q5Rk9dga#!a'!a=#a0!:+Tb*b@aO.a4!aba8aFJv^}?!VyR~Dr<g;u%Rn.~<5p[x'e`wNZtR@3p]Pw:5pZhNvjBp.woe_g5u-r4JwF!%DtO3:ooc7&!#:p^3DtpLuGw(!+%)Dtk6Vz#2sd=<r8d'#Y([y#<x3gJt`w@!)%}MRiowzikRij=]ilxAf3,U(#B2Rf#g0v-Rm[ck{`U#]giKv3>)!&6Ri154s,KuGB_%@r68r:dJ|t`#X(9<E|u2@H|rx3gJu?w'!+'1Nu7Reg4=H~+9<wxgY95Rm]xLggZ-`(X}U2:Ri4h<uOawRmsJv__5@bb{jbV~3dka#a'a]!,#a+U=a>b6a3b%!/aKa/)!arwve^VyJ;:pR~DpTg3uJpS~<5pOPw;5qmPw:5pNOu!5pQJvG'!6Vyx=<qoJvA!{~Jup!%@qk7Rn/KvyD!}''[xz;>wkh'?Rh,x8gyt`w5D!&),(SgyccRgztJ@3pPB5p#d'(Y#<]mmifubw&RgoJvE&!82s^JvF&!8Rf,ADb]~;x=h'rNu]vK!,%'*0RnORh)4Rh*AqQg-vaRnNg;wHwkh'ba~4cE#Ta*x3gctyw@'!+%RnFRnD<4Rn@hFvK5RnCxWg[#`&a0Ua()`1Rm75Rg[c]%X#qi8Rg^NvdRj>BwzgZauwji7Rm6A4wgg]d1#&(*,.0a#Rm;Rm<Rm=Rm>Rm?Rm@RmARmBe%#^^^Xaea?aC/b+(,!a+a#!a/!>a&Ta<aKbD!2wphBRnk[yPw}hE|.=Br-3Dtm>6Vy~g6urRf.x,hPrNav!%'RnqRo%Ro#Nu;q[Pw;5r+JwNZtM@3r)d'#Y'Weh;xChL#`&RnmRnoKu}>%(!Rne~Bs-;2wjcussJv+'!aYSO}6@B<5?ba~8LrNvj!.%*ROwungw~ng~:9;Ri^>wtnig;wHRnixDh@|(UZ.x1h@|)!#:2<H|*xHn]#-UX'3Ro)z=iT}6ARns=Bwsn_wpnaRncw]aR(#UXa&Ua*a/=]iPd'#Y&Ro'WnXf{QRm2hNvj]nZd`'T~&1`{|`#9b]{}c:'!#Wl{>@=be}]?cl{{U#:5Abb}Jds#^YaF!a*b4a#a3aPa>&Tb!bH!*a_!Eau?/a&RjY<]gj>6Vz*;:pe~DrZg,QRj1JwNZtX@wihspcJvZ&!VyX9WmOJu|!|N2WmHJvh&!]ht~Bpbcn&T(!#RmQ<s7Nu;padH#X'`+WmJ@>RmKCARhnKup=!)&Wf+:RhqNuPpf9c!#'45pd5AwghpARn(Ls@w!%,)!RmP@Wfe<E|IJva!&WmNg8vsRmLd`*.`#Y'Xa!axRn*]hrA8Rhug5s@rXg8u!RmMd8#X'X*3@rV72smdI*#UY&RmICARho~GsgxVgd)Ta'U-Y&Xa!T#RnEWnA@Wffg1uDRi0hFvK5RnBxGnG&#`%owp)@wsf+bX}Ze-*1!a*^^^Ua|!#a.aq&Ya2!a>.a6!a:aO`aJDtL[y`@Wg#>6Vz12@wzoYRoZNuPRi!NuPRhzg=ucRi,@=b`{Yg=ucRi-ACJvB!&Sh[ebSh]ebi`wUuFRm4Jw2_[y0JvB!.<Ju(!&SoG}6Shd}6<Ju(!&SoH}6She}6Kur@._g5vHRieJvx!{L2G{Kx6gd'T#?Rh82Wi5cZ#X(g1w)Rm5dW-Y(Ta#!a)!#aYa=wnfE=su2>>bU{0j9udv:<svj8uQv-7RgHdE%#^'sq9sp=>Bb_{TJv`!&g/r|snj6v(us5d,#Y(56H}[978H}]Jw5!&g1rushJvB!+j;v{u5?zDhd}6}bj;v{u5?zDhe}6}ce*#`(^^^a[aea!=!a6a*aoXb1a.!aAbL!b>,b'aL!aV@Wf|2Wlg3[y/JwNZt^@3piPw:5pgJunZou3@rsJva&!Vy_g<v~Rm#JvG'!6Vz0=<r{Ju{%!:pj@WfsiXuJu3Rm:JvZ&!WfA~Bph@c4Z&Dtwax5rubx(#:awRk1@d,#Y&RfjRfid1#,Y(@Wfp2Wlrg5s@ryKu[@!,'=]ig9wlk?Rk>g5u-rqJvy'!@9RkQcH(T#=>Ri~@<wkj(Wj(KuZB*!&<7rw@9RkRcH(T#=>Ri}@<wkj)Wj)dg(Ta2Xa9X#`-!a*CARhg@@=I}d9x;c~#X%so=<sj>2@@=aybb}XjWv0Q~EfEj3vLv;<d,#Y(56H}`978H}_dgaPaFa'a/!#a3Y0a_a;a|!1(a7-[yE3[xt;:pJNvZrrg3uJrvJwNZt=@3pIh=rt3rxPw:5pGOu!5rpJvG'!6Vys=<rz@c4Z&Dt(ax5rtJvZ!&~BpH@wsfNg-vaRlNci*U#=<wei<F}a5@Jq.!a*JQ!%@qZ23d(#Y&RjH5]jCk!u7w&u0udARjFd/prq=tyvpaEa(a:.!a1aZ(@@=I}:9wpd%=<sX55w_h}@@=I{t=ay<aU@@=I}T=ay<2@@=I})?C9:9au@9Cb]}DP~=x-fAZ(2Wl1=ay<aU@@=I}>5@d##Y+jTv|vV~EfFj]uNpn~FRfGdgaK!Z2&!a8a-Tb({E!acTbM*!a(DtY[yYd'%Y#sl[y*hHvh>Re5x2c{Z}.j4uCvcawRiMd+#X+_x&d!},<5RkX;2Hzw@x,gavfB-!{CcF&T#Roe;RodwWbBg5urRgaKvHC*_6Vz+<4opieuew&Rmq@d]&Y)X,T#X0Rh}<BqP=4qS9:ReMg/ujReNJw0!/<Jui%!bd{kawwnemRelAxUa?a3#*.&UX(Ya+a/RhvRnQ<o}9Wmtd-#Y&RgSRmw9;Rmxay=Rmyg-vaRmuxEhSrNu,v-voC!%(aR.a(a7+1Ro1>Ro5CE{A9b]{@;5x#eO{:g;urRi+KrNA!%(Ro3>Ro79;Ri_Ku@>{;&!x%gX|{KunA_+g5QRj/g3u5Rj#g>uERj%wio/xRhS&!,!#^1U}wba{8>>@=be}qC@:D5ba{7Ku+A&!}x?ba}t>>@=be}se(aA^^^Uat!b0#{pa+awUazbGa#aLb9bgaWac'a5TbS=Br!d1#`%scp_Jvl!#rT>Re0JvX&!VyN=H{Fcm#U&:pY=ReaJv2&!]h0=]nUJvG'!6Vy|=<r%JrM_=]h2@Wlud'#)U'Wf'b]{i=]h/Jvh!&~BpWg=v]RnMx+ny#'Nu;pVwjnu=]nwxJnx,T#`&Reqwjnt=]nvieu9vrRjLLuYwP(#+!th@wih5pX~Gr'g5v/Rh4KunA'!-CARnP@wwiN:Rm_9x'cvw>!|l=<saKvAA!0&3@q}>w^e1bp#&Re2Re3BDx7gH#T|f5H|eKuZ>!%(:qNAH{]Jv6!+3B2B9=b^{X<5<B92:E{ZLvhwA(a;a%!igQuyRmad+#Y}m@3Rh5d8#X'X*:AqUAHzmaxwbh<aXRnVcF}RT#Nw&cj#U(BWnug/vsRntdka)(a3+.Zb7aYYan1!bVa@Xa}[y^@b[{G=H{+hFu73Rj&Pv#5ReQcK%T#sig1v{Rj'Ku+D#'!t]~Grm~?rkKuMB!01d5#`'Vy.ta3Dtu~Hroc8#'{^45s85AwZbP&!#Rn!wghxWn#KvEA!)&2RlA2RlBx:h|#(T,=]j09Wobz>x]z/@awRoTd+#Y(az]hFhCrm4d,#Y+jTv|Q~EfMj]uNr|~FRfOdCa!Xa9_X#@<plJvf!%b`{(9;Rgwc;.!#2x7cw#T|UDb]|T5Ju={(!=@E{&Jv)&!Ab`{'awJvf!~*>>@=be{#KuY>!+&4Ezyi[ugv&RjIdea+T)#UXa&T-T&a!Rh9auRmW=]kLg5vuRn+g3u4Rn-Ow6ARn,hHus5xNk?#UX(U~)/g8v0RkD~AwkkF?Ri.OuNBwkkA?Ri/d|a2`a*^UYa.!aBTZaTa'Xa;!(!2!-a#b2[yC>6Vyq3[xr2Wi?g1rusVh%s?DtF~<5rbJs;%!DtBfswKtCj[uvuSsEu3RgVx3o:u+wN'*Zt;@3rd~Grh~?rfg8w)Lq)qE&-a%!>bI|`jWv0vV~EfCjTv|vV~Ef@j]uNpn~FRfBcK#T']gWNu7x,k7q4ai(0!hHv8<RhmkMu9vrsBuev/RhlCJvB!,g<v{wchh~@:Rhji[vrv{wchi~@:RhkdS&a5UY#Ta!RgPwwiI5BwciI~@:Rh`x'iJvj'!5]iJPu8Bwch]~@:Rhach)U#h3rp]gLh@t|Ax,hTq3ah!-(~@:Ro0Ou!5RhXj^v(pyw8unRhVd|)`,^UYas!a?/a2Z'a^Ta{Tb7Ta(a#!a,Wf&9sZ3DtAadamov=Bqt3[xig8vsRm~>waiL2b`{QJv*_Ouv2qgj<v]v2BqfdR'X*X#Y-@3qr~Gqv~?p6hHv-]glPup5Lq+q?_%*b_{qF{n9b^{rOu4ARhpKvCD!+&~Bqp:5Dbb}nwoiKl&unuTuBv]v+ueunaXRf0=Jvh!0nKufu8v1w&w7q%w&uHrz:Rgnj5w,uxDJq/(!hNw'5ReCk0s2u3w/w'5ReFd>Za&!*UaA=<wkgsRnSJv^!%Refifw3vyRgOKu_B'!,<]gkiiu:w&Rh<=C@a^<B57@2F{[<B5@aW:=3away9A5aW=<B=C@a^<B57@2F{Ie-#`(^^^bCara.b8aza6!/bZ,!adTbnTbOb+aFaS!aAT9@Wf~2Wli3Dtl2@d,#Y&RfnRfmJwJZtN~GqyJva&!VyMg<v~Rm%iXuJu3Rm9Jv[_=]ih9wlkDRkCd1#`(@Wg>2Wls3cH#T(@<Rj*=>Ri|b~'#23s9h<~El.d'#Y&Dtxi^rzvdRl#d*#U%(o|B2s`hJwSaxRmDKv4B&!1:Rmdd5#`'Vx}to~Hq{x'f1v3(!BA5ba|bJv_&!Wfug1v]ReIdO+U/Y#&G}-8wze=Rh{g1v]ReHg/uQRf/by#)ibQwERl/cH#T(@<Rj+=>Ri{cNu+vlax-!(#a0qa9<Rii2;;bU{H;x<i=&X#Rk`<4wwi=C9H~8xAI(Y#<azRi@45wXI<B9;5bb~7dL(X#Xa(+!aL6Vy{g5QqOau:5au2@ay547EzbxOcU(UX-T#Ta#:Cbb|A?wjh/b_|SOw6ARgtihr}u7Rhy<d1#T)X1@@=I|~=ay<2@@=aybb}Sj3vLv;<d,#Y(56H}A978H}@dGpvs@uAu`vcw9*!aFa+ai%(b!aXa8.a?a[ozWey=sU2@G}Nch&U#Rf_WexKu+D#'!t:~Gr`~?r^j]uNr|~FRg*j^psurwJt|RmcKv)@&!)7Rkv~Br[@wxfO:Rl3co#U'6Rezj_q#vIuavjRltwzeyh@vr5JqD0!>aY?C9:9au@9Cb]}9cl#U*5;5<H||jbuus1ucv&Rfvg1v~d/pppzqFr^a--a~!aMat1(hFv;Wiz@@=Izoj5uuv-7Rix~Cw`fk2WlVcZ#X,k)u3vWs@u2]ktg;wEx'fBq(_2Wg/jTv|vV~EfoJv]!15x'hzqG!(P~EfU~CRl_j6v(us5x4i-#T(2WmZ?C2F|d>Kq<aj1!*jTqIsBv=Wl`~Cw`fi2WlWj`v0u*~>RlR=c>Z,k#u3vWs@u2]kr<c1Z+jTqIsBv=Wla~Cw`fm2WlXdmb3!a{(arZa`bkTa%TbQTa-a9+c'!aM!/[yL=Bqug.w'RifhFvyDRj.g>vgwyk^9]k^Jv3_@WfbAARkhJw2_[x|JvB_wkoIRoKwkoJRoLd'(Y#<]gm=<9<H|yd'%_X#skDtb3awwqkgNulRkgdB#^',9:p'hJwSaxRmEBwVb8@4=H|qLu+w50&!)@3qs~?pU>Awwn;;Rn=c:Z'ARn<=<qwKvC@!/&~BqqJv6!&]eVb^z^xRge'/a%+^`#Sge}6<4Rn3=]n0Pw2>Rn8Jw0!&>Rn:>Rn6cY#a7+!a&=<wkaNw~h3z_c5Z{=wjh#=]nLKv^D!&)Vyz=bW|swYb<WetcG#T(2wxa@qVx@gD#Y&b^|V5JwG&!5bb|pg/w&RgD@x=kHs=uAvn!a%%/'+RmSRh694Ro`g-vaRmRhHv-]mlxCcS#`&ba~.5cD#Ta)P~=d,#Y(56H{>978H{Dd_#{2^Y%_+qbbb{6g3sERhsbU{?dfa.,`a(Xa<!aiX#(55RiG54RiHcI#T'WiU3RiVNvdwtfcRlKNvdd,#Y&RlHRlExQgf.1*^T'X#Sgf}6Wn4=]hfPrk>Rn7Jw0!&>Rn5>Rn9Lunw?&a2!,5<oq@@wqfdRlJj5Q~=d,#Y(~ARfcOuN]fdDKw;ay(}i!547E}j?cI#T(@5bV}iCbV}hdv(^^Tb?a40,b##Tbo!a*bR!a<b|a/!aKai!aU[yK=]o^g:v>ReGJwPZtK<7Rh+h<~El,Pv#5ReR@awwxjCg,ulRjDJv6&!]j!z?aQeeg>w=Sh<eeJw;!&axEzOg,Qosc!#*:wkeJ]eJ>x'h-u(!%Ro.w~h.zPdNZ(X,Ya![x{;9ReY;wkgxRiF:x?ap#Y&RmUg<s2Rkod]+UY0TZ'!a&A9sw<=bczLNvuw{gqzNhJwSaxRmCKuLay!#&s_Rf-55b^{uJvZa!!c%#(55Ri654wmiu5RiuawLu,vp!+}^%b_}Y9;wkgxba}o>A9:=b^}zKuh=a''!3awRk3c*'!#aHRk6c+Z&Rk5Rk4Jv)&!awRjSawd9*`#0?C2@EzMj8u<uJ5RmbjQrquJu3x,k>uq@_+=ayb^|W~ARkEOuN]k@7dhzV^X/X&a-#zRzSb`zXcJzTT#2WkVKvDBzW!%FzY9;5bbzWjQrquJu3Jw3%!b`zU=ayb^zQd:#X(T-a!6Vyywxh}=b]{Jg=u1RiAdGp~qHtzv!w(wA+a+a;<!aJaYai'anasb(=azRmV:Cbb{MLq2vb!%')RjuRjrRjtRjqx3jnqCw3!%')Rk(Rk+Rk&Rk)Lq2vb!%')Rj{RjxRjzRjwLq2vb!%')RjsRjpRjfRjex3jcqCw3!%')Rk'Rk*RjkRjl9<CbbzfOu4ARhxLq2vb!%')RjyRjvRjhRjgx=joq*uKvb!%')+-Rk.Rk%Rj~Rk-Rk#Rj}x=jdq*uKvb!%')+-Rk,Rk!Rj|RjmRjjRjidAq&qKs@uAv8Aa.'*-a@a&0!aM@a5[y73Dsy3Ds|3Dt):wxgI2sHJwJZt.~Gqxwsf0ikrzt}Rl0Jvy_[xj~HqzKv_A|D!&WfP8axRoVcf,U#k(v]v+ueunaXRf1Ju}'!g8u#Ri=jQw!sCunLprq>!,')~<5qeGzq9F{W=c##%s5au:5aU3CBE|;d4#X(D!a&6Vygx(b;#(=]ed?C2F{N<capoq2r[a&!aPa9,'Pw;5s:@@=I|,55w_h|@@=IzcP~=x'fCqB_2Wl2>aU@@=I|1OuNBc1Z+jTqIsBv=Wlc~Cw`fl2WlZ~AcTa%!Z+jTqIsBv=Wlb~Cw`fh2WlYk+uNqJsBv=WlSg,u3dca3#UXaMYa)TaB-=cM|7T#<bI}l5@B932:aV2G{BOuNBJq:|M!5Ezt=<B=C@a^<B57@2F{v>cB{/T#=ay<bI{3Jv6!a.6BKq0ah&+!5E}HP~Ef{978BaU@@=Iza<7d#.Y#978BaU@@=IzH~AJq0!(@@=IzG978BaU@@=IzFe,aU*Y&^^^bvJb,b:bFad!a,c2Ta>aL.bo6!a#CbTa'T#Re{2Wlh2@G{yg6t~Ro_NvdRfticuRQRllJv3&!x&c|zs@Jw3!%RflwpfkRlpKuL;%(!Re<@G|C2GzdhIvuBwgjAg-u0RjAKQB%!(GzZ@G|5NuuRl7d='T+Y#Vy[g<v~Rm!==G|>JvA!)@wma=]m1ifuaw&RmnLs@vT'!|/+[y,g:v>ReTJw1!#qX=x!eC{bLu+wT&)ZtZauq_~Graci&U#F|89:r_Lupvq!.)&2RlG8RfaC=x!eF{_h?rpWlmd&'!#X|&]k::xJey#`'T|+<E|&2@H|%dE#(^,g;u.RiEg6vjRiC9xCkA{O|zY#g=ucRmXKs0@!&*@G|m@awRknJuh!,3d(}gY}eJvj!%Rm):Jw3!%Rm+Rm-Ls0w(&!a(a#@b[|6cZ#X'7RkxWgAOu4ARn'dH'U#Y*Vz-Wm'CARm}d]*#a%^a*T'aK!a<9bV{PC=p*Jw4!&SgxcbB5r]idw(wBRmF7xFkt#&`(Rm/Rm8E|!JuY_9:Rl5=wrgr2:bbxd@xXfB(a*#T+!.X0X1Ta/a'T&RlDRfL>RlyARl9b[z[>RfZ:RlL:RfRwlg/ARl;9;RlxKv,A/!%7s69<74=BA5ba{-8Bde#`a<XaKYa1,a'P~=wxfB2bZ}}?C972@@=I}r8@55B9;5bb}G978B2@@=aybb}3j3vLv;<Jw3&!>Rfk=ayb^}4~Ad1#`*@@=aybb{w2@>==<bbz]dx+UY#^UaF!a9!bB'Ya1.!ajXa#%olRhD[y=3Dt#Ov5BrHKuMB%!(Rf^Wep~HrJwkiQjKr|~FRg)Ku+D#'!t5~GrF~?rDdV)UY,Z/_7RkuG{<~BrBg,rlsO:235B@bX}|d?a1!#`(6Vyn5@d##Y+jTv|vV~EfIj]uNpn~FRfH7Lq2vb1!a9-978BaU@@=Iz9978BbU}#~AJq0!(@@=Iz8978BaU@@=Iz7~AJQ|}!978BbU}!JvkaK!AdUa21-U#`a+(g/vsRn~Ou!5RPj:rmu9WhOjXuvvNr}:RhAj^v(pyw8unRn[kPr}p|u7vwv]RiSBd;pppzq@qHQa?(b.!a.a`@.|xa(hFv;Wiyj5uuv-7Riw~Cw`fg2WlU978BbU|wOuNBJqG!(P~EfD~CRlQcZ#X,k)u3vWs@u2]ksg;wEx'f@q1_2Wg.j]uNpn~FRfqJv]!15x'h{qG!(@@=IzK~CRl^j6v(us5x4i,#T(2WmY?C2F{1>Kq<aj1!*jTqIsBv=Wld~Cw`fj2Wl[j`v0u*~>RlT=c>Z,k#u3vWs@u2]kq<c1Z+jTqIsBv=Wle~Cw`fn2Wl]dn1#c(a(b^a2!b/bAT(bj!aDa7bu,a_a{c0!2T0g:v>ReD2@G{42@G{5~DpM~<5rc=Bx6i>{RT#RnI@zCx]y]z:2Jv[!zr5Awyk]9]k]dD(Y+X#6Vz.g=wKtgwhaCwgmTWj2Lu,w%_+/[y-B;b^xeg3u3Rj-2@bX{*KrJ<!+'@Wg(g?QRlC@Jv`!%b[zIwsfII}8JQ_@w|kW|=Jv(%!AqcOuNBJvEzh!bYzjLs@wP#(0!oy@>RkdJwMZtc3Dtd@BcG#T'9bWxg2@2Fznd*#Y+;2x'c}w<zizixNgwa#Z'U+!/!a'!a+w~g~z6wcn{Rn}wcnzRn|5Rh%=]nJg5vuRmvNvdRlvcprJu}w*az*a#!%.a.'Bot9qT]kj@Wg'ay2Gzv@Jv`!%b[zEwsfHI}1;ck#Ux`<Cbbx_Lu+w!a&0*!wko*wwo,So,}6Juqxf!E}PigQuyRm`d3(`#8>Rn%:A5B;bZ~%KvhCa!a2!x>k7#Uxb@b{#xaRk7Jw0!)>wwhlShl}6>wwhmShm}6CJvB!.x'hhvj{!!5Bwkhhbaz}x'hivjz~!5Bwkhibaz|xEhTrNu,v-vpD!a%&/)a3a.,%Ro2t[CE{)@3re9b]{%wjo09:rgc:Z&Ro6=<riifuaw&RmoKrNA!%(Ro4>Ro89;Ri`dSaL'UYzxZb)7Rka3xRhT&!,!#^1U}vbaz{>>@=be}yC@:D5bazzKu+A&!}{?ba}y>>@=be}wxBh[t`u~vJvr!%a!a()a,a0a4RoC=]o;Ju(!%RoGRhdwjh`=]oAg>w#Ro?g5vuRo=NvdRl|Ku]C.!&;RoEJvB!%RoORoMBx'h[v+_?w~h`}~5?w~hd~!xKh]oiptu-utv.vp!#%&a30a@a'a+(a/aOp(o~p!RoDJu(!%RoHRhewjha=]oBNvdRl}g>w#Ro@g5vuRo>c[#X']o<CauRoRAd-#Y':RkpauRoQKu]C.!&;RoFJvB!%RoNRoPBx'h]v+_?w~ha}t5?w~he}ue!/UbhYacXaW^Tc&a;b:a-c/#b&aja1(!cL+!bKbt!bmcRc9aIc?8[yW3Dtt94Rg`Jv}!&SiRMzBhEebShEMNuPRe>x7gL#TzuwjirRipc<Z&>on;>z=h-MSh.Mwqczx'a7vj&!>Re4@=ResJt__NuPRi*NuPRi)j]uNr|~FRfzKrJ>_+@Wfy@Wf]2WocKrJ<!+'@Wg%g/QRl@@Jv`!&awRl<wsfFIzgLu(w*!.*&ShBMwvhIRhI9;RhNx1hK'!#Sn]Mx1hK~0!#:2<H~7cNu+w7D*'1ZtW>Rn1~?rOc:Z&Rn2=<rQ<7wjh&=BSnLMc]#X(6Vz)w[b=a!U#9wzgMc3#&(RgMRitRis<x,gKt`ax!&+SioM=BSilMc3#&(RgKRinRimKurB,!&SiQMzBhDebShDM6BJQ!(P~Efx978B2@@=I}WLrJw!!,a*&@G}O@9wkibRid@@x'fKwC!&SlDMSfLMjUv~Q~EfKKv3@a+!(hFv-]mpx/hYZ(C5RiWz<o/MwkhY?So/M@x,gbvfB*&!SgEM:SoeeehFu3:Rgbda(,^TZa)X/7Sg[eb:2RgI~BrMC@wgkc:wwkcRerx3h(uUvK!&*,SnOM4Sh*MArRg;wHRh(x=h;rJvPwI!a4',a'0@Wg&=BSh/Mg>w=Rh=g3w*wwgGRgGcW(X#;Sg}M2Gzk@Jv`!&awRl=wsfGIz`dKZ*T'Y-:RhR7RhQg5u-p`j6v(us5d,#Y+~Awkia?RicOuNBwkibba}Ld6p~tyu_vbAa'a+!a/'a3aEa8a!>Sh,ebJv{!&Sh@ebSaReb9;SgwebNuPRi(NvdRl)NuPRi'hHu^<Rm^Jvv_@Wl(g;u1Si/ebKu'B&!*Sh?eb@Wl'z@aPeb95Si.ebcpputyvjB)!,&a+0a%ShAMWeK@G}C@WfJ9;RhMwvhH9w{ia}ix,hJvRA1(!zAn[MRhHx1hJ~*!#hFv(BSn[MBJQ!(@@=I~'978B2@@=I}2db.Ua<'X}+T#a0XaG2G}E;wkg|wuh!Rh!x,hZu,@)!&So0MVy)C5RiXACJvB!&5RiY5RiZg8w)cG}*T#2@bU}=KsA>(!a.3wkhZba~(x,h^u(A!&(SoCMRhb5Bz=h[eb?w~hb~6x,h_u(A!&(SoDMRhc5Bz=h]eb?w~hc~6e)aA1T#T,^^^c-bMb&blcPaP(a/!0!bA=b5c@a(!bfbrc#2afwmhARnjwchORnp2Wlf3DtsNvdRl-2@wpa<]m0bx(#:awRk2@Jw3!%RfhwpfgRlnKQB%!(G{V@G|'NuuRl6d='T+Y#VyUg<v~Rl~==G|<Jv+'!aYShC}6@B<5?ba~8@Jw3'!g2QRljhLrpWlOd+#Y'g.w'rIg>w*wgj@g-u0Rj@Lu+wT&)ZtUauq]~GrGci&U#F|39:rELrNvj!.%*RhCwunfw~nf~:9;Ri]>wtnhg;wHRnhx3hDs@v~!/+'@Wfr@9RkSNu&Rlo=@<5GzoKs0@_+@Wl+@awRkmJuh!-3d(}pY#qWJvj!%Rm(:Jw3!%Rm,Rm*de&!1U-U#`)Re;@G|.@9Ri82@wjfvRlq=@<5GzpLvOvr!).&2RlF8Rf`C=x!eE{.Jw3_g2QRlkhLrpWlPde(!#U{s,UXa*Ta'[y'g:v>ReS;x0PZ&RnlRnn~HrKJw1}f!=x!eB|2w]aP(#Xa&a*Ta.Ua2a7=]iOd'#Y&Ro&WnWg;u.RiDg6vjRiBNvdRlzhNvj]nYJuW_2Wm3x)kFze{9d])!a.!,Y01!#&aC!a3RndC=ox~BrC@2b^{pg,rlse7x'ksuq!%Rm.E{xidw(wBRmGx9o+)X#wwo-So-}69:Rl4@xSf@a#XZ'X)X,Ta(/ARl8b[xc>RfY:RlI:RfQwlg.ARl:9;Rlwdn'#^XafaQa1X1TaHTa)@b[{zcZ#X'7RkwWg@Ou4ARn&x)kG#{,g7u/RkGdH'U#Y*Vz'Wm&CARm|bx#(A]gUbUzJj9Q~=d,#Y(56H}l978H{U7d,0#U*2>ABb_xZ978BbU{e~AJQ{g!978BbU{hxMh?ad{oUYZ.x1h?{l!#:2<H{mx3n[t{vl!,&a%3Ro(z=iS}6ARnr=Bwsn^wvn`Rnbd`*T}B0!#^X'BG{c9b]{a>>@=be}F?JvS!&BG{d7BG}(Bde#`a1X,Ya@!a'P~=wxf@2bZ}I56B2@@=aybb}08@55B9;5bb}<j3vLv;<Jw3&!>Rfg=ayb^}&OuNBKuLA!)a!P~=x#fD{f2@>==<bbzl?C972@@=Ix^d6rSu,v7w*C(0a)a6#B+a%!sQ[y?3Dt%3[xn~<5rLOu!5p@Ku+D#'!t7~GrP~?rNKvlaya7'!h+v-5qMg=t|cd,U#5AAaa5Abb{S@52B5@a[@52B5Gx[iXueu;d<#`a(!/549C;ag>23ExY5@Dah89b^~689Jv)!~2b[~1Lv'w(%*!a#bX|aPrmawRe]keu7uhv-q6rxu,q`xTo]/a5aU!bNaDXbi!b-!ao!b<bwA!#5@B932:aV2G|:d-)Y#hJrL>RhG<7@C5<H|_=Cau:5aj5@B932:bJ|ng>vIbs)#?C2F|9jPv0w.vISh-MKvUaz(.!9ABbb|[5;5<H|Eg>unwfh;9:4E|YjQsBt|vjx'hYq3!(?C2F|J:2<BaY?C2F|GOu!5x,g|p{ah!-(?C2F|c9:4E|OjXuvvNr}:Rh&i[w*t|cd+U#jJvsu)vsSn~Mkfrmu9p}u7vwv]So!McW#Xa!ax5@A5aY:5;5<H|>kJv~vYrquJu3x4ib#T)2@SmZM?C2F|Bj:rmu9@xPhI(a*a#U#`a3-5Abb|L~@:RhK9:4E|0@52B5G|#C::aY?C2F|-:2<BaY?C2F|.5Jvk!a)javYrquJu3x4ia#T)2@SmYM?C2F|HAxPhH(!a#U#`a*-5Abb|4~@:RhJ9:4E|R@52B5G|F:2<BaY?C2F|Sc^#Xa2j=Qq5CJvB!-g<v{z;hhM?C2F|Zi[vrv{z;hiM?C2F|XKsA>!a)-g<v{z;h[eb?C2F|]i[vrv{z;h]eb?C2F|^iZu.vix,hZq3ah!.(?C2F|QOu!5ShXM:2<BaY?C2F|P", 13494, 2713, 49, 25, 61), Se = /* #__PURE__ */ new Uint16Array([
	512,
	26465,
	29036,
	7,
	0,
	2,
	4,
	116,
	24638,
	116,
	24636,
	8693,
	29807,
	24610,
	621,
	1,
	0,
	0,
	3,
	112,
	24614,
	111,
	115,
	24615
]), A;
(function(e) {
	e[e.VALUE_LENGTH = 49152] = "VALUE_LENGTH", e[e.FLAG13 = 8192] = "FLAG13", e[e.BRANCH_LENGTH = 8064] = "BRANCH_LENGTH", e[e.JUMP_TABLE = 127] = "JUMP_TABLE", e[e.VALUE_MASK = 8191] = "VALUE_MASK";
})(A ||= {});
// node_modules/entities/dist/decode.js
var j;
(function(e) {
	e[e.AMP = 38] = "AMP", e[e.NUM = 35] = "NUM", e[e.SEMI = 59] = "SEMI", e[e.EQUALS = 61] = "EQUALS", e[e.ZERO = 48] = "ZERO", e[e.NINE = 57] = "NINE", e[e.LOWER_A = 97] = "LOWER_A", e[e.LOWER_X = 120] = "LOWER_X";
})(j ||= {});
var Ce = 32;
function we(e) {
	return e - j.ZERO >>> 0 <= 9;
}
function Te(e) {
	return (e | Ce) - j.LOWER_A >>> 0 <= 5;
}
function Ee(e) {
	return (e | Ce) - j.LOWER_A >>> 0 <= 25;
}
function De(e) {
	return e === j.EQUALS || Ee(e) || we(e);
}
var M;
(function(e) {
	e[e.EntityStart = 0] = "EntityStart", e[e.NumericStart = 1] = "NumericStart", e[e.NumericDecimal = 2] = "NumericDecimal", e[e.NumericHex = 3] = "NumericHex", e[e.NamedEntity = 4] = "NamedEntity";
})(M ||= {});
var Oe;
(function(e) {
	e[e.Legacy = 0] = "Legacy", e[e.Strict = 1] = "Strict", e[e.Attribute = 2] = "Attribute";
})(Oe ||= {});
var ke = class {
	decodeTree;
	emitCodePoint;
	errors;
	state = M.EntityStart;
	consumed = 1;
	result = 0;
	treeIndex = 0;
	excess = 1;
	decodeMode = Oe.Strict;
	runConsumed = 0;
	constructor(e, t, n) {
		this.decodeTree = e, this.emitCodePoint = t, this.errors = n;
	}
	startEntity(e) {
		this.decodeMode = e, this.state = M.EntityStart, this.result = 0, this.treeIndex = 0, this.excess = 1, this.consumed = 1, this.runConsumed = 0;
	}
	write(e, t) {
		switch (this.state) {
			case M.EntityStart: return e.charCodeAt(t) === j.NUM ? (this.state = M.NumericStart, this.consumed += 1, this.stateNumericStart(e, t + 1)) : (this.state = M.NamedEntity, this.stateNamedEntity(e, t));
			case M.NumericStart: return this.stateNumericStart(e, t);
			case M.NumericDecimal: return this.stateNumericDecimal(e, t);
			case M.NumericHex: return this.stateNumericHex(e, t);
			default: return this.stateNamedEntity(e, t);
		}
	}
	stateNumericStart(e, t) {
		return t >= e.length ? -1 : (e.charCodeAt(t) | Ce) === j.LOWER_X ? (this.state = M.NumericHex, this.consumed += 1, this.stateNumericHex(e, t + 1)) : (this.state = M.NumericDecimal, this.stateNumericDecimal(e, t));
	}
	stateNumericHex(e, t) {
		let n = e.length, { result: r } = this, { consumed: i } = this;
		for (; t < n;) {
			let n = e.charCodeAt(t);
			if (we(n) || Te(n)) {
				let e = n <= j.NINE ? n - j.ZERO : (n | Ce) - j.LOWER_A + 10;
				r = r * 16 + e, i += 1, t += 1;
			} else return this.result = r, this.consumed = i, this.emitNumericEntity(n, 3);
		}
		return this.result = r, this.consumed = i, -1;
	}
	stateNumericDecimal(e, t) {
		let n = e.length, { result: r } = this, { consumed: i } = this;
		for (; t < n;) {
			let n = e.charCodeAt(t) - j.ZERO;
			if (n >>> 0 > 9) return this.result = r, this.consumed = i, this.emitNumericEntity(n + j.ZERO, 2);
			r = r * 10 + n, i += 1, t += 1;
		}
		return this.result = r, this.consumed = i, -1;
	}
	emitNumericEntity(e, t) {
		if (this.consumed <= t) return this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
		if (e === j.SEMI) this.consumed += 1;
		else if (this.decodeMode === Oe.Strict) return 0;
		return this.emitCodePoint((this.decodeTree === Se ? ve : _e)(this.result), this.consumed), this.errors && (e !== j.SEMI && this.errors.missingSemicolonAfterCharacterReference(), this.errors.validateNumericCharacterReference(this.result)), this.consumed;
	}
	flushAndEmitLegacyOrReject(e, t, n, r) {
		return this.consumed = e, this.excess = t, this.result === 0 || this.decodeMode === Oe.Attribute && (r === 0 || t > 1 || De(n)) ? 0 : this.emitNotTerminatedNamedEntity();
	}
	stateNamedEntity(e, t) {
		let { decodeTree: n } = this, r = e.length, i = this.decodeMode === Oe.Strict, { treeIndex: a } = this, { excess: o } = this, { consumed: s } = this, c = n[a];
		for (; t < r;) {
			for (; (c & (A.VALUE_LENGTH | A.FLAG13)) === 0 && (c & A.JUMP_TABLE) !== 0;) {
				let i = e.charCodeAt(t), l = c & A.JUMP_TABLE, u = (c & A.BRANCH_LENGTH) >> 7;
				if (u === 0) {
					if (i !== l) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					a += 1;
				} else {
					let e = i - l;
					if (e >>> 0 >= u) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					let t = n[a + 1 + e];
					if (t === 0) return this.flushAndEmitLegacyOrReject(s, o, i, 0);
					a = a + u + t & 65535;
				}
				if (c = n[a], t += 1, o += 1, t >= r) break;
			}
			if (t >= r) break;
			if ((c & (A.VALUE_LENGTH | A.FLAG13)) === A.FLAG13) {
				let i = (c & A.BRANCH_LENGTH) >> 7, { runConsumed: l } = this;
				if (l === 0) {
					let n = e.charCodeAt(t);
					if (n !== (c & A.JUMP_TABLE)) return this.flushAndEmitLegacyOrReject(s, o, n, 0);
					t += 1, o += 1, l = 1;
				}
				for (; l < i;) {
					if (t >= r) return this.treeIndex = a, this.excess = o, this.consumed = s, this.runConsumed = l, -1;
					let i = l - 1, c = n[a + 1 + (i >> 1)] >> ((i & 1) << 3) & 255, u = e.charCodeAt(t);
					if (u !== c) return this.runConsumed = 0, this.flushAndEmitLegacyOrReject(s, o, u, 0);
					t += 1, o += 1, l += 1;
				}
				this.runConsumed = 0, a += 1 + (i >> 1), c = n[a];
				continue;
			}
			let l = c >>> 14, u = e.charCodeAt(t);
			if (l !== 0) {
				if (!i && (c & A.FLAG13) === 0 && (this.result = a, s += o - 1, o = 1), u === j.SEMI) return this.emitNamedEntityData(a, l, s + o);
				if (l === 1) return this.flushAndEmitLegacyOrReject(s, o, u, l);
			}
			let d = Ae(n, c, a + (l || 1), u);
			if (d < 0) return this.flushAndEmitLegacyOrReject(s, o, u, l);
			a = d, c = n[a], t += 1, o += 1;
		}
		return !i && c >>> 14 && (c & A.FLAG13) === 0 && (this.result = a, s += o - 1, o = 1), this.treeIndex = a, this.excess = o, this.consumed = s, -1;
	}
	emitNotTerminatedNamedEntity() {
		let { result: e, decodeTree: t } = this, n = t[e] >>> 14;
		return this.emitNamedEntityData(e, n, this.consumed), this.errors?.missingSemicolonAfterCharacterReference(), this.consumed;
	}
	emitNamedEntityData(e, t, n) {
		let { decodeTree: r } = this;
		return this.emitCodePoint(t === 1 ? r[e] & A.VALUE_MASK : r[e + 1], n), t === 3 && this.emitCodePoint(r[e + 2], n), n;
	}
	end() {
		switch (this.state) {
			case M.NamedEntity: return this.result !== 0 && (this.decodeMode !== Oe.Attribute || this.result === this.treeIndex) ? this.emitNotTerminatedNamedEntity() : 0;
			case M.NumericDecimal: return this.emitNumericEntity(0, 2);
			case M.NumericHex: return this.emitNumericEntity(0, 3);
			case M.NumericStart: return this.errors?.absenceOfDigitsInNumericCharacterReference(this.consumed), 0;
			default: return 0;
		}
	}
};
function Ae(e, t, n, r) {
	let i = (t & A.BRANCH_LENGTH) >> 7, a = t & A.JUMP_TABLE;
	if (a) {
		if (i === 0) return r === a ? n : -1;
		let t = r - a;
		if (t >>> 0 >= i) return -1;
		let o = e[n + t];
		return o === 0 ? -1 : n + i + o - 1 & 65535;
	}
	if (i === 0) return -1;
	let o = i + 1 >> 1, s = n + o + i;
	for (let t = 0; t < i; t++) {
		let i = e[n + (t >> 1)] >> ((t & 1) << 3) & 255;
		if (i === r) return s + e[n + o + t] & 65535;
		if (i > r) return -1;
	}
	return -1;
}
// node_modules/parse5/dist/common/html.js
var N;
(function(e) {
	e.HTML = "http://www.w3.org/1999/xhtml", e.MATHML = "http://www.w3.org/1998/Math/MathML", e.SVG = "http://www.w3.org/2000/svg", e.XLINK = "http://www.w3.org/1999/xlink", e.XML = "http://www.w3.org/XML/1998/namespace", e.XMLNS = "http://www.w3.org/2000/xmlns/";
})(N ||= {});
var je;
(function(e) {
	e.TYPE = "type", e.ACTION = "action", e.ENCODING = "encoding", e.PROMPT = "prompt", e.NAME = "name", e.COLOR = "color", e.FACE = "face", e.SIZE = "size";
})(je ||= {});
var P;
(function(e) {
	e.NO_QUIRKS = "no-quirks", e.QUIRKS = "quirks", e.LIMITED_QUIRKS = "limited-quirks";
})(P ||= {});
var F;
(function(e) {
	e.A = "a", e.ADDRESS = "address", e.ANNOTATION_XML = "annotation-xml", e.APPLET = "applet", e.AREA = "area", e.ARTICLE = "article", e.ASIDE = "aside", e.B = "b", e.BASE = "base", e.BASEFONT = "basefont", e.BGSOUND = "bgsound", e.BIG = "big", e.BLOCKQUOTE = "blockquote", e.BODY = "body", e.BR = "br", e.BUTTON = "button", e.CAPTION = "caption", e.CENTER = "center", e.CODE = "code", e.COL = "col", e.COLGROUP = "colgroup", e.DD = "dd", e.DESC = "desc", e.DETAILS = "details", e.DIALOG = "dialog", e.DIR = "dir", e.DIV = "div", e.DL = "dl", e.DT = "dt", e.EM = "em", e.EMBED = "embed", e.FIELDSET = "fieldset", e.FIGCAPTION = "figcaption", e.FIGURE = "figure", e.FONT = "font", e.FOOTER = "footer", e.FOREIGN_OBJECT = "foreignObject", e.FORM = "form", e.FRAME = "frame", e.FRAMESET = "frameset", e.H1 = "h1", e.H2 = "h2", e.H3 = "h3", e.H4 = "h4", e.H5 = "h5", e.H6 = "h6", e.HEAD = "head", e.HEADER = "header", e.HGROUP = "hgroup", e.HR = "hr", e.HTML = "html", e.I = "i", e.IMG = "img", e.IMAGE = "image", e.INPUT = "input", e.IFRAME = "iframe", e.KEYGEN = "keygen", e.LABEL = "label", e.LI = "li", e.LINK = "link", e.LISTING = "listing", e.MAIN = "main", e.MALIGNMARK = "malignmark", e.MARQUEE = "marquee", e.MATH = "math", e.MENU = "menu", e.META = "meta", e.MGLYPH = "mglyph", e.MI = "mi", e.MO = "mo", e.MN = "mn", e.MS = "ms", e.MTEXT = "mtext", e.NAV = "nav", e.NOBR = "nobr", e.NOFRAMES = "noframes", e.NOEMBED = "noembed", e.NOSCRIPT = "noscript", e.OBJECT = "object", e.OL = "ol", e.OPTGROUP = "optgroup", e.OPTION = "option", e.P = "p", e.PARAM = "param", e.PLAINTEXT = "plaintext", e.PRE = "pre", e.RB = "rb", e.RP = "rp", e.RT = "rt", e.RTC = "rtc", e.RUBY = "ruby", e.S = "s", e.SCRIPT = "script", e.SEARCH = "search", e.SECTION = "section", e.SELECT = "select", e.SOURCE = "source", e.SMALL = "small", e.SPAN = "span", e.STRIKE = "strike", e.STRONG = "strong", e.STYLE = "style", e.SUB = "sub", e.SUMMARY = "summary", e.SUP = "sup", e.TABLE = "table", e.TBODY = "tbody", e.TEMPLATE = "template", e.TEXTAREA = "textarea", e.TFOOT = "tfoot", e.TD = "td", e.TH = "th", e.THEAD = "thead", e.TITLE = "title", e.TR = "tr", e.TRACK = "track", e.TT = "tt", e.U = "u", e.UL = "ul", e.SVG = "svg", e.VAR = "var", e.WBR = "wbr", e.XMP = "xmp";
})(F ||= {});
var I;
(function(e) {
	e[e.UNKNOWN = 0] = "UNKNOWN", e[e.A = 1] = "A", e[e.ADDRESS = 2] = "ADDRESS", e[e.ANNOTATION_XML = 3] = "ANNOTATION_XML", e[e.APPLET = 4] = "APPLET", e[e.AREA = 5] = "AREA", e[e.ARTICLE = 6] = "ARTICLE", e[e.ASIDE = 7] = "ASIDE", e[e.B = 8] = "B", e[e.BASE = 9] = "BASE", e[e.BASEFONT = 10] = "BASEFONT", e[e.BGSOUND = 11] = "BGSOUND", e[e.BIG = 12] = "BIG", e[e.BLOCKQUOTE = 13] = "BLOCKQUOTE", e[e.BODY = 14] = "BODY", e[e.BR = 15] = "BR", e[e.BUTTON = 16] = "BUTTON", e[e.CAPTION = 17] = "CAPTION", e[e.CENTER = 18] = "CENTER", e[e.CODE = 19] = "CODE", e[e.COL = 20] = "COL", e[e.COLGROUP = 21] = "COLGROUP", e[e.DD = 22] = "DD", e[e.DESC = 23] = "DESC", e[e.DETAILS = 24] = "DETAILS", e[e.DIALOG = 25] = "DIALOG", e[e.DIR = 26] = "DIR", e[e.DIV = 27] = "DIV", e[e.DL = 28] = "DL", e[e.DT = 29] = "DT", e[e.EM = 30] = "EM", e[e.EMBED = 31] = "EMBED", e[e.FIELDSET = 32] = "FIELDSET", e[e.FIGCAPTION = 33] = "FIGCAPTION", e[e.FIGURE = 34] = "FIGURE", e[e.FONT = 35] = "FONT", e[e.FOOTER = 36] = "FOOTER", e[e.FOREIGN_OBJECT = 37] = "FOREIGN_OBJECT", e[e.FORM = 38] = "FORM", e[e.FRAME = 39] = "FRAME", e[e.FRAMESET = 40] = "FRAMESET", e[e.H1 = 41] = "H1", e[e.H2 = 42] = "H2", e[e.H3 = 43] = "H3", e[e.H4 = 44] = "H4", e[e.H5 = 45] = "H5", e[e.H6 = 46] = "H6", e[e.HEAD = 47] = "HEAD", e[e.HEADER = 48] = "HEADER", e[e.HGROUP = 49] = "HGROUP", e[e.HR = 50] = "HR", e[e.HTML = 51] = "HTML", e[e.I = 52] = "I", e[e.IMG = 53] = "IMG", e[e.IMAGE = 54] = "IMAGE", e[e.INPUT = 55] = "INPUT", e[e.IFRAME = 56] = "IFRAME", e[e.KEYGEN = 57] = "KEYGEN", e[e.LABEL = 58] = "LABEL", e[e.LI = 59] = "LI", e[e.LINK = 60] = "LINK", e[e.LISTING = 61] = "LISTING", e[e.MAIN = 62] = "MAIN", e[e.MALIGNMARK = 63] = "MALIGNMARK", e[e.MARQUEE = 64] = "MARQUEE", e[e.MATH = 65] = "MATH", e[e.MENU = 66] = "MENU", e[e.META = 67] = "META", e[e.MGLYPH = 68] = "MGLYPH", e[e.MI = 69] = "MI", e[e.MO = 70] = "MO", e[e.MN = 71] = "MN", e[e.MS = 72] = "MS", e[e.MTEXT = 73] = "MTEXT", e[e.NAV = 74] = "NAV", e[e.NOBR = 75] = "NOBR", e[e.NOFRAMES = 76] = "NOFRAMES", e[e.NOEMBED = 77] = "NOEMBED", e[e.NOSCRIPT = 78] = "NOSCRIPT", e[e.OBJECT = 79] = "OBJECT", e[e.OL = 80] = "OL", e[e.OPTGROUP = 81] = "OPTGROUP", e[e.OPTION = 82] = "OPTION", e[e.P = 83] = "P", e[e.PARAM = 84] = "PARAM", e[e.PLAINTEXT = 85] = "PLAINTEXT", e[e.PRE = 86] = "PRE", e[e.RB = 87] = "RB", e[e.RP = 88] = "RP", e[e.RT = 89] = "RT", e[e.RTC = 90] = "RTC", e[e.RUBY = 91] = "RUBY", e[e.S = 92] = "S", e[e.SCRIPT = 93] = "SCRIPT", e[e.SEARCH = 94] = "SEARCH", e[e.SECTION = 95] = "SECTION", e[e.SELECT = 96] = "SELECT", e[e.SOURCE = 97] = "SOURCE", e[e.SMALL = 98] = "SMALL", e[e.SPAN = 99] = "SPAN", e[e.STRIKE = 100] = "STRIKE", e[e.STRONG = 101] = "STRONG", e[e.STYLE = 102] = "STYLE", e[e.SUB = 103] = "SUB", e[e.SUMMARY = 104] = "SUMMARY", e[e.SUP = 105] = "SUP", e[e.TABLE = 106] = "TABLE", e[e.TBODY = 107] = "TBODY", e[e.TEMPLATE = 108] = "TEMPLATE", e[e.TEXTAREA = 109] = "TEXTAREA", e[e.TFOOT = 110] = "TFOOT", e[e.TD = 111] = "TD", e[e.TH = 112] = "TH", e[e.THEAD = 113] = "THEAD", e[e.TITLE = 114] = "TITLE", e[e.TR = 115] = "TR", e[e.TRACK = 116] = "TRACK", e[e.TT = 117] = "TT", e[e.U = 118] = "U", e[e.UL = 119] = "UL", e[e.SVG = 120] = "SVG", e[e.VAR = 121] = "VAR", e[e.WBR = 122] = "WBR", e[e.XMP = 123] = "XMP";
})(I ||= {});
var Me = /* @__PURE__ */ new Map([
	[F.A, I.A],
	[F.ADDRESS, I.ADDRESS],
	[F.ANNOTATION_XML, I.ANNOTATION_XML],
	[F.APPLET, I.APPLET],
	[F.AREA, I.AREA],
	[F.ARTICLE, I.ARTICLE],
	[F.ASIDE, I.ASIDE],
	[F.B, I.B],
	[F.BASE, I.BASE],
	[F.BASEFONT, I.BASEFONT],
	[F.BGSOUND, I.BGSOUND],
	[F.BIG, I.BIG],
	[F.BLOCKQUOTE, I.BLOCKQUOTE],
	[F.BODY, I.BODY],
	[F.BR, I.BR],
	[F.BUTTON, I.BUTTON],
	[F.CAPTION, I.CAPTION],
	[F.CENTER, I.CENTER],
	[F.CODE, I.CODE],
	[F.COL, I.COL],
	[F.COLGROUP, I.COLGROUP],
	[F.DD, I.DD],
	[F.DESC, I.DESC],
	[F.DETAILS, I.DETAILS],
	[F.DIALOG, I.DIALOG],
	[F.DIR, I.DIR],
	[F.DIV, I.DIV],
	[F.DL, I.DL],
	[F.DT, I.DT],
	[F.EM, I.EM],
	[F.EMBED, I.EMBED],
	[F.FIELDSET, I.FIELDSET],
	[F.FIGCAPTION, I.FIGCAPTION],
	[F.FIGURE, I.FIGURE],
	[F.FONT, I.FONT],
	[F.FOOTER, I.FOOTER],
	[F.FOREIGN_OBJECT, I.FOREIGN_OBJECT],
	[F.FORM, I.FORM],
	[F.FRAME, I.FRAME],
	[F.FRAMESET, I.FRAMESET],
	[F.H1, I.H1],
	[F.H2, I.H2],
	[F.H3, I.H3],
	[F.H4, I.H4],
	[F.H5, I.H5],
	[F.H6, I.H6],
	[F.HEAD, I.HEAD],
	[F.HEADER, I.HEADER],
	[F.HGROUP, I.HGROUP],
	[F.HR, I.HR],
	[F.HTML, I.HTML],
	[F.I, I.I],
	[F.IMG, I.IMG],
	[F.IMAGE, I.IMAGE],
	[F.INPUT, I.INPUT],
	[F.IFRAME, I.IFRAME],
	[F.KEYGEN, I.KEYGEN],
	[F.LABEL, I.LABEL],
	[F.LI, I.LI],
	[F.LINK, I.LINK],
	[F.LISTING, I.LISTING],
	[F.MAIN, I.MAIN],
	[F.MALIGNMARK, I.MALIGNMARK],
	[F.MARQUEE, I.MARQUEE],
	[F.MATH, I.MATH],
	[F.MENU, I.MENU],
	[F.META, I.META],
	[F.MGLYPH, I.MGLYPH],
	[F.MI, I.MI],
	[F.MO, I.MO],
	[F.MN, I.MN],
	[F.MS, I.MS],
	[F.MTEXT, I.MTEXT],
	[F.NAV, I.NAV],
	[F.NOBR, I.NOBR],
	[F.NOFRAMES, I.NOFRAMES],
	[F.NOEMBED, I.NOEMBED],
	[F.NOSCRIPT, I.NOSCRIPT],
	[F.OBJECT, I.OBJECT],
	[F.OL, I.OL],
	[F.OPTGROUP, I.OPTGROUP],
	[F.OPTION, I.OPTION],
	[F.P, I.P],
	[F.PARAM, I.PARAM],
	[F.PLAINTEXT, I.PLAINTEXT],
	[F.PRE, I.PRE],
	[F.RB, I.RB],
	[F.RP, I.RP],
	[F.RT, I.RT],
	[F.RTC, I.RTC],
	[F.RUBY, I.RUBY],
	[F.S, I.S],
	[F.SCRIPT, I.SCRIPT],
	[F.SEARCH, I.SEARCH],
	[F.SECTION, I.SECTION],
	[F.SELECT, I.SELECT],
	[F.SOURCE, I.SOURCE],
	[F.SMALL, I.SMALL],
	[F.SPAN, I.SPAN],
	[F.STRIKE, I.STRIKE],
	[F.STRONG, I.STRONG],
	[F.STYLE, I.STYLE],
	[F.SUB, I.SUB],
	[F.SUMMARY, I.SUMMARY],
	[F.SUP, I.SUP],
	[F.TABLE, I.TABLE],
	[F.TBODY, I.TBODY],
	[F.TEMPLATE, I.TEMPLATE],
	[F.TEXTAREA, I.TEXTAREA],
	[F.TFOOT, I.TFOOT],
	[F.TD, I.TD],
	[F.TH, I.TH],
	[F.THEAD, I.THEAD],
	[F.TITLE, I.TITLE],
	[F.TR, I.TR],
	[F.TRACK, I.TRACK],
	[F.TT, I.TT],
	[F.U, I.U],
	[F.UL, I.UL],
	[F.SVG, I.SVG],
	[F.VAR, I.VAR],
	[F.WBR, I.WBR],
	[F.XMP, I.XMP]
]);
function Ne(e) {
	return Me.get(e) ?? I.UNKNOWN;
}
var L = I, Pe = {
	[N.HTML]: /* @__PURE__ */ new Set([
		L.ADDRESS,
		L.APPLET,
		L.AREA,
		L.ARTICLE,
		L.ASIDE,
		L.BASE,
		L.BASEFONT,
		L.BGSOUND,
		L.BLOCKQUOTE,
		L.BODY,
		L.BR,
		L.BUTTON,
		L.CAPTION,
		L.CENTER,
		L.COL,
		L.COLGROUP,
		L.DD,
		L.DETAILS,
		L.DIR,
		L.DIV,
		L.DL,
		L.DT,
		L.EMBED,
		L.FIELDSET,
		L.FIGCAPTION,
		L.FIGURE,
		L.FOOTER,
		L.FORM,
		L.FRAME,
		L.FRAMESET,
		L.H1,
		L.H2,
		L.H3,
		L.H4,
		L.H5,
		L.H6,
		L.HEAD,
		L.HEADER,
		L.HGROUP,
		L.HR,
		L.HTML,
		L.IFRAME,
		L.IMG,
		L.INPUT,
		L.LI,
		L.LINK,
		L.LISTING,
		L.MAIN,
		L.MARQUEE,
		L.MENU,
		L.META,
		L.NAV,
		L.NOEMBED,
		L.NOFRAMES,
		L.NOSCRIPT,
		L.OBJECT,
		L.OL,
		L.P,
		L.PARAM,
		L.PLAINTEXT,
		L.PRE,
		L.SCRIPT,
		L.SECTION,
		L.SELECT,
		L.SOURCE,
		L.STYLE,
		L.SUMMARY,
		L.TABLE,
		L.TBODY,
		L.TD,
		L.TEMPLATE,
		L.TEXTAREA,
		L.TFOOT,
		L.TH,
		L.THEAD,
		L.TITLE,
		L.TR,
		L.TRACK,
		L.UL,
		L.WBR,
		L.XMP
	]),
	[N.MATHML]: /* @__PURE__ */ new Set([
		L.MI,
		L.MO,
		L.MN,
		L.MS,
		L.MTEXT,
		L.ANNOTATION_XML
	]),
	[N.SVG]: /* @__PURE__ */ new Set([
		L.TITLE,
		L.FOREIGN_OBJECT,
		L.DESC
	]),
	[N.XLINK]: /* @__PURE__ */ new Set(),
	[N.XML]: /* @__PURE__ */ new Set(),
	[N.XMLNS]: /* @__PURE__ */ new Set()
}, Fe = /* @__PURE__ */ new Set([
	L.H1,
	L.H2,
	L.H3,
	L.H4,
	L.H5,
	L.H6
]), Ie = /* @__PURE__ */ new Set([
	F.STYLE,
	F.SCRIPT,
	F.XMP,
	F.IFRAME,
	F.NOEMBED,
	F.NOFRAMES,
	F.PLAINTEXT
]);
function Le(e, t) {
	return Ie.has(e) || t && e === F.NOSCRIPT;
}
// node_modules/parse5/dist/tokenizer/index.js
var R;
(function(e) {
	e[e.DATA = 0] = "DATA", e[e.RCDATA = 1] = "RCDATA", e[e.RAWTEXT = 2] = "RAWTEXT", e[e.SCRIPT_DATA = 3] = "SCRIPT_DATA", e[e.PLAINTEXT = 4] = "PLAINTEXT", e[e.TAG_OPEN = 5] = "TAG_OPEN", e[e.END_TAG_OPEN = 6] = "END_TAG_OPEN", e[e.TAG_NAME = 7] = "TAG_NAME", e[e.RCDATA_LESS_THAN_SIGN = 8] = "RCDATA_LESS_THAN_SIGN", e[e.RCDATA_END_TAG_OPEN = 9] = "RCDATA_END_TAG_OPEN", e[e.RCDATA_END_TAG_NAME = 10] = "RCDATA_END_TAG_NAME", e[e.RAWTEXT_LESS_THAN_SIGN = 11] = "RAWTEXT_LESS_THAN_SIGN", e[e.RAWTEXT_END_TAG_OPEN = 12] = "RAWTEXT_END_TAG_OPEN", e[e.RAWTEXT_END_TAG_NAME = 13] = "RAWTEXT_END_TAG_NAME", e[e.SCRIPT_DATA_LESS_THAN_SIGN = 14] = "SCRIPT_DATA_LESS_THAN_SIGN", e[e.SCRIPT_DATA_END_TAG_OPEN = 15] = "SCRIPT_DATA_END_TAG_OPEN", e[e.SCRIPT_DATA_END_TAG_NAME = 16] = "SCRIPT_DATA_END_TAG_NAME", e[e.SCRIPT_DATA_ESCAPE_START = 17] = "SCRIPT_DATA_ESCAPE_START", e[e.SCRIPT_DATA_ESCAPE_START_DASH = 18] = "SCRIPT_DATA_ESCAPE_START_DASH", e[e.SCRIPT_DATA_ESCAPED = 19] = "SCRIPT_DATA_ESCAPED", e[e.SCRIPT_DATA_ESCAPED_DASH = 20] = "SCRIPT_DATA_ESCAPED_DASH", e[e.SCRIPT_DATA_ESCAPED_DASH_DASH = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_OPEN = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN", e[e.SCRIPT_DATA_ESCAPED_END_TAG_NAME = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_START = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START", e[e.SCRIPT_DATA_DOUBLE_ESCAPED = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH", e[e.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN", e[e.SCRIPT_DATA_DOUBLE_ESCAPE_END = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END", e[e.BEFORE_ATTRIBUTE_NAME = 31] = "BEFORE_ATTRIBUTE_NAME", e[e.ATTRIBUTE_NAME = 32] = "ATTRIBUTE_NAME", e[e.AFTER_ATTRIBUTE_NAME = 33] = "AFTER_ATTRIBUTE_NAME", e[e.BEFORE_ATTRIBUTE_VALUE = 34] = "BEFORE_ATTRIBUTE_VALUE", e[e.ATTRIBUTE_VALUE_DOUBLE_QUOTED = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED", e[e.ATTRIBUTE_VALUE_SINGLE_QUOTED = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED", e[e.ATTRIBUTE_VALUE_UNQUOTED = 37] = "ATTRIBUTE_VALUE_UNQUOTED", e[e.AFTER_ATTRIBUTE_VALUE_QUOTED = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED", e[e.SELF_CLOSING_START_TAG = 39] = "SELF_CLOSING_START_TAG", e[e.BOGUS_COMMENT = 40] = "BOGUS_COMMENT", e[e.MARKUP_DECLARATION_OPEN = 41] = "MARKUP_DECLARATION_OPEN", e[e.COMMENT_START = 42] = "COMMENT_START", e[e.COMMENT_START_DASH = 43] = "COMMENT_START_DASH", e[e.COMMENT = 44] = "COMMENT", e[e.COMMENT_LESS_THAN_SIGN = 45] = "COMMENT_LESS_THAN_SIGN", e[e.COMMENT_LESS_THAN_SIGN_BANG = 46] = "COMMENT_LESS_THAN_SIGN_BANG", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH", e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH", e[e.COMMENT_END_DASH = 49] = "COMMENT_END_DASH", e[e.COMMENT_END = 50] = "COMMENT_END", e[e.COMMENT_END_BANG = 51] = "COMMENT_END_BANG", e[e.DOCTYPE = 52] = "DOCTYPE", e[e.BEFORE_DOCTYPE_NAME = 53] = "BEFORE_DOCTYPE_NAME", e[e.DOCTYPE_NAME = 54] = "DOCTYPE_NAME", e[e.AFTER_DOCTYPE_NAME = 55] = "AFTER_DOCTYPE_NAME", e[e.AFTER_DOCTYPE_PUBLIC_KEYWORD = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD", e[e.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER", e[e.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_PUBLIC_IDENTIFIER = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER", e[e.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS", e[e.AFTER_DOCTYPE_SYSTEM_KEYWORD = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD", e[e.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER", e[e.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED", e[e.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED", e[e.AFTER_DOCTYPE_SYSTEM_IDENTIFIER = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER", e[e.BOGUS_DOCTYPE = 67] = "BOGUS_DOCTYPE", e[e.CDATA_SECTION = 68] = "CDATA_SECTION", e[e.CDATA_SECTION_BRACKET = 69] = "CDATA_SECTION_BRACKET", e[e.CDATA_SECTION_END = 70] = "CDATA_SECTION_END", e[e.CHARACTER_REFERENCE = 71] = "CHARACTER_REFERENCE", e[e.AMBIGUOUS_AMPERSAND = 72] = "AMBIGUOUS_AMPERSAND";
})(R ||= {});
var z = {
	DATA: R.DATA,
	RCDATA: R.RCDATA,
	RAWTEXT: R.RAWTEXT,
	SCRIPT_DATA: R.SCRIPT_DATA,
	PLAINTEXT: R.PLAINTEXT,
	CDATA_SECTION: R.CDATA_SECTION
};
function Re(e) {
	return e >= E.DIGIT_0 && e <= E.DIGIT_9;
}
function ze(e) {
	return e >= E.LATIN_CAPITAL_A && e <= E.LATIN_CAPITAL_Z;
}
function Be(e) {
	return e >= E.LATIN_SMALL_A && e <= E.LATIN_SMALL_Z;
}
function Ve(e) {
	return Be(e) || ze(e);
}
function He(e) {
	return Ve(e) || Re(e);
}
function Ue(e) {
	return e + 32;
}
function We(e) {
	return e === E.SPACE || e === E.LINE_FEED || e === E.TABULATION || e === E.FORM_FEED;
}
function Ge(e) {
	return We(e) || e === E.SOLIDUS || e === E.GREATER_THAN_SIGN;
}
function Ke(e) {
	return e === E.NULL ? O.nullCharacterReference : e > 1114111 ? O.characterReferenceOutsideUnicodeRange : se(e) ? O.surrogateCharacterReference : de(e) ? O.noncharacterCharacterReference : ue(e) || e === E.CARRIAGE_RETURN ? O.controlCharacterReference : null;
}
var qe = class {
	constructor(e, t) {
		this.options = e, this.handler = t, this.paused = !1, this.inLoop = !1, this.inForeignNode = !1, this.lastStartTagName = "", this.active = !1, this.state = R.DATA, this.returnState = R.DATA, this.entityStartPos = 0, this.consumedAfterSnapshot = -1, this.currentCharacterToken = null, this.currentToken = null, this.currentAttr = {
			name: "",
			value: ""
		}, this.preprocessor = new pe(t), this.currentLocation = this.getCurrentLocation(-1), this.entityDecoder = new ke(xe, (e, t) => {
			this.preprocessor.pos = this.entityStartPos + t - 1, this._flushCodePointConsumedAsCharacterReference(e);
		}, t.onParseError ? {
			missingSemicolonAfterCharacterReference: () => {
				this._err(O.missingSemicolonAfterCharacterReference, 1);
			},
			absenceOfDigitsInNumericCharacterReference: (e) => {
				this._err(O.absenceOfDigitsInNumericCharacterReference, this.entityStartPos - this.preprocessor.pos + e);
			},
			validateNumericCharacterReference: (e) => {
				let t = Ke(e);
				t && this._err(t, 1);
			}
		} : void 0);
	}
	_err(e, t = 0) {
		var n, r;
		(r = (n = this.handler).onParseError) == null || r.call(n, this.preprocessor.getError(e, t));
	}
	getCurrentLocation(e) {
		return this.options.sourceCodeLocationInfo ? {
			startLine: this.preprocessor.line,
			startCol: this.preprocessor.col - e,
			startOffset: this.preprocessor.offset - e,
			endLine: -1,
			endCol: -1,
			endOffset: -1
		} : null;
	}
	_runParsingLoop() {
		if (!this.inLoop) {
			for (this.inLoop = !0; this.active && !this.paused;) {
				this.consumedAfterSnapshot = 0;
				let e = this._consume();
				this._ensureHibernation() || this._callState(e);
			}
			this.inLoop = !1;
		}
	}
	pause() {
		this.paused = !0;
	}
	resume(e) {
		if (!this.paused) throw Error("Parser was already resumed");
		this.paused = !1, !this.inLoop && (this._runParsingLoop(), this.paused || e?.());
	}
	write(e, t, n) {
		this.active = !0, this.preprocessor.write(e, t), this._runParsingLoop(), this.paused || n?.();
	}
	insertHtmlAtCurrentPos(e) {
		this.active = !0, this.preprocessor.insertHtmlAtCurrentPos(e), this._runParsingLoop();
	}
	_ensureHibernation() {
		return this.preprocessor.endOfChunkHit ? (this.preprocessor.retreat(this.consumedAfterSnapshot), this.consumedAfterSnapshot = 0, this.active = !1, !0) : !1;
	}
	_consume() {
		return this.consumedAfterSnapshot++, this.preprocessor.advance();
	}
	_advanceBy(e) {
		this.consumedAfterSnapshot += e;
		for (let t = 0; t < e; t++) this.preprocessor.advance();
	}
	_consumeSequenceIfMatch(e, t) {
		return this.preprocessor.startsWith(e, t) ? (this._advanceBy(e.length - 1), !0) : !1;
	}
	_createStartTagToken() {
		this.currentToken = {
			type: k.START_TAG,
			tagName: "",
			tagID: I.UNKNOWN,
			selfClosing: !1,
			ackSelfClosing: !1,
			attrs: [],
			location: this.getCurrentLocation(1)
		};
	}
	_createEndTagToken() {
		this.currentToken = {
			type: k.END_TAG,
			tagName: "",
			tagID: I.UNKNOWN,
			selfClosing: !1,
			ackSelfClosing: !1,
			attrs: [],
			location: this.getCurrentLocation(2)
		};
	}
	_createCommentToken(e) {
		this.currentToken = {
			type: k.COMMENT,
			data: "",
			location: this.getCurrentLocation(e)
		};
	}
	_createDoctypeToken(e) {
		this.currentToken = {
			type: k.DOCTYPE,
			name: e,
			forceQuirks: !1,
			publicId: null,
			systemId: null,
			location: this.currentLocation
		};
	}
	_createCharacterToken(e, t) {
		this.currentCharacterToken = {
			type: e,
			chars: t,
			location: this.currentLocation
		};
	}
	_createAttr(e) {
		this.currentAttr = {
			name: e,
			value: ""
		}, this.currentLocation = this.getCurrentLocation(0);
	}
	_leaveAttrName() {
		var e;
		let t = this.currentToken;
		if (me(t, this.currentAttr.name) === null) {
			if (t.attrs.push(this.currentAttr), t.location && this.currentLocation) {
				let n = (e = t.location).attrs ?? (e.attrs = Object.create(null));
				n[this.currentAttr.name] = this.currentLocation, this._leaveAttrValue();
			}
		} else this._err(O.duplicateAttribute);
	}
	_leaveAttrValue() {
		this.currentLocation && (this.currentLocation.endLine = this.preprocessor.line, this.currentLocation.endCol = this.preprocessor.col, this.currentLocation.endOffset = this.preprocessor.offset);
	}
	prepareToken(e) {
		this._emitCurrentCharacterToken(e.location), this.currentToken = null, e.location && (e.location.endLine = this.preprocessor.line, e.location.endCol = this.preprocessor.col + 1, e.location.endOffset = this.preprocessor.offset + 1), this.currentLocation = this.getCurrentLocation(-1);
	}
	emitCurrentTagToken() {
		let e = this.currentToken;
		this.prepareToken(e), e.tagID = Ne(e.tagName), e.type === k.START_TAG ? (this.lastStartTagName = e.tagName, this.handler.onStartTag(e)) : (e.attrs.length > 0 && this._err(O.endTagWithAttributes), e.selfClosing && this._err(O.endTagWithTrailingSolidus), this.handler.onEndTag(e)), this.preprocessor.dropParsedChunk();
	}
	emitCurrentComment(e) {
		this.prepareToken(e), this.handler.onComment(e), this.preprocessor.dropParsedChunk();
	}
	emitCurrentDoctype(e) {
		this.prepareToken(e), this.handler.onDoctype(e), this.preprocessor.dropParsedChunk();
	}
	_emitCurrentCharacterToken(e) {
		if (this.currentCharacterToken) {
			switch (e && this.currentCharacterToken.location && (this.currentCharacterToken.location.endLine = e.startLine, this.currentCharacterToken.location.endCol = e.startCol, this.currentCharacterToken.location.endOffset = e.startOffset), this.currentCharacterToken.type) {
				case k.CHARACTER:
					this.handler.onCharacter(this.currentCharacterToken);
					break;
				case k.NULL_CHARACTER:
					this.handler.onNullCharacter(this.currentCharacterToken);
					break;
				case k.WHITESPACE_CHARACTER: this.handler.onWhitespaceCharacter(this.currentCharacterToken);
			}
			this.currentCharacterToken = null;
		}
	}
	_emitEOFToken() {
		let e = this.getCurrentLocation(0);
		e && (e.endLine = e.startLine, e.endCol = e.startCol, e.endOffset = e.startOffset), this._emitCurrentCharacterToken(e), this.handler.onEof({
			type: k.EOF,
			location: e
		}), this.active = !1;
	}
	_appendCharToCurrentCharacterToken(e, t) {
		if (this.currentCharacterToken) {
			if (this.currentCharacterToken.type === e) {
				this.currentCharacterToken.chars += t;
				return;
			}
			this.currentLocation = this.getCurrentLocation(0), this._emitCurrentCharacterToken(this.currentLocation), this.preprocessor.dropParsedChunk();
		}
		this._createCharacterToken(e, t);
	}
	_emitCodePoint(e) {
		let t = We(e) ? k.WHITESPACE_CHARACTER : e === E.NULL ? k.NULL_CHARACTER : k.CHARACTER;
		this._appendCharToCurrentCharacterToken(t, e < 65536 ? String.fromCharCode(e) : String.fromCodePoint(e));
	}
	_emitChars(e) {
		this._appendCharToCurrentCharacterToken(k.CHARACTER, e);
	}
	_startCharacterReference() {
		this.returnState = this.state, this.state = R.CHARACTER_REFERENCE, this.entityStartPos = this.preprocessor.pos, this.entityDecoder.startEntity(this._isCharacterReferenceInAttribute() ? Oe.Attribute : Oe.Legacy);
	}
	_isCharacterReferenceInAttribute() {
		return this.returnState === R.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === R.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === R.ATTRIBUTE_VALUE_UNQUOTED;
	}
	_flushCodePointConsumedAsCharacterReference(e) {
		this._isCharacterReferenceInAttribute() ? this.currentAttr.value += String.fromCodePoint(e) : this._emitCodePoint(e);
	}
	_callState(e) {
		switch (this.state) {
			case R.DATA:
				this._stateData(e);
				break;
			case R.RCDATA:
				this._stateRcdata(e);
				break;
			case R.RAWTEXT:
				this._stateRawtext(e);
				break;
			case R.SCRIPT_DATA:
				this._stateScriptData(e);
				break;
			case R.PLAINTEXT:
				this._statePlaintext(e);
				break;
			case R.TAG_OPEN:
				this._stateTagOpen(e);
				break;
			case R.END_TAG_OPEN:
				this._stateEndTagOpen(e);
				break;
			case R.TAG_NAME:
				this._stateTagName(e);
				break;
			case R.RCDATA_LESS_THAN_SIGN:
				this._stateRcdataLessThanSign(e);
				break;
			case R.RCDATA_END_TAG_OPEN:
				this._stateRcdataEndTagOpen(e);
				break;
			case R.RCDATA_END_TAG_NAME:
				this._stateRcdataEndTagName(e);
				break;
			case R.RAWTEXT_LESS_THAN_SIGN:
				this._stateRawtextLessThanSign(e);
				break;
			case R.RAWTEXT_END_TAG_OPEN:
				this._stateRawtextEndTagOpen(e);
				break;
			case R.RAWTEXT_END_TAG_NAME:
				this._stateRawtextEndTagName(e);
				break;
			case R.SCRIPT_DATA_LESS_THAN_SIGN:
				this._stateScriptDataLessThanSign(e);
				break;
			case R.SCRIPT_DATA_END_TAG_OPEN:
				this._stateScriptDataEndTagOpen(e);
				break;
			case R.SCRIPT_DATA_END_TAG_NAME:
				this._stateScriptDataEndTagName(e);
				break;
			case R.SCRIPT_DATA_ESCAPE_START:
				this._stateScriptDataEscapeStart(e);
				break;
			case R.SCRIPT_DATA_ESCAPE_START_DASH:
				this._stateScriptDataEscapeStartDash(e);
				break;
			case R.SCRIPT_DATA_ESCAPED:
				this._stateScriptDataEscaped(e);
				break;
			case R.SCRIPT_DATA_ESCAPED_DASH:
				this._stateScriptDataEscapedDash(e);
				break;
			case R.SCRIPT_DATA_ESCAPED_DASH_DASH:
				this._stateScriptDataEscapedDashDash(e);
				break;
			case R.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN:
				this._stateScriptDataEscapedLessThanSign(e);
				break;
			case R.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:
				this._stateScriptDataEscapedEndTagOpen(e);
				break;
			case R.SCRIPT_DATA_ESCAPED_END_TAG_NAME:
				this._stateScriptDataEscapedEndTagName(e);
				break;
			case R.SCRIPT_DATA_DOUBLE_ESCAPE_START:
				this._stateScriptDataDoubleEscapeStart(e);
				break;
			case R.SCRIPT_DATA_DOUBLE_ESCAPED:
				this._stateScriptDataDoubleEscaped(e);
				break;
			case R.SCRIPT_DATA_DOUBLE_ESCAPED_DASH:
				this._stateScriptDataDoubleEscapedDash(e);
				break;
			case R.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH:
				this._stateScriptDataDoubleEscapedDashDash(e);
				break;
			case R.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN:
				this._stateScriptDataDoubleEscapedLessThanSign(e);
				break;
			case R.SCRIPT_DATA_DOUBLE_ESCAPE_END:
				this._stateScriptDataDoubleEscapeEnd(e);
				break;
			case R.BEFORE_ATTRIBUTE_NAME:
				this._stateBeforeAttributeName(e);
				break;
			case R.ATTRIBUTE_NAME:
				this._stateAttributeName(e);
				break;
			case R.AFTER_ATTRIBUTE_NAME:
				this._stateAfterAttributeName(e);
				break;
			case R.BEFORE_ATTRIBUTE_VALUE:
				this._stateBeforeAttributeValue(e);
				break;
			case R.ATTRIBUTE_VALUE_DOUBLE_QUOTED:
				this._stateAttributeValueDoubleQuoted(e);
				break;
			case R.ATTRIBUTE_VALUE_SINGLE_QUOTED:
				this._stateAttributeValueSingleQuoted(e);
				break;
			case R.ATTRIBUTE_VALUE_UNQUOTED:
				this._stateAttributeValueUnquoted(e);
				break;
			case R.AFTER_ATTRIBUTE_VALUE_QUOTED:
				this._stateAfterAttributeValueQuoted(e);
				break;
			case R.SELF_CLOSING_START_TAG:
				this._stateSelfClosingStartTag(e);
				break;
			case R.BOGUS_COMMENT:
				this._stateBogusComment(e);
				break;
			case R.MARKUP_DECLARATION_OPEN:
				this._stateMarkupDeclarationOpen(e);
				break;
			case R.COMMENT_START:
				this._stateCommentStart(e);
				break;
			case R.COMMENT_START_DASH:
				this._stateCommentStartDash(e);
				break;
			case R.COMMENT:
				this._stateComment(e);
				break;
			case R.COMMENT_LESS_THAN_SIGN:
				this._stateCommentLessThanSign(e);
				break;
			case R.COMMENT_LESS_THAN_SIGN_BANG:
				this._stateCommentLessThanSignBang(e);
				break;
			case R.COMMENT_LESS_THAN_SIGN_BANG_DASH:
				this._stateCommentLessThanSignBangDash(e);
				break;
			case R.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH:
				this._stateCommentLessThanSignBangDashDash(e);
				break;
			case R.COMMENT_END_DASH:
				this._stateCommentEndDash(e);
				break;
			case R.COMMENT_END:
				this._stateCommentEnd(e);
				break;
			case R.COMMENT_END_BANG:
				this._stateCommentEndBang(e);
				break;
			case R.DOCTYPE:
				this._stateDoctype(e);
				break;
			case R.BEFORE_DOCTYPE_NAME:
				this._stateBeforeDoctypeName(e);
				break;
			case R.DOCTYPE_NAME:
				this._stateDoctypeName(e);
				break;
			case R.AFTER_DOCTYPE_NAME:
				this._stateAfterDoctypeName(e);
				break;
			case R.AFTER_DOCTYPE_PUBLIC_KEYWORD:
				this._stateAfterDoctypePublicKeyword(e);
				break;
			case R.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER:
				this._stateBeforeDoctypePublicIdentifier(e);
				break;
			case R.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED:
				this._stateDoctypePublicIdentifierDoubleQuoted(e);
				break;
			case R.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED:
				this._stateDoctypePublicIdentifierSingleQuoted(e);
				break;
			case R.AFTER_DOCTYPE_PUBLIC_IDENTIFIER:
				this._stateAfterDoctypePublicIdentifier(e);
				break;
			case R.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS:
				this._stateBetweenDoctypePublicAndSystemIdentifiers(e);
				break;
			case R.AFTER_DOCTYPE_SYSTEM_KEYWORD:
				this._stateAfterDoctypeSystemKeyword(e);
				break;
			case R.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER:
				this._stateBeforeDoctypeSystemIdentifier(e);
				break;
			case R.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED:
				this._stateDoctypeSystemIdentifierDoubleQuoted(e);
				break;
			case R.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED:
				this._stateDoctypeSystemIdentifierSingleQuoted(e);
				break;
			case R.AFTER_DOCTYPE_SYSTEM_IDENTIFIER:
				this._stateAfterDoctypeSystemIdentifier(e);
				break;
			case R.BOGUS_DOCTYPE:
				this._stateBogusDoctype(e);
				break;
			case R.CDATA_SECTION:
				this._stateCdataSection(e);
				break;
			case R.CDATA_SECTION_BRACKET:
				this._stateCdataSectionBracket(e);
				break;
			case R.CDATA_SECTION_END:
				this._stateCdataSectionEnd(e);
				break;
			case R.CHARACTER_REFERENCE:
				this._stateCharacterReference();
				break;
			case R.AMBIGUOUS_AMPERSAND:
				this._stateAmbiguousAmpersand(e);
				break;
			default: throw Error("Unknown state");
		}
	}
	_stateData(e) {
		switch (e) {
			case E.LESS_THAN_SIGN:
				this.state = R.TAG_OPEN;
				break;
			case E.AMPERSAND:
				this._startCharacterReference();
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this._emitCodePoint(e);
				break;
			case E.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateRcdata(e) {
		switch (e) {
			case E.AMPERSAND:
				this._startCharacterReference();
				break;
			case E.LESS_THAN_SIGN:
				this.state = R.RCDATA_LESS_THAN_SIGN;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this._emitChars("�");
				break;
			case E.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateRawtext(e) {
		switch (e) {
			case E.LESS_THAN_SIGN:
				this.state = R.RAWTEXT_LESS_THAN_SIGN;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this._emitChars("�");
				break;
			case E.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptData(e) {
		switch (e) {
			case E.LESS_THAN_SIGN:
				this.state = R.SCRIPT_DATA_LESS_THAN_SIGN;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this._emitChars("�");
				break;
			case E.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_statePlaintext(e) {
		switch (e) {
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this._emitChars("�");
				break;
			case E.EOF:
				this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateTagOpen(e) {
		if (Ve(e)) this._createStartTagToken(), this.state = R.TAG_NAME, this._stateTagName(e);
		else switch (e) {
			case E.EXCLAMATION_MARK:
				this.state = R.MARKUP_DECLARATION_OPEN;
				break;
			case E.SOLIDUS:
				this.state = R.END_TAG_OPEN;
				break;
			case E.QUESTION_MARK:
				this._err(O.unexpectedQuestionMarkInsteadOfTagName), this._createCommentToken(1), this.state = R.BOGUS_COMMENT, this._stateBogusComment(e);
				break;
			case E.EOF:
				this._err(O.eofBeforeTagName), this._emitChars("<"), this._emitEOFToken();
				break;
			default: this._err(O.invalidFirstCharacterOfTagName), this._emitChars("<"), this.state = R.DATA, this._stateData(e);
		}
	}
	_stateEndTagOpen(e) {
		if (Ve(e)) this._createEndTagToken(), this.state = R.TAG_NAME, this._stateTagName(e);
		else switch (e) {
			case E.GREATER_THAN_SIGN:
				this._err(O.missingEndTagName), this.state = R.DATA;
				break;
			case E.EOF:
				this._err(O.eofBeforeTagName), this._emitChars("</"), this._emitEOFToken();
				break;
			default: this._err(O.invalidFirstCharacterOfTagName), this._createCommentToken(2), this.state = R.BOGUS_COMMENT, this._stateBogusComment(e);
		}
	}
	_stateTagName(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
				this.state = R.BEFORE_ATTRIBUTE_NAME;
				break;
			case E.SOLIDUS:
				this.state = R.SELF_CLOSING_START_TAG;
				break;
			case E.GREATER_THAN_SIGN:
				this.state = R.DATA, this.emitCurrentTagToken();
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), t.tagName += "�";
				break;
			case E.EOF:
				this._err(O.eofInTag), this._emitEOFToken();
				break;
			default: t.tagName += String.fromCodePoint(ze(e) ? Ue(e) : e);
		}
	}
	_stateRcdataLessThanSign(e) {
		e === E.SOLIDUS ? this.state = R.RCDATA_END_TAG_OPEN : (this._emitChars("<"), this.state = R.RCDATA, this._stateRcdata(e));
	}
	_stateRcdataEndTagOpen(e) {
		Ve(e) ? (this.state = R.RCDATA_END_TAG_NAME, this._stateRcdataEndTagName(e)) : (this._emitChars("</"), this.state = R.RCDATA, this._stateRcdata(e));
	}
	handleSpecialEndTag(e) {
		if (!this.preprocessor.startsWith(this.lastStartTagName, !1)) return !this._ensureHibernation();
		this._createEndTagToken();
		let t = this.currentToken;
		switch (t.tagName = this.lastStartTagName, this.preprocessor.peek(this.lastStartTagName.length)) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: return this._advanceBy(this.lastStartTagName.length), this.state = R.BEFORE_ATTRIBUTE_NAME, !1;
			case E.SOLIDUS: return this._advanceBy(this.lastStartTagName.length), this.state = R.SELF_CLOSING_START_TAG, !1;
			case E.GREATER_THAN_SIGN: return this._advanceBy(this.lastStartTagName.length), this.emitCurrentTagToken(), this.state = R.DATA, !1;
			default: return !this._ensureHibernation();
		}
	}
	_stateRcdataEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = R.RCDATA, this._stateRcdata(e));
	}
	_stateRawtextLessThanSign(e) {
		e === E.SOLIDUS ? this.state = R.RAWTEXT_END_TAG_OPEN : (this._emitChars("<"), this.state = R.RAWTEXT, this._stateRawtext(e));
	}
	_stateRawtextEndTagOpen(e) {
		Ve(e) ? (this.state = R.RAWTEXT_END_TAG_NAME, this._stateRawtextEndTagName(e)) : (this._emitChars("</"), this.state = R.RAWTEXT, this._stateRawtext(e));
	}
	_stateRawtextEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = R.RAWTEXT, this._stateRawtext(e));
	}
	_stateScriptDataLessThanSign(e) {
		switch (e) {
			case E.SOLIDUS:
				this.state = R.SCRIPT_DATA_END_TAG_OPEN;
				break;
			case E.EXCLAMATION_MARK:
				this.state = R.SCRIPT_DATA_ESCAPE_START, this._emitChars("<!");
				break;
			default: this._emitChars("<"), this.state = R.SCRIPT_DATA, this._stateScriptData(e);
		}
	}
	_stateScriptDataEndTagOpen(e) {
		Ve(e) ? (this.state = R.SCRIPT_DATA_END_TAG_NAME, this._stateScriptDataEndTagName(e)) : (this._emitChars("</"), this.state = R.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = R.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscapeStart(e) {
		e === E.HYPHEN_MINUS ? (this.state = R.SCRIPT_DATA_ESCAPE_START_DASH, this._emitChars("-")) : (this.state = R.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscapeStartDash(e) {
		e === E.HYPHEN_MINUS ? (this.state = R.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-")) : (this.state = R.SCRIPT_DATA, this._stateScriptData(e));
	}
	_stateScriptDataEscaped(e) {
		switch (e) {
			case E.HYPHEN_MINUS:
				this.state = R.SCRIPT_DATA_ESCAPED_DASH, this._emitChars("-");
				break;
			case E.LESS_THAN_SIGN:
				this.state = R.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this._emitChars("�");
				break;
			case E.EOF:
				this._err(O.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedDash(e) {
		switch (e) {
			case E.HYPHEN_MINUS:
				this.state = R.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-");
				break;
			case E.LESS_THAN_SIGN:
				this.state = R.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this.state = R.SCRIPT_DATA_ESCAPED, this._emitChars("�");
				break;
			case E.EOF:
				this._err(O.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = R.SCRIPT_DATA_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedDashDash(e) {
		switch (e) {
			case E.HYPHEN_MINUS:
				this._emitChars("-");
				break;
			case E.LESS_THAN_SIGN:
				this.state = R.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
				break;
			case E.GREATER_THAN_SIGN:
				this.state = R.SCRIPT_DATA, this._emitChars(">");
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this.state = R.SCRIPT_DATA_ESCAPED, this._emitChars("�");
				break;
			case E.EOF:
				this._err(O.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = R.SCRIPT_DATA_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataEscapedLessThanSign(e) {
		e === E.SOLIDUS ? this.state = R.SCRIPT_DATA_ESCAPED_END_TAG_OPEN : Ve(e) ? (this._emitChars("<"), this.state = R.SCRIPT_DATA_DOUBLE_ESCAPE_START, this._stateScriptDataDoubleEscapeStart(e)) : (this._emitChars("<"), this.state = R.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataEscapedEndTagOpen(e) {
		Ve(e) ? (this.state = R.SCRIPT_DATA_ESCAPED_END_TAG_NAME, this._stateScriptDataEscapedEndTagName(e)) : (this._emitChars("</"), this.state = R.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataEscapedEndTagName(e) {
		this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = R.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataDoubleEscapeStart(e) {
		if (this.preprocessor.startsWith(D.SCRIPT, !1) && Ge(this.preprocessor.peek(D.SCRIPT.length))) {
			this._emitCodePoint(e);
			for (let e = 0; e < D.SCRIPT.length; e++) this._emitCodePoint(this._consume());
			this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED;
		} else this._ensureHibernation() || (this.state = R.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e));
	}
	_stateScriptDataDoubleEscaped(e) {
		switch (e) {
			case E.HYPHEN_MINUS:
				this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED_DASH, this._emitChars("-");
				break;
			case E.LESS_THAN_SIGN:
				this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this._emitChars("�");
				break;
			case E.EOF:
				this._err(O.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedDash(e) {
		switch (e) {
			case E.HYPHEN_MINUS:
				this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH, this._emitChars("-");
				break;
			case E.LESS_THAN_SIGN:
				this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars("�");
				break;
			case E.EOF:
				this._err(O.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedDashDash(e) {
		switch (e) {
			case E.HYPHEN_MINUS:
				this._emitChars("-");
				break;
			case E.LESS_THAN_SIGN:
				this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN, this._emitChars("<");
				break;
			case E.GREATER_THAN_SIGN:
				this.state = R.SCRIPT_DATA, this._emitChars(">");
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitChars("�");
				break;
			case E.EOF:
				this._err(O.eofInScriptHtmlCommentLikeText), this._emitEOFToken();
				break;
			default: this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED, this._emitCodePoint(e);
		}
	}
	_stateScriptDataDoubleEscapedLessThanSign(e) {
		e === E.SOLIDUS ? (this.state = R.SCRIPT_DATA_DOUBLE_ESCAPE_END, this._emitChars("/")) : (this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e));
	}
	_stateScriptDataDoubleEscapeEnd(e) {
		if (this.preprocessor.startsWith(D.SCRIPT, !1) && Ge(this.preprocessor.peek(D.SCRIPT.length))) {
			this._emitCodePoint(e);
			for (let e = 0; e < D.SCRIPT.length; e++) this._emitCodePoint(this._consume());
			this.state = R.SCRIPT_DATA_ESCAPED;
		} else this._ensureHibernation() || (this.state = R.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e));
	}
	_stateBeforeAttributeName(e) {
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.SOLIDUS:
			case E.GREATER_THAN_SIGN:
			case E.EOF:
				this.state = R.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(e);
				break;
			case E.EQUALS_SIGN:
				this._err(O.unexpectedEqualsSignBeforeAttributeName), this._createAttr("="), this.state = R.ATTRIBUTE_NAME;
				break;
			default: this._createAttr(""), this.state = R.ATTRIBUTE_NAME, this._stateAttributeName(e);
		}
	}
	_stateAttributeName(e) {
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
			case E.SOLIDUS:
			case E.GREATER_THAN_SIGN:
			case E.EOF:
				this._leaveAttrName(), this.state = R.AFTER_ATTRIBUTE_NAME, this._stateAfterAttributeName(e);
				break;
			case E.EQUALS_SIGN:
				this._leaveAttrName(), this.state = R.BEFORE_ATTRIBUTE_VALUE;
				break;
			case E.QUOTATION_MARK:
			case E.APOSTROPHE:
			case E.LESS_THAN_SIGN:
				this._err(O.unexpectedCharacterInAttributeName), this.currentAttr.name += String.fromCodePoint(e);
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this.currentAttr.name += "�";
				break;
			default: this.currentAttr.name += String.fromCodePoint(ze(e) ? Ue(e) : e);
		}
	}
	_stateAfterAttributeName(e) {
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.SOLIDUS:
				this.state = R.SELF_CLOSING_START_TAG;
				break;
			case E.EQUALS_SIGN:
				this.state = R.BEFORE_ATTRIBUTE_VALUE;
				break;
			case E.GREATER_THAN_SIGN:
				this.state = R.DATA, this.emitCurrentTagToken();
				break;
			case E.EOF:
				this._err(O.eofInTag), this._emitEOFToken();
				break;
			default: this._createAttr(""), this.state = R.ATTRIBUTE_NAME, this._stateAttributeName(e);
		}
	}
	_stateBeforeAttributeValue(e) {
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.QUOTATION_MARK:
				this.state = R.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
				break;
			case E.APOSTROPHE:
				this.state = R.ATTRIBUTE_VALUE_SINGLE_QUOTED;
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.missingAttributeValue), this.state = R.DATA, this.emitCurrentTagToken();
				break;
			default: this.state = R.ATTRIBUTE_VALUE_UNQUOTED, this._stateAttributeValueUnquoted(e);
		}
	}
	_stateAttributeValueDoubleQuoted(e) {
		switch (e) {
			case E.QUOTATION_MARK:
				this.state = R.AFTER_ATTRIBUTE_VALUE_QUOTED;
				break;
			case E.AMPERSAND:
				this._startCharacterReference();
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case E.EOF:
				this._err(O.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAttributeValueSingleQuoted(e) {
		switch (e) {
			case E.APOSTROPHE:
				this.state = R.AFTER_ATTRIBUTE_VALUE_QUOTED;
				break;
			case E.AMPERSAND:
				this._startCharacterReference();
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case E.EOF:
				this._err(O.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAttributeValueUnquoted(e) {
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
				this._leaveAttrValue(), this.state = R.BEFORE_ATTRIBUTE_NAME;
				break;
			case E.AMPERSAND:
				this._startCharacterReference();
				break;
			case E.GREATER_THAN_SIGN:
				this._leaveAttrValue(), this.state = R.DATA, this.emitCurrentTagToken();
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this.currentAttr.value += "�";
				break;
			case E.QUOTATION_MARK:
			case E.APOSTROPHE:
			case E.LESS_THAN_SIGN:
			case E.EQUALS_SIGN:
			case E.GRAVE_ACCENT:
				this._err(O.unexpectedCharacterInUnquotedAttributeValue), this.currentAttr.value += String.fromCodePoint(e);
				break;
			case E.EOF:
				this._err(O.eofInTag), this._emitEOFToken();
				break;
			default: this.currentAttr.value += String.fromCodePoint(e);
		}
	}
	_stateAfterAttributeValueQuoted(e) {
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
				this._leaveAttrValue(), this.state = R.BEFORE_ATTRIBUTE_NAME;
				break;
			case E.SOLIDUS:
				this._leaveAttrValue(), this.state = R.SELF_CLOSING_START_TAG;
				break;
			case E.GREATER_THAN_SIGN:
				this._leaveAttrValue(), this.state = R.DATA, this.emitCurrentTagToken();
				break;
			case E.EOF:
				this._err(O.eofInTag), this._emitEOFToken();
				break;
			default: this._err(O.missingWhitespaceBetweenAttributes), this.state = R.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(e);
		}
	}
	_stateSelfClosingStartTag(e) {
		switch (e) {
			case E.GREATER_THAN_SIGN: {
				let e = this.currentToken;
				e.selfClosing = !0, this.state = R.DATA, this.emitCurrentTagToken();
				break;
			}
			case E.EOF:
				this._err(O.eofInTag), this._emitEOFToken();
				break;
			default: this._err(O.unexpectedSolidusInTag), this.state = R.BEFORE_ATTRIBUTE_NAME, this._stateBeforeAttributeName(e);
		}
	}
	_stateBogusComment(e) {
		let t = this.currentToken;
		switch (e) {
			case E.GREATER_THAN_SIGN:
				this.state = R.DATA, this.emitCurrentComment(t);
				break;
			case E.EOF:
				this.emitCurrentComment(t), this._emitEOFToken();
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), t.data += "�";
				break;
			default: t.data += String.fromCodePoint(e);
		}
	}
	_stateMarkupDeclarationOpen(e) {
		this._consumeSequenceIfMatch(D.DASH_DASH, !0) ? (this._createCommentToken(D.DASH_DASH.length + 1), this.state = R.COMMENT_START) : this._consumeSequenceIfMatch(D.DOCTYPE, !1) ? (this.currentLocation = this.getCurrentLocation(D.DOCTYPE.length + 1), this.state = R.DOCTYPE) : this._consumeSequenceIfMatch(D.CDATA_START, !0) ? this.inForeignNode ? this.state = R.CDATA_SECTION : (this._err(O.cdataInHtmlContent), this._createCommentToken(D.CDATA_START.length + 1), this.currentToken.data = "[CDATA[", this.state = R.BOGUS_COMMENT) : this._ensureHibernation() || (this._err(O.incorrectlyOpenedComment), this._createCommentToken(2), this.state = R.BOGUS_COMMENT, this._stateBogusComment(e));
	}
	_stateCommentStart(e) {
		switch (e) {
			case E.HYPHEN_MINUS:
				this.state = R.COMMENT_START_DASH;
				break;
			case E.GREATER_THAN_SIGN: {
				this._err(O.abruptClosingOfEmptyComment), this.state = R.DATA;
				let e = this.currentToken;
				this.emitCurrentComment(e);
				break;
			}
			default: this.state = R.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentStartDash(e) {
		let t = this.currentToken;
		switch (e) {
			case E.HYPHEN_MINUS:
				this.state = R.COMMENT_END;
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.abruptClosingOfEmptyComment), this.state = R.DATA, this.emitCurrentComment(t);
				break;
			case E.EOF:
				this._err(O.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += "-", this.state = R.COMMENT, this._stateComment(e);
		}
	}
	_stateComment(e) {
		let t = this.currentToken;
		switch (e) {
			case E.HYPHEN_MINUS:
				this.state = R.COMMENT_END_DASH;
				break;
			case E.LESS_THAN_SIGN:
				t.data += "<", this.state = R.COMMENT_LESS_THAN_SIGN;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), t.data += "�";
				break;
			case E.EOF:
				this._err(O.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += String.fromCodePoint(e);
		}
	}
	_stateCommentLessThanSign(e) {
		let t = this.currentToken;
		switch (e) {
			case E.EXCLAMATION_MARK:
				t.data += "!", this.state = R.COMMENT_LESS_THAN_SIGN_BANG;
				break;
			case E.LESS_THAN_SIGN:
				t.data += "<";
				break;
			default: this.state = R.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentLessThanSignBang(e) {
		e === E.HYPHEN_MINUS ? this.state = R.COMMENT_LESS_THAN_SIGN_BANG_DASH : (this.state = R.COMMENT, this._stateComment(e));
	}
	_stateCommentLessThanSignBangDash(e) {
		e === E.HYPHEN_MINUS ? this.state = R.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH : (this.state = R.COMMENT_END_DASH, this._stateCommentEndDash(e));
	}
	_stateCommentLessThanSignBangDashDash(e) {
		e !== E.GREATER_THAN_SIGN && e !== E.EOF && this._err(O.nestedComment), this.state = R.COMMENT_END, this._stateCommentEnd(e);
	}
	_stateCommentEndDash(e) {
		let t = this.currentToken;
		switch (e) {
			case E.HYPHEN_MINUS:
				this.state = R.COMMENT_END;
				break;
			case E.EOF:
				this._err(O.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += "-", this.state = R.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentEnd(e) {
		let t = this.currentToken;
		switch (e) {
			case E.GREATER_THAN_SIGN:
				this.state = R.DATA, this.emitCurrentComment(t);
				break;
			case E.EXCLAMATION_MARK:
				this.state = R.COMMENT_END_BANG;
				break;
			case E.HYPHEN_MINUS:
				t.data += "-";
				break;
			case E.EOF:
				this._err(O.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += "--", this.state = R.COMMENT, this._stateComment(e);
		}
	}
	_stateCommentEndBang(e) {
		let t = this.currentToken;
		switch (e) {
			case E.HYPHEN_MINUS:
				t.data += "--!", this.state = R.COMMENT_END_DASH;
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.incorrectlyClosedComment), this.state = R.DATA, this.emitCurrentComment(t);
				break;
			case E.EOF:
				this._err(O.eofInComment), this.emitCurrentComment(t), this._emitEOFToken();
				break;
			default: t.data += "--!", this.state = R.COMMENT, this._stateComment(e);
		}
	}
	_stateDoctype(e) {
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
				this.state = R.BEFORE_DOCTYPE_NAME;
				break;
			case E.GREATER_THAN_SIGN:
				this.state = R.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(e);
				break;
			case E.EOF: {
				this._err(O.eofInDoctype), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this._emitEOFToken();
				break;
			}
			default: this._err(O.missingWhitespaceBeforeDoctypeName), this.state = R.BEFORE_DOCTYPE_NAME, this._stateBeforeDoctypeName(e);
		}
	}
	_stateBeforeDoctypeName(e) {
		if (ze(e)) this._createDoctypeToken(String.fromCharCode(Ue(e))), this.state = R.DOCTYPE_NAME;
		else switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), this._createDoctypeToken("�"), this.state = R.DOCTYPE_NAME;
				break;
			case E.GREATER_THAN_SIGN: {
				this._err(O.missingDoctypeName), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this.state = R.DATA;
				break;
			}
			case E.EOF: {
				this._err(O.eofInDoctype), this._createDoctypeToken(null);
				let e = this.currentToken;
				e.forceQuirks = !0, this.emitCurrentDoctype(e), this._emitEOFToken();
				break;
			}
			default: this._createDoctypeToken(String.fromCodePoint(e)), this.state = R.DOCTYPE_NAME;
		}
	}
	_stateDoctypeName(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
				this.state = R.AFTER_DOCTYPE_NAME;
				break;
			case E.GREATER_THAN_SIGN:
				this.state = R.DATA, this.emitCurrentDoctype(t);
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), t.name += "�";
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.name += String.fromCodePoint(ze(e) ? Ue(e) : e);
		}
	}
	_stateAfterDoctypeName(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.GREATER_THAN_SIGN:
				this.state = R.DATA, this.emitCurrentDoctype(t);
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._consumeSequenceIfMatch(D.PUBLIC, !1) ? this.state = R.AFTER_DOCTYPE_PUBLIC_KEYWORD : this._consumeSequenceIfMatch(D.SYSTEM, !1) ? this.state = R.AFTER_DOCTYPE_SYSTEM_KEYWORD : this._ensureHibernation() || (this._err(O.invalidCharacterSequenceAfterDoctypeName), t.forceQuirks = !0, this.state = R.BOGUS_DOCTYPE, this._stateBogusDoctype(e));
		}
	}
	_stateAfterDoctypePublicKeyword(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
				this.state = R.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case E.QUOTATION_MARK:
				this._err(O.missingWhitespaceAfterDoctypePublicKeyword), t.publicId = "", this.state = R.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case E.APOSTROPHE:
				this._err(O.missingWhitespaceAfterDoctypePublicKeyword), t.publicId = "", this.state = R.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.missingDoctypePublicIdentifier), t.forceQuirks = !0, this.state = R.DATA, this.emitCurrentDoctype(t);
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(O.missingQuoteBeforeDoctypePublicIdentifier), t.forceQuirks = !0, this.state = R.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBeforeDoctypePublicIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.QUOTATION_MARK:
				t.publicId = "", this.state = R.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case E.APOSTROPHE:
				t.publicId = "", this.state = R.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.missingDoctypePublicIdentifier), t.forceQuirks = !0, this.state = R.DATA, this.emitCurrentDoctype(t);
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(O.missingQuoteBeforeDoctypePublicIdentifier), t.forceQuirks = !0, this.state = R.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateDoctypePublicIdentifierDoubleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case E.QUOTATION_MARK:
				this.state = R.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), t.publicId += "�";
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.abruptDoctypePublicIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = R.DATA;
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.publicId += String.fromCodePoint(e);
		}
	}
	_stateDoctypePublicIdentifierSingleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case E.APOSTROPHE:
				this.state = R.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), t.publicId += "�";
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.abruptDoctypePublicIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = R.DATA;
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.publicId += String.fromCodePoint(e);
		}
	}
	_stateAfterDoctypePublicIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
				this.state = R.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
				break;
			case E.GREATER_THAN_SIGN:
				this.state = R.DATA, this.emitCurrentDoctype(t);
				break;
			case E.QUOTATION_MARK:
				this._err(O.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), t.systemId = "", this.state = R.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case E.APOSTROPHE:
				this._err(O.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers), t.systemId = "", this.state = R.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(O.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = R.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBetweenDoctypePublicAndSystemIdentifiers(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = R.DATA;
				break;
			case E.QUOTATION_MARK:
				t.systemId = "", this.state = R.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case E.APOSTROPHE:
				t.systemId = "", this.state = R.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(O.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = R.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateAfterDoctypeSystemKeyword(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED:
				this.state = R.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case E.QUOTATION_MARK:
				this._err(O.missingWhitespaceAfterDoctypeSystemKeyword), t.systemId = "", this.state = R.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case E.APOSTROPHE:
				this._err(O.missingWhitespaceAfterDoctypeSystemKeyword), t.systemId = "", this.state = R.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.missingDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = R.DATA, this.emitCurrentDoctype(t);
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(O.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = R.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBeforeDoctypeSystemIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.QUOTATION_MARK:
				t.systemId = "", this.state = R.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
				break;
			case E.APOSTROPHE:
				t.systemId = "", this.state = R.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.missingDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = R.DATA, this.emitCurrentDoctype(t);
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(O.missingQuoteBeforeDoctypeSystemIdentifier), t.forceQuirks = !0, this.state = R.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateDoctypeSystemIdentifierDoubleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case E.QUOTATION_MARK:
				this.state = R.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), t.systemId += "�";
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.abruptDoctypeSystemIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = R.DATA;
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.systemId += String.fromCodePoint(e);
		}
	}
	_stateDoctypeSystemIdentifierSingleQuoted(e) {
		let t = this.currentToken;
		switch (e) {
			case E.APOSTROPHE:
				this.state = R.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter), t.systemId += "�";
				break;
			case E.GREATER_THAN_SIGN:
				this._err(O.abruptDoctypeSystemIdentifier), t.forceQuirks = !0, this.emitCurrentDoctype(t), this.state = R.DATA;
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: t.systemId += String.fromCodePoint(e);
		}
	}
	_stateAfterDoctypeSystemIdentifier(e) {
		let t = this.currentToken;
		switch (e) {
			case E.SPACE:
			case E.LINE_FEED:
			case E.TABULATION:
			case E.FORM_FEED: break;
			case E.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = R.DATA;
				break;
			case E.EOF:
				this._err(O.eofInDoctype), t.forceQuirks = !0, this.emitCurrentDoctype(t), this._emitEOFToken();
				break;
			default: this._err(O.unexpectedCharacterAfterDoctypeSystemIdentifier), this.state = R.BOGUS_DOCTYPE, this._stateBogusDoctype(e);
		}
	}
	_stateBogusDoctype(e) {
		let t = this.currentToken;
		switch (e) {
			case E.GREATER_THAN_SIGN:
				this.emitCurrentDoctype(t), this.state = R.DATA;
				break;
			case E.NULL:
				this._err(O.unexpectedNullCharacter);
				break;
			case E.EOF: this.emitCurrentDoctype(t), this._emitEOFToken();
		}
	}
	_stateCdataSection(e) {
		switch (e) {
			case E.RIGHT_SQUARE_BRACKET:
				this.state = R.CDATA_SECTION_BRACKET;
				break;
			case E.EOF:
				this._err(O.eofInCdata), this._emitEOFToken();
				break;
			default: this._emitCodePoint(e);
		}
	}
	_stateCdataSectionBracket(e) {
		e === E.RIGHT_SQUARE_BRACKET ? this.state = R.CDATA_SECTION_END : (this._emitChars("]"), this.state = R.CDATA_SECTION, this._stateCdataSection(e));
	}
	_stateCdataSectionEnd(e) {
		switch (e) {
			case E.GREATER_THAN_SIGN:
				this.state = R.DATA;
				break;
			case E.RIGHT_SQUARE_BRACKET:
				this._emitChars("]");
				break;
			default: this._emitChars("]]"), this.state = R.CDATA_SECTION, this._stateCdataSection(e);
		}
	}
	_stateCharacterReference() {
		let e = this.entityDecoder.write(this.preprocessor.html, this.preprocessor.pos);
		if (e < 0) {
			if (this.preprocessor.lastChunkWritten) e = this.entityDecoder.end();
			else {
				this.active = !1, this.preprocessor.pos = this.preprocessor.html.length - 1, this.consumedAfterSnapshot = 0, this.preprocessor.endOfChunkHit = !0;
				return;
			}
		}
		e === 0 ? (this.preprocessor.pos = this.entityStartPos, this._flushCodePointConsumedAsCharacterReference(E.AMPERSAND), this.state = !this._isCharacterReferenceInAttribute() && He(this.preprocessor.peek(1)) ? R.AMBIGUOUS_AMPERSAND : this.returnState) : this.state = this.returnState;
	}
	_stateAmbiguousAmpersand(e) {
		He(e) ? this._flushCodePointConsumedAsCharacterReference(e) : (e === E.SEMICOLON && this._err(O.unknownNamedCharacterReference), this.state = this.returnState, this._callState(e));
	}
}, Je = /* @__PURE__ */ new Set([
	I.DD,
	I.DT,
	I.LI,
	I.OPTGROUP,
	I.OPTION,
	I.P,
	I.RB,
	I.RP,
	I.RT,
	I.RTC
]), Ye = /* @__PURE__ */ new Set([
	...Je,
	I.CAPTION,
	I.COLGROUP,
	I.TBODY,
	I.TD,
	I.TFOOT,
	I.TH,
	I.THEAD,
	I.TR
]), Xe = /* @__PURE__ */ new Set([
	I.APPLET,
	I.CAPTION,
	I.HTML,
	I.MARQUEE,
	I.OBJECT,
	I.TABLE,
	I.TD,
	I.TEMPLATE,
	I.TH
]), Ze = /* @__PURE__ */ new Set([
	...Xe,
	I.OL,
	I.UL
]), Qe = /* @__PURE__ */ new Set([...Xe, I.BUTTON]), $e = /* @__PURE__ */ new Set([
	I.ANNOTATION_XML,
	I.MI,
	I.MN,
	I.MO,
	I.MS,
	I.MTEXT
]), et = /* @__PURE__ */ new Set([
	I.DESC,
	I.FOREIGN_OBJECT,
	I.TITLE
]), tt = /* @__PURE__ */ new Set([
	I.TR,
	I.TEMPLATE,
	I.HTML
]), nt = /* @__PURE__ */ new Set([
	I.TBODY,
	I.TFOOT,
	I.THEAD,
	I.TEMPLATE,
	I.HTML
]), rt = /* @__PURE__ */ new Set([
	I.TABLE,
	I.TEMPLATE,
	I.HTML
]), it = /* @__PURE__ */ new Set([I.TD, I.TH]), at = class {
	get currentTmplContentOrNode() {
		return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current;
	}
	constructor(e, t, n) {
		this.treeAdapter = t, this.handler = n, this.items = [], this.tagIDs = [], this.stackTop = -1, this.tmplCount = 0, this.currentTagId = I.UNKNOWN, this.current = e;
	}
	_indexOf(e) {
		return this.items.lastIndexOf(e, this.stackTop);
	}
	_isInTemplate() {
		return this.currentTagId === I.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === N.HTML;
	}
	_updateCurrentElement() {
		this.current = this.items[this.stackTop], this.currentTagId = this.tagIDs[this.stackTop];
	}
	push(e, t) {
		this.stackTop++, this.items[this.stackTop] = e, this.current = e, this.tagIDs[this.stackTop] = t, this.currentTagId = t, this._isInTemplate() && this.tmplCount++, this.handler.onItemPush(e, t, !0);
	}
	pop() {
		let e = this.current;
		this.tmplCount > 0 && this._isInTemplate() && this.tmplCount--, this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(e, !0);
	}
	replace(e, t) {
		let n = this._indexOf(e);
		this.items[n] = t, n === this.stackTop && (this.current = t);
	}
	insertAfter(e, t, n) {
		let r = this._indexOf(e) + 1;
		this.items.splice(r, 0, t), this.tagIDs.splice(r, 0, n), this.stackTop++, r === this.stackTop && this._updateCurrentElement(), this.current && this.currentTagId !== void 0 && this.handler.onItemPush(this.current, this.currentTagId, r === this.stackTop);
	}
	popUntilTagNamePopped(e) {
		let t = this.stackTop + 1;
		do
			t = this.tagIDs.lastIndexOf(e, t - 1);
		while (t > 0 && this.treeAdapter.getNamespaceURI(this.items[t]) !== N.HTML);
		this.shortenToLength(Math.max(t, 0));
	}
	shortenToLength(e) {
		for (; this.stackTop >= e;) {
			let t = this.current;
			this.tmplCount > 0 && this._isInTemplate() && --this.tmplCount, this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(t, this.stackTop < e);
		}
	}
	popUntilElementPopped(e) {
		let t = this._indexOf(e);
		this.shortenToLength(Math.max(t, 0));
	}
	popUntilPopped(e, t) {
		let n = this._indexOfTagNames(e, t);
		this.shortenToLength(Math.max(n, 0));
	}
	popUntilNumberedHeaderPopped() {
		this.popUntilPopped(Fe, N.HTML);
	}
	popUntilTableCellPopped() {
		this.popUntilPopped(it, N.HTML);
	}
	popAllUpToHtmlElement() {
		this.tmplCount = 0, this.shortenToLength(1);
	}
	_indexOfTagNames(e, t) {
		for (let n = this.stackTop; n >= 0; n--) if (e.has(this.tagIDs[n]) && this.treeAdapter.getNamespaceURI(this.items[n]) === t) return n;
		return -1;
	}
	clearBackTo(e, t) {
		let n = this._indexOfTagNames(e, t);
		this.shortenToLength(n + 1);
	}
	clearBackToTableContext() {
		this.clearBackTo(rt, N.HTML);
	}
	clearBackToTableBodyContext() {
		this.clearBackTo(nt, N.HTML);
	}
	clearBackToTableRowContext() {
		this.clearBackTo(tt, N.HTML);
	}
	remove(e) {
		let t = this._indexOf(e);
		t >= 0 && (t === this.stackTop ? this.pop() : (this.items.splice(t, 1), this.tagIDs.splice(t, 1), this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(e, !1)));
	}
	tryPeekProperlyNestedBodyElement() {
		return this.stackTop >= 1 && this.tagIDs[1] === I.BODY ? this.items[1] : null;
	}
	contains(e) {
		return this._indexOf(e) > -1;
	}
	getCommonAncestor(e) {
		let t = this._indexOf(e) - 1;
		return t >= 0 ? this.items[t] : null;
	}
	isRootHtmlElementCurrent() {
		return this.stackTop === 0 && this.tagIDs[0] === I.HTML;
	}
	hasInDynamicScope(e, t) {
		for (let n = this.stackTop; n >= 0; n--) {
			let r = this.tagIDs[n];
			switch (this.treeAdapter.getNamespaceURI(this.items[n])) {
				case N.HTML:
					if (r === e) return !0;
					if (t.has(r)) return !1;
					break;
				case N.SVG:
					if (et.has(r)) return !1;
					break;
				case N.MATHML: if ($e.has(r)) return !1;
			}
		}
		return !0;
	}
	hasInScope(e) {
		return this.hasInDynamicScope(e, Xe);
	}
	hasInListItemScope(e) {
		return this.hasInDynamicScope(e, Ze);
	}
	hasInButtonScope(e) {
		return this.hasInDynamicScope(e, Qe);
	}
	hasNumberedHeaderInScope() {
		for (let e = this.stackTop; e >= 0; e--) {
			let t = this.tagIDs[e];
			switch (this.treeAdapter.getNamespaceURI(this.items[e])) {
				case N.HTML:
					if (Fe.has(t)) return !0;
					if (Xe.has(t)) return !1;
					break;
				case N.SVG:
					if (et.has(t)) return !1;
					break;
				case N.MATHML: if ($e.has(t)) return !1;
			}
		}
		return !0;
	}
	hasInTableScope(e) {
		for (let t = this.stackTop; t >= 0; t--) if (this.treeAdapter.getNamespaceURI(this.items[t]) === N.HTML) switch (this.tagIDs[t]) {
			case e: return !0;
			case I.TABLE:
			case I.HTML: return !1;
		}
		return !0;
	}
	hasTableBodyContextInTableScope() {
		for (let e = this.stackTop; e >= 0; e--) if (this.treeAdapter.getNamespaceURI(this.items[e]) === N.HTML) switch (this.tagIDs[e]) {
			case I.TBODY:
			case I.THEAD:
			case I.TFOOT: return !0;
			case I.TABLE:
			case I.HTML: return !1;
		}
		return !0;
	}
	hasInSelectScope(e) {
		for (let t = this.stackTop; t >= 0; t--) if (this.treeAdapter.getNamespaceURI(this.items[t]) === N.HTML) switch (this.tagIDs[t]) {
			case e: return !0;
			case I.OPTION:
			case I.OPTGROUP: break;
			default: return !1;
		}
		return !0;
	}
	generateImpliedEndTags() {
		for (; this.currentTagId !== void 0 && Je.has(this.currentTagId);) this.pop();
	}
	generateImpliedEndTagsThoroughly() {
		for (; this.currentTagId !== void 0 && Ye.has(this.currentTagId);) this.pop();
	}
	generateImpliedEndTagsWithExclusion(e) {
		for (; this.currentTagId !== void 0 && this.currentTagId !== e && Ye.has(this.currentTagId);) this.pop();
	}
}, ot = 3, st;
(function(e) {
	e[e.Marker = 0] = "Marker", e[e.Element = 1] = "Element";
})(st ||= {});
var ct = { type: st.Marker }, lt = class {
	constructor(e) {
		this.treeAdapter = e, this.entries = [], this.bookmark = null;
	}
	_getNoahArkConditionCandidates(e, t) {
		let n = [], r = t.length, i = this.treeAdapter.getTagName(e), a = this.treeAdapter.getNamespaceURI(e);
		for (let e = 0; e < this.entries.length; e++) {
			let t = this.entries[e];
			if (t.type === st.Marker) break;
			let { element: o } = t;
			if (this.treeAdapter.getTagName(o) === i && this.treeAdapter.getNamespaceURI(o) === a) {
				let t = this.treeAdapter.getAttrList(o);
				t.length === r && n.push({
					idx: e,
					attrs: t
				});
			}
		}
		return n;
	}
	_ensureNoahArkCondition(e) {
		if (this.entries.length < ot) return;
		let t = this.treeAdapter.getAttrList(e), n = this._getNoahArkConditionCandidates(e, t);
		if (n.length < ot) return;
		let r = new Map(t.map((e) => [e.name, e.value])), i = 0;
		for (let e = 0; e < n.length; e++) {
			let t = n[e];
			t.attrs.every((e) => r.get(e.name) === e.value) && (i += 1, i >= ot && this.entries.splice(t.idx, 1));
		}
	}
	insertMarker() {
		this.entries.unshift(ct);
	}
	pushElement(e, t) {
		this._ensureNoahArkCondition(e), this.entries.unshift({
			type: st.Element,
			element: e,
			token: t
		});
	}
	insertElementAfterBookmark(e, t) {
		let n = this.entries.indexOf(this.bookmark);
		this.entries.splice(n, 0, {
			type: st.Element,
			element: e,
			token: t
		});
	}
	removeEntry(e) {
		let t = this.entries.indexOf(e);
		t !== -1 && this.entries.splice(t, 1);
	}
	clearToLastMarker() {
		let e = this.entries.indexOf(ct);
		e === -1 ? this.entries.length = 0 : this.entries.splice(0, e + 1);
	}
	getElementEntryInScopeWithTagName(e) {
		let t = this.entries.find((t) => t.type === st.Marker || this.treeAdapter.getTagName(t.element) === e);
		return t && t.type === st.Element ? t : null;
	}
	getElementEntry(e) {
		return this.entries.find((t) => t.type === st.Element && t.element === e);
	}
}, B = {
	createDocument() {
		return {
			nodeName: "#document",
			mode: P.NO_QUIRKS,
			childNodes: []
		};
	},
	createDocumentFragment() {
		return {
			nodeName: "#document-fragment",
			childNodes: []
		};
	},
	createElement(e, t, n) {
		return {
			nodeName: e,
			tagName: e,
			attrs: n,
			namespaceURI: t,
			childNodes: [],
			parentNode: null
		};
	},
	createCommentNode(e) {
		return {
			nodeName: "#comment",
			data: e,
			parentNode: null
		};
	},
	createTextNode(e) {
		return {
			nodeName: "#text",
			value: e,
			parentNode: null
		};
	},
	appendChild(e, t) {
		e.childNodes.push(t), t.parentNode = e;
	},
	insertBefore(e, t, n) {
		let r = e.childNodes.indexOf(n);
		e.childNodes.splice(r, 0, t), t.parentNode = e;
	},
	setTemplateContent(e, t) {
		e.content = t;
	},
	getTemplateContent(e) {
		return e.content;
	},
	setDocumentType(e, t, n, r) {
		let i = e.childNodes.find((e) => e.nodeName === "#documentType");
		if (i) i.name = t, i.publicId = n, i.systemId = r;
		else {
			let i = {
				nodeName: "#documentType",
				name: t,
				publicId: n,
				systemId: r,
				parentNode: null
			};
			B.appendChild(e, i);
		}
	},
	setDocumentMode(e, t) {
		e.mode = t;
	},
	getDocumentMode(e) {
		return e.mode;
	},
	detachNode(e) {
		if (e.parentNode) {
			let t = e.parentNode.childNodes.indexOf(e);
			e.parentNode.childNodes.splice(t, 1), e.parentNode = null;
		}
	},
	insertText(e, t) {
		if (e.childNodes.length > 0) {
			let n = e.childNodes[e.childNodes.length - 1];
			if (B.isTextNode(n)) {
				n.value += t;
				return;
			}
		}
		B.appendChild(e, B.createTextNode(t));
	},
	insertTextBefore(e, t, n) {
		let r = e.childNodes[e.childNodes.indexOf(n) - 1];
		r && B.isTextNode(r) ? r.value += t : B.insertBefore(e, B.createTextNode(t), n);
	},
	adoptAttributes(e, t) {
		let n = new Set(e.attrs.map((e) => e.name));
		for (let r = 0; r < t.length; r++) n.has(t[r].name) || e.attrs.push(t[r]);
	},
	getFirstChild(e) {
		return e.childNodes[0];
	},
	getChildNodes(e) {
		return e.childNodes;
	},
	getParentNode(e) {
		return e.parentNode;
	},
	getAttrList(e) {
		return e.attrs;
	},
	getTagName(e) {
		return e.tagName;
	},
	getNamespaceURI(e) {
		return e.namespaceURI;
	},
	getTextNodeContent(e) {
		return e.value;
	},
	getCommentNodeContent(e) {
		return e.data;
	},
	getDocumentTypeNodeName(e) {
		return e.name;
	},
	getDocumentTypeNodePublicId(e) {
		return e.publicId;
	},
	getDocumentTypeNodeSystemId(e) {
		return e.systemId;
	},
	isTextNode(e) {
		return e.nodeName === "#text";
	},
	isCommentNode(e) {
		return e.nodeName === "#comment";
	},
	isDocumentTypeNode(e) {
		return e.nodeName === "#documentType";
	},
	isElementNode(e) {
		return Object.prototype.hasOwnProperty.call(e, "tagName");
	},
	setNodeSourceCodeLocation(e, t) {
		e.sourceCodeLocation = t;
	},
	getNodeSourceCodeLocation(e) {
		return e.sourceCodeLocation;
	},
	updateNodeSourceCodeLocation(e, t) {
		e.sourceCodeLocation = {
			...e.sourceCodeLocation,
			...t
		};
	}
}, ut = "html", dt = "about:legacy-compat", ft = "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd", pt = /* @__PURE__ */ "+//silmaril//dtd html pro v0r11 19970101//,-//as//dtd html 3.0 aswedit + extensions//,-//advasoft ltd//dtd html 3.0 aswedit + extensions//,-//ietf//dtd html 2.0 level 1//,-//ietf//dtd html 2.0 level 2//,-//ietf//dtd html 2.0 strict level 1//,-//ietf//dtd html 2.0 strict level 2//,-//ietf//dtd html 2.0 strict//,-//ietf//dtd html 2.0//,-//ietf//dtd html 2.1e//,-//ietf//dtd html 3.0//,-//ietf//dtd html 3.2 final//,-//ietf//dtd html 3.2//,-//ietf//dtd html 3//,-//ietf//dtd html level 0//,-//ietf//dtd html level 1//,-//ietf//dtd html level 2//,-//ietf//dtd html level 3//,-//ietf//dtd html strict level 0//,-//ietf//dtd html strict level 1//,-//ietf//dtd html strict level 2//,-//ietf//dtd html strict level 3//,-//ietf//dtd html strict//,-//ietf//dtd html//,-//metrius//dtd metrius presentational//,-//microsoft//dtd internet explorer 2.0 html strict//,-//microsoft//dtd internet explorer 2.0 html//,-//microsoft//dtd internet explorer 2.0 tables//,-//microsoft//dtd internet explorer 3.0 html strict//,-//microsoft//dtd internet explorer 3.0 html//,-//microsoft//dtd internet explorer 3.0 tables//,-//netscape comm. corp.//dtd html//,-//netscape comm. corp.//dtd strict html//,-//o'reilly and associates//dtd html 2.0//,-//o'reilly and associates//dtd html extended 1.0//,-//o'reilly and associates//dtd html extended relaxed 1.0//,-//sq//dtd html 2.0 hotmetal + extensions//,-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//,-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//,-//spyglass//dtd html 2.0 extended//,-//sun microsystems corp.//dtd hotjava html//,-//sun microsystems corp.//dtd hotjava strict html//,-//w3c//dtd html 3 1995-03-24//,-//w3c//dtd html 3.2 draft//,-//w3c//dtd html 3.2 final//,-//w3c//dtd html 3.2//,-//w3c//dtd html 3.2s draft//,-//w3c//dtd html 4.0 frameset//,-//w3c//dtd html 4.0 transitional//,-//w3c//dtd html experimental 19960712//,-//w3c//dtd html experimental 970421//,-//w3c//dtd w3 html//,-//w3o//dtd w3 html 3.0//,-//webtechs//dtd mozilla html 2.0//,-//webtechs//dtd mozilla html//".split(","), mt = [
	...pt,
	"-//w3c//dtd html 4.01 frameset//",
	"-//w3c//dtd html 4.01 transitional//"
], ht = /* @__PURE__ */ new Set([
	"-//w3o//dtd w3 html strict 3.0//en//",
	"-/w3c/dtd html 4.0 transitional/en",
	"html"
]), gt = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"], _t = [
	...gt,
	"-//w3c//dtd html 4.01 frameset//",
	"-//w3c//dtd html 4.01 transitional//"
];
function vt(e, t) {
	return t.some((t) => e.startsWith(t));
}
function yt(e) {
	return e.name === ut && e.publicId === null && (e.systemId === null || e.systemId === dt);
}
function bt(e) {
	if (e.name !== ut) return P.QUIRKS;
	let { systemId: t } = e;
	if (t && t.toLowerCase() === ft) return P.QUIRKS;
	let { publicId: n } = e;
	if (n !== null) {
		if (n = n.toLowerCase(), ht.has(n)) return P.QUIRKS;
		let e = t === null ? mt : pt;
		if (vt(n, e)) return P.QUIRKS;
		if (e = t === null ? gt : _t, vt(n, e)) return P.LIMITED_QUIRKS;
	}
	return P.NO_QUIRKS;
}
// node_modules/parse5/dist/common/foreign-content.js
var xt = {
	TEXT_HTML: "text/html",
	APPLICATION_XML: "application/xhtml+xml"
}, St = "definitionurl", Ct = "definitionURL", wt = new Map((/* @__PURE__ */ "attributeName.attributeType.baseFrequency.baseProfile.calcMode.clipPathUnits.diffuseConstant.edgeMode.filterUnits.glyphRef.gradientTransform.gradientUnits.kernelMatrix.kernelUnitLength.keyPoints.keySplines.keyTimes.lengthAdjust.limitingConeAngle.markerHeight.markerUnits.markerWidth.maskContentUnits.maskUnits.numOctaves.pathLength.patternContentUnits.patternTransform.patternUnits.pointsAtX.pointsAtY.pointsAtZ.preserveAlpha.preserveAspectRatio.primitiveUnits.refX.refY.repeatCount.repeatDur.requiredExtensions.requiredFeatures.specularConstant.specularExponent.spreadMethod.startOffset.stdDeviation.stitchTiles.surfaceScale.systemLanguage.tableValues.targetX.targetY.textLength.viewBox.viewTarget.xChannelSelector.yChannelSelector.zoomAndPan".split(".")).map((e) => [e.toLowerCase(), e])), Tt = /* @__PURE__ */ new Map([
	["xlink:actuate", {
		prefix: "xlink",
		name: "actuate",
		namespace: N.XLINK
	}],
	["xlink:arcrole", {
		prefix: "xlink",
		name: "arcrole",
		namespace: N.XLINK
	}],
	["xlink:href", {
		prefix: "xlink",
		name: "href",
		namespace: N.XLINK
	}],
	["xlink:role", {
		prefix: "xlink",
		name: "role",
		namespace: N.XLINK
	}],
	["xlink:show", {
		prefix: "xlink",
		name: "show",
		namespace: N.XLINK
	}],
	["xlink:title", {
		prefix: "xlink",
		name: "title",
		namespace: N.XLINK
	}],
	["xlink:type", {
		prefix: "xlink",
		name: "type",
		namespace: N.XLINK
	}],
	["xml:lang", {
		prefix: "xml",
		name: "lang",
		namespace: N.XML
	}],
	["xml:space", {
		prefix: "xml",
		name: "space",
		namespace: N.XML
	}],
	["xmlns", {
		prefix: "",
		name: "xmlns",
		namespace: N.XMLNS
	}],
	["xmlns:xlink", {
		prefix: "xmlns",
		name: "xlink",
		namespace: N.XMLNS
	}]
]), Et = new Map((/* @__PURE__ */ "altGlyph.altGlyphDef.altGlyphItem.animateColor.animateMotion.animateTransform.clipPath.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feDistantLight.feFlood.feFuncA.feFuncB.feFuncG.feFuncR.feGaussianBlur.feImage.feMerge.feMergeNode.feMorphology.feOffset.fePointLight.feSpecularLighting.feSpotLight.feTile.feTurbulence.foreignObject.glyphRef.linearGradient.radialGradient.textPath".split(".")).map((e) => [e.toLowerCase(), e])), Dt = /* @__PURE__ */ new Set([
	I.B,
	I.BIG,
	I.BLOCKQUOTE,
	I.BODY,
	I.BR,
	I.CENTER,
	I.CODE,
	I.DD,
	I.DIV,
	I.DL,
	I.DT,
	I.EM,
	I.EMBED,
	I.H1,
	I.H2,
	I.H3,
	I.H4,
	I.H5,
	I.H6,
	I.HEAD,
	I.HR,
	I.I,
	I.IMG,
	I.LI,
	I.LISTING,
	I.MENU,
	I.META,
	I.NOBR,
	I.OL,
	I.P,
	I.PRE,
	I.RUBY,
	I.S,
	I.SMALL,
	I.SPAN,
	I.STRONG,
	I.STRIKE,
	I.SUB,
	I.SUP,
	I.TABLE,
	I.TT,
	I.U,
	I.UL,
	I.VAR
]);
function Ot(e) {
	let t = e.tagID;
	return t === I.FONT && e.attrs.some(({ name: e }) => e === je.COLOR || e === je.SIZE || e === je.FACE) || Dt.has(t);
}
function kt(e) {
	for (let t = 0; t < e.attrs.length; t++) if (e.attrs[t].name === St) {
		e.attrs[t].name = Ct;
		break;
	}
}
function At(e) {
	for (let t = 0; t < e.attrs.length; t++) {
		let n = wt.get(e.attrs[t].name);
		n != null && (e.attrs[t].name = n);
	}
}
function jt(e) {
	for (let t = 0; t < e.attrs.length; t++) {
		let n = Tt.get(e.attrs[t].name);
		n && (e.attrs[t].prefix = n.prefix, e.attrs[t].name = n.name, e.attrs[t].namespace = n.namespace);
	}
}
function Mt(e) {
	let t = Et.get(e.tagName);
	t != null && (e.tagName = t, e.tagID = Ne(e.tagName));
}
function Nt(e, t) {
	return t === N.MATHML && (e === I.MI || e === I.MO || e === I.MN || e === I.MS || e === I.MTEXT);
}
function Pt(e, t, n) {
	if (t === N.MATHML && e === I.ANNOTATION_XML) {
		for (let e = 0; e < n.length; e++) if (n[e].name === je.ENCODING) {
			let t = n[e].value.toLowerCase();
			return t === xt.TEXT_HTML || t === xt.APPLICATION_XML;
		}
	}
	return t === N.SVG && (e === I.FOREIGN_OBJECT || e === I.DESC || e === I.TITLE);
}
function Ft(e, t, n, r) {
	return (!r || r === N.HTML) && Pt(e, t, n) || (!r || r === N.MATHML) && Nt(e, t);
}
// node_modules/parse5/dist/parser/index.js
var It = "hidden", Lt = 8, Rt = 3, V;
(function(e) {
	e[e.INITIAL = 0] = "INITIAL", e[e.BEFORE_HTML = 1] = "BEFORE_HTML", e[e.BEFORE_HEAD = 2] = "BEFORE_HEAD", e[e.IN_HEAD = 3] = "IN_HEAD", e[e.IN_HEAD_NO_SCRIPT = 4] = "IN_HEAD_NO_SCRIPT", e[e.AFTER_HEAD = 5] = "AFTER_HEAD", e[e.IN_BODY = 6] = "IN_BODY", e[e.TEXT = 7] = "TEXT", e[e.IN_TABLE = 8] = "IN_TABLE", e[e.IN_TABLE_TEXT = 9] = "IN_TABLE_TEXT", e[e.IN_CAPTION = 10] = "IN_CAPTION", e[e.IN_COLUMN_GROUP = 11] = "IN_COLUMN_GROUP", e[e.IN_TABLE_BODY = 12] = "IN_TABLE_BODY", e[e.IN_ROW = 13] = "IN_ROW", e[e.IN_CELL = 14] = "IN_CELL", e[e.IN_SELECT = 15] = "IN_SELECT", e[e.IN_SELECT_IN_TABLE = 16] = "IN_SELECT_IN_TABLE", e[e.IN_TEMPLATE = 17] = "IN_TEMPLATE", e[e.AFTER_BODY = 18] = "AFTER_BODY", e[e.IN_FRAMESET = 19] = "IN_FRAMESET", e[e.AFTER_FRAMESET = 20] = "AFTER_FRAMESET", e[e.AFTER_AFTER_BODY = 21] = "AFTER_AFTER_BODY", e[e.AFTER_AFTER_FRAMESET = 22] = "AFTER_AFTER_FRAMESET";
})(V ||= {});
var zt = {
	startLine: -1,
	startCol: -1,
	startOffset: -1,
	endLine: -1,
	endCol: -1,
	endOffset: -1
}, Bt = /* @__PURE__ */ new Set([
	I.TABLE,
	I.TBODY,
	I.TFOOT,
	I.THEAD,
	I.TR
]), Vt = {
	scriptingEnabled: !0,
	sourceCodeLocationInfo: !1,
	treeAdapter: B,
	onParseError: null
}, Ht = class {
	constructor(e, t, n = null, r = null) {
		this.fragmentContext = n, this.scriptHandler = r, this.currentToken = null, this.stopped = !1, this.insertionMode = V.INITIAL, this.originalInsertionMode = V.INITIAL, this.headElement = null, this.formElement = null, this.currentNotInHTML = !1, this.tmplInsertionModeStack = [], this.pendingCharacterTokens = [], this.hasNonWhitespacePendingCharacterToken = !1, this.framesetOk = !0, this.skipNextNewLine = !1, this.fosterParentingEnabled = !1, this.options = {
			...Vt,
			...e
		}, this.treeAdapter = this.options.treeAdapter, this.onParseError = this.options.onParseError, this.onParseError && (this.options.sourceCodeLocationInfo = !0), this.document = t ?? this.treeAdapter.createDocument(), this.tokenizer = new qe(this.options, this), this.activeFormattingElements = new lt(this.treeAdapter), this.fragmentContextID = n ? Ne(this.treeAdapter.getTagName(n)) : I.UNKNOWN, this._setContextModes(n ?? this.document, this.fragmentContextID), this.openElements = new at(this.document, this.treeAdapter, this);
	}
	static parse(e, t) {
		let n = new this(t);
		return n.tokenizer.write(e, !0), n.document;
	}
	static getFragmentParser(e, t) {
		let n = {
			...Vt,
			...t
		};
		e ??= n.treeAdapter.createElement(F.TEMPLATE, N.HTML, []);
		let r = n.treeAdapter.createElement("documentmock", N.HTML, []), i = new this(n, r, e);
		return i.fragmentContextID === I.TEMPLATE && i.tmplInsertionModeStack.unshift(V.IN_TEMPLATE), i._initTokenizerForFragmentParsing(), i._insertFakeRootElement(), i._resetInsertionMode(), i._findFormInFragmentContext(), i;
	}
	getFragment() {
		let e = this.treeAdapter.getFirstChild(this.document), t = this.treeAdapter.createDocumentFragment();
		return this._adoptNodes(e, t), t;
	}
	_err(e, t, n) {
		if (!this.onParseError) return;
		let r = e.location ?? zt, i = {
			code: t,
			startLine: r.startLine,
			startCol: r.startCol,
			startOffset: r.startOffset,
			endLine: n ? r.startLine : r.endLine,
			endCol: n ? r.startCol : r.endCol,
			endOffset: n ? r.startOffset : r.endOffset
		};
		this.onParseError(i);
	}
	onItemPush(e, t, n) {
		var r, i;
		(i = (r = this.treeAdapter).onItemPush) == null || i.call(r, e), n && this.openElements.stackTop > 0 && this._setContextModes(e, t);
	}
	onItemPop(e, t) {
		var n, r;
		if (this.options.sourceCodeLocationInfo && this._setEndLocation(e, this.currentToken), (r = (n = this.treeAdapter).onItemPop) == null || r.call(n, e, this.openElements.current), t) {
			let e, t;
			this.openElements.stackTop === 0 && this.fragmentContext ? (e = this.fragmentContext, t = this.fragmentContextID) : {current: e, currentTagId: t} = this.openElements, this._setContextModes(e, t);
		}
	}
	_setContextModes(e, t) {
		let n = e === this.document || e && this.treeAdapter.getNamespaceURI(e) === N.HTML;
		this.currentNotInHTML = !n, this.tokenizer.inForeignNode = !n && e !== void 0 && t !== void 0 && !this._isIntegrationPoint(t, e);
	}
	_switchToTextParsing(e, t) {
		this._insertElement(e, N.HTML), this.tokenizer.state = t, this.originalInsertionMode = this.insertionMode, this.insertionMode = V.TEXT;
	}
	switchToPlaintextParsing() {
		this.insertionMode = V.TEXT, this.originalInsertionMode = V.IN_BODY, this.tokenizer.state = z.PLAINTEXT;
	}
	_getAdjustedCurrentElement() {
		return this.openElements.stackTop === 0 && this.fragmentContext ? this.fragmentContext : this.openElements.current;
	}
	_findFormInFragmentContext() {
		let e = this.fragmentContext;
		for (; e;) {
			if (this.treeAdapter.getTagName(e) === F.FORM) {
				this.formElement = e;
				break;
			}
			e = this.treeAdapter.getParentNode(e);
		}
	}
	_initTokenizerForFragmentParsing() {
		if (this.fragmentContext && this.treeAdapter.getNamespaceURI(this.fragmentContext) === N.HTML) switch (this.fragmentContextID) {
			case I.TITLE:
			case I.TEXTAREA:
				this.tokenizer.state = z.RCDATA;
				break;
			case I.STYLE:
			case I.XMP:
			case I.IFRAME:
			case I.NOEMBED:
			case I.NOFRAMES:
			case I.NOSCRIPT:
				this.tokenizer.state = z.RAWTEXT;
				break;
			case I.SCRIPT:
				this.tokenizer.state = z.SCRIPT_DATA;
				break;
			case I.PLAINTEXT: this.tokenizer.state = z.PLAINTEXT;
		}
	}
	_setDocumentType(e) {
		let t = e.name || "", n = e.publicId || "", r = e.systemId || "";
		if (this.treeAdapter.setDocumentType(this.document, t, n, r), e.location) {
			let t = this.treeAdapter.getChildNodes(this.document).find((e) => this.treeAdapter.isDocumentTypeNode(e));
			t && this.treeAdapter.setNodeSourceCodeLocation(t, e.location);
		}
	}
	_attachElementToTree(e, t) {
		if (this.options.sourceCodeLocationInfo) {
			let n = t && {
				...t,
				startTag: t
			};
			this.treeAdapter.setNodeSourceCodeLocation(e, n);
		}
		if (this._shouldFosterParentOnInsertion()) this._fosterParentElement(e);
		else {
			let t = this.openElements.currentTmplContentOrNode;
			this.treeAdapter.appendChild(t ?? this.document, e);
		}
	}
	_appendElement(e, t) {
		let n = this.treeAdapter.createElement(e.tagName, t, e.attrs);
		this._attachElementToTree(n, e.location);
	}
	_insertElement(e, t) {
		let n = this.treeAdapter.createElement(e.tagName, t, e.attrs);
		this._attachElementToTree(n, e.location), this.openElements.push(n, e.tagID);
	}
	_insertFakeElement(e, t) {
		let n = this.treeAdapter.createElement(e, N.HTML, []);
		this._attachElementToTree(n, null), this.openElements.push(n, t);
	}
	_insertTemplate(e) {
		let t = this.treeAdapter.createElement(e.tagName, N.HTML, e.attrs), n = this.treeAdapter.createDocumentFragment();
		this.treeAdapter.setTemplateContent(t, n), this._attachElementToTree(t, e.location), this.openElements.push(t, e.tagID), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(n, null);
	}
	_insertFakeRootElement() {
		let e = this.treeAdapter.createElement(F.HTML, N.HTML, []);
		this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(e, null), this.treeAdapter.appendChild(this.openElements.current, e), this.openElements.push(e, I.HTML);
	}
	_appendCommentNode(e, t) {
		let n = this.treeAdapter.createCommentNode(e.data);
		this.treeAdapter.appendChild(t, n), this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(n, e.location);
	}
	_insertCharacters(e) {
		let t, n;
		if (this._shouldFosterParentOnInsertion() ? ({parent: t, beforeElement: n} = this._findFosterParentingLocation(), n ? this.treeAdapter.insertTextBefore(t, e.chars, n) : this.treeAdapter.insertText(t, e.chars)) : (t = this.openElements.currentTmplContentOrNode, this.treeAdapter.insertText(t, e.chars)), !e.location) return;
		let r = this.treeAdapter.getChildNodes(t), i = r[(n ? r.lastIndexOf(n) : r.length) - 1];
		if (this.treeAdapter.getNodeSourceCodeLocation(i)) {
			let { endLine: t, endCol: n, endOffset: r } = e.location;
			this.treeAdapter.updateNodeSourceCodeLocation(i, {
				endLine: t,
				endCol: n,
				endOffset: r
			});
		} else this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(i, e.location);
	}
	_adoptNodes(e, t) {
		for (let n = this.treeAdapter.getFirstChild(e); n; n = this.treeAdapter.getFirstChild(e)) this.treeAdapter.detachNode(n), this.treeAdapter.appendChild(t, n);
	}
	_setEndLocation(e, t) {
		if (this.treeAdapter.getNodeSourceCodeLocation(e) && t.location) {
			let n = t.location, r = this.treeAdapter.getTagName(e), i = t.type === k.END_TAG && r === t.tagName ? {
				endTag: { ...n },
				endLine: n.endLine,
				endCol: n.endCol,
				endOffset: n.endOffset
			} : {
				endLine: n.startLine,
				endCol: n.startCol,
				endOffset: n.startOffset
			};
			this.treeAdapter.updateNodeSourceCodeLocation(e, i);
		}
	}
	shouldProcessStartTagTokenInForeignContent(e) {
		if (!this.currentNotInHTML) return !1;
		let t, n;
		return this.openElements.stackTop === 0 && this.fragmentContext ? (t = this.fragmentContext, n = this.fragmentContextID) : {current: t, currentTagId: n} = this.openElements, e.tagID === I.SVG && this.treeAdapter.getTagName(t) === F.ANNOTATION_XML && this.treeAdapter.getNamespaceURI(t) === N.MATHML ? !1 : this.tokenizer.inForeignNode || (e.tagID === I.MGLYPH || e.tagID === I.MALIGNMARK) && n !== void 0 && !this._isIntegrationPoint(n, t, N.HTML);
	}
	_processToken(e) {
		switch (e.type) {
			case k.CHARACTER:
				this.onCharacter(e);
				break;
			case k.NULL_CHARACTER:
				this.onNullCharacter(e);
				break;
			case k.COMMENT:
				this.onComment(e);
				break;
			case k.DOCTYPE:
				this.onDoctype(e);
				break;
			case k.START_TAG:
				this._processStartTag(e);
				break;
			case k.END_TAG:
				this.onEndTag(e);
				break;
			case k.EOF:
				this.onEof(e);
				break;
			case k.WHITESPACE_CHARACTER: this.onWhitespaceCharacter(e);
		}
	}
	_isIntegrationPoint(e, t, n) {
		return Ft(e, this.treeAdapter.getNamespaceURI(t), this.treeAdapter.getAttrList(t), n);
	}
	_reconstructActiveFormattingElements() {
		let e = this.activeFormattingElements.entries.length;
		if (e) {
			let t = this.activeFormattingElements.entries.findIndex((e) => e.type === st.Marker || this.openElements.contains(e.element)), n = t === -1 ? e - 1 : t - 1;
			for (let e = n; e >= 0; e--) {
				let t = this.activeFormattingElements.entries[e];
				this._insertElement(t.token, this.treeAdapter.getNamespaceURI(t.element)), t.element = this.openElements.current;
			}
		}
	}
	_closeTableCell() {
		this.openElements.generateImpliedEndTags(), this.openElements.popUntilTableCellPopped(), this.activeFormattingElements.clearToLastMarker(), this.insertionMode = V.IN_ROW;
	}
	_closePElement() {
		this.openElements.generateImpliedEndTagsWithExclusion(I.P), this.openElements.popUntilTagNamePopped(I.P);
	}
	_resetInsertionMode() {
		for (let e = this.openElements.stackTop; e >= 0; e--) switch (e === 0 && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[e]) {
			case I.TR:
				this.insertionMode = V.IN_ROW;
				return;
			case I.TBODY:
			case I.THEAD:
			case I.TFOOT:
				this.insertionMode = V.IN_TABLE_BODY;
				return;
			case I.CAPTION:
				this.insertionMode = V.IN_CAPTION;
				return;
			case I.COLGROUP:
				this.insertionMode = V.IN_COLUMN_GROUP;
				return;
			case I.TABLE:
				this.insertionMode = V.IN_TABLE;
				return;
			case I.BODY:
				this.insertionMode = V.IN_BODY;
				return;
			case I.FRAMESET:
				this.insertionMode = V.IN_FRAMESET;
				return;
			case I.SELECT:
				this._resetInsertionModeForSelect(e);
				return;
			case I.TEMPLATE:
				this.insertionMode = this.tmplInsertionModeStack[0];
				return;
			case I.HTML:
				this.insertionMode = this.headElement ? V.AFTER_HEAD : V.BEFORE_HEAD;
				return;
			case I.TD:
			case I.TH:
				if (e > 0) {
					this.insertionMode = V.IN_CELL;
					return;
				}
				break;
			case I.HEAD: if (e > 0) {
				this.insertionMode = V.IN_HEAD;
				return;
			}
		}
		this.insertionMode = V.IN_BODY;
	}
	_resetInsertionModeForSelect(e) {
		if (e > 0) for (let t = e - 1; t > 0; t--) {
			let e = this.openElements.tagIDs[t];
			if (e === I.TEMPLATE) break;
			if (e === I.TABLE) {
				this.insertionMode = V.IN_SELECT_IN_TABLE;
				return;
			}
		}
		this.insertionMode = V.IN_SELECT;
	}
	_isElementCausesFosterParenting(e) {
		return Bt.has(e);
	}
	_shouldFosterParentOnInsertion() {
		return this.fosterParentingEnabled && this.openElements.currentTagId !== void 0 && this._isElementCausesFosterParenting(this.openElements.currentTagId);
	}
	_findFosterParentingLocation() {
		for (let e = this.openElements.stackTop; e >= 0; e--) {
			let t = this.openElements.items[e];
			switch (this.openElements.tagIDs[e]) {
				case I.TEMPLATE:
					if (this.treeAdapter.getNamespaceURI(t) === N.HTML) return {
						parent: this.treeAdapter.getTemplateContent(t),
						beforeElement: null
					};
					break;
				case I.TABLE: {
					let n = this.treeAdapter.getParentNode(t);
					return n ? {
						parent: n,
						beforeElement: t
					} : {
						parent: this.openElements.items[e - 1],
						beforeElement: null
					};
				}
			}
		}
		return {
			parent: this.openElements.items[0],
			beforeElement: null
		};
	}
	_fosterParentElement(e) {
		let t = this._findFosterParentingLocation();
		t.beforeElement ? this.treeAdapter.insertBefore(t.parent, e, t.beforeElement) : this.treeAdapter.appendChild(t.parent, e);
	}
	_isSpecialElement(e, t) {
		return Pe[this.treeAdapter.getNamespaceURI(e)].has(t);
	}
	onCharacter(e) {
		if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) oi(this, e);
		else switch (this.insertionMode) {
			case V.INITIAL:
				tn(this, e);
				break;
			case V.BEFORE_HTML:
				an(this, e);
				break;
			case V.BEFORE_HEAD:
				cn(this, e);
				break;
			case V.IN_HEAD:
				fn(this, e);
				break;
			case V.IN_HEAD_NO_SCRIPT:
				hn(this, e);
				break;
			case V.AFTER_HEAD:
				vn(this, e);
				break;
			case V.IN_BODY:
			case V.IN_CAPTION:
			case V.IN_CELL:
			case V.IN_TEMPLATE:
				xn(this, e);
				break;
			case V.TEXT:
			case V.IN_SELECT:
			case V.IN_SELECT_IN_TABLE:
				this._insertCharacters(e);
				break;
			case V.IN_TABLE:
			case V.IN_TABLE_BODY:
			case V.IN_ROW:
				hr(this, e);
				break;
			case V.IN_TABLE_TEXT:
				Or(this, e);
				break;
			case V.IN_COLUMN_GROUP:
				Fr(this, e);
				break;
			case V.AFTER_BODY:
				Zr(this, e);
				break;
			case V.AFTER_AFTER_BODY: ri(this, e);
		}
	}
	onNullCharacter(e) {
		if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode) ai(this, e);
		else switch (this.insertionMode) {
			case V.INITIAL:
				tn(this, e);
				break;
			case V.BEFORE_HTML:
				an(this, e);
				break;
			case V.BEFORE_HEAD:
				cn(this, e);
				break;
			case V.IN_HEAD:
				fn(this, e);
				break;
			case V.IN_HEAD_NO_SCRIPT:
				hn(this, e);
				break;
			case V.AFTER_HEAD:
				vn(this, e);
				break;
			case V.TEXT:
				this._insertCharacters(e);
				break;
			case V.IN_TABLE:
			case V.IN_TABLE_BODY:
			case V.IN_ROW:
				hr(this, e);
				break;
			case V.IN_COLUMN_GROUP:
				Fr(this, e);
				break;
			case V.AFTER_BODY:
				Zr(this, e);
				break;
			case V.AFTER_AFTER_BODY: ri(this, e);
		}
	}
	onComment(e) {
		if (this.skipNextNewLine = !1, this.currentNotInHTML) Xt(this, e);
		else switch (this.insertionMode) {
			case V.INITIAL:
			case V.BEFORE_HTML:
			case V.BEFORE_HEAD:
			case V.IN_HEAD:
			case V.IN_HEAD_NO_SCRIPT:
			case V.AFTER_HEAD:
			case V.IN_BODY:
			case V.IN_TABLE:
			case V.IN_CAPTION:
			case V.IN_COLUMN_GROUP:
			case V.IN_TABLE_BODY:
			case V.IN_ROW:
			case V.IN_CELL:
			case V.IN_SELECT:
			case V.IN_SELECT_IN_TABLE:
			case V.IN_TEMPLATE:
			case V.IN_FRAMESET:
			case V.AFTER_FRAMESET:
				Xt(this, e);
				break;
			case V.IN_TABLE_TEXT:
				kr(this, e);
				break;
			case V.AFTER_BODY:
				Zt(this, e);
				break;
			case V.AFTER_AFTER_BODY:
			case V.AFTER_AFTER_FRAMESET: Qt(this, e);
		}
	}
	onDoctype(e) {
		switch (this.skipNextNewLine = !1, this.insertionMode) {
			case V.INITIAL:
				en(this, e);
				break;
			case V.BEFORE_HEAD:
			case V.IN_HEAD:
			case V.IN_HEAD_NO_SCRIPT:
			case V.AFTER_HEAD:
				this._err(e, O.misplacedDoctype);
				break;
			case V.IN_TABLE_TEXT: kr(this, e);
		}
	}
	onStartTag(e) {
		this.skipNextNewLine = !1, this.currentToken = e, this._processStartTag(e), e.selfClosing && !e.ackSelfClosing && this._err(e, O.nonVoidHtmlElementStartTagWithTrailingSolidus);
	}
	_processStartTag(e) {
		this.shouldProcessStartTagTokenInForeignContent(e) ? ci(this, e) : this._startTagOutsideForeignContent(e);
	}
	_startTagOutsideForeignContent(e) {
		switch (this.insertionMode) {
			case V.INITIAL:
				tn(this, e);
				break;
			case V.BEFORE_HTML:
				nn(this, e);
				break;
			case V.BEFORE_HEAD:
				on(this, e);
				break;
			case V.IN_HEAD:
				ln(this, e);
				break;
			case V.IN_HEAD_NO_SCRIPT:
				pn(this, e);
				break;
			case V.AFTER_HEAD:
				gn(this, e);
				break;
			case V.IN_BODY:
				H(this, e);
				break;
			case V.IN_TABLE:
				wr(this, e);
				break;
			case V.IN_TABLE_TEXT:
				kr(this, e);
				break;
			case V.IN_CAPTION:
				jr(this, e);
				break;
			case V.IN_COLUMN_GROUP:
				Nr(this, e);
				break;
			case V.IN_TABLE_BODY:
				Ir(this, e);
				break;
			case V.IN_ROW:
				Rr(this, e);
				break;
			case V.IN_CELL:
				Br(this, e);
				break;
			case V.IN_SELECT:
				Hr(this, e);
				break;
			case V.IN_SELECT_IN_TABLE:
				Wr(this, e);
				break;
			case V.IN_TEMPLATE:
				Kr(this, e);
				break;
			case V.AFTER_BODY:
				Yr(this, e);
				break;
			case V.IN_FRAMESET:
				Qr(this, e);
				break;
			case V.AFTER_FRAMESET:
				ei(this, e);
				break;
			case V.AFTER_AFTER_BODY:
				ni(this, e);
				break;
			case V.AFTER_AFTER_FRAMESET: ii(this, e);
		}
	}
	onEndTag(e) {
		this.skipNextNewLine = !1, this.currentToken = e, this.currentNotInHTML ? li(this, e) : this._endTagOutsideForeignContent(e);
	}
	_endTagOutsideForeignContent(e) {
		switch (this.insertionMode) {
			case V.INITIAL:
				tn(this, e);
				break;
			case V.BEFORE_HTML:
				rn(this, e);
				break;
			case V.BEFORE_HEAD:
				sn(this, e);
				break;
			case V.IN_HEAD:
				un(this, e);
				break;
			case V.IN_HEAD_NO_SCRIPT:
				mn(this, e);
				break;
			case V.AFTER_HEAD:
				_n(this, e);
				break;
			case V.IN_BODY:
				dr(this, e);
				break;
			case V.TEXT:
				pr(this, e);
				break;
			case V.IN_TABLE:
				Tr(this, e);
				break;
			case V.IN_TABLE_TEXT:
				kr(this, e);
				break;
			case V.IN_CAPTION:
				Mr(this, e);
				break;
			case V.IN_COLUMN_GROUP:
				Pr(this, e);
				break;
			case V.IN_TABLE_BODY:
				Lr(this, e);
				break;
			case V.IN_ROW:
				zr(this, e);
				break;
			case V.IN_CELL:
				Vr(this, e);
				break;
			case V.IN_SELECT:
				Ur(this, e);
				break;
			case V.IN_SELECT_IN_TABLE:
				Gr(this, e);
				break;
			case V.IN_TEMPLATE:
				qr(this, e);
				break;
			case V.AFTER_BODY:
				Xr(this, e);
				break;
			case V.IN_FRAMESET:
				$r(this, e);
				break;
			case V.AFTER_FRAMESET:
				ti(this, e);
				break;
			case V.AFTER_AFTER_BODY: ri(this, e);
		}
	}
	onEof(e) {
		switch (this.insertionMode) {
			case V.INITIAL:
				tn(this, e);
				break;
			case V.BEFORE_HTML:
				an(this, e);
				break;
			case V.BEFORE_HEAD:
				cn(this, e);
				break;
			case V.IN_HEAD:
				fn(this, e);
				break;
			case V.IN_HEAD_NO_SCRIPT:
				hn(this, e);
				break;
			case V.AFTER_HEAD:
				vn(this, e);
				break;
			case V.IN_BODY:
			case V.IN_TABLE:
			case V.IN_CAPTION:
			case V.IN_COLUMN_GROUP:
			case V.IN_TABLE_BODY:
			case V.IN_ROW:
			case V.IN_CELL:
			case V.IN_SELECT:
			case V.IN_SELECT_IN_TABLE:
				fr(this, e);
				break;
			case V.TEXT:
				mr(this, e);
				break;
			case V.IN_TABLE_TEXT:
				kr(this, e);
				break;
			case V.IN_TEMPLATE:
				Jr(this, e);
				break;
			case V.AFTER_BODY:
			case V.IN_FRAMESET:
			case V.AFTER_FRAMESET:
			case V.AFTER_AFTER_BODY:
			case V.AFTER_AFTER_FRAMESET: $t(this, e);
		}
	}
	onWhitespaceCharacter(e) {
		if (this.skipNextNewLine && (this.skipNextNewLine = !1, e.chars.charCodeAt(0) === E.LINE_FEED)) {
			if (e.chars.length === 1) return;
			e.chars = e.chars.substr(1);
		}
		if (this.tokenizer.inForeignNode) this._insertCharacters(e);
		else switch (this.insertionMode) {
			case V.IN_HEAD:
			case V.IN_HEAD_NO_SCRIPT:
			case V.AFTER_HEAD:
			case V.TEXT:
			case V.IN_COLUMN_GROUP:
			case V.IN_SELECT:
			case V.IN_SELECT_IN_TABLE:
			case V.IN_FRAMESET:
			case V.AFTER_FRAMESET:
				this._insertCharacters(e);
				break;
			case V.IN_BODY:
			case V.IN_CAPTION:
			case V.IN_CELL:
			case V.IN_TEMPLATE:
			case V.AFTER_BODY:
			case V.AFTER_AFTER_BODY:
			case V.AFTER_AFTER_FRAMESET:
				bn(this, e);
				break;
			case V.IN_TABLE:
			case V.IN_TABLE_BODY:
			case V.IN_ROW:
				hr(this, e);
				break;
			case V.IN_TABLE_TEXT: Dr(this, e);
		}
	}
};
function Ut(e, t) {
	let n = e.activeFormattingElements.getElementEntryInScopeWithTagName(t.tagName);
	return n ? e.openElements.contains(n.element) ? e.openElements.hasInScope(t.tagID) || (n = null) : (e.activeFormattingElements.removeEntry(n), n = null) : ur(e, t), n;
}
function Wt(e, t) {
	let n = null, r = e.openElements.stackTop;
	for (; r >= 0; r--) {
		let i = e.openElements.items[r];
		if (i === t.element) break;
		e._isSpecialElement(i, e.openElements.tagIDs[r]) && (n = i);
	}
	return n || (e.openElements.shortenToLength(Math.max(r, 0)), e.activeFormattingElements.removeEntry(t)), n;
}
function Gt(e, t, n) {
	let r = t, i = e.openElements.getCommonAncestor(t);
	for (let a = 0, o = i; o !== n; a++, o = i) {
		i = e.openElements.getCommonAncestor(o);
		let n = e.activeFormattingElements.getElementEntry(o), s = n && a >= Rt;
		!n || s ? (s && e.activeFormattingElements.removeEntry(n), e.openElements.remove(o)) : (o = Kt(e, n), r === t && (e.activeFormattingElements.bookmark = n), e.treeAdapter.detachNode(r), e.treeAdapter.appendChild(o, r), r = o);
	}
	return r;
}
function Kt(e, t) {
	let n = e.treeAdapter.getNamespaceURI(t.element), r = e.treeAdapter.createElement(t.token.tagName, n, t.token.attrs);
	return e.openElements.replace(t.element, r), t.element = r, r;
}
function qt(e, t, n) {
	let r = Ne(e.treeAdapter.getTagName(t));
	if (e._isElementCausesFosterParenting(r)) e._fosterParentElement(n);
	else {
		let i = e.treeAdapter.getNamespaceURI(t);
		r === I.TEMPLATE && i === N.HTML && (t = e.treeAdapter.getTemplateContent(t)), e.treeAdapter.appendChild(t, n);
	}
}
function Jt(e, t, n) {
	let r = e.treeAdapter.getNamespaceURI(n.element), { token: i } = n, a = e.treeAdapter.createElement(i.tagName, r, i.attrs);
	e._adoptNodes(t, a), e.treeAdapter.appendChild(t, a), e.activeFormattingElements.insertElementAfterBookmark(a, i), e.activeFormattingElements.removeEntry(n), e.openElements.remove(n.element), e.openElements.insertAfter(t, a, i.tagID);
}
function Yt(e, t) {
	for (let n = 0; n < Lt; n++) {
		let n = Ut(e, t);
		if (!n) break;
		let r = Wt(e, n);
		if (!r) break;
		e.activeFormattingElements.bookmark = n;
		let i = Gt(e, r, n.element), a = e.openElements.getCommonAncestor(n.element);
		e.treeAdapter.detachNode(i), a && qt(e, a, i), Jt(e, r, n);
	}
}
function Xt(e, t) {
	e._appendCommentNode(t, e.openElements.currentTmplContentOrNode);
}
function Zt(e, t) {
	e._appendCommentNode(t, e.openElements.items[0]);
}
function Qt(e, t) {
	e._appendCommentNode(t, e.document);
}
function $t(e, t) {
	if (e.stopped = !0, t.location) {
		let n = e.fragmentContext ? 0 : 2;
		for (let r = e.openElements.stackTop; r >= n; r--) e._setEndLocation(e.openElements.items[r], t);
		if (!e.fragmentContext && e.openElements.stackTop >= 0) {
			let n = e.openElements.items[0], r = e.treeAdapter.getNodeSourceCodeLocation(n);
			if (r && !r.endTag && (e._setEndLocation(n, t), e.openElements.stackTop >= 1)) {
				let n = e.openElements.items[1], r = e.treeAdapter.getNodeSourceCodeLocation(n);
				r && !r.endTag && e._setEndLocation(n, t);
			}
		}
	}
}
function en(e, t) {
	e._setDocumentType(t);
	let n = t.forceQuirks ? P.QUIRKS : bt(t);
	yt(t) || e._err(t, O.nonConformingDoctype), e.treeAdapter.setDocumentMode(e.document, n), e.insertionMode = V.BEFORE_HTML;
}
function tn(e, t) {
	e._err(t, O.missingDoctype, !0), e.treeAdapter.setDocumentMode(e.document, P.QUIRKS), e.insertionMode = V.BEFORE_HTML, e._processToken(t);
}
function nn(e, t) {
	t.tagID === I.HTML ? (e._insertElement(t, N.HTML), e.insertionMode = V.BEFORE_HEAD) : an(e, t);
}
function rn(e, t) {
	let n = t.tagID;
	(n === I.HTML || n === I.HEAD || n === I.BODY || n === I.BR) && an(e, t);
}
function an(e, t) {
	e._insertFakeRootElement(), e.insertionMode = V.BEFORE_HEAD, e._processToken(t);
}
function on(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.HEAD:
			e._insertElement(t, N.HTML), e.headElement = e.openElements.current, e.insertionMode = V.IN_HEAD;
			break;
		default: cn(e, t);
	}
}
function sn(e, t) {
	let n = t.tagID;
	n === I.HEAD || n === I.BODY || n === I.HTML || n === I.BR ? cn(e, t) : e._err(t, O.endTagWithoutMatchingOpenElement);
}
function cn(e, t) {
	e._insertFakeElement(F.HEAD, I.HEAD), e.headElement = e.openElements.current, e.insertionMode = V.IN_HEAD, e._processToken(t);
}
function ln(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.BASE:
		case I.BASEFONT:
		case I.BGSOUND:
		case I.LINK:
		case I.META:
			e._appendElement(t, N.HTML), t.ackSelfClosing = !0;
			break;
		case I.TITLE:
			e._switchToTextParsing(t, z.RCDATA);
			break;
		case I.NOSCRIPT:
			e.options.scriptingEnabled ? e._switchToTextParsing(t, z.RAWTEXT) : (e._insertElement(t, N.HTML), e.insertionMode = V.IN_HEAD_NO_SCRIPT);
			break;
		case I.NOFRAMES:
		case I.STYLE:
			e._switchToTextParsing(t, z.RAWTEXT);
			break;
		case I.SCRIPT:
			e._switchToTextParsing(t, z.SCRIPT_DATA);
			break;
		case I.TEMPLATE:
			e._insertTemplate(t), e.activeFormattingElements.insertMarker(), e.framesetOk = !1, e.insertionMode = V.IN_TEMPLATE, e.tmplInsertionModeStack.unshift(V.IN_TEMPLATE);
			break;
		case I.HEAD:
			e._err(t, O.misplacedStartTagForHeadElement);
			break;
		default: fn(e, t);
	}
}
function un(e, t) {
	switch (t.tagID) {
		case I.HEAD:
			e.openElements.pop(), e.insertionMode = V.AFTER_HEAD;
			break;
		case I.BODY:
		case I.BR:
		case I.HTML:
			fn(e, t);
			break;
		case I.TEMPLATE:
			dn(e, t);
			break;
		default: e._err(t, O.endTagWithoutMatchingOpenElement);
	}
}
function dn(e, t) {
	e.openElements.tmplCount > 0 ? (e.openElements.generateImpliedEndTagsThoroughly(), e.openElements.currentTagId !== I.TEMPLATE && e._err(t, O.closingOfElementWithOpenChildElements), e.openElements.popUntilTagNamePopped(I.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode()) : e._err(t, O.endTagWithoutMatchingOpenElement);
}
function fn(e, t) {
	e.openElements.pop(), e.insertionMode = V.AFTER_HEAD, e._processToken(t);
}
function pn(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.BASEFONT:
		case I.BGSOUND:
		case I.HEAD:
		case I.LINK:
		case I.META:
		case I.NOFRAMES:
		case I.STYLE:
			ln(e, t);
			break;
		case I.NOSCRIPT:
			e._err(t, O.nestedNoscriptInHead);
			break;
		default: hn(e, t);
	}
}
function mn(e, t) {
	switch (t.tagID) {
		case I.NOSCRIPT:
			e.openElements.pop(), e.insertionMode = V.IN_HEAD;
			break;
		case I.BR:
			hn(e, t);
			break;
		default: e._err(t, O.endTagWithoutMatchingOpenElement);
	}
}
function hn(e, t) {
	let n = t.type === k.EOF ? O.openElementsLeftAfterEof : O.disallowedContentInNoscriptInHead;
	e._err(t, n), e.openElements.pop(), e.insertionMode = V.IN_HEAD, e._processToken(t);
}
function gn(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.BODY:
			e._insertElement(t, N.HTML), e.framesetOk = !1, e.insertionMode = V.IN_BODY;
			break;
		case I.FRAMESET:
			e._insertElement(t, N.HTML), e.insertionMode = V.IN_FRAMESET;
			break;
		case I.BASE:
		case I.BASEFONT:
		case I.BGSOUND:
		case I.LINK:
		case I.META:
		case I.NOFRAMES:
		case I.SCRIPT:
		case I.STYLE:
		case I.TEMPLATE:
		case I.TITLE:
			e._err(t, O.abandonedHeadElementChild), e.openElements.push(e.headElement, I.HEAD), ln(e, t), e.openElements.remove(e.headElement);
			break;
		case I.HEAD:
			e._err(t, O.misplacedStartTagForHeadElement);
			break;
		default: vn(e, t);
	}
}
function _n(e, t) {
	switch (t.tagID) {
		case I.BODY:
		case I.HTML:
		case I.BR:
			vn(e, t);
			break;
		case I.TEMPLATE:
			dn(e, t);
			break;
		default: e._err(t, O.endTagWithoutMatchingOpenElement);
	}
}
function vn(e, t) {
	e._insertFakeElement(F.BODY, I.BODY), e.insertionMode = V.IN_BODY, yn(e, t);
}
function yn(e, t) {
	switch (t.type) {
		case k.CHARACTER:
			xn(e, t);
			break;
		case k.WHITESPACE_CHARACTER:
			bn(e, t);
			break;
		case k.COMMENT:
			Xt(e, t);
			break;
		case k.START_TAG:
			H(e, t);
			break;
		case k.END_TAG:
			dr(e, t);
			break;
		case k.EOF: fr(e, t);
	}
}
function bn(e, t) {
	e._reconstructActiveFormattingElements(), e._insertCharacters(t);
}
function xn(e, t) {
	e._reconstructActiveFormattingElements(), e._insertCharacters(t), e.framesetOk = !1;
}
function Sn(e, t) {
	e.openElements.tmplCount === 0 && e.treeAdapter.adoptAttributes(e.openElements.items[0], t.attrs);
}
function Cn(e, t) {
	let n = e.openElements.tryPeekProperlyNestedBodyElement();
	n && e.openElements.tmplCount === 0 && (e.framesetOk = !1, e.treeAdapter.adoptAttributes(n, t.attrs));
}
function wn(e, t) {
	let n = e.openElements.tryPeekProperlyNestedBodyElement();
	e.framesetOk && n && (e.treeAdapter.detachNode(n), e.openElements.popAllUpToHtmlElement(), e._insertElement(t, N.HTML), e.insertionMode = V.IN_FRAMESET);
}
function Tn(e, t) {
	e.openElements.hasInButtonScope(I.P) && e._closePElement(), e._insertElement(t, N.HTML);
}
function En(e, t) {
	e.openElements.hasInButtonScope(I.P) && e._closePElement(), e.openElements.currentTagId !== void 0 && Fe.has(e.openElements.currentTagId) && e.openElements.pop(), e._insertElement(t, N.HTML);
}
function Dn(e, t) {
	e.openElements.hasInButtonScope(I.P) && e._closePElement(), e._insertElement(t, N.HTML), e.skipNextNewLine = !0, e.framesetOk = !1;
}
function On(e, t) {
	let n = e.openElements.tmplCount > 0;
	(!e.formElement || n) && (e.openElements.hasInButtonScope(I.P) && e._closePElement(), e._insertElement(t, N.HTML), n || (e.formElement = e.openElements.current));
}
function kn(e, t) {
	e.framesetOk = !1;
	let n = t.tagID;
	for (let t = e.openElements.stackTop; t >= 0; t--) {
		let r = e.openElements.tagIDs[t];
		if (n === I.LI && r === I.LI || (n === I.DD || n === I.DT) && (r === I.DD || r === I.DT)) {
			e.openElements.generateImpliedEndTagsWithExclusion(r), e.openElements.popUntilTagNamePopped(r);
			break;
		}
		if (r !== I.ADDRESS && r !== I.DIV && r !== I.P && e._isSpecialElement(e.openElements.items[t], r)) break;
	}
	e.openElements.hasInButtonScope(I.P) && e._closePElement(), e._insertElement(t, N.HTML);
}
function An(e, t) {
	e.openElements.hasInButtonScope(I.P) && e._closePElement(), e._insertElement(t, N.HTML), e.tokenizer.state = z.PLAINTEXT;
}
function jn(e, t) {
	e.openElements.hasInScope(I.BUTTON) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(I.BUTTON)), e._reconstructActiveFormattingElements(), e._insertElement(t, N.HTML), e.framesetOk = !1;
}
function Mn(e, t) {
	let n = e.activeFormattingElements.getElementEntryInScopeWithTagName(F.A);
	n && (Yt(e, t), e.openElements.remove(n.element), e.activeFormattingElements.removeEntry(n)), e._reconstructActiveFormattingElements(), e._insertElement(t, N.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Nn(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, N.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Pn(e, t) {
	e._reconstructActiveFormattingElements(), e.openElements.hasInScope(I.NOBR) && (Yt(e, t), e._reconstructActiveFormattingElements()), e._insertElement(t, N.HTML), e.activeFormattingElements.pushElement(e.openElements.current, t);
}
function Fn(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, N.HTML), e.activeFormattingElements.insertMarker(), e.framesetOk = !1;
}
function In(e, t) {
	e.treeAdapter.getDocumentMode(e.document) !== P.QUIRKS && e.openElements.hasInButtonScope(I.P) && e._closePElement(), e._insertElement(t, N.HTML), e.framesetOk = !1, e.insertionMode = V.IN_TABLE;
}
function Ln(e, t) {
	e._reconstructActiveFormattingElements(), e._appendElement(t, N.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function Rn(e) {
	let t = me(e, je.TYPE);
	return t != null && t.toLowerCase() === It;
}
function zn(e, t) {
	e._reconstructActiveFormattingElements(), e._appendElement(t, N.HTML), Rn(t) || (e.framesetOk = !1), t.ackSelfClosing = !0;
}
function Bn(e, t) {
	e._appendElement(t, N.HTML), t.ackSelfClosing = !0;
}
function Vn(e, t) {
	e.openElements.hasInButtonScope(I.P) && e._closePElement(), e._appendElement(t, N.HTML), e.framesetOk = !1, t.ackSelfClosing = !0;
}
function Hn(e, t) {
	t.tagName = F.IMG, t.tagID = I.IMG, Ln(e, t);
}
function Un(e, t) {
	e._insertElement(t, N.HTML), e.skipNextNewLine = !0, e.tokenizer.state = z.RCDATA, e.originalInsertionMode = e.insertionMode, e.framesetOk = !1, e.insertionMode = V.TEXT;
}
function Wn(e, t) {
	e.openElements.hasInButtonScope(I.P) && e._closePElement(), e._reconstructActiveFormattingElements(), e.framesetOk = !1, e._switchToTextParsing(t, z.RAWTEXT);
}
function Gn(e, t) {
	e.framesetOk = !1, e._switchToTextParsing(t, z.RAWTEXT);
}
function Kn(e, t) {
	e._switchToTextParsing(t, z.RAWTEXT);
}
function qn(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, N.HTML), e.framesetOk = !1, e.insertionMode = e.insertionMode === V.IN_TABLE || e.insertionMode === V.IN_CAPTION || e.insertionMode === V.IN_TABLE_BODY || e.insertionMode === V.IN_ROW || e.insertionMode === V.IN_CELL ? V.IN_SELECT_IN_TABLE : V.IN_SELECT;
}
function Jn(e, t) {
	e.openElements.currentTagId === I.OPTION && e.openElements.pop(), e._reconstructActiveFormattingElements(), e._insertElement(t, N.HTML);
}
function Yn(e, t) {
	e.openElements.hasInScope(I.RUBY) && e.openElements.generateImpliedEndTags(), e._insertElement(t, N.HTML);
}
function Xn(e, t) {
	e.openElements.hasInScope(I.RUBY) && e.openElements.generateImpliedEndTagsWithExclusion(I.RTC), e._insertElement(t, N.HTML);
}
function Zn(e, t) {
	e._reconstructActiveFormattingElements(), kt(t), jt(t), t.selfClosing ? e._appendElement(t, N.MATHML) : e._insertElement(t, N.MATHML), t.ackSelfClosing = !0;
}
function Qn(e, t) {
	e._reconstructActiveFormattingElements(), At(t), jt(t), t.selfClosing ? e._appendElement(t, N.SVG) : e._insertElement(t, N.SVG), t.ackSelfClosing = !0;
}
function $n(e, t) {
	e._reconstructActiveFormattingElements(), e._insertElement(t, N.HTML);
}
function H(e, t) {
	switch (t.tagID) {
		case I.I:
		case I.S:
		case I.B:
		case I.U:
		case I.EM:
		case I.TT:
		case I.BIG:
		case I.CODE:
		case I.FONT:
		case I.SMALL:
		case I.STRIKE:
		case I.STRONG:
			Nn(e, t);
			break;
		case I.A:
			Mn(e, t);
			break;
		case I.H1:
		case I.H2:
		case I.H3:
		case I.H4:
		case I.H5:
		case I.H6:
			En(e, t);
			break;
		case I.P:
		case I.DL:
		case I.OL:
		case I.UL:
		case I.DIV:
		case I.DIR:
		case I.NAV:
		case I.MAIN:
		case I.MENU:
		case I.ASIDE:
		case I.CENTER:
		case I.FIGURE:
		case I.FOOTER:
		case I.HEADER:
		case I.HGROUP:
		case I.DIALOG:
		case I.DETAILS:
		case I.ADDRESS:
		case I.ARTICLE:
		case I.SEARCH:
		case I.SECTION:
		case I.SUMMARY:
		case I.FIELDSET:
		case I.BLOCKQUOTE:
		case I.FIGCAPTION:
			Tn(e, t);
			break;
		case I.LI:
		case I.DD:
		case I.DT:
			kn(e, t);
			break;
		case I.BR:
		case I.IMG:
		case I.WBR:
		case I.AREA:
		case I.EMBED:
		case I.KEYGEN:
			Ln(e, t);
			break;
		case I.HR:
			Vn(e, t);
			break;
		case I.RB:
		case I.RTC:
			Yn(e, t);
			break;
		case I.RT:
		case I.RP:
			Xn(e, t);
			break;
		case I.PRE:
		case I.LISTING:
			Dn(e, t);
			break;
		case I.XMP:
			Wn(e, t);
			break;
		case I.SVG:
			Qn(e, t);
			break;
		case I.HTML:
			Sn(e, t);
			break;
		case I.BASE:
		case I.LINK:
		case I.META:
		case I.STYLE:
		case I.TITLE:
		case I.SCRIPT:
		case I.BGSOUND:
		case I.BASEFONT:
		case I.TEMPLATE:
			ln(e, t);
			break;
		case I.BODY:
			Cn(e, t);
			break;
		case I.FORM:
			On(e, t);
			break;
		case I.NOBR:
			Pn(e, t);
			break;
		case I.MATH:
			Zn(e, t);
			break;
		case I.TABLE:
			In(e, t);
			break;
		case I.INPUT:
			zn(e, t);
			break;
		case I.PARAM:
		case I.TRACK:
		case I.SOURCE:
			Bn(e, t);
			break;
		case I.IMAGE:
			Hn(e, t);
			break;
		case I.BUTTON:
			jn(e, t);
			break;
		case I.APPLET:
		case I.OBJECT:
		case I.MARQUEE:
			Fn(e, t);
			break;
		case I.IFRAME:
			Gn(e, t);
			break;
		case I.SELECT:
			qn(e, t);
			break;
		case I.OPTION:
		case I.OPTGROUP:
			Jn(e, t);
			break;
		case I.NOEMBED:
		case I.NOFRAMES:
			Kn(e, t);
			break;
		case I.FRAMESET:
			wn(e, t);
			break;
		case I.TEXTAREA:
			Un(e, t);
			break;
		case I.NOSCRIPT:
			e.options.scriptingEnabled ? Kn(e, t) : $n(e, t);
			break;
		case I.PLAINTEXT:
			An(e, t);
			break;
		case I.COL:
		case I.TH:
		case I.TD:
		case I.TR:
		case I.HEAD:
		case I.FRAME:
		case I.TBODY:
		case I.TFOOT:
		case I.THEAD:
		case I.CAPTION:
		case I.COLGROUP: break;
		default: $n(e, t);
	}
}
function er(e, t) {
	if (e.openElements.hasInScope(I.BODY) && (e.insertionMode = V.AFTER_BODY, e.options.sourceCodeLocationInfo)) {
		let n = e.openElements.tryPeekProperlyNestedBodyElement();
		n && e._setEndLocation(n, t);
	}
}
function tr(e, t) {
	e.openElements.hasInScope(I.BODY) && (e.insertionMode = V.AFTER_BODY, Xr(e, t));
}
function nr(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n));
}
function rr(e) {
	let t = e.openElements.tmplCount > 0, { formElement: n } = e;
	t || (e.formElement = null), (n || t) && e.openElements.hasInScope(I.FORM) && (e.openElements.generateImpliedEndTags(), t ? e.openElements.popUntilTagNamePopped(I.FORM) : n && e.openElements.remove(n));
}
function ir(e) {
	e.openElements.hasInButtonScope(I.P) || e._insertFakeElement(F.P, I.P), e._closePElement();
}
function ar(e) {
	e.openElements.hasInListItemScope(I.LI) && (e.openElements.generateImpliedEndTagsWithExclusion(I.LI), e.openElements.popUntilTagNamePopped(I.LI));
}
function or(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTagsWithExclusion(n), e.openElements.popUntilTagNamePopped(n));
}
function sr(e) {
	e.openElements.hasNumberedHeaderInScope() && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilNumberedHeaderPopped());
}
function cr(e, t) {
	let n = t.tagID;
	e.openElements.hasInScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n), e.activeFormattingElements.clearToLastMarker());
}
function lr(e) {
	e._reconstructActiveFormattingElements(), e._insertFakeElement(F.BR, I.BR), e.openElements.pop(), e.framesetOk = !1;
}
function ur(e, t) {
	let n = t.tagName, r = t.tagID;
	for (let t = e.openElements.stackTop; t > 0; t--) {
		let i = e.openElements.items[t], a = e.openElements.tagIDs[t];
		if (r === a && (r !== I.UNKNOWN || e.treeAdapter.getTagName(i) === n)) {
			e.openElements.generateImpliedEndTagsWithExclusion(r), e.openElements.stackTop >= t && e.openElements.shortenToLength(t);
			break;
		}
		if (e._isSpecialElement(i, a)) break;
	}
}
function dr(e, t) {
	switch (t.tagID) {
		case I.A:
		case I.B:
		case I.I:
		case I.S:
		case I.U:
		case I.EM:
		case I.TT:
		case I.BIG:
		case I.CODE:
		case I.FONT:
		case I.NOBR:
		case I.SMALL:
		case I.STRIKE:
		case I.STRONG:
			Yt(e, t);
			break;
		case I.P:
			ir(e);
			break;
		case I.DL:
		case I.UL:
		case I.OL:
		case I.DIR:
		case I.DIV:
		case I.NAV:
		case I.PRE:
		case I.MAIN:
		case I.MENU:
		case I.ASIDE:
		case I.BUTTON:
		case I.CENTER:
		case I.FIGURE:
		case I.FOOTER:
		case I.HEADER:
		case I.HGROUP:
		case I.DIALOG:
		case I.ADDRESS:
		case I.ARTICLE:
		case I.DETAILS:
		case I.SEARCH:
		case I.SECTION:
		case I.SUMMARY:
		case I.LISTING:
		case I.FIELDSET:
		case I.BLOCKQUOTE:
		case I.FIGCAPTION:
			nr(e, t);
			break;
		case I.LI:
			ar(e);
			break;
		case I.DD:
		case I.DT:
			or(e, t);
			break;
		case I.H1:
		case I.H2:
		case I.H3:
		case I.H4:
		case I.H5:
		case I.H6:
			sr(e);
			break;
		case I.BR:
			lr(e);
			break;
		case I.BODY:
			er(e, t);
			break;
		case I.HTML:
			tr(e, t);
			break;
		case I.FORM:
			rr(e);
			break;
		case I.APPLET:
		case I.OBJECT:
		case I.MARQUEE:
			cr(e, t);
			break;
		case I.TEMPLATE:
			dn(e, t);
			break;
		default: ur(e, t);
	}
}
function fr(e, t) {
	e.tmplInsertionModeStack.length > 0 ? Jr(e, t) : $t(e, t);
}
function pr(e, t) {
	var n;
	t.tagID === I.SCRIPT && ((n = e.scriptHandler) == null || n.call(e, e.openElements.current)), e.openElements.pop(), e.insertionMode = e.originalInsertionMode;
}
function mr(e, t) {
	e._err(t, O.eofInElementThatCanContainOnlyText), e.openElements.pop(), e.insertionMode = e.originalInsertionMode, e.onEof(t);
}
function hr(e, t) {
	if (e.openElements.currentTagId !== void 0 && Bt.has(e.openElements.currentTagId)) switch (e.pendingCharacterTokens.length = 0, e.hasNonWhitespacePendingCharacterToken = !1, e.originalInsertionMode = e.insertionMode, e.insertionMode = V.IN_TABLE_TEXT, t.type) {
		case k.CHARACTER:
			Or(e, t);
			break;
		case k.WHITESPACE_CHARACTER: Dr(e, t);
	}
	else Er(e, t);
}
function gr(e, t) {
	e.openElements.clearBackToTableContext(), e.activeFormattingElements.insertMarker(), e._insertElement(t, N.HTML), e.insertionMode = V.IN_CAPTION;
}
function _r(e, t) {
	e.openElements.clearBackToTableContext(), e._insertElement(t, N.HTML), e.insertionMode = V.IN_COLUMN_GROUP;
}
function vr(e, t) {
	e.openElements.clearBackToTableContext(), e._insertFakeElement(F.COLGROUP, I.COLGROUP), e.insertionMode = V.IN_COLUMN_GROUP, Nr(e, t);
}
function yr(e, t) {
	e.openElements.clearBackToTableContext(), e._insertElement(t, N.HTML), e.insertionMode = V.IN_TABLE_BODY;
}
function br(e, t) {
	e.openElements.clearBackToTableContext(), e._insertFakeElement(F.TBODY, I.TBODY), e.insertionMode = V.IN_TABLE_BODY, Ir(e, t);
}
function xr(e, t) {
	e.openElements.hasInTableScope(I.TABLE) && (e.openElements.popUntilTagNamePopped(I.TABLE), e._resetInsertionMode(), e._processStartTag(t));
}
function Sr(e, t) {
	Rn(t) ? e._appendElement(t, N.HTML) : Er(e, t), t.ackSelfClosing = !0;
}
function Cr(e, t) {
	!e.formElement && e.openElements.tmplCount === 0 && (e._insertElement(t, N.HTML), e.formElement = e.openElements.current, e.openElements.pop());
}
function wr(e, t) {
	switch (t.tagID) {
		case I.TD:
		case I.TH:
		case I.TR:
			br(e, t);
			break;
		case I.STYLE:
		case I.SCRIPT:
		case I.TEMPLATE:
			ln(e, t);
			break;
		case I.COL:
			vr(e, t);
			break;
		case I.FORM:
			Cr(e, t);
			break;
		case I.TABLE:
			xr(e, t);
			break;
		case I.TBODY:
		case I.TFOOT:
		case I.THEAD:
			yr(e, t);
			break;
		case I.INPUT:
			Sr(e, t);
			break;
		case I.CAPTION:
			gr(e, t);
			break;
		case I.COLGROUP:
			_r(e, t);
			break;
		default: Er(e, t);
	}
}
function Tr(e, t) {
	switch (t.tagID) {
		case I.TABLE:
			e.openElements.hasInTableScope(I.TABLE) && (e.openElements.popUntilTagNamePopped(I.TABLE), e._resetInsertionMode());
			break;
		case I.TEMPLATE:
			dn(e, t);
			break;
		case I.BODY:
		case I.CAPTION:
		case I.COL:
		case I.COLGROUP:
		case I.HTML:
		case I.TBODY:
		case I.TD:
		case I.TFOOT:
		case I.TH:
		case I.THEAD:
		case I.TR: break;
		default: Er(e, t);
	}
}
function Er(e, t) {
	let n = e.fosterParentingEnabled;
	e.fosterParentingEnabled = !0, yn(e, t), e.fosterParentingEnabled = n;
}
function Dr(e, t) {
	e.pendingCharacterTokens.push(t);
}
function Or(e, t) {
	e.pendingCharacterTokens.push(t), e.hasNonWhitespacePendingCharacterToken = !0;
}
function kr(e, t) {
	let n = 0;
	if (e.hasNonWhitespacePendingCharacterToken) for (; n < e.pendingCharacterTokens.length; n++) Er(e, e.pendingCharacterTokens[n]);
	else for (; n < e.pendingCharacterTokens.length; n++) e._insertCharacters(e.pendingCharacterTokens[n]);
	e.insertionMode = e.originalInsertionMode, e._processToken(t);
}
var Ar = /* @__PURE__ */ new Set([
	I.CAPTION,
	I.COL,
	I.COLGROUP,
	I.TBODY,
	I.TD,
	I.TFOOT,
	I.TH,
	I.THEAD,
	I.TR
]);
function jr(e, t) {
	let n = t.tagID;
	Ar.has(n) ? e.openElements.hasInTableScope(I.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(I.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = V.IN_TABLE, wr(e, t)) : H(e, t);
}
function Mr(e, t) {
	let n = t.tagID;
	switch (n) {
		case I.CAPTION:
		case I.TABLE:
			e.openElements.hasInTableScope(I.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(I.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = V.IN_TABLE, n === I.TABLE && Tr(e, t));
			break;
		case I.BODY:
		case I.COL:
		case I.COLGROUP:
		case I.HTML:
		case I.TBODY:
		case I.TD:
		case I.TFOOT:
		case I.TH:
		case I.THEAD:
		case I.TR: break;
		default: dr(e, t);
	}
}
function Nr(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.COL:
			e._appendElement(t, N.HTML), t.ackSelfClosing = !0;
			break;
		case I.TEMPLATE:
			ln(e, t);
			break;
		default: Fr(e, t);
	}
}
function Pr(e, t) {
	switch (t.tagID) {
		case I.COLGROUP:
			e.openElements.currentTagId === I.COLGROUP && (e.openElements.pop(), e.insertionMode = V.IN_TABLE);
			break;
		case I.TEMPLATE:
			dn(e, t);
			break;
		case I.COL: break;
		default: Fr(e, t);
	}
}
function Fr(e, t) {
	e.openElements.currentTagId === I.COLGROUP && (e.openElements.pop(), e.insertionMode = V.IN_TABLE, e._processToken(t));
}
function Ir(e, t) {
	switch (t.tagID) {
		case I.TR:
			e.openElements.clearBackToTableBodyContext(), e._insertElement(t, N.HTML), e.insertionMode = V.IN_ROW;
			break;
		case I.TH:
		case I.TD:
			e.openElements.clearBackToTableBodyContext(), e._insertFakeElement(F.TR, I.TR), e.insertionMode = V.IN_ROW, Rr(e, t);
			break;
		case I.CAPTION:
		case I.COL:
		case I.COLGROUP:
		case I.TBODY:
		case I.TFOOT:
		case I.THEAD:
			e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = V.IN_TABLE, wr(e, t));
			break;
		default: wr(e, t);
	}
}
function Lr(e, t) {
	let n = t.tagID;
	switch (t.tagID) {
		case I.TBODY:
		case I.TFOOT:
		case I.THEAD:
			e.openElements.hasInTableScope(n) && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = V.IN_TABLE);
			break;
		case I.TABLE:
			e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = V.IN_TABLE, Tr(e, t));
			break;
		case I.BODY:
		case I.CAPTION:
		case I.COL:
		case I.COLGROUP:
		case I.HTML:
		case I.TD:
		case I.TH:
		case I.TR: break;
		default: Tr(e, t);
	}
}
function Rr(e, t) {
	switch (t.tagID) {
		case I.TH:
		case I.TD:
			e.openElements.clearBackToTableRowContext(), e._insertElement(t, N.HTML), e.insertionMode = V.IN_CELL, e.activeFormattingElements.insertMarker();
			break;
		case I.CAPTION:
		case I.COL:
		case I.COLGROUP:
		case I.TBODY:
		case I.TFOOT:
		case I.THEAD:
		case I.TR:
			e.openElements.hasInTableScope(I.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = V.IN_TABLE_BODY, Ir(e, t));
			break;
		default: wr(e, t);
	}
}
function zr(e, t) {
	switch (t.tagID) {
		case I.TR:
			e.openElements.hasInTableScope(I.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = V.IN_TABLE_BODY);
			break;
		case I.TABLE:
			e.openElements.hasInTableScope(I.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = V.IN_TABLE_BODY, Lr(e, t));
			break;
		case I.TBODY:
		case I.TFOOT:
		case I.THEAD:
			(e.openElements.hasInTableScope(t.tagID) || e.openElements.hasInTableScope(I.TR)) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = V.IN_TABLE_BODY, Lr(e, t));
			break;
		case I.BODY:
		case I.CAPTION:
		case I.COL:
		case I.COLGROUP:
		case I.HTML:
		case I.TD:
		case I.TH: break;
		default: Tr(e, t);
	}
}
function Br(e, t) {
	let n = t.tagID;
	Ar.has(n) ? (e.openElements.hasInTableScope(I.TD) || e.openElements.hasInTableScope(I.TH)) && (e._closeTableCell(), Rr(e, t)) : H(e, t);
}
function Vr(e, t) {
	let n = t.tagID;
	switch (n) {
		case I.TD:
		case I.TH:
			e.openElements.hasInTableScope(n) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(n), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = V.IN_ROW);
			break;
		case I.TABLE:
		case I.TBODY:
		case I.TFOOT:
		case I.THEAD:
		case I.TR:
			e.openElements.hasInTableScope(n) && (e._closeTableCell(), zr(e, t));
			break;
		case I.BODY:
		case I.CAPTION:
		case I.COL:
		case I.COLGROUP:
		case I.HTML: break;
		default: dr(e, t);
	}
}
function Hr(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.OPTION:
			e.openElements.currentTagId === I.OPTION && e.openElements.pop(), e._insertElement(t, N.HTML);
			break;
		case I.OPTGROUP:
			e.openElements.currentTagId === I.OPTION && e.openElements.pop(), e.openElements.currentTagId === I.OPTGROUP && e.openElements.pop(), e._insertElement(t, N.HTML);
			break;
		case I.HR:
			e.openElements.currentTagId === I.OPTION && e.openElements.pop(), e.openElements.currentTagId === I.OPTGROUP && e.openElements.pop(), e._appendElement(t, N.HTML), t.ackSelfClosing = !0;
			break;
		case I.INPUT:
		case I.KEYGEN:
		case I.TEXTAREA:
		case I.SELECT:
			e.openElements.hasInSelectScope(I.SELECT) && (e.openElements.popUntilTagNamePopped(I.SELECT), e._resetInsertionMode(), t.tagID !== I.SELECT && e._processStartTag(t));
			break;
		case I.SCRIPT:
		case I.TEMPLATE: ln(e, t);
	}
}
function Ur(e, t) {
	switch (t.tagID) {
		case I.OPTGROUP:
			e.openElements.stackTop > 0 && e.openElements.currentTagId === I.OPTION && e.openElements.tagIDs[e.openElements.stackTop - 1] === I.OPTGROUP && e.openElements.pop(), e.openElements.currentTagId === I.OPTGROUP && e.openElements.pop();
			break;
		case I.OPTION:
			e.openElements.currentTagId === I.OPTION && e.openElements.pop();
			break;
		case I.SELECT:
			e.openElements.hasInSelectScope(I.SELECT) && (e.openElements.popUntilTagNamePopped(I.SELECT), e._resetInsertionMode());
			break;
		case I.TEMPLATE: dn(e, t);
	}
}
function Wr(e, t) {
	let n = t.tagID;
	n === I.CAPTION || n === I.TABLE || n === I.TBODY || n === I.TFOOT || n === I.THEAD || n === I.TR || n === I.TD || n === I.TH ? (e.openElements.popUntilTagNamePopped(I.SELECT), e._resetInsertionMode(), e._processStartTag(t)) : Hr(e, t);
}
function Gr(e, t) {
	let n = t.tagID;
	n === I.CAPTION || n === I.TABLE || n === I.TBODY || n === I.TFOOT || n === I.THEAD || n === I.TR || n === I.TD || n === I.TH ? e.openElements.hasInTableScope(n) && (e.openElements.popUntilTagNamePopped(I.SELECT), e._resetInsertionMode(), e.onEndTag(t)) : Ur(e, t);
}
function Kr(e, t) {
	switch (t.tagID) {
		case I.BASE:
		case I.BASEFONT:
		case I.BGSOUND:
		case I.LINK:
		case I.META:
		case I.NOFRAMES:
		case I.SCRIPT:
		case I.STYLE:
		case I.TEMPLATE:
		case I.TITLE:
			ln(e, t);
			break;
		case I.CAPTION:
		case I.COLGROUP:
		case I.TBODY:
		case I.TFOOT:
		case I.THEAD:
			e.tmplInsertionModeStack[0] = V.IN_TABLE, e.insertionMode = V.IN_TABLE, wr(e, t);
			break;
		case I.COL:
			e.tmplInsertionModeStack[0] = V.IN_COLUMN_GROUP, e.insertionMode = V.IN_COLUMN_GROUP, Nr(e, t);
			break;
		case I.TR:
			e.tmplInsertionModeStack[0] = V.IN_TABLE_BODY, e.insertionMode = V.IN_TABLE_BODY, Ir(e, t);
			break;
		case I.TD:
		case I.TH:
			e.tmplInsertionModeStack[0] = V.IN_ROW, e.insertionMode = V.IN_ROW, Rr(e, t);
			break;
		default: e.tmplInsertionModeStack[0] = V.IN_BODY, e.insertionMode = V.IN_BODY, H(e, t);
	}
}
function qr(e, t) {
	t.tagID === I.TEMPLATE && dn(e, t);
}
function Jr(e, t) {
	e.openElements.tmplCount > 0 ? (e.openElements.popUntilTagNamePopped(I.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode(), e.onEof(t)) : $t(e, t);
}
function Yr(e, t) {
	t.tagID === I.HTML ? H(e, t) : Zr(e, t);
}
function Xr(e, t) {
	if (t.tagID === I.HTML) {
		if (e.fragmentContext || (e.insertionMode = V.AFTER_AFTER_BODY), e.options.sourceCodeLocationInfo && e.openElements.tagIDs[0] === I.HTML) {
			e._setEndLocation(e.openElements.items[0], t);
			let n = e.openElements.items[1];
			n && !e.treeAdapter.getNodeSourceCodeLocation(n)?.endTag && e._setEndLocation(n, t);
		}
	} else Zr(e, t);
}
function Zr(e, t) {
	e.insertionMode = V.IN_BODY, yn(e, t);
}
function Qr(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.FRAMESET:
			e._insertElement(t, N.HTML);
			break;
		case I.FRAME:
			e._appendElement(t, N.HTML), t.ackSelfClosing = !0;
			break;
		case I.NOFRAMES: ln(e, t);
	}
}
function $r(e, t) {
	t.tagID === I.FRAMESET && !e.openElements.isRootHtmlElementCurrent() && (e.openElements.pop(), !e.fragmentContext && e.openElements.currentTagId !== I.FRAMESET && (e.insertionMode = V.AFTER_FRAMESET));
}
function ei(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.NOFRAMES: ln(e, t);
	}
}
function ti(e, t) {
	t.tagID === I.HTML && (e.insertionMode = V.AFTER_AFTER_FRAMESET);
}
function ni(e, t) {
	t.tagID === I.HTML ? H(e, t) : ri(e, t);
}
function ri(e, t) {
	e.insertionMode = V.IN_BODY, yn(e, t);
}
function ii(e, t) {
	switch (t.tagID) {
		case I.HTML:
			H(e, t);
			break;
		case I.NOFRAMES: ln(e, t);
	}
}
function ai(e, t) {
	t.chars = "�", e._insertCharacters(t);
}
function oi(e, t) {
	e._insertCharacters(t), e.framesetOk = !1;
}
function si(e) {
	for (; e.treeAdapter.getNamespaceURI(e.openElements.current) !== N.HTML && e.openElements.currentTagId !== void 0 && !e._isIntegrationPoint(e.openElements.currentTagId, e.openElements.current);) e.openElements.pop();
}
function ci(e, t) {
	if (Ot(t)) si(e), e._startTagOutsideForeignContent(t);
	else {
		let n = e._getAdjustedCurrentElement(), r = e.treeAdapter.getNamespaceURI(n);
		r === N.MATHML ? kt(t) : r === N.SVG && (Mt(t), At(t)), jt(t), t.selfClosing ? e._appendElement(t, r) : e._insertElement(t, r), t.ackSelfClosing = !0;
	}
}
function li(e, t) {
	if (t.tagID === I.P || t.tagID === I.BR) si(e), e._endTagOutsideForeignContent(t);
	else for (let n = e.openElements.stackTop; n > 0; n--) {
		let r = e.openElements.items[n];
		if (e.treeAdapter.getNamespaceURI(r) === N.HTML) {
			e._endTagOutsideForeignContent(t);
			break;
		}
		let i = e.treeAdapter.getTagName(r);
		if (i.toLowerCase() === t.tagName) {
			t.tagName = i, e.openElements.shortenToLength(n);
			break;
		}
	}
}
// node_modules/entities/dist/escape.js
function ui(e) {
	return e === 34 ? "&quot;" : e === 38 ? "&amp;" : e === 39 ? "&apos;" : e === 60 ? "&lt;" : e === 62 ? "&gt;" : "&nbsp;";
}
function di(e, t) {
	if (e.lastIndex = 0, !e.test(t)) return t;
	let n = "", r = 0;
	do {
		let i = e.lastIndex - 1;
		r !== i && (n += t.substring(r, i));
		let a = t.charCodeAt(i);
		n += ui(a), r = i + 1;
	} while (e.test(t));
	return n + t.substring(r);
}
var fi = /["&\u{A0}]/gu;
function pi(e) {
	return di(fi, e);
}
var mi = /[&<>\u{A0}]/gu;
function hi(e) {
	return di(mi, e);
}
// node_modules/parse5/dist/serializer/index.js
var gi = /* @__PURE__ */ new Set([
	F.AREA,
	F.BASE,
	F.BASEFONT,
	F.BGSOUND,
	F.BR,
	F.COL,
	F.EMBED,
	F.FRAME,
	F.HR,
	F.IMG,
	F.INPUT,
	F.KEYGEN,
	F.LINK,
	F.META,
	F.PARAM,
	F.SOURCE,
	F.TRACK,
	F.WBR
]);
function _i(e, t) {
	return t.treeAdapter.isElementNode(e) && t.treeAdapter.getNamespaceURI(e) === N.HTML && gi.has(t.treeAdapter.getTagName(e));
}
var vi = {
	treeAdapter: B,
	scriptingEnabled: !0
};
function yi(e, t) {
	let n = {
		...vi,
		...t
	};
	return _i(e, n) ? "" : xi(e, n);
}
function bi(e, t) {
	return Si(e, {
		...vi,
		...t
	});
}
function xi(e, t) {
	let n = "", r = t.treeAdapter.isElementNode(e) && t.treeAdapter.getTagName(e) === F.TEMPLATE && t.treeAdapter.getNamespaceURI(e) === N.HTML ? t.treeAdapter.getTemplateContent(e) : e, i = t.treeAdapter.getChildNodes(r);
	if (i) for (let e of i) n += Si(e, t);
	return n;
}
function Si(e, t) {
	return t.treeAdapter.isElementNode(e) ? Ci(e, t) : t.treeAdapter.isTextNode(e) ? Ti(e, t) : t.treeAdapter.isCommentNode(e) ? Ei(e, t) : t.treeAdapter.isDocumentTypeNode(e) ? Di(e, t) : "";
}
function Ci(e, t) {
	let n = t.treeAdapter.getTagName(e);
	return `<${n}${wi(e, t)}>${_i(e, t) ? "" : `${xi(e, t)}</${n}>`}`;
}
function wi(e, { treeAdapter: t }) {
	let n = "";
	for (let r of t.getAttrList(e)) {
		if (n += " ", r.namespace) switch (r.namespace) {
			case N.XML:
				n += `xml:${r.name}`;
				break;
			case N.XMLNS:
				r.name !== "xmlns" && (n += "xmlns:"), n += r.name;
				break;
			case N.XLINK:
				n += `xlink:${r.name}`;
				break;
			default: n += `${r.prefix}:${r.name}`;
		}
		else n += r.name;
		n += `="${pi(r.value)}"`;
	}
	return n;
}
function Ti(e, t) {
	let { treeAdapter: n } = t, r = n.getTextNodeContent(e), i = n.getParentNode(e), a = i && n.isElementNode(i) && n.getTagName(i);
	return a && n.getNamespaceURI(i) === N.HTML && Le(a, t.scriptingEnabled) ? r : hi(r);
}
function Ei(e, { treeAdapter: t }) {
	return `<!--${t.getCommentNodeContent(e)}-->`;
}
function Di(e, { treeAdapter: t }) {
	return `<!DOCTYPE ${t.getDocumentTypeNodeName(e)}>`;
}
// node_modules/parse5/dist/index.js
function Oi(e, t) {
	return Ht.parse(e, t);
}
function ki(e, t, n) {
	typeof e == "string" && (n = t, t = e, e = null);
	let r = Ht.getFragmentParser(e, n);
	return r.tokenizer.write(t, !0), r.getFragment();
}
// src/local/html/html-table.ts
var Ai = {
	table: [
		"caption",
		"colgroup",
		"thead",
		"tbody",
		"tfoot"
	],
	colgroup: ["col"],
	thead: ["tr"],
	tbody: ["tr"],
	tfoot: ["tr"],
	tr: ["th", "td"],
	col: []
};
function ji(e, t, n) {
	let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, t + 80));
	if (!r) return null;
	let i = "";
	for (let a = t + r[0].length; a < n; a++) {
		let t = e[a];
		if (i) t === i && (i = "");
		else if (t === "\"" || t === "'") i = t;
		else if (t === ">") return {
			name: r[2].toLowerCase(),
			closing: !!r[1],
			end: a + 1
		};
	}
	return null;
}
function Mi(e, t, n) {
	let r = "", i = "";
	if (e.startsWith("\\(", t) ? (r = "\\(", i = "\\)") : e.startsWith("\\[", t) ? (r = "\\[", i = "\\]") : e[t] === "$" && (r = e[t + 1] === "$" ? "$$" : "$", i = r), !r) return null;
	for (let a = t + r.length; a < n; a++) {
		if (e.startsWith(i, a)) return r === "$" && (/^\s|\s$/.test(e.slice(t + 1, a)) || /\d/.test(e[a + 1] ?? "")) ? null : a + i.length;
		if (e[a] === "\\" && a++, r === "$" && e[a] === "\n") return null;
	}
	return r === "$" ? null : n;
}
function Ni(e, t, n, r) {
	let i = ji(e, t, n);
	if (!i || i.closing || i.name !== "table") return null;
	let a = 0, o = 0, s = n, c = !1, l = !1, u = [];
	for (let i = t; i < n;) {
		let t = Mi(e, i, n);
		if (t !== null) {
			i = t;
			continue;
		}
		let d = r.shield(i, n);
		if (d !== null) {
			i = d;
			continue;
		}
		if (e.startsWith("<!--", i)) {
			let t = e.indexOf("-->", i + 4);
			i = t < 0 ? n : Math.min(n, t + 3);
			continue;
		}
		if (e[i] !== "<") {
			i++;
			continue;
		}
		let f = ji(e, i, n);
		if (!f) i++;
		else if (!f.closing && [
			"pre",
			"code",
			"script",
			"style"
		].includes(f.name)) {
			let t = RegExp(`</${f.name}\\s*>`, "gi");
			t.lastIndex = f.end;
			let r = t.exec(e);
			i = r && r.index < n ? r.index + r[0].length : n;
		} else {
			if (w.has(f.name) && (u.push({
				start: i,
				end: f.end
			}), o++, f.name !== "table" && (l = !0), l && r.budget(i, o), f.name === "table" && (a += f.closing ? -1 : 1, a === 0))) {
				s = f.end, c = !0;
				break;
			}
			i = f.end;
		}
	}
	if (!l) return null;
	c || r.problem("unclosed", t, s, "table");
	let d = e.slice(t, s).replace(/[^\r\n]/g, " ").split("");
	for (let n of u) for (let r = n.start; r < n.end; r++) d[r - t] = e[r];
	let f = ki(d.join(""), { sourceCodeLocationInfo: !0 }).childNodes.find((e) => e.tagName === "table");
	if (!f) return r.problem("structure", t, s), {
		node: r.node("htmlTable", t, s, { children: [] }),
		end: s
	};
	let p = (e) => {
		let n = e.sourceCodeLocation;
		if (n) return {
			start: t + n.startOffset,
			end: t + n.endOffset
		};
		let r = (e.childNodes ?? []).filter((e) => e.tagName);
		return r.length ? {
			start: p(r[0]).start,
			end: p(r.at(-1)).end
		} : {
			start: t,
			end: t
		};
	}, m = (t, n) => !e.slice(t, n).replace(/<!--[\s\S]*?-->/g, "").trim(), h = (e, n) => {
		let i = e.tagName, a = e.sourceCodeLocation, o = p(e);
		if (n > 120) return r.problem("structure", o.start, o.end, i), r.node("htmlTableElement", o.start, o.end, {
			name: i,
			children: []
		});
		let s = a?.startTag ? r.attributes(i, t + a.startTag.startOffset, t + a.startTag.endOffset) : {}, c, l = a?.startTag ? t + a.startTag.endOffset : o.start, u = a?.endTag ? t + a.endTag.startOffset : o.end, d = (e.childNodes ?? []).filter((e) => e.tagName);
		if (i === "table" && [
			"caption",
			"thead",
			"tfoot"
		].some((e) => d.filter((t) => t.tagName === e).length > 1) && r.problem("structure", o.start, o.end, i), i === "colgroup" && s.span !== void 0 && d.length > 0 && r.problem("structure", o.start, o.end, i), i === "td" || i === "th" || i === "caption") c = r.content(l, u);
		else {
			c = [];
			let e = l;
			for (let t of d) {
				let a = p(t);
				m(e, a.start) || r.problem("mixed", e, a.start, i), (Ai[i] ?? []).includes(t.tagName) ? c.push(h(t, n + 1)) : r.problem("structure", a.start, a.end, i), e = a.end;
			}
			m(e, u) || r.problem("mixed", e, u, i);
		}
		return r.node(i === "table" ? "htmlTable" : "htmlTableElement", o.start, o.end, {
			name: i,
			attrs: s,
			children: c
		});
	};
	return {
		node: h(f, 0),
		end: s
	};
}
// src/local/html/html.ts
var Pi = "http://www.w3.org/1999/xhtml", Fi = /* @__PURE__ */ new Set([
	"b",
	"strong",
	"i",
	"em",
	"s",
	"del",
	"u",
	"mark",
	"sup",
	"sub",
	"br",
	"hr",
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"div",
	"span",
	"details",
	"summary",
	"blockquote",
	"code",
	"pre",
	"ul",
	"ol",
	"li",
	"a",
	"img",
	...w
]), Ii = /* @__PURE__ */ new Set([
	"html",
	"head",
	"body"
]), Li = /* @__PURE__ */ new Set([
	"frameset",
	"frame",
	"noframes",
	"applet"
]), Ri = /* @__PURE__ */ new Set([
	"animate",
	"animatemotion",
	"animatetransform",
	"set",
	"discard"
]), zi = /* @__PURE__ */ new Set(/* @__PURE__ */ "alignment-baseline.baseline-shift.clip.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-rendering.cursor.direction.display.dominant-baseline.fill.fill-opacity.fill-rule.filter.flood-color.flood-opacity.font.font-family.font-size.font-size-adjust.font-stretch.font-style.font-variant.font-weight.glyph-orientation-horizontal.glyph-orientation-vertical.image-rendering.kerning.letter-spacing.lighting-color.marker.marker-end.marker-mid.marker-start.mask.opacity.overflow.paint-order.pointer-events.shape-rendering.stop-color.stop-opacity.stroke.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke-width.text-anchor.text-decoration.text-rendering.transform-origin.unicode-bidi.vector-effect.visibility.word-spacing.writing-mode".split(".")), Bi = /* @__PURE__ */ new Set([
	"id",
	"class",
	"title",
	"lang",
	"dir"
]), Vi = /* @__PURE__ */ new Set([
	"align",
	"bgcolor",
	"background",
	"face",
	"text",
	"link",
	"alink",
	"vlink",
	"border",
	"cellpadding",
	"cellspacing",
	"frame",
	"rules",
	"hspace",
	"vspace"
]), Hi = {
	a: t,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...s,
	script: /* @__PURE__ */ new Set([
		"type",
		"src",
		"async",
		"defer",
		"nomodule",
		"crossorigin",
		"integrity",
		"referrerpolicy"
	]),
	style: /* @__PURE__ */ new Set(["type", "media"]),
	link: /* @__PURE__ */ new Set([
		"rel",
		"href",
		"type",
		"media",
		"crossorigin",
		"integrity",
		"referrerpolicy",
		"disabled"
	])
}, Ui = {
	href: "link",
	action: "form",
	formaction: "form",
	poster: "image",
	background: "image",
	data: "frame",
	src: "source",
	cite: "link",
	longdesc: "link"
}, Wi = 4, Gi = class extends Error {
	start;
	end;
	limit;
	constructor(e, t, n) {
		super(`Syntax nodes exceed the limit of ${n}.`), this.start = e, this.end = t, this.limit = n, this.name = "HtmlBudgetError";
	}
};
function Ki(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function qi(e, t, n) {
	let r = e.source.length, i = Math.max(0, Math.min(r, t)), a = Math.max(i, Math.min(r, Math.max(i, n))), o = 0, s = e.lines.starts.length - 1;
	for (; o < s;) {
		let t = Math.ceil((o + s) / 2);
		e.lines.starts[t] <= i ? o = t : s = t - 1;
	}
	return {
		start: i,
		end: a,
		line: o + 1,
		column: i - e.lines.starts[o] + 1
	};
}
function U(e, t, n, i, a, o) {
	if (e.diagnostics.length >= 100) return;
	let s = qi(e, i, a), c = r(o?.key ?? t, o?.params);
	e.diagnostics.push({
		code: t,
		message: n,
		severity: "warning",
		range: {
			start: s.start,
			end: s.end
		},
		line: s.line,
		column: s.column,
		messageKey: c.key,
		...c.params ? { params: c.params } : {}
	});
}
function Ji(e, t) {
	let n = e.sourceCodeLocation, r = n && Number.isInteger(n.startOffset) ? n.startOffset : 0, i = n && Number.isInteger(n.endOffset) ? n.endOffset : r;
	return {
		start: Math.max(0, Math.min(t.source.length, r)),
		end: Math.max(0, Math.min(t.source.length, i))
	};
}
function Yi(e, t, n) {
	let r = e.sourceCodeLocation?.attrs, i = r && (r[t.name] ?? (t.prefix ? r[`${t.prefix}:${t.name}`] : void 0));
	return i && Number.isInteger(i.startOffset) && Number.isInteger(i.endOffset) ? {
		start: i.startOffset,
		end: i.endOffset
	} : Ji(e, n);
}
function Xi(e, t, n) {
	if (e.budget.nodes += 1, e.budget.nodes > e.maxNodes) throw new Gi(t, n, e.maxNodes);
}
function Zi(e, t) {
	let n = Ji(e, t);
	return t.source.slice(n.start, n.end).replace(/\u0000/g, "�");
}
function Qi(e) {
	return B.createTextNode(e.replace(/\u0000/g, "�"));
}
function $i(e) {
	return e.replace(/[\u0000- \u007f-\u009f]+/g, "");
}
function ea(e) {
	let t = /^([a-z][a-z0-9+.-]*):/i.exec($i(e));
	return t ? t[1].toLowerCase() : null;
}
function ta(e, t) {
	let n = e.trim();
	if (n === "") return !0;
	let r = ea(n);
	return r === null ? !0 : r === "javascript" || r === "vbscript" ? !1 : r === "data" ? t === "image" && /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/i.test(n.replace(/\s+/g, "")) : r === "http" || r === "https" || t === "link" && (r === "mailto" || r === "tel");
}
function na(e) {
	return Object.hasOwn(Ui, e) || e === "xlink:href";
}
function ra(e, t) {
	return (e === "href" || e === "xlink:href") && t === "image" ? "image" : e === "href" && t === "base" ? "source" : e === "xlink:href" ? "link" : e === "src" ? t === "img" || t === "image" ? "image" : t === "iframe" || t === "frame" || t === "embed" ? "frame" : t === "audio" || t === "video" || t === "source" || t === "track" ? "media" : "source" : Ui[e] ?? "source";
}
function ia(e, t) {
	return Bi.has(t) || t.startsWith("aria-") || t.startsWith("data-") ? !0 : Hi[e]?.has(t) ?? !1;
}
function aa(e) {
	return /^on[a-z]/i.test(e);
}
function oa(e, t) {
	return zi.has(e) ? !0 : t && Vi.has(e);
}
function sa(e) {
	return [...e.enableJavaScript ? ["allow-scripts"] : [], ...e.enableExtendedHtml ? ["allow-forms"] : []].join(" ");
}
function ca(e, t) {
	return e.split(/\s+/).filter(Boolean).filter((e) => {
		let n = e.toLowerCase();
		return n === "allow-same-origin" || n === "allow-top-navigation" || n === "allow-top-navigation-by-user-activation" || n === "allow-parent-navigation" || n === "allow-popups" || n === "allow-popups-to-escape-sandbox" || n === "allow-modals" || n === "allow-downloads" || n === "allow-orientation-lock" || n === "allow-pointer-lock" || n === "allow-presentation" ? !1 : n === "allow-forms" ? t.enableExtendedHtml : n === "allow-scripts" && t.enableJavaScript;
	}).join(" ");
}
function la(e, t) {
	for (let n of e.childNodes) if (B.isElementNode(n) && n.tagName.toLowerCase() === t) return n;
	return null;
}
function ua(e) {
	let t = "";
	for (let n of e.childNodes) t += bi(n, { scriptingEnabled: !1 });
	return t;
}
function da(e) {
	return e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function fa(e) {
	return [
		"default-src 'none'",
		e.enableExtendedHtml ? "base-uri 'self' http: https:" : "base-uri 'none'",
		e.enableExtendedHtml ? "form-action http: https:" : "form-action 'none'",
		"object-src 'none'",
		"connect-src 'none'",
		"media-src 'none'",
		"font-src data:",
		"img-src data:",
		e.enableCss ? "style-src 'unsafe-inline'" : "style-src 'none'",
		e.enableJavaScript ? "script-src 'unsafe-inline'" : "script-src 'none'",
		e.enableExtendedHtml ? "frame-src about: data: blob:" : "frame-src 'none'"
	].join("; ");
}
function pa(e, t) {
	let n = la(t, "html"), r = n ? la(n, "head") : null, i = n ? la(n, "body") : null, a = r ? ua(r) : "", o = ua(i || n || t);
	e.bodyFallbacks.length > 0 && (o = e.bodyFallbacks.map((e) => bi(Qi(e), { scriptingEnabled: !1 })).join("") + o);
	let s = da(fa(e.policy)), c = (e) => (e?.attrs ?? []).map((e) => ` ${e.prefix ? `${e.prefix}:` : ""}${e.name}="${da(e.value)}"`).join("");
	return `<!doctype html><html${c(n)}><head${c(r)}><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${s}">${a}</head><body${c(i)}>${o}</body></html>`;
}
function ma(e) {
	let t = e.source.replace(/\u0000/g, "�").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${da(fa(e.policy))}"></head><body><pre data-local-html-fallback="document">\n${t}</pre></body></html>`;
}
function ha(e, t, n) {
	if (t.depth >= Wi) return "";
	let r = t.diagnostics.length, i = () => (ba(t, r), U(t, "local.html.fallback", "Native HTML was safely converted to inert source text.", n.start, n.end), ma({
		...t,
		source: e
	})), a;
	try {
		a = Oi(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch {
		return i();
	}
	let o = {
		...t,
		source: e,
		lines: { starts: Ki(e) },
		depth: t.depth + 1,
		bodyFallbacks: []
	};
	try {
		let e = la(a, "html");
		if (e) {
			let n = t.diagnostics.length;
			if (!ga(e, "html", !0, o)) return ba(o, n), ma(o);
			xa(e, o, !1);
		}
		return pa(o, a);
	} catch (e) {
		if (e instanceof Gi) throw e;
		return i();
	}
}
function ga(e, t, r, o) {
	e.sourceCodeLocation;
	let s = [], c = !1, l = !0;
	for (let a of e.attrs) {
		let u = a.name.toLowerCase(), d = a.prefix ? `${a.prefix}:${a.name}` : a.name, f = Yi(e, a, o);
		if (r && w.has(t) && !h(u, a.value)) l = !1, U(o, "local.html.table", `Invalid value for ${u} on native HTML <${t}>.`, f.start, f.end, {
			key: "html.table.value",
			params: {
				name: u,
				tag: t
			}
		});
		else if (r && u === "align" && i.has(t)) {
			let e = n(a.value);
			e ? s.push({
				...a,
				value: e
			}) : (l = !1, U(o, "local.html.attribute", "HTML attribute align requires left, center, right or justify.", f.start, f.end, {
				key: "local.html.attribute",
				params: {
					name: d,
					tag: t
				}
			}));
		} else if (aa(u)) {
			if (!o.policy.enableJavaScript) {
				U(o, "local.html.capability", `Author event handler attribute ${d} was disabled by the compile options.`, f.start, f.end, {
					key: "local.html.capability",
					params: { feature: "event handlers" }
				});
				continue;
			}
			s.push(a);
		} else if (u === "style" || oa(u, r)) {
			if (!o.policy.enableCss) {
				U(o, "local.html.capability", `Author style attribute ${d} was disabled by the compile options.`, f.start, f.end, {
					key: "local.html.capability",
					params: { feature: "CSS" }
				});
				continue;
			}
			s.push(a);
		} else if (u === "srcset" || u === "imagesrcset") U(o, "local.html.unsafe-url", `Unsafe URL in attribute ${d} was removed.`, f.start, f.end, {
			key: "local.html.unsafe-url",
			params: { name: d }
		});
		else if (u === "srcdoc" && t === "iframe") {
			let e = ha(a.value, o, f);
			if (e === "") continue;
			a.value = e, s.push(a);
		} else u === "sandbox" && t === "iframe" ? (a.value = ca(a.value, o.policy), c = !0, s.push(a)) : na(u) && !ta(a.value, ra(u, t)) ? U(o, "local.html.unsafe-url", `Unsafe URL in attribute ${d} was removed.`, f.start, f.end, {
			key: "local.html.unsafe-url",
			params: { name: d }
		}) : u === "target" && /^_(?:top|parent)$/i.test(a.value.trim()) ? U(o, "local.html.capability", `Navigation target ${a.value} was disabled.`, f.start, f.end, {
			key: "local.html.capability",
			params: { feature: "top-level navigation" }
		}) : !o.policy.enableExtendedHtml && !ia(t, u) ? (l = !1, U(o, "local.html.attribute", `HTML attribute ${d} on <${t}> is not supported; the element is shown as source.`, f.start, f.end, {
			key: "local.html.attribute",
			params: {
				name: d,
				tag: t
			}
		})) : s.push(a);
	}
	if (t === "iframe" && !c && s.push({
		name: "sandbox",
		value: sa(o.policy)
	}), t === "a") {
		let e = s.find((e) => e.name.toLowerCase() === "target")?.value, t = s.find((e) => e.name.toLowerCase() === "rel"), n = a(t?.value, e);
		n !== void 0 && (t ? t.value = n : s.push({
			name: "rel",
			value: n
		}));
	}
	return e.attrs = s, l;
}
function _a(e, t, n) {
	let r = t.diagnostics.length, i = Ji(e, t);
	Xi(t, i.start, i.end);
	let a = e.tagName.toLowerCase(), o = e.namespaceURI === Pi;
	if (Li.has(a)) return t.bodyFallbacks.push(Zi(e, t)), U(t, "local.html.fallback", `HTML element <${a}> requires enableExtendedHtml in this mode; it is shown as source.`, i.start, i.end, {
		key: "local.html.extended",
		params: { name: a }
	}), [];
	if (!o && !t.policy.enableCss && Ri.has(a)) return U(t, "local.html.capability", `Author animation <${a}> was disabled by the compile options.`, i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "animation" }
	}), [];
	if (a === "script") return t.policy.enableJavaScript ? ga(e, a, o, t) ? [e] : ya(e, t, n, r) : (U(t, "local.html.capability", "Author JavaScript was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "JavaScript" }
	}), []);
	if (a === "style") return t.policy.enableCss ? ga(e, a, o, t) ? [e] : ya(e, t, n, r) : (U(t, "local.html.capability", "Author CSS was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "CSS" }
	}), []);
	if (a === "link") return (e.attrs.find((e) => e.name.toLowerCase() === "rel")?.value.toLowerCase() ?? "").split(/\s+/).includes("stylesheet") ? t.policy.enableCss ? ga(e, a, o, t) ? [e] : ya(e, t, n, r) : (U(t, "local.html.capability", "Author CSS was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "CSS" }
	}), []) : t.policy.enableExtendedHtml ? ga(e, a, o, t) ? [e] : ya(e, t, n, r) : va(e, t);
	if (a === "meta") {
		if (!t.policy.enableExtendedHtml) return va(e, t);
		let s = e.attrs.find((e) => e.name.toLowerCase() === "http-equiv")?.value.trim().toLowerCase() ?? "";
		return s === "refresh" || s === "content-security-policy" || s === "set-cookie" ? (U(t, "local.html.capability", `Author metadata ${s} was disabled.`, i.start, i.end, {
			key: "local.html.capability",
			params: { feature: "document metadata" }
		}), []) : ga(e, a, o, t) ? [e] : ya(e, t, n, r);
	}
	return (a === "title" || a === "html" || a === "head" || a === "body") && !t.policy.enableExtendedHtml && a === "title" || !(o && (Fi.has(a) || Ii.has(a)) || t.policy.enableExtendedHtml) ? va(e, t, n) : ga(e, a, o, t) ? a === "template" ? (xa(B.getTemplateContent(e), t, !1), [e]) : (xa(e, t, n), [e]) : ya(e, t, n, r);
}
function va(e, t, n = !1) {
	let r = t.diagnostics.length, i = e.tagName.toLowerCase(), a = Ji(e, t);
	return U(t, "local.html.extended", `HTML element <${i}> requires enableExtendedHtml in this mode; it is shown as source.`, a.start, a.end, {
		key: "local.html.extended",
		params: { name: i }
	}), ya(e, t, n, r);
}
function ya(e, t, n, r) {
	return ba(t, r), n ? (t.bodyFallbacks.push(Zi(e, t)), []) : [Qi(Zi(e, t))];
}
function ba(e, t) {
	for (let n of e.diagnostics.slice(t)) n.severity === "warning" && (n.code = "local.html.fallback");
}
function xa(e, t, n) {
	let r = [];
	for (let i of e.childNodes) if (B.isTextNode(i)) Xi(t, 0, 0), r.push(i);
	else if (B.isCommentNode(i)) Xi(t, 0, 0), r.push(i);
	else if (!B.isDocumentTypeNode(i) && B.isElementNode(i)) {
		let e = i.tagName.toLowerCase(), a = n || e === "head";
		r.push(..._a(i, t, a));
	}
	e.childNodes = r;
}
function Sa(e, t, n) {
	let r = [], i = {
		policy: t,
		source: e,
		lines: { starts: Ki(e) },
		diagnostics: r,
		maxNodes: n,
		depth: 0,
		budget: { nodes: 0 },
		bodyFallbacks: [],
		stopped: !1
	}, a;
	try {
		a = Oi(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch (e) {
		return {
			markup: ma(i),
			diagnostics: [{
				code: "local.parse",
				message: `Cannot parse the HTML document: ${e instanceof Error ? e.message : String(e)}`,
				severity: "error",
				range: {
					start: 0,
					end: 0
				},
				line: 1,
				column: 1,
				messageKey: "local.parse.document",
				params: { detail: e instanceof Error ? e.message : String(e) }
			}]
		};
	}
	try {
		let e = la(a, "html");
		if (e) {
			let t = i.diagnostics.length;
			if (!ga(e, "html", !0, i)) return ba(i, t), {
				markup: ma(i),
				diagnostics: r
			};
			xa(e, i, !1);
		} else xa(a, i, !1);
		return {
			markup: pa(i, a),
			diagnostics: r
		};
	} catch (e) {
		if (e instanceof Gi) {
			let t = qi(i, e.start, e.end);
			return {
				markup: ma(i),
				diagnostics: [{
					code: "local.budget",
					message: e.message,
					severity: "error",
					range: {
						start: t.start,
						end: t.end
					},
					line: t.line,
					column: t.column,
					messageKey: "local.budget.nodes",
					params: { limit: e.limit }
				}]
			};
		}
		return {
			markup: ma(i),
			diagnostics: [{
				code: "local.parse",
				message: `Cannot parse the HTML document: ${e instanceof Error ? e.message : String(e)}`,
				severity: "error",
				range: {
					start: 0,
					end: 0
				},
				line: 1,
				column: 1,
				messageKey: "local.parse.document",
				params: { detail: e instanceof Error ? e.message : String(e) }
			}]
		};
	}
}
// node_modules/@lezer/common/dist/index.js
var Ca = 1024, wa = 0, Ta = class {
	constructor(e, t) {
		this.from = e, this.to = t;
	}
}, W = class {
	constructor(e = {}) {
		this.id = wa++, this.perNode = !!e.perNode, this.deserialize = e.deserialize || (() => {
			throw Error("This node type doesn't define a deserialize function");
		}), this.combine = e.combine || null;
	}
	add(e) {
		if (this.perNode) throw RangeError("Can't add per-node props to node types");
		return typeof e != "function" && (e = G.match(e)), (t) => {
			let n = e(t);
			return n === void 0 ? null : [this, n];
		};
	}
};
W.closedBy = new W({ deserialize: (e) => e.split(" ") }), W.openedBy = new W({ deserialize: (e) => e.split(" ") }), W.group = new W({ deserialize: (e) => e.split(" ") }), W.isolate = new W({ deserialize: (e) => {
	if (e && e != "rtl" && e != "ltr" && e != "auto") throw RangeError("Invalid value for isolate: " + e);
	return e || "auto";
} }), W.contextHash = new W({ perNode: !0 }), W.lookAhead = new W({ perNode: !0 }), W.mounted = new W({ perNode: !0 });
var Ea = class {
	constructor(e, t, n, r = !1) {
		this.tree = e, this.overlay = t, this.parser = n, this.bracketed = r;
	}
	static get(e) {
		return e && e.props && e.props[W.mounted.id];
	}
}, Da = Object.create(null), G = class e {
	constructor(e, t, n, r = 0) {
		this.name = e, this.props = t, this.id = n, this.flags = r;
	}
	static define(t) {
		let n = t.props && t.props.length ? Object.create(null) : Da, r = +!!t.top | (t.skipped ? 2 : 0) | (t.error ? 4 : 0) | (t.name == null ? 8 : 0), i = new e(t.name || "", n, t.id, r);
		if (t.props) {
			for (let e of t.props) if (Array.isArray(e) || (e = e(i)), e) {
				if (e[0].perNode) throw RangeError("Can't store a per-node prop on a node type");
				n[e[0].id] = e[1];
			}
		}
		return i;
	}
	prop(e) {
		return this.props[e.id];
	}
	get isTop() {
		return (this.flags & 1) > 0;
	}
	get isSkipped() {
		return (this.flags & 2) > 0;
	}
	get isError() {
		return (this.flags & 4) > 0;
	}
	get isAnonymous() {
		return (this.flags & 8) > 0;
	}
	is(e) {
		if (typeof e == "string") {
			if (this.name == e) return !0;
			let t = this.prop(W.group);
			return t ? t.indexOf(e) > -1 : !1;
		}
		return this.id == e;
	}
	static match(e) {
		let t = Object.create(null);
		for (let n in e) for (let r of n.split(" ")) t[r] = e[n];
		return (e) => {
			for (let n = e.prop(W.group), r = -1; r < (n ? n.length : 0); r++) {
				let i = t[r < 0 ? e.name : n[r]];
				if (i) return i;
			}
		};
	}
};
G.none = new G("", Object.create(null), 0, 8);
var Oa = class e {
	constructor(e) {
		this.types = e;
		for (let t = 0; t < e.length; t++) if (e[t].id != t) throw RangeError("Node type ids should correspond to array positions when creating a node set");
	}
	extend(...t) {
		let n = [];
		for (let e of this.types) {
			let r = null;
			for (let n of t) {
				let t = n(e);
				if (t) {
					r ||= Object.assign({}, e.props);
					let n = t[1], i = t[0];
					i.combine && i.id in r && (n = i.combine(r[i.id], n)), r[i.id] = n;
				}
			}
			n.push(r ? new G(e.name, r, e.id, e.flags) : e);
		}
		return new e(n);
	}
}, ka = /* @__PURE__ */ new WeakMap(), Aa = /* @__PURE__ */ new WeakMap(), K;
(function(e) {
	e[e.ExcludeBuffers = 1] = "ExcludeBuffers", e[e.IncludeAnonymous = 2] = "IncludeAnonymous", e[e.IgnoreMounts = 4] = "IgnoreMounts", e[e.IgnoreOverlays = 8] = "IgnoreOverlays", e[e.EnterBracketed = 16] = "EnterBracketed";
})(K ||= {});
var q = class e {
	constructor(e, t, n, r, i) {
		if (this.type = e, this.children = t, this.positions = n, this.length = r, this.props = null, i && i.length) {
			this.props = Object.create(null);
			for (let [e, t] of i) this.props[typeof e == "number" ? e : e.id] = t;
		}
	}
	toString() {
		let e = Ea.get(this);
		if (e && !e.overlay) return e.tree.toString();
		let t = "";
		for (let e of this.children) {
			let n = e.toString();
			n && (t && (t += ","), t += n);
		}
		return this.type.name ? (/\W/.test(this.type.name) && !this.type.isError ? JSON.stringify(this.type.name) : this.type.name) + (t.length ? "(" + t + ")" : "") : t;
	}
	cursor(e = 0) {
		return new Wa(this.topNode, e);
	}
	cursorAt(e, t = 0, n = 0) {
		let r = new Wa(ka.get(this) || this.topNode);
		return r.moveTo(e, t), ka.set(this, r._tree), r;
	}
	get topNode() {
		return new Ia(this, 0, 0, null);
	}
	resolve(e, t = 0) {
		let n = Pa(ka.get(this) || this.topNode, e, t, !1);
		return ka.set(this, n), n;
	}
	resolveInner(e, t = 0) {
		let n = Pa(Aa.get(this) || this.topNode, e, t, !0);
		return Aa.set(this, n), n;
	}
	resolveStack(e, t = 0) {
		return Ua(this, e, t);
	}
	iterate(e) {
		let { enter: t, leave: n, from: r = 0, to: i = this.length } = e, a = e.mode || 0, o = (a & K.IncludeAnonymous) > 0;
		for (let e = this.cursor(a | K.IncludeAnonymous);;) {
			let a = !1;
			if (e.from <= i && e.to >= r && (!o && e.type.isAnonymous || t(e) !== !1)) {
				if (e.firstChild()) continue;
				a = !0;
			}
			for (; a && n && (o || !e.type.isAnonymous) && n(e), !e.nextSibling();) {
				if (!e.parent()) return;
				a = !0;
			}
		}
	}
	prop(e) {
		return e.perNode ? this.props ? this.props[e.id] : void 0 : this.type.prop(e);
	}
	get propValues() {
		let e = [];
		if (this.props) for (let t in this.props) e.push([+t, this.props[t]]);
		return e;
	}
	balance(t = {}) {
		return this.children.length <= 8 ? this : Ya(G.none, this.children, this.positions, 0, this.children.length, 0, this.length, (t, n, r) => new e(this.type, t, n, r, this.propValues), t.makeTree || ((t, n, r) => new e(G.none, t, n, r)));
	}
	static build(e) {
		return Ka(e);
	}
};
q.empty = new q(G.none, [], [], 0);
var ja = class e {
	constructor(e, t) {
		this.buffer = e, this.index = t;
	}
	get id() {
		return this.buffer[this.index - 4];
	}
	get start() {
		return this.buffer[this.index - 3];
	}
	get end() {
		return this.buffer[this.index - 2];
	}
	get size() {
		return this.buffer[this.index - 1];
	}
	get pos() {
		return this.index;
	}
	next() {
		this.index -= 4;
	}
	fork() {
		return new e(this.buffer, this.index);
	}
}, Ma = class e {
	constructor(e, t, n) {
		this.buffer = e, this.length = t, this.set = n;
	}
	get type() {
		return G.none;
	}
	toString() {
		let e = [];
		for (let t = 0; t < this.buffer.length;) e.push(this.childString(t)), t = this.buffer[t + 3];
		return e.join(",");
	}
	childString(e) {
		let t = this.buffer[e], n = this.buffer[e + 3], r = this.set.types[t], i = r.name;
		if (/\W/.test(i) && !r.isError && (i = JSON.stringify(i)), e += 4, n == e) return i;
		let a = [];
		for (; e < n;) a.push(this.childString(e)), e = this.buffer[e + 3];
		return i + "(" + a.join(",") + ")";
	}
	findChild(e, t, n, r, i) {
		let { buffer: a } = this, o = -1;
		for (let s = e; s != t && !(Na(i, r, a[s + 1], a[s + 2]) && (o = s, n > 0)); s = a[s + 3]);
		return o;
	}
	slice(t, n, r) {
		let i = this.buffer, a = new Uint16Array(n - t), o = 0;
		for (let e = t, s = 0; e < n;) {
			a[s++] = i[e++], a[s++] = i[e++] - r;
			let n = a[s++] = i[e++] - r;
			a[s++] = i[e++] - t, o = Math.max(o, n);
		}
		return new e(a, o, this.set);
	}
};
function Na(e, t, n, r) {
	switch (e) {
		case -2: return n < t;
		case -1: return r >= t && n < t;
		case 0: return n < t && r > t;
		case 1: return n <= t && r > t;
		case 2: return r > t;
		case 4: return !0;
	}
}
function Pa(e, t, n, r) {
	for (; e.from == e.to || (n < 1 ? e.from >= t : e.from > t) || (n > -1 ? e.to <= t : e.to < t);) {
		let t = !r && e instanceof Ia && e.index < 0 ? null : e.parent;
		if (!t) return e;
		e = t;
	}
	let i = r ? 0 : K.IgnoreOverlays;
	if (r) for (let r = e, a = r.parent; a; r = a, a = r.parent) r instanceof Ia && r.index < 0 && a.enter(t, n, i)?.from != r.from && (e = a);
	for (;;) {
		let r = e.enter(t, n, i);
		if (!r) return e;
		e = r;
	}
}
var Fa = class {
	cursor(e = 0) {
		return new Wa(this, e);
	}
	getChild(e, t = null, n = null) {
		let r = La(this, e, t, n);
		return r.length ? r[0] : null;
	}
	getChildren(e, t = null, n = null) {
		return La(this, e, t, n);
	}
	resolve(e, t = 0) {
		return Pa(this, e, t, !1);
	}
	resolveInner(e, t = 0) {
		return Pa(this, e, t, !0);
	}
	matchContext(e) {
		return Ra(this.parent, e);
	}
	enterUnfinishedNodesBefore(e) {
		let t = this.childBefore(e), n = this;
		for (; t;) {
			let e = t.lastChild;
			if (!e || e.to != t.to) break;
			e.type.isError && e.from == e.to ? (n = t, t = e.prevSibling) : t = e;
		}
		return n;
	}
	get node() {
		return this;
	}
	get next() {
		return this.parent;
	}
}, Ia = class e extends Fa {
	constructor(e, t, n, r) {
		super(), this._tree = e, this.from = t, this.index = n, this._parent = r;
	}
	get type() {
		return this._tree.type;
	}
	get name() {
		return this._tree.type.name;
	}
	get to() {
		return this.from + this._tree.length;
	}
	nextChild(t, n, r, i, a = 0) {
		for (let o = this;;) {
			for (let { children: s, positions: c } = o._tree, l = n > 0 ? s.length : -1; t != l; t += n) {
				let l = s[t], u = c[t] + o.from, d;
				if (a & K.EnterBracketed && l instanceof q && (d = Ea.get(l)) && !d.overlay && d.bracketed && r >= u && r <= u + l.length || Na(i, r, u, u + l.length)) {
					if (l instanceof Ma) {
						if (a & K.ExcludeBuffers) continue;
						let e = l.findChild(0, l.buffer.length, n, r - u, i);
						if (e > -1) return new Ba(new za(o, l, t, u), null, e);
					} else if (a & K.IncludeAnonymous || !l.type.isAnonymous || Ga(l)) {
						let s;
						if (!(a & K.IgnoreMounts) && (s = Ea.get(l)) && !s.overlay) return new e(s.tree, u, t, o);
						let c = new e(l, u, t, o);
						return a & K.IncludeAnonymous || !c.type.isAnonymous ? c : c.nextChild(n < 0 ? l.children.length - 1 : 0, n, r, i, a);
					}
				}
			}
			if (a & K.IncludeAnonymous || !o.type.isAnonymous || (t = o.index >= 0 ? o.index + n : n < 0 ? -1 : o._parent._tree.children.length, o = o._parent, !o)) return null;
		}
	}
	get firstChild() {
		return this.nextChild(0, 1, 0, 4);
	}
	get lastChild() {
		return this.nextChild(this._tree.children.length - 1, -1, 0, 4);
	}
	childAfter(e) {
		return this.nextChild(0, 1, e, 2);
	}
	childBefore(e) {
		return this.nextChild(this._tree.children.length - 1, -1, e, -2);
	}
	prop(e) {
		return this._tree.prop(e);
	}
	enter(t, n, r = 0) {
		let i;
		if (!(r & K.IgnoreOverlays) && (i = Ea.get(this._tree)) && i.overlay) {
			let a = t - this.from, o = r & K.EnterBracketed && i.bracketed;
			for (let { from: t, to: r } of i.overlay) if ((n > 0 || o ? t <= a : t < a) && (n < 0 || o ? r >= a : r > a)) return new e(i.tree, i.overlay[0].from + this.from, -1, this);
		}
		return this.nextChild(0, 1, t, n, r);
	}
	nextSignificantParent() {
		let e = this;
		for (; e.type.isAnonymous && e._parent;) e = e._parent;
		return e;
	}
	get parent() {
		return this._parent ? this._parent.nextSignificantParent() : null;
	}
	get nextSibling() {
		return this._parent && this.index >= 0 ? this._parent.nextChild(this.index + 1, 1, 0, 4) : null;
	}
	get prevSibling() {
		return this._parent && this.index >= 0 ? this._parent.nextChild(this.index - 1, -1, 0, 4) : null;
	}
	get tree() {
		return this._tree;
	}
	toTree() {
		return this._tree;
	}
	toString() {
		return this._tree.toString();
	}
};
function La(e, t, n, r) {
	let i = e.cursor(), a = [];
	if (!i.firstChild()) return a;
	if (n != null) {
		for (let e = !1; !e;) if (e = i.type.is(n), !i.nextSibling()) return a;
	}
	for (;;) {
		if (r != null && i.type.is(r)) return a;
		if (i.type.is(t) && a.push(i.node), !i.nextSibling()) return r == null ? a : [];
	}
}
function Ra(e, t, n = t.length - 1) {
	for (let r = e; n >= 0; r = r.parent) {
		if (!r) return !1;
		if (!r.type.isAnonymous) {
			if (t[n] && t[n] != r.name) return !1;
			n--;
		}
	}
	return !0;
}
var za = class {
	constructor(e, t, n, r) {
		this.parent = e, this.buffer = t, this.index = n, this.start = r;
	}
}, Ba = class e extends Fa {
	get name() {
		return this.type.name;
	}
	get from() {
		return this.context.start + this.context.buffer.buffer[this.index + 1];
	}
	get to() {
		return this.context.start + this.context.buffer.buffer[this.index + 2];
	}
	constructor(e, t, n) {
		super(), this.context = e, this._parent = t, this.index = n, this.type = e.buffer.set.types[e.buffer.buffer[n]];
	}
	child(t, n, r) {
		let { buffer: i } = this.context, a = i.findChild(this.index + 4, i.buffer[this.index + 3], t, n - this.context.start, r);
		return a < 0 ? null : new e(this.context, this, a);
	}
	get firstChild() {
		return this.child(1, 0, 4);
	}
	get lastChild() {
		return this.child(-1, 0, 4);
	}
	childAfter(e) {
		return this.child(1, e, 2);
	}
	childBefore(e) {
		return this.child(-1, e, -2);
	}
	prop(e) {
		return this.type.prop(e);
	}
	enter(t, n, r = 0) {
		if (r & K.ExcludeBuffers) return null;
		let { buffer: i } = this.context, a = i.findChild(this.index + 4, i.buffer[this.index + 3], n > 0 ? 1 : -1, t - this.context.start, n);
		return a < 0 ? null : new e(this.context, this, a);
	}
	get parent() {
		return this._parent || this.context.parent.nextSignificantParent();
	}
	externalSibling(e) {
		return this._parent ? null : this.context.parent.nextChild(this.context.index + e, e, 0, 4);
	}
	get nextSibling() {
		let { buffer: t } = this.context, n = t.buffer[this.index + 3];
		return n < (this._parent ? t.buffer[this._parent.index + 3] : t.buffer.length) ? new e(this.context, this._parent, n) : this.externalSibling(1);
	}
	get prevSibling() {
		let { buffer: t } = this.context, n = this._parent ? this._parent.index + 4 : 0;
		return this.index == n ? this.externalSibling(-1) : new e(this.context, this._parent, t.findChild(n, this.index, -1, 0, 4));
	}
	get tree() {
		return null;
	}
	toTree() {
		let e = [], t = [], { buffer: n } = this.context, r = this.index + 4, i = n.buffer[this.index + 3];
		if (i > r) {
			let a = n.buffer[this.index + 1];
			e.push(n.slice(r, i, a)), t.push(0);
		}
		return new q(this.type, e, t, this.to - this.from);
	}
	toString() {
		return this.context.buffer.childString(this.index);
	}
};
function Va(e) {
	if (!e.length) return null;
	let t = 0, n = e[0];
	for (let r = 1; r < e.length; r++) {
		let i = e[r];
		(i.from > n.from || i.to < n.to) && (n = i, t = r);
	}
	let r = n instanceof Ia && n.index < 0 ? null : n.parent, i = e.slice();
	return r ? i[t] = r : i.splice(t, 1), new Ha(i, n);
}
var Ha = class {
	constructor(e, t) {
		this.heads = e, this.node = t;
	}
	get next() {
		return Va(this.heads);
	}
};
function Ua(e, t, n) {
	let r = e.resolveInner(t, n), i = null;
	for (let e = r instanceof Ia ? r : r.context.parent; e; e = e.parent) if (e.index < 0) {
		let a = e.parent;
		(i ||= [r]).push(a.resolve(t, n)), e = a;
	} else {
		let a = Ea.get(e.tree);
		if (a && a.overlay && a.overlay[0].from <= t && a.overlay[a.overlay.length - 1].to >= t) {
			let o = new Ia(a.tree, a.overlay[0].from + e.from, -1, e);
			(i ||= [r]).push(Pa(o, t, n, !1));
		}
	}
	return i ? Va(i) : r;
}
var Wa = class {
	get name() {
		return this.type.name;
	}
	constructor(e, t = 0) {
		if (this.buffer = null, this.stack = [], this.index = 0, this.bufferNode = null, this.mode = t & ~K.EnterBracketed, e instanceof Ia) this.yieldNode(e);
		else {
			this._tree = e.context.parent, this.buffer = e.context;
			for (let t = e._parent; t; t = t._parent) this.stack.unshift(t.index);
			this.bufferNode = e, this.yieldBuf(e.index);
		}
	}
	yieldNode(e) {
		return e ? (this._tree = e, this.type = e.type, this.from = e.from, this.to = e.to, !0) : !1;
	}
	yieldBuf(e, t) {
		this.index = e;
		let { start: n, buffer: r } = this.buffer;
		return this.type = t || r.set.types[r.buffer[e]], this.from = n + r.buffer[e + 1], this.to = n + r.buffer[e + 2], !0;
	}
	yield(e) {
		return e ? e instanceof Ia ? (this.buffer = null, this.yieldNode(e)) : (this.buffer = e.context, this.yieldBuf(e.index, e.type)) : !1;
	}
	toString() {
		return this.buffer ? this.buffer.buffer.childString(this.index) : this._tree.toString();
	}
	enterChild(e, t, n) {
		if (!this.buffer) return this.yield(this._tree.nextChild(e < 0 ? this._tree._tree.children.length - 1 : 0, e, t, n, this.mode));
		let { buffer: r } = this.buffer, i = r.findChild(this.index + 4, r.buffer[this.index + 3], e, t - this.buffer.start, n);
		return i < 0 ? !1 : (this.stack.push(this.index), this.yieldBuf(i));
	}
	firstChild() {
		return this.enterChild(1, 0, 4);
	}
	lastChild() {
		return this.enterChild(-1, 0, 4);
	}
	childAfter(e) {
		return this.enterChild(1, e, 2);
	}
	childBefore(e) {
		return this.enterChild(-1, e, -2);
	}
	enter(e, t, n = this.mode) {
		return this.buffer ? n & K.ExcludeBuffers ? !1 : this.enterChild(1, e, t) : this.yield(this._tree.enter(e, t, n));
	}
	parent() {
		if (!this.buffer) return this.yieldNode(this.mode & K.IncludeAnonymous ? this._tree._parent : this._tree.parent);
		if (this.stack.length) return this.yieldBuf(this.stack.pop());
		let e = this.mode & K.IncludeAnonymous ? this.buffer.parent : this.buffer.parent.nextSignificantParent();
		return this.buffer = null, this.yieldNode(e);
	}
	sibling(e) {
		if (!this.buffer) return this._tree._parent ? this.yield(this._tree.index < 0 ? null : this._tree._parent.nextChild(this._tree.index + e, e, 0, 4, this.mode)) : !1;
		let { buffer: t } = this.buffer, n = this.stack.length - 1;
		if (e < 0) {
			let e = n < 0 ? 0 : this.stack[n] + 4;
			if (this.index != e) return this.yieldBuf(t.findChild(e, this.index, -1, 0, 4));
		} else {
			let e = t.buffer[this.index + 3];
			if (e < (n < 0 ? t.buffer.length : t.buffer[this.stack[n] + 3])) return this.yieldBuf(e);
		}
		return n < 0 && this.yield(this.buffer.parent.nextChild(this.buffer.index + e, e, 0, 4, this.mode));
	}
	nextSibling() {
		return this.sibling(1);
	}
	prevSibling() {
		return this.sibling(-1);
	}
	atLastNode(e) {
		let t, n, { buffer: r } = this;
		if (r) {
			if (e > 0) {
				if (this.index < r.buffer.buffer.length) return !1;
			} else for (let e = 0; e < this.index; e++) if (r.buffer.buffer[e + 3] < this.index) return !1;
			({index: t, parent: n} = r);
		} else ({index: t, _parent: n} = this._tree);
		for (; n; {index: t, _parent: n} = n) if (t > -1) for (let r = t + e, i = e < 0 ? -1 : n._tree.children.length; r != i; r += e) {
			let e = n._tree.children[r];
			if (this.mode & K.IncludeAnonymous || e instanceof Ma || !e.type.isAnonymous || Ga(e)) return !1;
		}
		return !0;
	}
	move(e, t) {
		if (t && this.enterChild(e, 0, 4)) return !0;
		for (;;) {
			if (this.sibling(e)) return !0;
			if (this.atLastNode(e) || !this.parent()) return !1;
		}
	}
	next(e = !0) {
		return this.move(1, e);
	}
	prev(e = !0) {
		return this.move(-1, e);
	}
	moveTo(e, t = 0) {
		for (; (this.from == this.to || (t < 1 ? this.from >= e : this.from > e) || (t > -1 ? this.to <= e : this.to < e)) && this.parent(););
		for (; this.enterChild(1, e, t););
		return this;
	}
	get node() {
		if (!this.buffer) return this._tree;
		let e = this.bufferNode, t = null, n = 0;
		if (e && e.context == this.buffer) scan: for (let r = this.index, i = this.stack.length; i >= 0;) {
			for (let a = e; a; a = a._parent) if (a.index == r) {
				if (r == this.index) return a;
				t = a, n = i + 1;
				break scan;
			}
			r = this.stack[--i];
		}
		for (let e = n; e < this.stack.length; e++) t = new Ba(this.buffer, t, this.stack[e]);
		return this.bufferNode = new Ba(this.buffer, t, this.index);
	}
	get tree() {
		return this.buffer ? null : this._tree._tree;
	}
	iterate(e, t) {
		for (let n = 0;;) {
			let r = !1;
			if (this.type.isAnonymous || e(this) !== !1) {
				if (this.firstChild()) {
					n++;
					continue;
				}
				this.type.isAnonymous || (r = !0);
			}
			for (;;) {
				if (r && t && t(this), r = this.type.isAnonymous, !n) return;
				if (this.nextSibling()) break;
				this.parent(), n--, r = !0;
			}
		}
	}
	matchContext(e) {
		if (!this.buffer) return Ra(this.node.parent, e);
		let { buffer: t } = this.buffer, { types: n } = t.set;
		for (let r = e.length - 1, i = this.stack.length - 1; r >= 0; i--) {
			if (i < 0) return Ra(this._tree, e, r);
			let a = n[t.buffer[this.stack[i]]];
			if (!a.isAnonymous) {
				if (e[r] && e[r] != a.name) return !1;
				r--;
			}
		}
		return !0;
	}
};
function Ga(e) {
	return e.children.some((e) => e instanceof Ma || !e.type.isAnonymous || Ga(e));
}
function Ka(e) {
	let { buffer: t, nodeSet: n, maxBufferLength: r = Ca, reused: i = [], minRepeatType: a = n.types.length } = e, o = Array.isArray(t) ? new ja(t, t.length) : t, s = n.types, c = 0, l = 0;
	function u(e, t, _, v, y, ee) {
		let { id: b, start: x, end: S, size: C } = o, te = l, ne = c;
		if (C < 0) {
			if (o.next(), C == -1) {
				let t = i[b];
				_.push(t), v.push(x - e);
				return;
			}
			if (C == -3) {
				c = b;
				return;
			}
			if (C == -4) {
				l = b;
				return;
			}
			throw RangeError(`Unrecognized record size: ${C}`);
		}
		let w = s[b], re, T, ie = x - e;
		if (S - x <= r && (T = h(o.pos - t, y))) {
			let t = new Uint16Array(T.size - T.skip), r = o.pos - T.size, i = t.length;
			for (; o.pos > r;) i = g(T.start, t, i);
			re = new Ma(t, S - T.start, n), ie = T.start - e;
		} else {
			let e = o.pos - C;
			o.next();
			let t = [], n = [], i = b >= a ? b : -1, s = 0, c = S, h = te;
			for (; o.pos > e;) i >= 0 && o.id == i && o.size >= 0 ? (o.end <= c - r && (p(t, n, x, s, o.end, c, i, h, ne), s = t.length, c = o.end, h = l), o.next()) : ee > 2500 ? d(x, e, t, n) : u(x, e, t, n, i, ee + 1);
			if (i >= 0 && s > 0 && s < t.length && p(t, n, x, s, x, c, i, h, ne), t.reverse(), n.reverse(), i > -1 && s > 0) {
				let e = f(w, ne);
				re = Ya(w, t, n, 0, t.length, 0, S - x, e, e);
			} else re = m(w, t, n, S - x, te - S, ne);
		}
		_.push(re), v.push(ie);
	}
	function d(e, t, i, a) {
		let s = [], c = 0, l = -1;
		for (; o.pos > t;) {
			let { id: e, start: t, end: n, size: i } = o;
			if (i > 4) o.next();
			else if (l > -1 && t < l) break;
			else l < 0 && (l = n - r), s.push(e, t, n), c++, o.next();
		}
		if (c) {
			let t = new Uint16Array(c * 4), r = s[s.length - 2];
			for (let e = s.length - 3, n = 0; e >= 0; e -= 3) t[n++] = s[e], t[n++] = s[e + 1] - r, t[n++] = s[e + 2] - r, t[n++] = n;
			i.push(new Ma(t, s[2] - r, n)), a.push(r - e);
		}
	}
	function f(e, t) {
		return (n, r, i) => {
			let a = 0, o = n.length - 1, s, c;
			if (o >= 0 && (s = n[o]) instanceof q) {
				if (!o && s.type == e && s.length == i) return s;
				(c = s.prop(W.lookAhead)) && (a = r[o] + s.length + c - i);
			}
			return m(e, n, r, i, a, t);
		};
	}
	function p(e, t, r, i, a, o, s, c, l) {
		let u = [], d = [];
		for (; e.length > i;) u.push(e.pop()), d.push(t.pop() + r - a);
		e.push(m(n.types[s], u, d, o - a, c - o, l)), t.push(a - r);
	}
	function m(e, t, n, r, i, a, o) {
		if (a) {
			let e = [W.contextHash, a];
			o = o ? [e].concat(o) : [e];
		}
		if (i > 25) {
			let e = [W.lookAhead, i];
			o = o ? [e].concat(o) : [e];
		}
		return new q(e, t, n, r, o);
	}
	function h(e, t) {
		let n = o.fork(), i = 0, s = 0, c = 0, l = n.end - r, u = {
			size: 0,
			start: 0,
			skip: 0
		};
		scan: for (let r = n.pos - e; n.pos > r;) {
			let e = n.size;
			if (n.id == t && e >= 0) {
				u.size = i, u.start = s, u.skip = c, c += 4, i += 4, n.next();
				continue;
			}
			let o = n.pos - e;
			if (e < 0 || o < r || n.start < l) break;
			let d = n.id >= a ? 4 : 0, f = n.start;
			for (n.next(); n.pos > o;) {
				if (n.size < 0) {
					if (n.size == -3 || n.size == -4) d += 4;
					else break scan;
				} else n.id >= a && (d += 4);
				n.next();
			}
			s = f, i += e, c += d;
		}
		return (t < 0 || i == e) && (u.size = i, u.start = s, u.skip = c), u.size > 4 ? u : void 0;
	}
	function g(e, t, n) {
		let { id: r, start: i, end: s, size: u } = o;
		if (o.next(), u >= 0 && r < a) {
			let a = n;
			if (u > 4) {
				let r = o.pos - (u - 4);
				for (; o.pos > r;) n = g(e, t, n);
			}
			t[--n] = a, t[--n] = s - e, t[--n] = i - e, t[--n] = r;
		} else u == -3 ? c = r : u == -4 && (l = r);
		return n;
	}
	let _ = [], v = [];
	for (; o.pos > 0;) u(e.start || 0, e.bufferStart || 0, _, v, -1, 0);
	let y = e.length ?? (_.length ? v[0] + _[0].length : 0);
	return new q(s[e.topID], _.reverse(), v.reverse(), y);
}
var qa = /* @__PURE__ */ new WeakMap();
function Ja(e, t) {
	if (!e.isAnonymous || t instanceof Ma || t.type != e) return 1;
	let n = qa.get(t);
	if (n == null) {
		n = 1;
		for (let r of t.children) {
			if (r.type != e || !(r instanceof q)) {
				n = 1;
				break;
			}
			n += Ja(e, r);
		}
		qa.set(t, n);
	}
	return n;
}
function Ya(e, t, n, r, i, a, o, s, c) {
	let l = 0;
	for (let n = r; n < i; n++) l += Ja(e, t[n]);
	let u = Math.ceil(l * 1.5 / 8), d = [], f = [];
	function p(t, n, r, i, o) {
		for (let s = r; s < i;) {
			let r = s, l = n[s], m = Ja(e, t[s]);
			for (s++; s < i; s++) {
				let n = Ja(e, t[s]);
				if (m + n >= u) break;
				m += n;
			}
			if (s == r + 1) {
				if (m > u) {
					let e = t[r];
					p(e.children, e.positions, 0, e.children.length, n[r] + o);
					continue;
				}
				d.push(t[r]);
			} else {
				let i = n[s - 1] + t[s - 1].length - l;
				d.push(Ya(e, t, n, r, s, l, i, null, c));
			}
			f.push(l + o - a);
		}
	}
	return p(t, n, r, i, 0), (s || c)(d, f, o);
}
var Xa = class e {
	constructor(e, t, n, r, i = !1, a = !1) {
		this.from = e, this.to = t, this.tree = n, this.offset = r, this.open = !!i | (a ? 2 : 0);
	}
	get openStart() {
		return (this.open & 1) > 0;
	}
	get openEnd() {
		return (this.open & 2) > 0;
	}
	static addTree(t, n = [], r = !1) {
		let i = [new e(0, t.length, t, 0, !1, r)];
		for (let e of n) e.to > t.length && i.push(e);
		return i;
	}
	static applyChanges(t, n, r = 128) {
		if (!n.length) return t;
		let i = [], a = 1, o = t.length ? t[0] : null;
		for (let s = 0, c = 0, l = 0;; s++) {
			let u = s < n.length ? n[s] : null, d = u ? u.fromA : 1e9;
			if (d - c >= r) for (; o && o.from < d;) {
				let n = o;
				if (c >= n.from || d <= n.to || l) {
					let t = Math.max(n.from, c) - l, r = Math.min(n.to, d) - l;
					n = t >= r ? null : new e(t, r, n.tree, n.offset + l, s > 0, !!u);
				}
				if (n && i.push(n), o.to > d) break;
				o = a < t.length ? t[a++] : null;
			}
			if (!u) break;
			c = u.toA, l = u.toA - u.toB;
		}
		return i;
	}
}, Za = class {
	startParse(e, t, n) {
		return typeof e == "string" && (e = new Qa(e)), n = n ? n.length ? n.map((e) => new Ta(e.from, e.to)) : [new Ta(0, 0)] : [new Ta(0, e.length)], this.createParse(e, t || [], n);
	}
	parse(e, t, n) {
		let r = this.startParse(e, t, n);
		for (;;) {
			let e = r.advance();
			if (e) return e;
		}
	}
}, Qa = class {
	constructor(e) {
		this.string = e;
	}
	get length() {
		return this.string.length;
	}
	chunk(e) {
		return this.string.slice(e);
	}
	get lineChunks() {
		return !1;
	}
	read(e, t) {
		return this.string.slice(e, t);
	}
};
new W({ perNode: !0 });
// node_modules/@lezer/highlight/dist/index.js
var $a = 0, eo = class e {
	constructor(e, t, n, r) {
		this.name = e, this.set = t, this.base = n, this.modified = r, this.id = $a++;
	}
	toString() {
		let { name: e } = this;
		for (let t of this.modified) t.name && (e = `${t.name}(${e})`);
		return e;
	}
	static define(t, n) {
		let r = typeof t == "string" ? t : "?";
		if (t instanceof e && (n = t), n?.base) throw Error("Can not derive from a modified tag");
		let i = new e(r, [], null, []);
		if (i.set.push(i), n) for (let e of n.set) i.set.push(e);
		return i;
	}
	static defineModifier(e) {
		let t = new no(e);
		return (e) => e.modified.indexOf(t) > -1 ? e : no.get(e.base || e, e.modified.concat(t).sort((e, t) => e.id - t.id));
	}
}, to = 0, no = class e {
	constructor(e) {
		this.name = e, this.instances = [], this.id = to++;
	}
	static get(t, n) {
		if (!n.length) return t;
		let r = n[0].instances.find((e) => e.base == t && ro(n, e.modified));
		if (r) return r;
		let i = [], a = new eo(t.name, i, t, n);
		for (let e of n) e.instances.push(a);
		let o = io(n);
		for (let n of t.set) if (!n.modified.length) for (let t of o) i.push(e.get(n, t));
		return a;
	}
};
function ro(e, t) {
	return e.length == t.length && e.every((e, n) => e == t[n]);
}
function io(e) {
	let t = [[]];
	for (let n = 0; n < e.length; n++) for (let r = 0, i = t.length; r < i; r++) t.push(t[r].concat(e[n]));
	return t.sort((e, t) => t.length - e.length);
}
function ao(e) {
	let t = Object.create(null);
	for (let n in e) {
		let r = e[n];
		Array.isArray(r) || (r = [r]);
		for (let e of n.split(" ")) if (e) {
			let n = [], i = 2, a = e;
			for (let t = 0;;) {
				if (a == "..." && t > 0 && t + 3 == e.length) {
					i = 1;
					break;
				}
				let r = /^"(?:[^"\\]|\\.)*?"|[^\/!]+/.exec(a);
				if (!r) throw RangeError("Invalid path: " + e);
				if (n.push(r[0] == "*" ? "" : r[0][0] == "\"" ? JSON.parse(r[0]) : r[0]), t += r[0].length, t == e.length) break;
				let o = e[t++];
				if (t == e.length && o == "!") {
					i = 0;
					break;
				}
				if (o != "/") throw RangeError("Invalid path: " + e);
				a = e.slice(t);
			}
			let o = n.length - 1, s = n[o];
			if (!s) throw RangeError("Invalid path: " + e);
			t[s] = new so(r, i, o > 0 ? n.slice(0, o) : null).sort(t[s]);
		}
	}
	return oo.add(t);
}
var oo = new W({ combine(e, t) {
	let n, r, i;
	for (; e || t;) {
		if (!e || t && e.depth <= t.depth ? (i = t, t = t.next) : (i = e, e = e.next), n && n.mode == i.mode && !i.context && !n.context) continue;
		let a = new so(i.tags, i.mode, i.context);
		n ? n.next = a : r = a, n = a;
	}
	return r;
} }), so = class {
	constructor(e, t, n, r) {
		this.tags = e, this.mode = t, this.context = n, this.next = r;
	}
	get opaque() {
		return this.mode == 0;
	}
	get inherit() {
		return this.mode == 1;
	}
	sort(e) {
		return !e || e.depth < this.depth ? (this.next = e, this) : (e.next = this.sort(e.next), e);
	}
	get depth() {
		return this.context ? this.context.length : 0;
	}
};
so.empty = new so([], 2, null);
function co(e, t) {
	let n = Object.create(null);
	for (let t of e) if (!Array.isArray(t.tag)) n[t.tag.id] = t.class;
	else for (let e of t.tag) n[e.id] = t.class;
	let { scope: r, all: i = null } = t || {};
	return {
		style: (e) => {
			let t = i;
			for (let r of e) for (let e of r.set) {
				let r = n[e.id];
				if (r) {
					t = t ? t + " " + r : r;
					break;
				}
			}
			return t;
		},
		scope: r
	};
}
var J = eo.define, lo = J(), uo = J(), fo = J(uo), po = J(uo), mo = J(), ho = J(mo), go = J(mo), _o = J(), vo = J(_o), yo = J(), bo = J(), xo = J(), So = J(xo), Co = J(), Y = {
	comment: lo,
	lineComment: J(lo),
	blockComment: J(lo),
	docComment: J(lo),
	name: uo,
	variableName: J(uo),
	typeName: fo,
	tagName: J(fo),
	propertyName: po,
	attributeName: J(po),
	className: J(uo),
	labelName: J(uo),
	namespace: J(uo),
	macroName: J(uo),
	literal: mo,
	string: ho,
	docString: J(ho),
	character: J(ho),
	attributeValue: J(ho),
	number: go,
	integer: J(go),
	float: J(go),
	bool: J(mo),
	regexp: J(mo),
	escape: J(mo),
	color: J(mo),
	url: J(mo),
	keyword: yo,
	self: J(yo),
	null: J(yo),
	atom: J(yo),
	unit: J(yo),
	modifier: J(yo),
	operatorKeyword: J(yo),
	controlKeyword: J(yo),
	definitionKeyword: J(yo),
	moduleKeyword: J(yo),
	operator: bo,
	derefOperator: J(bo),
	arithmeticOperator: J(bo),
	logicOperator: J(bo),
	bitwiseOperator: J(bo),
	compareOperator: J(bo),
	updateOperator: J(bo),
	definitionOperator: J(bo),
	typeOperator: J(bo),
	controlOperator: J(bo),
	punctuation: xo,
	separator: J(xo),
	bracket: So,
	angleBracket: J(So),
	squareBracket: J(So),
	paren: J(So),
	brace: J(So),
	content: _o,
	heading: vo,
	heading1: J(vo),
	heading2: J(vo),
	heading3: J(vo),
	heading4: J(vo),
	heading5: J(vo),
	heading6: J(vo),
	contentSeparator: J(_o),
	list: J(_o),
	quote: J(_o),
	emphasis: J(_o),
	strong: J(_o),
	link: J(_o),
	monospace: J(_o),
	strikethrough: J(_o),
	inserted: J(),
	deleted: J(),
	changed: J(),
	invalid: J(),
	meta: Co,
	documentMeta: J(Co),
	annotation: J(Co),
	processingInstruction: J(Co),
	definition: eo.defineModifier("definition"),
	constant: eo.defineModifier("constant"),
	function: eo.defineModifier("function"),
	standard: eo.defineModifier("standard"),
	local: eo.defineModifier("local"),
	special: eo.defineModifier("special")
};
for (let e in Y) {
	let t = Y[e];
	t instanceof eo && (t.name = e);
}
co([
	{
		tag: Y.link,
		class: "tok-link"
	},
	{
		tag: Y.heading,
		class: "tok-heading"
	},
	{
		tag: Y.emphasis,
		class: "tok-emphasis"
	},
	{
		tag: Y.strong,
		class: "tok-strong"
	},
	{
		tag: Y.keyword,
		class: "tok-keyword"
	},
	{
		tag: Y.atom,
		class: "tok-atom"
	},
	{
		tag: Y.bool,
		class: "tok-bool"
	},
	{
		tag: Y.url,
		class: "tok-url"
	},
	{
		tag: Y.labelName,
		class: "tok-labelName"
	},
	{
		tag: Y.inserted,
		class: "tok-inserted"
	},
	{
		tag: Y.deleted,
		class: "tok-deleted"
	},
	{
		tag: Y.literal,
		class: "tok-literal"
	},
	{
		tag: Y.string,
		class: "tok-string"
	},
	{
		tag: Y.number,
		class: "tok-number"
	},
	{
		tag: [
			Y.regexp,
			Y.escape,
			Y.special(Y.string)
		],
		class: "tok-string2"
	},
	{
		tag: Y.variableName,
		class: "tok-variableName"
	},
	{
		tag: Y.local(Y.variableName),
		class: "tok-variableName tok-local"
	},
	{
		tag: Y.definition(Y.variableName),
		class: "tok-variableName tok-definition"
	},
	{
		tag: Y.special(Y.variableName),
		class: "tok-variableName2"
	},
	{
		tag: Y.definition(Y.propertyName),
		class: "tok-propertyName tok-definition"
	},
	{
		tag: Y.typeName,
		class: "tok-typeName"
	},
	{
		tag: Y.namespace,
		class: "tok-namespace"
	},
	{
		tag: Y.className,
		class: "tok-className"
	},
	{
		tag: Y.macroName,
		class: "tok-macroName"
	},
	{
		tag: Y.propertyName,
		class: "tok-propertyName"
	},
	{
		tag: Y.operator,
		class: "tok-operator"
	},
	{
		tag: Y.comment,
		class: "tok-comment"
	},
	{
		tag: Y.meta,
		class: "tok-meta"
	},
	{
		tag: Y.invalid,
		class: "tok-invalid"
	},
	{
		tag: Y.punctuation,
		class: "tok-punctuation"
	}
]);
// node_modules/@lezer/markdown/dist/index.js
var wo = class e {
	static create(t, n, r, i, a) {
		let o = i + (i << 8) + t + (n << 4) | 0;
		return new e(t, n, r, o, a, [], []);
	}
	constructor(e, t, n, r, i, a, o) {
		this.type = e, this.value = t, this.from = n, this.hash = r, this.end = i, this.children = a, this.positions = o, this.blankFirstLine = !1, this.hashProp = [[W.contextHash, r]];
	}
	addChild(e, t) {
		e.prop(W.contextHash) != this.hash && (e = new q(e.type, e.children, e.positions, e.length, this.hashProp)), this.children.push(e), this.positions.push(t);
	}
	toTree(e, t = this.end) {
		let n = this.children.length - 1;
		return n >= 0 && (t = Math.max(t, this.positions[n] + this.children[n].length + this.from)), new q(e.types[this.type], this.children, this.positions, t - this.from).balance({ makeTree: (e, t, n) => new q(G.none, e, t, n, this.hashProp) });
	}
}, X;
(function(e) {
	e[e.Document = 1] = "Document", e[e.CodeBlock = 2] = "CodeBlock", e[e.FencedCode = 3] = "FencedCode", e[e.Blockquote = 4] = "Blockquote", e[e.HorizontalRule = 5] = "HorizontalRule", e[e.BulletList = 6] = "BulletList", e[e.OrderedList = 7] = "OrderedList", e[e.ListItem = 8] = "ListItem", e[e.ATXHeading1 = 9] = "ATXHeading1", e[e.ATXHeading2 = 10] = "ATXHeading2", e[e.ATXHeading3 = 11] = "ATXHeading3", e[e.ATXHeading4 = 12] = "ATXHeading4", e[e.ATXHeading5 = 13] = "ATXHeading5", e[e.ATXHeading6 = 14] = "ATXHeading6", e[e.SetextHeading1 = 15] = "SetextHeading1", e[e.SetextHeading2 = 16] = "SetextHeading2", e[e.HTMLBlock = 17] = "HTMLBlock", e[e.LinkReference = 18] = "LinkReference", e[e.Paragraph = 19] = "Paragraph", e[e.CommentBlock = 20] = "CommentBlock", e[e.ProcessingInstructionBlock = 21] = "ProcessingInstructionBlock", e[e.Escape = 22] = "Escape", e[e.Entity = 23] = "Entity", e[e.HardBreak = 24] = "HardBreak", e[e.Emphasis = 25] = "Emphasis", e[e.StrongEmphasis = 26] = "StrongEmphasis", e[e.Link = 27] = "Link", e[e.Image = 28] = "Image", e[e.InlineCode = 29] = "InlineCode", e[e.HTMLTag = 30] = "HTMLTag", e[e.Comment = 31] = "Comment", e[e.ProcessingInstruction = 32] = "ProcessingInstruction", e[e.Autolink = 33] = "Autolink", e[e.HeaderMark = 34] = "HeaderMark", e[e.QuoteMark = 35] = "QuoteMark", e[e.ListMark = 36] = "ListMark", e[e.LinkMark = 37] = "LinkMark", e[e.EmphasisMark = 38] = "EmphasisMark", e[e.CodeMark = 39] = "CodeMark", e[e.CodeText = 40] = "CodeText", e[e.CodeInfo = 41] = "CodeInfo", e[e.LinkTitle = 42] = "LinkTitle", e[e.LinkLabel = 43] = "LinkLabel", e[e.URL = 44] = "URL";
})(X ||= {});
var To = class {
	constructor(e, t) {
		this.start = e, this.content = t, this.marks = [], this.parsers = [];
	}
}, Eo = class {
	constructor() {
		this.text = "", this.baseIndent = 0, this.basePos = 0, this.depth = 0, this.markers = [], this.pos = 0, this.indent = 0, this.next = -1;
	}
	forward() {
		this.basePos > this.pos && this.forwardInner();
	}
	forwardInner() {
		let e = this.skipSpace(this.basePos);
		this.indent = this.countIndent(e, this.pos, this.indent), this.pos = e, this.next = e == this.text.length ? -1 : this.text.charCodeAt(e);
	}
	skipSpace(e) {
		return ko(this.text, e);
	}
	reset(e) {
		for (this.text = e, this.baseIndent = this.basePos = this.pos = this.indent = 0, this.forwardInner(), this.depth = 1; this.markers.length;) this.markers.pop();
	}
	moveBase(e) {
		this.basePos = e, this.baseIndent = this.countIndent(e, this.pos, this.indent);
	}
	moveBaseColumn(e) {
		this.baseIndent = e, this.basePos = this.findColumn(e);
	}
	addMarker(e) {
		this.markers.push(e);
	}
	countIndent(e, t = 0, n = 0) {
		for (let r = t; r < e; r++) n += this.text.charCodeAt(r) == 9 ? 4 - n % 4 : 1;
		return n;
	}
	findColumn(e) {
		let t = 0;
		for (let n = 0; t < this.text.length && n < e; t++) n += this.text.charCodeAt(t) == 9 ? 4 - n % 4 : 1;
		return t;
	}
	scrub() {
		if (!this.baseIndent) return this.text;
		let e = "";
		for (let t = 0; t < this.basePos; t++) e += " ";
		return e + this.text.slice(this.basePos);
	}
};
function Do(e, t, n) {
	if (n.pos == n.text.length || e != t.block && n.indent >= t.stack[n.depth + 1].value + n.baseIndent) return !0;
	if (n.indent >= n.baseIndent + 4) return !1;
	let r = (e.type == X.OrderedList ? Io : Fo)(n, t, !1);
	return r > 0 && (e.type != X.BulletList || No(n, t, !1) < 0) && n.text.charCodeAt(n.pos + r - 1) == e.value;
}
var Oo = {
	[X.Blockquote](e, t, n) {
		return n.next == 62 && (n.markers.push(Q(X.QuoteMark, t.lineStart + n.pos, t.lineStart + n.pos + 1)), n.moveBase(n.pos + (Z(n.text.charCodeAt(n.pos + 1)) ? 2 : 1)), e.end = t.lineStart + n.text.length, !0);
	},
	[X.ListItem](e, t, n) {
		return !(n.next < 0 ? e.blankFirstLine && e.children.length == 1 : n.indent < n.baseIndent + e.value) && (n.moveBaseColumn(n.baseIndent + e.value), !0);
	},
	[X.OrderedList]: Do,
	[X.BulletList]: Do,
	[X.Document]() {
		return !0;
	}
};
function Z(e) {
	return e == 32 || e == 9 || e == 10 || e == 13;
}
function ko(e, t = 0) {
	for (; t < e.length && Z(e.charCodeAt(t));) t++;
	return t;
}
function Ao(e, t, n) {
	for (; t > n && Z(e.charCodeAt(t - 1));) t--;
	return t;
}
function jo(e) {
	if (e.next != 96 && e.next != 126) return -1;
	let t = e.pos + 1;
	for (; t < e.text.length && e.text.charCodeAt(t) == e.next;) t++;
	if (t < e.pos + 3) return -1;
	if (e.next == 96) {
		for (let n = t; n < e.text.length; n++) if (e.text.charCodeAt(n) == 96) return -1;
	}
	return t;
}
function Mo(e) {
	return e.next == 62 ? e.text.charCodeAt(e.pos + 1) == 32 ? 2 : 1 : -1;
}
function No(e, t, n) {
	if (e.next != 42 && e.next != 45 && e.next != 95) return -1;
	let r = 1;
	for (let t = e.pos + 1; t < e.text.length; t++) {
		let n = e.text.charCodeAt(t);
		if (n == e.next) r++;
		else if (!Z(n)) return -1;
	}
	return n && e.next == 45 && Ro(e) > -1 && e.depth == t.stack.length && t.parser.leafBlockParsers.indexOf(Xo.SetextHeading) > -1 || r < 3 ? -1 : 1;
}
function Po(e, t) {
	for (let n = e.stack.length - 1; n >= 0; n--) if (e.stack[n].type == t) return !0;
	return !1;
}
function Fo(e, t, n) {
	return (e.next == 45 || e.next == 43 || e.next == 42) && (e.pos == e.text.length - 1 || Z(e.text.charCodeAt(e.pos + 1))) && (!n || Po(t, X.BulletList) || e.skipSpace(e.pos + 2) < e.text.length) ? 1 : -1;
}
function Io(e, t, n) {
	let r = e.pos, i = e.next;
	for (; i >= 48 && i <= 57;) {
		if (r++, r == e.text.length) return -1;
		i = e.text.charCodeAt(r);
	}
	return r == e.pos || r > e.pos + 9 || i != 46 && i != 41 || r < e.text.length - 1 && !Z(e.text.charCodeAt(r + 1)) || n && !Po(t, X.OrderedList) && (e.skipSpace(r + 1) == e.text.length || r > e.pos + 1 || e.next != 49) ? -1 : r + 1 - e.pos;
}
function Lo(e) {
	if (e.next != 35) return -1;
	let t = e.pos + 1;
	for (; t < e.text.length && e.text.charCodeAt(t) == 35;) t++;
	if (t < e.text.length && !Z(e.text.charCodeAt(t))) return -1;
	let n = t - e.pos;
	return n > 6 ? -1 : n;
}
function Ro(e) {
	if (e.next != 45 && e.next != 61 || e.indent >= e.baseIndent + 4) return -1;
	let t = e.pos + 1;
	for (; t < e.text.length && e.text.charCodeAt(t) == e.next;) t++;
	let n = t;
	for (; t < e.text.length && Z(e.text.charCodeAt(t));) t++;
	return t == e.text.length ? n : -1;
}
var zo = /^[ \t]*$/, Bo = /-->/, Vo = /\?>/, Ho = [
	[/^<(?:script|pre|style|textarea)(?:\s|>|$)/i, /<\/(?:script|pre|style|textarea)>/i],
	[/^\s*<!--/, Bo],
	[/^\s*<\?/, Vo],
	[/^\s*<![A-Z]/, />/],
	[/^\s*<!\[CDATA\[/, /\]\]>/],
	[/^\s*<\/?(?:address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h1|h2|h3|h4|h5|h6|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul)(?:\s|\/?>|$)/i, zo],
	[/^\s*(?:<\/[a-z][\w-]*\s*>|<[a-z][\w-]*(\s+[a-z:_][\w-.]*(?:\s*=\s*(?:[^\s"'=<>`]+|'[^']*'|"[^"]*"))?)*\s*>)\s*$/i, zo]
];
function Uo(e, t, n) {
	if (e.next != 60) return -1;
	let r = e.text.slice(e.pos);
	for (let e = 0, t = Ho.length - +!!n; e < t; e++) if (Ho[e][0].test(r)) return e;
	return -1;
}
function Wo(e, t) {
	let n = e.countIndent(t, e.pos, e.indent), r = e.skipSpace(t), i = e.countIndent(r, t, n);
	return i >= n + 5 || r == e.text.length ? n + 1 : i;
}
function Go(e, t, n) {
	let r = e.length - 1;
	r >= 0 && e[r].to == t && e[r].type == X.CodeText ? e[r].to = n : e.push(Q(X.CodeText, t, n));
}
var Ko = {
	LinkReference: void 0,
	IndentedCode(e, t) {
		let n = t.baseIndent + 4;
		if (t.indent < n) return !1;
		let r = t.findColumn(n), i = e.lineStart + r, a = e.lineStart + t.text.length, o = [], s = [];
		for (Go(o, i, a); e.nextLine() && t.depth >= e.stack.length;) if (t.pos == t.text.length) {
			Go(s, e.lineStart - 1, e.lineStart);
			for (let e of t.markers) s.push(e);
		} else if (t.indent < n) break;
		else {
			if (s.length) {
				for (let e of s) e.type == X.CodeText ? Go(o, e.from, e.to) : o.push(e);
				s = [];
			}
			Go(o, e.lineStart - 1, e.lineStart);
			for (let e of t.markers) o.push(e);
			a = e.lineStart + t.text.length;
			let n = e.lineStart + t.findColumn(t.baseIndent + 4);
			n < a && Go(o, n, a);
		}
		return s.length && (s = s.filter((e) => e.type != X.CodeText), s.length && (t.markers = s.concat(t.markers))), e.addNode(e.buffer.writeElements(o, -i).finish(X.CodeBlock, a - i), i), !0;
	},
	FencedCode(e, t) {
		let n = jo(t);
		if (n < 0) return !1;
		let r = e.lineStart + t.pos, i = t.next, a = n - t.pos, o = t.skipSpace(n), s = Ao(t.text, t.text.length, o), c = [Q(X.CodeMark, r, r + a)];
		o < s && c.push(Q(X.CodeInfo, e.lineStart + o, e.lineStart + s));
		for (let n = !0, r = !0, o = !1; e.nextLine() && t.depth >= e.stack.length; n = !1) {
			let s = t.pos;
			if (t.indent - t.baseIndent < 4) for (; s < t.text.length && t.text.charCodeAt(s) == i;) s++;
			if (s - t.pos >= a && t.skipSpace(s) == t.text.length) {
				for (let e of t.markers) c.push(e);
				r && o && Go(c, e.lineStart - 1, e.lineStart), c.push(Q(X.CodeMark, e.lineStart + t.pos, e.lineStart + s)), e.nextLine();
				break;
			}
			{
				o = !0, n || (Go(c, e.lineStart - 1, e.lineStart), r = !1);
				for (let e of t.markers) c.push(e);
				let i = e.lineStart + t.basePos, a = e.lineStart + t.text.length;
				i < a && (Go(c, i, a), r = !1);
			}
		}
		return e.addNode(e.buffer.writeElements(c, -r).finish(X.FencedCode, e.prevLineEnd() - r), r), !0;
	},
	Blockquote(e, t) {
		let n = Mo(t);
		return n < 0 ? !1 : (e.startContext(X.Blockquote, t.pos), e.addNode(X.QuoteMark, e.lineStart + t.pos, e.lineStart + t.pos + 1), t.moveBase(t.pos + n), null);
	},
	HorizontalRule(e, t) {
		if (No(t, e, !1) < 0) return !1;
		let n = e.lineStart + t.pos;
		return e.nextLine(), e.addNode(X.HorizontalRule, n), !0;
	},
	BulletList(e, t) {
		let n = Fo(t, e, !1);
		if (n < 0) return !1;
		e.block.type != X.BulletList && e.startContext(X.BulletList, t.basePos, t.next);
		let r = Wo(t, t.pos + 1);
		return e.startContext(X.ListItem, t.basePos, r - t.baseIndent), e.addNode(X.ListMark, e.lineStart + t.pos, e.lineStart + t.pos + n), t.moveBaseColumn(r), e.block.blankFirstLine = r >= t.text.length, null;
	},
	OrderedList(e, t) {
		let n = Io(t, e, !1);
		if (n < 0) return !1;
		e.block.type != X.OrderedList && e.startContext(X.OrderedList, t.basePos, t.text.charCodeAt(t.pos + n - 1));
		let r = Wo(t, t.pos + n);
		return e.startContext(X.ListItem, t.basePos, r - t.baseIndent), e.addNode(X.ListMark, e.lineStart + t.pos, e.lineStart + t.pos + n), t.moveBaseColumn(r), e.block.blankFirstLine = r == t.text.length, null;
	},
	ATXHeading(e, t) {
		let n = Lo(t);
		if (n < 0) return !1;
		let r = t.pos, i = e.lineStart + r, a = Ao(t.text, t.text.length, r), o = a;
		for (; o > r && t.text.charCodeAt(o - 1) == t.next;) o--;
		o != a && o != r && Z(t.text.charCodeAt(o - 1)) || (o = t.text.length);
		let s = e.buffer.write(X.HeaderMark, 0, n).writeElements(e.parser.parseInline(t.text.slice(r + n + 1, o), i + n + 1), -i);
		o < t.text.length && s.write(X.HeaderMark, o - r, a - r);
		let c = s.finish(X.ATXHeading1 - 1 + n, t.text.length - r);
		return e.nextLine(), e.addNode(c, i), !0;
	},
	HTMLBlock(e, t) {
		let n = Uo(t, e, !1);
		if (n < 0) return !1;
		let r = e.lineStart + t.pos, i = Ho[n][1], a = [], o = i != zo;
		for (; !i.test(t.text) && e.nextLine();) {
			if (t.depth < e.stack.length) {
				o = !1;
				break;
			}
			for (let e of t.markers) a.push(e);
		}
		o && e.nextLine();
		let s = i == Bo ? X.CommentBlock : i == Vo ? X.ProcessingInstructionBlock : X.HTMLBlock, c = e.prevLineEnd();
		return e.addNode(e.buffer.writeElements(a, -r).finish(s, c - r), r), !0;
	},
	SetextHeading: void 0
}, qo = class {
	constructor(e) {
		this.stage = 0, this.elts = [], this.pos = 0, this.start = e.start, this.advance(e.content);
	}
	nextLine(e, t, n) {
		if (this.stage == -1) return !1;
		let r = n.content + "\n" + t.scrub(), i = this.advance(r);
		return i > -1 && i < r.length && this.complete(e, n, i);
	}
	finish(e, t) {
		return (this.stage == 2 || this.stage == 3) && ko(t.content, this.pos) == t.content.length && this.complete(e, t, t.content.length);
	}
	complete(e, t, n) {
		return e.addLeafElement(t, Q(X.LinkReference, this.start, this.start + n, this.elts)), !0;
	}
	nextStage(e) {
		return e ? (this.pos = e.to - this.start, this.elts.push(e), this.stage++, !0) : (e === !1 && (this.stage = -1), !1);
	}
	advance(e) {
		for (;;) if (this.stage == -1) return -1;
		else if (this.stage == 0) {
			if (!this.nextStage(bs(e, this.pos, this.start, !0))) return -1;
			if (e.charCodeAt(this.pos) != 58) return this.stage = -1;
			this.elts.push(Q(X.LinkMark, this.pos + this.start, this.pos + this.start + 1)), this.pos++;
		} else if (this.stage == 1) {
			if (!this.nextStage(vs(e, ko(e, this.pos), this.start))) return -1;
		} else if (this.stage == 2) {
			let t = ko(e, this.pos), n = 0;
			if (t > this.pos) {
				let r = ys(e, t, this.start);
				if (r) {
					let t = Jo(e, r.to - this.start);
					t > 0 && (this.nextStage(r), n = t);
				}
			}
			return n ||= Jo(e, this.pos), n > 0 && n < e.length ? n : -1;
		} else return Jo(e, this.pos);
	}
};
function Jo(e, t) {
	for (; t < e.length; t++) {
		let n = e.charCodeAt(t);
		if (n == 10) break;
		if (!Z(n)) return -1;
	}
	return t;
}
var Yo = class {
	nextLine(e, t, n) {
		let r = t.depth < e.stack.length ? -1 : Ro(t), i = t.next;
		if (r < 0) return !1;
		let a = Q(X.HeaderMark, e.lineStart + t.pos, e.lineStart + r);
		return e.nextLine(), e.addLeafElement(n, Q(i == 61 ? X.SetextHeading1 : X.SetextHeading2, n.start, e.prevLineEnd(), [...e.parser.parseInline(n.content, n.start), a])), !0;
	}
	finish() {
		return !1;
	}
}, Xo = {
	LinkReference(e, t) {
		return t.content.charCodeAt(0) == 91 ? new qo(t) : null;
	},
	SetextHeading() {
		return new Yo();
	}
}, Zo = [
	(e, t) => Lo(t) >= 0,
	(e, t) => jo(t) >= 0,
	(e, t) => Mo(t) >= 0,
	(e, t) => Fo(t, e, !0) >= 0,
	(e, t) => Io(t, e, !0) >= 0,
	(e, t) => No(t, e, !0) >= 0,
	(e, t) => Uo(t, e, !0) >= 0
], Qo = {
	text: "",
	end: 0
}, $o = class {
	constructor(e, t, n, r) {
		this.parser = e, this.input = t, this.ranges = r, this.line = new Eo(), this.atEnd = !1, this.reusePlaceholders = /* @__PURE__ */ new Map(), this.stoppedAt = null, this.rangeI = 0, this.to = r[r.length - 1].to, this.lineStart = this.absoluteLineStart = this.absoluteLineEnd = r[0].from, this.block = wo.create(X.Document, 0, this.lineStart, 0, 0), this.stack = [this.block], this.fragments = n.length ? new ws(n, t) : null, this.readLine();
	}
	get parsedPos() {
		return this.absoluteLineStart;
	}
	advance() {
		if (this.stoppedAt != null && this.absoluteLineStart > this.stoppedAt) return this.finish();
		let { line: e } = this;
		for (;;) {
			for (let t = 0;;) {
				let n = e.depth < this.stack.length ? this.stack[this.stack.length - 1] : null;
				for (; t < e.markers.length && (!n || e.markers[t].from < n.end);) {
					let n = e.markers[t++];
					this.addNode(n.type, n.from, n.to);
				}
				if (!n) break;
				this.finishContext();
			}
			if (e.pos < e.text.length) break;
			if (!this.nextLine()) return this.finish();
		}
		if (this.fragments && this.reuseFragment(e.basePos)) return null;
		start: for (;;) {
			for (let t of this.parser.blockParsers) if (t) {
				let n = t(this, e);
				if (n != 0) {
					if (n == 1) return null;
					e.forward();
					continue start;
				}
			}
			break;
		}
		if (e.pos == e.text.length) return this.nextLine() ? null : this.finish();
		let t = new To(this.lineStart + e.pos, e.text.slice(e.pos));
		for (let e of this.parser.leafBlockParsers) if (e) {
			let n = e(this, t);
			n && t.parsers.push(n);
		}
		lines: for (; this.nextLine() && e.pos != e.text.length;) {
			if (e.indent < e.baseIndent + 4) {
				for (let n of this.parser.endLeafBlock) if (n(this, e, t)) break lines;
			}
			for (let n of t.parsers) if (n.nextLine(this, e, t)) return null;
			t.content += "\n" + e.scrub();
			for (let n of e.markers) t.marks.push(n);
		}
		return this.finishLeaf(t), null;
	}
	stopAt(e) {
		if (this.stoppedAt != null && this.stoppedAt < e) throw RangeError("Can't move stoppedAt forward");
		this.stoppedAt = e;
	}
	reuseFragment(e) {
		if (!this.fragments.moveTo(this.absoluteLineStart + e, this.absoluteLineStart) || !this.fragments.matches(this.block.hash)) return !1;
		let t = this.fragments.takeNodes(this);
		return t ? (this.absoluteLineStart += t, this.lineStart = Es(this.absoluteLineStart, this.ranges), this.moveRangeI(), this.absoluteLineStart < this.to ? (this.lineStart++, this.absoluteLineStart++, this.readLine()) : (this.atEnd = !0, this.readLine()), !0) : !1;
	}
	get depth() {
		return this.stack.length;
	}
	parentType(e = this.depth - 1) {
		return this.parser.nodeSet.types[this.stack[e].type];
	}
	nextLine() {
		return this.lineStart += this.line.text.length, this.absoluteLineEnd >= this.to ? (this.absoluteLineStart = this.absoluteLineEnd, this.atEnd = !0, this.readLine(), !1) : (this.lineStart++, this.absoluteLineStart = this.absoluteLineEnd + 1, this.moveRangeI(), this.readLine(), !0);
	}
	peekLine() {
		return this.scanLine(this.absoluteLineEnd + 1).text;
	}
	moveRangeI() {
		for (; this.rangeI < this.ranges.length - 1 && this.absoluteLineStart >= this.ranges[this.rangeI].to;) this.rangeI++, this.absoluteLineStart = Math.max(this.absoluteLineStart, this.ranges[this.rangeI].from);
	}
	scanLine(e) {
		let t = Qo;
		if (t.end = e, e >= this.to) t.text = "";
		else if (t.text = this.lineChunkAt(e), t.end += t.text.length, this.ranges.length > 1) {
			let e = this.absoluteLineStart, n = this.rangeI;
			for (; this.ranges[n].to < t.end;) {
				n++;
				let r = this.ranges[n].from, i = this.lineChunkAt(r);
				t.end = r + i.length, t.text = t.text.slice(0, this.ranges[n - 1].to - e) + i, e = t.end - t.text.length;
			}
		}
		return t;
	}
	readLine() {
		let { line: e } = this, { text: t, end: n } = this.scanLine(this.absoluteLineStart);
		for (this.absoluteLineEnd = n, e.reset(t); e.depth < this.stack.length; e.depth++) {
			let t = this.stack[e.depth], n = this.parser.skipContextMarkup[t.type];
			if (!n) throw Error("Unhandled block context " + X[t.type]);
			let r = this.line.markers.length;
			if (!n(t, this, e)) {
				this.line.markers.length > r && (t.end = this.line.markers[this.line.markers.length - 1].to), e.forward();
				break;
			}
			e.forward();
		}
	}
	lineChunkAt(e) {
		let t = this.input.chunk(e), n;
		if (this.input.lineChunks) n = t == "\n" ? "" : t;
		else {
			let e = t.indexOf("\n");
			n = e < 0 ? t : t.slice(0, e);
		}
		return e + n.length > this.to ? n.slice(0, this.to - e) : n;
	}
	prevLineEnd() {
		return this.atEnd ? this.lineStart : this.lineStart - 1;
	}
	startContext(e, t, n = 0) {
		this.block = wo.create(e, n, this.lineStart + t, this.block.hash, this.lineStart + this.line.text.length), this.stack.push(this.block);
	}
	startComposite(e, t, n = 0) {
		this.startContext(this.parser.getNodeType(e), t, n);
	}
	addNode(e, t, n) {
		typeof e == "number" && (e = new q(this.parser.nodeSet.types[e], os, os, (n ?? this.prevLineEnd()) - t)), this.block.addChild(e, t - this.block.from);
	}
	addElement(e) {
		this.block.addChild(e.toTree(this.parser.nodeSet), e.from - this.block.from);
	}
	addLeafElement(e, t) {
		this.addNode(this.buffer.writeElements(Ss(t.children, e.marks), -t.from).finish(t.type, t.to - t.from), t.from);
	}
	finishContext() {
		let e = this.stack.pop(), t = this.stack[this.stack.length - 1];
		t.addChild(e.toTree(this.parser.nodeSet), e.from - t.from), this.block = t;
	}
	finish() {
		for (; this.stack.length > 1;) this.finishContext();
		return this.addGaps(this.block.toTree(this.parser.nodeSet, this.lineStart));
	}
	addGaps(e) {
		return this.ranges.length > 1 ? es(this.ranges, 0, e.topNode, this.ranges[0].from, this.reusePlaceholders) : e;
	}
	finishLeaf(e) {
		for (let t of e.parsers) if (t.finish(this, e)) return;
		let t = Ss(this.parser.parseInline(e.content, e.start), e.marks);
		this.addNode(this.buffer.writeElements(t, -e.start).finish(X.Paragraph, e.content.length), e.start);
	}
	elt(e, t, n, r) {
		return typeof e == "string" ? Q(this.parser.getNodeType(e), t, n, r) : new ls(e, t);
	}
	get buffer() {
		return new ss(this.parser.nodeSet);
	}
};
function es(e, t, n, r, i) {
	let a = e[t].to, o = [], s = [], c = n.from + r;
	function l(n, i) {
		for (; i ? n >= a : n > a;) {
			let i = e[t + 1].from - a;
			r += i, n += i, t++, a = e[t].to;
		}
	}
	for (let u = n.firstChild; u; u = u.nextSibling) {
		l(u.from + r, !0);
		let n = u.from + r, d, f = i.get(u.tree);
		f ? d = f : u.to + r > a ? (d = es(e, t, u, r, i), l(u.to + r, !1)) : d = u.toTree(), o.push(d), s.push(n - c);
	}
	return l(n.to + r, !1), new q(n.type, o, s, n.to + r - c, n.tree ? n.tree.propValues : void 0);
}
var ts = class e extends Za {
	constructor(e, t, n, r, i, a, o, s, c) {
		super(), this.nodeSet = e, this.blockParsers = t, this.leafBlockParsers = n, this.blockNames = r, this.endLeafBlock = i, this.skipContextMarkup = a, this.inlineParsers = o, this.inlineNames = s, this.wrappers = c, this.nodeTypes = Object.create(null);
		for (let t of e.types) this.nodeTypes[t.name] = t.id;
	}
	createParse(e, t, n) {
		let r = new $o(this, e, t, n);
		for (let i of this.wrappers) r = i(r, e, t, n);
		return r;
	}
	configure(t) {
		let n = rs(t);
		if (!n) return this;
		let { nodeSet: r, skipContextMarkup: i } = this, a = this.blockParsers.slice(), o = this.leafBlockParsers.slice(), s = this.blockNames.slice(), c = this.inlineParsers.slice(), l = this.inlineNames.slice(), u = this.endLeafBlock.slice(), d = this.wrappers;
		if (ns(n.defineNodes)) {
			i = Object.assign({}, i);
			let e = r.types.slice(), t;
			for (let r of n.defineNodes) {
				let { name: n, block: a, composite: o, style: s } = typeof r == "string" ? { name: r } : r;
				if (e.some((e) => e.name == n)) continue;
				o && (i[e.length] = (e, t, n) => o(t, n, e.value));
				let c = e.length, l = o ? ["Block", "BlockContext"] : a ? c >= X.ATXHeading1 && c <= X.SetextHeading2 ? [
					"Block",
					"LeafBlock",
					"Heading"
				] : ["Block", "LeafBlock"] : void 0;
				e.push(G.define({
					id: c,
					name: n,
					props: l && [[W.group, l]]
				})), s && (t ||= {}, Array.isArray(s) || s instanceof eo ? t[n] = s : Object.assign(t, s));
			}
			r = new Oa(e), t && (r = r.extend(ao(t)));
		}
		if (ns(n.props) && (r = r.extend(...n.props)), ns(n.remove)) for (let e of n.remove) {
			let t = this.blockNames.indexOf(e), n = this.inlineNames.indexOf(e);
			t > -1 && (a[t] = o[t] = void 0), n > -1 && (c[n] = void 0);
		}
		if (ns(n.parseBlock)) for (let e of n.parseBlock) {
			let t = s.indexOf(e.name);
			if (t > -1) a[t] = e.parse, o[t] = e.leaf;
			else {
				let t = e.before ? is(s, e.before) : e.after ? is(s, e.after) + 1 : s.length - 1;
				a.splice(t, 0, e.parse), o.splice(t, 0, e.leaf), s.splice(t, 0, e.name);
			}
			e.endLeaf && u.push(e.endLeaf);
		}
		if (ns(n.parseInline)) for (let e of n.parseInline) {
			let t = l.indexOf(e.name);
			if (t > -1) c[t] = e.parse;
			else {
				let t = e.before ? is(l, e.before) : e.after ? is(l, e.after) + 1 : l.length - 1;
				c.splice(t, 0, e.parse), l.splice(t, 0, e.name);
			}
		}
		return n.wrap && (d = d.concat(n.wrap)), new e(r, a, o, s, u, i, c, l, d);
	}
	getNodeType(e) {
		let t = this.nodeTypes[e];
		if (t == null) throw RangeError(`Unknown node type '${e}'`);
		return t;
	}
	parseInline(e, t) {
		let n = new xs(this, e, t);
		outer: for (let e = t; e < n.end;) {
			let t = n.char(e);
			for (let r of this.inlineParsers) if (r) {
				let i = r(n, t, e);
				if (i >= 0) {
					e = i;
					continue outer;
				}
			}
			e++;
		}
		return n.resolveMarkers(0);
	}
};
function ns(e) {
	return e != null && e.length > 0;
}
function rs(e) {
	if (!Array.isArray(e)) return e;
	if (e.length == 0) return null;
	let t = rs(e[0]);
	if (e.length == 1) return t;
	let n = rs(e.slice(1));
	if (!n || !t) return t || n;
	let r = (e, t) => (e || os).concat(t || os), i = t.wrap, a = n.wrap;
	return {
		props: r(t.props, n.props),
		defineNodes: r(t.defineNodes, n.defineNodes),
		parseBlock: r(t.parseBlock, n.parseBlock),
		parseInline: r(t.parseInline, n.parseInline),
		remove: r(t.remove, n.remove),
		wrap: i ? a ? (e, t, n, r) => i(a(e, t, n, r), t, n, r) : i : a
	};
}
function is(e, t) {
	let n = e.indexOf(t);
	if (n < 0) throw RangeError(`Position specified relative to unknown parser ${t}`);
	return n;
}
var as = [G.none];
for (let e = 1, t; t = X[e]; e++) as[e] = G.define({
	id: e,
	name: t,
	props: e >= X.Escape ? [] : [[W.group, e in Oo ? ["Block", "BlockContext"] : ["Block", "LeafBlock"]]],
	top: t == "Document"
});
var os = [], ss = class {
	constructor(e) {
		this.nodeSet = e, this.content = [], this.nodes = [];
	}
	write(e, t, n, r = 0) {
		return this.content.push(e, t, n, 4 + r * 4), this;
	}
	writeElements(e, t = 0) {
		for (let n of e) n.writeTo(this, t);
		return this;
	}
	finish(e, t) {
		return q.build({
			buffer: this.content,
			nodeSet: this.nodeSet,
			reused: this.nodes,
			topID: e,
			length: t
		});
	}
}, cs = class {
	constructor(e, t, n, r = os) {
		this.type = e, this.from = t, this.to = n, this.children = r;
	}
	writeTo(e, t) {
		let n = e.content.length;
		e.writeElements(this.children, t), e.content.push(this.type, this.from + t, this.to + t, e.content.length + 4 - n);
	}
	toTree(e) {
		return new ss(e).writeElements(this.children, -this.from).finish(this.type, this.to - this.from);
	}
}, ls = class {
	constructor(e, t) {
		this.tree = e, this.from = t;
	}
	get to() {
		return this.from + this.tree.length;
	}
	get type() {
		return this.tree.type.id;
	}
	get children() {
		return os;
	}
	writeTo(e, t) {
		e.nodes.push(this.tree), e.content.push(e.nodes.length - 1, this.from + t, this.to + t, -1);
	}
	toTree() {
		return this.tree;
	}
};
function Q(e, t, n, r) {
	return new cs(e, t, n, r);
}
var us = {
	resolve: "Emphasis",
	mark: "EmphasisMark"
}, ds = {
	resolve: "Emphasis",
	mark: "EmphasisMark"
}, fs = {}, ps = {}, $ = class {
	constructor(e, t, n, r, i = n - t) {
		this.type = e, this.from = t, this.to = n, this.side = r, this.size = i;
	}
}, ms = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~", hs = /[!"#$%&'()*+,\-.\/:;<=>?@\[\\\]^_`{|}~\xA1\u2010-\u2027]/;
try {
	hs = /* @__PURE__ */ RegExp("[\\p{S}|\\p{P}]", "u");
} catch {}
var gs = {
	Escape(e, t, n) {
		if (t != 92 || n == e.end - 1) return -1;
		let r = e.char(n + 1);
		for (let t = 0; t < 32; t++) if (ms.charCodeAt(t) == r) return e.append(Q(X.Escape, n, n + 2));
		return -1;
	},
	Entity(e, t, n) {
		if (t != 38) return -1;
		let r = /^(?:#\d+|#x[a-f\d]+|\w+);/i.exec(e.slice(n + 1, n + 31));
		return r ? e.append(Q(X.Entity, n, n + 1 + r[0].length)) : -1;
	},
	InlineCode(e, t, n) {
		if (t != 96 || n && e.char(n - 1) == 96) return -1;
		let r = n + 1;
		for (; r < e.end && e.char(r) == 96;) r++;
		let i = r - n, a = 0;
		for (; r < e.end; r++) if (e.char(r) == 96) {
			if (a++, a == i && e.char(r + 1) != 96) return e.append(Q(X.InlineCode, n, r + 1, [Q(X.CodeMark, n, n + i), Q(X.CodeMark, r + 1 - i, r + 1)]));
		} else a = 0;
		return -1;
	},
	HTMLTag(e, t, n) {
		if (t != 60 || n == e.end - 1) return -1;
		let r = e.slice(n + 1, e.end), i = /^(?:[a-z][-\w+.]+:[^\s>]+|[a-z\d.!#$%&'*+/=?^_`{|}~-]+@[a-z\d](?:[a-z\d-]{0,61}[a-z\d])?(?:\.[a-z\d](?:[a-z\d-]{0,61}[a-z\d])?)*)>/i.exec(r);
		if (i) return e.append(Q(X.Autolink, n, n + 1 + i[0].length, [
			Q(X.LinkMark, n, n + 1),
			Q(X.URL, n + 1, n + i[0].length),
			Q(X.LinkMark, n + i[0].length, n + 1 + i[0].length)
		]));
		let a = /^!--(?:-?>|[^]*?-->)/.exec(r);
		if (a) return e.append(Q(X.Comment, n, n + 1 + a[0].length));
		let o = /^\?[^]*?\?>/.exec(r);
		if (o) return e.append(Q(X.ProcessingInstruction, n, n + 1 + o[0].length));
		let s = /^(?:![A-Z][^]*?>|!\[CDATA\[[^]*?\]\]>|\/[a-zA-Z][\w-]*\s*>|[a-zA-Z][\w-]*(\s+[a-zA-Z:_][\w-.:]*(?:\s*=\s*(?:[^\s"'=<>`]+|'[^']*'|"[^"]*"))?)*\s*\/?>)/.exec(r);
		return s ? e.append(Q(X.HTMLTag, n, n + 1 + s[0].length)) : -1;
	},
	Emphasis(e, t, n) {
		if (t != 95 && t != 42) return -1;
		let r = n + 1;
		for (; e.char(r) == t;) r++;
		let i = e.slice(n - 1, n), a = e.slice(r, r + 1), o = hs.test(i), s = hs.test(a), c = /\s|^$/.test(i), l = /\s|^$/.test(a), u = !l && (!s || c || o), d = !c && (!o || l || s), f = u && (t == 42 || !d || o), p = d && (t == 42 || !u || s);
		return e.append(new $(t == 95 ? us : ds, n, r, !!f | (p ? 2 : 0)));
	},
	HardBreak(e, t, n) {
		if (t == 92 && e.char(n + 1) == 10) return e.append(Q(X.HardBreak, n, n + 2));
		if (t == 32) {
			let t = n + 1;
			for (; e.char(t) == 32;) t++;
			if (e.char(t) == 10 && t >= n + 2) return e.append(Q(X.HardBreak, n, t + 1));
		}
		return -1;
	},
	Link(e, t, n) {
		return t == 91 ? e.append(new $(fs, n, n + 1, 1)) : -1;
	},
	Image(e, t, n) {
		return t == 33 && e.char(n + 1) == 91 ? e.append(new $(ps, n, n + 2, 1)) : -1;
	},
	LinkEnd(e, t, n) {
		if (t != 93) return -1;
		for (let t = e.parts.length - 1; t >= 0; t--) {
			let r = e.parts[t];
			if (r instanceof $ && (r.type == fs || r.type == ps)) {
				if (!r.side || e.skipSpace(r.to) == n && !/[(\[]/.test(e.slice(n + 1, n + 2))) return e.parts[t] = null, -1;
				let i = e.takeContent(t), a = e.parts[t] = _s(e, i, r.type == fs ? X.Link : X.Image, r.from, n + 1);
				if (r.type == fs) for (let n = 0; n < t; n++) {
					let t = e.parts[n];
					t instanceof $ && t.type == fs && (t.side = 0);
				}
				return a.to;
			}
		}
		return -1;
	}
};
function _s(e, t, n, r, i) {
	let { text: a } = e, o = e.char(i), s = i;
	if (t.unshift(Q(X.LinkMark, r, r + (n == X.Image ? 2 : 1))), t.push(Q(X.LinkMark, i - 1, i)), o == 40) {
		let n = e.skipSpace(i + 1), r = vs(a, n - e.offset, e.offset), o;
		r && (n = e.skipSpace(r.to), n != r.to && (o = ys(a, n - e.offset, e.offset), o && (n = e.skipSpace(o.to)))), e.char(n) == 41 && (t.push(Q(X.LinkMark, i, i + 1)), s = n + 1, r && t.push(r), o && t.push(o), t.push(Q(X.LinkMark, n, s)));
	} else if (o == 91) {
		let n = bs(a, i - e.offset, e.offset, !1);
		n && (t.push(n), s = n.to);
	}
	return Q(n, r, s, t);
}
function vs(e, t, n) {
	if (e.charCodeAt(t) == 60) {
		for (let r = t + 1, i = !1; r < e.length; r++) {
			let a = e.charCodeAt(r);
			if (a == 62 && !i) return Q(X.URL, t + n, r + 1 + n);
			if (a == 60 && !i || a == 10) return !1;
			i = a == 92;
		}
		return null;
	}
	{
		let r = 0, i = t;
		for (let t = !1; i < e.length; i++) {
			let n = e.charCodeAt(i);
			if (Z(n)) break;
			if (t) t = !1;
			else if (n == 40) r++;
			else if (n == 41) {
				if (!r) break;
				r--;
			} else n == 92 && (t = !0);
		}
		return i > t ? Q(X.URL, t + n, i + n) : i == e.length && null;
	}
}
function ys(e, t, n) {
	let r = e.charCodeAt(t);
	if (r != 39 && r != 34 && r != 40) return !1;
	let i = r == 40 ? 41 : r;
	for (let r = t + 1, a = !1; r < e.length; r++) {
		let o = e.charCodeAt(r);
		if (a) a = !1;
		else if (o == i) return Q(X.LinkTitle, t + n, r + 1 + n);
		else o == 92 && (a = !0);
	}
	return null;
}
function bs(e, t, n, r) {
	for (let i = !1, a = t + 1, o = Math.min(e.length, a + 999); a < o; a++) {
		let o = e.charCodeAt(a);
		if (i) i = !1;
		else if (o == 93) return !r && Q(X.LinkLabel, t + n, a + 1 + n);
		else {
			if (r && !Z(o) && (r = !1), o == 91) return !1;
			o == 92 && (i = !0);
		}
	}
	return null;
}
var xs = class {
	constructor(e, t, n) {
		this.parser = e, this.text = t, this.offset = n, this.parts = [];
	}
	char(e) {
		return e >= this.end ? -1 : this.text.charCodeAt(e - this.offset);
	}
	get end() {
		return this.offset + this.text.length;
	}
	slice(e, t) {
		return this.text.slice(e - this.offset, t - this.offset);
	}
	append(e) {
		return this.parts.push(e), e.to;
	}
	addDelimiter(e, t, n, r, i) {
		return this.append(new $(e, t, n, !!r | (i ? 2 : 0)));
	}
	get hasOpenLink() {
		for (let e = this.parts.length - 1; e >= 0; e--) {
			let t = this.parts[e];
			if (t instanceof $ && (t.type == fs || t.type == ps)) return !0;
		}
		return !1;
	}
	addElement(e) {
		return this.append(e);
	}
	resolveMarkers(e) {
		for (let t = e; t < this.parts.length; t++) {
			let n = this.parts[t];
			if (!(n instanceof $ && n.type.resolve && n.side & 2)) continue;
			let r = n.type == us || n.type == ds, i = n.to - n.from, a, o = t - 1;
			for (; o >= e; o--) {
				let e = this.parts[o];
				if (e instanceof $ && e.side & 1 && e.type == n.type && !(r && (n.side & 1 || e.side & 2) && (e.size + n.size) % 3 == 0 && (e.size % 3 || n.size % 3))) {
					a = e;
					break;
				}
			}
			if (!a) continue;
			let s = n.type.resolve, c = [], l = a.from, u = n.to;
			if (r) {
				let e = Math.min(2, a.to - a.from, i);
				l = a.to - e, u = n.from + e, s = e == 1 ? "Emphasis" : "StrongEmphasis";
			}
			a.type.mark && c.push(this.elt(a.type.mark, l, a.to));
			for (let e = o + 1; e < t; e++) this.parts[e] instanceof cs && c.push(this.parts[e]), this.parts[e] = null;
			n.type.mark && c.push(this.elt(n.type.mark, n.from, u));
			let d = this.elt(s, l, u, c);
			this.parts[o] = r && a.from != l ? new $(a.type, a.from, l, a.side, a.size) : null, (this.parts[t] = r && n.to != u ? new $(n.type, u, n.to, n.side, n.size) : null) ? this.parts.splice(t, 0, d) : this.parts[t] = d;
		}
		let t = [];
		for (let n = e; n < this.parts.length; n++) {
			let e = this.parts[n];
			e instanceof cs && t.push(e);
		}
		return t;
	}
	findOpeningDelimiter(e) {
		for (let t = this.parts.length - 1; t >= 0; t--) {
			let n = this.parts[t];
			if (n instanceof $ && n.type == e && n.side & 1) return t;
		}
		return null;
	}
	takeContent(e) {
		let t = this.resolveMarkers(e);
		return this.parts.length = e, t;
	}
	getDelimiterAt(e) {
		let t = this.parts[e];
		return t instanceof $ ? t : null;
	}
	skipSpace(e) {
		return ko(this.text, e - this.offset) + this.offset;
	}
	elt(e, t, n, r) {
		return typeof e == "string" ? Q(this.parser.getNodeType(e), t, n, r) : new ls(e, t);
	}
};
xs.linkStart = fs, xs.imageStart = ps, xs.emphasisAsterisk = ds, xs.emphasisUnderscore = us;
function Ss(e, t) {
	if (!t.length) return e;
	if (!e.length) return t;
	let n = e.slice(), r = 0;
	for (let e of t) {
		for (; r < n.length && n[r].to < e.to;) r++;
		if (r < n.length && n[r].from < e.from) {
			let t = n[r];
			t instanceof cs && (n[r] = new cs(t.type, t.from, t.to, Ss(t.children, [e])));
		} else n.splice(r++, 0, e);
	}
	return n;
}
var Cs = [
	X.CodeBlock,
	X.ListItem,
	X.OrderedList,
	X.BulletList
], ws = class {
	constructor(e, t) {
		this.fragments = e, this.input = t, this.i = 0, this.fragment = null, this.fragmentEnd = -1, this.cursor = null, e.length && (this.fragment = e[this.i++]);
	}
	nextFragment() {
		this.fragment = this.i < this.fragments.length ? this.fragments[this.i++] : null, this.cursor = null, this.fragmentEnd = -1;
	}
	moveTo(e, t) {
		for (; this.fragment && this.fragment.to <= e;) this.nextFragment();
		if (!this.fragment || this.fragment.from > (e ? e - 1 : 0)) return !1;
		if (this.fragmentEnd < 0) {
			let e = this.fragment.to;
			for (; e > 0 && this.input.read(e - 1, e) != "\n";) e--;
			this.fragmentEnd = e ? e - 1 : 0;
		}
		let n = this.cursor;
		n || (n = this.cursor = this.fragment.tree.cursor(K.IncludeAnonymous | K.IgnoreMounts), n.firstChild());
		let r = e + this.fragment.offset;
		for (; n.to <= r;) if (!n.parent()) return !1;
		for (;;) {
			if (n.from >= r) return this.fragment.from <= t;
			if (!n.childAfter(r)) return !1;
		}
	}
	matches(e) {
		let t = this.cursor.tree;
		for (; t && t.type.isAnonymous && t.children[0] instanceof q;) t = t.children[0];
		return t && t.prop(W.contextHash) == e;
	}
	takeNodes(e) {
		let t = this.cursor, n = this.fragment.offset, r = this.fragmentEnd - +!!this.fragment.openEnd, i = e.absoluteLineStart, a = i, o = e.block.children.length, s = e.lineStart - e.block.from >> 2, c = a, l = o;
		scan: for (;;) {
			if (t.to - n > Math.min(r, e.to) || t.type.isAnonymous && t.tree && (t.to - t.from > s || !Ts(t.tree))) {
				if (t.type.isAnonymous && t.firstChild()) continue;
				break;
			}
			let i = Es(t.from - n, e.ranges);
			if (t.to - n <= e.ranges[e.rangeI].to) e.addNode(t.tree, i);
			else {
				let n = new q(e.parser.nodeSet.types[X.Paragraph], [], [], 0, e.block.hashProp);
				e.reusePlaceholders.set(n, t.tree), e.addNode(n, i);
			}
			for ((t.type.isAnonymous || t.type.is("Block")) && (t.type.isAnonymous || Cs.indexOf(t.type.id) < 0 ? (a = t.to - n, o = e.block.children.length) : (a = c, o = l), c = t.to - n, l = e.block.children.length);;) {
				if (t.nextSibling()) continue scan;
				if (!t.parent() || !t.type.isAnonymous) break scan;
			}
		}
		for (; e.block.children.length > o;) e.block.children.pop(), e.block.positions.pop();
		return a - i;
	}
};
function Ts(e) {
	for (; e.type.isAnonymous;) {
		let t = e.children[e.children.length - 1];
		if (t instanceof q) e = t;
		else return !1;
	}
	return e.type.is("Block") && Cs.indexOf(e.type.id) < 0;
}
function Es(e, t) {
	let n = e;
	for (let r = 1; r < t.length; r++) {
		let i = t[r - 1].to, a = t[r].from;
		i < e && (n -= a - i);
	}
	return n;
}
var Ds = ao({
	"Blockquote/...": Y.quote,
	HorizontalRule: Y.contentSeparator,
	"ATXHeading1/... SetextHeading1/...": Y.heading1,
	"ATXHeading2/... SetextHeading2/...": Y.heading2,
	"ATXHeading3/...": Y.heading3,
	"ATXHeading4/...": Y.heading4,
	"ATXHeading5/...": Y.heading5,
	"ATXHeading6/...": Y.heading6,
	"Comment CommentBlock": Y.comment,
	Escape: Y.escape,
	Entity: Y.character,
	"Emphasis/...": Y.emphasis,
	"StrongEmphasis/...": Y.strong,
	"Link/... Image/...": Y.link,
	"OrderedList/... BulletList/...": Y.list,
	"BlockQuote/...": Y.quote,
	"InlineCode CodeText": Y.monospace,
	"URL Autolink": Y.url,
	"HeaderMark HardBreak QuoteMark ListMark LinkMark EmphasisMark CodeMark": Y.processingInstruction,
	"CodeInfo LinkLabel": Y.labelName,
	LinkTitle: Y.string,
	Paragraph: Y.content
}), Os = new ts(new Oa(as).extend(Ds), Object.keys(Ko).map((e) => Ko[e]), Object.keys(Ko).map((e) => Xo[e]), Object.keys(Ko), Zo, Oo, Object.keys(gs).map((e) => gs[e]), Object.keys(gs), []), ks = {
	resolve: "Strikethrough",
	mark: "StrikethroughMark"
}, As = {
	defineNodes: [{
		name: "Strikethrough",
		style: { "Strikethrough/...": Y.strikethrough }
	}, {
		name: "StrikethroughMark",
		style: Y.processingInstruction
	}],
	parseInline: [{
		name: "Strikethrough",
		parse(e, t, n) {
			if (t != 126 || e.char(n + 1) != 126 || e.char(n + 2) == 126) return -1;
			let r = e.slice(n - 1, n), i = e.slice(n + 2, n + 3), a = /\s|^$/.test(r), o = /\s|^$/.test(i), s = hs.test(r), c = hs.test(i);
			return e.addDelimiter(ks, n, n + 2, !o && (!c || a || s), !a && (!s || o || c));
		},
		after: "Emphasis"
	}]
};
function js(e, t, n = 0, r, i = 0) {
	let a = 0, o = !0, s = -1, c = -1, l = !1, u = () => {
		r.push(e.elt("TableCell", i + s, i + c, e.parser.parseInline(t.slice(s, c), i + s)));
	};
	for (let d = n; d < t.length; d++) {
		let n = t.charCodeAt(d);
		n == 124 && !l ? ((!o || s > -1) && a++, o = !1, r && (s > -1 && u(), r.push(e.elt("TableDelimiter", d + i, d + i + 1))), s = c = -1) : (l || n != 32 && n != 9) && (s < 0 && (s = d), c = d + 1), l = !l && n == 92;
	}
	return s > -1 && (a++, r && u()), a;
}
function Ms(e, t) {
	for (let n = t; n < e.length; n++) {
		let t = e.charCodeAt(n);
		if (t == 124) return !0;
		t == 92 && n++;
	}
	return !1;
}
var Ns = /^[>\s]*\|?(\s*:?-+:?\s*\|)+(\s*:?-+:?\s*)?$/, Ps = class {
	constructor() {
		this.rows = null;
	}
	nextLine(e, t, n) {
		if (this.rows == null) {
			this.rows = !1;
			let r;
			if ((t.next == 45 || t.next == 58 || t.next == 124) && Ns.test(r = t.text.slice(t.pos))) {
				let i = [];
				js(e, n.content, 0, i, n.start) == js(e, r, 0) && (this.rows = [e.elt("TableHeader", n.start, n.start + n.content.length, i), e.elt("TableDelimiter", e.lineStart + t.pos, e.lineStart + t.text.length)]);
			}
		} else if (this.rows) {
			let n = [];
			js(e, t.text, t.pos, n, e.lineStart), this.rows.push(e.elt("TableRow", e.lineStart + t.pos, e.lineStart + t.text.length, n));
		}
		return !1;
	}
	finish(e, t) {
		return this.rows ? (e.addLeafElement(t, e.elt("Table", t.start, t.start + t.content.length, this.rows)), !0) : !1;
	}
}, Fs = {
	defineNodes: [
		{
			name: "Table",
			block: !0
		},
		{
			name: "TableHeader",
			style: { "TableHeader/...": Y.heading }
		},
		"TableRow",
		{
			name: "TableCell",
			style: Y.content
		},
		{
			name: "TableDelimiter",
			style: Y.processingInstruction
		}
	],
	parseBlock: [{
		name: "Table",
		leaf(e, t) {
			return Ms(t.content, 0) ? new Ps() : null;
		},
		endLeaf(e, t, n) {
			if (n.parsers.some((e) => e instanceof Ps) || !Ms(t.text, t.basePos)) return !1;
			let r = e.peekLine();
			return Ns.test(r) && js(e, t.text, t.basePos) == js(e, r, t.basePos);
		},
		before: "SetextHeading"
	}]
}, Is = class {
	nextLine() {
		return !1;
	}
	finish(e, t) {
		return e.addLeafElement(t, e.elt("Task", t.start, t.start + t.content.length, [e.elt("TaskMarker", t.start, t.start + 3), ...e.parser.parseInline(t.content.slice(3), t.start + 3)])), !0;
	}
}, Ls = {
	defineNodes: [{
		name: "Task",
		block: !0,
		style: Y.list
	}, {
		name: "TaskMarker",
		style: Y.atom
	}],
	parseBlock: [{
		name: "TaskList",
		leaf(e, t) {
			return /^\[[ xX]\][ \t]/.test(t.content) && e.parentType().name == "ListItem" ? new Is() : null;
		},
		after: "SetextHeading"
	}]
}, Rs = /(www\.)|(https?:\/\/)|([\w.+-]{1,100}@)|(mailto:|xmpp:)/gy, zs = /[\w-]+(\.[\w-]+)+(:\d+)?(\/[^\s<]*)?/gy, Bs = /[\w-]+\.[\w-]+($|[/:])/, Vs = /[\w.+-]+@[\w-]+(\.[\w.-]+)+/gy, Hs = /\/[a-zA-Z\d@.]+/gy;
function Us(e, t, n, r) {
	let i = 0;
	for (let a = t; a < n; a++) e[a] == r && i++;
	return i;
}
function Ws(e, t) {
	zs.lastIndex = t;
	let n = zs.exec(e);
	if (!n || Bs.exec(n[0])[0].indexOf("_") > -1) return -1;
	let r = t + n[0].length;
	for (;;) {
		let n = e[r - 1], i;
		if (/[?!.,:*_~]/.test(n) || n == ")" && Us(e, t, r, ")") > Us(e, t, r, "(")) r--;
		else if (n == ";" && (i = /&(?:#\d+|#x[a-f\d]+|\w+);$/.exec(e.slice(t, r)))) r = t + i.index;
		else break;
	}
	return r;
}
function Gs(e, t) {
	Vs.lastIndex = t;
	let n = Vs.exec(e);
	if (!n) return -1;
	let r = n[0][n[0].length - 1];
	return r == "_" || r == "-" ? -1 : t + n[0].length - +(r == ".");
}
var Ks = [
	Fs,
	Ls,
	As,
	{ parseInline: [{
		name: "Autolink",
		parse(e, t, n) {
			let r = n - e.offset;
			if (r && /\w/.test(e.text[r - 1])) return -1;
			Rs.lastIndex = r;
			let i = Rs.exec(e.text), a = -1;
			return !i || (i[1] || i[2] ? (a = Ws(e.text, r + i[0].length), a > -1 && e.hasOpenLink && (a = r + /([^\[\]]|\[[^\]]*\])*/.exec(e.text.slice(r, a))[0].length)) : i[3] ? a = Gs(e.text, r) : (a = Gs(e.text, r + i[0].length), a > -1 && i[0] == "xmpp:" && (Hs.lastIndex = a, i = Hs.exec(e.text), i && (a = i.index + i[0].length))), a < 0) ? -1 : (e.addElement(e.elt("URL", n, a + e.offset)), a + e.offset);
		}
	}] }
];
Y.special(Y.content), Y.processingInstruction, Y.special(Y.content), Y.processingInstruction, Y.character;
// node_modules/ccount/index.js
function qs(e, t) {
	let n = String(e);
	if (typeof t != "string") throw TypeError("Expected character");
	let r = 0, i = n.indexOf(t);
	for (; i !== -1;) r++, i = n.indexOf(t, i + t.length);
	return r;
}
// node_modules/escape-string-regexp/index.js
function Js(e) {
	if (typeof e != "string") throw TypeError("Expected a string");
	return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
// node_modules/unist-util-is/lib/index.js
var Ys = (function(e) {
	if (e == null) return ec;
	if (typeof e == "function") return $s(e);
	if (typeof e == "object") return Array.isArray(e) ? Xs(e) : Zs(e);
	if (typeof e == "string") return Qs(e);
	throw Error("Expected function, string, or object as test");
});
function Xs(e) {
	let t = [], n = -1;
	for (; ++n < e.length;) t[n] = Ys(e[n]);
	return $s(r);
	function r(...e) {
		let n = -1;
		for (; ++n < t.length;) if (t[n].apply(this, e)) return !0;
		return !1;
	}
}
function Zs(e) {
	let t = e;
	return $s(n);
	function n(n) {
		let r = n, i;
		for (i in e) if (r[i] !== t[i]) return !1;
		return !0;
	}
}
function Qs(e) {
	return $s(t);
	function t(t) {
		return t && t.type === e;
	}
}
function $s(e) {
	return t;
	function t(t, n, r) {
		return !!(tc(t) && e.call(this, t, typeof n == "number" ? n : void 0, r || void 0));
	}
}
function ec() {
	return !0;
}
function tc(e) {
	return typeof e == "object" && !!e && "type" in e;
}
// node_modules/unist-util-visit-parents/lib/color.js
function nc(e) {
	return e;
}
// node_modules/unist-util-visit-parents/lib/index.js
var rc = [];
function ic(e, t, n, r) {
	let i;
	typeof t == "function" && typeof n != "function" ? (r = n, n = t) : i = t;
	let a = Ys(i), o = r ? -1 : 1;
	s(e, void 0, [])();
	function s(e, i, c) {
		let l = e && typeof e == "object" ? e : {};
		if (typeof l.type == "string") {
			let t = typeof l.tagName == "string" ? l.tagName : typeof l.name == "string" ? l.name : void 0;
			Object.defineProperty(u, "name", { value: "node (" + nc(e.type + (t ? "<" + t + ">" : "")) + ")" });
		}
		return u;
		function u() {
			let l = rc, u, d, f;
			if ((!t || a(e, i, c[c.length - 1] || void 0)) && (l = ac(n(e, c)), l[0] === !1)) return l;
			if ("children" in e && e.children) {
				let t = e;
				if (t.children && l[0] !== "skip") for (d = (r ? t.children.length : -1) + o, f = c.concat(t); d > -1 && d < t.children.length;) {
					let e = t.children[d];
					if (u = s(e, d, f)(), u[0] === !1) return u;
					d = typeof u[1] == "number" ? u[1] : d + o;
				}
			}
			return l;
		}
	}
}
function ac(e) {
	return Array.isArray(e) ? e : typeof e == "number" ? [!0, e] : e == null ? rc : [e];
}
// node_modules/mdast-util-find-and-replace/lib/index.js
function oc(e, t, n) {
	let r = Ys((n || {}).ignore || []), i = sc(t), a = -1;
	for (; ++a < i.length;) ic(e, "text", o);
	function o(e, t) {
		let n = -1, i;
		for (; ++n < t.length;) {
			let e = t[n], a = i ? i.children : void 0;
			if (r(e, a ? a.indexOf(e) : void 0, i)) return;
			i = e;
		}
		if (i) return s(e, t);
	}
	function s(e, t) {
		let n = t[t.length - 1], r = i[a][0], o = i[a][1], s = 0, c = n.children.indexOf(e), l = !1, u = [];
		r.lastIndex = 0;
		let d = r.exec(e.value);
		for (; d;) {
			let n = d.index, i = {
				index: d.index,
				input: d.input,
				stack: [...t, e]
			}, a = o(...d, i);
			if (typeof a == "string" && (a = a.length > 0 ? {
				type: "text",
				value: a
			} : void 0), a === !1) r.lastIndex = n + 1;
			else {
				if (s !== n && f({
					type: "text",
					value: e.value.slice(s, n)
				}), Array.isArray(a)) for (let e of a) f(e);
				else a && f(a);
				s = n + d[0].length, l = !0;
			}
			if (!r.global) break;
			d = r.exec(e.value);
		}
		return l ? (s < e.value.length && f({
			type: "text",
			value: e.value.slice(s)
		}), n.children.splice(c, 1, ...u)) : u = [e], c + u.length;
		function f(e) {
			let t = u[u.length - 1];
			t && t.type === "text" && e.type === "text" ? t.value += e.value : u.push(e);
		}
	}
}
function sc(e) {
	if (!Array.isArray(e)) throw TypeError("Expected find and replace tuple or list of tuples");
	let t = [], n = !e[0] || Array.isArray(e[0]) ? e : [e], r = -1;
	for (; ++r < n.length;) {
		let e = n[r];
		t.push([cc(e[0]), lc(e[1])]);
	}
	return t;
}
function cc(e) {
	return typeof e == "string" ? new RegExp(Js(e), "g") : e;
}
function lc(e) {
	return typeof e == "function" ? e : function() {
		return e;
	};
}
// node_modules/mdast-util-gfm-autolink-literal/lib/index.js
var uc = "phrasing", dc = [
	"autolink",
	"link",
	"image",
	"label"
];
function fc() {
	return {
		transforms: [bc],
		enter: {
			literalAutolink: mc,
			literalAutolinkEmail: hc,
			literalAutolinkHttp: hc,
			literalAutolinkWww: hc
		},
		exit: {
			literalAutolink: yc,
			literalAutolinkEmail: vc,
			literalAutolinkHttp: gc,
			literalAutolinkWww: _c
		}
	};
}
function pc() {
	return { unsafe: [
		{
			character: "@",
			before: "[+\\-.\\w]",
			after: "[\\-.\\w]",
			inConstruct: uc,
			notInConstruct: dc
		},
		{
			character: ".",
			before: "[Ww]",
			after: "[\\-.\\w]",
			inConstruct: uc,
			notInConstruct: dc
		},
		{
			character: ":",
			before: "[ps]",
			after: "\\/",
			inConstruct: uc,
			notInConstruct: dc
		}
	] };
}
function mc(e) {
	this.enter({
		type: "link",
		title: null,
		url: "",
		children: []
	}, e);
}
function hc(e) {
	this.config.enter.autolinkProtocol.call(this, e);
}
function gc(e) {
	this.config.exit.autolinkProtocol.call(this, e);
}
function _c(e) {
	this.config.exit.data.call(this, e);
	let t = this.stack[this.stack.length - 1];
	t.type, t.url = "http://" + this.sliceSerialize(e);
}
function vc(e) {
	this.config.exit.autolinkEmail.call(this, e);
}
function yc(e) {
	this.exit(e);
}
function bc(e) {
	oc(e, [[/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi, xc], [/(?<=^|\s|\p{P}|\p{S})([-.\w+]+)@([-\w]+(?:\.[-\w]+)+)/gu, Sc]], { ignore: ["link", "linkReference"] });
}
function xc(e, t, n, r, i) {
	let a = "";
	if (!Tc(i) || (/^w/i.test(t) && (n = t + n, t = "", a = "http://"), !Cc(n))) return !1;
	let o = wc(n + r);
	if (!o[0]) return !1;
	let s = {
		type: "link",
		title: null,
		url: a + t + o[0],
		children: [{
			type: "text",
			value: t + o[0]
		}]
	};
	return o[1] ? [s, {
		type: "text",
		value: o[1]
	}] : s;
}
function Sc(e, t, n, r) {
	return !Tc(r, !0) || /[-\d_]$/.test(n) ? !1 : {
		type: "link",
		title: null,
		url: "mailto:" + t + "@" + n,
		children: [{
			type: "text",
			value: t + "@" + n
		}]
	};
}
function Cc(e) {
	let t = e.split(".");
	return !(t.length < 2 || t[t.length - 1] && (/_/.test(t[t.length - 1]) || !/[a-zA-Z\d]/.test(t[t.length - 1])) || t[t.length - 2] && (/_/.test(t[t.length - 2]) || !/[a-zA-Z\d]/.test(t[t.length - 2])));
}
function wc(e) {
	let t = /[!"&'),.:;<>?\]}]+$/.exec(e);
	if (!t) return [e, void 0];
	e = e.slice(0, t.index);
	let n = t[0], r = n.indexOf(")"), i = qs(e, "("), a = qs(e, ")");
	for (; r !== -1 && i > a;) e += n.slice(0, r + 1), n = n.slice(r + 1), r = n.indexOf(")"), a++;
	return [e, n];
}
function Tc(e, t) {
	let n = e.input.charCodeAt(e.index - 1);
	return (e.index === 0 || C(n) || p(n)) && (!t || n !== 47);
}
// node_modules/mdast-util-gfm-footnote/lib/index.js
Fc.peek = Pc;
function Ec() {
	this.buffer();
}
function Dc(e) {
	this.enter({
		type: "footnoteReference",
		identifier: "",
		label: ""
	}, e);
}
function Oc() {
	this.buffer();
}
function kc(e) {
	this.enter({
		type: "footnoteDefinition",
		identifier: "",
		label: "",
		children: []
	}, e);
}
function Ac(e) {
	let t = this.resume(), n = this.stack[this.stack.length - 1];
	n.type, n.identifier = S(this.sliceSerialize(e)).toLowerCase(), n.label = t;
}
function jc(e) {
	this.exit(e);
}
function Mc(e) {
	let t = this.resume(), n = this.stack[this.stack.length - 1];
	n.type, n.identifier = S(this.sliceSerialize(e)).toLowerCase(), n.label = t;
}
function Nc(e) {
	this.exit(e);
}
function Pc() {
	return "[";
}
function Fc(e, t, n, r) {
	let i = n.createTracker(r), a = i.move("[^"), o = n.enter("footnoteReference"), s = n.enter("reference");
	return a += i.move(n.safe(n.associationId(e), {
		after: "]",
		before: a
	})), s(), o(), a += i.move("]"), a;
}
function Ic() {
	return {
		enter: {
			gfmFootnoteCallString: Ec,
			gfmFootnoteCall: Dc,
			gfmFootnoteDefinitionLabelString: Oc,
			gfmFootnoteDefinition: kc
		},
		exit: {
			gfmFootnoteCallString: Ac,
			gfmFootnoteCall: jc,
			gfmFootnoteDefinitionLabelString: Mc,
			gfmFootnoteDefinition: Nc
		}
	};
}
function Lc(e) {
	let t = !1;
	return e && e.firstLineBlank && (t = !0), {
		handlers: {
			footnoteDefinition: n,
			footnoteReference: Fc
		},
		unsafe: [{
			character: "[",
			inConstruct: [
				"label",
				"phrasing",
				"reference"
			]
		}]
	};
	function n(e, n, r, i) {
		let a = r.createTracker(i), o = a.move("[^"), s = r.enter("footnoteDefinition"), c = r.enter("label");
		return o += a.move(r.safe(r.associationId(e), {
			before: o,
			after: "]"
		})), c(), o += a.move("]:"), e.children && e.children.length > 0 && (a.shift(4), o += a.move((t ? "\n" : " ") + r.indentLines(r.containerFlow(e, a.current()), t ? zc : Rc))), s(), o;
	}
}
function Rc(e, t, n) {
	return t === 0 ? e : zc(e, t, n);
}
function zc(e, t, n) {
	return (n ? "" : "    ") + e;
}
// node_modules/mdast-util-gfm-strikethrough/lib/index.js
var Bc = [
	"autolink",
	"destinationLiteral",
	"destinationRaw",
	"reference",
	"titleQuote",
	"titleApostrophe"
];
Gc.attention = Kc, Gc.peek = qc;
function Vc() {
	return {
		canContainEols: ["delete"],
		enter: { strikethrough: Uc },
		exit: { strikethrough: Wc }
	};
}
function Hc() {
	return {
		handlers: { delete: Gc },
		unsafe: [{
			character: "~",
			inConstruct: "phrasing",
			notInConstruct: Bc
		}]
	};
}
function Uc(e) {
	this.enter({
		type: "delete",
		children: [],
		position: void 0
	}, e);
}
function Wc(e) {
	this.exit(e);
}
function Gc(e, t, n, r) {
	let i = n.createTracker(r), a = n.stack.includes("strikethrough") ? "~" : "~~", o = n.enter("strikethrough"), s = i.move(a);
	return s += n.containerPhrasing(e, {
		...i.current(),
		before: s,
		after: "~"
	}), s += i.move(a), o(), s;
}
function Kc() {
	return {
		construct: "strikethrough",
		markers: ["~"],
		sizes: [2, 1]
	};
}
function qc() {
	return "~";
}
// node_modules/markdown-table/index.js
function Jc(e) {
	return e.length;
}
function Yc(e, t) {
	let n = t || {}, r = (n.align || []).concat(), i = n.stringLength || Jc, a = [], o = [], s = [], c = [], l = 0, u = -1;
	for (; ++u < e.length;) {
		let t = [], r = [], a = -1;
		for (e[u].length > l && (l = e[u].length); ++a < e[u].length;) {
			let o = Xc(e[u][a]);
			if (n.alignDelimiters !== !1) {
				let e = i(o);
				r[a] = e, (c[a] === void 0 || e > c[a]) && (c[a] = e);
			}
			t.push(o);
		}
		o[u] = t, s[u] = r;
	}
	let d = -1;
	if (typeof r == "object" && "length" in r) for (; ++d < l;) a[d] = Zc(r[d]);
	else {
		let e = Zc(r);
		for (; ++d < l;) a[d] = e;
	}
	d = -1;
	let f = [], p = [];
	for (; ++d < l;) {
		let e = a[d], t = "", r = "";
		e === 99 ? (t = ":", r = ":") : e === 108 ? t = ":" : e === 114 && (r = ":");
		let i = n.alignDelimiters === !1 ? 1 : Math.max(1, c[d] - t.length - r.length), o = t + "-".repeat(i) + r;
		n.alignDelimiters !== !1 && (i = t.length + i + r.length, i > c[d] && (c[d] = i), p[d] = i), f[d] = o;
	}
	o.splice(1, 0, f), s.splice(1, 0, p), u = -1;
	let m = [];
	for (; ++u < o.length;) {
		let e = o[u], t = s[u];
		d = -1;
		let r = [];
		for (; ++d < l;) {
			let i = e[d] || "", o = "", s = "";
			if (n.alignDelimiters !== !1) {
				let e = c[d] - (t[d] || 0), n = a[d];
				n === 114 ? o = " ".repeat(e) : n === 99 ? e % 2 ? (o = " ".repeat(e / 2 + .5), s = " ".repeat(e / 2 - .5)) : (o = " ".repeat(e / 2), s = o) : s = " ".repeat(e);
			}
			n.delimiterStart !== !1 && !d && r.push("|"), n.padding === !1 || n.alignDelimiters === !1 && i === "" || n.delimiterStart === !1 && !d || r.push(" "), n.alignDelimiters !== !1 && r.push(o), r.push(i), n.alignDelimiters !== !1 && r.push(s), n.padding !== !1 && r.push(" "), (n.delimiterEnd !== !1 || d !== l - 1) && r.push("|");
		}
		m.push(n.delimiterEnd === !1 ? r.join("").replace(/ +$/, "") : r.join(""));
	}
	return m.join("\n");
}
function Xc(e) {
	return e == null ? "" : String(e);
}
function Zc(e) {
	let t = typeof e == "string" ? e.codePointAt(0) : 0;
	return t === 67 || t === 99 ? 99 : t === 76 || t === 108 ? 108 : t === 82 || t === 114 ? 114 : 0;
}
// node_modules/mdast-util-phrasing/lib/index.js
var Qc = Ys([
	"break",
	"delete",
	"emphasis",
	"footnote",
	"footnoteReference",
	"image",
	"imageReference",
	"inlineCode",
	"inlineMath",
	"link",
	"linkReference",
	"mdxJsxTextElement",
	"mdxTextExpression",
	"strong",
	"text",
	"textDirective"
]);
// node_modules/mdast-util-to-markdown/lib/handle/blockquote.js
function $c(e, t, n, r) {
	let i = n.enter("blockquote"), a = n.createTracker(r);
	a.move("> "), a.shift(2);
	let o = n.indentLines(n.containerFlow(e, a.current()), el);
	return i(), o;
}
function el(e, t, n) {
	return ">" + (n ? "" : " ") + e;
}
// node_modules/mdast-util-to-markdown/lib/util/pattern-in-scope.js
function tl(e, t) {
	return nl(e, t.inConstruct, !0) && !nl(e, t.notInConstruct, !1);
}
function nl(e, t, n) {
	if (typeof t == "string" && (t = [t]), !t || t.length === 0) return n;
	let r = -1;
	for (; ++r < t.length;) if (e.includes(t[r])) return !0;
	return !1;
}
// node_modules/mdast-util-to-markdown/lib/handle/break.js
function rl(e, t, n, r) {
	let i = -1;
	for (; ++i < n.unsafe.length;) {
		let e = n.unsafe[i];
		if (e.character === "\n" && !e.before && !e.after && tl(n.stack, e)) return /[\t ]/.test(r.before) ? "" : " ";
	}
	return "\\\n";
}
// node_modules/longest-streak/index.js
function il(e, t) {
	let n = String(e), r = n.indexOf(t), i = r, a = 0, o = 0;
	if (typeof t != "string") throw TypeError("Expected substring");
	for (; r !== -1;) r === i ? ++a > o && (o = a) : a = 1, i = r + t.length, r = n.indexOf(t, i);
	return o;
}
// node_modules/mdast-util-to-markdown/lib/util/format-code-as-indented.js
function al(e, t) {
	return !(t.options.fences !== !1 || !e.value || e.lang || !/[^\n\r ]/.test(e.value) || /^[\t ]*(?:[\n\r]|$)|(?:^|[\n\r])[\t ]*$/.test(e.value));
}
// node_modules/mdast-util-to-markdown/lib/util/check-fence.js
function ol(e) {
	let t = e.options.fence || "`";
	if (t !== "`" && t !== "~") throw Error("Cannot serialize code with `" + t + "` for `options.fence`, expected `` ` `` or `~`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/code.js
function sl(e, t, n, r) {
	let i = ol(n), a = e.value || "";
	if (al(e, n)) {
		let e = n.enter("codeIndented"), t = n.indentLines(a, cl);
		return e(), t;
	}
	let o = n.createTracker(r), s = i.repeat(Math.max(il(a, i) + 1, 3)), c = n.enter("codeFenced"), l = i === "`" ? "GraveAccent" : "Tilde", u = o.move(s);
	if (e.lang) {
		let t = n.enter(`codeFencedLang${l}`);
		u += o.move(n.safe(e.lang, {
			before: u,
			after: " ",
			encode: ["`"],
			...o.current()
		})), t();
	}
	if (e.lang && e.meta) {
		let t = n.enter(`codeFencedMeta${l}`);
		u += o.move(" "), u += o.move(n.safe(e.meta, {
			before: u,
			after: "\n",
			encode: ["`"],
			...o.current()
		})), t();
	}
	return u += o.move("\n"), a && (u += o.move(a + "\n")), u += o.move(s), c(), u;
}
function cl(e, t, n) {
	return (n ? "" : "    ") + e;
}
// node_modules/mdast-util-to-markdown/lib/util/check-quote.js
function ll(e) {
	let t = e.options.quote || "\"";
	if (t !== "\"" && t !== "'") throw Error("Cannot serialize title with `" + t + "` for `options.quote`, expected `\"`, or `'`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/definition.js
function ul(e, t, n, r) {
	let i = ll(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.enter("definition"), s = n.enter("label"), c = n.createTracker(r), l = c.move("[");
	return l += c.move(n.safe(n.associationId(e), {
		before: l,
		after: "]",
		...c.current()
	})), l += c.move("]: "), s(), !e.url || /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), l += c.move("<"), l += c.move(n.safe(e.url, {
		before: l,
		after: ">",
		...c.current()
	})), l += c.move(">")) : (s = n.enter("destinationRaw"), l += c.move(n.safe(e.url, {
		before: l,
		after: e.title ? " " : "\n",
		...c.current()
	}))), s(), e.title && (s = n.enter(`title${a}`), l += c.move(" " + i), l += c.move(n.safe(e.title, {
		before: l,
		after: i,
		...c.current()
	})), l += c.move(i), s()), o(), l;
}
// node_modules/mdast-util-to-markdown/lib/util/check-emphasis.js
function dl(e) {
	let t = e.options.emphasis || "*";
	if (t !== "*" && t !== "_") throw Error("Cannot serialize emphasis with `" + t + "` for `options.emphasis`, expected `*`, or `_`");
	return t;
}
fl.attention = pl, fl.peek = ml;
function fl(e, t, n, r) {
	let i = n.enter("phrasing"), a = n.containerPhrasing({
		type: "root",
		children: [e]
	}, r);
	return i(), a;
}
function pl(e, t) {
	return {
		construct: "emphasis",
		markers: dl(t) === "*" ? ["*", "_"] : ["_", "*"],
		sizes: [1]
	};
}
function ml(e, t, n) {
	return n.options.emphasis || "*";
}
// node_modules/mdast-util-to-markdown/lib/util/encode-character-reference.js
function hl(e) {
	return "&#x" + e.toString(16).toUpperCase() + ";";
}
// node_modules/unist-util-visit/lib/index.js
function gl(e, t, n, r) {
	let i, a, o;
	typeof t == "function" && typeof n != "function" ? (a = void 0, o = t, i = n) : (a = t, o = n, i = r), ic(e, a, s, i);
	function s(e, t) {
		let n = t[t.length - 1], r = n ? n.children.indexOf(e) : void 0;
		return o(e, r, n);
	}
}
// node_modules/mdast-util-to-markdown/lib/util/format-heading-as-setext.js
function _l(e, t) {
	let n = !1;
	return gl(e, function(e) {
		if ("value" in e && /\r?\n|\r/.test(e.value) || e.type === "break") return n = !0, !1;
	}), !!((!e.depth || e.depth < 3) && ne(e) && (t.options.setext || n));
}
// node_modules/mdast-util-to-markdown/lib/handle/heading.js
function vl(e, t, n, r) {
	let i = Math.max(Math.min(6, e.depth || 1), 1), a = n.createTracker(r);
	if (_l(e, n)) {
		let t = n.enter("headingSetext"), r = n.enter("phrasing"), o = n.containerPhrasing(e, {
			...a.current(),
			before: "\n",
			after: "\n"
		});
		return r(), t(), o + "\n" + (i === 1 ? "=" : "-").repeat(o.length - (Math.max(o.lastIndexOf("\r"), o.lastIndexOf("\n")) + 1));
	}
	let o = "#".repeat(i), s = n.enter("headingAtx"), c = n.enter("phrasing");
	a.move(o + " ");
	let l = n.containerPhrasing(e, {
		before: "# ",
		after: "\n",
		...a.current()
	}), u = l.charCodeAt(0);
	return (u === 9 || u === 32) && (l = hl(u) + l.slice(1)), l = l ? o + " " + l : o, n.options.closeAtx && (l += " " + o), c(), s(), l;
}
// node_modules/mdast-util-to-markdown/lib/handle/html.js
yl.peek = bl;
function yl(e) {
	return e.value || "";
}
function bl() {
	return "<";
}
// node_modules/mdast-util-to-markdown/lib/handle/image.js
xl.peek = Sl;
function xl(e, t, n, r) {
	let i = ll(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.enter("image"), s = n.enter("label"), c = n.createTracker(r), l = c.move("![");
	return l += c.move(n.safe(e.alt, {
		before: l,
		after: "]",
		...c.current()
	})), l += c.move("]("), s(), !e.url && e.title || /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), l += c.move("<"), l += c.move(n.safe(e.url, {
		before: l,
		after: ">",
		...c.current()
	})), l += c.move(">")) : (s = n.enter("destinationRaw"), l += c.move(n.safe(e.url, {
		before: l,
		after: e.title ? " " : ")",
		...c.current()
	}))), s(), e.title && (s = n.enter(`title${a}`), l += c.move(" " + i), l += c.move(n.safe(e.title, {
		before: l,
		after: i,
		...c.current()
	})), l += c.move(i), s()), l += c.move(")"), o(), l;
}
function Sl() {
	return "!";
}
// node_modules/mdast-util-to-markdown/lib/handle/image-reference.js
Cl.peek = wl;
function Cl(e, t, n, r) {
	let i = e.referenceType, a = n.enter("imageReference"), o = n.enter("label"), s = n.createTracker(r), c = s.move("!["), l = n.safe(e.alt, {
		before: c,
		after: "]",
		...s.current()
	});
	c += s.move(l + "]["), o();
	let u = n.stack;
	n.stack = u.filter(function(e) {
		return e !== "phrasing";
	}), o = n.enter("reference");
	let d = n.safe(n.associationId(e), {
		before: c,
		after: "]",
		...s.current()
	});
	return o(), n.stack = u, a(), i === "full" || !l || l !== d ? c += s.move(d + "]") : i === "shortcut" ? c = c.slice(0, -1) : c += s.move("]"), c;
}
function wl() {
	return "!";
}
// node_modules/mdast-util-to-markdown/lib/handle/inline-code.js
Tl.peek = El;
function Tl(e, t, n) {
	let r = e.value || "", i = "`", a = -1;
	for (; RegExp("(^|[^`])" + i + "([^`]|$)").test(r);) i += "`";
	for (/[^\n\r ]/.test(r) && (/^[\n\r ]/.test(r) && /[\n\r ]$/.test(r) || /^`|`$/.test(r)) && (r = " " + r + " "); ++a < n.unsafe.length;) {
		let e = n.unsafe[a], t = n.compilePattern(e);
		if (!e.atBreak) continue;
		let i;
		for (; i = t.exec(r);) {
			let e = i.index;
			r.charCodeAt(e) === 10 && r.charCodeAt(e - 1) === 13 && e--, r = r.slice(0, e) + " " + r.slice(i.index + 1);
		}
	}
	return i + r + i;
}
function El() {
	return "`";
}
// node_modules/mdast-util-to-markdown/lib/util/format-link-as-autolink.js
function Dl(e, t) {
	let n = ne(e);
	return !(t.options.resourceLink || !e.url || e.title || !e.children || e.children.length !== 1 || e.children[0].type !== "text" || n !== e.url && "mailto:" + n !== e.url || !/^[a-z][+\-.a-z]+:/i.test(e.url) || /[\0- <>\u007F]/.test(e.url));
}
// node_modules/mdast-util-to-markdown/lib/handle/link.js
Ol.peek = kl;
function Ol(e, t, n, r) {
	let i = ll(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.createTracker(r);
	if (Dl(e, n)) {
		let t = n.stack;
		n.stack = t.filter(function(e) {
			return e !== "phrasing";
		});
		let r = n.enter("autolink"), i = o.move("<");
		return i += o.move(n.containerPhrasing(e, {
			before: i,
			after: ">",
			...o.current()
		})), i += o.move(">"), r(), n.stack = t, i;
	}
	let s = n.enter("link"), c = n.enter("label"), l = o.move("[");
	return l += o.move(n.containerPhrasing(e, {
		before: l,
		after: "](",
		...o.current()
	})), l += o.move("]("), c(), !e.url && e.title || /[\0- \u007F]/.test(e.url) ? (c = n.enter("destinationLiteral"), l += o.move("<"), l += o.move(n.safe(e.url, {
		before: l,
		after: ">",
		...o.current()
	})), l += o.move(">")) : (c = n.enter("destinationRaw"), l += o.move(n.safe(e.url, {
		before: l,
		after: e.title ? " " : ")",
		...o.current()
	}))), c(), e.title && (c = n.enter(`title${a}`), l += o.move(" " + i), l += o.move(n.safe(e.title, {
		before: l,
		after: i,
		...o.current()
	})), l += o.move(i), c()), l += o.move(")"), s(), l;
}
function kl(e, t, n) {
	return Dl(e, n) ? "<" : "[";
}
// node_modules/mdast-util-to-markdown/lib/handle/link-reference.js
Al.peek = jl;
function Al(e, t, n, r) {
	let i = e.referenceType, a = n.enter("linkReference"), o = n.enter("label"), s = n.createTracker(r), c = s.move("["), l = n.containerPhrasing(e, {
		before: c,
		after: "]",
		...s.current()
	});
	c += s.move(l + "]["), o();
	let u = n.stack;
	n.stack = u.filter(function(e) {
		return e !== "phrasing";
	}), o = n.enter("reference");
	let d = n.safe(n.associationId(e), {
		before: c,
		after: "]",
		...s.current()
	});
	return o(), n.stack = u, a(), i === "full" || !l || l !== d ? c += s.move(d + "]") : i === "shortcut" ? c = c.slice(0, -1) : c += s.move("]"), c;
}
function jl() {
	return "[";
}
// node_modules/mdast-util-to-markdown/lib/util/check-bullet.js
function Ml(e) {
	let t = e.options.bullet || "*";
	if (t !== "*" && t !== "+" && t !== "-") throw Error("Cannot serialize items with `" + t + "` for `options.bullet`, expected `*`, `+`, or `-`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/util/check-bullet-other.js
function Nl(e) {
	let t = Ml(e), n = e.options.bulletOther;
	if (!n) return t === "*" ? "-" : "*";
	if (n !== "*" && n !== "+" && n !== "-") throw Error("Cannot serialize items with `" + n + "` for `options.bulletOther`, expected `*`, `+`, or `-`");
	if (n === t) throw Error("Expected `bullet` (`" + t + "`) and `bulletOther` (`" + n + "`) to be different");
	return n;
}
// node_modules/mdast-util-to-markdown/lib/util/check-bullet-ordered.js
function Pl(e) {
	let t = e.options.bulletOrdered || ".";
	if (t !== "." && t !== ")") throw Error("Cannot serialize items with `" + t + "` for `options.bulletOrdered`, expected `.` or `)`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/util/check-rule.js
function Fl(e) {
	let t = e.options.rule || "*";
	if (t !== "*" && t !== "-" && t !== "_") throw Error("Cannot serialize rules with `" + t + "` for `options.rule`, expected `*`, `-`, or `_`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/list.js
function Il(e, t, n, r) {
	let i = n.enter("list"), a = n.bulletCurrent, o = e.ordered ? Pl(n) : Ml(n), s = e.ordered ? o === "." ? ")" : "." : Nl(n), c = t && n.bulletLastUsed ? o === n.bulletLastUsed : !1;
	if (!e.ordered) {
		let t = e.children ? e.children[0] : void 0;
		if (o !== "*" && o !== "-" || !t || t.children && t.children[0] || n.stack[n.stack.length - 1] !== "list" || n.stack[n.stack.length - 2] !== "listItem" || n.stack[n.stack.length - 3] !== "list" || n.stack[n.stack.length - 4] !== "listItem" || n.indexStack[n.indexStack.length - 1] !== 0 || n.indexStack[n.indexStack.length - 2] !== 0 || n.indexStack[n.indexStack.length - 3] !== 0 || (c = !0), Fl(n) === o && t) {
			let t = -1;
			for (; ++t < e.children.length;) {
				let n = e.children[t];
				if (n && n.type === "listItem" && n.children && n.children[0] && n.children[0].type === "thematicBreak") {
					c = !0;
					break;
				}
			}
		}
	}
	c && (o = s), n.bulletCurrent = o;
	let l = n.containerFlow(e, r);
	return n.bulletLastUsed = o, n.bulletCurrent = a, i(), l;
}
// node_modules/mdast-util-to-markdown/lib/util/check-list-item-indent.js
function Ll(e) {
	let t = e.options.listItemIndent || "one";
	if (t !== "tab" && t !== "one" && t !== "mixed") throw Error("Cannot serialize items with `" + t + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/list-item.js
function Rl(e, t, n, r) {
	let i = Ll(n), a = n.bulletCurrent || Ml(n);
	t && t.type === "list" && t.ordered && (a = (typeof t.start == "number" && t.start > -1 ? t.start : 1) + (n.options.incrementListMarker === !1 ? 0 : t.children.indexOf(e)) + a);
	let o = a.length + 1;
	(i === "tab" || i === "mixed" && (t && t.type === "list" && t.spread || e.spread)) && (o = Math.ceil(o / 4) * 4);
	let s = n.createTracker(r);
	s.move(a + " ".repeat(o - a.length)), s.shift(o);
	let c = n.enter("listItem"), l = n.indentLines(n.containerFlow(e, s.current()), u);
	return c(), l;
	function u(e, t, n) {
		return t ? (n ? "" : " ".repeat(o)) + e : (n ? a : a + " ".repeat(o - a.length)) + e;
	}
}
// node_modules/mdast-util-to-markdown/lib/handle/paragraph.js
function zl(e, t, n, r) {
	let i = n.enter("paragraph"), a = n.enter("phrasing"), o = n.containerPhrasing(e, r);
	return a(), i(), o;
}
// node_modules/mdast-util-to-markdown/lib/handle/root.js
function Bl(e, t, n, r) {
	if (!e.children.some(function(e) {
		return Qc(e);
	})) return n.containerFlow(e, r);
	let i = n.enter("phrasing"), a = n.containerPhrasing(e, r);
	return i(), a;
}
// node_modules/mdast-util-to-markdown/lib/util/check-strong.js
function Vl(e) {
	let t = e.options.strong || "*";
	if (t !== "*" && t !== "_") throw Error("Cannot serialize strong with `" + t + "` for `options.strong`, expected `*`, or `_`");
	return t;
}
Hl.attention = Ul, Hl.peek = Wl;
function Hl(e, t, n, r) {
	let i = n.enter("phrasing"), a = n.containerPhrasing({
		type: "root",
		children: [e]
	}, r);
	return i(), a;
}
function Ul(e, t) {
	return {
		construct: "strong",
		markers: Vl(t) === "*" ? ["*", "_"] : ["_", "*"],
		sizes: [2]
	};
}
function Wl(e, t, n) {
	return n.options.strong || "*";
}
// node_modules/mdast-util-to-markdown/lib/handle/text.js
function Gl(e, t, n, r) {
	/* c8 ignore next -- parent always passed */
	let i = t ? t.children : [], a = i.indexOf(e);
	return n.safe(e.value, {
		...r,
		afterNode: i[a + 1],
		beforeNode: i[a - 1]
	});
}
// node_modules/mdast-util-to-markdown/lib/util/check-rule-repetition.js
function Kl(e) {
	let t = e.options.ruleRepetition || 3;
	if (t < 3) throw Error("Cannot serialize rules with repetition `" + t + "` for `options.ruleRepetition`, expected `3` or more");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/thematic-break.js
function ql(e, t, n) {
	let r = (Fl(n) + (n.options.ruleSpaces ? " " : "")).repeat(Kl(n));
	return n.options.ruleSpaces ? r.slice(0, -1) : r;
}
// node_modules/mdast-util-to-markdown/lib/handle/index.js
var Jl = {
	blockquote: $c,
	break: rl,
	code: sl,
	definition: ul,
	emphasis: fl,
	hardBreak: rl,
	heading: vl,
	html: yl,
	image: xl,
	imageReference: Cl,
	inlineCode: Tl,
	link: Ol,
	linkReference: Al,
	list: Il,
	listItem: Rl,
	paragraph: zl,
	root: Bl,
	strong: Hl,
	text: Gl,
	thematicBreak: ql
};
// node_modules/mdast-util-gfm-table/lib/index.js
function Yl() {
	return {
		enter: {
			table: Xl,
			tableData: eu,
			tableHeader: eu,
			tableRow: Ql
		},
		exit: {
			codeText: tu,
			table: Zl,
			tableData: $l,
			tableHeader: $l,
			tableRow: $l
		}
	};
}
function Xl(e) {
	let t = e._align;
	this.enter({
		type: "table",
		align: t.map(function(e) {
			return e === "none" ? null : e;
		}),
		children: []
	}, e), this.data.inTable = !0;
}
function Zl(e) {
	this.exit(e), this.data.inTable = void 0;
}
function Ql(e) {
	this.enter({
		type: "tableRow",
		children: []
	}, e);
}
function $l(e) {
	this.exit(e);
}
function eu(e) {
	this.enter({
		type: "tableCell",
		children: []
	}, e);
}
function tu(e) {
	let t = this.resume();
	this.data.inTable && (t = t.replace(/\\([\\|])/g, nu));
	let n = this.stack[this.stack.length - 1];
	n.type, n.value = t, this.exit(e);
}
function nu(e, t) {
	return t === "|" ? t : e;
}
function ru(e) {
	let t = e || {}, n = t.tableCellPadding, r = t.tablePipeAlign, i = t.stringLength, a = n ? " " : "|";
	return {
		unsafe: [
			{
				character: "\r",
				inConstruct: "tableCell"
			},
			{
				character: "\n",
				inConstruct: "tableCell"
			},
			{
				atBreak: !0,
				character: "|",
				after: "[	 :-]"
			},
			{
				character: "|",
				inConstruct: "tableCell"
			},
			{
				atBreak: !0,
				character: ":",
				after: "-"
			},
			{
				atBreak: !0,
				character: "-",
				after: "[:|-]"
			}
		],
		handlers: {
			inlineCode: f,
			table: o,
			tableCell: c,
			tableRow: s
		}
	};
	function o(e, t, n, r) {
		return l(u(e, n, r), e.align);
	}
	function s(e, t, n, r) {
		let i = l([d(e, n, r)]);
		return i.slice(0, i.indexOf("\n"));
	}
	function c(e, t, n, r) {
		let i = n.enter("tableCell"), o = n.enter("phrasing"), s = n.containerPhrasing(e, {
			...r,
			before: a,
			after: a
		});
		return o(), i(), s;
	}
	function l(e, t) {
		return Yc(e, {
			align: t,
			alignDelimiters: r,
			padding: n,
			stringLength: i
		});
	}
	function u(e, t, n) {
		let r = e.children, i = -1, a = [], o = t.enter("table");
		for (; ++i < r.length;) a[i] = d(r[i], t, n);
		return o(), a;
	}
	function d(e, t, n) {
		let r = e.children, i = -1, a = [], o = t.enter("tableRow");
		for (; ++i < r.length;) a[i] = c(r[i], e, t, n);
		return o(), a;
	}
	function f(e, t, n) {
		let r = Jl.inlineCode(e, t, n);
		return n.stack.includes("tableCell") && (r = r.replace(/\|/g, "\\$&")), r;
	}
}
// node_modules/mdast-util-gfm-task-list-item/lib/index.js
function iu() {
	return { exit: {
		taskListCheckValueChecked: ou,
		taskListCheckValueUnchecked: ou,
		paragraph: su
	} };
}
function au() {
	return {
		unsafe: [{
			atBreak: !0,
			character: "-",
			after: "[:|-]"
		}],
		handlers: { listItem: cu }
	};
}
function ou(e) {
	let t = this.stack[this.stack.length - 2];
	t.type, t.checked = e.type === "taskListCheckValueChecked";
}
function su(e) {
	let t = this.stack[this.stack.length - 2];
	if (t && t.type === "listItem" && typeof t.checked == "boolean") {
		let e = this.stack[this.stack.length - 1];
		e.type;
		let n = e.children[0];
		if (n && n.type === "text") {
			let r = t.children, i = -1, a;
			for (; ++i < r.length;) {
				let e = r[i];
				if (e.type === "paragraph") {
					a = e;
					break;
				}
			}
			a === e && (n.value = n.value.slice(1), n.value.length === 0 ? e.children.shift() : e.position && n.position && typeof n.position.start.offset == "number" && (n.position.start.column++, n.position.start.offset++, e.position.start = Object.assign({}, n.position.start)));
		}
	}
	this.exit(e);
}
function cu(e, t, n, r) {
	let i = e.children[0], a = typeof e.checked == "boolean" && i && i.type === "paragraph", o = "[" + (e.checked ? "x" : " ") + "] ", s = n.createTracker(r);
	a && s.move(o);
	let c = Jl.listItem(e, t, n, {
		...r,
		...s.current()
	});
	return a && (c = c.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, l)), c;
	function l(e) {
		return e + o;
	}
}
// node_modules/mdast-util-gfm/lib/index.js
function lu() {
	return [
		fc(),
		Ic(),
		Vc(),
		Yl(),
		iu()
	];
}
function uu(e) {
	return { extensions: [
		pc(),
		Lc(e),
		Hc(),
		ru(e),
		au()
	] };
}
// node_modules/micromark-extension-gfm-autolink-literal/lib/syntax.js
var du = {
	tokenize: Tu,
	partial: !0
}, fu = {
	tokenize: Eu,
	partial: !0
}, pu = {
	tokenize: Du,
	partial: !0
}, mu = {
	tokenize: Ou,
	partial: !0
}, hu = {
	tokenize: ku,
	partial: !0
}, gu = {
	name: "wwwAutolink",
	tokenize: Cu,
	previous: Au
}, _u = {
	name: "protocolAutolink",
	tokenize: wu,
	previous: ju
}, vu = {
	name: "emailAutolink",
	tokenize: Su,
	previous: Mu
}, yu = {};
function bu() {
	return { text: yu };
}
for (var xu = 48; xu < 123;) yu[xu] = vu, xu++, xu === 58 ? xu = 65 : xu === 91 && (xu = 97);
yu[43] = vu, yu[45] = vu, yu[46] = vu, yu[95] = vu, yu[72] = [vu, _u], yu[104] = [vu, _u], yu[87] = [vu, gu], yu[119] = [vu, gu];
function Su(e, t, n) {
	let r = this, i, a;
	return o;
	function o(t) {
		return !Nu(t) || !Mu.call(r, r.previous) || Pu(r.events) ? n(t) : (e.enter("literalAutolink"), e.enter("literalAutolinkEmail"), s(t));
	}
	function s(t) {
		return Nu(t) ? (e.consume(t), s) : t === 64 ? (e.consume(t), c) : n(t);
	}
	function c(t) {
		return t === 46 ? e.check(hu, u, l)(t) : t === 45 || t === 95 || ae(t) ? (a = !0, e.consume(t), c) : u(t);
	}
	function l(t) {
		return e.consume(t), i = !0, c;
	}
	function u(o) {
		return a && i && y(r.previous) ? (e.exit("literalAutolinkEmail"), e.exit("literalAutolink"), t(o)) : n(o);
	}
}
function Cu(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return t !== 87 && t !== 119 || !Au.call(r, r.previous) || Pu(r.events) ? n(t) : (e.enter("literalAutolink"), e.enter("literalAutolinkWww"), e.check(du, e.attempt(fu, e.attempt(pu, a), n), n)(t));
	}
	function a(n) {
		return e.exit("literalAutolinkWww"), e.exit("literalAutolink"), t(n);
	}
}
function wu(e, t, n) {
	let r = this, i = "", a = !1;
	return o;
	function o(t) {
		return (t === 72 || t === 104) && ju.call(r, r.previous) && !Pu(r.events) ? (e.enter("literalAutolink"), e.enter("literalAutolinkHttp"), i += String.fromCodePoint(t), e.consume(t), s) : n(t);
	}
	function s(t) {
		if (y(t) && i.length < 5) return i += String.fromCodePoint(t), e.consume(t), s;
		if (t === 58) {
			let n = i.toLowerCase();
			if (n === "http" || n === "https") return e.consume(t), c;
		}
		return n(t);
	}
	function c(t) {
		return t === 47 ? (e.consume(t), a ? l : (a = !0, c)) : n(t);
	}
	function l(t) {
		return t === null || x(t) || m(t) || C(t) || p(t) ? n(t) : e.attempt(fu, e.attempt(pu, u), n)(t);
	}
	function u(n) {
		return e.exit("literalAutolinkHttp"), e.exit("literalAutolink"), t(n);
	}
}
function Tu(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return (t === 87 || t === 119) && r < 3 ? (r++, e.consume(t), i) : t === 46 && r === 3 ? (e.consume(t), a) : n(t);
	}
	function a(e) {
		return e === null ? n(e) : t(e);
	}
}
function Eu(e, t, n) {
	let r, i, a;
	return o;
	function o(t) {
		return t === 46 || t === 95 ? e.check(mu, c, s)(t) : t === null || m(t) || C(t) || t !== 45 && p(t) ? c(t) : (a = !0, e.consume(t), o);
	}
	function s(t) {
		return t === 95 ? r = !0 : (i = r, r = void 0), e.consume(t), o;
	}
	function c(e) {
		return i || r || !a ? n(e) : t(e);
	}
}
function Du(e, t) {
	let n = 0, r = 0;
	return i;
	function i(o) {
		return o === 40 ? (n++, e.consume(o), i) : o === 41 && r < n ? a(o) : o === 33 || o === 34 || o === 38 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 60 || o === 63 || o === 93 || o === 95 || o === 126 ? e.check(mu, t, a)(o) : o === null || m(o) || C(o) ? t(o) : (e.consume(o), i);
	}
	function a(t) {
		return t === 41 && r++, e.consume(t), i;
	}
}
function Ou(e, t, n) {
	return r;
	function r(o) {
		return o === 33 || o === 34 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 63 || o === 95 || o === 126 ? (e.consume(o), r) : o === 38 ? (e.consume(o), a) : o === 93 ? (e.consume(o), i) : o === 60 || o === null || m(o) || C(o) ? t(o) : n(o);
	}
	function i(e) {
		return e === null || e === 40 || e === 91 || m(e) || C(e) ? t(e) : r(e);
	}
	function a(e) {
		return y(e) ? o(e) : n(e);
	}
	function o(t) {
		return t === 59 ? (e.consume(t), r) : y(t) ? (e.consume(t), o) : n(t);
	}
}
function ku(e, t, n) {
	return r;
	function r(t) {
		return e.consume(t), i;
	}
	function i(e) {
		return ae(e) ? n(e) : t(e);
	}
}
function Au(e) {
	return e === null || e === 40 || e === 42 || e === 95 || e === 91 || e === 93 || e === 126 || m(e);
}
function ju(e) {
	return !y(e);
}
function Mu(e) {
	return !(e === 47 || Nu(e));
}
function Nu(e) {
	return e === 43 || e === 45 || e === 46 || e === 95 || ae(e);
}
function Pu(e) {
	let t = e.length, n = !1;
	for (; t--;) {
		let r = e[t][1];
		if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
			n = !0;
			break;
		}
		if (r._gfmAutolinkLiteralWalkedInto) {
			n = !1;
			break;
		}
	}
	return e.length > 0 && !n && (e[e.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), n;
}
// node_modules/micromark-extension-gfm-footnote/lib/syntax.js
var Fu = {
	tokenize: Uu,
	partial: !0
};
function Iu() {
	return {
		document: { 91: {
			name: "gfmFootnoteDefinition",
			tokenize: Bu,
			continuation: { tokenize: Vu },
			exit: Hu
		} },
		text: {
			91: {
				name: "gfmFootnoteCall",
				tokenize: zu
			},
			93: {
				name: "gfmPotentialFootnoteCall",
				add: "after",
				tokenize: Lu,
				resolveTo: Ru
			}
		}
	};
}
function Lu(e, t, n) {
	let r = this, i = r.events.length, a = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), o;
	for (; i--;) {
		let e = r.events[i][1];
		if (e.type === "labelImage") {
			o = e;
			break;
		}
		if (e.type === "gfmFootnoteCall" || e.type === "labelLink" || e.type === "label" || e.type === "image" || e.type === "link") break;
	}
	return s;
	function s(i) {
		if (!o || !o._balanced) return n(i);
		let s = S(r.sliceSerialize({
			start: o.end,
			end: r.now()
		}));
		return s.codePointAt(0) !== 94 || !a.includes(s.slice(1)) ? n(i) : (e.enter("gfmFootnoteCallLabelMarker"), e.consume(i), e.exit("gfmFootnoteCallLabelMarker"), t(i));
	}
}
function Ru(e, t) {
	let n = e.length;
	for (; n--;) if (e[n][1].type === "labelImage" && e[n][0] === "enter") {
		e[n][1];
		break;
	}
	e[n + 1][1].type = "data", e[n + 3][1].type = "gfmFootnoteCallLabelMarker";
	let r = {
		type: "gfmFootnoteCall",
		start: Object.assign({}, e[n + 3][1].start),
		end: Object.assign({}, e[e.length - 1][1].end)
	}, i = {
		type: "gfmFootnoteCallMarker",
		start: Object.assign({}, e[n + 3][1].end),
		end: Object.assign({}, e[n + 3][1].end)
	};
	i.end.column++, i.end.offset++, i.end._bufferIndex++;
	let a = {
		type: "gfmFootnoteCallString",
		start: Object.assign({}, i.end),
		end: Object.assign({}, e[e.length - 1][1].start)
	}, o = {
		type: "chunkString",
		contentType: "string",
		start: Object.assign({}, a.start),
		end: Object.assign({}, a.end)
	}, s = [
		e[n + 1],
		e[n + 2],
		[
			"enter",
			r,
			t
		],
		e[n + 3],
		e[n + 4],
		[
			"enter",
			i,
			t
		],
		[
			"exit",
			i,
			t
		],
		[
			"enter",
			a,
			t
		],
		[
			"enter",
			o,
			t
		],
		[
			"exit",
			o,
			t
		],
		[
			"exit",
			a,
			t
		],
		e[e.length - 2],
		e[e.length - 1],
		[
			"exit",
			r,
			t
		]
	];
	return e.splice(n, e.length - n + 1, ...s), e;
}
function zu(e, t, n) {
	let r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), a = 0, o;
	return s;
	function s(t) {
		return e.enter("gfmFootnoteCall"), e.enter("gfmFootnoteCallLabelMarker"), e.consume(t), e.exit("gfmFootnoteCallLabelMarker"), c;
	}
	function c(t) {
		return t === 94 ? (e.enter("gfmFootnoteCallMarker"), e.consume(t), e.exit("gfmFootnoteCallMarker"), e.enter("gfmFootnoteCallString"), e.enter("chunkString").contentType = "string", l) : n(t);
	}
	function l(s) {
		if (a > 999 || s === 93 && !o || s === null || s === 91 || m(s)) return n(s);
		if (s === 93) {
			e.exit("chunkString");
			let a = e.exit("gfmFootnoteCallString");
			return i.includes(S(r.sliceSerialize(a))) ? (e.enter("gfmFootnoteCallLabelMarker"), e.consume(s), e.exit("gfmFootnoteCallLabelMarker"), e.exit("gfmFootnoteCall"), t) : n(s);
		}
		return m(s) || (o = !0), a++, e.consume(s), s === 92 ? u : l;
	}
	function u(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), a++, l) : l(t);
	}
}
function Bu(e, t, n) {
	let r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), a, o = 0, s;
	return c;
	function c(t) {
		return e.enter("gfmFootnoteDefinition")._container = !0, e.enter("gfmFootnoteDefinitionLabel"), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionLabelMarker"), l;
	}
	function l(t) {
		return t === 94 ? (e.enter("gfmFootnoteDefinitionMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionMarker"), e.enter("gfmFootnoteDefinitionLabelString"), e.enter("chunkString").contentType = "string", u) : n(t);
	}
	function u(t) {
		if (o > 999 || t === 93 && !s || t === null || t === 91 || m(t)) return n(t);
		if (t === 93) {
			e.exit("chunkString");
			let n = e.exit("gfmFootnoteDefinitionLabelString");
			return a = S(r.sliceSerialize(n)), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionLabelMarker"), e.exit("gfmFootnoteDefinitionLabel"), p;
		}
		return m(t) || (s = !0), o++, e.consume(t), t === 92 ? d : u;
	}
	function d(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), o++, u) : u(t);
	}
	function p(t) {
		return t === 58 ? (e.enter("definitionMarker"), e.consume(t), e.exit("definitionMarker"), i.includes(a) || i.push(a), f(e, h, "gfmFootnoteDefinitionWhitespace")) : n(t);
	}
	function h(e) {
		return t(e);
	}
}
function Vu(e, t, n) {
	return e.check(g, t, e.attempt(Fu, t, n));
}
function Hu(e) {
	e.exit("gfmFootnoteDefinition");
}
function Uu(e, t, n) {
	let r = this;
	return f(e, i, "gfmFootnoteDefinitionIndent", 5);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return i && i[1].type === "gfmFootnoteDefinitionIndent" && i[2].sliceSerialize(i[1], !0).length === 4 ? t(e) : n(e);
	}
}
// node_modules/micromark-extension-gfm-strikethrough/lib/syntax.js
function Wu(e) {
	let t = (e || {}).singleTilde, n = {
		name: "strikethrough",
		tokenize: i,
		resolveAll: r
	};
	return t ??= !0, {
		text: { 126: n },
		insideSpan: { null: [n] },
		attentionMarkers: { null: [126] }
	};
	function r(e, t) {
		let n = -1;
		for (; ++n < e.length;) if (e[n][0] === "enter" && e[n][1].type === "strikethroughSequenceTemporary" && e[n][1]._close) {
			let r = n;
			for (; r--;) if (e[r][0] === "exit" && e[r][1].type === "strikethroughSequenceTemporary" && e[r][1]._open && e[n][1].end.offset - e[n][1].start.offset === e[r][1].end.offset - e[r][1].start.offset) {
				e[n][1].type = "strikethroughSequence", e[r][1].type = "strikethroughSequence";
				let i = {
					type: "strikethrough",
					start: Object.assign({}, e[r][1].start),
					end: Object.assign({}, e[n][1].end)
				}, a = {
					type: "strikethroughText",
					start: Object.assign({}, e[r][1].end),
					end: Object.assign({}, e[n][1].start)
				}, s = [
					[
						"enter",
						i,
						t
					],
					[
						"enter",
						e[r][1],
						t
					],
					[
						"exit",
						e[r][1],
						t
					],
					[
						"enter",
						a,
						t
					]
				], c = t.parser.constructs.insideSpan.null;
				c && o(s, s.length, 0, v(c, e.slice(r + 1, n), t)), o(s, s.length, 0, [
					[
						"exit",
						a,
						t
					],
					[
						"enter",
						e[n][1],
						t
					],
					[
						"exit",
						e[n][1],
						t
					],
					[
						"exit",
						i,
						t
					]
				]), o(e, r - 1, n - r + 3, s), n = r + s.length - 2;
				break;
			}
		}
		for (n = -1; ++n < e.length;) e[n][1].type === "strikethroughSequenceTemporary" && (e[n][1].type = "data");
		return e;
	}
	function i(e, n, r) {
		let i = this.previous, a = this.events, o = 0;
		return s;
		function s(t) {
			return i === 126 && a[a.length - 1][1].type !== "characterEscape" ? r(t) : (e.enter("strikethroughSequenceTemporary"), c(t));
		}
		function c(a) {
			let s = u(i);
			if (a === 126) return o > 1 ? r(a) : (e.consume(a), o++, c);
			if (o < 2 && !t) return r(a);
			let l = e.exit("strikethroughSequenceTemporary"), d = u(a);
			return l._open = !d || d === 2 && !!s, l._close = !s || s === 2 && !!d, n(a);
		}
	}
}
// node_modules/micromark-extension-gfm-table/lib/edit-map.js
var Gu = class {
	constructor() {
		this.map = [], this.index = /* @__PURE__ */ new Map();
	}
	add(e, t, n) {
		Ku(this, e, t, n);
	}
	consume(e) {
		/* c8 ignore next 3 -- `resolve` is never called without tables, so without edits. */
		if (this.map.sort(function(e, t) {
			return e[0] - t[0];
		}), this.map.length === 0) return;
		let t = this.map.length, n = [];
		for (; t > 0;) --t, n.push(e.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), e.length = this.map[t][0];
		n.push(e.slice()), e.length = 0;
		let r = n.pop();
		for (; r;) {
			for (let t of r) e.push(t);
			r = n.pop();
		}
		this.map.length = 0, this.index.clear();
	}
};
function Ku(e, t, n, r) {
	/* c8 ignore next 3 -- `resolve` is never called without tables, so without edits. */
	if (n === 0 && r.length === 0) return;
	let i = e.index.get(t);
	if (i) {
		i[1] += n, i[2].push(...r);
		return;
	}
	let a = [
		t,
		n,
		r
	];
	e.map.push(a), e.index.set(t, a);
}
// node_modules/micromark-extension-gfm-table/lib/infer.js
function qu(e, t) {
	let n = !1, r = [];
	for (; t < e.length;) {
		let i = e[t];
		if (n) {
			if (i[0] === "enter") i[1].type === "tableContent" && r.push(e[t + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
			else if (i[1].type === "tableContent") {
				if (e[t - 1][1].type === "tableDelimiterMarker") {
					let e = r.length - 1;
					r[e] = r[e] === "left" ? "center" : "right";
				}
			} else if (i[1].type === "tableDelimiterRow") break;
		} else i[0] === "enter" && i[1].type === "tableDelimiterRow" && (n = !0);
		t += 1;
	}
	return r;
}
// node_modules/micromark-extension-gfm-table/lib/syntax.js
function Ju() {
	return { flow: { null: {
		name: "table",
		tokenize: Yu,
		resolveAll: Xu
	} } };
}
function Yu(e, t, n) {
	let r = this, i = 0, a = 0, o;
	return s;
	function s(e) {
		let t = r.events.length - 1;
		for (; t > -1;) {
			let { type: e } = r.events[t][1];
			if (e === "lineEnding" || e === "linePrefix") t--;
			else break;
		}
		let i = t > -1 ? r.events[t][1].type : null, a = i === "tableHead" || i === "tableRow" ? te : c;
		return a === te && r.parser.lazy[r.now().line] ? n(e) : a(e);
	}
	function c(t) {
		return e.enter("tableHead"), e.enter("tableRow"), l(t);
	}
	function l(e) {
		return e === 124 || (o = !0, a += 1), u(e);
	}
	function u(t) {
		return t === null ? n(t) : d(t) ? a > 1 ? (a = 0, r.interrupt = !0, e.exit("tableRow"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), g) : n(t) : T(t) ? f(e, u, "whitespace")(t) : (a += 1, o && (o = !1, i += 1), t === 124 ? (e.enter("tableCellDivider"), e.consume(t), e.exit("tableCellDivider"), o = !0, u) : (e.enter("data"), p(t)));
	}
	function p(t) {
		return t === null || t === 124 || m(t) ? (e.exit("data"), u(t)) : (e.consume(t), t === 92 ? h : p);
	}
	function h(t) {
		return t === 92 || t === 124 ? (e.consume(t), p) : p(t);
	}
	function g(t) {
		return r.interrupt = !1, r.parser.lazy[r.now().line] ? n(t) : (e.enter("tableDelimiterRow"), o = !1, T(t) ? f(e, _, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : _(t));
	}
	function _(t) {
		return t === 45 || t === 58 ? y(t) : t === 124 ? (o = !0, e.enter("tableCellDivider"), e.consume(t), e.exit("tableCellDivider"), v) : C(t);
	}
	function v(t) {
		return T(t) ? f(e, y, "whitespace")(t) : y(t);
	}
	function y(t) {
		return t === 58 ? (a += 1, o = !0, e.enter("tableDelimiterMarker"), e.consume(t), e.exit("tableDelimiterMarker"), ee) : t === 45 ? (a += 1, ee(t)) : t === null || d(t) ? S(t) : C(t);
	}
	function ee(t) {
		return t === 45 ? (e.enter("tableDelimiterFiller"), b(t)) : C(t);
	}
	function b(t) {
		return t === 45 ? (e.consume(t), b) : t === 58 ? (o = !0, e.exit("tableDelimiterFiller"), e.enter("tableDelimiterMarker"), e.consume(t), e.exit("tableDelimiterMarker"), x) : (e.exit("tableDelimiterFiller"), x(t));
	}
	function x(t) {
		return T(t) ? f(e, S, "whitespace")(t) : S(t);
	}
	function S(n) {
		return n === 124 ? _(n) : n === null || d(n) ? !o || i !== a ? C(n) : (e.exit("tableDelimiterRow"), e.exit("tableHead"), t(n)) : C(n);
	}
	function C(e) {
		return n(e);
	}
	function te(t) {
		return e.enter("tableRow"), ne(t);
	}
	function ne(n) {
		return n === 124 ? (e.enter("tableCellDivider"), e.consume(n), e.exit("tableCellDivider"), ne) : n === null || d(n) ? (e.exit("tableRow"), t(n)) : T(n) ? f(e, ne, "whitespace")(n) : (e.enter("data"), w(n));
	}
	function w(t) {
		return t === null || t === 124 || m(t) ? (e.exit("data"), ne(t)) : (e.consume(t), t === 92 ? re : w);
	}
	function re(t) {
		return t === 92 || t === 124 ? (e.consume(t), w) : w(t);
	}
}
function Xu(e, t) {
	let n = -1, r = !0, i = 0, a = [
		0,
		0,
		0,
		0
	], o = [
		0,
		0,
		0,
		0
	], s = !1, c = 0, l, u, d, f = new Gu();
	for (; ++n < e.length;) {
		let p = e[n], m = p[1];
		p[0] === "enter" ? m.type === "tableHead" ? (s = !1, c !== 0 && (Qu(f, t, c, l, u), u = void 0, c = 0), l = {
			type: "table",
			start: Object.assign({}, m.start),
			end: Object.assign({}, m.end)
		}, f.add(n, 0, [[
			"enter",
			l,
			t
		]])) : m.type === "tableRow" || m.type === "tableDelimiterRow" ? (r = !0, d = void 0, a = [
			0,
			0,
			0,
			0
		], o = [
			0,
			n + 1,
			0,
			0
		], s && (s = !1, u = {
			type: "tableBody",
			start: Object.assign({}, m.start),
			end: Object.assign({}, m.end)
		}, f.add(n, 0, [[
			"enter",
			u,
			t
		]])), i = m.type === "tableDelimiterRow" ? 2 : u ? 3 : 1) : i && (m.type === "data" || m.type === "tableDelimiterMarker" || m.type === "tableDelimiterFiller") ? (r = !1, o[2] === 0 && (a[1] !== 0 && (o[0] = o[1], d = Zu(f, t, a, i, void 0, d), a = [
			0,
			0,
			0,
			0
		]), o[2] = n)) : m.type === "tableCellDivider" && (r ? r = !1 : (a[1] !== 0 && (o[0] = o[1], d = Zu(f, t, a, i, void 0, d)), a = o, o = [
			a[1],
			n,
			0,
			0
		])) : m.type === "tableHead" ? (s = !0, c = n) : m.type === "tableRow" || m.type === "tableDelimiterRow" ? (c = n, a[1] === 0 ? o[1] !== 0 && (d = Zu(f, t, o, i, n, d)) : (o[0] = o[1], d = Zu(f, t, a, i, n, d)), i = 0) : i && (m.type === "data" || m.type === "tableDelimiterMarker" || m.type === "tableDelimiterFiller") && (o[3] = n);
	}
	for (c !== 0 && Qu(f, t, c, l, u), f.consume(t.events), n = -1; ++n < t.events.length;) {
		let e = t.events[n];
		e[0] === "enter" && e[1].type === "table" && (e[1]._align = qu(t.events, n));
	}
	return e;
}
function Zu(e, t, n, r, i, a) {
	let o = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData";
	n[0] !== 0 && (a.end = Object.assign({}, $u(t.events, n[0])), e.add(n[0], 0, [[
		"exit",
		a,
		t
	]]));
	let s = $u(t.events, n[1]);
	if (a = {
		type: o,
		start: Object.assign({}, s),
		end: Object.assign({}, s)
	}, e.add(n[1], 0, [[
		"enter",
		a,
		t
	]]), n[2] !== 0) {
		let i = $u(t.events, n[2]), a = $u(t.events, n[3]), o = {
			type: "tableContent",
			start: Object.assign({}, i),
			end: Object.assign({}, a)
		};
		if (e.add(n[2], 0, [[
			"enter",
			o,
			t
		]]), r !== 2) {
			let r = t.events[n[2]], i = t.events[n[3]];
			if (r[1].end = Object.assign({}, i[1].end), r[1].type = "chunkText", r[1].contentType = "text", n[3] > n[2] + 1) {
				let t = n[2] + 1, r = n[3] - n[2] - 1;
				e.add(t, r, []);
			}
		}
		e.add(n[3] + 1, 0, [[
			"exit",
			o,
			t
		]]);
	}
	return i !== void 0 && (a.end = Object.assign({}, $u(t.events, i)), e.add(i, 0, [[
		"exit",
		a,
		t
	]]), a = void 0), a;
}
function Qu(e, t, n, r, i) {
	let a = [], o = $u(t.events, n);
	i && (i.end = Object.assign({}, o), a.push([
		"exit",
		i,
		t
	])), r.end = Object.assign({}, o), a.push([
		"exit",
		r,
		t
	]), e.add(n + 1, 0, a);
}
function $u(e, t) {
	let n = e[t], r = n[0] === "enter" ? "start" : "end";
	return n[1][r];
}
// node_modules/micromark-extension-gfm-task-list-item/lib/syntax.js
var ed = {
	name: "tasklistCheck",
	tokenize: nd
};
function td() {
	return { text: { 91: ed } };
}
function nd(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return r.previous !== null || !r._gfmTasklistFirstContentOfListItem ? n(t) : (e.enter("taskListCheck"), e.enter("taskListCheckMarker"), e.consume(t), e.exit("taskListCheckMarker"), a);
	}
	function a(t) {
		return m(t) ? (e.enter("taskListCheckValueUnchecked"), e.consume(t), e.exit("taskListCheckValueUnchecked"), o) : t === 88 || t === 120 ? (e.enter("taskListCheckValueChecked"), e.consume(t), e.exit("taskListCheckValueChecked"), o) : n(t);
	}
	function o(t) {
		return t === 93 ? (e.enter("taskListCheckMarker"), e.consume(t), e.exit("taskListCheckMarker"), e.exit("taskListCheck"), s) : n(t);
	}
	function s(r) {
		return d(r) ? t(r) : T(r) ? e.check({ tokenize: rd }, t, n)(r) : n(r);
	}
}
function rd(e, t, n) {
	return f(e, r, "whitespace");
	function r(e) {
		return e === null ? n(e) : t(e);
	}
}
// node_modules/micromark-extension-gfm/index.js
function id(e) {
	return te([
		bu(),
		Iu(),
		Wu(e),
		Ju(),
		td()
	]);
}
// node_modules/remark-gfm/lib/index.js
var ad = {};
function od(e) {
	let t = this, n = e || ad, r = t.data(), i = r.micromarkExtensions ||= [], a = r.fromMarkdownExtensions ||= [], o = r.toMarkdownExtensions ||= [];
	i.push(id(n)), a.push(lu()), o.push(uu(n));
}
// src/local/html/html-entities.ts
function sd(e, t = !1) {
	let n = (e) => t ? e.replace(/\u0000/g, "�") : e;
	if (!e.includes("&")) return n(e);
	try {
		let t = ki(n(e).replace(/</g, "&lt;"), { scriptingEnabled: !1 }), r = "", i = (e) => {
			if (e.nodeName === "#text") r += e.value;
			else {
				for (let t of e.childNodes ?? []) i(t);
				if (e.content?.childNodes) for (let t of e.content.childNodes) i(t);
			}
		};
		for (let e of t.childNodes) i(e);
		return n(r);
	} catch {
		return n(e);
	}
}
function cd(e) {
	let t = e.replace(/\u0000/g, "�");
	if (!t.includes("&")) return t;
	try {
		return ki(`<x a="${t.replace(/"/g, "&quot;")}">`, { scriptingEnabled: !1 }).childNodes[0]?.attrs?.find((e) => e.name === "a")?.value ?? t;
	} catch {
		return t;
	}
}
// src/local/html/html-recovery.ts
var ld = N.HTML, ud = /* @__PURE__ */ new Set([
	"html",
	"head",
	"body"
]), dd = w, fd = {
	table: [
		"caption",
		"colgroup",
		"thead",
		"tbody",
		"tfoot"
	],
	colgroup: ["col"],
	thead: ["tr"],
	tbody: ["tr"],
	tfoot: ["tr"],
	tr: ["th", "td"],
	col: []
}, pd = 100;
function md(t, n, r, i, a) {
	let o = a === void 0 ? null : a.toLowerCase();
	if (o !== null && !e.has(o) && !w.has(o)) return null;
	let s = o !== null && dd.has(o), u = [], d = null, f = s, p = n;
	for (; p < r;) {
		let n = t.indexOf("<", p), a = n < 0 || n >= r ? r : n;
		if (t.slice(p, a).includes("{{")) return null;
		if (n < 0 || n >= r) break;
		if (p = n, t.startsWith("<!--", p)) {
			p = l(t, p, r);
			continue;
		}
		let o = /^<(\/?)([A-Za-z][A-Za-z0-9:-]*)/.exec(t.slice(p, Math.min(r, p + 80)));
		if (!o) {
			p += 1;
			continue;
		}
		let m = p + o[0].length, h = t[m];
		if (!(h === ">" || h === "/" || h !== void 0 && /\s/.test(h))) {
			p = m;
			continue;
		}
		let g = o[2].toLowerCase(), _ = o[1] === "/", v = c(t, m, r);
		if (v < 0) return null;
		let y = {
			name: g,
			closing: _,
			self: !_ && /\/\s*$/.test(t.slice(m, v - 1)),
			start: p,
			end: v
		};
		if (i.has(g)) return null;
		if (_) {
			if (g !== "table" && !w.has(g) && !e.has(g) || g !== "table" && w.has(g) && !s && !u.some((e) => e.name === "table")) return null;
			let t = -1;
			for (let e = u.length - 1; e >= 0; --e) if (u[e].name === g) {
				t = e;
				break;
			}
			t >= 0 ? u.length = t : d ??= y, p = y.end;
		} else {
			if (g === "table") f = !0;
			else if (w.has(g)) {
				if (!s && !u.some((e) => e.name === "table")) return null;
			} else if (!e.has(g)) return null;
			if (ud.has(g)) return null;
			if (!ie.has(g) && !y.self) {
				if (g === "code" || g === "pre") {
					let e = RegExp(`</${g}\\s*>`, "gi");
					e.lastIndex = y.end;
					let n = e.exec(t);
					if (n && n.index < r) {
						p = n.index + n[0].length;
						continue;
					}
					u.push(y), p = r;
					continue;
				}
				u.push(y);
			}
			p = y.end;
		}
	}
	return u.length > 0 ? {
		tableMode: f,
		contextTag: o,
		strayClose: d,
		unclosed: u[0]
	} : {
		tableMode: f,
		contextTag: o,
		strayClose: d,
		unclosed: null
	};
}
function hd(e, t) {
	let n = {};
	for (let r of t.attrs) {
		if (r.prefix || r.namespace || r.value.includes("{{")) return null;
		let t = r.name.toLowerCase();
		if (!_(e, t)) return null;
		if (t === "align" && i.has(e)) {
			let t = b(e, r.value);
			if (!t) return null;
			n.align = t;
		} else {
			if (!re(t, r.value)) return null;
			n[t] = r.value;
		}
	}
	return e === "details" && Object.hasOwn(n, "open") && (n.open = "true"), n;
}
function gd(t, n, r, i, a, o) {
	if (!Number.isInteger(n) || !Number.isInteger(r) || n < 0 || r > t.length || r <= n) return null;
	let s = md(t, n, r, a, o);
	if (s === null) return null;
	let c = r - n, l = (e) => Math.max(0, Math.min(c, e)), u = (e) => n + l(e), d = [], f = [];
	s.strayClose && d.push({
		start: s.strayClose.start,
		end: s.strayClose.end
	}), s.unclosed && d.push({
		start: s.unclosed.start,
		end: s.unclosed.end
	});
	let p = s.tableMode, m = {
		scriptingEnabled: !1,
		sourceCodeLocationInfo: !0
	}, h = t.slice(n, r), g = s.contextTag === null ? ki(h, m) : ki(B.createElement(s.contextTag, ld, []), h, m);
	function _(e) {
		if (!Number.isInteger(e.startOffset) || !Number.isInteger(e.endOffset)) return null;
		let t = u(e.startOffset), n = u(e.endOffset);
		return n < t ? null : {
			start: t,
			end: n
		};
	}
	function v(e) {
		if (e.length === 0) return null;
		let t = Infinity, i = -Infinity;
		for (let n of e) t = Math.min(t, n.range.start), i = Math.max(i, n.range.end);
		return {
			start: Math.max(n, t),
			end: Math.min(r, Math.max(t, i))
		};
	}
	function y(e, t) {
		return v(e) ?? {
			start: Math.max(n, Math.min(r, t)),
			end: Math.max(n, Math.min(r, t))
		};
	}
	function b(e, t) {
		e.synthetic = !0, e.syntheticBoundary = {
			start: t.start,
			end: t.end
		}, f.push({
			start: t.start,
			end: t.end
		});
	}
	function x(e, t) {
		let n = t;
		if (e === "details") {
			let e = n.findIndex((e) => e.type === "summary");
			if (e > 0) {
				let [t] = n.splice(e, 1);
				n.unshift(t);
			}
			return n;
		}
		if (e === "li" && n.length === 1 && n[0].type === "paragraph") return n[0].children ?? [];
		if (e === "ul" || e === "ol") {
			let e = n.filter((e) => !(e.type === "comment" || e.type === "text" && !(e.value ?? "").trim()));
			return e.every((e) => e.type === "listItem") ? e : null;
		}
		return n;
	}
	function S(e, t, n, r) {
		let i = [], a = -Infinity;
		for (let t of e.childNodes) {
			let e = C(t, n + 1, r);
			if (e === null) return null;
			if (e !== void 0) {
				if (e.range.start < a) return null;
				a = e.range.end, i.push(e);
			}
		}
		return x(t, i);
	}
	function C(e, t, n) {
		if (B.isTextNode(e)) {
			let t = e.sourceCodeLocation;
			if (!t) return null;
			let n = _(t);
			return n === null ? null : n.start === n.end ? void 0 : e.value.includes("{{") ? null : i("text", n.start, n.end, { value: e.value.replace(/\u0000/g, "�") });
		}
		if (B.isCommentNode(e)) {
			let t = e.sourceCodeLocation;
			if (!t) return null;
			let n = _(t);
			return n === null ? null : i("comment", n.start, n.end);
		}
		return B.isElementNode(e) ? ne(e, t, n) : null;
	}
	function te(e, t, n) {
		let r = {
			attrs: t,
			children: n
		};
		if (e === "a") return t.href === void 0 ? r.type = "span" : (r.type = "link", r.url = t.href, r.title = t.title ?? null), r;
		if (/^h[1-6]$/.test(e)) return r.type = "heading", r.depth = Number(e.slice(1)), r;
		if (e === "ul" || e === "ol") {
			r.type = "list", r.ordered = e === "ol";
			let n = t.start === void 0 ? void 0 : Number(t.start);
			return e === "ol" && n !== void 0 && Number.isFinite(n) && (r.start = n), r;
		}
		return r.type = e === "p" ? "paragraph" : e === "div" ? "div" : e === "blockquote" ? "blockquote" : e === "details" ? "details" : e === "li" ? "listItem" : ee[e] ?? e, r;
	}
	function ne(n, r, a) {
		if (r > pd || n.namespaceURI !== ld) return null;
		let o = n.tagName.toLowerCase();
		if (ud.has(o) || !e.has(o) && !(p && w.has(o))) return null;
		let s = n.sourceCodeLocation, c = !s, l = hd(o, n);
		if (l === null) return null;
		if (o === "br" || o === "hr" || o === "img") {
			if (!s) return null;
			let e = _(s);
			if (e === null) return null;
			if (o === "br") return i("break", e.start, e.end, { attrs: l });
			if (o === "hr") return i("thematicBreak", e.start, e.end, { attrs: l });
			let t = l.width === void 0 ? void 0 : Number(l.width), n = l.height === void 0 ? void 0 : Number(l.height);
			return i("image", e.start, e.end, {
				attrs: l,
				url: l.src,
				alt: l.alt ?? "",
				title: l.title ?? null,
				...t === void 0 ? {} : { width: t },
				...n === void 0 ? {} : { height: n }
			});
		}
		if (o === "code" || o === "pre") {
			if (!s || !s.startTag) return null;
			let e = _(s);
			if (e === null) return null;
			let n = u(s.startTag.endOffset), r = s.endTag ? u(s.endTag.startOffset) : u(s.endOffset);
			if (r < n) return null;
			let a = t.slice(n, r);
			if (s.endTag === void 0 && d.push({
				start: u(s.startTag.startOffset),
				end: u(s.startTag.endOffset)
			}), o === "pre") {
				let t = /^<code(?:\s[^>]*)?>([\s\S]*)<\/code>$/.exec(a);
				return i("code", e.start, e.end, {
					attrs: l,
					value: sd(t ? t[1] : a, !0)
				});
			}
			return i("inlineCode", e.start, e.end, {
				attrs: l,
				value: sd(a, !0)
			});
		}
		if (w.has(o)) return T(n, o, l, r, a, s);
		let f = S(n, o, r, a);
		if (f === null) return null;
		let m = te(o, l, f), h;
		if (c) h = y(f, a), b(m, h);
		else {
			let e = _(s);
			if (e === null) return null;
			h = e, !s?.endTag && s?.startTag && d.push({
				start: u(s.startTag.startOffset),
				end: u(s.startTag.endOffset)
			});
		}
		return i(m.type ?? o, h.start, h.end, m);
	}
	function re(e, t, n, r) {
		let i = fd[t];
		if (i === void 0) return null;
		let a = [], o = -Infinity;
		for (let t of e.childNodes) {
			if (B.isTextNode(t)) {
				if (!t.value.trim()) continue;
				return null;
			}
			if (B.isCommentNode(t)) continue;
			if (!B.isElementNode(t) || t.namespaceURI !== ld) return null;
			let e = t.tagName.toLowerCase();
			if (!i.includes(e)) return null;
			let s = hd(e, t);
			if (s === null) return null;
			let c = T(t, e, s, n + 1, r, t.sourceCodeLocation);
			if (c === null || c.range.start < o) return null;
			o = c.range.end, a.push(c);
		}
		return a;
	}
	function T(e, t, n, r, a, o) {
		if (r > pd) return null;
		let s = !o, c;
		if (c = t === "td" || t === "th" || t === "caption" ? S(e, t, r, a) : re(e, t, r, a), c === null) return null;
		let l, f = t === "table" ? {
			attrs: n,
			children: c
		} : {
			attrs: n,
			children: c,
			name: t
		};
		if (s) l = y(c, a), b(f, l);
		else {
			let e = _(o);
			if (e === null) return null;
			l = e, !o?.endTag && !ie.has(t) && o?.startTag && d.push({
				start: u(o.startTag.startOffset),
				end: u(o.startTag.endOffset)
			});
		}
		return i(t === "table" ? "htmlTable" : "htmlTableElement", l.start, l.end, f);
	}
	let ae = [], oe = -Infinity;
	for (let e of g.childNodes) {
		let t = C(e, 0, n);
		if (t === null) return null;
		if (t !== void 0) {
			if (t.range.start < oe || t.range.start < n || t.range.end > r) return null;
			oe = t.range.end, ae.push(t);
		}
	}
	if (ae.length === 0 || !ae.some((e) => !(e.type === "comment" || e.type === "text" && !(e.value ?? "").trim()))) return null;
	d.sort((e, t) => e.start - t.start || e.end - t.end), f.sort((e, t) => e.start - t.start || e.end - t.end);
	let E = d[0] ?? f[0], D = E === void 0 ? n : Math.max(n, Math.min(r, E.start));
	return {
		nodes: ae,
		recovery: {
			code: "local.html.repair",
			causeRange: {
				start: D,
				end: E === void 0 ? D : Math.max(D, Math.min(r, E.end))
			},
			affectedRange: {
				start: n,
				end: r
			},
			action: "html-repair",
			boundary: "fragment"
		},
		end: r
	};
}
// src/local/parsing/parser-standard.ts
var _d = Os.configure(Ks);
function vd(e) {
	let t;
	try {
		t = _d.parse(e.replace(/\r(?!\n)/g, "\n"));
	} catch {
		return {
			candidates: [],
			maxDepth: 0,
			codeRanges: []
		};
	}
	let n = [];
	for (let e = t.topNode.firstChild; e; e = e.nextSibling) n.push({
		from: e.from,
		to: e.to,
		type: e.type.name
	});
	let r = 0, i = 0, a = [], o = /* @__PURE__ */ new Set([
		"Blockquote",
		"BulletList",
		"OrderedList"
	]);
	return t.iterate({
		enter(e) {
			o.has(e.name) && (r++, i = Math.max(i, r)), (e.name === "FencedCode" || e.name === "CodeBlock") && a.push({
				start: e.from,
				end: e.to
			});
		},
		leave(e) {
			o.has(e.name) && r--;
		}
	}), {
		candidates: n,
		maxDepth: i,
		codeRanges: a
	};
}
var yd = Object.freeze({
	markdownPlugins: Object.freeze([od]),
	html: Object.freeze({
		nativeTagNames: new Set(Object.values(F)),
		decodeEntities: (e) => sd(e, !0),
		decodeAttribute: cd,
		readTable: Ni,
		recoverFragment: gd
	}),
	markdownStructure: vd
});
export { sa as a, ki as c, B as d, Xa as i, yi as l, Ks as n, Sa as o, Os as r, Oi as s, yd as t, bi as u };
