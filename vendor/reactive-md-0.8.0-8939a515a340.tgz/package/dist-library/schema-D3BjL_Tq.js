import "./preset-core-CKc5YXSM.js";
import { b as e, y as t } from "./config-validation-C5kJYk-J.js";
import { c as n } from "./compiler-core-DTxY-qYz.js";
import { t as r } from "./registry-core-Bbad9Bm2.js";
import { r as i } from "./default-components-CGsBNWCT.js";
import { n as a } from "./options-BbrCscOF.js";
// src/local/parsing/parser.ts
function o(e, t, r, i, o) {
	return typeof e != "string" || e.length > 1e6 ? n(e, void 0, r, i, o) : n(e, a(t), r, i, o);
}
// src/local/configuration/schema.ts
function s() {
	let e = i.map(r), n = e.findIndex((e) => e.name === "validation"), a = n < 0 ? e.length : n;
	return Object.freeze([
		...e.slice(0, a),
		...t,
		...e.slice(a)
	]);
}
var c = s(), l = Object.freeze(Object.fromEntries(c.map((e) => [e.name, Object.freeze(e)]))), u = Object.freeze(c.map((e) => e.name)), d = Object.freeze({
	leaf: Object.freeze(c.filter((e) => e.form === "leaf").map((e) => e.name)),
	inline: Object.freeze(c.filter((e) => e.form === "inline").map((e) => e.name)),
	container: Object.freeze(c.filter((e) => e.form === "container").map((e) => e.name))
});
function f(e) {
	return d[e];
}
function p(e) {
	return Object.hasOwn(l, e) ? l[e] : void 0;
}
function m(e, t) {
	return e.props[t]?.default;
}
function h(t) {
	return e(t, u);
}
function g(t, n) {
	return e(n, Object.keys(t.props));
}
export { f as a, o as c, m as i, u as n, g as o, p as r, h as s, l as t };
