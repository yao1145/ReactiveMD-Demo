import { L as e, n as t, r as n, t as r } from "./identity-D1cB_NI3.js";
import { t as i } from "./default-components-BdkPID3o.js";
// src/presets/default.ts
var a = n({
	protocol: e,
	id: r,
	version: t,
	components: i
});
export { a as default, a as defaultPreset };
