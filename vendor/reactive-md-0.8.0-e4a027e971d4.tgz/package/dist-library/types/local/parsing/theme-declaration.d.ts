interface ThemeTag {
    start: number;
    end: number;
    rest: string;
    closing: boolean;
    selfClosing: boolean;
    unclosed: boolean;
}
/** Cheap pre-check so ordinary `<` characters never pay for a tag scan. */
export declare function isThemeTagAt(source: string, index: number): boolean;
export declare function themeTagAt(source: string, start: number, limit: number): ThemeTag | null;
/** Whitespace, BOM and leading comments may precede the declaration. */
export declare function skipThemePrefix(source: string, from: number, to: number): number;
export declare function standaloneTheme(source: string, tag: ThemeTag): boolean;
export declare function themeNameFrom(rest: string): {
    name?: string;
    code?: string;
    key?: string;
    params?: Record<string, string | number>;
    message?: string;
};
export {};
