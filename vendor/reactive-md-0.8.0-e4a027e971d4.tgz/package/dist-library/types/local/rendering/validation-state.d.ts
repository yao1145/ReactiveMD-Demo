import type { LocalDocument, LocalNode, LocalRuntime } from '../contracts/types.js';
export interface LocalValidationHint {
    /** Per-document-instance id, kept stable for every rule state. */
    id: string;
    failed: boolean;
    error: boolean;
    message: string;
}
export interface LocalValidationField {
    describedBy?: string;
    invalid: boolean;
}
export interface LocalValidationState {
    /** The hint for a rendered `<validation>` tag, matched by tag range. */
    hintFor(node: LocalNode): LocalValidationHint | null;
    /** Current failing hints attached to a bound control/slot group. */
    fieldFor(node: LocalNode): LocalValidationField;
}
export type LocalizeValidation = (english: string, chinese: string) => string;
export declare const NO_VALIDATIONS: LocalValidationState;
/**
 * Project runtime validation results onto rule hints and their bound fields.
 * Rendering consumes this small model to set accessible hint and error props.
 */
export declare function createValidationState(document: LocalDocument, runtime: LocalRuntime, instanceId: string, t: LocalizeValidation): LocalValidationState;
