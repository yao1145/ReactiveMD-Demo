import { type RefObject } from 'react';
import type { LocalColorScheme } from '../theme/theme.js';
type ResolvedColorScheme = 'light' | 'dark';
/**
 * Resolve the effective mode for one document instance. Server rendering and
 * the hydration pass always start light so markup matches; the client effect
 * then follows the nearest host attribute and the OS, observing both.
 */
export declare function useResolvedColorScheme(rootRef: RefObject<HTMLElement | null>, requested: LocalColorScheme): ResolvedColorScheme;
export {};
