import { j as e, k as t } from "./version-DAxuGOG2.js";
import { _ as n, s as r } from "./document-theme-C8J6UyNO.js";
import { B as i, C as a, D as o, E as s, I as c, L as l, M as u, N as d, O as f, P as p, R as m, T as h, U as g, V as _, _ as v, b as y, c as b, f as x, g as S, h as C, j as w, k as T, l as E, m as D, s as O, u as k, w as A, y as j, z as M } from "./sdk-core-PbZXOq_H.js";
import { a as N, c as P, d as F, f as I, i as L, l as R, n as z, o as B, p as V, r as ee, s as H, t as U, u as te } from "./react-BbyAgeXc.js";
import * as W from "react";
import { Children as ne, createContext as G, createElement as re, forwardRef as K, isValidElement as ie, useCallback as ae, useContext as oe, useEffect as se, useId as ce, useInsertionEffect as le, useLayoutEffect as ue, useMemo as de, useRef as q, useState as J, useSyncExternalStore as fe } from "react";
import { Fragment as pe, jsx as Y, jsxs as X } from "react/jsx-runtime";
import * as me from "react-dom";
// node_modules/framer-motion/dist/es/utils/use-composed-ref.mjs
function he(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
function ge(...e) {
	return (t) => {
		let n = !1, r = e.map((e) => {
			let r = he(e, t);
			return !n && typeof r == "function" && (n = !0), r;
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				typeof n == "function" ? n() : he(e[t], null);
			}
		};
	};
}
function _e(...e) {
	return W.useCallback(ge(...e), e);
}
// node_modules/framer-motion/dist/es/components/AnimatePresence/PopChild.mjs
var ve = (e) => {
	let { width: t, height: n } = e?.getBoundingClientRect() || {};
	return [t / e?.offsetWidth || 1, n / e?.offsetHeight || 1];
}, ye = (e) => {
	let { left: t, top: n } = e.getBoundingClientRect(), r = e;
	for (; r = r.parentElement || r.parentNode?.host;) {
		let { scrollLeft: e, scrollTop: i } = r;
		if (e || i) {
			let [a, o] = ve(r);
			t += e * a, n += i * o;
		}
		if (getComputedStyle(r).position === "fixed") break;
	}
	let [i, a] = ve(e.offsetParent);
	return [t / i, n / a];
}, be = class extends W.Component {
	getSnapshotBeforeUpdate(e) {
		let t = this.props.getElement();
		if (R(t) && e.isPresent && !this.props.isPresent && this.props.pop !== !1) {
			let e = t.offsetParent, n = R(e) && e.offsetWidth || 0, r = R(e) && e.offsetHeight || 0, i = getComputedStyle(t), a = this.props.sizeRef.current;
			a.height = parseFloat(i.height), a.width = parseFloat(i.width), a.top = t.offsetTop, a.left = t.offsetLeft, a.right = n - a.width - a.left, a.bottom = r - a.height - a.top, a.direction = i.direction, a.point = ye(t);
		}
		return null;
	}
	componentDidUpdate() {}
	render() {
		return this.props.children;
	}
};
function xe({ children: e, isPresent: t, anchorX: n, anchorY: r, root: i, pop: a, popNode: o }) {
	let s = ce(), c = q(null), l = q({
		width: 0,
		height: 0,
		top: 0,
		left: 0,
		right: 0,
		bottom: 0,
		direction: "ltr"
	}), { nonce: u } = oe(H), d = _e(c, a === !1 ? void 0 : e.props?.ref ?? e?.ref), f = () => c.current || o?.current?.current, p = (e) => {
		let { width: t, height: i, top: a, left: o, right: c, bottom: u, direction: d } = l.current, f = d === "rtl", p = n === "left" ? f ? `right:${c}` : `left:${o}` : f ? `left:${o}` : `right:${c}`, m = r === "bottom" ? `bottom:${u}` : `top:${a}`;
		e?.insertRule(`[data-motion-pop-id="${s}"]{position:absolute!important;width:${t}px!important;height:${i}px!important;${p}px!important;${m}px!important}`);
	};
	return le(() => {
		let { width: e, height: n } = l.current, r = f();
		if (t || a === !1 || !r || !e || !n) return;
		r.dataset.motionPopId = s;
		let o = r.ownerDocument, c = o.createElement("style");
		u && (c.nonce = u);
		let d = i ?? o.head;
		d.appendChild(c), p(c.sheet);
		let m = 0, h = 0;
		return P.setup(() => {
			let [e, t] = ye(r);
			m = l.current.point[0] - e, h = l.current.point[1] - t;
		}), P.read(() => {
			let { sheet: e } = c;
			if (!e || !m && !h) return;
			let t = l.current;
			t.left += m, t.right -= m, t.top += h, t.bottom -= h, e.deleteRule(0), p(e);
		}), () => {
			r.removeAttribute("data-motion-pop-id"), d.contains(c) && d.removeChild(c);
		};
	}, [t]), Y(be, {
		isPresent: t,
		getElement: f,
		sizeRef: l,
		pop: a,
		children: a === !1 ? e : W.cloneElement(e, { ref: d })
	});
}
// node_modules/framer-motion/dist/es/components/AnimatePresence/PresenceChild.mjs
var Se = ({ children: e, initial: t, isPresent: n, onExitComplete: r, custom: i, presenceAffectsLayout: a, mode: o, anchorX: s, anchorY: c, root: l }) => {
	let u = I(Ce), d = ce(), f = q(), p = q(n), m = q(r);
	F(() => {
		p.current = n, m.current = r;
	});
	let h = !0, g = de(() => (h = !1, {
		id: d,
		initial: t,
		isPresent: n,
		custom: i,
		onExitComplete: (e) => {
			u.set(e, !0);
			for (let e of u.values()) if (!e) return;
			r && r();
		},
		register: (e, t) => (u.set(e, !1), t && t.parent?.presenceContext?.id !== d && (f.current = t), () => {
			u.delete(e), !p.current && !u.size && m.current?.();
		})
	}), [
		n,
		u,
		r
	]);
	return a && h && (g = { ...g }), de(() => {
		u.forEach((e, t) => u.set(t, !1));
	}, [n]), W.useEffect(() => {
		!n && !u.size && r && r();
	}, [n]), e = Y(xe, {
		pop: o === "popLayout",
		isPresent: n,
		anchorX: s,
		anchorY: c,
		root: l,
		popNode: f,
		children: e
	}), Y(te.Provider, {
		value: g,
		children: e
	});
};
function Ce() {
	return /* @__PURE__ */ new Map();
}
// node_modules/framer-motion/dist/es/components/AnimatePresence/utils.mjs
var we = (e) => e.key || "";
function Te(e) {
	let t = [];
	return ne.forEach(e, (e) => {
		ie(e) && t.push(e);
	}), t;
}
// node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs
var Ee = ({ children: e, custom: t, initial: n = !0, onExitComplete: r, presenceAffectsLayout: i = !0, mode: a = "sync", propagate: o = !1, anchorX: s = "left", anchorY: c = "top", root: l }) => {
	let [u, d] = B(o), f = de(() => Te(e), [e]), p = o && !u ? [] : f.map(we), m = q(!0), h = I(() => /* @__PURE__ */ new Map()), g = q(/* @__PURE__ */ new Set()), [_, v] = J(f), [y, b] = J(f);
	F(() => {
		o && !u && !y.length && d?.();
	}, [
		u,
		o,
		y.length,
		d
	]);
	let x = q();
	se(() => () => {
		let e = x.current;
		x.current = void 0, e?.();
	}, [y]), F(() => {
		m.current = !1;
		for (let e = 0; e < y.length; e++) {
			let t = we(y[e]);
			p.includes(t) ? (h.delete(t), g.current.delete(t)) : h.get(t) !== !0 && h.set(t, !1);
		}
	}, [
		y,
		p.length,
		p.join("-")
	]);
	let S = [];
	if (f !== _) {
		let e = [...f], t = 0;
		for (let n of y) {
			let r = p.indexOf(we(n));
			r === -1 ? (e.splice(t++, 0, n), S.push(n)) : t = r + S.length + 1;
		}
		return S.every((e) => h.get(we(e))) ? e = f : a === "wait" && (e = S), b(Te(e)), v(f), null;
	}
	process.env.NODE_ENV !== "production" && a === "wait" && y.length > 1 && console.warn("You're attempting to animate multiple children within AnimatePresence, but its mode is set to \"wait\". This will lead to odd visual behaviour.");
	let { forceRender: C } = oe(V);
	return Y(pe, { children: y.map((e) => {
		let _ = we(e), b = o && !u ? !1 : f === y || p.includes(_);
		return Y(Se, {
			isPresent: b,
			initial: !m.current || n ? void 0 : !1,
			custom: t,
			presenceAffectsLayout: i,
			mode: a,
			root: l,
			onExitComplete: b ? void 0 : () => {
				if (g.current.has(_)) return;
				if (h.has(_)) g.current.add(_), h.set(_, !0);
				else return;
				let e = !0;
				h.forEach((t) => {
					t || (e = !1);
				}), e && (C?.(), v([]), o && d?.(), x.current = r);
			},
			anchorX: s,
			anchorY: c,
			children: e
		}, _);
	}) });
};
// node_modules/framer-motion/dist/es/utils/use-motion-value-event.mjs
function De(e, t, n) {
	le(() => e.on(t, n), [
		e,
		t,
		n
	]);
}
// node_modules/lucide-react/dist/esm/shared/src/utils/toKebabCase.mjs
var Oe = (e) => e?.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
// node_modules/lucide-react/dist/esm/shared/src/utils/toLucideIconData.mjs
function ke(e, t, n = []) {
	if (t == null) throw Error("[lucide]: iconNode is required when icon name is used");
	return {
		name: Oe(e),
		size: 24,
		node: t,
		...n.length > 0 ? { aliases: n } : {}
	};
}
// node_modules/lucide-react/dist/esm/shared/src/utils/toCamelCase.mjs
var Ae = (e) => {
	let t = "", n = !1;
	for (let r of e) r === "-" || r === "_" || r <= " " ? n = t.length > 0 : (t.length === 0 ? t += r.toLowerCase() : t += n ? r.toUpperCase() : r, n = !1);
	return t;
}, je = (e) => {
	let t = Ae(e);
	return t.charAt(0).toUpperCase() + t.slice(1);
}, Me = (...e) => e.filter((e, t, n) => !!e && e.trim() !== "" && n.indexOf(e) === t).join(" ").trim(), Ne = {
	xmlns: "http://www.w3.org/2000/svg",
	width: 24,
	height: 24,
	viewBox: "0 0 24 24",
	fill: "none",
	stroke: "currentColor",
	"stroke-width": 2,
	"stroke-linecap": "round",
	"stroke-linejoin": "round"
};
// node_modules/lucide-react/dist/esm/shared/src/build/buildLucideIconNode.mjs
function Pe(e) {
	return e != null;
}
function Fe(e, t = {}) {
	let n = t.attributeNames ?? {}, r = (e) => n[e] ?? e, i = e.size ?? e.width ?? Ne.width, a = e.size ?? e.height ?? Ne.height, o = e.aliases?.filter((e) => typeof e == "string" && e.trim() !== "").map((e) => `lucide-${e}`) ?? [], s = [...e.name ? [`lucide-${e.name}`] : [], ...o], c = t.className?.split(" ").filter(Boolean) ?? [], l = t.includeDefaultClasses === !1 ? Me(...c) : Me("lucide", ...s, ...c), u = t.absoluteStrokeWidth ? Number(t.strokeWidth ?? Ne["stroke-width"]) * Number(e.size ?? e.width ?? Ne.width) / Number(t.size ?? t.width ?? Ne.width) : t.strokeWidth ?? Ne["stroke-width"];
	return [
		"svg",
		{
			...Object.entries(Ne).reduce((e, [t, n]) => (e[r(t)] = n, e), {}),
			..."color" in t && t.color && { [r("stroke")]: t.color },
			..."size" in t && Pe(t.size) && {
				[r("width")]: t.size,
				[r("height")]: t.size
			},
			..."width" in t && Pe(t.width) && { [r("width")]: t.width },
			..."height" in t && Pe(t.height) && { [r("height")]: t.height },
			[r("stroke-width")]: u,
			...l && { [r("class")]: l },
			[r("viewBox")]: `0 0 ${i} ${a}`,
			...t.hasA11yProp === !1 ? { [r("aria-hidden")]: "true" } : {},
			..."attributes" in t && t.attributes
		},
		e.node.map((e) => {
			let [n, i, a] = e, o = t.nonScalingStroke ? {
				[r("vector-effect")]: "non-scaling-stroke",
				...i
			} : i;
			return a ? [
				n,
				o,
				a
			] : [n, o];
		})
	];
}
// node_modules/lucide-react/dist/esm/shared/src/build/buildLucideIconForReact.mjs
function Ie(e, t = {}) {
	return Fe(e, {
		...t,
		attributeNames: {
			...t.attributeNames,
			class: "className",
			"stroke-width": "strokeWidth",
			"stroke-linecap": "strokeLinecap",
			"stroke-linejoin": "strokeLinejoin",
			"vector-effect": "vectorEffect"
		}
	});
}
// node_modules/lucide-react/dist/esm/shared/src/utils/hasA11yProp.mjs
var Le = (e) => {
	for (let t in e) if (t.startsWith("aria-") || t === "role" || t === "title") return !0;
	return !1;
}, Re = G({}), ze = () => oe(Re), Be = K(({ color: e, size: t, width: n, height: r, strokeWidth: i, absoluteStrokeWidth: a, nonScalingStroke: o, className: s = "", children: c, iconNode: l = [], icon: u = {
	node: l,
	aliases: [],
	size: 24
}, ...d }, f) => {
	let { size: p = 24, strokeWidth: m = 2, absoluteStrokeWidth: h = !1, nonScalingStroke: g = !1, color: _ = "currentColor", className: v = "" } = ze() ?? {}, y = !!c || Le(d), [b, x, S = []] = Ie(u, {
		color: e ?? _,
		width: n ?? t ?? p,
		height: r ?? t ?? p,
		strokeWidth: i ?? m,
		absoluteStrokeWidth: a ?? h,
		nonScalingStroke: o ?? g,
		className: Me(v, s),
		hasA11yProp: y,
		attributes: d
	});
	return re(b, {
		ref: f,
		...x
	}, [...S.map(([e, t]) => re(e, t)), ...Array.isArray(c) ? c : [c]]);
});
// node_modules/lucide-react/dist/esm/createLucideIcon.mjs
function Ve(e, t = [], n = []) {
	let r = typeof e == "string" ? ke(e, t, n) : e, i = K(({ className: e, ...t }, n) => re(Be, {
		ref: n,
		icon: r,
		className: e,
		...t
	}));
	return r.name && (i.displayName = je(r.name)), i;
}
// node_modules/lucide-react/dist/esm/icons/calendar-days.mjs
var He = {
	name: "calendar-days",
	size: 24,
	node: [
		["path", {
			d: "M8 2v3",
			key: "1ioesn"
		}],
		["path", {
			d: "M16 2v3",
			key: "otl347"
		}],
		["rect", {
			x: "3",
			y: "3",
			width: "18",
			height: "18",
			rx: "2",
			key: "h1oib"
		}],
		["path", {
			d: "M3 9h18",
			key: "1pudct"
		}],
		["path", {
			d: "M8 13h.01",
			key: "1sbv64"
		}],
		["path", {
			d: "M12 13h.01",
			key: "y0uutt"
		}],
		["path", {
			d: "M16 13h.01",
			key: "wip0gl"
		}],
		["path", {
			d: "M8 17h.01",
			key: "p3bg7i"
		}],
		["path", {
			d: "M12 17h.01",
			key: "p32p05"
		}],
		["path", {
			d: "M16 17h.01",
			key: "ql8jdd"
		}]
	]
};
He.node;
var Ue = Ve(He), We = {
	name: "check",
	size: 24,
	node: [["path", {
		d: "M20 6 9 17l-5-5",
		key: "1gmf2c"
	}]]
};
We.node;
var Ge = Ve(We), Ke = {
	name: "chevron-down",
	size: 24,
	node: [["path", {
		d: "m6 9 6 6 6-6",
		key: "qrunsl"
	}]]
};
Ke.node;
var qe = Ve(Ke), Je = {
	name: "chevron-left",
	size: 24,
	node: [["path", {
		d: "m15 18-6-6 6-6",
		key: "1wnfg3"
	}]]
};
Je.node;
var Ye = Ve(Je), Xe = {
	name: "chevron-right",
	size: 24,
	node: [["path", {
		d: "m9 18 6-6-6-6",
		key: "mthhwq"
	}]]
};
Xe.node;
var Ze = Ve(Xe), Qe = {
	name: "chevron-up",
	size: 24,
	node: [["path", {
		d: "m18 15-6-6-6 6",
		key: "153udz"
	}]]
};
Qe.node;
var $e = Ve(Qe), et = {
	duration: {
		instant: .12,
		fast: .16,
		exit: .18,
		standard: .24,
		considered: .48
	},
	ease: {
		enter: [
			.16,
			1,
			.3,
			1
		],
		exit: [
			.7,
			0,
			.84,
			0
		],
		standard: [
			.22,
			1,
			.36,
			1
		],
		inOut: [
			.65,
			0,
			.35,
			1
		]
	},
	spring: {
		responsive: {
			type: "spring",
			stiffness: 520,
			damping: 44
		},
		gentle: {
			type: "spring",
			stiffness: 340,
			damping: 34
		},
		snappy: {
			type: "spring",
			visualDuration: .26,
			bounce: 0
		},
		smooth: {
			type: "spring",
			visualDuration: .4,
			bounce: 0
		},
		morph: {
			type: "spring",
			visualDuration: .42,
			bounce: 0
		}
	},
	stagger: {
		char: .016,
		word: .04,
		line: .08,
		item: .035
	},
	blur: {
		subtle: 2,
		soft: 4,
		text: 8
	}
}, tt = (e) => `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`, nt = (e) => {
	let [t = 1970, n = 1, r = 1] = e.split("-").map(Number);
	return new Date(t, n - 1, r);
}, rt = (e) => {
	let t = 0, n = () => {
		let r = /* @__PURE__ */ new Date(), i = new Date(r.getFullYear(), r.getMonth(), r.getDate() + 1);
		t = window.setTimeout(() => {
			e(), n();
		}, i.getTime() - r.getTime() + 1e3);
	}, r = () => {
		document.visibilityState === "visible" && e();
	};
	return n(), document.addEventListener("visibilitychange", r), window.addEventListener("focus", e), () => {
		window.clearTimeout(t), document.removeEventListener("visibilitychange", r), window.removeEventListener("focus", e);
	};
}, it = () => tt(/* @__PURE__ */ new Date()), at = () => "";
function ot() {
	let e = fe(rt, it, at);
	return de(() => e ? nt(e) : void 0, [e]);
}
var Z = {
	calendar: "_calendar_1xv46_7",
	header: "_header_1xv46_9",
	heading: "_heading_1xv46_10",
	navigation: "_navigation_1xv46_10",
	title: "_title_1xv46_13",
	titleRow: "_titleRow_1xv46_15",
	srOnly: "_srOnly_1xv46_17",
	navButton: "_navButton_1xv46_20",
	todayButton: "_todayButton_1xv46_20",
	weekdays: "_weekdays_1xv46_26",
	week: "_week_1xv46_26",
	monthViewport: "_monthViewport_1xv46_30",
	monthBody: "_monthBody_1xv46_31",
	grid: "_grid_1xv46_33",
	placeholderDay: "_placeholderDay_1xv46_34",
	day: "_day_1xv46_35",
	dayNumber: "_dayNumber_1xv46_38",
	highlight: "_highlight_1xv46_40",
	highlightFill: "_highlightFill_1xv46_41",
	selected: "_selected_1xv46_42",
	outside: "_outside_1xv46_45",
	today: "_today_1xv46_20"
}, st = (e, t, n) => {
	let r = /* @__PURE__ */ new Date(0);
	return r.setFullYear(e, t, n), r.setHours(0, 0, 0, 0), r;
}, ct = (e) => st(e.getFullYear(), e.getMonth(), e.getDate()), lt = (e) => st(e.getFullYear(), e.getMonth(), 1), ut = (e, t) => !!(e && t && e.getFullYear() === t.getFullYear() && e.getMonth() === t.getMonth() && e.getDate() === t.getDate()), dt = (e, t) => !!(e && t && e.getFullYear() === t.getFullYear() && e.getMonth() === t.getMonth()), ft = (e, t) => st(e.getFullYear(), e.getMonth(), e.getDate() + t), pt = (e, t) => st(e.getFullYear(), e.getMonth() + t, 1), mt = (e, t) => st(e.getFullYear(), e.getMonth() + t, Math.min(e.getDate(), st(e.getFullYear(), e.getMonth() + t + 1, 0).getDate())), ht = (e, t) => !!(t && ct(e).getTime() < ct(t).getTime()), gt = (e, t) => !!(t && ct(e).getTime() > ct(t).getTime()), _t = (e) => `${e.getFullYear()}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`, vt = (e) => {
	let t = ft(e, -e.getDay());
	return Array.from({ length: 6 }, (e, n) => Array.from({ length: 7 }, (e, r) => ft(t, n * 7 + r)));
}, yt = () => () => {}, bt = () => !0, xt = () => !1, { spring: St, duration: Ct, ease: wt } = et, Tt = {
	type: "spring",
	visualDuration: .36,
	bounce: 0,
	restDelta: .002
}, Et = (e) => e.getFullYear() * 12 + e.getMonth(), Dt = (e) => st(Math.floor(e / 12), (e % 12 + 12) % 12, 1), Ot = {
	enter: (e) => ({
		opacity: 0,
		x: e * 12
	}),
	center: {
		opacity: 1,
		x: 0,
		transition: {
			duration: Ct.standard,
			ease: wt.enter
		}
	},
	exit: (e) => ({
		opacity: 0,
		x: e * -12,
		transition: {
			duration: .14,
			ease: wt.standard
		}
	})
}, kt = {
	enter: {
		opacity: 1,
		x: 0
	},
	center: {
		opacity: 1,
		x: 0,
		transition: { duration: 0 }
	},
	exit: {
		opacity: 0,
		transition: { duration: 0 }
	}
};
function At({ cell: e, reduced: t }) {
	let n = e >= 0, r = N(n ? e % 7 : 0), i = N(n ? Math.floor(e / 7) : 0), a = N(+!!n), o = N(n ? 1 : .6), s = L(() => `translate(calc(${r.get()} * (100% + var(--rmd-calendar-gap))), calc(${i.get()} * (100% + var(--rmd-calendar-gap)))) scale(${o.get()})`), c = q(!n);
	return ue(() => {
		if (!n) {
			c.current = !0;
			let e = t ? { duration: 0 } : {
				duration: .14,
				ease: wt.standard
			}, n = [z(a, 0, e), z(o, .6, e)];
			return () => n.forEach((e) => e.stop());
		}
		let s = e % 7, l = Math.floor(e / 7), u = [];
		return c.current || t ? (r.jump(s), i.jump(l)) : u.push(z(r, s, St.morph), z(i, l, St.morph)), c.current = !1, u.push(z(a, 1, t ? { duration: 0 } : {
			duration: Ct.fast,
			ease: wt.enter
		}), z(o, 1, t ? { duration: 0 } : St.snappy)), () => u.forEach((e) => e.stop());
	}, [
		e,
		n,
		t,
		r,
		i,
		a,
		o
	]), /* @__PURE__ */ Y(U.span, {
		className: Z.highlight,
		"data-rmd-part": "selection",
		style: {
			transform: s,
			opacity: a
		},
		"aria-hidden": "true",
		children: /* @__PURE__ */ Y("span", { className: Z.highlightFill })
	});
}
function jt({ index: e, position: t, present: n, children: r }) {
	let i = L(t, (t) => `calc(${(e - t) * 100}% + ${(e - t) * 16}px)`), a = L(t, (t) => 1 - Math.min(1, Math.abs(e - t)) * .6);
	return /* @__PURE__ */ Y(U.div, {
		className: Z.monthBody,
		style: {
			x: i,
			opacity: a
		},
		"data-present": n || void 0,
		"aria-hidden": !n || void 0,
		inert: !n,
		children: r
	});
}
function Mt({ value: e, onChange: t, month: n, onMonthChange: r, minDate: i, maxDate: a, disabledDates: o, locale: s = "en-US", className: c, showToday: l = !1, todayLabel: u = "Today", previousMonthLabel: d = "Previous month", nextMonthLabel: f = "Next month" }) {
	let p = ce(), m = ot(), h = fe(yt, bt, xt), g = (ee() ?? !1) && h, [_, v] = J(() => e ? lt(e) : void 0), [y, b] = J(e), x = q(null), S = q(null), C = e ?? m, w = n ? lt(n) : _ ?? (C && lt(C));
	!n && !_ && w && v(w);
	let T = w?.getTime(), E = w ? _t(w) : "pending", [D, O] = J(T), [k, A] = J(0);
	D !== T && (O(T), A(D === void 0 || T === void 0 ? 0 : T > D ? 1 : -1));
	let j = de(() => T === void 0 ? [] : vt(new Date(T)), [T]), M = w ? Et(w) : 0, P = N(M), [F, I] = J([M, M]);
	De(P, "change", (e) => {
		let t = [Math.floor(e + .001), Math.ceil(e - .001)];
		I((e) => e[0] === t[0] && e[1] === t[1] ? e : t);
	});
	let L = w !== void 0, R = q(L);
	ue(() => {
		if (!L) return;
		let e = P.get();
		if (e === M) return;
		if (!R.current || g) {
			R.current = !0, P.jump(M);
			return;
		}
		Math.abs(M - e) > 2 && P.jump(M - Math.sign(M - e));
		let t = z(P, M, Tt);
		return () => t.stop();
	}, [
		L,
		M,
		g,
		P
	]);
	let B = Array.from(/* @__PURE__ */ new Set([
		F[0],
		F[1],
		M
	])).sort((e, t) => e - t), V = de(() => new Intl.DateTimeFormat(s, {
		month: "long",
		year: "numeric"
	}), [s]), H = de(() => new Intl.DateTimeFormat(s, { weekday: "short" }), [s]), te = de(() => Array.from({ length: 7 }, (e, t) => H.format(new Date(2024, 0, 7 + t))), [H]), W = w ? V.format(w) : "", ne = e ? _t(e) : "", [G, re] = J({
		key: ne,
		date: e
	}), [K, ie] = J({
		from: "",
		to: "",
		distance: 0
	});
	if (G.key !== ne) {
		let t = G.date && e ? Math.round((ct(e).getTime() - ct(G.date).getTime()) / 864e5) : 0, n = G.date && e ? e.getDay() - G.date.getDay() : 0;
		re({
			key: ne,
			date: e
		}), ie({
			from: G.key,
			to: ne,
			distance: Math.hypot(n, (t - n) / 7)
		});
	}
	let ae = (e) => {
		if (!K.distance || g || e !== K.to && e !== K.from) return;
		let t = e === K.to ? Math.min(260, 95 + 85 * Math.log(K.distance)) : Math.max(20, 130 / K.distance);
		return { "--number-delay": `${Math.round(t)}ms` };
	}, oe = (e) => ht(e, i) || gt(e, a) || !!o?.(e), se = w && pt(w, -1), le = w && pt(w, 1), me = !!(se && i && se.getTime() < lt(i).getTime()), he = !!(le && a && le.getTime() > lt(a).getTime()), ge = !!(m && !oe(m) && t), _e = !(!m || !dt(w, m) || ge && !ut(e, m)), ve = (() => {
		let t = (e) => e && dt(e, w) && !oe(e) ? _t(e) : "";
		return t(y) || t(e) || t(m) || _t(j.flat().find((e) => dt(e, w) && !oe(e)) ?? /* @__PURE__ */ new Date(0));
	})(), ye = (e) => {
		let t = lt(e);
		n || v(t), r?.(t);
	};
	ue(() => {
		let e = S.current;
		if (!e) return;
		let t = x.current?.querySelector(`[data-present] [data-date="${e}"]`);
		t && (S.current = null, t.focus({ preventScroll: !0 }));
	});
	let be = (e, t, n) => {
		let r = ht(t, i) && i ? ct(i) : gt(t, a) && a ? ct(a) : t;
		for (let e = 0; e < 42 && oe(r); e += 1) r = ft(r, n);
		oe(r) || ut(r, e) || (b(r), S.current = _t(r), dt(r, w) || ye(r));
	}, xe = (e, n) => {
		if (e.key === "Enter" || e.key === " ") {
			e.preventDefault(), oe(n) || t?.(n);
			return;
		}
		let r = {
			ArrowLeft: [ft(n, -1), -1],
			ArrowRight: [ft(n, 1), 1],
			ArrowUp: [ft(n, -7), -1],
			ArrowDown: [ft(n, 7), 1],
			Home: [ft(n, -n.getDay()), 1],
			End: [ft(n, 6 - n.getDay()), -1],
			PageUp: [mt(n, e.shiftKey ? -12 : -1), -1],
			PageDown: [mt(n, e.shiftKey ? 12 : 1), 1]
		}[e.key];
		r && (e.preventDefault(), be(n, r[0], r[1]));
	}, Se = () => {
		m && w && !_e && (b(m), dt(m, w) || ye(m), ge && !ut(e, m) && t?.(m));
	}, Ce = (...e) => e.filter(Boolean).join(" "), we = (t) => {
		if (!e) return -1;
		let n = ft(t, -t.getDay()), r = Math.round((ct(e).getTime() - n.getTime()) / 864e5);
		return r >= 0 && r < 42 ? r : -1;
	}, Te = (n, r) => /* @__PURE__ */ X(pe, { children: [/* @__PURE__ */ Y(At, {
		cell: we(n),
		reduced: g
	}), /* @__PURE__ */ Y("div", {
		className: Z.grid,
		role: "grid",
		"aria-label": V.format(n),
		"data-rmd-part": "grid",
		children: vt(n).map((i) => /* @__PURE__ */ Y("div", {
			className: Z.week,
			role: "row",
			"data-rmd-part": "week",
			children: i.map((i) => {
				let a = _t(i), o = ut(i, e), c = ut(i, m);
				return /* @__PURE__ */ Y("button", {
					type: "button",
					role: "gridcell",
					"data-date": a,
					"data-rmd-part": "day",
					"aria-label": i.toLocaleDateString(s, { dateStyle: "full" }),
					"aria-selected": o,
					"aria-current": c ? "date" : void 0,
					tabIndex: r && a === ve ? 0 : -1,
					disabled: oe(i),
					style: r ? ae(a) : void 0,
					className: Ce(Z.day, !dt(i, n) && Z.outside, o && Z.selected, c && Z.today),
					onFocus: () => b(i),
					onKeyDown: (e) => xe(e, i),
					onClick: () => t?.(i),
					children: /* @__PURE__ */ Y("span", {
						className: Z.dayNumber,
						"data-rmd-part": "day-number",
						children: i.getDate()
					})
				}, a);
			})
		}, _t(i[0])))
	})] });
	return /* @__PURE__ */ X("section", {
		className: Ce(Z.calendar, c),
		"aria-labelledby": p,
		"data-rmd-component": "calendar",
		"data-rmd-part": "root",
		children: [
			/* @__PURE__ */ X("div", {
				className: Z.header,
				"data-rmd-part": "header",
				children: [
					/* @__PURE__ */ X("h2", {
						id: p,
						className: Z.heading,
						"data-rmd-part": "heading",
						children: [/* @__PURE__ */ Y("span", {
							className: Z.srOnly,
							children: W
						}), /* @__PURE__ */ Y("span", {
							className: Z.title,
							"aria-hidden": "true",
							children: /* @__PURE__ */ Y(Ee, {
								initial: !1,
								custom: k,
								children: w && /* @__PURE__ */ Y(U.span, {
									className: Z.titleRow,
									custom: k,
									variants: g || !k ? kt : Ot,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: W
								}, E)
							})
						})]
					}),
					/* @__PURE__ */ Y("span", {
						className: Z.srOnly,
						"aria-live": "polite",
						children: k ? W : ""
					}),
					/* @__PURE__ */ X("div", {
						className: Z.navigation,
						"data-rmd-part": "navigation",
						children: [
							l && /* @__PURE__ */ Y("button", {
								type: "button",
								className: Z.todayButton,
								"data-rmd-part": "today",
								"aria-disabled": _e || void 0,
								"aria-label": m ? `${u}, ${m.toLocaleDateString(s, { dateStyle: "full" })}` : u,
								onClick: Se,
								children: u
							}),
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: Z.navButton,
								"data-rmd-part": "previous-month",
								"aria-label": d,
								"aria-disabled": me || void 0,
								onClick: () => {
									!me && se && ye(se);
								},
								children: /* @__PURE__ */ Y(Ye, {
									size: 16,
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ Y("button", {
								type: "button",
								className: Z.navButton,
								"data-rmd-part": "next-month",
								"aria-label": f,
								"aria-disabled": he || void 0,
								onClick: () => {
									!he && le && ye(le);
								},
								children: /* @__PURE__ */ Y(Ze, {
									size: 16,
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							})
						]
					})
				]
			}),
			/* @__PURE__ */ Y("div", {
				className: Z.weekdays,
				"data-rmd-part": "weekdays",
				"aria-hidden": "true",
				children: te.map((e, t) => /* @__PURE__ */ Y("span", { children: e.slice(0, 2) }, `${e}-${t}`))
			}),
			/* @__PURE__ */ Y("div", {
				className: Z.monthViewport,
				"data-rmd-part": "viewport",
				ref: x,
				children: w ? B.map((e) => /* @__PURE__ */ Y(jt, {
					index: e,
					position: P,
					present: e === M,
					children: Te(Dt(e), e === M)
				}, e)) : /* @__PURE__ */ Y("div", {
					className: Z.monthBody,
					"aria-hidden": "true",
					children: /* @__PURE__ */ Y("div", {
						className: Z.grid,
						children: Array.from({ length: 6 }, (e, t) => /* @__PURE__ */ Y("div", {
							className: Z.week,
							children: Array.from({ length: 7 }, (e, t) => /* @__PURE__ */ Y("span", { className: Z.placeholderDay }, t))
						}, t))
					})
				})
			})
		]
	});
}
var Nt = {
	field: "_field_odvga_7",
	label: "_label_odvga_8",
	anchor: "_anchor_odvga_9",
	trigger: "_trigger_odvga_11",
	valueText: "_valueText_odvga_17",
	value: "_value_odvga_17",
	part: "_part_odvga_18",
	partValue: "_partValue_odvga_20",
	placeholder: "_placeholder_odvga_21",
	srOnly: "_srOnly_odvga_22",
	chevron: "_chevron_odvga_23",
	popover: "_popover_odvga_26",
	footer: "_footer_odvga_29",
	status: "_status_odvga_31",
	description: "_description_odvga_37"
}, Pt = (e) => {
	let t = new Date(e);
	return t.setDate(1), t.setHours(0, 0, 0, 0), t;
}, { spring: Ft, duration: It, ease: Lt, blur: Rt } = et, zt = { duration: It.instant }, Bt = {
	enter: (e) => ({
		opacity: 0,
		y: `${e * .35}em`,
		filter: `blur(${Rt.soft}px)`
	}),
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: {
			duration: It.standard,
			ease: Lt.enter
		}
	},
	exit: (e) => ({
		opacity: 0,
		y: `${e * -.3}em`,
		filter: `blur(${Rt.subtle}px)`,
		transition: {
			duration: .14,
			ease: Lt.standard
		}
	})
}, Vt = {
	enter: { opacity: 0 },
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: zt
	},
	exit: {
		opacity: 0,
		transition: zt
	}
}, Ht = {
	enter: {
		opacity: 0,
		y: "0.3em",
		filter: `blur(${Rt.soft}px)`
	},
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: {
			duration: It.standard,
			ease: Lt.enter
		}
	},
	exit: {
		opacity: 0,
		y: "-0.3em",
		filter: `blur(${Rt.subtle}px)`,
		transition: {
			duration: .14,
			ease: Lt.standard
		}
	}
};
function Ut({ label: e, value: t, onChange: n, description: r, placeholder: i = "Select a date", minDate: a, maxDate: o, disabledDates: s, locale: c = "en-US", format: l = {
	month: "short",
	day: "numeric",
	year: "numeric"
}, showToday: u, invalid: d, describedBy: f, todayLabel: p, previousMonthLabel: m, nextMonthLabel: h, clearLabel: g = "Clear", calendarLabel: _, statusLabel: v, id: y, className: b, disabled: x, ...S }) {
	let C = ce(), w = y ?? C, T = r ? `${w}-description` : void 0, E = [T, f].filter(Boolean).join(" ") || void 0, [D, O] = J(!1);
	se(() => {
		x && O(!1);
	}, [x]);
	let [k, A] = J(Pt(t ?? /* @__PURE__ */ new Date())), j = q(null), M = q(null), N = q(null), P = q(void 0), F = new Intl.DateTimeFormat(c, l), I = ee() ?? !1, L = t?.getTime() ?? null, [R, z] = J(L), [B, V] = J(1);
	R !== L && (z(L), V(L === null || R === null || L >= R ? 1 : -1));
	let H = t ? F.format(t) : null, te = H ?? i;
	se(() => {
		let e = (e) => {
			j.current?.contains(e.target) || (window.clearTimeout(P.current), O(!1));
		};
		return document.addEventListener("pointerdown", e), () => {
			document.removeEventListener("pointerdown", e), window.clearTimeout(P.current);
		};
	}, []), se(() => {
		D && N.current?.querySelector("[data-present] [data-date][tabindex=\"0\"]")?.focus({ preventScroll: !0 });
	}, [D]);
	let W = () => {
		window.clearTimeout(P.current), N.current?.contains(document.activeElement) && M.current?.focus(), O(!1);
	}, ne = () => {
		window.clearTimeout(P.current), A(Pt(t ?? /* @__PURE__ */ new Date())), O(!0);
	}, G = (e) => {
		n?.(e), window.clearTimeout(P.current), I || !e ? W() : P.current = window.setTimeout(W, 300);
	}, re = (e) => {
		e.key !== "ArrowDown" && e.key !== "Enter" && e.key !== " " || D || (e.preventDefault(), ne()), e.key === "Escape" && W();
	};
	return /* @__PURE__ */ X("div", {
		className: [Nt.field, b].filter(Boolean).join(" "),
		ref: j,
		onBlur: (e) => {
			let t = e.relatedTarget;
			D && t && !j.current?.contains(t) && (window.clearTimeout(P.current), O(!1));
		},
		"data-rmd-component": "date-picker",
		"data-rmd-part": "field",
		children: [
			/* @__PURE__ */ Y("label", {
				className: Nt.label,
				htmlFor: w,
				"data-rmd-part": "label",
				children: e
			}),
			/* @__PURE__ */ X("div", {
				className: Nt.anchor,
				"data-rmd-part": "anchor",
				children: [/* @__PURE__ */ X("button", {
					...S,
					ref: M,
					id: w,
					type: "button",
					disabled: x,
					"aria-haspopup": "dialog",
					"aria-expanded": D,
					"aria-describedby": E,
					"aria-invalid": d || void 0,
					"data-rmd-part": "trigger",
					className: Nt.trigger,
					onClick: () => D ? W() : ne(),
					onKeyDown: re,
					children: [
						/* @__PURE__ */ Y(Ue, {
							size: 16,
							strokeWidth: 1.75,
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ Y("span", {
							className: Nt.srOnly,
							children: te
						}),
						/* @__PURE__ */ Y("span", {
							className: Nt.valueText,
							"data-rmd-part": "value",
							"aria-hidden": "true",
							children: /* @__PURE__ */ Y(Ee, {
								mode: "popLayout",
								initial: !1,
								custom: 1,
								children: t ? /* @__PURE__ */ Y(U.span, {
									className: Nt.value,
									custom: B,
									variants: I ? Vt : Bt,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: te
								}, L) : /* @__PURE__ */ Y(U.span, {
									className: Nt.placeholder,
									custom: -1,
									variants: I ? Vt : Bt,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: i
								}, "placeholder")
							})
						}),
						/* @__PURE__ */ Y(qe, {
							className: Nt.chevron,
							"data-rmd-part": "chevron",
							size: 16,
							strokeWidth: 1.75,
							"aria-hidden": "true"
						})
					]
				}), /* @__PURE__ */ Y(Ee, { children: D && /* @__PURE__ */ X(U.div, {
					ref: N,
					className: Nt.popover,
					"data-rmd-part": "popover",
					role: "dialog",
					"data-rmd-date-popover": "",
					"aria-label": _ ?? `${e} calendar`,
					onKeyDown: (e) => {
						e.key === "Escape" && (e.stopPropagation(), W());
					},
					initial: I ? { opacity: 0 } : {
						opacity: 0,
						y: -8,
						scale: .95
					},
					animate: {
						opacity: 1,
						y: 0,
						scale: 1,
						transition: I ? zt : {
							...Ft.snappy,
							opacity: {
								duration: It.fast,
								ease: Lt.enter
							}
						}
					},
					exit: {
						opacity: 0,
						...I ? {} : {
							y: -6,
							scale: .97
						},
						transition: {
							duration: .14,
							ease: Lt.standard
						}
					},
					children: [/* @__PURE__ */ Y(Mt, {
						value: t,
						onChange: G,
						month: k,
						onMonthChange: A,
						minDate: a,
						maxDate: o,
						disabledDates: s,
						locale: c,
						showToday: u,
						todayLabel: p,
						previousMonthLabel: m,
						nextMonthLabel: h
					}), /* @__PURE__ */ X("div", {
						className: Nt.footer,
						"data-rmd-part": "footer",
						children: [/* @__PURE__ */ Y("button", {
							type: "button",
							"data-rmd-part": "clear",
							onClick: () => G(void 0),
							disabled: !t,
							children: g
						}), /* @__PURE__ */ Y("span", {
							className: Nt.status,
							"data-rmd-part": "status",
							children: /* @__PURE__ */ Y(Ee, {
								initial: !1,
								children: /* @__PURE__ */ Y(U.span, {
									variants: I ? Vt : Ht,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: v ? v(H) : H ? `Selected ${H}` : "Choose a day"
								}, L ?? "none")
							})
						})]
					})]
				}) })]
			}),
			r && /* @__PURE__ */ Y("span", {
				id: T,
				className: Nt.description,
				"data-rmd-part": "description",
				children: r
			})
		]
	});
}
// src/components/uiarc/rmd-motion.ts
var Wt = [
	.22,
	.61,
	.36,
	1
], Gt = {
	fast: {
		type: "tween",
		duration: .15,
		ease: Wt
	},
	base: {
		type: "tween",
		duration: .22,
		ease: Wt
	}
}, Kt = Object.defineProperty, qt = (e, t) => Kt(e, "name", {
	value: t,
	configurable: !0
});
function Jt(e, [t, n]) {
	return Math.min(n, Math.max(t, e));
}
qt(Jt, "clamp");
// node_modules/@radix-ui/primitive/dist/index.mjs
var Yt = Object.defineProperty, Xt = (e, t) => Yt(e, "name", {
	value: t,
	configurable: !0
}), Zt = !!(typeof window < "u" && window.document && window.document.createElement);
function Qt(e, t, { checkForDefaultPrevented: n = !0 } = {}) {
	return /* @__PURE__ */ Xt(function(r) {
		if (e?.(r), n === !1 || !r || !r.defaultPrevented) return t?.(r);
	}, "handleEvent");
}
Xt(Qt, "composeEventHandlers");
function $t(e) {
	if (!Zt) throw Error("Cannot access window outside of the DOM");
	return e?.ownerDocument?.defaultView ?? window;
}
Xt($t, "getOwnerWindow");
function en(e) {
	if (!Zt) throw Error("Cannot access document outside of the DOM");
	return e?.ownerDocument ?? document;
}
Xt(en, "getOwnerDocument");
function tn(e, t = !1) {
	let { activeElement: n } = en(e);
	if (!n?.nodeName) return null;
	if (nn(n) && n.contentDocument) return tn(n.contentDocument.body, t);
	if (t) {
		let e = n.getAttribute("aria-activedescendant");
		if (e) {
			let t = en(n).getElementById(e);
			if (t) return t;
		}
	}
	return n;
}
Xt(tn, "getActiveElement");
function nn(e) {
	return e.tagName === "IFRAME";
}
Xt(nn, "isFrame");
// node_modules/@radix-ui/react-context/dist/index.mjs
var rn = Object.defineProperty, an = (e, t) => rn(e, "name", {
	value: t,
	configurable: !0
});
// @__NO_SIDE_EFFECTS__
function on(e, t) {
	let n = W.createContext(t);
	n.displayName = e + "Context";
	let r = /* @__PURE__ */ an((e) => {
		let { children: t, ...r } = e, i = W.useMemo(() => r, Object.values(r));
		return /* @__PURE__ */ Y(n.Provider, {
			value: i,
			children: t
		});
	}, "Provider");
	r.displayName = e + "Provider";
	function i(r, i = {}) {
		let { optional: a = !1 } = i, o = W.useContext(n);
		if (o) return o;
		if (t !== void 0) return t;
		if (!a) throw Error(`\`${r}\` must be used within \`${e}\``);
	}
	return an(i, "useContext"), [r, i];
}
an(on, "createContext");
// @__NO_SIDE_EFFECTS__
function sn(e, t = []) {
	let n = [];
	function r(t, r) {
		let i = W.createContext(r);
		i.displayName = t + "Context";
		let a = n.length;
		n = [...n, r];
		let o = /* @__PURE__ */ an((t) => {
			let { scope: n, children: r, ...o } = t, s = n?.[e]?.[a] || i, c = W.useMemo(() => o, Object.values(o));
			return /* @__PURE__ */ Y(s.Provider, {
				value: c,
				children: r
			});
		}, "Provider");
		o.displayName = t + "Provider";
		function s(n, o, s = {}) {
			let { optional: c = !1 } = s, l = o?.[e]?.[a] || i, u = W.useContext(l);
			if (u) return u;
			if (r !== void 0) return r;
			if (!c) throw Error(`\`${n}\` must be used within \`${t}\``);
		}
		return an(s, "useContext"), [o, s];
	}
	an(r, "createContext");
	let i = /* @__PURE__ */ an(() => {
		let t = n.map((e) => W.createContext(e));
		return /* @__PURE__ */ an(function(n) {
			let r = n?.[e] || t;
			return W.useMemo(() => ({ [`__scope${e}`]: {
				...n,
				[e]: r
			} }), [n, r]);
		}, "useScope");
	}, "createScope");
	return i.scopeName = e, [r, cn(i, ...t)];
}
an(sn, "createContextScope");
function cn(...e) {
	let t = e[0];
	if (e.length === 1) return t;
	let n = /* @__PURE__ */ an(() => {
		let n = e.map((e) => ({
			useScope: e(),
			scopeName: e.scopeName
		}));
		return /* @__PURE__ */ an(function(e) {
			let r = n.reduce((t, { useScope: n, scopeName: r }) => {
				let i = n(e)[`__scope${r}`];
				return {
					...t,
					...i
				};
			}, {});
			return W.useMemo(() => ({ [`__scope${t.scopeName}`]: r }), [r]);
		}, "useComposedScopes");
	}, "createScope");
	return n.scopeName = t.scopeName, n;
}
an(cn, "composeContextScopes");
// node_modules/@radix-ui/react-compose-refs/dist/index.mjs
var ln = Object.defineProperty, un = (e, t) => ln(e, "name", {
	value: t,
	configurable: !0
});
function dn(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
un(dn, "setRef");
function fn(...e) {
	return (t) => {
		let n = !1, r = e.map((e) => {
			let r = dn(e, t);
			return !n && typeof r == "function" && (n = !0), r;
		});
		if (n) return () => {
			for (let t = 0; t < r.length; t++) {
				let n = r[t];
				typeof n == "function" ? n() : dn(e[t], null);
			}
		};
	};
}
un(fn, "composeRefs");
function pn(...e) {
	return W.useCallback(fn(...e), e);
}
un(pn, "useComposedRefs");
// node_modules/@radix-ui/react-slot/dist/index.mjs
var mn = Object.defineProperty, hn = (e, t) => mn(e, "name", {
	value: t,
	configurable: !0
});
// @__NO_SIDE_EFFECTS__
function gn(e) {
	let t = W.forwardRef((t, n) => {
		let { children: r, ...i } = t, a = null, o = !1, s = [];
		r = En(r), W.Children.forEach(r, (e) => {
			if (Sn(e)) {
				o = !0;
				let t = e, n = "child" in t.props ? t.props.child : t.props.children;
				for (; wn(n) && typeof An == "function";) n = An(n._payload);
				a = yn(t, n), s.push(a?.props?.children);
			} else s.push(e);
		}), a ? a = W.cloneElement(a, void 0, s) : !o && W.Children.count(r) === 1 && W.isValidElement(r) && (a = r);
		let c = a ? xn(a) : void 0, l = pn(n, c);
		if (!a) {
			if (r || r === 0) throw Error(o ? kn(e) : On(e));
			return r;
		}
		let u = bn(i, a.props ?? {});
		return a.type !== W.Fragment && (u.ref = n ? l : c), W.cloneElement(a, u);
	});
	return t.displayName = `${e}.Slot`, t;
}
hn(gn, "createSlot");
var _n = Symbol.for("radix.slottable");
// @__NO_SIDE_EFFECTS__
function vn(e) {
	let t = /* @__PURE__ */ hn((e) => "child" in e ? e.children(e.child) : e.children, "Slottable");
	return t.displayName = `${e}.Slottable`, t.__radixId = _n, t;
}
hn(vn, "createSlottable");
var yn = /* @__PURE__ */ hn((e, t) => "child" in e.props ? W.isValidElement(t) ? W.cloneElement(t, void 0, e.props.children(t.props.children)) : null : W.isValidElement(t) ? t : null, "getSlottableElementFromSlottable");
function bn(e, t) {
	let n = { ...t };
	for (let r in t) {
		let i = e[r], a = t[r];
		/^on[A-Z]/.test(r) ? i && a ? n[r] = (...e) => {
			let t = a(...e);
			return i(...e), t;
		} : i && (n[r] = i) : r === "style" ? n[r] = {
			...i,
			...a
		} : r === "className" ? n[r] = [i, a].filter(Boolean).join(" ") : r === "aria-describedby" && (n[r] = Dn(a, i));
	}
	return {
		...e,
		...n
	};
}
hn(bn, "mergeProps");
function xn(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
hn(xn, "getElementRef");
function Sn(e) {
	return W.isValidElement(e) && typeof e.type == "function" && "__radixId" in e.type && e.type.__radixId === _n;
}
hn(Sn, "isSlottable");
var Cn = Symbol.for("react.lazy");
function wn(e) {
	return typeof e == "object" && !!e && "$$typeof" in e && e.$$typeof === Cn && "_payload" in e && Tn(e._payload);
}
hn(wn, "isLazyComponent");
function Tn(e) {
	return typeof e == "object" && !!e && "then" in e;
}
hn(Tn, "isPromiseLike");
function En(e) {
	let t = e;
	for (; wn(t) && typeof An == "function";) t = An(t._payload);
	return t;
}
hn(En, "useUnwrappedLazy");
function Dn(...e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) if (typeof n == "string") for (let e of String(n).trim().split(/\s+/)) e && t.add(e);
	return t.size > 0 ? Array.from(t).join(" ") : void 0;
}
hn(Dn, "concatAriaDescribedby");
var On = /* @__PURE__ */ hn((e) => `${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`, "createSlotError"), kn = /* @__PURE__ */ hn((e) => `${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`, "createSlottableError"), An = W.use, jn = globalThis?.document ? W.useLayoutEffect : () => {}, Mn = Object.defineProperty, Nn = (e, t) => Mn(e, "name", {
	value: t,
	configurable: !0
});
// @__NO_SIDE_EFFECTS__
function Pn(e) {
	let t = e + "CollectionProvider", [n, r] = /* @__PURE__ */ sn(t), [i, a] = n(t, {
		collectionRef: { current: null },
		itemMap: /* @__PURE__ */ new Map()
	}), o = /* @__PURE__ */ Nn((e) => {
		let { scope: t, children: n } = e, r = W.useRef(null), a = W.useRef(/* @__PURE__ */ new Map()).current;
		return /* @__PURE__ */ Y(i, {
			scope: t,
			itemMap: a,
			collectionRef: r,
			children: n
		});
	}, "CollectionProvider");
	o.displayName = t;
	let s = e + "CollectionSlot", c = /* @__PURE__ */ gn(s), l = W.forwardRef((e, t) => {
		let { scope: n, children: r } = e, i = pn(t, a(s, n).collectionRef);
		return /* @__PURE__ */ Y(c, {
			ref: i,
			children: r
		});
	});
	l.displayName = s;
	let u = e + "CollectionItemSlot", d = "data-radix-collection-item", f = /* @__PURE__ */ gn(u), p = W.forwardRef((e, t) => {
		let { scope: n, children: r, ...i } = e, o = W.useRef(null), s = pn(t, o), c = a(u, n);
		return W.useEffect(() => (c.itemMap.set(o, {
			ref: o,
			...i
		}), () => void c.itemMap.delete(o))), /* @__PURE__ */ Y(f, {
			[d]: "",
			ref: s,
			children: r
		});
	});
	p.displayName = u;
	function m(t) {
		let n = a(e + "CollectionConsumer", t);
		return W.useCallback(() => {
			let e = n.collectionRef.current;
			if (!e) return [];
			let t = Array.from(e.querySelectorAll(`[${d}]`));
			return Array.from(n.itemMap.values()).sort((e, n) => t.indexOf(e.ref.current) - t.indexOf(n.ref.current));
		}, [n.collectionRef, n.itemMap]);
	}
	return Nn(m, "useCollection"), [
		{
			Provider: o,
			Slot: l,
			ItemSlot: p
		},
		m,
		r
	];
}
Nn(Pn, "createCollection");
var Fn = /* @__PURE__ */ new WeakMap(), In = class e extends Map {
	static {
		Nn(this, "OrderedDict");
	}
	#e;
	constructor(e) {
		super(e), this.#e = [...super.keys()], Fn.set(this, !0);
	}
	set(e, t) {
		return Fn.get(this) && !this.has(e) && this.#e.push(e), super.set(e, t), this;
	}
	insert(e, t, n) {
		let r = this.has(t), i = r ? this.size : this.size + 1, a = zn(e), o = a >= 0 ? Math.min(a, i - 1) : Math.max(i + a, 0);
		if (r ? this.#e.indexOf(t) === o : o === this.size) return this.set(t, n), this;
		let s = this.#e.filter((e) => e !== t);
		s.splice(o, 0, t);
		let c = s.map((e) => [e, e === t ? n : this.get(e)]);
		this.clear();
		for (let [e, t] of c) this.set(e, t);
		return this;
	}
	with(t, n, r) {
		let i = new e(this);
		return i.insert(t, n, r), i;
	}
	before(e) {
		let t = this.#e.indexOf(e) - 1;
		if (!(t < 0)) return this.entryAt(t);
	}
	setBefore(e, t, n) {
		let r = this.#e.indexOf(e);
		if (r === -1) return this;
		let i = this.#e.indexOf(t), a = i !== -1 && i < r ? r - 1 : r;
		return this.insert(a, t, n);
	}
	after(e) {
		let t = this.#e.indexOf(e);
		if (t = t === -1 || t === this.size - 1 ? -1 : t + 1, t !== -1) return this.entryAt(t);
	}
	setAfter(e, t, n) {
		let r = this.#e.indexOf(e);
		if (r === -1) return this;
		let i = this.#e.indexOf(t), a = i !== -1 && i <= r ? r : r + 1;
		return this.insert(a, t, n);
	}
	first() {
		return this.entryAt(0);
	}
	last() {
		return this.entryAt(-1);
	}
	clear() {
		return this.#e = [], super.clear();
	}
	delete(e) {
		let t = super.delete(e);
		return t && this.#e.splice(this.#e.indexOf(e), 1), t;
	}
	deleteAt(e) {
		let t = this.keyAt(e);
		return t !== void 0 && this.delete(t);
	}
	at(e) {
		let t = Ln(this.#e, e);
		if (t !== void 0) return this.get(t);
	}
	entryAt(e) {
		let t = Ln(this.#e, e);
		if (t !== void 0) return [t, this.get(t)];
	}
	indexOf(e) {
		return this.#e.indexOf(e);
	}
	keyAt(e) {
		return Ln(this.#e, e);
	}
	from(e, t) {
		let n = this.indexOf(e);
		if (n === -1) return;
		let r = n + t;
		return r < 0 && (r = 0), r >= this.size && (r = this.size - 1), this.at(r);
	}
	keyFrom(e, t) {
		let n = this.indexOf(e);
		if (n === -1) return;
		let r = n + t;
		return r < 0 && (r = 0), r >= this.size && (r = this.size - 1), this.keyAt(r);
	}
	find(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return r;
			n++;
		}
	}
	findIndex(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return n;
			n++;
		}
		return -1;
	}
	filter(t, n) {
		let r = [], i = 0;
		for (let e of this) Reflect.apply(t, n, [
			e,
			i,
			this
		]) && r.push(e), i++;
		return new e(r);
	}
	map(t, n) {
		let r = [], i = 0;
		for (let e of this) r.push([e[0], Reflect.apply(t, n, [
			e,
			i,
			this
		])]), i++;
		return new e(r);
	}
	reduce(...e) {
		let [t, n] = e, r = e.length > 1;
		if (!r && this.size === 0) throw TypeError("Reduce of empty OrderedDict with no initial value");
		let i = 0, a = n;
		for (let e of this) a = i === 0 && !r ? e : Reflect.apply(t, this, [
			a,
			e,
			i,
			this
		]), i++;
		return a;
	}
	reduceRight(...e) {
		let [t, n] = e, r = e.length > 1;
		if (!r && this.size === 0) throw TypeError("Reduce of empty OrderedDict with no initial value");
		let i = n;
		for (let e = this.size - 1; e >= 0; e--) {
			let n = this.entryAt(e);
			i = e === this.size - 1 && !r ? n : Reflect.apply(t, this, [
				i,
				n,
				e,
				this
			]);
		}
		return i;
	}
	sort(e) {
		if (typeof e != "function") throw TypeError("OrderedDict.sort requires a compare function");
		let t = [...this.entries()].sort(e);
		this.clear();
		for (let [e, n] of t) this.set(e, n);
		return this;
	}
	toSorted(t) {
		if (typeof t != "function") throw TypeError("OrderedDict.toSorted requires a compare function");
		let n = [...this.entries()].sort(t);
		return new e(n);
	}
	toReversed() {
		let t = new e();
		for (let e = this.size - 1; e >= 0; e--) {
			let n = this.keyAt(e), r = this.get(n);
			t.set(n, r);
		}
		return t;
	}
	toSpliced(...t) {
		let n = [...this.entries()];
		return n.splice(...t), new e(n);
	}
	slice(t, n) {
		let r = new e();
		for (let e of this.#e.slice(t, n)) r.set(e, this.get(e));
		return r;
	}
	every(e, t) {
		let n = 0;
		for (let r of this) {
			if (!Reflect.apply(e, t, [
				r,
				n,
				this
			])) return !1;
			n++;
		}
		return !0;
	}
	some(e, t) {
		let n = 0;
		for (let r of this) {
			if (Reflect.apply(e, t, [
				r,
				n,
				this
			])) return !0;
			n++;
		}
		return !1;
	}
};
function Ln(e, t) {
	if ("at" in Array.prototype) return Array.prototype.at.call(e, t);
	let n = Rn(e, t);
	return n === -1 ? void 0 : e[n];
}
Nn(Ln, "at");
function Rn(e, t) {
	let n = e.length, r = zn(t), i = r >= 0 ? r : n + r;
	return i < 0 || i >= n ? -1 : i;
}
Nn(Rn, "toSafeIndex");
function zn(e) {
	return e !== e || e === 0 ? 0 : Math.trunc(e);
}
Nn(zn, "toSafeInteger");
// @__NO_SIDE_EFFECTS__
function Bn(e) {
	let t = e + "CollectionProvider", [n, r] = /* @__PURE__ */ sn(t), [i, a] = n(t);
	i.displayName = e + "CollectionStableContextProvider";
	let [o, s] = n(t);
	o.displayName = e + "CollectionStatefulContextProvider";
	let c = /* @__PURE__ */ Nn(({ state: e, ...t }) => e ? /* @__PURE__ */ Y(u, {
		...t,
		state: e
	}) : /* @__PURE__ */ Y(l, { ...t }), "CollectionProvider");
	c.displayName = t;
	let l = /* @__PURE__ */ Nn((e) => {
		let t = _();
		return /* @__PURE__ */ Y(u, {
			...e,
			state: t
		});
	}, "CollectionInit");
	l.displayName = e + "CollectionInit";
	let u = /* @__PURE__ */ Nn((e) => {
		let { scope: t, children: n, state: r } = e, a = W.useRef(null), [s, c] = W.useState(null), l = pn(a, c), [u, d] = r, f = W.useRef(new In()), p = W.useCallback(() => {
			let e = f.current;
			return Un(e) || e.sort(Wn), e;
		}, []);
		return W.useEffect(() => {
			if (!s) return;
			let e = Gn(() => {
				d((e) => {
					let t = e.toSorted(Wn);
					return t.some(([t], n) => e.keyAt(n) !== t) ? t : e;
				});
			});
			return e.observe(s, {
				childList: !0,
				subtree: !0
			}), () => {
				e.disconnect();
			};
		}, [s, d]), /* @__PURE__ */ Y(i, {
			scope: t,
			collectionElementRef: l,
			collectionElementRefObject: a,
			getCollection: p,
			setCollection: d,
			registryRef: f,
			children: /* @__PURE__ */ Y(o, {
				scope: t,
				collectionElement: s,
				collection: u,
				children: n
			})
		});
	}, "CollectionProviderImpl");
	u.displayName = e + "CollectionProviderImpl";
	let d = e + "CollectionSlot", f = /* @__PURE__ */ gn(d), p = W.forwardRef((e, t) => {
		let { scope: n, children: r } = e, i = pn(t, a(d, n).collectionElementRef);
		return /* @__PURE__ */ Y(f, {
			ref: i,
			children: r
		});
	});
	p.displayName = d;
	let m = e + "CollectionItemSlot", h = /* @__PURE__ */ gn(m), g = W.forwardRef((e, t) => {
		let { scope: n, children: r, ...i } = e, o = W.useRef(null), { setCollection: s, registryRef: c } = a(m, n), l = W.useRef(i);
		Vn(l.current, i) || (l.current = i);
		let u = l.current, d = pn(t, W.useCallback((e) => {
			let t = c.current;
			e ? t.set(e, {
				...l.current,
				element: e
			}) : o.current && t.delete(o.current);
		}, [c]), o);
		jn(() => {
			let e = o.current, t = c.current;
			e && t.has(e) && t.set(e, {
				...u,
				element: e
			});
		}, [u, c]);
		let f = W.useRef(null);
		return W.useEffect(() => {
			let e = o.current, t = f.current;
			((t?.element ?? null) !== e || e && t?.itemData !== u) && (f.current = e ? {
				element: e,
				itemData: u
			} : null, s((n) => {
				let r = new In(n);
				return t && t.element !== e && r.delete(t.element), e && r.set(e, {
					...u,
					element: e
				}), r.sort(Wn);
			}));
		}), W.useEffect(() => () => {
			let e = f.current;
			f.current = null, e && s((t) => {
				if (!t.has(e.element)) return t;
				let n = new In(t);
				return n.delete(e.element), n;
			});
		}, [s]), /* @__PURE__ */ Y(h, {
			"data-radix-collection-item": "",
			ref: d,
			children: r
		});
	});
	g.displayName = m;
	function _() {
		return W.useState(new In());
	}
	Nn(_, "useInitCollection");
	function v(t) {
		let { collection: n } = s(e + "CollectionConsumer", t);
		return n;
	}
	Nn(v, "useCollection");
	function y(t) {
		let { getCollection: n } = a(e + "CollectionConsumer", t);
		return n;
	}
	return Nn(y, "useGetCollection"), [{
		Provider: c,
		Slot: p,
		ItemSlot: g
	}, {
		createCollectionScope: r,
		useCollection: v,
		useGetCollection: y,
		useInitCollection: _
	}];
}
Nn(Bn, "createCollection");
function Vn(e, t) {
	if (e === t) return !0;
	if (typeof e != "object" || typeof t != "object" || e == null || t == null) return !1;
	let n = Object.keys(e), r = Object.keys(t);
	if (n.length !== r.length) return !1;
	for (let r of n) if (!Object.prototype.hasOwnProperty.call(t, r) || e[r] !== t[r]) return !1;
	return !0;
}
Nn(Vn, "shallowEqual");
function Hn(e, t) {
	return !!(t.compareDocumentPosition(e) & Node.DOCUMENT_POSITION_PRECEDING);
}
Nn(Hn, "isElementPreceding");
function Un(e) {
	let t;
	for (let n of e.keys()) {
		if (t) {
			let e = t.compareDocumentPosition(n);
			if (!(e & Node.DOCUMENT_POSITION_DISCONNECTED) && e & Node.DOCUMENT_POSITION_PRECEDING) return !1;
		}
		t = n;
	}
	return !0;
}
Nn(Un, "isInDocumentOrder");
function Wn(e, t) {
	return !e[1].element || !t[1].element ? 0 : Hn(e[1].element, t[1].element) ? -1 : 1;
}
Nn(Wn, "sortByDocumentPosition");
function Gn(e) {
	return new MutationObserver((t) => {
		for (let n of t) if (n.type === "childList") {
			e();
			return;
		}
	});
}
Nn(Gn, "getChildListObserver");
// node_modules/@radix-ui/react-direction/dist/index.mjs
var Kn = Object.defineProperty, qn = (e, t) => Kn(e, "name", {
	value: t,
	configurable: !0
}), Jn = {
	LTR: "ltr",
	RTL: "rtl"
}, Yn = W.createContext(void 0);
function Xn(e) {
	let t = W.useContext(Yn);
	return e || t || Jn.LTR;
}
qn(Xn, "useDirection");
// node_modules/@radix-ui/react-primitive/dist/index.mjs
var Zn = Object.defineProperty, Qn = (e, t) => Zn(e, "name", {
	value: t,
	configurable: !0
}), $n = [
	"a",
	"button",
	"div",
	"form",
	"h2",
	"h3",
	"img",
	"input",
	"label",
	"li",
	"nav",
	"ol",
	"p",
	"select",
	"span",
	"svg",
	"ul"
].reduce((e, t) => {
	let n = /* @__PURE__ */ gn(`Primitive.${t}`), r = W.forwardRef((e, r) => {
		let { asChild: i, ...a } = e, o = i ? n : t;
		return typeof window < "u" && (window[Symbol.for("radix-ui")] = !0), /* @__PURE__ */ Y(o, {
			...a,
			ref: r
		});
	});
	return r.displayName = `Primitive.${t}`, {
		...e,
		[t]: r
	};
}, {});
function er(e, t) {
	e && me.flushSync(() => e.dispatchEvent(t));
}
Qn(er, "dispatchDiscreteCustomEvent");
// node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
var tr = Object.defineProperty, nr = (e, t) => tr(e, "name", {
	value: t,
	configurable: !0
}), rr = W.useInsertionEffect;
function ir(e) {
	let t = W.useRef(e);
	return typeof rr == "function" ? rr(() => {
		t.current = e;
	}) : jn(() => {
		t.current = e;
	}), W.useMemo(() => ((...e) => t.current?.(...e)), []);
}
nr(ir, "useCallbackRef");
// node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
var ar = Object.defineProperty, or = (e, t) => ar(e, "name", {
	value: t,
	configurable: !0
}), sr = "dismissableLayer.update", cr = "dismissableLayer.pointerDownOutside", lr = "dismissableLayer.focusOutside", ur, dr = W.createContext({
	layers: /* @__PURE__ */ new Set(),
	layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
	branches: /* @__PURE__ */ new Set(),
	dismissableSurfaces: /* @__PURE__ */ new Set()
}), fr = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ or(function(e, t) {
	let { disableOutsidePointerEvents: n = !1, deferPointerDownOutside: r = !1, onEscapeKeyDown: i, onPointerDownOutside: a, onFocusOutside: o, onInteractOutside: s, onDismiss: c, ...l } = e, u = W.useContext(dr), [d, f] = W.useState(null), p = d?.ownerDocument ?? globalThis?.document, [, m] = W.useState({}), h = pn(t, f), g = Array.from(u.layers), [_] = [...u.layersWithOutsidePointerEventsDisabled].slice(-1), v = _ ? g.indexOf(_) : -1, y = d ? g.indexOf(d) : -1, b = u.layersWithOutsidePointerEventsDisabled.size > 0, x = y >= v, S = W.useRef(!1), C = hr((e) => {
		a?.(e), s?.(e), e.defaultPrevented || c?.();
	}, {
		ownerDocument: p,
		deferPointerDownOutside: r,
		isDeferredPointerDownOutsideRef: S,
		dismissableSurfaces: u.dismissableSurfaces,
		shouldHandlePointerDownOutside: W.useCallback((e) => {
			if (!(e instanceof Node)) return !1;
			let t = [...u.branches].some((t) => t.contains(e));
			return x && !t;
		}, [u.branches, x])
	}), w = gr((e) => {
		if (r && S.current) return;
		let t = e.target;
		[...u.branches].some((e) => e.contains(t)) || (o?.(e), s?.(e), e.defaultPrevented || c?.());
	}, p), T = d ? y === g.length - 1 : !1, E = ir((e) => {
		e.key === "Escape" && (i?.(e), !e.defaultPrevented && c && (e.preventDefault(), c()));
	});
	return W.useEffect(() => {
		if (T) return p.addEventListener("keydown", E, { capture: !0 }), () => p.removeEventListener("keydown", E, { capture: !0 });
	}, [
		p,
		T,
		E
	]), W.useEffect(() => {
		if (d) return n && (u.layersWithOutsidePointerEventsDisabled.size === 0 && (ur = p.body.style.pointerEvents, p.body.style.pointerEvents = "none"), u.layersWithOutsidePointerEventsDisabled.add(d)), u.layers.add(d), _r(), () => {
			n && (u.layersWithOutsidePointerEventsDisabled.delete(d), u.layersWithOutsidePointerEventsDisabled.size === 0 && (p.body.style.pointerEvents = ur));
		};
	}, [
		d,
		p,
		n,
		u
	]), W.useEffect(() => () => {
		d && (u.layers.delete(d), u.layersWithOutsidePointerEventsDisabled.delete(d), _r());
	}, [d, u]), W.useEffect(() => {
		let e = /* @__PURE__ */ or(() => m({}), "handleUpdate");
		return document.addEventListener(sr, e), () => document.removeEventListener(sr, e);
	}, []), /* @__PURE__ */ Y($n.div, {
		...l,
		ref: h,
		style: {
			pointerEvents: b ? x ? "auto" : "none" : void 0,
			...e.style
		},
		onFocusCapture: Qt(e.onFocusCapture, w.onFocusCapture),
		onBlurCapture: Qt(e.onBlurCapture, w.onBlurCapture),
		onPointerDownCapture: Qt(e.onPointerDownCapture, C.onPointerDownCapture)
	});
}, "DismissableLayer"));
function pr() {
	let e = W.useContext(dr), [t, n] = W.useState(null);
	return W.useEffect(() => {
		if (t) return e.dismissableSurfaces.add(t), () => {
			e.dismissableSurfaces.delete(t);
		};
	}, [t, e.dismissableSurfaces]), n;
}
or(pr, "useDismissableLayerSurface");
var mr = /* @__PURE__ */ or(() => !0, "IS_TRUE");
function hr(e, t) {
	let { ownerDocument: n = globalThis?.document, deferPointerDownOutside: r = !1, isDeferredPointerDownOutsideRef: i, dismissableSurfaces: a, shouldHandlePointerDownOutside: o = mr } = t, s = ir(e), c = W.useRef(!1), l = W.useRef(!1), u = W.useRef(/* @__PURE__ */ new Map()), d = W.useRef(() => {});
	return W.useEffect(() => {
		function e() {
			l.current = !1, i.current = !1, u.current.clear();
		}
		or(e, "resetOutsideInteraction");
		function t() {
			return Array.from(u.current.values()).some(Boolean);
		}
		or(t, "isOutsideInteractionIntercepted");
		function f(e) {
			if (!l.current) return;
			let t = e.target;
			t instanceof Node && [...a].some((e) => e.contains(t)) || u.current.set(e.type, !0), e.type === "click" && window.setTimeout(() => {
				l.current && d.current();
			}, 0);
		}
		or(f, "handleInteractionCapture");
		function p(e) {
			l.current && u.current.set(e.type, !1);
		}
		or(p, "handleInteractionBubble");
		let m = /* @__PURE__ */ or((a) => {
			if (a.target && !c.current) {
				let f = function() {
					n.removeEventListener("click", d.current);
					let r = t();
					e(), r || vr(cr, s, p, { discrete: !0 });
				};
				if (or(f, "handleAndDispatchPointerDownOutsideEvent"), !o(a.target)) {
					n.removeEventListener("click", d.current), e(), c.current = !1;
					return;
				}
				let p = { originalEvent: a };
				l.current = !0, i.current = r && a.button === 0, u.current.clear(), !r || a.button !== 0 ? f() : (n.removeEventListener("click", d.current), d.current = f, n.addEventListener("click", d.current, { once: !0 }));
			} else n.removeEventListener("click", d.current), e();
			c.current = !1;
		}, "handlePointerDown"), h = [
			"pointerup",
			"mousedown",
			"mouseup",
			"touchstart",
			"touchend",
			"click"
		];
		for (let e of h) n.addEventListener(e, f, !0), n.addEventListener(e, p);
		let g = window.setTimeout(() => {
			n.addEventListener("pointerdown", m);
		}, 0);
		return () => {
			window.clearTimeout(g), n.removeEventListener("pointerdown", m), n.removeEventListener("click", d.current);
			for (let e of h) n.removeEventListener(e, f, !0), n.removeEventListener(e, p);
		};
	}, [
		n,
		s,
		r,
		i,
		a,
		o
	]), { onPointerDownCapture: /* @__PURE__ */ or(() => c.current = !0, "onPointerDownCapture") };
}
or(hr, "usePointerDownOutside");
function gr(e, t = globalThis?.document) {
	let n = ir(e), r = W.useRef(!1);
	return W.useEffect(() => {
		let e = /* @__PURE__ */ or((e) => {
			e.target && !r.current && vr(lr, n, { originalEvent: e }, { discrete: !1 });
		}, "handleFocus");
		return t.addEventListener("focusin", e), () => t.removeEventListener("focusin", e);
	}, [t, n]), {
		onFocusCapture: /* @__PURE__ */ or(() => r.current = !0, "onFocusCapture"),
		onBlurCapture: /* @__PURE__ */ or(() => r.current = !1, "onBlurCapture")
	};
}
or(gr, "useFocusOutside");
function _r() {
	let e = new CustomEvent(sr);
	document.dispatchEvent(e);
}
or(_r, "dispatchUpdate");
function vr(e, t, n, { discrete: r }) {
	let i = n.originalEvent.target, a = new CustomEvent(e, {
		bubbles: !1,
		cancelable: !0,
		detail: n
	});
	t && i.addEventListener(e, t, { once: !0 }), r ? er(i, a) : i.dispatchEvent(a);
}
or(vr, "handleAndDispatchCustomEvent");
// node_modules/@radix-ui/react-focus-guards/dist/index.mjs
var yr = Object.defineProperty, br = (e, t) => yr(e, "name", {
	value: t,
	configurable: !0
}), xr = 0, Sr = null;
function Cr(e) {
	return wr(), e.children;
}
br(Cr, "FocusGuards");
function wr() {
	W.useEffect(() => {
		Sr ||= {
			start: Tr(),
			end: Tr()
		};
		let { start: e, end: t } = Sr;
		return document.body.firstElementChild !== e && document.body.insertAdjacentElement("afterbegin", e), document.body.lastElementChild !== t && document.body.insertAdjacentElement("beforeend", t), xr++, () => {
			xr === 1 && (Sr?.start.remove(), Sr?.end.remove(), Sr = null), xr = Math.max(0, xr - 1);
		};
	}, []);
}
br(wr, "useFocusGuards");
function Tr() {
	let e = document.createElement("span");
	return e.setAttribute("data-radix-focus-guard", ""), e.tabIndex = 0, e.style.outline = "none", e.style.opacity = "0", e.style.position = "fixed", e.style.pointerEvents = "none", e;
}
br(Tr, "createFocusGuard");
// node_modules/@radix-ui/react-focus-scope/dist/index.mjs
var Er = Object.defineProperty, Dr = (e, t) => Er(e, "name", {
	value: t,
	configurable: !0
}), Or = "focusScope.autoFocusOnMount", kr = "focusScope.autoFocusOnUnmount", Ar = {
	bubbles: !1,
	cancelable: !0
}, jr = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Dr(function(e, t) {
	let { loop: n = !1, trapped: r = !1, branches: i, onMountAutoFocus: a, onUnmountAutoFocus: o, ...s } = e, [c, l] = W.useState(null), u = ir(a), d = ir(o), f = W.useRef(null), p = pn(t, l), m = W.useRef(i);
	W.useEffect(() => {
		m.current = i;
	});
	let h = W.useCallback((e) => e ? c?.contains(e) ? !0 : !!m.current?.some((t) => t.contains(e)) : !1, [c]), g = W.useRef({
		paused: !1,
		pause() {
			this.paused = !0;
		},
		resume() {
			this.paused = !1;
		}
	}).current;
	W.useEffect(() => {
		if (r) {
			let e = function(e) {
				if (g.paused || !c) return;
				let t = e.target;
				h(t) ? f.current = t : Hr(f.current, { select: !0 });
			}, t = function(e) {
				if (g.paused || !c) return;
				let t = e.relatedTarget;
				t !== null && (h(t) || Hr(f.current, { select: !0 }));
			}, n = function(e) {
				if (document.activeElement === document.body) for (let t of e) t.removedNodes.length > 0 && Hr(c);
			};
			Dr(e, "handleFocusIn"), Dr(t, "handleFocusOut"), Dr(n, "handleMutations"), document.addEventListener("focusin", e), document.addEventListener("focusout", t);
			let r = new MutationObserver(n);
			return c && r.observe(c, {
				childList: !0,
				subtree: !0
			}), () => {
				document.removeEventListener("focusin", e), document.removeEventListener("focusout", t), r.disconnect();
			};
		}
	}, [
		r,
		c,
		g.paused,
		h
	]), W.useEffect(() => {
		if (c) {
			Ur.add(g);
			let e = document.activeElement;
			if (!c.contains(e)) {
				let t = new CustomEvent(Or, Ar);
				c.addEventListener(Or, u), c.dispatchEvent(t), t.defaultPrevented || (Ir(Kr(Rr(c)), { select: !0 }), document.activeElement === e && Hr(c));
			}
			return () => {
				c.removeEventListener(Or, u);
				let t = c.ownerDocument, n = CustomEvent;
				setTimeout(() => {
					let r = new n(kr, Ar);
					c.addEventListener(kr, d), c.dispatchEvent(r), r.defaultPrevented || Hr(e ?? t.body, { select: !0 }), c.removeEventListener(kr, d), Ur.remove(g);
				}, 0);
			};
		}
	}, [
		c,
		u,
		d,
		g
	]);
	let _ = W.useCallback((e) => {
		if (!n && !r || g.paused) return;
		let t = e.key === "Tab" && !e.altKey && !e.ctrlKey && !e.metaKey, i = document.activeElement;
		if (t && i) {
			let t = e.currentTarget, [r, a] = Lr(t);
			r && a ? !e.shiftKey && i === a ? (e.preventDefault(), n && Hr(r, { select: !0 })) : e.shiftKey && i === r && (e.preventDefault(), n && Hr(a, { select: !0 })) : i === t && e.preventDefault();
		}
	}, [
		n,
		r,
		g.paused
	]);
	return /* @__PURE__ */ Y($n.div, {
		tabIndex: -1,
		...s,
		ref: p,
		onKeyDown: _
	});
}, "FocusScope")), Mr = W.createContext(null);
function Nr({ registry: e, children: t }) {
	return e ? /* @__PURE__ */ Y(Mr.Provider, {
		value: e,
		children: t
	}) : t;
}
Dr(Nr, "FocusScopeBranchProvider");
function Pr() {
	let [e, t] = W.useState([]);
	return {
		nodes: e,
		registry: W.useMemo(() => ({
			add: /* @__PURE__ */ Dr((e) => t((t) => t.includes(e) ? t : [...t, e]), "add"),
			remove: /* @__PURE__ */ Dr((e) => t((t) => t.filter((t) => t !== e)), "remove")
		}), [])
	};
}
Dr(Pr, "useFocusScopeBranchRegistry");
function Fr(e) {
	let t = W.useContext(Mr);
	W.useEffect(() => {
		if (e && t) return t.add(e), () => t.remove(e);
	}, [e, t]);
}
Dr(Fr, "useFocusScopeBranch");
function Ir(e, { select: t = !1 } = {}) {
	let n = document.activeElement;
	for (let r of e) if (Hr(r, { select: t }), document.activeElement !== n) return;
}
Dr(Ir, "focusFirst");
function Lr(e) {
	let t = Rr(e);
	return [zr(t, e), zr(t.reverse(), e)];
}
Dr(Lr, "getTabbableEdges");
function Rr(e) {
	let t = [], n = e.ownerDocument.createTreeWalker(e, NodeFilter.SHOW_ELEMENT, { acceptNode: /* @__PURE__ */ Dr((e) => {
		let t = e.tagName === "INPUT" && e.type === "hidden";
		return e.disabled || e.hidden || t ? NodeFilter.FILTER_SKIP : e.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	}, "acceptNode") });
	for (; n.nextNode();) t.push(n.currentNode);
	return t;
}
Dr(Rr, "getTabbableCandidates");
function zr(e, t) {
	let n = typeof t.checkVisibility == "function" && t.checkVisibility({ checkVisibilityCSS: !0 });
	for (let r of e) if (!(n ? !r.checkVisibility({ checkVisibilityCSS: !0 }) : Br(r, { upTo: t }))) return r;
}
Dr(zr, "findVisible");
function Br(e, { upTo: t }) {
	if (getComputedStyle(e).visibility === "hidden") return !0;
	for (; e;) {
		if (t !== void 0 && e === t) return !1;
		if (getComputedStyle(e).display === "none") return !0;
		e = e.parentElement;
	}
	return !1;
}
Dr(Br, "isHidden");
function Vr(e) {
	return e.tagName === "INPUT" && typeof e.select == "function";
}
Dr(Vr, "isSelectableInput");
function Hr(e, { select: t = !1 } = {}) {
	if (e && e.focus) {
		let n = (e.ownerDocument ?? document).activeElement;
		e.focus({ preventScroll: !0 }), e !== n && Vr(e) && t && e.select();
	}
}
Dr(Hr, "focus");
var Ur = Wr();
function Wr() {
	let e = [];
	return {
		add(t) {
			let n = e[0];
			t !== n && n?.pause(), e = Gr(e, t), e.unshift(t);
		},
		remove(t) {
			e = Gr(e, t), e[0]?.resume();
		}
	};
}
Dr(Wr, "createFocusScopesStack");
function Gr(e, t) {
	let n = [...e], r = n.indexOf(t);
	return r !== -1 && n.splice(r, 1), n;
}
Dr(Gr, "arrayRemove");
function Kr(e) {
	return e.filter((e) => e.tagName !== "A");
}
Dr(Kr, "removeLinks");
// node_modules/@radix-ui/react-id/dist/index.mjs
var qr = Object.defineProperty, Jr = (e, t) => qr(e, "name", {
	value: t,
	configurable: !0
}), Yr = W.useId || (() => void 0), Xr = 0;
function Zr(e) {
	let [t, n] = W.useState(Yr());
	return jn(() => {
		e || n((e) => e ?? String(Xr++));
	}, [e]), e || (t ? `radix-${t}` : "");
}
Jr(Zr, "useId");
// node_modules/@floating-ui/utils/dist/floating-ui.utils.mjs
var Qr = [
	"top",
	"right",
	"bottom",
	"left"
], $r = Math.min, ei = Math.max, ti = Math.round, ni = Math.floor, ri = (e) => ({
	x: e,
	y: e
}), ii = {
	left: "right",
	right: "left",
	bottom: "top",
	top: "bottom"
};
function ai(e, t, n) {
	return ei(e, $r(t, n));
}
function oi(e, t) {
	return typeof e == "function" ? e(t) : e;
}
function si(e) {
	return e.split("-")[0];
}
function ci(e) {
	return e.split("-")[1];
}
function li(e) {
	return e === "x" ? "y" : "x";
}
function ui(e) {
	return e === "y" ? "height" : "width";
}
function di(e) {
	let t = e[0];
	return t === "t" || t === "b" ? "y" : "x";
}
function fi(e) {
	return li(di(e));
}
function pi(e, t, n) {
	n === void 0 && (n = !1);
	let r = ci(e), i = fi(e), a = ui(i), o = i === "x" ? r === (n ? "end" : "start") ? "right" : "left" : r === "start" ? "bottom" : "top";
	return t.reference[a] > t.floating[a] && (o = Si(o)), [o, Si(o)];
}
function mi(e) {
	let t = Si(e);
	return [
		hi(e),
		t,
		hi(t)
	];
}
function hi(e) {
	return e.includes("start") ? e.replace("start", "end") : e.replace("end", "start");
}
var gi = ["left", "right"], _i = ["right", "left"], vi = ["top", "bottom"], yi = ["bottom", "top"];
function bi(e, t, n) {
	switch (e) {
		case "top":
		case "bottom": return n ? t ? _i : gi : t ? gi : _i;
		case "left":
		case "right": return t ? vi : yi;
		default: return [];
	}
}
function xi(e, t, n, r) {
	let i = ci(e), a = bi(si(e), n === "start", r);
	return i && (a = a.map((e) => e + "-" + i), t && (a = a.concat(a.map(hi)))), a;
}
function Si(e) {
	let t = si(e);
	return ii[t] + e.slice(t.length);
}
function Ci(e) {
	return {
		top: e.top ?? 0,
		right: e.right ?? 0,
		bottom: e.bottom ?? 0,
		left: e.left ?? 0
	};
}
function wi(e) {
	return typeof e == "number" ? {
		top: e,
		right: e,
		bottom: e,
		left: e
	} : Ci(e);
}
function Ti(e) {
	let { x: t, y: n, width: r, height: i } = e;
	return {
		width: r,
		height: i,
		top: n,
		left: t,
		right: t + r,
		bottom: n + i,
		x: t,
		y: n
	};
}
// node_modules/@floating-ui/core/dist/floating-ui.core.mjs
function Ei(e, t, n) {
	let { reference: r, floating: i } = e, a = di(t), o = fi(t), s = ui(o), c = si(t), l = a === "y", u = r.x + r.width / 2 - i.width / 2, d = r.y + r.height / 2 - i.height / 2, f = r[s] / 2 - i[s] / 2, p;
	switch (c) {
		case "top":
			p = {
				x: u,
				y: r.y - i.height
			};
			break;
		case "bottom":
			p = {
				x: u,
				y: r.y + r.height
			};
			break;
		case "right":
			p = {
				x: r.x + r.width,
				y: d
			};
			break;
		case "left":
			p = {
				x: r.x - i.width,
				y: d
			};
			break;
		default: p = {
			x: r.x,
			y: r.y
		};
	}
	let m = ci(t);
	return m && (p[o] += f * (m === "end" ? 1 : -1) * (n && l ? -1 : 1)), p;
}
async function Di(e, t) {
	t === void 0 && (t = {});
	let { x: n, y: r, platform: i, rects: a, elements: o, strategy: s } = e, { boundary: c = "clippingAncestors", rootBoundary: l = "viewport", elementContext: u = "floating", altBoundary: d = !1, padding: f = 0 } = oi(t, e), p = wi(f), m = o[d ? u === "floating" ? "reference" : "floating" : u], h = Ti(await i.getClippingRect({
		element: await (i.isElement == null ? void 0 : i.isElement(m)) ?? !0 ? m : m.contextElement || await (i.getDocumentElement == null ? void 0 : i.getDocumentElement(o.floating)),
		boundary: c,
		rootBoundary: l,
		strategy: s
	})), g = u === "floating" ? {
		x: n,
		y: r,
		width: a.floating.width,
		height: a.floating.height
	} : a.reference, _ = await (i.getOffsetParent == null ? void 0 : i.getOffsetParent(o.floating)), v = await (i.isElement == null ? void 0 : i.isElement(_)) && await (i.getScale == null ? void 0 : i.getScale(_)) || {
		x: 1,
		y: 1
	}, y = Ti(i.convertOffsetParentRelativeRectToViewportRelativeRect ? await i.convertOffsetParentRelativeRectToViewportRelativeRect({
		elements: o,
		rect: g,
		offsetParent: _,
		strategy: s
	}) : g);
	return {
		top: (h.top - y.top + p.top) / v.y,
		bottom: (y.bottom - h.bottom + p.bottom) / v.y,
		left: (h.left - y.left + p.left) / v.x,
		right: (y.right - h.right + p.right) / v.x
	};
}
var Oi = 50, ki = async (e, t, n) => {
	let { placement: r = "bottom", strategy: i = "absolute", middleware: a = [], platform: o } = n, s = o.detectOverflow ? o : {
		...o,
		detectOverflow: Di
	}, c = await (o.isRTL == null ? void 0 : o.isRTL(t)), l = await o.getElementRects({
		reference: e,
		floating: t,
		strategy: i
	}), { x: u, y: d } = Ei(l, r, c), f = r, p = 0, m = {};
	for (let n = 0; n < a.length; n++) {
		let h = a[n];
		if (!h) continue;
		let { name: g, fn: _ } = h, { x: v, y, data: b, reset: x } = await _({
			x: u,
			y: d,
			initialPlacement: r,
			placement: f,
			strategy: i,
			middlewareData: m,
			rects: l,
			platform: s,
			elements: {
				reference: e,
				floating: t
			}
		});
		u = v ?? u, d = y ?? d, m[g] = {
			...m[g],
			...b
		}, x && p < Oi && (p++, typeof x == "object" && (x.placement && (f = x.placement), x.rects && (l = x.rects === !0 ? await o.getElementRects({
			reference: e,
			floating: t,
			strategy: i
		}) : x.rects), {x: u, y: d} = Ei(l, f, c)), n = -1);
	}
	return {
		x: u,
		y: d,
		placement: f,
		strategy: i,
		middlewareData: m
	};
}, Ai = (e) => ({
	name: "arrow",
	options: e,
	async fn(t) {
		let { x: n, y: r, placement: i, rects: a, platform: o, elements: s, middlewareData: c } = t, { element: l, padding: u = 0 } = oi(e, t) || {};
		if (l == null) return {};
		let d = wi(u), f = {
			x: n,
			y: r
		}, p = fi(i), m = ui(p), h = await o.getDimensions(l), g = p === "y", _ = g ? "top" : "left", v = g ? "bottom" : "right", y = g ? "clientHeight" : "clientWidth", b = a.reference[m] + a.reference[p] - f[p] - a.floating[m], x = f[p] - a.reference[p], S = await (o.getOffsetParent == null ? void 0 : o.getOffsetParent(l)), C = S ? S[y] : 0;
		C && await (o.isElement == null ? void 0 : o.isElement(S)) || (C = s.floating[y] || a.floating[m]);
		let w = b / 2 - x / 2, T = C / 2 - h[m] / 2 - 1, E = $r(d[_], T), D = $r(d[v], T), O = C - h[m] - D, k = C / 2 - h[m] / 2 + w, A = ai(E, k, O), j = !c.arrow && ci(i) != null && k !== A && a.reference[m] / 2 - (k < E ? E : D) - h[m] / 2 < 0, M = j ? k < E ? k - E : k - O : 0;
		return {
			[p]: f[p] + M,
			data: {
				[p]: A,
				centerOffset: k - A - M,
				...j && { alignmentOffset: M }
			},
			reset: j
		};
	}
}), ji = function(e) {
	return e === void 0 && (e = {}), {
		name: "flip",
		options: e,
		async fn(t) {
			var n;
			let { placement: r, middlewareData: i, rects: a, initialPlacement: o, platform: s, elements: c } = t, { mainAxis: l = !0, crossAxis: u = !0, fallbackPlacements: d, fallbackStrategy: f = "bestFit", fallbackAxisSideDirection: p = "none", flipAlignment: m = !0, ...h } = oi(e, t);
			if ((n = i.arrow) != null && n.alignmentOffset) return {};
			let g = si(r), _ = di(o), v = si(o) === o, y = await (s.isRTL == null ? void 0 : s.isRTL(c.floating)), b = d || (v || !m ? [Si(o)] : mi(o)), x = p !== "none";
			!d && x && b.push(...xi(o, m, p, y));
			let S = [o, ...b], C = await s.detectOverflow(t, h), w = [], T = i.flip?.overflows || [];
			if (l && w.push(C[g]), u) {
				let e = pi(r, a, y);
				w.push(C[e[0]], C[e[1]]);
			}
			if (T = [...T, {
				placement: r,
				overflows: w
			}], !w.every((e) => e <= 0)) {
				let e = (i.flip?.index || 0) + 1, t = S[e];
				if (t && (u !== "alignment" || _ === di(t) || T.every((e) => di(e.placement) !== _ || e.overflows[0] > 0))) return {
					data: {
						index: e,
						overflows: T
					},
					reset: { placement: t }
				};
				let n = T.filter((e) => e.overflows[0] <= 0).sort((e, t) => e.overflows[1] - t.overflows[1])[0]?.placement;
				if (!n) switch (f) {
					case "bestFit": {
						let e = T.filter((e) => {
							if (x) {
								let t = di(e.placement);
								return t === _ || t === "y";
							}
							return !0;
						}).map((e) => [e.placement, e.overflows.filter((e) => e > 0).reduce((e, t) => e + t, 0)]).sort((e, t) => e[1] - t[1])[0]?.[0];
						e && (n = e);
						break;
					}
					case "initialPlacement": n = o;
				}
				if (r !== n) return { reset: { placement: n } };
			}
			return {};
		}
	};
};
function Mi(e, t) {
	return {
		top: e.top - t.height,
		right: e.right - t.width,
		bottom: e.bottom - t.height,
		left: e.left - t.width
	};
}
function Ni(e) {
	return Qr.some((t) => e[t] >= 0);
}
var Pi = function(e) {
	return e === void 0 && (e = {}), {
		name: "hide",
		options: e,
		async fn(t) {
			let { rects: n, platform: r } = t, { strategy: i = "referenceHidden", ...a } = oi(e, t);
			switch (i) {
				case "referenceHidden": {
					let e = Mi(await r.detectOverflow(t, {
						...a,
						elementContext: "reference"
					}), n.reference);
					return { data: {
						referenceHiddenOffsets: e,
						referenceHidden: Ni(e)
					} };
				}
				case "escaped": {
					let e = Mi(await r.detectOverflow(t, {
						...a,
						altBoundary: !0
					}), n.floating);
					return { data: {
						escapedOffsets: e,
						escaped: Ni(e)
					} };
				}
				default: return {};
			}
		}
	};
}, Fi = /*#__PURE__*/ new Set(["left", "top"]);
async function Ii(e, t) {
	let { placement: n, platform: r, elements: i } = e, a = await (r.isRTL == null ? void 0 : r.isRTL(i.floating)), o = si(n), s = ci(n), c = di(n) === "y", l = Fi.has(o) ? -1 : 1, u = a && c ? -1 : 1, d = oi(t, e), { mainAxis: f, crossAxis: p, alignmentAxis: m } = typeof d == "number" ? {
		mainAxis: d,
		crossAxis: 0,
		alignmentAxis: null
	} : {
		mainAxis: d.mainAxis || 0,
		crossAxis: d.crossAxis || 0,
		alignmentAxis: d.alignmentAxis
	};
	return s && typeof m == "number" && (p = s === "end" ? m * -1 : m), c ? {
		x: p * u,
		y: f * l
	} : {
		x: f * l,
		y: p * u
	};
}
var Li = function(e) {
	return e === void 0 && (e = 0), {
		name: "offset",
		options: e,
		async fn(t) {
			var n;
			let { x: r, y: i, placement: a, middlewareData: o } = t, s = await Ii(t, e);
			return a === o.offset?.placement && (n = o.arrow) != null && n.alignmentOffset ? {} : {
				x: r + s.x,
				y: i + s.y,
				data: {
					...s,
					placement: a
				}
			};
		}
	};
}, Ri = function(e) {
	return e === void 0 && (e = {}), {
		name: "shift",
		options: e,
		async fn(t) {
			let { x: n, y: r, placement: i, platform: a } = t, { mainAxis: o = !0, crossAxis: s = !1, limiter: c = { fn: (e) => {
				let { x: t, y: n } = e;
				return {
					x: t,
					y: n
				};
			} }, ...l } = oi(e, t), u = {
				x: n,
				y: r
			}, d = await a.detectOverflow(t, l), f = di(i), p = li(f), m = u[p], h = u[f], g = (e, t) => ai(t + d[e === "y" ? "top" : "left"], t, t - d[e === "y" ? "bottom" : "right"]);
			o && (m = g(p, m)), s && (h = g(f, h));
			let _ = c.fn({
				...t,
				[p]: m,
				[f]: h
			});
			return {
				..._,
				data: {
					x: _.x - n,
					y: _.y - r,
					enabled: {
						[p]: o,
						[f]: s
					}
				}
			};
		}
	};
}, zi = function(e) {
	return e === void 0 && (e = {}), {
		options: e,
		fn(t) {
			let { x: n, y: r, placement: i, rects: a, middlewareData: o } = t, { offset: s = 0, mainAxis: c = !0, crossAxis: l = !0 } = oi(e, t), u = {
				x: n,
				y: r
			}, d = di(i), f = li(d), p = u[f], m = u[d], h = oi(s, t), g = typeof h == "number" ? {
				mainAxis: h,
				crossAxis: 0
			} : {
				mainAxis: h.mainAxis ?? 0,
				crossAxis: h.crossAxis ?? 0
			};
			if (c) {
				let e = f === "y" ? "height" : "width", t = a.reference[f] - a.floating[e] + g.mainAxis, n = a.reference[f] + a.reference[e] - g.mainAxis;
				p < t ? p = t : p > n && (p = n);
			}
			if (l) {
				let e = f === "y" ? "width" : "height", t = Fi.has(si(i)), n = a.reference[d] - a.floating[e] + (t && o.offset?.[d] || 0) + (t ? 0 : g.crossAxis), r = a.reference[d] + a.reference[e] + (t ? 0 : o.offset?.[d] || 0) - (t ? g.crossAxis : 0);
				m < n ? m = n : m > r && (m = r);
			}
			return {
				[f]: p,
				[d]: m
			};
		}
	};
}, Bi = function(e) {
	return e === void 0 && (e = {}), {
		name: "size",
		options: e,
		async fn(t) {
			let { placement: n, rects: r, platform: i, elements: a } = t, { apply: o = () => {}, ...s } = oi(e, t), c = await i.detectOverflow(t, s), l = si(n), u = ci(n), d = di(n) === "y", { width: f, height: p } = r.floating, m, h;
			l === "top" || l === "bottom" ? (m = l, h = u === (await (i.isRTL == null ? void 0 : i.isRTL(a.floating)) ? "start" : "end") ? "left" : "right") : (h = l, m = u === "end" ? "top" : "bottom");
			let g = p - c.top - c.bottom, _ = f - c.left - c.right, v = $r(p - c[m], g), y = $r(f - c[h], _), b = t.middlewareData.shift, x = !b, S = v, C = y;
			b != null && b.enabled.x && (C = _), b != null && b.enabled.y && (S = g), x && !u && (d ? C = f - 2 * ei(c.left, c.right) : S = p - 2 * ei(c.top, c.bottom)), await o({
				...t,
				availableWidth: C,
				availableHeight: S
			});
			let w = await i.getDimensions(a.floating);
			return f !== w.width || p !== w.height ? { reset: { rects: !0 } } : {};
		}
	};
};
// node_modules/@floating-ui/utils/dist/floating-ui.utils.dom.mjs
function Vi() {
	return typeof window < "u";
}
function Hi(e) {
	return Gi(e) ? (e.nodeName || "").toLowerCase() : "#document";
}
function Ui(e) {
	var t;
	return (e == null || (t = e.ownerDocument) == null ? void 0 : t.defaultView) || window;
}
function Wi(e) {
	return ((Gi(e) ? e.ownerDocument : e.document) || window.document)?.documentElement;
}
function Gi(e) {
	return Vi() ? e instanceof Node || e instanceof Ui(e).Node : !1;
}
function Ki(e) {
	return Vi() ? e instanceof Element || e instanceof Ui(e).Element : !1;
}
function qi(e) {
	return Vi() ? e instanceof HTMLElement || e instanceof Ui(e).HTMLElement : !1;
}
function Ji(e) {
	return !Vi() || typeof ShadowRoot > "u" ? !1 : e instanceof ShadowRoot || e instanceof Ui(e).ShadowRoot;
}
function Yi(e) {
	let { overflow: t, overflowX: n, overflowY: r, display: i } = oa(e);
	return /auto|scroll|overlay|hidden|clip/.test(t + r + n) && i !== "inline" && i !== "contents";
}
function Xi(e) {
	return /^(table|td|th)$/.test(Hi(e));
}
function Zi(e) {
	try {
		if (e.matches(":popover-open")) return !0;
	} catch {}
	try {
		return e.matches(":modal");
	} catch {
		return !1;
	}
}
var Qi = /transform|translate|scale|rotate|perspective|filter/, $i = /paint|layout|strict|content/, ea = (e) => !!e && e !== "none", ta;
function na(e) {
	let t = Ki(e) ? oa(e) : e;
	return ea(t.transform) || ea(t.translate) || ea(t.scale) || ea(t.rotate) || ea(t.perspective) || !ia() && (ea(t.backdropFilter) || ea(t.filter)) || Qi.test(t.willChange || "") || $i.test(t.contain || "");
}
function ra(e) {
	let t = ca(e);
	for (; qi(t) && !aa(t);) {
		if (na(t)) return t;
		if (Zi(t)) return null;
		t = ca(t);
	}
	return null;
}
function ia() {
	return ta ??= typeof CSS < "u" && CSS.supports && CSS.supports("-webkit-backdrop-filter", "none"), ta;
}
function aa(e) {
	return /^(html|body|#document)$/.test(Hi(e));
}
function oa(e) {
	return Ui(e).getComputedStyle(e);
}
function sa(e) {
	return Ki(e) ? {
		scrollLeft: e.scrollLeft,
		scrollTop: e.scrollTop
	} : {
		scrollLeft: e.scrollX,
		scrollTop: e.scrollY
	};
}
function ca(e) {
	if (Hi(e) === "html") return e;
	let t = e.assignedSlot || e.parentNode || Ji(e) && e.host || Wi(e);
	return Ji(t) ? t.host : t;
}
function la(e) {
	let t = ca(e);
	return aa(t) ? (e.ownerDocument || e).body : qi(t) && Yi(t) ? t : la(t);
}
function ua(e, t, n) {
	t === void 0 && (t = []), n === void 0 && (n = !0);
	let r = la(e), i = r === e.ownerDocument?.body, a = Ui(r);
	if (i) {
		let e = da(a);
		return t.concat(a, a.visualViewport || [], Yi(r) ? r : [], e && n ? ua(e) : []);
	}
	return t.concat(r, ua(r, [], n));
}
function da(e) {
	return e.parent && Object.getPrototypeOf(e.parent) ? e.frameElement : null;
}
// node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs
function fa(e) {
	let t = oa(e), n = parseFloat(t.width) || 0, r = parseFloat(t.height) || 0, i = qi(e), a = i ? e.offsetWidth : n, o = i ? e.offsetHeight : r, s = ti(n) !== a || ti(r) !== o;
	return s && (n = a, r = o), {
		width: n,
		height: r,
		$: s
	};
}
function pa(e) {
	return Ki(e) ? e : e.contextElement;
}
function ma(e) {
	let t = pa(e);
	if (!qi(t)) return ri(1);
	let n = t.getBoundingClientRect(), { width: r, height: i, $: a } = fa(t), o = (a ? ti(n.width) : n.width) / r, s = (a ? ti(n.height) : n.height) / i;
	return o && Number.isFinite(o) || (o = 1), s && Number.isFinite(s) || (s = 1), {
		x: o,
		y: s
	};
}
var ha = /*#__PURE__*/ ri(0);
function ga(e) {
	let t = Ui(e);
	return !ia() || !t.visualViewport ? ha : {
		x: t.visualViewport.offsetLeft,
		y: t.visualViewport.offsetTop
	};
}
function _a(e, t, n) {
	return t === void 0 && (t = !1), !!n && t && n === Ui(e);
}
function va(e, t, n, r) {
	t === void 0 && (t = !1), n === void 0 && (n = !1);
	let i = e.getBoundingClientRect(), a = pa(e), o = ri(1);
	t && (r ? Ki(r) && (o = ma(r)) : o = ma(e));
	let s = _a(a, n, r) ? ga(a) : ri(0), c = (i.left + s.x) / o.x, l = (i.top + s.y) / o.y, u = i.width / o.x, d = i.height / o.y;
	if (a && r) {
		let e = Ui(a), t = Ki(r) ? Ui(r) : r, n = e, i = da(n);
		for (; i && t !== n;) {
			let e = ma(i), t = i.getBoundingClientRect(), r = oa(i), a = t.left + (i.clientLeft + parseFloat(r.paddingLeft)) * e.x, o = t.top + (i.clientTop + parseFloat(r.paddingTop)) * e.y;
			c *= e.x, l *= e.y, u *= e.x, d *= e.y, c += a, l += o, n = Ui(i), i = da(n);
		}
	}
	return Ti({
		width: u,
		height: d,
		x: c,
		y: l
	});
}
function ya(e, t) {
	let n = sa(e).scrollLeft;
	return t ? t.left + n : va(Wi(e)).left + n;
}
function ba(e, t) {
	let n = e.getBoundingClientRect();
	return {
		x: n.left + t.scrollLeft - ya(e, n),
		y: n.top + t.scrollTop
	};
}
function xa(e) {
	let { elements: t, rect: n, offsetParent: r, strategy: i } = e, a = i === "fixed", o = Wi(r), s = t ? Zi(t.floating) : !1;
	if (r === o || s && a) return n;
	let c = {
		scrollLeft: 0,
		scrollTop: 0
	}, l = ri(1), u = ri(0), d = qi(r);
	if ((d || !a) && ((Hi(r) !== "body" || Yi(o)) && (c = sa(r)), d)) {
		let e = va(r);
		l = ma(r), u.x = e.x + r.clientLeft, u.y = e.y + r.clientTop;
	}
	let f = o && !d && !a ? ba(o, c) : ri(0);
	return {
		width: n.width * l.x,
		height: n.height * l.y,
		x: n.x * l.x - c.scrollLeft * l.x + u.x + f.x,
		y: n.y * l.y - c.scrollTop * l.y + u.y + f.y
	};
}
function Sa(e) {
	return e.getClientRects ? Array.from(e.getClientRects()) : [];
}
function Ca(e) {
	let t = sa(e), n = e.ownerDocument.body, r = ei(e.scrollWidth, e.clientWidth, n.scrollWidth, n.clientWidth), i = ei(e.scrollHeight, e.clientHeight, n.scrollHeight, n.clientHeight), a = -t.scrollLeft + ya(e), o = -t.scrollTop;
	return oa(n).direction === "rtl" && (a += ei(e.clientWidth, n.clientWidth) - r), {
		width: r,
		height: i,
		x: a,
		y: o
	};
}
var wa = 25;
function Ta(e, t, n) {
	n === void 0 && (n = "viewport");
	let r = n === "layoutViewport", i = Ui(e), a = Wi(e), o = i.visualViewport, s = a.clientWidth, c = a.clientHeight, l = 0, u = 0;
	if (o) {
		let e = !ia() || t === "fixed";
		r ? e || (l = -o.offsetLeft, u = -o.offsetTop) : (s = o.width, c = o.height, e && (l = o.offsetLeft, u = o.offsetTop));
	}
	if (ya(a) <= 0) {
		let e = a.ownerDocument, t = e.body, n = getComputedStyle(t), r = e.compatMode === "CSS1Compat" && parseFloat(n.marginLeft) + parseFloat(n.marginRight) || 0, i = Math.abs(a.clientWidth - t.clientWidth - r), o = getComputedStyle(a).scrollbarGutter === "stable both-edges" ? i / 2 : i;
		o <= wa && (s -= o);
	}
	return {
		width: s,
		height: c,
		x: l,
		y: u
	};
}
function Ea(e, t) {
	let n = va(e, !0, t === "fixed"), r = n.top + e.clientTop, i = n.left + e.clientLeft, a = ma(e);
	return {
		width: e.clientWidth * a.x,
		height: e.clientHeight * a.y,
		x: i * a.x,
		y: r * a.y
	};
}
function Da(e, t, n) {
	let r;
	if (t === "viewport" || t === "layoutViewport") r = Ta(e, n, t);
	else if (t === "document") r = Ca(Wi(e));
	else if (Ki(t)) r = Ea(t, n);
	else {
		let n = ga(e);
		r = {
			x: t.x - n.x,
			y: t.y - n.y,
			width: t.width,
			height: t.height
		};
	}
	return Ti(r);
}
function Oa(e, t) {
	let n = t.get(e);
	if (n) return n;
	let r = ua(e, [], !1).filter((e) => Ki(e) && Hi(e) !== "body"), i = null, a = oa(e).position === "fixed", o = a ? ca(e) : e;
	for (; Ki(o) && !aa(o);) {
		let e = oa(o), t = na(o), n = i ? i.position : a ? "fixed" : "";
		!t && (n === "fixed" || n === "absolute" && e.position === "static") ? r = r.filter((e) => e !== o) : i = e, o = ca(o);
	}
	return t.set(e, r), r;
}
function ka(e) {
	let { element: t, boundary: n, rootBoundary: r, strategy: i } = e, a = [...n === "clippingAncestors" ? Zi(t) ? [] : Oa(t, this._c) : [].concat(n), r], o = Da(t, a[0], i), s = o.top, c = o.right, l = o.bottom, u = o.left;
	for (let e = 1; e < a.length; e++) {
		let n = Da(t, a[e], i);
		s = ei(n.top, s), c = $r(n.right, c), l = $r(n.bottom, l), u = ei(n.left, u);
	}
	return {
		width: c - u,
		height: l - s,
		x: u,
		y: s
	};
}
function Aa(e) {
	let { width: t, height: n } = fa(e);
	return {
		width: t,
		height: n
	};
}
function ja(e, t, n) {
	let r = qi(t), i = Wi(t), a = n === "fixed", o = va(e, !0, a, t), s = {
		scrollLeft: 0,
		scrollTop: 0
	}, c = ri(0);
	if ((r || !a) && ((Hi(t) !== "body" || Yi(i)) && (s = sa(t)), r)) {
		let e = va(t, !0, a, t);
		c.x = e.x + t.clientLeft, c.y = e.y + t.clientTop;
	}
	!r && i && (c.x = ya(i));
	let l = i && !r && !a ? ba(i, s) : ri(0);
	return {
		x: o.left + s.scrollLeft - c.x - l.x,
		y: o.top + s.scrollTop - c.y - l.y,
		width: o.width,
		height: o.height
	};
}
function Ma(e) {
	return oa(e).position === "static";
}
function Na(e, t) {
	if (!qi(e) || oa(e).position === "fixed") return null;
	if (t) return t(e);
	let n = e.offsetParent;
	return Wi(e) === n && (n = n.ownerDocument.body), n;
}
function Pa(e, t) {
	let n = Ui(e);
	if (Zi(e)) return n;
	if (!qi(e)) {
		let t = ca(e);
		for (; t && !aa(t);) {
			if (Ki(t) && !Ma(t)) return t;
			t = ca(t);
		}
		return n;
	}
	let r = Na(e, t);
	for (; r && Xi(r) && Ma(r);) r = Na(r, t);
	return r && aa(r) && Ma(r) && !na(r) ? n : r || ra(e) || n;
}
var Fa = async function(e) {
	let t = this.getOffsetParent || Pa, n = this.getDimensions, r = await n(e.floating);
	return {
		reference: ja(e.reference, await t(e.floating), e.strategy),
		floating: {
			x: 0,
			y: 0,
			width: r.width,
			height: r.height
		}
	};
};
function Ia(e) {
	return oa(e).direction === "rtl";
}
var La = {
	convertOffsetParentRelativeRectToViewportRelativeRect: xa,
	getDocumentElement: Wi,
	getClippingRect: ka,
	getOffsetParent: Pa,
	getElementRects: Fa,
	getClientRects: Sa,
	getDimensions: Aa,
	getScale: ma,
	isElement: Ki,
	isRTL: Ia
};
function Ra(e, t) {
	return e.x === t.x && e.y === t.y && e.width === t.width && e.height === t.height;
}
function za(e, t, n) {
	let r = null, i, a = Wi(e);
	function o() {
		var e;
		clearTimeout(i), (e = r) == null || e.disconnect(), r = null;
	}
	function s(n, c) {
		n === void 0 && (n = !1), c === void 0 && (c = 1), o();
		let l = e.getBoundingClientRect(), { left: u, top: d, width: f, height: p } = l;
		if (n || t(), !f || !p) return;
		let m = ni(d), h = ni(a.clientWidth - (u + f)), g = ni(a.clientHeight - (d + p)), _ = ni(u), v = {
			rootMargin: -m + "px " + -h + "px " + -g + "px " + -_ + "px",
			threshold: ei(0, $r(1, c)) || 1
		}, y = !0;
		function b(t) {
			let n = t[0].intersectionRatio;
			if (!Ra(l, e.getBoundingClientRect())) return s();
			if (n !== c) {
				if (!y) return s();
				n ? s(!1, n) : i = setTimeout(() => {
					s(!1, 1e-7);
				}, 1e3);
			}
			y = !1;
		}
		try {
			r = new IntersectionObserver(b, {
				...v,
				root: a.ownerDocument
			});
		} catch {
			r = new IntersectionObserver(b, v);
		}
		r.observe(e);
	}
	let c = Ui(e), l = () => s(n);
	return c.addEventListener("resize", l), s(!0), () => {
		c.removeEventListener("resize", l), o();
	};
}
function Ba(e, t, n, r) {
	r === void 0 && (r = {});
	let { ancestorScroll: i = !0, ancestorResize: a = !0, elementResize: o = typeof ResizeObserver == "function", layoutShift: s = typeof IntersectionObserver == "function", animationFrame: c = !1 } = r, l = pa(e), u = i || a ? [...l ? ua(l) : [], ...t ? ua(t) : []] : [];
	u.forEach((e) => {
		i && e.addEventListener("scroll", n), a && e.addEventListener("resize", n);
	});
	let d = l && s ? za(l, n, a) : null, f = -1, p = null;
	o && (p = new ResizeObserver((e) => {
		let [r] = e;
		r && r.target === l && p && t && (p.unobserve(t), cancelAnimationFrame(f), f = requestAnimationFrame(() => {
			var e;
			(e = p) == null || e.observe(t);
		})), n();
	}), l && !c && p.observe(l), t && p.observe(t));
	let m, h = c ? va(e) : null;
	c && g();
	function g() {
		let t = va(e);
		h && !Ra(h, t) && n(), h = t, m = requestAnimationFrame(g);
	}
	return n(), () => {
		var e;
		u.forEach((e) => {
			i && e.removeEventListener("scroll", n), a && e.removeEventListener("resize", n);
		}), d?.(), (e = p) == null || e.disconnect(), p = null, c && cancelAnimationFrame(m);
	};
}
var Va = Li, Ha = Ri, Ua = ji, Wa = Bi, Ga = Pi, Ka = Ai, qa = zi, Ja = (e, t, n) => {
	let r = /* @__PURE__ */ new Map(), i = n ?? {}, a = {
		...La,
		...i.platform,
		_c: r
	};
	return ki(e, t, {
		...i,
		platform: a
	});
}, Ya = typeof document < "u" ? ue : function() {};
function Xa(e, t) {
	if (e === t) return !0;
	if (typeof e != typeof t) return !1;
	if (typeof e == "function" && e.toString() === t.toString()) return !0;
	let n, r, i;
	if (e && t && typeof e == "object") {
		if (Array.isArray(e)) {
			if (n = e.length, n !== t.length) return !1;
			for (r = n; r-- !== 0;) if (!Xa(e[r], t[r])) return !1;
			return !0;
		}
		if (i = Object.keys(e), n = i.length, n !== Object.keys(t).length) return !1;
		for (r = n; r-- !== 0;) if (!{}.hasOwnProperty.call(t, i[r])) return !1;
		for (r = n; r-- !== 0;) {
			let n = i[r];
			if (!(n === "_owner" && e.$$typeof) && !Xa(e[n], t[n])) return !1;
		}
		return !0;
	}
	return e !== e && t !== t;
}
function Za(e) {
	return typeof window > "u" ? 1 : (e.ownerDocument.defaultView || window).devicePixelRatio || 1;
}
function Qa(e, t) {
	let n = Za(e);
	return Math.round(t * n) / n;
}
function $a(e) {
	let t = W.useRef(e);
	return Ya(() => {
		t.current = e;
	}), t;
}
function eo(e) {
	e === void 0 && (e = {});
	let { placement: t = "bottom", strategy: n = "absolute", middleware: r = [], platform: i, elements: { reference: a, floating: o } = {}, transform: s = !0, whileElementsMounted: c, open: l } = e, [u, d] = W.useState({
		x: 0,
		y: 0,
		strategy: n,
		placement: t,
		middlewareData: {},
		isPositioned: !1
	}), [f, p] = W.useState(r);
	Xa(f, r) || p(r);
	let [m, h] = W.useState(null), [g, _] = W.useState(null), v = W.useCallback((e) => {
		e !== S.current && (S.current = e, h(e));
	}, []), y = W.useCallback((e) => {
		e !== C.current && (C.current = e, _(e));
	}, []), b = a || m, x = o || g, S = W.useRef(null), C = W.useRef(null), w = W.useRef(u), T = c != null, E = $a(c), D = $a(i), O = $a(l), k = W.useCallback(() => {
		if (!S.current || !C.current) return;
		let e = {
			placement: t,
			strategy: n,
			middleware: f
		};
		D.current && (e.platform = D.current), Ja(S.current, C.current, e).then((e) => {
			let t = {
				...e,
				isPositioned: O.current !== !1
			};
			A.current && !Xa(w.current, t) && (w.current = t, me.flushSync(() => {
				d(t);
			}));
		});
	}, [
		f,
		t,
		n,
		D,
		O
	]);
	Ya(() => {
		l === !1 && w.current.isPositioned && (w.current.isPositioned = !1, d((e) => ({
			...e,
			isPositioned: !1
		})));
	}, [l]);
	let A = W.useRef(!1);
	Ya(() => (A.current = !0, () => {
		A.current = !1;
	}), []), Ya(() => {
		if (b && (S.current = b), x && (C.current = x), b && x) {
			if (E.current) return E.current(b, x, k);
			k();
		}
	}, [
		b,
		x,
		k,
		E,
		T
	]);
	let j = W.useMemo(() => ({
		reference: S,
		floating: C,
		setReference: v,
		setFloating: y
	}), [v, y]), M = W.useMemo(() => ({
		reference: b,
		floating: x
	}), [b, x]), N = W.useMemo(() => {
		let e = {
			position: n,
			left: 0,
			top: 0
		};
		if (!M.floating) return e;
		let t = Qa(M.floating, u.x), r = Qa(M.floating, u.y);
		return s ? {
			...e,
			transform: "translate(" + t + "px, " + r + "px)",
			...Za(M.floating) >= 1.5 && { willChange: "transform" }
		} : {
			position: n,
			left: t,
			top: r
		};
	}, [
		n,
		s,
		M.floating,
		u.x,
		u.y
	]);
	return W.useMemo(() => ({
		...u,
		update: k,
		refs: j,
		elements: M,
		floatingStyles: N
	}), [
		u,
		k,
		j,
		M,
		N
	]);
}
var to = (e) => {
	function t(e) {
		return {}.hasOwnProperty.call(e, "current");
	}
	return {
		name: "arrow",
		options: e,
		fn(n) {
			let { element: r, padding: i } = typeof e == "function" ? e(n) : e;
			return r && t(r) ? r.current == null ? {} : Ka({
				element: r.current,
				padding: i
			}).fn(n) : r ? Ka({
				element: r,
				padding: i
			}).fn(n) : {};
		}
	};
}, no = (e, t) => {
	let n = Va(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, ro = (e, t) => {
	let n = Ha(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, io = (e, t) => ({
	fn: qa(e).fn,
	options: [e, t]
}), ao = (e, t) => {
	let n = Ua(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, oo = (e, t) => {
	let n = Wa(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, so = (e, t) => {
	let n = Ga(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, co = (e, t) => {
	let n = to(e);
	return {
		name: n.name,
		fn: n.fn,
		options: [e, t]
	};
}, lo = Object.defineProperty, uo = (e, t) => lo(e, "name", {
	value: t,
	configurable: !0
});
function fo(e) {
	let [t, n] = W.useState(void 0);
	return jn(() => {
		if (e) {
			n({
				width: e.offsetWidth,
				height: e.offsetHeight
			});
			let t = 0, r = new ResizeObserver((r) => {
				if (!Array.isArray(r) || !r.length) return;
				let i = r[0];
				window.cancelAnimationFrame(t), t = window.requestAnimationFrame(() => {
					let t, r;
					if ("borderBoxSize" in i) {
						let e = i.borderBoxSize, n = Array.isArray(e) ? e[0] : e;
						t = n.inlineSize, r = n.blockSize;
					} else t = e.offsetWidth, r = e.offsetHeight;
					n({
						width: t,
						height: r
					});
				});
			});
			return r.observe(e, { box: "border-box" }), () => {
				window.cancelAnimationFrame(t), r.unobserve(e);
			};
		}
		n(void 0);
	}, [e]), t;
}
uo(fo, "useSize");
// node_modules/@radix-ui/react-popper/dist/index.mjs
var po = Object.defineProperty, mo = (e, t) => po(e, "name", {
	value: t,
	configurable: !0
}), ho = {
	Partial: "partial",
	Always: "always"
}, go = {
	Optimized: "optimized",
	Always: "always"
}, _o = "Popper", [vo, yo] = /* @__PURE__ */ sn(_o), [bo, xo] = vo(_o), So = /* @__PURE__ */ mo((e) => {
	let { __scopePopper: t, children: n } = e, [r, i] = W.useState(null), [a, o] = W.useState(void 0);
	return /* @__PURE__ */ Y(bo, {
		scope: t,
		anchor: r,
		onAnchorChange: i,
		placementState: a,
		setPlacementState: o,
		children: n
	});
}, "Popper"), Co = "PopperAnchor", wo = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ mo(function(e, t) {
	let { __scopePopper: n, virtualRef: r, ...i } = e, a = xo(Co, n), o = W.useRef(null), s = a.onAnchorChange, c = pn(t, W.useCallback((e) => {
		o.current = e, e && s(e);
	}, [s])), l = W.useRef(null);
	W.useEffect(() => {
		if (!r) return;
		let e = l.current;
		l.current = r.current, e !== l.current && s(l.current);
	});
	let u = a.placementState && jo(a.placementState), d = u?.[0], f = u?.[1];
	return r ? null : /* @__PURE__ */ Y($n.div, {
		"data-radix-popper-side": d,
		"data-radix-popper-align": f,
		...i,
		ref: c
	});
}, "PopperAnchor")), To = "PopperContent", [Eo, Do] = vo(To), Oo = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ mo(function(e, t) {
	let { __scopePopper: n, side: r = "bottom", sideOffset: i = 0, align: a = "center", alignOffset: o = 0, arrowPadding: s = 0, avoidCollisions: c = !0, collisionBoundary: l = [], collisionPadding: u = 0, sticky: d = ho.Partial, hideWhenDetached: f = !1, updatePositionStrategy: p = go.Optimized, onPlaced: m, ...h } = e, g = xo(To, n), [_, v] = W.useState(null), y = pn(t, v), [b, x] = W.useState(null), S = fo(b), C = S?.width ?? 0, w = S?.height ?? 0, T = r + (a === "center" ? "" : "-" + a), E = typeof u == "number" ? u : {
		top: 0,
		right: 0,
		bottom: 0,
		left: 0,
		...u
	}, D = Array.isArray(l) ? l : [l], O = D.length > 0, k = {
		padding: E,
		boundary: D.filter(ko),
		altBoundary: O
	}, { refs: A, floatingStyles: j, placement: M, isPositioned: N, middlewareData: P } = eo({
		strategy: "fixed",
		placement: T,
		whileElementsMounted: /* @__PURE__ */ mo((...e) => Ba(...e, { animationFrame: p === go.Always }), "whileElementsMounted"),
		elements: { reference: g.anchor },
		middleware: [
			no({
				mainAxis: i + w,
				alignmentAxis: o
			}),
			c && ro({
				mainAxis: !0,
				crossAxis: !1,
				...d === ho.Partial ? { limiter: io() } : {},
				...k
			}),
			c && ao({ ...k }),
			oo({
				...k,
				apply: /* @__PURE__ */ mo(({ elements: e, rects: t, availableWidth: n, availableHeight: r }) => {
					let { width: i, height: a } = t.reference, o = e.floating.style;
					o.setProperty("--radix-popper-available-width", `${n}px`), o.setProperty("--radix-popper-available-height", `${r}px`), o.setProperty("--radix-popper-anchor-width", `${i}px`), o.setProperty("--radix-popper-anchor-height", `${a}px`);
				}, "apply")
			}),
			b && co({
				element: b,
				padding: s
			}),
			Ao({
				arrowWidth: C,
				arrowHeight: w
			}),
			f && so(O ? {
				strategy: "referenceHidden",
				...k
			} : {
				strategy: "referenceHidden",
				padding: k.padding,
				altBoundary: k.altBoundary
			})
		]
	}), F = g.setPlacementState;
	jn(() => (F(M), () => {
		F(void 0);
	}), [M, F]);
	let [I, L] = jo(M), R = ir(m);
	jn(() => {
		N && R?.();
	}, [N, R]);
	let z = P.arrow?.x, B = P.arrow?.y, V = P.arrow?.centerOffset !== 0, [ee, H] = W.useState();
	return jn(() => {
		_ && H(window.getComputedStyle(_).zIndex);
	}, [_]), /* @__PURE__ */ Y("div", {
		ref: A.setFloating,
		"data-radix-popper-content-wrapper": "",
		style: {
			...j,
			transform: N ? j.transform : "translate(0, -200%)",
			minWidth: "max-content",
			zIndex: ee,
			"--radix-popper-transform-origin": [P.transformOrigin?.x, P.transformOrigin?.y].join(" "),
			...P.hide?.referenceHidden && {
				visibility: "hidden",
				pointerEvents: "none"
			}
		},
		dir: e.dir,
		children: /* @__PURE__ */ Y(Eo, {
			scope: n,
			placedSide: I,
			placedAlign: L,
			onArrowChange: x,
			arrowX: z,
			arrowY: B,
			shouldHideArrow: V,
			children: /* @__PURE__ */ Y($n.div, {
				"data-side": I,
				"data-align": L,
				...h,
				ref: y,
				style: {
					...h.style,
					animation: N ? h.style?.animation : "none"
				}
			})
		})
	});
}, "PopperContent"));
function ko(e) {
	return e !== null;
}
mo(ko, "isNotNull");
var Ao = /* @__PURE__ */ mo((e) => ({
	name: "transformOrigin",
	options: e,
	fn(t) {
		let { placement: n, rects: r, middlewareData: i } = t, a = i.arrow?.centerOffset !== 0, o = a ? 0 : e.arrowWidth, s = a ? 0 : e.arrowHeight, [c, l] = jo(n), u = {
			start: "0%",
			center: "50%",
			end: "100%"
		}[l], d = (i.arrow?.x ?? 0) + o / 2, f = (i.arrow?.y ?? 0) + s / 2, p = "", m = "";
		return c === "bottom" ? (p = a ? u : `${d}px`, m = `${-s}px`) : c === "top" ? (p = a ? u : `${d}px`, m = `${r.floating.height + s}px`) : c === "right" ? (p = `${-s}px`, m = a ? u : `${f}px`) : c === "left" && (p = `${r.floating.width + s}px`, m = a ? u : `${f}px`), { data: {
			x: p,
			y: m
		} };
	}
}), "transformOrigin");
function jo(e) {
	let [t, n = "center"] = e.split("-");
	return [t, n];
}
mo(jo, "getSideAndAlignFromPlacement");
// node_modules/@radix-ui/react-portal/dist/index.mjs
var Mo = Object.defineProperty, No = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ ((e, t) => Mo(e, "name", {
	value: t,
	configurable: !0
}))(function(e, t) {
	let { container: n, ...r } = e, [i, a] = W.useState(!1);
	jn(() => a(!0), []);
	let o = n || i && globalThis?.document?.body;
	return o ? me.createPortal(/* @__PURE__ */ Y($n.div, {
		...r,
		ref: t
	}), o) : null;
}, "Portal")), Po = Object.defineProperty, Fo = (e, t) => Po(e, "name", {
	value: t,
	configurable: !0
});
function Io(e, t) {
	return W.useReducer((e, n) => t[e][n] ?? e, e);
}
Fo(Io, "useStateMachine");
var Lo = /* @__PURE__ */ Fo((e) => {
	let { present: t, children: n } = e, r = Ro(t), i = typeof n == "function" ? n({ present: r.isPresent }) : W.Children.only(n), a = Bo(r.ref, Ho(i));
	return typeof n == "function" || r.isPresent ? W.cloneElement(i, { ref: a }) : null;
}, "Presence");
function Ro(e) {
	let [t, n] = W.useState(), r = W.useRef(null), i = W.useRef(e), a = W.useRef("none"), o = W.useRef(void 0), [s, c] = Io(e ? "mounted" : "unmounted", {
		mounted: {
			UNMOUNT: "unmounted",
			ANIMATION_OUT: "unmountSuspended"
		},
		unmountSuspended: {
			MOUNT: "mounted",
			ANIMATION_END: "unmounted"
		},
		unmounted: { MOUNT: "mounted" }
	});
	return W.useEffect(() => {
		s === "mounted" ? (a.current = o.current ?? Vo(r.current), o.current = void 0) : a.current = "none";
	}, [s]), jn(() => {
		let t = r.current, n = i.current;
		if (n !== e) {
			let r = a.current, s = Vo(t);
			e ? (o.current = s, c("MOUNT")) : s === "none" || t?.display === "none" ? c("UNMOUNT") : c(n && r !== s ? "ANIMATION_OUT" : "UNMOUNT"), i.current = e;
		}
	}, [e, c]), jn(() => {
		if (t) {
			let e, n = t.ownerDocument.defaultView ?? window, o = /* @__PURE__ */ Fo((a) => {
				let o = Vo(r.current).includes(CSS.escape(a.animationName));
				if (a.target === t && o && (c("ANIMATION_END"), !i.current)) {
					let r = t.style.animationFillMode;
					t.style.animationFillMode = "forwards", e = n.setTimeout(() => {
						t.style.animationFillMode === "forwards" && (t.style.animationFillMode = r);
					});
				}
			}, "handleAnimationEnd"), s = /* @__PURE__ */ Fo((e) => {
				e.target === t && (a.current = Vo(r.current));
			}, "handleAnimationStart");
			return t.addEventListener("animationstart", s), t.addEventListener("animationcancel", o), t.addEventListener("animationend", o), () => {
				n.clearTimeout(e), t.removeEventListener("animationstart", s), t.removeEventListener("animationcancel", o), t.removeEventListener("animationend", o);
			};
		}
		c("ANIMATION_END");
	}, [t, c]), {
		isPresent: ["mounted", "unmountSuspended"].includes(s),
		ref: W.useCallback((e) => {
			if (e) {
				let t = getComputedStyle(e);
				r.current = t, o.current = Vo(t);
			} else r.current = null;
			n(e);
		}, [])
	};
}
Fo(Ro, "usePresence");
function zo(e, t) {
	if (typeof e == "function") return e(t);
	e != null && (e.current = t);
}
Fo(zo, "setRef");
function Bo(...e) {
	let t = W.useRef(e);
	return t.current = e, W.useCallback((e) => {
		let n = t.current, r = !1, i = n.map((t) => {
			let n = zo(t, e);
			return !r && typeof n == "function" && (r = !0), n;
		});
		if (r) return () => {
			for (let e = 0; e < i.length; e++) {
				let t = i[e];
				typeof t == "function" ? t() : zo(n[e], null);
			}
		};
	}, []);
}
Fo(Bo, "useStableComposedRefs");
function Vo(e) {
	return e?.animationName || "none";
}
Fo(Vo, "getAnimationName");
function Ho(e) {
	let t = Object.getOwnPropertyDescriptor(e.props, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning;
	return n ? e.ref : (t = Object.getOwnPropertyDescriptor(e, "ref")?.get, n = t && "isReactWarning" in t && t.isReactWarning, n ? e.props.ref : e.props.ref || e.ref);
}
Fo(Ho, "getElementRef");
// node_modules/@radix-ui/react-use-effect-event/dist/index.mjs
var Uo = Object.defineProperty, Wo = (e, t) => Uo(e, "name", {
	value: t,
	configurable: !0
}), Go = W.useEffectEvent, Ko = W.useInsertionEffect;
function qo(e) {
	if (typeof Go == "function") return Go(e);
	let t = W.useRef(() => {
		throw Error("Cannot call an event handler while rendering.");
	});
	return typeof Ko == "function" ? Ko(() => {
		t.current = e;
	}) : jn(() => {
		t.current = e;
	}), W.useMemo(() => ((...e) => t.current?.(...e)), []);
}
Wo(qo, "useEffectEvent");
// node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var Jo = Object.defineProperty, Yo = (e, t) => Jo(e, "name", {
	value: t,
	configurable: !0
}), Xo = W.useInsertionEffect || jn;
function Zo({ prop: e, defaultProp: t, onChange: n = /* @__PURE__ */ Yo(() => {}, "onChange"), caller: r }) {
	let [i, a, o] = Qo({
		defaultProp: t,
		onChange: n
	}), s = e !== void 0;
	return [s ? e : i, W.useCallback((t) => {
		if (s) {
			let n = $o(t) ? t(e) : t;
			n !== e && o.current?.(n);
		} else a(t);
	}, [
		s,
		e,
		a,
		o
	])];
}
Yo(Zo, "useControllableState");
function Qo({ defaultProp: e, onChange: t }) {
	let [n, r] = W.useState(e), i = W.useRef(n), a = W.useRef(t);
	return Xo(() => {
		a.current = t;
	}, [t]), W.useEffect(() => {
		i.current !== n && (a.current?.(n), i.current = n);
	}, [n, i]), [
		n,
		r,
		a
	];
}
Yo(Qo, "useUncontrolledState");
function $o(e) {
	return typeof e == "function";
}
Yo($o, "isFunction");
var es = Symbol("RADIX:SYNC_STATE");
function ts(e, t, n, r) {
	let { prop: i, defaultProp: a, onChange: o, caller: s } = t, c = i !== void 0, l = qo(o), u = [{
		...n,
		state: a
	}];
	r && u.push(r);
	let [d, f] = W.useReducer((t, n) => {
		if (n.type === es) return {
			...t,
			state: n.state
		};
		let r = e(t, n);
		return c && !Object.is(r.state, t.state) && l(r.state), r;
	}, ...u), p = d.state, m = W.useRef(p);
	W.useEffect(() => {
		m.current !== p && (m.current = p, c || l(p));
	}, [
		p,
		m,
		c
	]);
	let h = W.useMemo(() => i === void 0 ? d : {
		...d,
		state: i
	}, [d, i]);
	return W.useEffect(() => {
		c && !Object.is(i, d.state) && f({
			type: es,
			state: i
		});
	}, [
		i,
		d.state,
		c
	]), [h, f];
}
Yo(ts, "useControllableStateReducer");
// node_modules/@radix-ui/react-visually-hidden/dist/index.mjs
var ns = Object.freeze({
	position: "absolute",
	border: 0,
	width: 1,
	height: 1,
	padding: 0,
	margin: -1,
	overflow: "hidden",
	clip: "rect(0, 0, 0, 0)",
	whiteSpace: "nowrap",
	wordWrap: "normal"
}), rs = function(e) {
	return typeof document > "u" ? null : (Array.isArray(e) ? e[0] : e).ownerDocument.body;
}, is = /* @__PURE__ */ new WeakMap(), as = /* @__PURE__ */ new WeakMap(), os = {}, ss = 0, cs = function(e) {
	return e && (e.host || cs(e.parentNode));
}, ls = function(e, t) {
	return t.map(function(t) {
		if (e.contains(t)) return t;
		var n = cs(t);
		return n && e.contains(n) ? n : (console.error("aria-hidden", t, "in not contained inside", e, ". Doing nothing"), null);
	}).filter(function(e) {
		return !!e;
	});
}, us = function(e, t, n, r) {
	var i = ls(t, Array.isArray(e) ? e : [e]);
	os[n] || (os[n] = /* @__PURE__ */ new WeakMap());
	var a = os[n], o = [], s = /* @__PURE__ */ new Set(), c = new Set(i), l = function(e) {
		e && !s.has(e) && (s.add(e), l(e.parentNode));
	};
	i.forEach(l);
	var u = function(e) {
		e && !c.has(e) && Array.prototype.forEach.call(e.children, function(e) {
			if (s.has(e)) u(e);
			else try {
				var t = e.getAttribute(r), i = t !== null && t !== "false", c = (is.get(e) || 0) + 1, l = (a.get(e) || 0) + 1;
				is.set(e, c), a.set(e, l), o.push(e), c === 1 && i && as.set(e, !0), l === 1 && e.setAttribute(n, "true"), i || e.setAttribute(r, "true");
			} catch (t) {
				console.error("aria-hidden: cannot operate on ", e, t);
			}
		});
	};
	return u(t), s.clear(), ss++, function() {
		o.forEach(function(e) {
			var t = is.get(e) - 1, i = a.get(e) - 1;
			is.set(e, t), a.set(e, i), t || (as.has(e) || e.removeAttribute(r), as.delete(e)), i || e.removeAttribute(n);
		}), ss--, ss || (is = /* @__PURE__ */ new WeakMap(), is = /* @__PURE__ */ new WeakMap(), as = /* @__PURE__ */ new WeakMap(), os = {});
	};
}, ds = function(e, t, n) {
	n === void 0 && (n = "data-aria-hidden");
	var r = Array.from(Array.isArray(e) ? e : [e]), i = t || rs(e);
	return i ? (r.push.apply(r, Array.from(i.querySelectorAll("[aria-live], script"))), us(r, i, n, "aria-hidden")) : function() {
		return null;
	};
}, fs = function() {
	return fs = Object.assign || function(e) {
		for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n], t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
		return e;
	}, fs.apply(this, arguments);
};
function ps(e, t) {
	var n = {};
	for (var r in e) Object.prototype.hasOwnProperty.call(e, r) && t.indexOf(r) < 0 && (n[r] = e[r]);
	if (e != null && typeof Object.getOwnPropertySymbols == "function") for (var i = 0, r = Object.getOwnPropertySymbols(e); i < r.length; i++) t.indexOf(r[i]) < 0 && Object.prototype.propertyIsEnumerable.call(e, r[i]) && (n[r[i]] = e[r[i]]);
	return n;
}
function ms(e, t, n) {
	if (n || arguments.length === 2) for (var r = 0, i = t.length, a; r < i; r++) (a || !(r in t)) && (a ||= Array.prototype.slice.call(t, 0, r), a[r] = t[r]);
	return e.concat(a || Array.prototype.slice.call(t));
}
// node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var hs = "right-scroll-bar-position", gs = "width-before-scroll-bar", _s = "with-scroll-bars-hidden", vs = "--removed-body-scroll-bar-size";
// node_modules/use-callback-ref/dist/es2015/assignRef.js
function ys(e, t) {
	return typeof e == "function" ? e(t) : e && (e.current = t), e;
}
// node_modules/use-callback-ref/dist/es2015/useRef.js
function bs(e, t) {
	var n = J(function() {
		return {
			value: e,
			callback: t,
			facade: {
				get current() {
					return n.value;
				},
				set current(e) {
					var t = n.value;
					t !== e && (n.value = e, n.callback(e, t));
				}
			}
		};
	})[0];
	return n.callback = t, n.facade;
}
// node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var xs = typeof window < "u" ? W.useLayoutEffect : W.useEffect, Ss = /* @__PURE__ */ new WeakMap();
function Cs(e, t) {
	var n = bs(t || null, function(t) {
		return e.forEach(function(e) {
			return ys(e, t);
		});
	});
	return xs(function() {
		var t = Ss.get(n);
		if (t) {
			var r = new Set(t), i = new Set(e), a = n.current;
			r.forEach(function(e) {
				i.has(e) || ys(e, null);
			}), i.forEach(function(e) {
				r.has(e) || ys(e, a);
			});
		}
		Ss.set(n, e);
	}, [e]), n;
}
// node_modules/use-sidecar/dist/es2015/medium.js
function ws(e) {
	return e;
}
function Ts(e, t) {
	t === void 0 && (t = ws);
	var n = [], r = !1;
	return {
		read: function() {
			if (r) throw Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			return n.length ? n[n.length - 1] : e;
		},
		useMedium: function(e) {
			var i = t(e, r);
			return n.push(i), function() {
				n = n.filter(function(e) {
					return e !== i;
				});
			};
		},
		assignSyncMedium: function(e) {
			for (r = !0; n.length;) {
				var t = n;
				n = [], t.forEach(e);
			}
			n = {
				push: function(t) {
					return e(t);
				},
				filter: function() {
					return n;
				}
			};
		},
		assignMedium: function(e) {
			r = !0;
			var t = [];
			if (n.length) {
				var i = n;
				n = [], i.forEach(e), t = n;
			}
			var a = function() {
				var n = t;
				t = [], n.forEach(e);
			}, o = function() {
				return Promise.resolve().then(a);
			};
			o(), n = {
				push: function(e) {
					t.push(e), o();
				},
				filter: function(e) {
					return t = t.filter(e), n;
				}
			};
		}
	};
}
function Es(e) {
	e === void 0 && (e = {});
	var t = Ts(null);
	return t.options = fs({
		async: !0,
		ssr: !1
	}, e), t;
}
// node_modules/use-sidecar/dist/es2015/exports.js
var Ds = function(e) {
	var t = e.sideCar, n = ps(e, ["sideCar"]);
	if (!t) throw Error("Sidecar: please provide `sideCar` property to import the right car");
	var r = t.read();
	if (!r) throw Error("Sidecar medium not found");
	return W.createElement(r, fs({}, n));
};
Ds.isSideCarExport = !0;
function Os(e, t) {
	return e.useMedium(t), Ds;
}
// node_modules/react-remove-scroll/dist/es2015/medium.js
var ks = Es(), As = function() {}, js = W.forwardRef(function(e, t) {
	var n = W.useRef(null), r = W.useState({
		onScrollCapture: As,
		onWheelCapture: As,
		onTouchMoveCapture: As
	}), i = r[0], a = r[1], o = e.forwardProps, s = e.children, c = e.className, l = e.removeScrollBar, u = e.enabled, d = e.shards, f = e.sideCar, p = e.noRelative, m = e.noIsolation, h = e.inert, g = e.allowPinchZoom, _ = e.as, v = _ === void 0 ? "div" : _, y = e.gapMode, b = ps(e, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]), x = f, S = Cs([n, t]), C = fs(fs({}, b), i);
	return W.createElement(W.Fragment, null, u && W.createElement(x, {
		sideCar: ks,
		removeScrollBar: l,
		shards: d,
		noRelative: p,
		noIsolation: m,
		inert: h,
		setCallbacks: a,
		allowPinchZoom: !!g,
		lockRef: n,
		gapMode: y
	}), o ? W.cloneElement(W.Children.only(s), fs(fs({}, C), { ref: S })) : W.createElement(v, fs({}, C, {
		className: c,
		ref: S
	}), s));
});
js.defaultProps = {
	enabled: !0,
	removeScrollBar: !0,
	inert: !1
}, js.classNames = {
	fullWidth: gs,
	zeroRight: hs
};
// node_modules/get-nonce/dist/es2015/index.js
var Ms = function() {
	if (typeof __webpack_nonce__ < "u") return __webpack_nonce__;
};
// node_modules/react-style-singleton/dist/es2015/singleton.js
function Ns() {
	if (!document) return null;
	var e = document.createElement("style");
	e.type = "text/css";
	var t = Ms();
	return t && e.setAttribute("nonce", t), e;
}
function Ps(e, t) {
	e.styleSheet ? e.styleSheet.cssText = t : e.appendChild(document.createTextNode(t));
}
function Fs(e) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(e);
}
var Is = function() {
	var e = 0, t = null;
	return {
		add: function(n) {
			e == 0 && (t = Ns()) && (Ps(t, n), Fs(t)), e++;
		},
		remove: function() {
			e--, !e && t && (t.parentNode && t.parentNode.removeChild(t), t = null);
		}
	};
}, Ls = function() {
	var e = Is();
	return function(t, n) {
		W.useEffect(function() {
			return e.add(t), function() {
				e.remove();
			};
		}, [t && n]);
	};
}, Rs = function() {
	var e = Ls();
	return function(t) {
		var n = t.styles, r = t.dynamic;
		return e(n, r), null;
	};
}, zs = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
}, Bs = function(e) {
	return parseInt(e || "", 10) || 0;
}, Vs = function(e) {
	var t = window.getComputedStyle(document.body), n = t[e === "padding" ? "paddingLeft" : "marginLeft"], r = t[e === "padding" ? "paddingTop" : "marginTop"], i = t[e === "padding" ? "paddingRight" : "marginRight"];
	return [
		Bs(n),
		Bs(r),
		Bs(i)
	];
}, Hs = function(e) {
	if (e === void 0 && (e = "margin"), typeof window > "u") return zs;
	var t = Vs(e), n = document.documentElement.clientWidth, r = window.innerWidth;
	return {
		left: t[0],
		top: t[1],
		right: t[2],
		gap: Math.max(0, r - n + t[2] - t[0])
	};
}, Us = Rs(), Ws = "data-scroll-locked", Gs = function(e, t, n, r) {
	var i = e.left, a = e.top, o = e.right, s = e.gap;
	return n === void 0 && (n = "margin"), `
  .${_s} {
   overflow: hidden ${r};
   padding-right: ${s}px ${r};
  }
  body[${Ws}] {
    overflow: hidden ${r};
    overscroll-behavior: contain;
    ${[
		t && `position: relative ${r};`,
		n === "margin" && `
    padding-left: ${i}px;
    padding-top: ${a}px;
    padding-right: ${o}px;
    margin-left:0;
    margin-top:0;
    margin-right: ${s}px ${r};
    `,
		n === "padding" && `padding-right: ${s}px ${r};`
	].filter(Boolean).join("")}
  }
  
  .${hs} {
    right: ${s}px ${r};
  }
  
  .${gs} {
    margin-right: ${s}px ${r};
  }
  
  .${hs} .${hs} {
    right: 0 ${r};
  }
  
  .${gs} .${gs} {
    margin-right: 0 ${r};
  }
  
  body[${Ws}] {
    ${vs}: ${s}px;
  }
`;
}, Ks = function() {
	var e = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(e) ? e : 0;
}, qs = function() {
	W.useEffect(function() {
		return document.body.setAttribute(Ws, (Ks() + 1).toString()), function() {
			var e = Ks() - 1;
			e <= 0 ? document.body.removeAttribute(Ws) : document.body.setAttribute(Ws, e.toString());
		};
	}, []);
}, Js = function(e) {
	var t = e.noRelative, n = e.noImportant, r = e.gapMode, i = r === void 0 ? "margin" : r;
	qs();
	var a = W.useMemo(function() {
		return Hs(i);
	}, [i]);
	return W.createElement(Us, { styles: Gs(a, !t, i, n ? "" : "!important") });
}, Ys = !1;
if (typeof window < "u") try {
	var Xs = Object.defineProperty({}, "passive", { get: function() {
		return Ys = !0, !0;
	} });
	window.addEventListener("test", Xs, Xs), window.removeEventListener("test", Xs, Xs);
} catch {
	Ys = !1;
}
var Zs = Ys ? { passive: !1 } : !1, Qs = function(e) {
	return e.tagName === "TEXTAREA";
}, $s = function(e, t) {
	if (!(e instanceof Element)) return !1;
	var n = window.getComputedStyle(e);
	return n[t] !== "hidden" && !(n.overflowY === n.overflowX && !Qs(e) && n[t] === "visible");
}, ec = function(e) {
	return $s(e, "overflowY");
}, tc = function(e) {
	return $s(e, "overflowX");
}, nc = function(e, t) {
	var n = t.ownerDocument, r = t;
	do {
		if (typeof ShadowRoot < "u" && r instanceof ShadowRoot && (r = r.host), ac(e, r)) {
			var i = oc(e, r);
			if (i[1] > i[2]) return !0;
		}
		r = r.parentNode;
	} while (r && r !== n.body);
	return !1;
}, rc = function(e) {
	return [
		e.scrollTop,
		e.scrollHeight,
		e.clientHeight
	];
}, ic = function(e) {
	return [
		e.scrollLeft,
		e.scrollWidth,
		e.clientWidth
	];
}, ac = function(e, t) {
	return e === "v" ? ec(t) : tc(t);
}, oc = function(e, t) {
	return e === "v" ? rc(t) : ic(t);
}, sc = function(e, t) {
	return e === "h" && t === "rtl" ? -1 : 1;
}, cc = function(e, t, n, r, i) {
	var a = sc(e, window.getComputedStyle(t).direction), o = a * r, s = n.target, c = t.contains(s), l = !1, u = o > 0, d = 0, f = 0;
	do {
		if (!s) break;
		var p = oc(e, s), m = p[0], h = p[1] - p[2] - a * m;
		(m || h) && ac(e, s) && (d += h, f += m);
		var g = s.parentNode;
		s = g && g.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? g.host : g;
	} while (!c && s !== document.body || c && (t.contains(s) || t === s));
	return (u && (i && Math.abs(d) < 1 || !i && o > d) || !u && (i && Math.abs(f) < 1 || !i && -o > f)) && (l = !0), l;
}, lc = function(e) {
	return "changedTouches" in e ? [e.changedTouches[0].clientX, e.changedTouches[0].clientY] : [0, 0];
}, uc = function(e) {
	return [e.deltaX, e.deltaY];
}, dc = function(e) {
	return e && "current" in e ? e.current : e;
}, fc = function(e, t) {
	return e[0] === t[0] && e[1] === t[1];
}, pc = function(e) {
	return `
  .block-interactivity-${e} {pointer-events: none;}
  .allow-interactivity-${e} {pointer-events: all;}
`;
}, mc = 0, hc = [];
function gc(e) {
	var t = W.useRef([]), n = W.useRef([0, 0]), r = W.useRef(), i = W.useState(mc++)[0], a = W.useState(Rs)[0], o = W.useRef(e);
	W.useEffect(function() {
		o.current = e;
	}, [e]), W.useEffect(function() {
		if (e.inert) {
			document.body.classList.add(`block-interactivity-${i}`);
			var t = ms([e.lockRef.current], (e.shards || []).map(dc), !0).filter(Boolean);
			return t.forEach(function(e) {
				return e.classList.add(`allow-interactivity-${i}`);
			}), function() {
				document.body.classList.remove(`block-interactivity-${i}`), t.forEach(function(e) {
					return e.classList.remove(`allow-interactivity-${i}`);
				});
			};
		}
	}, [
		e.inert,
		e.lockRef.current,
		e.shards
	]);
	var s = W.useCallback(function(e, t) {
		if ("touches" in e && e.touches.length === 2 || e.type === "wheel" && e.ctrlKey) return !o.current.allowPinchZoom;
		var i = lc(e), a = n.current, s = "deltaX" in e ? e.deltaX : a[0] - i[0], c = "deltaY" in e ? e.deltaY : a[1] - i[1], l, u = e.target, d = Math.abs(s) > Math.abs(c) ? "h" : "v";
		if ("touches" in e && d === "h" && u.type === "range") return !1;
		var f = window.getSelection(), p = f && f.anchorNode;
		if (p && (p === u || p.contains(u))) return !1;
		var m = nc(d, u);
		if (!m) return !0;
		if (m ? l = d : (l = d === "v" ? "h" : "v", m = nc(d, u)), !m) return !1;
		if (!r.current && "changedTouches" in e && (s || c) && (r.current = l), !l) return !0;
		var h = r.current || l;
		return cc(h, t, e, h === "h" ? s : c, !0);
	}, []), c = W.useCallback(function(e) {
		var n = e;
		if (hc.length && hc[hc.length - 1] === a) {
			var r = "deltaY" in n ? uc(n) : lc(n), i = t.current.filter(function(e) {
				return e.name === n.type && (e.target === n.target || n.target === e.shadowParent) && fc(e.delta, r);
			})[0];
			if (i && i.should) n.cancelable && n.preventDefault();
			else if (!i) {
				var c = (o.current.shards || []).map(dc).filter(Boolean).filter(function(e) {
					return e.contains(n.target);
				});
				(c.length > 0 ? s(n, c[0]) : !o.current.noIsolation) && n.cancelable && n.preventDefault();
			}
		}
	}, []), l = W.useCallback(function(e, n, r, i) {
		var a = {
			name: e,
			delta: n,
			target: r,
			should: i,
			shadowParent: _c(r)
		};
		t.current.push(a), setTimeout(function() {
			t.current = t.current.filter(function(e) {
				return e !== a;
			});
		}, 1);
	}, []), u = W.useCallback(function(e) {
		n.current = lc(e), r.current = void 0;
	}, []), d = W.useCallback(function(t) {
		l(t.type, uc(t), t.target, s(t, e.lockRef.current));
	}, []), f = W.useCallback(function(t) {
		l(t.type, lc(t), t.target, s(t, e.lockRef.current));
	}, []);
	W.useEffect(function() {
		return hc.push(a), e.setCallbacks({
			onScrollCapture: d,
			onWheelCapture: d,
			onTouchMoveCapture: f
		}), document.addEventListener("wheel", c, Zs), document.addEventListener("touchmove", c, Zs), document.addEventListener("touchstart", u, Zs), function() {
			hc = hc.filter(function(e) {
				return e !== a;
			}), document.removeEventListener("wheel", c, Zs), document.removeEventListener("touchmove", c, Zs), document.removeEventListener("touchstart", u, Zs);
		};
	}, []);
	var p = e.removeScrollBar, m = e.inert;
	return W.createElement(W.Fragment, null, m ? W.createElement(a, { styles: pc(i) }) : null, p ? W.createElement(Js, {
		noRelative: e.noRelative,
		gapMode: e.gapMode
	}) : null);
}
function _c(e) {
	for (var t = null; e !== null;) e instanceof ShadowRoot && (t = e.host, e = e.host), e = e.parentNode;
	return t;
}
// node_modules/react-remove-scroll/dist/es2015/sidecar.js
var vc = Os(ks, gc), yc = W.forwardRef(function(e, t) {
	return W.createElement(js, fs({}, e, {
		ref: t,
		sideCar: vc
	}));
});
yc.classNames = js.classNames;
// node_modules/@radix-ui/react-select/dist/index.mjs
var bc = Object.defineProperty, Q = (e, t) => bc(e, "name", {
	value: t,
	configurable: !0
}), xc = {
	ItemAligned: "item-aligned",
	Popper: "popper"
}, Sc = {
	LTR: "ltr",
	RTL: "rtl"
}, Cc = [
	" ",
	"Enter",
	"ArrowUp",
	"ArrowDown"
], wc = [" ", "Enter"], Tc = "Select", [Ec, Dc, Oc] = /* @__PURE__ */ Pn(Tc), [kc, Ac] = /* @__PURE__ */ sn(Tc, [Oc, yo]), jc = yo(), [Mc, Nc] = kc(Tc), [Pc, Fc] = kc(Tc);
function Ic(e) {
	let { __scopeSelect: t, children: n, open: r, defaultOpen: i, onOpenChange: a, value: o, defaultValue: s, onValueChange: c, dir: l, name: u, autoComplete: d, disabled: f, required: p, form: m, internal_do_not_use_render: h } = e, g = jc(t), [_, v] = W.useState(null), [y, b] = W.useState(null), [x, S] = W.useState(!1), C = Xn(l), [w, T] = Zo({
		prop: r,
		defaultProp: i ?? !1,
		onChange: a,
		caller: Tc
	}), [E, D] = Zo({
		prop: o,
		defaultProp: s,
		onChange: c,
		caller: Tc
	}), O = W.useRef(null), k = W.useRef(!1), [A, j] = W.useState(null), M = /* @__PURE__ */ Q((e) => {
		j({
			value: e,
			hasConsumerStoppedPropagation: k.current
		}), D(e);
	}, "handleUserSelect"), N = W.useRef(E);
	W.useEffect(() => {
		let e = m ? _?.ownerDocument.getElementById(m) : _?.form;
		if (e instanceof HTMLFormElement) {
			let t = /* @__PURE__ */ Q(() => D(N.current), "reset");
			return e.addEventListener("reset", t), () => e.removeEventListener("reset", t);
		}
	}, [
		m,
		_,
		D
	]);
	let P = !_ || !!m || !!_.closest("form"), [F, I] = W.useState(/* @__PURE__ */ new Set()), L = Zr(), R = Array.from(F).map((e) => e.props.value).join(";"), z = W.useCallback((e) => {
		I((t) => new Set(t).add(e));
	}, []), B = W.useCallback((e) => {
		I((t) => {
			let n = new Set(t);
			return n.delete(e), n;
		});
	}, []), V = {
		required: p,
		trigger: _,
		onTriggerChange: v,
		valueNode: y,
		onValueNodeChange: b,
		valueNodeHasChildren: x,
		onValueNodeHasChildrenChange: S,
		contentId: L,
		value: E,
		onValueChange: D,
		hasConsumerStoppedPropagationRef: k,
		userSelection: A,
		onUserSelect: M,
		open: w,
		onOpenChange: T,
		dir: C,
		triggerPointerDownPosRef: O,
		disabled: f,
		name: u,
		autoComplete: d,
		form: m,
		nativeOptions: F,
		nativeSelectKey: R,
		isFormControl: P
	};
	return /* @__PURE__ */ Y(So, {
		...g,
		children: /* @__PURE__ */ Y(Mc, {
			scope: t,
			...V,
			children: /* @__PURE__ */ Y(Ec.Provider, {
				scope: t,
				children: /* @__PURE__ */ Y(Pc, {
					scope: t,
					onNativeOptionAdd: z,
					onNativeOptionRemove: B,
					children: Cl(h) ? h(V) : n
				})
			})
		})
	});
}
Q(Ic, "SelectProvider");
var Lc = /* @__PURE__ */ Q((e) => {
	let { __scopeSelect: t, children: n, ...r } = e;
	return /* @__PURE__ */ Y(Ic, {
		__scopeSelect: t,
		...r,
		internal_do_not_use_render: ({ isFormControl: e }) => /* @__PURE__ */ X(pe, { children: [n, e ? /* @__PURE__ */ Y(Sl, { __scopeSelect: t }) : null] })
	});
}, "Select"), Rc = "SelectTrigger", zc = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, disabled: r = !1, ...i } = e, a = jc(n), o = Nc(Rc, n), s = o.disabled || r, c = pn(t, o.onTriggerChange), l = Dc(n), u = W.useRef("touch"), [d, f, p] = Tl((e) => {
		let t = l().filter((e) => !e.disabled), n = El(t, e, t.find((e) => e.value === o.value));
		n !== void 0 && o.onUserSelect(n.value);
	}), m = /* @__PURE__ */ Q((e) => {
		s || (o.onOpenChange(!0), p()), e && (o.triggerPointerDownPosRef.current = {
			x: Math.round(e.pageX),
			y: Math.round(e.pageY)
		});
	}, "handleOpen");
	return /* @__PURE__ */ Y(wo, {
		asChild: !0,
		...a,
		children: /* @__PURE__ */ Y($n.button, {
			type: "button",
			role: "combobox",
			"aria-controls": o.open ? o.contentId : void 0,
			"aria-expanded": o.open,
			"aria-required": o.required,
			"aria-autocomplete": "none",
			dir: o.dir,
			"data-state": o.open ? "open" : "closed",
			disabled: s,
			"data-disabled": s ? "" : void 0,
			"data-placeholder": wl(o.value) ? "" : void 0,
			...i,
			ref: c,
			onClick: Qt(i.onClick, (e) => {
				e.currentTarget.focus(), u.current !== "mouse" && m(e);
			}),
			onPointerDown: Qt(i.onPointerDown, (e) => {
				u.current = e.pointerType;
				let t = e.target;
				t.hasPointerCapture(e.pointerId) && t.releasePointerCapture(e.pointerId), e.button === 0 && e.ctrlKey === !1 && e.pointerType === "mouse" && (m(e), e.preventDefault());
			}),
			onKeyDown: Qt(i.onKeyDown, (e) => {
				let t = d.current !== "";
				!(e.ctrlKey || e.altKey || e.metaKey) && e.key.length === 1 && (o.hasConsumerStoppedPropagationRef.current = e.isPropagationStopped(), f(e.key)), !(t && e.key === " ") && Cc.includes(e.key) && (m(), e.preventDefault());
			})
		})
	});
}, "SelectTrigger")), Bc = "SelectValue", Vc = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, className: r, style: i, children: a, placeholder: o = "", ...s } = e, c = Nc(Bc, n), { onValueNodeHasChildrenChange: l } = c, u = a !== void 0, d = pn(t, c.onValueNodeChange);
	jn(() => {
		l(u);
	}, [l, u]);
	let f = wl(c.value);
	return /* @__PURE__ */ Y($n.span, {
		...s,
		asChild: !f && s.asChild,
		ref: d,
		style: { pointerEvents: "none" },
		children: /* @__PURE__ */ Y(W.Fragment, { children: f ? o : a }, f ? "placeholder" : "value")
	});
}, "SelectValue")), Hc = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, children: r, ...i } = e;
	return /* @__PURE__ */ Y($n.span, {
		"aria-hidden": !0,
		...i,
		ref: t,
		children: r || "▼"
	});
}, "SelectIcon")), [Uc, Wc] = kc("SelectPortal", { forceMount: void 0 }), Gc = /* @__PURE__ */ Q((e) => {
	let { __scopeSelect: t, forceMount: n, ...r } = e;
	return /* @__PURE__ */ Y(Uc, {
		scope: e.__scopeSelect,
		forceMount: n,
		children: /* @__PURE__ */ Y(No, {
			asChild: !0,
			...r
		})
	});
}, "SelectPortal"), Kc = "SelectContent", qc = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let n = Wc(Kc, e.__scopeSelect), { forceMount: r = n.forceMount, ...i } = e, a = Nc(Kc, e.__scopeSelect), [o, s] = W.useState();
	return jn(() => {
		s(new DocumentFragment());
	}, []), /* @__PURE__ */ Y(Lo, {
		present: r || a.open,
		children: ({ present: e }) => e ? /* @__PURE__ */ Y($c, {
			...i,
			ref: t
		}) : /* @__PURE__ */ Y(Jc, {
			...i,
			fragment: o
		})
	});
}, "SelectContent")), Jc = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, children: r, fragment: i } = e;
	return i ? me.createPortal(/* @__PURE__ */ Y(Xc, {
		scope: n,
		children: /* @__PURE__ */ Y(Ec.Slot, {
			scope: n,
			children: /* @__PURE__ */ Y("div", {
				ref: t,
				children: r
			})
		})
	}), i) : null;
}, "SelectContentFragment")), Yc = 10, [Xc, Zc] = kc(Kc), Qc = /* @__PURE__ */ gn("SelectContent.RemoveScroll"), $c = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n } = e, { position: r = xc.ItemAligned, onCloseAutoFocus: i, onEscapeKeyDown: a, onPointerDownOutside: o, side: s, sideOffset: c, align: l, alignOffset: u, arrowPadding: d, collisionBoundary: f, collisionPadding: p, sticky: m, hideWhenDetached: h, avoidCollisions: g, ..._ } = e, v = Nc(Kc, n), [y, b] = W.useState(null), [x, S] = W.useState(null), C = pn(t, b), [w, T] = W.useState(null), [E, D] = W.useState(null), O = Dc(n), [k, A] = W.useState(!1), j = W.useRef(!1), M = W.useRef(!1), N = W.useRef(!1);
	W.useEffect(() => {
		if (y) return ds(y);
	}, [y]), wr();
	let P = W.useCallback((e) => {
		let [t, ...n] = O().map((e) => e.ref.current), [r] = n.slice(-1), i = document.activeElement;
		for (let n of e) if (n === i || (n?.scrollIntoView({ block: "nearest" }), n === t && x && (x.scrollTop = 0), n === r && x && (x.scrollTop = x.scrollHeight), n?.focus(), document.activeElement !== i)) return;
	}, [O, x]), F = W.useCallback(() => P([w, y]), [
		P,
		w,
		y
	]);
	W.useEffect(() => {
		k && F();
	}, [k, F]);
	let { onOpenChange: I, triggerPointerDownPosRef: L } = v;
	W.useEffect(() => {
		if (y) {
			let e = {
				x: 0,
				y: 0
			}, t = /* @__PURE__ */ Q((t) => {
				e = {
					x: Math.abs(Math.round(t.pageX) - (L.current?.x ?? 0)),
					y: Math.abs(Math.round(t.pageY) - (L.current?.y ?? 0))
				};
			}, "handlePointerMove"), n = /* @__PURE__ */ Q((n) => {
				e.x <= 10 && e.y <= 10 ? n.preventDefault() : n.composedPath().includes(y) || I(!1), document.removeEventListener("pointermove", t), L.current = null;
			}, "handlePointerUp");
			return L.current !== null && (document.addEventListener("pointermove", t), document.addEventListener("pointerup", n, {
				capture: !0,
				once: !0
			})), () => {
				document.removeEventListener("pointermove", t), document.removeEventListener("pointerup", n, { capture: !0 });
			};
		}
	}, [
		y,
		I,
		L
	]), W.useEffect(() => {
		let e = /* @__PURE__ */ Q(() => I(!1), "close");
		return window.addEventListener("blur", e), window.addEventListener("resize", e), () => {
			window.removeEventListener("blur", e), window.removeEventListener("resize", e);
		};
	}, [I]);
	let [R, z] = Tl((e) => {
		let t = O().filter((e) => !e.disabled), n = El(t, e, t.find((e) => e.ref.current === document.activeElement));
		n && setTimeout(() => n.ref.current?.focus());
	}), B = W.useCallback((e, t, n) => {
		let r = !M.current;
		r && (M.current = !0);
		let i = !j.current && !n;
		v.value !== void 0 && v.value === t || i ? (T(e), i && (j.current = !0)) : r && T(e);
	}, [v.value]), V = W.useCallback(() => y?.focus(), [y]), ee = W.useCallback((e, t, n) => {
		if (!e) return;
		let r = !N.current;
		r && (N.current = !0);
		let i = !j.current && !n;
		(v.value !== void 0 && v.value === t || i || r) && D(e);
	}, [v.value]), H = r === xc.Popper ? tl : el, U = H === tl ? {
		side: s,
		sideOffset: c,
		align: l,
		alignOffset: u,
		arrowPadding: d,
		collisionBoundary: f,
		collisionPadding: p,
		sticky: m,
		hideWhenDetached: h,
		avoidCollisions: g
	} : {};
	return /* @__PURE__ */ Y(Xc, {
		scope: n,
		content: y,
		viewport: x,
		onViewportChange: S,
		itemRefCallback: B,
		selectedItem: w,
		onItemLeave: V,
		itemTextRefCallback: ee,
		focusSelectedItem: F,
		selectedItemText: E,
		position: r,
		isPositioned: k,
		searchRef: R,
		children: /* @__PURE__ */ Y(yc, {
			as: Qc,
			allowPinchZoom: !0,
			children: /* @__PURE__ */ Y(jr, {
				asChild: !0,
				trapped: v.open,
				onMountAutoFocus: (e) => {
					e.preventDefault();
				},
				onUnmountAutoFocus: Qt(i, (e) => {
					v.trigger?.focus({ preventScroll: !0 }), e.preventDefault();
				}),
				children: /* @__PURE__ */ Y(fr, {
					asChild: !0,
					disableOutsidePointerEvents: !0,
					onEscapeKeyDown: a,
					onPointerDownOutside: o,
					onFocusOutside: (e) => e.preventDefault(),
					onDismiss: () => v.onOpenChange(!1),
					children: /* @__PURE__ */ Y(H, {
						role: "listbox",
						id: v.contentId,
						"data-state": v.open ? "open" : "closed",
						dir: v.dir,
						onContextMenu: (e) => e.preventDefault(),
						..._,
						...U,
						onPlaced: () => A(!0),
						ref: C,
						style: {
							display: "flex",
							flexDirection: "column",
							outline: "none",
							..._.style
						},
						onKeyDown: Qt(_.onKeyDown, (e) => {
							let t = e.ctrlKey || e.altKey || e.metaKey;
							if (e.key === "Tab" && e.preventDefault(), !t && e.key.length === 1 && z(e.key), [
								"ArrowUp",
								"ArrowDown",
								"Home",
								"End"
							].includes(e.key)) {
								let t = O().filter((e) => !e.disabled).map((e) => e.ref.current);
								if (["ArrowUp", "End"].includes(e.key) && (t = t.slice().reverse()), ["ArrowUp", "ArrowDown"].includes(e.key)) {
									let n = e.target, r = t.indexOf(n);
									t = t.slice(r + 1);
								}
								setTimeout(() => P(t)), e.preventDefault();
							}
						})
					})
				})
			})
		})
	});
}, "SelectContentImpl")), el = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, onPlaced: r, ...i } = e, a = Nc(Kc, n), o = Zc(Kc, n), [s, c] = W.useState(null), [l, u] = W.useState(null), d = pn(t, u), f = Dc(n), p = W.useRef(!1), m = W.useRef(!0), { viewport: h, selectedItem: g, selectedItemText: _, focusSelectedItem: v } = o, y = W.useCallback(() => {
		if (a.trigger && a.valueNode && s && l && h && g && _) {
			let e = a.trigger.getBoundingClientRect(), t = l.getBoundingClientRect(), n = a.valueNode.getBoundingClientRect(), i = _.getBoundingClientRect();
			if (a.dir !== Sc.RTL) {
				let r = i.left - t.left, a = n.left - r, o = e.left - a, c = e.width + o, l = Math.max(c, t.width), u = window.innerWidth - Yc, d = Jt(a, [Yc, Math.max(Yc, u - l)]);
				s.style.minWidth = c + "px", s.style.left = d + "px";
			} else {
				let r = t.right - i.right, a = window.innerWidth - n.right - r, o = window.innerWidth - e.right - a, c = e.width + o, l = Math.max(c, t.width), u = window.innerWidth - Yc, d = Jt(a, [Yc, Math.max(Yc, u - l)]);
				s.style.minWidth = c + "px", s.style.right = d + "px";
			}
			let o = f(), c = window.innerHeight - Yc * 2, u = h.scrollHeight, d = window.getComputedStyle(l), m = parseInt(d.borderTopWidth, 10), v = parseInt(d.paddingTop, 10), y = parseInt(d.borderBottomWidth, 10), b = parseInt(d.paddingBottom, 10), x = m + v + u + b + y, S = Math.min(g.offsetHeight * 5, x), C = window.getComputedStyle(h), w = parseInt(C.paddingTop, 10), T = parseInt(C.paddingBottom, 10), E = e.top + e.height / 2 - Yc, D = c - E, O = g.offsetHeight / 2, k = g.offsetTop + O, A = m + v + k, j = x - A;
			if (A <= E) {
				let e = o.length > 0 && g === o[o.length - 1].ref.current;
				s.style.bottom = "0px";
				let t = l.clientHeight - h.offsetTop - h.offsetHeight, n = A + Math.max(D, O + (e ? T : 0) + t + y);
				s.style.height = n + "px";
			} else {
				let e = o.length > 0 && g === o[0].ref.current;
				s.style.top = "0px";
				let t = Math.max(E, m + h.offsetTop + (e ? w : 0) + O) + j;
				s.style.height = t + "px", h.scrollTop = A - E + h.offsetTop;
			}
			s.style.margin = `${Yc}px 0`, s.style.minHeight = S + "px", s.style.maxHeight = c + "px", r?.(), requestAnimationFrame(() => p.current = !0);
		}
	}, [
		f,
		a.trigger,
		a.valueNode,
		s,
		l,
		h,
		g,
		_,
		a.dir,
		r
	]);
	jn(() => y(), [y]);
	let [b, x] = W.useState();
	jn(() => {
		l && x(window.getComputedStyle(l).zIndex);
	}, [l]);
	let S = W.useCallback((e) => {
		e && m.current === !0 && (y(), v?.(), m.current = !1);
	}, [y, v]);
	return /* @__PURE__ */ Y(nl, {
		scope: n,
		contentWrapper: s,
		shouldExpandOnScrollRef: p,
		onScrollButtonChange: S,
		children: /* @__PURE__ */ Y("div", {
			ref: c,
			style: {
				display: "flex",
				flexDirection: "column",
				position: "fixed",
				zIndex: b
			},
			children: /* @__PURE__ */ Y($n.div, {
				...i,
				ref: d,
				style: {
					boxSizing: "border-box",
					maxHeight: "100%",
					...i.style
				}
			})
		})
	});
}, "SelectItemAlignedPosition")), tl = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, align: r = "start", collisionPadding: i = Yc, ...a } = e, o = jc(n);
	return /* @__PURE__ */ Y(Oo, {
		...o,
		...a,
		ref: t,
		align: r,
		collisionPadding: i,
		style: {
			boxSizing: "border-box",
			...a.style,
			"--radix-select-content-transform-origin": "var(--radix-popper-transform-origin)",
			"--radix-select-content-available-width": "var(--radix-popper-available-width)",
			"--radix-select-content-available-height": "var(--radix-popper-available-height)",
			"--radix-select-trigger-width": "var(--radix-popper-anchor-width)",
			"--radix-select-trigger-height": "var(--radix-popper-anchor-height)"
		}
	});
}, "SelectPopperPosition")), [nl, rl] = kc(Kc, {}), il = "SelectViewport", al = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, nonce: r, ...i } = e, a = Zc(il, n), o = rl(il, n), s = pn(t, a.onViewportChange), c = W.useRef(0);
	return /* @__PURE__ */ X(pe, { children: [/* @__PURE__ */ Y("style", {
		dangerouslySetInnerHTML: { __html: "[data-radix-select-viewport]{scrollbar-width:none;-ms-overflow-style:none;-webkit-overflow-scrolling:touch;}[data-radix-select-viewport]::-webkit-scrollbar{display:none}" },
		nonce: r
	}), /* @__PURE__ */ Y(Ec.Slot, {
		scope: n,
		children: /* @__PURE__ */ Y($n.div, {
			"data-radix-select-viewport": "",
			role: "presentation",
			...i,
			ref: s,
			style: {
				position: "relative",
				flex: 1,
				overflow: "hidden auto",
				...i.style
			},
			onScroll: Qt(i.onScroll, (e) => {
				let t = e.currentTarget, { contentWrapper: n, shouldExpandOnScrollRef: r } = o;
				if (r?.current && n) {
					let e = Math.abs(c.current - t.scrollTop);
					if (e > 0) {
						let r = window.innerHeight - Yc * 2, i = parseFloat(n.style.minHeight), a = parseFloat(n.style.height), o = Math.max(i, a);
						if (o < r) {
							let i = o + e, a = Math.min(r, i), s = i - a;
							n.style.height = a + "px", n.style.bottom === "0px" && (t.scrollTop = s > 0 ? s : 0, n.style.justifyContent = "flex-end");
						}
					}
				}
				c.current = t.scrollTop;
			})
		})
	})] });
}, "SelectViewport")), [ol, sl] = kc("SelectGroup"), cl = "SelectItem", [ll, ul] = kc(cl), dl = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, value: r, disabled: i = !1, textValue: a, ...o } = e, s = Nc(cl, n), c = Zc(cl, n), l = s.value === r, [u, d] = W.useState(a ?? ""), [f, p] = W.useState(!1), m = pn(t, ir((e) => c.itemRefCallback?.(e, r, i))), h = Zr(), g = W.useRef("touch");
	function _(e) {
		s.hasConsumerStoppedPropagationRef.current = e.isPropagationStopped(), s.onUserSelect(r), s.onOpenChange(!1);
	}
	return Q(_, "handleSelect"), /* @__PURE__ */ Y(ll, {
		scope: n,
		value: r,
		disabled: i,
		textId: h,
		isSelected: l,
		onItemTextChange: W.useCallback((e) => {
			d((t) => t || (e?.textContent ?? "").trim());
		}, []),
		children: /* @__PURE__ */ Y(Ec.ItemSlot, {
			scope: n,
			value: r,
			disabled: i,
			textValue: u,
			children: /* @__PURE__ */ Y($n.div, {
				role: "option",
				"aria-labelledby": h,
				"data-highlighted": f ? "" : void 0,
				"aria-selected": l && f,
				"data-state": l ? "checked" : "unchecked",
				"aria-disabled": i || void 0,
				"data-disabled": i ? "" : void 0,
				tabIndex: i ? void 0 : -1,
				...o,
				ref: m,
				onFocus: Qt(o.onFocus, () => p(!0)),
				onBlur: Qt(o.onBlur, () => p(!1)),
				onClick: Qt(o.onClick, (e) => {
					i || g.current !== "mouse" && _(e);
				}),
				onPointerUp: Qt(o.onPointerUp, (e) => {
					i || g.current === "mouse" && _(e);
				}),
				onPointerDown: Qt(o.onPointerDown, (e) => {
					g.current = e.pointerType;
				}),
				onPointerMove: Qt(o.onPointerMove, (e) => {
					g.current = e.pointerType, i ? c.onItemLeave?.() : g.current === "mouse" && e.currentTarget.focus({ preventScroll: !0 });
				}),
				onPointerLeave: Qt(o.onPointerLeave, (e) => {
					e.currentTarget === document.activeElement && c.onItemLeave?.();
				}),
				onKeyDown: Qt(o.onKeyDown, (e) => {
					i || e.target !== e.currentTarget || (c.searchRef?.current === "" || e.key !== " ") && (wc.includes(e.key) && _(e), e.key === " " && e.preventDefault());
				})
			})
		})
	});
}, "SelectItem")), fl = "SelectItemText", pl = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, className: r, style: i, ...a } = e, o = Nc(fl, n), s = Zc(fl, n), c = ul(fl, n), l = Fc(fl, n), [u, d] = W.useState(null), f = ir((e) => s.itemTextRefCallback?.(e, c.value, c.disabled)), p = pn(t, d, c.onItemTextChange, f), m = u?.textContent, h = W.useMemo(() => /* @__PURE__ */ Y("option", {
		value: c.value,
		disabled: c.disabled,
		children: m
	}, c.value), [
		c.disabled,
		c.value,
		m
	]), { onNativeOptionAdd: g, onNativeOptionRemove: _ } = l;
	return jn(() => (g(h), () => _(h)), [
		g,
		_,
		h
	]), /* @__PURE__ */ X(pe, { children: [/* @__PURE__ */ Y($n.span, {
		id: c.textId,
		...a,
		ref: p
	}), c.isSelected && o.valueNode && !o.valueNodeHasChildren && !wl(o.value) ? me.createPortal(a.children, o.valueNode) : null] });
}, "SelectItemText")), ml = "SelectItemIndicator", hl = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, ...r } = e;
	return ul(ml, n).isSelected ? /* @__PURE__ */ Y($n.span, {
		"aria-hidden": !0,
		...r,
		ref: t
	}) : null;
}, "SelectItemIndicator")), gl = "SelectScrollUpButton", _l = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let n = Zc(gl, e.__scopeSelect), r = rl(gl, e.__scopeSelect), [i, a] = W.useState(!1), o = pn(t, r.onScrollButtonChange);
	return jn(() => {
		if (n.viewport && n.isPositioned) {
			let e = function() {
				let e = t.scrollTop > 0;
				a(e);
			};
			Q(e, "handleScroll");
			let t = n.viewport;
			return e(), t.addEventListener("scroll", e), () => t.removeEventListener("scroll", e);
		}
	}, [n.viewport, n.isPositioned]), i ? /* @__PURE__ */ Y(bl, {
		...e,
		ref: o,
		onAutoScroll: () => {
			let { viewport: e, selectedItem: t } = n;
			e && t && (e.scrollTop -= t.offsetHeight);
		}
	}) : null;
}, "SelectScrollUpButton")), vl = "SelectScrollDownButton", yl = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let n = Zc(vl, e.__scopeSelect), r = rl(vl, e.__scopeSelect), [i, a] = W.useState(!1), o = pn(t, r.onScrollButtonChange);
	return jn(() => {
		if (n.viewport && n.isPositioned) {
			let e = function() {
				let e = t.scrollHeight - t.clientHeight, n = Math.ceil(t.scrollTop) < e;
				a(n);
			};
			Q(e, "handleScroll");
			let t = n.viewport;
			return e(), t.addEventListener("scroll", e), () => t.removeEventListener("scroll", e);
		}
	}, [n.viewport, n.isPositioned]), i ? /* @__PURE__ */ Y(bl, {
		...e,
		ref: o,
		onAutoScroll: () => {
			let { viewport: e, selectedItem: t } = n;
			e && t && (e.scrollTop += t.offsetHeight);
		}
	}) : null;
}, "SelectScrollDownButton")), bl = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function(e, t) {
	let { __scopeSelect: n, onAutoScroll: r, ...i } = e, a = Zc("SelectScrollButton", n), o = W.useRef(null), s = Dc(n), c = W.useCallback(() => {
		o.current !== null && (window.clearInterval(o.current), o.current = null);
	}, []);
	return W.useEffect(() => () => c(), [c]), jn(() => {
		s().find((e) => e.ref.current === document.activeElement)?.ref.current?.scrollIntoView({ block: "nearest" });
	}, [s]), /* @__PURE__ */ Y($n.div, {
		"aria-hidden": !0,
		...i,
		ref: t,
		style: {
			flexShrink: 0,
			...i.style
		},
		onPointerDown: Qt(i.onPointerDown, () => {
			o.current === null && (o.current = window.setInterval(r, 50));
		}),
		onPointerMove: Qt(i.onPointerMove, () => {
			a.onItemLeave?.(), o.current === null && (o.current = window.setInterval(r, 50));
		}),
		onPointerLeave: Qt(i.onPointerLeave, () => {
			c();
		})
	});
}, "SelectScrollButtonImpl")), xl = "SelectBubbleInput", Sl = /* @__PURE__ */ W.forwardRef(/* @__PURE__ */ Q(function({ __scopeSelect: e, ...t }, n) {
	let r = Nc(xl, e), { value: i, onValueChange: a, required: o, disabled: s, name: c, autoComplete: l, form: u, userSelection: d } = r, { nativeOptions: f, nativeSelectKey: p } = r, m = W.useRef(null), h = pn(n, m), g = i ?? "", _ = W.useRef(g), v = W.useRef(d), y = W.useRef(!1), b = Array.from(f).some((e) => (e.props.value ?? "") === "");
	return W.useEffect(() => {
		let e = m.current;
		if (!e) return;
		let t = window.HTMLSelectElement.prototype, n = Object.getOwnPropertyDescriptor(t, "value").set, r = d !== null && d !== v.current;
		v.current = d;
		let i = _.current !== g;
		_.current = g;
		let a = r && i;
		if (r && !i && d.value !== g && !d.hasConsumerStoppedPropagation && n) {
			y.current = !0;
			try {
				n.call(e, d.value), e.dispatchEvent(new Event("change", { bubbles: !0 }));
			} finally {
				y.current = !1, n.call(e, g);
			}
			return;
		}
		let o = a && !d.hasConsumerStoppedPropagation;
		if (i && n) {
			let t = new Event("change", { bubbles: o });
			n.call(e, g), e.dispatchEvent(t);
		}
	}, [g, d]), /* @__PURE__ */ X($n.select, {
		"aria-hidden": !0,
		required: o,
		tabIndex: -1,
		name: c,
		autoComplete: l,
		disabled: s,
		form: u,
		onChange: (e) => {
			y.current || a(e.target.value);
		},
		...t,
		style: {
			...ns,
			...t.style
		},
		ref: h,
		defaultValue: g,
		children: [wl(i) && !b ? /* @__PURE__ */ Y("option", { value: "" }) : null, Array.from(f)]
	}, p);
}, "SelectBubbleInput"));
function Cl(e) {
	return typeof e == "function";
}
Q(Cl, "isFunction");
function wl(e) {
	return e === "" || e === void 0;
}
Q(wl, "shouldShowPlaceholder");
function Tl(e) {
	let t = ir(e), n = W.useRef(""), r = W.useRef(0), i = W.useCallback((e) => {
		let i = n.current + e;
		t(i);
		function a(e) {
			n.current = e, window.clearTimeout(r.current), e !== "" && (r.current = window.setTimeout(() => a(""), 1e3));
		}
		Q(a, "updateSearch"), a(i);
	}, [t]), a = W.useCallback(() => {
		n.current = "", window.clearTimeout(r.current);
	}, []);
	return W.useEffect(() => () => window.clearTimeout(r.current), []), [
		n,
		i,
		a
	];
}
Q(Tl, "useTypeaheadSearch");
function El(e, t, n) {
	let r = t.length > 1 && Array.from(t).every((e) => e === t[0]) ? t[0] : t, i = n ? e.indexOf(n) : -1, a = Dl(e, Math.max(i, 0));
	r.length === 1 && (a = a.filter((e) => e !== n));
	let o = a.find((e) => e.textValue.toLowerCase().startsWith(r.toLowerCase()));
	return o === n ? void 0 : o;
}
Q(El, "findNextItem");
function Dl(e, t) {
	return e.map((n, r) => e[(t + r) % e.length]);
}
Q(Dl, "wrapArray");
var Ol = {
	field: "_field_19mpc_8",
	trigger: "_trigger_19mpc_11",
	valueText: "_valueText_19mpc_16",
	srOnly: "_srOnly_19mpc_19",
	chevron: "_chevron_19mpc_20",
	hint: "_hint_19mpc_22",
	content: "_content_19mpc_24",
	"select-in": "_select-in_19mpc_1",
	"select-out": "_select-out_19mpc_1",
	viewport: "_viewport_19mpc_29",
	item: "_item_19mpc_30",
	itemLabel: "_itemLabel_19mpc_34",
	indicator: "_indicator_19mpc_36",
	"indicator-in": "_indicator-in_19mpc_1",
	scrollButton: "_scrollButton_19mpc_37",
	"select-fade": "_select-fade_19mpc_1",
	"select-fade-out": "_select-fade-out_19mpc_1"
}, kl = {
	enter: (e) => ({
		opacity: 0,
		y: `${e * .35}em`,
		filter: `blur(${et.blur.soft}px)`
	}),
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: {
			duration: et.duration.standard,
			ease: [...et.ease.enter]
		}
	},
	exit: (e) => ({
		opacity: 0,
		y: `${e * -.3}em`,
		filter: `blur(${et.blur.subtle}px)`,
		transition: {
			duration: et.duration.fast,
			ease: [...et.ease.standard]
		}
	})
}, Al = {
	enter: { opacity: 0 },
	center: {
		opacity: 1,
		y: 0,
		filter: "blur(0px)",
		transition: { duration: et.duration.instant }
	},
	exit: {
		opacity: 0,
		transition: { duration: et.duration.instant }
	}
}, jl = K(function({ label: e, description: t, placeholder: n = "Select an option", options: r, id: i, className: a, disabled: o, invalid: s, describedBy: c, portalContainer: l, onValueChange: u, open: d, defaultOpen: f, onOpenChange: p, ...m }, h) {
	let g = ce(), _ = i ?? g, v = t ? `${_}-description` : void 0, y = [v, c].filter(Boolean).join(" ") || void 0, [b, x] = J(null), S = l ?? b?.closest(".local-select") ?? b?.closest("[data-rmd-theme]") ?? void 0, C = ee(), [w, T] = J(m.defaultValue ?? ""), E = m.value ?? w, [D, O] = J(f ?? !1), k = q(E);
	se(() => {
		(o || k.current !== E) && O(!1), k.current = E;
	}, [E, o]);
	let A = r.findIndex((e) => e.value === E), j = E ? r[A]?.label ?? "" : n, [M, N] = J(A), [P, F] = J(1);
	return M !== A && (N(A), F(A > M ? 1 : -1)), /* @__PURE__ */ X("div", {
		className: Ol.field,
		ref: x,
		"data-rmd-component": "select",
		"data-rmd-part": "field",
		children: [
			/* @__PURE__ */ Y("label", {
				htmlFor: _,
				"data-rmd-part": "label",
				children: e
			}),
			/* @__PURE__ */ X(Lc, {
				...m,
				disabled: o,
				open: !o && (d ?? D),
				onOpenChange: (e) => {
					O(e), p?.(e);
				},
				onValueChange: (e) => {
					T(e), u?.(e);
				},
				children: [/* @__PURE__ */ X(zc, {
					ref: h,
					id: _,
					"aria-describedby": y,
					"aria-invalid": s || void 0,
					"data-rmd-part": "trigger",
					className: [Ol.trigger, a].filter(Boolean).join(" "),
					children: [
						/* @__PURE__ */ Y("span", {
							className: Ol.srOnly,
							children: /* @__PURE__ */ Y(Vc, {
								placeholder: n,
								children: E ? j : void 0
							})
						}),
						/* @__PURE__ */ Y("span", {
							className: Ol.valueText,
							"data-rmd-part": "value",
							"aria-hidden": "true",
							children: /* @__PURE__ */ Y(Ee, {
								initial: !1,
								custom: P,
								children: /* @__PURE__ */ Y(U.span, {
									"data-placeholder": E ? void 0 : "",
									custom: P,
									variants: C ? Al : kl,
									initial: "enter",
									animate: "center",
									exit: "exit",
									children: j
								}, E ? `value-${E}` : "placeholder")
							})
						}),
						/* @__PURE__ */ Y(Hc, {
							className: Ol.chevron,
							"data-rmd-part": "chevron",
							children: /* @__PURE__ */ Y(qe, {
								size: 16,
								strokeWidth: 1.75,
								"aria-hidden": "true"
							})
						})
					]
				}), /* @__PURE__ */ Y(Gc, {
					container: S,
					children: /* @__PURE__ */ X(qc, {
						className: Ol.content,
						"data-rmd-part": "menu",
						position: "popper",
						sideOffset: 4,
						collisionPadding: 12,
						children: [
							/* @__PURE__ */ Y(_l, {
								className: Ol.scrollButton,
								"data-rmd-part": "scroll-up",
								children: /* @__PURE__ */ Y($e, {
									size: 16,
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							}),
							/* @__PURE__ */ Y(al, {
								className: Ol.viewport,
								"data-rmd-part": "viewport",
								children: r.map((e) => /* @__PURE__ */ X(dl, {
									value: e.value,
									disabled: e.disabled,
									className: Ol.item,
									"data-rmd-part": "item",
									children: [/* @__PURE__ */ Y(pl, { children: /* @__PURE__ */ Y("span", {
										className: Ol.itemLabel,
										children: e.label
									}) }), /* @__PURE__ */ Y(hl, {
										className: Ol.indicator,
										"data-rmd-part": "indicator",
										children: /* @__PURE__ */ Y(Ge, {
											size: 16,
											strokeWidth: 1.75,
											"aria-hidden": "true"
										})
									})]
								}, e.value))
							}),
							/* @__PURE__ */ Y(yl, {
								className: Ol.scrollButton,
								"data-rmd-part": "scroll-down",
								children: /* @__PURE__ */ Y(qe, {
									size: 16,
									strokeWidth: 1.75,
									"aria-hidden": "true"
								})
							})
						]
					})
				})]
			}),
			t && /* @__PURE__ */ Y("span", {
				id: v,
				className: Ol.hint,
				"data-rmd-part": "hint",
				children: t
			})
		]
	});
});
// src/react/field-validation.ts
function Ml(r, i, a) {
	if (i.required && r.length === 0) return a("This field is required", "请填写此字段");
	if (r.length > 1e5) return a(`At most ${t} characters`, `最多允许 ${t} 个字符`);
	if (i.email && r !== "" && !e(r)) return a("Enter a valid email address", "请输入有效的邮箱地址");
	let o = n(r);
	return i.minLength !== void 0 && i.minLength > 0 && r !== "" && o < i.minLength ? a(`At least ${i.minLength} characters`, `至少需要 ${i.minLength} 个字符`) : i.maxLength !== void 0 && i.maxLength >= 0 && o > i.maxLength ? a(`At most ${i.maxLength} characters`, `最多允许 ${i.maxLength} 个字符`) : null;
}
// src/react/use-draft-field.ts
function Nl(e, t) {
	let n = q(t);
	ue(() => {
		n.current = t;
	});
	let { runtime: r, mode: i, content: a } = e, o = a.attrs.bind;
	ue(() => {
		if (i !== "static" && o !== void 0) return r.registerSubmissionField?.(a, (e) => n.current(e));
	}, [
		r.identity,
		a.id,
		o,
		i
	]);
}
function Pl(e, t, n) {
	let [r, i] = J(t), [a, o] = J(!1), [s, c] = J(!1), [l, u] = J(null), d = q(!1), f = q(void 0), p = q(t), m = q(t);
	return m.current = t, se(() => {
		p.current !== t && (p.current = t, !a && !d.current && (f.current = void 0, i(t)));
	}, [t, a]), M(e, () => {
		d.current = !1, f.current = void 0, i(m.current), c(!1), u(null), n(null);
	}), {
		draft: r,
		focused: a,
		touched: s,
		draftError: l,
		composing: d,
		pendingDraft: f,
		setDraft(e) {
			f.current = e, i(e);
		},
		setFocused: o,
		setTouched: c,
		setDraftError: u
	};
}
var $ = {
	root: "_root_15jrj_11",
	header: "_header_15jrj_12",
	label: "_label_15jrj_13",
	readout: "_readout_15jrj_14",
	dash: "_dash_15jrj_15",
	body: "_body_15jrj_17",
	start: "_start_15jrj_18",
	end: "_end_15jrj_19",
	control: "_control_15jrj_23",
	track: "_track_15jrj_24",
	fill: "_fill_15jrj_26",
	tick: "_tick_15jrj_27",
	thumbs: "_thumbs_15jrj_29",
	thumbLayer: "_thumbLayer_15jrj_31",
	thumb: "_thumb_15jrj_29",
	bubbleAnchor: "_bubbleAnchor_15jrj_50",
	bubble: "_bubble_15jrj_50",
	marks: "_marks_15jrj_54",
	markLabel: "_markLabel_15jrj_55",
	number: "_number_15jrj_62"
}, { spring: Fl, duration: Il, blur: Ll } = et, Rl = [...et.ease.enter], zl = [...et.ease.standard], Bl = ({ visualDuration: e, bounce: t }) => {
	let n = 2 * Math.PI / (e * 1.2);
	return {
		type: "spring",
		stiffness: n * n,
		damping: 2 * (1 - t) * n,
		restDelta: .002,
		restSpeed: .02
	};
}, Vl = Bl(Fl.snappy), Hl = Bl(Fl.morph), Ul = 9, Wl = 150, Gl = 12, Kl = (e, t = Ul) => Math.sign(e) * (1 - 1 / (Math.abs(e) * .55 / t + 1)) * t, ql = (e) => e * .099, Jl = (e, t) => `inset(0 ${(100 - t).toFixed(3)}% 0 ${e.toFixed(3)}% round var(--rmd-slider-track-radius))`, Yl = (e) => (String(e).split(".")[1] ?? "").length, Xl = (e, t, n) => Math.min(n, Math.max(t, e)), Zl = {
	opacity: 0,
	scale: .6,
	y: 6,
	filter: `blur(${Ll.subtle}px)`
}, Ql = {
	opacity: 1,
	scale: 1,
	y: 0,
	filter: "blur(0px)",
	transitionEnd: { filter: "none" }
}, $l = {
	opacity: 0,
	scale: .8,
	y: 4,
	filter: `blur(${Ll.subtle}px)`,
	transition: {
		duration: Il.instant,
		ease: zl
	}
}, eu = {
	...Fl.snappy,
	opacity: {
		duration: Il.fast,
		ease: Rl
	},
	filter: {
		duration: Il.fast,
		ease: Rl
	}
};
function tu({ quiet: e, index: t, shown: n, value: r, text: i, low: a, high: o, ariaLabel: s, labelledBy: c, describedBy: l, invalid: u, active: d, lifted: f, bubble: p, disabled: m, onKeyDown: h, onFocus: g, onBlur: _ }) {
	let v = ee(), y = L(n, (e) => `${e - 100}%`);
	return /* @__PURE__ */ X(U.div, {
		className: $.thumbLayer,
		"data-rmd-part": "thumb-layer",
		style: {
			x: y,
			zIndex: d ? 2 : 1,
			"--at": n
		},
		children: [/* @__PURE__ */ Y(U.div, {
			role: "slider",
			"data-rmd-part": "thumb",
			"data-thumb": "",
			"data-index": t,
			"data-active": f || void 0,
			"data-quiet": e || void 0,
			className: $.thumb,
			tabIndex: m ? -1 : 0,
			"aria-label": s,
			"aria-labelledby": s ? void 0 : c,
			"aria-valuemin": a,
			"aria-valuemax": o,
			"aria-valuenow": r,
			"aria-valuetext": i,
			"aria-orientation": "horizontal",
			"aria-disabled": m || void 0,
			"aria-describedby": l,
			"aria-invalid": u || void 0,
			initial: !1,
			animate: { scale: f ? 1.16 : 1 },
			transition: v ? { duration: 0 } : Fl.snappy,
			onKeyDown: h,
			onFocus: g,
			onBlur: _
		}), /* @__PURE__ */ Y(U.span, {
			className: $.bubbleAnchor,
			"data-rmd-part": "bubble-anchor",
			children: /* @__PURE__ */ Y(Ee, { children: p && /* @__PURE__ */ Y(U.span, {
				className: $.bubble,
				"data-rmd-part": "bubble",
				"aria-hidden": "true",
				initial: v ? { opacity: 0 } : Zl,
				animate: Ql,
				exit: v ? {
					opacity: 0,
					transition: { duration: Il.instant }
				} : $l,
				transition: v ? { duration: Il.instant } : eu,
				children: /* @__PURE__ */ Y("span", {
					className: $.number,
					children: i
				})
			}, "bubble") })
		})]
	});
}
function nu({ label: e, value: t, defaultValue: n, onValueChange: r, onValueCommit: i, min: a = 0, max: o = 100, step: s = 1, largeStep: c, marks: l, minStepsBetweenThumbs: u = 0, format: d, showValue: f = !0, thumbLabels: p, start: m, end: h, readout: g, invalid: _, describedBy: v, resetSignal: y, name: b, disabled: x, className: S }) {
	let C = ee(), w = ce(), T = s > 0 ? s : 1, E = o - a || 1, D = Array.isArray(t ?? n), O = (e) => e === void 0 ? [a, o].slice(0, D ? 2 : 1) : Array.isArray(e) ? [e[0], e[1]] : [e], [k, A] = J(() => O(n)), j = t === void 0 ? k : O(t), M = Math.max(Yl(T), Yl(a)), P = d ?? ((e) => e.toLocaleString("en-US", {
		minimumFractionDigits: M,
		maximumFractionDigits: M
	})), F = D ? u * T : 0, I = (e) => (e - a) / E * 100, R = (e) => a + e / 100 * E, B = (e) => Number((a + Math.round((e - a) / T) * T).toFixed(M)), V = (e, t) => e === 1 ? t[0] + F : a, H = (e, t) => e === 0 && D ? t[1] - F : o, te = (e, t, n) => Xl(B(Xl(t, a, o)), V(e, n), H(e, n)), W = q(null), ne = q(null), G = q(j), re = q(j.map(I)), K = q(null), ie = q(!1), ae = q(void 0), [oe, le] = J(null), [de, fe] = J(null), [me, he] = J(null), [ge, _e] = J(+!!D), [ve, ye] = J(null), be = N(I(j[0])), xe = N(I(j[1] ?? j[0])), Se = N(0), Ce = N(0), we = L(() => be.get() + Se.get()), Te = L(() => xe.get() + Ce.get()), Ee = L(() => Jl(D ? Xl(we.get(), 0, 100) : 0, Xl((D ? Te : we).get(), 0, 100))), De = [{
		pos: be,
		lag: Se,
		shown: we
	}, {
		pos: xe,
		lag: Ce,
		shown: Te
	}], Oe = (e) => D ? [e[0], e[1]] : e[0];
	function ke(e, n) {
		let i = G.current;
		if (i[e] === n) return;
		let a = i.map((t, r) => r === e ? n : t);
		G.current = a, t === void 0 && A(a), r?.(Oe(a));
	}
	ue(() => {
		G.current = j, j.forEach((e, t) => {
			let n = I(e), r = De[t];
			if (K.current?.index === t || re.current[t] === n) return;
			re.current[t] = n;
			let i = r.pos.get() + r.lag.get();
			r.lag.jump(0), r.pos.jump(i), C ? r.pos.jump(n) : z(r.pos, n, Vl);
		});
	}), se(() => () => window.clearTimeout(ae.current), []), se(() => {
		x && (K.current = null, le(null), he(null), fe(null), ye(null), window.clearTimeout(ae.current));
	}, [x]), se(() => {
		K.current = null, le(null), he(null), fe(null), ye(null), window.clearTimeout(ae.current);
	}, [y]);
	let Ae = (e) => ne.current?.querySelector(`[data-index="${e}"]`);
	function je(e) {
		let t = Ae(e);
		t && document.activeElement !== t && (ye(e), ie.current = !0, t.focus({ preventScroll: !0 }), ie.current = !1);
	}
	let Me = () => W.current?.getBoundingClientRect().width || 1;
	function Ne(e, t) {
		if (!D) return 0;
		let n = Math.abs(e - I(t[0])), r = Math.abs(e - I(t[1]));
		return n === r ? e < I(t[0]) ? 0 : 1 : n < r ? 0 : 1;
	}
	function Pe(e) {
		window.clearTimeout(ae.current), he(e), ae.current = window.setTimeout(() => he(null), 700);
	}
	function Fe(e, t, n, r) {
		let i = De[t], a = i.pos.get() + i.lag.get();
		e.index = t, e.grab = r ? 0 : n - a, e.raw = a, i.lag.jump(0), i.pos.jump(a), le(t), _e(t), window.clearTimeout(ae.current), he(null), je(t), r && Ie(e, n, 0, !0);
	}
	function Ie(e, t, n, r = !1) {
		let i = e.index;
		if (i === null) return;
		let a = De[i], o = G.current, s = Me(), c = t - e.grab, l = Xl(c, I(V(i, o)), I(H(i, o))), u = C ? l : l + Kl((c - l) / 100 * s) / s * 100;
		if (r && !C) {
			let e = a.pos.get();
			a.pos.jump(u), a.lag.jump(e - u), z(a.lag, 0, Vl);
		} else a.pos.set(u);
		e.raw = c, e.samples.push({
			t: n,
			p: u
		}), e.samples.length > 6 && e.samples.shift(), ke(i, te(i, R(c), o));
	}
	function Le(e) {
		if (x || e.button !== 0 || !e.isPrimary) return;
		let t = W.current?.getBoundingClientRect();
		if (!t) return;
		let n = (e.clientX - t.left) / (t.width || 1) * 100, r = e.target.closest("[data-thumb]"), i = G.current;
		try {
			e.currentTarget.setPointerCapture(e.pointerId);
		} catch {}
		let a = {
			pointer: e.pointerId,
			index: null,
			grab: 0,
			x: e.clientX,
			raw: n,
			samples: []
		};
		K.current = a, r && D && i[0] === i[1] ? je(Number(r.dataset.index)) : (Fe(a, r ? Number(r.dataset.index) : Ne(n, i), n, !r), a.samples = [{
			t: e.timeStamp,
			p: De[a.index ?? 0].pos.get()
		}]);
	}
	function Re(e) {
		let t = K.current;
		if (!t || t.pointer !== e.pointerId) return;
		if (x) {
			K.current = null, le(null);
			return;
		}
		let n = W.current?.getBoundingClientRect();
		if (!n) return;
		let r = (e.clientX - n.left) / (n.width || 1) * 100;
		if (t.index === null) {
			let i = e.clientX - t.x;
			if (Math.abs(i) < 2) return;
			Fe(t, i < 0 ? 0 : 1, r - i / (n.width || 1) * 100, !1);
		}
		Ie(t, r, e.timeStamp);
	}
	function ze(e) {
		let t = K.current;
		if (!t || t.pointer !== e.pointerId) return;
		if (K.current = null, x) {
			le(null);
			return;
		}
		let n = t.index;
		if (n === null) return;
		let r = De[n], a = G.current, o = Me(), s = t.samples, c = s[0], l = s[s.length - 1], u = l && c ? (l.t - c.t) / 1e3 : 0, d = (l && c && u > .008 && e.timeStamp - l.t < 60 ? (l.p - c.p) / u : 0) + r.lag.getVelocity(), f = T / E * 100, p = e.type === "pointerup" && f / 100 * o >= Gl ? Xl(ql(d), -f, f) : 0, m = te(n, R(t.raw + p), a), h = r.pos.get() + r.lag.get(), g = I(m);
		r.lag.jump(0), r.pos.jump(h), re.current[n] = g, C ? r.pos.jump(g) : z(r.pos, g, {
			...Vl,
			velocity: d
		}), ke(n, m), le(null), e.type === "pointerup" && Pe(n), i?.(Oe(G.current));
	}
	function Be(e, t) {
		if (x) return;
		let n = G.current, r = n[e], o = c ?? Math.max(T, B(a + E / 10) - a), s = {
			ArrowRight: T,
			ArrowUp: T,
			ArrowLeft: -T,
			ArrowDown: -T,
			PageUp: o,
			PageDown: -o
		}, l;
		if (t.key === "Home") l = V(e, n);
		else if (t.key === "End") l = H(e, n);
		else if (t.key in s) l = r + (t.shiftKey && /^Arrow/.test(t.key) ? Math.sign(s[t.key]) * o : s[t.key]);
		else return;
		t.preventDefault(), fe(e), ye(null), _e(e);
		let u = te(e, l, n);
		if (u === r) {
			let t = Math.sign(l - r);
			t && !C && z(De[e].pos, re.current[e], {
				...Hl,
				velocity: t * Wl / Me() * 100
			});
		} else ke(e, u), i?.(Oe(G.current));
	}
	function Ve(e) {
		if (x) return;
		let t = G.current, n = Ne(I(e), t), r = te(n, e, t);
		_e(n), je(n), r !== t[n] && (ke(n, r), i?.(Oe(G.current)));
	}
	let He = (l ?? []).map((e) => typeof e == "number" ? { value: e } : e).filter((e) => e.value >= a && e.value <= o), Ue = He.filter((e) => e.value > a && e.value < o), We = He.filter((e) => e.label), Ge = (e) => D ? e >= j[0] && e <= j[1] : e <= j[0], Ke = p ?? [`${e}, minimum`, `${e}, maximum`];
	return /* @__PURE__ */ X("div", {
		className: [$.root, S].filter(Boolean).join(" "),
		"data-rmd-component": "slider",
		"data-rmd-part": "root",
		"data-rmd-slider": "arc",
		"data-disabled": x || void 0,
		"data-dragging": oe !== null || void 0,
		"data-invalid": _ || void 0,
		"data-marks": We.length > 0 || void 0,
		children: [
			/* @__PURE__ */ X("div", {
				className: $.header,
				"data-rmd-part": "header",
				children: [/* @__PURE__ */ Y("span", {
					id: w,
					className: $.label,
					"data-rmd-part": "label",
					children: e
				}), (g !== void 0 || f) && /* @__PURE__ */ Y("span", {
					className: $.readout,
					"data-rmd-part": "readout",
					"aria-hidden": "true",
					children: g ?? /* @__PURE__ */ X(pe, { children: [/* @__PURE__ */ Y("span", {
						className: $.number,
						children: P(j[0])
					}), D && /* @__PURE__ */ X(pe, { children: [/* @__PURE__ */ Y("span", {
						className: $.dash,
						children: "–"
					}), /* @__PURE__ */ Y("span", {
						className: $.number,
						children: P(j[1])
					})] })] })
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: $.body,
				children: [
					m && /* @__PURE__ */ Y("div", {
						className: $.start,
						"data-rmd-part": "start",
						children: m
					}),
					/* @__PURE__ */ X("div", {
						className: $.control,
						"data-rmd-part": "control",
						onPointerDown: Le,
						onPointerMove: Re,
						onPointerUp: ze,
						onPointerCancel: ze,
						onLostPointerCapture: ze,
						onMouseDown: (e) => e.preventDefault(),
						children: [/* @__PURE__ */ X("div", {
							ref: W,
							className: $.track,
							"data-rmd-part": "track",
							children: [Ue.map((e) => /* @__PURE__ */ Y("span", {
								className: $.tick,
								"data-rmd-part": "tick",
								style: { left: `${I(e.value)}%` }
							}, e.value)), /* @__PURE__ */ Y(U.div, {
								className: $.fill,
								"data-rmd-part": "fill",
								style: { clipPath: Ee },
								children: Ue.map((e) => /* @__PURE__ */ Y("span", {
									className: $.tick,
									"data-rmd-part": "tick",
									style: { left: `${I(e.value)}%` }
								}, e.value))
							})]
						}), /* @__PURE__ */ Y("div", {
							ref: ne,
							className: $.thumbs,
							"data-rmd-part": "thumbs",
							children: j.map((e, t) => /* @__PURE__ */ Y(tu, {
								quiet: ve === t,
								index: t,
								shown: De[t].shown,
								value: e,
								text: P(e),
								low: V(t, j),
								high: H(t, j),
								ariaLabel: D ? Ke[t] : void 0,
								labelledBy: w,
								describedBy: v,
								invalid: _,
								active: ge === t,
								lifted: oe === t,
								bubble: oe === t || de === t || me === t,
								disabled: x,
								onKeyDown: (e) => Be(t, e),
								onFocus: (e) => {
									!ie.current && e.currentTarget.matches(":focus-visible") && fe(t);
								},
								onBlur: () => {
									fe((e) => e === t ? null : e), ye((e) => e === t ? null : e);
								}
							}, t))
						})]
					}),
					h && /* @__PURE__ */ Y("div", {
						className: $.end,
						"data-rmd-part": "end",
						children: h
					}),
					We.length > 0 && /* @__PURE__ */ Y("div", {
						className: $.marks,
						"data-rmd-part": "marks",
						"aria-hidden": "true",
						children: We.map((e) => /* @__PURE__ */ Y("span", {
							className: $.markLabel,
							"data-rmd-part": "mark",
							"data-on": Ge(e.value) || void 0,
							"data-edge": e.value === a ? "start" : e.value === o ? "end" : void 0,
							style: { left: `${I(e.value)}%` },
							onClick: () => Ve(e.value),
							children: e.label
						}, e.value))
					})
				]
			}),
			b && j.map((e, t) => /* @__PURE__ */ Y("input", {
				type: "hidden",
				name: b,
				value: e,
				disabled: x
			}, t))
		]
	});
}
// src/components/controls/numeric-sliders.tsx
function ru(e) {
	return String(Number(e.toFixed(12)));
}
function iu({ value: e }) {
	return /* @__PURE__ */ Y("span", {
		className: "md-slider-value",
		"aria-hidden": "true",
		children: e
	});
}
function au(e) {
	let t = l(e), n = ce(), r = i(e), { content: o, mode: s, t: u } = t, d = c(e), { write: f, error: v } = g(e), y = p(e, "label", u("Slider", "滑块")), { disabled: b, invalid: S } = m(e), w = _(e), T = h(e, "min"), D = h(e, "max"), j = T.present && !T.error ? T.value : 0, M = D.present && !D.error ? D.value : 100, N = T.error || D.error, P = A(e, "step", 1), F = C(e), I = typeof F == "number" && Number.isFinite(F) ? F : j, L = Math.min(M, Math.max(j, I)), R = typeof F == "number" && Number.isFinite(F) ? F < j ? u(`Must be at least ${j}`, `不能小于 ${j}`) : F > M ? u(`Must be at most ${M}`, `不能大于 ${M}`) : null : null, z = !!(w.invalid || R || N);
	return s === "static" ? /* @__PURE__ */ Y(k, {
		authorRoot: d(),
		className: "md-slider local-slider",
		label: y,
		value: String(I)
	}) : /* @__PURE__ */ X("div", {
		className: "md-control md-slider local-slider",
		...d(x(a(o))),
		...r,
		"data-rmd-part": "control",
		"aria-invalid": z || void 0,
		"aria-describedby": w.describedBy,
		children: [
			/* @__PURE__ */ Y(nu, {
				label: y,
				value: L,
				min: j,
				max: M,
				step: P,
				disabled: b,
				className: "local-slider-arc",
				readout: /* @__PURE__ */ Y(iu, { value: String(I) }),
				format: ru,
				invalid: z,
				describedBy: w.describedBy,
				resetSignal: t.resetToken,
				onValueChange: (e) => {
					f(e);
				}
			}),
			/* @__PURE__ */ Y("input", {
				id: `${n}-slider`,
				type: "range",
				min: j,
				max: M,
				step: P,
				value: L,
				disabled: b,
				tabIndex: -1,
				"aria-hidden": "true",
				"data-rmd-native-proxy": "",
				style: { display: "none" },
				onChange: () => {}
			}),
			/* @__PURE__ */ Y(E, { value: String(I) }),
			/* @__PURE__ */ Y(O, { message: S || N ? u("Cannot compute", "无法计算") : v ?? R })
		]
	});
}
function ou(e) {
	let t = c(e), n = l(e), { content: r, mode: i, t: o } = n, { writeMany: d, error: f, setError: h } = g(e), v = p(e, "label", o("Range", "范围")), { disabled: y, invalid: b } = m(e), S = _(e), { min: C, max: T, step: A } = s(e, "min", "max", 0, 100, 1), j = Math.floor((T - C) / A + 1e-9), N = C, P = D(C + Math.max(0, j) * A, C, T), F = u(w(e, "start", N), C, T, A), I = u(w(e, "end", P), C, T, A);
	F > I && (F = I), M(e, () => {
		h(null);
	});
	let L = o("Start", "起点"), R = o("End", "终点"), z = `${L}: ${F} · ${R}: ${I}`, B = T - C, V = B > 0 ? (F - C) / B * 100 : 0, ee = B > 0 ? (I - C) / B * 100 : 100;
	return i === "static" ? /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-range-slider",
		label: v,
		value: z
	}) : /* @__PURE__ */ X("div", {
		className: "md-control local-range-slider",
		...t({
			...x(a(r)) ?? {},
			"--local-range-start": V,
			"--local-range-end": ee
		}),
		"data-rmd-part": "control",
		role: "group",
		"aria-label": v,
		"aria-invalid": S.invalid || void 0,
		"aria-describedby": S.describedBy,
		children: [
			/* @__PURE__ */ Y(nu, {
				label: v,
				value: [F, I],
				min: C,
				max: T,
				step: A,
				disabled: y,
				className: "local-slider-arc",
				thumbLabels: [`${v} ${L}`, `${v} ${R}`],
				readout: /* @__PURE__ */ Y(iu, { value: `${F} – ${I}` }),
				format: ru,
				invalid: S.invalid,
				describedBy: S.describedBy,
				resetSignal: n.resetToken,
				onValueChange: (e) => {
					let [t, n] = e;
					(t !== F || n !== I) && d({
						start: t,
						end: n
					});
				}
			}),
			/* @__PURE__ */ Y("input", {
				type: "range",
				className: "local-range-input local-range-input-start",
				min: C,
				max: T,
				step: A,
				value: F,
				disabled: y,
				"aria-label": `${v} ${L}`,
				tabIndex: -1,
				"aria-hidden": "true",
				"data-rmd-native-proxy": "",
				style: { display: "none" },
				onChange: () => {}
			}),
			/* @__PURE__ */ Y("input", {
				type: "range",
				className: "local-range-input local-range-input-end",
				min: C,
				max: T,
				step: A,
				value: I,
				disabled: y,
				"aria-label": `${v} ${R}`,
				tabIndex: -1,
				"aria-hidden": "true",
				"data-rmd-native-proxy": "",
				style: { display: "none" },
				onChange: () => {}
			}),
			/* @__PURE__ */ Y(E, { value: z }),
			/* @__PURE__ */ Y(O, { message: b ? o("Cannot compute", "无法计算") : f })
		]
	});
}
// src/components/controls/controls.tsx
function su(e, t) {
	if (e.content.attrs[t] !== void 0) return Math.max(0, Math.floor(A(e, t, 0)));
}
function cu(e) {
	let t = l(e), n = p(e, "label", t.content.name || t.t("Input", "输入")), r = (f(t.content, "type") ?? "text") === "email";
	return /* @__PURE__ */ Y(uu, {
		context: e,
		label: n,
		email: r
	});
}
function lu(e) {
	let t = l(e), n = p(e, "label", t.t("Text", "文本")), r = Math.min(40, Math.max(1, Math.floor(A(e, "rows", 4))));
	return /* @__PURE__ */ Y(uu, {
		context: e,
		label: n,
		multiline: !0,
		rows: r
	});
}
function uu({ context: e, label: t, email: n = !1, multiline: r = !1, rows: a }) {
	let o = c(e), s = l(e), u = ce(), h = i(e), { content: y, mode: b, t: x } = s, { write: S, error: w, setError: D } = g(e), A = p(e, "placeholder", ""), j = T(e, "required", !1), M = j.ok ? j.value : !1, N = (f(y, "required") ?? "").includes("{{"), { disabled: P, invalid: F } = m(e), I = _(e), L = su(e, "min-length"), R = su(e, "max-length"), z = v(C(e)), B = r ? "local-textarea" : `local-input${n ? " local-input-email" : ""}`, { draft: V, setDraft: ee, setFocused: H, touched: U, setTouched: te, draftError: W, setDraftError: ne, composing: G, pendingDraft: re } = Pl(e, z, D), K = (e) => Ml(e, {
		required: M,
		minLength: L,
		maxLength: R,
		email: n
	}, x);
	if (Nl(e, (e) => {
		if (G.current) return "invalid";
		let t = v(e), n = re.current ?? t;
		if (M && n === "") return "required";
		if (n !== t) return "invalid";
	}), b === "static") return /* @__PURE__ */ Y(k, {
		authorRoot: o(),
		className: B,
		label: t,
		value: d(z),
		multiline: r
	});
	let ie = (e) => {
		S(e) && (re.current = void 0);
	}, ae = {
		id: `${u}-${r ? "textarea" : "input"}`,
		className: "md-text-input",
		value: V,
		placeholder: A || void 0,
		disabled: P,
		"aria-required": M || void 0,
		"aria-invalid": W || w || I.invalid || !j.ok ? !0 : void 0,
		"aria-describedby": I.describedBy,
		onFocus: () => H(!0),
		onBlur: () => {
			H(!1), te(!0);
			let e = K(V);
			ne(e), !e && V !== z && ie(V);
		},
		onChange: (e) => {
			let t = e.target.value;
			ee(t), D(null), U && ne(K(t)), !G.current && K(t) === null && ie(t);
		},
		onCompositionStart: () => {
			G.current = !0;
		},
		onCompositionEnd: (e) => {
			G.current = !1;
			let t = e.currentTarget.value;
			ee(t), U && ne(K(t)), K(t) === null && ie(t);
		}
	};
	return /* @__PURE__ */ X("div", {
		...o(),
		className: `md-control ${B}`,
		"data-rmd-component": r ? "textarea" : "input",
		...h,
		children: [
			/* @__PURE__ */ Y("label", {
				className: "md-label",
				htmlFor: ae.id,
				children: t
			}),
			r ? /* @__PURE__ */ Y("textarea", {
				...ae,
				rows: a
			}) : /* @__PURE__ */ Y("input", {
				...ae,
				type: n ? "email" : "text"
			}),
			/* @__PURE__ */ Y(E, {
				value: d(z),
				block: r
			}),
			/* @__PURE__ */ Y(O, { message: F || !j.ok ? x("Cannot compute", "无法计算") : W ?? w ?? (N && M && z === "" ? x("This field is required", "请填写此字段") : null) })
		]
	});
}
function du(e) {
	let t = e.trim();
	if (t === "" || t === "-" || t === "+" || t === "." || t === "-.") return { kind: "empty" };
	let n = Number(t);
	return Number.isFinite(n) ? {
		kind: "valid",
		value: n
	} : { kind: "invalid" };
}
function fu(e, t, n, r, i) {
	let a = 1e-9 * Math.max(1, Math.abs(e));
	if (t !== void 0 && e < t - a) return i(`Must be at least ${t}`, `不能小于 ${t}`);
	if (n !== void 0 && e > n + a) return i(`Must be at most ${n}`, `不能大于 ${n}`);
	if (!Number.isFinite(r) || r <= 0) return i("Step must be greater than 0", "步长必须大于 0");
	let o = (e - (t ?? 0)) / r;
	return Math.abs(o - Math.round(o)) > 1e-9 * Math.max(1, Math.abs(o)) ? i(`Must be a multiple of ${r}`, `需要按步长 ${r} 取值`) : null;
}
function pu(e) {
	let t = c(e), n = l(e), r = ce(), a = i(e), { mode: o, t: s } = n, { write: u, error: f, setError: v } = g(e), y = p(e, "label", s("Number", "数字")), { disabled: b, invalid: x } = m(e), S = _(e), w = h(e, "min"), T = h(e, "max"), D = w.present && !w.error ? w.value : void 0, j = T.present && !T.error ? T.value : void 0, M = w.error || T.error, N = A(e, "step", 1), P = C(e), F = typeof P == "number" && Number.isFinite(P) ? String(P) : "", I = typeof P == "number" && Number.isFinite(P) ? fu(P, D, j, N, s) : null, { draft: L, setDraft: R, focused: z, setFocused: B, touched: V, setTouched: ee, draftError: H, setDraftError: U, composing: te, pendingDraft: W } = Pl(e, F, v);
	Nl(e, (e) => {
		if (te.current) return "invalid";
		let t = W.current;
		if (t !== void 0) {
			let n = du(t);
			if (n.kind !== "valid" || n.value !== e) return "invalid";
		}
	});
	let ne = /* @__PURE__ */ X(pe, { children: [
		D === void 0 ? "" : s(`Min ${D}`, `最小 ${D}`),
		D !== void 0 && j !== void 0 ? " · " : "",
		j === void 0 ? "" : s(`Max ${j}`, `最大 ${j}`),
		N === void 0 ? "" : s(` · Step ${N}`, ` · 步长 ${N}`)
	] });
	if (o === "static") return /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-number",
		label: y,
		value: d(F),
		hint: ne
	});
	let G = (e, t) => {
		let n = du(e);
		if (n.kind !== "valid") return t && U(s("Enter a valid number", "请输入有效数字")), !1;
		let r = fu(n.value, D, j, N, s);
		if (r) return t && U(r), !1;
		U(null);
		let i = u(n.value);
		return i && (W.current = void 0), i;
	};
	return /* @__PURE__ */ X("div", {
		...t(),
		className: "md-control local-number",
		"data-rmd-component": "number",
		...a,
		children: [
			/* @__PURE__ */ Y("label", {
				className: "md-label",
				htmlFor: `${r}-number`,
				children: y
			}),
			/* @__PURE__ */ Y("input", {
				id: `${r}-number`,
				className: "md-text-input",
				type: "text",
				inputMode: "decimal",
				value: L,
				min: D,
				max: j,
				step: N,
				disabled: b,
				"aria-invalid": H || f || S.invalid || M || !z && I ? !0 : void 0,
				"aria-describedby": S.describedBy,
				onFocus: () => B(!0),
				onBlur: () => {
					B(!1), ee(!0), G(L, !0);
				},
				onChange: (e) => {
					let t = e.target.value;
					R(t), v(null), te.current || G(t, V);
				},
				onCompositionStart: () => {
					te.current = !0;
				},
				onCompositionEnd: (e) => {
					te.current = !1, R(e.currentTarget.value), G(e.currentTarget.value, V);
				}
			}),
			/* @__PURE__ */ Y(E, { value: d(F) }),
			D !== void 0 || j !== void 0 || N !== void 0 ? /* @__PURE__ */ Y("span", {
				className: "md-hint",
				children: ne
			}) : null,
			/* @__PURE__ */ Y(O, { message: x || M ? s("Cannot compute", "无法计算") : H ?? f ?? (z ? null : I) })
		]
	});
}
function mu(e) {
	let t = c(e), n = l(e), r = ce(), o = i(e), { content: s, mode: u, t: d } = n, { write: f, error: h } = g(e), v = p(e, "label", d("Toggle", "开关")), { disabled: y, invalid: b } = m(e), S = _(e), w = C(e) === !0, T = w ? d("On", "开") : d("Off", "关");
	return u === "static" ? /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "md-toggle local-toggle",
		label: v,
		value: T
	}) : /* @__PURE__ */ X("div", {
		className: "md-control md-toggle local-toggle",
		...t(x(a(s))),
		"data-rmd-component": "toggle",
		...o,
		children: [
			/* @__PURE__ */ X("label", {
				className: "md-toggle-label",
				htmlFor: `${r}-toggle`,
				children: [/* @__PURE__ */ Y("input", {
					id: `${r}-toggle`,
					type: "checkbox",
					checked: w,
					disabled: y,
					"aria-invalid": S.invalid || void 0,
					"aria-describedby": S.describedBy,
					onChange: (e) => f(e.target.checked)
				}), /* @__PURE__ */ Y("span", { children: v })]
			}),
			/* @__PURE__ */ Y(E, { value: T }),
			/* @__PURE__ */ Y(O, { message: b ? d("Cannot compute", "无法计算") : h })
		]
	});
}
function hu(e) {
	let t = c(e), n = l(e), r = ce(), o = i(e), { content: s, mode: u, t: d } = n, { write: f, error: h } = g(e), v = p(e, "label", d("Checkbox", "勾选")), { disabled: y, invalid: b } = m(e), S = _(e), w = C(e) === !0, T = w ? d("Checked", "已勾选") : d("Unchecked", "未勾选");
	return u === "static" ? /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-checkbox",
		label: v,
		value: T
	}) : /* @__PURE__ */ X("div", {
		className: "md-control local-checkbox",
		...t(x(a(s))),
		"data-rmd-component": "checkbox",
		...o,
		children: [
			/* @__PURE__ */ X("label", {
				className: "md-toggle-label",
				htmlFor: `${r}-checkbox`,
				children: [/* @__PURE__ */ Y("input", {
					id: `${r}-checkbox`,
					type: "checkbox",
					checked: w,
					disabled: y,
					"aria-invalid": S.invalid || void 0,
					"aria-describedby": S.describedBy,
					onChange: (e) => f(e.target.checked)
				}), /* @__PURE__ */ Y("span", { children: v })]
			}),
			/* @__PURE__ */ Y(E, { value: T }),
			/* @__PURE__ */ Y(O, { message: b ? d("Cannot compute", "无法计算") : h })
		]
	});
}
var gu = /^(\d{4})-(\d{2})-(\d{2})$/;
function _u(e) {
	let t = gu.exec(e);
	if (!t) return;
	let [n, r, i] = [
		Number(t[1]),
		Number(t[2]),
		Number(t[3])
	];
	if (n < 1 || n > 9999) return;
	let a = /* @__PURE__ */ new Date(0);
	return a.setFullYear(n, r - 1, i), a.setHours(0, 0, 0, 0), a.getFullYear() === n && a.getMonth() === r - 1 && a.getDate() === i ? a : void 0;
}
function vu(e) {
	return `${String(e.getFullYear()).padStart(4, "0")}-${String(e.getMonth() + 1).padStart(2, "0")}-${String(e.getDate()).padStart(2, "0")}`;
}
function yu(e) {
	let t = c(e), n = l(e), r = ce(), a = i(e), { content: o, mode: s, locale: u, t: h } = n, { write: v, error: y } = g(e), b = p(e, "label", h("Date", "日期")), { disabled: x, invalid: w } = m(e), D = _(e), A = T(e, "required", !1), j = A.ok ? A.value : !1, N = (f(o, "required") ?? "").includes("{{"), P = S(e, "min"), F = S(e, "max"), I = P.present && !P.error ? P.value : "", L = F.present && !F.error ? F.value : "", R = P.error || F.error || !A.ok, z = C(e), B = typeof z == "string" ? z : "", [V, ee] = J(!1);
	M(e, () => ee(!1));
	let H = B !== "" && (I !== "" && B < I || L !== "" && B > L) ? h(`Date must be between ${I || "…"} and ${L || "…"}`, `日期必须在 ${I || "…"} 与 ${L || "…"} 之间`) : null, U = (j && B === "" && (V || N) ? h("Select a date", "请选择日期") : null) ?? H;
	if (s === "static") return /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-date",
		label: b,
		value: d(B)
	});
	let te = w || R ? h("Cannot compute", "无法计算") : U ?? y, W = te ? `${r}-date-error` : void 0;
	return /* @__PURE__ */ X("div", {
		...t(),
		className: "md-control local-date local-date-picker",
		"data-rmd-part": "control",
		...a,
		children: [
			/* @__PURE__ */ Y(Ut, {
				id: `${r}-date`,
				label: b,
				value: _u(B),
				onChange: (e) => {
					ee(!0), v(e ? vu(e) : "");
				},
				onBlur: () => ee(!0),
				minDate: _u(I),
				maxDate: _u(L),
				locale: u === "zh" ? "zh-CN" : "en-US",
				placeholder: h("Select a date", "请选择日期"),
				todayLabel: h("Today", "今天"),
				previousMonthLabel: h("Previous month", "上个月"),
				nextMonthLabel: h("Next month", "下个月"),
				clearLabel: h("Clear", "清除"),
				calendarLabel: h(`${b} calendar`, `${b} 日历`),
				statusLabel: (e) => e ? h(`Selected ${e}`, `已选择 ${e}`) : h("Choose a day", "请选择日期"),
				showToday: !0,
				disabled: x,
				"aria-required": j || void 0,
				invalid: !!te || D.invalid,
				describedBy: [D.describedBy, W].filter(Boolean).join(" ") || void 0
			}, n.resetToken),
			/* @__PURE__ */ Y(O, {
				id: W,
				message: te
			}),
			/* @__PURE__ */ Y(E, { value: d(B) })
		]
	});
}
function bu(e) {
	let t = c(e), n = l(e), r = ce(), { content: i, mode: s, t: u } = n, { write: f, error: h } = g(e), v = p(e, "label", u("Select", "选择")), { disabled: y, invalid: S } = m(e), w = _(e), T = e.children.options(), D = C(e), A = typeof D == "string" ? D : "", j = T.some((e) => e.value === A) ? A : T[0]?.value ?? "", M = T.find((e) => e.value === j), N = M ? o(e, M) || j : "";
	if (T.length === 0) return /* @__PURE__ */ Y(b, { message: u("Missing options", "缺少选项") });
	if (s === "static") return /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "md-select local-select",
		label: v,
		value: d(N)
	});
	let P = T.map((t, n) => ({
		value: `${r}-option-${n}`,
		label: o(e, t) || t.value
	})), F = P[Math.max(0, T.findIndex((e) => e.value === j))]?.value ?? "", I = S ? u("Cannot compute", "无法计算") : h, L = I ? `${r}-select-error` : void 0;
	return /* @__PURE__ */ X("div", {
		className: "md-control md-select local-select",
		...t(x(a(i))),
		"data-rmd-part": "control",
		children: [
			/* @__PURE__ */ Y(jl, {
				id: `${r}-select`,
				label: v,
				options: P,
				value: F,
				placeholder: u("Select an option", "请选择选项"),
				onValueChange: (e) => {
					let t = P.findIndex((t) => t.value === e), n = T[t];
					n && f(n.value);
				},
				disabled: y,
				invalid: !!I || w.invalid,
				describedBy: [w.describedBy, L].filter(Boolean).join(" ") || void 0
			}, n.resetToken),
			/* @__PURE__ */ Y(O, {
				id: L,
				message: I
			}),
			/* @__PURE__ */ Y(E, { value: d(N) })
		]
	});
}
function xu(e) {
	let t = c(e), n = l(e), r = ce(), { content: i, mode: s, visible: u, t: f } = n, { write: h, error: v } = g(e), y = p(e, "label", f("Options", "选项")), { disabled: S, invalid: w } = m(e), T = _(e), D = e.children.options(), A = C(e), j = typeof A == "string" ? A : "", M = D.findIndex((e) => e.value === j), P = M >= 0 ? M : 0, F = M >= 0 ? D[M] : void 0, I = F ? o(e, F) : "", L = q([]), R = ee() ?? !1, B = D.length >= 2 && D.length <= 4, V = N(P);
	if (se(() => {
		let e = M >= 0 ? M : 0;
		if (!B || R) {
			V.jump(e);
			return;
		}
		let t = z(V, e, Gt.base);
		return () => t.stop();
	}, [
		V,
		R,
		B,
		M
	]), D.length === 0) return /* @__PURE__ */ Y(b, { message: f("Missing options", "缺少选项") });
	if (s === "static") return /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-choices",
		label: y,
		value: d(I)
	});
	let H = (e) => {
		let t = D[e];
		t && (h(t.value), L.current[e]?.focus());
	}, te = (e, t) => {
		let n = -1;
		e.key === "ArrowRight" || e.key === "ArrowDown" ? n = (t + 1) % D.length : e.key === "ArrowLeft" || e.key === "ArrowUp" ? n = (t - 1 + D.length) % D.length : e.key === "Home" ? n = 0 : e.key === "End" && (n = D.length - 1), !(n < 0) && (e.preventDefault(), H(n));
	};
	return /* @__PURE__ */ X("div", {
		className: "md-control local-choices",
		...t(x(a(i))),
		"data-rmd-component": "choices",
		children: [
			/* @__PURE__ */ Y("span", {
				className: "md-label",
				id: `${r}-choices-label`,
				children: y
			}),
			/* @__PURE__ */ Y(U.div, {
				className: "local-choice-list",
				role: "radiogroup",
				"aria-labelledby": `${r}-choices-label`,
				"aria-disabled": S || void 0,
				"aria-invalid": T.invalid || void 0,
				"aria-describedby": T.describedBy,
				"data-rmd-choices": B ? "uiarc" : void 0,
				"data-rmd-part": "list",
				"data-rmd-segments": B ? "" : void 0,
				style: B ? { "--pu-choice-index": V } : void 0,
				children: D.map((e, t) => {
					let r = e.value === j;
					return /* @__PURE__ */ Y("button", {
						ref: (e) => {
							L.current[t] = e;
						},
						type: "button",
						role: "radio",
						"aria-checked": r,
						tabIndex: t === P ? 0 : -1,
						disabled: S,
						className: `local-choice${r ? " is-selected" : ""}`,
						"data-rmd-appearance": "custom",
						"data-rmd-part": "segment",
						onClick: () => h(e.value),
						onKeyDown: (e) => te(e, t),
						children: n.renderInline(e.content.children, u)
					}, e.content.id);
				})
			}),
			/* @__PURE__ */ Y(E, { value: d(I) }),
			/* @__PURE__ */ Y(O, { message: w ? f("Cannot compute", "无法计算") : v })
		]
	});
}
function Su(e) {
	let t = c(e), n = l(e), r = ce(), { content: i, mode: s, visible: u, t: f } = n, { write: h, error: v } = g(e), y = p(e, "label", f("Options", "选项")), { disabled: S, invalid: w } = m(e), T = _(e), D = e.children.options(), A = C(e), j = typeof A == "string" ? A : "", M = r, N = D.find((e) => e.value === j), P = N ? o(e, N) : "";
	return D.length === 0 ? /* @__PURE__ */ Y(b, { message: f("Missing options", "缺少选项") }) : s === "static" ? /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-radio-group",
		label: y,
		value: d(P)
	}) : /* @__PURE__ */ X("fieldset", {
		className: "md-control local-radio-group",
		...t(x(a(i))),
		"data-rmd-component": "radio-group",
		disabled: S,
		"aria-invalid": T.invalid || void 0,
		"aria-describedby": T.describedBy,
		children: [
			/* @__PURE__ */ Y("legend", {
				className: "md-label",
				children: y
			}),
			D.map((e) => /* @__PURE__ */ X("label", {
				className: "local-radio-option",
				children: [/* @__PURE__ */ Y("input", {
					type: "radio",
					name: M,
					value: e.value,
					checked: j === e.value,
					onChange: () => h(e.value)
				}), /* @__PURE__ */ Y("span", { children: n.renderInline(e.content.children, u) })]
			}, e.content.id)),
			/* @__PURE__ */ Y(E, { value: d(P) }),
			/* @__PURE__ */ Y(O, { message: w ? f("Cannot compute", "无法计算") : v })
		]
	});
}
function Cu(e) {
	return (e.children.find((e) => e.kind === "list")?.children ?? []).filter((e) => e.kind === "listItem").map((e, t) => ({
		id: `item-${t + 1}`,
		content: e
	}));
}
function wu(e) {
	let t = c(e), n = l(e), r = ce(), { content: i, mode: o, visible: s, t: u } = n, { write: d, error: f } = g(e), h = p(e, "label", u("Checklist", "清单")), { disabled: v, invalid: S } = m(e), w = _(e), T = Cu(i), D = C(e), k = Array.isArray(D) ? D.filter((e) => typeof e == "string") : [];
	if (T.length === 0) return /* @__PURE__ */ Y(b, { message: u("Checklist requires a task list", "清单需要任务列表") });
	let A = (e) => e ? u("Checked", "已勾选") : u("Unchecked", "未勾选");
	if (o === "static") return /* @__PURE__ */ X("div", {
		className: "local-checklist local-static-checklist",
		...t(x(a(i))),
		role: "group",
		"aria-label": h,
		children: [/* @__PURE__ */ Y("span", {
			className: "md-label",
			children: h
		}), /* @__PURE__ */ Y("ul", {
			className: "local-static-list",
			children: T.map((e) => {
				let t = k.includes(e.id);
				return /* @__PURE__ */ X("li", {
					className: "local-static-list-item",
					children: [/* @__PURE__ */ Y("span", {
						className: "local-static-state",
						children: A(t)
					}), /* @__PURE__ */ Y("span", {
						className: `local-static-item${t ? " is-checked" : ""}`,
						children: n.renderInline(e.content.children, s)
					})]
				}, e.id);
			})
		})]
	});
	let j = (e, t) => {
		let n = new Set(k);
		t ? n.add(e) : n.delete(e), d(T.filter((e) => n.has(e.id)).map((e) => e.id));
	};
	return /* @__PURE__ */ X("fieldset", {
		className: "local-checklist",
		...t(x(a(i))),
		"data-rmd-component": "checklist",
		disabled: v,
		"aria-invalid": w.invalid || void 0,
		"aria-describedby": w.describedBy,
		children: [
			/* @__PURE__ */ Y("legend", {
				className: "md-label",
				children: h
			}),
			T.map((e) => {
				let t = k.includes(e.id);
				return /* @__PURE__ */ X("div", {
					className: "local-checklist-item",
					children: [/* @__PURE__ */ Y("input", {
						id: `${r}-${e.id}`,
						type: "checkbox",
						checked: t,
						onChange: (t) => j(e.id, t.target.checked)
					}), /* @__PURE__ */ Y("label", {
						className: `local-checklist-text${t ? " is-checked" : ""}`,
						htmlFor: `${r}-${e.id}`,
						children: n.renderInline(e.content.children, s)
					})]
				}, e.id);
			}),
			/* @__PURE__ */ Y(E, {
				block: !0,
				value: /* @__PURE__ */ Y("ul", {
					className: "local-static-list",
					children: T.map((t) => {
						let n = k.includes(t.id);
						return /* @__PURE__ */ X("li", {
							className: "local-static-list-item",
							children: [/* @__PURE__ */ Y("span", {
								className: "local-static-state",
								children: A(n)
							}), /* @__PURE__ */ Y("span", {
								className: `local-static-item${n ? " is-checked" : ""}`,
								children: y(e, t.content.children)
							})]
						}, t.id);
					})
				})
			}),
			/* @__PURE__ */ Y(O, { message: S ? u("Cannot compute", "无法计算") : f })
		]
	});
}
function Tu(e) {
	let t = c(e), { content: n, runtime: r, mode: i, t: a } = l(e), { write: o, error: s } = g(e), u = p(e, "label", a("Counter", "计数")), { disabled: d, invalid: h } = m(e), v = _(e), y = A(e, "min", 0), b = f(n, "max") === void 0 ? void 0 : A(e, "max", 0), x = A(e, "step", 1), S = C(e), w = typeof S == "number" && Number.isFinite(S) ? S : y, T = Number.isFinite(x) && x > 0 ? x : 1, D = 1e-9 * Math.max(1, Math.abs(w)), j = w - T >= y - D, M = b === void 0 || w + T <= b + D;
	if (i === "static") return /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-counter",
		label: u,
		value: String(w)
	});
	let N = (t) => {
		if (e.dispatchAuthorAction?.(t === 1 ? "increment" : "decrement")) return;
		let n = Number((w + t * T).toFixed(12));
		o(n);
	}, P = () => {
		e.dispatchAuthorAction?.("reset") || r.reset(n);
	};
	return /* @__PURE__ */ X("div", {
		...t(),
		className: "local-counter",
		role: "group",
		"aria-label": u,
		"data-rmd-component": "counter",
		"aria-invalid": v.invalid || void 0,
		"aria-describedby": v.describedBy,
		children: [
			/* @__PURE__ */ Y("span", {
				className: "md-label",
				children: u
			}),
			/* @__PURE__ */ X("div", {
				className: "local-counter-row",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "md-button md-button-secondary local-counter-button",
						"aria-label": `${u} ${a("decrease", "减少")}`,
						disabled: d || !j,
						onClick: () => N(-1),
						children: "−"
					}),
					/* @__PURE__ */ Y("span", {
						className: "local-counter-value",
						"aria-live": "polite",
						children: /* @__PURE__ */ Y("span", {
							className: "local-counter-value-pop",
							children: w
						}, w)
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "md-button md-button-secondary local-counter-button",
						"aria-label": `${u} ${a("increase", "增加")}`,
						disabled: d || !M,
						onClick: () => N(1),
						children: "+"
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "md-button md-button-quiet local-counter-reset",
						disabled: d,
						onClick: P,
						children: a("Reset", "恢复初值")
					})
				]
			}),
			/* @__PURE__ */ Y(E, { value: String(w) }),
			/* @__PURE__ */ Y(O, { message: h ? a("Cannot compute", "无法计算") : s })
		]
	});
}
function Eu(e) {
	let t = c(e), { content: n, runtime: i, mode: a, visible: o, locale: s, t: u } = l(e), d = p(e, "label", u("Timer", "计时器")), f = _(e), m = A(e, "duration", 60), h = Math.floor(m), g = C(e), v = typeof g == "number" && Number.isFinite(g) ? Math.max(0, Math.ceil(g)) : h, [y, x] = J(!1), [S, w] = J(!1), T = q(0), D = q(v);
	D.current = v;
	let [N, P] = J(null), F = ae((e) => {
		let t = i.set(n, e);
		t.length && P(t.map((e) => r(e, s)).join("; "));
	}, [
		n,
		s,
		i
	]);
	if (se(() => {
		if (!y) return;
		let e = window.setInterval(() => {
			let e = Math.max(0, Math.ceil((T.current - performance.now()) / 1e3));
			e !== D.current && (D.current = e, F(e)), e <= 0 && (x(!1), w(!0));
		}, 200);
		return () => window.clearInterval(e);
	}, [y, F]), se(() => {
		if (o || !y) return;
		let e = Math.max(0, Math.ceil((T.current - performance.now()) / 1e3));
		D.current = e, F(e), x(!1);
	}, [
		o,
		y,
		F
	]), M(e, () => {
		x(!1), w(!1), P(null);
	}), !Number.isFinite(m) || h <= 0) return /* @__PURE__ */ Y(b, { message: u("Timer duration must be a positive number of seconds", "计时时长必须是大于 0 的秒数") });
	if (a === "static") return /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-timer",
		label: d,
		value: j(v, u)
	});
	let I = () => {
		if (y) return;
		let e = v > 0 ? v : h;
		v <= 0 && (D.current = h, F(h)), T.current = performance.now() + e * 1e3, w(!1), P(null), x(!0);
	}, L = () => {
		if (!y) return;
		let e = Math.max(0, Math.ceil((T.current - performance.now()) / 1e3));
		D.current = e, F(e), x(!1);
	}, R = () => {
		x(!1), w(!1), P(null), D.current = h, i.reset(n);
	};
	return /* @__PURE__ */ X("div", {
		...t(),
		className: "local-timer",
		role: "group",
		"aria-label": d,
		"data-rmd-component": "timer",
		"aria-invalid": f.invalid || void 0,
		"aria-describedby": f.describedBy,
		children: [
			/* @__PURE__ */ X("div", {
				className: "local-timer-head",
				children: [/* @__PURE__ */ Y("span", {
					className: "md-label",
					children: d
				}), /* @__PURE__ */ Y("span", {
					className: "local-timer-value",
					role: "timer",
					"aria-label": u(`${v} seconds remaining`, `剩余 ${v} 秒`),
					children: j(v, u)
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "local-timer-controls",
				children: [
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "md-button md-button-primary",
						onClick: I,
						disabled: y,
						children: u("Start", "开始")
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "md-button md-button-secondary",
						onClick: L,
						disabled: !y,
						children: u("Pause", "暂停")
					}),
					/* @__PURE__ */ Y("button", {
						type: "button",
						className: "md-button md-button-quiet",
						onClick: R,
						children: u("Reset", "重置")
					})
				]
			}),
			/* @__PURE__ */ Y("span", {
				className: "local-timer-status",
				role: "status",
				"aria-live": "polite",
				children: S ? u("Completed", "计时完成") : y ? u("Running", "计时中") : u("Paused", "已暂停")
			}),
			/* @__PURE__ */ Y(E, { value: j(v, u) }),
			/* @__PURE__ */ Y(O, { message: N })
		]
	});
}
function Du(e) {
	let t = c(e), { content: n, t: r } = l(e), i = p(e, "label", r("Progress", "进度")), o = A(e, "max", 100), s = e.props.value;
	if (!Number.isFinite(o) || o <= 0) return /* @__PURE__ */ Y(b, { message: r("Progress maximum must be positive", "进度上限必须是正数") });
	if (s == null) return /* @__PURE__ */ Y(b, { message: r("Cannot compute", "无法计算") });
	let u = typeof s == "number" ? s : typeof s == "string" && s.trim() !== "" ? Number(s) : NaN;
	if (!Number.isFinite(u)) return /* @__PURE__ */ Y(b, { message: r("Cannot compute", "无法计算") });
	if (u < 0 || u > o) return /* @__PURE__ */ Y(b, { message: r(`Progress value must be between 0 and ${o}`, `进度值需要在 0 到 ${o} 之间`) });
	let d = u / o * 100, f = a(n);
	return /* @__PURE__ */ X("div", {
		className: "local-progress",
		"data-rmd-component": "progress",
		...t(f ? { "--local-progress-color": f } : void 0),
		children: [/* @__PURE__ */ X("div", {
			className: "local-progress-head",
			children: [/* @__PURE__ */ Y("span", {
				className: "md-label",
				children: i
			}), /* @__PURE__ */ X("span", {
				className: "local-progress-value",
				children: [Math.round(d), "%"]
			})]
		}), /* @__PURE__ */ Y("div", {
			className: "local-progress-track",
			role: "progressbar",
			"aria-label": i || r("Progress", "进度"),
			"aria-valuemin": 0,
			"aria-valuemax": o,
			"aria-valuenow": u,
			children: /* @__PURE__ */ Y("div", {
				className: "local-progress-fill",
				style: { width: `${d}%` }
			})
		})]
	});
}
function Ou(e) {
	let t = c(e), n = l(e), r = ce(), { content: i, mode: s, visible: u, t: f } = n, { write: h, error: v, setError: S } = g(e), w = p(e, "label", f("Multi select", "多选")), { disabled: T, invalid: D } = m(e), j = _(e), N = e.children.options(), P = C(e), F = Array.isArray(P) ? P.filter((e) => typeof e == "string") : [], I = N.filter((e) => F.includes(e.value)).map((t) => o(e, t) || t.value), L = A(e, "max-selected", N.length), R = Number.isFinite(L) ? Math.max(0, Math.floor(L)) : N.length, [z, B] = J("");
	if (M(e, () => {
		B(""), S(null);
	}), N.length === 0) return /* @__PURE__ */ Y(b, { message: f("Missing options", "缺少选项") });
	if (s === "static") return /* @__PURE__ */ Y(k, {
		authorRoot: t(),
		className: "local-multi-select",
		label: w,
		value: d(I.join(", "))
	});
	let V = new Set(F), ee = F.length >= R, H = z.trim().toLocaleLowerCase(), U = H ? N.filter((t) => `${y(e, t.content.children)} ${t.value}`.toLocaleLowerCase().includes(H)) : N, te = (e, t) => {
		let n = new Set(V);
		if (t) {
			if (!n.has(e) && n.size >= R) return;
			n.add(e);
		} else n.delete(e);
		h(N.filter((e) => n.has(e.value)).map((e) => e.value));
	}, W = () => {
		B(""), F.length > 0 && h([]);
	};
	return /* @__PURE__ */ X("fieldset", {
		className: "local-multi-select",
		...t(x(a(i))),
		"data-rmd-component": "multi-select",
		disabled: T,
		"aria-invalid": j.invalid || void 0,
		"aria-describedby": j.describedBy,
		children: [
			/* @__PURE__ */ Y("legend", {
				className: "md-label",
				children: w
			}),
			/* @__PURE__ */ X("div", {
				className: "local-multi-toolbar",
				children: [/* @__PURE__ */ Y("input", {
					id: `${r}-multi-search`,
					type: "search",
					className: "md-text-input local-multi-search",
					value: z,
					placeholder: f("Search options", "搜索选项"),
					"aria-label": f(`Search ${w}`, `搜索${w}`),
					onChange: (e) => B(e.target.value)
				}), /* @__PURE__ */ Y("button", {
					type: "button",
					className: "md-button md-button-quiet local-multi-clear",
					onClick: W,
					children: f("Clear", "清除")
				})]
			}),
			/* @__PURE__ */ Y("div", {
				className: "local-multi-list",
				role: "group",
				"aria-label": w,
				children: U.length === 0 ? /* @__PURE__ */ Y("span", {
					className: "local-multi-empty",
					children: f("No matching options", "没有匹配选项")
				}) : U.map((e) => {
					let t = V.has(e.value);
					return /* @__PURE__ */ X("label", {
						className: `local-multi-option${t ? " is-selected" : ""}`,
						children: [/* @__PURE__ */ Y("input", {
							type: "checkbox",
							checked: t,
							disabled: !t && ee,
							onChange: (t) => te(e.value, t.target.checked)
						}), /* @__PURE__ */ Y("span", { children: n.renderInline(e.content.children, u) })]
					}, e.content.id);
				})
			}),
			/* @__PURE__ */ Y("span", {
				className: "local-multi-count",
				role: "status",
				"aria-live": "polite",
				children: f(`${F.length} of ${R} selected`, `已选 ${F.length}/${R}`)
			}),
			/* @__PURE__ */ Y(E, { value: d(I.join(", ")) }),
			/* @__PURE__ */ Y(O, { message: D ? f("Cannot compute", "无法计算") : v })
		]
	});
}
function ku(e) {
	let t = c(e), n = l(e), r = ce(), { content: i, mode: a, visible: o, t: s } = n, u = p(e, "label", s("Quiz", "测验")), d = f(i, "type") === "number" ? "number" : "choice", h = (f(i, "answer") ?? "").trim(), g = A(e, "tolerance", 0), _ = Number.isFinite(g) && g >= 0 ? g : 0, { disabled: v, invalid: y } = m(e), x = e.children.options(), S = p(e, "explanation", ""), [C, w] = J(""), [T, D] = J(null);
	M(e, () => {
		w(""), D(null);
	});
	let k = d === "number" ? Number(h) : NaN;
	if (d === "number" && !Number.isFinite(k)) return /* @__PURE__ */ Y(b, { message: s("Quiz answer must be a number", "测验答案必须是数字") });
	if (d === "choice" && x.length === 0) return /* @__PURE__ */ Y(b, { message: s("Missing options", "缺少选项") });
	let j = x.map((e) => e.label || e.value);
	if (a === "static") return /* @__PURE__ */ X("div", {
		...t(),
		className: "local-quiz local-static-quiz",
		role: "group",
		"aria-label": u,
		children: [/* @__PURE__ */ Y("span", {
			className: "md-label",
			children: u
		}), d === "choice" ? /* @__PURE__ */ Y("ul", {
			className: "local-static-list local-static-quiz-options",
			children: x.map((e) => /* @__PURE__ */ Y("li", {
				className: "local-static-list-item",
				children: n.renderInline(e.content.children, o)
			}, e.content.id))
		}) : /* @__PURE__ */ Y("span", {
			className: "local-static-value",
			children: s("Numeric answer", "数字作答")
		})]
	});
	let N = () => {
		if (d === "choice") {
			if (C === "") {
				D("incomplete");
				return;
			}
			D(C === h ? "correct" : "incorrect");
			return;
		}
		let e = C.trim(), t = e === "" ? NaN : Number(e);
		D(Number.isFinite(t) ? Math.abs(t - k) <= _ ? "correct" : "incorrect" : "incomplete");
	}, P = () => {
		w(""), D(null);
	}, F = T === null ? null : T === "correct" ? `${s("Correct", "回答正确")}` : T === "incorrect" ? `${s("Not quite", "回答不正确")}` : d === "number" ? s("Enter a number first", "请先输入数字") : s("Choose an answer first", "请先选择答案"), I = T === "correct" ? " is-correct" : T === "incorrect" ? " is-incorrect" : "";
	return /* @__PURE__ */ X("div", {
		...t(),
		className: "local-quiz",
		role: "group",
		"aria-label": u,
		"data-rmd-component": "quiz",
		children: [
			d === "choice" ? /* @__PURE__ */ X("fieldset", {
				className: "local-quiz-options",
				disabled: v,
				children: [/* @__PURE__ */ Y("legend", {
					className: "md-label",
					children: u
				}), x.map((e) => /* @__PURE__ */ X("label", {
					className: "local-radio-option",
					children: [/* @__PURE__ */ Y("input", {
						type: "radio",
						name: `${r}-quiz`,
						value: e.value,
						checked: C === e.value,
						onChange: () => {
							w(e.value), D(null);
						}
					}), /* @__PURE__ */ Y("span", { children: n.renderInline(e.content.children, o) })]
				}, e.content.id))]
			}) : /* @__PURE__ */ X("div", {
				className: "local-quiz-number",
				children: [/* @__PURE__ */ Y("label", {
					className: "md-label",
					htmlFor: `${r}-quiz`,
					children: u
				}), /* @__PURE__ */ Y("input", {
					id: `${r}-quiz`,
					className: "md-text-input local-quiz-input",
					type: "text",
					inputMode: "decimal",
					value: C,
					disabled: v,
					"aria-label": u,
					onChange: (e) => {
						w(e.target.value), D(null);
					}
				})]
			}),
			/* @__PURE__ */ X("div", {
				className: "local-quiz-actions",
				children: [/* @__PURE__ */ Y("button", {
					type: "button",
					className: "md-button md-button-primary local-quiz-check",
					disabled: v,
					onClick: N,
					children: s("Check answer", "检查答案")
				}), /* @__PURE__ */ Y("button", {
					type: "button",
					className: "md-button md-button-secondary local-quiz-again",
					disabled: v,
					onClick: P,
					children: s("Try again", "再试一次")
				})]
			}),
			/* @__PURE__ */ Y("span", {
				className: `local-quiz-feedback${I}`,
				role: "status",
				"aria-live": "polite",
				children: F ? `${T === "correct" ? "✓ " : T === "incorrect" ? "✗ " : ""}${F}` : ""
			}),
			T !== null && S ? /* @__PURE__ */ Y("div", {
				className: "local-quiz-explanation",
				children: S
			}) : null,
			/* @__PURE__ */ Y(E, {
				block: !0,
				value: d === "choice" ? `${F ? `${F} · ` : ""}${j.join(" · ")}` : F || s("No answer yet", "尚未作答")
			}),
			/* @__PURE__ */ Y(O, { message: y ? s("Cannot compute", "无法计算") : null })
		]
	});
}
export { au as _, yu as a, pu as c, Su as d, bu as f, ou as g, mu as h, Tu as i, Du as l, Eu as m, wu as n, cu as o, lu as p, xu as r, Ou as s, hu as t, ku as u };
