/** True for an engine-owned report code outside the compiler's registry. */
export declare function isReportOnlyDiagnosticCode(code: string): boolean;
