import type { Diagnostic } from './types.js';
export interface LocalTraceEvent {
    readonly type: 'compile-start' | 'compile-end' | 'worker-request' | 'worker-response' | 'worker-timeout' | 'worker-stale-response' | 'worker-cancel' | 'worker-error' | 'export-start' | 'export-end' | 'export-cancel' | 'export-error';
    readonly traceId: string;
    readonly requestId?: number;
    readonly sourceRevision?: number;
    readonly timestamp: number;
    readonly durationMs?: number;
    readonly code?: string;
    readonly status?: string;
    readonly stage?: string;
    /**
     * Bounded free text for the observer only. Diagnostic reports copy an
     * allowlist that omits it, so a reason can reach host logging without
     * entering a shareable report.
     */
    readonly detail?: string;
}
export interface LocalObserver {
    onDiagnostic?: (diagnostic: Diagnostic) => void;
    onTrace?: (event: LocalTraceEvent) => void;
}
export declare function createLocalTraceId(): string;
export declare function emitLocalTrace(observer: LocalObserver | undefined, event: LocalTraceEvent): void;
export declare function emitLocalDiagnostic(observer: LocalObserver | undefined, diagnostic: Diagnostic): void;
