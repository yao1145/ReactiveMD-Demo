import { D as e, _ as t, g as n, i as r, o as i, r as a, t as o, v as s, w as c, y as l } from "./version-DAxuGOG2.js";
import { v as u } from "./document-theme-C8J6UyNO.js";
import { a as d, n as f, s as p, t as m } from "./compile-Dx6Uw3D9.js";
import { C as h, S as g, _, a as v, c as y, d as b, h as x, i as S, m as C, n as w, o as T, p as ee, r as E, s as te, t as ne, v as re, w as D, x as O, y as ie } from "./config-validation-D3D7Dy2J.js";
import { A as ae, N as oe, a as se, i as ce, t as le } from "./preset-core-DeZPA8IE.js";
import { n as ue } from "./props-sJ8vk0cr.js";
import { p as de, r as fe, x as pe } from "./registry-core-C9xOunaw.js";
// node_modules/devlop/lib/default.js
function me() {}
// node_modules/mdast-util-to-string/lib/index.js
var he = {};
function ge(e, t) {
	let n = t || he;
	return _e(e, typeof n.includeImageAlt != "boolean" || n.includeImageAlt, typeof n.includeHtml != "boolean" || n.includeHtml);
}
function _e(e, t, n) {
	if (ye(e)) {
		if ("value" in e) return e.type === "html" && !n ? "" : e.value;
		if (t && "alt" in e && e.alt) return e.alt;
		if ("children" in e) return ve(e.children, t, n);
	}
	return Array.isArray(e) ? ve(e, t, n) : "";
}
function ve(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) r[i] = _e(e[i], t, n);
	return r.join("");
}
function ye(e) {
	return !!(e && typeof e == "object");
}
// node_modules/micromark-util-chunked/index.js
function k(e, t, n, r) {
	let i = e.length, a = 0, o;
	if (t = t < 0 ? -t > i ? 0 : i + t : t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4) o = Array.from(r), o.unshift(t, n), e.splice(...o);
	else for (n && e.splice(t, n); a < r.length;) o = r.slice(a, a + 1e4), o.unshift(t, 0), e.splice(...o), a += 1e4, t += 1e4;
}
function be(e, t) {
	return e.length > 0 ? (k(e, e.length, 0, t), e) : t;
}
// node_modules/micromark-util-combine-extensions/index.js
var A = {}.hasOwnProperty;
function xe(e) {
	let t = {}, n = -1;
	for (; ++n < e.length;) Se(t, e[n]);
	return t;
}
function Se(e, t) {
	let n;
	for (n in t) {
		let r = (A.call(e, n) ? e[n] : void 0) || (e[n] = {}), i = t[n], a;
		if (i) for (a in i) {
			A.call(r, a) || (r[a] = []);
			let e = i[a];
			Ce(r[a], Array.isArray(e) ? e : e ? [e] : []);
		}
	}
}
function Ce(e, t) {
	let n = -1, r = [];
	for (; ++n < t.length;) (t[n].add === "after" ? e : r).push(t[n]);
	k(e, 0, 0, r);
}
// node_modules/micromark-util-normalize-identifier/index.js
function we(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
// node_modules/micromark-util-character/index.js
var Te = I(/[A-Za-z]/), Ee = I(/[\dA-Za-z]/), De = I(/[#-'*+\--9=?A-Z^-~]/);
function Oe(e) {
	return e !== null && (e < 32 || e === 127);
}
var ke = I(/\d/), Ae = I(/[\dA-Fa-f]/), je = I(/[!-/:-@[-`{-~]/);
function j(e) {
	return e !== null && e < -2;
}
function M(e) {
	return e !== null && (e < 0 || e === 32);
}
function N(e) {
	return e === -2 || e === -1 || e === 32;
}
var P = I(/\p{P}|\p{S}/u), F = I(/\s/);
function I(e) {
	return t;
	function t(t) {
		return t !== null && t > -1 && e.test(String.fromCharCode(t));
	}
}
// node_modules/micromark-factory-space/index.js
function L(e, t, n, r) {
	let i = r ? r - 1 : Infinity, a = 0;
	return o;
	function o(r) {
		return N(r) ? (e.enter(n), s(r)) : t(r);
	}
	function s(r) {
		return N(r) && a++ < i ? (e.consume(r), s) : (e.exit(n), t(r));
	}
}
function Me(e, t, n, r, i, a) {
	let o = 0;
	return s;
	function s(t) {
		return a > 0 && N(t) ? (e.enter(r), c(t)) : l(t);
	}
	function c(t) {
		return N(t) && o < a ? (e.consume(t), o++, c) : (e.exit(r), l(t));
	}
	function l(e) {
		return o >= i ? t(e) : n(e);
	}
}
// node_modules/micromark-util-classify-character/index.js
function Ne(e) {
	if (e === null || M(e) || F(e)) return 1;
	if (P(e)) return 2;
}
// node_modules/micromark-util-resolve-all/index.js
function Pe(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) {
		let a = e[i].resolveAll;
		a && !r.includes(a) && (t = a(t, n), r.push(a));
	}
	return t;
}
// node_modules/micromark-core-commonmark/lib/blank-line.js
var Fe = {
	partial: !0,
	tokenize: Ie
};
function Ie(e, t, n) {
	return r;
	function r(t) {
		return N(t) ? L(e, i, "linePrefix")(t) : i(t);
	}
	function i(e) {
		return e === null || j(e) ? t(e) : n(e);
	}
}
// src/local/html/html-table-names.ts
var Le = /* @__PURE__ */ new Set([
	"table",
	"caption",
	"colgroup",
	"col",
	"thead",
	"tbody",
	"tfoot",
	"tr",
	"th",
	"td"
]), R = {
	colgroup: /* @__PURE__ */ new Set(["span"]),
	col: /* @__PURE__ */ new Set(["span"]),
	td: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"align"
	]),
	th: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"scope",
		"abbr",
		"align"
	])
};
function z(e, t) {
	let n = t.trim();
	return [
		"colspan",
		"rowspan",
		"span"
	].includes(e) ? /^\d{1,5}$/.test(n) && Number(n) <= (e === "rowspan" ? 65534 : 1e3) && Number(n) >= (e === "rowspan" ? 0 : 1) : e === "align" ? D(t) !== null : e !== "scope" || [
		"row",
		"col",
		"rowgroup",
		"colgroup"
	].includes(n.toLowerCase());
}
// src/local/html/html-policy.ts
var Re = {
	b: "strong",
	strong: "strong",
	i: "emphasis",
	em: "emphasis",
	s: "delete",
	del: "delete",
	u: "underline",
	mark: "mark",
	sup: "sup",
	sub: "sub"
}, ze = /* @__PURE__ */ new Set([
	"br",
	"hr",
	"img",
	"col"
]), Be = /* @__PURE__ */ new Set([
	"pre",
	"code",
	"script",
	"style",
	"textarea",
	"title",
	"xmp",
	"iframe",
	"noembed",
	"noframes",
	"plaintext"
]), Ve = /* @__PURE__ */ new Set([
	"id",
	"title",
	"lang",
	"dir"
]), He = {
	a: g,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...R
};
function Ue(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") return i + 1;
	}
	return -1;
}
function We(e, t, n) {
	if (e.startsWith("<!-->", t)) return Math.min(n, t + 5);
	if (e.startsWith("<!--->", t)) return Math.min(n, t + 6);
	let r = e.indexOf("-->", t + 4);
	return r < 0 || r + 3 > n ? n : r + 3;
}
function Ge(e) {
	return e.trim().replace(/[\u0000- ]+/g, "");
}
function B(e, t) {
	let n = /^([a-z][a-z0-9+.-]*):/i.exec(Ge(e));
	if (!n) return !1;
	let r = n[1].toLowerCase();
	return t === "image" ? r !== "http" && r !== "https" : r !== "http" && r !== "https" && r !== "mailto" && r !== "tel";
}
function Ke(e, t) {
	return t === "class" || t === "style" || /^on[a-z]/i.test(t) ? !1 : t === "align" && O.has(e) || Ve.has(t) || /^aria-[a-z0-9_.-]+$/.test(t) || /^data-[a-z0-9_.-]+$/.test(t) ? !0 : He[e]?.has(t) ?? !1;
}
function qe(e, t) {
	return !(e === "dir" && ![
		"ltr",
		"rtl",
		"auto"
	].includes(t.trim().toLowerCase()) || e === "id" && t.trim() === "" || (e === "width" || e === "height") && !/^\d{1,6}$/.test(t.trim()) || e === "start" && !/^-?\d{1,9}$/.test(t.trim()) || !z(e, t) || e === "href" && B(t, "link") || e === "src" && B(t, "image"));
}
function Je(e, t) {
	return O.has(e) ? D(t) : null;
}
// src/local/parsing/parser-capabilities.ts
var Ye = Object.freeze({}), Xe = Object.freeze([
	"anchor",
	"checkbox",
	"column",
	"coordinate",
	"counter",
	"date",
	"edge",
	"input",
	"number",
	"progress",
	"range-slider",
	"slider",
	"textarea",
	"timer",
	"toggle",
	"validation"
]);
function Ze(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of Xe) e(n) || t.add(n);
	return t;
}
// src/sdk/compiler-config.ts
var V = Object.freeze({
	id: ce,
	version: se
}), H = /* @__PURE__ */ new WeakMap(), U = /* @__PURE__ */ new WeakMap();
function W(e, t = V) {
	if (e.length === 0) return;
	let n = t.id === V.id && t.version === V.version;
	if (n) {
		let t = H.get(e);
		if (t) return t;
	}
	let r = le({
		protocol: i,
		id: t.id,
		version: t.version,
		components: e
	});
	return n && H.set(e, r), r;
}
function G(e, t, n, r, i = "reactive-md-config/v1") {
	let a = x(e, { legacyProfiles: t.length > 0 ? n : [] }), o = [...a.legacyKeys, ...r !== void 0 && !a.legacyKeys.some((e) => e.key === r) ? [Object.freeze({
		profile: i,
		key: r
	})] : []];
	return b(e, a, o);
}
function Qe(e) {
	return v(e) || S("assembly", "must be an object."), E(e, /* @__PURE__ */ new Set([
		"protocol",
		"presets",
		"components",
		"replacementPolicy",
		"themes"
	]), "assembly"), e.protocol !== "reactive-md-assembly/v1" && S("assembly.protocol", `must be "${o}".`), C(e);
}
function $e(e, t = [], n = []) {
	let i = re(n);
	if (v(e) || S("config", "must be an object."), E(e, ne, "config"), e.protocol === "reactive-md-config/v2") {
		let n = Qe(e.assembly), r = G(n, t, i);
		return ae(n) > 16777216 && S("config", `serialized size exceeds the ${w}-byte budget.`), r;
	}
	e.protocol !== "reactive-md-config/v1" && S("config.protocol", `must be "${r}" (or legacy "${a}").`);
	let s = te(e.presets, V, i)[0] ?? V, c = _(s, i);
	c === void 0 && S("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${s.id}" ${s.version}.`);
	let l = c.legacyKeys[0];
	l === void 0 && S("presets", `local.config.migration-unsupported: profile "${c.name}" has no legacy key mapping.`), y(c, t);
	let u = T(e.components, t);
	u.some((e) => e.replaces !== void 0) && S("config", "replaces is not supported by reactive-md-config/v1.");
	let d = W(t, c.preset), f = Object.freeze({
		protocol: o,
		presets: Object.freeze(d ? [d] : []),
		components: u,
		replacementPolicy: "forbid",
		themes: Object.freeze([])
	}), p = G(f, t, i, t.length > 0 ? ee(c.preset, u) : void 0, l.profile);
	return ae(f) > 16777216 && S("config", `serialized size exceeds the ${w}-byte budget.`), p;
}
function et(e) {
	let t = U.get(e);
	if (t !== void 0) return t;
	let n = W(e), r = Object.freeze({
		protocol: o,
		presets: Object.freeze(n ? [n] : []),
		components: Object.freeze([]),
		replacementPolicy: "forbid",
		themes: Object.freeze([])
	}), i = x(r).key;
	return U.set(e, i), i;
}
// src/local/configuration/capability-policy.ts
var K = Object.freeze({
	enableCss: !0,
	enableJavaScript: !1,
	enableExtendedHtml: !1
});
function tt(e, t) {
	return {
		enableCss: e?.enableCss === !0 && (t?.enableCss ?? K.enableCss) === !0,
		enableJavaScript: e?.enableJavaScript === !0 && t?.enableJavaScript === !0,
		enableExtendedHtml: e?.enableExtendedHtml === !0 && t?.enableExtendedHtml === !0
	};
}
// src/local/configuration/options-core.ts
var nt = [
	"enableCss",
	"enableJavaScript",
	"enableExtendedHtml"
], rt = V;
function q(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var it = "local.options.invalid.host-components", at = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, ot = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), st = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), ct = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean"
]), lt = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]), ut = /* @__PURE__ */ new Set([
	"maxSyntaxNodes",
	"maxParseWork",
	"maxMarkdownDepth"
]);
function J(e, t, n) {
	if (!Object.hasOwn(e, t)) return {
		ok: !0,
		value: n
	};
	let r = e[t];
	if (r === void 0) return {
		ok: !0,
		value: n
	};
	if (typeof r != "number" || !Number.isSafeInteger(r) || r < 1) {
		let e = t === "maxSyntaxNodes" ? "max-syntax-nodes" : t === "maxParseWork" ? "max-parse-work" : "max-markdown-depth";
		return {
			ok: !1,
			message: `Compile option limits.${t} must be a positive safe integer.`,
			key: `local.options.invalid.${e}`
		};
	}
	return {
		ok: !0,
		value: r
	};
}
function Y(e) {
	return {
		ok: !1,
		message: `Compile option hostComponents is invalid: ${e}`,
		key: it,
		detail: e
	};
}
function dt(e, t) {
	if (e === void 0) return {
		ok: !0,
		binding: void 0
	};
	if (!q(e)) return Y(`${t} "binding" must be an object.`);
	for (let n of Object.keys(e)) if (![
		"kind",
		"initialRule",
		"min",
		"max",
		"step",
		"options",
		"exclusive"
	].includes(n)) return Y(`${t} "binding" has unknown field "${n}".`);
	let n = e.kind;
	if (typeof n != "string" || !ct.has(n)) return Y(`${t} "binding.kind" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
	let r = { kind: n };
	if (Object.hasOwn(e, "exclusive") && e.exclusive !== void 0) {
		if (typeof e.exclusive != "boolean") return Y(`${t} "binding.exclusive" must be a boolean.`);
		r.exclusive = e.exclusive;
	}
	if (Object.hasOwn(e, "initialRule") && e.initialRule !== void 0) {
		let n = e.initialRule;
		if (typeof n != "string" || ![
			"empty",
			"false",
			"nearest-zero",
			"min",
			"first-option"
		].includes(n)) return Y(`${t} "binding.initialRule" is not supported.`);
		r.initialRule = n;
	}
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (!Object.hasOwn(e, n) || e[n] === void 0) continue;
		if (r.kind !== "number") return Y(`${t} "binding.${n}" is only valid for number bindings.`);
		let i = e[n];
		if (typeof i != "number" || !Number.isFinite(i)) return Y(`${t} "binding.${n}" must be a finite number.`);
		r[n] = i;
	}
	if (r.kind === "number") {
		if (r.step !== void 0 && !(r.step > 0)) return Y(`${t} "binding.step" must be greater than 0.`);
		if (r.min !== void 0 && r.max !== void 0 && r.min > r.max) return Y(`${t} "binding.min" cannot exceed "binding.max".`);
		if (r.initialRule !== void 0 && !["min", "nearest-zero"].includes(r.initialRule)) return Y(`${t} "binding.initialRule" must be "min" or "nearest-zero" for number bindings.`);
		r.initialRule ??= "nearest-zero";
	}
	let i = Object.hasOwn(e, "options") && e.options !== void 0;
	if (i) {
		if (r.kind !== "string") return Y(`${t} "binding.options" is only valid for string bindings.`);
		let n = e.options;
		if (!Array.isArray(n) || n.length === 0) return Y(`${t} "binding.options" must be a non-empty string array.`);
		if (n.length > 64) return Y(`${t} "binding.options" accepts at most 64 values.`);
		let i = /* @__PURE__ */ new Set(), a = [];
		for (let e of n) {
			if (typeof e != "string" || e === "") return Y(`${t} "binding.options" must be a non-empty string array.`);
			if (e.length > 128) return Y(`${t} "binding.options" value exceeds the 128-character limit.`);
			if (i.has(e)) return Y(`${t} "binding.options" value "${e}" is declared more than once.`);
			i.add(e), a.push(e);
		}
		r.options = a, r.initialRule ??= "first-option";
	}
	if (r.kind === "string") {
		let e = i ? "first-option" : "empty";
		if (r.initialRule !== void 0 && r.initialRule !== e) return Y(`${t} "binding.initialRule" must be "${e}" for ${i ? "choice" : "string"} bindings.`);
		r.initialRule ??= e;
	}
	if (r.kind === "boolean") {
		if (r.initialRule !== void 0 && r.initialRule !== "false") return Y(`${t} "binding.initialRule" must be "false" for boolean bindings.`);
		r.initialRule ??= "false";
	}
	return {
		ok: !0,
		binding: r
	};
}
function ft(e, t) {
	let n = [], r = /* @__PURE__ */ new Map();
	if (e === void 0) return {
		ok: !0,
		hostComponents: n,
		hostByName: r
	};
	if (!Array.isArray(e)) return Y("must be an array.");
	if (e.length > 32) return Y("accepts at most 32 components.");
	let i = /* @__PURE__ */ new Set();
	for (let e of t) i.add(e.name.toLowerCase());
	for (let e of ie) i.add(e.name.toLowerCase());
	for (let e of h) i.add(e.toLowerCase());
	i.add("theme");
	for (let t = 0; t < e.length; t += 1) {
		let a = e[t], o = `hostComponents[${t}]`;
		if (!q(a)) return Y(`${o} must be an object.`);
		let s = a.name;
		if (typeof s != "string") return Y(`${o} "name" must be a string.`);
		if (s.length > 128) return Y(`${o} "name" exceeds the 128-character limit.`);
		if (!at.test(s)) return Y(`${o} "name" ${s} must use lowercase kebab-case.`);
		if (i.has(s.toLowerCase())) return Y(`${o} "name" ${s} conflicts with a built-in component, HTML tag or theme.`);
		if (r.has(s.toLowerCase())) return Y(`${o} "name" ${s} is declared more than once.`);
		if (typeof a.form != "string" || !st.has(a.form)) return Y(`${o} "form" must be "leaf", "inline" or "container".`);
		let c = a.form, l = dt(a.binding, o);
		if (!l.ok) return l;
		let u = l.binding, d = a.props;
		if (!q(d)) return Y(`${o} "props" must be an object.`);
		let f = {};
		for (let e of Object.keys(d)) {
			if (!at.test(e)) return Y(`${o} property "${e}" must use lowercase kebab-case.`);
			if (u && lt.has(e)) return Y(`${o} property "${e}" is reserved by the host binding.`);
			let t = d[e];
			if (!q(t)) return Y(`${o} property "${e}" must be an object.`);
			let n = t.kind;
			if (typeof n != "string" || !ot.has(n)) return Y(`property "${e}" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
			let r = { kind: n };
			for (let n of ["required", "static"]) if (Object.hasOwn(t, n) && t[n] !== void 0) {
				if (typeof t[n] != "boolean") return Y(`${o} property "${e}" "${n}" must be a boolean.`);
				r[n] = t[n];
			}
			let i = Object.hasOwn(t, "enum") && t.enum !== void 0;
			if (n !== "enum") {
				if (i) return Y(`${o} property "${e}" has "enum" but kind is "${n}".`);
			} else {
				let n = t.enum;
				if (!Array.isArray(n) || n.length === 0) return Y(`${o} property "${e}" "enum" must be a non-empty string array.`);
				if (n.length > 64) return Y(`${o} property "${e}" "enum" accepts at most 64 values.`);
				let i = /* @__PURE__ */ new Set();
				for (let t of n) {
					if (typeof t != "string") return Y(`${o} property "${e}" "enum" must be a non-empty string array.`);
					if (t.length > 128) return Y(`${o} property "${e}" enum value exceeds the 128-character limit.`);
					if (i.has(t)) return Y(`${o} property "${e}" enum value "${t}" is declared more than once.`);
					i.add(t);
				}
				r.enum = [...n];
			}
			let a = Object.hasOwn(t, "pattern") && t.pattern !== void 0;
			if (n !== "string") {
				if (a) return Y(`${o} property "${e}" has "pattern" but kind is "${n}".`);
			} else if (a) {
				let n = t.pattern;
				if (typeof n != "string") return Y(`${o} property "${e}" "pattern" must be a string.`);
				if (n.length > 512) return Y(`${o} property "${e}" "pattern" exceeds the 512-character limit.`);
				try {
					new RegExp(n);
				} catch {
					return Y(`${o} property "${e}" "pattern" is not a valid regular expression.`);
				}
				if (!oe(n)) return Y(`${o} property "${e}" "pattern" uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected.`);
				r.pattern = n;
			}
			f[e] = r;
		}
		let p = {
			name: s,
			form: c,
			props: f,
			...u ? { binding: u } : {}
		};
		n.push(p), r.set(s, p);
	}
	return {
		ok: !0,
		hostComponents: n,
		hostByName: r
	};
}
function pt(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function mt(e) {
	let t = e.static === !0 || e.dynamic === !1;
	if (e.kind === "enum") {
		let n = `^(?:${(e.enum ?? []).map(pt).join("|")})$`;
		if (n.length <= 512) return {
			kind: "string",
			...e.required === !0 ? { required: !0 } : {},
			...t ? { static: !0 } : {},
			pattern: n
		};
	}
	let n = { kind: e.kind };
	return e.required === !0 && e.default === void 0 && (n.required = !0), t && (n.static = !0), e.enum && (n.enum = [...e.enum]), e.pattern !== void 0 && (n.pattern = e.pattern), n;
}
function ht(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
	for (let i of e.components) {
		let e = {};
		for (let t of Object.keys(i.props)) e[t] = mt(i.props[t]);
		let a = ue(i), o = {
			name: i.name,
			form: i.form,
			props: e,
			...a ? { binding: a } : {}
		};
		t.push(o), n.set(i.name, o), r.set(i.name, i);
	}
	return {
		hostComponents: t,
		hostByName: n,
		sdkByName: r
	};
}
function X(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.name, t);
	let r = /* @__PURE__ */ new Map();
	for (let e of t.values()) r.set(e.name, e);
	for (let e of ie) r.has(e.name) || r.set(e.name, pe(e));
	return {
		componentByName: n,
		schemaByName: r
	};
}
function Z(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name, fe(n));
	return t;
}
function gt(e, r) {
	let i = r.defaults, a = new Set(i.map((e) => e.name));
	if (e !== void 0 && !q(e)) return {
		ok: !1,
		message: "Compile options must be an object.",
		key: "local.options.invalid.object"
	};
	let o = e ?? {}, c = { ...K };
	for (let e of nt) {
		if (!Object.hasOwn(o, e)) continue;
		let t = o[e];
		if (t !== void 0) {
			if (typeof t != "boolean") return {
				ok: !1,
				message: `Compile option ${e} must be a boolean.`,
				key: "local.options.invalid.html-flag"
			};
			c[e] = t;
		}
	}
	let l = !1;
	if (Object.hasOwn(o, "markdownBreaks")) {
		let e = o.markdownBreaks;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option markdownBreaks must be a boolean.",
				key: "local.options.invalid.markdown-breaks"
			};
			l = e;
		}
	}
	let u = !0;
	if (Object.hasOwn(o, "strict")) {
		let e = o.strict;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option strict must be a boolean.",
				key: "local.options.invalid.strict"
			};
			u = e;
		}
	}
	if (Object.hasOwn(o, "sourcePhase")) {
		let e = o.sourcePhase;
		if (e !== void 0 && e !== "streaming" && e !== "final") return {
			ok: !1,
			message: "Compile option sourcePhase must be \"streaming\" or \"final\".",
			key: "local.options.invalid.source-phase"
		};
	}
	let d = o.limits, f = s, p = t, m = n;
	if (d !== void 0) {
		if (!q(d)) return {
			ok: !1,
			message: "Compile option limits must be an object.",
			key: "local.options.invalid.limits"
		};
		for (let e of Object.keys(d)) if (!ut.has(e) && d[e] !== void 0) return {
			ok: !1,
			message: `Compile option limits.${e} is not supported.`,
			key: "local.options.invalid.limits-unknown",
			detail: e
		};
		let e = J(d, "maxSyntaxNodes", f);
		if (!e.ok) return e;
		f = e.value;
		let t = J(d, "maxParseWork", p);
		if (!t.ok) return t;
		p = t.value;
		let n = J(d, "maxMarkdownDepth", m);
		if (!n.ok) return n;
		m = n.value;
	}
	let h = Object.hasOwn(o, "config") && o.config !== void 0, g = Object.hasOwn(o, "hostComponents") && o.hostComponents !== void 0;
	if (h && g) return {
		ok: !1,
		message: "Compile option config cannot be combined with hostComponents.",
		key: "local.options.invalid.config-conflict"
	};
	let _, v, y, b, x, S, C, w, T;
	if (h) {
		try {
			_ = r.readConfig(o.config, i);
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return {
				ok: !1,
				message: `Compile option config is invalid: ${t}`,
				key: "local.options.invalid.config",
				detail: t
			};
		}
		let e = ht(_);
		v = e.hostComponents, y = e.hostByName, b = e.sdkByName, x = _.registry;
		let t = X(x, Z(x));
		S = t.schemaByName, C = t.componentByName, w = new Set(_.components.map((e) => e.name)), T = /* @__PURE__ */ new Set();
	} else if (g) {
		let e = ft(o.hostComponents, i);
		if (!e.ok) return e;
		v = e.hostComponents, y = e.hostByName, b = /* @__PURE__ */ new Map(), x = i;
		let t = Z(i);
		for (let [n, r] of e.hostByName) t.set(n, pe({
			...r,
			legacyHost: !0
		}));
		let n = X(i, t);
		S = n.schemaByName, C = n.componentByName, w = new Set(e.hostByName.keys()), T = new Set(e.hostByName.keys());
	} else {
		v = [], y = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Map(), x = i;
		let e = X(i, Z(i));
		S = e.schemaByName, C = e.componentByName, w = /* @__PURE__ */ new Set(), T = /* @__PURE__ */ new Set();
	}
	return {
		ok: !0,
		maxSyntaxNodes: f,
		maxParseWork: p,
		maxMarkdownDepth: m,
		html: c,
		markdownBreaks: l,
		strict: u,
		hostComponents: v,
		hostByName: y,
		..._ ? { config: _ } : {},
		sdkByName: b,
		registry: x,
		componentByName: C,
		schemaByName: S,
		defaultComponentNames: a,
		unmountedLeafNames: _?.presets.some((e) => e.id === "reactive-md/minimal") ? Ze((e) => S.has(e)) : /* @__PURE__ */ new Set(),
		externalComponentNames: w,
		legacyHostNames: T,
		componentConfigKey: _ ? r.configKey(_) : r.defaultConfigKey,
		capabilities: r.capabilities ?? Ye,
		...r.preset ? { preset: r.preset } : {}
	};
}
function _t(e, t = [], n) {
	let r = t.length > 0 ? rt : void 0;
	return gt(e, {
		defaults: t,
		...r ? { preset: r } : {},
		defaultConfigKey: et(t),
		readConfig: $e,
		configKey: (e) => e.key,
		...n ? { capabilities: n } : {}
	});
}
function vt(e) {
	return e.componentConfigKey;
}
// src/local/configuration/kernel-value-rules.ts
function Q(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) r !== void 0 && (t[n] = r);
	return t;
}
function yt(e) {
	let t = [];
	for (let n of de(e)) switch (n.kind) {
		case "value-date":
			t.push(Q({
				kind: "date",
				min: n.min,
				max: n.max,
				required: n.required
			}));
			break;
		case "value-length":
			t.push(Q({
				kind: "length",
				min: n.min,
				max: n.max
			})), (n.email !== void 0 || n.emailType !== void 0) && t.push(Q({
				kind: "email",
				type: n.email ?? "type",
				value: n.emailType ?? "email"
			}));
			break;
		case "value-email":
			t.push(Q({
				kind: "email",
				type: n.type ?? "type",
				value: n.value ?? "email"
			}));
			break;
		case "value-required": t.push({
			kind: "required",
			required: n.required
		});
	}
	return t;
}
function bt(e) {
	if (!e || typeof e != "object") return;
	let t = e.kernel;
	if (t && typeof t == "object") return t;
}
var xt = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function St(e) {
	return xt.test(e);
}
function Ct(e, t, n) {
	let r = [];
	for (let i of e) {
		let e = i.target;
		e ? e.startsWith("#") || /\s/.test(e) ? r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" must be a bare heading slug or anchor id without "#" or whitespace.`,
			start: i.offset,
			key: "local.jump.bad-target",
			params: { target: e }
		}) : !t.has(e) && !n.has(e) && r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" does not resolve to a heading or explicit anchor in this document.`,
			start: i.offset,
			key: "local.jump.unresolved",
			params: { target: e }
		}) : r.push({
			code: "local.jump.target",
			message: "<jump> target cannot be empty.",
			start: i.offset,
			key: "local.jump.empty"
		});
	}
	return r;
}
Object.freeze({
	arrayLength: l,
	dataTableColumns: 20,
	plotCurves: 16,
	plotPoints: e
});
// src/local/evaluation/computations.ts
function $(e, t, n) {
	let r = t ? f(t, n) : void 0;
	return e.expressionOffset + (r ?? Math.max(0, e.source.indexOf(n)));
}
function wt(e, t, n, r = "local.expression") {
	t instanceof d ? e(`${r}.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0)) : e(`${r}.invalid`, `Expression error: ${t instanceof Error ? t.message : String(t)}`, n);
}
function Tt(e) {
	return e instanceof d ? e : new d("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function Et(e, t) {
	let n = new Set(e), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let t of e) r.set(t, 0);
	for (let a of e) for (let e of t(a)) {
		if (!n.has(e)) continue;
		r.set(a, (r.get(a) ?? 0) + 1);
		let t = i.get(e);
		t ? t.push(a) : i.set(e, [a]);
	}
	let a = [];
	for (let t of e) (r.get(t) ?? 0) === 0 && a.push(t);
	let o = [];
	for (let e = 0; e < a.length; e += 1) {
		let t = a[e];
		o.push(t);
		for (let e of i.get(t) ?? []) {
			let t = (r.get(e) ?? 0) - 1;
			r.set(e, t), t === 0 && a.push(e);
		}
	}
	let s = new Set(o);
	return {
		order: o,
		cyclic: e.filter((e) => !s.has(e))
	};
}
function Dt(e) {
	let t = Object.keys(e), n = new Set(t);
	return Et(t, (t) => {
		let r = e[t];
		return r ? r.dependencies.filter((e) => n.has(e)) : [];
	});
}
function Ot(e, t, n, r = /* @__PURE__ */ new Set(), i) {
	let a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = [], l = /* @__PURE__ */ new Set();
	for (let t of e) s.has(t.name) || (s.set(t.name, t), c.push(t.name));
	let u = new Set(c);
	for (let e of c) {
		let t = s.get(e), r;
		try {
			r = i?.expression(t.source) ?? m(t.source);
		} catch (r) {
			wt(n, r, t.expressionOffset), l.add(e);
			continue;
		}
		a.set(e, r), o.set(e, [...r.dependencies]);
	}
	for (let e of c) if (!l.has(e)) {
		for (let r of o.get(e) ?? []) if (!(u.has(r) || Object.hasOwn(t, r))) {
			n("local.computation.unknown", `Reference to undeclared parameter ${r} in computation "${e}".`, $(s.get(e), a.get(e), r)), l.add(e);
			break;
		}
	}
	let d = /* @__PURE__ */ new Set();
	for (let e of c) {
		if (l.has(e)) continue;
		let i = s.get(e);
		if (i.kind === "const") for (let c of o.get(e) ?? []) {
			let o = u.has(c) ? s.get(c).kind : null;
			Object.hasOwn(t, c) ? (n("local.computation.const", `Constant "${e}" cannot depend on ${r.has(c) ? "external data" : "control parameter"} "${c}".`, $(i, a.get(e), c)), d.add(e)) : o === "computed" && (n("local.computation.const", `Constant "${e}" cannot depend on computed value "${c}".`, $(i, a.get(e), c)), d.add(e));
		}
	}
	let { order: f, cyclic: h } = Et(c, (e) => o.get(e) ?? []);
	if (h.length > 0) {
		let e = new Set(h), t = [], r = /* @__PURE__ */ new Map(), i = h[0];
		for (; !r.has(i);) {
			r.set(i, t.length), t.push(i);
			let n = (o.get(i) ?? []).find((t) => e.has(t));
			if (n === void 0) break;
			i = n;
		}
		let a = r.has(i) ? t.slice(r.get(i)) : [h[0]], c = a.slice(0, 12).join(" → ") + (a.length > 12 ? " → …" : ` → ${a[0]}`);
		for (let e of a.slice(0, 100)) {
			let t = s.get(e);
			n("local.computation.cycle", `Computation "${e}" is part of a dependency cycle: ${c}.`, t.range.start, t.range.end);
		}
		for (let e of h) l.add(e);
	}
	for (let e of f) if (!l.has(e) && !(s.get(e).kind !== "const" || d.has(e)) && (o.get(e) ?? []).some((e) => u.has(e) ? s.get(e).kind === "const" && d.has(e) : !1)) {
		let t = s.get(e);
		n("local.computation.const", `Constant "${e}" indirectly depends on a value that is not a constant.`, t.expressionOffset), d.add(e);
	}
	let g = {}, _ = { ...t };
	for (let e of f) {
		if (l.has(e)) continue;
		let t = s.get(e);
		if ((o.get(e) ?? []).some((e) => l.has(e))) {
			l.add(e);
			continue;
		}
		let r = a.get(e);
		try {
			let t = i ? i.infer(r, _) : r.inferType(_);
			g[e] = t, _[e] = t;
		} catch (r) {
			wt(n, r, t.expressionOffset), l.add(e);
		}
	}
	let v = {}, y = {}, b = /* @__PURE__ */ Error("failed constant read"), x = (e) => {
		l.add(e), Object.defineProperty(y, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw b;
			}
		});
	};
	for (let e of f) {
		if (l.has(e) || s.get(e).kind !== "const" || d.has(e)) continue;
		let t = s.get(e), r = a.get(e);
		try {
			let i = r.evaluate(y), a = p(i);
			if (a) {
				n("local.computation.budget", `Constant "${e}": ${a}`, t.expressionOffset), x(e);
				continue;
			}
			v[e] = Array.isArray(i) ? i.slice() : i, y[e] = v[e];
		} catch (r) {
			if (r === b) {
				x(e);
				continue;
			}
			let i = Tt(r);
			n("local.computation.expression", `Constant "${e}" cannot be evaluated: ${i.message}`, t.expressionOffset + (Number.isFinite(i.offset) ? i.offset : 0)), x(e);
		}
	}
	let S = {};
	for (let e of c) {
		let t = s.get(e);
		if (l.has(e) || g[e] === void 0) continue;
		let n = {
			name: e,
			kind: t.kind,
			source: t.source,
			dependencies: [...o.get(e) ?? []],
			type: g[e],
			nodeId: t.nodeId,
			range: { ...t.range }
		};
		t.kind === "const" && Object.hasOwn(v, e) && (n.value = v[e]), S[e] = n;
	}
	return {
		computations: S,
		kinds: g,
		order: f.filter((e) => !l.has(e)),
		expressions: a,
		constValues: v
	};
}
function kt(e, t, n, r, i, a = /* @__PURE__ */ new Map()) {
	let o = {}, s = /* @__PURE__ */ new Map(), c = {};
	for (let [e, t] of Object.entries(r)) c[e] = t;
	for (let [e, t] of a) Object.defineProperty(c, e, {
		enumerable: !0,
		configurable: !0,
		get() {
			throw t;
		}
	});
	for (let [e, t] of Object.entries(i)) o[e] = t, c[e] = t;
	for (let r of t) {
		let t = e[r];
		if (!t || t.kind === "const") continue;
		let i = n.get(r);
		if (i) try {
			let e = i.evaluate(c), t = p(e);
			if (t) throw new d("expression-budget", t, 0);
			o[r] = e, c[r] = e;
		} catch (e) {
			let t = Tt(e);
			s.set(r, t), Object.defineProperty(c, r, {
				enumerable: !0,
				configurable: !0,
				get() {
					throw t;
				}
			});
		}
	}
	return {
		values: o,
		errors: s
	};
}
// src/local/evaluation/validation.ts
var At = "local.validation.failed", jt = "local.validation.expression", Mt = "Validation failed.";
function Nt(e) {
	return e.length > 2e3 ? `${u(e, c - 1)}…` : e;
}
function Pt(e) {
	let t = e.trim();
	return t ? t.split(/\s+/) : [];
}
function Ft(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function It(e) {
	if (!e || typeof e != "object") return !1;
	let t = e, n = t.range;
	return typeof t.expression == "string" && typeof t.message == "string" && Array.isArray(t.fields) && !!n && Number.isFinite(n.start) && Number.isFinite(n.end);
}
function Lt(e, t, n, r, i) {
	let a = e.length, o = Math.max(0, Math.min(a, Math.trunc(n.start))), s = Math.max(o + 1, Math.min(a, Math.trunc(n.end))), c = 0, l = Math.max(0, t.length - 1);
	for (; c < l;) {
		let e = Math.ceil((c + l) / 2);
		t[e] <= o ? c = e : l = e - 1;
	}
	return {
		code: r,
		message: i,
		severity: "error",
		range: {
			start: o,
			end: s
		},
		line: c + 1,
		column: o - t[c] + 1
	};
}
export { k as $, R as A, De as B, Be as C, Ue as D, We as E, Ne as F, j as G, ke as H, L as I, P as J, M as K, Me as L, z as M, Fe as N, Ke as O, Pe as P, be as Q, Te as R, Re as S, Je as T, Ae as U, Oe as V, je as W, we as X, F as Y, xe as Z, vt as _, It as a, K as b, Lt as c, Ot as d, ge as et, St as f, nt as g, yt as h, Nt as i, Le as j, qe as k, kt as l, Ct as m, At as n, Ft as o, bt as p, N as q, Mt as r, Pt as s, jt as t, me as tt, Dt as u, _t as v, ze as w, tt as x, gt as y, Ee as z };
