import { n as e } from "./sdk-core-PbZXOq_H.js";
import { a as t } from "./LocalDocumentView-CTN_HiBg.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
