import { c as e, n as t } from "./version-DAxuGOG2.js";
import { c as n, m as r, n as i, u as a } from "./document-theme-C8J6UyNO.js";
import { t as o } from "./types-daDo2c_w.js";
import { i as s } from "./identity-BUx0Q_-d.js";
var c = {
	name: "reactive-md",
	version: "0.9.2",
	description: "Author interactive local documents in Markdown, with expression-bound inputs, charts and diagrams.",
	keywords: [
		"markdown",
		"interactive",
		"local-first",
		"reactive",
		"charts",
		"diagrams",
		"react",
		"typescript"
	],
	license: "MIT",
	repository: {
		type: "git",
		url: "git+https://github.com/yao1145/ReactiveMD.git"
	},
	homepage: "https://github.com/yao1145/ReactiveMD#readme",
	bugs: { url: "https://github.com/yao1145/ReactiveMD/issues" },
	engines: { node: ">=22.12.0" },
	type: "module",
	files: [
		"dist-library",
		"dist-standalone",
		"bin",
		"cli",
		"README.md",
		"README-en.md",
		"README-ch.md",
		"CONTRIBUTING.md",
		"CONTRIBUTING-ch.md",
		"CHANGELOG.md",
		"CHANGELOG-ch.md",
		"SECURITY.md",
		"SECURITY-ch.md",
		"THIRD_PARTY_NOTICES.md",
		"docs",
		"examples"
	],
	bin: { "reactive-md": "./bin/reactive-md.mjs" },
	sideEffects: ["**/*.css"],
	scripts: {
		"dev:lib": "vite build --config vite.lib.config.ts --watch",
		build: "npm run typecheck && npm run build:lib",
		"build:lib": "vite build --config vite.lib.config.ts && vite build --config vite.minimal.config.ts && vite build --config vite.build.config.ts && npm run build:standalone && tsc -p tsconfig.lib.json && node scripts/finalize-declarations.mjs",
		"build:standalone": "vite build --config vite.standalone.config.ts",
		typecheck: "tsc --noEmit",
		test: "vitest run --config vitest.config.ts --maxWorkers=4",
		check: "npm run check:styles && npm run build && npm test && npm run test:boundary && npm run test:compiler-entry && npm run check:versions",
		"check:styles": "node scripts/verify-style-boundaries.mjs",
		"test:theme:browser": "node scripts/verify-shared-theme-browser.mjs",
		"test:capabilities:browser": "node scripts/verify-document-capabilities.mjs",
		"test:streaming:browser": "node scripts/verify-streaming-browser.mjs",
		"test:boundary": "node scripts/verify-public-package.mjs",
		"test:compiler-entry": "node scripts/verify-compiler-entry.mjs",
		"test:pdf": "node scripts/verify-pdf.mjs",
		"test:preset-scaffold": "node scripts/verify-preset-scaffold.mjs",
		"check:versions": "node scripts/check-versions.mjs",
		"check:loc": "node scripts/check-loc.mjs",
		"compatibility:verify": "node scripts/verify-compatibility-manifest.mjs --require-workspace",
		"support:verify": "node scripts/verify-support-matrix.mjs",
		"bench:streaming": "node benchmarks/streaming-source.mjs",
		"sci-fi:dev": "vite --config examples/sci-fi-theme/vite.config.ts",
		"sci-fi:build": "vite build --config examples/sci-fi-theme/vite.config.ts",
		"sci-fi:typecheck": "tsc -p examples/sci-fi-theme/tsconfig.json --noEmit",
		"sci-fi:test": "vitest run tests/sci-fi-theme.test.ts --maxWorkers=1",
		"sci-fi:screenshot": "node examples/sci-fi-theme/scripts/screenshot.mjs",
		notices: "node scripts/generate-notices.mjs",
		prepack: "npm run build && npm run notices"
	},
	exports: {
		"./vite": {
			types: "./dist-library/types/vite/index.d.ts",
			import: "./dist-library/reactive-md-vite.js"
		},
		"./vite/client": { types: "./dist-library/types/vite/client.d.ts" },
		"./build": {
			types: "./dist-library/types/build/index.d.ts",
			import: "./dist-library/reactive-md-build.js"
		},
		"./compiler": {
			types: "./dist-library/types/compiler/index.d.ts",
			import: "./dist-library/reactive-md-compiler.js"
		},
		"./compiler/standard": {
			types: "./dist-library/types/compiler/standard.d.ts",
			import: "./dist-library/reactive-md-compiler-standard.js"
		},
		"./testing": {
			types: "./dist-library/types/testing/index.d.ts",
			import: "./dist-library/reactive-md-testing.js"
		},
		"./testing/react": {
			types: "./dist-library/types/testing/react.d.ts",
			import: "./dist-library/reactive-md-testing-react.js"
		},
		"./testing/browser": {
			types: "./dist-library/types/testing/browser.d.ts",
			import: "./dist-library/reactive-md-testing-browser.js"
		},
		"./sdk": {
			types: "./dist-library/types/sdk/index.d.ts",
			import: "./dist-library/reactive-md-sdk.js"
		},
		"./presets/default": {
			types: "./dist-library/types/presets/default.d.ts",
			import: "./dist-library/reactive-md-default-preset.js"
		},
		"./presets/default/packs": {
			types: "./dist-library/types/presets/packs.d.ts",
			import: "./dist-library/reactive-md-default-packs.js"
		},
		"./presets/minimal": {
			types: "./dist-library/types/presets/minimal.d.ts",
			import: "./dist-library/reactive-md-minimal-preset.js"
		},
		"./presets/minimal/react": {
			types: "./dist-library/types/components/minimal-preset.d.ts",
			import: "./dist-library/reactive-md-minimal-react-preset.js"
		},
		"./plugins/forms": {
			types: "./dist-library/types/components/plugins/forms.d.ts",
			import: "./dist-library/reactive-md-plugin-forms.js"
		},
		"./plugins/network": {
			types: "./dist-library/types/components/plugins/network.d.ts",
			import: "./dist-library/reactive-md-plugin-network.js"
		},
		"./plugins/navigation": {
			types: "./dist-library/types/components/plugins/navigation.d.ts",
			import: "./dist-library/reactive-md-plugin-navigation.js"
		},
		"./plugins/data": {
			types: "./dist-library/types/components/plugins/data.d.ts",
			import: "./dist-library/reactive-md-plugin-data.js"
		},
		"./plugins/chart": {
			types: "./dist-library/types/components/plugins/chart.d.ts",
			import: "./dist-library/reactive-md-plugin-chart.js"
		},
		"./plugins/plot": {
			types: "./dist-library/types/components/plugins/plot.d.ts",
			import: "./dist-library/reactive-md-plugin-plot.js"
		},
		"./plugins/diagram": {
			types: "./dist-library/types/components/plugins/diagram.d.ts",
			import: "./dist-library/reactive-md-plugin-diagram.js"
		},
		"./plugins/gallery": {
			types: "./dist-library/types/components/plugins/gallery.d.ts",
			import: "./dist-library/reactive-md-plugin-gallery.js"
		},
		"./pdf": {
			types: "./dist-library/types/pdf.d.ts",
			import: "./dist-library/reactive-md-pdf.js"
		},
		"./export": {
			types: "./dist-library/types/export/index.d.ts",
			import: "./dist-library/reactive-md-export.js"
		},
		"./export-assets": {
			types: "./dist-library/types/export-assets/index.d.ts",
			import: "./dist-library/reactive-md-export-assets.js"
		},
		"./standalone": {
			types: "./dist-library/types/standalone/library.d.ts",
			import: "./dist-library/reactive-md-standalone-host.js"
		},
		"./standalone/host": {
			types: "./dist-library/types/standalone/host.d.ts",
			import: "./dist-library/reactive-md-standalone-configured.js"
		},
		"./react/server": {
			types: "./dist-library/types/react/server.d.ts",
			import: "./dist-library/reactive-md-react-server.js"
		},
		".": {
			types: "./dist-library/types/index.d.ts",
			import: "./dist-library/reactive-md.js"
		},
		"./react": {
			types: "./dist-library/types/react/index.d.ts",
			import: "./dist-library/reactive-md-react.js"
		},
		"./react/runtime": {
			types: "./dist-library/types/react/runtime/index.d.ts",
			import: "./dist-library/reactive-md-react-runtime.js"
		},
		"./react/minimal": {
			types: "./dist-library/types/react/minimal.d.ts",
			import: "./dist-library/reactive-md-react-minimal.js"
		},
		"./runtime": {
			types: "./dist-library/types/runtime-services/index.d.ts",
			import: "./dist-library/reactive-md-runtime.js"
		},
		"./runtime/browser": {
			types: "./dist-library/types/runtime-services/browser/index.d.ts",
			import: "./dist-library/reactive-md-runtime-browser.js"
		},
		"./observability": {
			types: "./dist-library/types/observability.d.ts",
			import: "./dist-library/reactive-md-observability.js"
		},
		"./styles.css": "./dist-library/reactive-md.css",
		"./styles/minimal.css": "./dist-library/reactive-md-minimal.css",
		"./react/unstyled": {
			types: "./dist-library/types/react/index.d.ts",
			import: "./dist-library/reactive-md-react-unstyled.js"
		},
		"./screen.css": "./dist-library/reactive-md.css",
		"./print.css": "./dist-library/reactive-md-print.css",
		"./authoring": {
			types: "./dist-library/types/authoring/index.d.ts",
			import: "./dist-library/reactive-md-authoring.js"
		},
		"./package.json": "./package.json",
		"./notices": "./THIRD_PARTY_NOTICES.md",
		"./assets/standalone.js": "./dist-standalone/reactive-md-standalone.js"
	},
	peerDependencies: {
		react: "^19.0.0",
		"react-dom": "^19.0.0",
		vite: "^8.0.0"
	},
	peerDependenciesMeta: {
		vite: { optional: !0 },
		react: { optional: !0 },
		"react-dom": { optional: !0 }
	},
	devDependencies: {
		"@jitl/quickjs-singlefile-browser-release-sync": "0.32.0",
		"@lezer/common": "1.5.4",
		"@lezer/highlight": "1.2.5",
		"@lezer/markdown": "1.8.1",
		"@playwright/test": "1.64.1",
		"@radix-ui/react-select": "2.4.1",
		"@types/node": "26.6.5",
		"@types/react": "19.3.0",
		"@types/react-dom": "19.3.0",
		"@vitejs/plugin-react": "6.1.2",
		elkjs: "0.12.0",
		"highlight.js": "11.11.2",
		katex: "0.19.1",
		lowlight: "3.3.0",
		"lucide-react": "1.72.0",
		mafs: "0.21.0",
		motion: "14.12.0",
		parse5: "8.0.1",
		postcss: "8.5.31",
		"quickjs-emscripten-core": "0.32.0",
		react: "19.3.1",
		"react-dom": "19.3.1",
		"remark-gfm": "4.0.1",
		"remark-parse": "11.0.0",
		typescript: "7.0.2",
		unified: "11.0.5",
		vite: "8.3.5",
		vitest: "5.0.5"
	}
}, l = /* @__PURE__ */ new Set(/* @__PURE__ */ "local.build.budget,local.build.config,local.build.config-key,local.build.host,local.build.host-import,local.build.notice-budget,local.build.notice-conflict,local.build.notice-invalid,local.build.resource-budget,local.build.resource-conflict,local.build.resource-cycle,local.build.resource-invalid,local.build.resource-missing,local.build.resource-remote,local.build.resource-traversal,local.build.resource-unsupported,local.build.resource-unresolved,local.build.script,local.build.theme,local.build.vite,local.extension.binding,local.extension.bundle-assembly,local.extension.bundle-integrity,local.extension.bundle-mismatch,local.extension.bundle-missing,local.extension.bundle-theme,local.extension.config,local.extension.config-mismatch,local.extension.contract,local.extension.contract-metadata,local.extension.event,local.extension.export-capability,local.extension.render,local.extension.renderer-missing,local.extension.requirements,local.extension.resource-budget,local.extension.resource-conflict,local.extension.resource-invalid,local.extension.resource-missing,local.extension.restore-assembly,local.extension.restore-capability,local.extension.restore-component-missing,local.extension.restore-config,local.extension.restore-contract,local.extension.restore-metadata,local.extension.restore-resource-digest,local.extension.restore-resource-missing,local.extension.restore-sdk,local.extension.restore-source,local.extension.restore-theme,local.extension.restore-version,local.extension.ssr-render,local.extension.theme-missing,local.extension.write".split(","));
function u(e) {
	return l.has(e);
}
// src/local/observability.ts
function d(e, t = {}) {
	return {
		code: e,
		phase: e.startsWith("local.worker.") ? "worker" : e.startsWith("local.export.") ? "export" : "resource",
		severity: e === "local.worker.stale-response" ? "warning" : "error",
		recoverable: !0,
		messageKey: e,
		message: r(e, "en", t),
		details: t,
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
var f = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/, p = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/, m = /^[A-Za-z0-9][A-Za-z0-9._+/@-]{0,63}$/, h = /* @__PURE__ */ new Set([
	"budget",
	"limit",
	"actual",
	"unit",
	"timeoutMs",
	"requestId",
	"sourceRevision",
	"currentRevision",
	"stage",
	"format",
	"mode"
]), g = /* @__PURE__ */ new Set([
	"bytes",
	"nodes",
	"files",
	"depth",
	"steps",
	"work",
	"codeUnits"
]), _ = /* @__PURE__ */ new Set([
	"compile",
	"assets",
	"bundle",
	"render",
	"download",
	"pdf"
]), v = /* @__PURE__ */ new Set([
	"compile-start",
	"compile-end",
	"worker-request",
	"worker-response",
	"worker-timeout",
	"worker-stale-response",
	"worker-cancel",
	"worker-error",
	"export-start",
	"export-end",
	"export-cancel",
	"export-error"
]);
function y(e) {
	if (!e) return;
	let t = {};
	for (let [n, r] of Object.entries(e)) if (h.has(n) && ((typeof r == "number" && Number.isSafeInteger(r) && r >= 0 || n === "unit" && typeof r == "string" && g.has(r) || n === "stage" && typeof r == "string" && _.has(r) || n === "budget" && typeof r == "string" && f.test(r) || n === "format" && (r === "html" || r === "pdf") || n === "mode" && (r === "interactive" || r === "static")) && (t[n] = r), Object.keys(t).length >= 12)) break;
	return Object.keys(t).length ? t : void 0;
}
function b(e) {
	if (!e || !p.test(e.traceId) || !v.has(e.type) || !Number.isSafeInteger(e.timestamp) || e.timestamp < 0) return;
	let t = typeof e.code == "string" && f.test(e.code) ? e.code : void 0, n = typeof e.stage == "string" && _.has(e.stage) ? e.stage : void 0, r = typeof e.status == "string" && /^(?:ok|failed|stale|timeout|disposed|fallback|retry|cancelled|printed)$/.test(e.status) ? e.status : void 0;
	return {
		type: e.type,
		traceId: e.traceId.slice(0, 96),
		...Number.isSafeInteger(e.requestId) && (e.requestId ?? -1) >= 0 ? { requestId: e.requestId } : {},
		...Number.isSafeInteger(e.sourceRevision) && (e.sourceRevision ?? -1) >= 0 ? { sourceRevision: e.sourceRevision } : {},
		timestamp: e.timestamp,
		...Number.isSafeInteger(e.durationMs) && (e.durationMs ?? -1) >= 0 ? { durationMs: e.durationMs } : {},
		...t ? { code: t } : {},
		...r ? { status: r } : {},
		...n ? { stage: n } : {}
	};
}
function x(r, l = {}) {
	if (typeof r != "string") throw TypeError("Diagnostic reports require a source string.");
	let d = typeof self < "u" && typeof self.importScripts == "function" ? "worker" : typeof window < "u" ? "browser" : "node", f = globalThis.process, h = { runtime: d };
	d === "node" ? (f?.versions?.node && (h.node = f.versions.node.slice(0, 64)), f?.platform && (h.platform = f.platform.slice(0, 64))) : typeof navigator < "u" && (h.userAgent = navigator.userAgent.slice(0, 512), h.platform = navigator.platform.slice(0, 64));
	let g = Object.fromEntries(Object.entries(l.package ?? {}).filter(([e, t]) => [
		"editor",
		"react",
		"vite"
	].includes(e) && typeof t == "string" && m.test(t))), _ = (Array.isArray(l.diagnostics) ? l.diagnostics : []).slice(0, 100).flatMap((e) => {
		if (!e || !(n(e.code) || u(e.code)) || ![
			"info",
			"warning",
			"error",
			"fatal"
		].includes(e.severity) || !e.range || !Number.isSafeInteger(e.range.start) || !Number.isSafeInteger(e.range.end)) return [];
		let t = Math.max(0, Math.min(r.length, e.range.start)), i = Math.max(t, Math.min(r.length, e.range.end)), o = Number.isSafeInteger(e.line) && e.line > 0 ? e.line : void 0, s = Number.isSafeInteger(e.column) && e.column > 0 ? e.column : void 0, c = y(e.details), l = e.phase && [
			"source",
			"parse",
			"semantic",
			"runtime",
			"worker",
			"resource",
			"export",
			"host"
		].includes(e.phase) ? e.phase : void 0;
		return [{
			code: e.code,
			severity: e.severity,
			...l ? { phase: l } : {},
			...typeof e.recoverable == "boolean" ? { recoverable: e.recoverable } : {},
			range: {
				start: t,
				end: i
			},
			...o === void 0 ? {} : { line: o },
			...s === void 0 ? {} : { column: s },
			...typeof e.messageKey == "string" && a(e.messageKey) !== void 0 ? { messageKey: e.messageKey } : {},
			...c ? { details: c } : {}
		}];
	}), v = l.traceId && p.test(l.traceId) ? l.traceId : void 0, x = typeof l.sourceRevision == "string" && p.test(l.sourceRevision) ? l.sourceRevision : void 0, S = (Array.isArray(l.events) ? l.events : []).slice(-50).flatMap((e) => {
		let t = b({
			...e,
			type: e?.type?.slice(0, 64),
			traceId: e?.traceId?.slice(0, 96),
			status: e?.status?.slice(0, 32),
			stage: e?.stage?.slice(0, 32),
			code: e?.code?.slice(0, 128)
		});
		return t ? [t] : [];
	}), C = {
		schema: "reactive-md-diagnostic/v1",
		generatedAt: (/* @__PURE__ */ new Date()).toISOString(),
		...v ? { traceId: v } : {},
		package: {
			engine: c.version,
			sdk: e,
			syntax: o,
			component: t,
			theme: i,
			...g
		},
		environment: h,
		document: {
			sourceBytes: new TextEncoder().encode(r).byteLength,
			sourceDigest: s(r),
			...x ? { sourceRevision: x } : {}
		},
		diagnostics: _,
		...S.length ? { events: S } : {}
	};
	for (; new TextEncoder().encode(JSON.stringify(C)).byteLength > 65536;) if (C.events?.length) C.events = C.events.slice(1);
	else if (C.diagnostics.length) C.diagnostics = C.diagnostics.slice(0, -1);
	else throw RangeError("The diagnostic report exceeded its size limit.");
	return C;
}
export { d as n, x as t };
