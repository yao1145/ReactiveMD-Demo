import { o as e } from "./latex-1w7aQgD5.js";
import { o as t } from "./compile-Dx6Uw3D9.js";
import { j as n } from "./validation-B3RI0xOk.js";
import { C as r } from "./config-validation-D3D7Dy2J.js";
import { r as i } from "./options-BBp9IcHm.js";
import { t as a } from "./compiler-dxLPB9Ym.js";
import { c as o } from "./schema-BryM_VRW.js";
// src/local/source/authoring-syntax.ts
var s = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/;
function c(e, t) {
	if (e[t] !== "<") return null;
	let n = s.exec(e.slice(t));
	if (!n) return null;
	let r = !!n[1], i = n[2], a = t + (r ? 2 : 1), o = "", c = t + n[0].length;
	for (; c < e.length; c += 1) {
		let t = e[c];
		if (o) t === o && (o = "");
		else if (t === "\"" || t === "'") o = t;
		else if (t === ">") break;
	}
	if (c >= e.length) return null;
	let l = c, u = c + 1;
	if (r) return {
		start: t,
		end: u,
		contentEnd: l,
		name: i,
		nameRange: {
			start: a,
			end: a + i.length
		},
		closing: !0,
		selfClosing: !1,
		attrs: []
	};
	let d = [], f = a + i.length;
	for (; f < l;) {
		for (; f < l && h(e[f]);) f += 1;
		if (f >= l) break;
		if (e[f] === "/") {
			f += 1;
			continue;
		}
		let t = /^[A-Za-z][A-Za-z0-9_-]*/.exec(e.slice(f, l));
		if (!t) {
			f += 1;
			continue;
		}
		let n = f, r = t[0];
		f += r.length;
		let i = f, a = f;
		for (; a < l && h(e[a]);) a += 1;
		if (e[a] !== "=") {
			d.push({
				name: r,
				nameRange: {
					start: n,
					end: n + r.length
				}
			}), f = i;
			continue;
		}
		for (f = a + 1; f < l && h(e[f]);) f += 1;
		let o = e[f];
		if (o === "\"" || o === "'") {
			let t = f, i = f + 1, a = e.indexOf(o, i);
			if (a < 0 || a > l) {
				d.push({
					name: r,
					nameRange: {
						start: n,
						end: n + r.length
					},
					valueRange: {
						start: i,
						end: l
					},
					quoteStart: t,
					quoteEnd: l
				}), f = l;
				continue;
			}
			d.push({
				name: r,
				nameRange: {
					start: n,
					end: n + r.length
				},
				valueRange: {
					start: i,
					end: a
				},
				quoteStart: t,
				quoteEnd: a
			}), f = a + 1;
			continue;
		}
		let s = f;
		for (; f < l && !h(e[f]);) f += 1;
		d.push({
			name: r,
			nameRange: {
				start: n,
				end: n + r.length
			},
			valueRange: {
				start: s,
				end: f
			},
			unquoted: !0
		});
	}
	return {
		start: t,
		end: u,
		contentEnd: l,
		name: i,
		nameRange: {
			start: a,
			end: a + i.length
		},
		closing: !1,
		selfClosing: /\/\s*$/.test(e.slice(a + i.length, l)),
		attrs: d
	};
}
function l(e, t, i) {
	if (t.range.end <= i) return null;
	let a = e.lastIndexOf("</", t.range.end - 1);
	if (a < i) return null;
	let o = c(e, a);
	return !o || !o.closing || o.end > t.range.end || o.name !== t.name && (!r.has(o.name.toLowerCase()) && !n.has(o.name.toLowerCase()) || o.name.toLowerCase() !== t.name?.toLowerCase()) ? null : o;
}
function u(e, t, n) {
	let r = [];
	for (let i = t; i < n;) {
		if (e[i] === "\\" && e.startsWith("{{", i + 1)) {
			i += 3;
			continue;
		}
		if (!e.startsWith("{{", i)) {
			i += 1;
			continue;
		}
		let t = "", a = i + 2;
		for (; a < n - 1; a += 1) {
			let n = e[a];
			if (t) n === "\\" ? a += 1 : n === t && (t = "");
			else if (n === "\"" || n === "'") t = n;
			else if (n === "}" && e[a + 1] === "}") break;
		}
		if (a >= n - 1) break;
		r.push({
			start: i,
			end: a + 2,
			innerStart: i + 2,
			innerEnd: a
		}), i = a + 2;
	}
	return r;
}
function d(e, t) {
	let n = {
		quot: "\"",
		apos: "'",
		amp: "&",
		lt: "<",
		gt: ">"
	}, r = [t.start], i = "";
	for (let a = t.start; a < t.end;) {
		let o = e[a] === "&" ? /^&(quot|apos|amp|lt|gt);/.exec(e.slice(a, t.end)) : null;
		i += o ? n[o[1]] : e[a], a += o ? o[0].length : 1, r.push(a);
	}
	return {
		text: i,
		offsets: r
	};
}
function f(e, n, r) {
	let i = [];
	for (let a = n; a < r;) {
		let n = e[a];
		if (n === "\"" || n === "'") {
			let t = n;
			for (a += 1; a < r;) if (e[a] === "\\") a += 2;
			else {
				if (e[a] === t) {
					a += 1;
					break;
				}
				a += 1;
			}
		} else {
			if (/[0-9]/.test(n) || n === "." && e[a + 1] !== void 0 && /[0-9]/.test(e[a + 1])) {
				let t = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/.exec(e.slice(a, r));
				if (t) {
					a += t[0].length;
					continue;
				}
			}
			if (p(n)) {
				let n = a;
				for (a += 1; a < r && m(e[a]);) a += 1;
				let o = e.slice(n, a), s = a;
				for (; s < r && h(e[s]);) s += 1;
				if (e[s] === "(" || o === "true" || o === "false" || o === "null" || o === "pi" || o === "e" || t.has(o)) continue;
				i.push({
					name: o,
					range: {
						start: n,
						end: a
					}
				});
			} else a += 1;
		}
	}
	return i;
}
function p(e) {
	return e !== void 0 && /[A-Za-z_]/.test(e);
}
function m(e) {
	return e !== void 0 && /[A-Za-z0-9_]/.test(e);
}
function h(e) {
	return e !== void 0 && /\s/.test(e);
}
// src/local/source/authoring.ts
var g = /^[A-Za-z_][A-Za-z0-9_]*$/, _ = 128, v = /* @__PURE__ */ new Set([
	"code",
	"inlineCode",
	"math",
	"inlineMath",
	"fallback",
	"comment",
	"footnoteDefinition",
	"authorCss",
	"authorJavaScript",
	"extendedHtmlRaw"
]), y = /* @__PURE__ */ new Set([
	"local.version.unsupported",
	"local.version.malformed",
	"local.version.duplicate",
	"local.version.placement",
	"local.parse",
	"local.interpolation",
	"local.tag.unclosed",
	"local.tag.mismatch",
	"local.tag.closing",
	"local.tag.shape",
	"local.attribute",
	"local.budget"
]);
function b(e) {
	return e.length > 0 && e.length <= _ && g.test(e) && !t.has(e);
}
function x(e) {
	return {
		start: e.start,
		end: e.end
	};
}
function S(e, t) {
	try {
		return a(e, t).diagnostics;
	} catch {
		return [];
	}
}
function C(e) {
	return i(e).ok;
}
function w(e) {
	let t = i(e);
	return t.ok ? [...t.schemaByName.values()] : [];
}
function T(e, t) {
	return Object.values(e.bindings ?? {}).some((e) => e.bind === t);
}
function E(e, t = []) {
	for (let n of e) v.has(n.type) && t.push(x(n.range)), n.type !== "fallback" && n.children && E(n.children, t);
	return t;
}
function D(e, t) {
	let n = E(t), r = (t) => {
		for (let i of t) {
			if (i.type === "component" || i.type === "hostComponent") {
				let t = c(e, i.range.start);
				t && n.push({
					start: t.start,
					end: t.end
				});
			}
			i.type !== "fallback" && i.children && r(i.children);
		}
	};
	r(t), n.sort((e, t) => e.start - t.start || t.end - e.end);
	let i = [], a = 0, o = 0;
	for (; a < e.length;) {
		let t = e.indexOf("<!--", a);
		if (t < 0) break;
		for (; o < n.length && n[o].end <= t;) o++;
		let r = n[o];
		if (r && r.start <= t) {
			a = r.end;
			continue;
		}
		let s = e.indexOf("-->", t + 4), c = s < 0 ? e.length : s + 3;
		i.push({
			start: t,
			end: c
		}), a = c;
	}
	return i;
}
function O(e, t) {
	return t.find((t) => t.name === e)?.props;
}
function k(t, i, a, o) {
	let s = [];
	o?.themeRange && s.push({
		type: "component",
		name: "theme",
		id: "author-theme",
		range: o.themeRange
	});
	for (let e of Object.values(o?.computations ?? {})) s.push({
		type: "component",
		name: e.kind,
		id: e.nodeId,
		range: e.range
	});
	let p = s.length ? i.concat(s) : i, m = /* @__PURE__ */ new Set(), h = [], g = /* @__PURE__ */ new Map(), _ = [], y = [], S = (e, n) => {
		for (let r of f(t, e, n)) _.push(r);
	}, C = (e, t) => {
		let n = g.get(e);
		n ? n.push(x(t)) : g.set(e, [x(t)]);
	}, w = (e, n) => {
		if (m.has(e.range.start)) return;
		let r = c(t, e.range.start);
		if (!r || r.closing) return;
		m.add(e.range.start), h.push({
			kind: "tag",
			range: x(r.nameRange)
		});
		let i = a.find((t) => t.name === e.name);
		for (let n of r.attrs) {
			if (h.push({
				kind: "attribute",
				range: x(n.nameRange)
			}), !n.valueRange) continue;
			let o = O(e.name ?? "", a)?.[n.name], s = i !== void 0 && T(i, n.name) && Object.values(i.bindings ?? {}).some((e) => e.bind === n.name && (e.requiresAttributes ?? []).every((e) => r.attrs.some((t) => t.name === e))), c = (e.name === "computed" || e.name === "const" || e.name === "external") && n.name === "name", l = t.slice(n.valueRange.start, n.valueRange.end), p = d(t, n.valueRange);
			if (i?.rules?.some((e) => e.kind === "validation-rule" && e.fields === n.name)) {
				for (let e of p.text.matchAll(/\S+/g)) {
					if (!b(e[0])) continue;
					let t = {
						start: p.offsets[e.index],
						end: p.offsets[e.index + e[0].length]
					};
					_.push({
						name: e[0],
						range: t
					}), h.push({
						kind: "binding",
						range: t
					});
				}
				continue;
			}
			let m = o && !o.static ? u(p.text, 0, p.text.length) : [];
			if (m.length > 0) {
				let e = 0;
				for (let t of m) {
					t.start > e && h.push({
						kind: "string",
						range: {
							start: p.offsets[e],
							end: p.offsets[t.start]
						}
					}), h.push({
						kind: "expression",
						range: {
							start: p.offsets[t.start],
							end: p.offsets[t.end]
						}
					});
					for (let e of f(p.text, t.innerStart, t.innerEnd)) (!i?.rules?.some((e) => e.kind === "scoped-expressions" && e.scope === "row" && e.attributes.includes(n.name) || e.kind === "row-values" && e.key === n.name) || e.name !== "item" && e.name !== "index") && _.push({
						name: e.name,
						range: {
							start: p.offsets[e.range.start],
							end: p.offsets[e.range.end]
						}
					});
					e = t.end;
				}
				e < p.text.length && h.push({
					kind: "string",
					range: {
						start: p.offsets[e],
						end: n.valueRange.end
					}
				});
			} else (s || c) && b(l) ? (h.push({
				kind: "binding",
				range: x(n.valueRange)
			}), C(l, n.valueRange)) : n.valueRange.end > n.valueRange.start && h.push({
				kind: "string",
				range: x(n.valueRange)
			});
		}
		let o = l(t, e, r.end);
		o && h.push({
			kind: "tag",
			range: x(o.nameRange)
		});
	}, E = (i, o) => {
		for (let s of i) {
			if ((s.type === "component" || s.type === "hostComponent") && s.name) w(s, o);
			else if (s.type === "interpolation") h.push({
				kind: "expression",
				range: x(s.range)
			}), S(s.range.start + 2, Math.max(s.range.start + 2, s.range.end - 2));
			else if (s.type === "math" || s.type === "inlineMath") {
				if (h.push({
					kind: "math",
					range: x(s.range)
				}), a.find((e) => e.name === o)?.rules?.some((e) => e.kind === "inline-math-reads") && s.type === "math") {
					let n = s.range.start + 2;
					try {
						for (let r of e(t.slice(n, s.range.end - 2))) {
							let e = {
								name: r.name,
								range: {
									start: n + r.range.start,
									end: n + r.range.end
								}
							};
							_.push(e), y.push(e);
						}
					} catch {}
				}
			} else s.type === "code" || s.type === "inlineCode" ? h.push({
				kind: "code",
				range: x(s.range)
			}) : s.type === "comment" && h.push({
				kind: "comment",
				range: x(s.range)
			});
			if (!v.has(s.type) && t[s.range.start] === "<" && !m.has(s.range.start)) {
				let e = c(t, s.range.start);
				e && !e.closing && (r.has(e.name.toLowerCase()) || n.has(e.name.toLowerCase())) && w({
					...s,
					name: e.name
				}, o);
			}
			s.type !== "fallback" && s.children && E(s.children, s.name);
		}
	};
	E(p);
	for (let e of D(t, p)) h.push({
		kind: "comment",
		range: e
	});
	h.sort((e, t) => e.range.start - t.range.start || e.range.end - t.range.end);
	let k = [];
	for (let e of h) {
		if (e.range.end <= e.range.start) continue;
		let t = k[k.length - 1];
		t && e.range.start < t.range.end || k.push(e);
	}
	let A = [];
	for (let [e, t] of g) {
		let n = [], r = /* @__PURE__ */ new Set();
		for (let t of _) {
			if (t.name !== e) continue;
			let i = `${t.range.start}:${t.range.end}`;
			r.has(i) || (r.add(i), n.push(x(t.range)));
		}
		n.sort((e, t) => e.start - t.start || e.end - t.end), t.sort((e, t) => e.start - t.start || e.end - t.end), A.push({
			name: e,
			declarations: t,
			references: n
		});
	}
	return A.sort((e, t) => e.declarations[0].start - t.declarations[0].start || e.name.localeCompare(t.name)), {
		tokens: k,
		bindings: A,
		mathReferences: y
	};
}
function A(e, t, n = {}) {
	if (typeof e != "string") return {
		tokens: [],
		bindings: [],
		diagnostics: []
	};
	if (!C(t)) return {
		tokens: [],
		bindings: [],
		diagnostics: n.diagnostics === !1 ? [] : S(e, t)
	};
	let r = n.document?.source === e ? n.document : o(e, t), i = k(e, r.nodes, w(t), r);
	return {
		tokens: i.tokens,
		bindings: i.bindings,
		diagnostics: n.diagnostics === !1 ? [] : S(e, t)
	};
}
function j(e, t, n) {
	let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)/.exec(e.slice(t, Math.min(e.length, n + 1)));
	if (!r) return null;
	let i = !!r[1], a = r[2], o = t + r[0].length, s = [], c = !1, l, u = !1;
	if (!i) {
		let t = o;
		for (; t < n;) {
			for (; t < n && h(e[t]);) t += 1;
			if (t >= n) break;
			if (e[t] === "/") {
				u = !0, t += 1;
				continue;
			}
			let r = /^[A-Za-z][A-Za-z0-9_-]*/.exec(e.slice(t, n));
			if (!r) {
				t += 1;
				continue;
			}
			let i = r[0], a = t;
			t += i.length;
			let o = t, d = t;
			for (; d < n && h(e[d]);) d += 1;
			if (e[d] !== "=") {
				s.push({
					name: i,
					nameStart: a,
					nameEnd: o,
					nameRange: {
						start: a,
						end: o
					}
				}), t = o;
				continue;
			}
			for (t = d + 1; t < n && h(e[t]);) t += 1;
			let f = e[t];
			if (f === "\"" || f === "'") {
				let r = t, u = t + 1, d = e.indexOf(f, u);
				if (d < 0 || d >= n) {
					let e = {
						name: i,
						nameStart: a,
						nameEnd: o,
						nameRange: {
							start: a,
							end: o
						},
						valueRange: {
							start: u,
							end: n
						},
						quoteStart: r,
						quoteEnd: d < 0 ? n : d
					};
					s.push(e), l = e, c = !0, t = n;
					break;
				}
				s.push({
					name: i,
					nameStart: a,
					nameEnd: o,
					nameRange: {
						start: a,
						end: o
					},
					valueRange: {
						start: u,
						end: d
					},
					quoteStart: r,
					quoteEnd: d
				}), t = d + 1;
				continue;
			}
			let p = t;
			for (; t < n && !h(e[t]);) t += 1;
			s.push({
				name: i,
				nameStart: a,
				nameEnd: o,
				nameRange: {
					start: a,
					end: o
				},
				valueRange: {
					start: p,
					end: t
				},
				unquoted: !0
			});
		}
	}
	let d = -1;
	if (!c) {
		let t = n;
		for (; t > o && /[A-Za-z0-9_-]/.test(e[t - 1]);) --t;
		t > o && h(e[t - 1]) && (d = t);
	}
	return {
		name: a,
		closing: i,
		selfClosing: u,
		inValue: c,
		currentAttribute: l,
		attrs: s,
		partialStart: d
	};
}
function M(e, t, n) {
	let r = [], i = (e) => {
		for (let t of e) t.type === "component" && r.push(t.range.start), t.type !== "fallback" && t.children && i(t.children);
	};
	i(n), r.sort((e, t) => e - t);
	for (let n = r.length - 1; n >= 0; --n) {
		let i = r[n];
		if (i >= t) continue;
		let a = c(e, i);
		if (a && t <= a.end) return i;
		if (a && a.end < t) break;
	}
	let a = t;
	for (; a > 0;) {
		let n = e.lastIndexOf("<", a - 1);
		if (n < 0) return -1;
		if (e[n - 1] === "\\") {
			a = n;
			continue;
		}
		let r = e[n + 1];
		if (r !== "/" && !p(r)) a = n;
		else if (N(e, n, t)) a = n;
		else return n;
	}
	return -1;
}
function N(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") return !0;
	}
	return !1;
}
function P(e, t) {
	let n = t;
	for (; n > 0;) {
		let r = e.lastIndexOf("{{", n - 1);
		if (r < 0) return null;
		if (e[r - 1] === "\\") {
			n = r;
			continue;
		}
		let i = "", a = r + 2, o = -1;
		for (; a < e.length - 1; a += 1) {
			let t = e[a];
			if (i) t === "\\" ? a += 1 : t === i && (i = "");
			else if (t === "\"" || t === "'") i = t;
			else if (t === "}" && e[a + 1] === "}") {
				o = a;
				break;
			}
		}
		if (o >= 0 && o + 2 <= t) n = r;
		else return {
			start: r,
			end: o < 0 ? e.length : o + 2,
			innerStart: r + 2,
			innerEnd: o < 0 ? e.length : o
		};
	}
	return null;
}
function F(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		r ? t === "\\" ? i += 1 : t === r && (r = "") : (t === "\"" || t === "'") && (r = t);
	}
	return r !== "";
}
function I(e, t) {
	let n = 0, r = e.length - 1;
	for (; n <= r;) {
		let i = n + r >> 1, a = e[i];
		if (t < a.start) r = i - 1;
		else if (t >= a.end) n = i + 1;
		else return !0;
	}
	return !1;
}
function L(e, t, n, r) {
	let i = e.slice(t, n), a = i && r.startsWith(i) ? r.slice(i.length) : "";
	return {
		start: t,
		end: a && e.startsWith(a, n) ? n + a.length : n
	};
}
function R(e, t, n, r) {
	if (F(e, n.innerStart, t)) return [];
	let i = t;
	for (; i > n.innerStart && m(e[i - 1]);) --i;
	if (e[i - 1] === ".") return [];
	let a = e.slice(i, t);
	return a && !p(a[0]) ? [] : r.filter((e) => e.name.startsWith(a)).map((n) => ({
		label: n.name,
		insertText: n.name,
		range: L(e, i, t, n.name),
		kind: "binding",
		detail: `${n.declarations.length} declaration${n.declarations.length === 1 ? "" : "s"}, ${n.references.length} reference${n.references.length === 1 ? "" : "s"}`
	}));
}
function z(e, t, n, r) {
	let i = n.currentAttribute;
	if (!i) return [];
	let a = O(n.name, r)?.[i.name];
	if (!a || a.kind !== "enum" || !a.values) return [];
	let o = i.valueRange?.start ?? t, s = e.slice(o, t);
	return a.values.filter((e) => e.startsWith(s)).map((n) => ({
		label: n,
		insertText: n,
		range: L(e, o, t, n),
		kind: "value",
		detail: `${i.name} value`
	}));
}
function B(e, t, n, r) {
	if (n.closing || n.inValue || n.partialStart < 0) return [];
	let i = O(n.name, r);
	if (!i) return [];
	let a = e.slice(n.partialStart, t);
	if (a && !/^[A-Za-z0-9_-]*$/.test(a)) return [];
	let o = new Set(n.attrs.filter((e) => e.nameEnd < n.partialStart).map((e) => e.name)), s = { ...i };
	return ![
		"computed",
		"const",
		"external",
		"validation",
		"option",
		"column",
		"edge",
		"step"
	].includes(n.name) && !Object.hasOwn(i, "css") && (s.css = {
		kind: "string",
		static: !0
	}), n.name === "counter" && !Object.hasOwn(i, "action-id") && (s["action-id"] = {
		kind: "string",
		static: !0
	}), Object.entries(s).filter(([e]) => !o.has(e) && e.startsWith(a)).map(([r, i]) => ({
		label: r,
		insertText: r,
		range: L(e, n.partialStart, t, r),
		kind: "attribute",
		detail: i.required ? `${i.kind}, required` : i.kind
	}));
}
function V(e, t, n) {
	let r = Math.max(0, t - 256), i = e.slice(r, t), a = /<\/?([A-Za-z][A-Za-z0-9-]*)?$/.exec(i);
	if (!a) return [];
	let o = r + a.index;
	if (e[o] !== "<" || e[o - 1] === "\\") return [];
	let s = e[o + 1] === "/", c = o + (s ? 2 : 1);
	if (c > t) return [];
	let l = a[1] ?? "", u = s ? n.filter((e) => e.form !== "leaf").map((e) => e.name) : n.map((e) => e.name), d = ["css", "javascript"].filter((e) => !n.some((t) => t.name === e));
	return [...u, ...d].filter((e) => e.startsWith(l)).map((n) => ({
		label: n,
		insertText: !s && d.includes(n) && e[L(e, c, t, n).end] !== ">" ? `${n}>\n\n</${n}>` : n,
		range: L(e, c, t, n),
		kind: "tag",
		detail: s ? "closing tag" : d.includes(n) ? "document declaration" : "component"
	}));
}
function H(e, t, n) {
	if (typeof e != "string" || !Number.isFinite(t) || !C(n)) return [];
	let r = Math.max(0, Math.min(e.length, Math.floor(t))), i = w(n), a = o(e, n), s = [...E(a.nodes), ...D(e, a.nodes)].sort((e, t) => e.start - t.start);
	if (I(s, r) || r === e.length && s.some((e) => e.end === r && e.start < r)) return [];
	let c = k(e, a.nodes, i), l = P(e, r);
	if (l) {
		let t = M(e, r, a.nodes);
		if (t >= 0) {
			let n = j(e, t, r);
			if (n?.inValue && n.currentAttribute) {
				let e = O(n.name, i)?.[n.currentAttribute.name];
				if (e?.static || !e && ["css", "action-id"].includes(n.currentAttribute.name)) return [];
			}
		}
		return R(e, r, l, c.bindings);
	}
	let u = M(e, r, a.nodes);
	if (u >= 0) {
		let t = j(e, u, r);
		if (t?.inValue) return z(e, r, t, i);
	}
	let d = V(e, r, i);
	if (d.length > 0) return d;
	if (u >= 0) {
		let t = j(e, u, r);
		if (t) return B(e, r, t, i);
	}
	return [];
}
function U(e, t) {
	let n = "", r = 0;
	for (let i of t) n += e.slice(r, i.range.start) + i.text, r = i.range.end;
	return n + e.slice(r);
}
function W(e, t, n, r) {
	if (typeof e != "string" || typeof t != "string" || typeof n != "string") throw Error("Rename requires string arguments.");
	if (!C(r)) throw Error("Bindings cannot be renamed with invalid compile options.");
	if (!b(n)) throw Error(`"${n}" is not a valid binding name. Use [A-Za-z_][A-Za-z0-9_]* and avoid reserved names.`);
	let i = k(e, o(e, r).nodes, w(r)), s = i.bindings.find((e) => e.name === t);
	if (!s || s.declarations.length === 0) throw Error(`Binding "${t}" is not declared in this document.`);
	if (t === n) return {
		source: e,
		edits: []
	};
	if (i.bindings.some((e) => e.name === n)) throw Error(`Binding "${n}" already exists.`);
	if (S(e, r).some((e) => e.severity === "error" && y.has(e.code))) throw Error("The document cannot be renamed safely while parse errors remain.");
	let c = /* @__PURE__ */ new Set(), l = [];
	for (let e of [...s.declarations, ...s.references]) {
		let t = `${e.start}:${e.end}`;
		c.has(t) || (c.add(t), l.push(x(e)));
	}
	l.sort((e, t) => e.start - t.start || e.end - t.end);
	let u = new Set(i.mathReferences.filter((e) => e.name === t).map((e) => `${e.range.start}:${e.range.end}`)), d = l.map((e) => ({
		range: x(e),
		text: u.has(`${e.start}:${e.end}`) ? `\\mathrm{${n}}` : n
	})), f = U(e, d);
	if (a(e, r).ok && !a(f, r).ok) throw Error("Rename could not preserve all binding references; the source was left unchanged.");
	return {
		source: f,
		edits: d
	};
}
function G(e, t) {
	let n = e.slice(t.nameRange.start, t.nameRange.end), r = t.attrs.map((t) => {
		let n = e.slice(t.nameRange.start, t.nameRange.end);
		return t.valueRange === void 0 ? n : t.quoteStart !== void 0 && t.quoteEnd !== void 0 ? `${n}=${e.slice(t.quoteStart, t.quoteEnd + 1)}` : n;
	}), i = r.length > 0 ? `<${n} ${r.join(" ")}` : `<${n}`;
	return t.selfClosing ? `${i} />` : `${i}>`;
}
function K(e, t) {
	if (typeof e != "string" || !C(t)) return e;
	let n;
	try {
		n = a(e, t);
	} catch {
		return e;
	}
	if (n.diagnostics.some((e) => e.severity === "error")) return e;
	let r = o(e, t), i = [], s = (t) => {
		for (let n of t) {
			if ((n.type === "component" || n.type === "hostComponent") && n.name) {
				let t = c(e, n.range.start);
				if (t && !t.closing && !/[\r\n]/.test(e.slice(t.start, t.end))) {
					let n = G(e, t);
					n !== e.slice(t.start, t.end) && i.push({
						start: t.start,
						end: t.end,
						text: n
					});
				}
				if (t) {
					let r = l(e, n, t.end);
					if (r && !/[\r\n]/.test(e.slice(r.start, r.end))) {
						let t = `</${e.slice(r.nameRange.start, r.nameRange.end)}>`;
						t !== e.slice(r.start, r.end) && i.push({
							start: r.start,
							end: r.end,
							text: t
						});
					}
				}
			}
			n.type !== "fallback" && n.children && s(n.children);
		}
	};
	s(r.nodes), i.sort((e, t) => e.start - t.start || e.end - t.end);
	let u = "", d = 0;
	for (let t of i) t.start < d || (u += e.slice(d, t.start) + t.text, d = t.end);
	return u + e.slice(d);
}
export { W as i, H as n, K as r, A as t };
