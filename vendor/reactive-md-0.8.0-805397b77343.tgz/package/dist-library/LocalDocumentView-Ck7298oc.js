import { z as e } from "./preset-core-CKc5YXSM.js";
import t from "./reactive-md-default-preset.js";
import { c as n } from "./sdk-core-DSJFgLTA.js";
import { _ as r, a as ee, c as te, d as ne, f as re, g as ie, h as ae, i as oe, l as i, m as a, n as o, o as s, p as c, r as l, s as u, t as d, u as f } from "./controls-B--RJaYi.js";
import { a as p, i as m, n as h, o as g, r as _, t as v } from "./visuals-Bjt6G7zu.js";
import { t as y } from "./coordinate-C0F46RvH.js";
import { _ as b, a as x, b as S, c as C, d as w, f as T, g as E, h as D, i as se, l as O, m as k, n as A, o as j, p as M, r as N, s as P, t as F, u as I, v as L, x as R, y as z } from "./layout-3TNbc9za.js";
import { t as B } from "./data-table--1ogLj7f.js";
import { n as V, t as H } from "./gallery-B8kSt1oI.js";
import { r as U, t as W } from "./package-core-CiTTvM9v.js";
import { n as G, t as K } from "./LocalDocumentViewCore-CEW2X8s2.js";
import { jsx as q } from "react/jsx-runtime";
// src/components/default-preset.ts
function J() {
	return null;
}
var ce = Object.freeze({
	input: s,
	textarea: c,
	number: te,
	slider: r,
	"range-slider": ie,
	coordinate: y,
	toggle: ae,
	checkbox: d,
	date: ee,
	select: re,
	choices: l,
	"radio-group": ne,
	"multi-select": u,
	option: T,
	counter: oe,
	timer: a,
	checklist: o,
	progress: i,
	jump: w,
	anchor: N,
	text: z,
	section: k,
	quiz: f,
	panel: M,
	card: x,
	grid: O,
	gallery: V,
	"gallery-item": H,
	tabs: L,
	tab: b,
	steps: E,
	step: D,
	accordion: F,
	disclosure: P,
	if: I,
	alert: A,
	badge: se,
	tooltip: S,
	validation: R,
	"data-table": B,
	column: j,
	table: p,
	chart: v,
	plot: m,
	timeline: g,
	diagram: h,
	node: _,
	edge: C,
	computed: J,
	const: J,
	external: J
}), Y = null;
function X() {
	if (Y) return Y;
	let e = [];
	for (let r of t.components) {
		let t = ce[r.name];
		if (!t) throw Error(`Default React preset has no implementation for builtin component <${r.name}>.`);
		e.push(n(r, { render: t }));
	}
	return Y = Object.freeze({
		id: t.id,
		version: t.version,
		components: Object.freeze(e)
	}), Y;
}
X();
// src/react/package.ts
var Z = U({
	protocol: e,
	preset: t,
	components: X().components
});
function Q(e = {}) {
	return W(e, Z);
}
// src/local/rendering/LocalDocumentView.tsx
var le, $ = () => le ??= Q().reactConfig;
function ue(e) {
	return /* @__PURE__ */ q(K, {
		...e,
		getBaseConfig: $
	});
}
function de(e) {
	return /* @__PURE__ */ q(G, {
		...e,
		getBaseConfig: $
	});
}
export { X as a, Z as i, de as n, Q as r, ue as t };
