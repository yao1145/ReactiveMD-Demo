import { Z as e } from "./validation-BPmsZ5G9.js";
import { A as t, C as n, E as r, i, p as a } from "./network-Ca3GAJua.js";
// src/export/component-state.ts
function o(e, t) {
	return {
		code: e,
		message: t,
		severity: "warning",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function s(t, i) {
	let a = r(t.source), o = /* @__PURE__ */ new Set();
	for (let r of e(t.nodes)) r.name !== void 0 && o.add(n({
		documentId: i,
		sourceDigest: a,
		nodeId: r.id,
		stateKey: r.attrs?.["state-key"]
	}));
	return o;
}
function c(e, n, c) {
	let l = a(n);
	if (!l.ok) return l;
	let u = r(e.source), d = t({
		documentId: c?.documentId,
		sourceDigest: u
	}), f = s(e, d), p = [...l.diagnostics], m = {}, h = c?.configKey, g = l.document.configKey, _ = c?.legacyConfigKeys ?? [];
	if (g !== void 0 && h !== void 0 && g !== h && !_.includes(g)) return p.push(o("local.runtime.state.config-mismatch", `Saved component state belongs to configuration "${g}", not "${h}".`)), {
		ok: !0,
		componentState: Object.freeze({
			format: i,
			configKey: h,
			records: Object.freeze({})
		}),
		diagnostics: p
	};
	for (let [e, t] of Object.entries(l.records)) t.documentId !== void 0 && t.documentId !== d ? p.push(o("local.runtime.state.document-mismatch", `Saved state key "${e}" belongs to a different document identity (${t.documentId}).`)) : f.has(e) ? m[e] = t : p.push(o("local.runtime.state.unknown-component", `Saved state key "${e}" does not match any component in this document.`));
	return {
		ok: !0,
		componentState: Object.freeze({
			format: i,
			...(h ?? g) === void 0 ? {} : { configKey: h ?? g },
			records: Object.freeze(m)
		}),
		diagnostics: p
	};
}
export { c as t };
