/** JSON values accepted by a named network channel. */
export type Json = null | boolean | number | string | readonly Json[] | {
    readonly [key: string]: Json;
};
export type JsonPayload = Readonly<Record<string, Json>>;
export interface ChannelError {
    readonly code: 'unavailable' | 'invalid-data' | 'rejected' | 'transport' | 'unconfirmed' | 'cancelled';
    readonly message: string;
}
export type SubmitResult = {
    ok: true;
} | {
    ok: false;
    error: ChannelError;
};
export type StreamStatus = 'connecting' | 'open' | 'closed';
export type StreamEvent = {
    type: 'status';
    state: StreamStatus;
} | {
    type: 'data';
    value: Json;
} | {
    type: 'error';
    error: ChannelError;
};
export interface ComponentNetwork {
    supports(channel: string, operation: 'submit' | 'subscribe'): boolean;
    submit(channel: string, payload: JsonPayload, options?: SubmitOptions): Promise<SubmitResult>;
    subscribe(channel: string, listener: (event: StreamEvent) => void): () => void;
}
export interface SubmitOptions {
    readonly signal?: AbortSignal;
    readonly idempotencyKey?: string;
}
/** Return true to accept the data or a safe, user-facing string to reject it. */
export type ChannelValidator<T> = (value: T) => boolean | string;
export interface SubmitAdapterContext {
    readonly signal: AbortSignal;
    /** Shared by both directions of this named channel until the runtime disposes it. */
    readonly sessionSignal: AbortSignal;
    readonly requestId: string;
    readonly idempotencyKey?: string;
}
export interface SubmitAdapter {
    readonly validate: ChannelValidator<JsonPayload>;
    /** Maximum encoded JSON bytes. Defaults to 64 KiB. */
    readonly maxBytes?: number;
    send(payload: JsonPayload, context: SubmitAdapterContext): SubmitResult | Promise<SubmitResult>;
}
export interface SubscribeAdapterContext {
    readonly signal: AbortSignal;
    /** Shared by both directions of this named channel until the runtime disposes it. */
    readonly sessionSignal: AbortSignal;
    status(state: StreamStatus): void;
    data(value: unknown): void;
    error(error: ChannelError): void;
}
export interface SubscribeAdapter {
    readonly validate: ChannelValidator<Json>;
    /** Maximum decoded message size measured in encoded JSON bytes. Defaults to 64 KiB. */
    readonly maxBytes?: number;
    open(context: SubscribeAdapterContext): (() => void) | Promise<() => void>;
}
export interface NetworkChannel {
    readonly submit?: SubmitAdapter;
    readonly subscribe?: SubscribeAdapter;
}
export interface NetworkConfig {
    readonly channels: Readonly<Record<string, NetworkChannel>>;
    /** Thrown listener errors are isolated. The host receives a safe summary. */
    readonly onListenerError?: (error: ChannelError) => void;
}
export interface NetworkSession {
    readonly network: ComponentNetwork;
    dispose(): void;
}
export declare const DEFAULT_NETWORK_MAX_BYTES: number;
export declare const unavailableNetwork: ComponentNetwork;
export declare function createNetworkSession(config?: NetworkConfig): NetworkSession;
