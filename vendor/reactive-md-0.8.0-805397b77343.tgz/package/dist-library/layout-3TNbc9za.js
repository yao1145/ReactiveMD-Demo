import { A as e, I as t, M as n, O as r, P as i, S as a, _ as o, a as s, g as c, k as l, n as u, o as d, r as f, s as p, t as m } from "./component-utils-Dnlbk_nv.js";
import { n as h, t as g } from "./tooltip-layer-HDLrSWs0.js";
import { useEffect as _, useId as v, useRef as y, useState as b } from "react";
import { Fragment as x, jsx as S, jsxs as C } from "react/jsx-runtime";
// src/components/layout/layout.tsx
function w(t) {
	let n = e(t), { content: i, runtime: a, mode: o, t: s } = n, c = r(t, "title", ""), l = p(t, "reset", !0) && o !== "static", [u, d] = b(null);
	return /* @__PURE__ */ C("section", {
		className: "md-panel local-panel",
		"aria-label": c || s("Parameter panel", "参数面板"),
		children: [
			c || l ? /* @__PURE__ */ C("div", {
				className: "local-panel-head",
				children: [c ? /* @__PURE__ */ S("h3", {
					className: "md-panel-title local-panel-title",
					children: c
				}) : /* @__PURE__ */ S("span", {}), l ? /* @__PURE__ */ S("button", {
					type: "button",
					className: "md-button md-button-quiet local-panel-reset",
					onClick: () => {
						try {
							a.reset(i), d(null);
						} catch (e) {
							d(e instanceof Error ? e.message : s("Cannot reset", "无法恢复默认"));
						}
					},
					"aria-label": c ? s(`Reset ${c}`, `${c} 恢复默认`) : s("Reset", "恢复默认"),
					children: s("Reset", "恢复默认")
				}) : null]
			}) : null,
			/* @__PURE__ */ S("div", {
				className: "md-panel-body local-panel-body",
				children: n.render()
			}),
			/* @__PURE__ */ S(m, { message: u })
		]
	});
}
function T(t) {
	let n = e(t), i = r(t, "title", "");
	return /* @__PURE__ */ C("section", {
		className: "md-card local-card",
		children: [i ? /* @__PURE__ */ S("h3", {
			className: "md-card-title",
			children: i
		}) : null, /* @__PURE__ */ S("div", {
			className: "md-card-body",
			children: n.render()
		})]
	});
}
function E(t) {
	let n = e(t), r = Math.min(4, Math.max(1, Math.floor(Number(t.props.columns ?? 2) || 2)));
	return /* @__PURE__ */ S("div", {
		className: "local-grid",
		style: { "--local-grid-columns": String(r) },
		children: n.render()
	});
}
function D(t) {
	let n = e(t);
	return /* @__PURE__ */ S("div", {
		className: "local-tabpanel-body",
		children: n.render()
	});
}
function O() {
	return null;
}
function k() {
	return null;
}
function A() {
	return null;
}
function j(o) {
	let s = e(o), l = v(), { content: d, mode: p, visible: h, t: g } = s, { write: _, error: x } = t(o), w = r(o, "label", ""), T = i(o), E = d.children.filter((e) => e.kind === "component" && e.name === "tab"), D = E.map((e, t) => a(e, "value") ?? `tab-${t + 1}`), O = E.map((e, t) => c(o, e, "label", D[t])), k = a(d, "initial") ?? D[0] ?? "", A = a(d, "bind") !== void 0, j = o.runtime.get(d), M = typeof j == "string" ? j : "", [N, P] = b(() => D.includes(k) ? k : D[0] ?? ""), F = y([]);
	if (n(o, () => {
		P(D.includes(k) ? k : D[0] ?? "");
	}), E.length === 0) return /* @__PURE__ */ S(u, { message: g("Tabs requires at least one tab", "标签页至少需要一个 tab") });
	if (p === "static") return /* @__PURE__ */ C("section", {
		className: "local-tabs local-static-tabs",
		"aria-label": w || g("Tabs", "选项卡"),
		children: [w ? /* @__PURE__ */ S("div", {
			className: "local-tabs-label",
			children: w
		}) : null, E.map((e, t) => /* @__PURE__ */ C("section", {
			className: "local-static-tab",
			children: [/* @__PURE__ */ S("h4", {
				className: "local-static-tab-label",
				children: O[t]
			}), /* @__PURE__ */ S("div", {
				className: "local-static-tab-body",
				children: s.render(e.children, h)
			})]
		}, e.id))]
	});
	let I = A ? D.includes(M) ? M : D[0] : D.includes(N) ? N : D[0], L = Math.max(0, D.indexOf(I)), R = (e) => {
		let t = D[e];
		t !== void 0 && (A ? _(t) : P(t), F.current[e]?.focus());
	};
	return /* @__PURE__ */ C("section", {
		className: "md-tabs local-tabs",
		"aria-label": w || g("Tabs", "选项卡"),
		"aria-invalid": T.invalid || void 0,
		"aria-describedby": T.describedBy,
		children: [
			w ? /* @__PURE__ */ S("div", {
				className: "local-tabs-label",
				children: w
			}) : null,
			/* @__PURE__ */ S("div", {
				className: "md-tablist local-tablist",
				role: "tablist",
				"aria-label": w || g("Tabs", "选项卡"),
				onKeyDown: (e) => {
					let t = -1;
					e.key === "ArrowRight" ? t = (L + 1) % E.length : e.key === "ArrowLeft" ? t = (L - 1 + E.length) % E.length : e.key === "Home" ? t = 0 : e.key === "End" && (t = E.length - 1), !(t < 0) && (e.preventDefault(), R(t));
				},
				children: E.map((e, t) => {
					let n = D[t], r = n === I;
					return /* @__PURE__ */ S("button", {
						ref: (e) => {
							F.current[t] = e;
						},
						id: `${l}-tab-${t}`,
						type: "button",
						role: "tab",
						className: `md-tab local-tab${r ? " is-selected" : ""}`,
						"aria-selected": r,
						"aria-controls": `${l}-panel-${t}`,
						tabIndex: r ? 0 : -1,
						onClick: () => {
							A ? _(n) : P(n);
						},
						children: O[t]
					}, e.id);
				})
			}),
			E.map((e, t) => {
				let n = D[t] === I;
				return /* @__PURE__ */ C("div", {
					id: `${l}-panel-${t}`,
					className: "md-tabpanel local-tabpanel",
					role: "tabpanel",
					"aria-labelledby": `${l}-tab-${t}`,
					tabIndex: 0,
					hidden: !n,
					children: [/* @__PURE__ */ S(f, {
						block: !0,
						value: O[t]
					}), s.render(e.children, h && n)]
				}, e.id);
			}),
			/* @__PURE__ */ S(m, { message: x })
		]
	});
}
function M(o) {
	let s = e(o), l = v(), { content: d, mode: f, visible: p, t: h } = s, { write: g, error: b, setError: x } = t(o), w = r(o, "label", ""), T = i(o), E = d.children.filter((e) => e.kind === "component" && e.name === "step"), D = E.map((e, t) => a(e, "value") ?? `step-${t + 1}`), O = E.map((e, t) => c(o, e, "label", D[t])), k = a(d, "initial") ?? "", A = D.includes(k) ? k : D[0] ?? "", j = o.runtime.get(d), M = typeof j == "string" ? j : "", N = y([]), P = y(!1);
	n(o, () => {
		x(null), P.current = !1;
	});
	let F = D.includes(M) ? M : A, I = Math.max(0, D.indexOf(F));
	if (_(() => {
		P.current && (P.current = !1, N.current[I]?.focus({ preventScroll: !0 }));
	}, [I, F]), E.length === 0) return /* @__PURE__ */ S(u, { message: h("Steps requires at least one step", "步骤至少需要一个 step") });
	if (f === "static") {
		let e = E[I];
		return /* @__PURE__ */ C("section", {
			className: "local-steps local-static-steps",
			"aria-label": w || h("Steps", "步骤"),
			children: [
				w ? /* @__PURE__ */ S("div", {
					className: "local-steps-label",
					children: w
				}) : null,
				/* @__PURE__ */ S("ol", {
					className: "local-steps-rail",
					"aria-hidden": "true",
					style: { "--local-steps-progress": `${E.length <= 1 ? 100 : I / (E.length - 1) * 100}%` },
					children: E.map((e, t) => /* @__PURE__ */ S("li", {
						className: `local-steps-dot${t < I ? " is-complete" : t === I ? " is-current" : ""}`,
						children: /* @__PURE__ */ S("span", { children: t + 1 })
					}, e.id))
				}),
				/* @__PURE__ */ S("div", {
					className: "local-steps-nav local-static-steps-nav",
					children: /* @__PURE__ */ S("span", {
						className: "local-steps-status",
						role: "status",
						"aria-live": "polite",
						children: h(`Step ${I + 1} of ${E.length}`, `第 ${I + 1} 步，共 ${E.length} 步`)
					})
				}),
				/* @__PURE__ */ S("div", {
					className: "local-steps-panel",
					role: "group",
					"aria-label": O[I],
					children: s.render(e.children, p)
				})
			]
		});
	}
	let L = (e) => {
		let t = D[e];
		t !== void 0 && (P.current = !0, g(t));
	};
	return /* @__PURE__ */ C("section", {
		className: "local-steps",
		"aria-label": w || h("Steps", "步骤"),
		"aria-invalid": T.invalid || void 0,
		"aria-describedby": T.describedBy,
		children: [
			w ? /* @__PURE__ */ S("div", {
				className: "local-steps-label",
				children: w
			}) : null,
			/* @__PURE__ */ S("ol", {
				className: "local-steps-rail",
				"aria-hidden": "true",
				style: { "--local-steps-progress": `${E.length <= 1 ? 100 : I / (E.length - 1) * 100}%` },
				children: E.map((e, t) => /* @__PURE__ */ S("li", {
					className: `local-steps-dot${t < I ? " is-complete" : t === I ? " is-current" : ""}`,
					children: /* @__PURE__ */ S("span", { children: t + 1 })
				}, e.id))
			}),
			/* @__PURE__ */ C("div", {
				className: "local-steps-nav",
				children: [
					/* @__PURE__ */ S("button", {
						type: "button",
						className: "md-button md-button-secondary local-steps-prev",
						disabled: I <= 0,
						onClick: () => L(I - 1),
						children: h("Previous", "上一步")
					}),
					/* @__PURE__ */ S("span", {
						className: "local-steps-status",
						role: "status",
						"aria-live": "polite",
						children: h(`Step ${I + 1} of ${E.length}`, `第 ${I + 1} 步，共 ${E.length} 步`)
					}),
					/* @__PURE__ */ S("button", {
						type: "button",
						className: "md-button md-button-secondary local-steps-next",
						disabled: I >= E.length - 1,
						onClick: () => L(I + 1),
						children: h("Next", "下一步")
					})
				]
			}),
			E.map((e, t) => {
				let n = t === I;
				return /* @__PURE__ */ S("div", {
					id: `${l}-step-${t}`,
					ref: (e) => {
						N.current[t] = e;
					},
					className: "local-steps-panel",
					role: "group",
					"aria-label": O[t],
					tabIndex: -1,
					hidden: !n,
					children: s.render(e.children, p && n)
				}, e.id);
			}),
			/* @__PURE__ */ S(m, { message: b })
		]
	});
}
function N() {
	return null;
}
function P(t) {
	let n = e(t), i = r(t, "label", "");
	return /* @__PURE__ */ C("div", {
		className: "local-accordion",
		role: "group",
		"aria-label": i || n.t("Accordion", "折叠面板"),
		children: [i ? /* @__PURE__ */ S("div", {
			className: "local-accordion-label",
			children: i
		}) : null, n.render()]
	});
}
function F(t) {
	let i = e(t), a = v(), { mode: o, visible: s, t: c } = i, l = r(t, "label", c("Details", "折叠内容")), u = p(t, "open", !1), [d, m] = b(u);
	if (n(t, () => {
		m(u);
	}), o === "static") return /* @__PURE__ */ C("section", {
		className: "local-disclosure local-static-disclosure",
		children: [/* @__PURE__ */ S("h3", {
			className: "local-disclosure-heading",
			children: l
		}), /* @__PURE__ */ S("div", {
			className: "local-disclosure-panel",
			children: i.render()
		})]
	});
	let h = `${a}-disclosure-trigger`, g = `${a}-disclosure-panel`;
	return /* @__PURE__ */ C("div", {
		className: "local-disclosure",
		children: [/* @__PURE__ */ C("h3", {
			className: "local-disclosure-heading",
			children: [/* @__PURE__ */ C("button", {
				id: h,
				type: "button",
				className: "local-disclosure-trigger",
				"data-rmd-appearance": "custom",
				"aria-expanded": d,
				"aria-controls": g,
				onClick: () => m((e) => !e),
				children: [/* @__PURE__ */ S("span", {
					className: "local-disclosure-label",
					children: l
				}), /* @__PURE__ */ S("svg", {
					className: `local-chevron${d ? " is-open" : ""}`,
					viewBox: "0 0 24 24",
					width: "17",
					height: "17",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.75",
					strokeLinecap: "round",
					strokeLinejoin: "round",
					"aria-hidden": "true",
					focusable: "false",
					children: /* @__PURE__ */ S("path", { d: "m6 9 6 6 6-6" })
				})]
			}), /* @__PURE__ */ S(f, { value: l })]
		}), /* @__PURE__ */ S("div", {
			id: g,
			className: "local-disclosure-panel",
			role: "region",
			"aria-labelledby": h,
			hidden: !d,
			inert: !d,
			children: /* @__PURE__ */ S("div", {
				className: "local-disclosure-body",
				children: i.render(void 0, s)
			})
		})]
	});
}
function I(t) {
	let n = e(t), { content: r, t: i, visible: o } = n, s = a(r, "when"), c = t.props.when, l = typeof c == "boolean" && c, d = s !== void 0 && typeof c != "boolean", f = y(null), p = y(l), m = y(!1);
	return _(() => {
		if (p.current && !l) {
			if (m.current) {
				let e = f.current?.closest(".local-document");
				e && (e.tabIndex = -1, e.focus({ preventScroll: !0 }));
			}
			m.current = !1;
		}
		p.current = l;
	}, [l]), /* @__PURE__ */ C(x, { children: [d ? /* @__PURE__ */ S(u, { message: i("Cannot compute", "无法计算") }) : null, /* @__PURE__ */ S("div", {
		ref: f,
		className: "local-if md-if",
		role: "group",
		"aria-label": i("Conditional content", "条件内容"),
		tabIndex: -1,
		hidden: !l,
		"aria-hidden": !l,
		onFocus: () => {
			m.current = !0;
		},
		onBlur: (e) => {
			f.current?.contains(e.relatedTarget) || (m.current = !1);
		},
		children: n.render(void 0, o && l)
	})] });
}
function L(t) {
	let n = e(t), i = r(t, "title", ""), { tone: a, error: o } = l(t, "tone", [
		"info",
		"success",
		"warning"
	], "info"), c = a === "warning" ? "alert" : "status";
	return /* @__PURE__ */ C(x, { children: [o ? /* @__PURE__ */ S(s, { message: n.t("Invalid tone; using the default style", "色调无效，已使用默认样式") }) : null, /* @__PURE__ */ C("div", {
		className: `md-alert md-alert-${a} local-alert local-alert-${a}`,
		role: c,
		children: [i ? /* @__PURE__ */ S("div", {
			className: "md-alert-title local-alert-title",
			children: i
		}) : null, /* @__PURE__ */ S("div", {
			className: "md-alert-body local-alert-body",
			children: n.render()
		})]
	})] });
}
function R(t) {
	let n = e(t), { tone: r, error: i } = l(t, "tone", [
		"neutral",
		"success",
		"warning"
	], "neutral"), a = o(n.content);
	return /* @__PURE__ */ C(x, { children: [i ? /* @__PURE__ */ S(s, { message: n.t("Invalid tone; using the default style", "色调无效，已使用默认样式") }) : null, /* @__PURE__ */ S("span", {
		className: `md-badge md-badge-${r} local-badge`,
		style: a ? { color: a } : void 0,
		children: /* @__PURE__ */ S("span", {
			className: "md-badge-label",
			children: n.renderInline()
		})
	})] });
}
function z(t) {
	let n = e(t), i = v(), { mode: a, t: o } = n, s = r(t, "text", o("Tooltip", "提示")), [c, l] = b(!1), u = y(null), d = y(null), p = `${i}-tooltip`, m = c && t.visible && a !== "static";
	return h(d, m), _(() => l(!1), [
		t.visible,
		t.resetToken,
		a
	]), g(() => {
		let e = d.current, t = u.current;
		if (!m || !e || !t) return;
		let n = () => {
			let n = e.getBoundingClientRect(), r = t.getBoundingClientRect(), i = Number.parseFloat(getComputedStyle(e).getPropertyValue("--space-2")) || 8, a = Math.max(8, Math.min(r.left, window.innerWidth - n.width - 8)), o = r.top - n.height - i, s = o >= 8 ? o : Math.max(8, Math.min(r.bottom + i, window.innerHeight - n.height - 8));
			e.style.left = `${a}px`, e.style.top = `${s}px`;
		};
		n(), window.addEventListener("resize", n), window.addEventListener("scroll", n, {
			capture: !0,
			passive: !0
		});
		let r = new ResizeObserver(n);
		return r.observe(t), r.observe(e), () => {
			window.removeEventListener("resize", n), window.removeEventListener("scroll", n, !0), r.disconnect();
		};
	}, [m, s]), a === "static" ? /* @__PURE__ */ C("span", {
		className: "local-tooltip local-static-tooltip",
		children: [/* @__PURE__ */ S("span", {
			className: "local-tooltip-trigger",
			children: n.renderInline()
		}), /* @__PURE__ */ S("span", {
			className: "md-tooltip local-tooltip-bubble is-visible",
			role: "note",
			children: s
		})]
	}) : /* @__PURE__ */ C("span", {
		className: "local-tooltip",
		onMouseEnter: () => l(!0),
		onMouseLeave: () => l(!1),
		children: [
			/* @__PURE__ */ S("span", {
				className: "local-tooltip-trigger",
				ref: u,
				tabIndex: 0,
				"aria-describedby": p,
				onFocus: () => l(!0),
				onBlur: () => l(!1),
				onKeyDown: (e) => {
					e.key === "Escape" && (e.stopPropagation(), l(!1));
				},
				children: n.renderInline()
			}),
			/* @__PURE__ */ S("span", {
				id: p,
				ref: d,
				role: "tooltip",
				popover: "manual",
				className: `md-tooltip local-tooltip-bubble${m ? " is-visible" : ""}`,
				children: s
			}),
			/* @__PURE__ */ S(f, { value: s })
		]
	});
}
function B(t) {
	let r = e(t), i = v(), { content: s, mode: c, t: l } = r, u = `${i}-jump-feedback`, [f, p] = b(null), m = a(s, "to") ?? "", h = r.navigation.targetId(m), g = a(s, "appearance") === "button" ? "button" : "link", _ = o(s), y = h ? `#${h}` : "#", w = h !== void 0 && r.navigation.allowed(m);
	return n(t, () => p(null)), c === "static" ? w && h ? /* @__PURE__ */ S("a", {
		href: `#${h}`,
		className: "local-jump local-jump-link local-jump-static",
		style: d(_),
		children: r.renderInline()
	}) : /* @__PURE__ */ S("span", {
		className: "local-jump local-jump-static-blocked",
		style: d(_),
		children: r.renderInline()
	}) : /* @__PURE__ */ C(x, { children: [/* @__PURE__ */ S("a", {
		href: w ? y : "#",
		className: g === "button" ? "local-jump local-jump-button md-button md-button-secondary" : "local-jump local-jump-link",
		style: d(_),
		"data-local-custom-color": _ ? "true" : void 0,
		"data-local-target-missing": h ? void 0 : "true",
		"data-local-jump-blocked": h && !w ? "true" : void 0,
		"aria-describedby": f ? u : void 0,
		onClick: (e) => {
			if (!w || !h) {
				e.preventDefault(), p(h ? l("Jump is blocked by the host", "跳转已被主机策略阻止") : l("Jump target not found", "找不到跳转目标"));
				return;
			}
			if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
			let t = r.navigation.jump(m);
			t === "missing" ? (e.preventDefault(), p(l("Jump target not found", "找不到跳转目标"))) : t === "hidden" ? (e.preventDefault(), p(l("Jump target is hidden", "跳转目标当前隐藏"))) : (e.preventDefault(), p(null));
		},
		children: r.renderInline()
	}), f ? /* @__PURE__ */ S("span", {
		id: u,
		className: "local-jump-feedback",
		role: "status",
		"aria-live": "polite",
		children: f
	}) : null] });
}
function V(t) {
	let n = e(t).navigation.anchorId();
	return n ? /* @__PURE__ */ S("span", {
		className: "local-anchor",
		id: n,
		"data-local-anchor": ""
	}) : null;
}
function H(t) {
	let n = e(t), r = o(n.content);
	return /* @__PURE__ */ S("span", {
		className: "local-text",
		style: r ? { color: r } : void 0,
		children: n.renderInline()
	});
}
function U(t) {
	let n = e(t), r = o(n.content);
	return /* @__PURE__ */ S("div", {
		className: "local-section",
		style: r ? { color: r } : void 0,
		children: n.render()
	});
}
function W(t) {
	let n = e(t), r = t.validation.hintFor(t.content);
	if (!r) return null;
	let i = r.failed || r.error, a = n.visible && i;
	return /* @__PURE__ */ S("span", {
		id: r.id,
		className: "local-validation-hint",
		"data-local-validation": r.error ? "error" : r.failed ? "failed" : "passed",
		role: a ? "status" : void 0,
		"aria-live": a ? "polite" : void 0,
		children: i ? r.message : null
	});
}
export { D as _, T as a, z as b, A as c, B as d, O as f, M as g, N as h, R as i, E as l, U as m, L as n, k as o, w as p, V as r, F as s, P as t, I as u, j as v, W as x, H as y };
