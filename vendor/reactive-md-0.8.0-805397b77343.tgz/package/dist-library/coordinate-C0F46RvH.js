import { c as e, s as t } from "./visuals-Bjt6G7zu.js";
import { A as n, E as r, I as i, M as a, O as o, P as s, T as c, _ as l, b as u, c as d, i as f, j as p, o as m, r as h, t as g } from "./component-utils-Dnlbk_nv.js";
import { useEffect as _, useId as v, useRef as y, useState as b } from "react";
import { jsx as x, jsxs as S } from "react/jsx-runtime";
// src/components/plot/coordinate.tsx
function C({ id: e, label: t, value: n, min: i, max: a, step: o, disabled: s, onCommit: c, reset: l }) {
	let [u, f] = b(() => String(n)), [p, m] = b(!1), h = y(n);
	_(() => {
		f(String(n)), m(!1);
	}, [l]), _(() => {
		h.current !== n && (h.current = n, p || f(String(n)));
	}, [n, p]);
	let g = (e) => {
		let t = e.trim();
		if (t === "" || t === "-" || t === "." || t === "-.") return null;
		let n = Number(t);
		return Number.isFinite(n) ? r(d(n, i, a), i, a, o) : null;
	};
	return /* @__PURE__ */ S("div", {
		className: "local-number-field",
		children: [/* @__PURE__ */ x("label", {
			className: "md-label",
			htmlFor: e,
			children: t
		}), /* @__PURE__ */ x("input", {
			id: e,
			className: "md-text-input",
			type: "text",
			inputMode: "decimal",
			value: u,
			disabled: s,
			onFocus: () => m(!0),
			onBlur: () => {
				m(!1);
				let e = g(u);
				f(String(e ?? n));
			},
			onChange: (e) => {
				let t = e.target.value;
				f(t);
				let n = g(t);
				n !== null && c(n);
			}
		})]
	});
}
function w(_) {
	let b = n(_), w = v(), { content: T, mode: ee, resetToken: E, t: D } = b, { write: O, writeMany: te, error: k, setError: A } = i(_), j = o(_, "label", D("Coordinate", "坐标")), { disabled: M, invalid: N } = p(_), P = s(_), F = u(_, "x-min", "x-max", -5, 5, 1), I = u(_, "y-min", "y-max", -5, 5, 1), L = r(0, F.min, F.max, F.step), R = r(0, I.min, I.max, I.step), z = r(c(_, "x", L), F.min, F.max, F.step), B = r(c(_, "y", R), I.min, I.max, I.step), V = y(null), H = y(!1), U = t();
	a(_, () => A(null));
	let W = `X: ${z} · Y: ${B}`;
	if (ee === "static") return /* @__PURE__ */ x(f, {
		className: "local-coordinate",
		label: j,
		value: W
	});
	let G = (e) => F.max > F.min ? 40 + (e - F.min) / (F.max - F.min) * 320 : 200, K = (e) => I.max > I.min ? 360 - (e - I.min) / (I.max - I.min) * 320 : 200, q = G(z), J = K(B), Y = G(d(0, F.min, F.max)), X = K(d(0, I.min, I.max)), Z = (e) => {
		let t = e.step * Math.max(1, Math.ceil((e.max - e.min) / (e.step * 10))), n = Math.min(11, Math.floor((e.max - e.min) / t) + 1);
		return Array.from({ length: n }, (n, r) => e.min + r * t);
	}, Q = (e) => {
		let t = V.current?.getBoundingClientRect();
		if (!t || t.width === 0 || t.height === 0) return null;
		let n = d(((e.clientX - t.left) / t.width - .1) / .8, 0, 1), i = d(((e.clientY - t.top) / t.height - .1) / .8, 0, 1);
		return {
			x: r(F.min + n * (F.max - F.min), F.min, F.max, F.step),
			y: r(I.min + (1 - i) * (I.max - I.min), I.min, I.max, I.step)
		};
	}, $ = (e, t) => {
		(e !== z || t !== B) && te({
			x: e,
			y: t
		});
	};
	return /* @__PURE__ */ S("div", {
		className: "local-coordinate",
		style: m(l(T)),
		role: "group",
		"aria-label": j,
		"data-rmd-component": "coordinate",
		"aria-invalid": P.invalid || void 0,
		"aria-describedby": P.describedBy,
		children: [
			/* @__PURE__ */ x("span", {
				className: "md-label",
				children: j
			}),
			/* @__PURE__ */ S("div", {
				className: `local-coordinate-surface${U ? " local-mafs-surface" : ""}`,
				children: [/* @__PURE__ */ x("div", {
					ref: V,
					className: `local-coordinate-pad${U ? " local-mafs-coordinate" : ""}`,
					role: "group",
					"aria-label": D(`${j} drag area`, `${j} 拖拽区`),
					"aria-disabled": M || void 0,
					tabIndex: M ? -1 : 0,
					onKeyDownCapture: (e) => {
						if (M) return;
						let t = z, n = B;
						switch (e.key) {
							case "ArrowLeft":
								t = r(z - F.step, F.min, F.max, F.step);
								break;
							case "ArrowRight":
								t = r(z + F.step, F.min, F.max, F.step);
								break;
							case "ArrowDown":
								n = r(B - I.step, I.min, I.max, I.step);
								break;
							case "ArrowUp":
								n = r(B + I.step, I.min, I.max, I.step);
								break;
							case "Home":
								t = F.min, n = I.min;
								break;
							case "End":
								t = r(F.max, F.min, F.max, F.step), n = r(I.max, I.min, I.max, I.step);
								break;
							default: return;
						}
						e.preventDefault(), e.stopPropagation(), $(t, n);
					},
					onPointerDown: U ? void 0 : (e) => {
						if (M) return;
						e.preventDefault(), H.current = !0, V.current?.focus({ preventScroll: !0 });
						try {
							e.currentTarget.setPointerCapture(e.pointerId);
						} catch {}
						let t = Q(e);
						t && $(t.x, t.y);
					},
					onPointerMove: U ? void 0 : (e) => {
						if (!H.current || M) return;
						let t = Q(e);
						t && $(t.x, t.y);
					},
					onPointerUp: U ? void 0 : (e) => {
						H.current = !1;
						try {
							e.currentTarget.releasePointerCapture(e.pointerId);
						} catch {}
					},
					onPointerCancel: U ? void 0 : () => {
						H.current = !1;
					},
					children: U ? /* @__PURE__ */ x(e, {
						x: z,
						y: B,
						xRange: F,
						yRange: I,
						step: F.step,
						disabled: M,
						accent: "var(--local-accent, var(--coordinate-point))",
						onMove: $
					}) : /* @__PURE__ */ S("svg", {
						className: "local-coordinate-svg",
						viewBox: "0 0 400 400",
						"aria-hidden": "true",
						focusable: "false",
						children: [
							/* @__PURE__ */ x("defs", { children: /* @__PURE__ */ x("marker", {
								id: `${w}-coordinate-arrow`,
								markerWidth: "8",
								markerHeight: "8",
								refX: "6",
								refY: "4",
								orient: "auto",
								viewBox: "0 0 8 8",
								children: /* @__PURE__ */ x("path", {
									className: "local-coordinate-arrow",
									d: "M1 1 L6 4 L1 7"
								})
							}) }),
							/* @__PURE__ */ S("g", {
								className: "local-coordinate-grid",
								children: [
									/* @__PURE__ */ x("rect", {
										x: "40",
										y: "40",
										width: "320",
										height: "320"
									}),
									Z(F).map((e, t) => /* @__PURE__ */ x("line", {
										x1: G(e),
										y1: "40",
										x2: G(e),
										y2: "360"
									}, `x-${t}`)),
									Z(I).map((e, t) => /* @__PURE__ */ x("line", {
										x1: "40",
										y1: K(e),
										x2: "360",
										y2: K(e)
									}, `y-${t}`))
								]
							}),
							/* @__PURE__ */ S("g", {
								className: "local-coordinate-axes",
								children: [/* @__PURE__ */ x("line", {
									className: "local-coordinate-horizontal",
									x1: "26",
									y1: X,
									x2: "372",
									y2: X,
									markerEnd: `url(#${w}-coordinate-arrow)`
								}), /* @__PURE__ */ x("line", {
									className: "local-coordinate-vertical",
									x1: Y,
									y1: "374",
									x2: Y,
									y2: "24",
									markerEnd: `url(#${w}-coordinate-arrow)`
								})]
							}),
							/* @__PURE__ */ S("g", {
								className: "local-coordinate-axis-label",
								children: [/* @__PURE__ */ x("text", {
									x: "358",
									y: X - 14,
									children: "x"
								}), /* @__PURE__ */ x("text", {
									x: Y + 12,
									y: "40",
									children: "y"
								})]
							}),
							/* @__PURE__ */ S("g", {
								className: "local-coordinate-projection",
								children: [/* @__PURE__ */ x("line", {
									x1: q,
									y1: J,
									x2: q,
									y2: X
								}), /* @__PURE__ */ x("line", {
									x1: q,
									y1: J,
									x2: Y,
									y2: J
								})]
							}),
							/* @__PURE__ */ x("circle", {
								className: "local-coordinate-dot",
								cx: q,
								cy: J,
								r: "10"
							}),
							/* @__PURE__ */ x("text", {
								className: "local-coordinate-value",
								x: q,
								y: J > 330 ? J - 22 : J + 30,
								textAnchor: q < 80 ? "start" : q > 320 ? "end" : "middle",
								children: `(${z}, ${B})`
							})
						]
					})
				}), /* @__PURE__ */ x("span", {
					className: "local-coordinate-caption",
					children: D("Draggable coordinate plane", "可拖动的坐标平面")
				})]
			}),
			/* @__PURE__ */ x("span", {
				className: "md-hint local-hint",
				children: D("Arrow keys adjust the point; Home and End jump to the lower or upper bounds.", "方向键调整坐标；Home 和 End 跳到最小或最大边界。")
			}),
			/* @__PURE__ */ S("div", {
				className: "local-coordinate-fields",
				children: [/* @__PURE__ */ x(C, {
					id: `${w}-coordinate-x`,
					reset: E,
					label: `${j} X`,
					value: z,
					min: F.min,
					max: F.max,
					step: F.step,
					disabled: M,
					onCommit: (e) => O(e, "x")
				}), /* @__PURE__ */ x(C, {
					id: `${w}-coordinate-y`,
					reset: E,
					label: `${j} Y`,
					value: B,
					min: I.min,
					max: I.max,
					step: I.step,
					disabled: M,
					onCommit: (e) => O(e, "y")
				})]
			}),
			/* @__PURE__ */ x(h, { value: W }),
			/* @__PURE__ */ x(g, { message: N ? D("Cannot compute", "无法计算") : k })
		]
	});
}
export { w as t };
