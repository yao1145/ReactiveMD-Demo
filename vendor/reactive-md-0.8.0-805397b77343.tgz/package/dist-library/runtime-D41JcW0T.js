import { dt as e } from "./preset-core-CKc5YXSM.js";
import { a as t, l as n, w as r } from "./registry-core-CwQvif0w.js";
import { F as i, O as a, j as o } from "./config-validation-BLmgvFIS.js";
import { J as s, Q as c, Y as l, Z as u, a as d, c as f, i as p, n as m, o as h, r as g, t as _, w as v } from "./validation-BPmsZ5G9.js";
import { a as y, o as b, r as ee, s as x, t as S } from "./expression-By9QMkMR.js";
import { t as C } from "./registry-B-xSD10y.js";
import { C as te, E as ne, n as w } from "./network-Ca3GAJua.js";
import { n as T } from "./runtime-BxsXfFBM.js";
// src/local/runtime/retention.ts
function E(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of u(e.nodes)) t.set(n.id, n);
	return t;
}
function D(e, t, n) {
	let r = e.bindingSlots?.[t.id];
	return r !== void 0 && Object.values(r).includes(n);
}
function O(e, t, n) {
	let r = t.name ? C(t.name) : void 0;
	if (r?.bindings) {
		let i = e.bindingSlots?.[t.id];
		for (let [e, a] of Object.entries(r.bindings)) if (t.attrs?.[a.bind] === n || e !== "value" && i?.[e] === n) return a.retain === !1 ? void 0 : a.initial;
	} else if (t.attrs?.bind === n || D(e, t, n)) return "initial";
}
function k(e) {
	let t = E(e), r = n(e), i = new Set(r?.retentionExclusions ?? []), a = /* @__PURE__ */ new Map();
	for (let [n, o] of Object.entries(e.bindings)) {
		let s = o.nodeIds.flatMap((e) => {
			let n = t.get(e);
			return n ? [n] : [];
		});
		if (!s.length || n.startsWith("@") || i.has(n)) continue;
		let c;
		if (r === void 0) {
			let t = s.map((t) => O(e, t, n));
			if (t.some((e) => e === void 0)) continue;
			c = t;
		} else {
			let e = r.bindingAttributes?.[n]?.initial ?? "initial";
			c = s.map(() => e);
		}
		let l = s.flatMap((e, t) => Object.hasOwn(e.attrs ?? {}, c[t]) ? [e.attrs[c[t]]] : []).sort();
		a.set(n, {
			type: o.type,
			initialDefinition: JSON.stringify([o.initial, l])
		});
	}
	return a;
}
function A(e, t) {
	return Object.freeze({
		name: e,
		reason: t
	});
}
function re(e) {
	let t = k(e.previous), n = k(e.next), r = {}, i = [], a = [];
	for (let o of Object.keys(e.state).sort()) {
		if (o.startsWith("@")) {
			a.push(A(o, "internal"));
			continue;
		}
		if (!Object.hasOwn(e.previous.bindings, o) || !Object.hasOwn(e.next.bindings, o)) {
			a.push(A(o, "unknown"));
			continue;
		}
		let s = t.get(o), c = n.get(o);
		if (!s || !c) {
			a.push(A(o, "unretainable"));
			continue;
		}
		if (s.type !== c.type) {
			a.push(A(o, "type"));
			continue;
		}
		if (s.initialDefinition !== c.initialDefinition) {
			a.push(A(o, "initial"));
			continue;
		}
		let l = e.state[o];
		r[o] = Array.isArray(l) ? Object.freeze([...l]) : l, i.push(o);
	}
	return Object.freeze({
		values: Object.freeze(r),
		retained: Object.freeze(i),
		dropped: Object.freeze(a)
	});
}
function j(e, t, n) {
	return Object.freeze({
		retained: Object.freeze([...e]),
		dropped: Object.freeze(t.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...n])
	});
}
function M(e, t) {
	let n = Object.keys(t.values).sort();
	if (!e.setParameters(t.values).length) return j(n, t.dropped, []);
	let r = [], i = n, a = [];
	for (; i.length;) {
		let n = [];
		a = [];
		for (let o of i) {
			let i = e.setParameter(o, t.values[o]);
			i.length ? (n.push(o), a.push(...i)) : r.push(o);
		}
		if (n.length === i.length) break;
		i = n;
	}
	r.sort();
	let o = [...t.dropped, ...i.map((e) => A(e, "invalid"))];
	return o.sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name)), j(r, o, a);
}
// src/local/runtime/runtime.ts
var N = 1e-9, ie = 200;
function P(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function ae(e) {
	return {
		...e,
		range: { ...e.range }
	};
}
function F(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => e === t[n]) : e === t;
}
function I(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= N * Math.max(1, Math.abs(r));
}
function oe(e) {
	for (let [t, n] of Object.entries(e)) Array.isArray(n) && !Object.isFrozen(n) && (e[t] = Object.freeze([...n]));
	return Object.freeze(e);
}
function L(e, t, n, r) {
	let i = Math.max(0, Math.min(e.source.length, t.range.start)), o = e.source.slice(0, i).split("\n");
	return {
		code: n,
		message: a(r),
		severity: "error",
		range: {
			start: i,
			end: Math.max(i + 1, Math.min(e.source.length, t.range.end))
		},
		line: o.length,
		column: (o.at(-1) ?? "").length + 1,
		messageKey: r.key,
		...r.params ? { params: r.params } : {}
	};
}
function R(e, t, n) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1,
		...n ? {
			messageKey: n.key,
			...n.params ? { params: n.params } : {}
		} : {}
	};
}
function z(e, t) {
	return e.attrs?.[t];
}
function B(e, t) {
	let n = z(e, t);
	if (n === "true") return !0;
	if (n === "false") return !1;
}
function V(e, t) {
	let n = z(e, t);
	if (n === void 0) return;
	let r = Number(n);
	return Number.isFinite(r) ? r : void 0;
}
function H(e) {
	return i(e);
}
function U(e, t) {
	return {
		ok: !1,
		detail: o(e, t)
	};
}
function W(e, t) {
	if (t !== void 0) return z(e, t);
}
function se(e, t) {
	if (t !== void 0) return V(e, t);
}
function G(n, r, i, a = {}) {
	for (let o of i) if (o.kind === "date") {
		if (!t(r)) return U("local.runtime.value.date-invalid");
		let e = a.required ?? (o.required !== void 0 && B(n, o.required) === !0);
		if (r === "" && e) return U("local.runtime.value.date-required");
		let i = a.min ?? W(n, o.min), s = a.max ?? W(n, o.max);
		if (r !== "" && i && r < i) return U("local.runtime.value.date-earlier", { min: i });
		if (r !== "" && s && r > s) return U("local.runtime.value.date-later", { max: s });
	} else if (o.kind === "required") {
		let e = a.required ?? B(n, o.required) === !0;
		if (r === "" && e) return U("local.runtime.value.field-required");
	} else if (o.kind === "length") {
		let e = H(r), t = se(n, o.min), i = se(n, o.max);
		if (t !== void 0 && t > 0 && r !== "" && e < t) return U("local.runtime.value.min-length", { min: t });
		if (i !== void 0 && e > i) return U("local.runtime.value.max-length", { max: i });
	} else if (o.kind === "email" && (W(n, o.type) ?? "text") === o.value && r !== "") {
		if (r.length > 254) return U("local.runtime.value.email-length", { limit: 254 });
		if (!e(r)) return U("local.runtime.value.email-invalid");
	}
	return {
		ok: !0,
		value: r
	};
}
var K = /* @__PURE__ */ new Map();
function q(e) {
	if (!e.name) return J;
	let t = K.get(e.name);
	if (t !== void 0) return t ?? J;
	let n = C(e.name), i = n ? r(n) : J;
	return K.set(e.name, n ? i : null), i;
}
var J = Object.freeze([]);
function Y(e, n, r, i, o, s = !1) {
	switch (e.type) {
		case "number": {
			if (typeof r != "number" || !Number.isFinite(r)) return U("local.runtime.value.finite-number", { name: e.name });
			let t = e.step ?? 1, a = e.min ?? 0;
			for (let t of n) {
				let n = i(t, "min");
				if (n.present && !n.ok) return U("local.runtime.value.constraint", {
					name: e.name,
					attribute: "min"
				});
				if (n.present && n.ok) {
					if (typeof n.value != "number" || !Number.isFinite(n.value)) return U("local.runtime.value.constraint", {
						name: e.name,
						attribute: "min"
					});
					if (a = n.value, r < n.value) return U("local.runtime.value.min", {
						name: e.name,
						min: n.value
					});
				}
				let o = i(t, "max");
				if (o.present && !o.ok) return U("local.runtime.value.constraint", {
					name: e.name,
					attribute: "max"
				});
				if (o.present && o.ok) {
					if (typeof o.value != "number" || !Number.isFinite(o.value)) return U("local.runtime.value.constraint", {
						name: e.name,
						attribute: "max"
					});
					if (r > o.value) return U("local.runtime.value.max", {
						name: e.name,
						max: o.value
					});
				}
				if (n.present && n.ok && o.present && o.ok && typeof n.value == "number" && typeof o.value == "number" && n.value > o.value) return U("local.runtime.value.constraint-range", { name: e.name });
			}
			return e.min !== void 0 && r < e.min ? U("local.runtime.value.min", {
				name: e.name,
				min: e.min
			}) : e.max !== void 0 && r > e.max ? U("local.runtime.value.max", {
				name: e.name,
				max: e.max
			}) : t > 0 && !I(r, a, t) ? U("local.runtime.value.step", {
				name: e.name,
				step: t,
				base: a
			}) : {
				ok: !0,
				value: r
			};
		}
		case "boolean": return typeof r == "boolean" ? {
			ok: !0,
			value: r
		} : U("local.runtime.value.boolean", { name: e.name });
		case "string": {
			if (typeof r != "string") return U("local.runtime.value.string", { name: e.name });
			let c = x(r);
			if (c) return U("local.runtime.value.budget", {
				name: e.name,
				detail: a(c),
				detailKey: c.key,
				...c.params
			});
			for (let a of n) {
				let n = o?.get(a.id) ?? (s ? q(a) : J);
				if (!n.length) continue;
				let c = {};
				for (let r of n) {
					if (r.kind === "date") {
						for (let n of ["min", "max"]) {
							if (r[n] === void 0) continue;
							let o = i(a, n);
							if (o.present) {
								if (!o.ok || typeof o.value != "string" || !t(o.value)) return U("local.runtime.value.constraint-date", {
									name: e.name,
									attribute: n
								});
								c[n] = o.value;
							}
						}
						let n = c.min ?? W(a, r.min), o = c.max ?? W(a, r.max);
						if (n && o && t(n) && t(o) && n > o) return U("local.runtime.value.constraint-range", { name: e.name });
					}
					if ((r.kind === "date" || r.kind === "required" ? r.required : void 0) !== void 0) {
						let t = i(a, "required");
						if (t.present) {
							if (!t.ok || typeof t.value != "boolean") return U("local.runtime.value.constraint", {
								name: e.name,
								attribute: "required"
							});
							c.required = t.value;
						}
					}
				}
				let l = G(a, r, n, c);
				if (!l.ok) return l;
			}
			return e.options?.length && !e.options.includes(r) ? U("local.runtime.value.option", {
				value: r,
				options: e.options.join(", ")
			}) : {
				ok: !0,
				value: r
			};
		}
		case "array": {
			if (!Array.isArray(r)) return U("local.runtime.value.array", { name: e.name });
			let t = x(r);
			if (t) return U("local.runtime.value.budget", {
				name: e.name,
				detail: a(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of r) if (typeof t != "string") return U("local.runtime.value.array-members", { name: e.name });
			if (e.family === "collection") return e.maxItems !== void 0 && r.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: r.slice()
			};
			let n = /* @__PURE__ */ new Set();
			for (let t of r) {
				if (e.options && !e.options.includes(t)) return U("local.runtime.value.checklist-option", { value: t });
				n.add(t);
			}
			let i = e.options ? e.options.filter((e) => n.has(e)) : [...n];
			return e.maxItems !== void 0 && i.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: i
			};
		}
		case "number-array": {
			if (!Array.isArray(r)) return U("local.runtime.value.number-array", { name: e.name });
			let t = x(r);
			if (t) return U("local.runtime.value.budget", {
				name: e.name,
				detail: a(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of r) if (typeof t != "number" || !Number.isFinite(t)) return U("local.runtime.value.number-array-members", { name: e.name });
			return e.maxItems !== void 0 && r.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: r.slice()
			};
		}
		case "null": return r === null ? {
			ok: !0,
			value: r
		} : U("local.runtime.value.null", { name: e.name });
	}
	return U("local.runtime.value.unsupported-type", { name: e.name });
}
function X(e) {
	return e instanceof S ? e : new S("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function ce(e, t) {
	switch (e) {
		case "string": {
			if (typeof t != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string" }
			};
			let e = x(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t
			};
		}
		case "number": return typeof t == "number" && Number.isFinite(t) ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "number" }
		};
		case "boolean": return typeof t == "boolean" ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "boolean" }
		};
		case "array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			for (let e of t) if (typeof e != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			let e = x(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		case "number-array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			for (let e of t) if (typeof e != "number" || !Number.isFinite(e)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			let e = x(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		default: return {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: String(e) }
		};
	}
}
function le(e, t) {
	let n = e.document.bindings[t];
	if (!n) return;
	let { nodeIds: r, owner: i, ...a } = n, o = (e.controls.get(t) ?? []).map((t) => {
		let n = e.document.dynamicConstraints?.[t.id] ?? {};
		return {
			name: t.name ?? null,
			attrs: t.attrs ?? {},
			dynamic: Object.fromEntries(Object.entries(n).map(([e, t]) => [e, t ? {
				source: t.source,
				numeric: t.numeric ?? null
			} : null])),
			rules: e.valueRules.get(t.id) ?? null
		};
	});
	return JSON.stringify({
		facts: a,
		legacy: e.legacyValueRules,
		controls: o
	});
}
function ue(e, t) {
	let n = t.get(e);
	if (n) return {
		expression: n,
		error: null
	};
	try {
		let n = ee(e);
		if (t.size >= ie) {
			let e = t.keys().next().value;
			e !== void 0 && t.delete(e);
		}
		return t.set(e, n), {
			expression: n,
			error: null
		};
	} catch (e) {
		return {
			expression: null,
			error: X(e)
		};
	}
}
function de(e, t) {
	let r = /* @__PURE__ */ new Map();
	for (let t of u(e.nodes)) r.set(t.id, t);
	let i = {}, o = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) {
		let e = x(n.initial);
		if (e) throw new S("expression-budget", `Parameter "${t}": ${a(e)}`, 0);
		i[t] = P(n.initial);
		let s = [];
		for (let e of n.nodeIds) {
			let t = r.get(e);
			t && s.push(t);
		}
		o.set(t, s);
	}
	let s = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots ?? {})) s.set(t, { ...n });
	let c = n(e), f = new Map(Object.entries(c?.valueRules ?? {})), p = c === void 0, m = /* @__PURE__ */ new Map();
	if (c) for (let e of c.slotRelations) {
		let t = s.get(e.nodeId), n = t?.[e.lower], r = t?.[e.upper];
		if (!n || !r) continue;
		let i = m.get(e.nodeId) ?? [];
		i.push({
			lower: n,
			upper: r
		}), m.set(e.nodeId, i);
	}
	else for (let [e, t] of s) t.start && t.end && m.set(e, [{
		lower: t.start,
		upper: t.end
	}]);
	let g = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) for (let e of n.nodeIds) {
		if (s.has(e)) continue;
		let n = g.get(e);
		(n === void 0 || n.startsWith("@") && !t.startsWith("@")) && g.set(e, t);
	}
	let _ = Object.freeze(Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort()), v = /* @__PURE__ */ new Map();
	for (let [e, t] of s) for (let n of Object.values(t)) {
		if (n.startsWith("@")) continue;
		let t = v.get(n) ?? /* @__PURE__ */ new Set();
		t.add(e), v.set(n, t);
	}
	let y = e.computations ?? {}, ee = Object.keys(y), C = /* @__PURE__ */ new Map();
	for (let [e, n] of Object.entries(y)) {
		let r = ue(n.source, t);
		r.expression && C.set(e, r.expression);
	}
	let { order: te, cyclic: ne } = l(y), w = {}, T = /* @__PURE__ */ new Map();
	for (let e of te) {
		let t = y[e];
		if (!t || t.kind !== "const") continue;
		if (Object.hasOwn(t, "value")) {
			let n = t.value, r = b(n);
			if (r) {
				T.set(e, new S("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			w[e] = P(n);
			continue;
		}
		let n = C.get(e);
		if (!n) T.set(e, new S("expression-eval", `Constant "${e}" cannot be evaluated.`, 0));
		else try {
			let t = n.evaluate({ ...w }), r = b(t);
			if (r) {
				T.set(e, new S("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			w[e] = P(t);
		} catch (t) {
			T.set(e, X(t));
		}
	}
	let E = /* @__PURE__ */ new Map();
	for (let e of ne) E.set(e, new S("expression-cycle", `Computation "${e}" is part of a dependency cycle.`, 0));
	let D = [];
	if (Array.isArray(e.validations)) for (let n of e.validations) {
		if (!d(n)) continue;
		let e = ue(n.expression, t);
		D.push({
			rule: n,
			expression: e.expression,
			error: e.error
		});
	}
	return {
		document: e,
		nodeIndex: r,
		controls: o,
		slotKeys: s,
		publicNames: _,
		publicSlotOwners: v,
		initial: i,
		valueRules: f,
		legacyValueRules: p,
		slotRelations: m,
		bindingByNode: g,
		computationMetadata: y,
		computationNames: ee,
		computationOrder: te,
		cyclicComputations: ne,
		computationExpressions: C,
		constValues: w,
		constErrors: T,
		cycleErrors: E,
		validationRules: D,
		validationLineStarts: h(typeof e.source == "string" ? e.source : "")
	};
}
function fe(e) {
	return !e || e.syntax !== "local" ? "createLocalRuntime requires a local interaction document." : e.syntaxVersion !== void 0 && e.syntaxVersion !== "local-draft-3" || e.versionDeclaration && e.versionDeclaration.version !== "local-draft-3" ? `createLocalRuntime requires ${v}; migrate the source before constructing a runtime.` : null;
}
function Z(e, t) {
	return (e.controls.get(t.name) ?? [])[0] ?? (t.owner ? e.nodeIndex.get(t.owner) : void 0) ?? (t.nodeIds[0] ? e.nodeIndex.get(t.nodeIds[0]) : void 0);
}
function pe(e, t, n) {
	let r = Z(e, t);
	return r ? L(e.document, r, "local.runtime.value", n) : R("local.runtime.value", a(n));
}
function Q(e, t, n) {
	let r = e.slotRelations.get(t);
	return r?.length ? r.some(({ lower: e, upper: t }) => {
		let r = n[e], i = n[t];
		return typeof r == "number" && typeof i == "number" && r > i;
	}) : !1;
}
function me(e, t) {
	let n = e.nodeIndex.get(t);
	return n ? L(e.document, n, "local.runtime.value", o("local.runtime.value.range-order")) : R("local.runtime.value", a(o("local.runtime.value.range-order")));
}
var he = /* @__PURE__ */ new WeakMap();
function $(e) {
	return Object.freeze({
		ok: e.ok,
		changed: e.changed,
		revision: e.revision,
		retained: Object.freeze([...e.retained]),
		dropped: Object.freeze(e.dropped.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...e.diagnostics])
	});
}
function ge(e, t, n) {
	let r = he.get(e);
	if (!r) throw TypeError("updateLocalRuntime requires a runtime created by createLocalRuntime.");
	return r.update(t, n?.notify !== !1);
}
function _e(e) {
	he.get(e)?.notify();
}
function ve(e, t) {
	let n = fe(e);
	if (n) throw Error(n);
	let r = t?.services === void 0, i = w(t?.network), l = /* @__PURE__ */ new Map(), d = ne(e.source), h = /* @__PURE__ */ new Map(), v = /* @__PURE__ */ new Map(), b = de(e, v), C = () => b, E = () => {
		let e = /* @__PURE__ */ new Set();
		for (let n of u(b.document.nodes)) n.name !== void 0 && e.add(te({
			documentId: t?.documentId,
			sourceDigest: d,
			nodeId: n.id,
			stateKey: n.attrs?.["state-key"]
		}));
		return e;
	}, D = t?.services ?? T({
		documentId: t?.documentId,
		sourceDigest: d,
		randomSeed: t?.randomSeed,
		componentState: t?.componentState,
		...t?.componentStateStorage === void 0 ? {} : { componentStateStorage: t.componentStateStorage },
		...t?.componentStateWriteDelayMs === void 0 ? {} : { componentStateWriteDelayMs: t.componentStateWriteDelayMs },
		...t?.configKey === void 0 ? {} : { configKey: t.configKey },
		...t?.legacyConfigKeys === void 0 ? {} : { legacyConfigKeys: t.legacyConfigKeys },
		...r ? { knownStateKeys: E } : {}
	}), O = {};
	for (let [n, r] of Object.entries(e.externals ?? {})) {
		let e = t?.externalValues?.[n];
		if (e === void 0) continue;
		let i = ce(r.type, e);
		i.ok && (O[n] = i.value);
	}
	let k = (e) => {
		let t = {};
		for (let [n, r] of Object.entries(e.document.externals ?? {})) {
			if (!Object.hasOwn(O, n)) continue;
			let e = ce(r.type, O[n]);
			e.ok && (t[n] = e.value);
		}
		return t;
	}, A = (e, t, n, r = C()) => {
		let i = r.document.dynamicConstraints?.[e.id]?.[t];
		if (!i) return { present: !1 };
		let a = ue(i.source, v);
		if (!a.expression) return {
			present: !0,
			ok: !1
		};
		try {
			let e = a.expression.evaluate(n), t = i.numeric;
			return t && (typeof e != "number" || !Number.isFinite(e) || t.integer === !0 && !Number.isInteger(e) || t.min !== void 0 && e < t.min || t.max !== void 0 && e > t.max) ? {
				present: !0,
				ok: !1
			} : {
				present: !0,
				ok: !0,
				value: e
			};
		} catch {
			return {
				present: !0,
				ok: !1
			};
		}
	}, j = b.initial, M = 0, N = {}, I = {}, z = {
		revision: 0,
		state: oe({})
	}, B = !1, V = null, H = /* @__PURE__ */ new Set(), U = /* @__PURE__ */ new Map(), W = () => {
		if (B) throw Error("The local interaction runtime has been disposed.");
	};
	function se(e, t) {
		if (!t.startsWith("@") && Object.hasOwn(e.document.bindings, t)) return Object.hasOwn(j, t) ? j[t] : void 0;
	}
	let G = (e, t) => {
		let n = k(e), r = /* @__PURE__ */ new Map();
		for (let t of Object.keys(e.document.externals ?? {})) Object.hasOwn(n, t) || r.set(t, new S("external-missing", "External data \"" + t + "\" is not available.", 0));
		let i = {}, a = /* @__PURE__ */ new Map();
		if (e.computationNames.length > 0) {
			let o = s(e.computationMetadata, e.computationOrder, e.computationExpressions, {
				...t,
				...n
			}, e.constValues, r);
			i = o.values, a = o.errors;
			for (let [t, n] of e.constErrors) Object.hasOwn(i, t) || a.set(t, n);
			for (let [t, n] of e.cycleErrors) Object.hasOwn(i, t) || a.set(t, n);
		}
		let o = {};
		for (let [e, n] of Object.entries(t)) o[e] = n;
		for (let [e, t] of Object.entries(n)) o[e] = t;
		for (let [e, t] of Object.entries(i)) o[e] = t;
		for (let [e, t] of [...r, ...a]) Object.hasOwn(i, e) || Object.defineProperty(o, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw t;
			}
		});
		let c = {};
		for (let [e, n] of Object.entries(t)) c[e] = n;
		for (let [e, t] of Object.entries(n)) c[e] = t;
		for (let [e, t] of Object.entries(i)) c[e] = t;
		return {
			environment: o,
			snapshotState: c
		};
	}, K = () => {
		let e = G(C(), j);
		N = e.environment, I = e.snapshotState;
	}, q = (e, t = C(), n = j) => {
		let r;
		return (i, a) => t.document.dynamicConstraints?.[i.id]?.[a] ? (r ??= G(t, {
			...n,
			...e
		}).environment, A(i, a, r, t)) : { present: !1 };
	}, J = () => {
		z = {
			revision: M,
			state: oe(I)
		};
	}, X = () => {
		for (let e of H) e();
	}, Z = (e) => {
		j = e, M += 1, K(), J(), X();
	}, ge = (e) => {
		if (W(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setExternalValues requires an object of external values.");
		let t = [], n = {}, r = Object.keys(e).sort();
		for (let i of r) {
			if (i === "__proto__") {
				t.push(R("local.runtime.external", "External names cannot be \"__proto__\"."));
				continue;
			}
			let r = C().document.externals ?? {}, s = Object.hasOwn(r, i) ? r[i] : void 0;
			if (!s) {
				let e = o("local.runtime.external", { name: i });
				t.push(R("local.runtime.external", a(e), e));
				continue;
			}
			let c = ce(s.type, e[i]);
			if (c.ok) n[i] = c.value;
			else {
				let e = o(c.key, {
					name: i,
					...c.params ?? {}
				});
				t.push(R("local.runtime.external", a(e), e));
			}
		}
		if (t.length) return t;
		if (!r.some((e) => !F(O[e], n[e]))) return [];
		for (let [e, t] of Object.entries(n)) O[e] = t;
		return M += 1, K(), J(), X(), [];
	}, _e = (e) => {
		W();
		let t = C(), n = [], r = {}, i = Object.keys(e).sort(), a = q(e);
		for (let o of i) {
			if (o === "__proto__") {
				n.push(R("local.runtime.parameter", "Parameter names cannot be \"__proto__\"."));
				continue;
			}
			if (o.startsWith("@")) {
				n.push(R("local.runtime.parameter", `Internal parameter "${o}" cannot be written by name.`));
				continue;
			}
			if (!Object.hasOwn(t.document.bindings, o)) {
				n.push(R("local.runtime.parameter", `Unknown parameter "${o}".`));
				continue;
			}
			let i = t.document.bindings[o], s = Y(i, t.controls.get(o) ?? [], e[o], a, t.valueRules, t.legacyValueRules);
			s.ok ? r[o] = P(s.value) : n.push(pe(t, i, s.detail));
		}
		if (n.length) return n;
		if (!i.some((e) => !F(j[e], r[e]))) return [];
		let o = {
			...j,
			...r
		}, s = /* @__PURE__ */ new Set();
		for (let e of i) for (let n of t.publicSlotOwners.get(e) ?? []) s.add(n);
		for (let e of [...s].sort()) Q(t, e, o) && n.push(me(t, e));
		return n.length ? n : (Z(o), []);
	}, ve = (e) => {
		let t = h.get(e);
		if (!t) {
			if (t = ee(e), h.size >= ie) {
				let e = h.keys().next().value;
				e !== void 0 && h.delete(e);
			}
			h.set(e, t);
		}
		return t;
	}, ye = () => {
		let e = C(), t = [], n = typeof e.document.source == "string" ? e.document.source : "";
		for (let r of e.validationRules) {
			if (r.error) {
				t.push(f(n, e.validationLineStarts, r.rule.range, _, p(`Validation expression is invalid: ${r.error.message}`)));
				continue;
			}
			if (!r.expression) continue;
			let i;
			try {
				i = r.expression.evaluate(N);
			} catch (i) {
				t.push(f(n, e.validationLineStarts, r.rule.range, _, p(`Validation expression failed: ${i instanceof Error ? i.message : String(i)}`)));
				continue;
			}
			typeof i == "boolean" ? i || t.push(f(n, e.validationLineStarts, r.rule.range, m, be(r.rule.message))) : t.push(f(n, e.validationLineStarts, r.rule.range, _, "Validation expression must evaluate to a boolean."));
		}
		return t;
	}, be = (e) => {
		let t;
		try {
			t = y(e, N);
		} catch {
			t = g;
		}
		return p(t);
	}, xe = (e, t) => {
		let n = re({
			previous: b.document,
			state: j,
			next: e
		}), r = {};
		for (let [t, n] of Object.entries(e.bindings)) r[t] = P(n.initial);
		let i = /* @__PURE__ */ new Map();
		for (let e of n.dropped) i.set(e.name, Object.freeze({ ...e }));
		let a = [], o = {}, s = [], c = /* @__PURE__ */ new Set(), l, u = (e) => {
			let r = b.document.bindings[e], i = b.controls.get(e) ?? [];
			return !r || !i.some((e) => b.document.dynamicConstraints?.[e.id]) || (l ??= q({}, b, j), Y(r, i, n.values[e], l, b.valueRules, b.legacyValueRules).ok) ? !1 : le(b, e) === le(t, e);
		};
		for (let l of n.retained) {
			let d = e.bindings[l];
			if (!d) continue;
			if (u(l)) {
				c.add(l), o[l] = P(n.values[l]), s.push(l);
				continue;
			}
			let f = Y(d, t.controls.get(l) ?? [], n.values[l], q(n.values, t, r), t.valueRules, t.legacyValueRules);
			f.ok ? (o[l] = P(f.value), s.push(l)) : (a.push(pe(t, d, f.detail)), i.set(l, Object.freeze({
				name: l,
				reason: "invalid"
			})));
		}
		let d = {
			...r,
			...o
		}, f = /* @__PURE__ */ new Set();
		for (let e of s) for (let n of t.publicSlotOwners.get(e) ?? []) f.add(n);
		let p = !1;
		for (let e of [...f].sort()) if (Q(t, e, d)) {
			p = !0;
			break;
		}
		let m;
		if (!p) Object.assign(r, o), m = s;
		else {
			m = [];
			for (let e of s) {
				let n = r[e];
				r[e] = o[e];
				let s = !1;
				for (let n of [...t.publicSlotOwners.get(e) ?? []].sort()) Q(t, n, r) && (a.push(me(t, n)), s = !0);
				s ? (r[e] = n, i.set(e, Object.freeze({
					name: e,
					reason: "invalid"
				}))) : m.push(e);
			}
		}
		for (let [n, o] of t.slotRelations) if (Q(t, n, r)) {
			for (let t of o) for (let n of [t.lower, t.upper]) {
				let t = e.bindings[n];
				if (!t) continue;
				r[n] = P(t.initial);
				let a = m.indexOf(n);
				a >= 0 && m.splice(a, 1), i.set(n, Object.freeze({
					name: n,
					reason: "invalid"
				}));
			}
			if (a.push(me(t, n)), Q(t, n, r)) return {
				values: {},
				retained: [],
				dropped: [],
				diagnostics: []
			};
		}
		let h = !0;
		for (; h;) {
			let n = q({}, t, r), o = [];
			for (let i of m) {
				if (c.has(i)) continue;
				let s = e.bindings[i], l = Y(s, t.controls.get(i) ?? [], r[i], n, t.valueRules, t.legacyValueRules);
				l.ok || (a.push(pe(t, s, l.detail)), o.push(i));
			}
			for (let t of o) r[t] = P(e.bindings[t].initial), m.splice(m.indexOf(t), 1), i.set(t, Object.freeze({
				name: t,
				reason: "invalid"
			}));
			h = o.length > 0;
		}
		let g = [...i.values()].sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name));
		return m.sort(), {
			values: r,
			retained: m,
			dropped: g,
			diagnostics: a
		};
	}, Se = (e, t) => {
		if (W(), e === b.document) return $({
			ok: !0,
			changed: !1,
			revision: M,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		if (fe(e)) return $({
			ok: !1,
			changed: !1,
			revision: M,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let n;
		try {
			n = de(e, v);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: M,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let r = xe(e, n);
		if (Object.keys(r.values).length === 0 && Object.keys(e.bindings).length > 0) return $({
			ok: !1,
			changed: !1,
			revision: M,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let i;
		try {
			i = G(n, r.values);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: M,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let a = k(n);
		for (let e of Object.keys(O)) delete O[e];
		if (Object.assign(O, a), b = n, j = r.values, N = i.environment, I = i.snapshotState, V = null, M += 1, J(), t) for (let e of H) e();
		return $({
			ok: !0,
			changed: !0,
			revision: M,
			retained: r.retained,
			dropped: r.dropped,
			diagnostics: r.diagnostics
		});
	}, Ce = (e) => {
		let t = /* @__PURE__ */ new Set();
		for (let n of u([e])) t.add(n.id);
		return t;
	}, we = {
		network: i.network,
		get document() {
			return b.document;
		},
		services: D,
		snapshot() {
			return W(), z;
		},
		get(e, t) {
			W();
			let n = C(), r = n.nodeIndex.get(e.id);
			if (!r) return null;
			let i = t === void 0 ? n.slotKeys.get(r.id)?.value ?? n.bindingByNode.get(r.id) ?? c(r) : n.slotKeys.get(r.id)?.[t];
			return i && Object.hasOwn(j, i) ? P(j[i]) : null;
		},
		set(e, t, n) {
			W();
			let r = C(), i = r.nodeIndex.get(e.id);
			if (!i) return [L(r.document, e, "local.runtime.binding", o("local.runtime.binding.no-writable"))];
			let a = r.slotKeys.get(i.id), s;
			if (n === void 0) {
				if (a && !a.value) return [L(r.document, i, "local.runtime.binding", o("local.runtime.binding.needs-slot"))];
				s = a?.value ?? r.bindingByNode.get(i.id) ?? c(i);
			} else if (s = a?.[n], !s) return [L(r.document, i, "local.runtime.binding", o("local.runtime.binding.unknown-slot", { slot: n }))];
			let l = Object.hasOwn(r.document.bindings, s) ? r.document.bindings[s] : void 0;
			if (!l) return [L(r.document, i, "local.runtime.binding", o("local.runtime.binding.no-writable"))];
			let u = Y(l, r.controls.get(s) ?? [], t, q({ [s]: t }), r.valueRules, r.legacyValueRules);
			if (!u.ok) return [L(r.document, i, "local.runtime.value", u.detail)];
			let d = P(u.value);
			if (F(j[s], d)) return [];
			let f = {
				...j,
				[s]: d
			};
			return Q(r, i.id, f) ? [L(r.document, i, "local.runtime.value", o("local.runtime.value.range-order"))] : (Z(f), []);
		},
		setMany(e, t) {
			W();
			let n = C(), r = n.nodeIndex.get(e.id);
			if (!r) return [L(n.document, e, "local.runtime.binding", o("local.runtime.binding.no-writable"))];
			let i = n.slotKeys.get(r.id);
			if (!i) return [L(n.document, r, "local.runtime.binding", o("local.runtime.binding.no-multi-slot"))];
			let a = Object.entries(t);
			if (!a.length) return [];
			let s = { ...j }, c = G(n, {
				...j,
				...Object.fromEntries(a.map(([e, t]) => [i[e], t]))
			}).environment;
			for (let [e, t] of a) {
				let a = i[e];
				if (!a || !Object.hasOwn(n.document.bindings, a)) return [L(n.document, r, "local.runtime.binding", o("local.runtime.binding.unknown-slot", { slot: e }))];
				let l = Y(n.document.bindings[a], n.controls.get(a) ?? [], t, (e, t) => A(e, t, c), n.valueRules, n.legacyValueRules);
				if (!l.ok) return [L(n.document, r, "local.runtime.value", l.detail)];
				s[a] = P(l.value);
			}
			return Q(n, r.id, s) ? [L(n.document, r, "local.runtime.value", o("local.runtime.value.range-order"))] : (a.every(([e, t]) => F(j[i[e]], t)) || Z(s), []);
		},
		parameterNames() {
			return W(), C().publicNames;
		},
		getParameter(e) {
			W();
			let t = se(C(), e);
			return t === void 0 ? void 0 : P(t);
		},
		getParameters() {
			W();
			let e = C(), t = {};
			for (let n of e.publicNames) {
				let e = j[n];
				t[n] = Array.isArray(e) ? Object.freeze([...e]) : e;
			}
			return Object.freeze(t);
		},
		readSubmissionFields(e) {
			W();
			let t = C(), n = /* @__PURE__ */ new Map(), r = (e, n) => A(e, n, N, t);
			if (e.length === 0) return {
				ok: !1,
				field: "",
				reason: "unavailable"
			};
			for (let i of e) {
				let e = se(t, i);
				if (e === void 0 || n.has(i)) return {
					ok: !1,
					field: i,
					reason: "unavailable"
				};
				let a = Y(t.document.bindings[i], t.controls.get(i) ?? [], e, r, t.valueRules, t.legacyValueRules);
				if (!a.ok) {
					let e = a.detail.key;
					return {
						ok: !1,
						field: i,
						reason: e === "local.runtime.value.field-required" || e === "local.runtime.value.date-required" ? "required" : "invalid"
					};
				}
				n.set(i, e);
			}
			let i = Object.create(null);
			for (let [e, r] of n) {
				for (let [n, i] of l.get(e) ?? []) {
					if (!t.controls.get(e)?.some((e) => e.id === i)) continue;
					let a = n(P(r));
					if (a) return {
						ok: !1,
						field: e,
						reason: a
					};
				}
				i[e] = Array.isArray(r) ? Object.freeze([...r]) : r;
			}
			return {
				ok: !0,
				payload: Object.freeze(i)
			};
		},
		registerSubmissionField(e, t) {
			if (B) return () => {};
			let n = C(), r = n.slotKeys.get(e.id)?.value ?? n.bindingByNode.get(e.id);
			if (!r || r.startsWith("@")) return () => {};
			let i = l.get(r);
			return i || l.set(r, i = /* @__PURE__ */ new Map()), i.set(t, e.id), () => {
				i.delete(t), i.size === 0 && l.get(r) === i && l.delete(r);
			};
		},
		setParameter(e, t) {
			W();
			let n = Object.create(null);
			return n[e] = t, _e(n);
		},
		setParameters(e) {
			if (W(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setParameters requires an object of parameter values.");
			return _e(e);
		},
		getExternal(e) {
			if (W(), Object.hasOwn(C().document.externals ?? {}, e) && Object.hasOwn(O, e)) return P(O[e]);
		},
		getExternalValues() {
			W();
			let e = {};
			for (let [t, n] of Object.entries(O)) e[t] = Array.isArray(n) ? Object.freeze([...n]) : n;
			return Object.freeze(e);
		},
		setExternalValues(e) {
			return ge(e);
		},
		evaluate(e) {
			W();
			let t = ve(e).evaluate(N);
			return Array.isArray(t) ? t.slice() : t;
		},
		validate() {
			if (W(), V && V.revision === M) return V.diagnostics.map(ae);
			let e = ye();
			return V = {
				revision: M,
				diagnostics: e
			}, e.map(ae);
		},
		text(e) {
			return W(), y(e, N);
		},
		reset(e) {
			W();
			let t = C(), n = t.nodeIndex.get(e.id);
			if (!n) return;
			let r = Ce(n), i = { ...j };
			for (let [e, n] of Object.entries(t.document.bindings)) {
				if (!(t.controls.get(e) ?? []).some((e) => r.has(e.id))) continue;
				let o = x(n.initial);
				if (o) throw new S("expression-budget", `Parameter "${e}": ${a(o)}`, 0);
				i[e] = P(n.initial);
			}
			for (let e of r) U.set(e, (U.get(e) ?? 0) + 1);
			Z(i);
		},
		resetToken(e) {
			W();
			let t = C().nodeIndex.get(e.id);
			return t ? U.get(t.id) ?? 0 : 0;
		},
		subscribe(e) {
			return W(), H.add(e), () => {
				H.delete(e);
			};
		},
		dispose() {
			B || (B = !0, i.dispose(), l.clear(), D.state.flush(), r && D.scheduler.dispose(), H.clear(), h.clear(), v.clear(), b.computationExpressions.clear(), b.constErrors.clear(), b.cycleErrors.clear(), b.validationRules.length = 0, U.clear());
		}
	};
	return he.set(we, {
		update: Se,
		notify() {
			if (!B) for (let e of H) e();
		}
	}), K(), J(), we;
}
export { re as a, M as i, _e as n, ge as r, ve as t };
