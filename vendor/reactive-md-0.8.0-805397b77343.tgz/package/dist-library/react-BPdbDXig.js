import { n as e } from "./sdk-core-DSJFgLTA.js";
import { a as t } from "./LocalDocumentView-Ck7298oc.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
