import { D as e, c as t } from "./network-Ca3GAJua.js";
// src/runtime-services/browser/duplex.ts
var n = 15e3, r = 65536, i = Object.freeze({
	code: "cancelled",
	message: "The operation was cancelled."
}), a = Object.freeze({
	code: "transport",
	message: "The channel could not communicate with its endpoint."
}), o = Object.freeze({
	code: "unconfirmed",
	message: "The submission was sent but was not confirmed."
}), s = Object.freeze({
	code: "invalid-data",
	message: "The channel received invalid data."
}), c = Object.freeze([]), l = 2048, u = 16, d = 200, f = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/, p = /[\u0000-\u001f\u007f]/, m = /[\u0000-\u001f\u007f]+/g, h = {
	setTimeout(e, t) {
		return globalThis.setTimeout(e, t);
	},
	clearTimeout(e) {
		globalThis.clearTimeout(e);
	}
};
function g(e) {
	return {
		ok: !1,
		error: e
	};
}
function _(e, t, n) {
	if (e === void 0) return n;
	if (typeof e != "number" || !Number.isSafeInteger(e) || e < 1) throw TypeError(`${t} must be a positive integer.`);
	return e;
}
function v(e, t, n) {
	if (e === void 0) return n;
	if (typeof e != "number" || !Number.isSafeInteger(e) || e < 0) throw TypeError(`${t} must be a non-negative integer.`);
	return e;
}
function y(e) {
	if (e === void 0) return c;
	let t = typeof e == "string" ? [e] : Array.isArray(e) ? e : void 0;
	if (t === void 0 || t.length > u) throw TypeError(`protocols must be a string or an array of at most ${u} tokens.`);
	let n = [];
	for (let e of t) {
		if (typeof e != "string" || !f.test(e)) throw TypeError("Each WebSocket subprotocol must be a non-empty HTTP token.");
		if (n.includes(e)) throw TypeError("WebSocket subprotocols must be unique.");
		n.push(e);
	}
	return Object.freeze(n);
}
function b(e) {
	if (typeof e != "string" || e.length === 0 || e !== e.trim() || e.length > l) throw TypeError("endpoint must be a non-empty, trimmed ws: or wss: URL.");
	let t;
	try {
		t = new URL(e);
	} catch {
		throw TypeError("endpoint must be an absolute ws: or wss: URL.");
	}
	if (t.protocol !== "ws:" && t.protocol !== "wss:") throw TypeError("endpoint must use the ws: or wss: protocol.");
	return t.toString();
}
function x(e) {
	if (typeof e != "string") throw TypeError("endpoint must be a non-empty signaling path.");
	let t = e.trim();
	if (t.length === 0 || t.length > l || p.test(t)) throw TypeError("endpoint must be a non-empty signaling path without control characters.");
	return t;
}
function S(e) {
	if (e === void 0 || e === !1) return;
	if (e === !0) return {
		delayMs: 1e3,
		maxDelayMs: 3e4,
		attempts: Infinity
	};
	if (typeof e != "object" || !e) throw TypeError("reconnect must be a boolean or an options object.");
	let t = v(e.delayMs, "reconnect.delayMs", 1e3), n = v(e.maxDelayMs, "reconnect.maxDelayMs", 3e4);
	if (n < t) throw TypeError("reconnect.maxDelayMs must not be smaller than reconnect.delayMs.");
	let r = v(e.attempts, "reconnect.attempts", Infinity);
	if (r < 1) throw TypeError("reconnect.attempts must be at least 1.");
	return {
		delayMs: t,
		maxDelayMs: n,
		attempts: r
	};
}
function C(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function w(e, t) {
	if (!C(e)) throw TypeError(`${t} requires an options object.`);
}
function T(e) {
	if (C(e)) {
		if (e.type === "ack" && typeof e.requestId == "string") return {
			type: "ack",
			requestId: e.requestId
		};
		if (e.type === "reject" && typeof e.requestId == "string") return {
			type: "reject",
			requestId: e.requestId,
			...typeof e.message == "string" ? { message: e.message } : {}
		};
		if (e.type === "data" && "value" in e) return {
			type: "data",
			value: e.value
		};
	}
}
function E(e) {
	if (typeof e == "string") return e.length === 0 ? void 0 : JSON.parse(e);
	if (e instanceof ArrayBuffer || ArrayBuffer.isView(e)) return JSON.parse(new TextDecoder().decode(e));
}
var D = Object.freeze({
	encodeSubmit(e) {
		return JSON.stringify(e);
	},
	decode(e) {
		return T(E(e));
	}
});
function ee(e) {
	if (typeof e != "string") return "The channel rejected the submission.";
	let t = e.replace(m, " ").trim().slice(0, d);
	return t.length > 0 ? t : "The channel rejected the submission.";
}
function O(e) {
	if (typeof e == "object" && e && "data" in e) return e.data;
}
var k = new TextEncoder();
function A(e, t) {
	return typeof e == "string" ? e.length > t || k.encode(e).byteLength > t : (e instanceof ArrayBuffer || ArrayBuffer.isView(e)) && e.byteLength > t;
}
function j(e) {
	if (typeof e != "object" || !e) return;
	let t = e.release;
	if (typeof t == "function") try {
		t.call(e);
	} catch {}
}
function M(e) {
	try {
		e.dispose();
	} catch {}
}
function N(e, t) {
	let { validateSubmit: c, validateSubscribe: l } = e;
	if (c === void 0 && l === void 0) throw TypeError("A duplex channel needs validateSubmit, validateSubscribe, or both.");
	if (c !== void 0 && typeof c != "function") throw TypeError("validateSubmit must be a function.");
	if (l !== void 0 && typeof l != "function") throw TypeError("validateSubscribe must be a function.");
	let u = e.codec ?? D;
	if (typeof u != "object" || !u || typeof u.encodeSubmit != "function" || typeof u.decode != "function") throw TypeError("codec must provide encodeSubmit and decode functions.");
	let d = e.timers ?? h;
	if (typeof d != "object" || !d || typeof d.setTimeout != "function" || typeof d.clearTimeout != "function") throw TypeError("timers must provide setTimeout and clearTimeout functions.");
	let f = _(e.ackTimeoutMs, "ackTimeoutMs", n), p = _(e.connectTimeoutMs, "connectTimeoutMs", n), m = _(e.maxMessageBytes, "maxMessageBytes", r), v = e.maxBytes === void 0 ? void 0 : _(e.maxBytes, "maxBytes", 1), y = S(e.reconnect), b = /* @__PURE__ */ new Map();
	function x(e) {
		e.reconnectTimer !== void 0 && (d.clearTimeout(e.reconnectTimer), e.reconnectTimer = void 0);
	}
	function C(e) {
		x(e), e.connectTimer !== void 0 && (d.clearTimeout(e.connectTimer), e.connectTimer = void 0);
		let t = e.connecting;
		e.connecting = void 0, t !== void 0 && t.abort();
		let n = e.handle;
		e.handle = void 0, n !== void 0 && M(n);
	}
	function w(e) {
		e.subscribers.size > 0 || e.pending.size > 0 || e.waiters.length > 0 || (e.reconnectTimer !== void 0 && x(e), (e.handle !== void 0 || e.connecting !== void 0) && C(e));
	}
	function T(e) {
		e.signal.removeEventListener("abort", e.abortListener), b.delete(e.signal), e.subscribers.clear();
		for (let t of [...e.pending.values()]) t.finish(g(i));
		e.pending.clear();
		let t = e.waiters;
		e.waiters = [];
		for (let e of t) e.fail(i);
		C(e);
	}
	function E(e) {
		let t = b.get(e);
		if (t !== void 0) return t;
		if (e.aborted) return;
		let n = {
			signal: e,
			abortListener: () => {},
			subscribers: /* @__PURE__ */ new Set(),
			pending: /* @__PURE__ */ new Map(),
			waiters: [],
			handle: void 0,
			connecting: void 0,
			connectTimer: void 0,
			reconnectTimer: void 0,
			reconnectAttempts: 0
		}, r = () => {
			T(n);
		};
		return n.abortListener = r, e.addEventListener("abort", r, { once: !0 }), b.set(e, n), n;
	}
	function O(e) {
		if (y === void 0 || e.subscribers.size === 0) return !1;
		if (e.reconnectAttempts += 1, e.reconnectAttempts > y.attempts) return e.reconnectAttempts = 0, !1;
		let t = Math.min(y.delayMs * 2 ** (e.reconnectAttempts - 1), y.maxDelayMs);
		for (let t of [...e.subscribers]) t.status("connecting");
		return e.reconnectTimer = d.setTimeout(() => {
			e.reconnectTimer = void 0, e.subscribers.size > 0 && e.handle === void 0 && e.connecting === void 0 && P(e);
		}, t), !0;
	}
	function k(e) {
		e.connectTimer !== void 0 && (d.clearTimeout(e.connectTimer), e.connectTimer = void 0);
	}
	function j(e, t, n) {
		if (e.connecting !== t) {
			M(n);
			return;
		}
		e.connecting = void 0, k(e), e.handle = n, e.reconnectAttempts = 0;
		for (let t of [...e.subscribers]) t.status("open");
		let r = e.waiters;
		e.waiters = [];
		for (let e of r) e.ready();
	}
	function N(e, t) {
		if (e.connecting !== t) return;
		e.connecting = void 0, k(e);
		let n = e.waiters;
		e.waiters = [];
		for (let e of n) e.fail(a);
		if (e.subscribers.size === 0) w(e);
		else if (!O(e)) for (let t of [...e.subscribers]) t.error(a), t.status("closed");
	}
	function P(e) {
		if (e.handle !== void 0 || e.connecting !== void 0) return;
		x(e);
		let n = new AbortController();
		e.connecting = n;
		let r = {
			message(t) {
				L(e, t);
			},
			close() {
				R(e);
			}
		};
		e.connectTimer = d.setTimeout(() => {
			e.connectTimer = void 0, e.connecting === n && (n.abort(), N(e, n));
		}, p);
		let i;
		try {
			i = t(r, n.signal);
		} catch {
			N(e, n);
			return;
		}
		Promise.resolve(i).then((t) => {
			j(e, n, t);
		}, () => {
			N(e, n);
		});
	}
	function F(e) {
		x(e), P(e);
	}
	function I(e) {
		for (let t of [...e.subscribers]) t.error(s);
	}
	function L(e, t) {
		if (A(t, m)) {
			I(e);
			return;
		}
		let n;
		try {
			n = u.decode(t);
		} catch {
			I(e);
			return;
		}
		if (n === void 0) return;
		if (n.type === "data") {
			for (let t of [...e.subscribers]) t.data(n.value);
			return;
		}
		let r = e.pending.get(n.requestId);
		r !== void 0 && (n.type === "ack" ? r.finish({ ok: !0 }) : r.finish({
			ok: !1,
			error: Object.freeze({
				code: "rejected",
				message: ee(n.message)
			})
		}));
	}
	function R(e) {
		if (e.handle === void 0) return;
		e.handle = void 0;
		for (let t of [...e.pending.values()]) t.finish(g(o));
		let t = e.waiters;
		e.waiters = [];
		for (let e of t) e.fail(a);
		if (e.subscribers.size === 0) w(e);
		else if (!O(e)) for (let t of [...e.subscribers]) t.error(a), t.status("closed");
	}
	function z(e) {
		let t = E(e.sessionSignal);
		if (t === void 0 || e.signal.aborted) return e.status("closed"), () => {};
		let n = !0, r = () => {
			n && (n = !1, e.signal.removeEventListener("abort", r), t.subscribers.delete(e), w(t));
		};
		return t.handle === void 0 ? (t.subscribers.add(e), e.status("connecting"), F(t)) : (t.subscribers.add(e), e.status("open")), e.signal.addEventListener("abort", r, { once: !0 }), r;
	}
	function B(e, t) {
		let n = t.requestId, r = E(t.sessionSignal);
		return r === void 0 ? Promise.resolve(g(i)) : new Promise((s) => {
			let c = !1, l, p, m = (e) => {
				if (c) return;
				if (c = !0, l !== void 0 && (d.clearTimeout(l), l = void 0), t.signal.removeEventListener("abort", h), p !== void 0) {
					let e = r.waiters.indexOf(p);
					e >= 0 && r.waiters.splice(e, 1), p = void 0;
				}
				let i = r.pending.get(n);
				i !== void 0 && i.finish === m && r.pending.delete(n), w(r), s(e);
			}, h = () => {
				m(g(i));
			};
			if (t.signal.aborted) {
				m(g(i));
				return;
			}
			t.signal.addEventListener("abort", h, { once: !0 });
			let _ = (i) => {
				if (c) return;
				let s;
				try {
					s = u.encodeSubmit({
						type: "submit",
						requestId: n,
						payload: e,
						...t.idempotencyKey === void 0 ? {} : { idempotencyKey: t.idempotencyKey }
					});
				} catch {
					m(g(a));
					return;
				}
				r.pending.set(n, { finish: m }), l = d.setTimeout(() => {
					l = void 0;
					let e = r.pending.get(n);
					e !== void 0 && e.finish === m && m(g(o));
				}, f);
				try {
					i.send(s);
				} catch {
					m(g(a));
				}
			};
			r.handle === void 0 ? (p = {
				ready() {
					p = void 0, r.handle === void 0 ? m(g(a)) : _(r.handle);
				},
				fail(e) {
					m(g(e));
				}
			}, r.waiters.push(p), F(r)) : _(r.handle);
		});
	}
	return Object.freeze({
		...c === void 0 ? {} : { submit: Object.freeze({
			validate: c,
			...v === void 0 ? {} : { maxBytes: v },
			send: B
		}) },
		...l === void 0 ? {} : { subscribe: Object.freeze({
			validate: l,
			...v === void 0 ? {} : { maxBytes: v },
			open: z
		}) }
	});
}
function P(e) {
	return (t, n) => new Promise((r, i) => {
		let a = !1, o = !1, s, c = [], l = () => {
			if (s !== void 0) {
				for (let [e, t] of c) s.removeEventListener(e, t);
				c.length = 0;
			}
		}, u = () => {
			let e = s;
			if (s = void 0, e !== void 0) try {
				e.close();
			} catch {}
		}, d = () => {
			a || (a = !0, n.removeEventListener("abort", f), l(), u(), i(/* @__PURE__ */ Error("The WebSocket connection failed.")));
		}, f = () => {
			d();
		};
		n.addEventListener("abort", f, { once: !0 });
		let p = (e, t) => {
			s.addEventListener(e, t), c.push([e, t]);
		}, m = () => {
			a || (a = !0, o = !0, n.removeEventListener("abort", f), r({
				send(e) {
					s.send(e);
				},
				dispose() {
					l(), u();
				}
			}));
		}, h = (r) => {
			if (a) return;
			let c, u;
			try {
				c = b(r?.url ?? e.endpoint), u = y(r?.protocols ?? e.protocols);
			} catch {
				a = !0, n.removeEventListener("abort", f), i(/* @__PURE__ */ Error("The WebSocket endpoint is invalid."));
				return;
			}
			try {
				s = e.createSocket(c, u);
			} catch {
				d();
				return;
			}
			try {
				p("open", m), p("message", (e) => {
					o && t.message(O(e));
				}), p("close", () => {
					o ? (l(), s = void 0, t.close()) : d();
				}), p("error", () => {
					o || d();
				});
			} catch {
				d();
			}
		};
		if (e.prepare === void 0) {
			h(void 0);
			return;
		}
		let g;
		try {
			g = e.prepare({ signal: n });
		} catch {
			d();
			return;
		}
		Promise.resolve(g).then((e) => {
			h(e);
		}, () => {
			d();
		});
	});
}
function F(e, t) {
	let n = globalThis.WebSocket;
	if (typeof n != "function") throw TypeError("WebSocket is unavailable in this context; pass options.webSocket.");
	return new n(e, t.length > 0 ? [...t] : void 0);
}
function I(e) {
	w(e, "webSocketChannel");
	let t = b(e.endpoint), n = y(e.protocols);
	if (e.prepare !== void 0 && typeof e.prepare != "function") throw TypeError("prepare must be a function.");
	let r = e.webSocket ?? F;
	if (typeof r != "function") throw TypeError("webSocket must be a function.");
	return N(e, P({
		endpoint: t,
		protocols: n,
		...e.prepare === void 0 ? {} : { prepare: e.prepare },
		createSocket: r
	}));
}
function L(e) {
	if (typeof e != "object" || !e) return !1;
	let t = e.channel;
	if (typeof t != "object" || !t) return !1;
	let n = t;
	return typeof n.send == "function" && typeof n.addEventListener == "function" && typeof n.removeEventListener == "function";
}
function R(e) {
	return (t, n) => new Promise((r, i) => {
		let a = !1, o = !1, s, c, l = [], u = () => {
			if (s !== void 0) {
				for (let [e, t] of l) s.removeEventListener(e, t);
				l.length = 0;
			}
		}, d = () => {
			u();
			let e = c;
			if (c = void 0, e !== void 0) try {
				e();
			} catch {}
		}, f = () => {
			a || o || (o = !0, n.removeEventListener("abort", p), d(), i(/* @__PURE__ */ Error("The WebRTC data channel failed.")));
		}, p = () => {
			f();
		};
		n.addEventListener("abort", p, { once: !0 });
		let m = (e, t) => {
			s.addEventListener(e, t), l.push([e, t]);
		}, h = () => {
			a || o || (a = !0, n.removeEventListener("abort", p), r({
				send(e) {
					s.send(e);
				},
				dispose() {
					o || (o = !0, d());
				}
			}));
		}, g = (e) => {
			a && !o && t.message(O(e));
		}, _ = () => {
			a || f();
		}, v = () => {
			o || (a ? (o = !0, d(), t.close()) : f());
		}, y = (e) => {
			if (o) j(e);
			else if (!L(e)) j(e), f();
			else if (s = e.channel, c = typeof e.release == "function" ? e.release.bind(e) : void 0, n.aborted) f();
			else try {
				m("message", g), m("close", v), m("error", _), m("open", h);
				let e = s.readyState;
				e === "open" ? h() : e === "closed" && v();
			} catch {
				f();
				return;
			}
		}, b;
		try {
			b = e.connect(e.endpoint, n);
		} catch {
			f();
			return;
		}
		Promise.resolve(b).then(y, () => {
			f();
		});
	});
}
function z(e) {
	w(e, "webRtcChannel");
	let t = x(e.endpoint);
	if (typeof e.connect != "function") throw TypeError("connect must be a function that selects a peer.");
	return N(e, R({
		endpoint: t,
		connect: e.connect
	}));
}
// src/runtime-services/browser/http-sse.ts
var B = new TextEncoder();
function V(e, t) {
	return e.length > t || B.encode(e).length > t;
}
var H = 2048, te = "Idempotency-Key", ne = 15e3, re = 2147483647, U = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/, ie = /[\u0000-\u0008\u000a-\u001f\u007f]/, ae = /^[A-Za-z][A-Za-z0-9!#$%&'*+\-.^_`|~]*$/, oe = /^[A-Za-z][A-Za-z0-9+.-]*:/, se = /^https?:\/\/[^/]/i, W = /[\u0000- \u007f]/;
function G(e, t) {
	return {
		ok: !1,
		error: {
			code: e,
			message: t
		}
	};
}
function K(e, t) {
	if (typeof e != "object" || !e) throw TypeError(`${t} requires an options object.`);
}
function q(e, t) {
	if (typeof e != "string") throw TypeError(`${t} requires a string endpoint.`);
	let n = e.trim();
	if (n.length === 0) throw TypeError(`${t} requires a non-empty endpoint.`);
	if (n.length > H) throw TypeError(`${t} endpoint must be at most ${H} characters.`);
	if (W.test(n)) throw TypeError(`${t} endpoint must not contain whitespace or control characters.`);
	if (n.includes("\\")) throw TypeError(`${t} endpoint must not contain backslashes.`);
	if (oe.test(n)) {
		if (!se.test(n)) throw TypeError(`${t} endpoint must use HTTP(S) or be a same-origin relative path.`);
		try {
			new URL(n);
		} catch {
			throw TypeError(`${t} endpoint must be a valid HTTP(S) URL.`);
		}
		return n;
	}
	if (n.startsWith("//")) throw TypeError(`${t} endpoint must not be protocol-relative.`);
	if (n.startsWith("#")) throw TypeError(`${t} endpoint must name a resource, not a fragment.`);
	return n;
}
function J(e, t) {
	if (e !== void 0) {
		if (typeof e != "function") throw TypeError(`${t} must be a function.`);
		return e;
	}
}
function Y(e, t) {
	if (e !== void 0) {
		if (typeof e != "number" || !Number.isSafeInteger(e) || e <= 0) throw TypeError(`${t} must be a positive integer.`);
		return e;
	}
}
function ce(e) {
	if (e === void 0) return "POST";
	if (typeof e != "string" || !ae.test(e)) throw TypeError("httpSubmit method must be an HTTP method token.");
	return e;
}
function le(e) {
	if (e !== void 0) {
		if (e !== "omit" && e !== "same-origin" && e !== "include") throw TypeError("httpSubmit credentials must be \"omit\", \"same-origin\" or \"include\".");
		return e;
	}
}
function ue(e) {
	if (e === void 0) return te;
	if (e === null || e === "") return null;
	if (typeof e != "string" || !U.test(e)) throw TypeError("httpSubmit idempotencyHeader must be an HTTP header name, null or an empty string.");
	return e;
}
function X(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) throw TypeError("HTTP headers must be a plain object of strings.");
	let t = {};
	for (let [n, r] of Object.entries(e)) {
		if (!U.test(n)) throw TypeError(`Invalid HTTP header name: ${n}.`);
		if (typeof r != "string" || ie.test(r)) throw TypeError(`Invalid value for HTTP header ${n}.`);
		t[n] = r;
	}
	return t;
}
function de(e) {
	if (e !== void 0) return typeof e == "function" ? e : X(e);
}
function Z(e, t) {
	let n = t.toLowerCase();
	return Object.keys(e).some((e) => e.toLowerCase() === n);
}
function fe(e, t, n, r) {
	let i = { ...e };
	return t !== null && !Z(i, "content-type") && (i["Content-Type"] = t), n !== null && r.idempotencyKey !== void 0 && !Z(i, n) && (i[n] = r.idempotencyKey), i;
}
function pe(e) {
	if (e !== void 0) return e;
	let t = globalThis.fetch;
	if (typeof t != "function") return;
	let n = t;
	return (e, t) => n.call(globalThis, e, t);
}
async function me(e, t, n) {
	if (e === null) return "";
	let r = e.getReader(), i = new TextDecoder(), a = t, o = "", s = !1, c = () => {
		r.cancel().catch(() => {});
	};
	n.addEventListener("abort", c, { once: !0 });
	try {
		for (;;) {
			let e = await r.read();
			if (n.throwIfAborted(), e.done) return s = !0, o + i.decode();
			if (a -= e.value.byteLength, a < 0) return;
			o += i.decode(e.value, { stream: !0 });
		}
	} finally {
		n.removeEventListener("abort", c), !s && !n.aborted && c(), r.releaseLock();
	}
}
async function he(e, t, n, r) {
	if (!r || t.aborted) e.body?.cancel().catch(() => {}), t.throwIfAborted();
	else {
		let i;
		try {
			i = await me(e.body, n, t);
		} catch {
			return G("unconfirmed", "The server responded but its confirmation could not be read.");
		}
		if (i === void 0) return G("unconfirmed", `The server response exceeds the ${n}-byte budget.`);
		t.throwIfAborted();
		try {
			let t = r({
				status: e.status,
				ok: e.ok,
				headers: e.headers,
				text: i
			});
			if (t !== void 0) return t;
		} catch {
			return G("unconfirmed", "The server responded but its result could not be interpreted.");
		}
	}
	return e.ok ? { ok: !0 } : e.status >= 400 && e.status < 500 ? G("rejected", `The server rejected the submission (HTTP ${e.status}).`) : G("unconfirmed", `The submission outcome was not confirmed (HTTP ${e.status}).`);
}
function ge(e) {
	K(e, "httpSubmit");
	let t = q(e.endpoint, "httpSubmit");
	if (typeof e.validate != "function") throw TypeError("httpSubmit requires a validate function.");
	let n = Y(e.maxBytes, "httpSubmit maxBytes") ?? 65536, r = Y(e.maxResponseBytes, "httpSubmit maxResponseBytes") ?? 65536, i = Y(e.timeoutMs, "httpSubmit timeoutMs") ?? ne;
	if (i > re) throw TypeError("httpSubmit timeoutMs exceeds the maximum timer delay.");
	let a = ce(e.method), o = de(e.headers), s = le(e.credentials), c = J(e.fetch, "httpSubmit fetch"), l = J(e.encode, "httpSubmit encode"), u = J(e.interpret, "httpSubmit interpret"), d = ue(e.idempotencyHeader);
	return Object.freeze({
		validate: e.validate,
		maxBytes: n,
		async send(e, f) {
			if (f.signal.aborted || f.sessionSignal.aborted) return G("cancelled", "The submission was cancelled.");
			let p, m;
			try {
				let t = l === void 0 ? {
					body: JSON.stringify(e),
					contentType: "application/json"
				} : l(e, f);
				if (typeof t.body != "string") throw TypeError("The encoder must return a string body.");
				p = t.body;
				let n = t.contentType === void 0 ? "application/json" : t.contentType;
				if (n !== null && typeof n != "string") throw TypeError("The encoder contentType must be a string or null.");
				m = fe(typeof o == "function" ? X(o(f)) : o ?? {}, n, d, f);
			} catch {
				return G("transport", "The submission could not be encoded.");
			}
			let h = a === "GET" || a === "HEAD";
			if (h && p !== "") return G("invalid-data", `${a} submissions cannot carry a request body.`);
			if (V(p, n)) return G("invalid-data", `The submission exceeds the ${n}-byte budget.`);
			let g = pe(c);
			if (g === void 0) return G("transport", "HTTP fetch is unavailable in this context; pass options.fetch.");
			if (f.signal.aborted || f.sessionSignal.aborted) return G("cancelled", "The submission was cancelled.");
			let _ = new AbortController(), v, y = new Promise((e) => {
				v = e;
			}), b = (e) => {
				v(e), _.abort();
			}, x = () => b(G("cancelled", "The submission was cancelled."));
			f.signal.addEventListener("abort", x, { once: !0 }), f.sessionSignal.addEventListener("abort", x, { once: !0 });
			let S = setTimeout(() => b(G("unconfirmed", "The submission timed out before confirmation.")), i), C = async () => {
				try {
					return await he(await g(t, {
						method: a,
						headers: m,
						body: h ? void 0 : p,
						credentials: s,
						signal: _.signal
					}), _.signal, r, u);
				} catch {
					return G("unconfirmed", "The submission was sent but no confirmation arrived.");
				}
			};
			try {
				return await Promise.race([y, C()]);
			} finally {
				clearTimeout(S), f.signal.removeEventListener("abort", x), f.sessionSignal.removeEventListener("abort", x);
			}
		}
	});
}
function _e(e) {
	if (e === void 0) return ["message"];
	if (!Array.isArray(e) || e.length === 0) throw TypeError("sseStream events must be a non-empty array of event names.");
	let t = /* @__PURE__ */ new Set();
	for (let n of e) {
		if (typeof n != "string" || n.length === 0 || W.test(n)) throw TypeError("sseStream event names must be non-empty strings without whitespace.");
		if (n === "open" || n === "error") throw TypeError("sseStream event names must not be \"open\" or \"error\".");
		if (t.has(n)) throw TypeError(`sseStream event name "${n}" is listed twice.`);
		t.add(n);
	}
	return [...e];
}
function ve(e) {
	let t = globalThis.EventSource;
	if (typeof t == "function") return (n) => new t(n, { withCredentials: e });
}
function Q(e) {
	return typeof e == "string" ? JSON.parse(e) : e;
}
function ye(e) {
	K(e, "sseStream");
	let t = q(e.endpoint, "sseStream");
	if (typeof e.validate != "function") throw TypeError("sseStream requires a validate function.");
	let n = Y(e.maxBytes, "sseStream maxBytes") ?? 65536, r = _e(e.events);
	if (e.withCredentials !== void 0 && typeof e.withCredentials != "boolean") throw TypeError("sseStream withCredentials must be a boolean.");
	let i = e.withCredentials === !0, a = J(e.createEventSource, "sseStream createEventSource"), o = J(e.decode, "sseStream decode");
	return Object.freeze({
		validate: e.validate,
		maxBytes: n,
		open(e) {
			if (e.signal.aborted || e.sessionSignal.aborted) return () => {};
			let s = a ?? ve(i);
			if (s === void 0) return e.error({
				code: "unavailable",
				message: "EventSource is unavailable in this context; pass options.createEventSource."
			}), e.status("closed"), () => {};
			let c;
			try {
				c = s(t);
			} catch {
				return e.error({
					code: "unavailable",
					message: "The event stream could not be opened."
				}), e.status("closed"), () => {};
			}
			let l = !1, u = [], d = () => {
				l || e.status("open");
			}, f = () => {
				l || (e.error({
					code: "transport",
					message: "The event stream reported an error."
				}), c.readyState === 2 ? (e.status("closed"), h()) : c.readyState === 0 && e.status("connecting"));
			}, p = (t) => {
				if (l) return;
				let r = t.data;
				if (r === void 0) return;
				if (typeof r == "string" && V(r, n)) {
					e.error({
						code: "invalid-data",
						message: `An event exceeded the ${n}-byte budget.`
					});
					return;
				}
				let i;
				try {
					i = o === void 0 ? Q(r) : o(r, t);
				} catch {
					e.error({
						code: "invalid-data",
						message: "An event could not be decoded."
					});
					return;
				}
				e.data(i);
			};
			function m() {
				h();
			}
			function h() {
				if (!l) {
					l = !0;
					for (let [e, t] of u) c.removeEventListener(e, t);
					e.signal.removeEventListener("abort", m), e.sessionSignal.removeEventListener("abort", m);
					try {
						c.close();
					} catch {}
				}
			}
			u.push(["open", d], ["error", f]);
			for (let e of r) u.push([e, p]);
			for (let [e, t] of u) c.addEventListener(e, t);
			return e.signal.addEventListener("abort", m, { once: !0 }), e.sessionSignal.addEventListener("abort", m, { once: !0 }), (e.signal.aborted || e.sessionSignal.aborted) && h(), h;
		}
	});
}
// src/runtime-services/browser/index.ts
var be = "reactive-md:component-state:v1:", $ = 128;
function xe(e, t = {}) {
	let n = globalThis, r = t.page ?? (typeof n.addEventListener == "function" ? n : void 0), i = t.document ?? (typeof n.document?.addEventListener == "function" ? n.document : void 0);
	if (r === void 0 || i === void 0) return () => {};
	let a = () => {
		e.flush();
	}, o = () => {
		i.visibilityState === "hidden" && a();
	};
	r.addEventListener("pagehide", a), i.addEventListener("visibilitychange", o);
	let s = !1;
	return () => {
		s || (s = !0, r.removeEventListener("pagehide", a), i.removeEventListener("visibilitychange", o));
	};
}
function Se() {
	let e;
	try {
		e = globalThis.localStorage;
	} catch (e) {
		throw TypeError(`localStorage is unavailable in this context: ${e instanceof Error ? e.message : String(e)}`);
	}
	if (typeof e != "object" || !e || typeof e.getItem != "function" || typeof e.setItem != "function" || typeof e.removeItem != "function") throw TypeError("localStorage is unavailable in this context; pass options.storage instead.");
	return e;
}
function Ce(n) {
	if (typeof n != "object" || !n) throw TypeError("createLocalBrowserStateStorage requires an options object.");
	let r = e(n.documentId);
	if (r === void 0) throw TypeError("createLocalBrowserStateStorage requires a valid documentId.");
	let i = n.keyPrefix ?? "reactive-md:component-state:v1:";
	if (typeof i != "string" || i.length === 0 || i.length > $) throw TypeError(`keyPrefix must be a non-empty string of at most ${$} characters.`);
	let a = n.storage ?? Se(), o = `${i}${r}`;
	return Object.freeze({
		key: o,
		read() {
			let e = a.getItem(o);
			return e === null ? null : e;
		},
		write(e) {
			let n = JSON.stringify(e);
			if (n.length > 1048576) throw RangeError(`The serialized component state exceeds the ${t}-character storage budget.`);
			a.setItem(o, n);
		},
		remove() {
			a.removeItem(o);
		}
	});
}
export { n as DEFAULT_DUPLEX_ACK_TIMEOUT_MS, r as DEFAULT_DUPLEX_MESSAGE_BYTES, be as LOCAL_COMPONENT_STATE_STORAGE_PREFIX, Ce as createLocalBrowserStateStorage, xe as flushComponentStateOnPageHide, ge as httpSubmit, D as jsonDuplexCodec, ye as sseStream, z as webRtcChannel, I as webSocketChannel };
