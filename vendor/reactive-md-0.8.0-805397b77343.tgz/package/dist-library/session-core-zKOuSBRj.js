import { w as e } from "./validation-BPmsZ5G9.js";
import { s as t } from "./config-C7nMEidX.js";
import { n } from "./options-DiCwIp4Z.js";
import { t as r } from "./compiler-DGI0MNNC.js";
import { t as i } from "./runtime-D41JcW0T.js";
import { D as a, p as o } from "./network-Ca3GAJua.js";
import { _ as s, d as c, h as l, i as u, u as d } from "./shareable-CHxaEj_P.js";
import { i as f, t as p } from "./resources-85Qoj6wA.js";
import { jsx as m } from "react/jsx-runtime";
import { createRoot as h, hydrateRoot as g } from "react-dom/client";
// src/standalone/diagnostics.ts
function _(e, t) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function v(e, t = 8) {
	let n = e.slice(0, t).map((e) => `- [${e.code}] ${e.message} (line ${e.line}, column ${e.column})`);
	return e.length > n.length && n.push(`- ${e.length - n.length} more diagnostic(s).`), n.join("\n");
}
function y(e) {
	return e instanceof Error ? e.message : String(e);
}
var b = class extends Error {
	diagnostics;
	constructor(e, t) {
		let n = v(t);
		super(n ? `${e}\n${n}` : e), this.name = "ReactiveMDMountError", this.diagnostics = t;
	}
};
function x(e, t = "standalone.mount") {
	if (typeof e == "object" && e && Array.isArray(e.diagnostics)) {
		let t = e.diagnostics;
		if (t.length > 0) return t;
	}
	return [_(t, y(e))];
}
// src/standalone/events.ts
var S = "reactive-md-diagnostics", C = "reactive-md-state-change", w = /^[A-Za-z][A-Za-z0-9_-]*$/, T = 256, E = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, D = /[\u0000-\u001f\u007f-\u009f]/, O = 64, k = 4096, A = 41943040;
function j(e, t) {
	if (e === void 0) return;
	if (!N(e)) {
		t("standalone.payload.images", "images must be a JSON object mapping image URLs to data URLs.");
		return;
	}
	let n = Object.entries(e);
	if (n.length > O) {
		t("standalone.payload.images", `images cannot contain more than ${O} entries.`);
		return;
	}
	let r = Object.create(null), i = 0;
	for (let [e, a] of n) if (!e || e.length > k || e === "__proto__" || D.test(e) || typeof a != "string" || !E.test(a)) t("standalone.payload.images", "Every image entry must use a bounded URL key and a base64 raster data URL.");
	else {
		if (i += a.length, i > A) {
			t("standalone.payload.images", "The embedded image map exceeds the 40 MiB budget.");
			return;
		}
		r[e] = a;
	}
	return r;
}
function M(e, t) {
	if (e === void 0) return;
	let r = n(e);
	if (!r.ok) t("standalone.payload.compile-options", `The payload compile options are invalid: ${r.message}`);
	else return c(e);
}
function N(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function P(e, t) {
	if (e === void 0) return;
	let n = a(e);
	if (typeof e != "string" || n !== e) t("standalone.payload.document-id", "The payload documentId must be a canonical 1-256 character string.");
	else return n;
}
function F(e, t) {
	if (e !== void 0) {
		if (typeof e != "number" || !Number.isInteger(e) || e < 0 || e > 4294967295) t("standalone.payload.random-seed", "The payload randomSeed must be a 32-bit unsigned integer.");
		else return e;
	}
}
function I(e, t) {
	if (e === void 0) return;
	let n = o(e);
	if (!n.ok || n.diagnostics.length > 0) {
		let e = n.diagnostics;
		e.length === 0 && t("standalone.payload.component-state", "The payload component state is invalid.");
		for (let n of e) t("standalone.payload.component-state", n.message);
	} else return n.document;
}
function L(e) {
	let t = [], n = (e, n) => {
		t.push(_(e, n));
	};
	if (!N(e)) return {
		ok: !1,
		diagnostics: [_("standalone.payload.shape", "The reactive-md payload must be a JSON object.")]
	};
	e.version !== 1 && e.version !== 2 && n("standalone.payload.version", "The reactive-md payload must use version 1 or 2."), e.version === 2 && e.restoration === void 0 && n("standalone.payload.requirements", "Version 2 requires restoration contracts."), e.version === 1 && (e.restoration !== void 0 || e.resources !== void 0) && n("standalone.payload.version", "Restoration contracts require payload version 2.");
	let r = e.target;
	typeof r != "string" || r.length === 0 || r.length > T ? n("standalone.payload.target", `The payload target must be an element id of 1-${T} characters.`) : w.test(r) || n("standalone.payload.target", "The payload target must start with a letter and use only letters, digits, underscores or hyphens.");
	let i = e.source;
	typeof i != "string" && n("standalone.payload.source", "The payload source must be a string.");
	let a = e.locale === void 0 ? "en" : e.locale;
	a !== "en" && a !== "zh" && n("standalone.payload.locale", "The payload locale must be \"en\" or \"zh\".");
	let o = e.colorScheme === void 0 ? "auto" : e.colorScheme;
	o !== "light" && o !== "dark" && o !== "auto" && n("standalone.payload.color-scheme", "The payload colorScheme must be \"light\", \"dark\" or \"auto\".");
	let s = e.hydrate !== void 0 && e.hydrate;
	typeof s != "boolean" && n("standalone.payload.hydrate", "The payload hydrate flag must be a boolean.");
	let c = e.state;
	N(c) || n("standalone.payload.state", "The payload state must be a JSON object.");
	let l = M(e.compileOptions, n);
	t.push(...f(e.extensions, l?.config));
	let u = p(e.resources ?? []);
	t.push(...u.diagnostics), t.push(...d(e.restoration, {
		config: l?.config,
		source: typeof i == "string" ? i : "",
		resources: u.resources
	}));
	let m = j(e.images, n), h = P(e.documentId, n), g = F(e.randomSeed, n), v = I(e.componentState, n);
	return t.length > 0 ? {
		ok: !1,
		diagnostics: t
	} : {
		ok: !0,
		payload: {
			version: e.version,
			target: r,
			source: i,
			state: c,
			locale: a,
			colorScheme: o,
			hydrate: s,
			...l === void 0 ? {} : { compileOptions: l },
			...e.extensions === void 0 ? {} : { extensions: e.extensions },
			...e.restoration === void 0 ? {} : {
				restoration: e.restoration,
				resources: u.resources
			},
			...m && Object.keys(m).length > 0 ? { images: m } : {},
			...h === void 0 ? {} : { documentId: h },
			...g === void 0 ? {} : { randomSeed: g },
			...v === void 0 ? {} : { componentState: v }
		}
	};
}
function R(e) {
	try {
		return L(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [_("standalone.payload.invalid", `The reactive-md payload could not be read: ${y(e)}`)]
		};
	}
}
// src/standalone/prepare.ts
function z(t, i, a, o, c) {
	if (typeof t != "string") throw new b("Cannot mount a Reactive MD document: source must be a string.", [_("standalone.source", "source must be a string.")]);
	let l = r(t, o), d;
	if (l.ok) d = l.document;
	else {
		let r = n(o);
		if (!r.ok || !r.htmlActive) throw new b("Cannot mount a Reactive MD document: the source contains syntax errors.", l.diagnostics);
		d = {
			syntax: "local",
			syntaxVersion: e,
			source: t,
			html: r.html,
			initialState: {},
			bindings: {},
			nodes: [{
				type: "fallback",
				id: "local-0",
				range: {
					start: 0,
					end: t.length
				},
				value: t
			}]
		};
	}
	if (c?.(d), i !== void 0) {
		let e = s(i);
		if (!e.ok) throw new b("Cannot mount a Reactive MD document: the state payload is invalid.", e.diagnostics);
		let t = u(d, e.file);
		if (!t.ok) throw new b("Cannot mount a Reactive MD document: the state does not match this source.", t.diagnostics);
		d = t.baseline.document;
	}
	return typeof a == "string" && a.trim().length > 0 && (d = {
		...d,
		theme: a.trim(),
		themeRange: void 0
	}), {
		document: d,
		diagnostics: l.diagnostics.slice()
	};
}
var B = Object.freeze({
	name: "reactive-md-standalone",
	version: "0.4.0"
}), V = "data-reactive-md-mounted", H = "script[type=\"application/reactive-md+json\"][data-reactive-md-auto]", U = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, W = 64;
function G(e) {
	if (!e) return {};
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e).slice(0, W)) typeof n == "string" && n.length > 0 && typeof r == "string" && U.test(r) && t.set(n, r);
	return t.size === 0 ? {} : {
		urlPolicy: (e, n) => n === "link" || t.has(e),
		imageResolver: (e) => t.get(e) ?? null
	};
}
var K = /* @__PURE__ */ new WeakSet();
function q(e) {
	return K.has(e) || e.hasAttribute("data-reactive-md-mounted");
}
function J(e, t) {
	return l(e, t);
}
function Y(e) {
	if (e) try {
		e();
	} catch {}
}
function X(e) {
	let t = () => {
		let t = e.querySelector("article.local-document");
		t && (t.classList.remove("local-static-first", "reactive-md-static-first", "reactive-md-hydrating"), t.removeAttribute("data-static-first"), t.removeAttribute("data-reactive-md-static-first")), e.classList.remove("local-static-first", "reactive-md-static-first"), e.removeAttribute("data-static-first");
	};
	if (typeof requestAnimationFrame != "function") return t(), () => {};
	let n = 0, r = 0;
	return n = requestAnimationFrame(() => {
		t(), r = requestAnimationFrame(t);
	}), () => {
		typeof cancelAnimationFrame == "function" && (cancelAnimationFrame(n), r && cancelAnimationFrame(r));
	};
}
function Z(e, n, r, a = {}) {
	if (!e || typeof e != "object" || !("nodeType" in e) || !e.hasAttribute) throw new b("Cannot mount a Reactive MD document: element must be an HTMLElement.", [_("standalone.element", "element must be an HTMLElement.")]);
	if (q(e)) throw new b("Cannot mount a Reactive MD document: this element is already mounted.", [_("standalone.mount", "The target element already hosts a Reactive MD document.")]);
	if (!n || typeof n != "object") throw new b("Cannot mount a Reactive MD document: options are required.", [_("standalone.options", "mount requires an options object with a source string.")]);
	let o = n.compileOptions;
	if (n.reactConfig) {
		if (o?.hostComponents !== void 0 || n.themes !== void 0) throw new b("Conflicting extension registration.", [_("local.extension.config", "reactConfig cannot be combined with hostComponents or themes.")]);
		if (o?.config && t(o.config).key !== n.reactConfig.config.key) throw new b("The export configuration differs from the installed bundle.", [_("local.extension.config", "Compile configuration does not match installed implementations.")]);
		o = {
			...o,
			config: n.reactConfig.config
		};
	}
	let s = f(n.extensions, n.reactConfig?.config);
	if (s.length) throw new b("Extension requirements are not satisfied.", s);
	let c = d(n.restoration, {
		config: n.reactConfig?.config ?? o?.config,
		source: n.source,
		resources: n.resources
	});
	if (c.length) throw new b("Restoration requirements are not satisfied.", c);
	let l = p(n.resources ?? []);
	if (l.diagnostics.length) throw new b("Style resources are invalid.", l.diagnostics);
	let u = z(n.source, n.state, a.theme, o, (e) => {
		let t = f(e.extensions, n.reactConfig?.config);
		if (t.push(...d(n.restoration, {
			config: n.reactConfig?.config ?? o?.config,
			source: n.source,
			resources: n.resources,
			document: e
		})), t.length) throw new b("Installed contracts must match before state recovery.", t);
	}), v = f(u.document.extensions, n.reactConfig?.config);
	if (v.length) throw new b("Installed extension implementations are required.", v);
	let S = o?.config, C = S?.key ?? u.document.componentConfigKey, w = S?.legacyKeys.map((e) => e.key) ?? [], T;
	try {
		T = i(u.document, {
			documentId: n.documentId,
			randomSeed: n.randomSeed,
			componentState: n.componentState,
			...C === void 0 ? {} : { configKey: C },
			...w.length === 0 ? {} : { legacyConfigKeys: w }
		});
	} catch (e) {
		throw new b("Cannot mount a Reactive MD document: the interactive runtime could not be created.", [_("standalone.runtime", y(e))]);
	}
	let E = n.generator ?? B, D = G(n.images), O = n.urlPolicy ?? D.urlPolicy, k = n.imageResolver ?? D.imageResolver, A = () => J(T, E), j;
	try {
		j = A();
	} catch (e) {
		try {
			T.dispose();
		} catch {}
		throw new b("Cannot mount a Reactive MD document: the initial state could not be captured.", [_("standalone.state", y(e))]);
	}
	let M = !1, N = (e) => {
		M || Y(a.onDiagnostics ? () => a.onDiagnostics(e) : void 0);
	}, P = (() => {
		try {
			return T.services?.state.diagnostics() ?? [];
		} catch {
			return [];
		}
	})(), F = n.hydrate === !0 && e.hasChildNodes(), I = /* @__PURE__ */ m(r, {
		document: u.document,
		runtime: T,
		onDiagnostics: N,
		urlPolicy: O,
		locale: n.locale ?? "en",
		themes: n.themes,
		reactConfig: n.reactConfig,
		colorScheme: n.colorScheme ?? "auto",
		mode: "interactive",
		staticFirst: F,
		imageResolver: k
	});
	if (!F) for (; e.firstChild;) e.removeChild(e.firstChild);
	let L = null, R = [];
	try {
		for (let t of l.resources) {
			let n = e.ownerDocument.createElement("style");
			n.setAttribute("data-reactive-md-resource", t.id), n.textContent = t.css, (e.ownerDocument.head ?? e.ownerDocument.documentElement).appendChild(n), R.push(n);
		}
		L = F ? g(e, I) : h(e), F || L.render(I);
	} catch (e) {
		R.forEach((e) => e.remove());
		try {
			L?.unmount();
		} catch {}
		try {
			T.dispose();
		} catch {}
		throw new b("Cannot mount a Reactive MD document: React could not render the document.", x(e, "standalone.render"));
	}
	K.add(e), e.setAttribute(V, "");
	let H = a.onStateChange ? T.subscribe(() => {
		if (M) return;
		let e;
		try {
			e = A();
		} catch {
			return;
		}
		Y(a.onStateChange ? () => a.onStateChange(e) : void 0);
	}) : () => {};
	Y(a.onStateChange ? () => a.onStateChange(j) : void 0), u.diagnostics.length > 0 && N(u.diagnostics), P.length > 0 && N([...P]);
	let U = F ? X(e) : () => {};
	return {
		element: e,
		getState() {
			if (M) throw Error("This Reactive MD document has been unmounted.");
			return A();
		},
		unmount: () => {
			if (!M) {
				M = !0, H(), U(), R.forEach((e) => e.remove());
				try {
					L?.unmount();
				} catch {}
				try {
					T.dispose();
				} catch {}
				K.delete(e), e.getAttribute("data-reactive-md-mounted") === "" && e.removeAttribute(V);
			}
		}
	};
}
function Q(e, t, n) {
	if (typeof console < "u" && typeof console.error == "function") try {
		console.error(`Reactive MD: ${n.map((e) => `[${e.code}] ${e.message}`).join(" ")}`);
	} catch {}
	let r = e.defaultView?.CustomEvent;
	if (typeof r == "function") try {
		t.dispatchEvent(new r(S, {
			detail: n,
			bubbles: !0,
			composed: !0
		}));
	} catch {}
}
function $(e, t) {
	let n = t.defaultView?.HTMLElement;
	return n ? e instanceof n : e.namespaceURI === "http://www.w3.org/1999/xhtml";
}
function ee(e, t, n = {}) {
	if (typeof document > "u") return [];
	let r = t ?? document, i = r, a = i.nodeType === 9 ? r : i.ownerDocument ?? document, o = [], s;
	try {
		s = Array.from(r.querySelectorAll(H));
	} catch {
		return o;
	}
	for (let t of s) {
		let s;
		try {
			s = R(JSON.parse(t.textContent ?? ""));
		} catch (e) {
			Q(a, t, [_("standalone.payload.json", `The reactive-md payload is not valid JSON: ${y(e)}`)]);
			continue;
		}
		if (!s.ok) {
			Q(a, t, s.diagnostics);
			continue;
		}
		let c = s.payload, l = r, u = (typeof l.getElementById == "function" ? l.getElementById(c.target) : null) ?? a.getElementById(c.target);
		if (!u) Q(a, t, [_("standalone.target.missing", `The reactive-md payload target "#${c.target}" was not found.`)]);
		else if (i !== a && !i.contains(u)) Q(a, t, [_("standalone.target.scope", "The reactive-md payload target is outside the scanned root.")]);
		else if (!$(u, a)) Q(a, t, [_("standalone.target.type", "The reactive-md payload target must be an HTML element.")]);
		else if (!q(u)) try {
			o.push(Z(u, {
				source: c.source,
				state: c.state,
				locale: c.locale,
				colorScheme: c.colorScheme,
				hydrate: c.hydrate,
				images: c.images,
				compileOptions: c.compileOptions,
				extensions: c.extensions,
				restoration: c.restoration,
				resources: c.resources,
				documentId: c.documentId,
				randomSeed: c.randomSeed,
				componentState: c.componentState,
				reactConfig: n.reactConfig
			}, e, { onDiagnostics: (e) => Q(a, u, e) }));
		} catch (e) {
			Q(a, u, x(e));
		}
	}
	return o;
}
export { R as a, b as c, ee as i, Z as n, S as o, q as r, C as s, V as t };
