// src/runtime-services/identity.ts
var e = new TextEncoder(), t = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/, n = /^[^\u0000-\u001f\u007f]{1,256}$/;
function r(t) {
	let n = e.encode(t), r = 2166136261;
	for (let e = 0; e < n.length; e += 1) r ^= n[e], r = Math.imul(r, 16777619) >>> 0;
	return r >>> 0;
}
function i(e) {
	if (typeof e != "string") throw TypeError("localSourceDigest requires a source string.");
	return `fnv1a32:${r(e).toString(16).padStart(8, "0")}`;
}
function a(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	return n.test(t) ? t : void 0;
}
function o(e) {
	if (typeof e != "string") return;
	let n = e.trim();
	return t.test(n) ? n : void 0;
}
function s(e) {
	return a(e.documentId) ?? e.sourceDigest;
}
function c(e) {
	let t = s(e), n = o(e.stateKey), i = n === void 0 ? `node:${e.nodeId}` : `state:${n}`, a = encodeURIComponent(t);
	return `doc:${a.length <= 256 ? a : `h${r(t).toString(16).padStart(8, "0")}`}:${i}`;
}
function l(e, t) {
	return r(`${e >>> 0}:${t}`);
}
function u(e) {
	if (typeof e.explicitSeed == "number" && Number.isFinite(e.explicitSeed)) return Math.trunc(e.explicitSeed) >>> 0;
	let t = o(e.stateKey), n = t === void 0 ? `node:${e.nodeId}` : `state:${t}`;
	return l(e.documentSeed, `${e.componentId}|${n}`);
}
function d(e) {
	return Number.isFinite(e) ? Math.trunc(e) >>> 0 : 0;
}
// src/runtime-services/random.ts
var f = "mulberry32", p = 1;
function m(e) {
	return Object.freeze({
		algorithm: f,
		version: 1,
		state: d(e)
	});
}
function h(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return null;
	let t = e;
	if (t.algorithm !== "mulberry32" || t.version !== 1 || typeof t.state != "number" || !Number.isFinite(t.state)) return null;
	let n = d(t.state);
	return n === t.state ? Object.freeze({
		algorithm: f,
		version: 1,
		state: n
	}) : null;
}
function g(e) {
	let t = d(e.state + 1831565813), n = Math.imul(t ^ t >>> 15, t | 1);
	return n ^= n + Math.imul(n ^ n >>> 7, n | 61), {
		value: ((n ^ n >>> 14) >>> 0) / 4294967296,
		state: Object.freeze({
			algorithm: f,
			version: 1,
			state: t
		})
	};
}
function _(e, t, n) {
	let r = g(e);
	if (!Number.isFinite(t) || !Number.isFinite(n)) return {
		value: 0,
		state: r.state
	};
	let i = Math.ceil(Math.min(t, n)), a = Math.floor(Math.max(t, n));
	return a < i ? {
		value: i,
		state: r.state
	} : {
		value: i + Math.floor(r.value * (a - i + 1)),
		state: r.state
	};
}
function v(e, t) {
	let n = t.slice(), r = e;
	for (let e = n.length - 1; e > 0; --e) {
		let t = _(r, 0, e);
		r = t.state;
		let i = n[e];
		n[e] = n[t.value], n[t.value] = i;
	}
	return {
		items: n,
		state: r
	};
}
function y(e, t) {
	return m(l(e, t));
}
function b(e, t = .5) {
	let n = g(e);
	return {
		value: n.value < t,
		state: n.state
	};
}
// src/runtime-services/component-state.ts
var x = "reactive-md-component-state/v1", S = "reactive-md-component-state-document/v1", C = 16384, w = 262144, T = 16, E = 1e4, D = 1e5, O = 1048576, k = 128, A = 64, j = 512, ee = 1e6, te = 128, ne = /[\u0000-\u001f\u007f-\u009f]/, M = new TextEncoder();
function N(e, t, n = "error") {
	return {
		code: e,
		message: t,
		severity: n,
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function P(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function F(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function I(e) {
	return typeof e == "string" && e.length > 0 && e.length <= te && !ne.test(e) && F(e);
}
function L(e, t, n) {
	return t === void 0 || e === t || n.includes(e);
}
function R(e, t) {
	if (e === null) return null;
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw TypeError("numbers must be finite");
		return e;
	}
	if (typeof e == "string") {
		if (e.length > 1e5) throw RangeError(`strings exceed ${D} characters`);
		if (!F(e)) throw TypeError("strings must be well-formed Unicode");
		return e;
	}
	if (t >= 16) throw RangeError("nesting exceeds 16 levels");
	if (Array.isArray(e)) {
		if (e.length > 1e4) throw RangeError(`arrays exceed ${E} items`);
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("arrays cannot use symbol keys");
		return e.map((e) => R(e, t + 1));
	}
	if (P(e)) {
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("objects cannot use symbol keys");
		let n = Object.keys(e);
		if (n.length > 1e4) throw RangeError(`objects exceed ${E} keys`);
		let r = {};
		for (let i of n) {
			if (i === "__proto__") throw TypeError("the key \"__proto__\" is not allowed");
			if (i.length > 1e5) throw RangeError(`keys exceed ${D} characters`);
			if (!F(i)) throw TypeError("keys must be well-formed Unicode");
			r[i] = R(e[i], t + 1);
		}
		return r;
	}
	throw TypeError("values must be JSON-safe primitives, arrays or plain objects");
}
function z(e) {
	return R(e, 0);
}
function B(e) {
	return Object.freeze({
		...e,
		data: R(e.data, 0),
		...e.random === void 0 ? {} : { random: h(e.random) ?? e.random }
	});
}
function V(e) {
	if (!P(e)) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.shape", "A component state record must be a plain object.")]
	};
	let t = /* @__PURE__ */ new Set([
		"format",
		"component",
		"componentVersion",
		"stateVersion",
		"key",
		"documentId",
		"data",
		"random"
	]);
	for (let n of Object.keys(e)) if (!t.has(n)) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.key", `Unknown component state key "${n}".`)]
	};
	if (e.format !== "reactive-md-component-state/v1") return {
		ok: !1,
		diagnostics: [N("local.runtime.state.format", `Unsupported component state format; expected "${x}".`)]
	};
	let n = e.component;
	if (typeof n != "string" || n.trim() === "" || n.length > k) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.component", "Component name must be a non-empty string.")]
	};
	let r = e.componentVersion;
	if (typeof r != "string" || r.trim() === "" || r.length > A) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.component-version", "Component version must be a non-empty string.")]
	};
	let i = e.stateVersion;
	if (typeof i != "number" || !Number.isInteger(i) || i < 0 || i > ee) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.version", "State version must be a non-negative integer.")]
	};
	let a = e.key;
	if (typeof a != "string" || a.trim() === "" || a.length > j) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.key-name", "State key must be a non-empty string.")]
	};
	let o = e.documentId;
	if (o !== void 0 && (typeof o != "string" || o.trim() === "" || o.length > 256)) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.document", "State documentId must be a non-empty string.")]
	};
	let s;
	try {
		s = z(e.data);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [N("local.runtime.state.data", `Invalid component state data: ${e instanceof Error ? e.message : String(e)}.`)]
		};
	}
	let c;
	if (e.random !== void 0 && (c = h(e.random) ?? void 0, c === void 0)) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.random", "Invalid random state.")]
	};
	let l = {
		format: x,
		component: n,
		componentVersion: r,
		stateVersion: i,
		key: a,
		...o === void 0 ? {} : { documentId: o },
		data: s,
		...c === void 0 ? {} : { random: c }
	};
	return M.encode(JSON.stringify(l)).length > 16384 ? {
		ok: !1,
		diagnostics: [N("local.runtime.state.size", `Component state exceeds the ${C}-byte limit.`)]
	} : {
		ok: !0,
		record: Object.freeze(l)
	};
}
function H(e) {
	let t = e;
	if (typeof e == "string") {
		if (e.length > 1048576) return {
			ok: !1,
			diagnostics: [N("local.runtime.state.size", "The component state payload is too large.")]
		};
		try {
			t = JSON.parse(e);
		} catch {
			return {
				ok: !1,
				diagnostics: [N("local.runtime.state.json", "The component state payload is not valid JSON.")]
			};
		}
	}
	if (!P(t)) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.shape", "The component state document must be a plain object.")]
	};
	if (t.format !== "reactive-md-component-state-document/v1") return {
		ok: !1,
		diagnostics: [N("local.runtime.state.document-format", `Unsupported component state document format; expected "${S}".`)]
	};
	let n = t.configKey;
	if (n !== void 0 && !I(n)) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.config-key", "The component state configKey must be a non-empty bounded string.")]
	};
	if (!P(t.records)) return {
		ok: !1,
		diagnostics: [N("local.runtime.state.records", "Component state records must be a plain object.")]
	};
	let r = {}, i = [], a = [], o = 0;
	for (let e of Object.keys(t.records)) {
		let n = V(t.records[e]);
		n.ok ? n.record.key === e ? (o += M.encode(JSON.stringify(n.record)).length, o > 262144 ? (a.push(e), i.push(N("local.runtime.state.total-size", `Component state exceeds the ${w}-byte document limit.`))) : r[e] = n.record) : (a.push(e), i.push(N("local.runtime.state.key-mismatch", `Component state record "${e}" declares a different key "${n.record.key}".`))) : (a.push(e), i.push(...n.diagnostics));
	}
	return {
		ok: !0,
		...n === void 0 ? {} : { configKey: n },
		records: r,
		diagnostics: i,
		skipped: a
	};
}
function U(e) {
	let t = H(e);
	if (!t.ok) return t;
	let n = {};
	for (let [e, r] of Object.entries(t.records)) n[e] = r;
	return {
		ok: !0,
		document: Object.freeze({
			format: S,
			...t.configKey === void 0 ? {} : { configKey: t.configKey },
			records: Object.freeze(n)
		}),
		records: Object.freeze(n),
		diagnostics: t.diagnostics,
		skipped: t.skipped
	};
}
function re(e) {
	let t = s(e), n = e.sourceDigest, r = e.knownKeys, i = e.configKey;
	if (i !== void 0 && !I(i)) throw TypeError("configKey must be a non-empty bounded string.");
	let a = Object.freeze((e.legacyConfigKeys ?? []).filter(I)), o = e.writeDelayMs ?? 0;
	if (typeof o != "number" || !Number.isFinite(o) || o < 0) throw TypeError("writeDelayMs must be a non-negative finite number.");
	let l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Set(), p = [], m = e.storage, h = null, g = null, _ = !1, v = () => {
		for (let e of f) e();
	};
	function y() {
		if (m === void 0) return !0;
		try {
			let e = D.snapshot();
			return Object.keys(e.records).length === 0 ? m.remove() : m.write(e), h = null, !0;
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return t !== h && (h = t, p.push(N("local.runtime.state.storage", `The component state could not be persisted: ${t}`, "warning"))), !1;
		}
	}
	let b = () => {
		g !== null && (clearTimeout(g), g = null);
	};
	function C() {
		_ && (b(), y() && (_ = !1));
	}
	let T = () => {
		m !== void 0 && (o <= 0 ? y() : (_ = !0, g === null && (g = setTimeout(() => {
			g = null, C();
		}, Math.min(o, 2147483647)))));
	}, E = (e) => {
		let t = 0;
		for (let [n, r] of l) n !== e && (t += M.encode(JSON.stringify(r)).length);
		return t;
	}, D = {
		documentId: t,
		sourceDigest: n,
		key(e) {
			return c({
				documentId: t,
				sourceDigest: n,
				nodeId: e.nodeId,
				stateKey: e.stateKey
			});
		},
		handle(e) {
			let n = D.key({
				nodeId: e.nodeId,
				stateKey: e.stateKey
			}), r = u.get(n), i = !1;
			r !== void 0 && r !== e.nodeId ? (i = !0, d.has(n) || (d.add(n), p.push(N("local.runtime.state.duplicate-key", `Component state key "${n}" is used by more than one component instance.`)))) : u.set(n, e.nodeId);
			let a = {
				key: n,
				component: e.component,
				componentVersion: e.componentVersion,
				duplicate: i,
				load() {
					if (i) return null;
					let e = l.get(n);
					return e === void 0 ? null : B(e);
				},
				save(r, a) {
					if (i) return {
						ok: !1,
						diagnostics: [N("local.runtime.state.duplicate-key", `Component state key "${n}" is used by more than one component instance.`)]
					};
					let o = a?.version ?? e.stateVersion ?? 0, s = V({
						format: x,
						component: e.component,
						componentVersion: e.componentVersion,
						stateVersion: o,
						key: n,
						documentId: t,
						data: r,
						...a?.random === void 0 ? {} : { random: a.random }
					});
					if (!s.ok) return {
						ok: !1,
						diagnostics: s.diagnostics
					};
					let c = M.encode(JSON.stringify(s.record)).length;
					return E(n) + c > 262144 ? {
						ok: !1,
						diagnostics: [N("local.runtime.state.total-size", `Component state exceeds the ${w}-byte document limit.`)]
					} : (l.set(n, s.record), T(), v(), {
						ok: !0,
						diagnostics: [],
						record: B(s.record)
					});
				},
				clear() {
					i || l.delete(n) && (T(), v());
				}
			};
			return Object.freeze(a);
		},
		load(e) {
			let t = l.get(e);
			return t === void 0 ? null : B(t);
		},
		clear(e) {
			l.delete(e) && (T(), v());
		},
		snapshot() {
			let e = {};
			for (let [t, n] of l) e[t] = B(n);
			return Object.freeze({
				format: S,
				...i === void 0 ? {} : { configKey: i },
				records: Object.freeze(e)
			});
		},
		restore(e) {
			let n = H(e);
			if (!n.ok) return p.push(...n.diagnostics), {
				accepted: [],
				skipped: [],
				diagnostics: n.diagnostics
			};
			if (n.configKey !== void 0 && !L(n.configKey, i, a)) {
				let e = [.../* @__PURE__ */ new Set([...n.skipped, ...Object.keys(n.records)])];
				return n.diagnostics.push(N("local.runtime.state.config-mismatch", `Saved component state belongs to configuration "${n.configKey}", not "${i}".`, "warning")), p.push(...n.diagnostics), {
					accepted: [],
					skipped: e,
					diagnostics: n.diagnostics
				};
			}
			let o = [], s = typeof r == "function" ? r() : r;
			for (let [e, r] of Object.entries(n.records)) r.documentId !== void 0 && r.documentId !== t ? (n.skipped.push(e), n.diagnostics.push(N("local.runtime.state.document-mismatch", `Saved state key "${e}" belongs to a different document.`))) : s !== void 0 && !s.has(e) ? (n.skipped.push(e), n.diagnostics.push(N("local.runtime.state.unknown-component", `Saved state key "${e}" does not match any component in this document.`))) : (l.set(e, r), o.push(e));
			return n.diagnostics.length && p.push(...n.diagnostics), o.length && v(), {
				accepted: o,
				skipped: n.skipped,
				diagnostics: n.diagnostics
			};
		},
		flush() {
			C();
		},
		diagnostics() {
			return Object.freeze([...p]);
		},
		subscribe(e) {
			return f.add(e), () => {
				f.delete(e);
			};
		}
	}, O = e.initial;
	if (O === void 0 && m !== void 0) try {
		let e = m.read();
		e !== null && (O = e);
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		p.push(N("local.runtime.state.storage", `The component state could not be read: ${t}`, "warning"));
	}
	return O !== void 0 && D.restore(O), Object.freeze(D);
}
// src/runtime-services/network.ts
var W = 65536, G = Object.freeze({
	code: "unavailable",
	message: "This channel operation is unavailable."
}), K = Object.freeze({
	code: "cancelled",
	message: "The operation was cancelled."
}), q = Object.freeze({
	code: "invalid-data",
	message: "The channel data is invalid."
}), J = Object.freeze({
	code: "transport",
	message: "The channel could not communicate with its endpoint."
}), ie = Object.freeze({
	code: "rejected",
	message: "A channel listener failed."
}), ae = 0;
function Y(e) {
	return {
		ok: !1,
		error: e
	};
}
var X = Object.freeze({
	supports: () => !1,
	submit: async () => Y(G),
	subscribe(e, t) {
		let n = !0;
		return queueMicrotask(() => {
			if (n) try {
				t({
					type: "error",
					error: G
				});
			} catch {}
		}), () => {
			n = !1;
		};
	}
});
function Z(e = W) {
	if (!Number.isSafeInteger(e) || e < 1) throw TypeError("A channel byte budget must be a positive integer.");
	return e;
}
function Q(e, t) {
	let n = t;
	function r(e) {
		if (n -= e, n < 0) throw RangeError();
	}
	function i(e, t) {
		if (r(1), t > 64) throw RangeError();
		if (e === null || typeof e == "boolean") return e;
		if (typeof e == "string") return r(e.length), e;
		if (typeof e == "number" && Number.isFinite(e)) return e;
		if (Array.isArray(e)) {
			if (e.length > n) throw RangeError();
			let r = [];
			for (let n = 0; n < e.length; n += 1) {
				let a = Object.getOwnPropertyDescriptor(e, String(n));
				if (!a || !("value" in a)) throw TypeError();
				r.push(i(a.value, t + 1));
			}
			return Object.freeze(r);
		}
		if (typeof e != "object" || !e) throw TypeError();
		let a = Object.getPrototypeOf(e);
		if (a !== Object.prototype && a !== null) throw TypeError();
		let o = Object.create(null);
		for (let n of Object.keys(e)) {
			r(n.length);
			let a = Object.getOwnPropertyDescriptor(e, n);
			if (!a || !("value" in a)) throw TypeError();
			o[n] = i(a.value, t + 1);
		}
		return Object.freeze(o);
	}
	let a = i(e, 0);
	if (new TextEncoder().encode(JSON.stringify(a)).length > t) throw RangeError();
	return a;
}
function $(e, t) {
	let n = t(e);
	if (n !== !0) return typeof n == "string" && n.trim() ? Object.freeze({
		code: "invalid-data",
		message: n
	}) : q;
}
function oe(e) {
	if (!e) return {
		network: X,
		dispose() {}
	};
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e.channels)) {
		let { submit: e, subscribe: i } = r;
		if (e && (typeof e.validate != "function" || typeof e.send != "function")) throw TypeError("A submit channel requires a validator and a send function.");
		if (i && (typeof i.validate != "function" || typeof i.open != "function")) throw TypeError("A subscription channel requires a validator and an open function.");
		t.set(n, {
			...e && { submit: {
				maxBytes: Z(e.maxBytes),
				validate: e.validate.bind(e),
				send: e.send.bind(e)
			} },
			...i && { subscribe: {
				maxBytes: Z(i.maxBytes),
				validate: i.validate.bind(i),
				open: i.open.bind(i)
			} }
		});
	}
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Map(), a = !1;
	function o(e) {
		let t = n.get(e);
		return t || n.set(e, t = new AbortController()), t.signal;
	}
	function s(t, n) {
		try {
			t.notify(Object.freeze(n));
		} catch {
			try {
				e?.onListenerError?.(ie);
			} catch {}
		}
	}
	function c(e) {
		try {
			e?.();
		} catch {}
	}
	function l(e, t) {
		i.delete(e), t.listeners.clear(), t.events.length = 0, t.controller.abort(), c(t.release);
	}
	function u(e, t) {
		if (!(a || e.controller.signal.aborted) && (e.events.push({
			event: t,
			recipients: [...e.listeners],
			status: e.status
		}), !e.dispatching)) {
			e.dispatching = !0;
			try {
				for (let t = 0; t < e.events.length; t += 1) {
					let { event: n, recipients: r, status: i } = e.events[t];
					for (let t of r) e.listeners.has(t) && (t.initial || (t.initial = !0, n.type !== "status" && s(t, {
						type: "status",
						state: i
					})), e.listeners.has(t) && s(t, n));
				}
			} finally {
				e.events.length = 0, e.dispatching = !1;
			}
		}
	}
	function d(e, t, n) {
		let r = t.controller.signal;
		if (r.aborted) return;
		let i = (e) => {
			r.aborted || t.status === e || (t.status = e, u(t, {
				type: "status",
				state: e
			}));
		}, a = (e) => {
			u(t, {
				type: "error",
				error: Object.freeze({ ...e })
			});
		}, s = (e) => {
			if (r.aborted) return;
			let i, o;
			try {
				i = Q(e, n.maxBytes ?? 65536), o = $(i, n.validate);
			} catch {
				a(q);
				return;
			}
			o ? a(o) : u(t, {
				type: "data",
				value: i
			});
		}, l = () => {
			r.aborted || (a(J), i("closed"));
		}, d = (e) => {
			r.aborted ? c(e) : t.release = e;
		};
		try {
			let t = n.open({
				signal: r,
				sessionSignal: o(e),
				status: i,
				error: a,
				data: s
			});
			typeof t == "function" ? d(t) : Promise.resolve(t).then(d, l);
		} catch {
			l();
		}
	}
	return {
		network: Object.freeze({
			supports(e, n) {
				return !a && (n === "submit" || n === "subscribe") && t.get(e)?.[n] !== void 0;
			},
			async submit(e, n, i) {
				let s = a ? void 0 : t.get(e)?.submit;
				if (!s) return Y(G);
				if (i?.signal?.aborted) return Y(K);
				let c;
				try {
					let e = Q(n, s.maxBytes ?? 65536);
					if (typeof e != "object" || !e || Array.isArray(e)) return Y(q);
					c = e;
					let t = $(c, s.validate);
					if (t) return Y(t);
				} catch {
					return Y(q);
				}
				let l = i?.signal;
				if (a || l?.aborted) return Y(K);
				let u = new AbortController();
				return new Promise((t) => {
					let n = !1, a = (e) => {
						n || (n = !0, l?.removeEventListener("abort", d), r.delete(d), t(e));
					}, d = () => {
						a(Y(K)), u.abort();
					};
					r.add(d), l?.addEventListener("abort", d, { once: !0 });
					try {
						let t = s.send(c, {
							signal: u.signal,
							sessionSignal: o(e),
							requestId: String(++ae),
							...i?.idempotencyKey === void 0 ? {} : { idempotencyKey: i.idempotencyKey }
						});
						Promise.resolve(t).then(a, () => a(Y(J)));
					} catch {
						a(Y(J));
					}
				});
			},
			subscribe(e, n) {
				if (a) return X.subscribe(e, n);
				let r = {
					notify: n,
					initial: !1
				}, o = t.get(e)?.subscribe;
				if (!o) {
					let e = !0;
					return queueMicrotask(() => {
						e && !a && s(r, {
							type: "error",
							error: G
						});
					}), () => {
						e = !1;
					};
				}
				let c = i.get(e), u = c ?? {
					controller: new AbortController(),
					listeners: /* @__PURE__ */ new Set(),
					events: [],
					status: "connecting",
					dispatching: !1
				};
				return u.listeners.add(r), c || i.set(e, u), queueMicrotask(() => {
					u.listeners.has(r) && !r.initial && (r.initial = !0, s(r, {
						type: "status",
						state: u.status
					})), c || d(e, u, o);
				}), () => {
					u.listeners.delete(r) && u.listeners.size === 0 && l(e, u);
				};
			}
		}),
		dispose() {
			if (!a) {
				a = !0;
				for (let e of r) e();
				for (let [e, t] of i) l(e, t);
				for (let e of n.values()) e.abort();
				n.clear(), t.clear();
			}
		}
	};
}
export { s as A, c as C, a as D, i as E, o as O, v as S, r as T, y as _, x as a, b, O as c, w as d, re as f, m as g, p as h, S as i, d as j, u as k, E as l, f as m, oe as n, C as o, U as p, X as r, T as s, W as t, D as u, g as v, l as w, _ as x, h as y };
