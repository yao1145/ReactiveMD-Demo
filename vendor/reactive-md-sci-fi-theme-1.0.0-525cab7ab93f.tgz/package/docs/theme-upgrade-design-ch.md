# SF-01 主题升级设计文档

**状态**：待实施
**对象**：`others/sci-fi-theme`（参考主题包），同步目标 `ReactiveMD/examples/sci-fi-theme`
**对照内核**：`reactive-md@0.8.0`，样式契约 `reactive-md-styles-1`
**合并来源**：`docs/optimization-notes-ch.md`（2026-11-14 审计）与
`docs/theme-update-report-ch.md`（2026-11-15 复审计）。本文取代两者的实施部分，
原文件保留为历史记录。

本文分四部分：整体要求（§1）、缺陷与缺口修复（§2）、NeonBlade 接入（§3）、
分工设计（§4）。

---

# 第一部分 整体要求

## 1.1 目标

把 `sci-fi-theme` 从"在重构前模型上写的、能跑但有多处失效的主题"，升级为
"完全对齐 `reactive-md-styles-1`、与 default 基线无冲突、且视觉契约自洽的主题"。

三条验收线：

1. **契约一致**：任何圆角、间距、时长、对比度都能被测试断言；
2. **无覆盖冲突**：主题不覆盖它不该改的基线行为（如把 `<toggle>` 改成勾选框）；
3. **无失效声明**：主题里写的每条规则都真实命中某个元素。

## 1.2 目标主题形态

| 项 | 现状 | 目标 |
| --- | --- | --- |
| 圆角 | 契约"0–4px"，实际泄漏 5 处默认圆角 | **收紧为 0–2px**，全部命名圆角显式声明 |
| `<toggle>` | 16px 方框勾选，与 `<checkbox>` 同形 | **40×20 方形开关**，方形滑块 14px，`travel = 20px` |
| 角切 | 无（纯矩形 + 8px 角标线） | **引入角切**：面板/卡片/按钮/图表框右下 45° 切角 |
| 图表 | 写了 `stroke`/`fill` 但被行内样式覆盖；柱 4px 圆角 | 全部走 `--rmd-chart-*` 变量；柱 0 圆角；dim `.45` |
| 版本 | vendor tarball 落后内核一个提交 | 与当前 HEAD 同源构建 |
| 动画 | 只有 transition，无 keyframes（SDK 拒绝） | 保持，不引入 keyframes |

## 1.3 已确认的四项决策

| 决策 | 取值 | 影响面 |
| --- | --- | --- |
| toggle 形态 | **接受变化**：胶囊 → 方形开关 | §2.2，破坏性视觉变更 |
| 圆角契约 | **收紧为 0–2px** | §2.3，步骤点变方块、日历日期变方格 |
| 角切 | **引入** | §3.6，新增 `src/notch.css` 资源 |
| 图表 dim 透明度 | **`.45`** | §2.4，刚好过 3:1 |

## 1.4 平台硬约束（不可协商）

来自 `defineLocalTheme` 的校验，任何设计都不能越过：

| 约束 | 后果 |
| --- | --- |
| 拒绝 `@keyframes` / `*-keyframes` | 只能做 transition，**不能做任何动画** |
| 拒绝 `@import` | 资源必须内联或拆成多个 `css` 条目 |
| `url()` 只接受 `data:` | 图标只能是 data URI 或纯 CSS 绘制 |
| 拒绝 `:root` / `html` / `body` | 全部规则必须从 `[data-rmd-theme="sci-fi"]` 起 |
| 禁止从主题根用 `+` / `~` 逃逸，`:has()` 内同样 | 实例隔离 |
| 32 个资源 / 单资源 256 KiB / 总计 512 KiB | 当前 2 个资源、约 63 KiB，余量充足 |
| 字符串外禁止 CSS 转义 | 不能写 `\75` 之类的伪装 |
| `@font-face` 家族名被重写 | 字体隔离，不影响本任务 |

**当前用量**：`tokens.css` 13 KiB + `components.css` 48 KiB = 61 KiB，可再加
一个 2–4 KiB 的 `notch.css`。

## 1.5 设计契约（测试可断言）

| 项 | 规则 |
| --- | --- |
| 圆角 | 全部落在 `0px` 或 `2px`；不允许 `50%`、`999px`、`>2px` |
| 间距 | 4px 基数：4 / 8 / 12 / 16 / 24 / 32 / 48 |
| 时长 | 只用 `--motion-fast`(80ms) / `--motion-base`(120ms) / `--motion-slow`(180ms) |
| 对比度 | 正文 ≥ 7:1；次级/弱化 ≥ 4.5:1；图表系列 ≥ 3:1 |
| 立面 | 只用 1px 环与 1–2px 描边，禁止模糊投影与发光 |
| 语言 | 标签/元数据/数值等宽大写；正文无衬线、正常大小写 |
| 状态 | 不只用颜色：同时改变描边、内嵌线或标签 |

## 1.6 层叠与加载模型

```
rmd.reset → rmd.defaults → rmd.components → rmd.themes → rmd.overrides
```

- `reactive-md/styles.css` 提供**完整 default 基线**，主题只写差异。
- 主题资源由 SDK 包进 `@layer rmd.themes`，并逐条重定到
  `[data-rmd-theme="sci-fi"]`。
- 直接引入时，文件必须先声明层序（现有 `sci-fi.css:1` 已正确）。
- **加载顺序不再影响结果**（已实测：正序与逆序计算样式完全一致），
  但仍按"基线 → 主题"书写，保持可读。

## 1.7 交付物

| 文件 | 变化 |
| --- | --- |
| `src/tokens.css` | 补圆角、图表、UIArc、开关变量 |
| `src/components.css` | 修 toggle、删死规则、补图表部件、补缺口 |
| `src/notch.css` | **新增**，角切系统 |
| `src/sci-fi.css` | 增加一条 `@import './notch.css'` |
| `src/theme.ts` | 资源数组增加 `notch.css` 条目 |
| `sci-fi-theme.test.ts` | 补层、keyframes、圆角上限断言 |
| `demo/main.tsx` | 去掉重复直接导入，改为只导 `sci-fi.css` |
| `vendor/*.tgz` + `package-lock.json` | 换到与 HEAD 同源构建 |
| `README-ch.md` / `docs/design-system-ch.md` | 同步新契约与新形态 |
| `ReactiveMD/examples/sci-fi-theme/**` | 结尾整体同步 |

## 1.8 完成定义

每个任务完成后必须同时满足：

```sh
npm run test        # vitest，当前 7 个用例，改造后约 9 个
npm run typecheck   # tsc --noEmit
npm run build       # vite build
```

**不做**浏览器验证（截图、Playwright、视觉比对）。浏览器验收由用户在所有任务
合并后统一执行，见 §4.6。

---

# 第二部分 缺陷与缺口修复

## 2.1 D1 版本对齐（前置，必须先做）

**问题**：主题 `vendor/reactive-md-0.8.0-92733a4c0cc3.tgz` 构建于 2026-11-14 20:10，
内核重构 `4d26832` 在当晚 23:12。主题 tarball 缺 41 个自定义属性：

```
--dialog-backdrop --tooltip-bg --tooltip-ink
--radius-hairline --radius-circle --radius-2xs --radius-xs
--radius-inset --radius-toolbar --radius-xl --shadow-lg
--rmd-button-press-shadow --rmd-diagram-node-shadow
及整套 --rmd-*-shadow-geometry / *-shadow-opacity
```

`node_modules` 是指向 `ReactiveMD-Demo/node_modules` 的软链接（当前是
`2a1df8bd` 构建），所以 `npm test` 跑新内核、通过无意义；真跑 `npm ci` 会
**静默降级**一个提交。

**动作**：

1. 用核心仓库当前 HEAD 重新打包：`npm pack`（`prepack` 会先 build）；
2. 以内容哈希命名放入 `vendor/`，同步 `package.json` 与 `package-lock.json`；
3. `npm ci` 验证解析到新包；
4. 记录内核提交号到 `vendor/README-ch.md`（若存在）。

**验收**：`grep -c -- '--radius-hairline' node_modules/reactive-md/dist-library/reactive-md.css`
返回 ≥ 1。

## 2.2 D2 toggle 与 checkbox 解耦（最高优先）

**问题**：主题的 `[data-rmd-theme="sci-fi"] .md-toggle-label input` 同时命中
`<toggle>` 与 `<checkbox>`（两者 DOM 相同：`label.md-toggle-label > input + span`）。
该规则在 `rmd.themes` 层，永远赢过基线在 `rmd.components` 层的开关皮肤，
结果 `<toggle>` 渲染成 16×16 方框、无位移、无 track，整套 `--rmd-switch-*`
变量从未被消费。

**两者的区分依据**（可用于收窄任何勾选类规则）：

| 组件 | 包装类 | `data-rmd-component` |
| --- | --- | --- |
| `<toggle>` | `md-control md-toggle local-toggle` | `toggle` |
| `<checkbox>` | `md-control local-checkbox` | `checkbox` |

### 2.2.1 勾选类：收窄选择器

把现有四条规则里的 `.md-toggle-label input` 换成 `.local-checkbox .md-toggle-label input`，
其余三类（`.local-checklist-item input`、`.local-multi-option input`、
`.local-radio-option input`）保持不变。

同时用 `--rmd-uiarc-checkbox-size` 控制尺寸，不再硬编码 16px。

### 2.2.2 toggle：方形开关

```css
[data-rmd-theme="sci-fi"] .local-toggle .md-toggle-label input[type="checkbox"] {
  -webkit-appearance: none;
  appearance: none;
  -webkit-mask-image: none;
  mask-image: none;
  box-sizing: border-box;
  flex: 0 0 auto;
  inline-size: 40px;
  block-size: 20px;
  margin: 0;
  padding: 0;
  border: 1px solid var(--line-strong);
  border-radius: 0;
  background-color: var(--sf-field-bg);
  /* 一层画滑块；轨道颜色由 background-color 承担 */
  background-image: linear-gradient(var(--control-thumb), var(--control-thumb));
  background-repeat: no-repeat;
  background-size: 14px 14px;
  background-position: left 2px center;
  box-shadow: var(--rmd-switch-shadow, var(--rmd-switch-shadow-geometry) var(--line));
  cursor: pointer;
  transition:
    background-color var(--motion-fast) var(--ease-standard),
    background-position var(--motion-base) var(--ease-standard),
    border-color var(--motion-fast) var(--ease-standard);
}

[data-rmd-theme="sci-fi"] .local-toggle .md-toggle-label input[type="checkbox"]:checked {
  border-color: var(--accent);
  background-color: var(--accent);
  background-image: linear-gradient(var(--accent-ink), var(--accent-ink));
  background-position: right 2px center;
}

[data-rmd-theme="sci-fi"] .local-toggle .md-toggle-label:hover
  input[type="checkbox"]:not(:disabled):not(:checked) {
  border-color: var(--sf-field-hover, var(--accent-line));
}

[data-rmd-theme="sci-fi"] .local-toggle .md-toggle-label
  input[type="checkbox"]:focus-visible {
  outline: var(--focus-outline);
  outline-offset: 2px;
}

[data-rmd-theme="sci-fi"] .local-toggle .md-toggle-label
  input[type="checkbox"]:disabled {
  border-color: var(--line);
  background-color: var(--sf-hatch);
  opacity: var(--disabled-opacity);
  cursor: not-allowed;
}
```

几何推导（写进注释）：

```
travel = 40(轨道) − 2×1(边框) − 14(滑块) − 2×2(两侧间隙) = 20px
```

两端位置用 `left 2px center` / `right 2px center` 表达，不写 `20px` 魔法数，
换尺寸时只改三处。

**为什么不用胶囊**：`border-radius` 会突破 0–2px 契约，且方角是本主题的识别要素。

**已知限制**：`<toggle>` 输出裸 `input[type=checkbox]`，没有 `role="switch"`，
也没有独立 track/thumb 节点。视觉上是开关，语义上仍是复选框。若要补语义，
需要改内核组件，不在本任务范围；应在 `docs/design-system-ch.md` 注明。

### 2.2.3 checkbox 的混合态

主题用 `background-image` 覆盖了 `:checked`，但遗漏 `:indeterminate`；
基线靠 `accent-color` 表达混合态，被 `background-color` 覆盖后渲染成纯实心块。
见 §3.1。

## 2.3 D3 圆角 token 补全

基线新增了一批命名圆角，主题一个都没声明，导致 5 处默认圆角泄漏：

| token | 基线值 | 消费者 | 实测 |
| --- | --- | --- | --- |
| `--radius-circle` | `50%` | 步骤点、画廊箭头、tooltip 色点、日历今日点、选择标记 | 步骤点 50%、画廊箭头 50% |
| `--radius-xl` | `22px` | `.local-coordinate-surface`（Mafs 画布） | 22px |
| `--radius-toolbar` | `9px` | `.rmd-diagram-zoom` 容器 | 未覆盖 |
| `--radius-inset` | `6px` | 图解缩放/tooltip 关闭按钮 | 未覆盖 |
| `--radius-hairline` | `1px` | 表格选择勾 | 未覆盖 |
| `--radius-2xs` / `-xs` | `2` / `3px` | 链接焦点、页签指示条、图例色块 | 未覆盖 |
| `--pu-radius-md` | `10px` | **公共原生按钮** `border-radius` | plot 图例按钮 10px |

`--pu-radius-md` 尤其隐蔽：基线给所有原生 `<button>` 用的就是它，所以
plot 图例按钮是 10px，而主题 `.md-button` 是 0——同一文档两种按钮圆角。

### 2.3.1 `tokens.css` 新增块（放在现有 Radius 注释块之后）

```css
  /* 共享基线在 reactive-md-styles-1 里新增了命名圆角。
     漏掉任何一个，对应部件就会保留默认圆度。 */
  --radius-xl: var(--sf-radius-0);
  --radius-circle: var(--sf-radius-0);
  --radius-hairline: var(--sf-radius-1);
  --radius-2xs: var(--sf-radius-1);
  --radius-xs: var(--sf-radius-1);
  --radius-inset: var(--sf-radius-0);
  --radius-toolbar: var(--sf-radius-0);

  /* 基线原语，被公共按钮与部分表面直接消费。 */
  --pu-radius-xs: var(--sf-radius-1);
  --pu-radius-sm: var(--sf-radius-1);
  --pu-radius-md: var(--sf-radius-1);
  --pu-radius-lg: var(--sf-radius-1);
  --pu-radius-xl: var(--sf-radius-1);
```

其中 `--sf-radius-0: 0px`、`--sf-radius-1: 2px`（已有），符合 0–2px 新契约。

### 2.3.2 `components.css` 的针对性修补

token 化覆盖不到的部件，用规则补：

```css
/* 步骤点：环形 → 方形节点 */
[data-rmd-theme="sci-fi"] .local-steps-dot {
  border-radius: 0;
  border-width: 1px;
  font-size: var(--sf-type-micro);
  font-family: var(--font-mono);
}

/* 步骤轨道节点尺寸，落在 4px 网格 */
[data-rmd-theme="sci-fi"] .local-steps-rail {
  --pu-rail-dot: 20px;
  --pu-rail-track: var(--line);
  --pu-rail-fill: var(--accent);
}
```

`--pu-rail-dot` 定义在 `.local-steps-rail` 上（基线写在同处），不是文档根。

### 2.3.3 剩余泄漏点的处置

| 部件 | 处置 |
| --- | --- |
| `.local-coordinate-surface` | 由 `--radius-xl` 归零，无需额外规则 |
| `.rmd-diagram-zoom` | 由 `--radius-toolbar` 归零；删除现有的重复 `border-radius: 0` |
| `.rmd-diagram-tooltip-close`、缩放按钮 | 由 `--radius-inset` 归零 |
| plot 图例按钮 | 由 `--pu-radius-md` 归零 |
| 画廊箭头 `.rmd-gallery-button` | 由 `--radius-circle` 归零；补一条 44px→32px 尺寸规则见 §2.6 |
| 日历日 | 由 `--rmd-calendar-day-radius: 0` 归零（§2.6） |
| 图表 tooltip 色点 | 由 `--radius-circle` 归零 |

## 2.4 D4 图表绘制变量

**问题**：交互图表把绘制值写成**行内 style**：

```js
// ReactiveMD/src/components/default-chart.tsx:38-40
const GRID_STROKE      = 'var(--rmd-chart-grid, var(--chart-grid))';
const AXIS_TITLE_FILL  = 'var(--rmd-chart-axis-title, var(--ink-soft))';
const GUIDE_STROKE     = 'var(--rmd-chart-guide, var(--line-strong))';
```

主题里写的 `stroke:` / `fill:` 全部输给行内样式。实测主题的
`rmd-chart-grid` 规则不生效，引导线拿到的是 `--line-strong` 而不是 accent。
另外柱子的 `rx` 是 **4**（基线 `--rmd-chart-bar-radius: 4px`），与设计规范
"柱子是清晰矩形"不符。

### 2.4.1 `tokens.css` 图表变量块（浅色，紧跟 `--chart-axis`）

```css
  /* 交互图表用行内 style 消费这些变量，主题规则赢不了 stroke/fill，
     只能改变量。 */
  --rmd-chart-bar-radius: 0px;
  --rmd-chart-line-width: 1.6;
  --rmd-chart-line-highlight-width: 2.4;
  --rmd-chart-point-stroke-width: 1.5;
  --rmd-chart-area-opacity: 0.1;
  --rmd-chart-dim-opacity: 0.45;
  --rmd-chart-mark-stroke: var(--surface);
  --rmd-chart-grid: var(--chart-grid);
  --rmd-chart-axis: var(--chart-axis);
  --rmd-chart-axis-title: var(--ink-soft);
  --rmd-chart-guide: var(--accent);
```

暗色块只需重复 `--rmd-chart-dim-opacity: 0.45`（其余继承）。

**dim 取值依据**（实测，暗色方案）：

| 透明度 | 混色结果 | 对 `--surface` 对比度 |
| --- | --- | --- |
| .22（基线） | `#1a3c47` | 1.61:1 ✗ |
| **.45（采用）** | `#2a6a77` | **3.09:1 ✓** |
| .55 | `#307d8d` | 4.01:1 |

### 2.4.2 删除失效声明

`components.css` §9c 中删除这几条（保留 `stroke-dasharray` 与字体类）：

```css
/* 删掉这三条的 stroke/fill 部分，其余保留 */
[data-rmd-theme="sci-fi"] .rmd-chart-grid      { stroke: var(--chart-grid); }   /* 删 */
[data-rmd-theme="sci-fi"] .rmd-chart-axis-label{ fill: var(--chart-axis); }     /* 删 */
[data-rmd-theme="sci-fi"] .rmd-chart-guide     { stroke: var(--accent); }       /* 删 */
```

改为在注释里说明"绘制值由 tokens.css 的 `--rmd-chart-*` 控制"。

### 2.4.3 补齐缺失的图表部件

主题只覆盖了 15 个 `rmd-chart-*` 类，缺以下部件（基线已定义）：
`-stage`、`-svg`、`-tooltip-row`、`-tooltip-label`、`-tooltip-value`、
`-tooltip-dot`、`-tooltip-foot`、`-legend-label`、`-legend-share`。

补法见 §3.4（tooltip 斜边）与 §3.2（legend 等宽大写）。

## 2.5 D5 死选择器清理

| 位置 | 问题 | 处置 |
| --- | --- | --- |
| `.local-range-value` | 内核无此元素，`RangeSliderView` 用 `md-slider-value` | 删除 |
| `.md-select-input` × 8 条 | select 是 Radix `<button data-rmd-part="trigger">`；该 class 只作基线兜底 | 删除；`trigger`/`menu` 规则已存在 |
| `.local-visual .local-visual` | 为旧嵌套 `.local-visual` 而写；交互路径是 `figure.local-visual` 包 `div.rmd-chart` | 删除 |
| `--focus-ring` | 主题定义但内核从不消费（实际用 `--pu-focus-halo`） | 删除定义，改为覆盖 `--pu-focus-halo` |

**不是死规则**：`.local-alert-success` / `-warning` 是 `layout.tsx:529` 用
`local-alert-${tone}` 模板拼出来的，静态扫描会漏判。保留。

## 2.6 D6 缺口补齐（继承 default 外观的部分）

这些不是错，只是与 SF-01 语言不一致。逐项：

### 2.6.1 步骤指示器

见 §2.3.2。补 `.local-steps-dot.is-complete` / `.is-current` 的实心/空心语义
（基线已有，主题只需确认与方角不冲突）。

### 2.6.2 日历与日期选择器

```css
[data-rmd-theme="sci-fi"] {
  --rmd-calendar-day-radius: 0px;
  --rmd-calendar-nav-radius: 0px;
  --rmd-date-picker-radius: 0px;
  --rmd-date-picker-popover-radius: 0px;
  --rmd-date-picker-action-radius: 0px;
  --rmd-select-radius: 0px;
  --rmd-select-menu-radius: 0px;
  --rmd-select-item-radius: 0px;
  --rmd-select-menu-radius-offset: 0px;
  --rmd-select-item-radius-offset: 0px;
  --rmd-slider-bubble-radius: 0px;
  --rmd-slider-tick-radius: 0px;
}
```

这些是组件变量而非经典圆角 token，必须单独写；放在 `tokens.css` 的
组件层（浅色块）即可，暗色不需要重复。

### 2.6.3 画廊

```css
[data-rmd-theme="sci-fi"] .rmd-gallery-button {
  border-radius: 0;
  inline-size: 32px;
  block-size: 32px;
  flex-basis: 32px;
  border-width: 1px;
}

[data-rmd-theme="sci-fi"] .rmd-gallery-thumb {
  border-radius: 0;
  block-size: 2px;
}

[data-rmd-theme="sci-fi"] .rmd-gallery-count,
[data-rmd-theme="sci-fi"] .rmd-gallery-caption {
  font-family: var(--font-mono);
  letter-spacing: var(--sf-track-label);
  text-transform: uppercase;
}
```

### 2.6.4 quiz

主题零覆盖。只需把它拉进同一语言，不重画结构：

```css
[data-rmd-theme="sci-fi"] .local-quiz {
  padding: var(--space-3) var(--space-4);
  border: 1px solid var(--line-strong);
  border-left: var(--sf-rule) solid var(--accent);
  border-radius: 0;
  background: var(--surface-subtle);
}

[data-rmd-theme="sci-fi"] .local-quiz-feedback.is-correct {
  border-color: var(--success-line);
  background: var(--success-soft);
  color: var(--success);
  font-family: var(--font-mono);
}

[data-rmd-theme="sci-fi"] .local-quiz-feedback.is-incorrect {
  border-color: var(--danger-line);
  background: var(--danger-soft);
  color: var(--danger);
  font-family: var(--font-mono);
}

[data-rmd-theme="sci-fi"] .local-quiz-explanation {
  color: var(--ink-soft);
  font-size: var(--text-sm);
}
```

### 2.6.5 状态点、加载与骨架

```css
/* 状态点：圆形 → 2px 方块，保持 1:1 */
[data-rmd-theme="sci-fi"] .md-status::before {
  inline-size: 6px;
  block-size: 6px;
  border-radius: 0;
}

[data-rmd-theme="sci-fi"] .md-status {
  padding: 2px var(--space-2);
  border: 1px solid var(--line-strong);
  border-radius: 0;
  background: transparent;
  font-family: var(--font-mono);
  font-size: var(--sf-type-micro);
  letter-spacing: var(--sf-track-label);
  text-transform: uppercase;
}

[data-rmd-theme="sci-fi"] .md-loading {
  color: var(--ink-muted);
  font-family: var(--font-mono);
  font-size: var(--text-sm);
}

/* 旋转指示器：方角 + 1px 描边，无发光 */
[data-rmd-theme="sci-fi"] .md-spinner {
  border-width: 1px;
  border-radius: 0;
  border-color: var(--line);
  border-top-color: var(--accent);
}

[data-rmd-theme="sci-fi"] .md-skeleton {
  border-radius: 0;
  background-color: var(--surface-subtle);
  background-image: linear-gradient(
    90deg,
    transparent 0%,
    var(--surface-hover) 50%,
    transparent 100%
  );
}
```

### 2.6.6 表格内边距

```css
[data-rmd-theme="sci-fi"].md-document,
[data-rmd-theme="sci-fi"] .md-document {
  --table-cell-padding-y: 8px;
  --table-cell-padding-x: 12px;
}
```

**必须写 `.md-document`**：变量要落在文档根上。

### 2.6.7 进度条时长

`.local-progress-fill` 从基线继承 `transition: width 300ms`，不在 80/120/180
三档内：

```css
[data-rmd-theme="sci-fi"] .local-progress-fill {
  transition: width var(--motion-slow) var(--ease-standard);
}
```

### 2.6.8 autofill / caret / spinner（主题级可选项）

基线与主题都未处理，属内核级缺口。主题可以先补，不阻塞其它任务：

```css
[data-rmd-theme="sci-fi"] .md-text-input:-webkit-autofill,
[data-rmd-theme="sci-fi"] .md-text-input:-webkit-autofill:hover,
[data-rmd-theme="sci-fi"] .md-text-input:-webkit-autofill:focus {
  -webkit-box-shadow: 0 0 0 1000px var(--sf-field-bg) inset;
  -webkit-text-fill-color: var(--ink);
}

[data-rmd-theme="sci-fi"] .md-text-input {
  caret-color: var(--accent);
}
```

`<number>` 是 `type="text" inputMode="decimal"`，**不存在原生 spinner**，
相关规则不必写。

## 2.7 D7 测试断言更新

现有 7 个用例全部通过，但有两处与新模型不符：

| 用例 | 问题 | 处置 |
| --- | --- | --- |
| `defines the full light and dark semantic contract` | 强制主题重述整套语义变量，而新模型下主题只需覆盖差异 | 保留（主题确实全量覆盖），不阻塞 |
| `declares the shared slider contract in both modes` | 强制两套模式都声明滑块几何，新模型下继承即可 | 保留，不阻塞 |
| **缺** 层引导断言 | 不检查 `@layer rmd.themes` 与层序声明 | **新增** |
| **缺** keyframes 断言 | 不检查 SDK 会拒绝的写法 | **新增** |
| 圆角断言 | 只查 token，不查实际规则 | **收紧到 ≤2px** |

新增用例：

```ts
it('bootstraps the public cascade for direct CSS imports', () => {
  for (const css of [tokensCss, componentsCss, notchCss]) {
    expect(css.startsWith(LOCAL_STYLE_LAYER_ORDER)).toBe(true);
    expect(css).toContain('@layer rmd.themes {');
  }
});

it('uses no animation keyframes', () => {
  for (const css of [tokensCss, componentsCss, notchCss]) {
    expect(css).not.toMatch(/@(-webkit-)?keyframes/);
  }
});

it('keeps every radius token at or below 2px', () => {
  const radius = block(tokensCss, ROOT);
  for (const name of ['sf-radius-1', 'sf-radius-2', 'radius-control',
    'radius-card', 'radius-panel', 'radius-field', 'radius-xl',
    'radius-circle', 'radius-toolbar', 'radius-inset']) {
    const px = Number.parseFloat(resolve(name, radius));
    expect(px, `--${name}`).toBeLessThanOrEqual(2);
  }
});
```

注意：`--radius-circle` 与 `--radius-pill` 归零后，`Number.parseFloat` 得到 0，
符合断言。若将来保留百分比，需要单独排除。

---

# 第三部分 NeonBlade 组件接入

参考库：`_research/neonblade-ui`（MIT）。以下 5 项可移植，另外定义一套角切系统。

**总原则**：只取机制，不取装饰。任何依赖 `@keyframes` 的项直接排除——
不是审美判断，是 SDK 拒绝编译。

## 3.1 N1 混合态勾选框（`:indeterminate`）

**来源**：`neon-checkbox`。**价值**：修真实缺陷。

主题用 `background-image` 覆盖了 `:checked`，但没写 `:indeterminate`；
基线靠 `accent-color` 表达混合态，被 `background-color` 覆盖后失效。

```css
[data-rmd-theme="sci-fi"] :is(
  .local-checkbox .md-toggle-label input,
  .local-checklist-item input,
  .local-multi-option input
)[type="checkbox"]:indeterminate {
  -webkit-mask-image: none;
  mask-image: none;
  border-color: var(--accent);
  background-color: var(--accent);
  background-image: linear-gradient(var(--accent-ink), var(--accent-ink));
  background-size: 8px 2px;   /* 2px 信号线，落在 4px 网格 */
  background-position: center;
  background-repeat: no-repeat;
}
```

排除：发光（`box-shadow: 0 0 8px color-mix(...)`）、180ms 勾号缩放
（需要 keyframes）、9px 间距与 13px 字号（不在网格上）。

## 3.2 N2 进度条分段刻度

**来源**：`progress-bar` 的 `segmented` 变体。该变体用 9 个 DOM 分隔元素；
纯 CSS 可以用一个伪元素替代。

```css
[data-rmd-theme="sci-fi"] .local-progress-track::after {
  content: "";
  position: absolute;
  inset: 0;
  pointer-events: none;
  background: repeating-linear-gradient(
    90deg,
    transparent 0 calc(10% - 1px),
    var(--surface) calc(10% - 1px) 10%
  );
}
```

前提：`.local-progress-track` 已有 `position: relative`（现有规则满足）。
`::after` 画在 `-fill` 子元素之后，刻度压在填充上。

**与现有 45° 斜纹二选一**：设计上"分段仪表"和"斜纹填充"是两种语言，
不要叠加。建议采用分段刻度，删除现有斜纹（`components.css:1262-1270`）。

## 3.3 N3 时间轴几何

**来源**：`timeline`。三个可直接用的公式：

```css
/* 切片：平行四边形，不引入圆角 */
[data-rmd-theme="sci-fi"] .local-visual-timeline-title {
  clip-path: polygon(4px 0, 100% 0, calc(100% - 4px) 100%, 0 100%);
}

/* 竖线穿过 N 像素节点的精确居中 */
[data-rmd-theme="sci-fi"] .local-visual-timeline-axis {
  left: calc(var(--sf-timeline-node, 8px) / 2 - 1px);   /* 1px = 线宽/2 */
}

/* 纯 CSS 虚线轴，不必用 SVG stroke-dasharray */
[data-rmd-theme="sci-fi"] .local-visual-timeline-axis {
  background: repeating-linear-gradient(
    to bottom,
    var(--accent) 0 4px,
    transparent 4px 12px
  );
}
```

配合 `nth-child` 的 80ms 阶梯延迟（`--motion-fast`），落在契约第一档。
主题当前只写了 `-bar` / `-track` 两条，其余 9 个部件继承默认。

## 3.4 N4 tooltip 斜切边描线

**来源**：`neon-line-chart`。让被切掉的斜边有 1px 描线：

```css
[data-rmd-theme="sci-fi"] .rmd-chart-tooltip {
  position: relative;
  overflow: hidden;
  clip-path: polygon(0 0, 100% 0, 100% calc(100% - 10px),
                     calc(100% - 10px) 100%, 0 100%);
  /* 斜边描线：在对角面画一条 45° 渐变线 */
  background-image: linear-gradient(
    to top right,
    transparent calc(50% - 0.5px),
    var(--line-strong) calc(50% - 0.5px) calc(50% + 0.5px),
    transparent calc(50% + 0.5px)
  );
  background-size: 10px 10px;
  background-position: bottom right;
  background-repeat: no-repeat;
}
```

**实测结论**：`clip-path` 会同时裁掉 `border` 与向外的 `box-shadow`，
所以斜边不能靠边框，必须用背景渐变补（已验证：单角切效果正确）。
若将来需要焦点环，`outline` 也会被裁掉，需改用负 `outline-offset`
或内嵌 `box-shadow`。

## 3.5 N5 柱圆角走变量

已并入 §2.4.1（`--rmd-chart-bar-radius: 0px`）。此处只记录来源与验证：
实测柱子 `rx` 当前为 4，改变量后为 0。

## 3.6 N6 角切系统（新增 `src/notch.css`）

**来源**：`neon-input` / `notch-card` / `neon-modal` 的双层角切 +
`neon-line-chart` 的斜边描线，改造后用于本主题。

### 3.6.1 为什么单独成文件

- 避免与 §2 的修补在同一文件里互相冲突（并行开发）；
- 角切是可选装饰层，独立资源便于宿主按需组合；
- 资源数从 2 变 3，远低于 32 上限。

### 3.6.2 技术方案（已实测）

两种实现，按是否需要改背景选择：

**A. 不需要改背景 → 单层 + 渐变描边**（推荐，最简单）

```css
[data-rmd-theme="sci-fi"] .md-card {
  position: relative;
  clip-path: polygon(0 0, 100% 0, 100% calc(100% - 10px),
                     calc(100% - 10px) 100%, 0 100%);
  background-image: linear-gradient(
    to top right,
    transparent calc(50% - 0.5px),
    var(--line) calc(50% - 0.5px) calc(50% + 0.5px),
    transparent calc(50% + 0.5px)
  );
  background-size: 10px 10px;
  background-position: bottom right;
  background-repeat: no-repeat;
}
```

**B. 需要改背景（hover、选中）→ 双层**

外层背景当边框（`padding: 1px`），内层用收缩 1px 的同形 `clip-path`：

```css
.notch-frame {
  padding: 1px;
  background: var(--line-strong);
  clip-path: polygon(0 0, 100% 0, 100% calc(100% - 10px),
                     calc(100% - 10px) 100%, 0 100%);
}
.notch-frame > * {
  clip-path: polygon(0 0, 100% 0, 100% calc(100% - 9px),
                     calc(100% - 9px) 100%, 0 100%);
}
```

### 3.6.3 适用部件与取舍

| 部件 | 方案 | 说明 |
| --- | --- | --- |
| `.md-panel` / `.local-panel` | A | 已有 `::before/::after` 角标线，**右下角标会被裁掉**，需移到切角对侧（左上） |
| `.md-card` / `.local-card` | A | 无现有伪元素，直接加 |
| `.local-visual`（图表框） | A | 已有右下 8px 角标，同上需移位 |
| `.md-alert` / `.local-alert` | A | 保留左侧 2px 信号线 |
| `.md-button` / `.md-button-primary` | **不采用** | 按钮太小（34px 高），10px 切角吃掉近三分之一；且按钮状态多，渐变描边要重复三份 |
| `.local-choice` | A | 选中态改背景时用 B |
| tooltip / popover | A | 与 §3.4 合并 |

### 3.6.4 与圆角契约的关系

角切是"用斜边替代圆角"的另一种手段，二者不冲突：

- 圆角仍为 0–2px；
- 切角尺寸 10px（面板）/ 8px（卡片）/ 10px（tooltip），落在 4px 网格外的
  8/10 二选一需统一——**建议统一为 8px**，落在网格上。

### 3.6.5 验收要点（留给浏览器验证）

- 切角处没有 1px 的"断线"或锯齿；
- 深色与浅色下描边颜色一致（用 `var(--line-strong)`，不要硬编码）；
- 焦点态在被裁元素上仍然可见（`outline` 被裁，改用内嵌环）；
- 打印时切角不应产生大片空白（`@media print` 可关闭 `clip-path`）。

## 3.7 明确排除的新候选（附理由）

| 来源 | 理由 |
| --- | --- |
| `badge` 的 dot flicker / pulse | 需要 `@keyframes`，SDK 直接拒绝 |
| `accent-frame` 的 glow/pulse/flicker | 同上 |
| `corner-cut-button` 的 shine/scan/pulse | keyframes + 4–6s + GPU |
| `border-beam-corner-cut-card` | `inset:-100%` 旋转 conic，4–6s，纯装饰 |
| `neon-sparkline` | 面积渐变不可达：RM 用行内 `fill: var(--chart-N)`，无 `<defs>` |
| `neon-glow-corner-cut-card` | 只有发光；源文件有失效的 `.ngcc-wrapper` 选择器 |
| `rain-loader` | 运行时注入全局 `<style>`，且无对应组件 |
| `turbine-loader` | 需要 SVG 标记；1800ms 旋转 |
| `circular-progress` | **备选**：没有径向图表类型，仅当将来做仪表盘时用 |

## 3.8 移植通用陷阱

1. **硬编码深色底**：`#000`、`#0a0a12`、`rgba(10,10,18)` 遍布 badge、
   corner-cut-button、neon-checkbox、neon-select。本主题有亮色模式，
   全部换成 `var(--surface)` / `var(--sf-field-bg)` / `var(--accent-ink)`。
2. **`color-mix(..., transparent)` 发光阴影**：立面契约是 1px 环，全部剥离。
3. **Tailwind 承载的布局**：`accent-frame` 的 CSS 明写"布局在 Tailwind"；
   `badge` 的尺寸也在 class 字符串里。单独拿 `.css` 是残的。
4. **离网格数值**：`gap: 9px`→8、`padding: 2px 10px`→`0 8`、
   `margin-bottom: 5px`→4、`translateY(10px)`→8。
5. **时长**：库里集中在 150/200/300/450/500/600/1200/1600/1800ms；
   只有 checkbox 180ms、select 120ms、timeline 80ms 落在契约上。
6. **`data:` URI 合法**（测试只拒绝 `@import` 与 `http(s)`），
   但 URI 内颜色跟不上 `--accent` 与明暗切换，优先 `mask-image`。

---

# 第四部分 分工设计

## 4.1 总体策略

**并行作者 + 串行集成 + 集中验收**。

```
        ┌── W1 tokens ──────────┐
        ├── W2 controls ────────┤
并行 ───├── W3 chart ───────────┼──→ W6 集成 ──→ 集中验收（用户浏览器）
        ├── W4 data & nav ──────┤
        └── W5 notch ───────────┘
```

关键约束：`tokens.css` 与 `components.css` 是**单文件多区段**，
多个智能体同时编辑同一文件会互相覆盖。因此：

- 每个作者的产出是**独立片段文件**，不是直接改目标文件；
- 由 W6 按固定顺序应用到 `src/`；
- 这样即使某一路失败，其它路的产物仍可用。

## 4.2 工作包与文件归属

| 工作包 | 负责区段 | 产出文件 | 依赖 |
| --- | --- | --- | --- |
| **W1 Tokens** | `tokens.css` 全文件 | `_work/w1/tokens.patch.css` | D1 |
| **W2 Controls** | `components.css` §6 forms + §5 按钮补充 | `_work/w2/controls.patch.css` | D1 |
| **W3 Chart** | `components.css` §9c | `_work/w3/chart.patch.css` | D1、W1（变量名） |
| **W4 Data & nav** | `components.css` §4、§7、新增步骤/日历/画廊/quiz 块 | `_work/w4/data.patch.css` | D1、W1 |
| **W5 Notch** | 新文件 `src/notch.css` | `_work/w5/notch.css` | 无 |
| **W6 集成** | `theme.ts`、`sci-fi.css`、`demo/main.tsx`、测试、README、核心示例同步 | 直接改 | W1–W5 |

W1 必须先完成（或至少先产出变量清单），W3/W4 依赖其中的变量名。

## 4.3 各工作包任务说明

### W1 Tokens

范围：`src/tokens.css` 单文件，含浅色与暗色两个块。

任务：

1. §2.3.1 补 12 个命名圆角 + 5 个 `--pu-radius-*`；
2. §2.4.1 补 11 个图表变量（浅色全套、暗色只补 `dim-opacity`）；
3. §2.6.2 补 12 个 UIArc 组件圆角变量；
4. 补开关几何变量（`--rmd-switch-shadow-*`、`--rmd-uiarc-checkbox-*`）；
5. 删除 `--focus-ring`，改覆盖 `--pu-focus-halo`。

禁止：改任何现有语义色值；改 `components.css`。

验证：`npm run test` 中圆角与对比度用例。

### W2 Controls

范围：`components.css` §6 forms（约 745–1028 行）及 §5 相关补充。

任务：

1. §2.2.1 收窄勾选选择器；
2. §2.2.2 新增方形开关；
3. §3.1 混合态；
4. §2.6.7 进度条时长；
5. §3.2 分段刻度（替换斜纹）。

禁止：动 `.md-button` 的配色；动 §5 的分支按钮规则。

### W3 Chart

范围：`components.css` §9c（约 1433–1532 行）。

任务：

1. 删除失效的 `stroke`/`fill`；
2. 补 9 个缺失部件（`-stage`、`-svg`、`-tooltip-row/-label/-value/-dot/-foot`、
   `-legend-label/-share`）；
3. §3.4 tooltip 斜切 + 描边；
4. 图例与 readout 的等宽大写统一。

禁止：改 `tokens.css` 的图表变量（那是 W1 的）。

### W4 Data & nav

范围：`components.css` §4 tables、§7 navigation，以及在 §11 之前追加的
新块（步骤、日历、画廊、quiz、status、spinner）。

任务：

1. §2.3.2 步骤点方角 + `--pu-rail-*`；
2. §2.6.3 画廊；§2.6.4 quiz；§2.6.5 状态点/加载/骨架；
3. §2.6.6 表格内边距；
4. §3.3 时间轴几何；
5. 删除 `.local-range-value`、8 条 `.md-select-input`、嵌套 `.local-visual`。

### W5 Notch

范围：新文件 `src/notch.css`，单文件、无依赖。

任务：

1. 按 §3.6 实现角切系统；
2. 只作用于 `.md-panel`/`.local-panel`、`.md-card`、`.local-visual`、
   `.md-alert`/`.local-alert`、`.local-choice`、tooltip/popover；
3. 处理已有角标线的移位（面板与图表框的右下 8px 角标会被裁掉）；
4. 提供 `@media print` 关闭开关；
5. 统一切角 8px。

必须满足：每条规则以 `[data-rmd-theme="sci-fi"]` 开头；
不新增 `@keyframes`；不硬编码颜色。

### W6 集成

串行执行，顺序固定：

1. 按 W1 → W2 → W3 → W4 顺序把片段合并进 `tokens.css` / `components.css`；
2. 放入 `src/notch.css`；
3. `src/sci-fi.css` 追加 `@import './notch.css';`；
4. `src/theme.ts` 的 `css` 数组追加 third resource；
5. `demo/main.tsx` 改为只 `import '../src/sci-fi.css'`（去掉重复直接导入）；
6. 更新 `sci-fi-theme.test.ts`（§2.7 三个新用例）；
7. 更新 `README-ch.md` 与 `docs/design-system-ch.md` 的契约表；
8. 同步 `ReactiveMD/examples/sci-fi-theme/`（该目录与 `others/` 当前逐字节相同）；
9. 依次跑 test / typecheck / build。

## 4.4 测试策略

**只做必要测试**，浏览器验证全部交给用户。

每个作者在提交片段前只跑：

```sh
npx vitest run --config vitest.config.ts   # 片段未合并时可能失败，属预期
```

真正必须通过的是 W6 的三条：

```sh
npm run test        # 作用域、层、keyframes、圆角、对比度、间距
npm run typecheck
npm run build
```

作者不需要截图、不需要 Playwright、不需要跑 `npm run screenshot`。
理由：`screenshot` 依赖完整 demo 与浏览器，成本高且会在中间态失败，
放在集中验收阶段更有意义。

## 4.5 冲突预防规则

1. **不跨区段编辑**。W2 只碰 §6，W3 只碰 §9c，W4 只碰 §4/§7 与新增块。
2. **不新增重复 token**。需要新变量先查 W1 的产出清单。
3. **选择器收窄优先于加 `!important`**。主题里已有 3 处 `!important`
   （reduced-motion、print），不得再增。
4. **同一属性只写一次**。若发现要覆盖自己上一段规则，合并而不是叠加。
5. **每条新增规则写一行注释**说明它修的是哪个具体问题（可引用本文编号）。

## 4.6 集中验收（用户执行）

所有工作包合并、`npm run test/typecheck/build` 通过后，由用户统一验收：

```sh
cd others/sci-fi-theme
npm run dev          # 打开 http://127.0.0.1:4319
npm run screenshot   # 生成 screenshots/，出现运行时错误即失败
```

验收清单：

| # | 检查 | 期望 |
| --- | --- | --- |
| 1 | toggle 与 checkbox 同屏 | 一个是 40×20 方形开关，一个是 16px 方框 |
| 2 | 滑块单击与拖动 | 方形 14px 滑块、两端位置准确、键盘 Home/End 到达端点 |
| 3 | 图表柱与格线 | 柱子无圆角；格线为 `--chart-grid`；引导线为 accent |
| 4 | 图表 hover 图例 | 未选中系列变淡但仍在 3:1 以上 |
| 5 | 步骤指示器 | 方形节点，非圆点 |
| 6 | 日历 | 日期为方格，非圆点 |
| 7 | 面板/卡片/图表框 | 右下 45° 切角，无断线；角标线不与切角重叠 |
| 8 | 所有 focus-visible | 焦点环完整可见，含被裁元素 |
| 9 | 深/浅切换 | 无硬编码深色残留（尤其 notch 描边） |
| 10 | 390px 宽度 | 切角不溢出、表格横向滚动、控件不塌陷 |
| 11 | `prefers-reduced-motion` | 无过渡 |
| 12 | 打印预览 | 切角关闭、无大片空白 |

## 4.7 风险与回退

| 风险 | 概率 | 回退 |
| --- | --- | --- |
| W5 角切与现有角标线视觉冲突 | 中 | 保留 `notch.css` 但让它只作用于卡片，面板维持纯矩形 |
| 方形开关在 34px 控件高度内视觉偏大 | 低 | 降到 36×18，滑块 12px，travel 18px |
| 分段刻度与现有斜纹重复 | 中 | 保留其中一个，删除另一个 |
| 圆角收到 2px 后某些部件显得过锐 | 低 | 只回退该部件的 token，不动全局 |
| 版本对齐后出现新回归 | 低 | 版本对齐独立成一次提交，便于单独 revert |

## 4.8 提交建议

分四次提交，便于单独回退：

1. `chore(theme): align vendor package with the current core build`（D1）
2. `fix(theme): separate toggle from checkbox and complete radius tokens`（W1/W2）
3. `fix(theme): drive chart paint through component variables`（W3/W4）
4. `feat(theme): add notch system and borrow NeonBlade mechanisms`（W5 + §3 其余）

---

## 附录 A 关键选择器速查

| 目标 | 选择器 |
| --- | --- |
| 文档根 | `.md-document`（带 `data-rmd-theme`、`data-color-scheme`） |
| toggle 输入 | `.local-toggle .md-toggle-label input[type="checkbox"]` |
| checkbox 输入 | `.local-checkbox .md-toggle-label input` |
| 滑块部件 | `[data-rmd-component="slider"] [data-rmd-part="thumb"|"track"|"fill"]` |
| select | `[data-rmd-part="trigger"]`、`[data-rmd-part="menu"]`、`[data-rmd-part="item"]` |
| 日期选择 | `[data-rmd-component="date-picker"]`、`[data-rmd-component="calendar"]` |
| 图表外壳 | `.rmd-chart`、`.rmd-chart-tooltip`、`.rmd-chart-legend-item` |
| 步骤 | `.local-steps`、`.local-steps-rail`、`.local-steps-dot` |
| 退出公共皮肤 | `data-rmd-appearance="custom"`（由组件输出，主题不设置） |

## 附录 B 当前文件区段索引

`src/components.css`（1700 行，改造后预计约 1780 行）：

| 区段 | 行 | 负责 |
| --- | --- | --- |
| 1 document | 14–37 | — |
| 2 typography | 38–205 | — |
| 3 panels & cards | 206–357 | W5（追加） |
| 4 tables & data | 358–648 | W4 |
| 5 buttons | 649–744 | W2（少量） |
| 6 forms | 745–1028 | W2 |
| 7 navigation | 1029–1162 | W4 |
| 8 feedback & status | 1163–1297 | W4 |
| 9 code & math | 1298–1364 | — |
| 9b control shells | 1365–1432 | — |
| 9c chart | 1433–1532 | W3 |
| 9d diagram | 1533–1597 | W4 |
| 9e Mafs | 1598–1623 | — |
| 10 misc & print | 1624–1651 | — |
| 11 adaptation | 1652–1700 | — |

新增块统一追加在 §11 之前，按"步骤 / 日历 / 画廊 / quiz / 状态"顺序排列。
