# SF-01 优化调研笔记

记录 2026-11-14 对 `sci-fi-theme` 的一次完整审计，以及对外部参考库
[NeonBlade UI](https://github.com/vprix21/neonblade-ui)（MIT）的取舍判断。

本文只记录结论与依据，不改动 `src/` 下的任何文件。

2026-11-14 共享主题重构后，第 1 节的加载顺序问题及第 2.1、2.2 节的两套
图表、滑块路径已解决：核心提供完整 default 基线，主题统一使用共享组件、
`rmd.themes` 层和组件变量。以下旧文件行号与 `local-range-*` 轨道规则保留为
当时的审计记录；新主题应使用 `--rmd-slider-*` 和公开部件入口。

---

## 0. 方法与可信度

结论分两类，可信度不同，请勿混用：

| 类别 | 依据 | 可信度 |
| --- | --- | --- |
| A 类：主题缺样式 | 在独立 HTML 中按真实顺序加载 `local.css` → `tokens.css` → `components.css`，用 Playwright 读 `getComputedStyle`；同时对照渲染器源码 | 已实测 |
| B 类：借鉴判断 | 阅读 NeonBlade 的 `.css` 与 `.tsx`，对照 ReactiveMD 实际输出的 DOM | 推断，实施前需再验 |

复现脚本在 `_research/verify/`（一次性目录，可随时删除）。
Playwright 与 vite 通过 `node_modules` 软链接自 `ReactiveMD-Demo` 取得。

---

## 1. 首要问题：样式表加载顺序

主题 CSS 必须**晚于** `reactive-md/styles.css` 加载。

实测：顺序颠倒时，基础样式会整片覆盖主题——

- `<toggle>` 的输入框从 16px 方块变成 22px 圆形；
- `border-radius`、`background-color` 全部回退到基础值。

当前 `demo/main.tsx` 的导入顺序是对的（先 `reactive-md/styles.css`，后主题两层），
所以截图没有暴露。但任何外部宿主都可能踩到，建议：

1. 在 README 的快速开始里显式写明顺序要求；
2. 或在 `src/sci-fi.css` 头部加注释说明。

---

## 2. A 类：主题确实缺失的样式

按影响排序。所有行号指 `src/components.css`，除非另注。

### 2.1 图表交互层完全没有样式（最严重）

ReactiveMD 的交互式图表只在 `[data-rmd-theme="default"]` 下定义样式
（`ReactiveMD/src/themes/default/chart-interactions.css`，36 条规则）。
主题选择 `sci-fi` 时这些规则全部不匹配，于是下列类裸奔：

`rmd-chart`、`rmd-chart-stage`、`rmd-chart-svg`、`rmd-chart-tooltip`、
`rmd-chart-tooltip-title`、`rmd-chart-tooltip-row`、`rmd-chart-tooltip-label`、
`rmd-chart-tooltip-value`、`rmd-chart-tooltip-dot`、`rmd-chart-tooltip-foot`、
`rmd-chart-legend`、`rmd-chart-legend-item`、`rmd-chart-swatch`、
`rmd-chart-legend-label`、`rmd-chart-legend-share`、`rmd-chart-readout`、
`rmd-chart-grid`、`rmd-chart-axis-label`、`rmd-chart-axis-title`、
`rmd-chart-guide`、`rmd-chart-empty`

其中图例项是 `<button>`，会继承 `.md-document button` 的通用按钮皮肤，
所以视觉上"有东西"，但和 SF-01 的方角、等宽、信号线语言不一致。
tooltip 则完全依赖行内 `position/left/top`，缺边框、缺背景。

注意：`DefaultChart` 只在 `defaultTheme` 为真时渲染
（`components/visuals.tsx:919`），所以**非 default 主题的图表走的是旧绘图路径**，
`local-visual-*` 那批类仍然生效。上表的 `rmd-chart-*` 只在宿主把主题名设为
`default` 时才出现，移植图表样式前必须先确认走的是哪条路径。

### 2.2 双滑块 `<range-slider>` 与单滑块 `<slider>` 形态不一致

| | 轨道高度 | 滑块 | 圆角 |
| --- | --- | --- | --- |
| `<slider>`（主题已覆盖） | 4px | 14px 方块 | 0 |
| `<range-slider>`（主题未覆盖） | 6px | 24px 圆形 | 50% |

滑块形状写死在基础样式 `ReactiveMD/src/local/rendering/local.css:1338-1350`
的 `::-webkit-slider-thumb` / `::-moz-range-thumb` 里，用的是
`var(--local-range-thumb, 24px)` 控制尺寸、`border-radius: 50%` 控制形状。
主题一处都没碰。同一份文档里两种滑块形态，是最明显的一致性缺陷。

可修：主题覆盖 `--local-range-thumb` 并重写 `border-radius`、轨道高、填充色；
轨道是 `.local-range-rail` / `.local-range-fill`，可直接改。

### 2.3 `<toggle>` 不是开关，且与 `<checkbox>` 完全同形

两者在渲染器里用同一个 label 结构：

```html
<label class="md-toggle-label"><input type="checkbox"><span>文字</span></label>
```

（`components/controls.tsx:356` 与 `:392`）

主题对 `.md-toggle-label input` 只做了"方框 + 勾号"（第 913-941 行），
于是：

- `<toggle>` 和 `<checkbox>` 长得一模一样；
- `<toggle>` 没有轨道、没有滑块位移，概念上不是 switch。

要做成开关，`input` 是唯一可造型的元素（没有独立的 track/thumb 节点）。
`appearance: none` 之后可以用 `background-image`（两层渐变或内联 SVG）
画轨道 + 滑块，并用 `background-position` 过渡位移。**不要**用
`border-radius` 胶囊形——与 SF-01 的 0-4px 圆角契约冲突。

### 2.4 `<select>` 仍用系统原生箭头

实测 `appearance: auto`，`background-image: none`。
主题第 764-782 行只改了边框、背景、高度、字体，没重置 `appearance`。
截图里那个系统小三角就是证据。

注意：非 default 主题走的是原生 `<select>`
（`components/controls.tsx:601`），不存在自定义下拉面板可改。
NeonBlade 的 `neon-select` 有整套下拉样式，但这里拿不到对应的 DOM。

### 2.5 `<number>` 的原生 spinner 未处理

主题对 `input[type=number]` 无任何规则（`appearance`、`::-webkit-inner-spin-button`
均为 0 处）。ReactiveMD 的基础样式也明确声明"不碰原生 spinner"
（`native-fields.css:9`）。结果是数字输入右侧出现系统上下箭头，破坏仪表盘观感。

### 2.6 其他零覆盖的类

以下类在主题里 0 条规则，完全沿用基础样式或浏览器默认：

- `.local-steps-rail`、`.local-steps-dot`：基础样式为 `display: none`
  （`local.css:1551`），主题也没有恢复它——**步骤指示器整条不可见**，
  只剩"上一步 / 第 N 步 / 下一步"按钮。default 主题在
  `themes/default/navigation.css:457` 有完整实现，可参考。
- `.local-quiz`、`.local-quiz-options`、`.local-quiz-feedback` 等
- `.local-date-picker`（仅 default 主题启用 UIARC 日期选择器）
- `.local-jump*`、`.local-coordinate*`
- `.local-visual-plot*`（函数绘图）、`.local-mafs-*`
- `.local-visual-timeline-*`：主题只写了 `-bar` 和 `-track` 两条（638、642 行），
  其余（axis、tick、item、head、title、times、detail）沿用基础样式
- `.local-visual-line`、`-point`、`-area`、`-grid-line`、`-zero-line`、
  `-tick`、`-axis-line`、`-donut-total`
- `.local-visual-sort-marker`：主题未定义，默认是一个小三角
- `.rmd-gallery*`（`ReactiveMD/src/gallery.css` 不受主题作用域约束）
- `-webkit-autofill` 黄底、`caret-color`：0 处处理

---

## 3. B 类：可从 NeonBlade 借鉴的部分

参考库结构：`packages/registry/components/<name>/{index.tsx, *.css}`，
Tailwind v4 为主，`.css` 只留 Tailwind 表达不了的几何与动画。
**不能整段复制**——布局和字号都在 TSX 的 class 里，单独拿 `.css` 是残的。

### 3.1 值得直接采用的手法

**双层角切边框（`neon-input` / `neon-select` / `notch-card` / `neon-modal`）**

问题：`clip-path` 会同时切掉 `border` 和向外的 `box-shadow`。
解法：外层容器背景色当边框（`padding: 1px`），内层用完全相同的
`clip-path` 再画一次；1px 的差值就是那条斜边上的边框。

```css
.outer { background: var(--line-strong); padding: 1px; clip-path: <polygon>; }
.inner { background: var(--surface);   clip-path: <同一个 polygon 但内缩>); }
```

同一个技巧可套到 `.local-panel`、`.md-button`、`.md-badge`、`.local-visual` 上，
作为"notch 变体"补上目前只有 8px 角刻度线的单调。默认仍保持 0 圆角矩形。

**发光裁剪的替代写法**

`clip-path` 元素上 `box-shadow` 无效，改为在父层用 `filter: drop-shadow(...)`
——`drop-shadow` 跟随裁剪后的多边形，包括斜边。若将来需要发光状态，这是唯一正确写法。

**图表 tooltip 的三行结构（`neon-line-chart`）**

`标题 / [色块 + 名称 + 数值] / 脚注`，配 1px 内缩的角切外框。
可直接映射到 `rmd-chart-tooltip-title / -row / -label / -value / -foot`。
颜色改成 `--accent`，去掉 blur 阴影。

**表头交互（`neon-table`）**

可排序表头 hover 变色、排序箭头激活态、空状态文案、骨架 shimmer。
对应 `local-visual-sort-button` / `is-sorted` / `local-visual-sort-marker`。

**分页与计数器（`card-slider`）**

`01 / 06` 等宽等宽计数器、进度点的 3px 微角切
`polygon(0 0, 100% 0, 100% calc(100% - 3px), calc(100% - 3px) 100%, 0 100%)`。
纯几何，与 SF-01 完全兼容。可映射到 `.local-visual-pagination`。

**输入框细节（`neon-input`）**

`-webkit-autofill` 覆盖、`::-webkit-inner-spin-button` 去除、
`-moz-appearance: textfield`、`caret-color`、prefix/suffix 随 focus 提亮。
都是纯行为修正，无美学冲突。

**开关位移模型（`neon-toggle`）**

`travel = trackWidth - thumbDiameter - gap * 2` 的算法可用。
其余需改写（见下）。

### 3.2 必须改造后才能用

| 来源 | 保留 | 丢弃 |
| --- | --- | --- |
| `neon-toggle` | `aria-hidden` 轨道 + 位移计算、focus ring | 胶囊圆角、`ntg-spark` 三颗粒子、双向发光 |
| `neon-input` | autofill / spinner / caret | 双层 clip-path（没有外层容器）、focus 发光 |
| `neon-select` | `appearance: none` + 等宽箭头 | 绝对定位下拉面板（原生 `<select>` 无法插入 DOM） |
| `card-slider` | mono 计数器、微角切进度点 | 420ms 缓动、边缘辉光、CRT 扫描线（与 `gallery.css` 的 fade 重复） |
| `stat-card` | 24px 角括号、hover 扫描线（压到 120-180ms） | 彩色 trend 光晕 |
| `timeline` | 竖线穿点、active dot、stepped 变体 | 圆点、发光 |

### 3.3 明确不采用

`ascii-rain`、`grid-floor`、`grid-scene`、`holographic-terrain`、`glyph-city`、
`hexagons`、`void-vortex`、`neon-tide`、`pluviophile`、`neon-cascade`、
`cyber-circuit`、`datalines-with-grid`、`fox-cursor`、`crosshair`、
`glitch-text`、`blur-text`、`outline-text`、`neon-glow`、
`lightning-button` 的爆裂/销毁、`navbar`、`footer`、`neon-modal` 的旋转光束。

理由：装饰性、GPU 开销大、与"硬科幻仪表盘"的气质相反，
且多数是营销页外壳，文档内没有对应组件。

### 3.4 移植的硬约束

所有引入样式必须满足现有测试（`sci-fi-theme.test.ts`）：

- 每条规则以 `[data-rmd-theme="sci-fi"]` 开头（含 `@media` 内部）；
- 无 `@import`、无远程 `url(http...)`；
- 圆角 ≤ 4px，间距落在 4px 网格；
- 对比度：正文 ≥ 7:1，次级/弱化 ≥ 4.5:1，图表系列 ≥ 3:1；
- 动画时长收敛到 80 / 120 / 180ms 三档，并遵守
  `prefers-reduced-motion`。

---

## 4. 建议的实施顺序

| 阶段 | 内容 | 风险 | 肉眼收益 |
| --- | --- | --- | --- |
| 1 | 表单一致性：range-slider 方形化、toggle 改开关、select 箭头、number spinner | 低（单文件、纯 CSS） | 高 |
| 2 | 图表交互层 `rmd-chart-*`（先确认渲染路径） | 中（需区分 default / 非 default） | 高（现有截图会变） |
| 3 | steps rail、timeline 补全 | 低 | 中 |
| 4 | 面板/卡片 notch 变体、stat-card 角括号 | 低 | 低（装饰） |
| 5 | 未覆盖的边缘组件：quiz、date、jump、coordinate | 中（组件多） | 低 |

每阶段完成后应执行：

```sh
npm run test        # 作用域、对比度、圆角、间距契约
npm run typecheck
npm run build
npm run screenshot  # 会因 console error / 渲染诊断非零而失败
```

阶段 2 之后需人工比对 `screenshots/` 下的图表与图例特写。

---

## 5. 待决策

1. 阶段 1 是否包含 `range-slider` 的形态统一？这会改变现有文档里
   `<range-slider>` 的外观，属于破坏性视觉变更。
2. 图表 `rmd-chart-*` 是否需要同时支持 default 与非 default 两条渲染路径，
   还是只在非 default 路径补齐 `local-visual-*` 的缺项。
3. 是否把 NeonBlade 的角切手法做成可选变体（token 开关），
   还是直接替换现有 8px 角刻度线。
