# SF-01 主题更新报告（2026-11-15）

对照 Reactive MD 新的外接主题机制，重新审计 `sci-fi-theme`，并给出
NeonBlade UI 参考库中仍值得借鉴的部分。

本文只记录结论、证据与建议，不改动 `src/`。上一版笔记
`docs/optimization-notes-ch.md` 写于 2026-11-14，基于重构前的内核模型；
本文取代它的 A 类结论，B 类借鉴判断保留并更新。

\---

## 0\. 结论摘要

|#|结论|依据|
|-|-|-|
|1|主题的**结构已经跟上**新模型（`@layer rmd.themes`、`--rmd-\*`、`data-rmd-part` 都在用），不是陈旧样式表|A 类实测|
|2|但主题**测试与示例针对的是重构前一次提交的内核**（`92733a4`），与当前 HEAD 相差一个 `4d26832`|二进制比对|
|3|旧笔记 §1「加载顺序」**已失效**：层叠层解决了它，正序与逆序加载的计算样式完全一致|A 类实测|
|4|旧笔记 §2.1 图表、§2.2 滑块、§2.4 select、§2.6 步骤/quiz/日期**已由共享基线覆盖**，不再是主题任务|源码 + 实测|
|5|**仍有一个实质缺陷**：主题的 `.md-toggle-label input` 规则把 `<toggle>` 也一起改成了方框勾选，基线的开关皮肤被整个覆盖|A 类实测|
|6|**新增一个覆盖缺口**：共享基线新增的命名圆角（`--radius-circle`/`-xl`/`-toolbar`/`-hairline`/`-2xs`/`-xs`/`-inset`）主题一个都没声明，导致步骤点、日历日、画廊箭头、坐标画布仍是默认圆角|A 类实测|
|7|**图表的 `stroke`/`fill` 主题写了但没生效**：交互图表用行内 `style` 绑定 `var(--rmd-chart-\*)`，主题规则赢不了|A 类实测|
|8|NeonBlade 仍有 5 项可借鉴，集中在**核对框 `:indeterminate`**、进度分段刻度、时间轴几何，都不是装饰|B 类推断|

\---

## 1\. 方法

|类别|依据|可信度|
|-|-|-|
|A|用真实渲染器起 Vite + Playwright，读 `getComputedStyle` 与匹配到的 `cssRules`；对照内核源码|已实测|
|B|读 NeonBlade 的 `.css`/`.tsx`，对照 Reactive MD 实际 DOM|推断，实施前需再验|

复现方式已删除临时脚本所在的 `\_research/verify-2026-11-15/`；重新复现可按
§7 的步骤重建（约 60 行 Playwright 脚本）。

实测环境：`reactive-md@0.8.0`（Demo 的 `2a1df8bd` 构建，内核 `f4452b5`），
主题 `src/` 未改动，`colorScheme="dark"`，Edge（Chromium 内核）。

\---

## 2\. 新机制：外接主题现在怎么工作

这一节是新旧模型的实际差异，也是旧笔记里多条结论失效的原因。

### 2.1 层叠层取代了加载顺序

层序固定为：

```
rmd.reset → rmd.defaults → rmd.components → rmd.themes → rmd.overrides
```

* `reactive-md/styles.css` 现在提供**完整的 default 基线**，不再是"另一套主题"。
* 主题只覆盖差异，放在 `rmd.themes` 层。
* SDK 的 `defineLocalTheme` 会把每个资源包成
`@layer rmd.themes { … }`，并把每条规则重定到 `\[data-rmd-theme="<name>"]`
（`src/sdk/theme.ts:1291-1297`，`scopeSelector` 在 `:374-380`）。
* 直接 `<link>`/`import` 主题 CSS 时，文件自身必须先声明层序，再进层
（`docs/reference/theme-protocol-ch.md:90-92`）。

**实测**：把 `main.tsx` 的导入顺序从「基线→主题」改成「主题→基线」，
panel 边框、badge 字体、toggle 尺寸、图表字体、文档底色**逐项完全相同**。
旧笔记 §1 说的「顺序颠倒会整片覆盖」在当前内核下不再成立。

### 2.2 空主题 = 完整 default 外观

登记一个没有 CSS 的主题，得到与 `default` **逐像素相同**的计算样式
（内核自带 `scripts/verify-shared-theme-browser.mjs:33-45` 就在断言这件事）。
所以「主题必须重述整套语义变量」这条要求已经作废。

### 2.3 组件变量与部件钩子

* 组件级变量统一 `--rmd-` 前缀，例如滑块
`--rmd-slider-thumb-width/-height/-radius`、`--rmd-slider-track-height/-radius`，
原生 range 单独一套 `--rmd-native-range-\*`。
* 稳定 DOM 入口：`data-rmd-component`（`slider`、`select`、`date-picker`、
`calendar`、`chart`、`quiz`、`number`、`toggle`、`checkbox` 等）与
`data-rmd-part`（`track`、`fill`、`thumb`、`trigger`、`menu`、`popover`、
`legend`、`readout` 等）。
* `data-rmd-appearance="custom"` 是逐元素退出公共皮肤的唯一开关。

### 2.4 SDK 的硬限制（主题必须设计在其中的约束）

|限制|说明|
|-|-|
|无 `@import`|必须内联|
|`url()` 只接受 `data:`|远程/相对/文件 URL 一律拒绝|
|**拒绝 `@keyframes`**|声明的是全局名；主题只能做状态过渡，不能做动画|
|无 `expression()`、字符串外无 CSS 转义、无 `</style>`|安全扫描|
|不能选 `:root`/`html`/`body`|宿主全局|
|不能从主题根用 `+`/`\~` 逃逸，`:has()` 里的兄弟组合也拒绝|实例隔离|
|32 个资源 / 单资源 256 KiB / 总计 512 KiB|体积预算|
|`@font-face` 家族名会被重写成 `rmd-theme-<theme>-font-<hex>`|字体隔离|

**`@keyframes` 被拒绝这条直接影响 NeonBlade 的取舍**：那个库里几乎所有"好看"
的东西都靠 keyframes（扫描线、闪烁、脉冲、旋转光束）。主题侧只能做
transition，这是排除大量候选的硬理由，比"气质不符"更硬。

\---

## 3\. 主题与当前内核的对照

### 3.1 主题已正确使用的部分

* `src/sci-fi.css:1` 声明完整层序，`tokens.css`/`components.css` 各自
`@layer rmd.themes {`（`:1-3`，分别在 `:444` / `:1700` 收口）。
* 全部选择器以 `\[data-rmd-theme="sci-fi"]` 开头，测试的 `assertScoped` 零违规。
* 滑块走 `--rmd-slider-\*`（`tokens.css:271-280`）+ `data-rmd-part`
（`components.css:858-887`），方形 14px 块 / 4px 轨道，两种滑块共用同一实现。
* select 走 `\[data-rmd-part="trigger"]` / `\[data-rmd-part="menu"]`（`:1371-1431`）。
* 图表外壳 `rmd-chart-\*`、图解 `rmd-diagram-\*`、Mafs `.MafsView` 都已覆盖。

### 3.2 实质缺陷（需要修）

#### A. `<toggle>` 被改成方框勾选（最严重）

主题原来的规则是：

```css
\[data-rmd-theme="sci-fi"] .md-toggle-label input { … 16px 方框 … }
\[data-rmd-theme="sci-fi"] .md-toggle-label input\[type="checkbox"]:checked { … 白色勾 … }
```

这个选择器**同时命中** `<toggle>` 与 `<checkbox>`（两者的 label 结构相同：
`label.md-toggle-label > input\[type=checkbox] + span`）。而基线的开关皮肤是：

```css
.local-toggle .md-toggle-label input\[type="checkbox"] { 42×24 胶囊 + 渐变滑块 }
```

`.md-toggle-label input` 在 `rmd.themes` 层，基线在 `rmd.components` 层，
**后者永远输**。实测结果：`<toggle>` 与 `<checkbox>` 都是 16×16、`border-radius:0`、
无位移；`--rmd-switch-shadow-\*` 一整套变量完全没被消费。

<toggle> 与 <checkbox> 的包装类其实不同，可以区分：

|组件|包装类|`data-rmd-component`|
|-|-|-|
|`<toggle>`|`md-control md-toggle local-toggle`|`toggle`|
|`<checkbox>`|`md-control local-checkbox`|`checkbox`|

修法有两条：

1. 把选择器收窄到 `.local-checkbox .md-toggle-label input` 等四类勾选控件；
2. 或者不改结构，只覆盖 `--rmd-switch-\*` 与 `--rmd-uiarc-checkbox-size`
让基线自己画。

注意：`<toggle>` 输出的是裸 `input\[type=checkbox]`，没有 `role="switch"`，
也没有独立的 track/thumb 节点。要做成真正的开关，只能在 `input` 上
`appearance: none` 后用 `background-image`（一层画轨道、一层画滑块）+
`background-position` 位移，**不要**用 `border-radius` 胶囊，与 0–4px 的
圆角契约冲突。

#### B. 新增命名圆角全部未覆盖

基线在 `reactive-md-styles-1` 里新增了一批圆角 token，主题一个都没声明：

|token|基线值|消费者|实测现状|
|-|-|-|-|
|`--radius-circle`|`50%`|步骤点、画廊箭头、图表 tooltip 色点、日历"今天"点、选择标记|步骤点 `border-radius: 50%`、画廊箭头 `50%`|
|`--radius-xl`|`22px`|`.local-coordinate-surface`（Mafs 坐标画布）|`22px`|
|`--radius-toolbar`|`9px`|`.rmd-diagram-zoom` 工具条|主题只压了按钮，容器仍圆|
|`--radius-inset`|`var(--pu-radius-xs)` = 6px|图解 tooltip 关闭按钮、缩放按钮|未覆盖|
|`--radius-hairline` / `-2xs` / `-xs`|1 / 2 / 3px|表格选择勾、页签指示条、图例色块|未覆盖|
|`--pu-radius-\*`|6/8/10/12/14px|公共按钮 `border-radius: var(--pu-radius-md)`|见下|

`--pu-radius-md` 这条尤其隐蔽：基线给所有原生 `<button>` 的 `border-radius`
是 `var(--pu-radius-md)`，plot 图例按钮因此是 **10px**，而主题自己的
`.md-button` 规则是 0。同一份文档里出现两种按钮圆角。

实测非零圆角元素共 5 个：

```
li.local-steps-dot            50%
div.local-coordinate-surface  22px
button.local-visual-plot-legend-button  10px
button.rmd-gallery-button     50%
（另有一个 tooltip 色点 8px 圆形，由 --radius-circle 决定）
```

主题当前只覆盖了 `--radius-control/-card/-panel/-pill/-field/-field-multiline/ -sm/-md/-lg`（`tokens.css:203-211`），正好漏掉新增的那一批。

#### C. 图表的 `stroke`/`fill` 写了但无效

交互图表把绘制值作为**行内 style** 写死：

```js
// src/components/default-chart.tsx:38-40
const GRID\_STROKE = 'var(--rmd-chart-grid, var(--chart-grid))';
const AXIS\_TITLE\_FILL = 'var(--rmd-chart-axis-title, var(--ink-soft))';
const GUIDE\_STROKE = 'var(--rmd-chart-guide, var(--line-strong))';
```

主题里的 `stroke: var(--chart-grid)` / `fill: var(--chart-axis)` /
`stroke: var(--accent)` **全部输给行内样式**。实测：

```
格线 inline style = stroke: var(--rmd-chart-grid, var(--chart-grid))
主题规则 stroke  = 未生效
```

后果是主题以为自己在控制图表配色，实际上格线、坐标轴、引导线用的都是
`--chart-grid`/`--chart-axis` 的**兜底值**（这两个变量主题确实定义了，
所以颜色碰巧对；但 `--rmd-chart-guide` 没定义，引导线拿到的是
基线的 `--line-strong`，不是主题想要的 accent）。

正确做法是只设变量：`--rmd-chart-grid`、`--rmd-chart-axis`、
`--rmd-chart-axis-title`、`--rmd-chart-guide`，不要写 `stroke`/`fill`。

#### D. 图表 dim 透明度违反 3:1

基线 `--rmd-chart-dim-opacity: .22`。实测按主题暗色算：

|透明度|混色结果|对 `--surface` 对比度|
|-|-|-|
|.22（基线）|`#1a3c47`|**1.61:1**|
|.45|`#2a6a77`|3.09:1|
|.55|`#307d8d`|4.01:1|

图表系列的对比度下限是 3:1，`.22` 明显不够。主题需要把它提到 ≥ .45。

#### E. 死选择器

|位置|问题|
|-|-|
|`components.css:844` `.local-range-value`|内核已无此元素（`RangeSliderView` 用 `md-slider-value`）|
|`components.css:767-817` 共 8 条 `.md-select-input`|select 现在是 Radix `<button data-rmd-part="trigger">`，该 class 只在基线里作为兜底存在；主题同时已有正确的 `trigger` 规则|
|`components.css:428` `.local-visual .local-visual`|为旧的嵌套 `.local-visual` 而写；交互路径现在是 `figure.local-visual` 包 `div.rmd-chart`，嵌套已不存在|
|`tokens.css` `--focus-ring`|主题定义但内核从未消费；实际生效的是 `--pu-focus-halo`（主题也没覆盖）|

`.local-alert-success` / `.local-alert-warning` 不是死规则——`layout.tsx:529`
用模板拼出 `local-alert-${tone}`，静态扫描会漏掉，实际存在。

### 3.3 旧笔记中已失效的条目

|旧条目|现在的事实|
|-|-|
|§1 加载顺序必须先基线后主题|层叠层已解决；实测正逆序计算样式一致|
|§2.1 非 default 主题图表完全裸奔|`DefaultChart` 的判定是 `if (!staticMode)`，与主题名无关；`chart.css` 在 `rmd.components` 层对**所有**主题生效|
|§2.2 两种滑块形态不一致|都是同一个 UIArc `Slider`，共用 `--rmd-slider-\*`；实测两者 thumb 14px、track 4px、radius 0|
|§2.3 toggle 与 checkbox 同形|基线已提供真开关；**是主题自己的规则把它们又拉平了**（§3.2 A）|
|§2.4 select 用系统原生箭头|select 是 Radix 自定义 listbox，有 `trigger`/`menu`/`item` 部件钩子，下拉面板可以完整造型|
|§2.5 number 有原生 spinner|`<number>` 是 `type="text" inputMode="decimal"`，**不存在** spinner|
|§2.6 步骤指示器整条不可见|基线 `navigation.css:427-512` 完整实现；实测 rail `display: flex`、有 2 个 dot|
|§2.6 quiz / date picker 零覆盖|基线 `controls.css:621-700`、UIArc 日历模块完整覆盖|
|§2.6 gallery 不受主题作用域约束|`gallery.css` 在 `rmd.components` 层，跟随主题变量|
|§2.6 autofill 黄底|基线与主题都未处理，仍是**内核级**缺口，不是主题缺口|

### 3.4 主题未覆盖、基线用默认外观的部分

这些不是"错"，只是继承了 default 皮肤，与 SF-01 语言不一致：

|区域|现状|
|-|-|
|步骤点 `.local-steps-dot`|22px 圆形 + 2px 描边，`--pu-rail-\*` 未覆盖|
|日历 `.local-calendar`|`--rmd-calendar-day-radius: 50%`，日期是圆点|
|画廊 `.rmd-gallery-\*`|箭头 44px 圆形，`--rmd-gallery-radius` 继承 `--radius-card`（已为 0）|
|quiz|完整 default 皮肤，只有按钮因 `.md-button` 规则而方角|
|徽标状态点 `.md-status::before`|`0.5em` 圆形，主题零规则|
|`md-spinner` / `md-skeleton` / `md-loading`|主题零规则|
|图解工具条容器|`--radius-toolbar` 未覆盖（只压了按钮）|
|表格单元格内边距|`--table-cell-padding-y/-x` 未覆盖，基线 10/12px|

\---

## 4\. 版本错位：主题针对旧内核测试

|项|值|
|-|-|
|主题 vendor|`reactive-md-0.8.0-92733a4c0cc3.tgz`（2026-11-14 20:10）|
|内核 HEAD|`f4452b5`（2026-11-15 10:56）|
|重构提交|`4d26832`（2026-11-14 23:12），晚于主题 tarball **约 3 小时**|
|实际解析到的包|Demo 的 `2a1df8bd` 构建（`node\_modules` 是软链接）|

差异是**单向**的：主题 tarball 的 `reactive-md.css` 有 255 个自定义属性，
当前构建有 296 个，缺失的 41 个全部来自 `4d26832`：

```
--dialog-backdrop --tooltip-bg --tooltip-ink
--radius-hairline --radius-circle --radius-2xs --radius-xs
--radius-inset --radius-toolbar --radius-xl --shadow-lg
--rmd-button-press-shadow --rmd-diagram-node-shadow
以及整套 --rmd-\*-shadow-geometry / \*-shadow-opacity
```

`--rmd-slider-thumb-width`、`@layer rmd.themes`、`data-rmd-part` 这些
**两边都有**——说明主题是在重构**前**按同一套接口先行写的，
重构后被内核追平，但主题从未对新基线复验。

实际风险：在主题目录跑 `npm ci`（按 lockfile 装 `92733a4`）会**静默降级**
内核一个提交；而 `npm test` 现在其实跑的是新内核（经软链接），
所以测试通过反而掩盖了错位。

**建议**：把 `vendor/\*.tgz` 与 lockfile 换到与 HEAD 同源的构建；
并在测试里断言 `LOCAL\_STYLE\_CONTRACT` 与 `@layer rmd.themes` 存在
（当前主题测试不检查层，内核自己的示例测试检查）。

\---

## 5\. NeonBlade UI 还能借鉴什么

上一版报告已采纳/否决的项不再重复。下面是**新筛出的 5 项**，按价值排序。
筛选标准是：解决真实缺口、纯 CSS（或只需变量）、落在 0–4px / 4px 网格 /
80-120-180ms / 无 keyframes 的约束内。

|#|来源|要借鉴的机制|映射到|结论|
|-|-|-|-|-|
|1|`neon-checkbox`|`:indeterminate` 的横杠画法|`.local-checkbox input`、`.local-checklist-item input`|**采纳**（修实测缺陷）|
|2|`progress-bar`|伪元素画 10 段刻度|`.local-progress-track::after`|**采纳**|
|3|`timeline`|平行四边形切片 + 竖线穿点居中公式|`.local-visual-timeline-\*`|**采纳**（几何）|
|4|`neon-line-chart`|tooltip 斜切边的 1px 描线|`.rmd-chart-tooltip`|**采纳**（一个伪元素）|
|5|`neon-bar-chart`|柱圆角走变量而非规则|`--rmd-chart-bar-radius`|**采纳**（一行 token）|
|6|`circular-progress`|`C=2πr`、`offset=C−(pct/100)C`、`rotate(-90deg)`|无对应图表类型|备选|
|7|`accent-frame` / `corner-cut-button`|边框框套相邻兄弟、`-thickness/2` 光学校正|`.local-visual::after`|可选|
|8|`badge`|显式百分比的闪烁阶梯|`.md-status::before`|否决（需要 keyframes，SDK 拒绝）|

### 5.1 `:indeterminate` 横杠（最高价值）

实测确认这是**活的缺陷**：主题用 `background-image` 覆盖了 `:checked`，
但没写 `:indeterminate`，而基线是靠 `accent-color` 表达混合态的，
被主题的 `background-color` 覆盖后，混合态渲染成一个纯色实心方块，
没有任何"部分选中"的信号。

纯 CSS 修法（不需要 data URI，不需要 keyframes）：

```css
\[data-rmd-theme="sci-fi"] :is(
  .local-checkbox .md-toggle-label input,
  .local-checklist-item input,
  .local-multi-option input
)\[type="checkbox"]:indeterminate {
  -webkit-mask-image: none;
  mask-image: none;
  border-color: var(--accent);
  background-color: var(--accent);
  background-image: linear-gradient(var(--accent-ink), var(--accent-ink));
  background-size: 8px 2px;      /\* 2px 信号线，落在 4px 网格上 \*/
  background-position: center;
  background-repeat: no-repeat;
}
```

注意 `:indeterminate` 只能由 DOM 属性触发，CSS 无法自己产生；主题侧
只需保证这个状态有正确的视觉。它属于"作者写 HTML 时才出现"的状态
（`<checkbox>` 组件本身不输出 `indeterminate`），所以优先级排第一
但收益面积较小。

### 5.2 进度条分段刻度

NeonBlade 用 9 个 DOM 分隔元素；纯 CSS 可以一个伪元素搞定：

```css
\[data-rmd-theme="sci-fi"] .local-progress-track {
  position: relative;           /\* 主题已有 \*/
}
\[data-rmd-theme="sci-fi"] .local-progress-track::after {
  content: "";
  position: absolute;
  inset: 0;
  pointer-events: none;
  background: repeating-linear-gradient(
    90deg,
    transparent 0 calc(10% - 1px),
    var(--surface) calc(10% - 1px) 10%
  );
}
```

`::after` 画在 `-fill` 子元素之后，所以刻度压在填充上，形成"10 段仪表"
读数。这与主题现有的 45° 斜纹是两种语言，二选一，不要叠加。

顺带一个实测到的**时序违规**：`.local-progress-fill` 从基线继承
`transition: width 300ms`，不在 80/120/180 三档内，主题需另行覆盖。

### 5.3 时间轴几何

三个可以直接用的公式：

```css
/\* 切片形状：平行四边形，不引入圆角 \*/
clip-path: polygon(6px 0, 100% 0, calc(100% - 6px) 100%, 0 100%);

/\* 竖线穿过 N 像素节点的精确居中（lw = 线宽） \*/
left: calc(var(--node-size) / 2 - var(--line-width) / 2);

/\* 纯 CSS 虚线轴，不必用 SVG stroke-dasharray \*/
background: repeating-linear-gradient(
  to bottom, var(--accent) 0 4px, transparent 4px 12px);
```

配合 `nth-child` 的 80ms 阶梯延迟（`--motion-fast`），正好落在契约的
第一档。主题当前只写了 `-bar` 和 `-track` 两条规则（`components.css:641-645`），
其余（axis、tick、item、head、title、times、detail）全部继承 default。

### 5.4 tooltip 斜切边描线

```css
\[data-rmd-theme="sci-fi"] .rmd-chart-tooltip {
  position: relative;
  overflow: hidden;
}
\[data-rmd-theme="sci-fi"] .rmd-chart-tooltip::after {
  content: "";
  position: absolute;
  right: 0;
  bottom: 0;
  inline-size: 12px;
  block-size: 1px;
  background: var(--accent);
  transform-origin: bottom right;
  transform: rotate(-45deg) translateX(4px);
}
```

让被切掉的那条斜边有 1px 描线，从"裁掉了一角"变成"加工过的边"。
主题当前的 tooltip 是纯 0 圆角矩形，没有斜切，所以这条要先决定
是否引入角切造型；如果引入，才需要它。

### 5.5 柱圆角走变量

实测柱子的 `rx` 是 **4**，因为基线 `--rmd-chart-bar-radius: 4px`，
而主题的设计规范写的是"柱为清晰矩形"。规范与输出不一致。

```css
\[data-rmd-theme="sci-fi"].md-document,
\[data-rmd-theme="sci-fi"] .md-document {
  --rmd-chart-bar-radius: 0px;
}
```

**必须写 `.md-document`**：变量要落在文档根上，`\[data-rmd-theme="sci-fi"]`
单独写在某些路径下不一定命中根节点。

顺带把整套图表绘制变量补上（这是 §3.2 C 的修法）：

```css
--rmd-chart-bar-radius: 0px;
--rmd-chart-line-width: 1.6;
--rmd-chart-line-highlight-width: 2.4;
--rmd-chart-point-stroke-width: 1.5;
--rmd-chart-area-opacity: 0.10;
--rmd-chart-dim-opacity: 0.55;   /\* ≥3:1，见 §3.2 D \*/
--rmd-chart-mark-stroke: var(--surface);
--rmd-chart-grid: var(--chart-grid);
--rmd-chart-axis: var(--chart-axis);
--rmd-chart-axis-title: var(--ink-soft);
--rmd-chart-guide: var(--accent);
```

### 5.6 循环进度（备选）

没有对应的图表类型（`default-chart.tsx` 只有 `bar|line|area|scatter|donut|pie`），
只有将来做仪表盘时才有意义。几何本身很干净：

```
radius = (diameter − strokeWidth) / 2
circumference = 2π·radius
offset = circumference − (pct/100)·circumference
svg = rotate(-90deg)              // 0% 在 12 点方向
```

那时要用 `stroke-linecap: butt`、1px 描边轨道、180ms 过渡，
不要 `drop-shadow` 发光。

### 5.7 明确否决的新候选

|来源|否决理由|
|-|-|
|`badge` 的 dot flicker / pulse|需要 `@keyframes`，SDK 直接拒绝；且闪烁与"信号先于装饰"的原则冲突|
|`accent-frame` 的 glow/pulse/flicker hover|同上，全部是 keyframes|
|`corner-cut-button` 的 shine/scan/pulse|keyframes + 4–6s 时长 + GPU 开销|
|`border-beam-corner-cut-card`|`inset:-100%` + 旋转 conic 渐变，4–6s，纯装饰|
|`neon-sparkline`|面积渐变不可达：RM 用行内 `fill: var(--chart-N)`，没有 `<defs>` 可挂|
|`neon-glow-corner-cut-card`|只有发光，且源文件里有失效的 `.ngcc-wrapper` 选择器（类已从 JSX 移除）|
|`rain-loader`|运行时注入全局 `<style>`，且无对应组件|
|`turbine-loader`|需要 SVG 标记；1800ms 旋转 + 多层发光|

### 5.8 移植时的通用陷阱

1. **硬编码深色底**。`#000`、`#0a0a12`、`rgba(10,10,18)` 遍布 badge、
corner-cut-button、neon-checkbox、neon-select。SF-01 有真正的亮色模式，
每处都要换成 `var(--surface)` / `var(--sf-field-bg)` / `var(--accent-ink)`。
2. **`color-mix(..., transparent)` 的发光阴影**。SF-01 的立面契约是
"1px 环，永不模糊投影"，全部剥离。
3. **Tailwind class 承载的布局**。`accent-frame` 的 `.css` 里明写
"布局和背景在 Tailwind"；`badge` 的尺寸也是 class 字符串。单独拿 CSS 是残的。
4. **离网格数值** 需要吸附：`gap: 9px`→8、`padding: 2px 10px`→0 8、
`margin-bottom: 5px`→4、`translateY(10px)`→8。
5. **时长**：整个库集中在 150/200/300/450/500/600/1200/1600/1800ms；
只有 checkbox 的 180ms、select 的 120ms、timeline 的 80ms 落在契约上。
6. **`data:` URI 合法**（主题测试只拒绝 `@import` 与 `http(s)`），
但 URI 里的颜色跟不上 `--accent` 与明暗切换，优先用 `mask-image`。

\---

## 6\. 建议的实施顺序

|阶段|内容|风险|收益|
|-|-|-|-|
|1|**版本对齐**：vendor tarball + lockfile 换到 HEAD 同源构建；测试补断言 `@layer rmd.themes` 与 `LOCAL\_STYLE\_CONTRACT`|低|消除"测试通过但针对旧内核"的假象|
|2|**toggle/checkbox 解耦**：收窄勾选选择器，`<toggle>` 改成方形开关（`appearance:none` + 双层 `background-image` + `background-position` 位移，travel = 40−2−14−4 = 20px）|中（视觉变化明显）|高|
|3|**圆角补全**：`--radius-circle/-xl/-toolbar/-inset/-hairline/-2xs/-xs` + `--pu-radius-\*` 全部落到 0–2px|低（纯 token）|高（消除 5 处圆形泄漏）|
|4|**图表绘制变量**：`--rmd-chart-\*` 整套 + `dim-opacity ≥ .45`；删掉无效的 `stroke`/`fill` 规则|低|高（柱子 4px→0、dim 合规）|
|5|**死选择器清理**：`.local-range-value`、8 条 `.md-select-input`、嵌套 `.local-visual`；补 `.md-status::before`、spinner/skeleton|低|中|
|6|**补一致外观**：步骤点方角 + `--pu-rail-\*`、日历日、画廊箭头、quiz 外壳|低|中|
|7|**NeonBlade 借鉴**：`:indeterminate`、进度刻度、时间轴几何、tooltip 斜边|低|低–中|

每阶段后执行：

```sh
npm run test        # 作用域、对比度、圆角、间距契约
npm run typecheck
npm run build
npm run screenshot  # 控制台错误或渲染诊断非零即失败
```

阶段 2、4 属破坏性视觉变更，需人工比对 `screenshots/`。

\---

## 7\. 复现方法

```sh
cd others/sci-fi-theme
mkdir -p \_research/verify
```

在 `\_research/verify/` 放四个文件（`index.html`、`main.tsx`、`vite.config.ts`、
`probe.mjs`），要点：

* `main.tsx` 导入 `reactive-md/styles.css` → `../../src/tokens.css` →
`../../src/components.css`，用 `themes={\[sciFiTheme]}` 登记；
* 探针文档要覆盖 `<slider>`、`<range-slider bind-start="low" bind-end="high">`、
`<toggle>`、`<checkbox>`、`<select>`、`<number>`、`<date>`、`<progress>`、
`<steps>`、`<quiz type="choice" answer="a">`、`<chart>`、`<timeline>`、
`<coordinate>`、`<plot>`、`<gallery>`；
* `probe.mjs` 用 Playwright（`channel: 'msedge'`）启动 Vite 后读
`getComputedStyle`，并遍历 `document.styleSheets` 找出**实际匹配到**的规则。

几个容易踩的写法（都能让整篇文档变成 `role="alert"` 的错误页）：

|错|对|
|-|-|
|`bind-start="{{bind:low}}"`|`bind-start="low"`|
|`<badge label="Beta">`|`<badge tone="neutral">Beta</badge>`|
|`<timer seconds="60">`|`<timer duration="60">`|
|`<diagram title="…">`|`<diagram label="…">` + 每个 `<node>` 都要 `</node>`|

验证加载顺序是否已无关，把两个 `import` 对调后重复读同样的属性即可
（本文 §2.1 的结论就是这样得出的）。

\---

## 8\. 待决策

1. `<toggle>` 是否接受形态变化（16px 方框 → 40×20 方形开关）？这是
§6 阶段 2 的内容，属于破坏性视觉变更。
2. 圆角契约的上限是否从「0–4px」收紧到「0–2px」？新增的命名圆角如果
全部取 0，步骤点会变成方块、日历日期会变成方格，需要确认这是否是
想要的语言。
3. 图表 dim 透明度取 .45 还是 .55？前者刚好过 3:1，后者留余量但会让
"淡化非选中系列"的效果变弱。或者改用描边淡化（`stroke: var(--line)`）
而不是透明度，更符合主题"不用色块"的原则。
4. 是否把 NeonBlade 的角切（notch）做成 token 开关，还是彻底不引入？
主题现在是纯矩形，角切会改变整体识别度。

