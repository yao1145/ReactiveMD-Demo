// src/testing/types.ts
var e = "reactive-md-compliance/v1", t = "reactive-md-behavior-spec/v1", n = "reactive-md-react-spec/v1", r = "reactive-md-browser-spec/v1", i = 128, a = 262144, o = 4096, s = 64, c = 16, l = 16, u = 512, d = 2048, f = 16, p = 1e4;
// src/testing/cases.ts
function m(e) {
	return Object.freeze({
		id: e.id,
		suite: e.suite,
		status: e.status,
		...e.message === void 0 ? {} : { message: e.message },
		diagnostics: Object.freeze([...e.diagnostics ?? []]),
		...e.capabilities === void 0 ? {} : { capabilities: Object.freeze([...e.capabilities]) },
		...e.observed === void 0 ? {} : { observed: Object.freeze({ ...e.observed }) }
	});
}
function h(e, t, n = {}) {
	return m({
		id: e,
		suite: t,
		status: "passed",
		...n
	});
}
function g(e, t, n, r = []) {
	return m({
		id: e,
		suite: t,
		status: "failed",
		message: n,
		diagnostics: r
	});
}
function _(e, t, n, r) {
	return m({
		id: e,
		suite: t,
		status: "skipped",
		message: n,
		capabilities: r
	});
}
function v(e, t, n, r) {
	return m({
		id: e,
		suite: t,
		status: "unsupported",
		message: n,
		capabilities: r
	});
}
// src/testing/values.ts
var y = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
function b(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function x(e, t) {
	if (!b(e)) throw TypeError(`${t} must be a plain object.`);
	return e;
}
function S(e, t, n) {
	for (let r of Object.keys(e)) {
		if (y.has(r)) throw TypeError(`${n} must not contain "${r}".`);
		if (!t.has(r)) throw TypeError(`${n} has unknown field "${r}".`);
	}
}
function C(e, t, n = o) {
	if (typeof e != "string") throw TypeError(`${t} must be a string.`);
	if (e.length > n) throw TypeError(`${t} exceeds ${n} characters.`);
	return e;
}
function w(e, t) {
	if (typeof e != "boolean") throw TypeError(`${t} must be a boolean.`);
	return e;
}
function T(e, t) {
	if (typeof e != "number" || !Number.isFinite(e)) throw TypeError(`${t} must be a finite number.`);
	return e;
}
function E(e, t, n = 0, r = 2 ** 53 - 1) {
	let i = T(e, t);
	if (!Number.isInteger(i) || i < n || i > r) throw TypeError(`${t} must be an integer between ${n} and ${r}.`);
	return i;
}
function D(e, t) {
	if (e === null || typeof e == "boolean") return e;
	if (typeof e == "number") return T(e, t);
	if (typeof e == "string") return C(e, t);
	if (Array.isArray(e)) {
		if (e.length > 1e4) throw TypeError(`${t} exceeds ${p} entries.`);
		let n = e.every((e) => typeof e == "string"), r = e.every((e) => typeof e == "number" && Number.isFinite(e));
		if (!n && !r) throw TypeError(`${t} must be an array of strings or an array of finite numbers.`);
		return Object.freeze(n ? e.map((e) => C(e, t)) : e.map((e) => T(e, t)));
	}
	throw TypeError(`${t} must be a scalar or a flat string/number array.`);
}
function O(e, t, n) {
	let r = x(e, t), i = Object.keys(r);
	if (i.length === 0) throw TypeError(`${t} must not be empty.`);
	if (i.length > n) throw TypeError(`${t} accepts at most ${n} entries.`);
	let a = {};
	for (let e of i) {
		if (y.has(e)) throw TypeError(`${t} must not contain "${e}".`);
		if (!/^[A-Za-z_][A-Za-z0-9_-]*$/.test(e) || e.length > 128) throw TypeError(`${t}.${e} is not a valid public name.`);
		a[e] = D(r[e], `${t}.${e}`);
	}
	return Object.freeze(a);
}
function k(e, t, n) {
	if (!Array.isArray(e)) throw TypeError(`${t} must be an array of strings.`);
	if (e.length > n) throw TypeError(`${t} accepts at most ${n} entries.`);
	return Object.freeze(e.map((e) => C(e, t)));
}
function A(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => Object.is(e, t[n])) : Object.is(e, t);
}
function j(e, t) {
	let n = Object.keys(e);
	return n.length === Object.keys(t).length && n.every((n) => Object.hasOwn(t, n) && A(e[n], t[n]));
}
function M(e, t, n, r) {
	let i = e === void 0 ? r : C(e, t, 128);
	if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(i)) throw TypeError(`${t} must use letters, digits, ".", "_" or "-".`);
	if (n.has(i)) throw TypeError(`${t} duplicates case id "${i}".`);
	return n.add(i), i;
}
function N(e) {
	return (e instanceof Error ? e.message : String(e)).slice(0, 2e3);
}
export { s as A, f as C, c as D, u as E, a as O, i as S, l as T, t as _, O as a, n as b, C as c, j as d, A as f, v as g, _ as h, D as i, o as k, k as l, h as m, w as n, N as o, g as p, M as r, E as s, S as t, x as u, r as v, d as w, p as x, e as y };
