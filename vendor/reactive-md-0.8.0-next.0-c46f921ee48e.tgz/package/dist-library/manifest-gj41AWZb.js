// src/local/configuration/limits.ts
var e = 1e6, t = 1e4, n = 2e7, r = 1e3, i = 1e5, a = 1e4, o = 1e5, s = 2e3, c = 16, l = 2e4, u = 2e6, d = 1e3, f = 100, p = 20, m = 2e3, h = 1e4;
function g(e) {
	if (e.length > 254 || /\s/.test(e)) return !1;
	let t = e.indexOf("@");
	if (t < 1 || t !== e.lastIndexOf("@")) return !1;
	let n = e.lastIndexOf(".");
	return n > t + 1 && n < e.length - 1;
}
// src/sdk/hash.ts
function _(e) {
	let t = 2166136261, n = 16777619;
	for (let r = 0; r < e.length; r += 1) {
		let i = e.charCodeAt(r);
		t ^= i, t = Math.imul(t, 16777619) >>> 0, n ^= i + r, n = Math.imul(n, 2246822507) >>> 0;
	}
	let r = e.length;
	return t ^= r, t = Math.imul(t, 16777619) >>> 0, n ^= r, n = Math.imul(n, 3266489909) >>> 0, `rmd-${t.toString(16).padStart(8, "0")}${n.toString(16).padStart(8, "0")}`;
}
// src/sdk/pattern.ts
function v(e, t) {
	let n = e[t];
	if (n === "*" || n === "+" || n === "?") return { length: e[t + 1] === "?" ? 2 : 1 };
	if (n !== "{") return null;
	let r = /^\{(\d+)(?:,(\d*))?\}/.exec(e.slice(t));
	return r ? { length: r[0].length + +(e[t + r[0].length] === "?") } : null;
}
function y(e) {
	let t = [], n = !1, r = !1;
	for (let i = 0; i < e.length; i += 1) {
		let a = e[i];
		if (n) {
			n = !1;
			continue;
		}
		if (a === "\\") {
			let t = e[i + 1];
			if (t !== void 0 && t >= "1" && t <= "9" || t === "k" && e[i + 2] === "<") return !1;
			n = !0;
			continue;
		}
		if (r) {
			a === "]" && (r = !1);
			continue;
		}
		if (a === "[") {
			r = !0;
			continue;
		}
		if (a === "(") {
			if (e[i + 1] === "?") {
				if (e[i + 2] !== ":") return !1;
				t.push({
					quantified: !1,
					alternation: !1
				}), i += 2;
				continue;
			}
			t.push({
				quantified: !1,
				alternation: !1
			});
			continue;
		}
		if (a === "|") {
			let e = t[t.length - 1];
			e && (e.alternation = !0);
			continue;
		}
		if (a === ")") {
			let n = t.pop();
			if (!n) return !1;
			let r = v(e, i + 1);
			if (r && (n.quantified || n.alternation)) return !1;
			let a = t[t.length - 1];
			a && (a.quantified = a.quantified || n.quantified || r !== null, a.alternation = a.alternation || n.alternation), r && (i += r.length);
			continue;
		}
		let o = v(e, i);
		if (o) {
			let e = t[t.length - 1];
			e && (e.quantified = !0), i += o.length - 1;
		}
	}
	return t.length === 0 && !n && !r;
}
// src/sdk/version.ts
var ee = "0.7.0", b = "reactive-md-component/v1", te = "reactive-md-config/v1", ne = "reactive-md-extensions/v1", re = 128, ie = 8, ae = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/, oe = /^0\d+$/;
function se(e) {
	if (e === void 0) return Object.freeze([]);
	let t = e.split("."), n = [];
	for (let e of t) {
		if (e.length === 0 || oe.test(e) && e !== "0" && /^\d+$/.test(e) || /^\d+$/.test(e) && !Number.isSafeInteger(Number(e))) return null;
		n.push(/^\d+$/.test(e) ? Number(e) : e);
	}
	return Object.freeze(n);
}
function x(e) {
	let t = ae.exec(e);
	if (!t) return null;
	let [, n, r, i, a] = t;
	for (let e of [
		n,
		r,
		i
	]) if (e.length > 1 && e.startsWith("0") || !Number.isSafeInteger(Number(e))) return null;
	let o = se(a);
	return o === null ? null : {
		major: Number(n),
		minor: Number(r),
		patch: Number(i),
		prerelease: o
	};
}
function ce(e, t) {
	return typeof e == "number" && typeof t == "number" ? e === t ? 0 : e < t ? -1 : 1 : typeof e == "number" ? -1 : typeof t == "number" ? 1 : e === t ? 0 : e < t ? -1 : 1;
}
function le(e, t) {
	for (let n of [
		"major",
		"minor",
		"patch"
	]) if (e[n] !== t[n]) return e[n] < t[n] ? -1 : 1;
	if (e.prerelease.length === 0 && t.prerelease.length === 0) return 0;
	if (e.prerelease.length === 0) return 1;
	if (t.prerelease.length === 0) return -1;
	let n = Math.min(e.prerelease.length, t.prerelease.length);
	for (let r = 0; r < n; r += 1) {
		let n = ce(e.prerelease[r], t.prerelease[r]);
		if (n !== 0) return n;
	}
	return e.prerelease.length === t.prerelease.length ? 0 : e.prerelease.length < t.prerelease.length ? -1 : 1;
}
function S(e, t, n) {
	return {
		major: e,
		minor: t,
		patch: n,
		prerelease: Object.freeze([])
	};
}
function ue(e, t) {
	if (e === "^") {
		let e = t.major > 0 ? S(t.major + 1, 0, 0) : t.minor > 0 ? S(0, t.minor + 1, 0) : S(0, 0, t.patch + 1);
		return [{
			operator: ">=",
			version: t
		}, {
			operator: "<",
			version: e
		}];
	}
	return e === "~" ? [{
		operator: ">=",
		version: t
	}, {
		operator: "<",
		version: S(t.major, t.minor + 1, 0)
	}] : [{
		operator: e,
		version: t
	}];
}
function C(e) {
	if (typeof e != "string") return null;
	let t = e.trim();
	if (t.length === 0 || t.length > 128) return null;
	let n = t.split(/\s+/);
	if (n.length === 0 || n.length > 8) return null;
	let r = [];
	try {
		for (let e of n) {
			let t = "=", n = e;
			e.startsWith(">=") || e.startsWith("<=") ? (t = e.slice(0, 2), n = e.slice(2)) : (e.startsWith(">") || e.startsWith("<") || e.startsWith("=") || e.startsWith("^") || e.startsWith("~")) && (t = e[0], n = e.slice(1));
			let i = x(n);
			if (i === null || (r.push(...ue(t, i)), r.length > 16)) return null;
		}
	} catch {
		return null;
	}
	return Object.freeze({
		source: t,
		comparators: Object.freeze(r)
	});
}
function de(e) {
	return typeof e == "string" && x(e) !== null;
}
function fe(e, t) {
	try {
		let n = x(e);
		if (n === null) return !1;
		let r = typeof t == "string" ? C(t) : t;
		if (!r || !Array.isArray(r.comparators) || r.comparators.length === 0 || n.prerelease.length && !r.comparators.some(({ version: e }) => e.prerelease.length && e.major === n.major && e.minor === n.minor && e.patch === n.patch)) return !1;
		for (let e of r.comparators) {
			let t = le(n, e.version);
			switch (e.operator) {
				case "=":
					if (t !== 0) return !1;
					break;
				case ">":
					if (t <= 0) return !1;
					break;
				case ">=":
					if (t < 0) return !1;
					break;
				case "<":
					if (t >= 0) return !1;
					break;
				case "<=":
					if (t > 0) return !1;
					break;
				default: return !1;
			}
		}
		return !0;
	} catch {
		return !1;
	}
}
function pe(e) {
	return typeof e == "object" && !!e && typeof e.source == "string" && Array.isArray(e.comparators);
}
// src/sdk/manifest.ts
var me = 64, he = 64, ge = 128, _e = 160, ve = 64, ye = 64, be = 512, w = 4096, xe = 16, Se = 32, Ce = 256, T = 65536, E = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, D = /^[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*$/, we = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/, Te = /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/, O = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), k = /* @__PURE__ */ new WeakSet(), Ee = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), De = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), Oe = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), ke = /* @__PURE__ */ new Set([
	"text",
	"number",
	"boolean",
	"choice",
	"date",
	"timer",
	"checklist",
	"tabs",
	"diagram",
	"multi-select",
	"selection",
	"steps",
	"collection"
]), Ae = /* @__PURE__ */ new Set([
	"empty",
	"false",
	"max-step",
	"nearest-zero",
	"min",
	"first-option",
	"first-tab",
	"first-step",
	"first-node",
	"checked",
	"duration",
	"empty-array",
	"none"
]), je = /* @__PURE__ */ new Set([
	"none",
	"inline",
	"markdown"
]), Me = /* @__PURE__ */ new Set([
	"none",
	"any",
	"inline",
	"content",
	"table",
	"plot",
	"diagram",
	"quiz",
	"options",
	"tabs",
	"steps",
	"components"
]), Ne = /* @__PURE__ */ new Set(/* @__PURE__ */ "numeric-range.text-length.date-bounds.nonempty.progress-bounds.timer-duration.option-count.selection-requires.inline-body.no-components.single-table.math-body.options-body.value-sequence.only-children.diagram-body.quiz-body.checklist-body.dynamic-constraints.require-full-interpolation.scoped-expressions.row-values.validation-rule.anchor.navigation.data-table.plot-math.chart-table.timeline-table.table-selection.retain.self-binding-read.inline-math-reads.value-date.value-length.value-required.value-email".split(".")), Pe = /* @__PURE__ */ new Set([
	"none",
	"required",
	"optional"
]), Fe = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"form",
	"props",
	"bindings",
	"children",
	"structure",
	"rules",
	"slotRelations",
	"legacyHost",
	"capabilities",
	"authoring",
	"dependencies",
	"styles",
	"requires"
]), Ie = /* @__PURE__ */ new Set([
	"kind",
	"required",
	"static",
	"dynamic",
	"default",
	"nullable",
	"enum",
	"values",
	"pattern",
	"min",
	"max",
	"integer",
	"positive",
	"color",
	"coerce",
	"description"
]), Le = /* @__PURE__ */ new Set([
	"kind",
	"family",
	"bind",
	"initial",
	"initialRule",
	"required",
	"exclusive",
	"constraints",
	"options",
	"maxItems",
	"requiresAttributes",
	"compare",
	"retain"
]), Re = /* @__PURE__ */ new Set([
	"min",
	"max",
	"step"
]), ze = /* @__PURE__ */ new Set([
	"interactive",
	"static",
	"ssr",
	"offline"
]), Be = /* @__PURE__ */ new Set([
	"title",
	"description",
	"category",
	"insertText"
]), Ve = /* @__PURE__ */ new Set(["kind", "required"]), He = /* @__PURE__ */ new Set([
	"rule",
	"label",
	"parents",
	"child",
	"children",
	"min",
	"max",
	"inlineOnly",
	"noComponents",
	"valueAttribute",
	"generatedPrefix",
	"forbidSeparator",
	"maxItems"
]), Ue = /* @__PURE__ */ new Set(["id", "version"]), We = /* @__PURE__ */ new Set(["kernel"]), Ge = /^[A-Za-z0-9][A-Za-z0-9._/-]*$/, Ke = /^[A-Za-z][A-Za-z0-9]*$/, A = /* @__PURE__ */ new Set(["setMany"]), qe = 16, Je = 32, Ye = 16, Xe = 32, Ze = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]);
function j(e, t) {
	throw Error(`Invalid local component manifest (${e}): ${t}`);
}
function M(e) {
	try {
		let t = JSON.stringify(e);
		return typeof t == "string" ? typeof TextEncoder == "function" ? new TextEncoder().encode(t).length : t.length * 2 : Infinity;
	} catch {
		return Infinity;
	}
}
function N(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function P(e, t, n) {
	for (let r of Object.keys(e)) O.has(r) && j(n, `field "${r}" is not allowed.`), t.has(r) || j(n, `unknown field "${r}".`);
}
function F(e, t) {
	return typeof e != "boolean" && j(t, "must be a boolean."), e;
}
function I(e, t, n = w) {
	return typeof e != "string" && j(t, "must be a string."), e.length > n && j(t, `exceeds the ${n}-character limit.`), e;
}
function L(e, t) {
	return typeof e == "number" && Number.isFinite(e) || j(t, "must be a finite number."), e;
}
function R(e, t) {
	return typeof e != "string" && j(t, "must be a string."), e.length > 128 && j(t, "exceeds the 128-character limit."), E.test(e) || j(t, "must use lowercase kebab-case."), e;
}
function z(e, t) {
	N(e) || j(t, "must be an object.");
	let n = {}, r = Object.keys(e).sort();
	for (let i of r) O.has(i) && j(t, `locale "${i}" is not allowed.`), Te.test(i) || j(t, `locale "${i}" must look like "en" or "zh-CN".`), n[i] = I(e[i], `${t}.${i}`, 256);
	return n;
}
function Qe(e, t) {
	N(e) || j(t, "must be an object."), P(e, Be, t);
	let n = {};
	return e.title !== void 0 && (n.title = z(e.title, `${t}.title`)), e.description !== void 0 && (n.description = z(e.description, `${t}.description`)), e.category !== void 0 && (n.category = I(e.category, `${t}.category`, 64)), e.insertText !== void 0 && (n.insertText = I(e.insertText, `${t}.insertText`, w)), n;
}
function $e(e, t, n) {
	N(e) || j(n, "must be an object."), P(e, Ve, n);
	let r = e.kind;
	typeof r == "string" && je.has(r) || j(`${n}.kind`, "must be \"none\", \"inline\" or \"markdown\".");
	let i = r;
	e.required !== void 0 && F(e.required, `${n}.required`);
	let a = e.required === !0;
	return t === "leaf" && i !== "none" && j(n, "a leaf component cannot declare body content."), t === "inline" && i === "markdown" && j(n, "an inline component cannot declare Markdown block content."), a && i === "none" && j(n, "cannot require body content of kind \"none\"."), {
		kind: i,
		...a ? { required: !0 } : {}
	};
}
function B(e) {
	if (e !== void 0) return e.kind === "none" ? Object.freeze({
		rule: "none",
		label: "none"
	}) : e.kind === "inline" ? Object.freeze({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0,
		...e.required ? { min: 1 } : {}
	}) : Object.freeze({
		rule: "any",
		label: "none",
		...e.required ? { min: 1 } : {}
	});
}
function V(e, t) {
	Array.isArray(e) || j(t, "must be an array of component names."), e.length > 32 && j(t, "accepts at most 32 names.");
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = R(i, t);
		n.has(e) && j(t, `name "${e}" is declared more than once.`), n.add(e), r.push(e);
	}
	return Object.freeze(r);
}
function H(e, t) {
	let n = L(e, t);
	return (!Number.isInteger(n) || n < 0) && j(t, "must be a nonnegative integer."), n;
}
function et(e, t, n) {
	N(e) || j(n, "must be an object."), P(e, He, n);
	let r = e.rule;
	typeof r == "string" && Me.has(r) || j(`${n}.rule`, "is not a supported child rule.");
	let i = r;
	t === "leaf" && i !== "none" && j(n, "a leaf component cannot declare body content."), t === "inline" && i !== "none" && i !== "inline" && i !== "any" && j(n, "an inline component only supports \"none\", \"inline\" or \"any\".");
	let o = { rule: i };
	if (e.label !== void 0 && (typeof e.label == "string" && Pe.has(e.label) || j(`${n}.label`, "must be \"none\", \"required\" or \"optional\"."), o.label = e.label), e.parents !== void 0 && (o.parents = V(e.parents, `${n}.parents`)), e.child !== void 0 && (o.child = R(e.child, `${n}.child`)), e.children !== void 0 && (o.children = V(e.children, `${n}.children`)), e.min !== void 0 && (o.min = G(e.min, `${n}.min`, a)), e.max !== void 0 && (o.max = G(e.max, `${n}.max`, a)), o.min !== void 0 && o.max !== void 0 && o.min > o.max && j(n, "\"min\" cannot exceed \"max\"."), e.inlineOnly !== void 0 && (o.inlineOnly = F(e.inlineOnly, `${n}.inlineOnly`)), e.noComponents !== void 0 && (o.noComponents = F(e.noComponents, `${n}.noComponents`)), e.valueAttribute !== void 0 && (o.valueAttribute = R(e.valueAttribute, `${n}.valueAttribute`)), e.generatedPrefix !== void 0) {
		let t = I(e.generatedPrefix, `${n}.generatedPrefix`, 128);
		t.length === 0 && j(`${n}.generatedPrefix`, "must not be empty."), o.generatedPrefix = t;
	}
	if (e.forbidSeparator !== void 0) {
		let t = I(e.forbidSeparator, `${n}.forbidSeparator`, 4);
		t.length === 0 && j(`${n}.forbidSeparator`, "must not be empty."), o.forbidSeparator = t;
	}
	return e.maxItems !== void 0 && (o.maxItems = G(e.maxItems, `${n}.maxItems`, a)), Object.freeze(o);
}
function U(e, t) {
	return R(e, t);
}
function W(e, t) {
	return H(e, t);
}
function G(e, t, n) {
	let r = H(e, t);
	return r > n && j(t, `cannot exceed the kernel limit ${n}.`), r;
}
function K(e, t) {
	return V(e, t);
}
function tt(e, t) {
	return Array.isArray(e) || j(t, "must be an array of strings."), e.length > 32 && j(t, "accepts at most 32 values."), Object.freeze(e.map((e) => I(e, t, 128)));
}
function nt(e, t) {
	N(e) || j(t, "must be an object.");
	let n = e.kind;
	typeof n == "string" && Ne.has(n) || j(`${t}.kind`, "is not a supported rule.");
	let r = (n) => P(e, /* @__PURE__ */ new Set(["kind", ...n]), t), i = (n) => {
		let r = {};
		for (let i of n) e[i] !== void 0 && (r[i] = U(e[i], `${t}.${i}`));
		return r;
	};
	switch (n) {
		case "numeric-range": {
			r([
				"min",
				"max",
				"step",
				"order",
				"integer",
				"positiveInteger"
			]);
			let a;
			return e.order !== void 0 && (e.order !== "nondecreasing" && e.order !== "increasing" && j(`${t}.order`, "must be \"nondecreasing\" or \"increasing\"."), a = e.order), Object.freeze({
				kind: n,
				...i([
					"min",
					"max",
					"step",
					"integer",
					"positiveInteger"
				]),
				...a ? { order: a } : {}
			});
		}
		case "text-length": return r(["min", "max"]), Object.freeze({
			kind: n,
			...i(["min", "max"])
		});
		case "date-bounds": return r([
			"min",
			"max",
			"required"
		]), Object.freeze({
			kind: n,
			...i([
				"min",
				"max",
				"required"
			])
		});
		case "nonempty": return r(["attribute"]), Object.freeze({
			kind: n,
			attribute: U(e.attribute, `${t}.attribute`)
		});
		case "progress-bounds": return r([
			"value",
			"max",
			"defaultMax"
		]), Object.freeze({
			kind: n,
			value: U(e.value, `${t}.value`),
			max: U(e.max, `${t}.max`),
			defaultMax: L(e.defaultMax, `${t}.defaultMax`)
		});
		case "timer-duration": return r(["attribute", "default"]), Object.freeze({
			kind: n,
			attribute: U(e.attribute, `${t}.attribute`),
			default: L(e.default, `${t}.default`)
		});
		case "option-count": return r(["max"]), Object.freeze({
			kind: n,
			...e.max === void 0 ? {} : { max: U(e.max, `${t}.max`) }
		});
		case "selection-requires": return r(["key", "attributes"]), Object.freeze({
			kind: n,
			key: U(e.key, `${t}.key`),
			attributes: K(e.attributes, `${t}.attributes`)
		});
		case "inline-body": return r(["strict"]), Object.freeze({
			kind: n,
			...e.strict === void 0 ? {} : { strict: F(e.strict, `${t}.strict`) }
		});
		case "no-components":
		case "math-body":
		case "inline-math-reads": return r([]), Object.freeze({ kind: n });
		case "single-table": return r(["fallbackSingle"]), Object.freeze({
			kind: n,
			...e.fallbackSingle === void 0 ? {} : { fallbackSingle: F(e.fallbackSingle, `${t}.fallbackSingle`) }
		});
		case "options-body": return r([
			"child",
			"valueAttribute",
			"unique",
			"max",
			"forbidSeparator"
		]), Object.freeze({
			kind: n,
			child: U(e.child, `${t}.child`),
			valueAttribute: U(e.valueAttribute, `${t}.valueAttribute`),
			unique: e.unique === void 0 || F(e.unique, `${t}.unique`),
			...e.max === void 0 ? {} : { max: G(e.max, `${t}.max`, a) },
			...e.forbidSeparator === void 0 ? {} : { forbidSeparator: I(e.forbidSeparator, `${t}.forbidSeparator`, 4) }
		});
		case "value-sequence": return r([
			"child",
			"valueAttribute",
			"min",
			"generatedPrefix",
			"unique",
			"duplicateCode"
		]), Object.freeze({
			kind: n,
			child: U(e.child, `${t}.child`),
			valueAttribute: U(e.valueAttribute, `${t}.valueAttribute`),
			min: W(e.min, `${t}.min`),
			generatedPrefix: I(e.generatedPrefix, `${t}.generatedPrefix`, 128),
			unique: e.unique === void 0 || F(e.unique, `${t}.unique`),
			...e.duplicateCode === void 0 ? {} : { duplicateCode: I(e.duplicateCode, `${t}.duplicateCode`, 128) }
		});
		case "only-children": return r([
			"children",
			"min",
			"max",
			"maxCode",
			"onlyCode"
		]), Object.freeze({
			kind: n,
			children: K(e.children, `${t}.children`),
			min: W(e.min, `${t}.min`),
			...e.max === void 0 ? {} : { max: G(e.max, `${t}.max`, a) },
			...e.maxCode === void 0 ? {} : { maxCode: I(e.maxCode, `${t}.maxCode`, 128) },
			...e.onlyCode === void 0 ? {} : { onlyCode: I(e.onlyCode, `${t}.onlyCode`, 128) }
		});
		case "diagram-body": return r([
			"node",
			"edge",
			"id",
			"from",
			"to",
			"label"
		]), Object.freeze({
			kind: n,
			node: U(e.node, `${t}.node`),
			edge: U(e.edge, `${t}.edge`),
			id: U(e.id, `${t}.id`),
			from: U(e.from, `${t}.from`),
			to: U(e.to, `${t}.to`),
			...e.label === void 0 ? {} : { label: U(e.label, `${t}.label`) }
		});
		case "quiz-body": return r([
			"type",
			"answer",
			"tolerance",
			"child",
			"valueAttribute",
			"max"
		]), Object.freeze({
			kind: n,
			type: U(e.type, `${t}.type`),
			answer: U(e.answer, `${t}.answer`),
			tolerance: U(e.tolerance, `${t}.tolerance`),
			child: U(e.child, `${t}.child`),
			valueAttribute: U(e.valueAttribute, `${t}.valueAttribute`),
			...e.max === void 0 ? {} : { max: G(e.max, `${t}.max`, a) }
		});
		case "checklist-body": return r(["itemLimit"]), Object.freeze({
			kind: n,
			itemLimit: G(e.itemLimit, `${t}.itemLimit`, a)
		});
		case "dynamic-constraints":
		case "require-full-interpolation": return r(["attributes"]), Object.freeze({
			kind: n,
			attributes: K(e.attributes, `${t}.attributes`)
		});
		case "scoped-expressions": return r(["attributes", "scope"]), e.scope !== "row" && e.scope !== "validation" && j(`${t}.scope`, "must be \"row\" or \"validation\"."), Object.freeze({
			kind: n,
			attributes: K(e.attributes, `${t}.attributes`),
			scope: e.scope
		});
		case "row-values": return r([
			"rows",
			"key",
			"child",
			"childValue"
		]), Object.freeze({
			kind: n,
			rows: U(e.rows, `${t}.rows`),
			key: U(e.key, `${t}.key`),
			child: U(e.child, `${t}.child`),
			childValue: U(e.childValue, `${t}.childValue`)
		});
		case "validation-rule": return r([
			"when",
			"fields",
			"message",
			"placement",
			"max"
		]), e.placement !== "container" && e.placement !== "prose" && j(`${t}.placement`, "must be \"container\" or \"prose\"."), Object.freeze({
			kind: n,
			when: U(e.when, `${t}.when`),
			fields: U(e.fields, `${t}.fields`),
			message: U(e.message, `${t}.message`),
			placement: e.placement,
			max: G(e.max, `${t}.max`, 100)
		});
		case "anchor": return r(["id"]), Object.freeze({
			kind: n,
			id: U(e.id, `${t}.id`)
		});
		case "navigation": return r(["target"]), Object.freeze({
			kind: n,
			target: U(e.target, `${t}.target`)
		});
		case "data-table": return r([
			"rows",
			"key",
			"child",
			"childValue",
			"label",
			"maxRows",
			"defaultMaxRows",
			"documentRows",
			"documentCells",
			"maxColumns"
		]), Object.freeze({
			kind: n,
			rows: U(e.rows, `${t}.rows`),
			key: U(e.key, `${t}.key`),
			child: U(e.child, `${t}.child`),
			childValue: U(e.childValue, `${t}.childValue`),
			label: U(e.label, `${t}.label`),
			maxRows: U(e.maxRows, `${t}.maxRows`),
			defaultMaxRows: G(e.defaultMaxRows, `${t}.defaultMaxRows`, d),
			documentRows: G(e.documentRows, `${t}.documentRows`, m),
			documentCells: G(e.documentCells, `${t}.documentCells`, h),
			maxColumns: G(e.maxColumns, `${t}.maxColumns`, 20)
		});
		case "plot-math": return r([
			"min",
			"max",
			"samples",
			"curves",
			"points"
		]), Object.freeze({
			kind: n,
			min: U(e.min, `${t}.min`),
			max: U(e.max, `${t}.max`),
			samples: U(e.samples, `${t}.samples`),
			curves: G(e.curves, `${t}.curves`, 16),
			points: G(e.points, `${t}.points`, l)
		});
		case "chart-table": return r([
			"chartKind",
			"x",
			"y"
		]), Object.freeze({
			kind: n,
			chartKind: U(e.chartKind, `${t}.chartKind`),
			x: U(e.x, `${t}.x`),
			y: U(e.y, `${t}.y`)
		});
		case "timeline-table": {
			r(["headerSets"]), Array.isArray(e.headerSets) || j(`${t}.headerSets`, "must be an array.");
			let i = e.headerSets.map((e, n) => tt(e, `${t}.headerSets[${n}]`));
			return Object.freeze({
				kind: n,
				headerSets: Object.freeze(i)
			});
		}
		case "table-selection": return r(["key", "bindings"]), Object.freeze({
			kind: n,
			key: U(e.key, `${t}.key`),
			bindings: K(e.bindings, `${t}.bindings`)
		});
		case "retain": return r(["value"]), Object.freeze({
			kind: n,
			value: F(e.value, `${t}.value`)
		});
		case "self-binding-read": return r(["mode", "attribute"]), e.mode !== "always" && e.mode !== "attribute" && j(`${t}.mode`, "must be \"always\" or \"attribute\"."), Object.freeze({
			kind: n,
			mode: e.mode,
			...e.attribute === void 0 ? {} : { attribute: U(e.attribute, `${t}.attribute`) }
		});
		case "value-date": return r([
			"min",
			"max",
			"required"
		]), Object.freeze({
			kind: n,
			...i([
				"min",
				"max",
				"required"
			])
		});
		case "value-length": return r([
			"min",
			"max",
			"email",
			"emailType"
		]), Object.freeze({
			kind: n,
			...i([
				"min",
				"max",
				"email"
			]),
			...e.emailType === void 0 ? {} : { emailType: I(e.emailType, `${t}.emailType`, 128) }
		});
		case "value-required": return r(["required"]), Object.freeze({
			kind: n,
			required: U(e.required, `${t}.required`)
		});
		case "value-email": return r(["type", "value"]), Object.freeze({
			kind: n,
			...i(["type"]),
			...e.value === void 0 ? {} : { value: I(e.value, `${t}.value`, 128) }
		});
		default: j(`${t}.kind`, "is not a supported rule.");
	}
}
function rt(e) {
	Array.isArray(e) || j("rules", "must be an array."), e.length > 32 && j("rules", "accepts at most 32 rules.");
	let t = [];
	for (let n = 0; n < e.length; n += 1) t.push(nt(e[n], `rules[${n}]`));
	return Object.freeze(t);
}
function it(e) {
	Array.isArray(e) || j("slotRelations", "must be an array."), e.length > 16 && j("slotRelations", "accepts at most 16 relations.");
	let t = [];
	for (let n = 0; n < e.length; n += 1) {
		let r = e[n], i = `slotRelations[${n}]`;
		N(r) || j(i, "must be an object."), P(r, /* @__PURE__ */ new Set(["lower", "upper"]), i), t.push(Object.freeze({
			lower: R(r.lower, `${i}.lower`),
			upper: R(r.upper, `${i}.upper`)
		}));
	}
	return Object.freeze(t);
}
function at(e, t) {
	N(e) || j(t, "must be an object."), P(e, ze, t);
	let n = (n) => e[n] !== void 0 && F(e[n], `${t}.${n}`);
	return {
		interactive: n("interactive"),
		static: n("static"),
		ssr: n("ssr"),
		offline: n("offline")
	};
}
function ot(e, t) {
	N(e) || j(t, "must be an object."), P(e, Ie, t);
	let n = e.kind;
	typeof n == "string" && Ee.has(n) || j(`${t}.kind`, "must be \"string\", \"number\", \"boolean\" or \"enum\".");
	let r = n, i = { kind: r };
	for (let n of [
		"required",
		"static",
		"dynamic",
		"integer",
		"positive",
		"color",
		"nullable"
	]) e[n] !== void 0 && (i[n] = F(e[n], `${t}.${n}`));
	i.static === !0 && i.dynamic === !0 && j(t, "cannot be both static and dynamic."), e.coerce !== void 0 && (e.coerce !== "text" && j(`${t}.coerce`, "must be \"text\"."), r !== "string" && j(`${t}.coerce`, "is only valid for kind \"string\"."), i.coerce = "text");
	let a = e.enum === void 0 ? e.values : e.enum, o = a !== void 0;
	if (r !== "enum") o && j(t, `"enum" is only valid for kind "enum", not "${r}".`);
	else {
		e.enum !== void 0 && e.values !== void 0 && j(t, "use \"enum\" or \"values\", not both."), Array.isArray(a) && a.length !== 0 || j(`${t}.enum`, "must be a non-empty string array."), a.length > 64 && j(`${t}.enum`, "accepts at most 64 values.");
		let n = /* @__PURE__ */ new Set(), r = [];
		for (let e of a) {
			let i = I(e, `${t}.enum`, 128);
			n.has(i) && j(`${t}.enum`, `value "${i}" is declared more than once.`), n.add(i), r.push(i);
		}
		i.enum = r;
	}
	let s = e.pattern !== void 0;
	if (r !== "string") s && j(t, `"pattern" is only valid for kind "string", not "${r}".`);
	else if (s) {
		typeof e.pattern != "string" && j(`${t}.pattern`, "must be a string."), e.pattern.length > 512 && j(`${t}.pattern`, "exceeds the 512-character limit.");
		try {
			new RegExp(e.pattern);
		} catch {
			j(`${t}.pattern`, "is not a valid regular expression.");
		}
		y(e.pattern) || j(`${t}.pattern`, "uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected."), i.pattern = e.pattern;
	}
	let c = e.min !== void 0, l = e.max !== void 0;
	if (r === "number" ? (c && (i.min = L(e.min, `${t}.min`)), l && (i.max = L(e.max, `${t}.max`)), i.min !== void 0 && i.max !== void 0 && i.min > i.max && j(t, "\"min\" cannot exceed \"max\".")) : ((c || l) && j(t, "\"min\" and \"max\" are only valid for kind \"number\"."), i.integer === !0 && j(t, "\"integer\" is only valid for kind \"number\"."), i.positive === !0 && j(t, "\"positive\" is only valid for kind \"number\".")), i.color === !0 && r !== "string" && j(t, "\"color\" is only valid for kind \"string\"."), e.description !== void 0 && (i.description = z(e.description, `${t}.description`)), e.default !== void 0) {
		let n = e.default;
		if (n === null) i.nullable !== !0 && j(`${t}.default`, "is null but the prop is not nullable."), i.default = null;
		else if (r === "string") i.default = I(n, `${t}.default`);
		else if (r === "number") {
			let e = L(n, `${t}.default`);
			i.integer === !0 && !Number.isInteger(e) && j(`${t}.default`, "must be an integer."), i.positive === !0 && !(e > 0) && j(`${t}.default`, "must be greater than zero."), i.min !== void 0 && e < i.min && j(`${t}.default`, `is below the minimum ${i.min}.`), i.max !== void 0 && e > i.max && j(`${t}.default`, `exceeds the maximum ${i.max}.`), i.default = e;
		} else if (r === "boolean") i.default = F(n, `${t}.default`);
		else {
			let e = I(n, `${t}.default`, 128);
			i.enum?.includes(e) || j(`${t}.default`, `"${e}" is not an allowed enum value.`), i.default = e;
		}
		if (i.pattern !== void 0 && r === "string" && typeof i.default == "string") {
			let e = !0;
			try {
				e = new RegExp(i.pattern).test(i.default);
			} catch {
				e = !1;
			}
			e || j(`${t}.default`, `does not match pattern ${i.pattern}.`);
		}
	}
	return i;
}
function q(e, t) {
	N(e) || j(t, "must be an object with \"literal\" or \"prop\".");
	let n = Object.keys(e);
	n.length !== 1 && j(t, "must contain exactly one of \"literal\" or \"prop\".");
	let r = n[0];
	if (O.has(r) && j(t, `field "${r}" is not allowed.`), r === "literal") return { literal: L(e.literal, `${t}.literal`) };
	if (r === "prop") return { prop: R(e.prop, `${t}.prop`) };
	j(t, `unknown field "${r}"; use "literal" or "prop".`);
}
function st(e, t, n, r) {
	N(e) || j(r, "must be an object."), P(e, Re, r);
	let i = {};
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (e[n] === void 0) continue;
		let a = q(e[n], `${r}.${n}`);
		if ("prop" in a) {
			let e = t[a.prop];
			e === void 0 && j(`${r}.${n}`, `references undeclared prop "${a.prop}".`), e.kind !== "number" && j(`${r}.${n}`, `references prop "${a.prop}", which is not a number.`);
		}
		n === "step" && "literal" in a && !(a.literal > 0) && j(`${r}.step`, "must be greater than 0."), i[n] = a;
	}
	return n !== "number" && (i.min || i.max || i.step) && j(r, "\"min\", \"max\" and \"step\" are only valid for number bindings."), i.min && "literal" in i.min && i.max && "literal" in i.max && i.min.literal > i.max.literal && j(r, "\"min\" cannot exceed \"max\"."), i;
}
function ct(e, t) {
	if (e === "number") return t === "timer" ? /* @__PURE__ */ new Set([
		"duration",
		"min",
		"nearest-zero"
	]) : /* @__PURE__ */ new Set([
		"min",
		"nearest-zero",
		"max-step"
	]);
	if (e === "boolean") return /* @__PURE__ */ new Set(["false"]);
	if (e === "null") return /* @__PURE__ */ new Set(["empty"]);
	if (e === "array") return t === "checklist" ? /* @__PURE__ */ new Set(["checked", "empty-array"]) : /* @__PURE__ */ new Set(["empty-array"]);
	if (e === "number-array") return /* @__PURE__ */ new Set(["empty-array"]);
	switch (t) {
		case "choice":
		case "selection": return /* @__PURE__ */ new Set(["first-option", "none"]);
		case "tabs": return /* @__PURE__ */ new Set(["first-tab"]);
		case "steps": return /* @__PURE__ */ new Set(["first-step"]);
		case "diagram": return /* @__PURE__ */ new Set(["first-node"]);
		case "date": return /* @__PURE__ */ new Set(["empty"]);
		default: return /* @__PURE__ */ new Set(["empty"]);
	}
}
function lt(e, t, n, r = !1) {
	N(e) || j(n, "must be an object."), P(e, Le, n);
	let i = e.kind;
	typeof i == "string" && Oe.has(i) || j(`${n}.kind`, "must be \"string\", \"number\", \"boolean\", \"array\", \"number-array\" or \"null\".");
	let a = i, o = e.family;
	typeof o == "string" && ke.has(o) || j(`${n}.family`, "must be a supported binding family.");
	let s = o;
	({
		number: /* @__PURE__ */ new Set(["number", "timer"]),
		boolean: /* @__PURE__ */ new Set(["boolean"]),
		string: /* @__PURE__ */ new Set([
			"text",
			"choice",
			"date",
			"tabs",
			"diagram",
			"steps",
			"selection"
		]),
		array: /* @__PURE__ */ new Set([
			"multi-select",
			"checklist",
			"collection"
		]),
		"number-array": /* @__PURE__ */ new Set(["collection"]),
		null: /* @__PURE__ */ new Set(["text"])
	})[a]?.has(s) || j(`${n}.family`, `"${s}" is not supported for a ${a} binding.`);
	let c;
	if (e.options !== void 0) {
		a !== "string" && j(`${n}.options`, "is only valid for a string binding."), s !== "choice" && j(`${n}.options`, "requires family \"choice\".");
		let t = e.options;
		Array.isArray(t) && t.length !== 0 || j(`${n}.options`, "must be a non-empty string array."), t.length > 64 && j(`${n}.options`, "accepts at most 64 values.");
		let r = /* @__PURE__ */ new Set(), i = [];
		for (let e of t) {
			let t = I(e, `${n}.options`, 128);
			t.length === 0 && j(`${n}.options`, "values must be non-empty."), r.has(t) && j(`${n}.options`, `value "${t}" is declared more than once.`), r.add(t), i.push(t);
		}
		c = Object.freeze(i);
	}
	a === "string" && s === "choice" && c === void 0 && !r && j(`${n}.options`, "is required for a choice binding."), s !== "choice" && c !== void 0 && j(`${n}.options`, "is only valid for family \"choice\".");
	let l = R(e.bind, `${n}.bind`), u = R(e.initial, `${n}.initial`);
	l === u && j(n, "\"bind\" and \"initial\" must name different attributes."), (A.has(l) || A.has(u)) && j(n, "binding attributes cannot use a reserved slot name."), (Object.hasOwn(t, l) || Object.hasOwn(t, u)) && j(n, "binding attributes are reserved and cannot be declared as props.");
	let d = ct(a, s), f;
	if (e.initialRule === void 0) switch (a) {
		case "number":
			f = s === "timer" ? "duration" : "nearest-zero";
			break;
		case "boolean":
			f = "false";
			break;
		case "array":
			f = s === "checklist" ? "checked" : "empty-array";
			break;
		case "number-array":
			f = "empty-array";
			break;
		case "null":
			f = "empty";
			break;
		default: f = s === "choice" ? "first-option" : s === "tabs" ? "first-tab" : s === "steps" ? "first-step" : s === "diagram" ? "first-node" : s === "selection" ? "none" : "empty";
	}
	else typeof e.initialRule == "string" && Ae.has(e.initialRule) || j(`${n}.initialRule`, "is not a supported initial rule."), f = e.initialRule;
	d.has(f) || j(`${n}.initialRule`, `is not supported for a ${a} ${s} binding.`), e.required !== void 0 && F(e.required, `${n}.required`), e.exclusive !== void 0 && F(e.exclusive, `${n}.exclusive`), e.retain !== void 0 && F(e.retain, `${n}.retain`);
	let p;
	e.constraints !== void 0 && (p = st(e.constraints, t, a, `${n}.constraints`));
	let m;
	if (e.maxItems !== void 0) {
		if (a !== "array" && a !== "number-array" && j(`${n}.maxItems`, "is only valid for array or number-array bindings."), m = q(e.maxItems, `${n}.maxItems`), "prop" in m) {
			let e = t[m.prop];
			e === void 0 && j(`${n}.maxItems`, `references undeclared prop "${m.prop}".`), e.kind !== "number" && j(`${n}.maxItems`, `references prop "${m.prop}", which is not a number.`), e.dynamic === !0 && j(`${n}.maxItems`, "requires a static numeric property.");
		} else (!Number.isInteger(m.literal) || m.literal < 0) && j(`${n}.maxItems`, "must be a nonnegative integer.");
	}
	let h;
	if (e.requiresAttributes !== void 0) {
		h = V(e.requiresAttributes, `${n}.requiresAttributes`);
		for (let e of h) Object.hasOwn(t, e) || j(`${n}.requiresAttributes`, `references undeclared prop "${e}".`);
	}
	let g;
	if (e.compare !== void 0) {
		g = V(e.compare, `${n}.compare`);
		for (let e of g) Object.hasOwn(t, e) || j(`${n}.compare`, `references undeclared prop "${e}".`);
	}
	return Object.freeze({
		kind: a,
		family: s,
		bind: l,
		initial: u,
		initialRule: f,
		...e.required === !0 ? { required: !0 } : {},
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...c ? { options: c } : {},
		...p ? { constraints: Object.freeze(p) } : {},
		...m ? { maxItems: m } : {},
		...h ? { requiresAttributes: h } : {},
		...g ? { compare: g } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	});
}
function ut(e, t) {
	N(e) || j(t, "must be an object."), P(e, Ue, t);
	let n = e.id;
	(typeof n != "string" || !D.test(n) || n.length > 160) && j(`${t}.id`, "must be a lowercase namespaced id.");
	let r;
	if (e.version !== void 0) {
		let n = e.version, i = C(n);
		i === null && j(`${t}.version`, "must be an exact version or a supported range (exact, ^, ~, >=, <=, >, <)."), r = i.source;
	}
	return {
		id: n,
		...r ? { version: r } : {}
	};
}
function dt(e) {
	N(e) || j("requires", "must be an object."), P(e, We, "requires");
	let t;
	if (e.kernel !== void 0) {
		let n = C(e.kernel);
		n === null && j("requires.kernel", "must be a supported kernel version range (exact, ^, ~, >=, <=, >, <)."), t = n.source;
	}
	return { ...t ? { kernel: t } : {} };
}
function ft(e) {
	Array.isArray(e) || j("styles", "must be an array of style-resource ids."), e.length > 32 && j("styles", "accepts at most 32 resources.");
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r];
		(typeof i != "string" || i.length === 0 || i.length > 256) && j(`styles[${r}]`, "must be a non-empty string of at most 256 characters."), Ge.test(i) || j(`styles[${r}]`, "must be a bounded resource id."), t.has(i) && j("styles", `resource "${i}" is declared more than once.`), t.add(i), n.push(i);
	}
	return Object.freeze(n);
}
function J(e) {
	N(e) || j("manifest", "must be an object."), P(e, Fe, "manifest");
	let t = e.id;
	(typeof t != "string" || t.length > 160 || !D.test(t)) && j("id", "must be a lowercase namespaced id such as \"example/rating\".");
	let n = R(e.name, "name"), r = e.version;
	(typeof r != "string" || r.length > 64 || !we.test(r)) && j("version", "must be a semantic version such as 1.0.0."), e.protocol !== "reactive-md-component/v1" && j("protocol", `must be "${b}".`);
	let i = e.form;
	typeof i == "string" && De.has(i) || j("form", "must be \"leaf\", \"inline\" or \"container\".");
	let a = i;
	N(e.props) || j("props", "must be an object.");
	let o = Object.keys(e.props).sort();
	o.length > 64 && j("props", "accepts at most 64 properties.");
	let s = {};
	for (let t of o) O.has(t) && j("props", `property "${t}" is not allowed.`), (!E.test(t) || t.length > 128) && j("props", `property "${t}" must use lowercase kebab-case.`), s[t] = ot(e.props[t], `props.${t}`);
	let c;
	if (e.bindings !== void 0) {
		N(e.bindings) || j("bindings", "must be an object.");
		let t = Object.keys(e.bindings);
		t.length === 0 && j("bindings", "must declare at least one binding slot."), t.length > 16 && j("bindings", "accepts at most 16 slots.");
		let n = {}, r = /* @__PURE__ */ new Set();
		for (let i of t) {
			O.has(i) && j("bindings", `field "${i}" is not allowed.`), Ke.test(i) || j("bindings", `slot "${i}" must be a letter followed by letters or digits.`), A.has(i) && j("bindings", `slot "${i}" is reserved by the runtime.`);
			let t = lt(e.bindings[i], s, `bindings.${i}`, a === "container" && Array.isArray(e.rules) && e.rules.some((e) => N(e) && e.kind === "options-body"));
			i !== "value" && (t.kind !== "number" || t.family !== "number") && j(`bindings.${i}`, "numeric named slots support kind \"number\" with family \"number\" in this contract."), i !== "value" && N(e.bindings[i]) && e.bindings[i].exclusive === !1 && j(`bindings.${i}.exclusive`, "named slots require exclusive ownership in this contract.");
			for (let e of [t.bind, t.initial]) r.has(e) && j("bindings", `attribute "${e}" is claimed by more than one binding.`), r.add(e);
			n[i] = i === "value" ? t : Object.freeze({
				...t,
				exclusive: !0
			});
		}
		c = Object.freeze(n);
	}
	let l = e.children === void 0 ? void 0 : $e(e.children, a, "children");
	e.children !== void 0 && e.structure !== void 0 && j("manifest", "cannot declare both \"children\" and \"structure\"; use \"structure\".");
	let u = e.structure === void 0 ? B(l) : et(e.structure, a, "structure"), d = e.rules === void 0 ? void 0 : rt(e.rules), f = e.slotRelations === void 0 ? void 0 : it(e.slotRelations);
	e.legacyHost !== void 0 && F(e.legacyHost, "legacyHost");
	let p = at(e.capabilities, "capabilities"), m = e.authoring === void 0 ? void 0 : Qe(e.authoring, "authoring"), h = e.styles === void 0 ? void 0 : ft(e.styles), g = e.requires === void 0 ? void 0 : dt(e.requires), _;
	if (e.dependencies !== void 0) {
		Array.isArray(e.dependencies) || j("dependencies", "must be an array."), e.dependencies.length > 16 && j("dependencies", "accepts at most 16 entries.");
		let t = /* @__PURE__ */ new Set(), n = [];
		for (let r = 0; r < e.dependencies.length; r += 1) {
			let i = ut(e.dependencies[r], `dependencies[${r}]`);
			t.has(i.id) && j("dependencies", `"${i.id}" is declared more than once.`), t.add(i.id), n.push(Object.freeze(i));
		}
		_ = Object.freeze(n);
	}
	let v = {
		id: t,
		name: n,
		version: r,
		protocol: b,
		form: a,
		props: Object.freeze(s),
		...c ? { bindings: c } : {},
		...l ? { children: Object.freeze(l) } : {},
		...u && !l ? { structure: u } : {},
		...d ? { rules: d } : {},
		...f ? { slotRelations: f } : {},
		...e.legacyHost === !0 ? { legacyHost: !0 } : {},
		capabilities: Object.freeze(p),
		...m ? { authoring: Object.freeze(m) } : {},
		...h ? { styles: h } : {},
		...g ? { requires: Object.freeze(g) } : {},
		..._ ? { dependencies: _ } : {}
	};
	M(v) > 65536 && j("manifest", `serialized size exceeds the ${T}-byte budget.`);
	let y = Y(v);
	return k.add(y), y;
}
function pt(e) {
	return J(e);
}
function Y(e) {
	if (typeof e != "object" || !e) return e;
	for (let t of Object.keys(e)) Y(e[t]);
	return Object.freeze(e);
}
function mt(e) {
	return {
		kind: e.kind,
		...e.required === !0 ? { required: !0 } : {},
		...e.static === !0 ? { static: !0 } : {},
		...e.dynamic === void 0 ? {} : { dynamic: e.dynamic },
		...e.default === void 0 ? {} : { default: e.default },
		...e.nullable === !0 ? { nullable: !0 } : {},
		...e.enum ? { enum: [...e.enum] } : {},
		...e.pattern === void 0 ? {} : { pattern: e.pattern },
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.integer === !0 ? { integer: !0 } : {},
		...e.positive === !0 ? { positive: !0 } : {},
		...e.color === !0 ? { color: !0 } : {},
		...e.coerce === void 0 ? {} : { coerce: e.coerce }
	};
}
function X(e) {
	return "literal" in e ? { literal: e.literal } : { prop: e.prop };
}
function ht(e) {
	return {
		...e.min ? { min: X(e.min) } : {},
		...e.max ? { max: X(e.max) } : {},
		...e.step ? { step: X(e.step) } : {}
	};
}
function gt(e) {
	let t = e.constraints;
	return {
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule,
		...e.required === !0 ? { required: !0 } : {},
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...e.options ? { options: [...e.options] } : {},
		...t ? { constraints: ht(t) } : {},
		...e.maxItems ? { maxItems: X(e.maxItems) } : {},
		...e.requiresAttributes ? { requiresAttributes: [...e.requiresAttributes] } : {},
		...e.compare ? { compare: [...e.compare] } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function _t(e) {
	return {
		rule: e.rule,
		...e.label === void 0 ? {} : { label: e.label },
		...e.parents ? { parents: [...e.parents] } : {},
		...e.child === void 0 ? {} : { child: e.child },
		...e.children ? { children: [...e.children] } : {},
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.inlineOnly === void 0 ? {} : { inlineOnly: e.inlineOnly },
		...e.noComponents === void 0 ? {} : { noComponents: e.noComponents },
		...e.valueAttribute === void 0 ? {} : { valueAttribute: e.valueAttribute },
		...e.generatedPrefix === void 0 ? {} : { generatedPrefix: e.generatedPrefix },
		...e.forbidSeparator === void 0 ? {} : { forbidSeparator: e.forbidSeparator },
		...e.maxItems === void 0 ? {} : { maxItems: e.maxItems }
	};
}
function vt(e) {
	let t = e, n = Object.keys(t).sort(), r = {};
	for (let e of n) {
		let n = t[e];
		r[e] = Array.isArray(n) ? n.map((e) => Array.isArray(e) ? [...e] : e) : n;
	}
	return r;
}
function Z(e) {
	let t = {};
	for (let n of Object.keys(e.props).sort()) t[n] = mt(e.props[n]);
	let n = {};
	if (e.bindings) for (let t of Object.keys(e.bindings).sort()) n[t] = gt(e.bindings[t]);
	return {
		protocol: e.protocol,
		id: e.id,
		name: e.name,
		version: e.version,
		form: e.form,
		props: t,
		...e.bindings ? { bindings: n } : {},
		...e.children ? { children: {
			kind: e.children.kind,
			...e.children.required ? { required: !0 } : {}
		} } : {},
		...e.structure ? { structure: _t(e.structure) } : {},
		...e.rules ? { rules: e.rules.map(vt) } : {},
		...e.slotRelations ? { slotRelations: e.slotRelations.map((e) => ({ ...e })) } : {},
		capabilities: {
			interactive: e.capabilities.interactive,
			static: e.capabilities.static,
			ssr: e.capabilities.ssr,
			offline: e.capabilities.offline
		},
		...e.styles ? { styles: [...e.styles] } : {},
		...e.requires?.kernel ? { requires: { kernel: e.requires.kernel } } : {},
		...e.dependencies ? { dependencies: [...e.dependencies].map((e) => ({ ...e })).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)) } : {}
	};
}
var Q = /* @__PURE__ */ new WeakMap();
function $(e) {
	let t = k.has(e) ? e : J(e), n = Q.get(t);
	if (n !== void 0) return n;
	let r = _(JSON.stringify(Z(t)));
	return Q.set(t, r), r;
}
function yt(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: $(e)
	});
}
function bt(e) {
	return typeof e == "string" && e.length <= 128 && E.test(e);
}
export { o as $, ie as A, n as B, M as C, te as D, b as E, C as F, p as G, a as H, y as I, e as J, d as K, _ as L, de as M, pe as N, ne as O, fe as P, i as Q, f as R, yt as S, J as T, h as U, t as V, m as W, l as X, c as Y, u as Z, ve as _, ye as a, bt as b, ge as c, Je as d, g as et, Ye as f, Ce as g, Se as h, xe as i, re as j, ee as k, be as l, Xe as m, qe as n, _e as o, w as p, s as q, me as r, T as s, Ze as t, he as u, Z as v, B as w, $ as x, pt as y, r as z };
