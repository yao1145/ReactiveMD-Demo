import { x as e } from "./manifest-gj41AWZb.js";
import { f as t, n, u as r } from "./registry-B9eKQgGq.js";
import { _ as i, c as a, i as o, l as s, o as c, r as l, s as u, u as d } from "./shareable-BfmyUQFr.js";
import { i as f, n as p, r as m, t as h } from "./resources-BSaYBwu7.js";
// src/export/index.ts
function g(t, n) {
	let i = r(n);
	if (typeof t != "string" || !t.trim() || t.length > 33554432) throw TypeError("A standalone bundle must contain a nonempty script of at most 32 MiB.");
	return Object.freeze({
		script: t,
		seal: c(t, i),
		extensions: Object.freeze({
			protocol: "reactive-md-extensions/v1",
			components: Object.freeze(i.components.map((t) => Object.freeze({
				id: t.id,
				name: t.name,
				version: t.version,
				digest: e(t)
			})))
		})
	});
}
function _(e) {
	let i = r(e.config), o = e.document.extensions ?? {
		protocol: "reactive-md-extensions/v1",
		components: []
	}, c = f(o, i);
	c.push(...t(e.document, i)), c.push(...m({
		document: e.document,
		installed: n(i),
		externalNames: new Set(i.components.map((e) => e.name))
	}));
	let l = new Set(e.requiredResources ?? []), u = e.target;
	if (![
		"static",
		"ssr",
		"offline"
	].includes(u)) throw TypeError("Unknown export target.");
	for (let e of o.components) {
		let t = i.components.find((t) => t.id === e.id);
		if (!t) continue;
		for (let e of t.styles ?? []) l.add(e);
		let n = u === "offline" ? [
			"static",
			"interactive",
			"offline"
		] : [u];
		for (let e of n) t.capabilities[e] || c.push(p("local.extension.export-capability", `${t.id}@${t.version} does not support ${e} for ${u} export.`));
	}
	if (u === "offline") {
		if (!e.bundle?.script?.trim()) c.push(p("local.extension.bundle-missing", "Offline output requires an explicitly built standalone bundle."));
		else {
			c.push(...f(e.bundle.extensions, i));
			let t = e.bundle.seal;
			t && (t.protocol !== "reactive-md-bundle/v1" || t.sdkVersion !== "0.7.0" || t.configKey !== i.key || t.scriptDigest !== a(e.bundle.script)) && c.push(p("local.extension.bundle-integrity", "The bundle script or installed configuration differs from its sealed build manifest."));
			for (let t of o.components) e.bundle.extensions.components.some((e) => e.id === t.id && e.digest === t.digest) || c.push(p("local.extension.bundle-mismatch", `The standalone bundle does not include ${t.id}@${t.version}.`));
		}
	}
	let d = e.document.theme ?? "default", g = i.themes.find((e) => e.name === d);
	if (u === "offline" && g && e.bundle?.seal) {
		let t = e.bundle.seal.themes;
		Array.isArray(t) && t.some((e) => e.id === g.id && e.name === g.name && e.version === g.version && e.digest === s(g)) || c.push(p("local.extension.bundle-theme", `Bundle theme ${g.id}@${g.version} differs from the selected export theme. Rebuild the bundle.`));
	}
	d !== "default" && !g && c.push(p("local.extension.theme-missing", `Theme ${d} is not installed for export.`));
	let _ = h([...e.resources ?? [], ...g?.css ?? []]);
	c.push(..._.diagnostics);
	let v = new Map(_.resources.map((e) => [e.id, e]));
	for (let e of l) v.has(e) || c.push(p("local.extension.resource-missing", `Required style resource ${e} is missing.`));
	let y = Object.freeze([...v.values()]);
	return Object.freeze({
		target: u,
		extensions: o,
		resources: y,
		css: y.map((e) => e.css).join("\n"),
		diagnostics: Object.freeze(c),
		ok: c.length === 0
	});
}
function v(e) {
	if (e.document.source !== e.source) throw TypeError("The compiled document does not belong to this source.");
	let t = i(e.state);
	if (!t.ok) throw TypeError(t.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let n = o(e.document, t.file);
	if (!n.ok) throw TypeError(n.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let a = r(e.config);
	if (e.compileOptions?.hostComponents !== void 0 || e.compileOptions?.config && r(e.compileOptions.config).key !== a.key) throw TypeError("Conflicting export component configuration.");
	let s = _({
		...e,
		target: e.mode === "static" ? "static" : "offline"
	});
	if (!s.ok) throw TypeError(s.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	if (/data-rmd-extension-error\s*=|local-sdk-unavailable/.test(e.staticMarkup)) throw TypeError("Static output contains an unavailable extension component.");
	return l({
		...e,
		compileOptions: {
			...e.compileOptions,
			config: a
		},
		extensions: s.extensions,
		restoration: u(e.document, a, s.target, s.resources),
		resources: s.resources,
		runtimeScript: e.bundle?.script,
		css: `${e.css}\n${s.css}`
	});
}
export { c as createLocalBundleManifest, _ as createLocalExportPlan, u as createLocalRestorationRequirements, v as createLocalShareableHtml, g as defineLocalStandaloneBundle, a as localExportContentDigest, s as localThemeContractDigest, h as readLocalExportResources, m as validateLocalComponentContracts, f as validateLocalExtensionRequirements, d as validateLocalRestorationRequirements };
