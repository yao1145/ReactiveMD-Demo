import type { ReactNode } from 'react';
import type { LocalComponentContext } from '../react/component-api.js';
import { type LocalValue, type Localize } from '../react/component-utils.js';
/**
 * `<data-table>` renders generated rows from a list expression. Everything in
 * this module is deterministic and renderer-only: rows come from the runtime,
 * the row scope exposes `item`/`index`, and keys are validated before any row
 * markup is allocated.
 */
export type DataTableFailure = 'label' | 'columns' | 'max-rows' | 'rows' | 'rows-budget' | 'key' | 'text-budget';
export interface DataTableCell {
    ok: boolean;
    text: string;
}
export interface DataTableRow {
    key: string;
    cells: DataTableCell[];
}
export interface DataTableColumnSpec {
    label: string;
    value: string;
}
export interface DataTableModel {
    columns: string[];
    rows: DataTableRow[];
    empty: boolean;
}
export type DataTableBuildResult = {
    ok: true;
    model: DataTableModel;
} | {
    ok: false;
    failure: DataTableFailure;
};
export interface DataTableBuildOptions {
    readonly rows: readonly LocalValue[];
    readonly columns: readonly DataTableColumnSpec[];
    readonly keyExpression: string;
    readonly runtime: {
        evaluate(expression: string): LocalValue;
    };
    readonly maxRows?: number;
    readonly budget?: number;
}
export declare function encodeDataTableKey(value: LocalValue): string | null;
export declare function evaluateDataTableRows(runtime: {
    evaluate(expression: string): LocalValue;
}, expression: string): LocalValue[];
export declare function buildDataTableModel(options: DataTableBuildOptions): DataTableBuildResult;
export declare function dataTableFailureMessage(t: Localize, failure: DataTableFailure): string;
export declare function DataTableView(context: LocalComponentContext): ReactNode;
