import type { LocalComponentRender, LocalReactPreset } from '../react/component-api.js';
/** Public implementation table for the builtin preset, keyed by tag name. */
export declare const DEFAULT_COMPONENT_VIEWS: Readonly<Record<string, LocalComponentRender>>;
/**
 * Assemble the builtin React preset from the same public manifests the kernel
 * uses. Every builtin is bound with `defineReactComponent`; there is no
 * separate dispatch table or private default callback.
 */
export declare function createDefaultReactPreset(): LocalReactPreset;
export declare const defaultReactPreset: LocalReactPreset;
