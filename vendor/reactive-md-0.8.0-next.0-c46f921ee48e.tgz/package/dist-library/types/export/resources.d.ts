import type { Diagnostic } from '../local/contracts/types.js';
import type { LocalStyleResource } from '../sdk/theme.js';
/** Literal inline CSS; build adapters resolve local files before this boundary. */
export declare function isInlineExportCss(css: string): boolean;
export declare function readLocalExportResources(value: unknown): {
    resources: readonly LocalStyleResource[];
    diagnostics: Diagnostic[];
};
