import type { Diagnostic, LocalDocument } from '../local/contracts/types.js';
import { localHash } from '../sdk/hash.js';
import type { LocalConfig, LocalComponentRequirement } from '../sdk/types.js';
import type { LocalStyleResource, LocalThemePackage } from '../sdk/theme.js';
export interface LocalResourceRequirement {
    readonly id: string;
    readonly digest: string;
}
export interface LocalVersionedComponentRequirement extends LocalComponentRequirement {
    readonly range: string;
}
export interface LocalThemeRequirement {
    readonly id: string;
    readonly name: string;
    readonly version: string;
    readonly digest: string;
}
export interface LocalRestorationRequirements {
    readonly protocol: 'reactive-md-restore/v1';
    readonly sdk: string;
    readonly configKey: string;
    readonly sourceDigest: string;
    readonly target: 'static' | 'ssr' | 'offline';
    readonly components: readonly LocalVersionedComponentRequirement[];
    readonly themes: readonly LocalThemeRequirement[];
    readonly resources: readonly LocalResourceRequirement[];
}
export interface LocalStandaloneBundleManifest {
    readonly protocol: 'reactive-md-bundle/v1';
    readonly sdkVersion: string;
    readonly configKey: string;
    readonly scriptDigest: string;
    readonly themes: readonly LocalThemeRequirement[];
}
/** Content identities detect mismatches; they are not a code sandbox or signature. */
export declare const localExportContentDigest: typeof localHash;
export declare function localThemeContractDigest(theme: LocalThemePackage): string;
export declare function createLocalBundleManifest(script: string, config: LocalConfig): LocalStandaloneBundleManifest;
export declare function createLocalRestorationRequirements(document: LocalDocument, config: LocalConfig, target: LocalRestorationRequirements['target'], resources?: readonly LocalStyleResource[]): LocalRestorationRequirements;
export declare function validateLocalRestorationRequirements(value: unknown, options: {
    readonly config?: LocalConfig;
    readonly source: string;
    readonly resources?: readonly LocalStyleResource[];
    readonly document?: LocalDocument;
}): Diagnostic[];
