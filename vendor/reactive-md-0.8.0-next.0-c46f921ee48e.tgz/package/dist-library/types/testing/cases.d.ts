import type { LocalComplianceCapability, LocalComplianceCaseResult, LocalComplianceDiagnostic, LocalComplianceStatus, LocalComplianceSuite, LocalComplianceValue } from './types.js';
export interface LocalCaseInput {
    readonly id: string;
    readonly suite: LocalComplianceSuite;
    readonly status: LocalComplianceStatus;
    readonly message?: string;
    readonly diagnostics?: readonly LocalComplianceDiagnostic[];
    readonly capabilities?: readonly LocalComplianceCapability[];
    readonly observed?: Readonly<Record<string, LocalComplianceValue>>;
}
/** Build one bounded, frozen case result. */
export declare function localCase(input: LocalCaseInput): LocalComplianceCaseResult;
export declare function passed(id: string, suite: LocalComplianceSuite, options?: Omit<LocalCaseInput, 'id' | 'suite' | 'status'>): LocalComplianceCaseResult;
export declare function failed(id: string, suite: LocalComplianceSuite, message: string, diagnostics?: readonly LocalComplianceDiagnostic[]): LocalComplianceCaseResult;
export declare function skipped(id: string, suite: LocalComplianceSuite, message: string, capabilities?: readonly LocalComplianceCapability[]): LocalComplianceCaseResult;
export declare function unsupported(id: string, suite: LocalComplianceSuite, message: string, capabilities?: readonly LocalComplianceCapability[]): LocalComplianceCaseResult;
