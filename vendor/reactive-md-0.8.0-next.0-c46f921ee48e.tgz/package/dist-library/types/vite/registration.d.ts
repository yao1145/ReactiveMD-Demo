import type { LocalBuildAsset, LocalStandaloneBuild } from '../build/index.js';
import type { LocalReactPackage } from '../react/package.js';
import type { LocalThemePackage } from '../sdk/theme.js';
import type { DirectoryDiscovery } from './discovery.js';
/**
 * Browser-safe registration helpers for directory mode.
 *
 * The Vite adapter turns one discovery snapshot into one generated module.
 * That module is the only registration source for the page, the Worker
 * configuration, SSR and the embedded offline build. Everything here must stay
 * free of Node built-ins: the generated module is bundled for the browser.
 */
/** Plain discovery facts exposed for verification; never functions or config. */
export interface DiscoveryMetadata {
    readonly files: readonly string[];
    readonly directories: readonly string[];
    readonly themes: readonly {
        readonly file: string;
        readonly id: string;
        readonly name: string;
    }[];
    readonly plugins: readonly {
        readonly file: string;
        readonly resources: readonly string[];
    }[];
    readonly assets: readonly LocalBuildAsset[];
}
export interface DirectoryRegistrationSource {
    readonly code: string;
    /** Absolute dependency paths that development and build watchers need. */
    readonly files: readonly string[];
}
export interface ComponentOwner {
    readonly file: string;
    readonly id: string;
    readonly name: string;
}
export interface ThemeOwner {
    readonly file: string;
    readonly id: string;
    readonly name: string;
}
/**
 * Resolve the package exported by one `plugin/` entry module.
 *
 * A default export is preferred. Otherwise exactly one distinct named
 * `LocalReactPackage` is accepted; aliases that point at the same object are
 * deduplicated, and several distinct packages are an error instead of a silent
 * choice. Re-exporting an installed package's public entry works because this
 * reads the module namespace, not the entry source.
 */
export declare function readLocalReactPackage(namespace: unknown, file: string): LocalReactPackage;
/**
 * Reject duplicate component identities and theme identities across entries.
 *
 * The first owner wins the reporting order; a later duplicate names both source
 * entries so neither is silently overwritten.
 */
export declare function assertUniqueRegistration(components: readonly ComponentOwner[], themes: readonly ThemeOwner[]): void;
/** Serialize discovery facts without functions or derived config. */
export declare function discoveryMetadata(discovery: DirectoryDiscovery): DiscoveryMetadata;
/**
 * Generate the single registration module used by every consumer.
 *
 * Themes are plain data, so the snapshot is embedded directly. Plugin entry
 * modules are imported so their packages and implementations stay live under
 * the normal Vite dependency graph. The generated module exports mutable
 * bindings so a theme stylesheet refresh can replace the host without
 * rebuilding the document runtime; the SDK host itself stays frozen.
 */
export declare function createDirectoryRegistration(discovery: DirectoryDiscovery, styleId: string): DirectoryRegistrationSource;
/**
 * Merge scanner assets into the offline build result. Later entries never
 * replace a collector asset with the same path; the merged list drives both
 * `bundle.assets` and the manifest's `inlinedAssets`.
 */
export declare function mergeDiscoveredAssets(bundle: LocalStandaloneBuild, assets: readonly LocalBuildAsset[]): LocalStandaloneBuild;
/** Theme entries from one snapshot, for the development refresh payload. */
export declare function discoveredThemes(discovery: DirectoryDiscovery): readonly {
    readonly file: string;
    readonly theme: LocalThemePackage;
}[];
