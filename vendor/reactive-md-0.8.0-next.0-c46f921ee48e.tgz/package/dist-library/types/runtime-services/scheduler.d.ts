/**
 * Injected clock and scheduler.
 *
 * The core scheduler never touches `window` directly. Browser ports are
 * supplied by the default adapter below; tests and non-DOM hosts can inject
 * their own. Page visibility is handled here so components do not each
 * reimplement it.
 */
export type LocalSchedulerBackground = 'pause' | 'wall-clock';
export interface LocalSchedulerPorts {
    now(): number;
    setTimeout(run: () => void, ms: number): unknown;
    clearTimeout(handle: unknown): void;
    requestAnimationFrame?(run: (time: number) => void): unknown;
    cancelAnimationFrame?(handle: unknown): void;
    isHidden?(): boolean;
    subscribeVisibility?(listener: (hidden: boolean) => void): () => void;
}
export interface LocalSchedulerOptions {
    readonly ports?: Partial<LocalSchedulerPorts>;
    /** Reject runaway components. Defaults to 64 subscriptions per runtime. */
    readonly maxSubscriptions?: number;
    /** Clamp `every` intervals to avoid hot loops. Defaults to 16 ms. */
    readonly minIntervalMs?: number;
    readonly onError?: (error: unknown) => void;
}
export interface LocalTickerOptions {
    readonly background?: LocalSchedulerBackground;
}
export interface LocalClock {
    now(): number;
    activeNow(): number;
    readonly suspended: boolean;
}
export interface LocalScheduler extends LocalClock {
    readonly size: number;
    every(intervalMs: number, run: () => void, options?: LocalTickerOptions): () => void;
    after(delayMs: number, run: () => void, options?: LocalTickerOptions): () => void;
    frame(run: (deltaMs: number) => void): () => void;
    suspend(): void;
    resume(): void;
    dispose(): void;
}
export declare function createLocalScheduler(options?: LocalSchedulerOptions): LocalScheduler;
