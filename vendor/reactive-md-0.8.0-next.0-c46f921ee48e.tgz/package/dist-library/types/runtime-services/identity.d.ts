/**
 * Stable identities for document- and component-scoped runtime services.
 *
 * Node ids (`local-<serial>`) are only stable inside one compiled document.
 * They are deliberately never used as a persistent identity on their own.
 */
export interface LocalDocumentIdentityInput {
    /** Host-supplied stable identity. Falls back to the source digest. */
    readonly documentId?: string;
    /** Deterministic digest of the current source. */
    readonly sourceDigest: string;
}
export interface LocalComponentIdentityInput extends LocalDocumentIdentityInput {
    readonly nodeId: string;
    readonly stateKey?: string;
}
export interface LocalComponentSeedInput {
    /** Explicit component prop; wins over every host default. */
    readonly explicitSeed?: number;
    /** Host document seed. */
    readonly documentSeed: number;
    readonly componentId: string;
    readonly nodeId: string;
    readonly stateKey?: string;
}
/** FNV-1a over UTF-8 bytes. Integrity helper only, never a signature. */
export declare function fnv1a32(value: string): number;
/** The same digest format used by `reactive-md-state/v1`. */
export declare function localSourceDigest(source: string): string;
export declare function normalizeDocumentId(raw: unknown): string | undefined;
/**
 * Persistent component key. Explicit `state-key` values are portable across
 * source edits; without one only the current node identity is known.
 */
export declare function normalizeStateKey(raw: unknown): string | undefined;
export declare function resolveDocumentId(input: LocalDocumentIdentityInput): string;
export declare function componentStateKey(input: LocalComponentIdentityInput): string;
/** Derive an independent 32-bit seed. Pure: call order never matters. */
export declare function deriveSeed(seed: number, label: string): number;
export declare function resolveComponentSeed(input: LocalComponentSeedInput): number;
export declare function toUint32(value: number): number;
