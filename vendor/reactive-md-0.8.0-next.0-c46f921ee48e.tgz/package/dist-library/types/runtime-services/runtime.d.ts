/**
 * Document-level runtime services. The compiler never imports this module.
 */
import type { Diagnostic } from '../local/contracts/types.js';
import { type LocalComponentStateDocument, type LocalComponentStateRegistry } from './component-state.js';
import { type LocalClock, type LocalScheduler, type LocalSchedulerOptions } from './scheduler.js';
export interface LocalRuntimeServices {
    /** Stable identity used to scope component state. */
    readonly documentId: string;
    /** Digest of the exact source that created the runtime. */
    readonly sourceDigest: string;
    /** Host document seed; explicit component `seed` props still win. */
    readonly randomSeed: number;
    readonly clock: LocalClock;
    readonly scheduler: LocalScheduler;
    readonly state: LocalComponentStateRegistry;
}
export interface CreateLocalRuntimeServicesOptions {
    readonly documentId?: string;
    readonly sourceDigest: string;
    readonly randomSeed?: number;
    /** Restore a component-state sidecar before the first render. */
    readonly componentState?: unknown;
    /** Keys currently present in the document; unknown saved keys are skipped. */
    readonly knownStateKeys?: ReadonlySet<string> | (() => ReadonlySet<string>);
    /** Inject a scheduler, for example a fake clock in tests. */
    readonly scheduler?: LocalScheduler;
    readonly schedulerOptions?: LocalSchedulerOptions;
}
export declare function createLocalRuntimeServices(options: CreateLocalRuntimeServicesOptions): LocalRuntimeServices;
/**
 * Services for hand-built contexts that have no runtime-owned environment.
 * The scheduler is inert; saving state stays in memory.
 */
export declare function createDetachedRuntimeServices(options?: {
    documentId?: string;
    sourceDigest?: string;
    randomSeed?: number;
}): LocalRuntimeServices;
export type { Diagnostic, LocalComponentStateDocument };
