/**
 * Versioned, bounded component state and an in-memory state registry.
 *
 * This module defines the save protocol. It does not decide where bytes live:
 * the host can export a snapshot, pass it back to a new runtime, or persist it
 * through a browser backend. Multi-instance writing is deliberately explicit;
 * there is no cross-tab synchronization.
 */
import type { Diagnostic } from '../local/contracts/types.js';
import { type LocalRandomState } from './random.js';
export declare const LOCAL_COMPONENT_STATE_FORMAT: 'reactive-md-component-state/v1';
export declare const LOCAL_COMPONENT_STATE_DOCUMENT_FORMAT: 'reactive-md-component-state-document/v1';
export declare const MAX_COMPONENT_STATE_BYTES: number;
export declare const MAX_COMPONENT_STATE_TOTAL_BYTES: number;
export declare const MAX_COMPONENT_STATE_DEPTH = 16;
export declare const MAX_COMPONENT_STATE_ITEMS = 10000;
export declare const MAX_COMPONENT_STATE_STRING = 100000;
export declare const MAX_COMPONENT_STATE_DOCUMENT_INPUT: number;
export type LocalComponentStateData = null | boolean | number | string | readonly LocalComponentStateData[] | {
    readonly [key: string]: LocalComponentStateData;
};
export interface LocalComponentStateRecord {
    readonly format: typeof LOCAL_COMPONENT_STATE_FORMAT;
    readonly component: string;
    readonly componentVersion: string;
    readonly stateVersion: number;
    readonly key: string;
    readonly documentId?: string;
    readonly data: LocalComponentStateData;
    readonly random?: LocalRandomState;
}
export interface LocalComponentStateDocument {
    readonly format: typeof LOCAL_COMPONENT_STATE_DOCUMENT_FORMAT;
    readonly records: Readonly<Record<string, LocalComponentStateRecord>>;
}
export interface LocalComponentStateSaveResult {
    readonly ok: boolean;
    readonly diagnostics: Diagnostic[];
    readonly record?: LocalComponentStateRecord;
}
export interface LocalComponentStateRestoreResult {
    readonly accepted: readonly string[];
    readonly skipped: readonly string[];
    readonly diagnostics: Diagnostic[];
}
export interface LocalComponentStateHandleInput {
    readonly nodeId: string;
    readonly component: string;
    readonly componentVersion: string;
    readonly stateKey?: string;
    /** Default state version when `save` does not override it. */
    readonly stateVersion?: number;
}
export interface LocalComponentStateHandle {
    readonly key: string;
    readonly component: string;
    readonly componentVersion: string;
    readonly duplicate: boolean;
    load(): LocalComponentStateRecord | null;
    save(data: unknown, options?: {
        version?: number;
        random?: LocalRandomState;
    }): LocalComponentStateSaveResult;
    clear(): void;
}
export interface LocalComponentStateRegistry {
    readonly documentId: string;
    readonly sourceDigest: string;
    key(input: Omit<LocalComponentStateHandleInput, 'component' | 'componentVersion' | 'stateVersion'>): string;
    handle(input: LocalComponentStateHandleInput): LocalComponentStateHandle;
    load(key: string): LocalComponentStateRecord | null;
    clear(key: string): void;
    snapshot(): LocalComponentStateDocument;
    restore(input: unknown): LocalComponentStateRestoreResult;
    diagnostics(): readonly Diagnostic[];
    subscribe(listener: () => void): () => void;
}
export interface CreateLocalComponentStateRegistryOptions {
    readonly documentId?: string;
    readonly sourceDigest: string;
    /** Sidecar payload to restore before the first render. */
    readonly initial?: unknown;
    /**
     * Keys currently present in the document. A function is evaluated at each
     * restore so live document updates are reflected.
     */
    readonly knownKeys?: ReadonlySet<string> | (() => ReadonlySet<string>);
}
export declare function createLocalComponentStateRegistry(options: CreateLocalComponentStateRegistryOptions): LocalComponentStateRegistry;
