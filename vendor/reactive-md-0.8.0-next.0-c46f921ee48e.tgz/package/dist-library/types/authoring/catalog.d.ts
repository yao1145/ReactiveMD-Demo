import type { EditorLocale } from './command-types.js';
import type { LocalCompileOptions, LocalValue } from '../local/contracts/types.js';
import type { LocalComponentForm, LocalPropKind } from '../local/configuration/schema.js';
import type { LocalComponentRequires, LocalConfig } from '../sdk/types.js';
/**
 * Manifest-derived authoring catalog for the editor.
 *
 * Defaults and external components are projected from the same validated
 * registry. Default titles, descriptions, localized templates and search terms
 * come from the preset authoring data; external data comes from each manifest's
 * `authoring` block and prop descriptions. Nothing in this module imports
 * React, CSS or a browser API, so a worker or server can build the same menu.
 */
export interface LocalComponentCatalogProp {
    readonly name: string;
    readonly kind: LocalPropKind;
    readonly required: boolean;
    readonly static: boolean;
    readonly dynamic: boolean;
    readonly values?: readonly string[];
    readonly defaultValue?: string | number | boolean | null;
    /** Localized authoring description, when the manifest declares one. */
    readonly description?: string;
}
/** One frozen insertion-catalog entry. */
export interface LocalComponentCatalogEntry {
    readonly id: string;
    readonly name: string;
    readonly title: string;
    readonly description: string;
    readonly category: string;
    /** Localized label for `category`; falls back to the category id. */
    readonly categoryLabel: string;
    readonly insertText: string;
    readonly form: LocalComponentForm;
    /** True for inline and container forms, which accept a closing tag. */
    readonly paired: boolean;
    /** Inline components are inserted without block padding. */
    readonly inline: boolean;
    /** Structural parents that must enclose this component, when declared. */
    readonly parents?: readonly string[];
    /** Exclusive child components accepted by a container, when declared. */
    readonly allowedChildren?: readonly string[];
    /** Search terms from both languages (default preset entries). */
    readonly keywords?: readonly string[];
    readonly props: Readonly<Record<string, LocalComponentCatalogProp>>;
    /** Manifest style-resource identities preserved for export preflight. */
    readonly styles?: readonly string[];
    /** Kernel requirements preserved for configuration checks. */
    readonly requires?: LocalComponentRequires;
}
export interface LocalTagAuthoring {
    readonly name: string;
    readonly form: LocalComponentForm;
    /** True for inline and container forms, which accept a closing tag. */
    readonly paired: boolean;
    readonly title: string;
    readonly description: string;
    readonly category: string;
    readonly categoryLabel: string;
    readonly insertText: string;
    readonly props: Readonly<Record<string, LocalAttributeAuthoring>>;
    readonly parents?: readonly string[];
    readonly allowedChildren?: readonly string[];
    readonly keywords?: readonly string[];
    /** Manifest style-resource identities preserved for export preflight. */
    readonly styles?: readonly string[];
    /** Kernel requirements preserved for configuration checks. */
    readonly requires?: LocalComponentRequires;
}
export interface LocalAttributeAuthoring {
    readonly name: string;
    readonly kind: LocalPropKind;
    readonly required: boolean;
    readonly static: boolean;
    readonly dynamic: boolean;
    readonly values?: readonly string[];
    readonly defaultValue?: LocalValue;
    readonly pattern?: string;
    /** Localized authoring description, when the manifest declares one. */
    readonly description?: string;
}
export interface LocalAuthoringLookup {
    readonly tags: readonly LocalTagAuthoring[];
    /** Look up a tag by its exact lowercase kebab-case name. */
    tag(name: string): LocalTagAuthoring | undefined;
    attribute(tag: string, attribute: string): LocalAttributeAuthoring | undefined;
}
export interface LocalComponentCatalogGroup {
    readonly id: string;
    readonly label: string;
    readonly entries: readonly LocalComponentCatalogEntry[];
}
export interface LocalComponentCatalogFilter {
    /** Case-insensitive search over name, title, description, category and keywords. */
    readonly query?: string;
    /** Ancestor component names from outermost to innermost. */
    readonly ancestors?: readonly string[];
}
/**
 * Same parent-context rule for hosts that only hold frozen catalog entries
 * (conformance reporting). Uses the entry's already-localized template.
 */
export declare function localCatalogParentContext(entry: LocalComponentCatalogEntry, entries: readonly LocalComponentCatalogEntry[]): {
    before: string;
    after: string;
} | undefined;
/**
 * Stable signature of everything the authored catalog reads, including
 * authoring copy that the compile-semantics key deliberately excludes.
 *
 * Editors memoize the catalog on this key: a metadata-only configuration change
 * rebuilds the menu, while an equivalent options object is reused.
 */
export declare function localComponentCatalogKey(options?: LocalCompileOptions, locale?: EditorLocale): string;
/**
 * Frozen insertion catalog for a configuration. Invalid configurations throw;
 * this keeps `createLocalConfig`/registration errors visible to hosts that build
 * the catalog eagerly.
 */
export declare function createLocalComponentCatalog(config: LocalConfig, locale?: EditorLocale): readonly LocalComponentCatalogEntry[];
/**
 * Catalog without compiling external insertion templates.
 *
 * Conformance reporting needs every declared entry so it can report each bad
 * template individually instead of aborting on the first error. This is not
 * re-exported from the public authoring entry.
 */
export declare function createLocalComponentCatalogUnchecked(config: LocalConfig, locale?: EditorLocale): readonly LocalComponentCatalogEntry[];
/**
 * Catalog for the same `LocalCompileOptions` the editor and compiler use.
 * Invalid options produce an empty catalog so a malformed host option cannot
 * break the editor shell; the compiler still reports the error normally.
 */
export declare function createLocalComponentCatalogForOptions(options?: LocalCompileOptions, locale?: EditorLocale): readonly LocalComponentCatalogEntry[];
/**
 * Group catalog entries for a menu. Known default categories keep their
 * authoring order; additional host categories appear in first-seen order.
 */
export declare function localComponentCatalogGroups(entries: readonly LocalComponentCatalogEntry[]): readonly LocalComponentCatalogGroup[];
/**
 * Structural filter for a menu opened at a caret.
 *
 * - Components that declare `parents` only appear while one of those ancestors
 *   encloses the caret.
 * - When the innermost catalog parent declares exclusive children, only those
 *   children remain available.
 * - The optional query is matched against literal text fields; descriptions
 *   are never interpreted as HTML.
 */
export declare function filterLocalComponentCatalog(entries: readonly LocalComponentCatalogEntry[], filter?: LocalComponentCatalogFilter): readonly LocalComponentCatalogEntry[];
/** Plain-text help: component description followed by declared property help. */
export declare function localComponentHelp(entry: LocalComponentCatalogEntry): string;
/**
 * Ancestor components at `offset`, outermost to innermost. Uses the same
 * validated compile options as analysis and completion. Returns no ancestors
 * in HTML mode or when options are invalid.
 */
export declare function localCatalogAncestors(source: string, offset: number, options?: LocalCompileOptions): readonly string[];
/**
 * Tag, attribute and description lookup for an authoring host.
 *
 * Component shapes come from `readLocalCompileOptions`, so a `config` option
 * sees exactly the components the compiler accepted. Default localized
 * templates and keywords come from preset authoring data; external titles,
 * descriptions, templates and property help come from the same manifests.
 */
export declare function createLocalAuthoringLookup(options?: LocalCompileOptions, locale?: EditorLocale): LocalAuthoringLookup;
