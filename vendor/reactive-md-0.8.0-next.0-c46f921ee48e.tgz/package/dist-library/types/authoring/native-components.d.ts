/**
 * Compatibility catalog of default React-free editor components.
 *
 * The data no longer lives here: titles, descriptions, groups, keywords and
 * templates are the default preset authoring data in
 * `src/presets/default-authoring.ts`, and the same manifests are validated by
 * the default preset. This module only projects that single source into the
 * legacy `NATIVE_COMPONENTS` shape so existing editor and host code keeps
 * working.
 *
 * Templates stay close to the documented authoring syntax:
 * - `{{bind:base}}` is resolved by `renderNativeSnippet` to a fresh bind name.
 * - `{{selection}}`, `{{selection:fallback}}`, `{{caret}}` and `{{select:value}}`
 *   are left for the toolbar's `insertTemplate` handler.
 * - Leaf components never receive a closing tag; container bodies use blank
 *   lines so inserted Markdown keeps a natural block layout.
 */
import { type DefaultAuthoringGroupId } from '../presets/default-authoring.js';
import type { EditorLocale } from './command-types.js';
export type NativeComponentGroupId = DefaultAuthoringGroupId;
export interface NativeComponentGroup {
    id: NativeComponentGroupId;
    label: string;
}
export interface NativeComponentDefinition {
    id: string;
    label: string;
    description: string;
    group: NativeComponentGroupId;
    keywords: string[];
    inline?: boolean;
    template: string;
}
export declare const NATIVE_COMPONENT_GROUPS: readonly NativeComponentGroup[];
export declare const NATIVE_COMPONENTS: readonly NativeComponentDefinition[];
export declare const NATIVE_COMPONENT_GROUPS_ZH: readonly NativeComponentGroup[];
export declare const NATIVE_COMPONENTS_ZH: readonly NativeComponentDefinition[];
/** The legacy extended subset, derived from the same preset data. */
export declare const EXTENDED_NATIVE_COMPONENTS: readonly NativeComponentDefinition[];
/** Chinese copy for the legacy extended subset. */
export declare const EXTENDED_NATIVE_COMPONENT_COPY_ZH: Readonly<Record<string, {
    readonly label: string;
    readonly description: string;
    readonly keywords: readonly string[];
    readonly template: string;
}>>;
export interface NativeComponentCatalog {
    groups: readonly NativeComponentGroup[];
    components: readonly NativeComponentDefinition[];
}
/**
 * Catalog for the active UI language. Labels, descriptions and templates are
 * localized; keywords keep both English and Chinese terms so either query
 * works in either language.
 */
export declare function getNativeComponentCatalog(locale?: EditorLocale): NativeComponentCatalog;
/**
 * Render one toolbar template for insertion into `source`.
 *
 * Only `{{bind:base}}` is resolved here. Selection, caret and selectable tokens
 * stay intact for the toolbar's `insertTemplate` step. `selectedText` is kept
 * for future use; it never replaces the tokens here.
 */
export declare function renderNativeSnippet(component: NativeComponentDefinition, source: string, selectedText?: string): string;
