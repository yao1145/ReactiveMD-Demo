import type { LocalComponentDefinition } from '../sdk/types.js';
import type { LocalCompileOptions } from '../local/contracts/types.js';
import type { LocalPropKind } from '../local/configuration/schema.js';
/**
 * Minimal legal insertion-template synthesis for manifests that do not supply
 * `authoring.insertText`.
 *
 * A synthesized template is only offered when it compiles under the *same*
 * configuration the editor uses. Otherwise the component must provide a
 * template; the error names the component and includes the compiler
 * diagnostics instead of inserting a document that fails immediately.
 */
export interface TemplateProp {
    readonly kind: LocalPropKind;
    readonly required: boolean;
    readonly values?: readonly string[];
    readonly defaultValue?: string | number | boolean | null;
    readonly pattern?: string;
    readonly min?: number;
    readonly max?: number;
    readonly integer: boolean;
    readonly color: boolean;
}
export declare function templateProps(definition: LocalComponentDefinition): Record<string, TemplateProp>;
/**
 * Build a document-independent, directly compilable template. Binding names
 * are literals so repeated insertion can retarget them without parsing tokens.
 */
export declare function synthesizeInsertText(definition: LocalComponentDefinition, props: Readonly<Record<string, TemplateProp>>): string;
/**
 * Resolve toolbar-owned snippet tokens exactly as insertion does for an empty
 * document and a collapsed caret: `{{bind:base}}` becomes a fresh literal
 * binding, `{{selection}}` becomes empty, `{{selection:fallback}}` becomes the
 * fallback text, `{{caret}}` is dropped and `{{select:value}}` keeps its value.
 *
 * `source` mirrors the document the snippet will be inserted into so validation
 * can avoid reusing a binding name already present in a parent wrapper.
 */
export declare function expandInsertTemplate(template: string, source?: string): string;
/**
 * Place a child insertion inside an expanded container template just before its
 * closing tag. Returns `undefined` when the template has no such closing tag.
 */
export declare function parentInsertionWrapper(parentName: string, parentTemplate: string): {
    before: string;
    after: string;
} | undefined;
/**
 * Compile a supplied `authoring.insertText` after resolving snippet tokens.
 * `before`/`after` place the snippet in a legal structural parent context for
 * components that may only appear inside a container.
 */
export declare function assertSuppliedTemplateCompiles(template: string, options: LocalCompileOptions | undefined, label: string, context?: {
    readonly before: string;
    readonly after: string;
}): void;
/**
 * Compile a synthesized template with the editor configuration. The error is
 * deliberately concrete: it names the component and includes diagnostic codes
 * and messages.
 */
export declare function assertTemplateCompiles(template: string, options: LocalCompileOptions | undefined, label: string, context?: {
    readonly before: string;
    readonly after: string;
}): void;
