import { type RefObject } from 'react';
export interface LocalKeyOptions {
    readonly disabled?: boolean;
    /** Ignore events originating in form fields or editable regions. */
    readonly ignoreEditable?: boolean;
    /** `handled` prevents default only when a handler exists. */
    readonly preventDefault?: boolean | 'handled';
    readonly repeat?: boolean;
}
export type LocalKeyBindings = Readonly<Record<string, (event: KeyboardEvent) => void>>;
export declare function isEditableTarget(target: EventTarget | null): boolean;
/**
 * Focus-scoped keyboard handling for one element. The hook never installs a
 * global listener and never prevents keys the component did not handle.
 */
export declare function useKeys(ref: RefObject<HTMLElement | null>, bindings: LocalKeyBindings, options?: LocalKeyOptions): void;
