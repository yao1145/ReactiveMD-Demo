import type { LocalComponentContext } from '../component-api.js';
import type { LocalSchedulerBackground } from '../../runtime-services/scheduler.js';
export interface UseTickerOptions {
    /** `pause` stops while hidden; `wall-clock` settles on resume. */
    readonly background?: LocalSchedulerBackground;
    /** Further restrict the default `interactive && visible && !disabled` gate. */
    readonly enabled?: boolean;
    /** Restart the subscription after `runtime.reset`. */
    readonly restartOnReset?: boolean;
}
/**
 * Run a callback on a managed interval. The hook owns subscription cleanup
 * and pauses automatically in static mode, when hidden, or when disabled.
 */
export declare function useTicker(context: LocalComponentContext, intervalMs: number, run: () => void, options?: UseTickerOptions): void;
/** Run a callback on every animation frame with a measured delta. */
export declare function useFrame(context: LocalComponentContext, run: (deltaMs: number) => void, options?: Pick<UseTickerOptions, 'enabled' | 'restartOnReset'>): void;
