import { type RefObject } from 'react';
export type LocalSwipeDirection = 'left' | 'right' | 'up' | 'down';
export type LocalSwipeAxis = 'horizontal' | 'vertical' | 'both';
export interface LocalSwipeOptions {
    readonly threshold?: number;
    readonly axis?: LocalSwipeAxis;
    /** Set `touch-action: none` on the target while mounted. */
    readonly preventScroll?: boolean;
    readonly disabled?: boolean;
    readonly pointerTypes?: readonly ('mouse' | 'pen' | 'touch')[];
}
export interface LocalSwipeHandlers {
    onSwipe(direction: LocalSwipeDirection, event: PointerEvent): void;
}
/**
 * Pure direction classifier. Exported so behavior can be tested without a DOM.
 * Returns null until the movement exceeds the threshold.
 */
export declare function classifySwipe(deltaX: number, deltaY: number, axis?: LocalSwipeAxis, threshold?: number): LocalSwipeDirection | null;
/**
 * Pointer/touch swipe recognition for one element.
 *
 * The hook owns recognition, cancellation, pointer capture and listener
 * cleanup. The component still owns the business action, scroll policy,
 * keyboard parity and accessible labels.
 */
export declare function useSwipe(ref: RefObject<HTMLElement | null>, handlers: LocalSwipeHandlers, options?: LocalSwipeOptions): void;
