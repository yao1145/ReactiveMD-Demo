import type { LocalComponentContext } from '../component-api.js';
import type { LocalComponentStateSaveResult } from '../../runtime-services/component-state.js';
export interface UseComponentStateOptions<T> {
    /** Used when no valid saved state exists. Called once per mounted instance. */
    initial: () => T;
    /** Reject states that do not match the current shape. */
    validate?: (value: unknown) => value is T;
    /** Monotonic state version owned by the component. Defaults to 0. */
    version?: number;
    /** Save on every `setValue`. Defaults to false: saving stays explicit. */
    autoSave?: boolean;
}
export interface UseComponentStateResult<T> {
    value: T;
    setValue(next: T): void;
    /** Persist the current or supplied value. */
    save(next?: T): LocalComponentStateSaveResult;
    /** Delete the saved progress without changing the current in-memory value. */
    clear(): void;
    loaded: boolean;
    error: string | null;
}
/**
 * Restore and explicitly save one component's state.
 *
 * Invalid, missing or version-mismatched records are skipped. They never
 * prevent the rest of the document from rendering. `runtime.reset` restores
 * the in-memory initial value; `clear()` separately deletes saved progress.
 */
export declare function useComponentState<T>(context: LocalComponentContext, options: UseComponentStateOptions<T>): UseComponentStateResult<T>;
