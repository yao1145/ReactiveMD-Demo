import type { Diagnostic, LocalDocument, LocalRuntime, LocalValue } from '../contracts/types.js';
export type LocalStateRetentionReason = 'internal' | 'unknown' | 'unretainable' | 'type' | 'initial' | 'invalid';
export interface LocalStateRetentionDrop {
    name: string;
    reason: LocalStateRetentionReason;
}
export interface LocalStateRetentionInput {
    previous: LocalDocument;
    state: Readonly<Record<string, LocalValue>>;
    next: LocalDocument;
}
export interface LocalRetainedState {
    values: Readonly<Record<string, LocalValue>>;
    retained: readonly string[];
    dropped: readonly LocalStateRetentionDrop[];
}
export interface LocalStateRetentionResult {
    retained: readonly string[];
    dropped: readonly LocalStateRetentionDrop[];
    diagnostics: readonly Diagnostic[];
}
export declare function planLocalStateRetention(input: LocalStateRetentionInput): LocalRetainedState;
export declare function applyLocalStateRetention(runtime: LocalRuntime, retained: LocalRetainedState): LocalStateRetentionResult;
