import type { DependencyIndex, NodeDependencies } from '../compilation/dependencies.js';
import type { LocalDocument, LocalNode, LocalValue } from '../contracts/types.js';
import type { LocalComponentDefinition } from '../../sdk/types.js';
/**
 * Pure projections used to keep a rendered document's memo boundaries stable
 * while the source is recompiled. Structural sharing from the incremental
 * compiler means an unchanged node keeps its object identity, so identity
 * comparison is enough for every projection whose result is derived solely
 * from those nodes.
 */
export interface AnchorProjection {
    /** Nodes that can contribute a heading slug, `<anchor>` or explicit DOM id. */
    readonly nodes: readonly LocalNode[];
    /** Initial values and constants feed interpolations inside heading text. */
    readonly metadata: string;
}
export interface FootnoteProjection {
    readonly nodes: readonly LocalNode[];
}
/**
 * Stable handle over the current dependency index. The index itself changes
 * whenever a node id is recompiled, but the handle keeps its identity so a
 * memoized block is never invalidated merely because an unrelated block was
 * added or removed. Reads always observe the latest index for this render.
 */
export interface DependencyLookup {
    get(nodeId: string): NodeDependencies | undefined;
}
/** Signature of document metadata that can change an anchor's rendered id. */
export declare function anchorMetadataKey(document: LocalDocument, installed?: readonly LocalComponentDefinition[]): string;
export declare function projectAnchors(document: LocalDocument, installed?: readonly LocalComponentDefinition[]): AnchorProjection;
export declare function sameAnchorProjection(previous: AnchorProjection, next: AnchorProjection): boolean;
export declare function projectFootnotes(document: LocalDocument): FootnoteProjection;
export declare function sameFootnoteProjection(previous: FootnoteProjection, next: FootnoteProjection): boolean;
/** Content equality for a persisted or recomputed dependency index. */
export declare function dependencyIndexEqual(previous: DependencyIndex, next: DependencyIndex): boolean;
/**
 * Validation rendering reads the rule set and the node ids each field binds
 * to. Both are compared by content so a prose-only edit keeps the same
 * context value (and does not invalidate every memoized block).
 */
export declare function validationProjectionKey(document: LocalDocument): string;
/**
 * Semantic signature of validation results. Each diagnostic is identified by
 * its rule index (matched through the freshly compiled rule ranges, so source
 * offsets may move), then by code and message. This keeps prose shifts stable
 * while still distinguishing "the same message now belongs to another rule".
 */
export declare function validationDiagnosticKey(document: LocalDocument, diagnostics: readonly {
    code: string;
    message: string;
    range: {
        start: number;
        end: number;
    };
}[]): string;
/**
 * The scalar inputs of one memoized block. Everything else a block needs
 * travels through `env` (kept stable by the projections above) and through
 * the runtime subscription.
 */
export interface BlockComparisonInputs {
    readonly node: LocalNode;
    readonly visible: boolean;
    readonly resetToken: number;
    readonly env: unknown;
    readonly depValues: readonly LocalValue[] | null;
}
/**
 * A block subtree re-renders only when the bindings it (or a descendant) reads
 * changed. `null` depValues means the dependencies could not be decided, so
 * the block keeps the pre-memoization behavior of re-rendering on every
 * revision.
 */
export declare function blockInputsEqual(previous: BlockComparisonInputs, next: BlockComparisonInputs): boolean;
