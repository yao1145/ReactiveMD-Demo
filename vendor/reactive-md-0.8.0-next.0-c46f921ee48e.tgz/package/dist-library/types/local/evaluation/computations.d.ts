import { LocalExpressionError, type LocalExpression } from './expression.js';
import type { LocalComputation, LocalValue, LocalValueKind } from '../contracts/types.js';
/**
 * Declarations are resolved in one bounded pass: every expression is compiled
 * once, the dependency graph is topologically ordered with an iterative Kahn
 * walk (no recursion over long chains), and types are inferred once per node.
 * `const` values are evaluated statically so authors see domain errors at
 * compile time; the runtime evaluates `computed` values once per revision.
 */
export interface ComputationInput {
    name: string;
    kind: 'computed' | 'const';
    /** Trimmed expression between `{{` and `}}`. */
    source: string;
    /** Absolute source offset of the expression, used for diagnostics. */
    expressionOffset: number;
    nodeId: string;
    range: {
        start: number;
        end: number;
    };
}
export type ComputationReport = (code: string, message: string, start: number, end?: number) => void;
export interface ResolvedComputations {
    computations: Record<string, LocalComputation>;
    kinds: Record<string, LocalValueKind>;
    /** Dependency-safe order, excluding declarations that could not resolve. */
    order: string[];
    expressions: Map<string, LocalExpression>;
    constValues: Record<string, LocalValue>;
}
/**
 * Topological order for metadata that has already been validated. The runtime
 * uses this to evaluate a hand-built document without trusting declaration
 * order; unresolved names are reported through `cyclic`.
 */
export declare function orderComputations(computations: Record<string, LocalComputation>): {
    order: string[];
    cyclic: string[];
};
export declare function resolveComputationGraph(inputs: ComputationInput[], controls: Record<string, LocalValueKind>, report: ComputationReport, externalNames?: ReadonlySet<string>, cache?: {
    expression(source: string): LocalExpression;
    infer(expression: LocalExpression, env: Record<string, LocalValueKind>): LocalValueKind;
}): ResolvedComputations;
export interface ComputationEvaluation {
    values: Record<string, LocalValue>;
    errors: Map<string, LocalExpressionError>;
}
/**
 * Evaluate `computed` declarations against a control snapshot. Constants are
 * supplied from their static values and are never recalculated. Failures are
 * recorded rather than thrown; later declarations see a getter that rethrows
 * the original error only when the failing name is actually read, which keeps
 * short-circuited branches and independent consumers working.
 */
export declare function evaluateComputations(computations: Record<string, LocalComputation>, order: string[], expressions: Map<string, LocalExpression>, controls: Record<string, LocalValue>, constValues: Record<string, LocalValue>, unavailable?: ReadonlyMap<string, LocalExpressionError>): ComputationEvaluation;
