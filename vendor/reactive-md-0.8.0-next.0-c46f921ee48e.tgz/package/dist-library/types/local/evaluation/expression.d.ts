import { type LocalDiagnosticDetails } from '../configuration/diagnostics.js';
import type { LocalValue, LocalValueKind } from '../contracts/types.js';
/**
 * The local-draft expression language.
 *
 * The parser produces an explicit AST. Evaluation never uses eval, Function or
 * the global object: only the provided environment and a fixed set of pure
 * functions are reachable. Numbers must stay finite, strings and arrays have a
 * budget, and every operator is type checked.
 */
export declare class LocalExpressionError extends Error {
    readonly offset: number;
    readonly code: string;
    constructor(code: string, message: string, offset?: number);
}
export interface LocalExpression {
    readonly source: string;
    readonly dependencies: string[];
    evaluate(env: Record<string, LocalValue>): LocalValue;
    inferType(env: Record<string, LocalValueKind>): LocalValueKind;
}
/** Names that cannot be used as a document binding. */
export declare const RESERVED_NAMES: Set<string>;
/**
 * Allocation-free budget check for a value stored in the runtime or read from
 * an expression environment. Returns structured metadata, or null when the
 * value fits. These are defensive resource budgets: string lengths are UTF-16
 * code units (matching allocation cost), while author-visible text constraints
 * use `countLocalCodePoints`. `len()` keeps counting code points.
 */
export declare function localValueBudgetIssue(value: LocalValue): LocalDiagnosticDetails | null;
/** English message form kept for existing callers and error construction. */
export declare function localValueBudgetError(value: LocalValue): string | null;
export declare function compileExpression(source: string): LocalExpression;
/** Render a template to scalar text. Arrays are rejected rather than serialized. */
export declare function interpolate(template: string, env: Record<string, LocalValue>): string;
/**
 * Evaluate a template that is exactly one interpolation, preserving its type.
 * Mixed templates and plain text fall back to text rendering.
 */
export declare function expressionValue(template: string, env: Record<string, LocalValue>): LocalValue;
/**
 * Binding keys read by the `{{ }}` expressions of a template, deduplicated in
 * first-occurrence order. Malformed templates or expressions throw; callers
 * that only need a static scan treat a throw as undecidable.
 */
export declare function templateDependencies(template: string): string[];
