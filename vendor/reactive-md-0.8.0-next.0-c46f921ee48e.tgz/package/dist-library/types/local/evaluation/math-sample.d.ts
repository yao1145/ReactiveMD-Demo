import type { LatexEvaluationBudget, LatexExpression, PlotSample, PlotSegmentPoint } from './math.js';
import type { LocalValue } from '../contracts/types.js';
/**
 * Samples y(x) across [min, max]. Undefined points and the sample after a
 * detected break become null so a renderer cannot join the two sides of an
 * asymptote. The array always has exactly `samples` points.
 *
 * The optional final budget is shared by every curve/plot in a document. Each
 * evaluation is limited by whatever remains of both that shared budget and the
 * per-curve budget, and a `latex-budget` error aborts the whole sampling pass.
 */
export declare function samplePlot(expression: LatexExpression, env: Record<string, LocalValue>, min: number, max: number, samples?: number, sharedBudget?: LatexEvaluationBudget): PlotSample;
/**
 * Samples a parametric curve `(x(t), y(t))` over [min, max]. Points whose x or
 * y value is undefined keep a NaN x and a null y so the renderer breaks the
 * stroke instead of joining across a domain gap.
 */
export declare function sampleParametric(xExpression: LatexExpression, yExpression: LatexExpression, env: Record<string, LocalValue>, min: number, max: number, samples?: number, sharedBudget?: LatexEvaluationBudget): PlotSample;
/**
 * Traces `expression(x, y) = 0` with marching squares. The caller supplies the
 * viewport; the environment receives the current y for every evaluation.
 */
export declare function sampleImplicit(expression: LatexExpression, env: Record<string, LocalValue>, xMin: number, xMax: number, yMin: number, yMax: number, grid?: number, sharedBudget?: LatexEvaluationBudget): PlotSegmentPoint[][];
