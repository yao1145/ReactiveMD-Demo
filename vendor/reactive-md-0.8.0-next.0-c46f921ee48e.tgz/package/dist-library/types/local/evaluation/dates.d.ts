/** Shared Gregorian date-only calendar, compatible with native date inputs. */
export declare function localDateTimestamp(text: string): number | null;
