import type { Diagnostic, LocalCompileResult, LocalNode, LocalRecovery } from '../contracts/types.js';
/**
 * Wire protocol for incremental compile results.
 *
 * The first successful compile always exchanges the complete source and
 * result while advertising this protocol. Only after the other side has
 * acknowledged it may a request carry a UTF-16 source edit and a response
 * carry a result patch. Legacy peers keep receiving the classic full shapes.
 */
export declare const LOCAL_RESULT_PATCH_PROTOCOL = "patch-v1";
export type LocalResultPatchProtocol = typeof LOCAL_RESULT_PATCH_PROTOCOL;
/** A UTF-16 source replacement: keep `[0, from)`, insert, keep `[to, end)`. */
export interface LocalSourceEdit {
    readonly from: number;
    readonly to: number;
    readonly insert: string;
}
/** Replacement of one group of document metadata entries. */
export interface LocalRecordPatch {
    readonly set?: Record<string, unknown>;
    readonly remove?: readonly string[];
}
/** Per-node result diff keyed by the compiler-provided stable node id. */
export interface LocalNodePatch {
    readonly id: string;
    /**
     * Complete replacement subtree. Used for nodes that do not exist in the
     * baseline and therefore cannot share any object with it.
     */
    readonly node?: LocalNode;
    /**
     * Node fields (including `range`) except `children`. Omitted for nodes that
     * only shifted or whose children changed.
     */
    readonly data?: Omit<LocalNode, 'children'>;
    /**
     * New ordered child ids. `null` removes a `children` property that the
     * baseline node had; omitted means the baseline child list is unchanged.
     */
    readonly children?: readonly string[] | null;
    /** Uniform UTF-16 range shift relative to the baseline node. */
    readonly shift?: number;
    /**
     * The complete baseline subtree is unchanged apart from a uniform range
     * shift, so no descendant records are needed.
     */
    readonly subtree?: boolean;
}
export type LocalDocumentRecordKey = 'initialState' | 'bindings' | 'bindingSlots' | 'computations' | 'dependencies' | 'tableShapes';
export interface LocalDocumentPatch {
    readonly source?: LocalSourceEdit;
    readonly removed?: readonly string[];
    readonly values?: Record<string, unknown>;
    /** Root node ids in document order, when the root list changed. */
    readonly roots?: readonly string[];
    readonly nodes?: readonly LocalNodePatch[];
    readonly records?: Partial<Record<LocalDocumentRecordKey, LocalRecordPatch>>;
}
export interface LocalResultPatch {
    readonly kind: 'result-patch';
    readonly protocol: LocalResultPatchProtocol;
    readonly document: LocalDocumentPatch;
    readonly diagnostics?: Diagnostic[];
    /**
     * Result-level recovery records. Omitted when the baseline already carries
     * an equal list; `null` removes records that the previous revision had, so
     * closing a repaired construct cannot leave stale recoveries in the applied
     * baseline. An empty array is distinct from absence and is transmitted as-is.
     */
    readonly recoveries?: readonly LocalRecovery[] | null;
}
/**
 * Relative transport cost of an encoded patch and the equivalent complete
 * result. The complete result is only measured when the patch is too large to
 * be provably cheaper, so `fullBytes`/`fullNodes` stay absent otherwise.
 */
export interface LocalResultPatchCost {
    /** Estimated JSON UTF-8 bytes of the patch payload, not structured-clone bytes. */
    readonly patchBytes: number;
    /** Estimated JSON UTF-8 bytes of the complete result payload. */
    readonly fullBytes?: number;
    /** Node records carried by the patch. */
    readonly patchNodes: number;
    /** Nodes in the complete result; absent when it was not measured. */
    readonly fullNodes?: number;
    /** True when the complete result is expected to be no more expensive. */
    readonly preferFull: boolean;
    /** Which dimension made the complete result preferable. */
    readonly reason?: 'bytes' | 'nodes';
}
export interface LocalResultPatchEncoding {
    readonly patch: LocalResultPatch;
    readonly cost: LocalResultPatchCost;
}
/** Structural equality for the plain, acyclic values produced by the compiler. */
export declare function localDataEqual(left: unknown, right: unknown): boolean;
/**
 * Independent deep copy of compiler output. Unlike a structured clone it
 * preserves `undefined` properties and never carries frozen markers into the
 * copy, so a consumer mutating a delivered result cannot reach the scheduler's
 * internal baseline.
 */
export declare function cloneLocalCompileResult<T>(value: T): T;
/** Longest-common-prefix/suffix UTF-16 edit from `before` to `after`. */
export declare function diffSourceEdit(before: string, after: string): LocalSourceEdit | null;
/** Apply a UTF-16 edit, returning null when the edit does not fit the source. */
export declare function applySourceEdit(source: string, edit: LocalSourceEdit): string | null;
/**
 * Encode `next` relative to `base`. Returns null when a patch is impossible
 * (for example a failed result), in which case the caller must send the full
 * result. Only changed roots/nodes and changed metadata entries are present;
 * unchanged objects are addressed by their stable ids.
 */
export declare function encodeLocalResultPatch(base: LocalCompileResult, next: LocalCompileResult): LocalResultPatch | null;
/**
 * `encodeLocalResultPatch` plus a transport cost estimate. The patch contract
 * is unchanged; the estimate only tells the caller whether the complete
 * result would be cheaper for this same revision.
 */
export declare function encodeLocalResultPatchWithCost(base: LocalCompileResult, next: LocalCompileResult): LocalResultPatchEncoding | null;
/**
 * Apply a result patch to a baseline without mutating it. Unchanged nodes are
 * reused by reference; changed, added and shifted nodes become new objects.
 * Malformed or stale patches return null so the caller can request a full
 * result instead of trusting partial data.
 */
export declare function applyLocalResultPatch(base: LocalCompileResult, patch: LocalResultPatch): LocalCompileResult | null;
