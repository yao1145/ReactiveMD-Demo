/**
 * Diagnostic language resources.
 *
 * Bilingual templates and compatibility aliases are data only: the
 * construction, lookup and formatting logic lives in `diagnostics.ts`. Keeping
 * translations here makes it possible to move them to an external resource
 * file without changing any caller.
 */
export declare const LOCAL_DIAGNOSTIC_MESSAGES: {
    readonly 'local.version.unsupported': {
        readonly en: 'This reader accepts {supported}; migrate {declared} or use a compatible reader.';
        readonly zh: '此阅读器支持 {supported}；请迁移 {declared} 或使用兼容的阅读器。';
    };
    readonly 'local.version.malformed': {
        readonly en: 'Use <!-- reactive-md: local-draft-3 --> on one line.';
        readonly zh: '请在单独一行使用 <!-- reactive-md: local-draft-3 -->。';
    };
    readonly 'local.version.duplicate': {
        readonly en: 'Only one source syntax declaration is allowed.';
        readonly zh: '源码只能声明一次语法版本。';
    };
    readonly 'local.version.placement': {
        readonly en: 'The syntax declaration must be on its own line before the theme and document body.';
        readonly zh: '语法版本声明必须独占一行，位于主题声明和正文之前。';
    };
    readonly 'local.upgrade.from-version': {
        readonly en: 'Cannot migrate from {from}: {detail}.';
        readonly zh: '无法从 {from} 迁移：{detail}。';
    };
    readonly 'local.upgrade.reserved-binding': {
        readonly en: 'Binding {name} becomes reserved in local-draft-2; rename it with a compatible old editor before migration.';
        readonly zh: '绑定 {name} 在 local-draft-2 中成为保留名；迁移前请用兼容旧版本的编辑器重命名。';
    };
    readonly 'local.upgrade.tag': {
        readonly en: 'Tag {name} was inert in the older revision and becomes active in a newer one; preserve it as literal code before migration.';
        readonly zh: '标签 {name} 在旧版本中不执行，在较新版本中会激活；迁移前请将其保留为代码原文。';
    };
    readonly 'local.upgrade.text-length': {
        readonly en: 'Text length constraints change from UTF-16 units to Unicode code points; explicitly accept this semantic change before migration.';
        readonly zh: '文本长度约束从 UTF-16 单元改为 Unicode 码点计数；迁移前须明确接受这一语义变化。';
    };
    readonly 'local.upgrade.expression': {
        readonly en: 'This expression uses array syntax or a function introduced in local-draft-2; it is outside automatic draft-1 migration.';
        readonly zh: '此表达式使用了 local-draft-2 新增的数组语法或函数，不属于 draft-1 自动迁移范围。';
    };
    readonly 'local.upgrade.version-missing': {
        readonly en: 'The source has no syntax declaration; migration will pin {version}.';
        readonly zh: '源码尚未声明语法版本；迁移将固定为 {version}。';
    };
    readonly 'capability.html': {
        readonly en: 'This compiler assembly does not include the native HTML document branch.';
        readonly zh: '当前编译器装配不包含原生 HTML 文档分支。';
    };
    readonly 'capability.plot': {
        readonly en: 'This compiler assembly does not include plot formula support.';
        readonly zh: '当前编译器装配不包含绘图公式支持。';
    };
    readonly 'parse.sourceType': {
        readonly en: 'Document source must be a string.';
        readonly zh: '文档源必须是字符串。';
    };
    readonly 'parse.markdownFailed': {
        readonly en: 'Cannot parse the Markdown document.';
        readonly zh: '无法解析 Markdown 文档。';
    };
    readonly 'parse.failed': {
        readonly en: 'Cannot parse document: {detail}';
        readonly zh: '无法解析文档：{detail}';
    };
    readonly 'budget.document': {
        readonly en: 'Document exceeds the {limit}-character limit.';
        readonly zh: '文档超过 {limit} 个字符的上限。';
    };
    readonly 'budget.syntaxNodes': {
        readonly en: 'Syntax nodes exceed the limit of {limit}.';
        readonly zh: '语法节点数量超过上限 {limit}。';
    };
    readonly 'budget.parseWork': {
        readonly en: 'Parsing work exceeds the limit of {limit}.';
        readonly zh: '解析工作量超过上限 {limit}。';
    };
    readonly 'budget.markdownDepth': {
        readonly en: 'Markdown nesting exceeds the {limit}-level limit.';
        readonly zh: 'Markdown 嵌套超过 {limit} 层上限。';
    };
    readonly 'budget.nesting': {
        readonly en: 'Component nesting exceeds the {limit}-level limit.';
        readonly zh: '组件嵌套超过 {limit} 层上限。';
    };
    readonly 'options.notObject': {
        readonly en: 'Compile options must be an object.';
        readonly zh: '编译选项必须是对象。';
    };
    readonly 'options.limitsNotObject': {
        readonly en: 'Compile option limits must be an object.';
        readonly zh: '编译选项 limits 必须是对象。';
    };
    readonly 'options.maxSyntaxNodes': {
        readonly en: 'Compile option limits.maxSyntaxNodes must be a positive safe integer.';
        readonly zh: '编译选项 limits.maxSyntaxNodes 必须是正安全整数。';
    };
    readonly 'options.maxParseWork': {
        readonly en: 'Compile option limits.maxParseWork must be a positive safe integer.';
        readonly zh: '编译选项 limits.maxParseWork 必须是正安全整数。';
    };
    readonly 'options.maxMarkdownDepth': {
        readonly en: 'Compile option limits.maxMarkdownDepth must be a positive safe integer.';
        readonly zh: '编译选项 limits.maxMarkdownDepth 必须是正安全整数。';
    };
    readonly 'options.unknownLimit': {
        readonly en: 'Compile option limits.{detail} is not supported.';
        readonly zh: '编译选项 limits.{detail} 不受支持。';
    };
    readonly 'options.hostComponents': {
        readonly en: 'Compile option hostComponents is invalid: {detail}';
        readonly zh: '编译选项 hostComponents 无效：{detail}';
    };
    readonly 'theme.expression': {
        readonly en: 'Theme names must be static text, not expressions.';
        readonly zh: '主题名称必须是静态文本，不能是表达式。';
    };
    readonly 'theme.nameRequired': {
        readonly en: 'A theme declaration requires a quoted name attribute.';
        readonly zh: '主题声明需要一个带引号的 name 属性。';
    };
    readonly 'theme.attributeOnly': {
        readonly en: 'Theme declarations only accept a quoted name attribute.';
        readonly zh: '主题声明只接受带引号的 name 属性。';
    };
    readonly 'theme.nameInvalid': {
        readonly en: 'Theme name "{name}" must use lowercase letters, digits and single hyphens (maximum {limit} characters).';
        readonly zh: '主题名称“{name}”只能使用小写字母、数字和单个连字符（最多 {limit} 个字符）。';
    };
    readonly 'theme.malformedMissingClose': {
        readonly en: 'Theme declaration is missing >.';
        readonly zh: '主题声明缺少 >。';
    };
    readonly 'theme.malformedClosing': {
        readonly en: 'A theme declaration cannot be a closing tag.';
        readonly zh: '主题声明不能是结束标签。';
    };
    readonly 'theme.malformedStandalone': {
        readonly en: 'A theme declaration must be on its own line before the document content.';
        readonly zh: '主题声明必须单独占一行并位于文档内容之前。';
    };
    readonly 'theme.duplicateDeclaration': {
        readonly en: 'Only one theme declaration is allowed before the document content; this declaration is ignored.';
        readonly zh: '文档内容之前只允许一个主题声明；此声明将被忽略。';
    };
    readonly 'theme.late': {
        readonly en: 'Theme declarations after document content are ignored.';
        readonly zh: '文档内容之后的主题声明将被忽略。';
    };
    readonly 'theme.nested': {
        readonly en: 'Theme declarations inside document content are ignored.';
        readonly zh: '文档内容内部的主题声明将被忽略。';
    };
    readonly 'theme.invalidDeclaration': {
        readonly en: 'Invalid theme declaration.';
        readonly zh: '无效的主题声明。';
    };
    readonly 'attribute.lowercase': {
        readonly en: 'Attribute names must use lowercase kebab-case.';
        readonly zh: '属性名必须使用小写 kebab-case。';
    };
    readonly 'budget.attributeName': {
        readonly en: 'Attribute name exceeds the {limit}-character limit.';
        readonly zh: '属性名超过 {limit} 个字符的上限。';
    };
    readonly 'attribute.nameInvalid': {
        readonly en: 'Attribute name {name} must use lowercase kebab-case.';
        readonly zh: '属性名 {name} 必须使用小写 kebab-case。';
    };
    readonly 'attribute.valueQuoted': {
        readonly en: 'Attribute {name} value must be quoted.';
        readonly zh: '属性 {name} 的值必须加引号。';
    };
    readonly 'attribute.valueUnclosed': {
        readonly en: 'Attribute {name} is missing a closing quote.';
        readonly zh: '属性 {name} 缺少结束引号。';
    };
    readonly 'attribute.duplicate': {
        readonly en: 'Duplicate attribute {name}.';
        readonly zh: '重复的属性 {name}。';
    };
    readonly 'attribute.separator': {
        readonly en: 'Attributes must be separated by whitespace.';
        readonly zh: '属性之间必须用空白分隔。';
    };
    readonly 'budget.tagName': {
        readonly en: 'Tag name exceeds the {limit}-character limit.';
        readonly zh: '标签名超过 {limit} 个字符的上限。';
    };
    readonly 'tag.missingClose': {
        readonly en: 'Tag {name} is missing >.';
        readonly zh: '标签 {name} 缺少 >。';
    };
    readonly 'tag.closingAttributes': {
        readonly en: 'Closing tag </{name}> cannot have attributes.';
        readonly zh: '结束标签 </{name}> 不能带属性。';
    };
    readonly 'tag.nameInvalid': {
        readonly en: 'Tag name {name} must use lowercase kebab-case.';
        readonly zh: '标签名 {name} 必须使用小写 kebab-case。';
    };
    readonly 'tag.unclosedPaired': {
        readonly en: '<{name}> is missing </{name}>.';
        readonly zh: '<{name}> 缺少 </{name}>。';
    };
    readonly 'tag.mismatchRoot': {
        readonly en: 'Closing tag </{name}> does not match the document root.';
        readonly zh: '结束标签 </{name}> 与文档根不匹配。';
    };
    readonly 'tag.mismatchParent': {
        readonly en: 'Closing tag </{name}> does not match <{parent}>.';
        readonly zh: '结束标签 </{name}> 与 <{parent}> 不匹配。';
    };
    readonly 'tag.requiresClose': {
        readonly en: '<{name}> requires a closing tag.';
        readonly zh: '<{name}> 需要结束标签。';
    };
    readonly 'footnote.unsupported': {
        readonly en: 'Footnotes are not part of the local interaction syntax and are shown as source.';
        readonly zh: '脚注不属于本地交互语法，将按源文本显示。';
    };
    readonly 'interpolation.unclosed': {
        readonly en: 'Interpolation is missing }}.';
        readonly zh: '插值缺少 }}。';
    };
    readonly 'math.unclosed': {
        readonly en: 'Formula is missing its closing delimiter.';
        readonly zh: '公式缺少结束定界符。';
    };
    readonly 'math.whitespace': {
        readonly en: 'Inline math cannot start or end with whitespace.';
        readonly zh: '行内公式不能以空白开头或结尾。';
    };
    readonly 'budget.math': {
        readonly en: 'Formula exceeds the {limit}-character limit.';
        readonly zh: '公式超过 {limit} 个字符的上限。';
    };
    readonly 'html.raw': {
        readonly en: 'Raw HTML is not part of the local interaction syntax.';
        readonly zh: '原始 HTML 不属于本地交互语法。';
    };
    readonly 'html.fallback': {
        readonly en: 'Native HTML was safely converted to inert source text.';
        readonly zh: '原生 HTML 已安全回退为惰性源码文本。';
    };
    readonly 'html.fallbackAttribute': {
        readonly en: 'Native HTML attribute {name} is unsupported; the element was safely converted to inert source text.';
        readonly zh: '原生 HTML 属性 {name} 不受支持；该元素已安全回退为惰性源码文本。';
    };
    readonly 'html.table.structure': {
        readonly en: 'Invalid native HTML table structure in <{tag}>.';
        readonly zh: '原生 HTML 表格的 <{tag}> 结构无效。';
    };
    readonly 'html.table.mixed': {
        readonly en: 'Keep text and Markdown inside cells or captions; native HTML table structure cannot mix with Markdown table rows.';
        readonly zh: '文字和 Markdown 应写在单元格或标题内；原生 HTML 表格结构不能混用 Markdown 表格行。';
    };
    readonly 'html.table.attribute': {
        readonly en: 'Attribute {name} is not supported on native HTML <{tag}>. ReactiveMD table options require a Markdown table body.';
        readonly zh: '原生 HTML <{tag}> 不支持属性 {name}。ReactiveMD 表格选项只适用于 Markdown 表格正文。';
    };
    readonly 'html.table.value': {
        readonly en: 'Invalid value for {name} on native HTML <{tag}>.';
        readonly zh: '原生 HTML <{tag}> 的 {name} 属性值无效。';
    };
    readonly 'html.table.unclosed': {
        readonly en: 'Native HTML table is missing </table>.';
        readonly zh: '原生 HTML 表格缺少 </table>。';
    };
    readonly 'html.extended': {
        readonly en: 'HTML element <{name}> requires enableExtendedHtml in this mode; it is shown as source.';
        readonly zh: '此模式下 HTML 元素 <{name}> 需要启用 enableExtendedHtml；已按源码显示。';
    };
    readonly 'html.attribute': {
        readonly en: 'HTML attribute {name} on <{tag}> is not supported; the element is shown as source.';
        readonly zh: '<{tag}> 上的 HTML 属性 {name} 不受支持；该元素已按源码显示。';
    };
    readonly 'html.unsafeUrl': {
        readonly en: 'Unsafe URL in attribute {name} was removed.';
        readonly zh: '属性 {name} 中的不安全 URL 已移除。';
    };
    readonly 'html.capability': {
        readonly en: 'Author {feature} was disabled by the compile options.';
        readonly zh: '编译选项已禁用作者提供的{feature}。';
    };
    readonly 'recovery.unclosed': {
        readonly en: 'An unclosed RMD fragment was rendered as literal source; its components and expressions are inactive.';
        readonly zh: '未闭合的 RMD 片段已按原文显示，片段中的组件和表达式不执行。';
    };
    readonly 'recovery.mismatch': {
        readonly en: 'A fragment with mismatched tags was rendered as literal source; its components and expressions are inactive.';
        readonly zh: '标签不匹配的片段已按原文显示，片段中的组件和表达式不执行。';
    };
    readonly 'recovery.strayClose': {
        readonly en: 'A stray closing tag was rendered as literal source.';
        readonly zh: '孤立的结束标签已按原文显示。';
    };
    readonly 'recovery.htmlRepair': {
        readonly en: 'Malformed native HTML was structurally repaired for display.';
        readonly zh: 'HTML 结构已修复后显示。';
    };
    readonly 'recovery.htmlLiteral': {
        readonly en: 'Native HTML could not be safely repaired and was rendered as literal source.';
        readonly zh: 'HTML 片段无法安全恢复，已按原文显示。';
    };
    readonly 'options.htmlFlag': {
        readonly en: 'Compile option {name} must be a boolean.';
        readonly zh: '编译选项 {name} 必须是布尔值。';
    };
    readonly 'options.markdownBreaks': {
        readonly en: 'Compile option markdownBreaks must be a boolean.';
        readonly zh: '编译选项 markdownBreaks 必须为布尔值。';
    };
    readonly 'options.strict': {
        readonly en: 'Compile option strict must be a boolean.';
        readonly zh: '编译选项 strict 必须为布尔值。';
    };
    readonly 'component.unknownSuggestion': {
        readonly en: 'Unknown component <{name}>. Did you mean <{suggestion}>?';
        readonly zh: '未知组件 <{name}>。是否想使用 <{suggestion}>？';
    };
    readonly 'component.unknownPlain': {
        readonly en: 'Unknown component <{name}>. This mode only accepts local interaction components.';
        readonly zh: '未知组件 <{name}>。此模式只接受本地交互组件。';
    };
    readonly 'legacy.fence': {
        readonly en: 'Legacy reactive-md configuration fences (state/data/computed/actions, etc.) are not part of the local interaction syntax; select legacy mode explicitly in the host.';
        readonly zh: '旧版 reactive-md 配置围栏（state/data/computed/actions 等）不属于本地交互语法；请在宿主中显式选择旧版模式。';
    };
    readonly 'attribute.unknownSuggestion': {
        readonly en: 'Component <{component}> does not support attribute {name}. Did you mean {suggestion}?';
        readonly zh: '组件 <{component}> 不支持属性 {name}。是否想使用 {suggestion}？';
    };
    readonly 'attribute.unknownPlain': {
        readonly en: 'Component <{component}> does not support attribute {name}.';
        readonly zh: '组件 <{component}> 不支持属性 {name}。';
    };
    readonly 'budget.attribute': {
        readonly en: 'Attribute {name} on component <{component}> exceeds the {limit}-character limit.';
        readonly zh: '组件 <{component}> 的属性 {name} 超过 {limit} 个字符的上限。';
    };
    readonly 'attribute.color': {
        readonly en: 'Attribute {name} on component <{component}> must be a standard CSS named color or #RGB/#RRGGBB, got "{value}".';
        readonly zh: '组件 <{component}> 的属性 {name} 必须是标准 CSS 命名颜色或 #RGB/#RRGGBB，当前为“{value}”。';
    };
    readonly 'attribute.required': {
        readonly en: 'Component <{component}> is missing required attribute {name}.';
        readonly zh: '组件 <{component}> 缺少必需属性 {name}。';
    };
    readonly 'label.requiredMissing': {
        readonly en: 'Component <{name}> requires a label.';
        readonly zh: '组件 <{name}> 需要 label。';
    };
    readonly 'label.requiredEmpty': {
        readonly en: 'Component <{name}> label cannot be empty.';
        readonly zh: '组件 <{name}> 的 label 不能为空。';
    };
    readonly 'attribute.static': {
        readonly en: 'Attribute {name} is static and cannot contain interpolations.';
        readonly zh: '属性 {name} 是静态的，不能包含插值。';
    };
    readonly 'host.attributeUnknown': {
        readonly en: 'Component <{component}> does not support attribute {name}.';
        readonly zh: '组件 <{component}> 不支持属性 {name}。';
    };
    readonly 'host.attributeRequired': {
        readonly en: 'Component <{component}> is missing required attribute {name}.';
        readonly zh: '组件 <{component}> 缺少必需属性 {name}。';
    };
    readonly 'host.attributeStatic': {
        readonly en: 'Attribute {name} is static and cannot contain interpolations.';
        readonly zh: '属性 {name} 是静态的，不能包含插值。';
    };
    readonly 'host.attributeType': {
        readonly en: 'Attribute {name} requires a {kind}, got "{value}".';
        readonly zh: '属性 {name} 需要 {kind}，当前为“{value}”。';
    };
    readonly 'host.attributeEnum': {
        readonly en: 'Attribute {name} must be one of {values}, got "{value}".';
        readonly zh: '属性 {name} 必须是 {values} 之一，当前为“{value}”。';
    };
    readonly 'host.attributePattern': {
        readonly en: 'Attribute {name} must match pattern {pattern}.';
        readonly zh: '属性 {name} 必须匹配模式 {pattern}。';
    };
    readonly 'host.attributeInterpolation': {
        readonly en: 'Attribute {name} must be a literal matching {pattern} or one full interpolation.';
        readonly zh: '属性 {name} 必须是匹配 {pattern} 的字面值，或一个完整插值。';
    };
    readonly 'expression.emptyAttribute': {
        readonly en: 'Attribute {name} interpolation cannot be empty.';
        readonly zh: '属性 {name} 的插值不能为空。';
    };
    readonly 'expression.emptyInterpolation': {
        readonly en: 'Interpolation expression cannot be empty.';
        readonly zh: '插值表达式不能为空。';
    };
    readonly 'attribute.numberInvalid': {
        readonly en: 'Attribute {name} requires a number, got "{value}".';
        readonly zh: '属性 {name} 需要数字，当前为“{value}”。';
    };
    readonly 'attribute.numberInterpolationInvalid': {
        readonly en: 'Attribute {name} requires a number or a full number interpolation, got "{value}".';
        readonly zh: '属性 {name} 需要数字或完整的数字插值，当前为“{value}”。';
    };
    readonly 'attribute.integer': {
        readonly en: 'Attribute {name} requires an integer.';
        readonly zh: '属性 {name} 需要整数。';
    };
    readonly 'attribute.positive': {
        readonly en: 'Attribute {name} requires a positive number.';
        readonly zh: '属性 {name} 需要正数。';
    };
    readonly 'attribute.rangeMin': {
        readonly en: 'Attribute {name} must be at least {min}.';
        readonly zh: '属性 {name} 必须至少为 {min}。';
    };
    readonly 'attribute.rangeMax': {
        readonly en: 'Attribute {name} must be at most {max}.';
        readonly zh: '属性 {name} 必须至多为 {max}。';
    };
    readonly 'attribute.booleanInvalid': {
        readonly en: 'Attribute {name} requires true or false.';
        readonly zh: '属性 {name} 需要 true 或 false。';
    };
    readonly 'attribute.booleanInterpolationInvalid': {
        readonly en: 'Attribute {name} requires true or false, or a full boolean interpolation.';
        readonly zh: '属性 {name} 需要 true 或 false，或完整的布尔插值。';
    };
    readonly 'attribute.enumInvalid': {
        readonly en: 'Attribute {name} must be one of {values}, got "{value}".';
        readonly zh: '属性 {name} 必须是 {values} 之一，当前为“{value}”。';
    };
    readonly 'attribute.dateLower': {
        readonly en: 'Date lower bound {value} is not a valid YYYY-MM-DD.';
        readonly zh: '日期下界 {value} 不是有效的 YYYY-MM-DD。';
    };
    readonly 'attribute.dateUpper': {
        readonly en: 'Date upper bound {value} is not a valid YYYY-MM-DD.';
        readonly zh: '日期上界 {value} 不是有效的 YYYY-MM-DD。';
    };
    readonly 'constraint.componentMinMax': {
        readonly en: 'Component <{name}> min cannot exceed max.';
        readonly zh: '组件 <{name}> 的 min 不能大于 max。';
    };
    readonly 'constraint.componentStep': {
        readonly en: 'Component <{name}> step must be greater than 0.';
        readonly zh: '组件 <{name}> 的 step 必须大于 0。';
    };
    readonly 'constraint.lengthRange': {
        readonly en: 'max-length cannot be less than min-length.';
        readonly zh: 'max-length 不能小于 min-length。';
    };
    readonly 'constraint.dateOrder': {
        readonly en: 'Date min cannot be later than max.';
        readonly zh: '日期 min 不能晚于 max。';
    };
    readonly 'constraint.progressRange': {
        readonly en: 'progress value must be between 0 and {max}, got {value}.';
        readonly zh: 'progress 的 value 必须在 0 到 {max} 之间，当前为 {value}。';
    };
    readonly 'constraint.plotRange': {
        readonly en: 'plot min must be less than max.';
        readonly zh: 'plot 的 min 必须小于 max。';
    };
    readonly 'constraint.timerDuration': {
        readonly en: 'timer duration must be a positive whole number of seconds.';
        readonly zh: 'timer 的 duration 必须是正整数秒。';
    };
    readonly 'constraint.rangeSliderOrder': {
        readonly en: 'range-slider min cannot exceed max.';
        readonly zh: 'range-slider 的 min 不能大于 max。';
    };
    readonly 'constraint.rangeSliderStep': {
        readonly en: 'range-slider step must be a finite positive number.';
        readonly zh: 'range-slider 的 step 必须是有限正数。';
    };
    readonly 'constraint.coordinateOrder': {
        readonly en: 'coordinate {axis}-min cannot exceed {axis}-max.';
        readonly zh: 'coordinate 的 {axis}-min 不能大于 {axis}-max。';
    };
    readonly 'constraint.coordinateStep': {
        readonly en: 'coordinate step must be a finite positive number.';
        readonly zh: 'coordinate 的 step 必须是有限正数。';
    };
    readonly 'constraint.multiSelectMax': {
        readonly en: 'multi-select max-selected must be a nonnegative whole number.';
        readonly zh: 'multi-select 的 max-selected 必须是非负整数。';
    };
    readonly 'constraint.quizTolerance': {
        readonly en: '<quiz> tolerance must be a nonnegative finite number.';
        readonly zh: '<quiz> 的 tolerance 必须是非负有限数。';
    };
    readonly 'selection.keyNeedsKey': {
        readonly en: '<{component}> {name} requires a key attribute naming the selection column.';
        readonly zh: '<{component}> 的 {name} 需要 key 属性来指定选择列。';
    };
    readonly 'structure.parent': {
        readonly en: '<{name}> can only appear directly inside {parents}.';
        readonly zh: '<{name}> 只能直接位于 {parents} 内。';
    };
    readonly 'structure.noBody': {
        readonly en: '<{name}> does not accept body content.';
        readonly zh: '<{name}> 不接受正文内容。';
    };
    readonly 'structure.inlineOnly': {
        readonly en: '<{name}> only accepts inline Markdown.';
        readonly zh: '<{name}> 只接受行内 Markdown。';
    };
    readonly 'structure.noNestedComponents': {
        readonly en: 'The body of <{name}> cannot contain other interactive components.';
        readonly zh: '<{name}> 的正文不能包含其他交互组件。';
    };
    readonly 'structure.noComponents': {
        readonly en: 'The body of <{name}> cannot contain interactive components.';
        readonly zh: '<{name}> 的正文不能包含交互组件。';
    };
    readonly 'structure.childrenMinimum': {
        readonly en: '<{name}> requires at least {min} {children}.';
        readonly zh: '<{name}> 至少需要 {min} 个 {children}。';
    };
    readonly 'structure.childrenOnly': {
        readonly en: 'Direct children of <{name}> must be {children}.';
        readonly zh: '<{name}> 的直接子元素必须是 {children}。';
    };
    readonly 'structure.sequenceMinimum': {
        readonly en: '<{name}> requires at least one <{child}>.';
        readonly zh: '<{name}> 至少需要一个 <{child}>。';
    };
    readonly 'structure.sequenceOnly': {
        readonly en: '<{name}> can only contain <{child}>.';
        readonly zh: '<{name}> 只能包含 <{child}>。';
    };
    readonly 'structure.accordionNeedsDisclosure': {
        readonly en: '<accordion> requires at least one <disclosure>.';
        readonly zh: '<accordion> 至少需要一个 <disclosure>。';
    };
    readonly 'structure.accordionOnly': {
        readonly en: '<accordion> can only contain <disclosure>.';
        readonly zh: '<accordion> 只能包含 <disclosure>。';
    };
    readonly 'structure.gridNeedsCard': {
        readonly en: '<grid> requires at least one <card>.';
        readonly zh: '<grid> 至少需要一个 <card>。';
    };
    readonly 'structure.gridOnlyCard': {
        readonly en: 'Direct children of <grid> must be <card>.';
        readonly zh: '<grid> 的直接子元素必须是 <card>。';
    };
    readonly 'structure.exactlyOneTable': {
        readonly en: 'The body of <{name}> must be exactly one Markdown table.';
        readonly zh: '<{name}> 的正文必须恰好是一个 Markdown 表格。';
    };
    readonly 'structure.plotNeedsFormula': {
        readonly en: '<plot> requires at least one $$...$$ formula block.';
        readonly zh: '<plot> 至少需要一个 $$...$$ 公式块。';
    };
    readonly 'structure.plotOnlyFormulas': {
        readonly en: 'The body of <plot> can only contain blank lines and $$...$$ formula blocks.';
        readonly zh: '<plot> 的正文只能包含空行和 $$...$$ 公式块。';
    };
    readonly 'structure.nodeNoComponents': {
        readonly en: 'The description of <node> cannot contain interactive components.';
        readonly zh: '<node> 的描述不能包含交互组件。';
    };
    readonly 'structure.optionsNeeded': {
        readonly en: '<{name}> requires at least one <option value="...">.';
        readonly zh: '<{name}> 至少需要一个 <option value="...">。';
    };
    readonly 'structure.optionsOnly': {
        readonly en: '<{name}> can only contain <option>.';
        readonly zh: '<{name}> 只能包含 <option>。';
    };
    readonly 'budget.options': {
        readonly en: '<{name}> options exceed the limit of {limit}.';
        readonly zh: '<{name}> 的选项数量超过上限 {limit}。';
    };
    readonly 'option.valueRequired': {
        readonly en: '<option> requires a non-empty value.';
        readonly zh: '<option> 需要非空 value。';
    };
    readonly 'option.valueComma': {
        readonly en: '<multi-select> option values cannot contain commas: "{value}".';
        readonly zh: '<multi-select> 的选项值不能包含逗号：“{value}”。';
    };
    readonly 'option.valueDuplicate': {
        readonly en: 'Option values in <{name}> must be unique; duplicate value "{value}".';
        readonly zh: '<{name}> 的选项值必须唯一；重复值“{value}”。';
    };
    readonly 'structure.optionNoComponents': {
        readonly en: 'The body of <option> cannot contain interactive components.';
        readonly zh: '<option> 的正文不能包含交互组件。';
    };
    readonly 'structure.tabsNeedsTab': {
        readonly en: '<tabs> requires at least one <tab>.';
        readonly zh: '<tabs> 至少需要一个 <tab>。';
    };
    readonly 'structure.tabsOnly': {
        readonly en: '<tabs> can only contain <tab>.';
        readonly zh: '<tabs> 只能包含 <tab>。';
    };
    readonly 'tab.valueDuplicate': {
        readonly en: 'Tab values in <tabs> must be unique; duplicate value "{value}".';
        readonly zh: '<tabs> 的标签值必须唯一；重复值“{value}”。';
    };
    readonly 'structure.stepsNeedsStep': {
        readonly en: '<steps> requires at least one <step>.';
        readonly zh: '<steps> 至少需要一个 <step>。';
    };
    readonly 'structure.stepsOnly': {
        readonly en: '<steps> can only contain <step>.';
        readonly zh: '<steps> 只能包含 <step>。';
    };
    readonly 'step.valueDuplicate': {
        readonly en: 'Step values in <steps> must be unique; duplicate value "{value}".';
        readonly zh: '<steps> 的步骤值必须唯一；重复值“{value}”。';
    };
    readonly 'quiz.answerRequired': {
        readonly en: '<quiz> requires a non-empty answer.';
        readonly zh: '<quiz> 需要非空 answer。';
    };
    readonly 'structure.quizNumericNoBody': {
        readonly en: 'A numeric <quiz> cannot have body content; use type="choice" for option-based quizzes.';
        readonly zh: '数值型 <quiz> 不能有正文内容；基于选项的测验请使用 type="choice"。';
    };
    readonly 'quiz.answerNumeric': {
        readonly en: 'A numeric <quiz> answer must be a finite number.';
        readonly zh: '数值型 <quiz> 的 answer 必须是有限数字。';
    };
    readonly 'quiz.answerNotOption': {
        readonly en: '<quiz> answer "{answer}" is not one of the option values: {options}.';
        readonly zh: '<quiz> 的 answer“{answer}”不在选项值中：{options}。';
    };
    readonly 'diagram.needsNode': {
        readonly en: '<diagram> requires at least one <node>.';
        readonly zh: '<diagram> 至少需要一个 <node>。';
    };
    readonly 'structure.diagramOnly': {
        readonly en: '<diagram> can only contain <node> and <edge>.';
        readonly zh: '<diagram> 只能包含 <node> 和 <edge>。';
    };
    readonly 'diagram.nodeInvalid': {
        readonly en: 'Node ID "{id}" may only contain letters, digits, underscores and hyphens, and cannot start with a digit.';
        readonly zh: '节点 ID“{id}”只能包含字母、数字、下划线和连字符，且不能以数字开头。';
    };
    readonly 'diagram.nodeDuplicate': {
        readonly en: 'Duplicate node ID "{id}".';
        readonly zh: '重复的节点 ID“{id}”。';
    };
    readonly 'diagram.edgeFromUnknown': {
        readonly en: 'Edge from references unknown node "{id}".';
        readonly zh: '连线起点引用了未知节点“{id}”。';
    };
    readonly 'diagram.edgeToUnknown': {
        readonly en: 'Edge to references unknown node "{id}".';
        readonly zh: '连线终点引用了未知节点“{id}”。';
    };
    readonly 'diagram.edgeDuplicate': {
        readonly en: 'Duplicate edge: {from} → {to}{label}.';
        readonly zh: '重复的连线：{from} → {to}{label}。';
    };
    readonly 'checklist.bodySingle': {
        readonly en: 'The body of <checklist> must be exactly one single-level Markdown task list.';
        readonly zh: '<checklist> 的正文必须恰好是一个单层 Markdown 任务列表。';
    };
    readonly 'checklist.needsItem': {
        readonly en: '<checklist> requires at least one task list item.';
        readonly zh: '<checklist> 至少需要一个任务列表项。';
    };
    readonly 'budget.checklistItems': {
        readonly en: '<checklist> items exceed the limit of {limit}.';
        readonly zh: '<checklist> 的任务项数量超过上限 {limit}。';
    };
    readonly 'checklist.taskOnly': {
        readonly en: '<checklist> can only contain task list items (- [ ] / - [x]).';
        readonly zh: '<checklist> 只能包含任务列表项（- [ ] / - [x]）。';
    };
    readonly 'checklist.noNested': {
        readonly en: '<checklist> does not support nested lists.';
        readonly zh: '<checklist> 不支持嵌套列表。';
    };
    readonly 'checklist.noComponents': {
        readonly en: '<checklist> items cannot contain interactive components.';
        readonly zh: '<checklist> 的任务项不能包含交互组件。';
    };
    readonly 'budget.identifier': {
        readonly en: 'Parameter name exceeds the {limit}-character limit.';
        readonly zh: '参数名超过 {limit} 个字符的上限。';
    };
    readonly 'binding.nameInvalid': {
        readonly en: 'Parameter name "{name}" must match [A-Za-z_][A-Za-z0-9_]*.';
        readonly zh: '参数名“{name}”必须匹配 [A-Za-z_][A-Za-z0-9_]*。';
    };
    readonly 'binding.reserved': {
        readonly en: 'Parameter name "{name}" is reserved; choose another name.';
        readonly zh: '参数名“{name}”是保留名称；请换一个名称。';
    };
    readonly 'binding.typeConflict': {
        readonly en: 'Parameter "{key}" is already declared as {kind} by <{first}> and cannot also bind <{second}>.';
        readonly zh: '参数“{key}”已由 <{first}> 声明为 {kind}，不能再绑定 <{second}>。';
    };
    readonly 'binding.exclusive': {
        readonly en: 'Parameter "{key}" of <{first}> can only be owned by one component and cannot be shared with <{second}>.';
        readonly zh: '<{first}> 的参数“{key}”只能由一个组件拥有，不能与 <{second}> 共享。';
    };
    readonly 'binding.slotExclusive': {
        readonly en: 'Parameter "{key}" of the {slot} slot of <{name}> is exclusive and cannot be shared with another control.';
        readonly zh: '<{name}> 的 {slot} 槽参数“{key}”是独占的，不能与另一个控件共享。';
    };
    readonly 'binding.constraintConflict': {
        readonly en: 'Parameter "{key}" must use the same numeric range and step: <{first}> has {firstConstraints}, <{second}> has {secondConstraints}.';
        readonly zh: '参数“{key}”必须使用相同的数值范围和步长：<{first}> 为 {firstConstraints}，<{second}> 为 {secondConstraints}。';
    };
    readonly 'binding.optionConflict': {
        readonly en: 'Parameter "{key}" must use the same option set in the same order.';
        readonly zh: '参数“{key}”必须使用相同顺序的同一组选项。';
    };
    readonly 'initial.duplicate': {
        readonly en: 'Parameter "{key}" has multiple explicit initial values ({count} in total).';
        readonly zh: '参数“{key}”有多个显式初值（共 {count} 个）。';
    };
    readonly 'initial.duplicatePeers': {
        readonly en: 'Parameter "{key}" has multiple explicit initial values ({count} in total; see also line {lines}).';
        readonly zh: '参数“{key}”有多个显式初值（共 {count} 个；另见第 {lines} 行）。';
    };
    readonly 'initial.rangeNoStep': {
        readonly en: 'Parameter "{key}" has no valid step value within range [{min}, {max}].';
        readonly zh: '参数“{key}”在范围 [{min}, {max}] 内没有有效的步长值。';
    };
    readonly 'initial.cannotDerive': {
        readonly en: 'Cannot derive a default initial value for <{name}> parameter "{key}".';
        readonly zh: '无法为 <{name}> 的参数“{key}”推导默认初值。';
    };
    readonly 'initial.typeFiniteNumber': {
        readonly en: 'Initial value of parameter "{key}" must be a finite number.';
        readonly zh: '参数“{key}”的初值必须是有限数字。';
    };
    readonly 'initial.belowMin': {
        readonly en: 'Initial value {value} of parameter "{key}" is below the minimum {min}.';
        readonly zh: '参数“{key}”的初值 {value} 小于最小值 {min}。';
    };
    readonly 'initial.aboveMax': {
        readonly en: 'Initial value {value} of parameter "{key}" exceeds the maximum {max}.';
        readonly zh: '参数“{key}”的初值 {value} 超过最大值 {max}。';
    };
    readonly 'initial.offStep': {
        readonly en: 'Initial value {value} of parameter "{key}" is not on step {step} (based at {base}).';
        readonly zh: '参数“{key}”的初值 {value} 不在步长 {step} 上（基准 {base}）。';
    };
    readonly 'initial.typeBoolean': {
        readonly en: 'Initial value of parameter "{key}" must be a boolean.';
        readonly zh: '参数“{key}”的初值必须是布尔值。';
    };
    readonly 'initial.notAmongOptions': {
        readonly en: 'Initial value "{value}" of parameter "{key}" is not among the available values {options}.';
        readonly zh: '参数“{key}”的初值“{value}”不在可用值 {options} 中。';
    };
    readonly 'initial.typeWrong': {
        readonly en: 'Initial value of parameter "{name}" has the wrong type.';
        readonly zh: '参数“{name}”的初值类型不正确。';
    };
    readonly 'initial.typeCollection': {
        readonly en: 'Initial value of parameter "{key}" must be a JSON array.';
        readonly zh: '参数“{key}”的初值必须是 JSON 数组。';
    };
    readonly 'initial.typeStringArray': {
        readonly en: 'Initial value of parameter "{key}" must be an array of strings.';
        readonly zh: '参数“{key}”的初值必须是字符串数组。';
    };
    readonly 'initial.typeNumberArray': {
        readonly en: 'Initial value of parameter "{key}" must be an array of finite numbers.';
        readonly zh: '参数“{key}”的初值必须是有限数字组成的数组。';
    };
    readonly 'initial.maxItems': {
        readonly en: 'Initial value of parameter "{key}" exceeds the limit of {max} items.';
        readonly zh: '参数“{key}”的初值超过 {max} 项的上限。';
    };
    readonly 'initial.dateInvalid': {
        readonly en: 'Initial date "{value}" is not a valid YYYY-MM-DD.';
        readonly zh: '初值日期“{value}”不是有效的 YYYY-MM-DD。';
    };
    readonly 'initial.notAvailableOption': {
        readonly en: 'Initial value "{value}" is not an available option: {options}.';
        readonly zh: '初值“{value}”不是可用选项：{options}。';
    };
    readonly 'initial.multiSelectOption': {
        readonly en: 'Initial value "{value}" of parameter "{key}" is not an option of <multi-select>.';
        readonly zh: '参数“{key}”的初值“{value}”不是 <multi-select> 的选项。';
    };
    readonly 'initial.rangeSliderOrder': {
        readonly en: '<range-slider> start {start} cannot be greater than end {end}.';
        readonly zh: '<range-slider> 的 start {start} 不能大于 end {end}。';
    };
    readonly 'initial.slotBelowMin': {
        readonly en: 'Initial value {value} of <{name}> {slot} is below the minimum {min}.';
        readonly zh: '<{name}> 的 {slot} 初值 {value} 小于最小值 {min}。';
    };
    readonly 'initial.slotAboveMax': {
        readonly en: 'Initial value {value} of <{name}> {slot} exceeds the maximum {max}.';
        readonly zh: '<{name}> 的 {slot} 初值 {value} 超过最大值 {max}。';
    };
    readonly 'initial.slotOffStep': {
        readonly en: 'Initial value {value} of <{name}> {slot} is not on step {step} (based at {base}).';
        readonly zh: '<{name}> 的 {slot} 初值 {value} 不在步长 {step} 上（基准 {base}）。';
    };
    readonly 'initial.lengthBelow': {
        readonly en: 'Initial value of parameter "{key}" has length {length}, below the minimum length {min} required by <{name}>.';
        readonly zh: '参数“{key}”的初值长度为 {length}，小于 <{name}> 要求的最小长度 {min}。';
    };
    readonly 'initial.lengthAbove': {
        readonly en: 'Initial value of parameter "{key}" has length {length}, exceeding the maximum length {max} allowed by <{name}>.';
        readonly zh: '参数“{key}”的初值长度为 {length}，超过 <{name}> 允许的最大长度 {max}。';
    };
    readonly 'initial.email': {
        readonly en: 'Initial value of parameter "{key}" is not a valid email address.';
        readonly zh: '参数“{key}”的初值不是有效的电子邮件地址。';
    };
    readonly 'initial.dateBelow': {
        readonly en: 'Initial value {value} of parameter "{key}" is earlier than the minimum date {min} of <date>.';
        readonly zh: '参数“{key}”的初值 {value} 早于 <date> 的最小日期 {min}。';
    };
    readonly 'initial.dateAbove': {
        readonly en: 'Initial value {value} of parameter "{key}" is later than the maximum date {max} of <date>.';
        readonly zh: '参数“{key}”的初值 {value} 晚于 <date> 的最大日期 {max}。';
    };
    readonly 'initial.multiSelectExceeds': {
        readonly en: 'Initial values of <multi-select> exceed max-selected {max}.';
        readonly zh: '<multi-select> 的初值数量超过 max-selected {max}。';
    };
    readonly 'expression.error': {
        readonly en: 'Expression error: {detail}';
        readonly zh: '表达式错误：{detail}';
    };
    readonly 'binding.unknownSuggestion': {
        readonly en: 'Reference to undeclared parameter {name}. Did you mean {suggestion}?';
        readonly zh: '引用了未声明的参数 {name}。是否想使用 {suggestion}？';
    };
    readonly 'binding.unknownPlain': {
        readonly en: 'Reference to undeclared parameter {name}.';
        readonly zh: '引用了未声明的参数 {name}。';
    };
    readonly 'type.number': {
        readonly en: 'Expected a number here, but the expression evaluates to {kind}.';
        readonly zh: '此处需要数字，但表达式结果为 {kind}。';
    };
    readonly 'type.boolean': {
        readonly en: 'Expected a boolean here, but the expression evaluates to {kind}.';
        readonly zh: '此处需要布尔值，但表达式结果为 {kind}。';
    };
    readonly 'type.string': {
        readonly en: 'Expected a string here, but the expression evaluates to {kind}.';
        readonly zh: '此处需要字符串，但表达式结果为 {kind}。';
    };
    readonly 'type.arrayNoDisplay': {
        readonly en: 'Arrays cannot be displayed directly; convert them first with a function such as len.';
        readonly zh: '数组不能直接显示；请先用 len 等函数转换。';
    };
    readonly 'attribute.fullInterpolation': {
        readonly en: 'The {name} attribute of <{component}> must be a full interpolation.';
        readonly zh: '<{component}> 的 {name} 属性必须是完整插值。';
    };
    readonly 'anchor.idInvalid': {
        readonly en: 'Anchor id "{id}" must match [A-Za-z_][A-Za-z0-9_-]*.';
        readonly zh: '锚点 id“{id}”必须匹配 [A-Za-z_][A-Za-z0-9_-]*。';
    };
    readonly 'anchor.duplicate': {
        readonly en: 'Duplicate anchor id "{id}".';
        readonly zh: '重复的锚点 id“{id}”。';
    };
    readonly 'anchor.headingCollision': {
        readonly en: 'Anchor id "{id}" collides with an automatic heading target.';
        readonly zh: '锚点 id“{id}”与自动标题目标冲突。';
    };
    readonly 'jump.empty': {
        readonly en: '<jump> target cannot be empty.';
        readonly zh: '<jump> 的目标不能为空。';
    };
    readonly 'jump.badTarget': {
        readonly en: '<jump> target "{target}" must be a bare heading slug or anchor id without "#" or whitespace.';
        readonly zh: '<jump> 的目标“{target}”必须是不含“#”或空白的标题 slug 或锚点 id。';
    };
    readonly 'jump.unresolved': {
        readonly en: '<jump> target "{target}" does not resolve to a heading or explicit anchor in this document.';
        readonly zh: '<jump> 的目标“{target}”无法解析到本文档中的标题或显式锚点。';
    };
    readonly 'budget.plotCurves': {
        readonly en: '<plot> supports at most {limit} curves, but has {count}.';
        readonly zh: '<plot> 最多支持 {limit} 条曲线，当前有 {count} 条。';
    };
    readonly 'budget.plotPoints': {
        readonly en: "The document's total plot sample count exceeds the limit of {limit}.";
        readonly zh: '文档的绘图采样点总数超过上限 {limit}。';
    };
    readonly 'math.formulaShape': {
        readonly en: '<plot> formulas must be an equation: y = f(x), a parametric cases block, or an implicit equation in x and y.';
        readonly zh: '<plot> 的公式必须是方程：y = f(x)、参数方程 cases 块，或关于 x 和 y 的隐式方程。';
    };
    readonly 'math.computeFailed': {
        readonly en: 'Cannot compute plot formula: {detail}';
        readonly zh: '无法计算绘图公式（错误代码 {code}）：{detail}';
    };
    readonly 'math.bindingUnknown': {
        readonly en: 'Plot formula references undeclared parameter "{name}".';
        readonly zh: '绘图公式引用了未声明的参数“{name}”。';
    };
    readonly 'math.bindingType': {
        readonly en: 'Plot parameter "{name}" must be a number, but is {kind}.';
        readonly zh: '绘图参数“{name}”必须是数字，但当前为 {kind}。';
    };
    readonly 'math.displayUnsupportedCommand': {
        readonly en: 'Formula command \\{name} is not supported; it is displayed as literal text.';
        readonly zh: '公式命令 \\{name} 不受支持；已按原文显示。';
    };
    readonly 'math.displayUnsupportedEnvironment': {
        readonly en: 'Formula environment {name} is not supported; it is displayed as literal text.';
        readonly zh: '公式环境 {name} 不受支持；已按原文显示。';
    };
    readonly 'math.displayBudget': {
        readonly en: 'Formula exceeds a display resource limit ({limit}); it is displayed as literal text.';
        readonly zh: '公式超过显示资源上限（{limit}）；已按原文显示。';
    };
    readonly 'math.displayStrayEnd': {
        readonly en: 'Formula has an unmatched \\end; it is displayed as literal text.';
        readonly zh: '公式中存在未匹配的 \\end；已按原文显示。';
    };
    readonly 'math.displayEnvironmentUnclosed': {
        readonly en: 'Formula environment {name} is missing its closing brace; it is displayed as literal text.';
        readonly zh: '公式环境 {name} 缺少结束花括号；已按原文显示。';
    };
    readonly 'math.displayEnvironmentMissingName': {
        readonly en: 'Formula environment is missing its name; \\begin is displayed as literal text.';
        readonly zh: '公式环境缺少名称；\\begin 已按原文显示。';
    };
    readonly 'math.displaySyntax': {
        readonly en: 'Formula structure cannot be displayed and is shown as literal text.';
        readonly zh: '公式结构无法显示，已按原文显示。';
    };
    readonly 'table.missingHeader': {
        readonly en: 'The table for <{name}> is missing a header.';
        readonly zh: '<{name}> 的表格缺少表头。';
    };
    readonly 'table.headerInterpolation': {
        readonly en: 'Table headers cannot contain interpolations.';
        readonly zh: '表格表头不能包含插值。';
    };
    readonly 'table.headerEmpty': {
        readonly en: 'Table headers cannot be empty.';
        readonly zh: '表格表头不能为空。';
    };
    readonly 'table.headerDuplicate': {
        readonly en: 'Duplicate table header "{name}".';
        readonly zh: '重复的表格表头“{name}”。';
    };
    readonly 'table.rowColumnMismatch': {
        readonly en: 'Table row has a different column count: header has {header} columns, this row has {row}.';
        readonly zh: '表格行的列数不一致：表头有 {header} 列，此行有 {row} 列。';
    };
    readonly 'chart.numericExpression': {
        readonly en: 'Chart column "{name}" requires a number in row {row}, but the expression evaluates to {kind}.';
        readonly zh: '图表列“{name}”第 {row} 行需要数字，但表达式结果为 {kind}。';
    };
    readonly 'timeline.numericExpression': {
        readonly en: 'Timeline column "{name}" requires a number in row {row}, but the expression evaluates to {kind}.';
        readonly zh: '时间线列“{name}”第 {row} 行需要数字，但表达式结果为 {kind}。';
    };
    readonly 'chart.numericPlain': {
        readonly en: 'Chart column "{name}" requires a plain number in row {row}, got "{value}".';
        readonly zh: '图表列“{name}”第 {row} 行需要普通数字，当前为“{value}”。';
    };
    readonly 'timeline.numericPlain': {
        readonly en: 'Timeline column "{name}" requires a plain number in row {row}, got "{value}".';
        readonly zh: '时间线列“{name}”第 {row} 行需要普通数字，当前为“{value}”。';
    };
    readonly 'selection.keyEmpty': {
        readonly en: '<{component}> key cannot be empty.';
        readonly zh: '<{component}> 的 key 不能为空。';
    };
    readonly 'selection.keyMissingColumn': {
        readonly en: '<{component}> key column "{name}" does not exist in its table.';
        readonly zh: '<{component}> 的 key 列“{name}”在表格中不存在。';
    };
    readonly 'selection.keyInterpolation': {
        readonly en: '<{component}> key column "{name}" must contain static text; row {row} contains an interpolation.';
        readonly zh: '<{component}> 的 key 列“{name}”必须包含静态文本；第 {row} 行包含插值。';
    };
    readonly 'selection.keyEmptyCell': {
        readonly en: '<{component}> key column "{name}" cannot be empty in row {row}.';
        readonly zh: '<{component}> 的 key 列“{name}”在第 {row} 行不能为空。';
    };
    readonly 'selection.keyDuplicate': {
        readonly en: '<{component}> key column "{name}" must be unique; duplicate value "{value}".';
        readonly zh: '<{component}> 的 key 列“{name}”必须唯一；重复值“{value}”。';
    };
    readonly 'initial.selectionNotValue': {
        readonly en: 'Initial selection "{value}" of <{component}> is not a value of key column "{name}".';
        readonly zh: '<{component}> 的初始选择“{value}”不是 key 列“{name}”中的值。';
    };
    readonly 'chart.columnComma': {
        readonly en: 'Chart column names cannot contain commas: "{name}".';
        readonly zh: '图表列名不能包含逗号：“{name}”。';
    };
    readonly 'chart.xMissing': {
        readonly en: 'Chart x column "{name}" does not exist.';
        readonly zh: '图表 x 列“{name}”不存在。';
    };
    readonly 'chart.yRequired': {
        readonly en: 'Chart y requires a column name.';
        readonly zh: '图表 y 需要列名。';
    };
    readonly 'chart.yMissing': {
        readonly en: 'Chart y column "{name}" does not exist.';
        readonly zh: '图表 y 列“{name}”不存在。';
    };
    readonly 'chart.needsNumeric': {
        readonly en: 'Chart requires at least one numeric column.';
        readonly zh: '图表至少需要一个数值列。';
    };
    readonly 'chart.scatterXMissing': {
        readonly en: 'Scatter chart x column "{name}" does not exist.';
        readonly zh: '散点图的 x 列“{name}”不存在。';
    };
    readonly 'chart.scatterNeedsNumeric': {
        readonly en: 'Scatter chart requires at least one numeric column.';
        readonly zh: '散点图至少需要一个数值列。';
    };
    readonly 'chart.donutNeedsColumns': {
        readonly en: 'Donut chart requires a label column and a value column.';
        readonly zh: '环形图需要一个标签列和一个数值列。';
    };
    readonly 'chart.donutYOne': {
        readonly en: 'Donut chart y can only specify one numeric column.';
        readonly zh: '环形图的 y 只能指定一个数值列。';
    };
    readonly 'chart.donutNeedY': {
        readonly en: 'A donut chart with more than two columns must use y to specify the single numeric column.';
        readonly zh: '超过两列的环形图必须用 y 指定唯一的数值列。';
    };
    readonly 'chart.negative': {
        readonly en: 'Donut chart values cannot be negative; row {row} is {value}.';
        readonly zh: '环形图的数值不能为负；第 {row} 行为 {value}。';
    };
    readonly 'timeline.headerMissing': {
        readonly en: 'Timeline requires either Task, Start and Duration columns or 事项, 开始 and 时长 columns, with optional Notes or 说明.';
        readonly zh: '时间线需要 Task、Start、Duration 列，或 事项、开始、时长 列，并可选 Notes 或 说明。';
    };
    readonly 'timeline.columnUnsupported': {
        readonly en: 'Timeline does not support column "{name}".';
        readonly zh: '时间线不支持列“{name}”。';
    };
    readonly 'timeline.negative': {
        readonly en: 'Timeline column "{name}" cannot be negative in row {row}.';
        readonly zh: '时间线列“{name}”在第 {row} 行不能为负。';
    };
    readonly 'runtime.bindingNoWritable': {
        readonly en: 'This component has no writable binding state.';
        readonly zh: '此组件没有可写的绑定状态。';
    };
    readonly 'runtime.bindingNeedsSlot': {
        readonly en: 'This multi-slot component requires a slot such as start/end or x/y.';
        readonly zh: '此多槽组件需要 start/end 或 x/y 之类的槽位。';
    };
    readonly 'runtime.bindingUnknownSlot': {
        readonly en: 'This component has no writable slot "{slot}".';
        readonly zh: '此组件没有可写的槽位“{slot}”。';
    };
    readonly 'runtime.bindingNoMultiSlot': {
        readonly en: 'This component does not support multiple slots.';
        readonly zh: '此组件不支持多个槽位。';
    };
    readonly 'runtime.dateInvalid': {
        readonly en: 'Date must be a valid YYYY-MM-DD or an empty string.';
        readonly zh: '日期必须是有效的 YYYY-MM-DD 或空字符串。';
    };
    readonly 'runtime.dateRequired': {
        readonly en: 'This date is required.';
        readonly zh: '此日期为必填项。';
    };
    readonly 'runtime.dateEarlier': {
        readonly en: 'Date cannot be earlier than {min}.';
        readonly zh: '日期不能早于 {min}。';
    };
    readonly 'runtime.dateLater': {
        readonly en: 'Date cannot be later than {max}.';
        readonly zh: '日期不能晚于 {max}。';
    };
    readonly 'runtime.fieldRequired': {
        readonly en: 'This field is required.';
        readonly zh: '此字段为必填项。';
    };
    readonly 'runtime.minLength': {
        readonly en: 'At least {min} characters.';
        readonly zh: '至少 {min} 个字符。';
    };
    readonly 'runtime.maxLength': {
        readonly en: 'At most {max} characters.';
        readonly zh: '至多 {max} 个字符。';
    };
    readonly 'runtime.emailLength': {
        readonly en: 'Email address cannot exceed {limit} characters.';
        readonly zh: '电子邮件地址不能超过 {limit} 个字符。';
    };
    readonly 'runtime.emailInvalid': {
        readonly en: 'Enter a valid email address.';
        readonly zh: '请输入有效的电子邮件地址。';
    };
    readonly 'runtime.finiteNumber': {
        readonly en: 'Parameter "{name}" requires a finite number.';
        readonly zh: '参数“{name}”需要有限数字。';
    };
    readonly 'runtime.min': {
        readonly en: 'Parameter "{name}" must be at least {min}.';
        readonly zh: '参数“{name}”必须至少为 {min}。';
    };
    readonly 'runtime.max': {
        readonly en: 'Parameter "{name}" must be at most {max}.';
        readonly zh: '参数“{name}”必须至多为 {max}。';
    };
    readonly 'runtime.step': {
        readonly en: 'Parameter "{name}" must be a multiple of step {step} (base {base}).';
        readonly zh: '参数“{name}”必须是步长 {step} 的倍数（基准 {base}）。';
    };
    readonly 'runtime.boolean': {
        readonly en: 'Parameter "{name}" requires a boolean.';
        readonly zh: '参数“{name}”需要布尔值。';
    };
    readonly 'runtime.string': {
        readonly en: 'Parameter "{name}" requires a string.';
        readonly zh: '参数“{name}”需要字符串。';
    };
    readonly 'runtime.array': {
        readonly en: 'Parameter "{name}" requires an array of strings.';
        readonly zh: '参数“{name}”需要字符串数组。';
    };
    readonly 'runtime.arrayMembers': {
        readonly en: 'Parameter "{name}" members must be strings.';
        readonly zh: '参数“{name}”的成员必须是字符串。';
    };
    readonly 'runtime.numberArray': {
        readonly en: 'Parameter "{name}" requires an array of finite numbers.';
        readonly zh: '参数“{name}”需要有限数字数组。';
    };
    readonly 'runtime.numberArrayMembers': {
        readonly en: 'Parameter "{name}" members must be finite numbers.';
        readonly zh: '参数“{name}”的成员必须是有限数字。';
    };
    readonly 'runtime.null': {
        readonly en: 'Parameter "{name}" requires null.';
        readonly zh: '参数“{name}”需要 null。';
    };
    readonly 'runtime.checklistOption': {
        readonly en: 'Checklist item "{value}" does not exist.';
        readonly zh: '清单项“{value}”不存在。';
    };
    readonly 'runtime.maxItems': {
        readonly en: 'Parameter "{name}" allows at most {max} selected values.';
        readonly zh: '参数“{name}”最多允许选择 {max} 个值。';
    };
    readonly 'runtime.unsupportedType': {
        readonly en: 'Parameter "{name}" has an unsupported value type.';
        readonly zh: '参数“{name}”的值类型不受支持。';
    };
    readonly 'runtime.option': {
        readonly en: 'Value "{value}" is not among the options: {options}.';
        readonly zh: '值“{value}”不在选项中：{options}。';
    };
    readonly 'runtime.budget': {
        readonly en: 'Parameter "{name}": {detail}';
        readonly zh: '参数“{name}”：{detail}';
    };
    readonly 'runtime.rangeOrder': {
        readonly en: 'The range start cannot be greater than its end.';
        readonly zh: '范围起点不能大于终点。';
    };
    readonly 'budget.string': {
        readonly en: 'String exceeds the {limit}-character limit.';
        readonly zh: '字符串超过 {limit} 个字符的上限。';
    };
    readonly 'budget.array': {
        readonly en: 'Array exceeds the {limit}-item limit.';
        readonly zh: '数组超过 {limit} 个项的上限。';
    };
    readonly 'budget.arrayMember': {
        readonly en: 'Array member exceeds the {limit}-character limit.';
        readonly zh: '数组成员超过 {limit} 个字符的上限。';
    };
    readonly 'budget.arrayContents': {
        readonly en: 'Array contents exceed the {limit}-character limit.';
        readonly zh: '数组内容超过 {limit} 个字符的上限。';
    };
    readonly 'theme.missing': {
        readonly en: 'Theme "{name}" is not registered by the host; using the default theme.';
        readonly zh: '宿主未注册主题“{name}”；将使用默认主题。';
    };
    readonly 'theme.registryUnreadable': {
        readonly en: 'The host theme registry could not be read; using the default theme.';
        readonly zh: '无法读取宿主主题注册表；将使用默认主题。';
    };
    readonly 'theme.invalidDefinition': {
        readonly en: 'The selected theme "{name}" is not a valid definition; using the default theme.';
        readonly zh: '所选主题“{name}”不是有效定义；将使用默认主题。';
    };
    readonly 'theme.duplicateRegistration': {
        readonly en: 'Theme "{name}" is registered more than once; using the default theme.';
        readonly zh: '主题“{name}”被多次注册；将使用默认主题。';
    };
    readonly 'theme.protocol': {
        readonly en: 'Theme "{name}" does not support the {protocol} protocol; using the default theme.';
        readonly zh: '主题“{name}”不支持 {protocol} 协议；将使用默认主题。';
    };
    readonly 'theme.modes': {
        readonly en: 'Theme "{name}" must supply both light and dark color schemes; using the default theme.';
        readonly zh: '主题“{name}”必须同时提供浅色和深色配色；将使用默认主题。';
    };
    readonly 'theme.selectedUnreadable': {
        readonly en: 'The selected theme "{name}" could not be read; using the default theme.';
        readonly zh: '所选主题“{name}”无法读取；将使用默认主题。';
    };
    readonly 'error.expression-syntax': {
        readonly en: 'Check expression operators, parentheses and arguments.';
        readonly zh: '表达式语法不正确，请检查运算符、括号或参数是否完整。';
    };
    readonly 'error.expression-index': {
        readonly en: 'An array index must be a finite safe integer.';
        readonly zh: '数组索引必须为有限的安全整数。';
    };
    readonly 'error.expression-cycle': {
        readonly en: 'Named calculations contain a dependency cycle.';
        readonly zh: '命名计算中存在循环依赖。';
    };
    readonly 'error.array.homogeneous': {
        readonly en: 'Array elements must all be strings or all be numbers.';
        readonly zh: '数组元素必须全部为字符串或全部为数字。';
    };
    readonly 'error.array.finite': {
        readonly en: 'Array members must be finite numbers.';
        readonly zh: '数字数组元素必须为有限数值。';
    };
    readonly 'error.array.members': {
        readonly en: 'Array members must be strings or finite numbers.';
        readonly zh: '数组元素必须为字符串或有限数值。';
    };
    readonly 'error.expression-number': {
        readonly en: 'A numeric literal must be finite and valid.';
        readonly zh: '数字字面量无效，必须是有限数值。';
    };
    readonly 'error.expression-string': {
        readonly en: 'Check the string quotes and escape sequences.';
        readonly zh: '字符串格式不正确，请检查引号和转义。';
    };
    readonly 'error.expression-budget': {
        readonly en: 'The expression exceeded a resource budget.';
        readonly zh: '表达式超过长度、节点、深度或求值步数预算，请简化表达式。';
    };
    readonly 'error.expression-assignment': {
        readonly en: 'Assignment is not allowed in expressions.';
        readonly zh: '表达式不能执行赋值，请使用比较运算符。';
    };
    readonly 'error.expression-property': {
        readonly en: 'Property access is not allowed.';
        readonly zh: '表达式不支持属性访问，请直接引用绑定名称。';
    };
    readonly 'error.expression-empty': {
        readonly en: 'An expression is required.';
        readonly zh: '此处需要非空表达式。';
    };
    readonly 'error.expression-unknown-function': {
        readonly en: 'Use a supported built-in function.';
        readonly zh: '函数不受支持，请使用语言内置函数。';
    };
    readonly 'error.expression-arity': {
        readonly en: 'Check the function argument count.';
        readonly zh: '函数参数数量不正确。';
    };
    readonly 'error.expression-forbidden-name': {
        readonly en: 'The name is forbidden.';
        readonly zh: '此名称属于禁止访问的名称，请使用已声明的绑定。';
    };
    readonly 'error.expression-type': {
        readonly en: 'Operand or argument types do not match.';
        readonly zh: '操作数或函数参数的类型不匹配，请检查绑定类型。';
    };
    readonly 'error.expression-unknown-name': {
        readonly en: 'The binding is not declared.';
        readonly zh: '引用了未声明的绑定。';
    };
    readonly 'error.expression-value': {
        readonly en: 'The binding value is not supported.';
        readonly zh: '绑定值不符合表达式支持的类型或数值范围。';
    };
    readonly 'error.expression-eval': {
        readonly en: 'The expression cannot be evaluated.';
        readonly zh: '表达式无法求值，请检查输入和运算条件。';
    };
    readonly 'error.expression-domain': {
        readonly en: 'A value lies outside the function domain.';
        readonly zh: '参数超出函数定义域。';
    };
    readonly 'error.expression-divide-by-zero': {
        readonly en: 'Division by zero is undefined.';
        readonly zh: '除数不能为零。';
    };
    readonly 'error.expression-interpolation': {
        readonly en: 'Check interpolation delimiters and content.';
        readonly zh: '插值格式不正确，请检查分隔符和表达式内容。';
    };
    readonly 'error.latex-budget': {
        readonly en: 'The formula exceeded a resource budget.';
        readonly zh: '公式超过长度、记号、节点、深度或计算步数预算，请简化公式。';
    };
    readonly 'error.latex-syntax': {
        readonly en: 'Check formula syntax and delimiters.';
        readonly zh: '公式语法不正确，请检查命令、括号和分隔符。';
    };
    readonly 'error.latex-empty': {
        readonly en: 'A formula is required.';
        readonly zh: '公式不能为空。';
    };
    readonly 'error.latex-relation': {
        readonly en: 'Check the formula relation.';
        readonly zh: '公式中的关系式不符合计算语法。';
    };
    readonly 'error.latex-number': {
        readonly en: 'A formula number must be finite.';
        readonly zh: '公式中的数字必须是有限数值。';
    };
    readonly 'error.latex-name': {
        readonly en: 'Use a valid formula parameter name.';
        readonly zh: '公式参数名称无效，请使用合法绑定名。';
    };
    readonly 'error.latex-unsupported': {
        readonly en: 'The LaTeX structure is not computable.';
        readonly zh: '此 LaTeX 结构不支持计算，请改用支持的函数和运算。';
    };
    readonly 'error.latex-variable': {
        readonly en: 'A numeric formula parameter is missing or invalid.';
        readonly zh: '公式引用的参数缺失或不是有限数字。';
    };
    readonly 'error.latex-type': {
        readonly en: 'A formula parameter has the wrong type.';
        readonly zh: '公式参数类型不正确，计算参数必须为数字。';
    };
    readonly 'error.latex-divide-by-zero': {
        readonly en: 'Division by zero is undefined.';
        readonly zh: '公式中的除数不能为零。';
    };
    readonly 'error.latex-domain': {
        readonly en: 'A formula value lies outside the function domain.';
        readonly zh: '公式参数超出函数定义域。';
    };
    readonly 'error.latex-undefined': {
        readonly en: 'The formula is undefined at this point.';
        readonly zh: '公式在此点没有有限定义值。';
    };
    readonly 'error.latex-plot-range': {
        readonly en: 'Plot bounds must be finite and increasing.';
        readonly zh: '绘图区间必须由有限数值构成，且最小值小于最大值。';
    };
    readonly 'error.latex-plot-samples': {
        readonly en: 'The sample count must be an integer from 2 to 2000.';
        readonly zh: '采样点数必须为 2 至 2000 的整数。';
    };
    readonly 'local.external.placement': {
        readonly en: '<external> declarations must be standalone tags at the document top level.';
        readonly zh: '<external> 声明必须独占一行，位于文档顶层。';
    };
    readonly 'local.external.name': {
        readonly en: 'External name "{name}" must match [A-Za-z_][A-Za-z0-9_]*.';
        readonly zh: '外部名称“{name}”必须匹配 [A-Za-z_][A-Za-z0-9_]*。';
    };
    readonly 'local.external.reserved': {
        readonly en: 'External name "{name}" is reserved; choose another name.';
        readonly zh: '外部名称“{name}”为保留名称，请更换。';
    };
    readonly 'local.external.duplicate': {
        readonly en: 'External name "{name}" is declared more than once.';
        readonly zh: '外部名称“{name}”被重复声明。';
    };
    readonly 'local.external.conflict': {
        readonly en: 'External name "{name}" conflicts with a control parameter of the same name.';
        readonly zh: '外部名称“{name}”与同名控件参数冲突。';
    };
    readonly 'local.external.type': {
        readonly en: 'External "{name}" must declare type string, number, boolean, string-array or number-array.';
        readonly zh: '外部声明“{name}”必须声明 string、number、boolean、string-array 或 number-array 类型。';
    };
    readonly 'local.host.structure.leaf': {
        readonly en: 'Host component <{component}> is a leaf and cannot have body content.';
        readonly zh: '宿主组件 <{component}> 是叶子组件，不能包含正文内容。';
    };
    readonly 'local.runtime.external': {
        readonly en: 'External value {name} cannot be written.';
        readonly zh: '无法写入外部数据 {name}。';
    };
    readonly 'local.runtime.external-value': {
        readonly en: 'External value {name} must be {kind}.';
        readonly zh: '外部数据 {name} 必须是 {kind} 类型。';
    };
    readonly 'local.runtime.external-budget': {
        readonly en: 'External value {name} exceeds a resource limit.';
        readonly zh: '外部数据 {name} 超过资源限制。';
    };
    readonly 'local.runtime.value.constraint': {
        readonly en: 'Dynamic {attribute} constraint failed for parameter {name}.';
        readonly zh: '参数 {name} 的动态 {attribute} 约束无法计算。';
    };
    readonly 'local.runtime.value.constraint-range': {
        readonly en: 'Dynamic constraints for parameter {name} produce an invalid range.';
        readonly zh: '参数 {name} 的动态约束产生无效范围。';
    };
    readonly 'local.runtime.value.constraint-date': {
        readonly en: 'Dynamic {attribute} date bound for parameter {name} is not a valid YYYY-MM-DD value.';
        readonly zh: '参数 {name} 的动态 {attribute} 日期边界不是合法的 YYYY-MM-DD。';
    };
};
export type LocalDiagnosticMessageKey = keyof typeof LOCAL_DIAGNOSTIC_MESSAGES;
export declare const LOCAL_DIAGNOSTIC_TEMPLATE_ALIASES: {
    readonly 'local.options.invalid.object': 'options.notObject';
    readonly 'local.options.invalid.limits': 'options.limitsNotObject';
    readonly 'local.options.invalid.max-syntax-nodes': 'options.maxSyntaxNodes';
    readonly 'local.options.invalid.max-parse-work': 'options.maxParseWork';
    readonly 'local.options.invalid.max-markdown-depth': 'options.maxMarkdownDepth';
    readonly 'local.options.invalid.limits-unknown': 'options.unknownLimit';
    readonly 'local.options.invalid.host-components': 'options.hostComponents';
    readonly 'local.budget.document': 'budget.document';
    readonly 'local.budget.nodes': 'budget.syntaxNodes';
    readonly 'local.budget.parse-work': 'budget.parseWork';
    readonly 'local.budget.markdown-depth': 'budget.markdownDepth';
    readonly 'local.budget.nesting': 'budget.nesting';
    readonly 'local.budget.name.attribute': 'budget.attributeName';
    readonly 'local.budget.name.tag': 'budget.tagName';
    readonly 'local.budget.math': 'budget.math';
    readonly 'local.budget.attribute': 'budget.attribute';
    readonly 'local.budget.array.options': 'budget.options';
    readonly 'local.budget.array.checklist': 'budget.checklistItems';
    readonly 'local.budget.identifier': 'budget.identifier';
    readonly 'local.budget.plot.curves': 'budget.plotCurves';
    readonly 'local.budget.plot.points': 'budget.plotPoints';
    readonly 'local.budget.value.string': 'budget.string';
    readonly 'local.budget.value.array': 'budget.array';
    readonly 'local.budget.value.array-member': 'budget.arrayMember';
    readonly 'local.budget.value.array-contents': 'budget.arrayContents';
    readonly 'local.capability.html': 'capability.html';
    readonly 'local.capability.plot': 'capability.plot';
    readonly 'local.parse.source': 'parse.sourceType';
    readonly 'local.parse.markdown': 'parse.markdownFailed';
    readonly 'local.parse.document': 'parse.failed';
    readonly 'local.legacy': 'legacy.fence';
    readonly 'local.theme.expression': 'theme.expression';
    readonly 'local.theme.name.missing': 'theme.nameRequired';
    readonly 'local.theme.attribute': 'theme.attributeOnly';
    readonly 'local.theme.name.invalid': 'theme.nameInvalid';
    readonly 'local.theme.name': 'theme.nameInvalid';
    readonly 'local.theme.malformed.unclosed': 'theme.malformedMissingClose';
    readonly 'local.theme.malformed.closing': 'theme.malformedClosing';
    readonly 'local.theme.malformed.placement': 'theme.malformedStandalone';
    readonly 'local.theme.duplicate.declaration': 'theme.duplicateDeclaration';
    readonly 'local.theme.duplicate': 'theme.duplicateRegistration';
    readonly 'local.theme.late': 'theme.late';
    readonly 'local.theme.nested': 'theme.nested';
    readonly 'local.theme.invalid': 'theme.invalidDeclaration';
    readonly 'local.theme.missing': 'theme.missing';
    readonly 'local.theme.manifest.unreadable': 'theme.registryUnreadable';
    readonly 'local.theme.manifest.definition': 'theme.invalidDefinition';
    readonly 'local.theme.manifest.selected': 'theme.selectedUnreadable';
    readonly 'local.theme.protocol': 'theme.protocol';
    readonly 'local.theme.modes': 'theme.modes';
    readonly 'local.tag.missing-close': 'tag.missingClose';
    readonly 'local.tag.unclosed.open': 'tag.missingClose';
    readonly 'local.tag.unclosed.pair': 'tag.unclosedPaired';
    readonly 'local.tag.closing': 'tag.closingAttributes';
    readonly 'local.tag.name': 'tag.nameInvalid';
    readonly 'local.tag.mismatch.root': 'tag.mismatchRoot';
    readonly 'local.tag.mismatch.parent': 'tag.mismatchParent';
    readonly 'local.tag.shape': 'tag.requiresClose';
    readonly 'local.interpolation.unclosed': 'interpolation.unclosed';
    readonly 'local.math.unclosed': 'math.unclosed';
    readonly 'local.math.whitespace': 'math.whitespace';
    readonly 'local.footnote.unsupported': 'footnote.unsupported';
    readonly 'local.html': 'html.raw';
    readonly 'local.html.fallback': 'html.fallback';
    readonly 'local.html.fallback.attribute': 'html.fallbackAttribute';
    readonly 'local.html.table': 'html.table.structure';
    readonly 'local.html.extended': 'html.extended';
    readonly 'local.html.attribute': 'html.attribute';
    readonly 'local.html.unsafe-url': 'html.unsafeUrl';
    readonly 'local.html.capability': 'html.capability';
    readonly 'local.recovery.unclosed': 'recovery.unclosed';
    readonly 'local.recovery.mismatch': 'recovery.mismatch';
    readonly 'local.recovery.stray-close': 'recovery.strayClose';
    readonly 'local.html.repair': 'recovery.htmlRepair';
    readonly 'local.html.literal': 'recovery.htmlLiteral';
    readonly 'local.options.invalid.html-flag': 'options.htmlFlag';
    readonly 'local.options.invalid.markdown-breaks': 'options.markdownBreaks';
    readonly 'local.options.invalid.strict': 'options.strict';
    readonly 'local.component.unknown.suggestion': 'component.unknownSuggestion';
    readonly 'local.component.unknown': 'component.unknownPlain';
    readonly 'local.attribute.format': 'attribute.lowercase';
    readonly 'local.attribute.name': 'attribute.nameInvalid';
    readonly 'local.attribute.value-quoted': 'attribute.valueQuoted';
    readonly 'local.attribute.closing-quote': 'attribute.valueUnclosed';
    readonly 'local.attribute.duplicate': 'attribute.duplicate';
    readonly 'local.attribute.separator': 'attribute.separator';
    readonly 'local.attribute.unknown.suggestion': 'attribute.unknownSuggestion';
    readonly 'local.attribute.unknown': 'attribute.unknownPlain';
    readonly 'local.attribute.color': 'attribute.color';
    readonly 'local.attribute.required': 'attribute.required';
    readonly 'local.attribute.static': 'attribute.static';
    readonly 'local.host.attribute.unknown': 'host.attributeUnknown';
    readonly 'local.host.attribute.required': 'host.attributeRequired';
    readonly 'local.host.attribute.static': 'host.attributeStatic';
    readonly 'local.host.attribute.type': 'host.attributeType';
    readonly 'local.host.attribute.enum': 'host.attributeEnum';
    readonly 'local.host.attribute.pattern': 'host.attributePattern';
    readonly 'local.host.attribute.interpolation': 'host.attributeInterpolation';
    readonly 'local.attribute.type.number': 'attribute.numberInvalid';
    readonly 'local.attribute.type.number-interpolation': 'attribute.numberInterpolationInvalid';
    readonly 'local.attribute.type.integer': 'attribute.integer';
    readonly 'local.attribute.type.positive': 'attribute.positive';
    readonly 'local.attribute.type.boolean': 'attribute.booleanInvalid';
    readonly 'local.attribute.type.boolean-interpolation': 'attribute.booleanInterpolationInvalid';
    readonly 'local.attribute.type.enum': 'attribute.enumInvalid';
    readonly 'local.attribute.type.date-lower': 'attribute.dateLower';
    readonly 'local.attribute.type.date-upper': 'attribute.dateUpper';
    readonly 'local.attribute.range.min': 'attribute.rangeMin';
    readonly 'local.attribute.range.max': 'attribute.rangeMax';
    readonly 'local.attribute.interpolation': 'attribute.fullInterpolation';
    readonly 'local.label.required.missing': 'label.requiredMissing';
    readonly 'local.label.required.empty': 'label.requiredEmpty';
    readonly 'local.expression.empty.attribute': 'expression.emptyAttribute';
    readonly 'local.expression.empty': 'expression.emptyInterpolation';
    readonly 'local.expression.error': 'expression.error';
    readonly 'local.constraint.number-min-max': 'constraint.componentMinMax';
    readonly 'local.constraint.number-step': 'constraint.componentStep';
    readonly 'local.constraint.length-order': 'constraint.lengthRange';
    readonly 'local.constraint.date-order': 'constraint.dateOrder';
    readonly 'local.constraint.progress-range': 'constraint.progressRange';
    readonly 'local.constraint.plot-range': 'constraint.plotRange';
    readonly 'local.constraint.timer-duration': 'constraint.timerDuration';
    readonly 'local.constraint.range-slider-min-max': 'constraint.rangeSliderOrder';
    readonly 'local.constraint.range-slider-step': 'constraint.rangeSliderStep';
    readonly 'local.constraint.coordinate-axis': 'constraint.coordinateOrder';
    readonly 'local.constraint.coordinate-step': 'constraint.coordinateStep';
    readonly 'local.constraint.multi-select': 'constraint.multiSelectMax';
    readonly 'local.constraint.quiz-tolerance': 'constraint.quizTolerance';
    readonly 'local.selection.key.required': 'selection.keyNeedsKey';
    readonly 'local.selection.key.empty': 'selection.keyEmpty';
    readonly 'local.selection.key.missing-column': 'selection.keyMissingColumn';
    readonly 'local.selection.key.interpolation': 'selection.keyInterpolation';
    readonly 'local.selection.key.empty-cell': 'selection.keyEmptyCell';
    readonly 'local.selection.key.duplicate': 'selection.keyDuplicate';
    readonly 'local.selection.key.initial': 'initial.selectionNotValue';
    readonly 'local.structure.parent': 'structure.parent';
    readonly 'local.structure.no-body': 'structure.noBody';
    readonly 'local.structure.inline-only': 'structure.inlineOnly';
    readonly 'local.structure.no-nested-components': 'structure.noNestedComponents';
    readonly 'local.structure.no-components': 'structure.noComponents';
    readonly 'local.structure.children.minimum': 'structure.childrenMinimum';
    readonly 'local.structure.children.only': 'structure.childrenOnly';
    readonly 'local.structure.sequence.minimum': 'structure.sequenceMinimum';
    readonly 'local.structure.sequence.only': 'structure.sequenceOnly';
    readonly 'local.structure.accordion.needs-disclosure': 'structure.accordionNeedsDisclosure';
    readonly 'local.structure.accordion.only-disclosure': 'structure.accordionOnly';
    readonly 'local.structure.grid.needs-card': 'structure.gridNeedsCard';
    readonly 'local.structure.grid.only-card': 'structure.gridOnlyCard';
    readonly 'local.structure.table.single': 'structure.exactlyOneTable';
    readonly 'local.structure.plot.needs-formula': 'structure.plotNeedsFormula';
    readonly 'local.structure.plot.only-formulas': 'structure.plotOnlyFormulas';
    readonly 'local.structure.node.no-components': 'structure.nodeNoComponents';
    readonly 'local.structure.options.needed': 'structure.optionsNeeded';
    readonly 'local.structure.options.only': 'structure.optionsOnly';
    readonly 'local.structure.option.no-components': 'structure.optionNoComponents';
    readonly 'local.structure.tabs.needs-tab': 'structure.tabsNeedsTab';
    readonly 'local.structure.tabs.only-tab': 'structure.tabsOnly';
    readonly 'local.structure.steps.needs-step': 'structure.stepsNeedsStep';
    readonly 'local.structure.steps.only-step': 'structure.stepsOnly';
    readonly 'local.structure.quiz.numeric-no-body': 'structure.quizNumericNoBody';
    readonly 'local.structure.diagram.only': 'structure.diagramOnly';
    readonly 'local.option.value.required': 'option.valueRequired';
    readonly 'local.option.value.comma': 'option.valueComma';
    readonly 'local.option.value.duplicate': 'option.valueDuplicate';
    readonly 'local.tab.value.duplicate': 'tab.valueDuplicate';
    readonly 'local.step.value.duplicate': 'step.valueDuplicate';
    readonly 'local.quiz.answer.required': 'quiz.answerRequired';
    readonly 'local.quiz.answer.numeric': 'quiz.answerNumeric';
    readonly 'local.quiz.answer.not-option': 'quiz.answerNotOption';
    readonly 'local.diagram.node.required': 'diagram.needsNode';
    readonly 'local.diagram.node.invalid': 'diagram.nodeInvalid';
    readonly 'local.diagram.node.duplicate': 'diagram.nodeDuplicate';
    readonly 'local.diagram.edge.from': 'diagram.edgeFromUnknown';
    readonly 'local.diagram.edge.to': 'diagram.edgeToUnknown';
    readonly 'local.diagram.edge.duplicate': 'diagram.edgeDuplicate';
    readonly 'local.checklist.body.single': 'checklist.bodySingle';
    readonly 'local.checklist.body.item-required': 'checklist.needsItem';
    readonly 'local.checklist.body.items-limit': 'budget.checklistItems';
    readonly 'local.checklist.body.task-only': 'checklist.taskOnly';
    readonly 'local.checklist.body.no-nested': 'checklist.noNested';
    readonly 'local.checklist.body.no-components': 'checklist.noComponents';
    readonly 'local.binding.name': 'binding.nameInvalid';
    readonly 'local.binding.reserved': 'binding.reserved';
    readonly 'local.binding.type': 'binding.typeConflict';
    readonly 'local.binding.exclusive': 'binding.exclusive';
    readonly 'local.binding.exclusive.slot': 'binding.slotExclusive';
    readonly 'local.binding.constraint': 'binding.constraintConflict';
    readonly 'local.binding.option': 'binding.optionConflict';
    readonly 'local.binding.unknown.suggestion': 'binding.unknownSuggestion';
    readonly 'local.binding.unknown': 'binding.unknownPlain';
    readonly 'local.initial.duplicate': 'initial.duplicate';
    readonly 'local.initial.duplicate-peers': 'initial.duplicatePeers';
    readonly 'local.initial.no-step': 'initial.rangeNoStep';
    readonly 'local.initial.cannot-derive': 'initial.cannotDerive';
    readonly 'local.initial.type.number': 'initial.typeFiniteNumber';
    readonly 'local.initial.type.boolean': 'initial.typeBoolean';
    readonly 'local.initial.type': 'initial.typeWrong';
    readonly 'local.initial.type.collection': 'initial.typeCollection';
    readonly 'local.initial.type.array': 'initial.typeStringArray';
    readonly 'local.initial.type.number-array': 'initial.typeNumberArray';
    readonly 'local.initial.value.max-items': 'initial.maxItems';
    readonly 'local.initial.range.min': 'initial.belowMin';
    readonly 'local.initial.range.max': 'initial.aboveMax';
    readonly 'local.initial.range.step': 'initial.offStep';
    readonly 'local.initial.value.options': 'initial.notAmongOptions';
    readonly 'local.initial.date': 'initial.dateInvalid';
    readonly 'local.initial.value.option': 'initial.notAvailableOption';
    readonly 'local.initial.option.multi-select': 'initial.multiSelectOption';
    readonly 'local.initial.range-slider': 'initial.rangeSliderOrder';
    readonly 'local.initial.slot.min': 'initial.slotBelowMin';
    readonly 'local.initial.slot.max': 'initial.slotAboveMax';
    readonly 'local.initial.slot.step': 'initial.slotOffStep';
    readonly 'local.initial.length.min': 'initial.lengthBelow';
    readonly 'local.initial.length.max': 'initial.lengthAbove';
    readonly 'local.initial.email': 'initial.email';
    readonly 'local.initial.date.min': 'initial.dateBelow';
    readonly 'local.initial.date.max': 'initial.dateAbove';
    readonly 'local.initial.multi-select': 'initial.multiSelectExceeds';
    readonly 'local.type.number': 'type.number';
    readonly 'local.type.boolean': 'type.boolean';
    readonly 'local.type.string': 'type.string';
    readonly 'local.type.array': 'type.arrayNoDisplay';
    readonly 'local.anchor.id': 'anchor.idInvalid';
    readonly 'local.anchor.duplicate': 'anchor.duplicate';
    readonly 'local.anchor.heading-collision': 'anchor.headingCollision';
    readonly 'local.jump.empty': 'jump.empty';
    readonly 'local.jump.bad-target': 'jump.badTarget';
    readonly 'local.jump.unresolved': 'jump.unresolved';
    readonly 'local.math.formula.shape': 'math.formulaShape';
    readonly 'local.math.compute': 'math.computeFailed';
    readonly 'local.math.binding.unknown': 'math.bindingUnknown';
    readonly 'local.math.binding.type': 'math.bindingType';
    readonly 'local.math.display.unsupported-command': 'math.displayUnsupportedCommand';
    readonly 'local.math.display.unsupported-environment': 'math.displayUnsupportedEnvironment';
    readonly 'local.math.display.budget': 'math.displayBudget';
    readonly 'local.math.display.stray-end': 'math.displayStrayEnd';
    readonly 'local.math.display.environment-unclosed': 'math.displayEnvironmentUnclosed';
    readonly 'local.math.display.environment-missing-name': 'math.displayEnvironmentMissingName';
    readonly 'local.math.display.syntax': 'math.displaySyntax';
    readonly 'local.table.header.missing': 'table.missingHeader';
    readonly 'local.table.header.interpolation': 'table.headerInterpolation';
    readonly 'local.table.header.empty': 'table.headerEmpty';
    readonly 'local.table.header.duplicate': 'table.headerDuplicate';
    readonly 'local.table.row.mismatch': 'table.rowColumnMismatch';
    readonly 'local.chart.numeric.expression': 'chart.numericExpression';
    readonly 'local.timeline.numeric.expression': 'timeline.numericExpression';
    readonly 'local.chart.numeric.plain': 'chart.numericPlain';
    readonly 'local.timeline.numeric.plain': 'timeline.numericPlain';
    readonly 'local.chart.column.comma': 'chart.columnComma';
    readonly 'local.chart.column.x-missing': 'chart.xMissing';
    readonly 'local.chart.column.y-required': 'chart.yRequired';
    readonly 'local.chart.column.y-missing': 'chart.yMissing';
    readonly 'local.chart.column.needs-numeric': 'chart.needsNumeric';
    readonly 'local.chart.column.scatter-x-missing': 'chart.scatterXMissing';
    readonly 'local.chart.column.scatter-needs-numeric': 'chart.scatterNeedsNumeric';
    readonly 'local.chart.column.donut-columns': 'chart.donutNeedsColumns';
    readonly 'local.chart.column.donut-y': 'chart.donutYOne';
    readonly 'local.chart.column.donut-need-y': 'chart.donutNeedY';
    readonly 'local.chart.negative': 'chart.negative';
    readonly 'local.timeline.header.missing': 'timeline.headerMissing';
    readonly 'local.timeline.header.column': 'timeline.columnUnsupported';
    readonly 'local.timeline.value.negative': 'timeline.negative';
    readonly 'local.runtime.binding.no-writable': 'runtime.bindingNoWritable';
    readonly 'local.runtime.binding.needs-slot': 'runtime.bindingNeedsSlot';
    readonly 'local.runtime.binding.unknown-slot': 'runtime.bindingUnknownSlot';
    readonly 'local.runtime.binding.no-multi-slot': 'runtime.bindingNoMultiSlot';
    readonly 'local.runtime.value.date-invalid': 'runtime.dateInvalid';
    readonly 'local.runtime.value.date-required': 'runtime.dateRequired';
    readonly 'local.runtime.value.date-earlier': 'runtime.dateEarlier';
    readonly 'local.runtime.value.date-later': 'runtime.dateLater';
    readonly 'local.runtime.value.field-required': 'runtime.fieldRequired';
    readonly 'local.runtime.value.min-length': 'runtime.minLength';
    readonly 'local.runtime.value.max-length': 'runtime.maxLength';
    readonly 'local.runtime.value.email-length': 'runtime.emailLength';
    readonly 'local.runtime.value.email-invalid': 'runtime.emailInvalid';
    readonly 'local.runtime.value.finite-number': 'runtime.finiteNumber';
    readonly 'local.runtime.value.min': 'runtime.min';
    readonly 'local.runtime.value.max': 'runtime.max';
    readonly 'local.runtime.value.step': 'runtime.step';
    readonly 'local.runtime.value.boolean': 'runtime.boolean';
    readonly 'local.runtime.value.string': 'runtime.string';
    readonly 'local.runtime.value.array': 'runtime.array';
    readonly 'local.runtime.value.array-members': 'runtime.arrayMembers';
    readonly 'local.runtime.value.number-array': 'runtime.numberArray';
    readonly 'local.runtime.value.number-array-members': 'runtime.numberArrayMembers';
    readonly 'local.runtime.value.null': 'runtime.null';
    readonly 'local.runtime.value.checklist-option': 'runtime.checklistOption';
    readonly 'local.runtime.value.max-items': 'runtime.maxItems';
    readonly 'local.runtime.value.unsupported-type': 'runtime.unsupportedType';
    readonly 'local.runtime.value.option': 'runtime.option';
    readonly 'local.runtime.value.budget': 'runtime.budget';
    readonly 'local.runtime.value.range-order': 'runtime.rangeOrder';
};
export type LocalDiagnosticTemplateKey = keyof typeof LOCAL_DIAGNOSTIC_TEMPLATE_ALIASES;
