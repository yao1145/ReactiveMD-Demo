import type { Diagnostic, LocalDiagnosticParams } from '../contracts/types.js';
import { LOCAL_DIAGNOSTIC_TEMPLATE_ALIASES } from './diagnostic-messages.js';
/**
 * Central diagnostic message registry.
 *
 * `code` stays the coarse, machine-stable classification; `messageKey` selects
 * one English/Chinese template and `params` carries the values needed to render
 * it. Construction sites never repeat translations, and formatting never parses
 * an English sentence. Unknown host diagnostics keep their original message.
 */
export type LocalDiagnosticLocale = 'en' | 'zh';
/** Structured metadata attached by a reporting site. */
export interface LocalDiagnosticDetails {
    key: string;
    params?: LocalDiagnosticParams;
}
/** Keep metadata JSON/worker-safe and bounded even if a caller passes junk. */
export declare function sanitizeDiagnosticParams(params: Record<string, unknown>): LocalDiagnosticParams | undefined;
/**
 * Build structured metadata at a reporting site. `key` is validated against the
 * template registry by tests, not at runtime: unknown host keys must still be
 * carried through so display code can fall back to `message`.
 */
export declare function localDiagnosticDetails(key: string, params?: Record<string, unknown> | LocalDiagnosticParams): LocalDiagnosticDetails;
/** Public error codes thrown by `compileExpression`/`interpolate`. */
export declare const LOCAL_EXPRESSION_ERROR_CODES: readonly ['expression-index', 'expression-cycle', 'expression-syntax', 'expression-number', 'expression-string', 'expression-budget', 'expression-assignment', 'expression-property', 'expression-empty', 'expression-unknown-function', 'expression-arity', 'expression-forbidden-name', 'expression-type', 'expression-unknown-name', 'expression-value', 'expression-eval', 'expression-domain', 'expression-divide-by-zero', 'expression-interpolation'];
export type LocalExpressionErrorCode = (typeof LOCAL_EXPRESSION_ERROR_CODES)[number];
/** Public error codes thrown by `compileLatex`/`samplePlot`. */
export declare const LOCAL_LATEX_ERROR_CODES: readonly ['latex-budget', 'latex-syntax', 'latex-empty', 'latex-relation', 'latex-number', 'latex-name', 'latex-unsupported', 'latex-variable', 'latex-type', 'latex-divide-by-zero', 'latex-domain', 'latex-undefined', 'latex-plot-range', 'latex-plot-samples'];
export type LocalLatexErrorCode = (typeof LOCAL_LATEX_ERROR_CODES)[number];
/**
 * Every diagnostic code the core can emit, including the raw public expression
 * and LaTeX error codes and the `local.expression.<code>` forms forwarded by
 * the compiler. Codes are never renamed or reused inside a 0.x minor version.
 */
export declare const LOCAL_DIAGNOSTIC_CODES: readonly string[];
/**
 * Message keys used on `Diagnostic.messageKey`. Most keys follow
 * `local.<diagnostic-code>.<variant>` so a reader can associate a template with
 * its machine code without a lookup table.
 */
export type LocalDiagnosticTemplateKey = keyof typeof LOCAL_DIAGNOSTIC_TEMPLATE_ALIASES;
/** Registered message keys, sorted for stable test snapshots. */
export declare const localDiagnosticTemplateKeys: readonly string[];
/** Look up the raw template text, or `undefined` for an unknown host key. */
export declare function localDiagnosticTemplate(key: string, locale?: LocalDiagnosticLocale): string | undefined;
/** Whether a code belongs to the registered core diagnostic surface. */
export declare function isLocalDiagnosticCode(code: unknown): code is string;
/** Render a registered template without constructing a full diagnostic. */
export declare function renderLocalDiagnostic(key: string, locale?: LocalDiagnosticLocale, params?: LocalDiagnosticParams): string;
/** English text for `Diagnostic.message`; keep the field backwards compatible. */
export declare function diagnosticEnglish(detail: LocalDiagnosticDetails): string;
/**
 * Format a diagnostic in the requested language. Known core diagnostics use
 * their registered template; host-supplied or unknown diagnostics keep the
 * original message. The result respects the existing UTF-16 message budget.
 */
export declare function formatLocalDiagnostic(diagnostic: Diagnostic, locale?: LocalDiagnosticLocale): string;
