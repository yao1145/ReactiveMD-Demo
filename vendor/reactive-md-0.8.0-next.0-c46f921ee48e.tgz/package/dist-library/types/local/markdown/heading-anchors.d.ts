import type { LocalDocument, LocalNode } from '../contracts/types.js';
import type { LocalComponentDefinition } from '../../sdk/types.js';
/**
 * Public anchor rules used by both navigation and its memo projection.
 *
 * The caller supplies the component semantics installed for this document
 * (compiled documents carry their own `componentDefinitions`). This module
 * never fills in a default preset: a document compiled without components
 * contributes no explicit anchor rules.
 */
export declare function anchorRuleAttributes(document: LocalDocument, installed?: readonly LocalComponentDefinition[]): ReadonlyMap<string, string>;
/**
 * Heading slugs and explicit `<anchor>` ids share one per-render-instance
 * namespace. Author fragments (`#result`) resolve against either kind of
 * target, and `<jump to="result">` asks for the already-namespaced DOM id via
 * `targetId`, so the renderer never has to query the global document.
 *
 * Fragments use source initial values, so editing parameters preserves
 * navigation.
 */
export declare function createHeadingAnchors(document: LocalDocument, namespace: string, includeExplicitAnchors?: boolean, installed?: readonly LocalComponentDefinition[]): {
    ids: Map<LocalNode, string>;
    anchorIds: Map<LocalNode, string>;
    htmlIds: Map<LocalNode, string>;
    /** Namespaced DOM id for a static jump/anchor target slug, if it exists. */
    targetId(to: string): string | undefined;
    referenceId(to: string): string;
    resolve(href: string): string;
};
