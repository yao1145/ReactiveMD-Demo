import { type ReactElement } from 'react';
/**
 * Safe KaTeX rendering for local LaTeX.
 *
 * Typesetting, support detection and diagnostics live in the React-free
 * `math-display` module, so compile-time diagnostics use exactly the same KaTeX
 * call as this renderer. Only the markup KaTeX generated is injected; error
 * messages, macros and HTML from the author are never interpreted. A formula
 * that cannot be typeset falls back to bounded source text rendered by React.
 */
export interface LatexViewProps {
    source: string;
    display?: boolean;
}
export declare function LatexView({ source, display }: LatexViewProps): ReactElement;
