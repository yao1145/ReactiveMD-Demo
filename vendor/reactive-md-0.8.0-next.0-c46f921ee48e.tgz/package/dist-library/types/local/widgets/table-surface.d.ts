import type { HTMLAttributes, ReactNode } from 'react';
/** The same table/scroll surface for Markdown-backed and native HTML tables. */
export declare function TableSurface({ children, className, scrollClassName, tableProps }: {
    children: ReactNode;
    className?: string;
    scrollClassName?: string;
    tableProps?: HTMLAttributes<HTMLTableElement> & {
        'data-merged'?: string;
    };
}): import("react").JSX.Element;
