import type { Diagnostic, SourceRange } from '../contracts/types.js';
/** Theme name grammar lives in a dependency-free module for the compiler kernel. */
export { isLocalThemeName } from './theme-name.js';
/**
 * Versioned theme contract. A host registers CSS for a theme name and declares
 * that contract here; the document only carries a name, never CSS or a URL.
 */
export declare const LOCAL_THEME_PROTOCOL: 'reactive-md-theme-1';
export type LocalColorScheme = 'light' | 'dark' | 'auto';
export interface LocalThemeDefinition {
    readonly name: string;
    readonly protocol: typeof LOCAL_THEME_PROTOCOL;
    readonly colorSchemes: readonly ('light' | 'dark')[];
}
/** Built-in theme supplied by the package, so old documents keep working. */
export declare const DEFAULT_LOCAL_THEME: LocalThemeDefinition;
export interface LocalThemeResolution {
    name: string;
    diagnostics: Diagnostic[];
}
/**
 * Resolve the document-selected theme against a host-supplied manifest.
 *
 * This is a pure validation step: it never mutates the registry, loads CSS,
 * runs host code or throws. Any malformed selection or manifest degrades to
 * the built-in `default` theme with a warning so healthy controls keep working.
 * Unknown names are not compiler errors; this function is called where the
 * renderer actually chooses a theme.
 */
export declare function resolveLocalTheme(requested?: string, themes?: readonly LocalThemeDefinition[], range?: SourceRange, source?: string): LocalThemeResolution;
