/**
 * Small lexical scanners shared by the strict parser and the recovery planner.
 *
 * These routines answer only "where does this token end". Callers decide
 * whether a missing closer is an error, a recovery boundary or literal text.
 */
/**
 * End offset (exclusive) of the `{{ ... }}` opened at `start`, honoring quoted
 * strings and backslash escapes. Returns -1 when the closer is missing.
 */
export declare function scanInterpolationEnd(source: string, start: number, limit: number): number;
/** End of an escaped `\X ... X` pair opening at `from`. */
export declare function escapedPairEnd(source: string, from: number, end: number, close: string): number | null;
/** End of an escaped `\\[ ... \\]` display wrapper. */
export declare function escapedDisplayEnd(source: string, from: number, end: number): number | null;
/**
 * End of the formula token starting at `start`, or null when the token is not
 * a formula. Formula spans are opaque so tags inside TeX never look
 * structural.
 */
export declare function mathTokenEnd(source: string, start: number, end: number): number | null;
