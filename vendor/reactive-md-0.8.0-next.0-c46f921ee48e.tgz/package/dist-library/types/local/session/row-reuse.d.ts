import type { LocalNode } from '../contracts/types.js';
/**
 * Conservative row-level node reuse for flat Markdown lists and tables.
 *
 * The incremental compiler still parses the block that contains the edit, so
 * the parser remains the only semantic authority. This module only replaces a
 * freshly parsed row subtree with the previous revision's subtree when:
 *
 * - the block is exactly one `list` or `table` whose children are all flat,
 *   single-line `listItem` / `tableRow` nodes, and
 * - the previous and next row have byte-identical source text, and
 * - the whole subtree (type, non-id fields and row-relative ranges) is equal.
 *
 * When the row's absolute start did not move the previous object is returned
 * as-is. Otherwise it is cloned with every range shifted; shifted nodes can
 * never be the same object because their ranges differ. IDs are always kept,
 * so unchanged rows keep a stable identity across revisions.
 */
export type RowKind = 'item' | 'row';
export interface RowBlock {
    /** Block text in the document, exactly as stored by the incremental snapshot. */
    text: string;
    /** Compiled-coordinate origin: `node.range.start - origin` is the text offset. */
    origin: number;
    /** Top-level block nodes in compiled coordinates. */
    nodes: readonly LocalNode[];
}
export interface RowReuseOutcome {
    /** Top-level nodes with substitutable rows replaced. */
    nodes: LocalNode[];
    /** Number of row subtrees taken from the previous revision. */
    reused: number;
    kind: RowKind;
    /** IDs owned by the previous revision's dependency map. */
    reusedIds: Set<string>;
}
/**
 * Align rows with a common prefix/suffix by exact source text, then substitute
 * only rows whose freshly parsed subtree is structurally identical. Duplicate
 * rows are safe because both matches have identical text; a misalignment can
 * only reduce reuse, never change the result.
 *
 * Returns `undefined` when nothing can be reused, so callers can keep the
 * fresh parse untouched.
 */
export declare function reuseFlatRows(previous: RowBlock | undefined, next: RowBlock): RowReuseOutcome | undefined;
