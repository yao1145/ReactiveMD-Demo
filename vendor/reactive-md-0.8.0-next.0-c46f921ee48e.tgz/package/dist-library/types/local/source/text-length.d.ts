/**
 * Author-visible character counting.
 *
 * Unicode code points are the unit authors see: `len()` in expressions,
 * `min-length`/`max-length` on text controls and initial-value checks all use
 * this function. Combining marks are not merged into grapheme clusters, and an
 * unpaired surrogate counts as one code point.
 *
 * Source offsets, line/column positions and defensive resource budgets remain
 * UTF-16 code units (see `limits.ts`); those are machine limits, not counts
 * authors compare against visible text.
 */
export declare function countLocalCodePoints(value: string): number;
