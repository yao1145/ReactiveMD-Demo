import type { LocalNode } from '../contracts/types.js';
/** Ordered traversal with memory proportional to depth, independent of JS stack. */
export declare function walkLocalNodes(nodes: readonly LocalNode[], postorder?: boolean): Generator<LocalNode>;
