import type { Diagnostic, LocalCompileOptions, LocalDocument, SourceRange } from '../contracts/types.js';
/**
 * DOM-free authoring services for the local interaction syntax.
 *
 * Everything here works from the same source offsets as the parser and the
 * compiler: positions are UTF-16 code units into the original document. Active
 * syntax is taken from `parseLocal`. Code, display math, comments, escaped
 * syntax, footnotes and unknown/fallback regions produce no binding reads or
 * formatting edits; computable plot parameters use the LaTeX AST.
 *
 * Every entry point accepts the same optional `LocalCompileOptions` as the
 * preview compiler. Host components and syntax limits therefore shape analysis
 * exactly as they shape rendering, and HTML mode is treated as opaque.
 */
export interface AuthorToken {
    kind: string;
    range: SourceRange;
}
export interface AuthorBinding {
    name: string;
    declarations: SourceRange[];
    references: SourceRange[];
}
export interface AuthorAnalysis {
    tokens: AuthorToken[];
    bindings: AuthorBinding[];
    diagnostics: Diagnostic[];
}
export type AuthorCompletionKind = 'tag' | 'attribute' | 'binding' | 'value';
export interface AuthorCompletion {
    label: string;
    insertText: string;
    range: SourceRange;
    kind: AuthorCompletionKind;
    detail?: string;
}
export interface AuthorRename {
    source: string;
    edits: {
        range: SourceRange;
        text: string;
    }[];
}
/**
 * Analyze syntax, declarations/references and (by default) compiler diagnostics.
 * A supplied document must come from the same source and compile options;
 * stale-source documents are ignored. Editors with separate diagnostics may
 * omit their compilation via `diagnostics: false`.
 */
export declare function analyzeLocalSource(source: string, options?: LocalCompileOptions, settings?: {
    document?: LocalDocument;
    diagnostics?: boolean;
}): AuthorAnalysis;
/**
 * Complete tags, schema attributes, enum values and declared binding names at
 * `offset`. Replacement ranges cover an already-typed valid suffix so applying
 * a suggestion never duplicates letters. Inactive regions yield no results.
 */
export declare function completeLocalSource(source: string, offset: number, options?: LocalCompileOptions): AuthorCompletion[];
/**
 * Rename a declared binding and every active reference. Literal attribute
 * text, Markdown text, strings inside expressions, code, display math, comments
 * and fallback regions are preserved. Plot parameters retain their computed
 * meaning. Invalid names, collisions and structural
 * parse failures are rejected.
 */
export declare function renameLocalBinding(source: string, oldName: string, newName: string, options?: LocalCompileOptions): AuthorRename;
/**
 * Conservatively normalize whitespace inside recognized reactive tags:
 * single spaces between attributes, no spaces around `=`, no space before `>`,
 * canonical closing tags. Quotes, attribute order and values are untouched.
 * Markdown, newlines, indentation, code, math and fallback regions are not
 * modified. Any compile error leaves the document unchanged.
 */
export declare function formatLocalSource(source: string, options?: LocalCompileOptions): string;
