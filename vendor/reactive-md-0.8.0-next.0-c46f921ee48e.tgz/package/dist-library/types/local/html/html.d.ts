import type { Diagnostic, LocalHtmlPolicy } from '../contracts/types.js';
export interface LocalHtmlSanitizeResult {
    markup: string;
    diagnostics: Diagnostic[];
}
/** The sandbox always keeps author documents separate from their host. */
export declare function localHtmlSandbox(policy: LocalHtmlPolicy): string;
/** Resources stay offline; extended HTML permits explicit HTTP(S) form submissions. */
export declare function localHtmlContentSecurityPolicy(policy: LocalHtmlPolicy): string;
/**
 * Parse, sanitize and serialize a whole native HTML document. The result is a
 * complete document string suitable for a sandboxed `srcdoc` iframe.
 */
export declare function sanitizeLocalHtmlDocument(source: string, policy: LocalHtmlPolicy, maxSyntaxNodes: number): LocalHtmlSanitizeResult;
export declare const LOCAL_HTML_P0_ELEMENTS: Set<string>;
export declare const LOCAL_HTML_VOID_ELEMENTS: Set<string>;
