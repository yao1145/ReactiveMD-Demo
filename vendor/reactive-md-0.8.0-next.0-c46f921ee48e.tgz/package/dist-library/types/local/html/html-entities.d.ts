/**
 * Decode character references with the browser grammar, never activating
 * markup. This is the shared implementation for the strict HTML parser and
 * the isolated HTML repair pass; `replaceNul` keeps the repaired tree free of
 * NUL characters.
 */
export declare function decodeLocalHtmlEntities(value: string, replaceNul?: boolean): string;
