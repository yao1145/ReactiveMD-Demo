/**
 * Shared P0 HTML policy and raw tag scanning.
 *
 * The strict Markdown parser, the structural recovery planner and the isolated
 * HTML repair pass must agree on which tags, attributes and URL shapes are
 * accepted. Keeping the tables and the lexical scanners here means a change to
 * the accepted surface reaches every consumer, while each pass keeps its own
 * structural decisions.
 */
/** Inline P0 names and the Markdown node type they lower to. */
export declare const HTML_INLINE_NODE_TYPES: Readonly<Record<string, string>>;
/** Elements with no end tag in HTML, including the table-only `col`. */
export declare const HTML_VOID_ELEMENTS: ReadonlySet<string>;
/** Raw-text elements: markup-looking text inside them is inert source. */
export declare const HTML_RAW_TEXT_ELEMENTS: ReadonlySet<string>;
/** Attributes accepted on every P0 element. */
export declare const HTML_GLOBAL_ATTRIBUTES: ReadonlySet<string>;
/** Per-tag attribute surface beyond globals, ARIA and `data-*`. */
export declare const HTML_TAG_ATTRIBUTES: Readonly<Record<string, ReadonlySet<string>>>;
/**
 * End offset (exclusive) of the tag starting at `from`, honoring quoted
 * attribute values. Returns -1 when no `>` is found before `limit`.
 */
export declare function htmlTagEnd(source: string, from: number, limit: number): number;
/**
 * End offset of the comment starting at `start`. `<!-->` and `<!--->` are
 * empty comments that end at their first `>`; searching only for `-->` would
 * hide following markup from the validator.
 */
export declare function htmlCommentEnd(source: string, start: number, limit: number): number;
/** URL comparison form: trimmed with embedded controls and spaces removed. */
export declare function normalizedHtmlUrl(value: string): string;
/** True when a URL scheme would escape the accepted P0 link/image surface. */
export declare function unsafeHtmlUrl(value: string, kind: 'link' | 'image'): boolean;
/**
 * Attribute-name policy. `align` is handled separately because callers
 * normalize it; `class`, `style` and event handlers never activate.
 */
export declare function isHtmlAttributeNameAllowed(tag: string, name: string): boolean;
/** Value policy shared by inline HTML and isolated HTML repair. */
export declare function isValidHtmlAttributeValue(name: string, value: string): boolean;
/** Normalized `align` value for a tag that declares it, or null. */
export declare function htmlAlignValue(tag: string, value: string): string | null;
