import type { LocalNode, LocalRecovery } from '../contracts/types.js';
/**
 * Recover an isolated HTML fragment inside `[start, end)`.
 *
 * The caller passes a range already confirmed to need structural repair. The
 * function parses only that slice, maps the repaired tree to the existing
 * `LocalNode` model through `createNode`, and never writes the source back.
 * Anything outside the supported P0 surface, any registered component tag,
 * and any interpolation that cannot be kept inert returns `null`, which tells
 * the caller to fall back to literal text for the whole range.
 */
export declare function recoverLocalHtml(source: string, start: number, end: number, createNode: (type: string, start: number, end: number, extra?: Partial<LocalNode>) => LocalNode, componentNames: ReadonlySet<string>, contextTag?: string): {
    nodes: LocalNode[];
    recovery: LocalRecovery;
    end: number;
} | null;
