/**
 * P0 native HTML tag names. The parser handles these before component tags, and
 * host component schemas may not reuse them because document parsing would
 * never dispatch such a tag to a host component.
 */
export declare const LOCAL_HTML_NAMES: ReadonlySet<string>;
/** Legacy text alignment accepted as a bounded HTML attribute, without CSS. */
export declare const LOCAL_HTML_ALIGN_ELEMENTS: ReadonlySet<string>;
export declare function localHtmlAlign(value: string): 'left' | 'center' | 'right' | 'justify' | null;
export declare const LOCAL_HTML_ANCHOR_ATTRIBUTES: ReadonlySet<string>;
/** Preserve author relationship tokens while retaining blank-link isolation. */
export declare function localHtmlLinkRel(rel: string | undefined, target: string | undefined): string | undefined;
