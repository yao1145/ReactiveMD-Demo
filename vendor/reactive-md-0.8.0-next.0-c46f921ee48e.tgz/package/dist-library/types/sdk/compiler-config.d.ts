import { componentConfigKey } from './config-validation.js';
import type { LocalComponentDefinition, LocalConfig, LocalPresetReference } from './types.js';
/**
 * Semantic SDK-configuration reader for single compilation.
 *
 * This module validates the configuration data that affects compilation:
 * presets, component manifests and their dependency graph. It intentionally
 * imports neither `config.ts` nor any theme implementation, so a compiler that
 * installs no default preset can still accept a host configuration.
 *
 * Host theme assets stay opaque and are excluded from the semantic snapshot.
 * The host validates those assets before loading them.
 */
/**
 * Phase-one default preset identity, kept as protocol data rather than by
 * importing the preset implementation. Update it here if the default preset
 * identity changes; the standard compiler and this reader must agree for the
 * semantic key to stay compatible with `localComponentConfigKey`.
 */
export declare const DEFAULT_COMPILER_PRESET: LocalPresetReference;
export { componentConfigKey as compilerConfigKey };
/**
 * Validate configuration data for compilation. The caller-supplied `key` and
 * `registry` are ignored; both are rebuilt from the validated semantics.
 * `defaults` is the assembled built-in registry used for reserved names,
 * dependency identifiers and the returned registry order.
 */
export declare function readCompilerConfig(value: unknown, defaults?: readonly LocalComponentDefinition[]): LocalConfig;
