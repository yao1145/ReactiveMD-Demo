import type { LocalComponentDefinition, LocalPresetReference } from './types.js';
/**
 * Theme-free SDK configuration validation shared by the full SDK entry and the
 * single-compilation reader.
 *
 * This module deliberately imports neither `theme.ts` nor the default preset.
 * Callers pass their assembled built-in component set, so the same rules serve
 * an assembly that installs `defaultPreset.components` and one that installs no
 * preset at all.
 */
/** Aggregate serialized-size budget for one configuration, excluding themes. */
export declare const MAX_LOCAL_SDK_CONFIG_BYTES: number;
export declare const DANGEROUS_KEYS: ReadonlySet<string>;
export declare const CONFIG_KEYS: ReadonlySet<string>;
export declare function fail(path: string, message: string): never;
export declare function isPlainRecord(value: unknown): value is Record<string, unknown>;
export declare function checkKeys(record: Record<string, unknown>, allowed: ReadonlySet<string>, path: string): void;
/**
 * Read the selected preset references against one supported preset identity.
 * Omitting `presets` selects that identity; `"default"` normalizes to it.
 */
export declare function readPresetReferences(value: unknown, preset: LocalPresetReference): readonly LocalPresetReference[];
/**
 * Read external component manifests. Built-in names, kernel grammar names,
 * HTML tag names and the theme declaration are reserved, and external ids may
 * not collide with each other or with the built-in registry.
 */
export declare function readComponents(value: unknown, defaults: readonly LocalComponentDefinition[]): readonly LocalComponentDefinition[];
/** Canonical preset references, sorted by id. */
export declare function canonicalPresets(presets: readonly LocalPresetReference[]): unknown;
/**
 * Semantic configuration key shared by both configuration readers.
 *
 * Themes and authoring copy are excluded so restyling never changes the
 * compiled identity.
 */
export declare function componentConfigKey(presets: readonly LocalPresetReference[], components: readonly LocalComponentDefinition[]): string;
