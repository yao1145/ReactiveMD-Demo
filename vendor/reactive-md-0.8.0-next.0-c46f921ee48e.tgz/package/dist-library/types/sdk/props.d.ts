import type { LocalHostBindingSchema, LocalRuntime } from '../local/contracts/types.js';
import type { LocalComponentDefinition } from './types.js';
/** Typed, resolved values handed to a component implementation. */
export type LocalResolvedProps = Readonly<Record<string, string | number | boolean | null>>;
/** Effective scalar binding constraints after resolving prop references. */
export interface LocalResolvedBindingConstraints {
    min?: number;
    max?: number;
    step?: number;
}
/** All attribute names owned implicitly by a manifest's declared bindings. */
export declare function localBindingAttributeNames(definition: LocalComponentDefinition): ReadonlySet<string>;
/**
 * Normalize a component's authored attributes against its manifest: missing
 * defaults, literal or expression evaluation, type checks and range/enum
 * checks. Optional missing props resolve to `null`; invalid explicit values
 * throw instead of being silently replaced by a default.
 */
export declare function resolveLocalComponentProps(definition: LocalComponentDefinition, attrs: Record<string, string>, runtime: Pick<LocalRuntime, 'evaluate' | 'text'>): LocalResolvedProps;
/** Resolve one declared prop using the same contract as document rendering. */
export declare function resolveLocalComponentProp(definition: LocalComponentDefinition, name: string, raw: string | undefined, runtime: Pick<LocalRuntime, 'evaluate' | 'text'>): string | number | boolean | null;
/**
 * Compiler-side view of a number binding. Literal bounds are always returned;
 * prop references resolve against literal attributes or their defaults, and
 * remain unknown for dynamic interpolations (the runtime checks those).
 */
export declare function resolveLocalComponentBindingConstraints(definition: LocalComponentDefinition, attrs: Record<string, string>): LocalResolvedBindingConstraints;
/**
 * Lower one manifest binding to the existing host binding shape. Only literal
 * constraints are represented here; per-node prop references are applied by
 * `resolveLocalComponentBindingConstraints` during compilation.
 */
export declare function localComponentHostBinding(definition: LocalComponentDefinition): LocalHostBindingSchema | undefined;
