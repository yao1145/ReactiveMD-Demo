/**
 * Restricted regular-expression subset shared by host schemas and SDK
 * manifests. Rejected constructs are the ones that can backtrack
 * super-linearly on document-controlled input.
 */
/**
 * True when `source` uses only linear-time-safe regex syntax: no
 * backreferences, lookarounds, named groups, and no quantifier applied to a
 * group that itself contains a quantifier or alternation.
 */
export declare function isSafeLocalPattern(source: string): boolean;
