import { DEFAULT_COMPONENT_DEFINITIONS, DEFAULT_COMPONENT_NAMES } from '../presets/default-components.js';
import type { LocalComponentSchema } from '../local/configuration/schema.js';
import type { LocalComponentDefinition, LocalConfig } from './types.js';
/** The 46 rendered/structural default manifests. */
export { DEFAULT_COMPONENT_DEFINITIONS, DEFAULT_COMPONENT_NAMES };
export { componentSchemaFromDefinition, localComponentSchema } from './registry-core.js';
/**
 * Resolve the full validated component snapshot: the default preset followed by
 * instance-level external components. Builtins and extensions share one list.
 * A raw configuration cannot smuggle in invalid, duplicate or reserved
 * manifests through a forged `registry` field; the snapshot is rebuilt from
 * validated externally supplied components and cached per configuration.
 */
export declare function getLocalComponentRegistry(config?: LocalConfig): readonly LocalComponentDefinition[];
/** Look up one definition by tag name in the resolved registry. */
export declare function getLocalComponentDefinition(name: string, config?: LocalConfig): LocalComponentDefinition | undefined;
/** Name-keyed schema view of the resolved registry. */
export declare function localComponentSchemas(config?: LocalConfig): ReadonlyMap<string, LocalComponentSchema>;
