import type { LocalComponentDefinition } from '../sdk/types.js';
import { DEFAULT_COMPONENT_NAMES } from './default-semantics.js';
export declare const DEFAULT_COMPONENT_DEFINITIONS: readonly LocalComponentDefinition[];
export { DEFAULT_COMPONENT_NAMES };
