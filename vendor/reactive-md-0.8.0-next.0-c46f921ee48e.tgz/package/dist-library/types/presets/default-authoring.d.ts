import type { LocalComponentAuthoring, LocalComponentText } from '../sdk/types.js';
/**
 * Authoring metadata for the default preset.
 *
 * This is the single home for default component titles, descriptions,
 * categories, keywords and insertion templates. The default manifests in
 * `default-components.ts` carry the canonical English forms, while the editor
 * catalog reads this module directly so localized templates and search
 * keywords do not need a second hand-maintained catalog.
 *
 * Everything here is bounded JSON data: no functions, React or DOM access.
 */
export type DefaultAuthoringGroupId = 'input' | 'action' | 'layout' | 'data' | 'hint';
export type DefaultAuthoringLocale = 'en' | 'zh';
export interface DefaultAuthoringGroup {
    readonly id: DefaultAuthoringGroupId;
    readonly title: LocalComponentText;
}
/** One default component's localized authoring data. */
export interface DefaultComponentAuthoring {
    readonly title: LocalComponentText;
    readonly description: LocalComponentText;
    readonly category: DefaultAuthoringGroupId;
    /** Locale-keyed insertion templates; `<default>` is not used. */
    readonly insertText: LocalComponentText;
    readonly keywords: Readonly<Record<DefaultAuthoringLocale, readonly string[]>>;
    /** Inline components are inserted without block padding. */
    readonly inline?: boolean;
    /** Part of the legacy extended catalog retained for compatibility. */
    readonly extended?: boolean;
}
export declare const DEFAULT_AUTHORING_GROUPS: readonly DefaultAuthoringGroup[];
export declare const DEFAULT_COMPONENT_AUTHORING: Readonly<Record<string, DefaultComponentAuthoring>>;
/** Catalog order derived from the data record's insertion order. */
export declare const DEFAULT_AUTHORING_ORDER: readonly string[];
export declare function defaultComponentAuthoring(name: string): DefaultComponentAuthoring | undefined;
/**
 * Explicit fallback order for authoring copy: requested locale, then English,
 * then Chinese, then the first declared value.
 */
export declare function pickDefaultAuthoringText(value: LocalComponentText | undefined, locale: string, fallback?: string): string;
export declare function defaultAuthoringGroupLabel(category: string, locale: string): string;
/** Search terms from both languages, deduplicated case-insensitively. */
export declare function defaultAuthoringKeywords(name: string): readonly string[] | undefined;
/**
 * Canonical manifest authoring metadata: English titles and templates are the
 * portable form carried by `defaultPreset.components`. Localized templates stay
 * in this module and are consumed by the editor catalog directly.
 */
export declare function defaultManifestAuthoring(name: string): LocalComponentAuthoring | undefined;
