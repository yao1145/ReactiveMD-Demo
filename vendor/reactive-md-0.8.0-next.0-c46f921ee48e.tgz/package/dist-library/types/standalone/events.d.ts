/** Diagnostics emitted by the Web Component and by automatic payload mounts. */
export declare const REACTIVE_MD_DIAGNOSTICS_EVENT = "reactive-md-diagnostics";
/** Emitted with a versioned LocalStateFile after the initial mount and on changes. */
export declare const REACTIVE_MD_STATE_CHANGE_EVENT = "reactive-md-state-change";
