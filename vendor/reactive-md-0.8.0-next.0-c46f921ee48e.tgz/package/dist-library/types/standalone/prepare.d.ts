import { type LocalStateFile } from '../local/runtime/state.js';
import type { Diagnostic, LocalCompileOptions, LocalDocument } from '../local/contracts/types.js';
export interface PreparedStandaloneDocument {
    document: LocalDocument;
    /** Compiler diagnostics, including errors retained for native source fallback. */
    diagnostics: Diagnostic[];
}
/**
 * Compile the source once and, when an exported state is supplied, rebase it
 * through `resolveLocalStateBaseline` so first render and Reset both start from
 * the shared values. Native HTML compile failures become literal source views;
 * invalid ReactiveMD source, host options or state still throw before mounting.
 *
 * `theme` is an optional host-only override (used by `<reactive-md-doc theme>`):
 * it replaces the document-level theme on a shallow, immutable clone so the
 * source, nodes, bindings, digest and validated state stay intact.
 *
 * `compileOptions` replays the capability flags and limits an export was
 * created with; omitting them keeps the default ReactiveMD route.
 */
export declare function prepareStandaloneDocument(source: string, state?: LocalStateFile | string, theme?: string, compileOptions?: LocalCompileOptions, beforeState?: (document: LocalDocument) => void): PreparedStandaloneDocument;
