/** Version of the standalone browser runtime bundle. */
export declare const REACTIVE_MD_STANDALONE_VERSION: '0.4.0';
/** Generator recorded in state files produced by the standalone runtime. */
export declare const REACTIVE_MD_STANDALONE_GENERATOR: Readonly<{
    name: "reactive-md-standalone";
    version: "0.4.0";
}>;
