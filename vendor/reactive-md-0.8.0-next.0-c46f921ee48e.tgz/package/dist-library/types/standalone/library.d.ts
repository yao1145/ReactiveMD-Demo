/** Host-bundled standalone entry. No automatic mount or implicit registration. */
export { mount, mountAll, isReactiveMDMounted, REACTIVE_MD_MOUNTED_ATTRIBUTE } from './session.js';
export type { ReactiveMDMountOptions, ReactiveMDHandle } from './session.js';
export { parseMountPayload } from './payload.js';
export { ReactiveMDMountError } from './diagnostics.js';
export { REACTIVE_MD_DIAGNOSTICS_EVENT, REACTIVE_MD_STATE_CHANGE_EVENT } from './events.js';
