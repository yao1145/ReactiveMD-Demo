/**
 * Minimal single-pass compiler entry.
 *
 * The minimal factory installs no default component preset: only the kernel
 * language declarations (theme/computed/const/external), CommonMark/RMD body,
 * semantic checks and budgets remain. GFM syntax, native HTML parsing and
 * repair, Lezer block planning, the KaTeX display precheck, plot formula
 * semantics and the whole-document HTML branch are standard-assembly
 * capabilities; requesting one here produces an explicit capability
 * diagnostic. `compiler/standard` keeps the full experience.
 *
 * The factory validates options once and snapshots them. `compile` performs
 * only the semantic pass: it creates no runtime, session, worker, timer or
 * cross-source cache.
 */
import type { LocalCompileOptions } from '../local/contracts/types.js';
import { type Compiler } from './types.js';
export { CompilerConfigurationError } from './types.js';
export type { CheckCoverage, CompileFailure, CompileResult, CompileSuccess, Compiler, CompilerConfigurationErrorOptions, OptionalCheck, Program, } from './types.js';
export type { DeepReadonly } from './types.js';
export type { LocalCompileOptions, LocalCompileResult, LocalRecovery } from '../local/contracts/types.js';
export declare function createCompiler(options?: LocalCompileOptions): Compiler;
