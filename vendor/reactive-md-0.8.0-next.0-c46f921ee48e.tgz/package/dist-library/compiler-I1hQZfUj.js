import { _ as e, g as t, n, t as r, y as i } from "./compiler-core-MF3N1RCF.js";
import { n as a } from "./math-display-DWZ_IJQh.js";
import { o } from "./parser-standard-_UZ5nkj3.js";
import { n as s, t as c } from "./options-CnU6rJZf.js";
// src/local/compilation/compiler.ts
function l(e, t) {
	return n(p(e, t));
}
function u(e, t, n) {
	let r, i = () => globalThis.performance?.now?.() ?? Date.now(), a = i(), o = {}, s = a, l = (e) => {
		let t = i();
		o[e] = t - s, s = t;
	};
	n?.semantic?.begin(c(t));
	let u = p(e, t, (e) => {
		r = e;
	}, n, l);
	return o.totalMs = i() - a, {
		result: u,
		parsed: r,
		...n?.semantic ? { semantic: n.semantic.stats } : {},
		timings: o
	};
}
function d(e) {
	return {
		ok: !1,
		diagnostics: [{
			code: "local.options.invalid",
			message: e.message,
			severity: "error",
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: e.key,
			...e.detail === void 0 ? {} : { params: { detail: e.detail } }
		}]
	};
}
function f(n) {
	return {
		...n?.parser ? { parser: n.parser } : {},
		...n?.semantic ? { semantic: n.semantic } : {},
		...n?.rowPlans ? { rowPlans: n.rowPlans } : {},
		display: n?.semantic ? (e, t) => n.semantic.display(e, t) : a,
		htmlDocument: o,
		plotMath: {
			kind: i,
			gridSize: e,
			compile: t
		}
	};
}
function p(e, t, n, i, a) {
	let o = s(t);
	return o.ok ? r(e, t, o, f(i), n, a) : d(o);
}
export { u as n, l as t };
