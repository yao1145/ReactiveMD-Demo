import { a as e, i as t } from "./props-DGlBk0e5.js";
import { T as n, x as r, y as i } from "./manifest-gj41AWZb.js";
import { n as a, u as o } from "./registry-B9eKQgGq.js";
import { t as s } from "./compiler-I1hQZfUj.js";
import { t as c } from "./runtime-BURmhlg5.js";
import { A as l, C as u, D as d, E as f, O as p, S as m, T as h, _ as g, a as _, b as v, c as y, d as b, f as x, h as S, i as C, k as w, m as T, n as E, o as D, p as O, r as k, t as A, u as j, v as M, w as ee, x as te, y as N } from "./values-CIt8AjiU.js";
// src/testing/behavior.ts
var P = /* @__PURE__ */ new Set([
	"protocol",
	"component",
	"source",
	"binding",
	"writes",
	"reset"
]), F = /* @__PURE__ */ new Set([
	"id",
	"slot",
	"value",
	"values",
	"accepted",
	"expect"
]), I = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, L = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function ne(e, t, n) {
	let r = `spec.writes[${t}]`, i = j(e, r);
	A(i, F, r);
	let a = k(i.id, `${r}.id`, n, `write.${t}`), o = E(i.accepted, `${r}.accepted`), s = i.value !== void 0, c = i.values !== void 0;
	if (s === c) throw TypeError(`${r} must declare exactly one of "value" or "values".`);
	let l;
	if (i.slot !== void 0) {
		if (c) throw TypeError(`${r}.slot cannot be combined with "values".`);
		if (l = y(i.slot, `${r}.slot`, 128), !L.test(l)) throw TypeError(`${r}.slot is not a declared slot name.`);
	}
	let u = s ? C(i.value, `${r}.value`) : void 0, d = c ? _(i.values, `${r}.values`, 16) : void 0, f = i.expect === void 0 ? void 0 : _(i.expect, `${r}.expect`, 16);
	return Object.freeze({
		id: a,
		accepted: o,
		...l === void 0 ? {} : { slot: l },
		...u === void 0 ? {} : { value: u },
		...d === void 0 ? {} : { values: d },
		...f === void 0 ? {} : { expect: f }
	});
}
function R(e) {
	let t = j(e, "spec");
	if (A(t, P, "spec"), t.protocol !== "reactive-md-behavior-spec/v1") throw TypeError(`spec.protocol must be "${g}".`);
	let n = y(t.component, "spec.component", 128);
	if (!I.test(n)) throw TypeError("spec.component must be a lowercase kebab-case tag name.");
	let r = y(t.source, "spec.source", p);
	if (r.trim() === "") throw TypeError("spec.source must not be empty.");
	let i;
	if (t.binding !== void 0 && (i = y(t.binding, "spec.binding", 128), !L.test(i))) throw TypeError("spec.binding must be a public parameter name.");
	let a;
	if (t.writes !== void 0) {
		if (!Array.isArray(t.writes)) throw TypeError("spec.writes must be an array.");
		if (t.writes.length > 64) throw TypeError("spec.writes accepts at most 64 entries.");
		let e = /* @__PURE__ */ new Set();
		a = Object.freeze(t.writes.map((t, n) => ne(t, n, e)));
	}
	let o = t.reset === void 0 ? void 0 : E(t.reset, "spec.reset");
	return Object.freeze({
		protocol: g,
		component: n,
		source: r,
		...i === void 0 ? {} : { binding: i },
		...a === void 0 ? {} : { writes: a },
		...o === void 0 ? {} : { reset: o }
	});
}
function re(e, t) {
	let n = [], r = [...e];
	for (; r.length > 0;) {
		let e = r.pop();
		if (e && (e.type !== "text" && e.name === t && n.push(e), Array.isArray(e.children))) for (let t of e.children) r.push(t);
	}
	return n;
}
function z(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function ie(e) {
	return Array.isArray(e) ? Object.freeze(e.slice()) : e ?? null;
}
function B(e, t) {
	let n = [];
	for (let [r, i] of Object.entries(e.bindings ?? {})) {
		if (i.requiresAttributes?.some((e) => !Object.hasOwn(t.attrs ?? {}, e))) continue;
		let e = t.attrs?.[i.bind], a = typeof e == "string" && e !== "";
		n.push({
			slot: r,
			parameter: a ? e : r,
			public: a,
			node: t
		});
	}
	return n;
}
function V(e, t) {
	let n = {};
	for (let r of t) n[r.parameter] = ie(H(e, r));
	return n;
}
function H(e, t) {
	return t.public ? e.getParameter(t.parameter) : e.get(t.node, t.slot === "value" ? void 0 : t.slot);
}
function U(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) t[`value.${n}`] = r;
	return t;
}
function W(e, t, n, r, i) {
	let a = n.id ?? `write.${r}`, o = e.snapshot().revision, s = V(e, [...i.values()]), c = [], l = [], u = [];
	try {
		if (n.values !== void 0) {
			let r = {};
			for (let [e, t] of Object.entries(n.values)) {
				if (!i.has(e)) {
					c.push({
						code: "testing.spec",
						message: `Spec writes unknown slot "${e}".`
					});
					continue;
				}
				let n = z(t);
				Array.isArray(n) && l.push({
					parameter: i.get(e).parameter,
					value: n
				}), r[e] = n;
			}
			u = c.length > 0 ? c : e.setMany(t, r);
		} else {
			let r = n.slot ?? "value";
			if (!i.has(r)) c.push({
				code: "testing.spec",
				message: `Spec writes unknown slot "${r}".`
			}), u = c;
			else {
				let a = z(n.value ?? null);
				Array.isArray(a) && l.push({
					parameter: i.get(r).parameter,
					value: a
				}), u = e.set(t, a, r === "value" ? void 0 : r);
			}
		}
	} catch (e) {
		c.push({
			code: "testing.behavior",
			message: D(e)
		}), u = c;
	}
	let d = u.length === 0, f = e.snapshot().revision, p = V(e, [...i.values()]), m = !b(s, p), h = [];
	if (d !== n.accepted && h.push(`Expected the write to be ${n.accepted ? "accepted" : "rejected"}, but it was ${d ? "accepted" : "rejected"}.`), d) {
		m && f <= o && h.push("An accepted change did not advance the runtime revision."), !m && f !== o && h.push("A no-op accepted write advanced the runtime revision.");
		for (let [e, t] of Object.entries(n.expect ?? {})) x(p[e], t) || h.push(`Parameter "${e}" is ${JSON.stringify(p[e])}, expected ${JSON.stringify(t)}.`);
	}
	for (let [e, t] of Object.entries(n.expect ?? {})) d || !x(s[e], t) && !x(p[e], t) && h.push(`Parameter "${e}" did not retain the expected value ${JSON.stringify(t)}.`);
	let g = [];
	if (g.push(h.length === 0 ? T(`behavior.write.${a}`, "behavior", { observed: {
		accepted: d,
		changed: m,
		revision: f,
		...U(p)
	} }) : O(`behavior.write.${a}`, "behavior", h.join(" "), u)), !d) {
		let e = [];
		f !== o && e.push(`Revision changed from ${o} to ${f}.`), b(s, p) || e.push("A rejected write changed public parameters."), g.push(e.length === 0 ? T(`behavior.rollback.${a}`, "behavior", { observed: { revision: f } }) : O(`behavior.rollback.${a}`, "behavior", e.join(" ")));
	}
	if (d && l.length > 0) {
		let t = [];
		for (let n of l) {
			Array.isArray(n.value) && n.value.length > 0 && (n.value[0] = typeof n.value[0] == "number" ? 999999 : "__mutated__");
			let r = V(e, [...i.values()]);
			x(r[n.parameter], p[n.parameter]) || t.push(`Mutating the written array changed stored parameter "${n.parameter}".`);
			let a = H(e, [...i.values()].find((e) => e.parameter === n.parameter));
			if (Array.isArray(a) && a.length > 0) {
				a[0] = typeof a[0] == "number" ? -999999 : "__read_mutated__";
				let r = V(e, [...i.values()]);
				x(r[n.parameter], p[n.parameter]) || t.push(`Mutating a returned array changed stored parameter "${n.parameter}".`);
			}
		}
		g.push(t.length === 0 ? T(`behavior.copy.${a}`, "behavior") : O(`behavior.copy.${a}`, "behavior", t.join(" ")));
	}
	return g;
}
function G(e, t) {
	let n = R(e), r = o(t), i = a(r).find((e) => e.name === n.component), l = [];
	if (!i) return l.push(O("behavior.component", "behavior", `Component <${n.component}> is not installed in this configuration.`)), Object.freeze({
		protocol: N,
		suite: "behavior",
		configKey: r.key,
		component: null,
		cases: Object.freeze(l)
	});
	let u = Object.freeze({
		id: i.id,
		name: i.name,
		version: i.version
	}), d = s(n.source, { config: r });
	if (!d.ok) return l.push(O("behavior.compile", "behavior", "The compliance source did not compile.", d.diagnostics)), l.push(S("behavior.execute", "behavior", "Skipped because the source did not compile.")), Object.freeze({
		protocol: N,
		suite: "behavior",
		configKey: r.key,
		component: u,
		cases: Object.freeze(l)
	});
	l.push(T("behavior.compile", "behavior"));
	let f = re(d.document.nodes, n.component);
	if (f.length !== 1) return l.push(O("behavior.node", "behavior", `Expected exactly one <${n.component}> node, found ${f.length}.`)), Object.freeze({
		protocol: N,
		suite: "behavior",
		configKey: r.key,
		component: u,
		cases: Object.freeze(l)
	});
	let p = f[0];
	l.push(T("behavior.node", "behavior"));
	let m = B(i, p);
	if (!(Object.keys(i.bindings ?? {}).length > 0)) return l.push(S("behavior.bindings", "behavior", "The manifest declares no bindings.")), (n.writes ?? []).length > 0 && l.push(O("behavior.writes", "behavior", "Write cases were supplied for a component without bindings.")), l.push(S("behavior.interactive", "behavior", "No bindings: interactive behavior must be executed by the browser suite.", ["interactive"])), Object.freeze({
		protocol: N,
		suite: "behavior",
		configKey: r.key,
		component: u,
		cases: Object.freeze(l)
	});
	if (m.length === 0) return l.push(O("behavior.bindings", "behavior", "The source does not bind any declared slot.")), Object.freeze({
		protocol: N,
		suite: "behavior",
		configKey: r.key,
		component: u,
		cases: Object.freeze(l)
	});
	if (n.binding !== void 0 && !m.some((e) => e.parameter === n.binding)) return l.push(O("behavior.parameter", "behavior", `The source does not bind parameter "${n.binding}".`)), Object.freeze({
		protocol: N,
		suite: "behavior",
		configKey: r.key,
		component: u,
		cases: Object.freeze(l)
	});
	l.push(T("behavior.bindings", "behavior", { observed: Object.fromEntries(m.map((e) => [e.slot, e.parameter])) }));
	let h = new Map(m.map((e) => [e.slot, e])), g = c(d.document);
	try {
		let e = V(g, m), t = g.snapshot().revision;
		l.push(T("behavior.initial", "behavior", { observed: {
			revision: t,
			...U(e)
		} }));
		let r = n.writes ?? [];
		r.length === 0 && l.push(S("behavior.writes", "behavior", "No write cases were supplied."));
		let i = 0, a = 0;
		for (let e = 0; e < r.length; e += 1) {
			let t = r[e], n = V(g, m), o = W(g, p, t, e, h);
			l.push(...o);
			let s = V(g, m);
			t.accepted && !b(n, s) && (i += 1), t.accepted || (a += 1);
		}
		let o = n.reset !== !1;
		if (o) {
			let t = g.resetToken(p), n = g.snapshot().revision;
			g.reset(p);
			let r = g.resetToken(p), i = g.snapshot().revision, a = V(g, m), o = [];
			b(e, a) || o.push("Reset did not restore the authored initial values."), r > t || o.push("Reset did not advance the reset token."), i > n || o.push("Reset did not advance the runtime revision."), l.push(o.length === 0 ? T("behavior.reset", "behavior", { observed: {
				revision: i,
				token: r,
				...U(a)
			} }) : O("behavior.reset", "behavior", o.join(" ")));
		} else l.push(S("behavior.reset", "behavior", "Reset checks were disabled by the spec."));
		i > 0 && a > 0 && o ? l.push(T("behavior.interactive", "behavior", { capabilities: ["interactive"] })) : l.push(S("behavior.interactive", "behavior", "Interactive evidence requires at least one accepted change, one rejected write and an executed reset.", ["interactive"]));
	} finally {
		g.dispose();
	}
	return Object.freeze({
		protocol: N,
		suite: "behavior",
		configKey: r.key,
		component: u,
		cases: Object.freeze(l)
	});
}
Object.freeze({
	maxWrites: 64,
	maxSlots: 16,
	maxStringLength: w
});
// src/testing/manifest.ts
var K = {
	evaluate() {
		throw Error("Expression evaluation is not available in manifest compliance.");
	},
	text(e) {
		return e;
	}
};
function q(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version
	});
}
function J(e, t, n) {
	try {
		t();
	} catch (t) {
		let r = D(t);
		return n !== void 0 && !r.includes(n) ? O(e, "manifest", `Rejected with an unexpected message: ${r}`) : T(e, "manifest");
	}
	return O(e, "manifest", "Invalid manifest input was accepted.");
}
function Y(e, t) {
	try {
		return t(), T(e, "manifest");
	} catch (t) {
		return O(e, "manifest", `Expected acceptance, got: ${D(t)}`);
	}
}
function ae(e) {
	let t;
	try {
		t = new RegExp(e);
	} catch {
		return null;
	}
	for (let e of [
		"",
		"x",
		"!",
		"\0"
	]) if (!t.test(e)) return e;
	return null;
}
function oe(e) {
	switch (e.kind) {
		case "number": return "not-a-number";
		case "boolean": return "maybe";
		case "enum": return "__invalid__";
		case "string": return e.color === !0 ? "#zzz" : e.pattern === void 0 ? void 0 : ae(e.pattern) ?? void 0;
		default: return;
	}
}
function se(e) {
	switch (e.kind) {
		case "number": return "not-a-number";
		case "boolean": return "yes";
		case "enum": return "__invalid__";
		case "string": return 42;
		default: return 42;
	}
}
function X(e) {
	return JSON.parse(JSON.stringify(e));
}
function ce(e, t, n) {
	return Object.defineProperty(e, t, {
		value: n,
		enumerable: !0,
		configurable: !0,
		writable: !0
	}), e;
}
function le(a) {
	let o;
	try {
		o = n(a);
	} catch (e) {
		let t = D(e);
		return Object.freeze({
			protocol: N,
			suite: "manifest",
			configKey: "invalid",
			component: null,
			cases: Object.freeze([O("manifest.normalize", "manifest", t, [{
				code: "testing.manifest",
				message: t
			}])])
		});
	}
	let s = [], c = X(o), l = r(o);
	s.push(Y("manifest.normalize", () => {
		let e = n(c);
		if (r(e) !== l) throw Error("A plain JSON round trip changed the semantic digest.");
	}));
	let u = X(o), d = u.props;
	if (d && typeof d == "object" && !Array.isArray(d)) {
		let e = {};
		for (let t of Object.keys(d).reverse()) e[t] = d[t];
		u.props = e;
	}
	s.push(Y("manifest.key-order", () => {
		let e = n(u);
		if (r(e) !== l) throw Error("Reordering props changed the semantic digest.");
	}));
	let f = Object.keys(o.props).sort();
	for (let e of f) {
		let n = o.props[e], r = e.replace(/[^A-Za-z0-9._-]/g, "_");
		if (n.default !== void 0) {
			s.push((() => {
				try {
					let i = t(o, e, void 0, K), a = C(n.default, `props.${e}.default`);
					return x(i, a) ? T(`manifest.default.${r}`, "manifest") : O(`manifest.default.${r}`, "manifest", `Declared default ${JSON.stringify(a)} resolved as ${JSON.stringify(i)}.`);
				} catch (e) {
					return O(`manifest.default.${r}`, "manifest", D(e));
				}
			})());
			let i = oe(n);
			i !== void 0 && s.push(J(`manifest.invalid-value.${r}`, () => t(o, e, i, K)));
		}
		n.required === !0 && n.default === void 0 && s.push(J(`manifest.required.${r}`, () => t(o, e, void 0, K)));
	}
	s.push(J("manifest.unknown-attribute", () => e(o, { __undeclared: "x" }, K))), s.push(J("manifest.unknown-field", () => {
		let e = X(o);
		e.__undeclared = !0, n(e);
	}, "unknown field")), s.push(J("manifest.dangerous-key", () => n(ce(X(o), "__proto__", 1)), "not allowed"));
	for (let [e, t] of [
		["id", (e) => {
			e.id = "Bad/Id";
		}],
		["name", (e) => {
			e.name = "Bad Name";
		}],
		["version", (e) => {
			e.version = "1";
		}],
		["protocol", (e) => {
			e.protocol = "reactive-md-component/v2";
		}],
		["form", (e) => {
			e.form = "box";
		}]
	]) s.push(J(`manifest.invalid-identity.${e}`, () => {
		let e = X(o);
		t(e), n(e);
	}));
	for (let e of f) {
		let t = o.props[e];
		if (t.default === void 0) continue;
		let r = e.replace(/[^A-Za-z0-9._-]/g, "_");
		s.push(J(`manifest.invalid-default.${r}`, () => {
			let r = X(o), i = r.props;
			i[e] = {
				...i[e],
				default: se(t)
			}, n(r);
		}));
	}
	return s.push(Y("manifest.define-round-trip", () => {
		let e = i(c);
		if (r(e) !== l) throw Error("defineLocalComponent changed the semantic digest.");
	})), Object.freeze({
		protocol: N,
		suite: "manifest",
		configKey: l,
		component: q(o),
		cases: Object.freeze(s)
	});
}
// src/testing/report.ts
var Z = [
	"interactive",
	"static",
	"ssr",
	"offline"
], ue = new Set(Z), de = /* @__PURE__ */ new Set([
	"passed",
	"failed",
	"skipped",
	"unsupported"
]), fe = /* @__PURE__ */ new Set([
	"manifest",
	"behavior",
	"react",
	"browser"
]);
function pe(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version
	});
}
function Q(e) {
	return Object.freeze(Z.filter((t) => e.capabilities[t] === !0));
}
function $(e, t) {
	if (!Array.isArray(e)) throw TypeError(`${t} must be an array.`);
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		if (typeof i != "string" || !ue.has(i)) throw TypeError(`${t} contains an unknown capability.`);
		if (n.has(i)) throw TypeError(`${t} repeats "${i}".`);
		n.add(i), r.push(i);
	}
	return Object.freeze(r);
}
function me(e) {
	if (!Array.isArray(e)) throw TypeError("report.suites must be an array.");
	if (e.length > 16) throw TypeError("report.suites accepts at most 16 suites.");
	for (let t = 0; t < e.length; t += 1) {
		let n = e[t];
		if (!n || typeof n != "object" || Array.isArray(n)) throw TypeError(`report.suites[${t}] must be a suite result.`);
		if (n.protocol !== "reactive-md-compliance/v1") throw TypeError(`report.suites[${t}] has an unsupported protocol.`);
		if (typeof n.suite != "string" || !fe.has(n.suite)) throw TypeError(`report.suites[${t}] has an unknown suite name.`);
		if (!Array.isArray(n.cases) || n.cases.length > 512) throw TypeError(`report.suites[${t}].cases must be an array.`);
		for (let e of n.cases) if (!e || typeof e.id != "string" || typeof e.status != "string" || !de.has(e.status)) throw TypeError(`report.suites[${t}] contains an invalid case.`);
	}
	return e;
}
function he(e) {
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r of e) for (let e of r.cases) n.has(e.id) ? t.push(O("report.duplicate-case", "manifest", `Case id "${e.id}" appears more than once; evidence is ambiguous.`)) : (n.add(e.id), t.push(e));
	return t;
}
function ge(e, t) {
	let n = t.filter((t) => t.capabilities?.includes(e)), r = n.filter((e) => e.status === "passed");
	if (r.length > 0) return Object.freeze({
		capability: e,
		status: "passed",
		cases: Object.freeze(r.map((e) => e.id))
	});
	let i = "unsupported";
	n.some((e) => e.status === "failed") ? i = "failed" : n.some((e) => e.status === "unsupported") ? i = "unsupported" : n.some((e) => e.status === "skipped") && (i = "skipped");
	let a = n.length === 0 ? `No compliance suite executed a case for "${e}".` : `Declared capability "${e}" has no passed evidence (${i}).`;
	return Object.freeze({
		capability: e,
		status: i,
		cases: Object.freeze(n.map((e) => e.id)),
		reason: a
	});
}
function _e(e) {
	let t = 0, n = 0, r = 0, i = 0;
	for (let a of e) a.status === "passed" ? t += 1 : a.status === "failed" ? n += 1 : a.status === "skipped" ? r += 1 : i += 1;
	return Object.freeze({
		passed: t,
		failed: n,
		skipped: r,
		unsupported: i
	});
}
function ve(e, t) {
	let n = [], r = /* @__PURE__ */ new Set(), i = (e) => {
		let t = `${e.code}\u0000${e.message}`;
		r.has(t) || (r.add(t), n.push(e));
	};
	for (let t of e) if (t.status === "failed") {
		if (t.diagnostics.length === 0) i({
			code: "testing.case-failed",
			message: t.message ?? t.id
		});
		else for (let e of t.diagnostics) i(e);
	}
	for (let e of t) e.status !== "passed" && i({
		code: "testing.capability-evidence",
		message: e.reason ?? `No passed evidence for capability "${e.capability}".`
	});
	return Object.freeze(n);
}
function ye(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("createLocalComplianceReport requires an options object.");
	let t = o(e.config), n = a(t), i, s;
	if (typeof e.component == "string") s = e.component, i = n.find((t) => t.name === e.component);
	else {
		let t = e.component;
		s = t.id, i = n.find((e) => e.id === t.id || e.name === t.name);
	}
	if (!i) return Object.freeze({
		protocol: N,
		ok: !1,
		complete: !1,
		configKey: t.key,
		component: null,
		capabilities: Object.freeze([]),
		cases: Object.freeze([]),
		summary: Object.freeze({
			passed: 0,
			failed: 0,
			skipped: 0,
			unsupported: 0
		}),
		diagnostics: Object.freeze([{
			code: "testing.component-missing",
			message: `Component "${s}" is not installed in this configuration.`
		}])
	});
	let c = me(e.suites), l = [], u = [];
	for (let [e, n] of c.entries()) {
		let a = n.component, o = n.suite === "manifest" ? r(i) : t.key;
		!a || a.id !== i.id || a.name !== i.name || a.version !== i.version || n.configKey !== o ? u.push(O(`report.suite-contract.${e}`, "manifest", "Suite evidence belongs to another component, version or configuration.", [{
			code: "testing.suite-contract",
			message: "Run the suite with the same installed component and configuration."
		}])) : l.push(n);
	}
	let d = [...he(l), ...u], f = e.capabilities === void 0 ? Q(i) : $(e.capabilities, "report.capabilities"), p = new Set(f), m = Z.filter((e) => p.has(e)).map((e) => ge(e, d)), h = e.requireCapabilities !== !1, g = h ? m.filter((e) => e.status !== "passed") : [], _ = d.some((e) => e.status === "failed"), v = ve(d, g);
	return Object.freeze({
		protocol: N,
		ok: !_ && g.length === 0,
		complete: !_ && h && Q(i).every((e) => p.has(e) && m.some((t) => t.capability === e && t.status === "passed")),
		configKey: t.key,
		component: pe(i),
		capabilities: Object.freeze(m),
		cases: Object.freeze(d),
		summary: _e(d),
		diagnostics: v
	});
}
function be(e, t) {
	let n = new Map(e.cases.map((e) => [e.id, e])), r = new Map(t.cases.map((e) => [e.id, e])), i = [.../* @__PURE__ */ new Set([...n.keys(), ...r.keys()])].sort(), a = [];
	for (let e of i) {
		let t = n.get(e), i = r.get(e);
		if (!t || !i) {
			a.push(Object.freeze({
				case: e,
				message: `Case "${e}" exists only in the ${t ? "left" : "right"} result.`
			}));
			continue;
		}
		if (t.status !== i.status) {
			a.push(Object.freeze({
				case: e,
				message: `Status differs: ${t.status} vs ${i.status}.`
			}));
			continue;
		}
		let o = [...t.capabilities ?? []].sort().join(","), s = [...i.capabilities ?? []].sort().join(",");
		o === s ? b(t.observed ?? {}, i.observed ?? {}) || a.push(Object.freeze({
			case: e,
			message: "Observed values differ."
		})) : a.push(Object.freeze({
			case: e,
			message: `Capability evidence differs: [${o}] vs [${s}].`
		}));
	}
	return Object.freeze({
		ok: a.length === 0,
		mismatches: Object.freeze(a)
	});
}
function xe(e) {
	let t = e.message ?? e.diagnostics.map((e) => e.message).join(" ");
	return t ? `${e.id}: ${t}` : e.id;
}
export { g as LOCAL_BEHAVIOR_SPEC_PROTOCOL, M as LOCAL_BROWSER_SPEC_PROTOCOL, N as LOCAL_COMPLIANCE_PROTOCOL, v as LOCAL_REACT_SPEC_PROTOCOL, te as MAX_LOCAL_COMPLIANCE_ARRAY_LENGTH, m as MAX_LOCAL_COMPLIANCE_CASES, u as MAX_LOCAL_COMPLIANCE_ERROR_PATTERNS, ee as MAX_LOCAL_COMPLIANCE_EXPRESSION_LENGTH, h as MAX_LOCAL_COMPLIANCE_MARKUP_PATTERNS, f as MAX_LOCAL_COMPLIANCE_SELECTOR_LENGTH, d as MAX_LOCAL_COMPLIANCE_SLOTS, p as MAX_LOCAL_COMPLIANCE_SOURCE_LENGTH, w as MAX_LOCAL_COMPLIANCE_STRING_LENGTH, l as MAX_LOCAL_COMPLIANCE_WRITES, be as compareLocalComplianceParity, ye as createLocalComplianceReport, xe as describeLocalComplianceCase, R as readLocalBehaviorSpec, G as runLocalBehaviorCompliance, le as runLocalManifestCompliance };
