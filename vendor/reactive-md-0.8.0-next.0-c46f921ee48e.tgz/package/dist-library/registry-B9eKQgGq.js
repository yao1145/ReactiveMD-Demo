import { C as e, D as t, L as n } from "./manifest-gj41AWZb.js";
import { K as r, U as i, a, c as o, f as s, i as c, l, n as u, o as d, r as f, s as ee, t as p } from "./config-validation-DaLdxnS1.js";
import { n as te, t as m } from "./default-d2u6mrJW.js";
// src/local/theme/theme.ts
var h = "reactive-md-theme-1", g = Object.freeze({
	name: "default",
	protocol: h,
	colorSchemes: Object.freeze(["light", "dark"])
});
function ne(e, t) {
	let n = typeof t == "string" ? t.length : Infinity;
	if (!e || typeof e.start != "number" || typeof e.end != "number" || !Number.isFinite(e.start) || !Number.isFinite(e.end)) return {
		start: 0,
		end: 0
	};
	let r = Math.max(0, Math.min(n, Math.floor(e.start)));
	return {
		start: r,
		end: Math.max(r, Math.min(n, Math.floor(e.end)))
	};
}
function re(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.min(t, e.length), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: t - i + 1
	};
}
function ie(e, t, n, r) {
	let a = ne(n, r), { line: o, column: s } = re(r, a.start);
	return {
		code: e,
		message: i(t),
		severity: "warning",
		range: a,
		line: o,
		column: s,
		messageKey: t.key,
		...t.params ? { params: t.params } : {}
	};
}
function ae(e, t, n, i) {
	let a = (e, t) => ({
		name: g.name,
		diagnostics: [ie(e, t, n, i)]
	}), o = e;
	if (o == null || o === "") return {
		name: g.name,
		diagnostics: []
	};
	if (!s(o)) return a("local.theme.name", r("local.theme.name", {
		name: String(o),
		limit: 64
	}));
	let c = o;
	if (c === g.name) return {
		name: g.name,
		diagnostics: []
	};
	if (!Array.isArray(t)) return a("local.theme.missing", r("local.theme.missing", { name: c }));
	let l = 0, u = null;
	try {
		for (let e of t) typeof e == "object" && e && !Array.isArray(e) && e.name === c && (l += 1, u = e);
	} catch {
		return a("local.theme.manifest", r("local.theme.manifest.unreadable"));
	}
	if (l === 0) return a("local.theme.missing", r("local.theme.missing", { name: c }));
	if (l > 1) return a("local.theme.duplicate", r("local.theme.duplicate", { name: c }));
	try {
		let e = u;
		if (!e || typeof e != "object") return a("local.theme.manifest", r("local.theme.manifest.definition", { name: c }));
		if (e.protocol !== "reactive-md-theme-1") return a("local.theme.protocol", r("local.theme.protocol", {
			name: c,
			protocol: h
		}));
		let t = e.colorSchemes;
		if (!Array.isArray(t) || !t.includes("light") || !t.includes("dark")) return a("local.theme.modes", r("local.theme.modes", { name: c }));
	} catch {
		return a("local.theme.manifest", r("local.theme.manifest.selected", { name: c }));
	}
	return {
		name: c,
		diagnostics: []
	};
}
// src/sdk/theme.ts
var oe = 128, se = 32, ce = 128, _ = 262144, v = 524288, le = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/, ue = /^[a-z][a-z0-9._/-]*$/, de = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/, y = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/, fe = /^(?::root|html|body)(?![A-Za-z0-9_-])/i, b = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]), pe = 256, me = /* @__PURE__ */ new Set([
	"serif",
	"sans-serif",
	"monospace",
	"cursive",
	"fantasy",
	"system-ui",
	"ui-serif",
	"ui-sans-serif",
	"ui-monospace",
	"ui-rounded",
	"math",
	"emoji",
	"fangsong",
	"-apple-system",
	"blinkmacsystemfont"
]), he = /* @__PURE__ */ new Set([
	"inherit",
	"initial",
	"unset",
	"revert",
	"revert-layer"
]), ge = /* @__PURE__ */ new Set([
	"caption",
	"icon",
	"menu",
	"message-box",
	"small-caption",
	"status-bar"
]), _e = /* @__PURE__ */ new Set([
	"xx-small",
	"x-small",
	"small",
	"medium",
	"large",
	"x-large",
	"xx-large",
	"xxx-large",
	"smaller",
	"larger"
]), ve = /^rmd-theme-([a-z][a-z0-9-]*)-font-([0-9a-f]+)$/;
function x(e, t) {
	return /* @__PURE__ */ Error(`Invalid local theme ${e}: ${t}`);
}
function S(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function C(e, t) {
	if (!S(e)) throw x(t, "must be an object.");
	return e;
}
function w(e, t) {
	if (typeof e != "string" || e.length === 0) throw x(t, "must be a non-empty string.");
	if (e.length > oe) throw x(t, `must not exceed ${oe} characters.`);
	if (!le.test(e)) throw x(t, `"${e}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return e;
}
function T(e, t) {
	if (!s(e)) throw x(t, "must be a lowercase kebab-case name that starts with a letter.");
	if (e === "default") throw x(t, "must not replace the reserved built-in \"default\" theme.");
	return e;
}
function E(e, t) {
	if (typeof e != "string" || !de.test(e)) throw x(t, "must be a semantic version such as \"1.0.0\".");
	return e;
}
function D(e, t) {
	if (e === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(e)) throw x(t, "must be an array of \"light\" and \"dark\".");
	let n = [];
	for (let r of e) {
		if (r !== "light" && r !== "dark") throw x(t, "may only contain \"light\" and \"dark\".");
		if (n.includes(r)) throw x(t, `must not repeat "${r}".`);
		n.push(r);
	}
	if (!n.includes("light") || !n.includes("dark")) throw x(t, "must declare both \"light\" and \"dark\".");
	return Object.freeze(n);
}
function O(e, t) {
	let n = e[t], r = t + 1;
	for (; r < e.length;) if (e[r] === "\\") r += 2;
	else {
		if (e[r] === n) return r + 1;
		r += 1;
	}
	return e.length;
}
function k(e, t, n, r) {
	let i = 0;
	for (let a = t; a < e.length; a += 1) {
		let t = e[a];
		if (t === "\"" || t === "'") a = O(e, a) - 1;
		else if (t === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === n) i += 1;
		else if (t === r && (--i, i === 0)) return a + 1;
	}
	return e.length;
}
function ye(e, t, n) {
	let r = t + 3;
	for (; r < e.length && /\s/.test(e[r]);) r += 1;
	if (e[r] !== "(") throw x(n, "has a malformed url() value.");
	for (r += 1; r < e.length && /\s/.test(e[r]);) r += 1;
	let i = e[r];
	if (i === "\"" || i === "'") {
		let t = e.indexOf(i, r + 1);
		if (t < 0) throw x(n, "has an unterminated url() string.");
		let a = e.slice(r + 1, t);
		for (r = t + 1; r < e.length && /\s/.test(e[r]);) r += 1;
		if (e[r] !== ")") throw x(n, "has a malformed url() value.");
		return {
			value: a.trim(),
			end: r + 1
		};
	}
	let a = e.indexOf(")", r);
	if (a < 0) throw x(n, "has an unterminated url() value.");
	return {
		value: e.slice(r, a).trim(),
		end: a + 1
	};
}
function be(e, t, n, r) {
	let i = t;
	for (; i < e.length && e[i] !== "(";) i += 1;
	if (i >= e.length) throw x(r, `has a malformed ${n}() value.`);
	let a = k(e, i, "(", ")");
	if (a <= i + 1 || e[a - 1] !== ")") throw x(r, `has an unterminated ${n}() value.`);
	return {
		body: e.slice(i + 1, a - 1),
		end: a
	};
}
function xe(e, t) {
	let n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (r === "\"" || r === "'") {
			let i = O(e, n);
			if (i > e.length || e[i - 1] !== r) throw x(t, "has an unterminated image-set() string.");
			let a = e.slice(n + 1, i - 1).trim();
			if (!/^data:/i.test(a)) throw x(t, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			n = i;
		} else if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else n += 1;
	}
}
function A(e, t, n = !1) {
	if (e.toLowerCase().includes("</style")) throw x(t, "must not contain a closing style tag.");
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = O(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else {
			if (i === "\\") throw x(t, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
			if (i === "@" && /^@import\b/i.test(e.slice(r, r + 8))) throw x(t, "must not use @import; inline every resource.");
			if ((i === "i" || i === "I" || i === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(e.slice(r, r + 24))) {
				let { body: n } = be(e, r, "image-set", t);
				xe(n, t), r += 1;
			} else if ((i === "u" || i === "U") && /^url\s*\(/i.test(e.slice(r, r + 12))) {
				let i = ye(e, r, t);
				if (!/^data:/i.test(i.value) && !(n && i.value.startsWith("#"))) throw x(t, "may only reference data: URLs; network and file URLs are not allowed.");
				r = i.end;
			} else {
				if ((i === "e" || i === "E") && /^expression\s*\(/i.test(e.slice(r, r + 16))) throw x(t, "must not use CSS expression().");
				r += 1;
			}
		}
	}
}
function Se(e) {
	if (typeof e != "string" || e.length > 4194304) return !1;
	try {
		return A(e, "css", !0), !0;
	} catch {
		return !1;
	}
}
function j(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		if (o === "\"" || o === "'") a = O(e, a) - 1;
		else if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else o === "\\" ? a += 1 : o === "(" ? r += 1 : o === ")" ? r = Math.max(0, r - 1) : o === "[" ? i += 1 : o === "]" ? i = Math.max(0, i - 1) : o === "," && r === 0 && i === 0 && (t.push(e.slice(n, a)), n = a + 1);
	}
	return t.push(e.slice(n)), t;
}
function Ce(e, t) {
	let n = e.trim(), r = `[data-rmd-theme="${t}"]`, i = y.exec(n);
	return i ? `${r}${n.slice(i[0].length)}` : `${r} ${n}`;
}
function we(e, t) {
	let n = t;
	for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
	else if (e[n] === "/" && e[n + 1] === "*") {
		let t = e.indexOf("*/", n + 2);
		n = t < 0 ? e.length : t + 2;
	} else break;
	return n;
}
function Te(e, t) {
	let n = e.toLowerCase(), r = /:has\s*\(/g;
	for (let i = r.exec(n); i; i = r.exec(n)) {
		if (r.lastIndex = i.index + 1, i.index >= t) continue;
		let n = i.index + i[0].length - 1, a = k(e, n, "(", ")"), o = e.slice(n + 1, Math.max(n + 1, a - 1));
		for (let t of j(o)) if (/^\s*[+~]/.test(t)) throw x("theme.css", `selector "${e.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
function Ee(e) {
	let t = e.trim();
	if (t === "") return;
	if (t[0] === "+" || t[0] === "~") throw x("theme.css", `selector "${t}" begins with a sibling combinator and cannot be scoped.`);
	let n = y.exec(t);
	if (n) {
		let e = n[0].length;
		for (; e < t.length;) {
			let n = t[e];
			if (/\s/.test(n) || n === "+" || n === "~" || n === ">" || n === ",") break;
			n === "[" ? e = k(t, e, "[", "]") : n === "(" ? e = k(t, e, "(", ")") : e += 1;
		}
		let r = we(t, e);
		if (t[r] === "+" || t[r] === "~") throw x("theme.css", `selector "${t}" uses a sibling combinator that can escape the theme root.`);
		Te(t, e);
	}
}
function De(e, t) {
	let n = j(e).map((e) => e.trim()).filter(Boolean);
	if (n.length === 0) return e.trim();
	for (let e of n) {
		if (fe.test(e)) throw x("theme.css", `selector "${e}" targets the host document; scope it under the theme root instead.`);
		Ee(e);
	}
	return n.map((e) => Ce(e, t)).join(", ");
}
function M(e, t) {
	let n = 1;
	for (let r = t; r < e.length; r += 1) {
		let t = e[r];
		if (t === "\"" || t === "'") r = O(e, r) - 1;
		else if (t === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return r;
	}
	return e.length;
}
function N(e) {
	return e.trim().replace(/\s+/g, " ").toLowerCase();
}
function Oe(e) {
	let t = [];
	for (let n of e) {
		let e = n.codePointAt(0);
		e <= 127 ? t.push(e) : e <= 2047 ? t.push(192 | e >> 6, 128 | e & 63) : e <= 65535 ? t.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : t.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63);
	}
	return t;
}
function ke(e) {
	let t = "", n = 0;
	for (; n < e.length;) {
		let r = e[n], i, a;
		if (r <= 127) i = r, a = 1;
		else if (r >= 194 && r <= 223) i = r & 31, a = 2;
		else if (r >= 224 && r <= 239) i = r & 15, a = 3;
		else if (r >= 240 && r <= 244) i = r & 7, a = 4;
		else return null;
		if (n + a > e.length) return null;
		for (let t = 1; t < a; t += 1) {
			let r = e[n + t];
			if ((r & 192) != 128) return null;
			i = i << 6 | r & 63;
		}
		if (a === 3 && (i < 2048 || i >= 55296 && i <= 57343) || a === 4 && (i < 65536 || i > 1114111)) return null;
		t += String.fromCodePoint(i), n += a;
	}
	return t;
}
function Ae(e, t) {
	return `rmd-theme-${e}-font-${Oe(t).map((e) => e.toString(16).padStart(2, "0")).join("")}`;
}
function je(e) {
	let t = ve.exec(e);
	if (!t || t[2].length % 2 != 0) return null;
	let n = [];
	for (let e = 0; e < t[2].length; e += 2) n.push(Number.parseInt(t[2].slice(e, e + 2), 16));
	let r = ke(n);
	return r === null || r.length === 0 || N(r) !== r ? null : {
		themeName: t[1],
		original: r
	};
}
function P(e) {
	return e === void 0 ? !1 : /[A-Za-z0-9_-]/.test(e) || e.codePointAt(0) >= 128;
}
function Me(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (/[A-Za-z_]/.test(n) || n.codePointAt(0) >= 128) return !0;
	if (n === "-") {
		let n = e[t + 1];
		return n !== void 0 && (P(n) || n === "-");
	}
	return !1;
}
function Ne(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (n >= "0" && n <= "9") return !0;
	let r = e[t + 1];
	return n === "+" || n === "-" ? r !== void 0 && (r >= "0" && r <= "9" || r === ".") : n === "." && r !== void 0 && r >= "0" && r <= "9";
}
function F(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
			continue;
		}
		let i = n;
		if (r === "\"" || r === "'") {
			let r = O(e, n);
			t.push({
				type: "string",
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: e.slice(i + 1, Math.max(i + 1, r - 1))
			}), n = r;
		} else if (r === ",") t.push({
			type: "comma",
			text: ",",
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
		else if (Ne(e, n)) {
			let r = n;
			for ((e[r] === "+" || e[r] === "-") && (r += 1); e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === ".") for (r += 1; e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === "e" || e[r] === "E") {
				let t = r;
				r += 1, (e[r] === "+" || e[r] === "-") && (r += 1);
				let n = r;
				for (; e[r] >= "0" && e[r] <= "9";) r += 1;
				r === n && (r = t);
			}
			let a = "number";
			if (e[r] === "%") r += 1, a = "percentage";
			else if (Me(e, r)) {
				for (r += 1; P(e[r]);) r += 1;
				a = "dimension";
			}
			t.push({
				type: a,
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: ""
			}), n = r;
		} else if (Me(e, n)) {
			let r = n + 1;
			for (; P(e[r]);) r += 1;
			let a = e.slice(n, r).toLowerCase();
			if (e[r] === "(") {
				let o = k(e, r, "(", ")"), s = Math.min(o, e.length);
				t.push({
					type: "function",
					text: e.slice(n, s),
					start: i,
					end: s,
					name: a,
					stringValue: ""
				}), n = s;
				continue;
			}
			t.push({
				type: "ident",
				text: e.slice(n, r),
				start: i,
				end: r,
				name: a,
				stringValue: ""
			}), n = r;
		} else if (r === "(") {
			let r = k(e, n, "(", ")"), a = Math.min(r, e.length);
			t.push({
				type: "function",
				text: e.slice(n, a),
				start: i,
				end: a,
				name: "",
				stringValue: ""
			}), n = a;
		} else t.push({
			type: "delimiter",
			text: r,
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
	}
	return t;
}
function I(e) {
	return e.trim() === "";
}
function L(e) {
	let t = F(e);
	if (t.length === 0) return null;
	if (t.length === 1 && t[0].type === "string") {
		let e = N(t[0].stringValue);
		return e === "" ? null : {
			key: e,
			start: t[0].start,
			end: t[0].end
		};
	}
	if (t[0].type === "string") return null;
	for (let n = 0; n < t.length; n += 1) if (t[n].type !== "ident" || n > 0 && !I(e.slice(t[n - 1].end, t[n].start))) return null;
	if (t.length === 1 && (he.has(t[0].name) || me.has(t[0].name))) return null;
	let n = N(t.map((e) => e.text).join(" "));
	return n === "" ? null : {
		key: n,
		start: t[0].start,
		end: t[t.length - 1].end
	};
}
function R(e) {
	let t = [], n = 0, r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = O(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else i === "(" || i === "[" ? r = k(e, r, i, i === "(" ? ")" : "]") : (i === "," && (t.push({
			start: n,
			end: r
		}), n = r + 1), r += 1);
	}
	return t.push({
		start: n,
		end: e.length
	}), t;
}
function z(e) {
	let t = F(e);
	if (t.length < 2) return {
		body: e,
		important: ""
	};
	let n = t[t.length - 1], r = t[t.length - 2];
	return n.type !== "ident" || n.name !== "important" || r.type !== "delimiter" || r.text !== "!" || !I(e.slice(r.end, n.start)) ? {
		body: e,
		important: ""
	} : {
		body: e.slice(0, r.start),
		important: e.slice(r.start)
	};
}
function B(e, t) {
	if (t.length === 0) return e;
	let n = [...t].sort((e, t) => e.start - t.start), r = "", i = 0;
	for (let t of n) t.start < i || (r += e.slice(i, t.start) + t.text, i = t.end);
	return r + e.slice(i);
}
function V(e) {
	return `"${e}"`;
}
function H(e, t) {
	let { body: n, important: r } = z(e), i = R(n), a = [];
	for (let e of i) {
		let r = L(n.slice(e.start, e.end));
		if (!r) continue;
		let i = t.get(r.key);
		i && a.push({
			start: e.start + r.start,
			end: e.start + r.end,
			text: V(i)
		});
	}
	return B(n, a) + r;
}
function Pe(e) {
	let t = F(e);
	if (t.length === 0 || t.length === 1 && t[0].type === "ident" && (ge.has(t[0].name) || he.has(t[0].name))) return null;
	let n = -1;
	for (let e = 0; e < t.length; e += 1) {
		let r = t[e];
		if (r.type === "dimension" || r.type === "percentage" || r.type === "ident" && _e.has(r.name) || r.type === "number" && Number(r.text) === 0) {
			n = e;
			break;
		}
		if (r.type === "function") {
			let r = t[e + 1];
			if (r?.type === "delimiter" && r.text === "/") {
				n = e;
				break;
			}
		}
	}
	if (n < 0) return null;
	let r = n + 1, i = t[r];
	return i?.type === "delimiter" && i.text === "/" && (r += 2), r >= t.length ? null : t[r].start;
}
function Fe(e, t) {
	let { body: n, important: r } = z(e), i = Pe(n);
	if (i === null) return null;
	let a = H(n.slice(i), t);
	return `${n.slice(0, i)}${a}${r}`;
}
function U(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r) || r === ";" || r === "}") {
			n += 1;
			continue;
		}
		if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
			continue;
		}
		if (r === "{") {
			n = M(e, n + 1) + 1;
			continue;
		}
		let i = n, a = n;
		for (; a < e.length;) {
			let t = e[a];
			if (t === "\"" || t === "'") a = O(e, a);
			else if (t === "/" && e[a + 1] === "*") {
				let t = e.indexOf("*/", a + 2);
				a = t < 0 ? e.length : t + 2;
			} else if (t === "(" || t === "[") a = k(e, a, t, t === "(" ? ")" : "]");
			else {
				if (t === ":" || t === ";" || t === "{" || t === "}") break;
				a += 1;
			}
		}
		if (a >= e.length) break;
		if (e[a] !== ":") {
			n = e[a] === "{" ? M(e, a + 1) + 1 : a + 1;
			continue;
		}
		let o = e.slice(i, a).trim().toLowerCase(), s = a + 1, c = s;
		for (; c < e.length;) {
			let t = e[c];
			if (t === "\"" || t === "'") c = O(e, c);
			else if (t === "/" && e[c + 1] === "*") {
				let t = e.indexOf("*/", c + 2);
				c = t < 0 ? e.length : t + 2;
			} else if (t === "(" || t === "[") c = k(e, c, t, t === "(" ? ")" : "]");
			else {
				if (t === ";" || t === "{" || t === "}") break;
				c += 1;
			}
		}
		o !== "" && t.push({
			name: o,
			valueStart: s,
			valueEnd: c
		}), n = c, e[c] === ";" && (n = c + 1);
	}
	return t;
}
function Ie(e, t) {
	let n = [];
	for (let r of U(e)) {
		let i = r.name === "font-family" || r.name === "--font-sans" || r.name === "--font-mono";
		if (!i && r.name !== "font") continue;
		let a = e.slice(r.valueStart, r.valueEnd), o = i ? H(a, t) : Fe(a, t);
		o !== null && o !== a && n.push({
			start: r.valueStart,
			end: r.valueEnd,
			text: o
		});
	}
	return B(e, n);
}
function W(e, t, n) {
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (/\s/.test(i) || i === ";" || i === "}") {
			r += 1;
			continue;
		}
		if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
			continue;
		}
		if (i === "{") {
			r = M(e, r + 1) + 1;
			continue;
		}
		let a = r, o = r;
		for (; o < e.length;) {
			let t = e[o];
			if (t === "\"" || t === "'") o = O(e, o);
			else if (t === "/" && e[o + 1] === "*") {
				let t = e.indexOf("*/", o + 2);
				o = t < 0 ? e.length : t + 2;
			} else if (t === "(" || t === "[") o = k(e, o, t, t === "(" ? ")" : "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				o += 1;
			}
		}
		if (o >= e.length) break;
		if (e[o] !== "{") {
			r = o + 1;
			continue;
		}
		let s = M(e, o + 1), c = e.slice(a, o).trim();
		if (c.startsWith("@")) {
			let r = (/^@([A-Za-z-]+)/.exec(c)?.[1] ?? "").toLowerCase();
			r === "font-face" ? n(e.slice(o + 1, s), t) : b.has(r) && W(e.slice(o + 1, s), t, n);
		}
		r = Math.min(s + 1, e.length);
	}
}
function Le(e, t) {
	let n = U(e).filter((e) => e.name === "font-family");
	if (n.length === 0) throw x(t, "@font-face must declare a font-family descriptor.");
	if (n.length > 1) throw x(t, "@font-face may declare font-family only once.");
	let { body: r, important: i } = z(e.slice(n[0].valueStart, n[0].valueEnd));
	if (i !== "") throw x(t, "@font-face descriptors must not use !important.");
	if (R(r).length !== 1) throw x(t, "@font-face font-family must be a single family name, not a list.");
	let a = L(r);
	if (!a) throw x(t, "@font-face font-family must be one quoted or unquoted family name; generic families, keywords, var() and other functions are not allowed.");
	if (Oe(je(a.key)?.original ?? a.key).length > pe) throw x(t, `@font-face font-family must not exceed ${pe} UTF-8 bytes.`);
	return a.key;
}
function G(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i of e) W(i.css, n, (e, n) => {
		let i = Le(e, n), a = je(i), o = a ? a.original : i, s = Ae(t, o), c = r.get(i);
		if (c !== void 0 && c !== s) throw x(n, `@font-face family "${i}" maps to more than one name.`);
		r.set(i, s), r.set(o, s);
	});
	return r;
}
function Re(e, t, n) {
	let r = U(e).filter((e) => e.name === "font-family");
	if (r.length !== 1) throw x(n, "@font-face must declare exactly one font-family descriptor.");
	let i = r[0], { body: a } = z(e.slice(i.valueStart, i.valueEnd));
	if (R(a).length !== 1) throw x(n, "@font-face font-family must be a single family name, not a list.");
	let o = L(a);
	if (!o) throw x(n, "@font-face has an unsupported font-family descriptor.");
	let s = t.get(o.key);
	if (s === void 0) throw x(n, `@font-face family "${o.key}" was not registered.`);
	return B(e, [{
		start: i.valueStart + o.start,
		end: i.valueStart + o.end,
		text: V(s)
	}]);
}
var K = /* @__PURE__ */ new Map();
function ze(e, t, n = K) {
	let r = "", i = 0;
	for (; i < e.length;) {
		let a = e[i];
		if (a === "/" && e[i + 1] === "*") {
			let t = e.indexOf("*/", i + 2), n = t < 0 ? e.length : t + 2;
			r += e.slice(i, n), i = n;
			continue;
		}
		if (/\s/.test(a) || a === ";" || a === "}") {
			r += a, i += 1;
			continue;
		}
		let o = i, s = i;
		for (; s < e.length;) {
			let t = e[s];
			if (t === "\"" || t === "'") s = O(e, s);
			else if (t === "/" && e[s + 1] === "*") {
				let t = e.indexOf("*/", s + 2);
				s = t < 0 ? e.length : t + 2;
			} else if (t === "(") s = k(e, s, "(", ")");
			else if (t === "[") s = k(e, s, "[", "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				s += 1;
			}
		}
		if (s >= e.length) {
			r += e.slice(o);
			break;
		}
		let c = e.slice(o, s), l = e[s];
		if (l === ";" || l === "}") {
			r += c + l, i = s + 1;
			continue;
		}
		let u = M(e, s + 1), d = e.slice(s + 1, u), f = c.trim();
		if (f.startsWith("@")) {
			let e = (/^@([A-Za-z-]+)/.exec(f)?.[1] ?? "").toLowerCase();
			if (e === "import") throw x("theme.css", "must not use @import.");
			if (e === "keyframes" || e.endsWith("-keyframes")) throw x("theme.css", `@${e} declares a global name; phase one only supports document-scoped CSS.`);
			if (e === "font-face") r += `${f} {${Re(d, n, "theme.css")}}`;
			else {
				let i = b.has(e) ? ze(d, t, n) : d;
				r += `${f} {${i}}`;
			}
		} else r += `${De(f, t)} {${Ie(d, n)}}`;
		i = Math.min(u + 1, e.length);
	}
	return r;
}
function q(e, t, n = K) {
	return ze(e, t, n);
}
function J(e, t) {
	if (!Array.isArray(e)) throw x(t, "must be an array of { id, css } resources.");
	if (e.length > se) throw x(t, `may contain at most ${se} resources.`);
	let n = /* @__PURE__ */ new Set(), r = [], i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a], s = `${t}[${a}]`;
		if (!S(o)) throw x(s, "must be an object.");
		let c = o.id;
		if (typeof c != "string" || c.length === 0) throw x(`${s}.id`, "must be a non-empty string.");
		if (c.length > ce) throw x(`${s}.id`, `must not exceed ${ce} characters.`);
		if (!ue.test(c)) throw x(`${s}.id`, `"${c}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (n.has(c)) throw x(`${s}.id`, `"${c}" is declared more than once.`);
		n.add(c);
		let l = o.css;
		if (typeof l != "string") throw x(`${s}.css`, "must be a string.");
		if (l.length > _) throw x(`${s}.css`, `must not exceed ${_} characters.`);
		if (i += l.length, i > v) throw x(t, `must not exceed ${v} characters in total.`);
		A(l, `${s}.css`), r.push(Object.freeze({
			id: c,
			css: l
		}));
	}
	return {
		resources: Object.freeze(r),
		totalLength: i
	};
}
function Y(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		protocol: e.protocol,
		colorSchemes: Object.freeze([...e.colorSchemes]),
		css: Object.freeze(e.css.map((e) => Object.freeze({
			id: e.id,
			css: e.css
		})))
	});
}
function Be(e, t) {
	let n = C(e, t), r = w(n.id, `${t}.id`), i = T(n.name, `${t}.name`), a = E(n.version, `${t}.version`);
	if (n.protocol !== "reactive-md-theme-1") throw x(`${t}.protocol`, `must be "${h}".`);
	let o = D(n.colorSchemes, `${t}.colorSchemes`), { resources: s } = J(n.css, `${t}.css`);
	return Y({
		id: r,
		name: i,
		version: a,
		protocol: h,
		colorSchemes: o,
		css: s
	});
}
function Ve(e) {
	let t = C(e, "input"), n = w(t.id, "theme.id"), r = T(t.name, "theme.name"), i = E(t.version, "theme.version");
	if ((t.protocol === void 0 ? "reactive-md-theme-1" : t.protocol) !== "reactive-md-theme-1") throw x("theme.protocol", `must be "${h}".`);
	let a = D(t.colorSchemes, "theme.colorSchemes"), { resources: o } = J(t.css, "theme.css"), s = G(o, r, "theme.css");
	return Y({
		id: n,
		name: r,
		version: i,
		protocol: h,
		colorSchemes: a,
		css: o.map((e) => Object.freeze({
			id: e.id,
			css: q(e.css, r, s)
		}))
	});
}
function He(e) {
	let t = C(e, "input"), n = w(t.id, "theme.id"), r = T(t.name, "theme.name"), i = E(t.version, "theme.version"), a = Be(t.base, "theme.base"), o = J(t.overrides, "theme.overrides"), s = G([...a.css, ...o.resources], r, "theme.css"), c = new Set(a.css.map((e) => e.id));
	for (let e of o.resources) {
		if (c.has(e.id)) throw x("theme.overrides", `resource "${e.id}" is already declared by the base theme.`);
		c.add(e.id);
	}
	let l = [...a.css.map((e) => Object.freeze({
		id: e.id,
		css: q(e.css, r, s)
	})), ...o.resources.map((e) => Object.freeze({
		id: e.id,
		css: q(e.css, r, s)
	}))], u = 0;
	for (let e of l) if (u += e.css.length, u > v) throw x("theme.css", `must not exceed ${v} characters in total.`);
	return Y({
		id: n,
		name: r,
		version: i,
		protocol: a.protocol,
		colorSchemes: a.colorSchemes,
		css: l
	});
}
function Ue(e) {
	let { resources: t } = J(C(e, "theme").css, "theme.css");
	return t.map((e) => e.css).join("\n");
}
// src/sdk/config.ts
var We = m.id, X = m.version, Ge = Object.freeze({
	id: We,
	version: X
}), Ke = 16, qe = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"themes"
]), Je = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"colorSchemes",
	"css"
]), Z = /* @__PURE__ */ new WeakSet();
function Ye(e) {
	d(e) || a("themes", "each theme must be an object."), f(e, Je, "theme");
	try {
		return Ve(e);
	} catch (e) {
		a("theme", e instanceof Error ? e.message : String(e));
	}
}
function Xe(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || a("themes", "must be an array."), e.length > 16 && a("themes", "accepts at most 16 themes.");
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = Ye(i);
		t.has(e.id) && a("themes", `theme id "${e.id}" is declared more than once.`), n.has(e.name) && a("themes", `theme name "${e.name}" is declared more than once.`), t.add(e.id), n.add(e.name), r.push(e);
	}
	return Object.freeze(r);
}
function Ze(n, r) {
	d(n) || a(r, "must be an object."), f(n, qe, r);
	let i = o(n.presets, Ge), s = ee(n.components, m.components), l = Xe(n.themes);
	e({
		protocol: "reactive-md-config/v1",
		presets: i,
		components: s,
		themes: l
	}) > 16777216 && a(r, `serialized size exceeds the ${u}-byte budget.`);
	let p = Object.freeze({
		protocol: t,
		key: c(i, s),
		presets: i,
		components: s,
		registry: Object.freeze([...m.components, ...s]),
		themes: l
	});
	return Z.add(p), p;
}
function Qe(e = {}) {
	return Ze(e, "config");
}
var $e;
function et(e) {
	return e === void 0 ? $e ??= Qe().key : Q(e).key;
}
function tt(e, t) {
	return e.componentConfigKey === void 0 || e.componentConfigKey === et(t) ? [] : [{
		code: "local.extension.config-mismatch",
		severity: "error",
		message: "The document compiler configuration differs from the installed renderer. Recompile with the same host.config used by host.reactConfig (including Worker requests).",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}];
}
function Q(e) {
	return typeof e == "object" && e && Z.has(e) ? e : (d(e) || a("config", "must be an object."), f(e, p, "config"), e.protocol !== "reactive-md-config/v1" && a("config.protocol", `must be "${t}".`), Ze({
		presets: e.presets,
		components: e.components,
		themes: e.themes
	}, "config"));
}
function nt(e) {
	if (typeof e == "object" && e && Z.has(e)) return e.key;
	try {
		return Q(e).key;
	} catch {
		try {
			return `invalid:${n(JSON.stringify(e))}`;
		} catch {
			return "invalid";
		}
	}
}
function rt(e) {
	try {
		return Q(e);
	} catch {
		return e;
	}
}
// src/sdk/registry.ts
function it() {
	return te;
}
function $(e) {
	return e ? Q(e).registry : it();
}
function at(e, t) {
	let n = $(t);
	for (let t of n) if (t.name === e) return t;
}
function ot(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of $(e)) t.set(n.name, l(n));
	return t;
}
export { g as _, X as a, et as c, rt as d, tt as f, Se as g, Ve as h, We as i, nt as l, He as m, $ as n, Ke as o, Ue as p, ot as r, Qe as s, at as t, Q as u, h as v, ae as y };
