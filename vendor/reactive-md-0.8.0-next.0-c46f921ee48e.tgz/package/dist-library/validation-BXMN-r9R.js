import { n as e } from "./props-DGlBk0e5.js";
import { $ as t, B as n, C as r, D as i, H as a, I as o, Q as s, V as c, k as l, q as u, z as d } from "./manifest-gj41AWZb.js";
import { K as f, U as p, V as m, _ as h, a as g, c as _, d as v, g as y, h as b, i as x, n as S, o as C, p as w, r as T, s as E, t as ee, v as te } from "./config-validation-DaLdxnS1.js";
// src/local/source/text-length.ts
function ne(e) {
	if (typeof e != "string") return 0;
	let t = 0;
	for (let n of e) t += 1;
	return t;
}
// src/local/contracts/types.ts
var re = (e) => e.attrs?.bind ?? `@${e.id}`, D = class extends Error {
	code;
	constructor(e, t) {
		super(t), this.name = "LocalFunctionError", this.code = e;
	}
}, ie = [
	"en-US",
	"zh-CN",
	"de-DE",
	"fr-FR",
	"ja-JP"
], ae = new Set(ie), oe = /^[A-Z]{3}$/, se = 20;
function O(e) {
	throw new D("expression-domain", e);
}
function k(e, t) {
	if (e.length > 1e5) throw new D("expression-budget", `${t} exceeds the ${s}-character limit.`);
	return e;
}
function A(e) {
	return ae.has(e) || O(`Unsupported locale "${e}"; expected one of ${ie.join(", ")}.`), e;
}
function j(e, t) {
	return (!Number.isInteger(e) || e < 0 || e > se) && O(`${t} digits must be an integer from 0 to ${se}.`), e;
}
function ce(e) {
	if (!Number.isFinite(e)) throw new D("expression-number", "Value must be a finite number.");
	return e;
}
function le(e) {
	return e === 0 ? 0 : e;
}
function ue(e, t) {
	let n = ce(e);
	return n === 0 || Math.abs(n) < .5 * 10 ** -t ? 0 : n;
}
function de(e, t) {
	let n = ce(e);
	return n === 0 || Math.abs(n) < .5 * 10 ** -(t + 2) ? 0 : n;
}
function M(e, t, n, r, i) {
	let a;
	try {
		a = new Intl.NumberFormat(e, t);
	} catch {
		a = void 0;
	}
	return a === void 0 && O(i), k(a.format(n), r);
}
function fe(e, t = 2, n = "en-US", r = !0) {
	let i = A(n), a = j(t, "formatNumber");
	return typeof r != "boolean" && O("formatNumber grouping must be a boolean."), e === null ? "" : M(i, {
		useGrouping: r,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, ue(e, a), "Formatted number", `Cannot format a number for locale "${i}".`);
}
function pe(e, t = 0, n = "en-US") {
	let r = A(n), i = j(t, "formatPercent");
	return e === null ? "" : M(r, {
		style: "percent",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, de(e, i), "Formatted percentage", `Cannot format a percentage for locale "${r}".`);
}
function me(e, t = 2, n = "en-US") {
	let r = A(n), i = j(t, "formatScientific");
	return e === null ? "" : M(r, {
		notation: "scientific",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, le(ce(e)), "Formatted number", `Cannot format a number for locale "${r}".`);
}
function he(e, t = "USD", n = 2, r = "en-US") {
	let i = A(r);
	oe.test(t) || O(`Currency "${t}" must be a three-letter uppercase code such as "USD".`);
	let a = j(n, "formatCurrency");
	return e === null ? "" : M(i, {
		style: "currency",
		currency: t,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, ue(e, a), "Formatted currency", `Currency code "${t}" is not accepted by Intl.`);
}
// src/local/evaluation/collection-functions.ts
function ge() {
	throw new D("expression-number", "The result is not a finite number.");
}
function N(e) {
	if (!Number.isFinite(e)) throw new D("expression-value", "Numeric array members must be finite numbers.");
	return e;
}
function _e(e) {
	let t = 0;
	for (let n of e) t += N(n);
	return Number.isFinite(t) || ge(), t;
}
function ve(e) {
	if (e.length === 0) return null;
	let t = _e(e) / e.length;
	return Number.isFinite(t) || ge(), t;
}
function ye(e) {
	if (e.length === 0) return null;
	let t = N(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = N(e[n]);
		r < t && (t = r);
	}
	return t;
}
function be(e) {
	if (e.length === 0) return null;
	let t = N(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = N(e[n]);
		r > t && (t = r);
	}
	return t;
}
// src/local/evaluation/dates.ts
function xe(e) {
	let t = /^(\d{4})-(\d{2})-(\d{2})$/.exec(e);
	if (!t) return null;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	if (n < 1 || r < 1 || r > 12 || i < 1 || i > 31) return null;
	let a = /* @__PURE__ */ new Date(0);
	return a.setUTCFullYear(n, r - 1, i), a.getUTCFullYear() === n && a.getUTCMonth() === r - 1 && a.getUTCDate() === i ? a.getTime() : null;
}
// src/local/evaluation/data-functions.ts
function P(e) {
	throw new D("expression-domain", e);
}
function Se(e) {
	return k(e.trim(), "trim result");
}
function Ce(e) {
	return k(e.toLowerCase(), "lower result");
}
function we(e) {
	return k(e.toUpperCase(), "upper result");
}
function Te(e, t) {
	return e.startsWith(t);
}
function Ee(e, t) {
	return e.endsWith(t);
}
function De(e, t, n) {
	t.length === 0 && P("replace search text must not be empty.");
	let r = n.length - t.length;
	if (r > 0) {
		let n = 0, i = 0;
		for (;;) {
			let r = e.indexOf(t, i);
			if (r < 0) break;
			n += 1, i = r + t.length;
		}
		if (e.length + n * r > 1e5) throw new D("expression-budget", `replace result would exceed the ${s}-character limit.`);
	}
	let i = "", a = 0;
	for (;;) {
		let r = e.indexOf(t, a);
		if (r < 0) break;
		i += e.slice(a, r), i += n, a = r + t.length;
	}
	return i += e.slice(a), k(i, "replace result");
}
function Oe(e, t) {
	return e < 0 ? Math.max(t + e, 0) : Math.min(e, t);
}
function ke(e, t, n) {
	Number.isInteger(t) || P("slice start must be an integer."), n !== void 0 && !Number.isInteger(n) && P("slice end must be an integer.");
	let r = Array.from(e), i = r.length, a = Oe(t, i), o = n === void 0 ? i : Oe(n, i);
	return o <= a ? "" : k(r.slice(a, o).join(""), "slice result");
}
var Ae = /* @__PURE__ */ new Map([
	["days", 864e5],
	["hours", 36e5],
	["minutes", 6e4],
	["seconds", 1e3],
	["milliseconds", 1]
]), je = "days, hours, minutes, seconds or milliseconds";
function Me(e) {
	let t = xe(e);
	if (t === null) throw new D("expression-domain", `Date "${e}" must be a valid YYYY-MM-DD calendar date in years 0001-9999.`);
	return t;
}
function Ne(e, t) {
	let n = Me(e), r = Me(t);
	return n === r ? 0 : n < r ? -1 : 1;
}
function Pe(e, t, n = "days") {
	let r = Ae.get(n);
	return r === void 0 && P(`dateDiff unit must be ${je}.`), (Me(e) - Me(t)) / r;
}
// src/local/evaluation/expression.ts
var F = class extends Error {
	offset;
	code;
	constructor(e, t, n = 0) {
		super(t), this.name = "LocalExpressionError", this.code = e, this.offset = n;
	}
}, Fe = /* @__PURE__ */ "abs.sqrt.floor.ceil.round.min.max.pow.sin.cos.tan.asin.acos.atan.exp.log.len.contains.clamp.sum.average.minOf.maxOf.formatNumber.formatPercent.formatScientific.formatCurrency.trim.lower.upper.startsWith.endsWith.replace.slice.dateCompare.dateDiff".split("."), Ie = new Set(Fe), Le = /* @__PURE__ */ new Map([["pi", Math.PI], ["e", Math.E]]), Re = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]), ze = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), Be = /* @__PURE__ */ new Set([
	...Fe,
	"x",
	"y",
	"pi",
	"e",
	"true",
	"false",
	"null",
	...Re
]), Ve = 4e3, He = 2e3, Ue = 100, We = 200, Ge = 1e4, Ke = 250, qe = s, Je = s, Ye = 500;
function Xe(e) {
	if (e.length > 1e4) return {
		code: "expression-budget",
		...f("local.budget.value.array", { limit: a }),
		message: `Array exceeds the ${a}-item limit.`
	};
	let n = null, r = 0;
	for (let i of e) if (typeof i == "string") {
		if (n === "number") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (n = "string", i.length > 1e5) return {
			code: "expression-budget",
			...f("local.budget.value.array-member", { limit: s }),
			message: `Array member exceeds the ${s}-character limit.`
		};
		if (r += i.length, r > 1e5) return {
			code: "expression-budget",
			...f("local.budget.value.array-contents", { limit: t }),
			message: `Array contents exceed the ${t}-character limit.`
		};
	} else if (typeof i == "number") {
		if (n === "string") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (n = "number", !Number.isFinite(i)) return {
			code: "expression-value",
			key: "error.array.finite",
			message: "Array members must be finite numbers."
		};
	} else return {
		code: "expression-value",
		key: "error.array.members",
		message: "Array members must be strings or finite numbers."
	};
	return null;
}
function Ze(e) {
	if (typeof e == "string") return e.length > 1e5 ? f("local.budget.value.string", { limit: s }) : null;
	if (Array.isArray(e)) {
		let t = Xe(e);
		return t ? f(t.key, t.params) : null;
	}
	return null;
}
function I(e) {
	let t = Ze(e);
	return t ? p(t) : null;
}
var Qe = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/, $e = /[A-Za-z_]/, et = /[A-Za-z0-9_]/;
function tt(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r >= "0" && r <= "9" || r === "." && /[0-9]/.test(e[n + 1] ?? "")) {
			let r = Qe.exec(e.slice(n));
			if (!r) throw new F("expression-syntax", "Invalid number.", n);
			let i = r[0], a = Number(i);
			if (!Number.isFinite(a)) throw new F("expression-number", `Number must be finite: ${i}.`, n);
			t.push({
				kind: "number",
				value: i,
				start: n,
				number: a
			}), n += i.length;
			continue;
		}
		if (r === "\"" || r === "'") {
			let i = n, a = r, o = "", s = n + 1, c = !1;
			for (; s < e.length;) {
				let t = e[s];
				if (t === a) {
					c = !0, s += 1;
					break;
				}
				if (t === "\n" || t === "\r") throw new F("expression-string", "String literals cannot span lines.", i);
				if (t === "\\") {
					let t = e[s + 1];
					if (t === void 0) break;
					switch (t) {
						case "\\":
							o += "\\";
							break;
						case "'":
							o += "'";
							break;
						case "\"":
							o += "\"";
							break;
						case "n":
							o += "\n";
							break;
						case "t":
							o += "	";
							break;
						default: throw new F("expression-string", `Unsupported escape \\${t}.`, s);
					}
					s += 2;
				} else o += t, s += 1;
			}
			if (!c) throw new F("expression-string", "Unterminated string literal.", i);
			if (o.length > qe) throw new F("expression-budget", "String literal exceeds the length limit.", i);
			t.push({
				kind: "string",
				value: o,
				start: i
			}), n = s;
			continue;
		}
		if ($e.test(r)) {
			let r = n + 1;
			for (; r < e.length && et.test(e[r]);) r += 1;
			t.push({
				kind: "ident",
				value: e.slice(n, r),
				start: n
			}), n = r;
			continue;
		}
		let i = e.slice(n, n + 2);
		if (e.startsWith("!==", n) || e.startsWith("===", n)) throw new F("expression-syntax", `Unsupported operator ${e.slice(n, n + 3)}.`, n);
		if (i === "==" || i === "!=" || i === "<=" || i === ">=" || i === "&&" || i === "||") t.push({
			kind: "punct",
			value: i,
			start: n
		}), n += 2;
		else if ("+-*/%()!<>?:,[]".includes(r)) t.push({
			kind: "punct",
			value: r,
			start: n
		}), n += 1;
		else throw r === "=" ? new F("expression-assignment", "Assignments are not supported.", n) : r === "." ? new F("expression-property", "Property access is not supported.", n) : r === "&" || r === "|" ? new F("expression-syntax", `Use ${r}${r} for logical operations.`, n) : new F("expression-syntax", `Unrecognized character "${r}".`, n);
	}
	return t.push({
		kind: "eof",
		value: "",
		start: e.length
	}), t;
}
var nt = {
	abs: [1, 1],
	sqrt: [1, 1],
	floor: [1, 1],
	ceil: [1, 1],
	round: [1, 1],
	min: [1, 2 ** 53 - 1],
	max: [1, 2 ** 53 - 1],
	pow: [2, 2],
	sin: [1, 1],
	cos: [1, 1],
	tan: [1, 1],
	asin: [1, 1],
	acos: [1, 1],
	atan: [1, 1],
	exp: [1, 1],
	log: [1, 1],
	len: [1, 1],
	contains: [2, 2],
	clamp: [3, 3],
	sum: [1, 1],
	average: [1, 1],
	minOf: [1, 1],
	maxOf: [1, 1],
	formatNumber: [1, 4],
	formatPercent: [1, 3],
	formatScientific: [1, 3],
	formatCurrency: [1, 4],
	trim: [1, 1],
	lower: [1, 1],
	upper: [1, 1],
	startsWith: [2, 2],
	endsWith: [2, 2],
	replace: [3, 3],
	slice: [2, 3],
	dateCompare: [2, 2],
	dateDiff: [2, 3]
};
function rt(e) {
	let t = 0, n = [{
		node: e,
		depth: 1
	}];
	for (; n.length > 0;) {
		let { node: e, depth: r } = n.pop();
		switch (r > t && (t = r), e.kind) {
			case "unary":
				n.push({
					node: e.operand,
					depth: r + 1
				});
				break;
			case "binary":
				n.push({
					node: e.left,
					depth: r + 1
				}), n.push({
					node: e.right,
					depth: r + 1
				});
				break;
			case "conditional":
				n.push({
					node: e.test,
					depth: r + 1
				}), n.push({
					node: e.consequent,
					depth: r + 1
				}), n.push({
					node: e.alternate,
					depth: r + 1
				});
				break;
			case "call":
				for (let t of e.args) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "array":
				for (let t of e.elements) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "index": n.push({
				node: e.target,
				depth: r + 1
			}), n.push({
				node: e.index,
				depth: r + 1
			});
		}
	}
	return t;
}
var it = class {
	tokens;
	position = 0;
	nodeCount = 0;
	dependencyNames = [];
	dependencySet = /* @__PURE__ */ new Set();
	constructor(e) {
		this.tokens = tt(e);
	}
	get dependencies() {
		return this.dependencyNames;
	}
	parse() {
		if (this.peek().kind === "eof") throw new F("expression-empty", "Expression is empty.", 0);
		let e = this.parseConditional(0), t = this.peek();
		if (t.kind !== "eof") throw new F("expression-syntax", `Unexpected content "${t.value}".`, t.start);
		if (rt(e) > We) throw new F("expression-budget", "Expression is nested too deeply.", e.start);
		return e;
	}
	peek() {
		return this.tokens[this.position];
	}
	next() {
		let e = this.tokens[this.position];
		return this.position += 1, e;
	}
	isPunct(e) {
		let t = this.peek();
		return t.kind === "punct" && t.value === e;
	}
	expect(e) {
		let t = this.peek();
		if (t.kind !== "punct" || t.value !== e) throw new F("expression-syntax", `Missing "${e}".`, t.start);
		return this.next();
	}
	node(e, t, n) {
		if (this.nodeCount += 1, this.nodeCount > He) throw new F("expression-budget", "Expression is too complex.", n);
		if (t > Ue) throw new F("expression-budget", "Expression is nested too deeply.", n);
		return e;
	}
	parseConditional(e) {
		let t = this.parseOr(e);
		if (!this.isPunct("?")) return t;
		let n = t.start;
		this.next();
		let r = this.parseConditional(e + 1);
		this.expect(":");
		let i = this.parseConditional(e + 1);
		return this.node({
			kind: "conditional",
			test: t,
			consequent: r,
			alternate: i,
			start: n
		}, e, n);
	}
	parseOr(e) {
		let t = this.parseAnd(e);
		for (; this.isPunct("||");) {
			let n = t.start;
			this.next();
			let r = this.parseAnd(e);
			t = this.node({
				kind: "binary",
				operator: "||",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAnd(e) {
		let t = this.parseEquality(e);
		for (; this.isPunct("&&");) {
			let n = t.start;
			this.next();
			let r = this.parseEquality(e);
			t = this.node({
				kind: "binary",
				operator: "&&",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseEquality(e) {
		let t = this.parseRelational(e);
		for (; this.isPunct("==") || this.isPunct("!=");) {
			let n = t.start, r = this.next().value, i = this.parseRelational(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseRelational(e) {
		let t = this.parseAdditive(e);
		for (; this.isPunct("<") || this.isPunct("<=") || this.isPunct(">") || this.isPunct(">=");) {
			let n = t.start, r = this.next().value, i = this.parseAdditive(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAdditive(e) {
		let t = this.parseMultiplicative(e);
		for (; this.isPunct("+") || this.isPunct("-");) {
			let n = t.start, r = this.next().value, i = this.parseMultiplicative(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseMultiplicative(e) {
		let t = this.parseUnary(e);
		for (; this.isPunct("*") || this.isPunct("/") || this.isPunct("%");) {
			let n = t.start, r = this.next().value, i = this.parseUnary(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseUnary(e) {
		let t = this.peek();
		if (t.kind === "punct" && (t.value === "-" || t.value === "+" || t.value === "!")) {
			this.next();
			let n = this.parseUnary(e + 1);
			return this.node({
				kind: "unary",
				operator: t.value,
				operand: n,
				start: t.start
			}, e, t.start);
		}
		return this.parsePrimary(e);
	}
	parsePrimary(e) {
		let t = this.parseAtom(e);
		for (; this.isPunct("[");) {
			let n = t.start;
			this.next();
			let r = this.parseConditional(e + 1);
			this.expect("]"), t = this.node({
				kind: "index",
				target: t,
				index: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAtom(e) {
		let t = this.peek();
		if (t.kind === "number") return this.next(), this.node({
			kind: "literal",
			value: t.number,
			start: t.start
		}, e, t.start);
		if (t.kind === "string") return this.next(), this.node({
			kind: "literal",
			value: t.value,
			start: t.start
		}, e, t.start);
		if (t.kind === "ident") {
			this.next();
			let n = t.value;
			if (this.isPunct("(")) {
				if (!Ie.has(n)) throw new F("expression-unknown-function", `Unknown function "${n}".`, t.start);
				this.next();
				let r = [];
				if (!this.isPunct(")")) for (r.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), r.push(this.parseConditional(e + 1));
				this.expect(")");
				let [i, a] = nt[n];
				if (r.length < i || r.length > a) throw new F("expression-arity", `Function ${n} expects ${i === a ? `${i} ${i === 1 ? "argument" : "arguments"}` : i === 1 ? "at least one argument" : `${i}–${a} arguments`}.`, t.start);
				return this.node({
					kind: "call",
					name: n,
					args: r,
					start: t.start
				}, e, t.start);
			}
			if (n === "true" || n === "false") return this.node({
				kind: "literal",
				value: n === "true",
				start: t.start
			}, e, t.start);
			if (n === "null") return this.node({
				kind: "literal",
				value: null,
				start: t.start
			}, e, t.start);
			let r = Le.get(n);
			if (r !== void 0) return this.node({
				kind: "literal",
				value: r,
				start: t.start
			}, e, t.start);
			if (Re.has(n)) throw new F("expression-forbidden-name", `Name "${n}" is not allowed.`, t.start);
			if (Ie.has(n)) throw new F("expression-syntax", `Function ${n} must be called with parentheses.`, t.start);
			return this.dependencySet.has(n) || (this.dependencySet.add(n), this.dependencyNames.push(n)), this.node({
				kind: "reference",
				name: n,
				start: t.start
			}, e, t.start);
		}
		if (t.kind === "punct" && t.value === "(") {
			this.next();
			let t = this.parseConditional(e + 1);
			return this.expect(")"), t;
		}
		if (t.kind === "punct" && t.value === "[") {
			this.next();
			let n = [];
			if (!this.isPunct("]")) for (n.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), n.push(this.parseConditional(e + 1));
			return this.expect("]"), this.node({
				kind: "array",
				elements: n,
				start: t.start
			}, e, t.start);
		}
		throw new F("expression-syntax", "Expected an expression.", t.start);
	}
};
function L(e) {
	switch (e) {
		case "string": return "string";
		case "number": return "number";
		case "boolean": return "boolean";
		case "null": return "null";
		case "array": return "array";
		case "number-array": return "number array";
	}
}
function at(e) {
	return e === null ? "null" : Array.isArray(e) ? "array" : typeof e == "boolean" ? "boolean" : typeof e == "number" ? "number" : "string";
}
function R(e, t) {
	throw new F("expression-type", e, t);
}
function z(e, t, n, r) {
	e !== t && R(`${r}, got ${L(e)}.`, n);
}
function ot(e, t) {
	return e === t ? e : e === "null" ? t : t === "null" ? e : null;
}
function B(e, t) {
	switch (e.kind) {
		case "literal": return at(e.value);
		case "reference": {
			if (typeof t != "object" || !t || !Object.prototype.hasOwnProperty.call(t, e.name)) throw new F("expression-unknown-name", `Variable "${e.name}" is not declared.`, e.start);
			let n = t[e.name];
			if (typeof n != "string" || !ze.has(n)) throw new F("expression-value", `Variable "${e.name}" has an invalid type.`, e.start);
			return n;
		}
		case "unary": {
			let n = B(e.operand, t);
			return e.operator === "!" ? (z(n, "boolean", e.start, "Logical not requires a boolean"), "boolean") : (z(n, "number", e.start, `Unary ${e.operator} requires a number`), "number");
		}
		case "binary": {
			let n = B(e.left, t), r = B(e.right, t);
			switch (e.operator) {
				case "+": return n === "number" && r === "number" ? "number" : n === "string" && r === "string" ? "string" : R(`Operator "+" requires two numbers or two strings, got ${L(n)} and ${L(r)}.`, e.start);
				case "-":
				case "*":
				case "/":
				case "%": return z(n, "number", e.start, `Operator "${e.operator}" requires a number`), z(r, "number", e.start, `Operator "${e.operator}" requires a number`), "number";
				case "<":
				case "<=":
				case ">":
				case ">=": return n === "number" && r === "number" || n === "string" && r === "string" ? "boolean" : R(`Comparison operator "${e.operator}" requires two numbers or two strings, got ${L(n)} and ${L(r)}.`, e.start);
				case "==":
				case "!=": return n !== r && n !== "null" && r !== "null" ? R(`Equality comparison requires matching types, got ${L(n)} and ${L(r)}.`, e.start) : "boolean";
				case "&&":
				case "||": return z(n, "boolean", e.start, "Logical operators require booleans"), z(r, "boolean", e.start, "Logical operators require booleans"), "boolean";
			}
			break;
		}
		case "array": {
			if (e.elements.length === 0) return "number-array";
			let n = null;
			for (let r of e.elements) {
				let e = B(r, t);
				if (e !== "string" && e !== "number") return R(`Array literals require string or number elements, got ${L(e)}.`, r.start);
				if (n === null) n = e;
				else if (n !== e) return R(`Array literals require elements of one type, got ${L(n)} and ${L(e)}.`, r.start);
			}
			return n === "string" ? "array" : "number-array";
		}
		case "index": {
			let n = B(e.target, t);
			return z(B(e.index, t), "number", e.start, "Array index must be a number"), n === "array" ? "string" : n === "number-array" ? "number" : R(`Index access requires an array, got ${L(n)}.`, e.start);
		}
		case "conditional": {
			z(B(e.test, t), "boolean", e.start, "Conditional test must be a boolean");
			let n = B(e.consequent, t), r = B(e.alternate, t);
			if (n === "array" && e.alternate.kind === "array" && e.alternate.elements.length === 0 || r === "array" && e.consequent.kind === "array" && e.consequent.elements.length === 0) return "array";
			let i = ot(n, r);
			return i === null ? R(`Conditional branches must have matching types or one null, got ${L(n)} and ${L(r)}.`, e.start) : i;
		}
		case "call": {
			let n = e.args.map((e) => B(e, t));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": return z(n[0], "number", e.start, `Function ${e.name} requires a number`), "number";
				case "min":
				case "max":
				case "pow":
				case "clamp":
					for (let t of n) z(t, "number", e.start, `Function ${e.name} requires a number`);
					return "number";
				case "len": return n[0] !== "string" && n[0] !== "array" && n[0] !== "number-array" && R(`Function len requires a string or array, got ${L(n[0])}.`, e.start), "number";
				case "contains":
					if (n[0] === "number-array") return z(n[1], "number", e.start, "Function contains requires a numeric member"), "boolean";
					if (n[0] === "string" || n[0] === "array") return z(n[1], "string", e.start, "Function contains requires a string member"), "boolean";
					R(`Function contains requires a string or array, got ${L(n[0])}.`, e.start);
					break;
				case "sum":
				case "average":
				case "minOf":
				case "maxOf": return z(n[0], "number-array", e.start, `Function ${e.name} requires a numeric array`), "number";
				case "formatNumber":
				case "formatPercent":
				case "formatScientific": return n[0] !== "number" && n[0] !== "null" && R(`Function ${e.name} requires a number or null, got ${L(n[0])}.`, e.start), n[1] !== void 0 && z(n[1], "number", e.start, `Function ${e.name} requires numeric fraction digits`), n[2] !== void 0 && z(n[2], "string", e.start, `Function ${e.name} requires a string locale`), e.name === "formatNumber" && n[3] !== void 0 && z(n[3], "boolean", e.start, "Function formatNumber requires a boolean grouping flag"), "string";
				case "formatCurrency": return n[0] !== "number" && n[0] !== "null" && R(`Function formatCurrency requires a number or null, got ${L(n[0])}.`, e.start), n[1] !== void 0 && z(n[1], "string", e.start, "Function formatCurrency requires a string currency code"), n[2] !== void 0 && z(n[2], "number", e.start, "Function formatCurrency requires numeric fraction digits"), n[3] !== void 0 && z(n[3], "string", e.start, "Function formatCurrency requires a string locale"), "string";
				case "trim":
				case "lower":
				case "upper": return z(n[0], "string", e.start, `Function ${e.name} requires a string`), "string";
				case "startsWith":
				case "endsWith": return z(n[0], "string", e.start, `Function ${e.name} requires a string`), z(n[1], "string", e.start, `Function ${e.name} requires a string search value`), "boolean";
				case "replace": return z(n[0], "string", e.start, "Function replace requires a string"), z(n[1], "string", e.start, "Function replace requires a string search value"), z(n[2], "string", e.start, "Function replace requires a string replacement"), "string";
				case "slice": return z(n[0], "string", e.start, "Function slice requires a string"), z(n[1], "number", e.start, "Function slice requires a numeric start index"), n[2] !== void 0 && z(n[2], "number", e.start, "Function slice requires a numeric end index"), "string";
				case "dateCompare": return z(n[0], "string", e.start, "Function dateCompare requires a date string"), z(n[1], "string", e.start, "Function dateCompare requires a date string"), "number";
				case "dateDiff": return z(n[0], "string", e.start, "Function dateDiff requires a date string"), z(n[1], "string", e.start, "Function dateDiff requires a date string"), n[2] !== void 0 && z(n[2], "string", e.start, "Function dateDiff requires a string unit"), "number";
			}
			break;
		}
	}
	throw new F("expression-type", "Unsupported expression.", 0);
}
function V(e, t, n = "expression-eval") {
	throw new F(n, e, t);
}
function st(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) throw new F("expression-value", "Expression environment must be an object.", 0);
}
function ct(e, t, n) {
	if (e === null) return null;
	if (typeof e == "string") {
		let r = I(e);
		if (r) throw new F("expression-budget", `Variable "${t}": ${r}`, n);
		return e;
	}
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new F("expression-value", `Variable "${t}" must be a finite number.`, n);
		return e;
	}
	if (Array.isArray(e)) {
		let r = Xe(e);
		if (r) throw new F(r.code, `Variable "${t}": ${r.message}`, n);
		return e;
	}
	throw new F("expression-value", `Variable "${t}" has an invalid value type.`, n);
}
function lt(e, t, n) {
	return st(e), Object.prototype.hasOwnProperty.call(e, t) || V(`Variable "${t}" is not declared.`, n, "expression-unknown-name"), ct(e[t], t, n);
}
function H(e, t, n = "Expected a number") {
	return typeof e == "number" && Number.isFinite(e) || V(`${n}.`, t, "expression-type"), e;
}
function U(e, t, n = "Expected a boolean") {
	return typeof e != "boolean" && V(`${n}.`, t, "expression-type"), e;
}
function W(e, t, n = "Expected a string") {
	return typeof e != "string" && V(`${n}.`, t, "expression-type"), e;
}
function G(e, t, n) {
	Array.isArray(e) || V(`${n}.`, t, "expression-type");
	for (let r of e) typeof r == "number" && Number.isFinite(r) || V(`${n}.`, t, "expression-type");
	return e;
}
function ut(e, t) {
	let n = Xe(e);
	return n && V(n.message, t, n.code), e;
}
function K(e, t) {
	try {
		return t();
	} catch (t) {
		throw t instanceof D ? new F(t.code, t.message, e) : t;
	}
}
function q(e, t) {
	return Number.isNaN(e) && V("The result is undefined.", t, "expression-domain"), Number.isFinite(e) || V("The result is not a finite number.", t, "expression-number"), e;
}
function dt(e, t) {
	let n = Array.from(e), r = Array.from(t), i = Math.min(n.length, r.length);
	for (let e = 0; e < i; e += 1) {
		let t = n[e].codePointAt(0), i = r[e].codePointAt(0);
		if (t !== i) return t < i ? -1 : 1;
	}
	return n.length === r.length ? 0 : n.length < r.length ? -1 : 1;
}
function ft(e, t) {
	if (e === t) return !0;
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return !1;
		for (let n = 0; n < e.length; n += 1) if (e[n] !== t[n]) return !1;
		return !0;
	}
	return !1;
}
function pt(e, t) {
	return J(e, t, { steps: 0 }, 1);
}
function J(e, t, n, r) {
	switch (n.steps += 1, n.steps > Ge && V("Expression evaluation exceeded the step limit.", e.start, "expression-budget"), r > Ke && V("Expression evaluation is nested too deeply.", e.start, "expression-budget"), e.kind) {
		case "literal": return e.value;
		case "reference": return lt(t, e.name, e.start);
		case "unary": {
			let i = J(e.operand, t, n, r + 1);
			if (e.operator === "!") return !U(i, e.start, "Logical not requires a boolean");
			let a = H(i, e.start, `Unary ${e.operator} requires a number`);
			return q(e.operator === "-" ? -a : a, e.start);
		}
		case "binary": {
			if (e.operator === "&&" || e.operator === "||") {
				let i = U(J(e.left, t, n, r + 1), e.start, "Logical operators require booleans");
				return e.operator === "&&" && !i ? !1 : e.operator === "||" && i ? !0 : U(J(e.right, t, n, r + 1), e.start, "Logical operators require booleans");
			}
			let i = J(e.left, t, n, r + 1), a = J(e.right, t, n, r + 1);
			switch (e.operator) {
				case "+":
					if (typeof i == "number" && typeof a == "number") return q(i + a, e.start);
					if (typeof i == "string" && typeof a == "string") {
						let t = i + a;
						return t.length > qe && V("String result exceeds the length limit.", e.start, "expression-budget"), t;
					}
					V("Operator \"+\" requires two numbers or two strings.", e.start, "expression-type");
				case "-":
				case "*":
				case "/":
				case "%": {
					let t = H(i, e.start, `Operator "${e.operator}" requires a number`), n = H(a, e.start, `Operator "${e.operator}" requires a number`);
					return (e.operator === "/" || e.operator === "%") && n === 0 && V("Division by zero.", e.start, "expression-divide-by-zero"), q(e.operator === "-" ? t - n : e.operator === "*" ? t * n : e.operator === "/" ? t / n : t % n, e.start);
				}
				case "==":
				case "!=": {
					let t = at(i), n = at(a);
					t !== n && t !== "null" && n !== "null" && V("Equality comparison requires matching types.", e.start, "expression-type");
					let r = ft(i, a);
					return e.operator === "==" ? r : !r;
				}
				case "<":
				case "<=":
				case ">":
				case ">=": {
					let t;
					return typeof i == "number" && typeof a == "number" ? t = i === a ? 0 : i < a ? -1 : 1 : typeof i == "string" && typeof a == "string" ? t = dt(i, a) : V(`Comparison operator "${e.operator}" requires two numbers or two strings.`, e.start, "expression-type"), e.operator === "<" ? t < 0 : e.operator === "<=" ? t <= 0 : e.operator === ">" ? t > 0 : t >= 0;
				}
			}
			break;
		}
		case "conditional": return J(U(J(e.test, t, n, r + 1), e.start, "Conditional test must be a boolean") ? e.consequent : e.alternate, t, n, r + 1);
		case "array": {
			let i = [];
			for (let a of e.elements) i.push(J(a, t, n, r + 1));
			return ut(i, e.start);
		}
		case "index": {
			let i = J(e.target, t, n, r + 1), a = H(J(e.index, t, n, r + 1), e.start, "Array index must be a number");
			return Number.isSafeInteger(a) || V("Array index must be a finite integer.", e.start, "expression-index"), Array.isArray(i) || V("Index access requires an array.", e.start, "expression-type"), a < 0 || a >= i.length ? null : i[a];
		}
		case "call": {
			let i = e.args.map((e) => J(e, t, n, r + 1));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": {
					let t = H(i[0], e.start, `Function ${e.name} requires a number`);
					e.name === "sqrt" && t < 0 && V("sqrt requires a non-negative argument.", e.start, "expression-domain"), e.name === "log" && t <= 0 && V("log requires a positive argument.", e.start, "expression-domain"), (e.name === "asin" || e.name === "acos") && (t < -1 || t > 1) && V(`${e.name} requires an argument between -1 and 1.`, e.start, "expression-domain");
					let n;
					switch (e.name) {
						case "abs":
							n = Math.abs(t);
							break;
						case "sqrt":
							n = Math.sqrt(t);
							break;
						case "floor":
							n = Math.floor(t);
							break;
						case "ceil":
							n = Math.ceil(t);
							break;
						case "round":
							n = Math.round(t);
							break;
						case "sin":
							n = Math.sin(t);
							break;
						case "cos":
							n = Math.cos(t);
							break;
						case "tan":
							n = Math.tan(t);
							break;
						case "asin":
							n = Math.asin(t);
							break;
						case "acos":
							n = Math.acos(t);
							break;
						case "atan":
							n = Math.atan(t);
							break;
						case "exp":
							n = Math.exp(t);
							break;
						default: n = Math.log(t);
					}
					return q(n, e.start);
				}
				case "min":
				case "max": {
					let t = H(i[0], e.start, `Function ${e.name} requires a number`);
					for (let n = 1; n < i.length; n += 1) {
						let r = H(i[n], e.start, `Function ${e.name} requires a number`);
						t = e.name === "min" ? Math.min(t, r) : Math.max(t, r);
					}
					return q(t, e.start);
				}
				case "pow": return q(H(i[0], e.start, "Function pow requires a number") ** +H(i[1], e.start, "Function pow requires a number"), e.start);
				case "clamp": {
					let t = H(i[0], e.start, "Function clamp requires a number"), n = H(i[1], e.start, "Function clamp requires a number"), r = H(i[2], e.start, "Function clamp requires a number");
					return n > r && V("clamp lower bound cannot exceed upper bound.", e.start, "expression-domain"), q(Math.min(r, Math.max(n, t)), e.start);
				}
				case "len": {
					let t = i[0];
					if (typeof t == "string") return ne(t);
					if (Array.isArray(t)) return t.length;
					V("Function len requires a string or array.", e.start, "expression-type");
				}
				case "contains": {
					let t = i[0], n = i[1];
					if (typeof t == "string") return t.includes(W(n, e.start, "Function contains requires a string member"));
					if (Array.isArray(t)) {
						if (typeof n == "string") {
							for (let n of t) typeof n != "string" && V("Function contains requires a string member for a string array.", e.start, "expression-type");
							return t.includes(n);
						}
						if (typeof n == "number" && Number.isFinite(n)) {
							for (let n of t) typeof n != "number" && V("Function contains requires a numeric member for a numeric array.", e.start, "expression-type");
							return t.includes(n);
						}
						V("Function contains requires a string or numeric member.", e.start, "expression-type");
					}
					V("Function contains requires a string or array.", e.start, "expression-type");
				}
				case "sum": {
					let t = G(i[0], e.start, "Function sum requires a numeric array");
					return K(e.start, () => _e(t));
				}
				case "average": {
					let t = G(i[0], e.start, "Function average requires a numeric array");
					return K(e.start, () => ve(t));
				}
				case "minOf": {
					let t = G(i[0], e.start, "Function minOf requires a numeric array");
					return K(e.start, () => ye(t));
				}
				case "maxOf": {
					let t = G(i[0], e.start, "Function maxOf requires a numeric array");
					return K(e.start, () => be(t));
				}
				case "formatNumber": {
					let t = i[0] === null ? null : H(i[0], e.start, "Function formatNumber requires a number or null"), n = i[1] === void 0 ? 2 : H(i[1], e.start, "Function formatNumber requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : W(i[2], e.start, "Function formatNumber requires a string locale"), a = i[3] === void 0 || U(i[3], e.start, "Function formatNumber requires a boolean grouping flag");
					return K(e.start, () => fe(t, n, r, a));
				}
				case "formatPercent": {
					let t = i[0] === null ? null : H(i[0], e.start, "Function formatPercent requires a number or null"), n = i[1] === void 0 ? 0 : H(i[1], e.start, "Function formatPercent requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : W(i[2], e.start, "Function formatPercent requires a string locale");
					return K(e.start, () => pe(t, n, r));
				}
				case "formatScientific": {
					let t = i[0] === null ? null : H(i[0], e.start, "Function formatScientific requires a number or null"), n = i[1] === void 0 ? 2 : H(i[1], e.start, "Function formatScientific requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : W(i[2], e.start, "Function formatScientific requires a string locale");
					return K(e.start, () => me(t, n, r));
				}
				case "formatCurrency": {
					let t = i[0] === null ? null : H(i[0], e.start, "Function formatCurrency requires a number or null"), n = i[1] === void 0 ? "USD" : W(i[1], e.start, "Function formatCurrency requires a string currency code"), r = i[2] === void 0 ? 2 : H(i[2], e.start, "Function formatCurrency requires numeric fraction digits"), a = i[3] === void 0 ? "en-US" : W(i[3], e.start, "Function formatCurrency requires a string locale");
					return K(e.start, () => he(t, n, r, a));
				}
				case "trim": return K(e.start, () => Se(W(i[0], e.start, "Function trim requires a string")));
				case "lower": return K(e.start, () => Ce(W(i[0], e.start, "Function lower requires a string")));
				case "upper": return K(e.start, () => we(W(i[0], e.start, "Function upper requires a string")));
				case "startsWith": return K(e.start, () => Te(W(i[0], e.start, "Function startsWith requires a string"), W(i[1], e.start, "Function startsWith requires a string search value")));
				case "endsWith": return K(e.start, () => Ee(W(i[0], e.start, "Function endsWith requires a string"), W(i[1], e.start, "Function endsWith requires a string search value")));
				case "replace": {
					let t = W(i[0], e.start, "Function replace requires a string"), n = W(i[1], e.start, "Function replace requires a string search value"), r = W(i[2], e.start, "Function replace requires a string replacement");
					return K(e.start, () => De(t, n, r));
				}
				case "slice": {
					let t = W(i[0], e.start, "Function slice requires a string"), n = H(i[1], e.start, "Function slice requires a numeric start index"), r = i[2] === void 0 ? void 0 : H(i[2], e.start, "Function slice requires a numeric end index");
					return K(e.start, () => ke(t, n, r));
				}
				case "dateCompare": {
					let t = W(i[0], e.start, "Function dateCompare requires a date string"), n = W(i[1], e.start, "Function dateCompare requires a date string");
					return K(e.start, () => Ne(t, n));
				}
				case "dateDiff": {
					let t = W(i[0], e.start, "Function dateDiff requires a date string"), n = W(i[1], e.start, "Function dateDiff requires a date string"), r = i[2] === void 0 ? "days" : W(i[2], e.start, "Function dateDiff requires a string unit");
					return K(e.start, () => Pe(t, n, r));
				}
			}
			break;
		}
	}
	throw new F("expression-eval", "Unsupported expression.", 0);
}
var Y = /* @__PURE__ */ new Map();
function mt(e) {
	if (typeof e != "string") throw new F("expression-syntax", "Expression must be a string.", 0);
	if (e.length > Ve) throw new F("expression-budget", `Expression exceeds the ${Ve}-character limit.`, 0);
	let t = Y.get(e);
	if (t) return t;
	let n = new it(e), r = n.parse(), i = [...n.dependencies], a = Object.freeze({
		source: e,
		dependencies: i,
		evaluate(e) {
			return pt(r, e);
		},
		inferType(e) {
			return B(r, e);
		}
	});
	if (Y.size >= Ye) {
		let e = Y.keys().next().value;
		e !== void 0 && Y.delete(e);
	}
	return Y.set(e, a), a;
}
function ht(e) {
	if (e.length > Je) throw new F("expression-budget", "Interpolation template exceeds the length limit.", 0);
	let t = [], n = 0;
	for (;;) {
		let r = e.indexOf("{{", n);
		if (r < 0) {
			n < e.length && t.push({
				kind: "text",
				value: e.slice(n)
			});
			break;
		}
		r > n && t.push({
			kind: "text",
			value: e.slice(n, r)
		});
		let i = r + 2, a = "", o = !1;
		for (; i < e.length;) {
			let t = e[i];
			if (a !== "") {
				if (t === "\\") {
					i += 2;
					continue;
				}
				t === a && (a = ""), i += 1;
			} else if (t === "\"" || t === "'") a = t, i += 1;
			else {
				if (t === "{" && e[i + 1] === "{") throw new F("expression-interpolation", "Interpolations cannot be nested.", i);
				if (t === "}" && e[i + 1] === "}") {
					o = !0;
					break;
				}
				i += 1;
			}
		}
		if (!o) throw new F("expression-interpolation", "Interpolation is missing }}.", r);
		let s = e.slice(r + 2, i);
		if (s.trim() === "") throw new F("expression-empty", "Interpolation expression is empty.", r + 2);
		t.push({
			kind: "expression",
			source: s,
			start: r + 2
		}), n = i + 2;
	}
	return t;
}
function gt(e) {
	try {
		return mt(e.source);
	} catch (t) {
		throw t instanceof F ? new F(t.code, t.message, e.start + t.offset) : t;
	}
}
function _t(e, t, n) {
	try {
		return e.evaluate(t);
	} catch (e) {
		throw e instanceof F ? new F(e.code, e.message, n + e.offset) : e;
	}
}
function vt(e, t) {
	if (e === null) return "";
	if (typeof e == "string") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new F("expression-value", "Cannot display a non-finite number.", t);
		return String(e);
	}
	if (typeof e == "boolean") return e ? "true" : "false";
	throw Array.isArray(e) ? new F("expression-type", "Cannot insert an array as text; convert it with a function such as len first.", t) : new F("expression-type", "Cannot display this value as text.", t);
}
function yt(e, t) {
	let n = [], r = 0;
	for (let i of e) {
		let e;
		if (e = i.kind === "text" ? i.value : vt(_t(gt(i), t, i.start), i.start), r += e.length, r > qe) throw new F("expression-budget", "Interpolation result exceeds the length limit.", 0);
		n.push(e);
	}
	return n.join("");
}
function bt(e, t) {
	if (typeof e != "string") throw new F("expression-interpolation", "Interpolation template must be a string.", 0);
	if (e.length > Je) throw new F("expression-budget", `Interpolation template exceeds the ${Je}-character limit.`, 0);
	return e.includes("{{") ? yt(ht(e), t) : e;
}
function xt(e) {
	if (typeof e != "string") throw new F("expression-interpolation", "Interpolation template must be a string.", 0);
	let t = /* @__PURE__ */ new Set();
	for (let n of ht(e)) if (n.kind === "expression") for (let e of gt(n).dependencies) t.add(e);
	return [...t];
}
// src/local/source/node-walk.ts
function* St(e, t = !1) {
	let n = [{
		nodes: e,
		index: 0
	}];
	for (; n.length;) {
		let e = n[n.length - 1];
		if (e.index === e.nodes.length) {
			n.pop(), t && e.owner && (yield e.owner);
			continue;
		}
		let r = e.nodes[e.index++];
		t || (yield r), r.children?.length ? n.push({
			nodes: r.children,
			index: 0,
			owner: r
		}) : t && (yield r);
	}
}
// src/local/evaluation/computations.ts
function Ct(e, t, n, r = "local.expression") {
	t instanceof F ? e(`${r}.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0)) : e(`${r}.invalid`, `Expression error: ${t instanceof Error ? t.message : String(t)}`, n);
}
function wt(e) {
	return e instanceof F ? e : new F("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function Tt(e, t) {
	let n = new Set(e), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let t of e) r.set(t, 0);
	for (let a of e) for (let e of t(a)) {
		if (!n.has(e)) continue;
		r.set(a, (r.get(a) ?? 0) + 1);
		let t = i.get(e);
		t ? t.push(a) : i.set(e, [a]);
	}
	let a = [];
	for (let t of e) (r.get(t) ?? 0) === 0 && a.push(t);
	let o = [];
	for (let e = 0; e < a.length; e += 1) {
		let t = a[e];
		o.push(t);
		for (let e of i.get(t) ?? []) {
			let t = (r.get(e) ?? 0) - 1;
			r.set(e, t), t === 0 && a.push(e);
		}
	}
	let s = new Set(o);
	return {
		order: o,
		cyclic: e.filter((e) => !s.has(e))
	};
}
function Et(e) {
	let t = Object.keys(e), n = new Set(t);
	return Tt(t, (t) => {
		let r = e[t];
		return r ? r.dependencies.filter((e) => n.has(e)) : [];
	});
}
function Dt(e, t, n, r = /* @__PURE__ */ new Set(), i) {
	let a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = [], l = /* @__PURE__ */ new Set();
	for (let t of e) s.has(t.name) || (s.set(t.name, t), c.push(t.name));
	let u = new Set(c);
	for (let e of c) {
		let t = s.get(e), r;
		try {
			r = i?.expression(t.source) ?? mt(t.source);
		} catch (r) {
			Ct(n, r, t.expressionOffset), l.add(e);
			continue;
		}
		a.set(e, r), o.set(e, [...r.dependencies]);
	}
	for (let e of c) if (!l.has(e)) {
		for (let r of o.get(e) ?? []) if (!(u.has(r) || Object.hasOwn(t, r))) {
			n("local.computation.unknown", `Reference to undeclared parameter ${r} in computation "${e}".`, s.get(e).expressionOffset + Math.max(0, s.get(e).source.indexOf(r))), l.add(e);
			break;
		}
	}
	let d = /* @__PURE__ */ new Set();
	for (let e of c) {
		if (l.has(e)) continue;
		let i = s.get(e);
		if (i.kind === "const") for (let a of o.get(e) ?? []) {
			let o = u.has(a) ? s.get(a).kind : null;
			Object.hasOwn(t, a) ? (n("local.computation.const", `Constant "${e}" cannot depend on ${r.has(a) ? "external data" : "control parameter"} "${a}".`, i.expressionOffset + Math.max(0, i.source.indexOf(a))), d.add(e)) : o === "computed" && (n("local.computation.const", `Constant "${e}" cannot depend on computed value "${a}".`, i.expressionOffset + Math.max(0, i.source.indexOf(a))), d.add(e));
		}
	}
	let { order: f, cyclic: p } = Tt(c, (e) => o.get(e) ?? []);
	if (p.length > 0) {
		let e = new Set(p), t = [], r = /* @__PURE__ */ new Map(), i = p[0];
		for (; !r.has(i);) {
			r.set(i, t.length), t.push(i);
			let n = (o.get(i) ?? []).find((t) => e.has(t));
			if (n === void 0) break;
			i = n;
		}
		let a = r.has(i) ? t.slice(r.get(i)) : [p[0]], c = a.slice(0, 12).join(" → ") + (a.length > 12 ? " → …" : ` → ${a[0]}`);
		for (let e of a.slice(0, 100)) {
			let t = s.get(e);
			n("local.computation.cycle", `Computation "${e}" is part of a dependency cycle: ${c}.`, t.range.start, t.range.end);
		}
		for (let e of p) l.add(e);
	}
	for (let e of f) if (!l.has(e) && !(s.get(e).kind !== "const" || d.has(e)) && (o.get(e) ?? []).some((e) => u.has(e) ? s.get(e).kind === "const" && d.has(e) : !1)) {
		let t = s.get(e);
		n("local.computation.const", `Constant "${e}" indirectly depends on a value that is not a constant.`, t.expressionOffset), d.add(e);
	}
	let m = {}, h = { ...t };
	for (let e of f) {
		if (l.has(e)) continue;
		let t = s.get(e);
		if ((o.get(e) ?? []).some((e) => l.has(e))) {
			l.add(e);
			continue;
		}
		let r = a.get(e);
		try {
			let t = i ? i.infer(r, h) : r.inferType(h);
			m[e] = t, h[e] = t;
		} catch (r) {
			Ct(n, r, t.expressionOffset), l.add(e);
		}
	}
	let g = {}, _ = {};
	for (let e of f) {
		if (l.has(e) || s.get(e).kind !== "const" || d.has(e)) continue;
		let t = s.get(e), r = a.get(e);
		try {
			let i = r.evaluate(_), a = I(i);
			if (a) {
				n("local.computation.budget", `Constant "${e}": ${a}`, t.expressionOffset), l.add(e);
				continue;
			}
			g[e] = Array.isArray(i) ? i.slice() : i, _[e] = g[e];
		} catch (r) {
			let i = wt(r);
			n("local.computation.expression", `Constant "${e}" cannot be evaluated: ${i.message}`, t.expressionOffset + (Number.isFinite(i.offset) ? i.offset : 0)), l.add(e);
		}
	}
	let v = {};
	for (let e of c) {
		let t = s.get(e);
		if (l.has(e) || m[e] === void 0) continue;
		let n = {
			name: e,
			kind: t.kind,
			source: t.source,
			dependencies: [...o.get(e) ?? []],
			type: m[e],
			nodeId: t.nodeId,
			range: { ...t.range }
		};
		t.kind === "const" && Object.hasOwn(g, e) && (n.value = g[e]), v[e] = n;
	}
	return {
		computations: v,
		kinds: m,
		order: f.filter((e) => !l.has(e)),
		expressions: a,
		constValues: g
	};
}
function Ot(e, t, n, r, i, a = /* @__PURE__ */ new Map()) {
	let o = {}, s = /* @__PURE__ */ new Map(), c = {};
	for (let [e, t] of Object.entries(r)) c[e] = t;
	for (let [e, t] of a) Object.defineProperty(c, e, {
		enumerable: !0,
		configurable: !0,
		get() {
			throw t;
		}
	});
	for (let [e, t] of Object.entries(i)) o[e] = t, c[e] = t;
	for (let r of t) {
		let t = e[r];
		if (!t || t.kind === "const") continue;
		let i = n.get(r);
		if (i) try {
			let e = i.evaluate(c), t = I(e);
			if (t) throw new F("expression-budget", t, 0);
			o[r] = e, c[r] = e;
		} catch (e) {
			let t = wt(e);
			s.set(r, t), Object.defineProperty(c, r, {
				enumerable: !0,
				configurable: !0,
				get() {
					throw t;
				}
			});
		}
	}
	return {
		values: o,
		errors: s
	};
}
// node_modules/devlop/lib/default.js
function kt() {}
// node_modules/mdast-util-to-string/lib/index.js
var At = {};
function jt(e, t) {
	let n = t || At;
	return Mt(e, typeof n.includeImageAlt != "boolean" || n.includeImageAlt, typeof n.includeHtml != "boolean" || n.includeHtml);
}
function Mt(e, t, n) {
	if (Pt(e)) {
		if ("value" in e) return e.type === "html" && !n ? "" : e.value;
		if (t && "alt" in e && e.alt) return e.alt;
		if ("children" in e) return Nt(e.children, t, n);
	}
	return Array.isArray(e) ? Nt(e, t, n) : "";
}
function Nt(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) r[i] = Mt(e[i], t, n);
	return r.join("");
}
function Pt(e) {
	return !!(e && typeof e == "object");
}
// node_modules/micromark-util-chunked/index.js
function Ft(e, t, n, r) {
	let i = e.length, a = 0, o;
	if (t = t < 0 ? -t > i ? 0 : i + t : t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4) o = Array.from(r), o.unshift(t, n), e.splice(...o);
	else for (n && e.splice(t, n); a < r.length;) o = r.slice(a, a + 1e4), o.unshift(t, 0), e.splice(...o), a += 1e4, t += 1e4;
}
function It(e, t) {
	return e.length > 0 ? (Ft(e, e.length, 0, t), e) : t;
}
// node_modules/micromark-util-combine-extensions/index.js
var Lt = {}.hasOwnProperty;
function Rt(e) {
	let t = {}, n = -1;
	for (; ++n < e.length;) zt(t, e[n]);
	return t;
}
function zt(e, t) {
	let n;
	for (n in t) {
		let r = (Lt.call(e, n) ? e[n] : void 0) || (e[n] = {}), i = t[n], a;
		if (i) for (a in i) {
			Lt.call(r, a) || (r[a] = []);
			let e = i[a];
			Bt(r[a], Array.isArray(e) ? e : e ? [e] : []);
		}
	}
}
function Bt(e, t) {
	let n = -1, r = [];
	for (; ++n < t.length;) (t[n].add === "after" ? e : r).push(t[n]);
	Ft(e, 0, 0, r);
}
// node_modules/micromark-util-normalize-identifier/index.js
function Vt(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
// node_modules/micromark-util-character/index.js
var Ht = Z(/[A-Za-z]/), Ut = Z(/[\dA-Za-z]/), Wt = Z(/[#-'*+\--9=?A-Z^-~]/);
function Gt(e) {
	return e !== null && (e < 32 || e === 127);
}
var Kt = Z(/\d/), qt = Z(/[\dA-Fa-f]/), Jt = Z(/[!-/:-@[-`{-~]/);
function Yt(e) {
	return e !== null && e < -2;
}
function Xt(e) {
	return e !== null && (e < 0 || e === 32);
}
function X(e) {
	return e === -2 || e === -1 || e === 32;
}
var Zt = Z(/\p{P}|\p{S}/u), Qt = Z(/\s/);
function Z(e) {
	return t;
	function t(t) {
		return t !== null && t > -1 && e.test(String.fromCharCode(t));
	}
}
// node_modules/micromark-factory-space/index.js
function $t(e, t, n, r) {
	let i = r ? r - 1 : Infinity, a = 0;
	return o;
	function o(r) {
		return X(r) ? (e.enter(n), s(r)) : t(r);
	}
	function s(r) {
		return X(r) && a++ < i ? (e.consume(r), s) : (e.exit(n), t(r));
	}
}
function en(e, t, n, r, i, a) {
	let o = 0;
	return s;
	function s(t) {
		return a > 0 && X(t) ? (e.enter(r), c(t)) : l(t);
	}
	function c(t) {
		return X(t) && o < a ? (e.consume(t), o++, c) : (e.exit(r), l(t));
	}
	function l(e) {
		return o >= i ? t(e) : n(e);
	}
}
// node_modules/micromark-util-classify-character/index.js
function tn(e) {
	if (e === null || Xt(e) || Qt(e)) return 1;
	if (Zt(e)) return 2;
}
// node_modules/micromark-util-resolve-all/index.js
function nn(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) {
		let a = e[i].resolveAll;
		a && !r.includes(a) && (t = a(t, n), r.push(a));
	}
	return t;
}
// node_modules/micromark-core-commonmark/lib/blank-line.js
var rn = {
	partial: !0,
	tokenize: an
};
function an(e, t, n) {
	return r;
	function r(t) {
		return X(t) ? $t(e, i, "linePrefix")(t) : i(t);
	}
	function i(e) {
		return e === null || Yt(e) ? t(e) : n(e);
	}
}
// src/local/contracts/version.ts
var on = "local-draft-3", sn = /* @__PURE__ */ new Set([
	"table",
	"caption",
	"colgroup",
	"col",
	"thead",
	"tbody",
	"tfoot",
	"tr",
	"th",
	"td"
]), cn = {
	colgroup: /* @__PURE__ */ new Set(["span"]),
	col: /* @__PURE__ */ new Set(["span"]),
	td: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"align"
	]),
	th: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"scope",
		"abbr",
		"align"
	])
};
function ln(e, t) {
	let n = t.trim();
	return [
		"colspan",
		"rowspan",
		"span"
	].includes(e) ? /^\d{1,5}$/.test(n) && Number(n) <= (e === "rowspan" ? 65534 : 1e3) && Number(n) >= (e === "rowspan" ? 0 : 1) : e === "align" ? te(t) !== null : e !== "scope" || [
		"row",
		"col",
		"rowgroup",
		"colgroup"
	].includes(n.toLowerCase());
}
// src/local/html/html-policy.ts
var un = {
	b: "strong",
	strong: "strong",
	i: "emphasis",
	em: "emphasis",
	s: "delete",
	del: "delete",
	u: "underline",
	mark: "mark",
	sup: "sup",
	sub: "sub"
}, dn = /* @__PURE__ */ new Set([
	"br",
	"hr",
	"img",
	"col"
]), fn = /* @__PURE__ */ new Set([
	"pre",
	"code",
	"script",
	"style",
	"textarea",
	"title",
	"xmp",
	"iframe",
	"noembed",
	"noframes",
	"plaintext"
]), pn = /* @__PURE__ */ new Set([
	"id",
	"title",
	"lang",
	"dir"
]), mn = {
	a: y,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...cn
};
function hn(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") return i + 1;
	}
	return -1;
}
function gn(e, t, n) {
	if (e.startsWith("<!-->", t)) return Math.min(n, t + 5);
	if (e.startsWith("<!--->", t)) return Math.min(n, t + 6);
	let r = e.indexOf("-->", t + 4);
	return r < 0 || r + 3 > n ? n : r + 3;
}
function _n(e) {
	return e.trim().replace(/[\u0000- ]+/g, "");
}
function vn(e, t) {
	let n = /^([a-z][a-z0-9+.-]*):/i.exec(_n(e));
	if (!n) return !1;
	let r = n[1].toLowerCase();
	return t === "image" ? r !== "http" && r !== "https" : r !== "http" && r !== "https" && r !== "mailto" && r !== "tel";
}
function yn(e, t) {
	return t === "class" || t === "style" || /^on[a-z]/i.test(t) ? !1 : t === "align" && b.has(e) || pn.has(t) || /^aria-[a-z0-9_.-]+$/.test(t) || /^data-[a-z0-9_.-]+$/.test(t) ? !0 : mn[e]?.has(t) ?? !1;
}
function bn(e, t) {
	return !(e === "dir" && ![
		"ltr",
		"rtl",
		"auto"
	].includes(t.trim().toLowerCase()) || e === "id" && t.trim() === "" || (e === "width" || e === "height") && !/^\d{1,6}$/.test(t.trim()) || e === "start" && !/^-?\d{1,9}$/.test(t.trim()) || !ln(e, t) || e === "href" && vn(t, "link") || e === "src" && vn(t, "image"));
}
function xn(e, t) {
	return b.has(e) ? te(t) : null;
}
// src/local/parsing/parser-capabilities.ts
var Sn = Object.freeze({}), Cn = Object.freeze({
	id: "reactive-md/default",
	version: l
});
function wn(e, t = []) {
	C(e) || g("config", "must be an object."), T(e, ee, "config"), e.protocol !== "reactive-md-config/v1" && g("config.protocol", `must be "${i}".`);
	let n = _(e.presets, Cn), a = t.length > 0 ? n : Object.freeze([]), o = E(e.components, t), s = Object.freeze([]);
	return r({
		protocol: "reactive-md-config/v1",
		presets: a,
		components: o
	}) > 16777216 && g("config", `serialized size exceeds the ${S}-byte budget.`), Object.freeze({
		protocol: i,
		key: x(a, o),
		presets: a,
		components: o,
		registry: Object.freeze([...t, ...o]),
		themes: s
	});
}
// src/local/configuration/options-core.ts
var Tn = [
	"enableCss",
	"enableJavaScript",
	"enableExtendedHtml"
], En = Cn;
function Q(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var Dn = "local.options.invalid.host-components", On = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, kn = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), An = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), jn = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean"
]), Mn = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]), Nn = /* @__PURE__ */ new Set([
	"maxSyntaxNodes",
	"maxParseWork",
	"maxMarkdownDepth"
]);
function Pn(e, t, n) {
	if (!Object.hasOwn(e, t)) return {
		ok: !0,
		value: n
	};
	let r = e[t];
	if (r === void 0) return {
		ok: !0,
		value: n
	};
	if (typeof r != "number" || !Number.isSafeInteger(r) || r < 1) {
		let e = t === "maxSyntaxNodes" ? "max-syntax-nodes" : t === "maxParseWork" ? "max-parse-work" : "max-markdown-depth";
		return {
			ok: !1,
			message: `Compile option limits.${t} must be a positive safe integer.`,
			key: `local.options.invalid.${e}`
		};
	}
	return {
		ok: !0,
		value: r
	};
}
function $(e) {
	return {
		ok: !1,
		message: `Compile option hostComponents is invalid: ${e}`,
		key: Dn,
		detail: e
	};
}
function Fn(e, t) {
	if (e === void 0) return {
		ok: !0,
		binding: void 0
	};
	if (!Q(e)) return $(`${t} "binding" must be an object.`);
	for (let n of Object.keys(e)) if (![
		"kind",
		"initialRule",
		"min",
		"max",
		"step",
		"options",
		"exclusive"
	].includes(n)) return $(`${t} "binding" has unknown field "${n}".`);
	let n = e.kind;
	if (typeof n != "string" || !jn.has(n)) return $(`${t} "binding.kind" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
	let r = { kind: n };
	if (Object.hasOwn(e, "exclusive") && e.exclusive !== void 0) {
		if (typeof e.exclusive != "boolean") return $(`${t} "binding.exclusive" must be a boolean.`);
		r.exclusive = e.exclusive;
	}
	if (Object.hasOwn(e, "initialRule") && e.initialRule !== void 0) {
		let n = e.initialRule;
		if (typeof n != "string" || ![
			"empty",
			"false",
			"nearest-zero",
			"min",
			"first-option"
		].includes(n)) return $(`${t} "binding.initialRule" is not supported.`);
		r.initialRule = n;
	}
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (!Object.hasOwn(e, n) || e[n] === void 0) continue;
		if (r.kind !== "number") return $(`${t} "binding.${n}" is only valid for number bindings.`);
		let i = e[n];
		if (typeof i != "number" || !Number.isFinite(i)) return $(`${t} "binding.${n}" must be a finite number.`);
		r[n] = i;
	}
	if (r.kind === "number") {
		if (r.step !== void 0 && !(r.step > 0)) return $(`${t} "binding.step" must be greater than 0.`);
		if (r.min !== void 0 && r.max !== void 0 && r.min > r.max) return $(`${t} "binding.min" cannot exceed "binding.max".`);
		if (r.initialRule !== void 0 && !["min", "nearest-zero"].includes(r.initialRule)) return $(`${t} "binding.initialRule" must be "min" or "nearest-zero" for number bindings.`);
		r.initialRule ??= "nearest-zero";
	}
	let i = Object.hasOwn(e, "options") && e.options !== void 0;
	if (i) {
		if (r.kind !== "string") return $(`${t} "binding.options" is only valid for string bindings.`);
		let n = e.options;
		if (!Array.isArray(n) || n.length === 0) return $(`${t} "binding.options" must be a non-empty string array.`);
		if (n.length > 64) return $(`${t} "binding.options" accepts at most 64 values.`);
		let i = /* @__PURE__ */ new Set(), a = [];
		for (let e of n) {
			if (typeof e != "string" || e === "") return $(`${t} "binding.options" must be a non-empty string array.`);
			if (e.length > 128) return $(`${t} "binding.options" value exceeds the 128-character limit.`);
			if (i.has(e)) return $(`${t} "binding.options" value "${e}" is declared more than once.`);
			i.add(e), a.push(e);
		}
		r.options = a, r.initialRule ??= "first-option";
	}
	if (r.kind === "string") {
		let e = i ? "first-option" : "empty";
		if (r.initialRule !== void 0 && r.initialRule !== e) return $(`${t} "binding.initialRule" must be "${e}" for ${i ? "choice" : "string"} bindings.`);
		r.initialRule ??= e;
	}
	if (r.kind === "boolean") {
		if (r.initialRule !== void 0 && r.initialRule !== "false") return $(`${t} "binding.initialRule" must be "false" for boolean bindings.`);
		r.initialRule ??= "false";
	}
	return {
		ok: !0,
		binding: r
	};
}
function In(e, t) {
	let n = [], r = /* @__PURE__ */ new Map();
	if (e === void 0) return {
		ok: !0,
		hostComponents: n,
		hostByName: r
	};
	if (!Array.isArray(e)) return $("must be an array.");
	if (e.length > 32) return $("accepts at most 32 components.");
	let i = /* @__PURE__ */ new Set();
	for (let e of t) i.add(e.name.toLowerCase());
	for (let e of w) i.add(e.name.toLowerCase());
	for (let e of h) i.add(e.toLowerCase());
	i.add("theme");
	for (let t = 0; t < e.length; t += 1) {
		let a = e[t], s = `hostComponents[${t}]`;
		if (!Q(a)) return $(`${s} must be an object.`);
		let c = a.name;
		if (typeof c != "string") return $(`${s} "name" must be a string.`);
		if (c.length > 128) return $(`${s} "name" exceeds the 128-character limit.`);
		if (!On.test(c)) return $(`${s} "name" ${c} must use lowercase kebab-case.`);
		if (i.has(c.toLowerCase())) return $(`${s} "name" ${c} conflicts with a built-in component, HTML tag or theme.`);
		if (r.has(c.toLowerCase())) return $(`${s} "name" ${c} is declared more than once.`);
		if (typeof a.form != "string" || !An.has(a.form)) return $(`${s} "form" must be "leaf", "inline" or "container".`);
		let l = a.form, u = Fn(a.binding, s);
		if (!u.ok) return u;
		let d = u.binding, f = a.props;
		if (!Q(f)) return $(`${s} "props" must be an object.`);
		let p = {};
		for (let e of Object.keys(f)) {
			if (!On.test(e)) return $(`${s} property "${e}" must use lowercase kebab-case.`);
			if (d && Mn.has(e)) return $(`${s} property "${e}" is reserved by the host binding.`);
			let t = f[e];
			if (!Q(t)) return $(`${s} property "${e}" must be an object.`);
			let n = t.kind;
			if (typeof n != "string" || !kn.has(n)) return $(`property "${e}" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
			let r = { kind: n };
			for (let n of ["required", "static"]) if (Object.hasOwn(t, n) && t[n] !== void 0) {
				if (typeof t[n] != "boolean") return $(`${s} property "${e}" "${n}" must be a boolean.`);
				r[n] = t[n];
			}
			let i = Object.hasOwn(t, "enum") && t.enum !== void 0;
			if (n !== "enum") {
				if (i) return $(`${s} property "${e}" has "enum" but kind is "${n}".`);
			} else {
				let n = t.enum;
				if (!Array.isArray(n) || n.length === 0) return $(`${s} property "${e}" "enum" must be a non-empty string array.`);
				if (n.length > 64) return $(`${s} property "${e}" "enum" accepts at most 64 values.`);
				let i = /* @__PURE__ */ new Set();
				for (let t of n) {
					if (typeof t != "string") return $(`${s} property "${e}" "enum" must be a non-empty string array.`);
					if (t.length > 128) return $(`${s} property "${e}" enum value exceeds the 128-character limit.`);
					if (i.has(t)) return $(`${s} property "${e}" enum value "${t}" is declared more than once.`);
					i.add(t);
				}
				r.enum = [...n];
			}
			let a = Object.hasOwn(t, "pattern") && t.pattern !== void 0;
			if (n !== "string") {
				if (a) return $(`${s} property "${e}" has "pattern" but kind is "${n}".`);
			} else if (a) {
				let n = t.pattern;
				if (typeof n != "string") return $(`${s} property "${e}" "pattern" must be a string.`);
				if (n.length > 512) return $(`${s} property "${e}" "pattern" exceeds the 512-character limit.`);
				try {
					new RegExp(n);
				} catch {
					return $(`${s} property "${e}" "pattern" is not a valid regular expression.`);
				}
				if (!o(n)) return $(`${s} property "${e}" "pattern" uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected.`);
				r.pattern = n;
			}
			p[e] = r;
		}
		let m = {
			name: c,
			form: l,
			props: p,
			...d ? { binding: d } : {}
		};
		n.push(m), r.set(c, m);
	}
	return {
		ok: !0,
		hostComponents: n,
		hostByName: r
	};
}
function Ln(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function Rn(e) {
	let t = e.static === !0 || e.dynamic === !1;
	if (e.kind === "enum") {
		let n = `^(?:${(e.enum ?? []).map(Ln).join("|")})$`;
		if (n.length <= 512) return {
			kind: "string",
			...e.required === !0 ? { required: !0 } : {},
			...t ? { static: !0 } : {},
			pattern: n
		};
	}
	let n = { kind: e.kind };
	return e.required === !0 && e.default === void 0 && (n.required = !0), t && (n.static = !0), e.enum && (n.enum = [...e.enum]), e.pattern !== void 0 && (n.pattern = e.pattern), n;
}
function zn(t) {
	let n = [], r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let a of t.components) {
		let t = {};
		for (let e of Object.keys(a.props)) t[e] = Rn(a.props[e]);
		let o = e(a), s = {
			name: a.name,
			form: a.form,
			props: t,
			...o ? { binding: o } : {}
		};
		n.push(s), r.set(a.name, s), i.set(a.name, a);
	}
	return {
		hostComponents: n,
		hostByName: r,
		sdkByName: i
	};
}
function Bn(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.name, t);
	let r = /* @__PURE__ */ new Map();
	for (let e of t.values()) r.set(e.name, e);
	for (let e of w) r.has(e.name) || r.set(e.name, m(e));
	return {
		componentByName: n,
		schemaByName: r
	};
}
function Vn(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name, v(n));
	return t;
}
function Hn(e, t) {
	let r = t.defaults, i = new Set(r.map((e) => e.name));
	if (e !== void 0 && !Q(e)) return {
		ok: !1,
		message: "Compile options must be an object.",
		key: "local.options.invalid.object"
	};
	let a = e ?? {}, o = {
		enableCss: !1,
		enableJavaScript: !1,
		enableExtendedHtml: !1
	};
	for (let e of Tn) {
		if (!Object.hasOwn(a, e)) continue;
		let t = a[e];
		if (t !== void 0) {
			if (typeof t != "boolean") return {
				ok: !1,
				message: `Compile option ${e} must be a boolean.`,
				key: "local.options.invalid.html-flag"
			};
			o[e] = t;
		}
	}
	let s = !1;
	if (Object.hasOwn(a, "markdownBreaks")) {
		let e = a.markdownBreaks;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option markdownBreaks must be a boolean.",
				key: "local.options.invalid.markdown-breaks"
			};
			s = e;
		}
	}
	let l = !0;
	if (Object.hasOwn(a, "strict")) {
		let e = a.strict;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option strict must be a boolean.",
				key: "local.options.invalid.strict"
			};
			l = e;
		}
	}
	let u = a.limits, f = c, p = n, h = d;
	if (u !== void 0) {
		if (!Q(u)) return {
			ok: !1,
			message: "Compile option limits must be an object.",
			key: "local.options.invalid.limits"
		};
		for (let e of Object.keys(u)) if (!Nn.has(e) && u[e] !== void 0) return {
			ok: !1,
			message: `Compile option limits.${e} is not supported.`,
			key: "local.options.invalid.limits-unknown",
			detail: e
		};
		let e = Pn(u, "maxSyntaxNodes", f);
		if (!e.ok) return e;
		f = e.value;
		let t = Pn(u, "maxParseWork", p);
		if (!t.ok) return t;
		p = t.value;
		let n = Pn(u, "maxMarkdownDepth", h);
		if (!n.ok) return n;
		h = n.value;
	}
	let g = Object.hasOwn(a, "config") && a.config !== void 0, _ = Object.hasOwn(a, "hostComponents") && a.hostComponents !== void 0;
	if (g && _) return {
		ok: !1,
		message: "Compile option config cannot be combined with hostComponents.",
		key: "local.options.invalid.config-conflict"
	};
	let v, y, b, x, S, C, w, T, E;
	if (g) {
		try {
			v = t.readConfig(a.config, r);
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return {
				ok: !1,
				message: `Compile option config is invalid: ${t}`,
				key: "local.options.invalid.config",
				detail: t
			};
		}
		let e = zn(v);
		y = e.hostComponents, b = e.hostByName, x = e.sdkByName, S = v.registry;
		let n = Bn(S, Vn(S));
		C = n.schemaByName, w = n.componentByName, T = new Set(v.components.map((e) => e.name)), E = /* @__PURE__ */ new Set();
	} else if (_) {
		let e = In(a.hostComponents, r);
		if (!e.ok) return e;
		y = e.hostComponents, b = e.hostByName, x = /* @__PURE__ */ new Map(), S = r;
		let t = Vn(r);
		for (let [n, r] of e.hostByName) t.set(n, m({
			...r,
			legacyHost: !0
		}));
		let n = Bn(r, t);
		C = n.schemaByName, w = n.componentByName, T = new Set(e.hostByName.keys()), E = new Set(e.hostByName.keys());
	} else {
		y = [], b = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Map(), S = r;
		let e = Bn(r, Vn(r));
		C = e.schemaByName, w = e.componentByName, T = /* @__PURE__ */ new Set(), E = /* @__PURE__ */ new Set();
	}
	return {
		ok: !0,
		maxSyntaxNodes: f,
		maxParseWork: p,
		maxMarkdownDepth: h,
		html: o,
		htmlActive: o.enableCss || o.enableJavaScript || o.enableExtendedHtml,
		markdownBreaks: s,
		strict: l,
		hostComponents: y,
		hostByName: b,
		...v ? { config: v } : {},
		sdkByName: x,
		registry: S,
		componentByName: w,
		schemaByName: C,
		defaultComponentNames: i,
		externalComponentNames: T,
		legacyHostNames: E,
		componentConfigKey: v ? t.configKey(v) : t.defaultConfigKey,
		capabilities: t.capabilities ?? Sn,
		...t.preset ? { preset: t.preset } : {}
	};
}
function Un(e, t = [], n) {
	let r = t.length > 0 ? En : void 0, i = r ? [r] : [];
	return Hn(e, {
		defaults: t,
		...r ? { preset: r } : {},
		defaultConfigKey: x(i, []),
		readConfig: wn,
		configKey: (e) => e.key,
		...n ? { capabilities: n } : {}
	});
}
function Wn(e) {
	return e.componentConfigKey;
}
// src/local/evaluation/validation.ts
var Gn = "local.validation.failed", Kn = "local.validation.expression", qn = "Validation failed.";
function Jn(e) {
	return e.length > 2e3 ? `${e.slice(0, u - 1)}…` : e;
}
function Yn(e) {
	let t = e.trim();
	return t ? t.split(/\s+/) : [];
}
function Xn(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function Zn(e) {
	if (!e || typeof e != "object") return !1;
	let t = e, n = t.range;
	return typeof t.expression == "string" && typeof t.message == "string" && Array.isArray(t.fields) && !!n && Number.isFinite(n.start) && Number.isFinite(n.end);
}
function Qn(e, t, n, r, i) {
	let a = e.length, o = Math.max(0, Math.min(a, Math.trunc(n.start))), s = Math.max(o + 1, Math.min(a, Math.trunc(n.end))), c = 0, l = Math.max(0, t.length - 1);
	for (; c < l;) {
		let e = Math.ceil((c + l) / 2);
		t[e] <= o ? c = e : l = e - 1;
	}
	return {
		code: r,
		message: i,
		severity: "error",
		range: {
			start: o,
			end: s
		},
		line: c + 1,
		column: o - t[c] + 1
	};
}
export { Be as $, Ht as A, Zt as B, ln as C, tn as D, nn as E, qt as F, Ft as G, Vt as H, Jt as I, Ot as J, jt as K, Yt as L, Wt as M, Gt as N, $t as O, Kt as P, F as Q, Xt as R, sn as S, rn as T, Rt as U, Qt as V, It as W, Dt as X, Et as Y, St as Z, gn as _, Zn as a, re as at, bn as b, Qn as c, Un as d, mt as et, Hn as f, xn as g, dn as h, Jn as i, xt as it, Ut as j, en as k, Tn as l, fn as m, Gn as n, I as nt, Xn as o, ne as ot, un as p, kt as q, qn as r, Ze as rt, Yn as s, Kn as t, bt as tt, Wn as u, hn as v, on as w, cn as x, yn as y, X as z };
