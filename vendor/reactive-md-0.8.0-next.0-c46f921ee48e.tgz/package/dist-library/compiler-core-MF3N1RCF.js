import { o as e } from "./props-DGlBk0e5.js";
import { H as t, J as n, K as r, O as i, Q as a, S as o, U as s, W as c, X as l, et as u, q as d } from "./manifest-gj41AWZb.js";
import { A as f, B as p, C as m, D as h, E as g, F as _, I as v, K as y, L as b, M as x, N as S, O as C, P as w, R as T, S as E, T as D, U as O, Y as ee, _ as te, b as ne, f as re, h as k, j as A, k as ie, m as ae, w as oe, x as se, z as j } from "./config-validation-DaLdxnS1.js";
import { $ as ce, A as M, D as le, E as ue, F as de, G as fe, H as pe, I as N, J as me, K as he, L as P, M as F, N as ge, O as I, P as _e, Q as L, R, S as ve, T as z, U as ye, W as B, X as be, Y as xe, Z as V, _ as Se, at as H, b as Ce, et as we, g as Te, h as Ee, it as De, j as U, k as Oe, m as ke, ot as Ae, p as je, rt as Me, s as Ne, u as Pe, v as Fe, w as Ie, y as Le, z as W } from "./validation-BXMN-r9R.js";
// \0rolldown/runtime.js
var Re = Object.create, ze = Object.defineProperty, Be = Object.getOwnPropertyDescriptor, Ve = Object.getOwnPropertyNames, He = Object.getPrototypeOf, Ue = Object.prototype.hasOwnProperty, We = (e, t) => () => (t || (e((t = { exports: {} }).exports, t, t.exports), e = null), t.exports), Ge = (e, t) => {
	let n = {};
	for (var r in e) ze(n, r, {
		get: e[r],
		enumerable: !0
	});
	return t || ze(n, Symbol.toStringTag, { value: "Module" }), n;
}, G = (e, t, n, r) => {
	if (t && typeof t == "object" || typeof t == "function") for (var i = Ve(t), a = 0, o = i.length, s; a < o; a++) s = i[a], !Ue.call(e, s) && s !== n && ze(e, s, {
		get: ((e) => t[e]).bind(null, s),
		enumerable: !(r = Be(t, s)) || r.enumerable
	});
	return e;
}, Ke = (e, t, n) => (n = e == null ? {} : Re(He(e)), G(t || !e || !e.__esModule || !Ue.call(e, "default") ? ze(n, "default", {
	value: e,
	enumerable: !0
}) : n, e)), qe = /* @__PURE__ */ ((e) => typeof require < "u" ? require : typeof Proxy < "u" ? new Proxy(e, { get: (e, t) => (typeof require < "u" ? require : e)[t] }) : e)(function(e) {
	if (typeof require < "u") return require.apply(this, arguments);
	throw Error("Calling `require` for \"" + e + "\" in an environment that doesn't expose the `require` function. See https://rolldown.rs/in-depth/bundling-cjs#require-external-modules for more details.");
}), K = class extends Error {
	code;
	offset;
	constructor(e, t, n = 0) {
		super(t), this.name = "LatexError", this.code = e, this.offset = n;
	}
}, Je = 5e4, Ye = 2e4, Xe = 5e3, Ze = 120, Qe = 2e4, $e = 1e3, et = /* @__PURE__ */ new Set([
	"quad",
	"qquad",
	"enspace",
	"thinspace",
	"medspace",
	"thickspace",
	"negthinspace",
	"displaystyle",
	"textstyle",
	"scriptstyle",
	"scriptscriptstyle",
	"limits",
	"nolimits"
]), tt = {
	alpha: "alpha",
	beta: "beta",
	gamma: "gamma",
	theta: "theta",
	omega: "omega",
	lambda: "lambda",
	mu: "mu",
	sigma: "sigma"
}, nt = /* @__PURE__ */ new Set([
	"sin",
	"cos",
	"tan",
	"arcsin",
	"arccos",
	"arctan",
	"exp",
	"ln",
	"log",
	"min",
	"max"
]), rt = {
	"{": "lbrace",
	"}": "rbrace",
	"|": "vert",
	"%": "percent",
	"&": "amp",
	"#": "hash",
	_: "underscore",
	$: "dollar"
};
function it(e) {
	let t = [], n = 0, r = (e, n, r) => {
		if (t.length >= Ye) throw new K("latex-budget", "Math input contains too many tokens.", r);
		t.push({
			kind: e,
			value: n,
			offset: r
		});
	};
	for (; n < e.length;) {
		let t = e[n];
		if (t === " " || t === "	" || t === "\r" || t === "\n") n += 1;
		else if (t === "%") for (; n < e.length && e[n] !== "\n";) n += 1;
		else if (t === "\\") {
			if (n + 1 >= e.length) throw new K("latex-syntax", "Formula ends with a lone backslash.", n);
			let t = e[n + 1];
			if (t === "\\") {
				r("command", "newline", n), n += 2;
				continue;
			}
			if (/[A-Za-z]/.test(t)) {
				let t = n + 1;
				for (; t < e.length && /[A-Za-z]/.test(e[t]);) t += 1;
				let i = e.slice(n + 1, t);
				et.has(i) || r("command", i, n), n = t;
				continue;
			}
			if (t === " " || t === "," || t === ";" || t === ":" || t === "!") {
				n += 2;
				continue;
			}
			let i = rt[t];
			if (i) {
				r("command", i, n), n += 2;
				continue;
			}
			r("command", t, n), n += 2;
		} else if (t >= "0" && t <= "9") {
			let t = /^(?:\d+(?:\.\d*)?|\.\d+)/.exec(e.slice(n));
			r("number", t[0], n), n += t[0].length;
		} else if (t === "." && e[n + 1] >= "0" && e[n + 1] <= "9") {
			let t = /^(?:\d+(?:\.\d*)?|\.\d+)/.exec(e.slice(n));
			r("number", t[0], n), n += t[0].length;
		} else /[A-Za-z]/.test(t) ? (r("letter", t, n), n += 1) : (r("punct", t, n), n += 1);
	}
	return r("eof", "", e.length), t;
}
function at(e) {
	return Object.prototype.hasOwnProperty.call(tt, e);
}
function ot(e) {
	switch (e.kind) {
		case "number":
		case "letter": return !0;
		case "punct": return e.value === "(" || e.value === "{" || e.value === "[" || e.value === "|";
		case "command": {
			let t = e.value;
			return nt.has(t) || at(t) ? !0 : t === "frac" || t === "dfrac" || t === "tfrac" || t === "sqrt" || t === "left" || t === "pi" || t === "mathrm" || t === "begin" || t === "lvert" || t === "vert" || t === "lbrace";
		}
		default: return !1;
	}
}
function st(e) {
	if (e.kind === "punct") return e.value === "=" ? "eq" : e.value === "<" ? "lt" : e.value === ">" ? "gt" : null;
	if (e.kind === "command") {
		if (e.value === "ne" || e.value === "neq") return "ne";
		if (e.value === "le" || e.value === "leq") return "le";
		if (e.value === "ge" || e.value === "geq") return "ge";
	}
	return null;
}
var ct = class {
	tokens;
	source;
	pos = 0;
	nodes = 0;
	allowY;
	constructor(e, t, n = {}) {
		this.source = e, this.tokens = t, this.allowY = n.allowY === !0;
	}
	parseDocument() {
		if (this.peek().kind === "eof") throw new K("latex-empty", "Formula is empty.", 0);
		if (this.atLetter("y") && this.atPunctAt(1, "=") && (this.pos += 2), this.peek().kind === "eof") throw new K("latex-empty", "Missing expression after y.", this.peek().offset);
		let e = this.parseAdditive(0), t = this.peek();
		if (t.kind !== "eof") throw st(t) || t.kind === "punct" && t.value === "=" ? new K("latex-relation", "Plots support only explicit y = f(x) equations.", t.offset) : new K("latex-syntax", `Unexpected token "${this.raw(t)}".`, t.offset);
		return e;
	}
	parseEquation() {
		if (this.peek().kind === "eof") throw new K("latex-empty", "Formula is empty.", 0);
		let e = this.parseAdditive(0), t = this.peek();
		if (t.kind !== "punct" || t.value !== "=") throw new K("latex-relation", "Plot formulas must be written as an equation.", t.offset);
		this.take();
		let n = this.parseAdditive(0), r = this.peek();
		if (r.kind !== "eof") throw new K("latex-syntax", `Unexpected token "${this.raw(r)}".`, r.offset);
		return {
			left: e,
			right: n
		};
	}
	peek(e = 0) {
		return this.tokens[Math.min(this.pos + e, this.tokens.length - 1)];
	}
	take() {
		return this.tokens[this.pos++];
	}
	atPunct(e) {
		let t = this.peek();
		return t.kind === "punct" && t.value === e;
	}
	atPunctAt(e, t) {
		let n = this.peek(e);
		return n.kind === "punct" && n.value === t;
	}
	atCommand(e) {
		let t = this.peek();
		return t.kind === "command" && t.value === e;
	}
	atLetter(e) {
		let t = this.peek();
		return t.kind === "letter" && t.value === e;
	}
	expectPunct(e) {
		let t = this.peek();
		if (t.kind !== "punct" || t.value !== e) throw new K("latex-syntax", `Missing "${e}".`, t.offset);
		return this.take();
	}
	raw(e) {
		return e.kind === "eof" ? "end of input" : e.kind === "command" ? `\\${e.value}` : this.source.slice(e.offset, e.offset + Math.max(1, e.value.length));
	}
	make(e, t, n) {
		if (this.nodes += 1, this.nodes > Xe) throw new K("latex-budget", "Formula is too complex.", t);
		if (n > Ze) throw new K("latex-budget", "Formula is nested too deeply.", t);
		return e;
	}
	parseAdditive(e) {
		let t = this.parseMultiplicative(e + 1, !1);
		for (;;) {
			let n = this.peek();
			if (n.kind !== "punct" || n.value !== "+" && n.value !== "-") break;
			let r = this.take().value, i = this.parseMultiplicative(e + 1, !1);
			t = this.make({
				kind: "binary",
				op: r,
				left: t,
				right: i,
				offset: n.offset
			}, n.offset, e);
		}
		return t;
	}
	parseMultiplicative(e, t) {
		let n = this.parseUnary(e + 1, t);
		for (;;) {
			let r = this.peek();
			if (r.kind === "punct" && r.value === "/") {
				this.take();
				let i = this.parseUnary(e + 1, t);
				n = this.make({
					kind: "binary",
					op: "/",
					left: n,
					right: i,
					offset: r.offset
				}, r.offset, e);
				continue;
			}
			if (r.kind === "punct" && r.value === "*" || r.kind === "command" && (r.value === "cdot" || r.value === "times")) {
				this.take();
				let i = this.parseUnary(e + 1, t);
				n = this.make({
					kind: "binary",
					op: "*",
					left: n,
					right: i,
					offset: r.offset
				}, r.offset, e);
				continue;
			}
			if (t && r.kind === "command" && nt.has(r.value) || !ot(r)) break;
			let i = this.parseUnary(e + 1, t);
			n = this.make({
				kind: "binary",
				op: "*",
				left: n,
				right: i,
				offset: r.offset
			}, r.offset, e);
		}
		return n;
	}
	parseUnary(e, t) {
		let n = this.peek();
		if (n.kind === "punct" && (n.value === "+" || n.value === "-")) {
			this.take();
			let r = this.parseUnary(e + 1, t);
			return n.value === "+" ? r : this.make({
				kind: "unary",
				op: "-",
				operand: r,
				offset: n.offset
			}, n.offset, e);
		}
		return this.parsePower(e, t);
	}
	parsePower(e, t) {
		let n = this.parseAtom(e + 1, t), r = this.peek();
		if (r.kind === "punct" && r.value === "^") {
			this.take();
			let t = this.parseScriptArgument(e + 1);
			return this.make({
				kind: "binary",
				op: "^",
				left: n,
				right: t,
				offset: r.offset
			}, r.offset, e);
		}
		return n;
	}
	parseScriptArgument(e) {
		if (this.atPunct("{")) return this.parseBraceGroup(e + 1);
		if (this.atPunct("+") || this.atPunct("-")) {
			let t = this.take(), n = this.parseUnary(e + 1, !1);
			return t.value === "+" ? n : this.make({
				kind: "unary",
				op: "-",
				operand: n,
				offset: t.offset
			}, t.offset, e);
		}
		return this.parseUnary(e + 1, !1);
	}
	parseAtom(e, t) {
		let n = this.peek();
		if (n.kind === "number") {
			this.take();
			let t = Number(n.value);
			if (!Number.isFinite(t)) throw new K("latex-number", `Number "${n.value}" is not finite.`, n.offset);
			return this.make({
				kind: "number",
				value: t,
				offset: n.offset
			}, n.offset, e);
		}
		if (n.kind === "letter") return this.take(), this.variable(n.value, n.offset, e);
		if (n.kind === "punct") {
			if (n.value === "(") return this.parseParenthesized(e);
			if (n.value === "{") return this.parseBraceGroup(e);
			if (n.value === "[") return this.parseBracketGroup(e);
			if (n.value === "|") return this.parsePlainAbs(e, n.offset);
			throw new K("latex-syntax", `Cannot start an expression with "${n.value}".`, n.offset);
		}
		if (n.kind === "command") {
			let t = n.value;
			if (t === "frac" || t === "dfrac" || t === "tfrac") {
				this.take();
				let t = this.parseArgument(e + 1), r = this.parseArgument(e + 1);
				return this.make({
					kind: "binary",
					op: "/",
					left: t,
					right: r,
					offset: n.offset
				}, n.offset, e);
			}
			if (t === "sqrt") {
				this.take();
				let t = null;
				this.atPunct("[") && (this.take(), t = this.parseAdditive(e + 1), this.expectPunct("]"));
				let r = this.parseArgument(e + 1);
				return this.make({
					kind: "call",
					name: "sqrt",
					args: [r],
					base: t,
					power: null,
					offset: n.offset
				}, n.offset, e);
			}
			if (t === "left") return this.parseLeft(e);
			if (nt.has(t)) return this.parseFunction(t, e);
			if (t === "pi") return this.take(), this.make({
				kind: "constant",
				value: "pi",
				offset: n.offset
			}, n.offset, e);
			if (at(t)) return this.take(), this.variable(tt[t], n.offset, e);
			if (t === "mathrm") {
				this.take();
				let t = this.readRawGroup();
				if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(t.raw)) throw new K("latex-name", "\\mathrm requires a valid parameter name.", t.offset);
				return this.variable(t.raw, n.offset, e);
			}
			if (t === "begin") return this.parseCases(e);
			if (t === "lvert" || t === "vert") return this.parseCommandAbs(e, n.offset);
			throw t === "right" ? new K("latex-syntax", "\\right has no matching \\left.", n.offset) : t === "text" ? new K("latex-unsupported", "\\text is only allowed as the otherwise condition of a piecewise function.", n.offset) : new K("latex-unsupported", `Command \\${t} is not supported for computation.`, n.offset);
		}
		throw new K("latex-syntax", "Expression is incomplete.", n.offset);
	}
	parseArgument(e) {
		if (this.atPunct("{")) return this.parseBraceGroup(e + 1);
		if (this.peek().kind === "eof") throw new K("latex-syntax", "Command is missing an argument.", this.peek().offset);
		return this.parseUnary(e + 1, !1);
	}
	parseParenthesized(e) {
		let t = this.expectPunct("(");
		if (this.atPunct(")")) throw new K("latex-syntax", "Missing expression inside parentheses.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct(")"), n;
	}
	parseBraceGroup(e) {
		let t = this.expectPunct("{");
		if (this.atPunct("}")) throw new K("latex-syntax", "Missing expression inside braces.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct("}"), n;
	}
	parseBracketGroup(e) {
		let t = this.expectPunct("[");
		if (this.atPunct("]")) throw new K("latex-syntax", "Missing expression inside brackets.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct("]"), n;
	}
	parsePlainAbs(e, t) {
		if (this.take(), this.atPunct("|")) throw new K("latex-syntax", "Absolute value is missing its contents.", t);
		let n = this.parseAdditive(e + 1);
		if (this.atPunct("|")) this.take();
		else if (this.atCommand("rvert")) this.take();
		else throw new K("latex-syntax", "Unpaired absolute value bar.", t);
		return this.make({
			kind: "abs",
			value: n,
			offset: t
		}, t, e);
	}
	parseCommandAbs(e, t) {
		if (this.take(), this.atCommand("rvert") || this.atCommand("vert") || this.atPunct("|")) throw new K("latex-syntax", "Absolute value is missing its contents.", t);
		let n = this.parseAdditive(e + 1);
		if (this.atCommand("rvert") || this.atCommand("vert") || this.atPunct("|")) this.take();
		else throw new K("latex-syntax", "Unpaired absolute value bar.", t);
		return this.make({
			kind: "abs",
			value: n,
			offset: t
		}, t, e);
	}
	parseLeft(e) {
		let t = this.take(), n = this.readDelimiter(), r = this.parseAdditive(e + 1);
		if (!this.atCommand("right")) throw new K("latex-syntax", "\\left has no matching \\right.", t.offset);
		this.take();
		let i = this.readDelimiter();
		if (n === "|" && i !== "|") throw new K("latex-syntax", "Unpaired absolute value bar.", t.offset);
		return n === "|" ? this.make({
			kind: "abs",
			value: r,
			offset: t.offset
		}, t.offset, e) : r;
	}
	readDelimiter() {
		let e = this.peek();
		if (e.kind === "punct" && (e.value === "(" || e.value === ")" || e.value === "[" || e.value === "]" || e.value === "|" || e.value === ".")) return this.take(), e.value;
		if (e.kind === "command" && (e.value === "lbrace" || e.value === "rbrace" || e.value === "lvert" || e.value === "rvert" || e.value === "vert" || e.value === "Vert")) return this.take(), e.value === "lbrace" || e.value === "rbrace" ? "{" : e.value === "lvert" || e.value === "rvert" || e.value === "vert" ? "|" : "Vert";
		throw new K("latex-syntax", "Missing delimiter after \\left/\\right.", e.offset);
	}
	variable(e, t, n) {
		if (e === "y" && !this.allowY) throw new K("latex-name", "y is the plot output marker and cannot appear in the expression.", t);
		return e === "e" || e === "pi" ? this.make({
			kind: "constant",
			value: e,
			offset: t
		}, t, n) : this.make({
			kind: "variable",
			name: e,
			offset: t
		}, t, n);
	}
	parseFunction(e, t) {
		let n = this.take().offset, r = null, i = null;
		e === "log" && this.atPunct("_") && (this.take(), r = this.parseScriptArgument(t + 1)), this.atPunct("^") && (this.take(), i = this.parseScriptArgument(t + 1));
		let a = [];
		if ((e === "min" || e === "max") && this.atPunct("(")) {
			if (this.take(), this.atPunct(")")) throw new K("latex-syntax", `\\${e} requires at least one argument.`, n);
			for (a.push(this.parseAdditive(t + 1)); this.atPunct(",");) this.take(), a.push(this.parseAdditive(t + 1));
			this.expectPunct(")");
		} else a.push(this.parseFunctionArgument(t + 1));
		return this.make({
			kind: "call",
			name: e,
			args: a,
			base: r,
			power: i,
			offset: n
		}, n, t);
	}
	parseFunctionArgument(e) {
		if (this.atPunct("(")) {
			this.take();
			let t = this.parseAdditive(e + 1);
			return this.expectPunct(")"), t;
		}
		return this.parseMultiplicative(e + 1, !0);
	}
	parseCases(e) {
		let t = this.take(), n = this.readRawGroup();
		if (n.raw.trim() !== "cases") throw new K("latex-unsupported", `Environment "${n.raw.trim()}" is not supported.`, n.offset);
		let r = [];
		for (; !this.atCommand("end");) {
			if (this.peek().kind === "eof") throw new K("latex-syntax", "cases environment is missing \\end{cases}.", t.offset);
			if (this.atCommand("newline")) {
				this.take();
				continue;
			}
			let n = this.parseAdditive(e + 1);
			this.atPunct(",") && this.take();
			let i = null;
			if (this.atPunct("&") && (this.take(), i = this.parseCaseCondition(e + 1), this.atPunct(",") && this.take()), r.push({
				value: n,
				when: i
			}), this.atCommand("newline")) {
				this.take();
				continue;
			}
			if (this.atCommand("end")) break;
			let a = this.peek();
			throw new K("latex-syntax", `Unexpected "${this.raw(a)}" after a cases branch.`, a.offset);
		}
		let i = this.take();
		if (this.readRawGroup().raw.trim() !== "cases") throw new K("latex-syntax", "\\begin{cases} must be closed with \\end{cases}.", i.offset);
		if (r.length === 0) throw new K("latex-syntax", "cases environment has no branches.", t.offset);
		return this.make({
			kind: "cases",
			branches: r,
			offset: t.offset
		}, t.offset, e);
	}
	parseCaseCondition(e) {
		if (this.atCommand("text")) {
			let e = this.take(), t = this.readRawGroup();
			if (t.raw.trim() !== "otherwise") throw new K("latex-unsupported", `Unsupported piecewise condition text "${t.raw.trim()}".`, e.offset);
			return null;
		}
		let t = this.parseAdditive(e + 1), n = this.peek(), r = st(n);
		if (!r) throw new K("latex-syntax", "Piecewise condition requires one comparison.", n.offset);
		return this.take(), {
			op: r,
			left: t,
			right: this.parseAdditive(e + 1)
		};
	}
	readRawGroup() {
		let e = this.expectPunct("{"), t = 1, n = this.pos;
		for (; n < this.tokens.length; n += 1) {
			let e = this.tokens[n];
			if (e.kind === "eof") break;
			if (e.kind === "punct") {
				if (e.value === "{") t += 1;
				else if (e.value === "}" && (--t, t === 0)) break;
			}
		}
		if (n >= this.tokens.length || this.tokens[n].kind === "eof") throw new K("latex-syntax", "Unclosed brace.", e.offset);
		let r = this.tokens[n];
		return this.pos = n + 1, {
			raw: this.source.slice(e.offset + 1, r.offset),
			offset: e.offset + 1
		};
	}
};
function q(e, t) {
	switch (e.kind) {
		case "variable":
			e.name !== "x" && t.add(e.name);
			return;
		case "number":
		case "constant": return;
		case "unary":
			q(e.operand, t);
			return;
		case "binary":
			q(e.left, t), q(e.right, t);
			return;
		case "abs":
			q(e.value, t);
			return;
		case "call":
			e.base && q(e.base, t), e.power && q(e.power, t);
			for (let n of e.args) q(n, t);
			return;
		case "cases":
			for (let n of e.branches) q(n.value, t), n.when && (q(n.when.left, t), q(n.when.right, t));
			return;
	}
}
function lt(e, t, n, r) {
	let i = [], a = (t) => {
		switch (t.kind) {
			case "variable": {
				if (r.has(t.name)) return;
				let a = n + t.offset, o = a + 1;
				e.startsWith("\\mathrm", t.offset) ? o = n + e.indexOf("}", t.offset) + 1 : e[t.offset] === "\\" && (o = a + 1 + t.name.length), i.push({
					name: t.name,
					range: {
						start: a,
						end: o
					}
				});
				return;
			}
			case "unary":
				a(t.operand);
				return;
			case "binary":
				a(t.left), a(t.right);
				return;
			case "abs":
				a(t.value);
				return;
			case "call":
				t.base && a(t.base), t.power && a(t.power), t.args.forEach(a);
				return;
			case "cases":
				for (let e of t.branches) a(e.value), e.when && (a(e.when.left), a(e.when.right));
				return;
			case "number":
			case "constant": return;
		}
	};
	return a(t), i;
}
function ut(e) {
	let t = e.trim(), n = e.length - e.trimStart().length, r = Ct(t);
	if (r) {
		let e = /* @__PURE__ */ new Set([
			"x",
			"y",
			"t"
		]), t = [];
		for (let i of [{
			text: r.x,
			offset: r.xOffset
		}, {
			text: r.y,
			offset: r.yOffset
		}]) {
			yt(i.text);
			let r = new ct(i.text, it(i.text)).parseDocument();
			t.push(...lt(i.text, r, n + i.offset, e));
		}
		return t.sort((e, t) => e.range.start - t.range.start);
	}
	try {
		return lt(e, new ct(e, it(e)).parseDocument(), 0, /* @__PURE__ */ new Set(["x", "y"])).sort((e, t) => e.range.start - t.range.start);
	} catch (t) {
		try {
			let t = new ct(e, it(e), { allowY: !0 }).parseEquation(), n = /* @__PURE__ */ new Set(["x", "y"]);
			return [...lt(e, t.left, 0, n), ...lt(e, t.right, 0, n)].sort((e, t) => e.range.start - t.range.start);
		} catch {
			throw t;
		}
	}
}
function J(e, t, n) {
	throw new K(e, t, n);
}
function dt(e, t) {
	return Number.isFinite(e) || J("latex-number", "Result is not finite.", t), e;
}
function ft(e, t, n) {
	if (e === "x") return t.x;
	let r = t.env[e];
	return r === void 0 && !Object.prototype.hasOwnProperty.call(t.env, e) && J("latex-variable", `Parameter "${e}" is not declared.`, n), typeof r == "number" && Number.isFinite(r) || J("latex-type", `Parameter "${e}" must be a finite number.`, n), r;
}
function pt(e, t, n) {
	return e === 0 && t < 0 && J("latex-divide-by-zero", "Negative powers of zero are undefined.", n), e < 0 && !Number.isInteger(t) && J("latex-domain", "A negative base with a non-integer exponent is not real.", n), dt(e ** +t, n);
}
function mt(e, t, n) {
	let r = t ?? 2;
	return (!Number.isFinite(r) || r <= 0) && J("latex-domain", "Root index must be positive.", n), e < 0 ? (Number.isInteger(r) && r % 2 != 0 || J("latex-domain", "A negative number has no real even root.", n), dt(r === 3 ? -Math.cbrt(-e) : -((-e) ** (1 / r)), n)) : dt(e ** (1 / r), n);
}
function ht(e, t) {
	let n = Y(e.left, t), r = Y(e.right, t);
	switch (e.op) {
		case "eq": return n === r;
		case "ne": return n !== r;
		case "lt": return n < r;
		case "le": return n <= r;
		case "gt": return n > r;
		case "ge": return n >= r;
		default: return !1;
	}
}
function gt(e, t) {
	let n = e.args.map((e) => Y(e, t)), r = 0;
	switch (e.name) {
		case "sin":
			r = Math.sin(n[0]);
			break;
		case "cos":
			r = Math.cos(n[0]);
			break;
		case "tan":
			Math.abs(Math.cos(n[0])) < 1e-15 && J("latex-domain", "tan is undefined at this point.", e.offset), r = Math.tan(n[0]);
			break;
		case "arcsin":
			(n[0] < -1 || n[0] > 1) && J("latex-domain", "arcsin argument must be in [-1, 1].", e.offset), r = Math.asin(n[0]);
			break;
		case "arccos":
			(n[0] < -1 || n[0] > 1) && J("latex-domain", "arccos argument must be in [-1, 1].", e.offset), r = Math.acos(n[0]);
			break;
		case "arctan":
			r = Math.atan(n[0]);
			break;
		case "exp":
			r = Math.exp(n[0]);
			break;
		case "ln":
			n[0] <= 0 && J("latex-domain", "ln argument must be positive.", e.offset), r = Math.log(n[0]);
			break;
		case "log": {
			let i = e.base ? Y(e.base, t) : 10;
			(i <= 0 || i === 1) && J("latex-domain", "Logarithm base must be positive and not equal to 1.", e.offset), n[0] <= 0 && J("latex-domain", "Logarithm argument must be positive.", e.offset), r = Math.log(n[0]) / Math.log(i);
			break;
		}
		case "min":
			r = Math.min(...n);
			break;
		case "max":
			r = Math.max(...n);
			break;
		case "sqrt":
			r = mt(n[0], e.base ? Y(e.base, t) : null, e.offset);
			break;
		default: J("latex-unsupported", "Unsupported function.", e.offset);
	}
	return e.power && (r = pt(r, Y(e.power, t), e.offset)), dt(r, e.offset);
}
function Y(e, t) {
	let n = e.offset;
	t.steps += 1, t.depth += 1;
	try {
		switch (t.steps > t.limit && J("latex-budget", "Math evaluation exceeded its budget.", n), t.depth > $e && J("latex-budget", "Math evaluation is nested too deeply.", n), e.kind) {
			case "number": return e.value;
			case "constant": return e.value === "pi" ? Math.PI : Math.E;
			case "variable": return ft(e.name, t, e.offset);
			case "unary": {
				let n = Y(e.operand, t);
				return e.op === "-" ? -n : n;
			}
			case "binary": {
				let n = Y(e.left, t), r = Y(e.right, t);
				switch (e.op) {
					case "+": return dt(n + r, e.offset);
					case "-": return dt(n - r, e.offset);
					case "*": return dt(n * r, e.offset);
					case "/": return r === 0 && J("latex-divide-by-zero", "Division by zero.", e.offset), dt(n / r, e.offset);
					case "^": return pt(n, r, e.offset);
				}
				break;
			}
			case "abs": return dt(Math.abs(Y(e.value, t)), e.offset);
			case "call": return gt(e, t);
			case "cases":
				for (let n of e.branches) if (n.when === null || ht(n.when, t)) return Y(n.value, t);
				J("latex-undefined", "No piecewise branch matched.", e.offset);
		}
		J("latex-unsupported", "Cannot compute this math structure.", n);
	} finally {
		--t.depth;
	}
}
var _t = /* @__PURE__ */ new Map();
function vt(e, t, n) {
	return {
		source: e,
		dependencies: n,
		evaluate(e, n, r) {
			if (typeof e != "number" || !Number.isFinite(e)) throw new K("latex-variable", "Plot input x must be a finite number.", 0);
			let i = {
				x: e,
				env: n ?? {},
				steps: r?.steps ?? 0,
				limit: r?.limit ?? Qe,
				depth: 0
			};
			try {
				return Y(t, i);
			} finally {
				r && (r.steps = i.steps);
			}
		}
	};
}
function yt(e) {
	if (typeof e != "string") throw new K("latex-syntax", "Math source must be a string.", 0);
	if (e.length > Je) throw new K("latex-budget", "Formula exceeds the length limit.", Je);
	let t = _t.get(e);
	if (t) return t;
	let n = new ct(e, it(e)).parseDocument(), r = /* @__PURE__ */ new Set();
	q(n, r);
	let i = vt(e, n, [...r]);
	return _t.size >= 512 && _t.clear(), _t.set(e, i), i;
}
function X(e, t) {
	switch (e.kind) {
		case "variable": return e.name === t;
		case "number":
		case "constant": return !1;
		case "unary": return X(e.operand, t);
		case "binary": return X(e.left, t) || X(e.right, t);
		case "abs": return X(e.value, t);
		case "call": return e.base !== null && X(e.base, t) || e.power !== null && X(e.power, t) || e.args.some((e) => X(e, t));
		case "cases": return e.branches.some((e) => X(e.value, t) || e.when !== null && (X(e.when.left, t) || X(e.when.right, t)));
	}
}
function bt(e, t) {
	return e.kind === "variable" && e.name === t;
}
function xt(e) {
	let t = 0;
	for (let n = 0; n < e.length; n += 1) {
		let r = e[n];
		if (r === "{") t += 1;
		else if (r === "}") t = Math.max(0, t - 1);
		else if (r === "=" && t === 0) return n;
	}
	return -1;
}
function St(e, t) {
	let n = [], r = 0, i = 0, a = (r) => {
		let a = e.slice(i, r), o = a.length - a.trimStart().length, s = a.trim();
		s && n.push({
			text: s,
			offset: t + i + o
		});
	};
	for (let t = 0; t < e.length; t += 1) {
		let n = e[t];
		n === "{" ? r += 1 : n === "}" ? r = Math.max(0, r - 1) : n === "\\" && e[t + 1] === "\\" && r === 0 && (a(t), i = t + 2, t += 1);
	}
	return a(e.length), n;
}
function Ct(e) {
	let t = /^\\begin\{cases\}([\s\S]*)\\end\{cases\}$/u.exec(e);
	if (!t) return null;
	let n = t.index + 13, r = St(t[1], n);
	if (r.length !== 2) return null;
	let i = null, a = null;
	for (let e of r) {
		let t = xt(e.text);
		if (t < 0) return null;
		let n = e.text.slice(0, t).trim(), r = e.text.slice(t + 1), o = r.length - r.trimStart().length, s = r.trim();
		if (!s) return null;
		let c = e.offset + t + 1 + o;
		if (n === "x" && i === null) i = {
			text: s,
			offset: c
		};
		else if (n === "y" && a === null) a = {
			text: s,
			offset: c
		};
		else return null;
	}
	return i !== null && a !== null ? {
		x: i.text,
		y: a.text,
		xOffset: i.offset,
		yOffset: a.offset
	} : null;
}
function wt(e) {
	let t = e.trim();
	if (!t) return null;
	if (/^\\begin\{cases\}/u.test(t)) return "parametric";
	let n = xt(t);
	if (n < 0) return null;
	if (t.slice(0, n).trim() !== "y") return "implicit";
	try {
		let { right: e } = new ct(t, it(t), { allowY: !0 }).parseEquation();
		return X(e, "y") ? "implicit" : "explicit";
	} catch {
		return "explicit";
	}
}
function Tt(e) {
	if (typeof e != "string") throw new K("latex-syntax", "Math source must be a string.", 0);
	if (e.length > Je) throw new K("latex-budget", "Formula exceeds the length limit.", Je);
	let t = e.trim();
	if (!t) throw new K("latex-empty", "Formula is empty.", 0);
	let n = Ct(t);
	if (n) {
		let e = (e) => it(e).some((e) => e.kind === "letter" && e.value === "x");
		if (e(n.x) || e(n.y)) throw new K("latex-variable", "Parametric formulas use t and cannot read x.", 0);
		let r = yt(n.x), i = yt(n.y), a = /* @__PURE__ */ new Set();
		for (let e of [...r.dependencies, ...i.dependencies]) e !== "t" && e !== "x" && e !== "y" && a.add(e);
		return {
			kind: "parametric",
			source: t,
			expression: r,
			yExpression: i,
			dependencies: [...a]
		};
	}
	let { left: r, right: i } = new ct(t, it(t), { allowY: !0 }).parseEquation();
	if (bt(r, "y") && !X(i, "y")) {
		let e = yt(t);
		return {
			kind: "explicit",
			source: t,
			expression: e,
			yExpression: null,
			dependencies: e.dependencies
		};
	}
	let a = {
		kind: "binary",
		op: "-",
		left: r,
		right: i,
		offset: r.offset
	}, o = /* @__PURE__ */ new Set();
	return q(a, o), o.delete("x"), o.delete("y"), {
		kind: "implicit",
		source: t,
		expression: vt(t, a, [...o]),
		yExpression: null,
		dependencies: [...o]
	};
}
var Et = 100, Dt = 32;
function Ot(e) {
	return Math.max(32, Math.min(100, Math.floor(e)));
}
// src/local/compilation/dependencies.ts
var kt = /* @__PURE__ */ new Map(), At = /* @__PURE__ */ new WeakMap(), jt = /* @__PURE__ */ new WeakMap();
function Mt(e) {
	let t = e.snapshot().revision, n = jt.get(e);
	if (n?.revision === t) return n.tokens;
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new WeakMap();
	for (let t of V(e.document.nodes, !0)) {
		let n = e.resetToken(t);
		for (let e of t.children ?? []) n += i.get(e);
		r.set(t.id, n), i.set(t, n);
	}
	return jt.set(e, {
		revision: t,
		tokens: r
	}), r;
}
function Nt(e, t) {
	for (let n of t) e.add(n);
}
function Pt(e, t) {
	let n = At.get(e);
	if (n !== void 0 && n.definitions === t) return n.index;
	let r = e.dependencies;
	if (r !== void 0) {
		let n = new Map(Object.entries(r));
		return At.set(e, {
			definitions: t,
			index: n
		}), n;
	}
	let i = t ?? (Array.isArray(e.componentDefinitions) ? e.componentDefinitions : []), a = /* @__PURE__ */ new Map(), o = D(e), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Set();
	for (let [t, n] of Object.entries(e.bindings)) {
		for (let e of n.nodeIds) c.add(e);
		if (!t.startsWith("@")) for (let e of n.nodeIds) {
			let n = s.get(e) ?? [];
			n.push(t), s.set(e, n);
		}
	}
	let l = (e) => s.get(e.id) ?? [H(e)], u = (t, n) => {
		let r = e.bindingSlots?.[n.id];
		if (r !== void 0) {
			t.add(H(n));
			for (let e of Object.values(r)) t.add(e);
		}
	}, d = /* @__PURE__ */ new WeakMap();
	for (let t of V(e.nodes, !0)) {
		let n = /* @__PURE__ */ new Set(), r = !1;
		if (t.attrs !== void 0) for (let e of Object.values(t.attrs)) try {
			Nt(n, De(e));
		} catch {
			r = !0;
			break;
		}
		if (!r) {
			if (t.type === "interpolation") try {
				Nt(n, we(t.value ?? "").dependencies);
			} catch {
				r = !0;
			}
			else if (t.type === "math") try {
				Nt(n, yt(t.value ?? "").dependencies);
			} catch {
				r = !0;
			}
			else if (t.name !== void 0) {
				if (o) {
					let r = o.dependencyRules?.[t.id];
					if (r?.selfBinding) {
						let e = r.selfBinding.attribute;
						(r.selfBinding.mode === "always" || e !== void 0 && (t.attrs?.[e] ?? "").trim() !== "") && Nt(n, l(t));
					}
					if (r?.inlineMathReads) for (let e of t.children ?? []) {
						if (e.type !== "inlineMath") continue;
						let t = (e.value ?? "").trim();
						if (/^y\s*=/u.test(t)) try {
							Nt(n, yt(t).dependencies);
						} catch {}
					}
					r || (e.bindingSlots?.[t.id] !== void 0 && n.add(H(t)), c.has(t.id) && Nt(n, l(t)), u(n, t));
				} else {
					let e = t.name ? i.find((e) => e.name === t.name) : void 0, r = e ? x(e) : [], a = r.find((e) => e.kind === "self-binding-read"), o = r.some((e) => e.kind === "inline-math-reads");
					if (a ? (a.mode === "always" || a.attribute !== void 0 && (t.attrs?.[a.attribute] ?? "").trim() !== "") && Nt(n, l(t)) : !o && c.has(t.id) && Nt(n, l(t)), o) for (let e of t.children ?? []) {
						if (e.type !== "inlineMath") continue;
						let t = (e.value ?? "").trim();
						if (/^y\s*=/u.test(t)) try {
							Nt(n, yt(t).dependencies);
						} catch {}
					}
					u(n, t);
				}
			}
		}
		let s = !1;
		for (let e of t.children ?? []) {
			let t = d.get(e);
			t === null ? s = !0 : Nt(n, t);
		}
		let f = r || s ? null : [...n];
		a.set(t.id, f), d.set(t, f);
	}
	return At.set(e, {
		definitions: t,
		index: a
	}), a;
}
function Ft(e, t) {
	if (e.dependencies !== void 0) return;
	let n = Pt(e, t), r = Object.create(null);
	for (let [e, t] of n) r[e] = t === null ? null : Object.freeze([...t]);
	e.dependencies = Object.freeze(r);
}
// src/local/markdown/heading-anchors.ts
function It(e, t) {
	return (e ?? []).map((e) => {
		switch (e.type) {
			case "text":
			case "inlineCode":
			case "inlineMath":
			case "fallback": return e.value ?? "";
			case "image": return e.alt ?? "";
			case "break": return " ";
			case "interpolation": try {
				let n = we(e.value ?? "").evaluate(t);
				return Array.isArray(n) ? "Cannot compute" : n === null ? "" : String(n);
			} catch {
				return "Cannot compute";
			}
			default: return It(e.children, t);
		}
	}).join("");
}
function Lt(e) {
	return e.trim().toLowerCase().replace(/[^\p{L}\p{N}\p{M}\s_-]/gu, "").replace(/\s+/g, "-") || "section";
}
function Rt(e, t) {
	let n = /* @__PURE__ */ new Map(), r = t ?? (Array.isArray(e.componentDefinitions) ? e.componentDefinitions : []);
	for (let e of r.slice(0, 192)) {
		if (!e || typeof e.name != "string" || !Array.isArray(e.rules)) continue;
		let t = e.rules.find((e) => e?.kind === "anchor");
		t?.kind === "anchor" && n.set(e.name, t.id);
	}
	return n;
}
function zt(e, t) {
	if (e.type !== "component" && e.type !== "hostComponent") return;
	let n = t.get(e.name ?? "");
	if (n === void 0) return;
	let r = e.attrs?.[n];
	if (typeof r == "string" && r.length !== 0) return /^[A-Za-z_][A-Za-z0-9_-]*$/.test(r) ? r : void 0;
}
function Bt(e) {
	if (e.type === "component" || e.type === "hostComponent") return;
	let t = e.attrs?.id;
	if (typeof t != "string") return;
	let n = t.trim().replace(/[\u0000- \u007f-\u009f]+/g, "-").replace(/^-+|-+$/g, "");
	return n === "" ? void 0 : n;
}
function Vt(e, t, n = !0, r) {
	let i = Rt(e, r), a = e.initialState;
	if (e.computations) {
		let t = {}, n = /* @__PURE__ */ new Map();
		for (let [r, i] of Object.entries(e.computations)) {
			i.kind === "const" && Object.hasOwn(i, "value") && (t[r] = i.value);
			try {
				n.set(r, we(i.source));
			} catch {}
		}
		let { order: r } = xe(e.computations), i = me(e.computations, r, n, a, t);
		a = {
			...a,
			...i.values
		};
	}
	let o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map();
	function d(e) {
		let n = e, r = u.get(e) ?? 0;
		for (; l.has(n);) r += 1, n = `${e}-${r}`;
		u.set(e, r);
		let i = `${t}-${n}`;
		return l.set(n, i), {
			slug: n,
			id: i
		};
	}
	for (let t of V(e.nodes)) if (t.type === "heading") {
		let e = Bt(t) ?? Lt(It(t.children, a));
		o.set(t, d(e).id);
	} else {
		if (n) {
			let e = zt(t, i);
			e && s.set(t, d(e).id);
		}
		let e = Bt(t);
		e && c.set(t, d(e).id);
	}
	function f(e) {
		if (e.length === 0) return;
		let t = l.get(e);
		if (t) return t;
		try {
			return l.get(decodeURIComponent(e));
		} catch {
			return;
		}
	}
	return {
		ids: o,
		anchorIds: s,
		htmlIds: c,
		targetId(e) {
			return f(e);
		},
		referenceId(e) {
			return f(e) ?? `${t}-${e}`;
		},
		resolve(e) {
			if (!e.startsWith("#")) return e;
			let t = f(e.slice(1));
			return t ? `#${t}` : e;
		}
	};
}
// node_modules/bail/index.js
function Ht(e) {
	if (e) throw e;
}
// node_modules/is-plain-obj/index.js
var Ut = /* @__PURE__ */ Ke((/* @__PURE__ */ We(((e, t) => {
	var n = Object.prototype.hasOwnProperty, r = Object.prototype.toString, i = Object.defineProperty, a = Object.getOwnPropertyDescriptor, o = function(e) {
		return typeof Array.isArray == "function" ? Array.isArray(e) : r.call(e) === "[object Array]";
	}, s = function(e) {
		if (!e || r.call(e) !== "[object Object]") return !1;
		var t = n.call(e, "constructor"), i = e.constructor && e.constructor.prototype && n.call(e.constructor.prototype, "isPrototypeOf");
		if (e.constructor && !t && !i) return !1;
		for (var a in e);
		return a === void 0 || n.call(e, a);
	}, c = function(e, t) {
		i && t.name === "__proto__" ? i(e, t.name, {
			enumerable: !0,
			configurable: !0,
			value: t.newValue,
			writable: !0
		}) : e[t.name] = t.newValue;
	}, l = function(e, t) {
		if (t === "__proto__") {
			if (!n.call(e, t)) return;
			if (a) return a(e, t).value;
		}
		return e[t];
	};
	t.exports = function e() {
		var t, n, r, i, a, u, d = arguments[0], f = 1, p = arguments.length, m = !1;
		for (typeof d == "boolean" && (m = d, d = arguments[1] || {}, f = 2), (d == null || typeof d != "object" && typeof d != "function") && (d = {}); f < p; ++f) if (t = arguments[f], t != null) for (n in t) r = l(d, n), i = l(t, n), d !== i && (m && i && (s(i) || (a = o(i))) ? (a ? (a = !1, u = r && o(r) ? r : []) : u = r && s(r) ? r : {}, c(d, {
			name: n,
			newValue: e(m, u, i)
		})) : i !== void 0 && c(d, {
			name: n,
			newValue: i
		}));
		return d;
	};
})))(), 1);
function Wt(e) {
	if (typeof e != "object" || !e) return !1;
	let t = Object.getPrototypeOf(e);
	return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e);
}
// node_modules/trough/lib/index.js
function Gt() {
	let e = [], t = {
		run: n,
		use: r
	};
	return t;
	function n(...t) {
		let n = -1, r = t.pop();
		if (typeof r != "function") throw TypeError("Expected function as last argument, not " + r);
		i(null, ...t);
		function i(a, ...o) {
			let s = e[++n], c = -1;
			if (a) r(a);
			else {
				for (; ++c < t.length;) (o[c] === null || o[c] === void 0) && (o[c] = t[c]);
				t = o, s ? Kt(s, i)(...o) : r(null, ...o);
			}
		}
	}
	function r(n) {
		if (typeof n != "function") throw TypeError("Expected `middelware` to be a function, not " + n);
		return e.push(n), t;
	}
}
function Kt(e, t) {
	let n;
	return r;
	function r(...t) {
		let r = e.length > t.length, o;
		r && t.push(i);
		try {
			o = e.apply(this, t);
		} catch (e) {
			let t = e;
			if (r && n) throw t;
			return i(t);
		}
		r || (o && o.then && typeof o.then == "function" ? o.then(a, i) : o instanceof Error ? i(o) : a(o));
	}
	function i(e, ...r) {
		n || (n = !0, t(e, ...r));
	}
	function a(e) {
		i(null, e);
	}
}
// node_modules/unist-util-stringify-position/lib/index.js
function qt(e) {
	return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? Yt(e.position) : "start" in e || "end" in e ? Yt(e) : "line" in e || "column" in e ? Jt(e) : "";
}
function Jt(e) {
	return Xt(e && e.line) + ":" + Xt(e && e.column);
}
function Yt(e) {
	return Jt(e && e.start) + "-" + Jt(e && e.end);
}
function Xt(e) {
	return e && typeof e == "number" ? e : 1;
}
// node_modules/vfile-message/lib/index.js
var Z = class extends Error {
	constructor(e, t, n) {
		super(), typeof t == "string" && (n = t, t = void 0);
		let r = "", i = {}, a = !1;
		if (t && (i = "line" in t && "column" in t || "start" in t && "end" in t ? { place: t } : "type" in t ? {
			ancestors: [t],
			place: t.position
		} : { ...t }), typeof e == "string" ? r = e : !i.cause && e && (a = !0, r = e.message, i.cause = e), !i.ruleId && !i.source && typeof n == "string") {
			let e = n.indexOf(":");
			e === -1 ? i.ruleId = n : (i.source = n.slice(0, e), i.ruleId = n.slice(e + 1));
		}
		if (!i.place && i.ancestors && i.ancestors) {
			let e = i.ancestors[i.ancestors.length - 1];
			e && (i.place = e.position);
		}
		let o = i.place && "start" in i.place ? i.place.start : i.place;
		this.ancestors = i.ancestors || void 0, this.cause = i.cause || void 0, this.column = o ? o.column : void 0, this.fatal = void 0, this.file = "", this.message = r, this.line = o ? o.line : void 0, this.name = qt(i.place) || "1:1", this.place = i.place || void 0, this.reason = this.message, this.ruleId = i.ruleId || void 0, this.source = i.source || void 0, this.stack = a && i.cause && typeof i.cause.stack == "string" ? i.cause.stack : "", this.actual = void 0, this.expected = void 0, this.note = void 0, this.url = void 0;
	}
};
Z.prototype.file = "", Z.prototype.name = "", Z.prototype.reason = "", Z.prototype.message = "", Z.prototype.stack = "", Z.prototype.column = void 0, Z.prototype.line = void 0, Z.prototype.ancestors = void 0, Z.prototype.cause = void 0, Z.prototype.fatal = void 0, Z.prototype.place = void 0, Z.prototype.ruleId = void 0, Z.prototype.source = void 0;
// node_modules/vfile/lib/minpath.browser.js
var Zt = {
	basename: Qt,
	dirname: $t,
	extname: en,
	join: tn,
	sep: "/"
};
function Qt(e, t) {
	if (t !== void 0 && typeof t != "string") throw TypeError("\"ext\" argument must be a string");
	an(e);
	let n = 0, r = -1, i = e.length, a;
	if (t === void 0 || t.length === 0 || t.length > e.length) {
		for (; i--;) if (e.codePointAt(i) === 47) {
			if (a) {
				n = i + 1;
				break;
			}
		} else r < 0 && (a = !0, r = i + 1);
		return r < 0 ? "" : e.slice(n, r);
	}
	if (t === e) return "";
	let o = -1, s = t.length - 1;
	for (; i--;) if (e.codePointAt(i) === 47) {
		if (a) {
			n = i + 1;
			break;
		}
	} else o < 0 && (a = !0, o = i + 1), s > -1 && (e.codePointAt(i) === t.codePointAt(s--) ? s < 0 && (r = i) : (s = -1, r = o));
	return n === r ? r = o : r < 0 && (r = e.length), e.slice(n, r);
}
function $t(e) {
	if (an(e), e.length === 0) return ".";
	let t = -1, n = e.length, r;
	for (; --n;) if (e.codePointAt(n) === 47) {
		if (r) {
			t = n;
			break;
		}
	} else r ||= !0;
	return t < 0 ? e.codePointAt(0) === 47 ? "/" : "." : t === 1 && e.codePointAt(0) === 47 ? "//" : e.slice(0, t);
}
function en(e) {
	an(e);
	let t = e.length, n = -1, r = 0, i = -1, a = 0, o;
	for (; t--;) {
		let s = e.codePointAt(t);
		if (s === 47) {
			if (o) {
				r = t + 1;
				break;
			}
		} else n < 0 && (o = !0, n = t + 1), s === 46 ? i < 0 ? i = t : a !== 1 && (a = 1) : i > -1 && (a = -1);
	}
	return i < 0 || n < 0 || a === 0 || a === 1 && i === n - 1 && i === r + 1 ? "" : e.slice(i, n);
}
function tn(...e) {
	let t = -1, n;
	for (; ++t < e.length;) an(e[t]), e[t] && (n = n === void 0 ? e[t] : n + "/" + e[t]);
	return n === void 0 ? "." : nn(n);
}
function nn(e) {
	an(e);
	let t = e.codePointAt(0) === 47, n = rn(e, !t);
	return n.length === 0 && !t && (n = "."), n.length > 0 && e.codePointAt(e.length - 1) === 47 && (n += "/"), t ? "/" + n : n;
}
function rn(e, t) {
	let n = "", r = 0, i = -1, a = 0, o = -1, s, c;
	for (; ++o <= e.length;) {
		if (o < e.length) s = e.codePointAt(o);
		else if (s === 47) break;
		else s = 47;
		if (s === 47) {
			if (i !== o - 1 && a !== 1) {
				if (i !== o - 1 && a === 2) {
					if (n.length < 2 || r !== 2 || n.codePointAt(n.length - 1) !== 46 || n.codePointAt(n.length - 2) !== 46) {
						if (n.length > 2) {
							if (c = n.lastIndexOf("/"), c !== n.length - 1) {
								c < 0 ? (n = "", r = 0) : (n = n.slice(0, c), r = n.length - 1 - n.lastIndexOf("/")), i = o, a = 0;
								continue;
							}
						} else if (n.length > 0) {
							n = "", r = 0, i = o, a = 0;
							continue;
						}
					}
					t && (n = n.length > 0 ? n + "/.." : "..", r = 2);
				} else n.length > 0 ? n += "/" + e.slice(i + 1, o) : n = e.slice(i + 1, o), r = o - i - 1;
			}
			i = o, a = 0;
		} else s === 46 && a > -1 ? a++ : a = -1;
	}
	return n;
}
function an(e) {
	if (typeof e != "string") throw TypeError("Path must be a string. Received " + JSON.stringify(e));
}
// node_modules/vfile/lib/minproc.browser.js
var on = { cwd: sn };
function sn() {
	return "/";
}
// node_modules/vfile/lib/minurl.shared.js
function cn(e) {
	return !!(typeof e == "object" && e && "href" in e && e.href && "protocol" in e && e.protocol && e.auth === void 0);
}
// node_modules/vfile/lib/minurl.browser.js
function ln(e) {
	if (typeof e == "string") e = new URL(e);
	else if (!cn(e)) {
		let t = /* @__PURE__ */ TypeError("The \"path\" argument must be of type string or an instance of URL. Received `" + e + "`");
		throw t.code = "ERR_INVALID_ARG_TYPE", t;
	}
	if (e.protocol !== "file:") {
		let e = /* @__PURE__ */ TypeError("The URL must be of scheme file");
		throw e.code = "ERR_INVALID_URL_SCHEME", e;
	}
	return un(e);
}
function un(e) {
	if (e.hostname !== "") {
		let e = /* @__PURE__ */ TypeError("File URL host must be \"localhost\" or empty on darwin");
		throw e.code = "ERR_INVALID_FILE_URL_HOST", e;
	}
	let t = e.pathname, n = -1;
	for (; ++n < t.length;) if (t.codePointAt(n) === 37 && t.codePointAt(n + 1) === 50) {
		let e = t.codePointAt(n + 2);
		if (e === 70 || e === 102) {
			let e = /* @__PURE__ */ TypeError("File URL path must not include encoded / characters");
			throw e.code = "ERR_INVALID_FILE_URL_PATH", e;
		}
	}
	return decodeURIComponent(t);
}
// node_modules/vfile/lib/index.js
var dn = [
	"history",
	"path",
	"basename",
	"stem",
	"extname",
	"dirname"
], fn = class {
	constructor(e) {
		let t;
		t = e ? cn(e) ? { path: e } : typeof e == "string" || gn(e) ? { value: e } : e : {}, this.cwd = "cwd" in t ? "" : on.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
		let n = -1;
		for (; ++n < dn.length;) {
			let e = dn[n];
			e in t && t[e] !== void 0 && t[e] !== null && (this[e] = e === "history" ? [...t[e]] : t[e]);
		}
		let r;
		for (r in t) dn.includes(r) || (this[r] = t[r]);
	}
	get basename() {
		return typeof this.path == "string" ? Zt.basename(this.path) : void 0;
	}
	set basename(e) {
		mn(e, "basename"), pn(e, "basename"), this.path = Zt.join(this.dirname || "", e);
	}
	get dirname() {
		return typeof this.path == "string" ? Zt.dirname(this.path) : void 0;
	}
	set dirname(e) {
		hn(this.basename, "dirname"), this.path = Zt.join(e || "", this.basename);
	}
	get extname() {
		return typeof this.path == "string" ? Zt.extname(this.path) : void 0;
	}
	set extname(e) {
		if (pn(e, "extname"), hn(this.dirname, "extname"), e) {
			if (e.codePointAt(0) !== 46) throw Error("`extname` must start with `.`");
			if (e.includes(".", 1)) throw Error("`extname` cannot contain multiple dots");
		}
		this.path = Zt.join(this.dirname, this.stem + (e || ""));
	}
	get path() {
		return this.history[this.history.length - 1];
	}
	set path(e) {
		cn(e) && (e = ln(e)), mn(e, "path"), this.path !== e && this.history.push(e);
	}
	get stem() {
		return typeof this.path == "string" ? Zt.basename(this.path, this.extname) : void 0;
	}
	set stem(e) {
		mn(e, "stem"), pn(e, "stem"), this.path = Zt.join(this.dirname || "", e + (this.extname || ""));
	}
	fail(e, t, n) {
		let r = this.message(e, t, n);
		throw r.fatal = !0, r;
	}
	info(e, t, n) {
		let r = this.message(e, t, n);
		return r.fatal = void 0, r;
	}
	message(e, t, n) {
		let r = new Z(e, t, n);
		return this.path && (r.name = this.path + ":" + r.name, r.file = this.path), r.fatal = !1, this.messages.push(r), r;
	}
	toString(e) {
		return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(e || void 0).decode(this.value);
	}
};
function pn(e, t) {
	if (e && e.includes(Zt.sep)) throw Error("`" + t + "` cannot be a path: did not expect `" + Zt.sep + "`");
}
function mn(e, t) {
	if (!e) throw Error("`" + t + "` cannot be empty");
}
function hn(e, t) {
	if (!e) throw Error("Setting `" + t + "` requires `path` to be set too");
}
function gn(e) {
	return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
// node_modules/unified/lib/callable-instance.js
var _n = (function(e) {
	let t = this.constructor.prototype, n = t[e], r = function() {
		return n.apply(r, arguments);
	};
	return Object.setPrototypeOf(r, t), r;
}), vn = {}.hasOwnProperty, yn = new class e extends _n {
	constructor() {
		super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = Gt();
	}
	copy() {
		let t = new e(), n = -1;
		for (; ++n < this.attachers.length;) {
			let e = this.attachers[n];
			t.use(...e);
		}
		return t.data((0, Ut.default)(!0, {}, this.namespace)), t;
	}
	data(e, t) {
		return typeof e == "string" ? arguments.length === 2 ? (Sn("data", this.frozen), this.namespace[e] = t, this) : vn.call(this.namespace, e) && this.namespace[e] || void 0 : e ? (Sn("data", this.frozen), this.namespace = e, this) : this.namespace;
	}
	freeze() {
		if (this.frozen) return this;
		let e = this;
		for (; ++this.freezeIndex < this.attachers.length;) {
			let [t, ...n] = this.attachers[this.freezeIndex];
			if (n[0] === !1) continue;
			n[0] === !0 && (n[0] = void 0);
			let r = t.call(e, ...n);
			typeof r == "function" && this.transformers.use(r);
		}
		return this.frozen = !0, this.freezeIndex = Infinity, this;
	}
	parse(e) {
		this.freeze();
		let t = Tn(e), n = this.parser || this.Parser;
		return bn("parse", n), n(String(t), t);
	}
	process(e, t) {
		let n = this;
		return this.freeze(), bn("process", this.parser || this.Parser), xn("process", this.compiler || this.Compiler), t ? r(void 0, t) : new Promise(r);
		function r(r, i) {
			let a = Tn(e), o = n.parse(a);
			n.run(o, a, function(e, t, r) {
				if (e || !t || !r) return s(e);
				let i = t, a = n.stringify(i, r);
				Dn(a) ? r.value = a : r.result = a, s(e, r);
			});
			function s(e, n) {
				e || !n ? i(e) : r ? r(n) : t(void 0, n);
			}
		}
	}
	processSync(e) {
		let t = !1, n;
		return this.freeze(), bn("processSync", this.parser || this.Parser), xn("processSync", this.compiler || this.Compiler), this.process(e, r), wn("processSync", "process", t), n;
		function r(e, r) {
			t = !0, Ht(e), n = r;
		}
	}
	run(e, t, n) {
		Cn(e), this.freeze();
		let r = this.transformers;
		return !n && typeof t == "function" && (n = t, t = void 0), n ? i(void 0, n) : new Promise(i);
		function i(i, a) {
			let o = Tn(t);
			r.run(e, o, s);
			function s(t, r, o) {
				let s = r || e;
				t ? a(t) : i ? i(s) : n(void 0, s, o);
			}
		}
	}
	runSync(e, t) {
		let n = !1, r;
		return this.run(e, t, i), wn("runSync", "run", n), r;
		function i(e, t) {
			Ht(e), r = t, n = !0;
		}
	}
	stringify(e, t) {
		this.freeze();
		let n = Tn(t), r = this.compiler || this.Compiler;
		return xn("stringify", r), Cn(e), r(e, n);
	}
	use(e, ...t) {
		let n = this.attachers, r = this.namespace;
		if (Sn("use", this.frozen), e != null) {
			if (typeof e == "function") s(e, t);
			else if (typeof e == "object") Array.isArray(e) ? o(e) : a(e);
			else throw TypeError("Expected usable value, not `" + e + "`");
		}
		return this;
		function i(e) {
			if (typeof e == "function") s(e, []);
			else if (typeof e == "object") {
				if (Array.isArray(e)) {
					let [t, ...n] = e;
					s(t, n);
				} else a(e);
			} else throw TypeError("Expected usable value, not `" + e + "`");
		}
		function a(e) {
			if (!("plugins" in e) && !("settings" in e)) throw Error("Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither");
			o(e.plugins), e.settings && (r.settings = (0, Ut.default)(!0, r.settings, e.settings));
		}
		function o(e) {
			let t = -1;
			if (e != null) {
				if (Array.isArray(e)) for (; ++t < e.length;) {
					let n = e[t];
					i(n);
				}
				else throw TypeError("Expected a list of plugins, not `" + e + "`");
			}
		}
		function s(e, t) {
			let r = -1, i = -1;
			for (; ++r < n.length;) if (n[r][0] === e) {
				i = r;
				break;
			}
			if (i === -1) n.push([e, ...t]);
			else if (t.length > 0) {
				let [r, ...a] = t, o = n[i][1];
				Wt(o) && Wt(r) && (r = (0, Ut.default)(!0, o, r)), n[i] = [
					e,
					r,
					...a
				];
			}
		}
	}
}().freeze();
function bn(e, t) {
	if (typeof t != "function") throw TypeError("Cannot `" + e + "` without `parser`");
}
function xn(e, t) {
	if (typeof t != "function") throw TypeError("Cannot `" + e + "` without `compiler`");
}
function Sn(e, t) {
	if (t) throw Error("Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.");
}
function Cn(e) {
	if (!Wt(e) || typeof e.type != "string") throw TypeError("Expected node, got `" + e + "`");
}
function wn(e, t, n) {
	if (!n) throw Error("`" + e + "` finished async. Use `" + t + "` instead");
}
function Tn(e) {
	return En(e) ? e : new fn(e);
}
function En(e) {
	return !!(e && typeof e == "object" && "message" in e && "messages" in e);
}
function Dn(e) {
	return typeof e == "string" || On(e);
}
function On(e) {
	return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
// node_modules/character-entities/index.js
var kn = {
	AElig: "Æ",
	AMP: "&",
	Aacute: "Á",
	Abreve: "Ă",
	Acirc: "Â",
	Acy: "А",
	Afr: "𝔄",
	Agrave: "À",
	Alpha: "Α",
	Amacr: "Ā",
	And: "⩓",
	Aogon: "Ą",
	Aopf: "𝔸",
	ApplyFunction: "⁡",
	Aring: "Å",
	Ascr: "𝒜",
	Assign: "≔",
	Atilde: "Ã",
	Auml: "Ä",
	Backslash: "∖",
	Barv: "⫧",
	Barwed: "⌆",
	Bcy: "Б",
	Because: "∵",
	Bernoullis: "ℬ",
	Beta: "Β",
	Bfr: "𝔅",
	Bopf: "𝔹",
	Breve: "˘",
	Bscr: "ℬ",
	Bumpeq: "≎",
	CHcy: "Ч",
	COPY: "©",
	Cacute: "Ć",
	Cap: "⋒",
	CapitalDifferentialD: "ⅅ",
	Cayleys: "ℭ",
	Ccaron: "Č",
	Ccedil: "Ç",
	Ccirc: "Ĉ",
	Cconint: "∰",
	Cdot: "Ċ",
	Cedilla: "¸",
	CenterDot: "·",
	Cfr: "ℭ",
	Chi: "Χ",
	CircleDot: "⊙",
	CircleMinus: "⊖",
	CirclePlus: "⊕",
	CircleTimes: "⊗",
	ClockwiseContourIntegral: "∲",
	CloseCurlyDoubleQuote: "”",
	CloseCurlyQuote: "’",
	Colon: "∷",
	Colone: "⩴",
	Congruent: "≡",
	Conint: "∯",
	ContourIntegral: "∮",
	Copf: "ℂ",
	Coproduct: "∐",
	CounterClockwiseContourIntegral: "∳",
	Cross: "⨯",
	Cscr: "𝒞",
	Cup: "⋓",
	CupCap: "≍",
	DD: "ⅅ",
	DDotrahd: "⤑",
	DJcy: "Ђ",
	DScy: "Ѕ",
	DZcy: "Џ",
	Dagger: "‡",
	Darr: "↡",
	Dashv: "⫤",
	Dcaron: "Ď",
	Dcy: "Д",
	Del: "∇",
	Delta: "Δ",
	Dfr: "𝔇",
	DiacriticalAcute: "´",
	DiacriticalDot: "˙",
	DiacriticalDoubleAcute: "˝",
	DiacriticalGrave: "`",
	DiacriticalTilde: "˜",
	Diamond: "⋄",
	DifferentialD: "ⅆ",
	Dopf: "𝔻",
	Dot: "¨",
	DotDot: "⃜",
	DotEqual: "≐",
	DoubleContourIntegral: "∯",
	DoubleDot: "¨",
	DoubleDownArrow: "⇓",
	DoubleLeftArrow: "⇐",
	DoubleLeftRightArrow: "⇔",
	DoubleLeftTee: "⫤",
	DoubleLongLeftArrow: "⟸",
	DoubleLongLeftRightArrow: "⟺",
	DoubleLongRightArrow: "⟹",
	DoubleRightArrow: "⇒",
	DoubleRightTee: "⊨",
	DoubleUpArrow: "⇑",
	DoubleUpDownArrow: "⇕",
	DoubleVerticalBar: "∥",
	DownArrow: "↓",
	DownArrowBar: "⤓",
	DownArrowUpArrow: "⇵",
	DownBreve: "̑",
	DownLeftRightVector: "⥐",
	DownLeftTeeVector: "⥞",
	DownLeftVector: "↽",
	DownLeftVectorBar: "⥖",
	DownRightTeeVector: "⥟",
	DownRightVector: "⇁",
	DownRightVectorBar: "⥗",
	DownTee: "⊤",
	DownTeeArrow: "↧",
	Downarrow: "⇓",
	Dscr: "𝒟",
	Dstrok: "Đ",
	ENG: "Ŋ",
	ETH: "Ð",
	Eacute: "É",
	Ecaron: "Ě",
	Ecirc: "Ê",
	Ecy: "Э",
	Edot: "Ė",
	Efr: "𝔈",
	Egrave: "È",
	Element: "∈",
	Emacr: "Ē",
	EmptySmallSquare: "◻",
	EmptyVerySmallSquare: "▫",
	Eogon: "Ę",
	Eopf: "𝔼",
	Epsilon: "Ε",
	Equal: "⩵",
	EqualTilde: "≂",
	Equilibrium: "⇌",
	Escr: "ℰ",
	Esim: "⩳",
	Eta: "Η",
	Euml: "Ë",
	Exists: "∃",
	ExponentialE: "ⅇ",
	Fcy: "Ф",
	Ffr: "𝔉",
	FilledSmallSquare: "◼",
	FilledVerySmallSquare: "▪",
	Fopf: "𝔽",
	ForAll: "∀",
	Fouriertrf: "ℱ",
	Fscr: "ℱ",
	GJcy: "Ѓ",
	GT: ">",
	Gamma: "Γ",
	Gammad: "Ϝ",
	Gbreve: "Ğ",
	Gcedil: "Ģ",
	Gcirc: "Ĝ",
	Gcy: "Г",
	Gdot: "Ġ",
	Gfr: "𝔊",
	Gg: "⋙",
	Gopf: "𝔾",
	GreaterEqual: "≥",
	GreaterEqualLess: "⋛",
	GreaterFullEqual: "≧",
	GreaterGreater: "⪢",
	GreaterLess: "≷",
	GreaterSlantEqual: "⩾",
	GreaterTilde: "≳",
	Gscr: "𝒢",
	Gt: "≫",
	HARDcy: "Ъ",
	Hacek: "ˇ",
	Hat: "^",
	Hcirc: "Ĥ",
	Hfr: "ℌ",
	HilbertSpace: "ℋ",
	Hopf: "ℍ",
	HorizontalLine: "─",
	Hscr: "ℋ",
	Hstrok: "Ħ",
	HumpDownHump: "≎",
	HumpEqual: "≏",
	IEcy: "Е",
	IJlig: "Ĳ",
	IOcy: "Ё",
	Iacute: "Í",
	Icirc: "Î",
	Icy: "И",
	Idot: "İ",
	Ifr: "ℑ",
	Igrave: "Ì",
	Im: "ℑ",
	Imacr: "Ī",
	ImaginaryI: "ⅈ",
	Implies: "⇒",
	Int: "∬",
	Integral: "∫",
	Intersection: "⋂",
	InvisibleComma: "⁣",
	InvisibleTimes: "⁢",
	Iogon: "Į",
	Iopf: "𝕀",
	Iota: "Ι",
	Iscr: "ℐ",
	Itilde: "Ĩ",
	Iukcy: "І",
	Iuml: "Ï",
	Jcirc: "Ĵ",
	Jcy: "Й",
	Jfr: "𝔍",
	Jopf: "𝕁",
	Jscr: "𝒥",
	Jsercy: "Ј",
	Jukcy: "Є",
	KHcy: "Х",
	KJcy: "Ќ",
	Kappa: "Κ",
	Kcedil: "Ķ",
	Kcy: "К",
	Kfr: "𝔎",
	Kopf: "𝕂",
	Kscr: "𝒦",
	LJcy: "Љ",
	LT: "<",
	Lacute: "Ĺ",
	Lambda: "Λ",
	Lang: "⟪",
	Laplacetrf: "ℒ",
	Larr: "↞",
	Lcaron: "Ľ",
	Lcedil: "Ļ",
	Lcy: "Л",
	LeftAngleBracket: "⟨",
	LeftArrow: "←",
	LeftArrowBar: "⇤",
	LeftArrowRightArrow: "⇆",
	LeftCeiling: "⌈",
	LeftDoubleBracket: "⟦",
	LeftDownTeeVector: "⥡",
	LeftDownVector: "⇃",
	LeftDownVectorBar: "⥙",
	LeftFloor: "⌊",
	LeftRightArrow: "↔",
	LeftRightVector: "⥎",
	LeftTee: "⊣",
	LeftTeeArrow: "↤",
	LeftTeeVector: "⥚",
	LeftTriangle: "⊲",
	LeftTriangleBar: "⧏",
	LeftTriangleEqual: "⊴",
	LeftUpDownVector: "⥑",
	LeftUpTeeVector: "⥠",
	LeftUpVector: "↿",
	LeftUpVectorBar: "⥘",
	LeftVector: "↼",
	LeftVectorBar: "⥒",
	Leftarrow: "⇐",
	Leftrightarrow: "⇔",
	LessEqualGreater: "⋚",
	LessFullEqual: "≦",
	LessGreater: "≶",
	LessLess: "⪡",
	LessSlantEqual: "⩽",
	LessTilde: "≲",
	Lfr: "𝔏",
	Ll: "⋘",
	Lleftarrow: "⇚",
	Lmidot: "Ŀ",
	LongLeftArrow: "⟵",
	LongLeftRightArrow: "⟷",
	LongRightArrow: "⟶",
	Longleftarrow: "⟸",
	Longleftrightarrow: "⟺",
	Longrightarrow: "⟹",
	Lopf: "𝕃",
	LowerLeftArrow: "↙",
	LowerRightArrow: "↘",
	Lscr: "ℒ",
	Lsh: "↰",
	Lstrok: "Ł",
	Lt: "≪",
	Map: "⤅",
	Mcy: "М",
	MediumSpace: " ",
	Mellintrf: "ℳ",
	Mfr: "𝔐",
	MinusPlus: "∓",
	Mopf: "𝕄",
	Mscr: "ℳ",
	Mu: "Μ",
	NJcy: "Њ",
	Nacute: "Ń",
	Ncaron: "Ň",
	Ncedil: "Ņ",
	Ncy: "Н",
	NegativeMediumSpace: "​",
	NegativeThickSpace: "​",
	NegativeThinSpace: "​",
	NegativeVeryThinSpace: "​",
	NestedGreaterGreater: "≫",
	NestedLessLess: "≪",
	NewLine: "\n",
	Nfr: "𝔑",
	NoBreak: "⁠",
	NonBreakingSpace: "\xA0",
	Nopf: "ℕ",
	Not: "⫬",
	NotCongruent: "≢",
	NotCupCap: "≭",
	NotDoubleVerticalBar: "∦",
	NotElement: "∉",
	NotEqual: "≠",
	NotEqualTilde: "≂̸",
	NotExists: "∄",
	NotGreater: "≯",
	NotGreaterEqual: "≱",
	NotGreaterFullEqual: "≧̸",
	NotGreaterGreater: "≫̸",
	NotGreaterLess: "≹",
	NotGreaterSlantEqual: "⩾̸",
	NotGreaterTilde: "≵",
	NotHumpDownHump: "≎̸",
	NotHumpEqual: "≏̸",
	NotLeftTriangle: "⋪",
	NotLeftTriangleBar: "⧏̸",
	NotLeftTriangleEqual: "⋬",
	NotLess: "≮",
	NotLessEqual: "≰",
	NotLessGreater: "≸",
	NotLessLess: "≪̸",
	NotLessSlantEqual: "⩽̸",
	NotLessTilde: "≴",
	NotNestedGreaterGreater: "⪢̸",
	NotNestedLessLess: "⪡̸",
	NotPrecedes: "⊀",
	NotPrecedesEqual: "⪯̸",
	NotPrecedesSlantEqual: "⋠",
	NotReverseElement: "∌",
	NotRightTriangle: "⋫",
	NotRightTriangleBar: "⧐̸",
	NotRightTriangleEqual: "⋭",
	NotSquareSubset: "⊏̸",
	NotSquareSubsetEqual: "⋢",
	NotSquareSuperset: "⊐̸",
	NotSquareSupersetEqual: "⋣",
	NotSubset: "⊂⃒",
	NotSubsetEqual: "⊈",
	NotSucceeds: "⊁",
	NotSucceedsEqual: "⪰̸",
	NotSucceedsSlantEqual: "⋡",
	NotSucceedsTilde: "≿̸",
	NotSuperset: "⊃⃒",
	NotSupersetEqual: "⊉",
	NotTilde: "≁",
	NotTildeEqual: "≄",
	NotTildeFullEqual: "≇",
	NotTildeTilde: "≉",
	NotVerticalBar: "∤",
	Nscr: "𝒩",
	Ntilde: "Ñ",
	Nu: "Ν",
	OElig: "Œ",
	Oacute: "Ó",
	Ocirc: "Ô",
	Ocy: "О",
	Odblac: "Ő",
	Ofr: "𝔒",
	Ograve: "Ò",
	Omacr: "Ō",
	Omega: "Ω",
	Omicron: "Ο",
	Oopf: "𝕆",
	OpenCurlyDoubleQuote: "“",
	OpenCurlyQuote: "‘",
	Or: "⩔",
	Oscr: "𝒪",
	Oslash: "Ø",
	Otilde: "Õ",
	Otimes: "⨷",
	Ouml: "Ö",
	OverBar: "‾",
	OverBrace: "⏞",
	OverBracket: "⎴",
	OverParenthesis: "⏜",
	PartialD: "∂",
	Pcy: "П",
	Pfr: "𝔓",
	Phi: "Φ",
	Pi: "Π",
	PlusMinus: "±",
	Poincareplane: "ℌ",
	Popf: "ℙ",
	Pr: "⪻",
	Precedes: "≺",
	PrecedesEqual: "⪯",
	PrecedesSlantEqual: "≼",
	PrecedesTilde: "≾",
	Prime: "″",
	Product: "∏",
	Proportion: "∷",
	Proportional: "∝",
	Pscr: "𝒫",
	Psi: "Ψ",
	QUOT: "\"",
	Qfr: "𝔔",
	Qopf: "ℚ",
	Qscr: "𝒬",
	RBarr: "⤐",
	REG: "®",
	Racute: "Ŕ",
	Rang: "⟫",
	Rarr: "↠",
	Rarrtl: "⤖",
	Rcaron: "Ř",
	Rcedil: "Ŗ",
	Rcy: "Р",
	Re: "ℜ",
	ReverseElement: "∋",
	ReverseEquilibrium: "⇋",
	ReverseUpEquilibrium: "⥯",
	Rfr: "ℜ",
	Rho: "Ρ",
	RightAngleBracket: "⟩",
	RightArrow: "→",
	RightArrowBar: "⇥",
	RightArrowLeftArrow: "⇄",
	RightCeiling: "⌉",
	RightDoubleBracket: "⟧",
	RightDownTeeVector: "⥝",
	RightDownVector: "⇂",
	RightDownVectorBar: "⥕",
	RightFloor: "⌋",
	RightTee: "⊢",
	RightTeeArrow: "↦",
	RightTeeVector: "⥛",
	RightTriangle: "⊳",
	RightTriangleBar: "⧐",
	RightTriangleEqual: "⊵",
	RightUpDownVector: "⥏",
	RightUpTeeVector: "⥜",
	RightUpVector: "↾",
	RightUpVectorBar: "⥔",
	RightVector: "⇀",
	RightVectorBar: "⥓",
	Rightarrow: "⇒",
	Ropf: "ℝ",
	RoundImplies: "⥰",
	Rrightarrow: "⇛",
	Rscr: "ℛ",
	Rsh: "↱",
	RuleDelayed: "⧴",
	SHCHcy: "Щ",
	SHcy: "Ш",
	SOFTcy: "Ь",
	Sacute: "Ś",
	Sc: "⪼",
	Scaron: "Š",
	Scedil: "Ş",
	Scirc: "Ŝ",
	Scy: "С",
	Sfr: "𝔖",
	ShortDownArrow: "↓",
	ShortLeftArrow: "←",
	ShortRightArrow: "→",
	ShortUpArrow: "↑",
	Sigma: "Σ",
	SmallCircle: "∘",
	Sopf: "𝕊",
	Sqrt: "√",
	Square: "□",
	SquareIntersection: "⊓",
	SquareSubset: "⊏",
	SquareSubsetEqual: "⊑",
	SquareSuperset: "⊐",
	SquareSupersetEqual: "⊒",
	SquareUnion: "⊔",
	Sscr: "𝒮",
	Star: "⋆",
	Sub: "⋐",
	Subset: "⋐",
	SubsetEqual: "⊆",
	Succeeds: "≻",
	SucceedsEqual: "⪰",
	SucceedsSlantEqual: "≽",
	SucceedsTilde: "≿",
	SuchThat: "∋",
	Sum: "∑",
	Sup: "⋑",
	Superset: "⊃",
	SupersetEqual: "⊇",
	Supset: "⋑",
	THORN: "Þ",
	TRADE: "™",
	TSHcy: "Ћ",
	TScy: "Ц",
	Tab: "	",
	Tau: "Τ",
	Tcaron: "Ť",
	Tcedil: "Ţ",
	Tcy: "Т",
	Tfr: "𝔗",
	Therefore: "∴",
	Theta: "Θ",
	ThickSpace: "  ",
	ThinSpace: " ",
	Tilde: "∼",
	TildeEqual: "≃",
	TildeFullEqual: "≅",
	TildeTilde: "≈",
	Topf: "𝕋",
	TripleDot: "⃛",
	Tscr: "𝒯",
	Tstrok: "Ŧ",
	Uacute: "Ú",
	Uarr: "↟",
	Uarrocir: "⥉",
	Ubrcy: "Ў",
	Ubreve: "Ŭ",
	Ucirc: "Û",
	Ucy: "У",
	Udblac: "Ű",
	Ufr: "𝔘",
	Ugrave: "Ù",
	Umacr: "Ū",
	UnderBar: "_",
	UnderBrace: "⏟",
	UnderBracket: "⎵",
	UnderParenthesis: "⏝",
	Union: "⋃",
	UnionPlus: "⊎",
	Uogon: "Ų",
	Uopf: "𝕌",
	UpArrow: "↑",
	UpArrowBar: "⤒",
	UpArrowDownArrow: "⇅",
	UpDownArrow: "↕",
	UpEquilibrium: "⥮",
	UpTee: "⊥",
	UpTeeArrow: "↥",
	Uparrow: "⇑",
	Updownarrow: "⇕",
	UpperLeftArrow: "↖",
	UpperRightArrow: "↗",
	Upsi: "ϒ",
	Upsilon: "Υ",
	Uring: "Ů",
	Uscr: "𝒰",
	Utilde: "Ũ",
	Uuml: "Ü",
	VDash: "⊫",
	Vbar: "⫫",
	Vcy: "В",
	Vdash: "⊩",
	Vdashl: "⫦",
	Vee: "⋁",
	Verbar: "‖",
	Vert: "‖",
	VerticalBar: "∣",
	VerticalLine: "|",
	VerticalSeparator: "❘",
	VerticalTilde: "≀",
	VeryThinSpace: " ",
	Vfr: "𝔙",
	Vopf: "𝕍",
	Vscr: "𝒱",
	Vvdash: "⊪",
	Wcirc: "Ŵ",
	Wedge: "⋀",
	Wfr: "𝔚",
	Wopf: "𝕎",
	Wscr: "𝒲",
	Xfr: "𝔛",
	Xi: "Ξ",
	Xopf: "𝕏",
	Xscr: "𝒳",
	YAcy: "Я",
	YIcy: "Ї",
	YUcy: "Ю",
	Yacute: "Ý",
	Ycirc: "Ŷ",
	Ycy: "Ы",
	Yfr: "𝔜",
	Yopf: "𝕐",
	Yscr: "𝒴",
	Yuml: "Ÿ",
	ZHcy: "Ж",
	Zacute: "Ź",
	Zcaron: "Ž",
	Zcy: "З",
	Zdot: "Ż",
	ZeroWidthSpace: "​",
	Zeta: "Ζ",
	Zfr: "ℨ",
	Zopf: "ℤ",
	Zscr: "𝒵",
	aacute: "á",
	abreve: "ă",
	ac: "∾",
	acE: "∾̳",
	acd: "∿",
	acirc: "â",
	acute: "´",
	acy: "а",
	aelig: "æ",
	af: "⁡",
	afr: "𝔞",
	agrave: "à",
	alefsym: "ℵ",
	aleph: "ℵ",
	alpha: "α",
	amacr: "ā",
	amalg: "⨿",
	amp: "&",
	and: "∧",
	andand: "⩕",
	andd: "⩜",
	andslope: "⩘",
	andv: "⩚",
	ang: "∠",
	ange: "⦤",
	angle: "∠",
	angmsd: "∡",
	angmsdaa: "⦨",
	angmsdab: "⦩",
	angmsdac: "⦪",
	angmsdad: "⦫",
	angmsdae: "⦬",
	angmsdaf: "⦭",
	angmsdag: "⦮",
	angmsdah: "⦯",
	angrt: "∟",
	angrtvb: "⊾",
	angrtvbd: "⦝",
	angsph: "∢",
	angst: "Å",
	angzarr: "⍼",
	aogon: "ą",
	aopf: "𝕒",
	ap: "≈",
	apE: "⩰",
	apacir: "⩯",
	ape: "≊",
	apid: "≋",
	apos: "'",
	approx: "≈",
	approxeq: "≊",
	aring: "å",
	ascr: "𝒶",
	ast: "*",
	asymp: "≈",
	asympeq: "≍",
	atilde: "ã",
	auml: "ä",
	awconint: "∳",
	awint: "⨑",
	bNot: "⫭",
	backcong: "≌",
	backepsilon: "϶",
	backprime: "‵",
	backsim: "∽",
	backsimeq: "⋍",
	barvee: "⊽",
	barwed: "⌅",
	barwedge: "⌅",
	bbrk: "⎵",
	bbrktbrk: "⎶",
	bcong: "≌",
	bcy: "б",
	bdquo: "„",
	becaus: "∵",
	because: "∵",
	bemptyv: "⦰",
	bepsi: "϶",
	bernou: "ℬ",
	beta: "β",
	beth: "ℶ",
	between: "≬",
	bfr: "𝔟",
	bigcap: "⋂",
	bigcirc: "◯",
	bigcup: "⋃",
	bigodot: "⨀",
	bigoplus: "⨁",
	bigotimes: "⨂",
	bigsqcup: "⨆",
	bigstar: "★",
	bigtriangledown: "▽",
	bigtriangleup: "△",
	biguplus: "⨄",
	bigvee: "⋁",
	bigwedge: "⋀",
	bkarow: "⤍",
	blacklozenge: "⧫",
	blacksquare: "▪",
	blacktriangle: "▴",
	blacktriangledown: "▾",
	blacktriangleleft: "◂",
	blacktriangleright: "▸",
	blank: "␣",
	blk12: "▒",
	blk14: "░",
	blk34: "▓",
	block: "█",
	bne: "=⃥",
	bnequiv: "≡⃥",
	bnot: "⌐",
	bopf: "𝕓",
	bot: "⊥",
	bottom: "⊥",
	bowtie: "⋈",
	boxDL: "╗",
	boxDR: "╔",
	boxDl: "╖",
	boxDr: "╓",
	boxH: "═",
	boxHD: "╦",
	boxHU: "╩",
	boxHd: "╤",
	boxHu: "╧",
	boxUL: "╝",
	boxUR: "╚",
	boxUl: "╜",
	boxUr: "╙",
	boxV: "║",
	boxVH: "╬",
	boxVL: "╣",
	boxVR: "╠",
	boxVh: "╫",
	boxVl: "╢",
	boxVr: "╟",
	boxbox: "⧉",
	boxdL: "╕",
	boxdR: "╒",
	boxdl: "┐",
	boxdr: "┌",
	boxh: "─",
	boxhD: "╥",
	boxhU: "╨",
	boxhd: "┬",
	boxhu: "┴",
	boxminus: "⊟",
	boxplus: "⊞",
	boxtimes: "⊠",
	boxuL: "╛",
	boxuR: "╘",
	boxul: "┘",
	boxur: "└",
	boxv: "│",
	boxvH: "╪",
	boxvL: "╡",
	boxvR: "╞",
	boxvh: "┼",
	boxvl: "┤",
	boxvr: "├",
	bprime: "‵",
	breve: "˘",
	brvbar: "¦",
	bscr: "𝒷",
	bsemi: "⁏",
	bsim: "∽",
	bsime: "⋍",
	bsol: "\\",
	bsolb: "⧅",
	bsolhsub: "⟈",
	bull: "•",
	bullet: "•",
	bump: "≎",
	bumpE: "⪮",
	bumpe: "≏",
	bumpeq: "≏",
	cacute: "ć",
	cap: "∩",
	capand: "⩄",
	capbrcup: "⩉",
	capcap: "⩋",
	capcup: "⩇",
	capdot: "⩀",
	caps: "∩︀",
	caret: "⁁",
	caron: "ˇ",
	ccaps: "⩍",
	ccaron: "č",
	ccedil: "ç",
	ccirc: "ĉ",
	ccups: "⩌",
	ccupssm: "⩐",
	cdot: "ċ",
	cedil: "¸",
	cemptyv: "⦲",
	cent: "¢",
	centerdot: "·",
	cfr: "𝔠",
	chcy: "ч",
	check: "✓",
	checkmark: "✓",
	chi: "χ",
	cir: "○",
	cirE: "⧃",
	circ: "ˆ",
	circeq: "≗",
	circlearrowleft: "↺",
	circlearrowright: "↻",
	circledR: "®",
	circledS: "Ⓢ",
	circledast: "⊛",
	circledcirc: "⊚",
	circleddash: "⊝",
	cire: "≗",
	cirfnint: "⨐",
	cirmid: "⫯",
	cirscir: "⧂",
	clubs: "♣",
	clubsuit: "♣",
	colon: ":",
	colone: "≔",
	coloneq: "≔",
	comma: ",",
	commat: "@",
	comp: "∁",
	compfn: "∘",
	complement: "∁",
	complexes: "ℂ",
	cong: "≅",
	congdot: "⩭",
	conint: "∮",
	copf: "𝕔",
	coprod: "∐",
	copy: "©",
	copysr: "℗",
	crarr: "↵",
	cross: "✗",
	cscr: "𝒸",
	csub: "⫏",
	csube: "⫑",
	csup: "⫐",
	csupe: "⫒",
	ctdot: "⋯",
	cudarrl: "⤸",
	cudarrr: "⤵",
	cuepr: "⋞",
	cuesc: "⋟",
	cularr: "↶",
	cularrp: "⤽",
	cup: "∪",
	cupbrcap: "⩈",
	cupcap: "⩆",
	cupcup: "⩊",
	cupdot: "⊍",
	cupor: "⩅",
	cups: "∪︀",
	curarr: "↷",
	curarrm: "⤼",
	curlyeqprec: "⋞",
	curlyeqsucc: "⋟",
	curlyvee: "⋎",
	curlywedge: "⋏",
	curren: "¤",
	curvearrowleft: "↶",
	curvearrowright: "↷",
	cuvee: "⋎",
	cuwed: "⋏",
	cwconint: "∲",
	cwint: "∱",
	cylcty: "⌭",
	dArr: "⇓",
	dHar: "⥥",
	dagger: "†",
	daleth: "ℸ",
	darr: "↓",
	dash: "‐",
	dashv: "⊣",
	dbkarow: "⤏",
	dblac: "˝",
	dcaron: "ď",
	dcy: "д",
	dd: "ⅆ",
	ddagger: "‡",
	ddarr: "⇊",
	ddotseq: "⩷",
	deg: "°",
	delta: "δ",
	demptyv: "⦱",
	dfisht: "⥿",
	dfr: "𝔡",
	dharl: "⇃",
	dharr: "⇂",
	diam: "⋄",
	diamond: "⋄",
	diamondsuit: "♦",
	diams: "♦",
	die: "¨",
	digamma: "ϝ",
	disin: "⋲",
	div: "÷",
	divide: "÷",
	divideontimes: "⋇",
	divonx: "⋇",
	djcy: "ђ",
	dlcorn: "⌞",
	dlcrop: "⌍",
	dollar: "$",
	dopf: "𝕕",
	dot: "˙",
	doteq: "≐",
	doteqdot: "≑",
	dotminus: "∸",
	dotplus: "∔",
	dotsquare: "⊡",
	doublebarwedge: "⌆",
	downarrow: "↓",
	downdownarrows: "⇊",
	downharpoonleft: "⇃",
	downharpoonright: "⇂",
	drbkarow: "⤐",
	drcorn: "⌟",
	drcrop: "⌌",
	dscr: "𝒹",
	dscy: "ѕ",
	dsol: "⧶",
	dstrok: "đ",
	dtdot: "⋱",
	dtri: "▿",
	dtrif: "▾",
	duarr: "⇵",
	duhar: "⥯",
	dwangle: "⦦",
	dzcy: "џ",
	dzigrarr: "⟿",
	eDDot: "⩷",
	eDot: "≑",
	eacute: "é",
	easter: "⩮",
	ecaron: "ě",
	ecir: "≖",
	ecirc: "ê",
	ecolon: "≕",
	ecy: "э",
	edot: "ė",
	ee: "ⅇ",
	efDot: "≒",
	efr: "𝔢",
	eg: "⪚",
	egrave: "è",
	egs: "⪖",
	egsdot: "⪘",
	el: "⪙",
	elinters: "⏧",
	ell: "ℓ",
	els: "⪕",
	elsdot: "⪗",
	emacr: "ē",
	empty: "∅",
	emptyset: "∅",
	emptyv: "∅",
	emsp13: " ",
	emsp14: " ",
	emsp: " ",
	eng: "ŋ",
	ensp: " ",
	eogon: "ę",
	eopf: "𝕖",
	epar: "⋕",
	eparsl: "⧣",
	eplus: "⩱",
	epsi: "ε",
	epsilon: "ε",
	epsiv: "ϵ",
	eqcirc: "≖",
	eqcolon: "≕",
	eqsim: "≂",
	eqslantgtr: "⪖",
	eqslantless: "⪕",
	equals: "=",
	equest: "≟",
	equiv: "≡",
	equivDD: "⩸",
	eqvparsl: "⧥",
	erDot: "≓",
	erarr: "⥱",
	escr: "ℯ",
	esdot: "≐",
	esim: "≂",
	eta: "η",
	eth: "ð",
	euml: "ë",
	euro: "€",
	excl: "!",
	exist: "∃",
	expectation: "ℰ",
	exponentiale: "ⅇ",
	fallingdotseq: "≒",
	fcy: "ф",
	female: "♀",
	ffilig: "ﬃ",
	fflig: "ﬀ",
	ffllig: "ﬄ",
	ffr: "𝔣",
	filig: "ﬁ",
	fjlig: "fj",
	flat: "♭",
	fllig: "ﬂ",
	fltns: "▱",
	fnof: "ƒ",
	fopf: "𝕗",
	forall: "∀",
	fork: "⋔",
	forkv: "⫙",
	fpartint: "⨍",
	frac12: "½",
	frac13: "⅓",
	frac14: "¼",
	frac15: "⅕",
	frac16: "⅙",
	frac18: "⅛",
	frac23: "⅔",
	frac25: "⅖",
	frac34: "¾",
	frac35: "⅗",
	frac38: "⅜",
	frac45: "⅘",
	frac56: "⅚",
	frac58: "⅝",
	frac78: "⅞",
	frasl: "⁄",
	frown: "⌢",
	fscr: "𝒻",
	gE: "≧",
	gEl: "⪌",
	gacute: "ǵ",
	gamma: "γ",
	gammad: "ϝ",
	gap: "⪆",
	gbreve: "ğ",
	gcirc: "ĝ",
	gcy: "г",
	gdot: "ġ",
	ge: "≥",
	gel: "⋛",
	geq: "≥",
	geqq: "≧",
	geqslant: "⩾",
	ges: "⩾",
	gescc: "⪩",
	gesdot: "⪀",
	gesdoto: "⪂",
	gesdotol: "⪄",
	gesl: "⋛︀",
	gesles: "⪔",
	gfr: "𝔤",
	gg: "≫",
	ggg: "⋙",
	gimel: "ℷ",
	gjcy: "ѓ",
	gl: "≷",
	glE: "⪒",
	gla: "⪥",
	glj: "⪤",
	gnE: "≩",
	gnap: "⪊",
	gnapprox: "⪊",
	gne: "⪈",
	gneq: "⪈",
	gneqq: "≩",
	gnsim: "⋧",
	gopf: "𝕘",
	grave: "`",
	gscr: "ℊ",
	gsim: "≳",
	gsime: "⪎",
	gsiml: "⪐",
	gt: ">",
	gtcc: "⪧",
	gtcir: "⩺",
	gtdot: "⋗",
	gtlPar: "⦕",
	gtquest: "⩼",
	gtrapprox: "⪆",
	gtrarr: "⥸",
	gtrdot: "⋗",
	gtreqless: "⋛",
	gtreqqless: "⪌",
	gtrless: "≷",
	gtrsim: "≳",
	gvertneqq: "≩︀",
	gvnE: "≩︀",
	hArr: "⇔",
	hairsp: " ",
	half: "½",
	hamilt: "ℋ",
	hardcy: "ъ",
	harr: "↔",
	harrcir: "⥈",
	harrw: "↭",
	hbar: "ℏ",
	hcirc: "ĥ",
	hearts: "♥",
	heartsuit: "♥",
	hellip: "…",
	hercon: "⊹",
	hfr: "𝔥",
	hksearow: "⤥",
	hkswarow: "⤦",
	hoarr: "⇿",
	homtht: "∻",
	hookleftarrow: "↩",
	hookrightarrow: "↪",
	hopf: "𝕙",
	horbar: "―",
	hscr: "𝒽",
	hslash: "ℏ",
	hstrok: "ħ",
	hybull: "⁃",
	hyphen: "‐",
	iacute: "í",
	ic: "⁣",
	icirc: "î",
	icy: "и",
	iecy: "е",
	iexcl: "¡",
	iff: "⇔",
	ifr: "𝔦",
	igrave: "ì",
	ii: "ⅈ",
	iiiint: "⨌",
	iiint: "∭",
	iinfin: "⧜",
	iiota: "℩",
	ijlig: "ĳ",
	imacr: "ī",
	image: "ℑ",
	imagline: "ℐ",
	imagpart: "ℑ",
	imath: "ı",
	imof: "⊷",
	imped: "Ƶ",
	in: "∈",
	incare: "℅",
	infin: "∞",
	infintie: "⧝",
	inodot: "ı",
	int: "∫",
	intcal: "⊺",
	integers: "ℤ",
	intercal: "⊺",
	intlarhk: "⨗",
	intprod: "⨼",
	iocy: "ё",
	iogon: "į",
	iopf: "𝕚",
	iota: "ι",
	iprod: "⨼",
	iquest: "¿",
	iscr: "𝒾",
	isin: "∈",
	isinE: "⋹",
	isindot: "⋵",
	isins: "⋴",
	isinsv: "⋳",
	isinv: "∈",
	it: "⁢",
	itilde: "ĩ",
	iukcy: "і",
	iuml: "ï",
	jcirc: "ĵ",
	jcy: "й",
	jfr: "𝔧",
	jmath: "ȷ",
	jopf: "𝕛",
	jscr: "𝒿",
	jsercy: "ј",
	jukcy: "є",
	kappa: "κ",
	kappav: "ϰ",
	kcedil: "ķ",
	kcy: "к",
	kfr: "𝔨",
	kgreen: "ĸ",
	khcy: "х",
	kjcy: "ќ",
	kopf: "𝕜",
	kscr: "𝓀",
	lAarr: "⇚",
	lArr: "⇐",
	lAtail: "⤛",
	lBarr: "⤎",
	lE: "≦",
	lEg: "⪋",
	lHar: "⥢",
	lacute: "ĺ",
	laemptyv: "⦴",
	lagran: "ℒ",
	lambda: "λ",
	lang: "⟨",
	langd: "⦑",
	langle: "⟨",
	lap: "⪅",
	laquo: "«",
	larr: "←",
	larrb: "⇤",
	larrbfs: "⤟",
	larrfs: "⤝",
	larrhk: "↩",
	larrlp: "↫",
	larrpl: "⤹",
	larrsim: "⥳",
	larrtl: "↢",
	lat: "⪫",
	latail: "⤙",
	late: "⪭",
	lates: "⪭︀",
	lbarr: "⤌",
	lbbrk: "❲",
	lbrace: "{",
	lbrack: "[",
	lbrke: "⦋",
	lbrksld: "⦏",
	lbrkslu: "⦍",
	lcaron: "ľ",
	lcedil: "ļ",
	lceil: "⌈",
	lcub: "{",
	lcy: "л",
	ldca: "⤶",
	ldquo: "“",
	ldquor: "„",
	ldrdhar: "⥧",
	ldrushar: "⥋",
	ldsh: "↲",
	le: "≤",
	leftarrow: "←",
	leftarrowtail: "↢",
	leftharpoondown: "↽",
	leftharpoonup: "↼",
	leftleftarrows: "⇇",
	leftrightarrow: "↔",
	leftrightarrows: "⇆",
	leftrightharpoons: "⇋",
	leftrightsquigarrow: "↭",
	leftthreetimes: "⋋",
	leg: "⋚",
	leq: "≤",
	leqq: "≦",
	leqslant: "⩽",
	les: "⩽",
	lescc: "⪨",
	lesdot: "⩿",
	lesdoto: "⪁",
	lesdotor: "⪃",
	lesg: "⋚︀",
	lesges: "⪓",
	lessapprox: "⪅",
	lessdot: "⋖",
	lesseqgtr: "⋚",
	lesseqqgtr: "⪋",
	lessgtr: "≶",
	lesssim: "≲",
	lfisht: "⥼",
	lfloor: "⌊",
	lfr: "𝔩",
	lg: "≶",
	lgE: "⪑",
	lhard: "↽",
	lharu: "↼",
	lharul: "⥪",
	lhblk: "▄",
	ljcy: "љ",
	ll: "≪",
	llarr: "⇇",
	llcorner: "⌞",
	llhard: "⥫",
	lltri: "◺",
	lmidot: "ŀ",
	lmoust: "⎰",
	lmoustache: "⎰",
	lnE: "≨",
	lnap: "⪉",
	lnapprox: "⪉",
	lne: "⪇",
	lneq: "⪇",
	lneqq: "≨",
	lnsim: "⋦",
	loang: "⟬",
	loarr: "⇽",
	lobrk: "⟦",
	longleftarrow: "⟵",
	longleftrightarrow: "⟷",
	longmapsto: "⟼",
	longrightarrow: "⟶",
	looparrowleft: "↫",
	looparrowright: "↬",
	lopar: "⦅",
	lopf: "𝕝",
	loplus: "⨭",
	lotimes: "⨴",
	lowast: "∗",
	lowbar: "_",
	loz: "◊",
	lozenge: "◊",
	lozf: "⧫",
	lpar: "(",
	lparlt: "⦓",
	lrarr: "⇆",
	lrcorner: "⌟",
	lrhar: "⇋",
	lrhard: "⥭",
	lrm: "‎",
	lrtri: "⊿",
	lsaquo: "‹",
	lscr: "𝓁",
	lsh: "↰",
	lsim: "≲",
	lsime: "⪍",
	lsimg: "⪏",
	lsqb: "[",
	lsquo: "‘",
	lsquor: "‚",
	lstrok: "ł",
	lt: "<",
	ltcc: "⪦",
	ltcir: "⩹",
	ltdot: "⋖",
	lthree: "⋋",
	ltimes: "⋉",
	ltlarr: "⥶",
	ltquest: "⩻",
	ltrPar: "⦖",
	ltri: "◃",
	ltrie: "⊴",
	ltrif: "◂",
	lurdshar: "⥊",
	luruhar: "⥦",
	lvertneqq: "≨︀",
	lvnE: "≨︀",
	mDDot: "∺",
	macr: "¯",
	male: "♂",
	malt: "✠",
	maltese: "✠",
	map: "↦",
	mapsto: "↦",
	mapstodown: "↧",
	mapstoleft: "↤",
	mapstoup: "↥",
	marker: "▮",
	mcomma: "⨩",
	mcy: "м",
	mdash: "—",
	measuredangle: "∡",
	mfr: "𝔪",
	mho: "℧",
	micro: "µ",
	mid: "∣",
	midast: "*",
	midcir: "⫰",
	middot: "·",
	minus: "−",
	minusb: "⊟",
	minusd: "∸",
	minusdu: "⨪",
	mlcp: "⫛",
	mldr: "…",
	mnplus: "∓",
	models: "⊧",
	mopf: "𝕞",
	mp: "∓",
	mscr: "𝓂",
	mstpos: "∾",
	mu: "μ",
	multimap: "⊸",
	mumap: "⊸",
	nGg: "⋙̸",
	nGt: "≫⃒",
	nGtv: "≫̸",
	nLeftarrow: "⇍",
	nLeftrightarrow: "⇎",
	nLl: "⋘̸",
	nLt: "≪⃒",
	nLtv: "≪̸",
	nRightarrow: "⇏",
	nVDash: "⊯",
	nVdash: "⊮",
	nabla: "∇",
	nacute: "ń",
	nang: "∠⃒",
	nap: "≉",
	napE: "⩰̸",
	napid: "≋̸",
	napos: "ŉ",
	napprox: "≉",
	natur: "♮",
	natural: "♮",
	naturals: "ℕ",
	nbsp: "\xA0",
	nbump: "≎̸",
	nbumpe: "≏̸",
	ncap: "⩃",
	ncaron: "ň",
	ncedil: "ņ",
	ncong: "≇",
	ncongdot: "⩭̸",
	ncup: "⩂",
	ncy: "н",
	ndash: "–",
	ne: "≠",
	neArr: "⇗",
	nearhk: "⤤",
	nearr: "↗",
	nearrow: "↗",
	nedot: "≐̸",
	nequiv: "≢",
	nesear: "⤨",
	nesim: "≂̸",
	nexist: "∄",
	nexists: "∄",
	nfr: "𝔫",
	ngE: "≧̸",
	nge: "≱",
	ngeq: "≱",
	ngeqq: "≧̸",
	ngeqslant: "⩾̸",
	nges: "⩾̸",
	ngsim: "≵",
	ngt: "≯",
	ngtr: "≯",
	nhArr: "⇎",
	nharr: "↮",
	nhpar: "⫲",
	ni: "∋",
	nis: "⋼",
	nisd: "⋺",
	niv: "∋",
	njcy: "њ",
	nlArr: "⇍",
	nlE: "≦̸",
	nlarr: "↚",
	nldr: "‥",
	nle: "≰",
	nleftarrow: "↚",
	nleftrightarrow: "↮",
	nleq: "≰",
	nleqq: "≦̸",
	nleqslant: "⩽̸",
	nles: "⩽̸",
	nless: "≮",
	nlsim: "≴",
	nlt: "≮",
	nltri: "⋪",
	nltrie: "⋬",
	nmid: "∤",
	nopf: "𝕟",
	not: "¬",
	notin: "∉",
	notinE: "⋹̸",
	notindot: "⋵̸",
	notinva: "∉",
	notinvb: "⋷",
	notinvc: "⋶",
	notni: "∌",
	notniva: "∌",
	notnivb: "⋾",
	notnivc: "⋽",
	npar: "∦",
	nparallel: "∦",
	nparsl: "⫽⃥",
	npart: "∂̸",
	npolint: "⨔",
	npr: "⊀",
	nprcue: "⋠",
	npre: "⪯̸",
	nprec: "⊀",
	npreceq: "⪯̸",
	nrArr: "⇏",
	nrarr: "↛",
	nrarrc: "⤳̸",
	nrarrw: "↝̸",
	nrightarrow: "↛",
	nrtri: "⋫",
	nrtrie: "⋭",
	nsc: "⊁",
	nsccue: "⋡",
	nsce: "⪰̸",
	nscr: "𝓃",
	nshortmid: "∤",
	nshortparallel: "∦",
	nsim: "≁",
	nsime: "≄",
	nsimeq: "≄",
	nsmid: "∤",
	nspar: "∦",
	nsqsube: "⋢",
	nsqsupe: "⋣",
	nsub: "⊄",
	nsubE: "⫅̸",
	nsube: "⊈",
	nsubset: "⊂⃒",
	nsubseteq: "⊈",
	nsubseteqq: "⫅̸",
	nsucc: "⊁",
	nsucceq: "⪰̸",
	nsup: "⊅",
	nsupE: "⫆̸",
	nsupe: "⊉",
	nsupset: "⊃⃒",
	nsupseteq: "⊉",
	nsupseteqq: "⫆̸",
	ntgl: "≹",
	ntilde: "ñ",
	ntlg: "≸",
	ntriangleleft: "⋪",
	ntrianglelefteq: "⋬",
	ntriangleright: "⋫",
	ntrianglerighteq: "⋭",
	nu: "ν",
	num: "#",
	numero: "№",
	numsp: " ",
	nvDash: "⊭",
	nvHarr: "⤄",
	nvap: "≍⃒",
	nvdash: "⊬",
	nvge: "≥⃒",
	nvgt: ">⃒",
	nvinfin: "⧞",
	nvlArr: "⤂",
	nvle: "≤⃒",
	nvlt: "<⃒",
	nvltrie: "⊴⃒",
	nvrArr: "⤃",
	nvrtrie: "⊵⃒",
	nvsim: "∼⃒",
	nwArr: "⇖",
	nwarhk: "⤣",
	nwarr: "↖",
	nwarrow: "↖",
	nwnear: "⤧",
	oS: "Ⓢ",
	oacute: "ó",
	oast: "⊛",
	ocir: "⊚",
	ocirc: "ô",
	ocy: "о",
	odash: "⊝",
	odblac: "ő",
	odiv: "⨸",
	odot: "⊙",
	odsold: "⦼",
	oelig: "œ",
	ofcir: "⦿",
	ofr: "𝔬",
	ogon: "˛",
	ograve: "ò",
	ogt: "⧁",
	ohbar: "⦵",
	ohm: "Ω",
	oint: "∮",
	olarr: "↺",
	olcir: "⦾",
	olcross: "⦻",
	oline: "‾",
	olt: "⧀",
	omacr: "ō",
	omega: "ω",
	omicron: "ο",
	omid: "⦶",
	ominus: "⊖",
	oopf: "𝕠",
	opar: "⦷",
	operp: "⦹",
	oplus: "⊕",
	or: "∨",
	orarr: "↻",
	ord: "⩝",
	order: "ℴ",
	orderof: "ℴ",
	ordf: "ª",
	ordm: "º",
	origof: "⊶",
	oror: "⩖",
	orslope: "⩗",
	orv: "⩛",
	oscr: "ℴ",
	oslash: "ø",
	osol: "⊘",
	otilde: "õ",
	otimes: "⊗",
	otimesas: "⨶",
	ouml: "ö",
	ovbar: "⌽",
	par: "∥",
	para: "¶",
	parallel: "∥",
	parsim: "⫳",
	parsl: "⫽",
	part: "∂",
	pcy: "п",
	percnt: "%",
	period: ".",
	permil: "‰",
	perp: "⊥",
	pertenk: "‱",
	pfr: "𝔭",
	phi: "φ",
	phiv: "ϕ",
	phmmat: "ℳ",
	phone: "☎",
	pi: "π",
	pitchfork: "⋔",
	piv: "ϖ",
	planck: "ℏ",
	planckh: "ℎ",
	plankv: "ℏ",
	plus: "+",
	plusacir: "⨣",
	plusb: "⊞",
	pluscir: "⨢",
	plusdo: "∔",
	plusdu: "⨥",
	pluse: "⩲",
	plusmn: "±",
	plussim: "⨦",
	plustwo: "⨧",
	pm: "±",
	pointint: "⨕",
	popf: "𝕡",
	pound: "£",
	pr: "≺",
	prE: "⪳",
	prap: "⪷",
	prcue: "≼",
	pre: "⪯",
	prec: "≺",
	precapprox: "⪷",
	preccurlyeq: "≼",
	preceq: "⪯",
	precnapprox: "⪹",
	precneqq: "⪵",
	precnsim: "⋨",
	precsim: "≾",
	prime: "′",
	primes: "ℙ",
	prnE: "⪵",
	prnap: "⪹",
	prnsim: "⋨",
	prod: "∏",
	profalar: "⌮",
	profline: "⌒",
	profsurf: "⌓",
	prop: "∝",
	propto: "∝",
	prsim: "≾",
	prurel: "⊰",
	pscr: "𝓅",
	psi: "ψ",
	puncsp: " ",
	qfr: "𝔮",
	qint: "⨌",
	qopf: "𝕢",
	qprime: "⁗",
	qscr: "𝓆",
	quaternions: "ℍ",
	quatint: "⨖",
	quest: "?",
	questeq: "≟",
	quot: "\"",
	rAarr: "⇛",
	rArr: "⇒",
	rAtail: "⤜",
	rBarr: "⤏",
	rHar: "⥤",
	race: "∽̱",
	racute: "ŕ",
	radic: "√",
	raemptyv: "⦳",
	rang: "⟩",
	rangd: "⦒",
	range: "⦥",
	rangle: "⟩",
	raquo: "»",
	rarr: "→",
	rarrap: "⥵",
	rarrb: "⇥",
	rarrbfs: "⤠",
	rarrc: "⤳",
	rarrfs: "⤞",
	rarrhk: "↪",
	rarrlp: "↬",
	rarrpl: "⥅",
	rarrsim: "⥴",
	rarrtl: "↣",
	rarrw: "↝",
	ratail: "⤚",
	ratio: "∶",
	rationals: "ℚ",
	rbarr: "⤍",
	rbbrk: "❳",
	rbrace: "}",
	rbrack: "]",
	rbrke: "⦌",
	rbrksld: "⦎",
	rbrkslu: "⦐",
	rcaron: "ř",
	rcedil: "ŗ",
	rceil: "⌉",
	rcub: "}",
	rcy: "р",
	rdca: "⤷",
	rdldhar: "⥩",
	rdquo: "”",
	rdquor: "”",
	rdsh: "↳",
	real: "ℜ",
	realine: "ℛ",
	realpart: "ℜ",
	reals: "ℝ",
	rect: "▭",
	reg: "®",
	rfisht: "⥽",
	rfloor: "⌋",
	rfr: "𝔯",
	rhard: "⇁",
	rharu: "⇀",
	rharul: "⥬",
	rho: "ρ",
	rhov: "ϱ",
	rightarrow: "→",
	rightarrowtail: "↣",
	rightharpoondown: "⇁",
	rightharpoonup: "⇀",
	rightleftarrows: "⇄",
	rightleftharpoons: "⇌",
	rightrightarrows: "⇉",
	rightsquigarrow: "↝",
	rightthreetimes: "⋌",
	ring: "˚",
	risingdotseq: "≓",
	rlarr: "⇄",
	rlhar: "⇌",
	rlm: "‏",
	rmoust: "⎱",
	rmoustache: "⎱",
	rnmid: "⫮",
	roang: "⟭",
	roarr: "⇾",
	robrk: "⟧",
	ropar: "⦆",
	ropf: "𝕣",
	roplus: "⨮",
	rotimes: "⨵",
	rpar: ")",
	rpargt: "⦔",
	rppolint: "⨒",
	rrarr: "⇉",
	rsaquo: "›",
	rscr: "𝓇",
	rsh: "↱",
	rsqb: "]",
	rsquo: "’",
	rsquor: "’",
	rthree: "⋌",
	rtimes: "⋊",
	rtri: "▹",
	rtrie: "⊵",
	rtrif: "▸",
	rtriltri: "⧎",
	ruluhar: "⥨",
	rx: "℞",
	sacute: "ś",
	sbquo: "‚",
	sc: "≻",
	scE: "⪴",
	scap: "⪸",
	scaron: "š",
	sccue: "≽",
	sce: "⪰",
	scedil: "ş",
	scirc: "ŝ",
	scnE: "⪶",
	scnap: "⪺",
	scnsim: "⋩",
	scpolint: "⨓",
	scsim: "≿",
	scy: "с",
	sdot: "⋅",
	sdotb: "⊡",
	sdote: "⩦",
	seArr: "⇘",
	searhk: "⤥",
	searr: "↘",
	searrow: "↘",
	sect: "§",
	semi: ";",
	seswar: "⤩",
	setminus: "∖",
	setmn: "∖",
	sext: "✶",
	sfr: "𝔰",
	sfrown: "⌢",
	sharp: "♯",
	shchcy: "щ",
	shcy: "ш",
	shortmid: "∣",
	shortparallel: "∥",
	shy: "­",
	sigma: "σ",
	sigmaf: "ς",
	sigmav: "ς",
	sim: "∼",
	simdot: "⩪",
	sime: "≃",
	simeq: "≃",
	simg: "⪞",
	simgE: "⪠",
	siml: "⪝",
	simlE: "⪟",
	simne: "≆",
	simplus: "⨤",
	simrarr: "⥲",
	slarr: "←",
	smallsetminus: "∖",
	smashp: "⨳",
	smeparsl: "⧤",
	smid: "∣",
	smile: "⌣",
	smt: "⪪",
	smte: "⪬",
	smtes: "⪬︀",
	softcy: "ь",
	sol: "/",
	solb: "⧄",
	solbar: "⌿",
	sopf: "𝕤",
	spades: "♠",
	spadesuit: "♠",
	spar: "∥",
	sqcap: "⊓",
	sqcaps: "⊓︀",
	sqcup: "⊔",
	sqcups: "⊔︀",
	sqsub: "⊏",
	sqsube: "⊑",
	sqsubset: "⊏",
	sqsubseteq: "⊑",
	sqsup: "⊐",
	sqsupe: "⊒",
	sqsupset: "⊐",
	sqsupseteq: "⊒",
	squ: "□",
	square: "□",
	squarf: "▪",
	squf: "▪",
	srarr: "→",
	sscr: "𝓈",
	ssetmn: "∖",
	ssmile: "⌣",
	sstarf: "⋆",
	star: "☆",
	starf: "★",
	straightepsilon: "ϵ",
	straightphi: "ϕ",
	strns: "¯",
	sub: "⊂",
	subE: "⫅",
	subdot: "⪽",
	sube: "⊆",
	subedot: "⫃",
	submult: "⫁",
	subnE: "⫋",
	subne: "⊊",
	subplus: "⪿",
	subrarr: "⥹",
	subset: "⊂",
	subseteq: "⊆",
	subseteqq: "⫅",
	subsetneq: "⊊",
	subsetneqq: "⫋",
	subsim: "⫇",
	subsub: "⫕",
	subsup: "⫓",
	succ: "≻",
	succapprox: "⪸",
	succcurlyeq: "≽",
	succeq: "⪰",
	succnapprox: "⪺",
	succneqq: "⪶",
	succnsim: "⋩",
	succsim: "≿",
	sum: "∑",
	sung: "♪",
	sup1: "¹",
	sup2: "²",
	sup3: "³",
	sup: "⊃",
	supE: "⫆",
	supdot: "⪾",
	supdsub: "⫘",
	supe: "⊇",
	supedot: "⫄",
	suphsol: "⟉",
	suphsub: "⫗",
	suplarr: "⥻",
	supmult: "⫂",
	supnE: "⫌",
	supne: "⊋",
	supplus: "⫀",
	supset: "⊃",
	supseteq: "⊇",
	supseteqq: "⫆",
	supsetneq: "⊋",
	supsetneqq: "⫌",
	supsim: "⫈",
	supsub: "⫔",
	supsup: "⫖",
	swArr: "⇙",
	swarhk: "⤦",
	swarr: "↙",
	swarrow: "↙",
	swnwar: "⤪",
	szlig: "ß",
	target: "⌖",
	tau: "τ",
	tbrk: "⎴",
	tcaron: "ť",
	tcedil: "ţ",
	tcy: "т",
	tdot: "⃛",
	telrec: "⌕",
	tfr: "𝔱",
	there4: "∴",
	therefore: "∴",
	theta: "θ",
	thetasym: "ϑ",
	thetav: "ϑ",
	thickapprox: "≈",
	thicksim: "∼",
	thinsp: " ",
	thkap: "≈",
	thksim: "∼",
	thorn: "þ",
	tilde: "˜",
	times: "×",
	timesb: "⊠",
	timesbar: "⨱",
	timesd: "⨰",
	tint: "∭",
	toea: "⤨",
	top: "⊤",
	topbot: "⌶",
	topcir: "⫱",
	topf: "𝕥",
	topfork: "⫚",
	tosa: "⤩",
	tprime: "‴",
	trade: "™",
	triangle: "▵",
	triangledown: "▿",
	triangleleft: "◃",
	trianglelefteq: "⊴",
	triangleq: "≜",
	triangleright: "▹",
	trianglerighteq: "⊵",
	tridot: "◬",
	trie: "≜",
	triminus: "⨺",
	triplus: "⨹",
	trisb: "⧍",
	tritime: "⨻",
	trpezium: "⏢",
	tscr: "𝓉",
	tscy: "ц",
	tshcy: "ћ",
	tstrok: "ŧ",
	twixt: "≬",
	twoheadleftarrow: "↞",
	twoheadrightarrow: "↠",
	uArr: "⇑",
	uHar: "⥣",
	uacute: "ú",
	uarr: "↑",
	ubrcy: "ў",
	ubreve: "ŭ",
	ucirc: "û",
	ucy: "у",
	udarr: "⇅",
	udblac: "ű",
	udhar: "⥮",
	ufisht: "⥾",
	ufr: "𝔲",
	ugrave: "ù",
	uharl: "↿",
	uharr: "↾",
	uhblk: "▀",
	ulcorn: "⌜",
	ulcorner: "⌜",
	ulcrop: "⌏",
	ultri: "◸",
	umacr: "ū",
	uml: "¨",
	uogon: "ų",
	uopf: "𝕦",
	uparrow: "↑",
	updownarrow: "↕",
	upharpoonleft: "↿",
	upharpoonright: "↾",
	uplus: "⊎",
	upsi: "υ",
	upsih: "ϒ",
	upsilon: "υ",
	upuparrows: "⇈",
	urcorn: "⌝",
	urcorner: "⌝",
	urcrop: "⌎",
	uring: "ů",
	urtri: "◹",
	uscr: "𝓊",
	utdot: "⋰",
	utilde: "ũ",
	utri: "▵",
	utrif: "▴",
	uuarr: "⇈",
	uuml: "ü",
	uwangle: "⦧",
	vArr: "⇕",
	vBar: "⫨",
	vBarv: "⫩",
	vDash: "⊨",
	vangrt: "⦜",
	varepsilon: "ϵ",
	varkappa: "ϰ",
	varnothing: "∅",
	varphi: "ϕ",
	varpi: "ϖ",
	varpropto: "∝",
	varr: "↕",
	varrho: "ϱ",
	varsigma: "ς",
	varsubsetneq: "⊊︀",
	varsubsetneqq: "⫋︀",
	varsupsetneq: "⊋︀",
	varsupsetneqq: "⫌︀",
	vartheta: "ϑ",
	vartriangleleft: "⊲",
	vartriangleright: "⊳",
	vcy: "в",
	vdash: "⊢",
	vee: "∨",
	veebar: "⊻",
	veeeq: "≚",
	vellip: "⋮",
	verbar: "|",
	vert: "|",
	vfr: "𝔳",
	vltri: "⊲",
	vnsub: "⊂⃒",
	vnsup: "⊃⃒",
	vopf: "𝕧",
	vprop: "∝",
	vrtri: "⊳",
	vscr: "𝓋",
	vsubnE: "⫋︀",
	vsubne: "⊊︀",
	vsupnE: "⫌︀",
	vsupne: "⊋︀",
	vzigzag: "⦚",
	wcirc: "ŵ",
	wedbar: "⩟",
	wedge: "∧",
	wedgeq: "≙",
	weierp: "℘",
	wfr: "𝔴",
	wopf: "𝕨",
	wp: "℘",
	wr: "≀",
	wreath: "≀",
	wscr: "𝓌",
	xcap: "⋂",
	xcirc: "◯",
	xcup: "⋃",
	xdtri: "▽",
	xfr: "𝔵",
	xhArr: "⟺",
	xharr: "⟷",
	xi: "ξ",
	xlArr: "⟸",
	xlarr: "⟵",
	xmap: "⟼",
	xnis: "⋻",
	xodot: "⨀",
	xopf: "𝕩",
	xoplus: "⨁",
	xotime: "⨂",
	xrArr: "⟹",
	xrarr: "⟶",
	xscr: "𝓍",
	xsqcup: "⨆",
	xuplus: "⨄",
	xutri: "△",
	xvee: "⋁",
	xwedge: "⋀",
	yacute: "ý",
	yacy: "я",
	ycirc: "ŷ",
	ycy: "ы",
	yen: "¥",
	yfr: "𝔶",
	yicy: "ї",
	yopf: "𝕪",
	yscr: "𝓎",
	yucy: "ю",
	yuml: "ÿ",
	zacute: "ź",
	zcaron: "ž",
	zcy: "з",
	zdot: "ż",
	zeetrf: "ℨ",
	zeta: "ζ",
	zfr: "𝔷",
	zhcy: "ж",
	zigrarr: "⇝",
	zopf: "𝕫",
	zscr: "𝓏",
	zwj: "‍",
	zwnj: "‌"
}, An = {}.hasOwnProperty;
function jn(e) {
	return An.call(kn, e) ? kn[e] : !1;
}
// node_modules/micromark-util-decode-numeric-character-reference/index.js
function Mn(e, t) {
	let n = Number.parseInt(e, t);
	return n < 9 || n === 11 || n > 13 && n < 32 || n > 126 && n < 160 || n > 55295 && n < 57344 || n > 64975 && n < 65008 || (n & 65535) == 65535 || (n & 65535) == 65534 || n > 1114111 ? "�" : String.fromCodePoint(n);
}
// node_modules/micromark/lib/initialize/content.js
var Nn = { tokenize: Pn };
function Pn(e) {
	let t = e.attempt(this.parser.constructs.contentInitial, r, i), n;
	return t;
	function r(n) {
		if (n === null) e.consume(n);
		else return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), I(e, t, "linePrefix");
	}
	function i(t) {
		return e.enter("paragraph"), a(t);
	}
	function a(t) {
		let r = e.enter("chunkText", {
			contentType: "text",
			previous: n
		});
		return n && (n.next = r), n = r, o(t);
	}
	function o(t) {
		if (t === null) e.exit("chunkText"), e.exit("paragraph"), e.consume(t);
		else return P(t) ? (e.consume(t), e.exit("chunkText"), a) : (e.consume(t), o);
	}
}
// node_modules/micromark-util-edit-map/index.js
var Fn = class {
	constructor() {
		this.index = /* @__PURE__ */ new Map(), this.map = [];
	}
	add(e, t, n) {
		In(this, e, t, n, !1);
	}
	addBefore(e, t, n) {
		In(this, e, t, n, !0);
	}
	consume(e) {
		if (this.map.sort(function(e, t) {
			return e[0] - t[0];
		}), this.map.length === 0) return;
		let t = this.map.length, n = [];
		for (; t > 0;) --t, n.push(e.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), e.length = this.map[t][0];
		n.push(e.slice()), e.length = 0;
		let r = n.pop();
		for (; r;) {
			for (let t of r) e.push(t);
			r = n.pop();
		}
		this.map.length = 0, this.index.clear();
	}
};
function In(e, t, n, r, i) {
	if (n === 0 && r.length === 0) return;
	let a = e.index.get(t);
	if (a) {
		a[1] += n, i ? (r.push(...a[2]), a[2] = r) : a[2].push(...r);
		return;
	}
	let o = [
		t,
		n,
		r
	];
	e.map.push(o), e.index.set(t, o);
}
// node_modules/micromark/lib/initialize/document.js
var Ln = { tokenize: zn }, Rn = { tokenize: Bn };
function zn(e) {
	let t = this, n = [], r = 0, i, a, o;
	return s;
	function s(i) {
		if (r < n.length) {
			let a = n[r];
			return t.containerState = a[1], e.attempt(a[0].continuation, c, l)(i);
		}
		return l(i);
	}
	function c(e) {
		if (r++, t.containerState._closeFlow) {
			t.containerState._closeFlow = void 0, i && v();
			let n = t.events.length, a = n, o;
			for (; a--;) if (t.events[a][0] === "exit" && t.events[a][1].type === "chunkFlow") {
				o = t.events[a][1].end;
				break;
			}
			_(r);
			let s = n;
			for (; s < t.events.length;) t.events[s][1].end = { ...o }, s++;
			let c = new Fn();
			return c.add(a + 1, 0, t.events.slice(n)), c.add(n, s - n, []), c.consume(t.events), l(e);
		}
		return s(e);
	}
	function l(a) {
		if (r === n.length) {
			if (!i) return f(a);
			if (i.currentConstruct && i.currentConstruct.concrete) return m(a);
			t.interrupt = !(!i.currentConstruct || i._gfmTableDynamicInterruptHack);
		}
		return t.containerState = {}, e.check(Rn, u, d)(a);
	}
	function u(e) {
		return i && v(), _(r), f(e);
	}
	function d(e) {
		return t.parser.lazy[t.now().line] = r !== n.length, o = t.now().offset, m(e);
	}
	function f(n) {
		return t.containerState = {}, e.attempt(Rn, p, m)(n);
	}
	function p(e) {
		return r++, n.push([t.currentConstruct, t.containerState]), f(e);
	}
	function m(n) {
		if (n === null) i && v(), _(0), e.consume(n);
		else return i ||= t.parser.flow(t.now()), e.enter("chunkFlow", {
			_tokenizer: i,
			contentType: "flow",
			previous: a
		}), h(n);
	}
	function h(n) {
		if (n === null) g(e.exit("chunkFlow"), !0), _(0), e.consume(n);
		else return P(n) ? (e.consume(n), g(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, s) : (e.consume(n), h);
	}
	function g(e, n) {
		let s = t.sliceStream(e);
		if (n && s.push(null), e.previous = a, a && (a.next = e), a = e, i.defineSkip(e.start), i.write(s), t.parser.lazy[e.start.line]) {
			let e = i.events.length;
			for (; e--;) if (i.events[e][1].start.offset < o && (!i.events[e][1].end || i.events[e][1].end.offset > o)) return;
			let n = t.events.length, a = n, s, c;
			for (; a--;) if (t.events[a][0] === "exit" && t.events[a][1].type === "chunkFlow") {
				if (s) {
					c = t.events[a][1].end;
					break;
				}
				s = !0;
			}
			for (_(r), e = n; e < t.events.length;) t.events[e][1].end = { ...c }, e++;
			let l = new Fn();
			l.add(a + 1, 0, t.events.slice(n)), l.add(n, e - n, []), l.consume(t.events);
		}
	}
	function _(r) {
		let i = n.length;
		for (; i-- > r;) {
			let r = n[i];
			t.containerState = r[1], r[0].exit.call(t, e);
		}
		n.length = r;
	}
	function v() {
		i.write([null]), a = void 0, i = void 0, t.containerState._closeFlow = void 0;
	}
}
function Bn(e, t, n) {
	return I(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
// node_modules/micromark-core-commonmark/lib/attention.js
var Vn = {
	name: "attention",
	resolveAll: Hn,
	tokenize: Un
};
function Hn(e, t) {
	let n = -1, r;
	for (; ++n < e.length;) if (e[n][0] === "enter" && e[n][1].type === "attentionSequence" && e[n][1]._close) {
		let i = n;
		for (; i--;) if (e[i][0] === "exit" && e[i][1].type === "attentionSequence" && e[i][1]._open && t.sliceSerialize(e[i][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
			if ((e[i][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[i][1].end.offset - e[i][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3)) continue;
			let a = e[i][1].end.offset - e[i][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1, o = { ...e[i][1].end }, s = { ...e[n][1].start };
			Wn(o, -a), Wn(s, a);
			let c = {
				type: a > 1 ? "strongSequence" : "emphasisSequence",
				start: o,
				end: { ...e[i][1].end }
			}, l = {
				type: a > 1 ? "strongSequence" : "emphasisSequence",
				start: { ...e[n][1].start },
				end: s
			}, u = {
				type: a > 1 ? "strongText" : "emphasisText",
				start: { ...e[i][1].end },
				end: { ...e[n][1].start }
			}, d = {
				type: a > 1 ? "strong" : "emphasis",
				start: { ...c.start },
				end: { ...l.end }
			};
			e[i][1].end = { ...c.start }, e[n][1].start = { ...l.end }, r = [], e[i][1].end.offset - e[i][1].start.offset && (r = B(r, [[
				"enter",
				e[i][1],
				t
			], [
				"exit",
				e[i][1],
				t
			]])), r = B(r, [
				[
					"enter",
					d,
					t
				],
				[
					"enter",
					c,
					t
				],
				[
					"exit",
					c,
					t
				],
				[
					"enter",
					u,
					t
				]
			]), r = B(r, ue(t.parser.constructs.insideSpan.null, e.slice(i + 1, n), t)), r = B(r, [
				[
					"exit",
					u,
					t
				],
				[
					"enter",
					l,
					t
				],
				[
					"exit",
					l,
					t
				],
				[
					"exit",
					d,
					t
				]
			]);
			let f = 0;
			e[n][1].end.offset - e[n][1].start.offset && (f = 2, r = B(r, [[
				"enter",
				e[n][1],
				t
			], [
				"exit",
				e[n][1],
				t
			]])), fe(e, i - 1, n - i + 3, r), n = i + r.length - f - 2;
			break;
		}
	}
	for (n = -1; ++n < e.length;) e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
	return e;
}
function Un(e, t) {
	let n = this.parser.constructs.attentionMarkers.null, r = this.previous, i = le(r), a;
	return o;
	function o(t) {
		return a = t, e.enter("attentionSequence"), s(t);
	}
	function s(o) {
		if (o === a) return e.consume(o), s;
		let c = e.exit("attentionSequence"), l = le(o), u = !l || l === 2 && i || n.includes(o) && o !== 42 && o !== 95, d = !i || i === 2 && l || n.includes(r) && r !== 42 && r !== 95;
		return c._open = !!(a === 42 ? u : u && (i || !d)), c._close = !!(a === 42 ? d : d && (l || !u)), t(o);
	}
}
function Wn(e, t) {
	e.column += t, e.offset += t, e._bufferIndex += t;
}
// node_modules/micromark-core-commonmark/lib/autolink.js
var Gn = {
	name: "autolink",
	tokenize: Kn
};
function Kn(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(t), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), a;
	}
	function a(t) {
		return M(t) ? (e.consume(t), o) : t === 64 ? n(t) : l(t);
	}
	function o(e) {
		return e === 43 || e === 45 || e === 46 || U(e) ? (r = 1, s(e)) : l(e);
	}
	function s(t) {
		return t === 58 ? (e.consume(t), r = 0, c) : (t === 43 || t === 45 || t === 46 || U(t)) && r++ < 32 ? (e.consume(t), s) : (r = 0, l(t));
	}
	function c(r) {
		return r === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(r), e.exit("autolinkMarker"), e.exit("autolink"), t) : r === null || r === 32 || r === 60 || ge(r) ? n(r) : (e.consume(r), c);
	}
	function l(t) {
		return t === 64 ? (e.consume(t), u) : F(t) ? (e.consume(t), l) : n(t);
	}
	function u(e) {
		return U(e) ? d(e) : n(e);
	}
	function d(n) {
		return n === 46 ? (e.consume(n), r = 0, u) : n === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(n), e.exit("autolinkMarker"), e.exit("autolink"), t) : f(n);
	}
	function f(t) {
		if ((t === 45 || U(t)) && r++ < 63) {
			let n = t === 45 ? f : d;
			return e.consume(t), n;
		}
		return n(t);
	}
}
// node_modules/micromark-core-commonmark/lib/block-quote.js
var qn = {
	continuation: { tokenize: Yn },
	exit: Xn,
	name: "blockQuote",
	tokenize: Jn
};
function Jn(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		if (t === 62) {
			let n = r.containerState;
			return n.open ||= (e.enter("blockQuote", { _container: !0 }), !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(t), e.exit("blockQuoteMarker"), a;
		}
		return n(t);
	}
	function a(n) {
		return W(n) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(n), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(n));
	}
}
function Yn(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return W(t) ? I(e, a, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : a(t);
	}
	function a(r) {
		return e.attempt(qn, t, n)(r);
	}
}
function Xn(e) {
	e.exit("blockQuote");
}
// node_modules/micromark-core-commonmark/lib/character-escape.js
var Zn = {
	name: "characterEscape",
	tokenize: Qn
};
function Qn(e, t, n) {
	return r;
	function r(t) {
		return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(t), e.exit("escapeMarker"), i;
	}
	function i(r) {
		return N(r) ? (e.enter("characterEscapeValue"), e.consume(r), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/character-reference.js
var $n = {
	name: "characterReference",
	tokenize: er
};
function er(e, t, n) {
	let r = this, i = 0, a, o;
	return s;
	function s(t) {
		return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(t), e.exit("characterReferenceMarker"), c;
	}
	function c(t) {
		return t === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(t), e.exit("characterReferenceMarkerNumeric"), l) : (e.enter("characterReferenceValue"), a = 31, o = U, u(t));
	}
	function l(t) {
		return t === 88 || t === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(t), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), a = 6, o = de, u) : (e.enter("characterReferenceValue"), a = 7, o = _e, u(t));
	}
	function u(s) {
		if (s === 59 && i) {
			let i = e.exit("characterReferenceValue");
			return o === U && !jn(r.sliceSerialize(i)) ? n(s) : (e.enter("characterReferenceMarker"), e.consume(s), e.exit("characterReferenceMarker"), e.exit("characterReference"), t);
		}
		return o(s) && i++ < a ? (e.consume(s), u) : n(s);
	}
}
// node_modules/micromark-core-commonmark/lib/partial-non-lazy-continuation.js
var tr = {
	partial: !0,
	tokenize: nr
};
function nr(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return t === null ? n(t) : (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), a);
	}
	function a(e) {
		return r.parser.lazy[r.now().line] ? n(e) : t(e);
	}
}
// node_modules/micromark-core-commonmark/lib/code-fenced.js
var rr = {
	concrete: !0,
	name: "codeFenced",
	tokenize: ir
};
function ir(e, t, n) {
	let r = this, i = {
		partial: !0,
		tokenize: x
	}, a = 0, o = 0, s;
	return c;
	function c(e) {
		return l(e);
	}
	function l(t) {
		let n = r.events[r.events.length - 1];
		return a = n && n[1].type === "linePrefix" ? n[2].sliceSerialize(n[1], !0).length : 0, s = t, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), u(t);
	}
	function u(t) {
		return t === s ? (o++, e.consume(t), u) : o < 3 ? n(t) : (e.exit("codeFencedFenceSequence"), W(t) ? I(e, d, "whitespace")(t) : d(t));
	}
	function d(n) {
		return n === null || P(n) ? (e.exit("codeFencedFence"), r.interrupt ? t(n) : e.check(tr, h, b)(n)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", { contentType: "string" }), f(n));
	}
	function f(t) {
		return t === null || P(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), d(t)) : W(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), I(e, p, "whitespace")(t)) : t === 96 && t === s ? n(t) : (e.consume(t), f);
	}
	function p(t) {
		return t === null || P(t) ? d(t) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", { contentType: "string" }), m(t));
	}
	function m(t) {
		return t === null || P(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), d(t)) : t === 96 && t === s ? n(t) : (e.consume(t), m);
	}
	function h(t) {
		return e.attempt(i, b, g)(t);
	}
	function g(t) {
		return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), _;
	}
	function _(t) {
		return a > 0 && W(t) ? I(e, v, "linePrefix", a + 1)(t) : v(t);
	}
	function v(t) {
		return t === null || P(t) ? e.check(tr, h, b)(t) : (e.enter("codeFlowValue"), y(t));
	}
	function y(t) {
		return t === null || P(t) ? (e.exit("codeFlowValue"), v(t)) : (e.consume(t), y);
	}
	function b(n) {
		return e.exit("codeFenced"), t(n);
	}
	function x(e, t, n) {
		let i = 0;
		return a;
		function a(t) {
			return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), c;
		}
		function c(t) {
			return e.enter("codeFencedFence"), W(t) ? I(e, l, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : l(t);
		}
		function l(t) {
			return t === s ? (e.enter("codeFencedFenceSequence"), u(t)) : n(t);
		}
		function u(t) {
			return t === s ? (i++, e.consume(t), u) : i >= o ? (e.exit("codeFencedFenceSequence"), W(t) ? I(e, d, "whitespace")(t) : d(t)) : n(t);
		}
		function d(r) {
			return r === null || P(r) ? (e.exit("codeFencedFence"), t(r)) : n(r);
		}
	}
}
// node_modules/micromark-core-commonmark/lib/code-indented.js
var ar = {
	name: "codeIndented",
	tokenize: sr
}, or = {
	partial: !0,
	tokenize: cr
};
function sr(e, t, n) {
	return r;
	function r(t) {
		return e.enter("codeIndented"), Oe(e, i, n, "linePrefix", 4, 4)(t);
	}
	function i(t) {
		return t === null ? o(t) : P(t) ? e.attempt(or, i, o)(t) : (e.enter("codeFlowValue"), a(t));
	}
	function a(t) {
		return t === null || P(t) ? (e.exit("codeFlowValue"), i(t)) : (e.consume(t), a);
	}
	function o(n) {
		return e.exit("codeIndented"), t(n);
	}
}
function cr(e, t, n) {
	let r = this;
	return i;
	function i(o) {
		return r.parser.lazy[r.now().line] ? n(o) : P(o) ? (e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), i) : Oe(e, t, a, "linePrefix", 4, 4)(o);
	}
	function a(e) {
		return P(e) ? i(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/code-text.js
var lr = {
	name: "codeText",
	previous: dr,
	resolve: ur,
	tokenize: fr
};
function ur(e) {
	let t = e.length - 4, n = 3, r, i;
	if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
		for (r = n; ++r < t;) if (e[r][1].type === "codeTextData") {
			e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
			break;
		}
	}
	for (r = n - 1, t++; ++r <= t;) i === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (i = r) : (r === t || e[r][1].type === "lineEnding") && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
	return e;
}
function dr(e) {
	return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function fr(e, t, n) {
	let r = 0, i, a;
	return o;
	function o(t) {
		return e.enter("codeText"), e.enter("codeTextSequence"), s(t);
	}
	function s(t) {
		return t === 96 ? (e.consume(t), r++, s) : (e.exit("codeTextSequence"), c(t));
	}
	function c(t) {
		return t === null ? n(t) : t === 32 ? (e.enter("space"), e.consume(t), e.exit("space"), c) : t === 96 ? (a = e.enter("codeTextSequence"), i = 0, u(t)) : P(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), c) : (e.enter("codeTextData"), l(t));
	}
	function l(t) {
		return t === null || t === 32 || t === 96 || P(t) ? (e.exit("codeTextData"), c(t)) : (e.consume(t), l);
	}
	function u(n) {
		return n === 96 ? (e.consume(n), i++, u) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(n)) : (a.type = "codeTextData", l(n));
	}
}
// node_modules/micromark-util-subtokenize/lib/splice-buffer.js
var pr = class {
	constructor(e) {
		this.left = e ? [...e] : [], this.right = [];
	}
	get(e) {
		if (e < 0 || e >= this.left.length + this.right.length) throw RangeError("Cannot access index `" + e + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
		return e < this.left.length ? this.left[e] : this.right[this.right.length - e + this.left.length - 1];
	}
	get length() {
		return this.left.length + this.right.length;
	}
	shift() {
		return this.setCursor(0), this.right.pop();
	}
	slice(e, t) {
		let n = t ?? Infinity;
		return n < this.left.length ? this.left.slice(e, n) : e > this.left.length ? this.right.slice(this.right.length - n + this.left.length, this.right.length - e + this.left.length).reverse() : this.left.slice(e).concat(this.right.slice(this.right.length - n + this.left.length).reverse());
	}
	splice(e, t, n) {
		let r = t || 0;
		this.setCursor(Math.trunc(e));
		let i = this.right.splice(this.right.length - r, Infinity);
		return n && mr(this.left, n), i.reverse();
	}
	pop() {
		return this.setCursor(Infinity), this.left.pop();
	}
	push(e) {
		this.setCursor(Infinity), this.left.push(e);
	}
	pushMany(e) {
		this.setCursor(Infinity), mr(this.left, e);
	}
	unshift(e) {
		this.setCursor(0), this.right.push(e);
	}
	unshiftMany(e) {
		this.setCursor(0), mr(this.right, e.reverse());
	}
	setCursor(e) {
		if (!(e === this.left.length || e > this.left.length && this.right.length === 0 || e < 0 && this.left.length === 0)) {
			if (e < this.left.length) {
				let t = this.left.splice(e, Infinity);
				mr(this.right, t.reverse());
			} else {
				let t = this.right.splice(this.left.length + this.right.length - e, Infinity);
				mr(this.left, t.reverse());
			}
		}
	}
};
function mr(e, t) {
	let n = 0;
	if (t.length < 1e4) e.push(...t);
	else for (; n < t.length;) e.push(...t.slice(n, n + 1e4)), n += 1e4;
}
// node_modules/micromark-util-subtokenize/index.js
function hr(e) {
	let t = {}, n = -1, r, i, a, o, s, c, l, u = new pr(e);
	for (; ++n < u.length;) {
		for (; n in t;) n = t[n];
		if (r = u.get(n), n && r[1].type === "chunkFlow" && u.get(n - 1)[1].type === "listItemPrefix" && (c = r[1]._tokenizer.events, a = 0, a < c.length && c[a][1].type === "lineEndingBlank" && (a += 2), a < c.length && c[a][1].type === "content")) for (; ++a < c.length && c[a][1].type !== "content";) c[a][1].type === "chunkText" && (c[a][1]._isInFirstContentOfListItem = !0, a++);
		if (r[0] === "enter") r[1].contentType && (Object.assign(t, gr(u, n)), n = t[n], l = !0);
		else if (r[1]._container) {
			for (a = n, i = void 0; a--;) if (o = u.get(a), o[1].type === "lineEnding" || o[1].type === "lineEndingBlank") o[0] === "enter" && (i && (u.get(i)[1].type = "lineEndingBlank"), o[1].type = "lineEnding", i = a);
			else if (o[1].type !== "linePrefix" && o[1].type !== "listItemIndent") break;
			i && (r[1].end = { ...u.get(i)[1].start }, s = u.slice(i, n), s.unshift(r), u.splice(i, n - i + 1, s));
		}
	}
	return fe(e, 0, Infinity, u.slice(0)), !l;
}
function gr(e, t) {
	let n = e.get(t)[1], r = e.get(t)[2], i = t - 1, a = [], o = n._tokenizer;
	o || (o = r.parser[n.contentType](n.start), n._contentTypeTextTrailing && (o._contentTypeTextTrailing = !0));
	let s = o.events, c = [], l = {}, u, d, f = -1, p = n, m = 0, h = 0, g = [h];
	for (; p;) {
		for (; e.get(++i)[1] !== p;);
		a.push(i), p._tokenizer || (u = r.sliceStream(p), p.next || u.push(null), d && o.defineSkip(p.start), p._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = !0), o.write(u), p._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = void 0)), d = p, p = p.next;
	}
	for (p = n; ++f < s.length;) s[f][0] === "exit" && s[f - 1][0] === "enter" && s[f][1].type === s[f - 1][1].type && s[f][1].start.line !== s[f][1].end.line && (h = f + 1, g.push(h), p._tokenizer = void 0, p.previous = void 0, p = p.next);
	for (o.events = [], p ? (p._tokenizer = void 0, p.previous = void 0) : g.pop(), f = g.length; f--;) {
		let t = s.slice(g[f], g[f + 1]), n = a.pop();
		c.push([n, n + t.length - 1]), e.splice(n, 2, t);
	}
	for (c.reverse(), f = -1; ++f < c.length;) l[m + c[f][0]] = m + c[f][1], m += c[f][1] - c[f][0] - 1;
	return l;
}
// node_modules/micromark-core-commonmark/lib/content.js
var _r = {
	resolve: yr,
	tokenize: br
}, vr = {
	partial: !0,
	tokenize: xr
};
function yr(e) {
	return hr(e), e;
}
function br(e, t) {
	let n;
	return r;
	function r(t) {
		return e.enter("content"), n = e.enter("chunkContent", { contentType: "content" }), i(t);
	}
	function i(t) {
		return t === null ? a(t) : P(t) ? e.check(vr, o, a)(t) : (e.consume(t), i);
	}
	function a(n) {
		return e.exit("chunkContent"), e.exit("content"), t(n);
	}
	function o(t) {
		return e.consume(t), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
			contentType: "content",
			previous: n
		}), n = n.next, i;
	}
}
function xr(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), I(e, a, "linePrefix");
	}
	function a(i) {
		if (i === null || P(i)) return n(i);
		let a = r.events[r.events.length - 1];
		return !r.parser.constructs.disable.null.includes("codeIndented") && a && a[1].type === "linePrefix" && a[2].sliceSerialize(a[1], !0).length >= 4 ? t(i) : e.interrupt(r.parser.constructs.flow, n, t)(i);
	}
}
// node_modules/micromark-factory-destination/index.js
function Sr(e, t, n, r, i, a, o, s, c) {
	let l = c || Infinity, u = 0;
	return d;
	function d(t) {
		return t === 60 ? (e.enter(r), e.enter(i), e.enter(a), e.consume(t), e.exit(a), f) : t === null || t === 32 || t === 41 || ge(t) ? n(t) : (e.enter(r), e.enter(o), e.enter(s), e.enter("chunkString", { contentType: "string" }), h(t));
	}
	function f(n) {
		return n === 62 ? (e.enter(a), e.consume(n), e.exit(a), e.exit(i), e.exit(r), t) : (e.enter(s), e.enter("chunkString", { contentType: "string" }), p(n));
	}
	function p(t) {
		return t === 62 ? (e.exit("chunkString"), e.exit(s), f(t)) : t === null || t === 60 || P(t) ? n(t) : (e.consume(t), t === 92 ? m : p);
	}
	function m(t) {
		return t === 60 || t === 62 || t === 92 ? (e.consume(t), p) : p(t);
	}
	function h(i) {
		return !u && (i === null || i === 41 || R(i)) ? (e.exit("chunkString"), e.exit(s), e.exit(o), e.exit(r), t(i)) : u < l && i === 40 ? (e.consume(i), u++, h) : i === 41 ? (e.consume(i), u--, h) : i === null || i === 32 || i === 40 || ge(i) ? n(i) : (e.consume(i), i === 92 ? g : h);
	}
	function g(t) {
		return t === 40 || t === 41 || t === 92 ? (e.consume(t), h) : h(t);
	}
}
// node_modules/micromark-factory-label/index.js
function Cr(e, t, n, r, i, a) {
	let o = this, s = 0, c;
	return l;
	function l(t) {
		return e.enter(r), e.enter(i), e.consume(t), e.exit(i), e.enter(a), u;
	}
	function u(l) {
		return s > 999 || l === null || l === 91 || l === 93 && !c || 
		/* c8 ignore next 3 */
		l === 94 && !s && "_hiddenFootnoteSupport" in o.parser.constructs ? n(l) : l === 93 ? (e.exit(a), e.enter(i), e.consume(l), e.exit(i), e.exit(r), t) : P(l) ? (e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), u) : (e.enter("chunkString", { contentType: "string" }), d(l));
	}
	function d(t) {
		return t === null || t === 91 || t === 93 || P(t) || s++ > 999 ? (e.exit("chunkString"), u(t)) : (e.consume(t), c ||= !W(t), t === 92 ? f : d);
	}
	function f(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), s++, d) : d(t);
	}
}
// node_modules/micromark-factory-title/index.js
function wr(e, t, n, r, i, a) {
	let o;
	return s;
	function s(t) {
		return t === 34 || t === 39 || t === 40 ? (e.enter(r), e.enter(i), e.consume(t), e.exit(i), o = t === 40 ? 41 : t, c) : n(t);
	}
	function c(n) {
		return n === o ? (e.enter(i), e.consume(n), e.exit(i), e.exit(r), t) : (e.enter(a), l(n));
	}
	function l(t) {
		return t === o ? (e.exit(a), c(o)) : t === null ? n(t) : P(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), I(e, l, "linePrefix")) : (e.enter("chunkString", { contentType: "string" }), u(t));
	}
	function u(t) {
		return t === o || t === null || P(t) ? (e.exit("chunkString"), l(t)) : (e.consume(t), t === 92 ? d : u);
	}
	function d(t) {
		return t === o || t === 92 ? (e.consume(t), u) : u(t);
	}
}
// node_modules/micromark-factory-whitespace/index.js
function Tr(e, t) {
	let n;
	return r;
	function r(i) {
		return P(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), n = !0, r) : W(i) ? I(e, r, n ? "linePrefix" : "lineSuffix")(i) : t(i);
	}
}
// node_modules/micromark-core-commonmark/lib/definition.js
var Er = {
	name: "definition",
	tokenize: Or
}, Dr = {
	partial: !0,
	tokenize: kr
};
function Or(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("definition"), o(t);
	}
	function o(t) {
		return Cr.call(r, e, s, n, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(t);
	}
	function s(t) {
		return i = pe(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), t === 58 ? (e.enter("definitionMarker"), e.consume(t), e.exit("definitionMarker"), c) : n(t);
	}
	function c(t) {
		return R(t) ? Tr(e, l)(t) : l(t);
	}
	function l(t) {
		return Sr(e, u, n, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString")(t);
	}
	function u(t) {
		return e.attempt(Dr, d, d)(t);
	}
	function d(t) {
		return W(t) ? I(e, f, "whitespace")(t) : f(t);
	}
	function f(a) {
		return a === null || P(a) ? (e.exit("definition"), r.parser.defined.push(i), t(a)) : n(a);
	}
}
function kr(e, t, n) {
	return r;
	function r(t) {
		return R(t) ? Tr(e, i)(t) : n(t);
	}
	function i(t) {
		return wr(e, a, n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(t);
	}
	function a(t) {
		return W(t) ? I(e, o, "whitespace")(t) : o(t);
	}
	function o(e) {
		return e === null || P(e) ? t(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/hard-break-escape.js
var Ar = {
	name: "hardBreakEscape",
	tokenize: jr
};
function jr(e, t, n) {
	return r;
	function r(t) {
		return e.enter("hardBreakEscape"), e.consume(t), i;
	}
	function i(r) {
		return P(r) ? (e.exit("hardBreakEscape"), t(r)) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/heading-atx.js
var Mr = {
	name: "headingAtx",
	resolve: Nr,
	tokenize: Pr
};
function Nr(e, t) {
	let n = e.length - 2, r = 3;
	if (e[r][1].type === "whitespace" && (r += 2), n - 2 > r && e[n][1].type === "whitespace" && (n -= 2), e[n][1].type === "atxHeadingSequence" && (r === n - 1 || n - 4 > r && e[n - 2][1].type === "whitespace") && (n -= r + 1 === n ? 2 : 4), n > r) {
		let i = {
			type: "atxHeadingText",
			start: e[r][1].start,
			end: e[n][1].end
		}, a = {
			type: "chunkText",
			start: e[r][1].start,
			end: e[n][1].end,
			contentType: "text"
		};
		fe(e, r, n - r + 1, [
			[
				"enter",
				i,
				t
			],
			[
				"enter",
				a,
				t
			],
			[
				"exit",
				a,
				t
			],
			[
				"exit",
				i,
				t
			]
		]);
	}
	return e;
}
function Pr(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return e.enter("atxHeading"), a(t);
	}
	function a(t) {
		return e.enter("atxHeadingSequence"), o(t);
	}
	function o(t) {
		return t === 35 && r++ < 6 ? (e.consume(t), o) : t === null || R(t) ? (e.exit("atxHeadingSequence"), s(t)) : n(t);
	}
	function s(n) {
		return n === 35 ? (e.enter("atxHeadingSequence"), c(n)) : n === null || P(n) ? (e.exit("atxHeading"), t(n)) : W(n) ? I(e, s, "whitespace")(n) : (e.enter("atxHeadingText"), l(n));
	}
	function c(t) {
		return t === 35 ? (e.consume(t), c) : (e.exit("atxHeadingSequence"), s(t));
	}
	function l(t) {
		return t === null || t === 35 || R(t) ? (e.exit("atxHeadingText"), s(t)) : (e.consume(t), l);
	}
}
// node_modules/micromark-util-html-tag-name/index.js
var Fr = /* @__PURE__ */ "address.article.aside.base.basefont.blockquote.body.caption.center.col.colgroup.dd.details.dialog.dir.div.dl.dt.fieldset.figcaption.figure.footer.form.frame.frameset.h1.h2.h3.h4.h5.h6.head.header.hr.html.iframe.legend.li.link.main.menu.menuitem.nav.noframes.ol.optgroup.option.p.param.search.section.summary.table.tbody.td.tfoot.th.thead.title.tr.track.ul".split("."), Ir = [
	"pre",
	"script",
	"style",
	"textarea"
], Lr = {
	concrete: !0,
	name: "htmlFlow",
	resolveTo: zr,
	tokenize: Br
}, Rr = {
	partial: !0,
	tokenize: Vr
};
function zr(e) {
	let t = e.length;
	for (; t-- && (e[t][0] !== "enter" || e[t][1].type !== "htmlFlow"););
	return t > 1 && e[t - 2][1].type === "linePrefix" && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e;
}
function Br(e, t, n) {
	let r = this, i, a, o, s, c;
	return l;
	function l(e) {
		return u(e);
	}
	function u(t) {
		return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(t), d;
	}
	function d(s) {
		return s === 33 ? (e.consume(s), f) : s === 47 ? (e.consume(s), a = !0, h) : s === 63 ? (e.consume(s), i = 3, r.interrupt ? t : ae) : M(s) ? (e.consume(s), o = String.fromCharCode(s), g) : n(s);
	}
	function f(a) {
		return a === 45 ? (e.consume(a), i = 2, p) : a === 91 ? (e.consume(a), i = 5, s = 0, m) : M(a) ? (e.consume(a), i = 4, r.interrupt ? t : ae) : n(a);
	}
	function p(i) {
		return i === 45 ? (e.consume(i), r.interrupt ? t : ae) : n(i);
	}
	function m(i) {
		return i === "CDATA[".charCodeAt(s++) ? (e.consume(i), s === 6 ? r.interrupt ? t : O : m) : n(i);
	}
	function h(t) {
		return M(t) ? (e.consume(t), o = String.fromCharCode(t), g) : n(t);
	}
	function g(s) {
		if (s === null || s === 47 || s === 62 || R(s)) {
			let c = s === 47, l = o.toLowerCase();
			return !c && !a && Ir.includes(l) ? (i = 1, r.interrupt ? t(s) : O(s)) : Fr.includes(o.toLowerCase()) ? (i = 6, c ? (e.consume(s), _) : r.interrupt ? t(s) : O(s)) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(s) : a ? v(s) : y(s));
		}
		return s === 45 || U(s) ? (e.consume(s), o += String.fromCharCode(s), g) : n(s);
	}
	function _(i) {
		return i === 62 ? (e.consume(i), r.interrupt ? t : O) : n(i);
	}
	function v(t) {
		return W(t) ? (e.consume(t), v) : E(t);
	}
	function y(t) {
		return t === 47 ? (e.consume(t), E) : t === 58 || t === 95 || M(t) ? (e.consume(t), b) : W(t) ? (e.consume(t), y) : E(t);
	}
	function b(t) {
		return t === 45 || t === 46 || t === 58 || t === 95 || U(t) ? (e.consume(t), b) : x(t);
	}
	function x(t) {
		return t === 61 ? (e.consume(t), S) : W(t) ? (e.consume(t), x) : y(t);
	}
	function S(t) {
		return t === null || t === 60 || t === 61 || t === 62 || t === 96 ? n(t) : t === 34 || t === 39 ? (e.consume(t), c = t, C) : W(t) ? (e.consume(t), S) : w(t);
	}
	function C(t) {
		return t === c ? (e.consume(t), c = null, T) : t === null || P(t) ? n(t) : (e.consume(t), C);
	}
	function w(t) {
		return t === null || t === 34 || t === 39 || t === 47 || t === 60 || t === 61 || t === 62 || t === 96 || R(t) ? x(t) : (e.consume(t), w);
	}
	function T(e) {
		return e === 47 || e === 62 || W(e) ? y(e) : n(e);
	}
	function E(t) {
		return t === 62 ? (e.consume(t), D) : n(t);
	}
	function D(t) {
		return t === null || P(t) ? O(t) : W(t) ? (e.consume(t), D) : n(t);
	}
	function O(t) {
		return t === 45 && i === 2 ? (e.consume(t), re) : t === 60 && i === 1 ? (e.consume(t), k) : t === 62 && i === 4 ? (e.consume(t), oe) : t === 63 && i === 3 ? (e.consume(t), ae) : t === 93 && i === 5 ? (e.consume(t), ie) : P(t) && (i === 6 || i === 7) ? (e.exit("htmlFlowData"), e.check(Rr, se, ee)(t)) : t === null || P(t) ? (e.exit("htmlFlowData"), ee(t)) : (e.consume(t), O);
	}
	function ee(t) {
		return e.check(tr, te, se)(t);
	}
	function te(t) {
		return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), ne;
	}
	function ne(t) {
		return t === null || P(t) ? ee(t) : (e.enter("htmlFlowData"), O(t));
	}
	function re(t) {
		return t === 45 ? (e.consume(t), ae) : O(t);
	}
	function k(t) {
		return t === 47 ? (e.consume(t), o = "", A) : O(t);
	}
	function A(t) {
		if (t === 62) {
			let n = o.toLowerCase();
			return Ir.includes(n) ? (e.consume(t), oe) : O(t);
		}
		return M(t) && o.length < 8 ? (e.consume(t), o += String.fromCharCode(t), A) : O(t);
	}
	function ie(t) {
		return t === 93 ? (e.consume(t), ae) : O(t);
	}
	function ae(t) {
		return t === 62 ? (e.consume(t), oe) : t === 45 && i === 2 ? (e.consume(t), ae) : O(t);
	}
	function oe(t) {
		return t === null || P(t) ? (e.exit("htmlFlowData"), se(t)) : (e.consume(t), oe);
	}
	function se(n) {
		return e.exit("htmlFlow"), t(n);
	}
}
function Vr(e, t, n) {
	return r;
	function r(r) {
		return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), e.attempt(z, t, n);
	}
}
// node_modules/micromark-core-commonmark/lib/html-text.js
var Hr = {
	name: "htmlText",
	tokenize: Ur
};
function Ur(e, t, n) {
	let r = this, i, a, o;
	return s;
	function s(t) {
		return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(t), c;
	}
	function c(t) {
		return t === 33 ? (e.consume(t), l) : t === 47 ? (e.consume(t), x) : t === 63 ? (e.consume(t), y) : M(t) ? (e.consume(t), w) : n(t);
	}
	function l(t) {
		return t === 45 ? (e.consume(t), u) : t === 91 ? (e.consume(t), a = 0, m) : M(t) ? (e.consume(t), v) : n(t);
	}
	function u(t) {
		return t === 45 ? (e.consume(t), p) : n(t);
	}
	function d(t) {
		return t === null ? n(t) : t === 45 ? (e.consume(t), f) : P(t) ? (o = d, k(t)) : (e.consume(t), d);
	}
	function f(t) {
		return t === 45 ? (e.consume(t), p) : d(t);
	}
	function p(e) {
		return e === 62 ? re(e) : e === 45 ? f(e) : d(e);
	}
	function m(t) {
		return t === "CDATA[".charCodeAt(a++) ? (e.consume(t), a === 6 ? h : m) : n(t);
	}
	function h(t) {
		return t === null ? n(t) : t === 93 ? (e.consume(t), g) : P(t) ? (o = h, k(t)) : (e.consume(t), h);
	}
	function g(t) {
		return t === 93 ? (e.consume(t), _) : h(t);
	}
	function _(t) {
		return t === 62 ? re(t) : t === 93 ? (e.consume(t), _) : h(t);
	}
	function v(t) {
		return t === null || t === 62 ? re(t) : P(t) ? (o = v, k(t)) : (e.consume(t), v);
	}
	function y(t) {
		return t === null ? n(t) : t === 63 ? (e.consume(t), b) : P(t) ? (o = y, k(t)) : (e.consume(t), y);
	}
	function b(e) {
		return e === 62 ? re(e) : y(e);
	}
	function x(t) {
		return M(t) ? (e.consume(t), S) : n(t);
	}
	function S(t) {
		return t === 45 || U(t) ? (e.consume(t), S) : C(t);
	}
	function C(t) {
		return P(t) ? (o = C, k(t)) : W(t) ? (e.consume(t), C) : re(t);
	}
	function w(t) {
		return t === 45 || U(t) ? (e.consume(t), w) : t === 47 || t === 62 || R(t) ? T(t) : n(t);
	}
	function T(t) {
		return t === 47 ? (e.consume(t), re) : t === 58 || t === 95 || M(t) ? (e.consume(t), E) : P(t) ? (o = T, k(t)) : W(t) ? (e.consume(t), T) : re(t);
	}
	function E(t) {
		return t === 45 || t === 46 || t === 58 || t === 95 || U(t) ? (e.consume(t), E) : D(t);
	}
	function D(t) {
		return t === 61 ? (e.consume(t), O) : P(t) ? (o = D, k(t)) : W(t) ? (e.consume(t), D) : T(t);
	}
	function O(t) {
		return t === null || t === 60 || t === 61 || t === 62 || t === 96 ? n(t) : t === 34 || t === 39 ? (e.consume(t), i = t, ee) : P(t) ? (o = O, k(t)) : W(t) ? (e.consume(t), O) : (e.consume(t), te);
	}
	function ee(t) {
		return t === i ? (e.consume(t), i = void 0, ne) : t === null ? n(t) : P(t) ? (o = ee, k(t)) : (e.consume(t), ee);
	}
	function te(t) {
		return t === null || t === 34 || t === 39 || t === 60 || t === 61 || t === 96 ? n(t) : t === 47 || t === 62 || R(t) ? T(t) : (e.consume(t), te);
	}
	function ne(e) {
		return e === 47 || e === 62 || R(e) ? T(e) : n(e);
	}
	function re(r) {
		return r === 62 ? (e.consume(r), e.exit("htmlTextData"), e.exit("htmlText"), t) : n(r);
	}
	function k(t) {
		return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), A;
	}
	function A(t) {
		return W(t) ? I(e, ie, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : ie(t);
	}
	function ie(t) {
		return e.enter("htmlTextData"), o(t);
	}
}
// node_modules/micromark-core-commonmark/lib/label-end.js
var Wr = {
	name: "labelEnd",
	resolveAll: Jr,
	resolveTo: Yr,
	tokenize: Xr
}, Gr = { tokenize: Zr }, Kr = { tokenize: Qr }, qr = { tokenize: $r };
function Jr(e) {
	let t = -1, n = [];
	for (; ++t < e.length;) {
		let r = e[t][1];
		if (n.push(e[t]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
			let e = r.type === "labelImage" ? 4 : 2;
			r.type = "data", t += e;
		}
	}
	return e.length !== n.length && fe(e, 0, e.length, n), e;
}
function Yr(e, t) {
	let n = e.length, r = 0, i, a, o;
	for (; n--;) {
		let t = e[n][1];
		if (i) {
			if (t.type === "link" || t.type === "labelLink" && t._inactive) break;
			e[n][0] === "enter" && t.type === "labelLink" && (t._inactive = !0);
		} else if (a) {
			if (e[n][0] === "enter" && (t.type === "labelImage" || t.type === "labelLink") && !t._balanced && (i = n, t.type !== "labelLink")) {
				r = 2;
				break;
			}
		} else t.type === "labelEnd" && (a = n);
	}
	let s = {
		type: e[i][1].type === "labelLink" ? "link" : "image",
		start: { ...e[i][1].start },
		end: { ...e[e.length - 1][1].end }
	}, c = {
		type: "label",
		start: { ...e[i][1].start },
		end: { ...e[a][1].end }
	}, l = {
		type: "labelText",
		start: { ...e[i + r + 2][1].end },
		end: { ...e[a - 2][1].start }
	};
	return o = [[
		"enter",
		s,
		t
	], [
		"enter",
		c,
		t
	]], o = B(o, e.slice(i + 1, i + r + 3)), o = B(o, [[
		"enter",
		l,
		t
	]]), o = B(o, ue(t.parser.constructs.insideSpan.null, e.slice(i + r + 4, a - 3), t)), o = B(o, [
		[
			"exit",
			l,
			t
		],
		e[a - 2],
		e[a - 1],
		[
			"exit",
			c,
			t
		]
	]), o = B(o, e.slice(a + 1)), o = B(o, [[
		"exit",
		s,
		t
	]]), fe(e, i, e.length, o), e;
}
function Xr(e, t, n) {
	let r = this, i = r._labelStarts, a, o;
	if (i) {
		for (; i.length > 0 && i[i.length - 1]._balanced;) i.pop();
		a = i[i.length - 1];
	}
	return s;
	function s(t) {
		return a ? a._inactive ? d(t) : (o = r.parser.defined.includes(pe(r.sliceSerialize({
			start: a.end,
			end: r.now()
		}))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), e.exit("labelEnd"), c) : n(t);
	}
	function c(t) {
		return t === 40 ? e.attempt(Gr, u, o ? u : d)(t) : t === 91 ? e.attempt(Kr, u, o ? l : d)(t) : o ? u(t) : d(t);
	}
	function l(t) {
		return e.attempt(qr, u, d)(t);
	}
	function u(e) {
		return i.pop(), t(e);
	}
	function d(e) {
		return a._balanced = !0, n(e);
	}
}
function Zr(e, t, n) {
	return r;
	function r(t) {
		return e.enter("resource"), e.enter("resourceMarker"), e.consume(t), e.exit("resourceMarker"), i;
	}
	function i(t) {
		return R(t) ? Tr(e, a)(t) : a(t);
	}
	function a(t) {
		return t === 41 ? u(t) : Sr(e, o, s, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(t);
	}
	function o(t) {
		return R(t) ? Tr(e, c)(t) : u(t);
	}
	function s(e) {
		return n(e);
	}
	function c(t) {
		return t === 34 || t === 39 || t === 40 ? wr(e, l, n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(t) : u(t);
	}
	function l(t) {
		return R(t) ? Tr(e, u)(t) : u(t);
	}
	function u(r) {
		return r === 41 ? (e.enter("resourceMarker"), e.consume(r), e.exit("resourceMarker"), e.exit("resource"), t) : n(r);
	}
}
function Qr(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return Cr.call(r, e, a, o, "reference", "referenceMarker", "referenceString")(t);
	}
	function a(e) {
		return r.parser.defined.includes(pe(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(e) : n(e);
	}
	function o(e) {
		return n(e);
	}
}
function $r(e, t, n) {
	return r;
	function r(t) {
		return e.enter("reference"), e.enter("referenceMarker"), e.consume(t), e.exit("referenceMarker"), i;
	}
	function i(r) {
		return r === 93 ? (e.enter("referenceMarker"), e.consume(r), e.exit("referenceMarker"), e.exit("reference"), t) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/label-start-image.js
var ei = {
	name: "labelStartImage",
	resolveAll: Wr.resolveAll,
	tokenize: ti
};
function ti(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(t), e.exit("labelImageMarker"), o;
	}
	function o(t) {
		return t === 91 ? (e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), i = e.exit("labelImage"), s) : n(t);
	}
	function s(e) {
		return e === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(e));
	}
}
// node_modules/micromark-core-commonmark/lib/label-start-link.js
var ni = {
	name: "labelStartLink",
	resolveAll: Wr.resolveAll,
	tokenize: ri
};
function ri(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("labelLink"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), i = e.exit("labelLink"), o;
	}
	function o(e) {
		return e === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(e));
	}
}
// node_modules/micromark-core-commonmark/lib/line-ending.js
var ii = {
	name: "lineEnding",
	tokenize: ai
};
function ai(e, t) {
	return n;
	function n(n) {
		return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), I(e, t, "linePrefix");
	}
}
// node_modules/micromark-core-commonmark/lib/thematic-break.js
var oi = {
	name: "thematicBreak",
	tokenize: si
};
function si(e, t, n) {
	let r = 0, i;
	return a;
	function a(t) {
		return e.enter("thematicBreak"), o(t);
	}
	function o(e) {
		return i = e, s(e);
	}
	function s(a) {
		return a === i ? (e.enter("thematicBreakSequence"), c(a)) : r >= 3 && (a === null || P(a)) ? (e.exit("thematicBreak"), t(a)) : n(a);
	}
	function c(t) {
		return t === i ? (e.consume(t), r++, c) : (e.exit("thematicBreakSequence"), W(t) ? I(e, s, "whitespace")(t) : s(t));
	}
}
// node_modules/micromark-core-commonmark/lib/list.js
var Q = {
	continuation: { tokenize: di },
	exit: pi,
	name: "list",
	tokenize: ui
}, ci = {
	partial: !0,
	tokenize: mi
}, li = {
	partial: !0,
	tokenize: fi
};
function ui(e, t, n) {
	let r = this, i = r.events[r.events.length - 1], a = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], !0).length : 0, o = 0;
	return s;
	function s(t) {
		let i = r.containerState.type || (t === 42 || t === 43 || t === 45 ? "listUnordered" : "listOrdered");
		if (i === "listUnordered" ? !r.containerState.marker || t === r.containerState.marker : _e(t)) {
			if (r.containerState.type || (r.containerState.type = i, e.enter(i, { _container: !0 })), i === "listUnordered") return e.enter("listItemPrefix"), t === 42 || t === 45 ? e.check(oi, n, l)(t) : l(t);
			if (!r.interrupt || t === 49) return e.enter("listItemPrefix"), e.enter("listItemValue"), c(t);
		}
		return n(t);
	}
	function c(t) {
		return _e(t) && ++o < 10 ? (e.consume(t), c) : (!r.interrupt || o < 2) && (r.containerState.marker ? t === r.containerState.marker : t === 41 || t === 46) ? (e.exit("listItemValue"), l(t)) : n(t);
	}
	function l(t) {
		return e.enter("listItemMarker"), e.consume(t), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || t, e.check(z, r.interrupt ? n : u, e.attempt(ci, f, d));
	}
	function u(e) {
		return r.containerState.initialBlankLine = !0, a++, f(e);
	}
	function d(t) {
		return W(t) ? (e.enter("listItemPrefixWhitespace"), e.consume(t), e.exit("listItemPrefixWhitespace"), f) : n(t);
	}
	function f(n) {
		return r.containerState.size = a + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, t(n);
	}
}
function di(e, t, n) {
	let r = this;
	return r.containerState._closeFlow = void 0, e.check(z, i, a);
	function i(n) {
		return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, I(e, t, "listItemIndent", r.containerState.size + 1)(n);
	}
	function a(n) {
		return r.containerState.furtherBlankLines || !W(n) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, o(n)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(li, t, o)(n));
	}
	function o(i) {
		return r.containerState._closeFlow = !0, r.interrupt = void 0, I(e, e.attempt(Q, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(i);
	}
}
function fi(e, t, n) {
	let r = this;
	return I(e, i, "listItemIndent", r.containerState.size + 1);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return i && i[1].type === "listItemIndent" && i[2].sliceSerialize(i[1], !0).length === r.containerState.size ? t(e) : n(e);
	}
}
function pi(e) {
	e.exit(this.containerState.type);
}
function mi(e, t, n) {
	let r = this;
	return I(e, i, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return !W(e) && i && i[1].type === "listItemPrefixWhitespace" ? t(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/setext-underline.js
var hi = {
	name: "setextUnderline",
	resolveTo: gi,
	tokenize: _i
};
function gi(e, t) {
	let n = new Fn(), r = e.length, i, a, o;
	for (; r--;) if (e[r][0] === "enter") {
		if (e[r][1].type === "content") {
			i = r;
			break;
		}
		e[r][1].type === "paragraph" && (a = r);
	} else e[r][1].type === "content" && n.add(r, 1, []), !o && e[r][1].type === "definition" && (o = r);
	let s = {
		type: "setextHeading",
		start: { ...e[i][1].start },
		end: { ...e[e.length - 1][1].end }
	};
	return e[a][1].type = "setextHeadingText", o ? (n.add(a, 0, [[
		"enter",
		s,
		t
	]]), n.add(o + 1, 0, [[
		"exit",
		e[i][1],
		t
	]]), e[i][1].end = { ...e[o][1].end }) : e[i][1] = s, n.add(e.length, 0, [[
		"exit",
		s,
		t
	]]), n.consume(e), e;
}
function _i(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		let a = r.events.length, s;
		for (; a--;) if (r.events[a][1].type !== "lineEnding" && r.events[a][1].type !== "linePrefix" && r.events[a][1].type !== "content") {
			s = r.events[a][1].type === "paragraph";
			break;
		}
		return !r.parser.lazy[r.now().line] && (r.interrupt || s) ? (e.enter("setextHeadingLine"), i = t, o(t)) : n(t);
	}
	function o(t) {
		return e.enter("setextHeadingLineSequence"), s(t);
	}
	function s(t) {
		return t === i ? (e.consume(t), s) : (e.exit("setextHeadingLineSequence"), W(t) ? I(e, c, "lineSuffix")(t) : c(t));
	}
	function c(r) {
		return r === null || P(r) ? (e.exit("setextHeadingLine"), t(r)) : n(r);
	}
}
// node_modules/micromark/lib/initialize/flow.js
var vi = { tokenize: yi };
function yi(e) {
	let t = this, n = e.attempt(z, r, e.attempt(this.parser.constructs.flowInitial, i, I(e, e.attempt(this.parser.constructs.flow, i, e.attempt(_r, i)), "linePrefix")));
	return n;
	function r(r) {
		if (r === null) e.consume(r);
		else return e.enter("lineEndingBlank"), e.consume(r), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n;
	}
	function i(r) {
		if (r === null) e.consume(r);
		else return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), t.currentConstruct = void 0, n;
	}
}
// node_modules/micromark/lib/initialize/text.js
var bi = { resolveAll: wi() }, xi = Ci("string"), Si = Ci("text");
function Ci(e) {
	return {
		resolveAll: wi(e === "text" ? Ti : void 0),
		tokenize: t
	};
	function t(t) {
		let n = this, r = this.parser.constructs[e], i = t.attempt(r, a, o);
		return a;
		function a(e) {
			return c(e) ? i(e) : o(e);
		}
		function o(e) {
			if (e === null) t.consume(e);
			else return t.enter("data"), t.consume(e), s;
		}
		function s(e) {
			return c(e) ? (t.exit("data"), i(e)) : (t.consume(e), s);
		}
		function c(e) {
			if (e === null) return !0;
			let t = r[e], i = -1;
			if (t) for (; ++i < t.length;) {
				let e = t[i];
				if (!e.previous || e.previous.call(n, n.previous)) return !0;
			}
			return !1;
		}
	}
}
function wi(e) {
	return t;
	function t(t, n) {
		let r = -1, i;
		for (; ++r <= t.length;) i === void 0 ? t[r] && t[r][1].type === "data" && (i = r, r++) : t[r] && t[r][1].type === "data" || (r !== i + 2 && (t[i][1].end = t[r - 1][1].end, t.splice(i + 2, r - i - 2), r = i + 2), i = void 0);
		return e ? e(t, n) : t;
	}
}
function Ti(e, t) {
	let n = new Fn(), r = 0;
	for (; ++r <= e.length;) if ((r === e.length || e[r][1].type === "lineEnding") && e[r - 1][1].type === "data") {
		let i = e[r - 1][1], a = t.sliceStream(i), o = a.length, s = -1, c = 0, l;
		for (; o--;) {
			let e = a[o];
			if (typeof e == "string") {
				for (s = e.length; e.charCodeAt(s - 1) === 32;) c++, s--;
				if (s) break;
				s = -1;
			} else if (e === -2) l = !0, c++;
			else if (e !== -1) {
				o++;
				break;
			}
		}
		if (t._contentTypeTextTrailing && r === e.length && (c = 0), c) {
			let a = {
				type: r === e.length || l || c < 2 ? "lineSuffix" : "hardBreakTrailing",
				start: {
					_bufferIndex: o ? s : i.start._bufferIndex + s,
					_index: i.start._index + o,
					line: i.end.line,
					column: i.end.column - c,
					offset: i.end.offset - c
				},
				end: { ...i.end }
			};
			i.end = { ...a.start }, i.start.offset === i.end.offset ? Object.assign(i, a) : n.add(r, 0, [[
				"enter",
				a,
				t
			], [
				"exit",
				a,
				t
			]]);
		}
		r++;
	}
	return n.consume(e), e;
}
// node_modules/micromark/lib/constructs.js
var Ei = /* @__PURE__ */ Ge({
	attentionMarkers: () => Pi,
	contentInitial: () => Oi,
	disable: () => Fi,
	document: () => Di,
	flow: () => Ai,
	flowInitial: () => ki,
	insideSpan: () => Ni,
	string: () => ji,
	text: () => Mi
}), Di = {
	42: Q,
	43: Q,
	45: Q,
	48: Q,
	49: Q,
	50: Q,
	51: Q,
	52: Q,
	53: Q,
	54: Q,
	55: Q,
	56: Q,
	57: Q,
	62: qn
}, Oi = { 91: Er }, ki = {
	[-2]: ar,
	[-1]: ar,
	32: ar
}, Ai = {
	35: Mr,
	42: oi,
	45: [hi, oi],
	60: Lr,
	61: hi,
	95: oi,
	96: rr,
	126: rr
}, ji = {
	38: $n,
	92: Zn
}, Mi = {
	[-5]: ii,
	[-4]: ii,
	[-3]: ii,
	33: ei,
	38: $n,
	42: Vn,
	60: [Gn, Hr],
	91: ni,
	92: [Ar, Zn],
	93: Wr,
	95: Vn,
	96: lr
}, Ni = { null: [Vn, bi] }, Pi = { null: [42, 95] }, Fi = { null: [] };
// node_modules/micromark/lib/create-tokenizer.js
function Ii(e, t, n) {
	let r = {
		_bufferIndex: -1,
		_index: 0,
		line: n && n.line || 1,
		column: n && n.column || 1,
		offset: n && n.offset || 0
	}, i = {}, a = [], o = [], s = [], c = {
		attempt: C(x),
		check: C(S),
		consume: v,
		enter: y,
		exit: b,
		interrupt: C(S, { interrupt: !0 })
	}, l = {
		code: null,
		containerState: {},
		defineSkip: h,
		events: [],
		now: m,
		parser: e,
		previous: null,
		sliceSerialize: f,
		sliceStream: p,
		write: d
	}, u = t.tokenize.call(l, c);
	return t.resolveAll && a.push(t), l;
	function d(e) {
		return o = B(o, e), g(), o[o.length - 1] === null ? (w(t, 0), l.events = ue(a, l.events, l), l.events) : [];
	}
	function f(e, t) {
		return Ri(p(e), t);
	}
	function p(e) {
		return Li(o, e);
	}
	function m() {
		let { _bufferIndex: e, _index: t, line: n, column: i, offset: a } = r;
		return {
			_bufferIndex: e,
			_index: t,
			line: n,
			column: i,
			offset: a
		};
	}
	function h(e) {
		i[e.line] = e.column, E();
	}
	function g() {
		for (; r._index < o.length;) {
			let e = o[r._index];
			if (typeof e == "string") {
				let t = r._index;
				for (r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === t && r._bufferIndex < e.length;) _(e.charCodeAt(r._bufferIndex));
			} else _(e);
		}
	}
	function _(e) {
		u = u(e);
	}
	function v(e) {
		P(e) ? (r.line++, r.column = 1, r.offset += e === -3 ? 2 : 1, E()) : e !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === o[r._index].length && (r._bufferIndex = -1, r._index++)), l.previous = e;
	}
	function y(e, t) {
		let n = t || {};
		return n.type = e, n.start = m(), l.events.push([
			"enter",
			n,
			l
		]), s.push(n), n;
	}
	function b(e) {
		let t = s.pop();
		return t.end = m(), l.events.push([
			"exit",
			t,
			l
		]), t;
	}
	function x(e, t) {
		w(e, t.from);
	}
	function S(e, t) {
		t.restore();
	}
	function C(e, t) {
		return n;
		function n(n, r, i) {
			let a, o, s, u;
			return Array.isArray(n) ? f(n) : "tokenize" in n ? f([n]) : d(n);
			function d(e) {
				return t;
				function t(t) {
					let n = t !== null && e[t], r = t !== null && e.null;
					return f([...Array.isArray(n) ? n : n ? [n] : [], ...Array.isArray(r) ? r : r ? [r] : []])(t);
				}
			}
			function f(e) {
				return a = e, o = 0, e.length === 0 ? i : p(e[o]);
			}
			function p(e) {
				return n;
				function n(n) {
					return u = T(), s = e, e.partial || (l.currentConstruct = e), e.name && l.parser.constructs.disable.null.includes(e.name) ? h(n) : e.tokenize.call(t ? Object.assign(Object.create(l), t) : l, c, m, h)(n);
				}
			}
			function m(t) {
				return e(s, u), r;
			}
			function h(e) {
				return u.restore(), ++o < a.length ? p(a[o]) : i;
			}
		}
	}
	function w(e, t) {
		e.resolveAll && !a.includes(e) && a.push(e), e.resolve && fe(l.events, t, l.events.length - t, e.resolve(l.events.slice(t), l)), e.resolveTo && (l.events = e.resolveTo(l.events, l));
	}
	function T() {
		let e = m(), t = l.previous, n = l.currentConstruct, i = l.events.length, a = Array.from(s);
		return {
			from: i,
			restore: o
		};
		function o() {
			r = e, l.previous = t, l.currentConstruct = n, l.events.length = i, s = a, E();
		}
	}
	function E() {
		r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1);
	}
}
function Li(e, t) {
	let n = t.start._index, r = t.start._bufferIndex, i = t.end._index, a = t.end._bufferIndex, o;
	if (n === i) o = [e[n].slice(r, a)];
	else {
		if (o = e.slice(n, i), r > -1) {
			let e = o[0];
			typeof e == "string" ? o[0] = e.slice(r) : o.shift();
		}
		a > 0 && o.push(e[i].slice(0, a));
	}
	return o;
}
function Ri(e, t) {
	let n = -1, r = [], i;
	for (; ++n < e.length;) {
		let a = e[n], o;
		if (typeof a == "string") o = a;
		else switch (a) {
			case -5:
				o = "\r";
				break;
			case -4:
				o = "\n";
				break;
			case -3:
				o = "\r\n";
				break;
			case -2:
				o = t ? " " : "	";
				break;
			case -1:
				if (!t && i) continue;
				o = " ";
				break;
			default: o = String.fromCharCode(a);
		}
		i = a === -2, r.push(o);
	}
	return r.join("");
}
// node_modules/micromark/lib/parse.js
function zi(e) {
	let t = {
		constructs: ye([Ei, ...(e || {}).extensions || []]),
		content: n(Nn),
		defined: [],
		document: n(Ln),
		flow: n(vi),
		lazy: {},
		string: n(xi),
		text: n(Si)
	};
	return t;
	function n(e) {
		return n;
		function n(n) {
			return Ii(t, e, n);
		}
	}
}
// node_modules/micromark/lib/postprocess.js
function Bi(e) {
	for (; !hr(e););
	return e;
}
// node_modules/micromark/lib/preprocess.js
var Vi = /[\0\t\n\r]/g;
function Hi() {
	let e = 1, t = "", n = !0, r;
	return i;
	function i(i, a, o) {
		i = t + (typeof i == "string" ? i.toString() : new TextDecoder(a || void 0).decode(i));
		let s = [], c = 0;
		for (t = "", n &&= (i.charCodeAt(0) === 65279 && c++, void 0); c < i.length;) {
			Vi.lastIndex = c;
			let n = Vi.exec(i), a = n && n.index !== void 0 ? n.index : i.length, o = i.charCodeAt(a);
			if (!n) {
				t = i.slice(c);
				break;
			}
			if (o === 10 && c === a && r) s.push(-3), r = void 0;
			else switch (r &&= (s.push(-5), void 0), c < a && (s.push(i.slice(c, a)), e += a - c), o) {
				case 0:
					s.push(65533), e++;
					break;
				case 9: {
					let t = Math.ceil(e / 4) * 4;
					for (s.push(-2); e++ < t;) s.push(-1);
					break;
				}
				case 10:
					s.push(-4), e = 1;
					break;
				default: r = !0, e = 1;
			}
			c = a + 1;
		}
		return o && (r && s.push(-5), t && s.push(t), s.push(null)), s;
	}
}
// node_modules/micromark-util-decode-string/index.js
var Ui = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function Wi(e) {
	return e.replace(Ui, Gi);
}
function Gi(e, t, n) {
	if (t) return t;
	if (n.charCodeAt(0) === 35) {
		let e = n.charCodeAt(1), t = e === 120 || e === 88;
		return Mn(n.slice(t ? 2 : 1), t ? 16 : 10);
	}
	return jn(n) || e;
}
// node_modules/mdast-util-from-markdown/lib/index.js
var Ki = {}.hasOwnProperty;
function qi(e, t, n) {
	return t && typeof t == "object" && (n = t, t = void 0), Ji(n)(Bi(zi(n).document().write(Hi()(e, t, !0))));
}
function Ji(e) {
	let t = {
		afterExit: [],
		beforeEnter: [],
		transforms: [],
		canContainEols: [
			"emphasis",
			"fragment",
			"heading",
			"paragraph",
			"strong"
		],
		enter: {
			autolink: o(z),
			autolinkProtocol: E,
			autolinkEmail: E,
			atxHeading: o(_e),
			blockQuote: o(me),
			characterEscape: E,
			characterReference: E,
			codeFenced: o(P),
			codeFencedFenceInfo: s,
			codeFencedFenceMeta: s,
			codeIndented: o(P, s),
			codeText: o(F, s),
			codeTextData: E,
			data: E,
			codeFlowValue: E,
			definition: o(ge),
			definitionDestinationString: s,
			definitionLabelString: s,
			definitionTitleString: s,
			emphasis: o(I),
			hardBreakEscape: o(L),
			hardBreakTrailing: o(L),
			htmlFlow: o(R, s),
			htmlFlowData: E,
			htmlText: o(R, s),
			htmlTextData: E,
			image: o(ve),
			label: s,
			link: o(z),
			listItem: o(B),
			listItemValue: p,
			listOrdered: o(ye, f),
			listUnordered: o(ye),
			paragraph: o(be),
			reference: ce,
			referenceString: s,
			resourceDestinationString: s,
			resourceTitleString: s,
			setextHeading: o(_e),
			strong: o(xe),
			thematicBreak: o(Se)
		},
		exit: {
			atxHeading: l(),
			atxHeadingSequence: S,
			autolink: l(),
			autolinkEmail: N,
			autolinkProtocol: fe,
			blockQuote: l(),
			characterEscapeValue: D,
			characterReferenceMarkerHexadecimal: le,
			characterReferenceMarkerNumeric: le,
			characterReferenceValue: ue,
			characterReference: de,
			codeFenced: l(_),
			codeFencedFence: g,
			codeFencedFenceInfo: m,
			codeFencedFenceMeta: h,
			codeFlowValue: D,
			codeIndented: l(v),
			codeText: l(re),
			codeTextData: D,
			data: D,
			definition: l(),
			definitionDestinationString: x,
			definitionLabelString: y,
			definitionTitleString: b,
			emphasis: l(),
			hardBreakEscape: l(ee),
			hardBreakTrailing: l(ee),
			htmlFlow: l(te),
			htmlFlowData: D,
			htmlText: l(ne),
			htmlTextData: D,
			image: l(A),
			label: ae,
			labelText: ie,
			lineEnding: O,
			link: l(k),
			listItem: l(),
			listOrdered: l(),
			listUnordered: l(),
			paragraph: l(),
			referenceString: M,
			resourceDestinationString: oe,
			resourceTitleString: se,
			resource: j,
			setextHeading: l(T),
			setextHeadingLineSequence: w,
			setextHeadingText: C,
			strong: l(),
			thematicBreak: l()
		}
	};
	Xi(t, (e || {}).mdastExtensions || []);
	let n = {};
	return r;
	function r(e) {
		let r = {
			type: "root",
			children: [],
			position: void 0
		}, o = {
			stack: [r],
			tokenStack: [],
			config: t,
			enter: c,
			exit: u,
			buffer: s,
			resume: d,
			data: n
		}, l = [], f = [], p = -1;
		for (; ++p < e.length;) f.push(e[p]), (e[p][1].type === "listOrdered" || e[p][1].type === "listUnordered") && (e[p][0] === "enter" ? l.push(f.length - 1) : a(f, l.pop()));
		for (e = f, p = -1; ++p < e.length;) {
			let n = t[e[p][0]];
			e[p][0] === "enter" && t.beforeEnter.length > 0 && i(t.beforeEnter, {
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]), Ki.call(n, e[p][1].type) && n[e[p][1].type].call({
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]), e[p][0] === "exit" && t.afterExit.length > 0 && i(t.afterExit, {
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]);
		}
		if (o.tokenStack.length > 0) {
			let e = o.tokenStack[o.tokenStack.length - 1];
			(e[1] || Qi).call(o, void 0, e[0]);
		}
		for (r.position = {
			start: Yi(e.length > 0 ? e[0][1].start : {
				line: 1,
				column: 1,
				offset: 0
			}),
			end: Yi(e.length > 0 ? e[e.length - 2][1].end : {
				line: 1,
				column: 1,
				offset: 0
			})
		}, p = -1; ++p < t.transforms.length;) r = t.transforms[p](r) || r;
		return r;
	}
	function i(e, t, n) {
		let r = -1;
		for (; ++r < e.length;) e[r].call(t, n);
	}
	function a(e, t) {
		let n = e.length - 1, r = t - 1, i = -1, a = !1, o, s, c, l, u = [];
		for (; ++r <= n;) {
			let t = e[r];
			switch (t[1].type) {
				case "listUnordered":
				case "listOrdered":
				case "blockQuote":
					t[0] === "enter" ? i++ : i--, l = void 0;
					break;
				case "lineEndingBlank":
					t[0] === "enter" && (o && !l && !i && !c && (c = r), l = void 0);
					break;
				case "linePrefix":
				case "listItemValue":
				case "listItemMarker":
				case "listItemPrefix":
				case "listItemPrefixWhitespace": break;
				default: l = void 0;
			}
			if (!i && t[0] === "enter" && t[1].type === "listItemPrefix" || i === -1 && t[0] === "exit" && (t[1].type === "listUnordered" || t[1].type === "listOrdered")) {
				if (o) {
					let n = r;
					for (s = void 0; n--;) {
						let t = e[n];
						if (t[1].type === "lineEnding" || t[1].type === "lineEndingBlank") {
							if (t[0] === "exit") continue;
							s && (e[s][1].type = "lineEndingBlank", a = !0), t[1].type = "lineEnding", s = n;
						} else if (t[1].type !== "linePrefix" && t[1].type !== "blockQuotePrefix" && t[1].type !== "blockQuotePrefixWhitespace" && t[1].type !== "blockQuoteMarker" && t[1].type !== "listItemIndent") break;
					}
					c && (!s || c < s) && (o._spread = !0), o.end = Object.assign({}, s ? e[s][1].start : t[1].end), u.push({
						at: s || r,
						event: [
							"exit",
							o,
							t[2]
						]
					});
				}
				if (t[1].type === "listItemPrefix") {
					let e = {
						type: "listItem",
						_spread: !1,
						start: Object.assign({}, t[1].start),
						end: void 0
					};
					o = e, u.push({
						at: r,
						event: [
							"enter",
							e,
							t[2]
						]
					}), c = void 0, l = !0;
				}
			}
		}
		let d = e.splice(t), f = 0;
		for (r = -1; ++r < d.length;) {
			for (; f < u.length && u[f].at === t + r;) e.push(u[f++].event);
			e.push(d[r]);
		}
		e[t][1]._spread = a;
	}
	function o(e, t) {
		return n;
		function n(n) {
			c.call(this, e(n), n), t && t.call(this, n);
		}
	}
	function s() {
		this.stack.push({
			type: "fragment",
			children: []
		});
	}
	function c(e, t, n) {
		this.stack[this.stack.length - 1].children.push(e), this.stack.push(e), this.tokenStack.push([t, n || void 0]), e.position = {
			start: Yi(t.start),
			end: void 0
		};
	}
	function l(e) {
		return t;
		function t(t) {
			e && e.call(this, t), u.call(this, t);
		}
	}
	function u(e, t) {
		let n = this.stack.pop(), r = this.tokenStack.pop();
		if (!r) throw Error("Cannot close `" + e.type + "` (" + qt({
			start: e.start,
			end: e.end
		}) + "): it’s not open");
		r[0].type !== e.type && (t ? t.call(this, e, r[0]) : (r[1] || Qi).call(this, e, r[0])), n.position.end = Yi(e.end);
	}
	function d() {
		return he(this.stack.pop());
	}
	function f() {
		this.data.expectingFirstListItemValue = !0;
	}
	function p(e) {
		if (this.data.expectingFirstListItemValue) {
			let t = this.stack[this.stack.length - 2];
			t.start = Number.parseInt(this.sliceSerialize(e), 10), this.data.expectingFirstListItemValue = void 0;
		}
	}
	function m() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.lang = e;
	}
	function h() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.meta = e;
	}
	function g() {
		this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
	}
	function _() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
	}
	function v() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e.replace(/(\r?\n|\r)$/g, "");
	}
	function y(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.label = t, n.identifier = pe(this.sliceSerialize(e)).toLowerCase();
	}
	function b() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.title = e;
	}
	function x() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.url = e;
	}
	function S(e) {
		let t = this.stack[this.stack.length - 1];
		t.depth ||= this.sliceSerialize(e).length;
	}
	function C() {
		this.data.setextHeadingSlurpLineEnding = !0;
	}
	function w(e) {
		let t = this.stack[this.stack.length - 1];
		t.depth = this.sliceSerialize(e).codePointAt(0) === 61 ? 1 : 2;
	}
	function T() {
		this.data.setextHeadingSlurpLineEnding = void 0;
	}
	function E(e) {
		let t = this.stack[this.stack.length - 1].children, n = t[t.length - 1];
		n && n.type === "text" || (n = V(), n.position = {
			start: Yi(e.start),
			end: void 0
		}, t.push(n)), this.stack.push(n);
	}
	function D(e) {
		let t = this.stack.pop();
		t.value += this.sliceSerialize(e), t.position.end = Yi(e.end);
	}
	function O(e) {
		let n = this.stack[this.stack.length - 1];
		if (this.data.atHardBreak) {
			let t = n.children[n.children.length - 1];
			t.position.end = Yi(e.end), this.data.atHardBreak = void 0;
		} else !this.data.setextHeadingSlurpLineEnding && t.canContainEols.includes(n.type) && (E.call(this, e), D.call(this, e));
	}
	function ee() {
		this.data.atHardBreak = !0;
	}
	function te() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function ne() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function re() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function k() {
		let e = this.stack[this.stack.length - 1];
		if (this.data.inReference) {
			let t = this.data.referenceType || "shortcut";
			e.type += "Reference", e.referenceType = t, delete e.url, delete e.title;
		} else delete e.identifier, delete e.label;
		this.data.referenceType = void 0;
	}
	function A() {
		let e = this.stack[this.stack.length - 1];
		if (this.data.inReference) {
			let t = this.data.referenceType || "shortcut";
			e.type += "Reference", e.referenceType = t, delete e.url, delete e.title;
		} else delete e.identifier, delete e.label;
		this.data.referenceType = void 0;
	}
	function ie(e) {
		let t = this.sliceSerialize(e), n = this.stack[this.stack.length - 2];
		n.label = Wi(t), n.identifier = pe(t).toLowerCase();
	}
	function ae() {
		let e = this.stack[this.stack.length - 1], t = this.resume(), n = this.stack[this.stack.length - 1];
		this.data.inReference = !0, n.type === "link" ? n.children = e.children : n.alt = t;
	}
	function oe() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.url = e;
	}
	function se() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.title = e;
	}
	function j() {
		this.data.inReference = void 0;
	}
	function ce() {
		this.data.referenceType = "collapsed";
	}
	function M(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.label = t, n.identifier = pe(this.sliceSerialize(e)).toLowerCase(), this.data.referenceType = "full";
	}
	function le(e) {
		this.data.characterReferenceType = e.type;
	}
	function ue(e) {
		let t = this.sliceSerialize(e), n = this.data.characterReferenceType, r;
		n ? (r = Mn(t, n === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : r = jn(t);
		let i = this.stack[this.stack.length - 1];
		i.value += r;
	}
	function de(e) {
		let t = this.stack.pop();
		t.position.end = Yi(e.end);
	}
	function fe(e) {
		D.call(this, e);
		let t = this.stack[this.stack.length - 1];
		t.url = this.sliceSerialize(e);
	}
	function N(e) {
		D.call(this, e);
		let t = this.stack[this.stack.length - 1];
		t.url = "mailto:" + this.sliceSerialize(e);
	}
	function me() {
		return {
			type: "blockquote",
			children: [],
			position: void 0
		};
	}
	function P() {
		return {
			type: "code",
			lang: null,
			meta: null,
			value: "",
			position: void 0
		};
	}
	function F() {
		return {
			type: "inlineCode",
			value: "",
			position: void 0
		};
	}
	function ge() {
		return {
			type: "definition",
			identifier: "",
			label: null,
			title: null,
			url: "",
			position: void 0
		};
	}
	function I() {
		return {
			type: "emphasis",
			children: [],
			position: void 0
		};
	}
	function _e() {
		return {
			type: "heading",
			depth: 0,
			children: [],
			position: void 0
		};
	}
	function L() {
		return {
			type: "break",
			position: void 0
		};
	}
	function R() {
		return {
			type: "html",
			value: "",
			position: void 0
		};
	}
	function ve() {
		return {
			type: "image",
			title: null,
			url: "",
			alt: null,
			position: void 0
		};
	}
	function z() {
		return {
			type: "link",
			title: null,
			url: "",
			children: [],
			position: void 0
		};
	}
	function ye(e) {
		return {
			type: "list",
			ordered: e.type === "listOrdered",
			start: null,
			spread: e._spread,
			children: [],
			position: void 0
		};
	}
	function B(e) {
		return {
			type: "listItem",
			spread: e._spread,
			checked: null,
			children: [],
			position: void 0
		};
	}
	function be() {
		return {
			type: "paragraph",
			children: [],
			position: void 0
		};
	}
	function xe() {
		return {
			type: "strong",
			children: [],
			position: void 0
		};
	}
	function V() {
		return {
			type: "text",
			value: "",
			position: void 0
		};
	}
	function Se() {
		return {
			type: "thematicBreak",
			position: void 0
		};
	}
}
function Yi(e) {
	return {
		line: e.line,
		column: e.column,
		offset: e.offset
	};
}
function Xi(e, t) {
	let n = -1;
	for (; ++n < t.length;) {
		let r = t[n];
		Array.isArray(r) ? Xi(e, r) : Zi(e, r);
	}
}
function Zi(e, t) {
	let n;
	for (n in t) if (Ki.call(t, n)) switch (n) {
		case "canContainEols": {
			let r = t[n];
			r && e[n].push(...r);
			break;
		}
		case "transforms": {
			let r = t[n];
			r && e[n].push(...r);
			break;
		}
		case "afterExit":
		case "beforeEnter": {
			let r = t[n];
			r && e[n].push(r);
			break;
		}
		case "enter":
		case "exit": {
			let r = t[n];
			r && Object.assign(e[n], r);
			break;
		}
	}
}
function Qi(e, t) {
	throw Error(e ? "Cannot close `" + e.type + "` (" + qt({
		start: e.start,
		end: e.end
	}) + "): a different token (`" + t.type + "`, " + qt({
		start: t.start,
		end: t.end
	}) + ") is open" : "Cannot close document, a token (`" + t.type + "`, " + qt({
		start: t.start,
		end: t.end
	}) + ") is still open");
}
// node_modules/remark-parse/lib/index.js
function $i(e) {
	let t = this;
	t.parser = n;
	function n(n) {
		return qi(n, {
			...t.data("settings"),
			...e,
			extensions: t.data("micromarkExtensions") || [],
			mdastExtensions: t.data("fromMarkdownExtensions") || []
		});
	}
}
// src/local/parsing/lexical.ts
function ea(e, t, n) {
	let r = "";
	for (let i = t + 2; i < n - 1; i += 1) {
		let t = e[i];
		if (r) t === "\\" ? i += 1 : t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === "}" && e[i + 1] === "}") return i + 2;
	}
	return -1;
}
function ta(e, t, n, r) {
	for (let i = t; i + 1 < n; i += 1) if (e[i] === "\\") {
		if (e[i + 1] === r) return i + 2;
		i += 1;
	}
	return null;
}
function na(e, t, n) {
	for (let r = t; r + 2 < n; r += 1) if (e[r] === "\\") {
		if (e[r + 1] === "\\" && e[r + 2] === "]" && /\s/.test(e[r - 1] ?? "")) return r + 3;
		r += 1;
	}
	return null;
}
function ra(e, t, n) {
	if (e.startsWith("\\\\[", t)) return na(e, t + 3, n) ?? t + 3;
	if (e[t] === "\\" && e[t + 1] === "(") return ta(e, t + 2, n, ")") ?? t + 2;
	if (e[t] === "\\" && e[t + 1] === "[") return ta(e, t + 2, n, "]") ?? t + 2;
	if (e[t] !== "$") return null;
	if (e[t + 1] === "$") {
		for (let r = t + 2; r + 1 < n; r += 1) if (e[r] === "\\") r += 1;
		else if (e[r] === "$" && e[r + 1] === "$") return r + 2;
		return t + 2;
	}
	for (let r = t + 1; r < n; r += 1) {
		let n = e[r];
		if (n === "\\") {
			r += 1;
			continue;
		}
		if (n === "\n" || n === "\r") break;
		if (n !== "$") continue;
		let i = e.slice(t + 1, r), a = e[r + 1];
		if (!i.trim() || a !== void 0 && a >= "0" && a <= "9") break;
		return r + 1;
	}
	return t + 1;
}
// src/local/markdown/footnotes.ts
function ia(e) {
	return typeof e == "string" && e.trim() !== "" ? e : void 0;
}
function aa(e) {
	let t = /^\[\^([\s\S]*)\]$/.exec(e.trim());
	return t ? t[1] : e;
}
function oa(e) {
	return e;
}
function sa(e, t) {
	return ia(e.attrs?.[t]);
}
function ca(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase().toLowerCase();
}
function la(e) {
	let t = oa(e), n = ia(e.value);
	return ia(t.identifier) ?? ia(t.label) ?? sa(e, "identifier") ?? sa(e, "label") ?? (n ? aa(n) : "");
}
function ua(e) {
	return ca(la(e));
}
function da(e) {
	let t = oa(e), n = ia(e.value);
	return (ia(t.label) ?? ia(t.identifier) ?? sa(e, "label") ?? sa(e, "identifier") ?? (n ? aa(n) : "")).trim().replace(/\s+/g, " ");
}
function fa(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [], i = /* @__PURE__ */ new Map(), a = [{
		nodes: e.nodes,
		index: 0
	}];
	for (; a.length;) {
		let e = a[a.length - 1];
		if (e.index === e.nodes.length) {
			a.pop();
			continue;
		}
		let t = e.nodes[e.index++];
		if (t.type === "footnoteDefinition") {
			let e = ua(t);
			e && !n.has(e) && n.set(e, t), t.children && a.push({
				nodes: t.children,
				index: 0,
				owner: t
			});
		} else if (t.type === "footnoteReference") {
			let n = e.owner;
			if (n) {
				let e = i.get(n);
				e ? e.push(t) : i.set(n, [t]);
			} else r.push(t);
		} else t.children && a.push({
			nodes: t.children,
			index: 0,
			owner: e.owner
		});
	}
	let o = [], s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = (e) => {
		let r = n.get(e);
		if (!r) return null;
		let i = s.get(e);
		if (i) return i;
		let a = {
			identifier: e,
			number: o.length + 1,
			definition: r,
			id: `${t}-fn-${o.length + 1}`,
			references: []
		};
		return o.push(a), s.set(e, a), a;
	}, d = (e) => {
		let n = ua(e), r = n ? u(n) : null;
		if (!r) {
			c.set(e, {
				id: "",
				entry: null,
				label: da(e)
			});
			return;
		}
		let i = (l.get(n) ?? 0) + 1;
		l.set(n, i);
		let a = `${t}-fnref-${r.number}-${i}`;
		r.references.push({
			node: e,
			id: a
		}), c.set(e, {
			id: a,
			entry: r,
			label: da(e)
		});
	};
	for (let e of r) d(e);
	for (let e = 0; e < o.length; e += 1) {
		let t = o[e];
		for (let e of i.get(t.definition) ?? []) d(e);
	}
	return {
		entries: o,
		siteFor(e) {
			return c.get(e);
		}
	};
}
// src/local/markdown/plain-paragraphs.ts
function pa(e, t, n) {
	if (/[\u0000-\u0009\u000b\u000c\u000e-\u001f\u007f\ufeff\\`*_{}\[\]<>!~&|$@]/.test(e) || /(?:^|[\r\n])(?:[ #>+=-]|\d{1,9}[.)](?: |[\r\n]|$))/.test(e) || / [\r\n]/.test(e) || e.includes("://") || /www\./i.test(e)) return;
	let r = [], i = -1, a = 0;
	function o() {
		if (i < 0) return;
		let o = a;
		for (; e[o - 1] === " ";) o--;
		let s = [];
		if (t) {
			let t = i;
			for (let r = t; r < o; r++) {
				if (e[r] !== "\r" && e[r] !== "\n") continue;
				r > t && s.push(n("text", t, r, { value: e.slice(t, r) }));
				let i = e[r] === "\r" && e[r + 1] === "\n" ? r + 2 : r + 1;
				s.push(n("break", r, i)), t = i, r = i - 1;
			}
			t < o && s.push(n("text", t, o, { value: e.slice(t, o) }));
		} else s.push(n("text", i, o, { value: e.slice(i, o) }));
		r.push(n("paragraph", i, a, { children: s })), i = -1;
	}
	for (let t = 0; t < e.length;) {
		let n = t;
		for (; n < e.length && e[n] !== "\r" && e[n] !== "\n";) n++;
		n === t ? o() : (i < 0 && (i = t), a = n), t = e[n] === "\r" && e[n + 1] === "\n" ? n + 2 : n + 1;
	}
	return o(), r;
}
// src/local/markdown/fast-markdown.ts
var ma = /^([-+*]|\d{1,9}[.)]) /, ha = /!\[(\ue000[0-9]+\ue001)\]\(rmd-internal:placeholder\)/g;
function ga(e, t) {
	let n = t?.placeholders ? e.replace(ha, (e, n, r) => {
		let i = t.placeholders.get(r + (t.offset ?? 0));
		return i && i.marker === n && i.end === r + (t.offset ?? 0) + e.length ? "x".repeat(e.length) : e;
	}) : e;
	if (e.includes("﻿") || /[\u0000-\u0009\u000b\u000c\u000e-\u001f\u007f\\`_\[\]<>!~&$@#]/.test(n) || !t?.allowBraces && /[{}]/.test(e) || e.includes("://") || /www\./i.test(e)) return;
	let r = [];
	for (let t = 0; t < e.length;) {
		let n = t;
		for (; n < e.length && e[n] !== "\r" && e[n] !== "\n";) n++;
		let i = e.slice(t, n);
		if (i.startsWith(" ") || i.endsWith(" ")) return;
		r.push({
			from: t,
			to: n,
			text: i
		}), t = e[n] === "\r" && e[n + 1] === "\n" ? n + 2 : n + 1;
	}
	return r;
}
function _a(e, t = !1) {
	let n = [], r = 0;
	for (; r < e.length;) {
		let i = r;
		for (; i < e.length && e[i] !== "*" && !(t && e[i] === "!");) i++;
		if (i === e.length) {
			n.push({
				type: "text",
				from: r,
				to: e.length,
				value: e.slice(r)
			});
			break;
		}
		if (t && e[i] === "!") {
			ha.lastIndex = i;
			let t = ha.exec(e);
			if (!t || t.index !== i) return;
			i > r && n.push({
				type: "text",
				from: r,
				to: i,
				value: e.slice(r, i)
			}), n.push({
				type: "opaque",
				from: i,
				to: i + t[0].length,
				value: t[1]
			}), r = i + t[0].length;
			continue;
		}
		if (e.slice(i, i + 2) !== "**" || i > 0 && e[i - 1] !== " ") return;
		let a = i + 2;
		for (; a < e.length && e[a] !== "*";) a++;
		if (a + 2 > e.length || e.slice(a, a + 2) !== "**" || a + 2 < e.length && !/[ .,;:?)\-]/.test(e[a + 2])) return;
		let o = e.slice(i + 2, a);
		if (!/^[\p{L}\p{N}](?:[\p{L}\p{N} .,:;()/-]*[\p{L}\p{N}])?$/u.test(o)) return;
		i > r && n.push({
			type: "text",
			from: r,
			to: i,
			value: e.slice(r, i)
		}), n.push({
			type: "strong",
			from: i,
			to: a + 2,
			value: o
		}), r = a + 2;
	}
	return n;
}
function va(e, t, n, r, i) {
	let a = i(e, t, n);
	if (a === void 0) return;
	let o = [];
	for (let t of a) if (t.type === "text") o.push(r("text", e + t.from, e + t.to, { value: t.value }));
	else if (t.type === "opaque") o.push(r("rmdOpaque", e + t.from, e + t.to, { value: t.value }));
	else {
		let n = r("text", e + t.from + 2, e + t.to - 2, { value: t.value });
		o.push(r("strong", e + t.from, e + t.to, { children: [n] }));
	}
	return o;
}
function ya(e, t, n, r) {
	function i(e, t, i) {
		return va(e, t, i, n, r);
	}
	function a(t, r, a) {
		let o = e.slice(t, r);
		if (!o || /^[ >+=-]/.test(o) || ma.test(o) || o.includes("|") || !a && o.startsWith("![")) return;
		let s = i(t, r, a);
		if (s !== void 0) return n("paragraph", t, r, { children: s });
	}
	function o(t) {
		if (!t.text.startsWith("|") || !t.text.endsWith("|") || t.text.length < 2) return;
		let n = [], r = t.from;
		for (let i = r + 1; i < t.to; i++) {
			if (e[i] !== "|") continue;
			let t = r + 1, a = i;
			for (; e[t] === " " && t < a;) t++;
			for (; e[a - 1] === " " && a > t;) a--;
			n.push({
				from: t,
				to: a,
				left: r,
				right: i
			}), r = i;
		}
		return n;
	}
	function s(e, t) {
		let r = [];
		for (let a = 0; a < t.length; a++) {
			let o = t[a], s = i(o.from, o.to, "row");
			if (s === void 0) return;
			r.push(n("tableCell", o.left, a === t.length - 1 ? e.to : o.right, { children: s }));
		}
		return n("tableRow", e.from, e.to, { children: r });
	}
	let c = [];
	for (let r = 0; r < t.length;) {
		let i = t[r];
		if (!i.text) {
			r++;
			continue;
		}
		let l = ma.exec(i.text);
		if (l) {
			let e = [], o = l[1].length > 1, s = o ? l[1].at(-1) : l[1];
			for (; r < t.length;) {
				let i = t[r], c = ma.exec(i.text);
				if (!c || (o ? c[1].length === 1 || c[1].at(-1) !== s : c[1] !== s)) break;
				let l = a(i.from + c[0].length, i.to, "item");
				if (l === void 0) return;
				e.push(n("listItem", i.from, i.to, {
					checked: null,
					children: [l]
				})), r++;
			}
			let u = r;
			for (; u < t.length && !t[u].text;) u++;
			if (u < t.length && ma.test(t[u].text)) return;
			c.push(n("list", i.from, t[r - 1].to, {
				ordered: o,
				start: o ? parseInt(l[1], 10) : null,
				children: e
			}));
		} else if (i.text.startsWith("|")) {
			let a = o(i), l = t[r + 1] && o(t[r + 1]);
			if (!a?.length || !l || a.length !== l.length) return;
			let u = [];
			for (let t of l) {
				let n = e.slice(t.from, t.to);
				if (!/^:?-+:?$/.test(n)) return;
				u.push(n.startsWith(":") ? n.endsWith(":") ? "center" : "left" : n.endsWith(":") ? "right" : null);
			}
			let d = s(i, a);
			if (d === void 0) return;
			let f = [d];
			for (r += 2; r < t.length && t[r].text.startsWith("|");) {
				let e = o(t[r]);
				if (!e || e.length !== a.length) return;
				let n = s(t[r], e);
				if (n === void 0) return;
				f.push(n), r++;
			}
			c.push(n("table", i.from, t[r - 1].to, {
				align: u,
				children: f
			}));
		} else {
			let e = a(i.from, i.to);
			if (e === void 0) return;
			c.push(e), r++;
		}
		if (r < t.length && t[r].text) return;
	}
	return c;
}
function ba(e, t, n, r, i) {
	let a = i ?? ga(e, r);
	if (a === void 0) return;
	let o = /* @__PURE__ */ new Map(), s = (i, a, s) => {
		let c = e.slice(i, a);
		if (o.has(c)) return o.get(c);
		if (n?.has(c)) {
			let e = n.get(c);
			return o.set(c, e), s && e !== void 0 && t?.noteInlineReuse?.(s), e;
		}
		if (t) {
			let e = t.readInline(r?.placeholders ? "\0opaque\0" + c : c);
			if (e.hit) return s && e.value !== void 0 && t.noteInlineReuse?.(s), o.set(c, e.value), e.value;
		}
		let l = _a(c, !!r?.placeholders);
		return o.set(c, l), t?.writeInline(r?.placeholders ? "\0opaque\0" + c : c, l), l;
	}, c = 0, l = ya(e, a, (e) => (e !== "rmdOpaque" && (c += 1), null), s);
	if (l === void 0) return;
	let u = l.length;
	return {
		nodeCount: c,
		blockCount: u,
		source: e,
		rows: o,
		overflowAt(t) {
			let n = t + 1;
			if (!Number.isSafeInteger(n) || n < 1 || n > c) return;
			let r = 0, i, o = {};
			try {
				ya(e, a, (e, t, a) => {
					if (e === "rmdOpaque") return null;
					if (r += 1, r === n) throw i = {
						start: t,
						end: a
					}, o;
					return null;
				}, s);
			} catch (e) {
				if (e !== o) throw e;
			}
			return i;
		},
		emit(t) {
			let n = ya(e, a, (e, n, r, i) => t(e, n, r, i), s);
			if (n === void 0) throw Error("Fast Markdown plan became invalid during emission.");
			return n;
		}
	};
}
function xa(e, t, n, r) {
	let i = r?.placeholders ? ga(e, r) : void 0;
	if (r?.placeholders && !i) return;
	let a = r ? "\0" + (r.allowBraces ? "braces" : "") + (r.placeholders ? "opaque" : "") + "\0" + e : e;
	if (t) {
		let e = t.readPlan(a);
		if (e.hit) return e.value !== void 0 && t.notePlanReuse?.(), e.value;
	}
	let o = ba(e, t, n, r, i);
	return t?.writePlan(a, o), o;
}
// src/local/markdown/markdown-blocks.ts
var Sa = "rmdFastBlock", Ca = "[^";
function wa(e, t, n, r, i, a, o) {
	let s = n?.source === e ? n.logicalLineCount : Va(e), c = Ta(e, r, a, o);
	if (c) return {
		tree: za(e, [Ra(0, e.length, c)]),
		stats: {
			fastBlocks: c.blockCount,
			generalBlocks: 0,
			fastCharacters: e.length,
			generalCharacters: 0,
			lines: s
		}
	};
	let l = i?.candidates ?? [], u = [], d = 0;
	for (let t = 0; t < l.length; t++) {
		let n = l[t];
		if (n.from < d || !ka(e, n) || !Aa(e, n, l[t - 1])) continue;
		let i = Ta(e.slice(n.from, n.to), r, a, o ? {
			...o,
			offset: n.from
		} : void 0);
		i && (u.push({
			from: n.from,
			to: n.to,
			plan: i
		}), d = n.to);
	}
	if (!u.length) return Ea(e, t, s);
	let f = t(Na(e, u));
	if (!f || !Array.isArray(f.children) || Pa(f.children, u) || Fa(e, f.children, u)) return Ea(e, t, s);
	let p = 0, m = 0;
	for (let e of u) p += e.to - e.from, m += e.plan.blockCount;
	return {
		tree: za(e, La(f.children, u)),
		stats: {
			fastBlocks: m,
			generalBlocks: f.children.length,
			fastCharacters: p,
			generalCharacters: e.length - p,
			lines: s
		}
	};
}
function Ta(e, t, n, r) {
	if (!e.length || typeof xa != "function") return;
	let i;
	try {
		let a = r?.shield?.(e, r.offset ?? 0);
		if (a !== void 0) {
			let e = xa(a, t, void 0, { allowBraces: !0 });
			if (e) return {
				...e,
				shieldOnly: !0,
				emit() {
					throw Error("Cannot emit an advisory shielding plan");
				}
			};
		}
		i = xa(e, t, n, r);
	} catch {
		return;
	}
	return i && Number.isInteger(i.blockCount) && i.blockCount > 0 && typeof i.emit == "function" && typeof i.overflowAt == "function" ? i : void 0;
}
function Ea(e, t, n) {
	let r = t(e);
	return {
		tree: r,
		stats: {
			fastBlocks: 0,
			generalBlocks: r && Array.isArray(r.children) ? r.children.length : 0,
			fastCharacters: 0,
			generalCharacters: e.length,
			lines: n
		}
	};
}
var Da = /* @__PURE__ */ new WeakMap();
function Oa(e, t = !0) {
	let n = Da.get(e) ?? {}, r = t ? "all" : "outer";
	if (n[r]) return n[r];
	let i = {
		codeRanges: [],
		definitions: [],
		mathLiterals: []
	}, a = [e];
	for (; a.length;) {
		let e = a.pop(), n = e.position?.start?.offset, r = e.position?.end?.offset;
		e.type === "code" && Number.isInteger(n) && Number.isInteger(r) && i.codeRanges.push({
			start: n,
			end: r
		}), e.type === "footnoteDefinition" && Number.isInteger(n) && Number.isInteger(r) && i.definitions.push({
			start: n,
			end: r
		});
		let o = [
			"image",
			"imageReference",
			"definition"
		].includes(e.type);
		if (o || e.type === "link" || e.type === "linkReference") {
			let t = o ? n : e.children?.at(-1)?.position?.end?.offset ?? n;
			Number.isInteger(t) && Number.isInteger(r) && i.mathLiterals.push({
				start: t,
				end: r
			});
		}
		if (!t && e.type === "footnoteDefinition") continue;
		let s = e.children ?? [];
		for (let e = s.length - 1; e >= 0; e--) a.push(s[e]);
	}
	return n[r] = i, Da.set(e, n), i;
}
function ka(e, t) {
	return Number.isInteger(t.from) && Number.isInteger(t.to) && t.from >= 0 && t.to <= e.length && t.from < t.to && (t.from === 0 || Ba(e.charCodeAt(t.from - 1))) && (t.to === e.length || Ba(e.charCodeAt(t.to)));
}
function Aa(e, t, n) {
	if (t.from === 0) return !0;
	let r = ja(e, t.from);
	return Ma(e, r) ? !0 : !(!n || n.to !== r || n.type === "LinkReference" && t.type === "Paragraph" && e.startsWith(Ca, n.from));
}
function ja(e, t) {
	let n = t;
	return e.charCodeAt(n - 1) === 10 && n--, n > 0 && e.charCodeAt(n - 1) === 13 && n--, n;
}
function Ma(e, t) {
	for (let n = t; n > 0;) {
		let t = e.charCodeAt(n - 1);
		if (Ba(t)) return !0;
		if (t !== 32 && t !== 9) return !1;
		n--;
	}
	return !0;
}
function Na(e, t) {
	let n = [], r = 0;
	for (let i of t) n.push(e.slice(r, i.from)), n.push(e.slice(i.from, i.to).replace(/[^\r\n]/g, " ")), r = i.to;
	return n.push(e.slice(r)), n.join("");
}
function Pa(e, t) {
	let n = 0, r = -1;
	for (let i of e) {
		let e = i?.position?.start?.offset, a = i?.position?.end?.offset;
		if (!Number.isInteger(e) || !Number.isInteger(a) || a < e || e < r) return !0;
		for (r = e; n < t.length && t[n].to <= e;) n++;
		let o = t[n];
		if (o && o.from < a && e < o.to) return !0;
	}
	return !1;
}
function Fa(e, t, n) {
	let r = new Set(n.map((e) => e.from)), i = [...t];
	for (; i.length;) {
		let t = i.pop();
		if (t?.type === "footnoteDefinition") {
			let n = t.position?.end?.offset, i = Number.isInteger(n) ? Ia(e, n) : void 0;
			if (i !== void 0 && r.has(i)) return !0;
		}
		let n = t?.children;
		if (Array.isArray(n)) for (let e of n) i.push(e);
	}
	return !1;
}
function Ia(e, t) {
	let n = t;
	for (; n < e.length && (e.charCodeAt(n) === 32 || e.charCodeAt(n) === 9);) n++;
	if (n >= e.length) return;
	let r = e.charCodeAt(n);
	if (r === 10) return n + 1;
	if (r === 13) return n + (e.charCodeAt(n + 1) === 10 ? 2 : 1);
}
function La(e, t) {
	let n = [], r = 0;
	for (let i of e) {
		let e = i.position.start.offset;
		for (; r < t.length && t[r].to <= e;) n.push(Ra(t[r].from, t[r].to, t[r].plan)), r++;
		n.push(i);
	}
	for (; r < t.length;) n.push(Ra(t[r].from, t[r].to, t[r].plan)), r++;
	return n;
}
function Ra(e, t, n) {
	return {
		type: Sa,
		position: {
			start: { offset: e },
			end: { offset: t }
		},
		plan: n
	};
}
function za(e, t) {
	return {
		type: "root",
		position: {
			start: { offset: 0 },
			end: { offset: e.length }
		},
		children: t
	};
}
function Ba(e) {
	return e === 10 || e === 13;
}
function Va(e) {
	if (!e.length) return 0;
	let t = 1;
	for (let n = 0; n < e.length; n++) {
		let r = e.charCodeAt(n);
		r === 10 ? t++ : r === 13 && (t++, e.charCodeAt(n + 1) === 10 && n++);
	}
	return t;
}
// src/local/source/source-context.ts
function Ha(e, t) {
	let n = e[t];
	if (n !== "`" && n !== "~") return;
	let r = 0;
	for (; e[t + r] === n;) r++;
	return r >= 3 ? {
		char: n,
		length: r
	} : void 0;
}
function Ua(e) {
	if (!e.length) return {
		lines: [],
		maxMarkdownDepth: 0,
		potentialDepth: 0,
		fenceSpans: []
	};
	let t = [0];
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		r === "\r" ? (e[n + 1] === "\n" && n++, t.push(n + 1)) : r === "\n" && t.push(n + 1);
	}
	let n = [], r = [], i = [], a = null, o = 0, s = 0;
	for (let c = 0; c < t.length; c++) {
		let l = t[c], u = c + 1 < t.length ? t[c + 1] : e.length;
		for (; u > l && (e[u - 1] === "\r" || e[u - 1] === "\n");) u--;
		let d = e.slice(l, u), f = l, p = 0;
		for (; f < u;) {
			for (; e[f] === " " || e[f] === "	";) p += e[f] === "	" ? 4 : 1, f++;
			if (e[f] === ">") {
				p++, f++;
				continue;
			}
			let t = /^(?:[-+*]|\d{1,9}[.)])(?=[ \t])/.exec(e.slice(f, u));
			if (t) p++, f += t[0].length;
			else break;
		}
		s = Math.max(s, p);
		let m = c === 0 && e.charCodeAt(0) === 65279 ? l + 1 : l, h = 0;
		for (; e[m + h] === " " || e[m + h] === "	";) h++;
		let g = /^[ \t]*$/.test(e.slice(m, u)), _ = m;
		for (let t = 0; t < 3 && e[_] === " "; t++) _++;
		let v = !1;
		if (a) {
			let t = e.slice(_, u), n = Ha(t, 0);
			if (n && n.char === a.char && n.length >= a.length && /^[ \t]*$/.test(t.slice(n.length))) {
				a = null;
				let e = r[r.length - 1];
				e && (e.to = u);
			}
			v = !0;
		} else {
			let t = Ha(e.slice(_, u), 0);
			t && (a = {
				char: t.char,
				length: t.length
			}, v = !0, r.push({
				from: l,
				to: e.length
			}));
		}
		let y = 0, b = 0;
		if (!v && !g) {
			let t = m;
			for (;;) {
				let n = t;
				for (let t = 0; t < 3 && e[n] === " "; t++) n++;
				if (e[n] !== ">") break;
				t = n + 1, e[t] === " " && t++, y++;
			}
			let n = t;
			for (; n < u && (e[n] === " " || e[n] === "	");) n++;
			let r = /^([-+*]|\d{1,9}[.)])(?=[ \t]|$)/.exec(e.slice(n, u)), a = n - t >= 4 && i.length === 0;
			if (r && !a) {
				let e = n - m;
				for (; i.length && i[i.length - 1] >= e;) i.pop();
				i.push(e);
			} else {
				let e = n - t;
				for (; i.length && e < i[i.length - 1];) i.pop();
			}
			b = y + i.length, b > o && (o = b);
		}
		n.push({
			from: l,
			to: u,
			text: d,
			blank: g,
			indent: h,
			quoteDepth: y,
			fenced: v,
			depth: b
		});
	}
	return {
		lines: n,
		maxMarkdownDepth: o,
		potentialDepth: s,
		fenceSpans: r
	};
}
var Wa = class {
	source;
	lineStarts = [0];
	logicalLines;
	factsValue;
	constructor(e) {
		this.source = e;
		for (let t = 0; t < e.length; t++) e[t] === "\n" && this.lineStarts.push(t + 1);
	}
	get logicalLineCount() {
		if (this.logicalLines !== void 0) return this.logicalLines;
		let e = this.source.length ? this.lineStarts.length : 0;
		for (let t = this.source.indexOf("\r"); t >= 0; t = this.source.indexOf("\r", t + 1)) this.source[t + 1] !== "\n" && e++;
		return this.logicalLines = e;
	}
	get facts() {
		return this.factsValue ??= Ua(this.source);
	}
	lineIndexAt(e) {
		let t = 0, n = this.lineStarts.length - 1;
		for (; t < n;) {
			let r = t + n + 1 >>> 1;
			this.lineStarts[r] <= e ? t = r : n = r - 1;
		}
		return t;
	}
	lineStartAt(e) {
		return this.lineStarts[this.lineIndexAt(e)];
	}
}, Ga = class {
	context;
	chunks = [];
	segments = [];
	end = 0;
	recent = 0;
	length = 0;
	constructor(e) {
		this.context = e;
	}
	get segmentCount() {
		return this.segments.length;
	}
	append(e, t, n) {
		if (!e.length) return;
		let r = this.segments.at(-1);
		r && r.step === n && r.source + (r.to - r.from) * n === t ? r.to += e.length : this.segments.push({
			from: this.length,
			to: this.length + e.length,
			source: t,
			step: n
		}), this.chunks.push(e), this.length += e.length;
	}
	generated(e, t) {
		this.append(e, t, 0);
	}
	original(e, t, n = 0, r = !1, i = !1) {
		let { source: a, lineStarts: o } = this.context;
		if (i && e === 0 && a.charCodeAt(0) === 65279 && e++, e >= t) return;
		if (!n) {
			this.append(a.slice(e, t), e, 1);
			return;
		}
		let s = this.context.lineIndexAt(e);
		for (; e < t;) {
			let i = o[s], c = o[s + 1] ?? a.length, l = Math.min(t, c), u = r ? /^(?:[ \t]{0,3}>[ \t]?)+/.exec(a.slice(i, c))?.[0].length ?? 0 : 0, d = 0;
			for (; d < n && (a[i + u] === " " || a[i + u] === "	");) u++, d++;
			let f = Math.min(l, Math.max(e, i + u));
			this.append(a.slice(f, l), f, 1), e = l, s++;
		}
	}
	finish(e) {
		this.end = e;
	}
	text() {
		return this.chunks.join("");
	}
	at(e, t) {
		if (e === this.length) return this.end;
		if (e < 0 || e > this.length || !Number.isInteger(e)) return t;
		let n = this.segments[this.recent];
		if (!n || e < n.from || e >= n.to) {
			let t = 0, r = this.segments.length - 1;
			for (; t < r;) {
				let n = t + r + 1 >>> 1;
				this.segments[n].from <= e ? t = n : r = n - 1;
			}
			this.recent = t, n = this.segments[t];
		}
		return n ? n.source + (e - n.from) * n.step : t;
	}
}, Ka = class extends Error {
	kind;
	limit;
	start;
	end;
	constructor(e, t, n, r) {
		super(e === "parse-work" ? `Parsing work exceeds the limit of ${t}.` : `Markdown nesting exceeds the ${t}-level limit.`), this.kind = e, this.limit = t, this.start = n, this.end = r, this.name = "ParseBudgetError";
	}
}, qa = class {
	limits;
	usedWork = 0;
	observedDepth = 0;
	constructor(e) {
		this.limits = e;
	}
	get parseWork() {
		return this.usedWork;
	}
	get maxDepth() {
		return this.observedDepth;
	}
	charge(e, t, n) {
		if (!(!Number.isFinite(e) || e <= 0) && (this.usedWork += Math.floor(e), this.usedWork > this.limits.maxParseWork)) throw new Ka("parse-work", this.limits.maxParseWork, t, Math.max(t + 1, n));
	}
	observeDepth(e, t, n) {
		if (!Number.isFinite(e) || e <= 0) e > this.observedDepth && (this.observedDepth = e);
		else if (e > this.observedDepth && (this.observedDepth = e), e > this.limits.maxMarkdownDepth) throw new Ka("markdown-depth", this.limits.maxMarkdownDepth, t, Math.max(t + 1, n));
	}
}, Ja = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, Ya = 128, Xa = "local.recovery.unclosed", Za = "local.recovery.mismatch", Qa = "local.recovery.stray-close";
function $a(e, t) {
	let n = e.lines, r = 0, i = n.length - 1;
	for (; r < i;) {
		let e = r + i + 1 >>> 1;
		n[e].from <= t ? r = e : i = e - 1;
	}
	return r;
}
function eo(e, t) {
	let n = ea(e, t, e.length);
	return n < 0 ? t + 2 : n;
}
function to(e, t) {
	let n = e.slice(t.from, t.to), r = 0;
	for (;;) {
		let e = r;
		for (let t = 0; t < 3 && n[e] === " "; t += 1) e += 1;
		if (n[e] !== ">") break;
		e += 1, n[e] === " " && (e += 1), r = e;
	}
	let i = r;
	for (; n[i] === " " || n[i] === "	";) i += 1;
	if (i - r > 3 && t.depth === 0) return !1;
	let a = /^(?:[-+*]|\d{1,9}[.)])[ \t]+/.exec(n.slice(i));
	return a && (i += a[0].length), /^#{1,6}(?:[ \t]+|$)/.test(n.slice(i));
}
function no(e) {
	return e !== void 0 && (e.blank || /^[ \t]*(?:>[ \t]*)*$/.test(e.text));
}
function ro(e, t, n) {
	for (let r = e.length - 1; r >= 0; --r) if (n(), t(e[r])) return r;
	return -1;
}
function io(e, t) {
	let n = [], r = [];
	t.charge(e.length, 0, Math.max(1, e.length));
	let i = (e, t, r, i) => {
		r.end <= r.start || n.push({
			code: e,
			causeRange: {
				start: t.start,
				end: t.end
			},
			affectedRange: {
				start: r.start,
				end: r.end
			},
			action: "literal-fallback",
			boundary: i
		});
	}, a = (e, n) => n === "theme" ? "theme" : t.isKnown(e) ? "rmd" : t.isHtmlName(n) ? "html" : Ja.test(e) ? "rmd" : "ignore", o = (e, t) => {
		let n = r[e + 1];
		if (!n) return;
		let a = r.slice(e + 1).filter((e) => e.kind === "rmd" && e.structural);
		if (!a.length) return;
		let o = n.start;
		for (let e of a) i(Za, {
			start: e.start,
			end: e.end
		}, {
			start: o,
			end: t
		}, "container-end");
	}, s = 0, c = 0;
	for (; c < e.length;) {
		for (; s < t.definitions.length && t.definitions[s].end <= c;) s += 1;
		let l = t.definitions[s];
		if (l && l.start <= c) {
			c = l.end;
			continue;
		}
		let u = r.length > 0;
		if (!u) {
			let n = t.codeEndAt(c);
			if (n !== null && n > c) {
				c = Math.min(n, e.length);
				continue;
			}
		}
		let d = ra(e, c, e.length);
		if (d !== null) {
			c = d;
			continue;
		}
		let f = t.protectedEnd(c, u);
		if (f !== null && f > c) {
			c = Math.min(f, e.length);
			continue;
		}
		if (e.startsWith("<!--", c)) {
			c = Se(e, c, e.length);
			continue;
		}
		if (e.startsWith("{{", c)) {
			c = eo(e, c);
			continue;
		}
		if (e[c] !== "<") {
			c += 1;
			continue;
		}
		let p = t.readTag(c);
		if (!p) {
			c += 1;
			continue;
		}
		let m = p.name.toLowerCase(), h = a(p.name, m), g = Math.max(p.end, c + 1);
		if (h === "theme" || h === "ignore" || p.name.length > Ya) {
			c = g;
			continue;
		}
		if (!p.complete) {
			if (h === "html" || p.closing && !t.isKnown(p.name) && !t.beginsLine(c) || !p.closing && !t.isKnown(p.name) && !t.beginsLine(c)) {
				c = g;
				continue;
			}
			let n = null;
			for (let i = e.indexOf("<", g); i >= 0; i = e.indexOf("<", i + 1)) {
				if (t.facts.lines[$a(t.facts, i)]?.fenced || t.codeEndAt(i) !== null) continue;
				if (e.startsWith("<!--", i)) {
					let t = e.indexOf("-->", i + 4);
					if (t < 0) break;
					i = t + 2;
					continue;
				}
				let a = /^<\/([a-z][a-z0-9-]*)\s*>/.exec(e.slice(i, i + 256));
				if (a && ro(r, (e) => e.name === a[1], () => t.charge(1, i, i + a[0].length)) >= 0) {
					n = i;
					break;
				}
			}
			let a = n ?? ao(e, c, c, t);
			if (i(Xa, {
				start: c,
				end: g
			}, {
				start: c,
				end: a ?? e.length
			}, n === null ? a === null ? "eof" : "fragment" : "container-end"), n !== null) {
				c = n;
				continue;
			}
			break;
		}
		if (h === "html") {
			if (p.closing) {
				let e = ro(r, (e) => e.kind === "html" && e.lower === m, () => t.charge(1, c, g));
				e >= 0 && (o(e, c), r.length = e), c = g;
				continue;
			}
			if (p.self || t.isVoidHtml(m)) {
				c = g;
				continue;
			}
			if (ke.has(m)) {
				let n = t.rawHtmlEnd(m, p.end, u);
				c = n === null ? e.length : Math.max(n, g);
				continue;
			}
			r.push({
				name: p.name,
				lower: m,
				start: c,
				end: p.end,
				kind: "html",
				known: !1,
				structural: !1,
				complete: !0,
				pendingMark: n.length
			}), c = g;
			continue;
		}
		if (p.closing) {
			let e = ro(r, (e) => e.kind === "rmd" && e.name === p.name, () => t.charge(1, c, g));
			if (e < 0) {
				if (!t.isPaired(p.name)) {
					c = g;
					continue;
				}
				i(Qa, {
					start: c,
					end: p.end
				}, {
					start: c,
					end: p.end
				}, "token");
			} else {
				let t = r[e];
				t.known ? o(e, c) : n.length = t.pendingMark, r.length = e;
			}
			c = g;
			continue;
		}
		if (p.self || !t.isPaired(p.name)) {
			c = g;
			continue;
		}
		let _ = t.isKnown(p.name);
		r.push({
			name: p.name,
			lower: m,
			start: c,
			end: p.end,
			kind: "rmd",
			known: _,
			structural: _ || t.beginsLine(c),
			complete: !0,
			pendingMark: n.length
		}), c = g;
	}
	let l = -1;
	for (let n of r) {
		if (n.kind !== "rmd" || !n.structural || n.start < l) continue;
		let r = e.length, a = "eof";
		if (n.complete) {
			let i = oo(e, n.end, n.start, t);
			i !== null && (r = i, a = "heading");
		}
		if (a === "eof") {
			let i = ao(e, n.end, n.start, t);
			i !== null && (r = i, a = "fragment");
		}
		i(Xa, {
			start: n.start,
			end: n.end
		}, {
			start: n.start,
			end: r
		}, a), l = r;
	}
	return so(n);
}
function ao(e, t, n, r) {
	let { facts: i } = r, a = i.lines[$a(i, n)];
	if (!a || a.quoteDepth === 0 && a.depth === 0) return null;
	let o = $a(i, Math.min(t, e.length)) + 1;
	for (; o < i.lines.length; o += 1) {
		let e = i.lines[o];
		if (!(!e || e.blank || e.fenced) && (e.quoteDepth < a.quoteDepth || e.depth < a.depth)) return e.from;
	}
	return null;
}
function oo(e, t, n, r) {
	let { facts: i } = r, a = i.lines;
	if (!a.length) return null;
	let o = a[$a(i, n)], s = $a(i, Math.min(t, e.length)) + 1;
	if (s >= a.length) return null;
	r.charge(Math.max(1, e.length - t), Math.max(0, t), e.length);
	let c = 0, l = a[s].from;
	for (; l < e.length;) {
		for (; c < r.definitions.length && r.definitions[c].end <= l;) c += 1;
		let t = r.definitions[c];
		if (t && t.start <= l) {
			l = t.end;
			continue;
		}
		s = $a(i, l);
		let n = a[s];
		if (n && l === n.from) {
			let t = s > 0 ? a[s - 1] : void 0;
			if (n.quoteDepth === o.quoteDepth && n.depth === o.depth && !n.fenced && no(t) && to(e, n)) return n.from;
		}
		let u = n !== void 0 && n.depth > 0, d = r.codeEndAt(l);
		if (d !== null && d > l) {
			l = Math.min(d, e.length);
			continue;
		}
		let f = ra(e, l, e.length);
		if (f !== null) {
			l = f;
			continue;
		}
		let p = r.protectedEnd(l, u);
		if (p !== null && p > l) l = Math.min(p, e.length);
		else if (e.startsWith("<!--", l)) l = Se(e, l, e.length);
		else if (e.startsWith("{{", l)) l = eo(e, l);
		else if (e[l] === "<") {
			let e = r.readTag(l);
			if (!e) {
				l += 1;
				continue;
			}
			if (!e.complete) return null;
			let t = e.name.toLowerCase();
			if (!e.closing && ke.has(t) && r.isHtmlName(t) && !e.self) {
				let n = r.rawHtmlEnd(t, e.end, u);
				if (n === null) return null;
				l = Math.max(n, l + 1);
				continue;
			}
			l = Math.max(e.end, l + 1);
		} else l += 1;
	}
	return null;
}
function so(e) {
	let t = e.map((e, t) => ({
		record: e,
		index: t
	})).sort((e, t) => e.record.affectedRange.start - t.record.affectedRange.start || e.record.affectedRange.end - t.record.affectedRange.end || e.record.causeRange.start - t.record.causeRange.start || e.index - t.index), n = [];
	for (let { record: e } of t) {
		let t = n[n.length - 1];
		t && e.affectedRange.start < t.affectedRange.end ? e.affectedRange.end > t.affectedRange.end && (t.affectedRange = {
			start: t.affectedRange.start,
			end: e.affectedRange.end
		}) : n.push({
			code: e.code,
			causeRange: {
				start: e.causeRange.start,
				end: e.causeRange.end
			},
			affectedRange: {
				start: e.affectedRange.start,
				end: e.affectedRange.end
			},
			action: e.action,
			boundary: e.boundary
		});
	}
	let r = n.map(({ affectedRange: e }) => e), i = /* @__PURE__ */ new Map();
	for (let e of r) i.set(e.start, e.end);
	return {
		recoveries: n,
		ranges: r,
		byStart: i
	};
}
// src/local/html/html-details.ts
var co = /^\s*$/;
function lo(e) {
	return e.type !== "text" || !co.test(e.value ?? "");
}
function uo(e, t) {
	let n = t[0]?.range, r = t[t.length - 1]?.range;
	return n !== void 0 && r !== void 0 && Number.isInteger(n.start) && Number.isInteger(r.end) && n.start >= e.range.start && r.end <= e.range.end && n.start <= r.end ? {
		...e,
		children: t,
		range: {
			start: n.start,
			end: r.end
		}
	} : {
		...e,
		children: t
	};
}
function fo(e) {
	let t = e.children;
	if (!t || t.length === 0) return null;
	let n = t.findIndex((e) => e.type === "summary");
	if (n < 0) return null;
	let r = t.filter((e, t) => t !== n);
	return r.some(lo) ? {
		summary: t[n],
		body: uo(e, r)
	} : { summary: t[n] };
}
function po(e) {
	let t = e.findIndex((e) => e.type === "summary");
	if (t >= 0) return {
		summary: e[t],
		body: e.filter((e, n) => n !== t)
	};
	let n = [], r;
	for (let t of e) {
		if (r === void 0 && t.type === "paragraph") {
			let e = fo(t);
			if (e) {
				r = e.summary, e.body && n.push(e.body);
				continue;
			}
		}
		n.push(t);
	}
	return r === void 0 ? { body: n } : {
		summary: r,
		body: n
	};
}
function mo(e) {
	let { summary: t, body: n } = po(e);
	return t === void 0 ? n : [t, ...n];
}
// src/local/parsing/parser-core.ts
var ho = "", go = "", _o = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, vo = _o, yo = te, bo = /* @__PURE__ */ new Set([
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"div",
	"details",
	"blockquote",
	"pre",
	"ul",
	"ol",
	"li"
]), xo = /* @__PURE__ */ new Set([
	"paragraph",
	"heading",
	"div",
	"details",
	"blockquote",
	"code",
	"list",
	"listItem",
	"thematicBreak",
	"htmlTable"
]), So = /* @__PURE__ */ new Set([
	"local.recovery.unclosed",
	"local.recovery.mismatch",
	"local.recovery.stray-close",
	"local.html.repair",
	"local.html.literal"
]), Co = /* @__PURE__ */ new Set([
	"area",
	"base",
	"br",
	"col",
	"embed",
	"hr",
	"img",
	"input",
	"link",
	"meta",
	"param",
	"source",
	"track",
	"wbr"
]);
function wo(e, t, n) {
	let r = Object.create(null), i = [], a = [], o = 0;
	for (; o < e.length;) {
		for (; o < e.length && /\s/.test(e[o]);) o += 1;
		if (o >= e.length || e[o] === "/") break;
		let s = o, c = /^[A-Za-z_:][A-Za-z0-9_.:-]*/.exec(e.slice(o));
		if (!c) {
			o += 1;
			continue;
		}
		let l = c[0].toLowerCase();
		for (o += c[0].length; o < e.length && /\s/.test(e[o]);) o += 1;
		let u = "true";
		if (e[o] === "=") {
			for (o += 1; o < e.length && /\s/.test(e[o]);) o += 1;
			let r = e[o];
			if (r === "\"" || r === "'") {
				o += 1;
				let i = e.indexOf(r, o);
				if (i < 0) {
					a.push({
						name: l,
						value: "",
						start: t + s,
						end: t + e.length
					});
					break;
				}
				u = n(e.slice(o, i)), o = i + 1;
			} else {
				let t = o;
				for (; o < e.length && !/[\s>]/.test(e[o]);) o += 1;
				u = n(e.slice(t, o));
			}
		}
		let d = {
			name: l,
			value: u,
			start: t + s,
			end: t + o
		};
		Object.hasOwn(r, l) || (r[l] = u), i.push(d);
	}
	return {
		attrs: r,
		entries: i,
		invalid: a
	};
}
var To = 128, Eo = Math.min(5e4, a), Do = 100, Oo = 1e3;
function ko() {
	let e = globalThis.performance;
	return e && typeof e.now == "function" ? e.now() : Date.now();
}
function Ao(e) {
	return Math.round(e * 1e3) / 1e3;
}
var jo = /(?:^|[\r\n])(?:[ \t]{0,3}>|[ \t]*(?:[-+*]|\d{1,9}[.)])(?=[ \t]|[\r\n]|$))/;
function Mo(e) {
	return jo.test(e) || e.charCodeAt(0) === 65279 && jo.test(e.slice(1));
}
var No = yn().use($i), Po = /* @__PURE__ */ new WeakMap();
function Fo(e) {
	let t = e?.markdownPlugins;
	if (!t?.length) return No;
	let n = Po.get(e);
	if (n === void 0) {
		n = yn().use($i);
		for (let e of t) n.use(e);
		Po.set(e, n);
	}
	return n;
}
var Io = class extends Error {
	code;
	start;
	end;
	key;
	params;
	constructor(e, t, n, r, i = e, a) {
		super(t), this.code = e, this.start = n, this.end = r, this.key = i, this.params = a, this.name = "LocalBudgetError";
	}
};
function Lo(e, t, r, i, a) {
	let o = [];
	if (typeof e != "string" || e.length > 1e6) {
		let t = typeof e == "string" ? y("local.budget.document", { limit: n }) : y("local.parse.source");
		return {
			nodes: [],
			diagnostics: [{
				code: typeof e == "string" ? "local.budget" : "local.parse",
				message: typeof e == "string" ? `Document exceeds the ${n}-character limit.` : "Document source must be a string.",
				severity: "error",
				range: {
					start: 0,
					end: typeof e == "string" && e.length ? 1 : 0
				},
				line: 1,
				column: 1,
				messageKey: t.key,
				...t.params ? { params: t.params } : {}
			}]
		};
	}
	if (!t.ok) return {
		nodes: [],
		diagnostics: [{
			code: "local.options.invalid",
			message: t.message,
			severity: "error",
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: t.key,
			...t.detail === void 0 ? {} : { params: { detail: t.detail } }
		}]
	};
	let s = t.maxSyntaxNodes, c = t.strict !== !1, l = new qa({
		maxParseWork: t.maxParseWork,
		maxMarkdownDepth: t.maxMarkdownDepth
	}), u = t.markdownBreaks, f = t.schemaByName, p = t.externalComponentNames, m = (e) => f.get(e)?.form === "inline", h = f, g = [...f.keys()], _ = t.capabilities, v = _?.html, b = _?.markdownStructure, x = v?.nativeTagNames ?? /* @__PURE__ */ new Set(), S = v?.decodeEntities ?? ((e) => e), C = Fo(_), w = r?.source === e ? r : new Wa(e), { lineStarts: T } = w, E = {
		markdownCalls: 0,
		fastBlocks: 0,
		generalBlocks: 0,
		fastCharacters: 0,
		generalCharacters: 0,
		mappingSegments: 0,
		sourceLines: T.length,
		maxComponentDepth: 0
	}, D = i?.counters(), te = ko(), ne = 0, A = 0, ie = 0, oe = /* @__PURE__ */ new Map(), se = /* @__PURE__ */ new Set(), j = (n) => {
		if (se.has(n) || !Mo(n)) return;
		se.add(n);
		let r = (n === e ? w : new Wa(n)).facts, i = r.maxMarkdownDepth;
		if (r.potentialDepth > t.maxMarkdownDepth || i > t.maxMarkdownDepth) {
			if (b) {
				let e = b(n);
				oe.set(n, e), i = e.maxDepth;
			} else {
				i = 0;
				let e = [{
					node: M(n),
					depth: 0
				}];
				for (; e.length;) {
					let n = e.pop(), r = n.depth + +(n.node.type === "blockquote" || n.node.type === "list");
					if (i = Math.max(i, r), i > t.maxMarkdownDepth) break;
					for (let t of n.node.children ?? []) e.push({
						node: t,
						depth: r
					});
				}
			}
		}
		l.observeDepth(i, 0, Math.max(1, n.length));
	}, ce = () => {
		if (E.parseWork = l.parseWork, E.maxMarkdownDepth = l.maxDepth, i) {
			let e = i.counters();
			E.cacheHits = e.hits - (D?.hits ?? e.hits), E.cacheMisses = e.misses - (D?.misses ?? e.misses), E.reusedBlocks = e.reusedBlocks - (D?.reusedBlocks ?? e.reusedBlocks), E.reusedRows = e.reusedRows - (D?.reusedRows ?? e.reusedRows), E.reusedItems = e.reusedItems - (D?.reusedItems ?? e.reusedItems), E.reusedAst = e.reusedAst - (D?.reusedAst ?? e.reusedAst);
		}
		E.timings = {
			shieldMs: Ao(ne),
			regionMs: Ao(A),
			convertMs: Ao(ie),
			totalMs: Ao(ko() - te)
		};
	}, M = (e) => {
		let t = i?.readTree(e);
		if (t?.hit) return t.value;
		let n = C.parse(e);
		return i?.writeTree(e, n), n;
	}, le = (e, t = !0, n = { allowBraces: !0 }) => {
		if (l.charge(e.length + 1, 0, Math.max(1, e.length)), j(e), !t) {
			let t = M(e);
			return E.markdownCalls++, E.generalBlocks += t.children.length, E.generalCharacters += e.length, t;
		}
		let r = oe.get(e);
		r === void 0 && b && (r = b(e), oe.set(e, r));
		let { tree: o, stats: s } = wa(e, M, w, i, r, a, n);
		return E.markdownCalls++, E.fastBlocks += s.fastBlocks, E.generalBlocks += s.generalBlocks, E.fastCharacters += s.fastCharacters, E.generalCharacters += s.generalCharacters, o;
	}, ue = 0, de = 0, fe = 0, pe = /* @__PURE__ */ new Set(), N = (e, t, n, r = {}) => {
		if (de >= s) throw new Io("local.budget", `Syntax nodes exceed the limit of ${s}.`, t, n, "local.budget.nodes", { limit: s });
		return de += 1, {
			type: e,
			id: `local-${ue++}`,
			range: {
				start: t,
				end: n
			},
			...r
		};
	};
	try {
		l.charge(e.length, 0, Math.max(1, e.length)), j(e);
		let t = pa(e, u, N);
		if (t !== void 0) return E.fastBlocks = t.length, E.fastCharacters = e.length, ce(), {
			nodes: t,
			diagnostics: o,
			syntaxNodes: de,
			work: E
		};
	} catch (e) {
		if (e instanceof Ka) return we(e), ce(), {
			nodes: [],
			diagnostics: o,
			work: E
		};
		if (!(e instanceof Io)) throw e;
		return V(e.code, e.message, e.start, e.end, {
			key: e.key,
			params: e.params
		}), {
			nodes: [],
			diagnostics: o
		};
	}
	let me = new Set(e.match(/* @__PURE__ */ RegExp("[0-9]+", "g")) ?? []), he = [], P = [], F = [], ge = [];
	function I(e, t) {
		let n = 0, r = e.length - 1;
		for (; n <= r;) {
			let i = n + r >>> 1, a = e[i];
			if (t < a.start) r = i - 1;
			else if (t >= a.end) n = i + 1;
			else return !0;
		}
		return !1;
	}
	let _e = [], L = +(e.charCodeAt(0) === 65279), R;
	try {
		if (R = le(e.slice(L), !0, {
			allowBraces: !0,
			shield(e, t) {
				if (!e.includes("{{")) return;
				let n = [], r = 0, i = 0;
				for (; i < e.length;) {
					let a = e.indexOf("{{", i);
					if (a < 0) break;
					let o = rt(a + t + L, t + L + e.length) - t - L;
					if (o <= a || /[\r\n]/.test(e.slice(a, o))) return;
					n.push(e.slice(r, a), "v".repeat(o - a)), r = i = o;
				}
				if (n.length) return n.push(e.slice(r)), n.join("");
			}
		}), !e.includes("{{") && R.children.length === 1 && R.children[0].type === "rmdFastBlock") {
			let e = R.children[0].plan.overflowAt(s);
			if (e) throw new Io("local.budget", `Syntax nodes exceed the limit of ${s}.`, e.start + L, e.end + L, "local.budget.nodes", { limit: s });
		}
		let t = Oa(R), n = (e) => ({
			start: e.start + L,
			end: e.end + L
		});
		for (let e of t.codeRanges) he.push(n(e));
		for (let e of t.definitions) e.end > e.start && _e.push(n(e));
		for (let e of t.mathLiterals) ge.push(n(e));
		ne = ko() - te;
	} catch (e) {
		return e instanceof Ka ? (we(e), ce(), {
			nodes: [],
			diagnostics: o,
			work: E
		}) : e instanceof Io ? (V(e.code, e.message, e.start, e.end, {
			key: e.key,
			params: e.params
		}), {
			nodes: [],
			diagnostics: o,
			work: E
		}) : (V("local.parse", { key: "local.parse.markdown" }, 0, void 0), {
			nodes: [],
			diagnostics: o
		});
	}
	_e.sort((e, t) => e.start - t.start || t.end - e.end), ge.sort((e, t) => e.start - t.start);
	let z = [];
	for (let e of _e) {
		let t = z[z.length - 1];
		t && e.start < t.end ? e.end > t.end && (t.end = e.end) : z.push({ ...e });
	}
	let ye = (e) => {
		let t = 0, n = he.length - 1;
		for (; t <= n;) {
			let r = t + n >> 1, i = he[r];
			if (e < i.start) n = r - 1;
			else if (e >= i.end) t = r + 1;
			else return i.end;
		}
		return null;
	}, B = 0;
	function be(t, n, r, i, a = i + 1, s) {
		if (o.length >= 100) {
			if (r === "warning") return;
			let e = o.length - 1;
			for (; e >= 0 && o[e].severity !== "warning";) --e;
			if (e < 0) return;
			o.splice(e, 1);
		}
		let c = Math.max(0, Math.min(e.length, i)), l = Math.max(c, Math.min(e.length, Math.max(c, a))), u = 0, f = T.length - 1;
		for (; u < f;) {
			let e = Math.ceil((u + f) / 2);
			T[e] <= c ? u = e : f = e - 1;
		}
		let p = u + 1, m = n.length > 2e3 ? `${n.slice(0, d - 1)}…` : n, h = y(s?.key ?? t, s?.params);
		o.push({
			code: t,
			message: m,
			severity: r,
			range: {
				start: c,
				end: l
			},
			line: p,
			column: c - T[u] + 1,
			messageKey: h.key,
			...h.params ? { params: h.params } : {}
		});
	}
	function xe(e) {
		return typeof e == "string" ? { text: e } : {
			text: O(e),
			details: e
		};
	}
	function V(e, t, n, r = n + 1, i) {
		let a = xe(t);
		be(e, a.text, "error", n, r, a.details ?? i);
	}
	function H(e, t, n, r = n + 1, i) {
		let a = xe(t);
		be(e, a.text, "warning", n, r, a.details ?? i);
	}
	function we(e) {
		V("local.budget", {
			key: e.kind === "parse-work" ? "local.budget.parse-work" : "local.budget.markdown-depth",
			params: { limit: e.limit }
		}, e.start, e.end);
	}
	let De, U, Oe = 0, Ae = 0, Me, Ne = 0;
	function Pe(t) {
		let n = e.startsWith("</theme", t), r = !n && e.startsWith("<theme", t);
		if (!n && !r) return !1;
		let i = e[t + (n ? 7 : 6)];
		return i !== void 0 && (i === ">" || i === "/" || /\s/.test(i));
	}
	function W(t, n) {
		let r = /^<(\/?)theme(?=[\s/>])/.exec(e.slice(t, n));
		if (!r) return null;
		let i = t + r[0].length, a = e.indexOf("\n", i), o = a < 0 ? n : Math.min(n, a), s = "", c = i;
		for (; c < o; c += 1) {
			let t = e[c];
			if (s) t === s && (s = "");
			else if (t === "\"" || t === "'") s = t;
			else if (t === ">") break;
		}
		let l = !!r[1];
		if (c >= o) {
			let n = o;
			return {
				start: t,
				end: n,
				rest: e.slice(i, n),
				closing: l,
				selfClosing: !1,
				unclosed: !0
			};
		}
		let u = e.slice(i, c);
		return {
			start: t,
			end: c + 1,
			rest: u,
			closing: l,
			selfClosing: /\/\s*$/.test(u),
			unclosed: !1
		};
	}
	function Re(t, n) {
		let r = t;
		for (; r < n;) {
			let t = e[r];
			if (t.charCodeAt(0) === 65279 || t === " " || t === "	" || t === "\r" || t === "\n") r += 1;
			else if (e.startsWith("<!--", r)) {
				let t = e.indexOf("-->", r + 4);
				if (t < 0 || t + 3 > n) return -1;
				r = t + 3;
			} else break;
		}
		return r;
	}
	function ze(t) {
		if (t.unclosed) return !1;
		let n = t.end;
		for (; n < e.length && (e[n] === " " || e[n] === "	" || e[n] === "\r");) n += 1;
		return n >= e.length || e[n] === "\n";
	}
	function Be(e) {
		if (/\{\{|\}\}/.test(e)) return {
			code: "local.theme.expression",
			key: "local.theme.expression",
			message: "Theme names must be static text, not expressions."
		};
		let t = e.replace(/\/\s*$/, ""), n = /^\s*name\s*=\s*(?:"([^"]*)"|'([^']*)')\s*$/.exec(t);
		if (!n) return /\bname\s*=/.test(t) ? {
			code: "local.theme.attribute",
			key: "local.theme.attribute",
			message: "Theme declarations only accept a quoted name attribute."
		} : {
			code: "local.theme.name",
			key: "local.theme.name.missing",
			message: "A theme declaration requires a quoted name attribute."
		};
		let r = n[1] ?? n[2] ?? "";
		return re(r) ? { name: r } : {
			code: "local.theme.name",
			key: "local.theme.name.invalid",
			params: {
				name: r,
				limit: 64
			},
			message: `Theme name "${r}" must use lowercase letters, digits and single hyphens (maximum 64 characters).`
		};
	}
	function Ve(e) {
		return e.replace(/&(quot|apos|amp|lt|gt);/g, (e, t) => ({
			quot: "\"",
			apos: "'",
			amp: "&",
			lt: "<",
			gt: ">"
		})[t]);
	}
	function He(e, t) {
		let n = Object.create(null), r = 0;
		for (; r < e.length;) {
			for (; r < e.length && /\s/.test(e[r]);) r++;
			if (r >= e.length || e[r] === "/") break;
			let i = r, a = /^[A-Za-z][A-Za-z0-9_-]*/.exec(e.slice(r));
			if (!a) {
				for (V("local.attribute", { key: "local.attribute.format" }, t + r, void 0); r < e.length && !/\s/.test(e[r]);) r++;
				continue;
			}
			let o = a[0];
			for (r += o.length, o.length > To ? V("local.budget.name", {
				key: "local.budget.name.attribute",
				params: { limit: To }
			}, t + i, t + r) : vo.test(o) || V("local.attribute.name", {
				key: "local.attribute.name",
				params: { name: o }
			}, t + i, t + r); r < e.length && /\s/.test(e[r]);) r++;
			let s = "true";
			if (e[r] === "=") {
				for (r++; r < e.length && /\s/.test(e[r]);) r++;
				let n = e[r++];
				if (n !== "\"" && n !== "'") {
					V("local.attribute", {
						key: "local.attribute.value-quoted",
						params: { name: o }
					}, t + Math.max(0, r - 1), void 0);
					break;
				}
				let i = e.indexOf(n, r);
				if (i < 0) {
					V("local.attribute", {
						key: "local.attribute.closing-quote",
						params: { name: o }
					}, t + Math.max(0, r - 1), void 0);
					break;
				}
				s = Ve(e.slice(r, i)), r = i + 1;
			}
			if (Object.hasOwn(n, o) ? V("local.attribute.duplicate", {
				key: "local.attribute.duplicate",
				params: { name: o }
			}, t + i, t + r) : n[o] = s, r < e.length && !/\s|\//.test(e[r])) {
				V("local.attribute", { key: "local.attribute.separator" }, t + r, void 0);
				break;
			}
		}
		return n;
	}
	function Ue(t, n) {
		let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, n));
		if (!r) return null;
		let i = t + r[0].length, a = n, o = e[i];
		if ((o === " " || o === "	" || o === "\n" || o === "\r") && !h.has(r[2].toLowerCase()) && !G(t)) {
			let t = e.indexOf("\n", i);
			t >= 0 && (a = Math.min(n, t));
		}
		let s = Fe(e, i, a), c = r[2];
		if (s < 0) return {
			name: c,
			closing: !!r[1],
			self: !1,
			start: t,
			end: a,
			attrs: {},
			head: i,
			unclosed: !0
		};
		let l = s - 1;
		c.length > To && V("local.budget.name", {
			key: "local.budget.name.tag",
			params: { limit: To }
		}, t, t + 1 + c.length);
		let u = e.slice(i, l);
		return r[1] ? (u.trim() && V("local.tag.closing", {
			key: "local.tag.closing",
			params: { name: c }
		}, t, s), {
			name: c,
			closing: !0,
			self: !1,
			start: t,
			end: s,
			attrs: {},
			head: i,
			unclosed: !1
		}) : {
			name: c,
			closing: !1,
			self: /\/\s*$/.test(u),
			start: t,
			end: s,
			attrs: h.has(c.toLowerCase()) ? He(u, i) : {},
			head: i,
			unclosed: !1
		};
	}
	function We(t, n) {
		let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, n));
		if (!r) return null;
		let i = t + r[0].length, a = n, o = e[i];
		if ((o === " " || o === "	" || o === "\n" || o === "\r") && !h.has(r[2].toLowerCase()) && !G(t)) {
			let t = e.indexOf("\n", i);
			t >= 0 && (a = Math.min(n, t));
		}
		let s = Fe(e, i, a);
		if (s < 0) return null;
		let c = e.slice(i, s - 1);
		return {
			name: r[2],
			closing: !!r[1],
			self: !r[1] && /\/\s*$/.test(c),
			end: s
		};
	}
	function Ge(t, n, r, i) {
		if (!c && i && ke.has(i.toLowerCase())) return n;
		let a = /\r?\n[\t ]*\r?\n/.exec(e.slice(t, n)), o = a ? t + a.index : n;
		if (r) {
			let n = RegExp(`</${r}\\s*>`, "g");
			n.lastIndex = t;
			let i = n.exec(e);
			i && i.index < o && (o = i.index);
		}
		return o;
	}
	function G(t) {
		let n = w.lineStartAt(t);
		return /^[ \t]*$/.test(e.slice(n, t));
	}
	function Ke(t, n) {
		if (e[t] !== "[" || e[t + 1] !== "^") return null;
		let r = t + 2, i = Math.min(n, t + 2 + Oo);
		for (; r < i; r++) {
			let t = e[r];
			if (t === "\\" && /[!-/:-@\[\]\\^_`{|}~]/.test(e[r + 1] ?? "")) r += 1;
			else {
				if (t === "]") break;
				if (t === "[" || t === "\n" || t === "\r") return null;
			}
		}
		if (r >= i || e[r] !== "]") return null;
		let a = e.slice(t + 2, r);
		if (!a.trim()) return null;
		let o = ca(a);
		return o ? {
			label: a,
			identifier: o,
			openEnd: t + 2,
			closeEnd: r + 1
		} : null;
	}
	function qe(t) {
		let n = Ke(t, e.length);
		return !n || e[n.closeEnd] !== ":" ? null : {
			label: n.label,
			identifier: n.identifier,
			bodyStart: n.closeEnd + 1
		};
	}
	function K(t, n, r = !1) {
		if (v === void 0) return null;
		let i = /^<(\/?)([A-Za-z][A-Za-z0-9]*)(?=[\s/>])/.exec(e.slice(t, Math.min(n, t + 64)));
		if (!i) return null;
		let a = i[2].toLowerCase();
		if (!yo.has(a) && !(r && ve.has(a))) return null;
		let o = t + i[0].length, s = Fe(e, o, n);
		if (s < 0) return null;
		let c = s - 1, l = e.slice(o, c), u = !!i[1], d = u ? {
			attrs: Object.create(null),
			entries: [],
			invalid: []
		} : wo(l, o, S);
		return {
			lower: a,
			closing: u,
			self: !u && /\/\s*$/.test(l),
			rest: l,
			attrs: d.attrs,
			entries: d.entries,
			invalid: d.invalid,
			start: t,
			head: o,
			end: c + 1
		};
	}
	function Je(t, n, r, i) {
		let a = 1;
		for (let o = t; o < r;) {
			if (!i) {
				let e = ye(o);
				if (e !== null && e > o) {
					o = Math.min(e, r);
					continue;
				}
			}
			let t = tt(o, r, i);
			if (t !== null) o = t;
			else if (e.startsWith("<!--", o)) o = Se(e, o, r);
			else {
				if (e[o] === "<") {
					let e = K(o, r);
					if (e) {
						if (e.lower === n) {
							if (e.closing) {
								if (--a, a === 0) return {
									start: o,
									end: e.end
								};
							} else !e.self && !Ee.has(n) && (a += 1);
						} else if (!e.closing && (e.lower === "pre" || e.lower === "code") && !Ee.has(e.lower)) {
							let t = Je(e.end, e.lower, r, i);
							if (t) {
								o = t.end;
								continue;
							}
						}
						o = e.end;
						continue;
					}
				}
				o++;
			}
		}
		return null;
	}
	function Ye(e, t) {
		if (!t) return {
			ok: !1,
			attr: ""
		};
		let n = Object.create(null);
		if (t.invalid.length) return {
			ok: !1,
			attr: t.invalid[0].name
		};
		for (let r of t.entries) {
			let t = r.name;
			if (!Le(e, t)) return {
				ok: !1,
				attr: t
			};
			if (t === "align" && k.has(e)) {
				let i = Te(e, r.value);
				if (!i) return {
					ok: !1,
					attr: t
				};
				n.align = i;
			} else {
				if (!Ce(t, r.value)) return {
					ok: !1,
					attr: t
				};
				n[t] = r.value;
			}
		}
		return e === "details" && Object.hasOwn(n, "open") && (n.open = "true"), {
			ok: !0,
			attrs: n
		};
	}
	function Xe(e) {
		return e.length === 1 && e[0].type === "paragraph" ? e[0].children ?? [] : e;
	}
	function Ze(e) {
		return e.flatMap((e) => e.type === "paragraph" ? e.children ?? [] : [e]);
	}
	function Qe(t, n, r, i) {
		let a = t.start, o = n.end, s = () => {
			let e = at(t.end, n.start, void 0, a, t.end, i.depth + 1, {
				footnote: i.footnote,
				indent: i.indent,
				container: i.container,
				definitions: [],
				stripBlockquote: i.stripBlockquote
			});
			return ot(t.end, n.start, e.tokens, i.indent, {
				literalHtml: i.footnote,
				stripBlockquote: i.stripBlockquote
			});
		}, c = () => Xe(s()), l = (e) => {
			let t = [];
			for (let n of e) if (n.type === "list") for (let e of n.children ?? []) e.type === "listItem" && t.push(e);
			else n.type === "listItem" ? t.push(n) : n.type === "comment" || n.type === "text" && !(n.value ?? "").trim() || t.push(N("listItem", n.range.start, n.range.end, { children: n.type === "paragraph" ? n.children ?? [] : [n] }));
			return t;
		};
		switch (t.lower) {
			case "code": return N("inlineCode", a, o, { value: S(e.slice(t.end, n.start)) });
			case "pre": {
				let i = e.slice(t.end, n.start), s = /^<code(?:\s[^>]*)?>([\s\S]*)<\/code>$/.exec(i);
				return N("code", a, o, {
					value: S(s ? s[1] : i),
					attrs: r
				});
			}
			case "summary": return N("summary", a, o, {
				attrs: r,
				children: c()
			});
			case "details": return N("details", a, o, {
				attrs: r,
				children: mo(s())
			});
			case "p": return N("paragraph", a, o, {
				attrs: r,
				children: Ze(s())
			});
			case "h1":
			case "h2":
			case "h3":
			case "h4":
			case "h5":
			case "h6": return N("heading", a, o, {
				depth: Number(t.lower.slice(1)),
				attrs: r,
				children: Ze(s())
			});
			case "div": return N("div", a, o, {
				attrs: r,
				children: s()
			});
			case "blockquote": return N("blockquote", a, o, {
				attrs: r,
				children: s()
			});
			case "ul":
			case "ol": {
				let e = t.lower === "ol", n = r.start, i = e && n !== void 0 ? Number(n) : void 0;
				return N("list", a, o, {
					ordered: e,
					...e && i !== void 0 && Number.isFinite(i) ? { start: i } : {},
					attrs: r,
					children: l(s())
				});
			}
			case "li": {
				let e = s();
				return N("listItem", a, o, {
					attrs: r,
					children: e.length === 1 && e[0].type === "paragraph" ? e[0].children ?? [] : e
				});
			}
			case "a": return r.href === void 0 ? N("span", a, o, {
				attrs: r,
				children: c()
			}) : N("link", a, o, {
				url: r.href,
				title: r.title ?? null,
				attrs: r,
				children: c()
			});
			case "span": return N("span", a, o, {
				attrs: r,
				children: c()
			});
			default: return N(je[t.lower] ?? t.lower, a, o, {
				attrs: r,
				children: c()
			});
		}
	}
	let $e = /^ {0,3}$/, et = /^[ \t]*$/;
	function tt(t, n, r) {
		let i = e[t];
		if (i === "\\") return Math.min(n, t + 2);
		if (i !== "`" && i !== "~") return null;
		let a = w.lineStartAt(t);
		if ((r ? et : $e).test(e.slice(a, t))) {
			let i = /^(`{3,}|~{3,})[^\n]*(?:\n|$)/.exec(e.slice(t, n));
			if (i) {
				let a = RegExp(`^${r ? "[ \\t]*" : " {0,3}"}${i[1][0]}{${i[1].length},}[ \\t]*\\r?$`, "gm");
				a.lastIndex = t + i[0].length;
				let o = a.exec(e);
				return o && o.index < n ? Math.min(n, o.index + o[0].length) : n;
			}
		}
		if (i === "`") {
			let r = /^`+/.exec(e.slice(t, n))[0], i = e.indexOf(r, t + r.length);
			for (; i >= 0 && i < n;) {
				if (e[i - 1] !== "`" && e[i + r.length] !== "`") return i + r.length;
				i = e.indexOf(r, i + r.length);
			}
			return t + r.length;
		}
		return null;
	}
	function nt(t, n, r, i, a = !1) {
		let o = 1;
		for (let s = t; s < r;) {
			if (!i) {
				let e = ye(s);
				if (e !== null && e > s) {
					s = Math.min(e, r);
					continue;
				}
			}
			let t = tt(s, r, i);
			if (t !== null) s = t;
			else if (e.startsWith("<!--", s)) s = Se(e, s, r);
			else {
				if (e[s] === "<") {
					let e = We(s, r);
					if (e) {
						if (e.name === n || a && e.name.toLowerCase() === n.toLowerCase()) {
							if (e.closing) {
								if (--o, o === 0) return {
									start: s,
									end: e.end
								};
							} else e.self || (o += 1);
						}
						s = e.end;
						continue;
					}
				}
				s++;
			}
		}
		return null;
	}
	function rt(t, n) {
		return ea(e, t, n);
	}
	function it(t, n) {
		let r = Infinity, i = "", a = 0, o = t;
		for (; o < n;) {
			let t = e.indexOf("\n", o), s = t < 0 || t > n ? n : t, c = e.slice(o, s);
			if (w.lineStartAt(o) === o) {
				if (i) RegExp(`^[ \\t]*${i}{${a},}[ \\t]*\\r?$`).test(c) && (i = "");
				else {
					let e = /^([ \t]*)(`{3,}|~{3,})/.exec(c);
					e ? (r = Math.min(r, e[1].length), i = e[2][0], a = e[2].length) : c.trim() !== "" && (r = Math.min(r, /^[ \t]*/.exec(c)[0].length));
				}
			}
			if (s >= n) break;
			o = s + 1;
		}
		return Number.isFinite(r) ? r : 0;
	}
	function at(t, n, r, i = t, a = t, u = 0, d = {}) {
		let m = [];
		if (n > t && l.charge(n - t, t, n), E.maxComponentDepth = Math.max(E.maxComponentDepth, u), u > Do) throw new Io("local.budget", "Component nesting exceeds the 100-level limit.", i, a, "local.budget.nesting", { limit: Do });
		let _ = d.footnote === !0, y = d.container ?? r !== void 0, b = d.indent ?? 0, S = d.definitions ?? z, C = ge;
		if (r) {
			let e = nt(t, r, n, !0)?.start ?? n, i = it(t, e);
			b = i;
			let a = new Ga(w);
			a.original(t, e, i), a.finish(e), E.mappingSegments += a.segmentCount;
			let o = a.text(), s;
			/[\[:@]|www\./i.test(o) ? s = Oa(le(o), !1) : (l.charge(o.length + 1, 0, Math.max(1, o.length)), j(o), s = {
				definitions: [],
				mathLiterals: []
			});
			let c = (t) => ({
				start: a.at(t.start, e),
				end: a.at(t.end, e)
			}), u = s.definitions.map(c).filter((e) => e.end > e.start);
			C = s.mathLiterals.map(c).sort((e, t) => e.start - t.start), S = u.filter((n) => n.start >= t && n.end <= e).sort((e, t) => e.start - t.start || t.end - e.end);
		} else t > 0 && d.definitions !== void 0 && !_ && (C = Oa(le(e.slice(t, n))).mathLiterals.map((e) => ({
			start: e.start + t,
			end: e.end + t
		})).sort((e, t) => e.start - t.start));
		let T = 0, D = 0;
		for (; D < P.length && P[D].end <= t;) D += 1;
		for (let i = t; i < n;) {
			for (; D < P.length && P[D].end <= i;) D += 1;
			let a = P[D];
			if (a && a.start <= i && i < a.end) {
				let t = Math.min(n, a.end);
				m.push({
					start: i,
					end: t,
					block: G(i),
					node: N("fallback", i, t, { value: e.slice(i, t) })
				}), i = t;
				continue;
			}
			if (!y) {
				for (; he[B]?.end <= i;) B++;
				let e = he[B];
				if (e && e.start <= i) {
					i = e.end;
					continue;
				}
			}
			for (; S[T]?.end <= i;) T++;
			let E = S[T];
			if (E && E.start === i) {
				let t = i, n = qe(t);
				for (; !n && t - i < 4 && t < E.end && (e[t] === " " || e[t] === "	");) t += 1, n = qe(t);
				if (n && n.bodyStart <= E.end) {
					let r = w.lineStartAt(t), a = e.slice(r, t), o = /^(?:[ \t]{0,3}>[ \t]?)+/.exec(a)?.[0] ?? "", s = /^[ \t]*/.exec(a.slice(o.length))[0].length, c = s + 4, l = at(n.bodyStart, E.end, void 0, n.bodyStart, n.bodyStart, u + 1, {
						footnote: !0,
						indent: c,
						container: y || s > 0,
						definitions: [],
						stripBlockquote: o.length > 0
					}), d = ot(n.bodyStart, E.end, l.tokens, c, {
						literalHtml: !0,
						stripBlockquote: o.length > 0
					});
					m.push({
						start: E.start,
						end: E.end,
						block: !0,
						node: N("footnoteDefinition", E.start, E.end, {
							identifier: n.identifier,
							label: n.label,
							children: d
						})
					}), i = E.end, T += 1;
					continue;
				}
				T += 1;
			}
			let O = e.startsWith("\\\\[", i) && /\s/.test(e[i + 3] ?? "");
			if (!_ && r !== "plot" && e[i] === "\\" && (e[i + 1] === "(" || e[i + 1] === "[" || O) && !I(C, i)) {
				let t = O || e[i + 1] === "[", r = O ? 3 : 2, a = t ? "]" : ")", o = i + r;
				for (; o < n;) if (e[o] === "\\") {
					if (O ? e.startsWith("\\\\]", o) && o + 2 < n && /\s/.test(e[o - 1] ?? "") : e[o + 1] === a && o + 1 < n) break;
					o += 2;
				} else o++;
				if (o >= n) {
					V("local.math.unclosed", { key: "local.math.unclosed" }, i, n), i = n;
					continue;
				}
				let s = o + r, c = e.slice(i + r, o);
				c.length > Eo && (V("local.budget.math", {
					key: "local.budget.math",
					params: { limit: Eo }
				}, i, s), c = c.slice(0, Eo)), m.push({
					start: i,
					end: s,
					node: N(t ? "math" : "inlineMath", i, s, { value: c })
				}), i = s;
				continue;
			}
			let ee = tt(i, n, y);
			if (ee !== null) i = ee;
			else if (e.startsWith("<!--", i)) {
				let t = Se(e, i, n), a = e.slice(i, t);
				if (!_ && /^<!--\s*reactive-md(?=[\s:]|-->|$)/i.test(a)) {
					Ne += 1;
					let n = w.lineStartAt(i), o = e.indexOf("\n", t), s = /^\s*$/.test(e.slice(n, i)) && /^\s*$/.test(e.slice(t, o < 0 ? e.length : o)), c = /^<!--[ \t]*reactive-md:[ \t]*(local-draft-[1-9][0-9]*)[ \t]*-->$/.exec(a);
					Ne > 1 ? V("local.version.duplicate", "Only one source syntax declaration is allowed.", i, t) : !c || /[\r\n]/.test(a) ? V("local.version.malformed", `Use <!-- reactive-md: ${Ie} --> on one line.`, i, t) : (Me = {
						version: c[1],
						range: {
							start: i,
							end: t
						}
					}, r !== void 0 || !s || Re(0, i) !== i ? V("local.version.placement", "The syntax declaration must be on its own line before the theme and document body.", i, t) : c[1] !== "local-draft-3" && V("local.version.unsupported", {
						key: "local.version.unsupported",
						params: {
							declared: c[1],
							supported: Ie
						}
					}, i, t));
				}
				m.push({
					start: i,
					end: t,
					node: N("comment", i, t)
				}), i = t;
			} else if (!_ && e.startsWith("{{", i)) {
				let t = rt(i, n);
				if (t < 0) {
					V("local.interpolation", { key: "local.interpolation.unclosed" }, i, n), i += 2;
					continue;
				}
				m.push({
					start: i,
					end: t,
					node: N("interpolation", i, t, { value: e.slice(i + 2, t - 2).trim() })
				}), i = t;
			} else if (!_ && e[i] === "$") {
				let t = e[i + 1] === "$", r = t ? "$$" : "$";
				if (t) {
					let t = i + r.length;
					for (; t < n; t++) if (e[t] === "\\") t++;
					else if (e.startsWith(r, t)) break;
					if (t >= n || !e.startsWith(r, t)) {
						V("local.math.unclosed", { key: "local.math.unclosed" }, i, void 0), i += r.length;
						continue;
					}
					let a = e.slice(i + r.length, t);
					a.length > Eo && (V("local.budget.math", {
						key: "local.budget.math",
						params: { limit: Eo }
					}, i, t + r.length), a = a.slice(0, Eo));
					let o = t + r.length;
					m.push({
						start: i,
						end: o,
						node: N("math", i, o, { value: a })
					}), i = o;
					continue;
				}
				let a = i + 1, o = -1;
				for (; a < n; a++) {
					let t = e[a];
					if (t === "\\") {
						a++;
						continue;
					}
					if (t === "\n" || t === "\r") break;
					if (t !== "$") continue;
					let n = e.slice(i + 1, a), r = e[a + 1];
					if (!n.trim() || /\s$/.test(n) && /^\d[\d.,]*(?:[，、；：。！？]|[.,;:!?]\s|\s+(?:and|or|to|each|per|for)\b)/i.test(n) || r !== void 0 && r >= "0" && r <= "9") break;
					o = a;
					break;
				}
				if (o < 0) {
					i += 1;
					continue;
				}
				let s = e.slice(i + 1, o);
				s.length > Eo && (V("local.budget.math", {
					key: "local.budget.math",
					params: { limit: Eo }
				}, i, o + 1), s = s.slice(0, Eo));
				let c = o + 1;
				m.push({
					start: i,
					end: c,
					node: N("inlineMath", i, c, { value: s })
				}), i = c;
			} else {
				if (e[i] === "[") {
					let t = Ke(i, n);
					if (t && (e[t.closeEnd] !== ":" || !G(i))) {
						m.push({
							start: i,
							end: t.closeEnd,
							node: N("footnoteReference", i, t.closeEnd, {
								identifier: t.identifier,
								label: t.label
							})
						}), i = t.closeEnd;
						continue;
					}
				}
				if (e[i] === "<") {
					if (v) {
						let t = o.length, a = !1, c;
						try {
							c = v.readTable(e, i, n, {
								shield: (t, n) => {
									if (e.startsWith("{{", t)) {
										let e = rt(t, n);
										if (e >= 0) return e;
									}
									if (e[t] === "<") {
										let e = We(t, n);
										if (e && !e.closing && !ve.has(e.name.toLowerCase()) && !yo.has(e.name.toLowerCase()) && !h.has(e.name.toLowerCase())) {
											let t = nt(e.end, e.name, n, y);
											if (t) return t.end;
										}
									}
									return tt(t, n, y);
								},
								budget: (e, t) => {
									if (t > s * 2) throw new Io("local.budget", `Syntax nodes exceed the limit of ${s}.`, e, e + 1, "local.budget.nodes", { limit: s });
								},
								node: N,
								problem: (e, t, n, r, i) => {
									a = !0, H("local.html.fallback", {
										key: `html.table.${e}`,
										params: {
											tag: r ?? "table",
											name: i ?? ""
										}
									}, t, n);
								},
								attributes: (e, t, n) => {
									let r = K(t, n, !0), i = r && Ye(e, r);
									if (!i || !i.ok) {
										a = !0;
										let r = i && !i.ok ? i.attr : "";
										return H("local.html.fallback", {
											key: `html.table.${[
												"colspan",
												"rowspan",
												"span",
												"scope",
												"align"
											].includes(r) ? "value" : "attribute"}`,
											params: {
												tag: e,
												name: r
											}
										}, t, n), {};
									}
									return i.attrs;
								},
								content: (e, t) => ot(e, t, at(e, t, void 0, e, e, u + 1, {
									...d,
									definitions: []
								}).tokens, it(e, t), {
									literalHtml: _,
									stripBlockquote: d.stripBlockquote === !0
								})
							});
						} catch (s) {
							if (s instanceof Io) throw s;
							let l = We(i, n);
							if (!l || l.closing || l.name.toLowerCase() !== "table") throw s;
							let u = nt(l.end, l.name, n, y, !0)?.end ?? Ge(l.end, n, r), d = o.slice(t).filter((e) => e.code.startsWith("local.budget"));
							o.splice(t, o.length - t, ...d), H("local.html.fallback", { key: "local.html.fallback" }, i, u), c = {
								node: N("fallback", i, u, { value: e.slice(i, u) }),
								end: u
							}, a = !1;
						}
						if (c) {
							if (a) {
								let e = o.slice(t).filter((e) => e.code === "local.html.fallback" || e.code.startsWith("local.budget"));
								o.splice(t, o.length - t, ...e);
							}
							m.push({
								start: i,
								end: c.end,
								block: !0,
								node: a ? N("fallback", i, c.end, { value: e.slice(i, c.end) }) : c.node
							}), i = c.end;
							continue;
						}
					}
					let a = K(i, n);
					if (a) {
						if (a.closing) {
							H("local.html.fallback", { key: "local.html.fallback" }, i, a.end), m.push({
								start: i,
								end: a.end,
								block: !1,
								node: N("fallback", i, a.end, { value: e.slice(i, a.end) })
							}), i = a.end;
							continue;
						}
						let t = Ye(a.lower, a);
						if (!t.ok) {
							let o = a.self || Ee.has(a.lower) ? a.end : Je(a.end, a.lower, n, y)?.end ?? Ge(a.end, n, r, a.lower);
							H("local.html.fallback", {
								key: "local.html.fallback.attribute",
								params: { name: t.attr }
							}, i, o), m.push({
								start: i,
								end: o,
								block: !1,
								node: N("fallback", i, o, { value: e.slice(i, o) })
							}), i = o;
							continue;
						}
						let o = t.attrs;
						if (Ee.has(a.lower)) {
							if (a.lower === "br") m.push({
								start: i,
								end: a.end,
								node: N("break", i, a.end, { attrs: o })
							});
							else if (a.lower === "hr") m.push({
								start: i,
								end: a.end,
								block: !0,
								node: N("thematicBreak", i, a.end, { attrs: o })
							});
							else {
								let e = o.width === void 0 ? void 0 : Number(o.width), t = o.height === void 0 ? void 0 : Number(o.height);
								m.push({
									start: i,
									end: a.end,
									node: N("image", i, a.end, {
										url: o.src,
										alt: o.alt ?? "",
										title: o.title ?? null,
										...e === void 0 ? {} : { width: e },
										...t === void 0 ? {} : { height: t },
										attrs: o
									})
								});
							}
							i = a.end;
							continue;
						}
						let s = Je(a.end, a.lower, n, y);
						if (!s) {
							let t = Ge(a.end, n, r, a.lower);
							if (!c && v) {
								l.charge(t - i, i, t);
								let n = v.recoverFragment(e, i, t, N, new Set(h.keys()));
								if (n) {
									F.push(n.recovery);
									for (let e of n.nodes) m.push({
										start: e.range.start,
										end: e.range.end,
										block: bo.has(a.lower) || xo.has(e.type),
										node: e
									});
								} else F.push({
									code: "local.html.literal",
									causeRange: {
										start: i,
										end: a.end
									},
									affectedRange: {
										start: i,
										end: t
									},
									action: "literal-fallback",
									boundary: "fragment"
								}), m.push({
									start: i,
									end: t,
									block: G(i),
									node: N("fallback", i, t, { value: e.slice(i, t) })
								});
								i = t;
								continue;
							}
							H("local.html.fallback", { key: "local.html.fallback" }, i, t), m.push({
								start: i,
								end: t,
								block: G(i),
								node: N("fallback", i, t, { value: e.slice(i, t) })
							}), i = t;
							continue;
						}
						let f = bo.has(a.lower), p = Qe(a, s, o, {
							footnote: _,
							container: y,
							indent: b,
							stripBlockquote: d.stripBlockquote === !0,
							depth: u
						});
						m.push({
							start: i,
							end: s.end,
							...f ? { block: !0 } : {},
							node: p
						}), i = s.end;
						continue;
					}
					if (_) {
						i += 1;
						continue;
					}
					let S = Pe(i) ? W(i, n) : null;
					if (S) {
						if (r === void 0 && Re(Ae, i) === i) {
							if (Oe += 1, Oe === 1 && (U = {
								start: S.start,
								end: S.end
							}), S.unclosed) H("local.theme.malformed", { key: "local.theme.malformed.unclosed" }, i, S.end);
							else if (S.closing) H("local.theme.malformed", { key: "local.theme.malformed.closing" }, i, S.end);
							else if (!ze(S)) H("local.theme.malformed", { key: "local.theme.malformed.placement" }, i, S.end);
							else if (Oe > 1) H("local.theme.duplicate", { key: "local.theme.duplicate.declaration" }, i, S.end);
							else {
								let e = Be(S.rest);
								e.code ? H(e.code, e.message ?? "Invalid theme declaration.", i, S.end, {
									key: e.key ?? e.code,
									...e.params ? { params: e.params } : {}
								}) : De = e.name;
							}
							Ae = S.end, m.push({
								start: i,
								end: S.end,
								block: !0,
								node: N("comment", i, S.end)
							}), i = S.end;
							continue;
						}
						let t = r === void 0 ? "local.theme.late" : "local.theme.nested";
						H(t, r === void 0 ? "Theme declarations after document content are ignored." : "Theme declarations inside document content are ignored.", i, S.end, { key: t }), m.push({
							start: i,
							end: S.end,
							block: !1,
							node: N("fallback", i, S.end, { value: e.slice(i, S.end) })
						}), i = S.end;
						continue;
					}
					let C = We(i, n);
					if (C && !h.has(C.name.toLowerCase()) && x.has(C.name.toLowerCase())) {
						let t = !C.closing && !C.self && !Co.has(C.name.toLowerCase()) ? nt(C.end, C.name, n, y, !0) : null, a = !c && !C.closing && !C.self && ke.has(C.name.toLowerCase()) && (!t || C.name.toLowerCase() === "plaintext"), o = C.closing || C.self || Co.has(C.name.toLowerCase()) ? C.end : a ? n : t?.end ?? Ge(C.end, n, r, C.name);
						a ? F.push({
							code: "local.html.literal",
							causeRange: {
								start: i,
								end: C.end
							},
							affectedRange: {
								start: i,
								end: o
							},
							action: "literal-fallback",
							boundary: o === e.length ? "eof" : "fragment"
						}) : H("local.html.fallback", { key: "local.html.fallback" }, i, o), m.push({
							start: i,
							end: o,
							block: G(i),
							node: N("fallback", i, o, { value: e.slice(i, o) })
						}), i = o;
						continue;
					}
					if (C && !C.closing && _o.test(C.name) && C.name.length <= To && !h.has(C.name)) {
						let t = C.self ? C.end : nt(C.end, C.name, n, y)?.end ?? null;
						if (t === null) {
							if (!G(i)) {
								m.push({
									start: i,
									end: C.end,
									block: !1,
									node: N("text", i, C.end, { value: e.slice(i, C.end) })
								}), i = C.end;
								continue;
							}
							V("local.tag.unclosed", {
								key: "local.tag.unclosed.pair",
								params: { name: C.name }
							}, i, C.end), i = C.end;
							continue;
						}
						let r = ae(C.name, g);
						H("local.component.unknown", {
							key: r ? "local.component.unknown.suggestion" : "local.component.unknown",
							params: r ? {
								name: C.name,
								suggestion: r
							} : { name: C.name }
						}, i, t), m.push({
							start: i,
							end: t,
							block: G(i),
							node: N("fallback", i, t, { value: e.slice(i, t) })
						}), i = t;
						continue;
					}
					let w = Ue(i, n);
					if (w) {
						if (w.unclosed) {
							if (!h.has(w.name.toLowerCase()) && x.has(w.name.toLowerCase())) {
								let t = Ge(w.head, n, r, w.name);
								!c && ke.has(w.name.toLowerCase()) ? F.push({
									code: "local.html.literal",
									causeRange: {
										start: i,
										end: w.head
									},
									affectedRange: {
										start: i,
										end: t
									},
									action: "literal-fallback",
									boundary: t === e.length ? "eof" : "fragment"
								}) : H("local.html.fallback", { key: "local.html.fallback" }, i, t), m.push({
									start: i,
									end: t,
									block: G(i),
									node: N("fallback", i, t, { value: e.slice(i, t) })
								}), i = t;
								continue;
							}
							if (!h.has(w.name.toLowerCase()) && !G(i)) {
								m.push({
									start: i,
									end: w.head,
									block: !1,
									node: N("text", i, w.head, { value: e.slice(i, w.head) })
								}), i = w.head;
								continue;
							}
							V("local.tag.unclosed", {
								key: "local.tag.unclosed.open",
								params: { name: w.name }
							}, i, n), i = n;
							continue;
						}
						if (!_o.test(w.name) && !h.has(w.name.toLowerCase())) {
							m.push({
								start: i,
								end: w.end,
								block: !1,
								node: N("text", i, w.end, { value: e.slice(i, w.end) })
							}), i = w.end;
							continue;
						}
						if (_o.test(w.name) || V("local.tag.name", {
							key: "local.tag.name",
							params: { name: w.name }
						}, i, i + 1 + w.name.length), w.closing) {
							if (w.name === r) return {
								tokens: m,
								end: w.end,
								contentEnd: i,
								indent: it(t, i)
							};
							if (p.has(w.name) && f.get(w.name)?.form === "leaf") {
								V("local.host.structure", {
									key: "local.host.structure.leaf",
									params: { component: w.name }
								}, i, w.end), i = w.end;
								continue;
							}
							V("local.tag.mismatch", {
								key: r ? "local.tag.mismatch.parent" : "local.tag.mismatch.root",
								params: r ? {
									name: w.name,
									parent: r
								} : { name: w.name }
							}, i, w.end), i = w.end;
							continue;
						}
						let a = f.get(w.name), o = p.has(w.name), s = o ? a?.form : void 0, l = a === void 0 || a.form !== "leaf", d = a?.form === "inline", g = !l || w.self;
						if (w.self && l && V("local.tag.shape", {
							key: "local.tag.shape",
							params: { name: w.name }
						}, i, w.end), g) {
							m.push({
								start: i,
								end: w.end,
								...o ? { block: G(i) } : {},
								node: N(o ? "hostComponent" : "component", i, w.end, {
									name: w.name,
									attrs: w.attrs,
									children: [],
									...o ? { hostForm: s } : {}
								})
							}), i = w.end;
							continue;
						}
						let _ = at(w.end, n, w.name, i, w.end, u + 1), v = ot(w.end, _.contentEnd, _.tokens, d ? 0 : _.indent), y = N(o ? "hostComponent" : "component", i, _.end, {
							name: w.name,
							attrs: w.attrs,
							children: d && v.length === 1 && v[0].type === "paragraph" ? v[0].children ?? [] : v,
							...o ? { hostForm: s } : {}
						});
						m.push({
							start: i,
							end: _.end,
							...o ? { block: G(i) } : {},
							node: y
						}), i = _.end;
						continue;
					}
				}
				i++;
			}
		}
		return r && V("local.tag.unclosed", {
			key: "local.tag.unclosed.pair",
			params: { name: r }
		}, i, Math.min(e.length, Math.max(a, i + 1))), {
			tokens: m,
			end: n,
			contentEnd: n,
			indent: r ? it(t, n) : 0
		};
	}
	function ot(t, n, r, i = 0, a = {}) {
		n > t && l.charge(n - t, t, n);
		let o = "", c = t, d = !1, f = t === 0 && n === e.length && r.length === 0 && i === 0 && !a.stripBlockquote && !a.literalHtml && !R?.children.some((e) => e.plan?.shieldOnly), p = new Ga(w), h = (e, t) => f ? e + L : p.at(e, t), g = /* @__PURE__ */ new Map();
		function _(e, t, n) {
			n ? (e.trim().length && (d = !0), p.original(t, t + e.length, i, a.stripBlockquote, !0)) : p.generated(e, t);
		}
		let v;
		if (f) o = e.slice(L), v = R, R = void 0;
		else {
			t === 0 && n === e.length && (R = void 0);
			for (let t of r) {
				_(e.slice(c, t.start), c, !0);
				let n;
				do
					n = ho + fe++ + go;
				while (me.has(n));
				let r = t.block ?? (t.node.type === "math" || (t.node.type === "component" || t.node.type === "hostComponent") && !m(t.node.name));
				r && _("\n\n", t.start, !1);
				let i = p.length;
				_(`![${n}](rmd-internal:placeholder)`, t.start, !1), g.set(i, {
					marker: n,
					end: p.length,
					node: t.node
				}), r && _("\n\n", t.end, !1), c = t.end;
			}
			_(e.slice(c, n), c, !0), p.finish(n), o = p.text(), E.mappingSegments += p.segmentCount;
			let i = new Map([...g].filter(([, e]) => e.node.type === "interpolation"));
			v = le(o, d, {
				allowBraces: !0,
				...i.size ? { placeholders: i } : {}
			});
		}
		function y(e) {
			for (let t of e) t.type === "interpolation" && t.value !== void 0 && (t.value = t.value.replace(/\\\|/g, "|")), t.children && y(t.children);
		}
		function b(t, n, r) {
			let i = t.value;
			if (typeof i != "string" || !i) return [];
			if (!u || !/[\r\n]/.test(i)) return [N("text", n, r, { value: i })];
			let a = t.position?.start?.offset, s = t.position?.end?.offset;
			if (!Number.isInteger(a) || !Number.isInteger(s) || a < 0 || s <= a || s > o.length) return [N("text", n, r, { value: i })];
			let c = (t, n) => {
				if (n === void 0) return t;
				let r = t;
				for (let t = 0; r < e.length && t < 32; t += 1) {
					let t = e[r];
					if (t !== " " && t !== "	" && t !== ">") break;
					r += 1;
				}
				return r < e.length && e[r] === n ? r : t;
			}, l = [];
			for (let e = a; e < s; e += 1) if (o[e] === "\\" && /[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(o[e + 1] ?? "")) e += 1;
			else {
				if (o[e] === "&") {
					let t = /^&(?:#(?:[xX][\da-fA-F]{1,6}|\d{1,7})|NewLine);/.exec(o.slice(e, Math.min(s, e + 34)))?.[0];
					if (t) {
						let n = t === "&NewLine;" ? 10 : t[2].toLowerCase() === "x" ? Number.parseInt(t.slice(3, -1), 16) : Number.parseInt(t.slice(2, -1), 10);
						(n === 10 || n === 13) && l.push({
							start: e,
							end: e + t.length,
							literal: !0
						}), e += t.length - 1;
						continue;
					}
				}
				if (o[e] === "\r") {
					let t = e + 1 < s && o[e + 1] === "\n" ? e + 2 : e + 1;
					l.push({
						start: e,
						end: t
					}), e = t - 1;
				} else o[e] === "\n" && l.push({
					start: e,
					end: e + 1
				});
			}
			if (!l.length) return [N("text", n, r, { value: i })];
			let d = [], f = 0, p = n, m = 0;
			for (let e = 0; e < i.length; e += 1) {
				let t = i[e];
				if (t !== "\n" && t !== "\r") continue;
				let n = l[m];
				if (n === void 0) break;
				m += 1;
				let r = !n.literal && t === "\r" && i[e + 1] === "\n" ? e + 2 : e + 1;
				if (n.literal) continue;
				let a = h(n.start, p), o = a + (n.end - n.start);
				e > f && d.push(N("text", p, a, { value: i.slice(f, e) })), d.push(N("break", a, o)), f = r, p = c(h(n.end, o), i[r]), e = r - 1;
			}
			return f < i.length && d.push(N("text", p, r, { value: i.slice(f) })), d;
		}
		function x(e, r) {
			let i = h(e.position?.start?.offset ?? 0, t), c = h(e.position?.end?.offset ?? o.length, n);
			if (e.type === "rmdFastBlock") {
				let t = e.plan, n = e.position.start.offset;
				pe.add(t);
				let r = t.overflowAt(s - de);
				if (r) throw new Io("local.budget", `Syntax nodes exceed the limit of ${s}.`, h(n + r.start, i), h(n + r.end, c), "local.budget.nodes", { limit: s });
				return t.emit((e, t, r, a) => {
					if (e === "rmdOpaque") {
						let e = g.get(n + t);
						if (!e || e.node.type !== "interpolation" || e.end !== n + r || e.marker !== a?.value) throw Error("Invalid interpolation placeholder");
						return g.delete(n + t), e.node;
					}
					return N(e, h(n + t, i), h(n + r, c), a);
				});
			}
			if (e.type === "image") {
				let t = g.get(e.position?.start?.offset);
				if (t && e.position.end.offset === t.end && e.url === "rmd-internal:placeholder" && e.alt === t.marker) return g.delete(e.position.start.offset), t.node.type === "comment" ? [] : [t.node];
			}
			if (e.type === "text") return b(e, i, c);
			if (e.type === "footnoteReference" || e.type === "footnoteDefinition") {
				let t = typeof e.label == "string" && e.label ? e.label : String(e.identifier ?? ""), n = ca(String(e.identifier ?? t));
				return e.type === "footnoteDefinition" ? [N("footnoteDefinition", i, c, {
					identifier: n,
					label: t,
					children: r ?? []
				})] : [N("footnoteReference", i, c, {
					identifier: n,
					label: t
				})];
			}
			if (e.type === "paragraph" && r?.length === 1 && (r[0].type === "math" || r[0].type === "fallback" || r[0].type === "footnoteDefinition" || xo.has(r[0].type) || (r[0].type === "component" || r[0].type === "hostComponent") && !m(r[0].name))) return r;
			if (e.type === "paragraph" && !r?.length) return [];
			if (e.type === "html") return a.literalHtml ? typeof e.value == "string" && e.value ? [N("text", i, c, { value: e.value })] : [] : (V("local.html", { key: "local.html" }, i, c), []);
			let l = N(e.type, i, c);
			for (let t of [
				"value",
				"depth",
				"ordered",
				"start",
				"checked",
				"url",
				"title",
				"alt",
				"lang",
				"align"
			]) e[t] !== void 0 && (l[t] = e[t]);
			return r && (l.children = r), e.type === "table" && l.children && y(l.children), [l];
		}
		let S = [{
			raw: v,
			index: 0,
			children: []
		}];
		for (; S.length;) {
			let e = S[S.length - 1];
			if (e.raw.children && e.index < e.raw.children.length) {
				let t = e.raw.children[e.index++];
				S.push({
					raw: t,
					index: 0,
					children: t.children ? [] : void 0
				});
				continue;
			}
			if (S.pop(), !S.length) return e.children ?? [];
			let t = x(e.raw, e.children);
			for (let e of t) S[S.length - 1].children.push(e);
		}
		return [];
	}
	function st(t) {
		let n = /* @__PURE__ */ new Set(), r = [...t];
		for (; r.length;) {
			let e = r.pop();
			if (e.type === "footnoteDefinition" && e.identifier && n.add(e.identifier), e.children) for (let t of e.children) r.push(t);
		}
		for (r.push(...t); r.length;) {
			let t = r.pop();
			if (t.type !== "footnoteReference" || t.identifier && n.has(t.identifier) || (t.type = "text", t.value = e.slice(t.range.start, t.range.end), delete t.identifier, delete t.label), t.children) for (let e of t.children) r.push(e);
		}
	}
	function ct() {
		if (c || F.length === 0) return;
		let e = /* @__PURE__ */ new Set(), t = !1;
		for (let n of F) {
			if (!So.has(n.code)) continue;
			let { causeRange: r, affectedRange: i } = n, a = `${n.code}:${r.start}:${r.end}:${i.start}:${i.end}:${n.boundary}`;
			e.has(a) || (e.add(a), H(n.code, ee(n.code, "en"), r.start, r.end, { key: n.code }), t = !0);
		}
		t && o.sort((e, t) => e.range.start - t.range.start || e.range.end - t.range.end);
	}
	try {
		if (!c && e.includes("<")) {
			let t = io(e, {
				facts: w.facts,
				definitions: z,
				isKnown: (e) => h.has(e),
				isPaired: (e) => {
					let t = h.get(e);
					return t === void 0 || t.form !== "leaf";
				},
				isHtmlName: (e) => v !== void 0 && (yo.has(e) || x.has(e)),
				isVoidHtml: (e) => Co.has(e) || Ee.has(e),
				rawHtmlEnd: (t, n, r) => {
					if (t === "plaintext") return e.length;
					if (t === "pre" || t === "code") return Je(n, t, e.length, r)?.end ?? null;
					let i = RegExp(`</${t}\\s*>`, "i").exec(e.slice(n));
					return i ? n + i.index + i[0].length : null;
				},
				protectedEnd: (t, n) => tt(t, e.length, n),
				codeEndAt: (e) => ye(e),
				readTag: (t) => {
					let n = We(t, e.length);
					if (n) return {
						name: n.name,
						closing: n.closing,
						self: n.self,
						end: n.end,
						complete: !0
					};
					let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, Math.min(e.length, t + 256)));
					return r ? {
						name: r[2],
						closing: !!r[1],
						self: !1,
						end: t + r[0].length,
						complete: !1
					} : null;
				},
				beginsLine: G,
				charge: (e, t, n) => l.charge(e, t, n)
			});
			P = t.ranges, F = [...t.recoveries];
		}
		let t = ko(), n = at(0, e.length);
		A = ko() - t;
		let r = ko(), i = ot(0, e.length, n.tokens);
		return ie = ko() - r, st(i), F.sort((e, t) => e.causeRange.start - t.causeRange.start || e.causeRange.end - t.causeRange.end || e.affectedRange.start - t.affectedRange.start || e.affectedRange.end - t.affectedRange.end || e.code.localeCompare(t.code)), ct(), ce(), {
			nodes: i,
			diagnostics: o,
			syntaxNodes: de,
			work: E,
			...pe.size ? { plans: [...pe] } : {},
			...Me ? { versionDeclaration: Me } : {},
			...De === void 0 ? {} : { theme: De },
			...U ? { themeRange: U } : {},
			...F.length ? { recoveries: F } : {}
		};
	} catch (e) {
		return e instanceof Ka ? (we(e), ce(), {
			nodes: [],
			diagnostics: o,
			work: E,
			...F.length ? { recoveries: F } : {}
		}) : e instanceof Io ? (V(e.code, e.message, e.start, e.end, {
			key: e.key,
			params: e.params
		}), ce(), {
			nodes: [],
			diagnostics: o,
			work: E,
			...F.length ? { recoveries: F } : {}
		}) : (V("local.parse", {
			key: "local.parse.document",
			params: { detail: e instanceof Error ? e.message : String(e) }
		}, 0, void 0), {
			nodes: [],
			diagnostics: o,
			...F.length ? { recoveries: F } : {}
		});
	}
}
// src/local/transport/compiled-data.ts
function Ro(e, t = !0) {
	let n = /* @__PURE__ */ new WeakMap(), r = [], i = (e) => {
		if (typeof e != "object" || !e) return e;
		let t = n.get(e);
		if (t) return t;
		let i = Array.isArray(e) ? Array(e.length) : {};
		return n.set(e, i), r.push({
			input: e,
			output: i
		}), i;
	}, a = i(e);
	for (; r.length;) {
		let { input: e, output: n } = r.pop();
		for (let [t, r] of Object.entries(e)) Object.defineProperty(n, t, {
			value: i(r),
			enumerable: !0,
			configurable: !0,
			writable: !0
		});
		t && Object.isFrozen(e) && Object.freeze(n);
	}
	return a;
}
// src/local/compilation/compiler-core.ts
var zo = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/, Bo = /^[A-Za-z_][A-Za-z0-9_]*$/, Vo = 128, Ho = 4, Uo = 3, Wo = /* @__PURE__ */ new Set([
	"x",
	"y",
	"true",
	"false",
	"null",
	"pi",
	"e"
]);
function Go(e) {
	let t = e.trim();
	if (!zo.test(t)) return null;
	let n = Number(t);
	return Number.isFinite(n) ? n : null;
}
function Ko(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function qo(e) {
	let t = [], n = [];
	for (let r = 0; r < e.length;) {
		if (e[r] === "\\" && e.startsWith("{{", r + 1)) {
			r += 3;
			continue;
		}
		if (!e.startsWith("{{", r)) {
			r++;
			continue;
		}
		let i = "", a = r + 2;
		for (; a < e.length - 1; a++) {
			let t = e[a];
			if (i) t === "\\" ? a++ : t === i && (i = "");
			else if (t === "\"" || t === "'") i = t;
			else if (t === "}" && e[a + 1] === "}") break;
		}
		if (a >= e.length - 1) {
			n.push(r);
			break;
		}
		let o = e.slice(r + 2, a), s = o.length - o.trimStart().length;
		t.push({
			expression: o.trim(),
			start: r + 2 + s,
			end: a
		}), r = a + 2;
	}
	return {
		segments: t,
		unterminated: n
	};
}
function Jo(e) {
	let t = /^\s*\{\{([\s\S]*)\}\}\s*$/.exec(e);
	if (!t) return null;
	let n = t[1], r = n.length - n.trimStart().length, i = e.indexOf("{{");
	return {
		expression: n.trim(),
		start: i + 2 + r
	};
}
function Yo(e) {
	return e.type === "comment" || e.type === "text" && !(e.value ?? "").trim() || e.type === "paragraph" && !e.children?.length && !(e.value ?? "").trim();
}
function $(e) {
	return (e ?? []).filter((e) => !Yo(e));
}
function Xo(e) {
	return e.type === "text" || e.type === "inlineCode" || e.type === "fallback" ? e.value ?? "" : e.type === "interpolation" ? "\0" : e.type === "break" ? " " : (e.children ?? []).map(Xo).join("");
}
function Zo(e) {
	return e.type === "interpolation" || (e.children ?? []).some(Zo);
}
function Qo(e) {
	return e.type === "component" || (e.children ?? []).some(Qo);
}
function $o(e) {
	switch (e) {
		case "string": return "string";
		case "number": return "number";
		case "boolean": return "boolean";
		case "null": return "null";
		case "array": return "array";
		case "number-array": return "number-array";
	}
}
function es(e, t) {
	return !t || t.length === 0 ? e : {
		...e,
		recoveries: [...t]
	};
}
function ts(e) {
	return e.schemaByName ?? /* @__PURE__ */ new Map();
}
function ns(e) {
	return e.componentByName ?? /* @__PURE__ */ new Map();
}
function rs(e, t) {
	if (!(e.length > Vo)) return ae(e, [...t]);
}
function is(e, t, r) {
	if (typeof e != "string" || e.length > 1e6) return {
		ok: !1,
		diagnostics: [{
			code: typeof e == "string" ? "local.budget" : "local.parse",
			message: typeof e == "string" ? `Document exceeds the ${n}-character limit.` : "Document source must be a string.",
			severity: "error",
			range: {
				start: 0,
				end: typeof e == "string" && e.length ? 1 : 0
			},
			line: 1,
			column: 1,
			messageKey: typeof e == "string" ? "local.budget.document" : "local.parse.source",
			...typeof e == "string" ? { params: { limit: n } } : {}
		}]
	};
	let i = r(e, t.html, t.maxSyntaxNodes);
	return i.diagnostics.some((e) => e.severity === "error") ? {
		ok: !1,
		diagnostics: i.diagnostics
	} : {
		ok: !0,
		document: {
			syntax: "local",
			source: e,
			syntaxVersion: Ie,
			html: t.html,
			nodes: [{
				type: "htmlDocument",
				id: "local-0",
				range: {
					start: 0,
					end: e.length
				},
				value: i.markup
			}],
			initialState: {},
			bindings: {}
		},
		diagnostics: i.diagnostics
	};
}
function as(e, t, n, r, i, a) {
	if (n.htmlActive) return r?.htmlDocument ? is(e, n, r.htmlDocument) : {
		ok: !1,
		diagnostics: [{
			code: "local.capability.html",
			message: O({ key: "local.capability.html" }),
			severity: "error",
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: "local.capability.html"
		}]
	};
	if (typeof e != "string" || e.length > 1e6) {
		let t = Lo(e, n);
		return es({
			ok: !1,
			diagnostics: t.diagnostics
		}, t.recoveries);
	}
	let o = [], s = new Wa(e), { lineStarts: c } = s, l = (t, n, r, i = r + 1, a) => {
		let s = typeof n == "string" ? a : n, l = typeof n == "string" ? n : O(n);
		if (o.length >= 100) {
			let e = o.length - 1;
			for (; e >= 0 && o[e].severity !== "warning";) --e;
			if (e < 0) return;
			o.splice(e, 1);
		}
		let u = Math.max(0, Math.min(e.length, r)), f = Math.max(u, Math.min(e.length, Math.max(u, i))), p = 0, m = c.length - 1;
		for (; p < m;) {
			let e = Math.ceil((p + m) / 2);
			c[e] <= u ? p = e : m = e - 1;
		}
		let h = y(s?.key ?? t, s?.params);
		o.push({
			code: t,
			message: l.length > 2e3 ? `${l.slice(0, d - 1)}…` : l,
			severity: "error",
			range: {
				start: u,
				end: f
			},
			line: p + 1,
			column: u - c[p] + 1,
			messageKey: h.key,
			...h.params ? { params: h.params } : {}
		});
	}, u;
	try {
		u = r?.parser ? r.parser.parse(e, t, s, r.rowPlans) : Lo(e, n, s), i?.(u), a?.("parseMs");
	} catch (e) {
		return l("local.parse", `Cannot parse document: ${e instanceof Error ? e.message : String(e)}`, 0, void 0, {
			key: "local.parse.document",
			params: { detail: e instanceof Error ? e.message : String(e) }
		}), {
			ok: !1,
			diagnostics: o
		};
	}
	o.push(...u.diagnostics);
	let f = u.recoveries;
	if (o.some((e) => e.severity === "error" && e.code.startsWith("local.version."))) {
		let e = new Set((f ?? []).map((e) => `${e.code}:${e.causeRange.start}:${e.causeRange.end}`));
		return es({
			ok: !1,
			diagnostics: o.filter((t) => t.code.startsWith("local.version.") || t.severity === "warning" && e.has(`${t.code}:${t.range.start}:${t.range.end}`))
		}, f);
	}
	for (let e of os(u.nodes)) l("local.legacy", "Legacy reactive-md configuration fences (state/data/computed/actions, etc.) are not part of the local interaction syntax; select legacy mode explicitly in the host.", e.range.start, e.range.end, { key: "local.legacy" });
	let p = {
		semantic: r?.semantic,
		display: r?.display,
		htmlDocument: r?.htmlDocument,
		plotMath: r?.plotMath,
		source: e,
		lineStarts: c,
		nodes: u.nodes,
		diagnostics: o,
		schemaByName: ts(n),
		definitionsByName: ns(n),
		report: l,
		entries: [],
		attrs: /* @__PURE__ */ new Map(),
		options: /* @__PURE__ */ new Map(),
		tabs: /* @__PURE__ */ new Map(),
		steps: /* @__PURE__ */ new Map(),
		selections: /* @__PURE__ */ new Map(),
		diagramNodes: /* @__PURE__ */ new Map(),
		checklists: /* @__PURE__ */ new Map(),
		tables: /* @__PURE__ */ new Map(),
		tableShapes: /* @__PURE__ */ new Map(),
		bindingSlots: Object.create(null),
		bindingKinds: {},
		computationKinds: {},
		computations: {},
		externals: {},
		externalKinds: {},
		dynamicConstraints: {},
		expressionKinds: /* @__PURE__ */ new Map()
	};
	ss(u.nodes, null, p.entries, p);
	for (let e of p.entries) p.attrs.set(e.node.id, us(e, p)), vs(e, p), _s(e, p);
	a?.("attributesMs");
	for (let e of p.entries) Fs(e, p);
	jc(p), a?.("structureMs");
	let m = Rs(p);
	p.bindingKinds = zs(m), a?.("bindingsMs"), uc(p), oc(p), a?.("computationsMs"), dc(p), fc(p), a?.("expressionsMs"), vc(p), a?.("dataTablesMs");
	let h = yc(p);
	a?.("validationsMs"), Cc(p), a?.("plotsMs"), Oc(p), a?.("tablesMs");
	let g = {};
	for (let [e, t] of Object.entries(m)) g[e] = Ko(t.initial);
	pc(p, m, g), zc(u.nodes, p), a?.("hostAndNavigationMs");
	let _ = [...u.nodes];
	for (; _.length && o.length < 100;) {
		let t = _.pop();
		if (t.type === "math" || t.type === "inlineMath") {
			let n = e.startsWith("\\\\[", t.range.start) ? 3 : t.type === "math" || e.startsWith("\\(", t.range.start) ? 2 : 1, r = t.range.start + n;
			if (p.display) for (let e of p.display(t.value ?? "", t.type === "math")) Pc(p, e.code, e.message, r + e.start, r + e.end, {
				key: e.messageKey,
				params: e.params
			});
		} else t.children && _.push(...t.children);
	}
	if (a?.("mathDisplayMs"), o.sort((e, t) => e.range.start - t.range.start || e.range.end - t.range.end), o.some((e) => e.severity === "error")) return es({
		ok: !1,
		diagnostics: o
	}, f);
	let v = rc(p), b = Object.keys(p.computations), x = Object.keys(p.externals), S = Object.keys(p.dynamicConstraints).length ? p.dynamicConstraints : void 0, C = Fc(u.nodes, n.sdkByName), w = Lc(p, m), T = Rc(p), E = {
		syntax: "local",
		source: e,
		...n.config || !t?.hostComponents ? { componentConfigKey: Pe(n) } : {},
		syntaxVersion: Ie,
		...u.versionDeclaration ? { versionDeclaration: u.versionDeclaration } : {},
		nodes: cc(u.nodes),
		initialState: g,
		bindings: m,
		theme: u.theme ?? "default",
		...u.themeRange ? { themeRange: u.themeRange } : {},
		...v ? { bindingSlots: v } : {},
		...b.length ? { computations: p.computations } : {},
		...x.length ? { externals: p.externals } : {},
		...S ? { dynamicConstraints: S } : {},
		...h.length ? { validations: h } : {},
		...C ? { extensions: C } : {},
		kernel: w,
		...T.length ? { componentDefinitions: Object.freeze(T) } : {}
	};
	return Ft(E, n.registry), Ac(E, p.tableShapes), a?.("publicationMs"), es({
		ok: !0,
		document: E,
		diagnostics: o
	}, f);
}
function os(e) {
	let t = [];
	for (let n of V(e)) n.type === "code" && (n.lang ?? "").trim().toLowerCase() === "reactive-md" && t.push(n);
	return t;
}
function ss(e, t, n, r) {
	let i = [{
		nodes: e,
		parent: t,
		index: 0
	}];
	for (; i.length;) {
		let e = i[i.length - 1];
		if (e.index === e.nodes.length) {
			i.pop();
			continue;
		}
		let t = e.nodes[e.index++], a = e.parent, o = a;
		if ((t.type === "component" || t.type === "hostComponent") && t.name) {
			let e = r.schemaByName.get(t.name);
			if (e) {
				let i = r.definitionsByName.get(t.name), s = T(e) || i !== void 0 && !i.rules?.length && t.type === "hostComponent", c = {
					node: t,
					name: t.name,
					kernel: e,
					...i ? { definition: i } : {},
					legacy: s,
					parent: a
				};
				n.push(c), o = c;
			} else if (t.type === "component") {
				let e = rs(t.name, r.schemaByName.keys());
				r.report("local.component.unknown", {
					key: e ? "local.component.unknown.suggestion" : "local.component.unknown",
					params: e ? {
						name: t.name,
						suggestion: e
					} : { name: t.name }
				}, t.range.start, t.range.end);
			}
		}
		t.children && i.push({
			nodes: t.children,
			parent: o,
			index: 0
		});
	}
}
function cs(e, t, n) {
	let r = "", i = t;
	for (; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") {
			i += 1;
			break;
		}
	}
	return e.slice(t, i);
}
function ls(e, t, n) {
	if (n.length > Vo) return t.range.start;
	let r = cs(e.source, t.range.start, t.range.end), i = RegExp(`(?:^|[\\s"'/])${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?=\\s|=|/|>)`).exec(r);
	return i ? t.range.start + i.index + (i[0].length - n.length) : t.range.start;
}
function us(e, t) {
	if (!t.semantic) return ds(e, t);
	let n = e.name + "\0" + cs(t.source, e.node.range.start, e.node.range.end), r = t.semantic.attributes(n), i = (e, t) => Object.fromEntries(Object.entries(e).map(([e, n]) => [e, {
		...n,
		offset: n.offset + t,
		...n.expressionOffset === void 0 ? {} : { expressionOffset: n.expressionOffset + t },
		...Array.isArray(n.value) ? { value: Ko(n.value) } : {}
	}]));
	if (r) return i(r.value, e.node.range.start - r.origin);
	let a = t.diagnostics.length, o = ds(e, t);
	return a < 100 && t.diagnostics.length === a && t.semantic.rememberAttributes(n, e.node.range.start, i(o, 0)), o;
}
function ds(t, n) {
	let r = {}, i = t.node.attrs ?? {}, o = t.kernel.props, s = t.legacy, c = s ? fs(t) : void 0;
	for (let [l, u] of Object.entries(i)) {
		let i = ls(n, t.node, l);
		if (s && u.length > 1e5) {
			n.report("local.budget.attribute", {
				key: "local.budget.attribute",
				params: {
					name: l,
					component: t.name,
					limit: a
				}
			}, i, i + l.length);
			continue;
		}
		if (c?.bind.has(l) || c?.initial.has(l)) {
			r[l] = ps(t, l, u, i);
			continue;
		}
		let d = o[l];
		if (!d) {
			let e = ae(l, Object.keys(o));
			s ? n.report("local.host.attribute", {
				key: "local.host.attribute.unknown",
				params: {
					component: t.name,
					name: l
				}
			}, i, i + l.length) : n.report("local.attribute.unknown", {
				key: e ? "local.attribute.unknown.suggestion" : "local.attribute.unknown",
				params: e ? {
					component: t.name,
					name: l,
					suggestion: e
				} : {
					component: t.name,
					name: l
				}
			}, i, i + l.length);
			continue;
		}
		let f = {
			raw: u,
			offset: i,
			dynamic: !1
		};
		if (d.kind === "string" && u.length > 1e5 && (n.report("local.budget.attribute", {
			key: "local.budget.attribute",
			params: {
				name: l,
				component: t.name,
				limit: a
			}
		}, i, i + l.length), f.raw = u.slice(0, a)), hs(l, d, f, n, s), d.color) {
			let r = qo(f.raw);
			r.segments.length || r.unterminated.length || e(f.raw) || n.report("local.attribute.color", {
				key: "local.attribute.color",
				params: {
					name: l,
					component: t.name,
					value: f.raw
				}
			}, i, i + l.length);
		}
		r[l] = f;
	}
	for (let [e, i] of Object.entries(o)) c?.bind.has(e) || c?.initial.has(e) || i.required && i.default === void 0 && !Object.hasOwn(r, e) && (s ? n.report("local.host.attribute", {
		key: "local.host.attribute.required",
		params: {
			component: t.name,
			name: e
		}
	}, t.node.range.start, t.node.range.end) : n.report("local.attribute.required", {
		key: "local.attribute.required",
		params: {
			component: t.name,
			name: e
		}
	}, t.node.range.start, t.node.range.end));
	return b(t.kernel).label === "required" && (Object.hasOwn(r, "label") ? String(r.label.raw).trim() || n.report("local.label.required", {
		key: "local.label.required.empty",
		params: { name: t.name }
	}, r.label.offset, void 0) : n.report("local.label.required", {
		key: "local.label.required.missing",
		params: { name: t.name }
	}, t.node.range.start, t.node.range.end)), r;
}
function fs(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = j(e.kernel);
	r && (t.add(r.bind), n.add(r.initial));
	for (let r of _(e.kernel)) t.add(r.bind), n.add(r.initial);
	return t.size || n.size ? {
		bind: t,
		initial: n
	} : void 0;
}
function ps(e, t, n, r) {
	let i = j(e.kernel), a = i && i.bind === t ? i : _(e.kernel).find((e) => e.bind === t || e.initial === t) ?? (i && i.initial === t ? i : void 0), o = {
		raw: n,
		offset: r,
		dynamic: !1
	};
	if (!a || a.bind === t) return o.value = n, o;
	if (a.kind === "number") {
		let e = Go(n);
		e !== null && (o.value = e);
	} else a.kind === "boolean" ? (n === "true" || n === "false") && (o.value = n === "true") : o.value = n;
	return o;
}
function ms(e) {
	return e.values ?? e.enum ?? [];
}
function hs(e, t, n, r, i) {
	let a = i ? "local.host.attribute.static" : "local.attribute.static", o = i ? "local.host.attribute" : "local.attribute.static";
	if (t.kind === "string") {
		if (t.dynamic) {
			let t = Jo(n.raw);
			if (t) {
				n.dynamic = !0, n.expression = t.expression, n.expressionOffset = n.offset + t.start, t.expression || r.report("local.expression.empty", {
					key: "local.expression.empty.attribute",
					params: { name: e }
				}, n.expressionOffset, void 0);
				return;
			}
		}
		if (t.static) {
			let t = qo(n.raw);
			(t.segments.length || t.unterminated.length) && r.report(o, `Attribute ${e} is static and cannot contain interpolations.`, n.offset, n.offset + n.raw.length, {
				key: a,
				params: { name: e }
			}), n.value = n.raw;
			return;
		}
		if (t.dynamic === !1) {
			let t = qo(n.raw);
			if (t.segments.length || t.unterminated.length) {
				r.report(i ? "local.host.attribute" : "local.attribute.interpolation", `Attribute ${e} does not accept interpolations.`, n.offset, n.offset + n.raw.length, {
					key: "local.attribute.interpolation.dynamic",
					params: { name: e }
				});
				return;
			}
		}
		if (t.pattern !== void 0) {
			let a = qo(n.raw);
			if (a.segments.length > 0 || a.unterminated.length > 0) {
				Ic(n.raw) || r.report(i ? "local.host.attribute" : "local.attribute.interpolation", `Attribute ${e} must be a literal matching ${t.pattern} or one full interpolation.`, n.offset, n.offset + n.raw.length, {
					key: i ? "local.host.attribute.interpolation" : "local.attribute.interpolation.pattern",
					params: {
						name: e,
						pattern: t.pattern
					}
				}), n.value = n.raw;
				return;
			}
			let o = !0;
			try {
				o = new RegExp(t.pattern).test(n.raw);
			} catch {}
			o || (i ? r.report("local.host.attribute", {
				key: "local.host.attribute.pattern",
				params: {
					name: e,
					pattern: t.pattern
				}
			}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
				key: "local.attribute.type.pattern",
				params: {
					name: e,
					pattern: t.pattern
				}
			}, n.offset, n.offset + n.raw.length)), n.value = n.raw;
			return;
		}
		n.value = n.raw;
		return;
	}
	let s = t.static !== !0 && t.dynamic !== !1 && (t.dynamic === !0 || i);
	if (t.kind === "number") {
		let a = s ? Jo(n.raw) : null;
		if (a) {
			n.dynamic = !0, n.expression = a.expression, n.expressionOffset = n.offset + a.start, a.expression || r.report("local.expression.empty", {
				key: "local.expression.empty.attribute",
				params: { name: e }
			}, n.expressionOffset, void 0);
			return;
		}
		let o = Go(n.raw);
		if (o === null) {
			i ? r.report("local.host.attribute", {
				key: "local.host.attribute.type",
				params: {
					name: e,
					value: n.raw,
					kind: "number"
				}
			}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
				key: t.dynamic ? "local.attribute.type.number-interpolation" : "local.attribute.type.number",
				params: {
					name: e,
					value: n.raw
				}
			}, n.offset, n.offset + n.raw.length);
			return;
		}
		t.integer && !Number.isInteger(o) && (i ? r.report("local.host.attribute", {
			key: "local.attribute.type.integer",
			params: { name: e }
		}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
			key: "local.attribute.type.integer",
			params: { name: e }
		}, n.offset, void 0)), t.positive && !(o > 0) && r.report("local.attribute.type", {
			key: "local.attribute.type.positive",
			params: { name: e }
		}, n.offset, void 0), t.min !== void 0 && o < t.min && (i ? r.report("local.host.attribute", {
			key: "local.attribute.range.min",
			params: {
				name: e,
				min: t.min
			}
		}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.range", {
			key: "local.attribute.range.min",
			params: {
				name: e,
				min: t.min
			}
		}, n.offset, void 0)), t.max !== void 0 && o > t.max && (i ? r.report("local.host.attribute", {
			key: "local.attribute.range.max",
			params: {
				name: e,
				max: t.max
			}
		}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.range", {
			key: "local.attribute.range.max",
			params: {
				name: e,
				max: t.max
			}
		}, n.offset, void 0)), n.value = o;
		return;
	}
	if (t.kind === "boolean") {
		let a = s ? Jo(n.raw) : null;
		if (a) {
			n.dynamic = !0, n.expression = a.expression, n.expressionOffset = n.offset + a.start, a.expression || r.report("local.expression.empty", {
				key: "local.expression.empty.attribute",
				params: { name: e }
			}, n.expressionOffset, void 0);
			return;
		}
		if (n.raw === "true" || n.raw === "false") {
			n.value = n.raw === "true";
			return;
		}
		i ? r.report("local.host.attribute", {
			key: "local.host.attribute.type",
			params: {
				name: e,
				value: n.raw,
				kind: "boolean"
			}
		}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
			key: t.dynamic ? "local.attribute.type.boolean-interpolation" : "local.attribute.type.boolean",
			params: { name: e }
		}, n.offset, n.offset + n.raw.length);
		return;
	}
	let c = s ? Jo(n.raw) : null;
	if (c) {
		n.dynamic = !0, n.expression = c.expression, n.expressionOffset = n.offset + c.start, c.expression || r.report("local.expression.empty", {
			key: "local.expression.empty.attribute",
			params: { name: e }
		}, n.expressionOffset, void 0);
		return;
	}
	let l = ms(t);
	l.includes(n.raw) ? n.value = n.raw : i ? r.report("local.host.attribute", {
		key: "local.host.attribute.enum",
		params: {
			name: e,
			values: l.join(" / "),
			value: n.raw
		}
	}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
		key: "local.attribute.type.enum",
		params: {
			name: e,
			values: l.join(" / "),
			value: n.raw
		}
	}, n.offset, n.offset + n.raw.length);
}
function gs(e, t, n) {
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.kernel.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function _s(e, t) {
	if (!e.legacy) return;
	let n = j(e.kernel), r = n?.kind === "number" ? n.constraints?.step : void 0;
	if (!r || !("prop" in r)) return;
	let i = t.attrs.get(e.node.id) ?? {}, a = r.prop, o = e.kernel.props[a], s = i[a], c = s?.offset ?? ls(t, e.node, a);
	if (s) s.dynamic ? t.report("local.host.attribute", {
		key: "local.host.attribute.static",
		params: { name: a }
	}, c, c + s.raw.length) : typeof s.value == "number" && !(s.value > 0) && t.report("local.host.attribute", {
		key: "local.attribute.type.positive",
		params: { name: a }
	}, c, c + s.raw.length);
	else {
		let n = o?.default;
		typeof n == "number" ? n > 0 || t.report("local.host.attribute", {
			key: "local.attribute.type.positive",
			params: { name: a }
		}, e.node.range.start, e.node.range.end) : t.report("local.host.attribute", {
			key: "local.host.attribute.type",
			params: {
				name: a,
				value: "missing",
				kind: "number"
			}
		}, e.node.range.start, e.node.range.end);
	}
}
function vs(e, t) {
	let n = t.attrs.get(e.node.id) ?? {};
	for (let r of E(e.kernel, n, e.node.range)) t.report(r.code, r.message, r.start, r.end, {
		key: r.key,
		...r.params ? { params: r.params } : {}
	});
}
function ys(e, t) {
	let n = [];
	for (let r of e.node.children ?? []) (r.type === "component" || r.type === "hostComponent") && r.name && t.schemaByName.has(r.name) && n.push({
		node: r,
		name: r.name
	});
	return n;
}
function bs(e, t) {
	switch (t) {
		case "options": return e.options;
		case "tabs": return e.tabs;
		case "steps": return e.steps;
		case "diagram-nodes": return e.diagramNodes;
	}
}
function xs(e, t, n, r) {
	n === "selection" ? e.selections.set(t.node.id, r) : n !== "checklist" && bs(e, n).set(t.node.id, r);
}
function Ss(e) {
	return e.children ?? e.items ?? (e.child ? [e.child] : []);
}
function Cs(e) {
	return e.min ?? e.minItems ?? 0;
}
function ws(e, t) {
	if (Ss(b(e.kernel)).includes(t)) return !0;
	for (let n of x(e.kernel)) switch (n.kind) {
		case "options-body":
		case "value-sequence":
			if (n.child === t) return !0;
			break;
		case "only-children":
			if (n.children.includes(t)) return !0;
			break;
		case "data-table":
			if (n.child === t) return !0;
			break;
		case "quiz-body":
			if (n.child === t) return !0;
			break;
		case "diagram-body": if (n.node === t || n.edge === t) return !0;
	}
	return !1;
}
function Ts(e) {
	return e.max ?? e.maxItems ?? e.maxItemsCount ?? e.maxItems;
}
var Es = /* @__PURE__ */ new Set([
	"text",
	"emphasis",
	"strong",
	"delete",
	"underline",
	"mark",
	"link",
	"image",
	"inlineCode",
	"inlineMath",
	"interpolation",
	"break",
	"comment",
	"fallback",
	"footnoteReference"
]);
function Ds(e) {
	return Es.has(e.type) && (e.children ?? []).every(Ds);
}
function Os(e, t, n, r) {
	r && ((t.length === 1 && t[0].type === "paragraph" ? t[0].children ?? [] : t).every(Ds) || n.report("local.structure.children", {
		key: "local.structure.inline-only",
		params: { name: e.name }
	}, e.node.range.start, e.node.range.end));
	for (let r of t) Qo(r) && n.report("local.structure.children", {
		key: "local.structure.no-nested-components",
		params: { name: e.name }
	}, r.range.start, r.range.end);
}
function ks(e, t) {
	let n = (r) => {
		for (let i of r) i.type === "component" || i.type === "hostComponent" ? t.report("local.structure.children", {
			key: "local.structure.no-components",
			params: { name: e.name }
		}, i.range.start, i.range.end) : i.children && n(i.children);
	};
	n(e.node.children ?? []);
}
function As(e, t, n, r, i, a, o, s) {
	let c = ys(e, t), l = c.filter((e) => e.name === r);
	l.length || t.report("local.structure.children", {
		key: "local.structure.options.needed",
		params: { name: e.name }
	}, e.node.range.start, e.node.range.end);
	for (let n of c) n.name !== r && t.report("local.structure.children", {
		key: "local.structure.options.only",
		params: { name: e.name }
	}, n.node.range.start, n.node.range.end);
	$(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || e.name !== r) && t.report("local.structure.children", {
		key: "local.structure.options.only",
		params: { name: e.name }
	}, e.node.range.start, e.node.range.end), l.length > o && t.report("local.budget.array", {
		key: "local.budget.array.options",
		params: {
			name: e.name,
			limit: o
		}
	}, e.node.range.start, e.node.range.end);
	let u = [];
	for (let n of l) {
		let r = t.attrs.get(n.node.id) ?? {}, o = typeof r[i]?.value == "string" ? r[i].value : "";
		o ? s !== void 0 && o.includes(s) ? t.report("local.option.value", {
			key: "local.option.value.comma",
			params: { value: o }
		}, n.node.range.start, n.node.range.end) : a && u.includes(o) ? t.report("local.option.value", {
			key: "local.option.value.duplicate",
			params: {
				name: e.name,
				value: o
			}
		}, n.node.range.start, n.node.range.end) : ((n.node.children ?? []).some(Qo) && t.report("local.structure.children", { key: "local.structure.option.no-components" }, n.node.range.start, n.node.range.end), u.push(o)) : t.report("local.option.value", { key: "local.option.value.required" }, n.node.range.start, n.node.range.end);
	}
	xs(t, e, "options", u);
}
function js(e, t, n, r, i, a) {
	let o = ys(e, t), s = o.filter((e) => e.name === n);
	s.length || t.report("local.structure.children", {
		key: "local.structure.sequence.minimum",
		params: {
			name: e.name,
			child: n
		}
	}, e.node.range.start, e.node.range.end);
	for (let r of o) r.name !== n && t.report("local.structure.children", {
		key: "local.structure.sequence.only",
		params: {
			name: e.name,
			child: n
		}
	}, r.node.range.start, r.node.range.end);
	$(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || e.name !== n) && t.report("local.structure.children", {
		key: "local.structure.sequence.only",
		params: {
			name: e.name,
			child: n
		}
	}, e.node.range.start, e.node.range.end);
	let c = [];
	s.forEach((n, o) => {
		let s = t.attrs.get(n.node.id) ?? {}, l = (typeof s[r]?.value == "string" ? s[r].value.trim() : "") || `${i}${o + 1}`;
		c.includes(l) ? t.report(a, `Values in <${e.name}> must be unique; duplicate value "${l}".`, n.node.range.start, n.node.range.end, {
			key: `${a}.duplicate`,
			params: { value: l }
		}) : c.push(l);
	});
	let l = j(e.kernel)?.family;
	xs(t, e, f(l ?? "") === "tabs" ? "tabs" : "steps", c);
}
function Ms(e, t, n, r, i, a, o) {
	let s = ys(e, t), c = s.filter((e) => n.includes(e.name)), l = n.map((e) => `<${e}>`).join(" or "), u = i !== void 0 && o === "local.budget.data-table.columns" ? Math.min(i, 20) : i;
	c.length < r && t.report("local.structure.children", {
		key: "local.structure.children.minimum",
		params: {
			name: e.name,
			min: r,
			children: l
		}
	}, e.node.range.start, e.node.range.end), u !== void 0 && c.length > u && t.report(o ?? "local.budget.array", `<${e.name}> supports at most ${u} ${l}, but has ${c.length}.`, e.node.range.start, e.node.range.end);
	for (let r of s) n.includes(r.name) || t.report("local.structure.children", {
		key: a ?? "local.structure.children.only",
		params: {
			name: e.name,
			children: l
		}
	}, r.node.range.start, r.node.range.end);
	$(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || !e.name || !t.schemaByName.has(e.name)) && t.report("local.structure.children", {
		key: a ?? "local.structure.children.only",
		params: {
			name: e.name,
			children: l
		}
	}, e.node.range.start, e.node.range.end);
}
function Ns(e, t, n) {
	let r = ys(e, t), i = r.filter((e) => e.name === n.node), a = r.filter((e) => e.name === n.edge);
	i.length || t.report("local.diagram.node", { key: "local.diagram.node.required" }, e.node.range.start, e.node.range.end);
	for (let e of r) e.name !== n.node && e.name !== n.edge && t.report("local.structure.children", { key: "local.structure.diagram.only" }, e.node.range.start, e.node.range.end);
	$(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || !e.name || e.name !== n.node && e.name !== n.edge) && t.report("local.structure.children", { key: "local.structure.diagram.only" }, e.node.range.start, e.node.range.end);
	let o = [];
	for (let e of i) {
		let r = (t.attrs.get(e.node.id) ?? {})[n.id]?.value, i = typeof r == "string" ? r : "";
		i && (/^[A-Za-z_][A-Za-z0-9_-]*$/.test(i) || t.report("local.diagram.node", {
			key: "local.diagram.node.invalid",
			params: { id: i }
		}, e.node.range.start, e.node.range.end), o.includes(i) ? t.report("local.diagram.node", {
			key: "local.diagram.node.duplicate",
			params: { id: i }
		}, e.node.range.start, e.node.range.end) : o.push(i));
	}
	xs(t, e, "diagram-nodes", o);
	let s = /* @__PURE__ */ new Set();
	for (let e of a) {
		let r = t.attrs.get(e.node.id) ?? {}, i = r[n.from]?.value, a = r[n.to]?.value, c = n.label ? r[n.label]?.value : void 0, l = typeof i == "string" ? i : "", u = typeof a == "string" ? a : "", d = typeof c == "string" ? c : "";
		l && !o.includes(l) && t.report("local.diagram.edge", {
			key: "local.diagram.edge.from",
			params: { id: l }
		}, e.node.range.start, e.node.range.end), u && !o.includes(u) && t.report("local.diagram.edge", {
			key: "local.diagram.edge.to",
			params: { id: u }
		}, e.node.range.start, e.node.range.end);
		let f = `${l}\u0000${u}\u0000${d}`;
		s.has(f) && t.report("local.diagram.edge", {
			key: "local.diagram.edge.duplicate",
			params: {
				from: l,
				to: u,
				label: d ? ` (${d})` : ""
			}
		}, e.node.range.start, e.node.range.end), s.add(f);
	}
}
function Ps(e, n, r, i) {
	let a = typeof r[i.type]?.value == "string" ? String(r[i.type].value) : "choice", o = Js(e, r, i.answer) ?? "";
	if (o.trim() || n.report("local.quiz.answer", { key: "local.quiz.answer.required" }, r[i.answer]?.offset ?? e.node.range.start, void 0), a === "number") {
		$(e.node.children).length && n.report("local.structure.children", { key: "local.structure.quiz.numeric-no-body" }, e.node.range.start, e.node.range.end), o.trim() && Go(o) === null && n.report("local.quiz.answer", { key: "local.quiz.answer.numeric" }, r[i.answer]?.offset ?? e.node.range.start, void 0);
		let t = gs(e, r, i.tolerance);
		t !== void 0 && (!Number.isFinite(t) || t < 0) && n.report("local.constraint", { key: "local.constraint.quiz-tolerance" }, r[i.tolerance]?.offset ?? e.node.range.start, void 0);
		return;
	}
	As(e, n, r, i.child, i.valueAttribute, !0, Math.min(i.max ?? 1e4, t), void 0);
	let s = n.options.get(e.node.id) ?? [];
	o.trim() && s.length && !s.includes(o) && n.report("local.quiz.answer", {
		key: "local.quiz.answer.not-option",
		params: {
			answer: o,
			options: s.join(", ")
		}
	}, r[i.answer]?.offset ?? e.node.range.start, void 0);
}
function Fs(e, n) {
	let r = n.attrs.get(e.node.id) ?? {}, i = $(e.node.children), a = n.report, o = b(e.kernel), s = x(e.kernel);
	o.parents && (e.parent === null || !o.parents.includes(e.parent.name) && !ws(e.parent, e.name)) && a("local.structure.parent", `<${e.name}> can only appear directly inside ${o.parents.map((e) => `<${e}>`).join(" or ")}.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.parent",
		params: {
			name: e.name,
			parents: o.parents.map((e) => `<${e}>`).join(" / ")
		}
	});
	let c = !1, l = !1;
	for (let u of s) switch (u.kind) {
		case "inline-body":
			c = !0, Os(e, i, n, u.strict === !0 || o.inlineOnly === !0);
			break;
		case "no-components":
			c = !0, ks(e, n);
			break;
		case "single-table": {
			c = !0, l = !0;
			let t = i.filter((e) => e.type === "table");
			(t.length !== 1 || i.length !== 1) && a("local.structure.children", `The body of <${e.name}> must be exactly one Markdown table.`, e.node.range.start, e.node.range.end, {
				key: "local.structure.table.single",
				params: { name: e.name }
			}), t.length ? n.tables.set(e.node.id, t[0]) : u.fallbackSingle === !0 && i.length === 1 && n.tables.set(e.node.id, i[0]);
			break;
		}
		case "math-body":
			c = !0, l = !0, i.filter((e) => e.type === "math").length || a("local.structure.children", `<${e.name}> requires at least one $$...$$ formula block.`, e.node.range.start, e.node.range.end, { key: "local.structure.plot.needs-formula" });
			for (let t of i) t.type !== "math" && a("local.structure.children", `The body of <${e.name}> can only contain blank lines and $$...$$ formula blocks.`, t.range.start, t.range.end, { key: "local.structure.plot.only-formulas" });
			break;
		case "options-body":
			c = !0, l = !0, As(e, n, r, u.child, u.valueAttribute, u.unique, Math.min(u.max ?? 1e4, t), u.forbidSeparator);
			break;
		case "value-sequence":
			c = !0, l = !0, js(e, n, u.child, u.valueAttribute, u.generatedPrefix, u.duplicateCode ?? `local.${u.child}.value`);
			break;
		case "only-children":
			c = !0, l = !0, Ms(e, n, u.children, u.min, u.max, u.onlyCode, u.maxCode);
			break;
		case "diagram-body":
			c = !0, l = !0, Ns(e, n, u);
			break;
		case "quiz-body":
			c = !0, l = !0, Ps(e, n, r, u);
			break;
		case "checklist-body": c = !0, l = !0, Is(e, n, Math.min(u.itemLimit, t));
	}
	if (!c) switch (o.rule) {
		case "none":
			i.length && (e.legacy ? a("local.host.structure", `Host component <${e.name}> is a leaf and cannot have body content.`, i[0].range.start, i[0].range.end, {
				key: "local.host.structure.leaf",
				params: { component: e.name }
			}) : a("local.structure.children", `<${e.name}> does not accept body content.`, i[0].range.start, i[0].range.end, {
				key: "local.structure.no-body",
				params: { name: e.name }
			}));
			break;
		case "inline":
			Os(e, i, n, o.inlineOnly === !0 || o.markdown === "inline");
			break;
		case "content":
			(o.noComponents === !0 || o.allowComponents === !1) && ks(e, n);
			break;
		case "components": {
			(o.noComponents === !0 || o.allowComponents === !1) && ks(e, n);
			let t = Ss(o);
			if (t.length) {
				l = !0;
				let r = A(e.kernel, "data-table");
				Ms(e, n, t, Cs(o), Ts(o), void 0, r ? "local.budget.data-table.columns" : void 0);
			}
			break;
		}
		case "options":
			l = !0, As(e, n, r, Ss(o)[0] ?? "option", o.valueAttribute ?? "value", !0, Math.min(o.maxItems ?? 1e4, t), o.forbidSeparator);
			break;
		case "tabs":
		case "steps": l = !0, js(e, n, Ss(o)[0] ?? (o.rule === "tabs" ? "tab" : "step"), o.valueAttribute ?? "value", o.generatedPrefix ?? o.valuePrefix ?? `${o.rule === "tabs" ? "tab" : "step"}-`, `local.${o.rule === "tabs" ? "tab" : "step"}.value`);
	}
	let u = Cs(o);
	!l && u > 0 && i.length < u && a(e.legacy ? "local.host.structure" : "local.structure.children", `Component <${e.name}> requires body content.`, e.node.range.start, e.node.range.end, {
		key: e.legacy ? "local.host.structure.leaf" : "local.structure.content-required",
		params: { component: e.name }
	});
	let d = Ts(o);
	!l && d !== void 0 && i.length > d && a("local.structure.children", `<${e.name}> accepts at most ${d} body blocks.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.body-max",
		params: {
			name: e.name,
			max: d
		}
	});
}
function Is(e, n, r = t) {
	let i = n.checklists.get(e.node.id);
	if (i) return i;
	let a = $(e.node.children), o = a.filter((e) => e.type === "list");
	(a.length !== 1 || o.length !== 1) && n.report("local.checklist.body", { key: "local.checklist.body.single" }, e.node.range.start, e.node.range.end);
	let s = o[0], c = [], l = [];
	if (!s) return n.checklists.set(e.node.id, {
		ids: c,
		checked: l
	}), {
		ids: c,
		checked: l
	};
	let u = s.children ?? [];
	u.length || n.report("local.checklist.body", { key: "local.checklist.body.item-required" }, s.range.start, s.range.end), u.length > r && n.report("local.budget.array", {
		key: "local.checklist.body.items-limit",
		params: { limit: r }
	}, s.range.start, s.range.end), u.slice(0, r).forEach((e, t) => {
		if (e.type !== "listItem" || e.checked === null || e.checked === void 0) {
			n.report("local.checklist.body", { key: "local.checklist.body.task-only" }, e.range.start, e.range.end);
			return;
		}
		(e.children ?? []).some((e) => e.type === "list") && n.report("local.checklist.body", { key: "local.checklist.body.no-nested" }, e.range.start, e.range.end), Qo(e) && n.report("local.checklist.body", { key: "local.checklist.body.no-components" }, e.range.start, e.range.end);
		let r = `item-${t + 1}`;
		c.push(r), e.checked && l.push(r);
	});
	let d = {
		ids: c,
		checked: l
	};
	return n.checklists.set(e.node.id, d), d;
}
function Ls(e, t, n, r) {
	t.required && !Object.hasOwn(n, t.bind) && r.report("local.attribute.required", {
		key: "local.attribute.required",
		params: {
			component: e.name,
			name: t.bind
		}
	}, e.node.range.start, e.node.range.end);
}
function Rs(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.entries) {
		let r = j(n.kernel);
		if (!r) continue;
		let i = e.attrs.get(n.node.id) ?? {};
		if (r.requiresAttributes?.some((e) => !Object.hasOwn(i, e))) continue;
		Ls(n, r, i, e);
		let a = typeof i[r.bind]?.value == "string" ? String(i[r.bind].value) : "", o = a || `@${n.node.id}`;
		if (Object.hasOwn(i, r.bind)) {
			let t = i[r.bind].offset ?? n.node.range.start;
			a.length > Vo ? (e.report("local.budget.identifier", {
				key: "local.budget.identifier",
				params: { limit: Vo }
			}, t, void 0), o = `@${n.node.id}`) : Bo.test(a) ? (ce.has(a) || Wo.has(a)) && (e.report("local.binding.reserved", {
				key: "local.binding.reserved",
				params: { name: a }
			}, t, void 0), o = `@${n.node.id}`) : (e.report("local.binding.name", {
				key: "local.binding.name",
				params: { name: a }
			}, t, void 0), o = `@${n.node.id}`);
		}
		let s = t.get(o);
		s ? s.members.push({
			entry: n,
			attrs: i
		}) : t.set(o, {
			key: o,
			binding: r,
			members: [{
				entry: n,
				attrs: i
			}]
		});
	}
	let n = {};
	for (let r of t.values()) {
		let t = r.binding.family, i = e.semantic && t !== "checklist" ? JSON.stringify([r.key, r.members.map(({ entry: n }) => [
			n.name,
			n.node.id,
			n.node.attrs,
			Ys(n, e, n.kernel, t)
		])]) : void 0, a = i ? e.semantic.binding(i) : void 0, o = e.diagnostics.length, s = a ? Ro(a) : Ws(r, e);
		!a && s && i && o < 100 && e.diagnostics.length === o && e.semantic.rememberBinding(i, Ro(s)), s && (n[r.key] = s);
	}
	return tc(e, n), n;
}
function zs(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) n.startsWith("@") || (t[n] = r.type);
	return t;
}
function Bs(e, t) {
	let n = j(e.kernel);
	return n ? C(e.kernel, n, t) : { step: 1 };
}
var Vs = w, Hs = oe;
function Us(e, t) {
	let n = e.attrs[t];
	if (n) return n.dynamic ? `{{ ${(n.expression ?? "").trim()} }}` : typeof n.value == "string" ? n.value : String(n.value ?? "");
}
function Ws(e, t) {
	let n = e.members[0], r = e.binding, i = r.family;
	for (let a of e.members.slice(1)) {
		let o = j(a.entry.kernel);
		o && o.family === i && o.kind === r.kind || t.report("local.binding.type", {
			key: "local.binding.type",
			params: {
				key: e.key,
				kind: $o(r.kind),
				first: n.entry.name,
				second: a.entry.name
			}
		}, a.entry.node.range.start, a.entry.node.range.end);
	}
	let a = e.members.find((e) => j(e.entry.kernel)?.exclusive === !0);
	if (a && e.members.length > 1) for (let n of e.members) n !== a && t.report("local.binding.exclusive", {
		key: "local.binding.exclusive",
		params: {
			key: e.key,
			first: a.entry.name,
			second: n.entry.name
		}
	}, n.entry.node.range.start, n.entry.node.range.end);
	let o = Ys(n.entry, t, n.entry.kernel, i), s;
	if (r.kind === "number") {
		s = Bs(n.entry, n.attrs);
		for (let r of e.members.slice(1)) {
			let i = Bs(r.entry, r.attrs);
			Vs(i, s, "min") && Vs(i, s, "max") && i.step === s.step || t.report("local.binding.constraint", {
				key: "local.binding.constraint",
				params: {
					key: e.key,
					first: n.entry.name,
					second: r.entry.name,
					firstConstraints: Hs(s),
					secondConstraints: Hs(i)
				}
			}, r.entry.node.range.start, r.entry.node.range.end);
		}
	}
	if (i === "choice" || i === "selection") for (let n of e.members.slice(1)) Ys(n.entry, t, n.entry.kernel, i).join("\0") !== o.join("\0") && t.report("local.binding.option", {
		key: "local.binding.option",
		params: { key: e.key }
	}, n.entry.node.range.start, n.entry.node.range.end);
	let c = new Set(r.compare ?? []);
	for (let e of x(n.entry.kernel)) e.kind === "date-bounds" && (e.min && c.add(e.min), e.max && c.add(e.max));
	for (let r of c) {
		let i = Us(n, r);
		for (let a of e.members.slice(1)) Us(a, r) !== i && t.report("local.binding.constraint", {
			key: "local.binding.constraint",
			params: {
				key: e.key,
				first: n.entry.name,
				second: a.entry.name,
				firstConstraints: `${r} bounds`,
				secondConstraints: `${r} bounds`
			}
		}, a.entry.node.range.start, a.entry.node.range.end);
	}
	let l = r.maxItems ? g(n.entry.kernel, r, n.attrs) : void 0, u = e.members.filter((e) => Object.hasOwn(e.attrs, r.initial)), d;
	if (u.length > 1) {
		let n = u.map((e) => Gs(t, e.attrs[r.initial].offset)), i = Math.min(u.length, Ho);
		for (let a = 0; a < i; a += 1) {
			let i = [];
			for (let e = 1; e < n.length && i.length < Uo; e += 1) i.push(n[(a + e) % n.length]);
			t.report("local.initial.duplicate", i.length ? {
				key: "local.initial.duplicate-peers",
				params: {
					key: e.key,
					count: u.length,
					lines: i.join(", ")
				}
			} : {
				key: "local.initial.duplicate",
				params: {
					key: e.key,
					count: u.length
				}
			}, u[a].attrs[r.initial].offset, void 0);
		}
	}
	d = i === "multi-select" ? u.length ? Zs(u[0], o, l, t, r) : [] : i === "collection" ? u.length ? Xs(u[0], t, r) : [] : u.length > 0 ? Qs(u[0], t, r, o) : $s(n, t, r, o, s), i === "checklist" && !Array.isArray(d) && (d = []), ec(e, n, d, r, o, s, t), Ks(e, d, t);
	let f = {
		family: r.family,
		name: e.key,
		nodeIds: e.members.map((e) => e.entry.node.id),
		type: r.kind,
		initial: Ko(d),
		owner: n.entry.node.id
	};
	return s && (s.min !== void 0 && (f.min = s.min), s.max !== void 0 && (f.max = s.max), f.step = s.step), o.length && (f.options = [...o]), i === "multi-select" ? f.maxItems = l ?? o.length : l !== void 0 && (f.maxItems = l), f;
}
function Gs(e, t) {
	let n = Math.max(0, Math.min(e.source.length, t)), r = 0, i = e.lineStarts.length - 1;
	for (; r < i;) {
		let t = Math.ceil((r + i) / 2);
		e.lineStarts[t] <= n ? r = t : i = t - 1;
	}
	return r + 1;
}
function Ks(e, t, n, r) {
	if (typeof t != "string" || t === "") return;
	let i = e.members[0], a = j(i.entry.kernel)?.initial ?? "initial", o = r ?? i.attrs[a]?.offset ?? i.entry.node.range.start, s = Ae(t);
	for (let r of e.members) {
		let { entry: i, attrs: a } = r;
		for (let r of p(i.kernel)) if (r.kind === "length") {
			let t = qs(i, a, r.min) ?? 0, c = qs(i, a, r.max);
			t > 0 && s < t && n.report("local.initial.length", {
				key: "local.initial.length.min",
				params: {
					key: e.key,
					length: s,
					min: t,
					name: i.name
				}
			}, o, void 0), c !== void 0 && s > c && n.report("local.initial.length", {
				key: "local.initial.length.max",
				params: {
					key: e.key,
					length: s,
					max: c,
					name: i.name
				}
			}, o, void 0);
		} else if (r.kind === "email") (Js(i, a, r.type) ?? "text") === r.value && (t.length > 254 || !u(t)) && n.report("local.initial.email", {
			key: "local.initial.email",
			params: { key: e.key }
		}, o, void 0);
		else if (r.kind === "date" && se(t)) {
			let s = Js(i, a, r.min), c = Js(i, a, r.max);
			s && se(s) && t < s && n.report("local.initial.range", {
				key: "local.initial.date.min",
				params: {
					key: e.key,
					value: t,
					min: s
				}
			}, o, void 0), c && se(c) && t > c && n.report("local.initial.range", {
				key: "local.initial.date.max",
				params: {
					key: e.key,
					value: t,
					max: c
				}
			}, o, void 0);
		}
	}
}
function qs(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.kernel.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function Js(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "string" ? r.value : void 0;
	let i = e.kernel.props[n]?.default;
	return typeof i == "string" ? i : void 0;
}
function Ys(e, t, n, r) {
	let i = f(r);
	if (!i) return [];
	if (i === "checklist") {
		let r = A(n, "checklist-body")?.itemLimit;
		return Is(e, t, r).ids;
	}
	if (i === "selection") return t.selections.get(e.node.id) ?? [""];
	let a = bs(t, i).get(e.node.id);
	return a === void 0 ? [...j(n)?.options ?? []] : a;
}
function Xs(e, t, n) {
	let r = e.attrs[n.initial];
	if (!r) return [];
	let i = typeof r.value == "string" ? r.value : String(r.value ?? ""), a;
	try {
		a = JSON.parse(i);
	} catch {
		return t.report("local.initial.type", {
			key: "local.initial.type.collection",
			params: { key: e.entry.node.id }
		}, r.offset, void 0), [];
	}
	return Array.isArray(a) ? n.kind === "number-array" ? a.every((e) => typeof e == "number" && Number.isFinite(e)) ? a : (t.report("local.initial.type", {
		key: "local.initial.type.number-array",
		params: { key: e.entry.node.id }
	}, r.offset, void 0), []) : a.every((e) => typeof e == "string") ? a : (t.report("local.initial.type", {
		key: "local.initial.type.array",
		params: { key: e.entry.node.id }
	}, r.offset, void 0), []) : (t.report("local.initial.type", {
		key: "local.initial.type.collection",
		params: { key: e.entry.node.id }
	}, r.offset, void 0), []);
}
function Zs(e, t, n, r, i) {
	let a = e.attrs[i.initial];
	if (!a) return [];
	let o = typeof a.value == "string" ? a.value : String(a.value ?? ""), s = [];
	for (let n of o.split(",").map((e) => e.trim()).filter(Boolean)) t.includes(n) ? s.includes(n) || s.push(n) : r.report("local.initial.option", {
		key: "local.initial.option.multi-select",
		params: {
			key: e.entry.node.id,
			value: n
		}
	}, a.offset, void 0);
	return n !== void 0 && s.length > n && r.report("local.initial.range", {
		key: "local.initial.multi-select",
		params: { max: n }
	}, a.offset, void 0), t.filter((e) => s.includes(e));
}
function Qs(e, t, n, r) {
	let i = e.attrs[n.initial], a = e.entry, o = Bs(a, e.attrs);
	if (!i) return $s(e, t, n, r, void 0);
	if (n.kind === "null") return i.raw.trim() !== "null" && t.report("local.initial.type", {
		key: "local.initial.type",
		params: { name: a.node.id }
	}, i.offset, void 0), null;
	if (a.legacy) {
		let e = qo(i.raw);
		if (e.segments.length || e.unterminated.length) {
			t.report("local.host.attribute", {
				key: "local.host.attribute.static",
				params: { name: n.initial }
			}, i.offset, i.offset + i.raw.length);
			let e = m(n.initialRule, o, r);
			return "value" in e ? e.value : "";
		}
	}
	if (n.kind === "number") return typeof i.value == "number" ? i.value : (t.report("local.initial.type", {
		key: "local.initial.type",
		params: { name: a.node.id }
	}, i.offset, void 0), 0);
	if (n.kind === "boolean") return typeof i.value == "boolean" ? i.value : (t.report("local.initial.type", {
		key: "local.initial.type",
		params: { name: a.node.id }
	}, i.offset, void 0), !1);
	let s = typeof i.value == "string" ? i.value : String(i.value ?? "");
	return p(a.kernel).some((e) => e.kind === "date") && !se(s) && t.report("local.initial.date", {
		key: "local.initial.date",
		params: { value: s }
	}, i.offset, void 0), r.length && !r.includes(s) && n.family !== "text" && n.family !== "date" && t.report("local.initial.option", {
		key: "local.initial.value.option",
		params: {
			value: s,
			options: r.join(", ")
		}
	}, i.offset, void 0), s;
}
function $s(e, t, n, r, i) {
	let a = e.entry;
	if (n.kind === "null") return null;
	if (n.family === "checklist") return [...Is(a, t, A(a.kernel, "checklist-body")?.itemLimit).checked];
	let o = i ?? Bs(a, e.attrs), s = m(n.initialRule, o, r);
	return "value" in s && s.value !== void 0 ? s.value : "error" in s && s.error === "no-step" ? (t.report("local.initial.range", {
		key: "local.initial.no-step",
		params: {
			key: a.node.id,
			min: o.min ?? "-∞",
			max: o.max ?? "∞"
		}
	}, a.node.range.start, a.node.range.end), 0) : (t.report("local.initial", {
		key: "local.initial.cannot-derive",
		params: {
			name: a.name,
			key: a.node.id
		}
	}, a.node.range.start, a.node.range.end), "");
}
function ec(e, t, n, r, i, a, o) {
	let s = e.key, c = t.attrs[r.initial]?.offset ?? t.entry.node.range.start;
	if (r.kind === "array" || r.kind === "number-array") {
		if (!Array.isArray(n)) {
			o.report("local.initial.type", {
				key: "local.initial.type.array",
				params: { key: s }
			}, c, void 0);
			return;
		}
		let e = Me(n);
		if (e) {
			o.report("local.budget.array", {
				key: e.key,
				params: {
					...e.params,
					key: s
				}
			}, c, void 0);
			return;
		}
		if (r.kind === "number-array") {
			if (!n.every((e) => typeof e == "number" && Number.isFinite(e))) {
				o.report("local.initial.type", {
					key: "local.initial.type.number-array",
					params: { key: s }
				}, c, void 0);
				return;
			}
		} else {
			if (!n.every((e) => typeof e == "string")) {
				o.report("local.initial.type", {
					key: "local.initial.type.array",
					params: { key: s }
				}, c, void 0);
				return;
			}
			if (i.length) for (let e of n) i.includes(e) || o.report("local.initial.option", {
				key: "local.initial.value.option",
				params: {
					value: e,
					options: i.join(", ")
				}
			}, c, void 0);
		}
		let a = g(t.entry.kernel, r, t.attrs);
		a !== void 0 && n.length > a && o.report("local.initial.range", {
			key: "local.initial.value.max-items",
			params: {
				key: s,
				max: a
			}
		}, c, void 0);
	} else if (r.kind === "number") {
		if (typeof n != "number" || !Number.isFinite(n)) {
			o.report("local.initial.type", {
				key: "local.initial.type.number",
				params: { key: s }
			}, t.entry.node.range.start, void 0);
			return;
		}
		let e = a ?? Bs(t.entry, t.attrs);
		e.min !== void 0 && n < e.min && o.report("local.initial.range", {
			key: "local.initial.range.min",
			params: {
				value: n,
				key: s,
				min: e.min
			}
		}, c, void 0), e.max !== void 0 && n > e.max && o.report("local.initial.range", {
			key: "local.initial.range.max",
			params: {
				value: n,
				key: s,
				max: e.max
			}
		}, c, void 0);
		let r = e.min ?? 0;
		e.dynamicMin === void 0 && n >= (e.min ?? -Infinity) && n <= (e.max ?? Infinity) && !ie(n, r, e.step) && o.report("local.initial.step", {
			key: "local.initial.range.step",
			params: {
				value: n,
				key: s,
				step: e.step,
				base: e.min ?? 0
			}
		}, c, void 0);
	} else r.kind === "boolean" && typeof n != "boolean" && o.report("local.initial.type", {
		key: "local.initial.type.boolean",
		params: { key: s }
	}, t.entry.node.range.start, void 0), (r.family === "choice" || r.family === "tabs" || r.family === "steps" || r.family === "diagram" || r.family === "selection") && i.length && !i.includes(String(n)) && o.report("local.initial.option", {
		key: "local.initial.value.options",
		params: {
			value: String(n),
			key: s,
			options: i.join(", ")
		}
	}, c, void 0);
}
function tc(e, t) {
	let n = new Set(Object.keys(t)), r = /* @__PURE__ */ new Map();
	for (let [e, n] of Object.entries(t)) for (let t of n.nodeIds) r.set(t, e);
	for (let i of e.entries) {
		let a = _(i.kernel);
		if (!a.length) continue;
		let o = e.attrs.get(i.node.id) ?? {}, s = Object.create(null), c = /* @__PURE__ */ new Map(), l = j(i.kernel);
		if (l && !l.requiresAttributes?.some((e) => !Object.hasOwn(o, e))) {
			let e = r.get(i.node.id);
			e && (s.value = e, c.set("value", e));
		}
		for (let r of a) {
			if (r.requiresAttributes?.some((e) => !Object.hasOwn(o, e))) continue;
			Ls(i, r, o, e);
			let a = o[r.bind], l;
			if (a) {
				let t = typeof a.value == "string" ? a.value : "";
				t.length > Vo ? e.report("local.budget.identifier", {
					key: "local.budget.identifier",
					params: { limit: Vo }
				}, a.offset ?? i.node.range.start, void 0) : Bo.test(t) ? ce.has(t) || Wo.has(t) ? e.report("local.binding.reserved", {
					key: "local.binding.reserved",
					params: { name: t }
				}, a.offset ?? i.node.range.start, void 0) : l = t : e.report("local.binding.name", {
					key: "local.binding.name",
					params: { name: t }
				}, a.offset ?? i.node.range.start, void 0);
			}
			let u = l ?? `@${i.node.id}:${r.slot}`;
			l && n.has(l) && (e.report("local.binding.exclusive", {
				key: "local.binding.exclusive.slot",
				params: {
					key: l,
					slot: r.slot,
					name: i.name
				}
			}, a?.offset ?? i.node.range.start, void 0), u = `@${i.node.id}:${r.slot}`), n.add(u);
			let d = C(i.kernel, r, o), f = nc(i, o, r, d, e), p = {
				name: u,
				nodeIds: [i.node.id],
				type: r.kind,
				initial: f,
				owner: i.node.id
			};
			d.min !== void 0 && (p.min = d.min), d.max !== void 0 && (p.max = d.max), p.step = d.step, t[u] = p, s[r.slot] = u, c.set(r.slot, u);
		}
		for (let n of v(i.kernel)) {
			let r = c.get(n.lower), a = c.get(n.upper);
			if (!r || !a) continue;
			let o = t[r].initial, s = t[a].initial;
			typeof o == "number" && typeof s == "number" && o > s && e.report("local.initial.range", {
				key: "local.initial.range-slider",
				params: {
					start: o,
					end: s
				}
			}, i.node.range.start, i.node.range.end);
		}
		Object.keys(s).length && (e.bindingSlots[i.node.id] = s);
	}
}
function nc(e, t, n, r, i) {
	let a = r.min ?? 0, o = t[n.initial];
	if (o && typeof o.value == "number") {
		let t = o.value;
		return r.min !== void 0 && t < r.min && i.report("local.initial.range", {
			key: "local.initial.slot.min",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				min: r.min
			}
		}, o.offset, void 0), r.max !== void 0 && t > r.max && i.report("local.initial.range", {
			key: "local.initial.slot.max",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				max: r.max
			}
		}, o.offset, void 0), ie(t, a, r.step) || i.report("local.initial.step", {
			key: "local.initial.slot.step",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				step: r.step,
				base: a
			}
		}, o.offset, void 0), t;
	}
	let s = m(n.initialRule, r, []);
	return "value" in s && s.value !== void 0 ? s.value : 0;
}
function rc(e) {
	return Object.keys(e.bindingSlots).length ? e.bindingSlots : void 0;
}
function ic(e, t) {
	let n = e.lineStarts[Gs(e, t.range.start) - 1], r = e.lineStarts[Gs(e, t.range.end)], i = r === void 0 ? e.source.length : r - 1;
	return e.source.slice(n, t.range.start).trim() === "" && e.source.slice(t.range.end, i).trim() === "";
}
function ac(e, t, n) {
	let r = cs(e.source, t.node.range.start, t.node.range.end), i = /(?:^|[\s"'/])value\s*=\s*(["'])/.exec(r);
	if (!i) return t.node.range.start;
	let a = t.node.range.start + i.index + i[0].length;
	return Math.min(t.node.range.end, a + n);
}
function oc(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = new Set(e.nodes);
	for (let i of e.entries) {
		if (i.name !== "computed" && i.name !== "const") continue;
		let a = i.name, o = i.node;
		if (!r.has(o) || !ic(e, o)) {
			e.report("local.computation.placement", `<${a}> declarations must be standalone tags at the document top level.`, o.range.start, o.range.end);
			continue;
		}
		let s = e.attrs.get(o.id) ?? {}, c = s.name, l = typeof c?.value == "string" ? c.value : "";
		if (!c || !l) continue;
		if (l.length > Vo) {
			e.report("local.budget.identifier", `Computation name exceeds the ${Vo}-character limit.`, c.offset);
			continue;
		}
		if (!Bo.test(l)) {
			e.report("local.computation.name", `Computation name "${l}" must match [A-Za-z_][A-Za-z0-9_]*.`, c.offset);
			continue;
		}
		if (ce.has(l) || Wo.has(l)) {
			e.report("local.computation.reserved", `Computation name "${l}" is reserved; choose another name.`, c.offset);
			continue;
		}
		if (Object.hasOwn(e.bindingKinds, l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" conflicts with a control parameter of the same name.`, c.offset);
			continue;
		}
		if (Object.hasOwn(e.externalKinds, l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" conflicts with an external declaration of the same name.`, c.offset);
			continue;
		}
		if (n.has(l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" is declared more than once.`, c.offset);
			continue;
		}
		n.set(l, a);
		let u = s.value;
		if (!u) continue;
		let d = Jo(u.raw);
		d ? d.expression ? t.push({
			name: l,
			kind: a,
			source: d.expression,
			expressionOffset: ac(e, i, d.start),
			nodeId: o.id,
			range: { ...o.range }
		}) : e.report("local.expression.empty", "Interpolation expression cannot be empty.", u.offset) : e.report("local.computation.value", `The value of <${a}> must be exactly one {{ expression }} interpolation.`, u.offset, u.offset + u.raw.length);
	}
	let i = be(t, {
		...e.bindingKinds,
		...e.externalKinds
	}, e.report, new Set(Object.keys(e.externalKinds)), e.semantic);
	e.computations = i.computations, e.computationKinds = i.kinds;
}
function sc(e) {
	return {
		...e.bindingKinds,
		...e.externalKinds,
		...e.computationKinds
	};
}
function cc(e) {
	let t = [], n = [{
		nodes: e,
		kept: t,
		index: 0
	}];
	for (; n.length;) {
		let e = n[n.length - 1];
		if (e.index === e.nodes.length) {
			n.pop();
			continue;
		}
		let t = e.nodes[e.index++];
		if ((t.type !== "component" || t.name !== "computed" && t.name !== "const" && t.name !== "external") && (e.kept.push(t), t.children)) {
			let e = t.children;
			t.children = [], n.push({
				nodes: e,
				kept: t.children,
				index: 0
			});
		}
	}
	return t;
}
var lc = {
	string: "string",
	number: "number",
	boolean: "boolean",
	"string-array": "array",
	"number-array": "number-array"
};
function uc(e) {
	let t = new Set(e.nodes);
	for (let n of e.entries) {
		if (n.name !== "external") continue;
		let r = n.node;
		if (!t.has(r) || !ic(e, r)) {
			e.report("local.external.placement", { key: "local.external.placement" }, r.range.start, r.range.end);
			continue;
		}
		let i = e.attrs.get(r.id) ?? {}, a = i.name, o = typeof a?.value == "string" ? a.value : "";
		if (!a || !o) continue;
		if (o.length > Vo) {
			e.report("local.budget.identifier", {
				key: "local.budget.identifier",
				params: { limit: Vo }
			}, a.offset, void 0);
			continue;
		}
		if (!Bo.test(o)) {
			e.report("local.external.name", {
				key: "local.external.name",
				params: { name: o }
			}, a.offset, void 0);
			continue;
		}
		if (ce.has(o) || Wo.has(o)) {
			e.report("local.external.reserved", {
				key: "local.external.reserved",
				params: { name: o }
			}, a.offset, void 0);
			continue;
		}
		if (Object.hasOwn(e.bindingKinds, o)) {
			e.report("local.external.duplicate", {
				key: "local.external.conflict",
				params: { name: o }
			}, a.offset, void 0);
			continue;
		}
		if (Object.hasOwn(e.externals, o)) {
			e.report("local.external.duplicate", {
				key: "local.external.duplicate",
				params: { name: o }
			}, a.offset, void 0);
			continue;
		}
		let s = i.type, c = lc[typeof s?.value == "string" ? s.value : ""];
		c ? (e.externals[o] = {
			name: o,
			type: c,
			nodeId: r.id,
			range: { ...r.range }
		}, e.externalKinds[o] = c) : e.report("local.external.type", {
			key: "local.external.type",
			params: { name: o }
		}, s?.offset ?? r.range.start, void 0);
	}
}
function dc(e) {
	for (let t of e.entries) {
		let n = e.attrs.get(t.node.id) ?? {}, r, i = (e, t, n) => {
			t.dynamic && t.expression !== void 0 && (r ??= {}, r[e] = {
				source: t.expression,
				offset: t.expressionOffset ?? t.offset,
				...n ? { numeric: n } : {}
			});
		};
		for (let e of S(t.kernel, "dynamic-constraints")) for (let t of e.attributes) if (t === "min" || t === "max" || t === "required") {
			let e = n[t];
			e && i(t, e);
		}
		let a = j(t.kernel);
		if (a?.kind === "number" && a.constraints) for (let e of ["min", "max"]) {
			let r = a.constraints[e];
			if (!r || !("prop" in r)) continue;
			let o = n[r.prop];
			if (!o) continue;
			let s = t.kernel.props[r.prop];
			i(e, o, s ? {
				...s.min === void 0 ? {} : { min: s.min },
				...s.max === void 0 ? {} : { max: s.max },
				...s.integer === !0 ? { integer: !0 } : {}
			} : void 0);
		}
		r && (e.dynamicConstraints[t.node.id] = r);
	}
}
function fc(e) {
	let t = sc(e), n = Object.keys(t), r = (t, n) => {
		t instanceof L ? e.report(`local.expression.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0), void 0, {
			key: "local.expression.error",
			params: {
				detail: t.message,
				code: t.code || "invalid",
				near: e.source.slice(Math.max(n, n + t.offset - 16), n + t.offset + 24)
			}
		}) : e.report("local.expression.invalid", {
			key: "local.expression.error",
			params: {
				detail: t instanceof Error ? t.message : String(t),
				code: "invalid"
			}
		}, n, void 0);
	}, i = (i, a, o) => {
		if (!i.trim()) return e.report("local.expression.empty", { key: "local.expression.empty" }, a, void 0), null;
		let s = null;
		try {
			s = e.semantic?.expression(i) ?? we(i);
		} catch (e) {
			return r(e, a), null;
		}
		if (!s) return null;
		let c = !1;
		for (let r of s.dependencies) if (!Object.hasOwn(t, r)) {
			let t = bc(r, n);
			e.report("local.binding.unknown", t ? {
				key: "local.binding.unknown.suggestion",
				params: {
					name: r,
					suggestion: t
				}
			} : {
				key: "local.binding.unknown",
				params: { name: r }
			}, a + Math.max(0, i.indexOf(r)), void 0), c = !0;
		}
		if (c) return null;
		let l;
		try {
			l = e.semantic ? e.semantic.infer(s, t) : s.inferType(t);
		} catch (e) {
			return r(e, a), null;
		}
		return o === "number" && l !== "number" ? e.report("local.type", {
			key: "local.type.number",
			params: { kind: $o(l) }
		}, a, void 0) : o === "boolean" && l !== "boolean" ? e.report("local.type", {
			key: "local.type.boolean",
			params: { kind: $o(l) }
		}, a, void 0) : o === "string" && l !== "string" ? e.report("local.type", {
			key: "local.type.string",
			params: { kind: $o(l) }
		}, a, void 0) : o === "text" && (l === "array" || l === "number-array") && e.report("local.type", { key: "local.type.array" }, a, void 0), l;
	};
	for (let t of V(e.nodes)) if (t.type === "interpolation") {
		let n = e.source.slice(t.range.start + 2, Math.max(t.range.start + 2, t.range.end - 2)), r = t.value ?? "", a = Math.max(0, n.indexOf(r)), o = t.range.start + 2 + a;
		e.expressionKinds.set(t.id, i(r, o, "text"));
	}
	for (let t of e.entries) {
		if (t.name === "computed" || t.name === "const") continue;
		let n = e.attrs.get(t.node.id) ?? {}, r = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
		for (let e of x(t.kernel)) if (e.kind === "scoped-expressions") for (let t of e.attributes) r.add(t);
		else if (e.kind === "row-values") r.add(e.rows), r.add(e.key);
		else if (e.kind === "validation-rule") r.add(e.when);
		else if (e.kind === "require-full-interpolation") for (let t of e.attributes) a.add(t);
		for (let [a, o] of Object.entries(n)) {
			let n = t.kernel.props[a];
			if (n && !n.static && !r.has(a)) {
				if (n.kind === "string") {
					if (n.dynamic) {
						o.dynamic && i(o.expression ?? "", o.expressionOffset ?? o.offset, "string");
						continue;
					}
					let t = qo(o.raw);
					for (let n of t.unterminated) e.report("local.interpolation", { key: "local.interpolation.unclosed" }, o.offset + n, void 0);
					for (let e of t.segments) i(e.expression, o.offset + e.start, "text");
				} else o.dynamic && (n.kind === "number" ? i(o.expression ?? "", o.expressionOffset ?? o.offset, "number") : n.kind === "boolean" ? i(o.expression ?? "", o.expressionOffset ?? o.offset, "boolean") : n.kind === "enum" && i(o.expression ?? "", o.expressionOffset ?? o.offset, "string"));
			}
		}
		for (let r of a) {
			let i = n[r];
			i && !Ic(i.raw) && e.report("local.attribute.interpolation", {
				key: "local.attribute.interpolation",
				params: {
					name: r,
					component: t.name
				}
			}, i.offset, void 0);
		}
	}
}
function pc(e, t, n) {
	let r = {
		syntax: "local",
		source: e.source,
		nodes: e.nodes,
		initialState: n,
		bindings: t,
		...Object.keys(e.computations).length ? { computations: e.computations } : {}
	}, i = "__local_core_check__", a = Vt(r, i, !1), o = /* @__PURE__ */ new Set();
	for (let t of V(e.nodes)) if (t.type === "heading") {
		let e = a.ids.get(t);
		e && e.startsWith(`${i}-`) && o.add(e.slice(21));
	}
	let s = /* @__PURE__ */ new Set();
	for (let t of e.entries) {
		let n = A(t.kernel, "anchor");
		if (!n) continue;
		let r = (e.attrs.get(t.node.id) ?? {})[n.id];
		if (!r) continue;
		let i = typeof r.value == "string" ? r.value : "";
		!i || !ne(i) ? e.report("local.anchor.id", {
			key: "local.anchor.id",
			params: { id: i }
		}, r.offset, void 0) : (s.has(i) ? e.report("local.anchor.duplicate", {
			key: "local.anchor.duplicate",
			params: { id: i }
		}, r.offset, void 0) : s.add(i), o.has(i) && e.report("local.anchor.duplicate", {
			key: "local.anchor.heading-collision",
			params: { id: i }
		}, r.offset, void 0));
	}
	let c = [];
	for (let t of e.entries) {
		let n = A(t.kernel, "navigation");
		if (!n) continue;
		let r = (e.attrs.get(t.node.id) ?? {})[n.target];
		r && c.push({
			name: t.name,
			target: typeof r.value == "string" ? r.value : "",
			offset: r.offset
		});
	}
	for (let t of h(c, s, o)) e.report(t.code, t.message, t.start, t.end, {
		key: t.key,
		...t.params ? { params: t.params } : {}
	});
}
function mc(e, t, n) {
	t instanceof L ? e.report(`local.expression.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0)) : e.report("local.expression.invalid", `Expression error: ${t instanceof Error ? t.message : String(t)}`, n);
}
function hc(e, t, n, r, i) {
	if (!t.trim()) return e.report("local.expression.empty", "Interpolation expression cannot be empty.", n), null;
	let a;
	try {
		a = e.semantic?.expression(t) ?? we(t);
	} catch (t) {
		return mc(e, t, n), null;
	}
	let o = Object.keys(r), s = !1;
	for (let i of a.dependencies) if (!Object.hasOwn(r, i)) {
		let r = bc(i, o);
		e.report("local.binding.unknown", `Reference to undeclared parameter ${i}.${r ? ` Did you mean ${r}?` : ""}`, n + Math.max(0, t.indexOf(i))), s = !0;
	}
	if (s || !i) return {
		compiled: a,
		kind: null
	};
	let c;
	try {
		c = e.semantic ? e.semantic.infer(a, r) : a.inferType(r);
	} catch (t) {
		return mc(e, t, n), null;
	}
	return {
		compiled: a,
		kind: c
	};
}
function gc(e, t, n, r, i) {
	if (!e) return null;
	let a = Jo(e.raw);
	return a ? a.expression ? {
		expression: a.expression,
		base: e.offset + a.start
	} : (i.report("local.expression.empty", "Interpolation expression cannot be empty.", e.offset + a.start), null) : (i.report(t, `<${n}> ${r} must be exactly one {{ expression }} interpolation.`, e.offset, e.offset + e.raw.length), null);
}
function _c(e, t) {
	let n = e[t.maxRows], i = Math.min(t.defaultMaxRows, r);
	return n && !n.dynamic && typeof n.value == "number" && Number.isInteger(n.value) && n.value > 0 && n.value <= 1e3 ? n.value : i;
}
function vc(e) {
	let t = [];
	for (let n of e.entries) {
		let e = A(n.kernel, "data-table");
		e && t.push([n, e]);
	}
	if (!t.length) return;
	let n = sc(e), r = 0, i = 0, a = !1, o = !1;
	for (let [l, u] of t) {
		let t = e.attrs.get(l.node.id) ?? {}, d = $(l.node.children).filter((e) => (e.type === "component" || e.type === "hostComponent") && e.name === u.child), f = _c(t, u), p = Math.min(u.maxColumns, 20), m = Math.min(u.documentRows, c), h = Math.min(u.documentCells, s), g = Math.min(d.length, p);
		r += f, i += f * g, !a && r > m && (a = !0, e.report("local.budget.data-table.rows", `The document's generated row budget exceeds ${m}; ${u.maxRows} summed over every <${l.name}> must stay within it.`, l.node.range.start, l.node.range.end)), !o && i > h && (o = !0, e.report("local.budget.data-table.cells", `The document's generated cell budget exceeds ${h}; ${u.maxRows} multiplied by columns, summed over every <${l.name}>, must stay within it.`, l.node.range.start, l.node.range.end));
		let _ = gc(t[u.rows], "local.data-table.rows", l.name, u.rows, e), v = "string", y = !1;
		if (_) {
			let t = hc(e, _.expression, _.base, n, !0);
			t?.kind === "array" ? (v = "string", y = !0) : t?.kind === "number-array" ? (v = "number", y = !0) : t && t.kind !== null && e.report("local.data-table.rows", `<${l.name}> ${u.rows} must evaluate to an array, but the expression evaluates to ${$o(t.kind)}.`, _.base);
		}
		let b = {
			...n,
			item: v,
			index: "number"
		}, x = gc(t[u.key], "local.data-table.key", l.name, u.key, e);
		if (x) {
			let t = hc(e, x.expression, x.base, b, y);
			if (t) {
				let r = t.compiled.dependencies;
				r.includes("item") || e.report("local.data-table.key", `<${l.name}> key must depend on item.`, x.base);
				for (let t of r) t !== "item" && (t === "index" ? e.report("local.data-table.key", `<${l.name}> key cannot depend on index; use a stable item identifier.`, x.base) : Object.hasOwn(n, t) && e.report("local.data-table.key", `<${l.name}> key cannot depend on global parameter "${t}"; it must be derived from item only.`, x.base));
				t.kind !== null && t.kind !== "string" && t.kind !== "number" && e.report("local.data-table.key", `<${l.name}> key must evaluate to a string or number, got ${$o(t.kind)}.`, x.base);
			}
		}
		for (let t of d) {
			let n = e.attrs.get(t.id) ?? {}, r = n[u.label];
			r && !String(r.value ?? "").trim() && e.report("local.data-table.column", `<${u.child}> ${u.label} cannot be empty.`, r.offset);
			let i = gc(n[u.childValue], "local.data-table.value", u.child, u.childValue, e);
			if (!i) continue;
			let a = hc(e, i.expression, i.base, b, y);
			a && (a.kind === "array" || a.kind === "number-array") && e.report("local.data-table.value", `<${u.child}> ${u.childValue} must be a scalar string, number, boolean or null, got ${$o(a.kind)}.`, i.base);
		}
	}
}
function yc(e) {
	let t = [], n = 0, r = !1, i = Object.keys(e.bindingKinds), a = sc(e);
	for (let o of e.entries) {
		let s = A(o.kernel, "validation-rule");
		if (!s) continue;
		n += 1;
		let c = o.node, l = Math.min(s.max, 100);
		if (n > l) {
			r || (r = !0, e.report("local.validation.budget", `The document declares more than ${l} validation rules; rules in hidden regions count too.`, c.range.start, c.range.end));
			continue;
		}
		o.parent && (o.parent.kernel.form !== "container" || A(o.parent.kernel, "data-table") !== void 0) && e.report("local.validation.placement", `<${o.name}> can appear in normal prose or a container, but not inside inline content or a data table.`, c.range.start, c.range.end);
		let u = e.attrs.get(c.id) ?? {}, d = "", f = [], p = u[s.when];
		if (p) {
			let t = Jo(p.raw);
			if (!t) e.report("local.validation.when", `<${o.name}> ${s.when} must be exactly one {{ boolean }} interpolation.`, p.offset, p.offset + p.raw.length);
			else if (t.expression) {
				d = t.expression;
				let n = hc(e, d, p.offset + t.start, a, !0);
				n && (f = [...n.compiled.dependencies], n.kind !== null && n.kind !== "boolean" && e.report("local.type", `Expected a boolean here, but the expression evaluates to ${$o(n.kind)}.`, p.offset + t.start));
			}
		}
		let m = u[s.fields], h = m ? Ne(m.raw) : [];
		m && !h.length && e.report("local.validation.fields", `<${o.name}> requires at least one field name.`, m.offset, m.offset + m.raw.length);
		let g = /* @__PURE__ */ new Set();
		for (let t of h) if (g.has(t)) e.report("local.validation.fields", `Duplicate field "${t}" in <${o.name}> fields.`, m?.offset ?? c.range.start);
		else if (g.add(t), !Object.hasOwn(e.bindingKinds, t)) {
			let n = bc(t, i);
			e.report("local.validation.fields", `Field "${t}" is not a public writable parameter.${n ? ` Did you mean ${n}?` : ""}`, m?.offset ?? c.range.start);
		}
		d && t.push({
			nodeId: c.id,
			expression: d,
			dependencies: f,
			message: typeof u[s.message]?.value == "string" ? String(u[s.message].value) : "",
			fields: [...g],
			range: { ...c.range }
		});
	}
	return t;
}
function bc(e, t) {
	if (e.length > Vo) return;
	let n, r = Infinity;
	for (let i of t) {
		let t = xc(e, i);
		t < r && (n = i, r = t);
	}
	return r <= 2 ? n : void 0;
}
function xc(e, t) {
	let n = Array.from({ length: t.length + 1 }, (e, t) => t);
	for (let r = 1; r <= e.length; r++) {
		let i = n[0];
		n[0] = r;
		for (let a = 1; a <= t.length; a++) {
			let o = n[a];
			n[a] = Math.min(n[a] + 1, n[a - 1] + 1, i + (e[r - 1] === t[a - 1] ? 0 : 1)), i = o;
		}
	}
	return n[t.length];
}
function Sc(e, t, n) {
	let r = e.kernel.props[n.samples]?.default, i = typeof r == "number" ? r : 200;
	return gs(e, t, n.samples) ?? i;
}
function Cc(e) {
	let t = sc(e), n = 0, r = !1;
	for (let i of e.entries) {
		let a = A(i.kernel, "plot-math");
		if (!a) continue;
		let o = e.plotMath;
		if (!o) {
			e.report("local.capability.plot", { key: "local.capability.plot" }, i.node.range.start, i.node.range.end);
			continue;
		}
		let s = e.attrs.get(i.node.id) ?? {}, c = $(i.node.children).filter((e) => e.type === "math"), u = Sc(i, s, a), d = Math.min(a.curves, 16), f = Math.min(a.points, l);
		c.length > d && e.report("local.budget.plot.curves", {
			key: "local.budget.plot.curves",
			params: {
				limit: d,
				count: c.length
			}
		}, i.node.range.start, i.node.range.end);
		let p = c.map((e) => o.kind(e.value ?? "")), m = p.reduce((e, t) => e + (t === "implicit" ? o.gridSize(u) ** 2 : u), 0), h = n + m;
		if (!r && h > f && (e.report("local.budget.plot.points", {
			key: "local.budget.plot.points",
			params: { limit: f }
		}, i.node.range.start, i.node.range.end), r = !0), n = Math.min(f + 1, h), !(c.length > d || r)) for (let n = 0; n < c.length; n += 1) {
			let r = c[n], i = (r.value ?? "").trim();
			if (p[n] === null) {
				e.report("local.math.formula", { key: "local.math.formula.shape" }, r.range.start, r.range.end);
				continue;
			}
			let a = null;
			try {
				a = o.compile(i);
			} catch (t) {
				e.report("local.math", {
					key: "local.math.compute",
					params: {
						detail: t instanceof Error ? t.message : String(t),
						code: t && typeof t == "object" && "code" in t && typeof t.code == "string" ? t.code : "latex-syntax",
						near: i.slice(0, 120)
					}
				}, r.range.start, r.range.end);
			}
			if (a) for (let n of a.dependencies) n !== "x" && n !== "y" && n !== "t" && (Object.hasOwn(t, n) ? t[n] !== "number" && e.report("local.math.binding", {
				key: "local.math.binding.type",
				params: {
					name: n,
					kind: $o(t[n])
				}
			}, r.range.start, r.range.end) : e.report("local.math.binding", {
				key: "local.math.binding.unknown",
				params: { name: n }
			}, r.range.start, r.range.end));
		}
	}
}
function wc(e, t, n) {
	let r = (e.children ?? []).filter((e) => e.type === "tableRow");
	if (!r.length) return t.report("local.table.header", {
		key: "local.table.header.missing",
		params: { name: n.name }
	}, e.range.start, e.range.end), null;
	let i = r[0].children ?? [], a = [];
	for (let e of i) {
		if (Zo(e)) return t.report("local.table.header", { key: "local.table.header.interpolation" }, e.range.start, e.range.end), null;
		let n = Xo(e).trim();
		if (!n) return t.report("local.table.header", { key: "local.table.header.empty" }, e.range.start, e.range.end), null;
		if (a.includes(n)) return t.report("local.table.header", {
			key: "local.table.header.duplicate",
			params: { name: n }
		}, e.range.start, e.range.end), null;
		a.push(n);
	}
	if (!a.length) return t.report("local.table.header", { key: "local.table.header.empty" }, e.range.start, e.range.end), null;
	let o = [];
	for (let e of r.slice(1)) {
		let n = e.children ?? [];
		n.length === a.length ? o.push(n) : t.report("local.table.row", {
			key: "local.table.row.mismatch",
			params: {
				header: a.length,
				row: n.length
			}
		}, e.range.start, e.range.end);
	}
	return {
		header: a,
		rows: o
	};
}
function Tc(e, t) {
	let n = $(e.children);
	if (n.length === 1 && n[0].type === "interpolation") {
		let e = t.expressionKinds.get(n[0].id);
		if (e === "number" || e === null) return !0;
		if (e !== void 0) return !1;
	}
	let r = Xo(e).trim();
	return r ? Go(r) !== null : !1;
}
function Ec(e, t, n, r, i) {
	let a = e.header[t], o = A(r.kernel, "timeline-table") !== void 0;
	e.rows.forEach((e, r) => {
		let i = e[t];
		if (!i) return;
		let s = $(i.children);
		if (s.length === 1 && s[0].type === "interpolation") {
			let e = n.expressionKinds.get(s[0].id);
			e != null && e !== "number" && n.report("local.chart.numeric", {
				key: o ? "local.timeline.numeric.expression" : "local.chart.numeric.expression",
				params: {
					name: a,
					row: r + 1,
					kind: $o(e)
				}
			}, i.range.start, i.range.end);
		} else Tc(i, n) || n.report("local.chart.numeric", {
			key: o ? "local.timeline.numeric.plain" : "local.chart.numeric.plain",
			params: {
				name: a,
				row: r + 1,
				value: Xo(i).trim() || "empty"
			}
		}, i.range.start, i.range.end);
	});
}
function Dc(e, t) {
	return e.indexOf(t);
}
function Oc(e) {
	for (let t of e.entries) {
		if (!A(t.kernel, "single-table")) continue;
		let n = A(t.kernel, "chart-table"), r = A(t.kernel, "timeline-table");
		if (!n && !r) {
			kc(t, e);
			continue;
		}
		let i = kc(t, e);
		i && (n ? Mc(t, i, e, n) : r && Nc(t, i, e, r));
	}
}
function kc(e, t) {
	if (t.tableShapes.has(e.node.id)) return t.tableShapes.get(e.node.id) ?? null;
	let n = t.tables.get(e.node.id), r = n ? wc(n, t, e) : null;
	return t.tableShapes.set(e.node.id, r), r;
}
function Ac(e, t) {
	if (t.size === 0) return;
	let n = Object.create(null), r = 0;
	for (let [e, i] of t) i && (n[e] = Object.freeze({
		header: Object.freeze([...i.header]),
		rowIds: Object.freeze(i.rows.map((e) => Object.freeze(e.map((e) => e.id))))
	}), r += 1);
	r !== 0 && (e.tableShapes = Object.freeze(n));
}
function jc(e) {
	for (let t of e.entries) {
		let n = A(t.kernel, "table-selection");
		if (!n) continue;
		let r = e.attrs.get(t.node.id) ?? {}, i = r[n.key];
		if (!i) continue;
		let a = typeof i.value == "string" ? i.value.trim() : "";
		if (!a) {
			e.report("local.selection.key", {
				key: "local.selection.key.empty",
				params: { component: t.name }
			}, i.offset, void 0), e.selections.set(t.node.id, [""]);
			continue;
		}
		let o = kc(t, e);
		if (!o) {
			e.selections.set(t.node.id, [""]);
			continue;
		}
		let s = Dc(o.header, a);
		if (s < 0) {
			e.report("local.selection.key", {
				key: "local.selection.key.missing-column",
				params: {
					component: t.name,
					name: a
				}
			}, i.offset, void 0), e.selections.set(t.node.id, [""]);
			continue;
		}
		let c = [], l = /* @__PURE__ */ new Set();
		o.rows.forEach((n, r) => {
			let i = n[s];
			if (!i) return;
			if (Zo(i)) {
				e.report("local.selection.key", {
					key: "local.selection.key.interpolation",
					params: {
						component: t.name,
						name: a,
						row: r + 1
					}
				}, i.range.start, i.range.end);
				return;
			}
			let o = Xo(i).trim();
			o ? l.has(o) ? e.report("local.selection.key", {
				key: "local.selection.key.duplicate",
				params: {
					component: t.name,
					name: a,
					value: o
				}
			}, i.range.start, i.range.end) : (l.add(o), c.push(o)) : e.report("local.selection.key", {
				key: "local.selection.key.empty-cell",
				params: {
					component: t.name,
					name: a,
					row: r + 1
				}
			}, i.range.start, i.range.end);
		}), e.selections.set(t.node.id, ["", ...c]);
		let u = r.initial;
		u && typeof u.value == "string" && u.value !== "" && !c.includes(u.value) && e.report("local.initial.option", {
			key: "local.selection.key.initial",
			params: {
				value: u.value,
				component: t.name,
				name: a
			}
		}, u.offset, void 0);
	}
}
function Mc(e, t, n, r) {
	let i = n.attrs.get(e.node.id) ?? {}, a = typeof i[r.chartKind]?.value == "string" ? String(i[r.chartKind].value) : "bar", o = t.header;
	for (let t of o) t.includes(",") && n.report("local.chart.column", {
		key: "local.chart.column.comma",
		params: { name: t }
	}, e.node.range.start, e.node.range.end);
	let s = typeof i[r.x]?.value == "string" ? String(i[r.x].value).trim() : "", c = typeof i[r.y]?.value == "string" ? String(i[r.y].value).trim() : "";
	s && Dc(o, s) < 0 && n.report("local.chart.column", {
		key: "local.chart.column.x-missing",
		params: { name: s }
	}, i[r.x]?.offset ?? e.node.range.start, void 0);
	let l = [];
	if (c) {
		l = c.split(",").map((e) => e.trim()).filter(Boolean), l.length || n.report("local.chart.column", { key: "local.chart.column.y-required" }, i[r.y]?.offset ?? e.node.range.start, void 0);
		for (let t of l) Dc(o, t) < 0 && n.report("local.chart.column", {
			key: "local.chart.column.y-missing",
			params: { name: t }
		}, i[r.y]?.offset ?? e.node.range.start, void 0);
	}
	let u = [];
	if (a === "bar" || a === "line" || a === "area") {
		let t = s ? Math.max(0, Dc(o, s)) : 0;
		u = l.length ? l.map((e) => Dc(o, e)).filter((e) => e >= 0) : o.map((e, t) => t).filter((e) => e !== t), u.length || n.report("local.chart.column", { key: "local.chart.column.needs-numeric" }, e.node.range.start, e.node.range.end);
	} else if (a === "scatter") {
		let r = s ? Dc(o, s) : 0;
		r < 0 ? n.report("local.chart.column", {
			key: "local.chart.column.scatter-x-missing",
			params: { name: s }
		}, e.node.range.start, void 0) : Ec(t, r, n, e, "x"), u = l.length ? l.map((e) => Dc(o, e)).filter((e) => e >= 0) : o.map((e, t) => t).filter((e) => e !== r), u.length || n.report("local.chart.column", { key: "local.chart.column.scatter-needs-numeric" }, e.node.range.start, e.node.range.end);
	} else if (a === "donut") {
		if (o.length < 2) {
			n.report("local.chart.column", { key: "local.chart.column.donut-columns" }, e.node.range.start, e.node.range.end);
			return;
		}
		if (l.length === 1) {
			let e = Dc(o, l[0]);
			e >= 0 && (u = [e]);
		} else l.length > 1 ? n.report("local.chart.column", { key: "local.chart.column.donut-y" }, i[r.y]?.offset ?? e.node.range.start, void 0) : o.length > 2 ? n.report("local.chart.column", { key: "local.chart.column.donut-need-y" }, e.node.range.start, e.node.range.end) : u = [1];
	}
	u = [...new Set(u)];
	for (let r of u) Ec(t, r, n, e, "y");
	if (a === "donut") for (let e of u) t.rows.forEach((t, r) => {
		let i = t[e];
		if (!i || $(i.children).length) return;
		let a = Go(Xo(i).trim());
		a !== null && a < 0 && n.report("local.chart.negative", {
			key: "local.chart.negative",
			params: {
				row: r + 1,
				value: a
			}
		}, i.range.start, i.range.end);
	});
}
function Nc(e, t, n, r) {
	let i = r.headerSets.map((e) => ({
		title: e[0] ?? "",
		start: e[1] ?? "",
		duration: e[2] ?? "",
		notes: e[3] ?? ""
	})).find((e) => t.header.includes(e.title) && t.header.includes(e.start) && t.header.includes(e.duration));
	if (!i) {
		n.report("local.timeline.header", { key: "local.timeline.header.missing" }, e.node.range.start, e.node.range.end);
		return;
	}
	let a = new Set(Object.values(i));
	for (let r of t.header) a.has(r) || n.report("local.timeline.header", {
		key: "local.timeline.header.column",
		params: { name: r }
	}, e.node.range.start, e.node.range.end);
	for (let r of [i.start, i.duration]) {
		let i = Dc(t.header, r);
		i >= 0 && Ec(t, i, n, e, r);
	}
	let o = Dc(t.header, i.start), s = Dc(t.header, i.duration);
	t.rows.forEach((e, r) => {
		for (let i of [o, s]) {
			if (i < 0) continue;
			let a = e[i];
			if (!a || $(a.children).length) continue;
			let o = Go(Xo(a).trim());
			o !== null && o < 0 && n.report("local.timeline.value", {
				key: "local.timeline.value.negative",
				params: {
					name: t.header[i],
					row: r + 1
				}
			}, a.range.start, a.range.end);
		}
	});
}
function Pc(e, t, n, r, i = r + 1, a) {
	let o = typeof n == "string" ? a : n, s = typeof n == "string" ? n : O(n);
	if (e.diagnostics.length >= 100) return;
	let c = Math.max(0, Math.min(e.source.length, r)), l = Math.max(c, Math.min(e.source.length, Math.max(c, i))), u = 0, f = e.lineStarts.length - 1;
	for (; u < f;) {
		let t = Math.ceil((u + f) / 2);
		e.lineStarts[t] <= c ? u = t : f = t - 1;
	}
	let p = y(o?.key ?? t, o?.params);
	e.diagnostics.push({
		code: t,
		message: s.length > 2e3 ? `${s.slice(0, d - 1)}…` : s,
		severity: "warning",
		range: {
			start: c,
			end: l
		},
		line: u + 1,
		column: c - e.lineStarts[u] + 1,
		messageKey: p.key,
		...p.params ? { params: p.params } : {}
	});
}
function Fc(e, t) {
	if (t.size === 0) return;
	let n = /* @__PURE__ */ new Map();
	for (let r of V(e)) {
		if (r.type !== "hostComponent" || !r.name) continue;
		let e = t.get(r.name);
		e !== void 0 && n.set(e.id, o(e));
	}
	if (n.size === 0) return;
	let r = Object.freeze([...n.values()].sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
	return Object.freeze({
		protocol: i,
		components: r
	});
}
function Ic(e) {
	if (!Jo(e)) return !1;
	let t = qo(e);
	return t.segments.length === 1 && t.unterminated.length === 0;
}
function Lc(e, t) {
	let n = {}, r = {}, i = {}, a = [], o = new Map(e.entries.map((e) => [e.node.id, e])), s = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots)) {
		let e = o.get(t);
		if (e) for (let [t, r] of Object.entries(n)) s.set(r, {
			entry: e,
			slot: t
		});
	}
	for (let [e, n] of Object.entries(t)) {
		let t = s.get(e);
		if (t) {
			let n = _(t.entry.kernel).find((e) => e.slot === t.slot);
			n && (i[e] = {
				bind: n.bind,
				initial: n.initial
			});
			continue;
		}
		let r = o.get(n.owner ?? n.nodeIds[0] ?? ""), a = r ? j(r.kernel) : void 0;
		a && (i[e] = {
			bind: a.bind,
			initial: a.initial
		});
	}
	for (let t of e.entries) {
		let i = p(t.kernel);
		i.length && (n[t.node.id] = Object.freeze([...i]));
		let o = A(t.kernel, "self-binding-read"), s = A(t.kernel, "inline-math-reads");
		(o || s) && (r[t.node.id] = {
			...o ? { selfBinding: {
				mode: o.mode,
				...o.attribute ? { attribute: o.attribute } : {}
			} } : {},
			...s ? { inlineMathReads: !0 } : {}
		});
		for (let n of v(t.kernel)) e.bindingSlots[t.node.id]?.[n.lower] && e.bindingSlots[t.node.id]?.[n.upper] && a.push({
			nodeId: t.node.id,
			lower: n.lower,
			upper: n.upper
		});
	}
	let c = [];
	for (let [e, n] of Object.entries(t)) n.nodeIds.some((e) => {
		let t = o.get(e);
		return (t ? j(t.kernel) : void 0)?.retain === !1;
	}) && c.push(e);
	return Object.keys(n).length === 0 && Object.keys(r).length === 0 && Object.keys(i).length === 0 && a.length === 0 && c.length === 0 ? {
		valueRules: Object.freeze({}),
		slotRelations: Object.freeze([]),
		retentionExclusions: Object.freeze([])
	} : {
		valueRules: Object.freeze(n),
		slotRelations: Object.freeze(a.map((e) => Object.freeze(e))),
		retentionExclusions: Object.freeze(c.sort()),
		...Object.keys(i).length ? { bindingAttributes: Object.freeze(i) } : {},
		...Object.keys(r).length ? { dependencyRules: Object.freeze(r) } : {}
	};
}
function Rc(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r of e.entries) {
		let e = r.definition;
		e && !t.has(e.id) && (t.add(e.id), n.push(e));
	}
	return n;
}
function zc(e, t) {
	for (let n of V(e)) n.type === "hostComponent" && (n.name && t.schemaByName.has(n.name) || Pc(t, "local.component.unknown", {
		key: "local.component.unknown",
		params: { name: n.name ?? "" }
	}, n.range.start, n.range.end));
}
export { Ke as S, Ot as _, fa as a, We as b, Vt as c, Mt as d, K as f, Tt as g, yt as h, po as i, kt as l, Dt as m, Ro as n, da as o, Et as p, Lo as r, Rt as s, as as t, Pt as u, ut as v, qe as x, wt as y };
