import { Y as e } from "./config-validation-DaLdxnS1.js";
// node_modules/katex/dist/katex.mjs
var t = class e extends Error {
	constructor(t, n) {
		var r = "KaTeX parse error: " + t, i, a, o = n && n.loc;
		if (o && o.start <= o.end) {
			var s = o.lexer.input;
			i = o.start, a = o.end, i === s.length ? r += " at end of input: " : r += " at position " + (i + 1) + ": ";
			var c = s.slice(i, a).replace(/[^]/g, "$&̲"), l = i > 15 ? "…" + s.slice(i - 15, i) : s.slice(0, i), u = a + 15 < s.length ? s.slice(a, a + 15) + "…" : s.slice(a);
			r += l + c + u;
		}
		super(r), this.name = "ParseError", this.position = void 0, this.length = void 0, this.rawMessage = void 0, Object.setPrototypeOf(this, e.prototype), this.position = i, i != null && a != null && (this.length = a - i), this.rawMessage = t;
	}
}, n = /([A-Z])/g, r = (e) => e.replace(n, "-$1").toLowerCase(), i = {
	"&": "&amp;",
	">": "&gt;",
	"<": "&lt;",
	"\"": "&quot;",
	"'": "&#x27;"
}, a = /[&><"']/g, o = (e) => String(e).replace(a, (e) => i[e]), s = (e) => e.type === "ordgroup" || e.type === "color" ? e.body.length === 1 ? s(e.body[0]) : e : e.type === "font" ? s(e.body) : e, c = /* @__PURE__ */ new Set([
	"mathord",
	"textord",
	"atom"
]), l = (e) => c.has(s(e).type), u = (e) => {
	var t = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(e);
	return t ? t[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(t[1]) ? null : t[1].toLowerCase() : "_relative";
}, d = {
	displayMode: {
		type: "boolean",
		description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.",
		cli: "-d, --display-mode"
	},
	output: {
		type: { enum: [
			"htmlAndMathml",
			"html",
			"mathml"
		] },
		description: "Determines the markup language of the output.",
		cli: "-F, --format <type>"
	},
	leqno: {
		type: "boolean",
		description: "Render display math in leqno style (left-justified tags)."
	},
	fleqn: {
		type: "boolean",
		description: "Render display math flush left."
	},
	throwOnError: {
		type: "boolean",
		default: !0,
		cli: "-t, --no-throw-on-error",
		cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error."
	},
	errorColor: {
		type: "string",
		default: "#cc0000",
		cli: "-c, --error-color <color>",
		cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.",
		cliProcessor: (e) => "#" + e
	},
	macros: {
		type: "object",
		cli: "-m, --macro <def>",
		cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).",
		cliDefault: [],
		cliProcessor: (e, t) => (t.push(e), t)
	},
	minRuleThickness: {
		type: "number",
		description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.",
		processor: (e) => Math.max(0, e),
		cli: "--min-rule-thickness <size>",
		cliProcessor: parseFloat
	},
	colorIsTextColor: {
		type: "boolean",
		description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.",
		cli: "-b, --color-is-text-color"
	},
	strict: {
		type: [
			{ enum: [
				"warn",
				"ignore",
				"error"
			] },
			"boolean",
			"function"
		],
		description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.",
		cli: "-S, --strict",
		cliDefault: !1
	},
	trust: {
		type: ["boolean", "function"],
		description: "Trust the input, enabling all HTML features such as \\url.",
		cli: "-T, --trust"
	},
	maxSize: {
		type: "number",
		default: Infinity,
		description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large",
		processor: (e) => Math.max(0, e),
		cli: "-s, --max-size <n>",
		cliProcessor: parseInt
	},
	maxExpand: {
		type: "number",
		default: 1e3,
		description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.",
		processor: (e) => Math.max(0, e),
		cli: "-e, --max-expand <n>",
		cliProcessor: (e) => e === "Infinity" ? Infinity : parseInt(e)
	},
	globalGroup: {
		type: "boolean",
		cli: !1
	}
};
function f(e) {
	if (typeof e != "string") return e.enum[0];
	switch (e) {
		case "boolean": return !1;
		case "string": return "";
		case "number": return 0;
		case "object": return {};
		default: throw Error("Unexpected schema type; settings must declare an explicit default.");
	}
}
function p(e) {
	return Object.prototype.hasOwnProperty.call(e, "default") && e.default !== void 0 ? e.default : f(Array.isArray(e.type) ? e.type[0] : e.type);
}
function m(e, t, n, r) {
	var i = Object.prototype.hasOwnProperty.call(n, t) ? n[t] : void 0, a = Object.prototype.hasOwnProperty.call(r, "processor") ? r.processor : void 0;
	e[t] = i === void 0 ? p(r) : a ? a(i) : i;
}
var h = class {
	constructor(e) {
		e === void 0 && (e = {}), this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, e ||= {};
		for (var t of Object.keys(d)) {
			var n = d[t];
			n && m(this, t, e, n);
		}
	}
	isTrusted(e) {
		if ("url" in e && e.url && !e.protocol) {
			var t = u(e.url);
			if (t == null) return !1;
			e.protocol = t;
		}
		return !!(typeof this.trust == "function" ? this.trust(e) : this.trust);
	}
}, g = class {
	constructor(e, t, n) {
		this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = n;
	}
	sup() {
		return ee[te[this.id]];
	}
	sub() {
		return ee[ne[this.id]];
	}
	fracNum() {
		return ee[re[this.id]];
	}
	fracDen() {
		return ee[ie[this.id]];
	}
	cramp() {
		return ee[ae[this.id]];
	}
	text() {
		return ee[oe[this.id]];
	}
	isTight() {
		return this.size >= 2;
	}
}, _ = 0, v = 1, y = 2, b = 3, x = 4, S = 5, C = 6, w = 7, ee = [
	new g(_, 0, !1),
	new g(v, 0, !0),
	new g(y, 1, !1),
	new g(b, 1, !0),
	new g(x, 2, !1),
	new g(S, 2, !0),
	new g(C, 3, !1),
	new g(w, 3, !0)
], te = [
	x,
	S,
	x,
	S,
	C,
	w,
	C,
	w
], ne = [
	S,
	S,
	S,
	S,
	w,
	w,
	w,
	w
], re = [
	y,
	b,
	x,
	S,
	C,
	w,
	C,
	w
], ie = [
	b,
	b,
	S,
	S,
	w,
	w,
	w,
	w
], ae = [
	v,
	v,
	b,
	b,
	S,
	S,
	w,
	w
], oe = [
	_,
	v,
	y,
	b,
	y,
	b,
	y,
	b
], T = {
	DISPLAY: ee[_],
	TEXT: ee[y],
	SCRIPT: ee[x],
	SCRIPTSCRIPT: ee[C]
}, se = [
	{
		name: "latin",
		blocks: [[256, 591], [768, 879]]
	},
	{
		name: "cyrillic",
		blocks: [[1024, 1279]]
	},
	{
		name: "armenian",
		blocks: [[1328, 1423]]
	},
	{
		name: "brahmic",
		blocks: [[2304, 4255]]
	},
	{
		name: "georgian",
		blocks: [[4256, 4351]]
	},
	{
		name: "cjk",
		blocks: [
			[12288, 12543],
			[19968, 40879],
			[65280, 65376]
		]
	},
	{
		name: "hangul",
		blocks: [[44032, 55215]]
	}
];
function ce(e) {
	for (var t = 0; t < se.length; t++) for (var n = se[t], r = 0; r < n.blocks.length; r++) {
		var i = n.blocks[r];
		if (e >= i[0] && e <= i[1]) return n.name;
	}
	return null;
}
var le = [];
se.forEach((e) => e.blocks.forEach((e) => le.push(...e)));
function ue(e) {
	for (var t = 0; t < le.length; t += 2) if (e >= le[t] && e <= le[t + 1]) return !0;
	return !1;
}
var E = (e) => e + " " + e, de = 80, fe = function(e, t) {
	return "M95," + (622 + e + t) + "\nc-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14\nc0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54\nc44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10\ns173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429\nc69,-144,104.5,-217.7,106.5,-221\nl" + e / 2.075 + " -" + e + "\nc5.3,-9.3,12,-14,20,-14\nH400000v" + (40 + e) + "H845.2724\ns-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7\nc-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z\nM" + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, pe = function(e, t) {
	return "M263," + (601 + e + t) + "c0.7,0,18,39.7,52,119\nc34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120\nc340,-704.7,510.7,-1060.3,512,-1067\nl" + e / 2.084 + " -" + e + "\nc4.7,-7.3,11,-11,19,-11\nH40000v" + (40 + e) + "H1012.3\ns-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232\nc-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1\ns-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26\nc-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z\nM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, me = function(e, t) {
	return "M983 " + (10 + e + t) + "\nl" + e / 3.13 + " -" + e + "\nc4,-6.7,10,-10,18,-10 H400000v" + (40 + e) + "\nH1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7\ns-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744\nc-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30\nc26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722\nc56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5\nc53.7,-170.3,84.5,-266.8,92.5,-289.5z\nM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, he = function(e, t) {
	return "M424," + (2398 + e + t) + "\nc-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514\nc0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20\ns-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121\ns209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081\nl" + e / 4.223 + " -" + e + "c4,-6.7,10,-10,18,-10 H400000\nv" + (40 + e) + "H1014.6\ns-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185\nc-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2z M" + (1001 + e) + " " + t + "\nh400000v" + (40 + e) + "h-400000z";
}, ge = function(e, t) {
	return "M473," + (2713 + e + t) + "\nc339.3,-1799.3,509.3,-2700,510,-2702 l" + e / 5.298 + " -" + e + "\nc3.3,-7.3,9.3,-11,18,-11 H400000v" + (40 + e) + "H1017.7\ns-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9\nc-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200\nc0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26\ns76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,\n606zM" + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, _e = function(e) {
	var t = e / 2;
	return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z";
}, ve = function(e, t, n) {
	var r = n - 54 - t - e;
	return "M702 " + (e + t) + "H400000" + (40 + e) + "\nH742v" + r + "l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1\nh-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170\nc-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667\n219 661 l218 661zM702 " + t + "H400000v" + (40 + e) + "H742z";
}, ye = function(e, t, n) {
	t = 1e3 * t;
	var r = "";
	switch (e) {
		case "sqrtMain":
			r = fe(t, de);
			break;
		case "sqrtSize1":
			r = pe(t, de);
			break;
		case "sqrtSize2":
			r = me(t, de);
			break;
		case "sqrtSize3":
			r = he(t, de);
			break;
		case "sqrtSize4":
			r = ge(t, de);
			break;
		case "sqrtTall": r = ve(t, de, n);
	}
	return r;
}, be = function(e, t) {
	switch (e) {
		case "⎜": return E("M291 0 H417 V" + t + " H291z");
		case "∣": return E("M145 0 H188 V" + t + " H145z");
		case "∥": return E("M145 0 H188 V" + t + " H145z") + E("M367 0 H410 V" + t + " H367z");
		case "⎟": return E("M457 0 H583 V" + t + " H457z");
		case "⎢": return E("M319 0 H403 V" + t + " H319z");
		case "⎥": return E("M263 0 H347 V" + t + " H263z");
		case "⎪": return E("M384 0 H504 V" + t + " H384z");
		case "⏐": return E("M312 0 H355 V" + t + " H312z");
		case "‖": return E("M257 0 H300 V" + t + " H257z") + E("M478 0 H521 V" + t + " H478z");
		default: return "";
	}
}, xe = {
	doubleleftarrow: "M262 157\nl10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3\n 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28\n 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5\nc2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5\n 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87\n-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7\n-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z\nm8 0v40h399730v-40zm0 194v40h399730v-40z",
	doublerightarrow: "M399738 392l\n-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5\n 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88\n-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68\n-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18\n-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782\nc-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3\n-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z",
	leftarrow: "M400000 241H110l3-3c68.7-52.7 113.7-120\n 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8\n-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247\nc-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208\n 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3\n 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202\n l-3-3h399890zM100 241v40h399900v-40z",
	leftbrace: "M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117\n-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7\n 5-6 9-10 13-.7 1-7.3 1-20 1H6z",
	leftbraceunder: "M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13\n 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688\n 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7\n-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z",
	leftgroup: "M400000 80\nH435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0\n 435 0h399565z",
	leftgroupunder: "M400000 262\nH435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219\n 435 219h399565z",
	leftharpoon: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3\n-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5\n-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7\n-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z",
	leftharpoonplus: "M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5\n 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3\n-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7\n-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z\nm0 0v40h400000v-40z",
	leftharpoondown: "M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333\n 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5\n 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667\n-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z",
	leftharpoondownplus: "M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12\n 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7\n-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0\nv40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z",
	lefthook: "M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5\n-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3\n-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21\n 71.5 23h399859zM103 281v-40h399897v40z",
	leftlinesegment: E("M40 281 V428 H0 V94 H40 V241 H400000 v40z"),
	leftbracketunder: E("M0 0 h120 V290 H399995 v120 H0z"),
	leftbracketover: E("M0 440 h120 V150 H399995 v-120 H0z"),
	leftmapsto: E("M40 281 V448H0V74H40V241H400000v40z"),
	leftToFrom: "M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23\n-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8\nc28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3\n 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z",
	longequal: E("M0 50 h400000 v40H0z m0 194h40000v40H0z"),
	midbrace: "M200428 334\nc-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14\n-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7\n 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11\n 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z",
	midbraceunder: "M199572 214\nc100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14\n 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3\n 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0\n-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z",
	oiintSize1: "M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6\n-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z\nm368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8\n60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z",
	oiintSize2: "M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8\n-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z\nm502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2\nc0 110 84 276 504 276s502.4-166 502.4-276z",
	oiiintSize1: "M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6\n-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z\nm525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0\n85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z",
	oiiintSize2: "M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8\n-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z\nm770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1\nc0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z",
	rightarrow: "M0 241v40h399891c-47.3 35.3-84 78-110 128\n-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20\n 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7\n 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85\n-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n 151.7 139 205zm0 0v40h399900v-40z",
	rightbrace: "M400000 542l\n-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5\ns-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1\nc124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z",
	rightbraceunder: "M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3\n 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237\n-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z",
	rightgroup: "M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0\n 3-1 3-3v-38c-76-158-257-219-435-219H0z",
	rightgroupunder: "M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18\n 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z",
	rightharpoon: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3\n-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2\n-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58\n 69.2 92 94.5zm0 0v40h399900v-40z",
	rightharpoonplus: "M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11\n-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7\n 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z\nm0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z",
	rightharpoondown: "M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8\n 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5\n-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95\n-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z",
	rightharpoondownplus: "M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8\n 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3\n 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3\n-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z\nm0-194v40h400000v-40zm0 0v40h400000v-40z",
	righthook: "M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3\n 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0\n-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21\n 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z",
	rightlinesegment: E("M399960 241 V94 h40 V428 h-40 V281 H0 v-40z"),
	rightbracketunder: E("M399995 0 h-120 V290 H0 v120 H400000z"),
	rightbracketover: E("M399995 440 h-120 V150 H0 v-120 H399995z"),
	rightToFrom: "M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23\n 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32\n-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142\n-167z M100 147v40h399900v-40zM0 341v40h399900v-40z",
	twoheadleftarrow: "M0 167c68 40\n 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69\n-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3\n-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19\n-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101\n 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z",
	twoheadrightarrow: "M400000 167\nc-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3\n 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42\n 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333\n-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70\n 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z",
	tilde1: "M200 55.538c-77 0-168 73.953-177 73.953-3 0-7\n-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0\n 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0\n 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128\n-68.267.847-113-73.952-191-73.952z",
	tilde2: "M344 55.266c-142 0-300.638 81.316-311.5 86.418\n-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9\n 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114\nc1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751\n 181.476 676 181.476c-149 0-189-126.21-332-126.21z",
	tilde3: "M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457\n-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0\n 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697\n 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696\n -338 0-409-156.573-744-156.573z",
	tilde4: "M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345\n-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409\n 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9\n 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409\n -175.236-744-175.236z",
	vec: "M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5\n3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11\n10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63\n-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1\n-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59\nH213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359\nc-16-25.333-24-45-24-59z",
	widehat1: "M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22\nc-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z",
	widehat2: "M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widehat3: "M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widehat4: "M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10\n-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z",
	widecheck1: "M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,\n-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z",
	widecheck2: "M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	widecheck3: "M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	widecheck4: "M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,\n-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z",
	baraboveleftarrow: "M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202\nc4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5\nc-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130\ns-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47\n121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6\ns2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11\nc0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z\nM100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z",
	rightarrowabovebar: "M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32\n-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0\n13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39\n-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5\n-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5\n-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67\n151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z",
	baraboveshortleftharpoon: "M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17\nc2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21\nc-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40\nc-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z\nM0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z",
	rightharpoonaboveshortbar: "M0,241 l0,40c399126,0,399993,0,399993,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z",
	shortbaraboveleftharpoon: "M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11\nc1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,\n1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,\n-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z\nM93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z",
	shortrightharpoonabovebar: "M53,241l0,40c398570,0,399437,0,399437,0\nc4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,\n-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6\nc-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z\nM500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z"
}, Se = function(e, t) {
	switch (e) {
		case "lbrack": return "M403 1759 V84 H666 V0 H319 V1759 v" + t + " v1759 v84 h347 v-84\nH403z M403 1759 V0 H319 V1759 v" + t + " v1759 v84 h84z";
		case "rbrack": return "M347 1759 V0 H0 V84 H263 V1759 v" + t + " v1759 H0 v84 H347z\nM347 1759 V0 H263 V1759 v" + t + " v1759 h84z";
		case "vert": return "M145 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + t + " v585 h43z";
		case "doublevert": return "M145 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M188 15 H145 v585 v" + t + " v585 h43z\nM367 15 v585 v" + t + " v585 c2.667,10,9.667,15,21,15\nc10,0,16.667,-5,20,-15 v-585 v" + -t + " v-585 c-2.667,-10,-9.667,-15,-21,-15\nc-10,0,-16.667,5,-20,15z M410 15 H367 v585 v" + t + " v585 h43z";
		case "lfloor": return "M319 602 V0 H403 V602 v" + t + " v1715 h263 v84 H319z\nMM319 602 V0 H403 V602 v" + t + " v1715 H319z";
		case "rfloor": return "M319 602 V0 H403 V602 v" + t + " v1799 H0 v-84 H319z\nMM319 602 V0 H403 V602 v" + t + " v1715 H319z";
		case "lceil": return "M403 1759 V84 H666 V0 H319 V1759 v" + t + " v602 h84z\nM403 1759 V0 H319 V1759 v" + t + " v602 h84z";
		case "rceil": return "M347 1759 V0 H0 V84 H263 V1759 v" + t + " v602 h84z\nM347 1759 V0 h-84 V1759 v" + t + " v602 h84z";
		case "lparen": return "M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1\nc-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,\n-36,557 l0," + (t + 84) + "c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,\n949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9\nc0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,\n-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189\nl0,-" + (t + 92) + "c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,\n-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z";
		case "rparen": return "M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,\n63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5\nc11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0," + (t + 9) + "\nc-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664\nc-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11\nc0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17\nc242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558\nl0,-" + (t + 144) + "c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,\n-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z";
		default: throw Error("Unknown stretchy delimiter.");
	}
};
function Ce(e) {
	return "toText" in e;
}
var we = class {
	constructor(e) {
		this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {};
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++) e.appendChild(this.children[t].toNode());
		return e;
	}
	toMarkup() {
		for (var e = "", t = 0; t < this.children.length; t++) e += this.children[t].toMarkup();
		return e;
	}
	toText() {
		return this.children.map((e) => {
			if (Ce(e)) return e.toText();
			throw Error("Expected MathDomNode with toText, got " + e.constructor.name);
		}).join("");
	}
}, Te = {
	pt: 1,
	mm: 7227 / 2540,
	cm: 7227 / 254,
	in: 72.27,
	bp: 803 / 800,
	pc: 12,
	dd: 1238 / 1157,
	cc: 14856 / 1157,
	nd: 685 / 642,
	nc: 1370 / 107,
	sp: 1 / 65536,
	px: 803 / 800
}, Ee = {
	ex: !0,
	em: !0,
	mu: !0
}, De = function(e) {
	return typeof e != "string" && (e = e.unit), e in Te || e in Ee || e === "ex";
}, D = function(e, n) {
	var r;
	if (e.unit in Te) r = Te[e.unit] / n.fontMetrics().ptPerEm / n.sizeMultiplier;
	else if (e.unit === "mu") r = n.fontMetrics().cssEmPerMu;
	else {
		var i = n.style.isTight() ? n.havingStyle(n.style.text()) : n;
		if (e.unit === "ex") r = i.fontMetrics().xHeight;
		else if (e.unit === "em") r = i.fontMetrics().quad;
		else throw new t("Invalid unit: '" + e.unit + "'");
		i !== n && (r *= i.sizeMultiplier / n.sizeMultiplier);
	}
	return Math.min(e.number * r, n.maxSize);
}, O = function(e) {
	return +e.toFixed(4) + "em";
}, Oe = function(e) {
	return e.filter((e) => e).join(" ");
}, ke = function(e) {
	var t = "";
	for (var n of Object.keys(e)) {
		var i = e[n];
		i !== void 0 && (t += r(n) + ":" + i + ";");
	}
	return t;
}, Ae = function(e, t, n) {
	if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = n || {}, t) {
		t.style.isTight() && this.classes.push("mtight");
		var r = t.getColor();
		r && (this.style.color = r);
	}
}, je = function(e) {
	var t = document.createElement(e);
	t.className = Oe(this.classes), Object.assign(t.style, this.style);
	for (var n of Object.keys(this.attributes)) t.setAttribute(n, this.attributes[n]);
	for (var r = 0; r < this.children.length; r++) t.appendChild(this.children[r].toNode());
	return t;
}, Me = /[\s"'>/=\x00-\x1f]/, Ne = function(e) {
	var n = "<" + e;
	this.classes.length && (n += " class=\"" + o(Oe(this.classes)) + "\"");
	var r = ke(this.style);
	r && (n += " style=\"" + o(r) + "\"");
	for (var i of Object.keys(this.attributes)) {
		if (Me.test(i)) throw new t("Invalid attribute name '" + i + "'");
		n += " " + i + "=\"" + o(this.attributes[i]) + "\"";
	}
	n += ">";
	for (var a = 0; a < this.children.length; a++) n += this.children[a].toMarkup();
	return n += "</" + e + ">", n;
}, Pe = class {
	constructor(e, t, n, r) {
		this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, this.italic = void 0, Ae.call(this, e, n, r), this.children = t || [];
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		return je.call(this, "span");
	}
	toMarkup() {
		return Ne.call(this, "span");
	}
}, Fe = class {
	constructor(e, t, n, r) {
		this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, Ae.call(this, t, r), this.children = n || [], this.setAttribute("href", e);
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		return je.call(this, "a");
	}
	toMarkup() {
		return Ne.call(this, "a");
	}
}, Ie = class {
	constructor(e, t, n) {
		this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = n;
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		var e = document.createElement("img");
		return e.src = this.src, e.alt = this.alt, e.className = "mord", Object.assign(e.style, this.style), e;
	}
	toMarkup() {
		var e = "<img src=\"" + o(this.src) + "\"" + (" alt=\"" + o(this.alt) + "\""), t = ke(this.style);
		return t && (e += " style=\"" + o(t) + "\""), e += "'/>", e;
	}
}, Le = {
	î: "ı̂",
	ï: "ı̈",
	í: "ı́",
	ì: "ı̀"
}, Re = class {
	constructor(e, t, n, r, i, a, o, s) {
		this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = n || 0, this.italic = r || 0, this.skew = i || 0, this.width = a || 0, this.classes = o || [], this.style = s || {}, this.maxFontSize = 0;
		var c = ce(this.text.charCodeAt(0));
		c && this.classes.push(c + "_fallback"), /[îïíì]/.test(this.text) && (this.text = Le[this.text]);
	}
	hasClass(e) {
		return this.classes.includes(e);
	}
	toNode() {
		var e = document.createTextNode(this.text), t = null;
		return this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = O(this.italic)), this.classes.length > 0 && (t ||= document.createElement("span"), t.className = Oe(this.classes)), Object.keys(this.style).length > 0 && (t ||= document.createElement("span"), Object.assign(t.style, this.style)), t ? (t.appendChild(e), t) : e;
	}
	toMarkup() {
		var e = !1, t = "<span";
		this.classes.length && (e = !0, t += " class=\"", t += o(Oe(this.classes)), t += "\"");
		var n = "";
		this.italic > 0 && (n += "margin-right:" + O(this.italic) + ";"), n += ke(this.style), n && (e = !0, t += " style=\"" + o(n) + "\"");
		var r = o(this.text);
		return e ? (t += ">", t += r, t += "</span>", t) : r;
	}
}, ze = class {
	constructor(e, t) {
		this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {};
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "svg");
		for (var t of Object.keys(this.attributes)) e.setAttribute(t, this.attributes[t]);
		for (var n = 0; n < this.children.length; n++) e.appendChild(this.children[n].toNode());
		return e;
	}
	toMarkup() {
		var e = "<svg xmlns=\"http://www.w3.org/2000/svg\"";
		for (var t of Object.keys(this.attributes)) e += " " + t + "=\"" + o(this.attributes[t]) + "\"";
		e += ">";
		for (var n = 0; n < this.children.length; n++) e += this.children[n].toMarkup();
		return e += "</svg>", e;
	}
}, Be = class {
	constructor(e, t) {
		this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t;
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "path");
		return this.alternate ? e.setAttribute("d", this.alternate) : e.setAttribute("d", xe[this.pathName]), e;
	}
	toMarkup() {
		return this.alternate ? "<path d=\"" + o(this.alternate) + "\"/>" : "<path d=\"" + o(xe[this.pathName]) + "\"/>";
	}
}, Ve = class {
	constructor(e) {
		this.attributes = void 0, this.attributes = e || {};
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/2000/svg", "line");
		for (var t of Object.keys(this.attributes)) e.setAttribute(t, this.attributes[t]);
		return e;
	}
	toMarkup() {
		var e = "<line";
		for (var t of Object.keys(this.attributes)) e += " " + t + "=\"" + o(this.attributes[t]) + "\"";
		return e += "/>", e;
	}
};
function He(e) {
	if (e instanceof Re) return e;
	throw Error("Expected symbolNode but got " + String(e) + ".");
}
function Ue(e) {
	if (e instanceof Pe) return e;
	throw Error("Expected span<HtmlDomNode> but got " + String(e) + ".");
}
var We = (e) => e instanceof Pe || e instanceof Fe || e instanceof we, Ge = {
	"AMS-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		66: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		67: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		68: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		69: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		70: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		71: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		72: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		73: [
			0,
			.68889,
			0,
			0,
			.38889
		],
		74: [
			.16667,
			.68889,
			0,
			0,
			.5
		],
		75: [
			0,
			.68889,
			0,
			0,
			.77778
		],
		76: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		77: [
			0,
			.68889,
			0,
			0,
			.94445
		],
		78: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		79: [
			.16667,
			.68889,
			0,
			0,
			.77778
		],
		80: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		81: [
			.16667,
			.68889,
			0,
			0,
			.77778
		],
		82: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		83: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		84: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		85: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		86: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		87: [
			0,
			.68889,
			0,
			0,
			1
		],
		88: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		89: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		90: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		107: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		165: [
			0,
			.675,
			.025,
			0,
			.75
		],
		174: [
			.15559,
			.69224,
			0,
			0,
			.94666
		],
		240: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		295: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		710: [
			0,
			.825,
			0,
			0,
			2.33334
		],
		732: [
			0,
			.9,
			0,
			0,
			2.33334
		],
		770: [
			0,
			.825,
			0,
			0,
			2.33334
		],
		771: [
			0,
			.9,
			0,
			0,
			2.33334
		],
		989: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		1008: [
			0,
			.43056,
			.04028,
			0,
			.66667
		],
		8245: [
			0,
			.54986,
			0,
			0,
			.275
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		8487: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8498: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		8502: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		8503: [
			0,
			.68889,
			0,
			0,
			.44445
		],
		8504: [
			0,
			.68889,
			0,
			0,
			.66667
		],
		8513: [
			0,
			.68889,
			0,
			0,
			.63889
		],
		8592: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8594: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8602: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8603: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8606: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8608: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8610: [
			.01354,
			.52239,
			0,
			0,
			1.11111
		],
		8611: [
			.01354,
			.52239,
			0,
			0,
			1.11111
		],
		8619: [
			0,
			.54986,
			0,
			0,
			1
		],
		8620: [
			0,
			.54986,
			0,
			0,
			1
		],
		8621: [
			-.13313,
			.37788,
			0,
			0,
			1.38889
		],
		8622: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8624: [
			0,
			.69224,
			0,
			0,
			.5
		],
		8625: [
			0,
			.69224,
			0,
			0,
			.5
		],
		8630: [
			0,
			.43056,
			0,
			0,
			1
		],
		8631: [
			0,
			.43056,
			0,
			0,
			1
		],
		8634: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8635: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8638: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8639: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8642: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8643: [
			.19444,
			.69224,
			0,
			0,
			.41667
		],
		8644: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8646: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8647: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8648: [
			.19444,
			.69224,
			0,
			0,
			.83334
		],
		8649: [
			.1808,
			.675,
			0,
			0,
			1
		],
		8650: [
			.19444,
			.69224,
			0,
			0,
			.83334
		],
		8651: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8652: [
			.01354,
			.52239,
			0,
			0,
			1
		],
		8653: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8654: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8655: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8666: [
			.13667,
			.63667,
			0,
			0,
			1
		],
		8667: [
			.13667,
			.63667,
			0,
			0,
			1
		],
		8669: [
			-.13313,
			.37788,
			0,
			0,
			1
		],
		8672: [
			-.064,
			.437,
			0,
			0,
			1.334
		],
		8674: [
			-.064,
			.437,
			0,
			0,
			1.334
		],
		8705: [
			0,
			.825,
			0,
			0,
			.5
		],
		8708: [
			0,
			.68889,
			0,
			0,
			.55556
		],
		8709: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8717: [
			0,
			.43056,
			0,
			0,
			.42917
		],
		8722: [
			-.03598,
			.46402,
			0,
			0,
			.5
		],
		8724: [
			.08198,
			.69224,
			0,
			0,
			.77778
		],
		8726: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8733: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8737: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8738: [
			.03517,
			.52239,
			0,
			0,
			.72222
		],
		8739: [
			.08167,
			.58167,
			0,
			0,
			.22222
		],
		8740: [
			.25142,
			.74111,
			0,
			0,
			.27778
		],
		8741: [
			.08167,
			.58167,
			0,
			0,
			.38889
		],
		8742: [
			.25142,
			.74111,
			0,
			0,
			.5
		],
		8756: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8757: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8764: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8765: [
			-.13313,
			.37788,
			0,
			0,
			.77778
		],
		8769: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8770: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8774: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8776: [
			-.01688,
			.48312,
			0,
			0,
			.77778
		],
		8778: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8782: [
			.06062,
			.54986,
			0,
			0,
			.77778
		],
		8783: [
			.06062,
			.54986,
			0,
			0,
			.77778
		],
		8785: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8786: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8787: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8790: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8791: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8796: [
			.08198,
			.91667,
			0,
			0,
			.77778
		],
		8806: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		8807: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		8808: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		8809: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		8812: [
			.25583,
			.75583,
			0,
			0,
			.5
		],
		8814: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8815: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8816: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8817: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8818: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8819: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8822: [
			.1808,
			.675,
			0,
			0,
			.77778
		],
		8823: [
			.1808,
			.675,
			0,
			0,
			.77778
		],
		8828: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8829: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8830: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8831: [
			.22958,
			.72958,
			0,
			0,
			.77778
		],
		8832: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8833: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8840: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8841: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8842: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8843: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8847: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8848: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8858: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8859: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8861: [
			.08198,
			.58198,
			0,
			0,
			.77778
		],
		8862: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8863: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8864: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8865: [
			0,
			.675,
			0,
			0,
			.77778
		],
		8872: [
			0,
			.69224,
			0,
			0,
			.61111
		],
		8873: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8874: [
			0,
			.69224,
			0,
			0,
			.88889
		],
		8876: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		8877: [
			0,
			.68889,
			0,
			0,
			.61111
		],
		8878: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8879: [
			0,
			.68889,
			0,
			0,
			.72222
		],
		8882: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8883: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8884: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8885: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8888: [
			0,
			.54986,
			0,
			0,
			1.11111
		],
		8890: [
			.19444,
			.43056,
			0,
			0,
			.55556
		],
		8891: [
			.19444,
			.69224,
			0,
			0,
			.61111
		],
		8892: [
			.19444,
			.69224,
			0,
			0,
			.61111
		],
		8901: [
			0,
			.54986,
			0,
			0,
			.27778
		],
		8903: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8905: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8906: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		8907: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8908: [
			0,
			.69224,
			0,
			0,
			.77778
		],
		8909: [
			-.03598,
			.46402,
			0,
			0,
			.77778
		],
		8910: [
			0,
			.54986,
			0,
			0,
			.76042
		],
		8911: [
			0,
			.54986,
			0,
			0,
			.76042
		],
		8912: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8913: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		8914: [
			0,
			.54986,
			0,
			0,
			.66667
		],
		8915: [
			0,
			.54986,
			0,
			0,
			.66667
		],
		8916: [
			0,
			.69224,
			0,
			0,
			.66667
		],
		8918: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8919: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8920: [
			.03517,
			.54986,
			0,
			0,
			1.33334
		],
		8921: [
			.03517,
			.54986,
			0,
			0,
			1.33334
		],
		8922: [
			.38569,
			.88569,
			0,
			0,
			.77778
		],
		8923: [
			.38569,
			.88569,
			0,
			0,
			.77778
		],
		8926: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8927: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		8928: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8929: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8934: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8935: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8936: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8937: [
			.23222,
			.74111,
			0,
			0,
			.77778
		],
		8938: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8939: [
			.20576,
			.70576,
			0,
			0,
			.77778
		],
		8940: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8941: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		8994: [
			.19444,
			.69224,
			0,
			0,
			.77778
		],
		8995: [
			.19444,
			.69224,
			0,
			0,
			.77778
		],
		9416: [
			.15559,
			.69224,
			0,
			0,
			.90222
		],
		9484: [
			0,
			.69224,
			0,
			0,
			.5
		],
		9488: [
			0,
			.69224,
			0,
			0,
			.5
		],
		9492: [
			0,
			.37788,
			0,
			0,
			.5
		],
		9496: [
			0,
			.37788,
			0,
			0,
			.5
		],
		9585: [
			.19444,
			.68889,
			0,
			0,
			.88889
		],
		9586: [
			.19444,
			.74111,
			0,
			0,
			.88889
		],
		9632: [
			0,
			.675,
			0,
			0,
			.77778
		],
		9633: [
			0,
			.675,
			0,
			0,
			.77778
		],
		9650: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9651: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9654: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		9660: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9661: [
			0,
			.54986,
			0,
			0,
			.72222
		],
		9664: [
			.03517,
			.54986,
			0,
			0,
			.77778
		],
		9674: [
			.11111,
			.69224,
			0,
			0,
			.66667
		],
		9733: [
			.19444,
			.69224,
			0,
			0,
			.94445
		],
		10003: [
			0,
			.69224,
			0,
			0,
			.83334
		],
		10016: [
			0,
			.69224,
			0,
			0,
			.83334
		],
		10731: [
			.11111,
			.69224,
			0,
			0,
			.66667
		],
		10846: [
			.19444,
			.75583,
			0,
			0,
			.61111
		],
		10877: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10878: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10885: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10886: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10887: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10888: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10889: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10890: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10891: [
			.48256,
			.98256,
			0,
			0,
			.77778
		],
		10892: [
			.48256,
			.98256,
			0,
			0,
			.77778
		],
		10901: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10902: [
			.13667,
			.63667,
			0,
			0,
			.77778
		],
		10933: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		10934: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		10935: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10936: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10937: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10938: [
			.26167,
			.75726,
			0,
			0,
			.77778
		],
		10949: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10950: [
			.25583,
			.75583,
			0,
			0,
			.77778
		],
		10955: [
			.28481,
			.79383,
			0,
			0,
			.77778
		],
		10956: [
			.28481,
			.79383,
			0,
			0,
			.77778
		],
		57350: [
			.08167,
			.58167,
			0,
			0,
			.22222
		],
		57351: [
			.08167,
			.58167,
			0,
			0,
			.38889
		],
		57352: [
			.08167,
			.58167,
			0,
			0,
			.77778
		],
		57353: [
			0,
			.43056,
			.04028,
			0,
			.66667
		],
		57356: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57357: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57358: [
			.41951,
			.91951,
			0,
			0,
			.77778
		],
		57359: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		57360: [
			.30274,
			.79383,
			0,
			0,
			.77778
		],
		57361: [
			.41951,
			.91951,
			0,
			0,
			.77778
		],
		57366: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57367: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57368: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57369: [
			.25142,
			.75726,
			0,
			0,
			.77778
		],
		57370: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		57371: [
			.13597,
			.63597,
			0,
			0,
			.77778
		]
	},
	"Caligraphic-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.68333,
			0,
			.19445,
			.79847
		],
		66: [
			0,
			.68333,
			.03041,
			.13889,
			.65681
		],
		67: [
			0,
			.68333,
			.05834,
			.13889,
			.52653
		],
		68: [
			0,
			.68333,
			.02778,
			.08334,
			.77139
		],
		69: [
			0,
			.68333,
			.08944,
			.11111,
			.52778
		],
		70: [
			0,
			.68333,
			.09931,
			.11111,
			.71875
		],
		71: [
			.09722,
			.68333,
			.0593,
			.11111,
			.59487
		],
		72: [
			0,
			.68333,
			.00965,
			.11111,
			.84452
		],
		73: [
			0,
			.68333,
			.07382,
			0,
			.54452
		],
		74: [
			.09722,
			.68333,
			.18472,
			.16667,
			.67778
		],
		75: [
			0,
			.68333,
			.01445,
			.05556,
			.76195
		],
		76: [
			0,
			.68333,
			0,
			.13889,
			.68972
		],
		77: [
			0,
			.68333,
			0,
			.13889,
			1.2009
		],
		78: [
			0,
			.68333,
			.14736,
			.08334,
			.82049
		],
		79: [
			0,
			.68333,
			.02778,
			.11111,
			.79611
		],
		80: [
			0,
			.68333,
			.08222,
			.08334,
			.69556
		],
		81: [
			.09722,
			.68333,
			0,
			.11111,
			.81667
		],
		82: [
			0,
			.68333,
			0,
			.08334,
			.8475
		],
		83: [
			0,
			.68333,
			.075,
			.13889,
			.60556
		],
		84: [
			0,
			.68333,
			.25417,
			0,
			.54464
		],
		85: [
			0,
			.68333,
			.09931,
			.08334,
			.62583
		],
		86: [
			0,
			.68333,
			.08222,
			0,
			.61278
		],
		87: [
			0,
			.68333,
			.08222,
			.08334,
			.98778
		],
		88: [
			0,
			.68333,
			.14643,
			.13889,
			.7133
		],
		89: [
			.09722,
			.68333,
			.08222,
			.08334,
			.66834
		],
		90: [
			0,
			.68333,
			.07944,
			.13889,
			.72473
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		]
	},
	"Fraktur-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69141,
			0,
			0,
			.29574
		],
		34: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		38: [
			0,
			.69141,
			0,
			0,
			.73786
		],
		39: [
			0,
			.69141,
			0,
			0,
			.21201
		],
		40: [
			.24982,
			.74947,
			0,
			0,
			.38865
		],
		41: [
			.24982,
			.74947,
			0,
			0,
			.38865
		],
		42: [
			0,
			.62119,
			0,
			0,
			.27764
		],
		43: [
			.08319,
			.58283,
			0,
			0,
			.75623
		],
		44: [
			0,
			.10803,
			0,
			0,
			.27764
		],
		45: [
			.08319,
			.58283,
			0,
			0,
			.75623
		],
		46: [
			0,
			.10803,
			0,
			0,
			.27764
		],
		47: [
			.24982,
			.74947,
			0,
			0,
			.50181
		],
		48: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		49: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		50: [
			0,
			.47534,
			0,
			0,
			.50181
		],
		51: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		52: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		53: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		54: [
			0,
			.69141,
			0,
			0,
			.50181
		],
		55: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		56: [
			0,
			.69141,
			0,
			0,
			.50181
		],
		57: [
			.18906,
			.47534,
			0,
			0,
			.50181
		],
		58: [
			0,
			.47534,
			0,
			0,
			.21606
		],
		59: [
			.12604,
			.47534,
			0,
			0,
			.21606
		],
		61: [
			-.13099,
			.36866,
			0,
			0,
			.75623
		],
		63: [
			0,
			.69141,
			0,
			0,
			.36245
		],
		65: [
			0,
			.69141,
			0,
			0,
			.7176
		],
		66: [
			0,
			.69141,
			0,
			0,
			.88397
		],
		67: [
			0,
			.69141,
			0,
			0,
			.61254
		],
		68: [
			0,
			.69141,
			0,
			0,
			.83158
		],
		69: [
			0,
			.69141,
			0,
			0,
			.66278
		],
		70: [
			.12604,
			.69141,
			0,
			0,
			.61119
		],
		71: [
			0,
			.69141,
			0,
			0,
			.78539
		],
		72: [
			.06302,
			.69141,
			0,
			0,
			.7203
		],
		73: [
			0,
			.69141,
			0,
			0,
			.55448
		],
		74: [
			.12604,
			.69141,
			0,
			0,
			.55231
		],
		75: [
			0,
			.69141,
			0,
			0,
			.66845
		],
		76: [
			0,
			.69141,
			0,
			0,
			.66602
		],
		77: [
			0,
			.69141,
			0,
			0,
			1.04953
		],
		78: [
			0,
			.69141,
			0,
			0,
			.83212
		],
		79: [
			0,
			.69141,
			0,
			0,
			.82699
		],
		80: [
			.18906,
			.69141,
			0,
			0,
			.82753
		],
		81: [
			.03781,
			.69141,
			0,
			0,
			.82699
		],
		82: [
			0,
			.69141,
			0,
			0,
			.82807
		],
		83: [
			0,
			.69141,
			0,
			0,
			.82861
		],
		84: [
			0,
			.69141,
			0,
			0,
			.66899
		],
		85: [
			0,
			.69141,
			0,
			0,
			.64576
		],
		86: [
			0,
			.69141,
			0,
			0,
			.83131
		],
		87: [
			0,
			.69141,
			0,
			0,
			1.04602
		],
		88: [
			0,
			.69141,
			0,
			0,
			.71922
		],
		89: [
			.18906,
			.69141,
			0,
			0,
			.83293
		],
		90: [
			.12604,
			.69141,
			0,
			0,
			.60201
		],
		91: [
			.24982,
			.74947,
			0,
			0,
			.27764
		],
		93: [
			.24982,
			.74947,
			0,
			0,
			.27764
		],
		94: [
			0,
			.69141,
			0,
			0,
			.49965
		],
		97: [
			0,
			.47534,
			0,
			0,
			.50046
		],
		98: [
			0,
			.69141,
			0,
			0,
			.51315
		],
		99: [
			0,
			.47534,
			0,
			0,
			.38946
		],
		100: [
			0,
			.62119,
			0,
			0,
			.49857
		],
		101: [
			0,
			.47534,
			0,
			0,
			.40053
		],
		102: [
			.18906,
			.69141,
			0,
			0,
			.32626
		],
		103: [
			.18906,
			.47534,
			0,
			0,
			.5037
		],
		104: [
			.18906,
			.69141,
			0,
			0,
			.52126
		],
		105: [
			0,
			.69141,
			0,
			0,
			.27899
		],
		106: [
			0,
			.69141,
			0,
			0,
			.28088
		],
		107: [
			0,
			.69141,
			0,
			0,
			.38946
		],
		108: [
			0,
			.69141,
			0,
			0,
			.27953
		],
		109: [
			0,
			.47534,
			0,
			0,
			.76676
		],
		110: [
			0,
			.47534,
			0,
			0,
			.52666
		],
		111: [
			0,
			.47534,
			0,
			0,
			.48885
		],
		112: [
			.18906,
			.52396,
			0,
			0,
			.50046
		],
		113: [
			.18906,
			.47534,
			0,
			0,
			.48912
		],
		114: [
			0,
			.47534,
			0,
			0,
			.38919
		],
		115: [
			0,
			.47534,
			0,
			0,
			.44266
		],
		116: [
			0,
			.62119,
			0,
			0,
			.33301
		],
		117: [
			0,
			.47534,
			0,
			0,
			.5172
		],
		118: [
			0,
			.52396,
			0,
			0,
			.5118
		],
		119: [
			0,
			.52396,
			0,
			0,
			.77351
		],
		120: [
			.18906,
			.47534,
			0,
			0,
			.38865
		],
		121: [
			.18906,
			.47534,
			0,
			0,
			.49884
		],
		122: [
			.18906,
			.47534,
			0,
			0,
			.39054
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		8216: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		8217: [
			0,
			.69141,
			0,
			0,
			.21471
		],
		58112: [
			0,
			.62119,
			0,
			0,
			.49749
		],
		58113: [
			0,
			.62119,
			0,
			0,
			.4983
		],
		58114: [
			.18906,
			.69141,
			0,
			0,
			.33328
		],
		58115: [
			.18906,
			.69141,
			0,
			0,
			.32923
		],
		58116: [
			.18906,
			.47534,
			0,
			0,
			.50343
		],
		58117: [
			0,
			.69141,
			0,
			0,
			.33301
		],
		58118: [
			0,
			.62119,
			0,
			0,
			.33409
		],
		58119: [
			0,
			.47534,
			0,
			0,
			.50073
		]
	},
	"Main-Bold": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.35
		],
		34: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.95833
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.575
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.95833
		],
		38: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		39: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		40: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		41: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		42: [
			0,
			.75,
			0,
			0,
			.575
		],
		43: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		44: [
			.19444,
			.15556,
			0,
			0,
			.31944
		],
		45: [
			0,
			.44444,
			0,
			0,
			.38333
		],
		46: [
			0,
			.15556,
			0,
			0,
			.31944
		],
		47: [
			.25,
			.75,
			0,
			0,
			.575
		],
		48: [
			0,
			.64444,
			0,
			0,
			.575
		],
		49: [
			0,
			.64444,
			0,
			0,
			.575
		],
		50: [
			0,
			.64444,
			0,
			0,
			.575
		],
		51: [
			0,
			.64444,
			0,
			0,
			.575
		],
		52: [
			0,
			.64444,
			0,
			0,
			.575
		],
		53: [
			0,
			.64444,
			0,
			0,
			.575
		],
		54: [
			0,
			.64444,
			0,
			0,
			.575
		],
		55: [
			0,
			.64444,
			0,
			0,
			.575
		],
		56: [
			0,
			.64444,
			0,
			0,
			.575
		],
		57: [
			0,
			.64444,
			0,
			0,
			.575
		],
		58: [
			0,
			.44444,
			0,
			0,
			.31944
		],
		59: [
			.19444,
			.44444,
			0,
			0,
			.31944
		],
		60: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		61: [
			-.10889,
			.39111,
			0,
			0,
			.89444
		],
		62: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		63: [
			0,
			.69444,
			0,
			0,
			.54305
		],
		64: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		66: [
			0,
			.68611,
			0,
			0,
			.81805
		],
		67: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		68: [
			0,
			.68611,
			0,
			0,
			.88194
		],
		69: [
			0,
			.68611,
			0,
			0,
			.75555
		],
		70: [
			0,
			.68611,
			0,
			0,
			.72361
		],
		71: [
			0,
			.68611,
			0,
			0,
			.90416
		],
		72: [
			0,
			.68611,
			0,
			0,
			.9
		],
		73: [
			0,
			.68611,
			0,
			0,
			.43611
		],
		74: [
			0,
			.68611,
			0,
			0,
			.59444
		],
		75: [
			0,
			.68611,
			0,
			0,
			.90138
		],
		76: [
			0,
			.68611,
			0,
			0,
			.69166
		],
		77: [
			0,
			.68611,
			0,
			0,
			1.09166
		],
		78: [
			0,
			.68611,
			0,
			0,
			.9
		],
		79: [
			0,
			.68611,
			0,
			0,
			.86388
		],
		80: [
			0,
			.68611,
			0,
			0,
			.78611
		],
		81: [
			.19444,
			.68611,
			0,
			0,
			.86388
		],
		82: [
			0,
			.68611,
			0,
			0,
			.8625
		],
		83: [
			0,
			.68611,
			0,
			0,
			.63889
		],
		84: [
			0,
			.68611,
			0,
			0,
			.8
		],
		85: [
			0,
			.68611,
			0,
			0,
			.88472
		],
		86: [
			0,
			.68611,
			.01597,
			0,
			.86944
		],
		87: [
			0,
			.68611,
			.01597,
			0,
			1.18888
		],
		88: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		89: [
			0,
			.68611,
			.02875,
			0,
			.86944
		],
		90: [
			0,
			.68611,
			0,
			0,
			.70277
		],
		91: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		92: [
			.25,
			.75,
			0,
			0,
			.575
		],
		93: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		94: [
			0,
			.69444,
			0,
			0,
			.575
		],
		95: [
			.31,
			.13444,
			.03194,
			0,
			.575
		],
		97: [
			0,
			.44444,
			0,
			0,
			.55902
		],
		98: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		99: [
			0,
			.44444,
			0,
			0,
			.51111
		],
		100: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		101: [
			0,
			.44444,
			0,
			0,
			.52708
		],
		102: [
			0,
			.69444,
			.10903,
			0,
			.35139
		],
		103: [
			.19444,
			.44444,
			.01597,
			0,
			.575
		],
		104: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		105: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		106: [
			.19444,
			.69444,
			0,
			0,
			.35139
		],
		107: [
			0,
			.69444,
			0,
			0,
			.60694
		],
		108: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		109: [
			0,
			.44444,
			0,
			0,
			.95833
		],
		110: [
			0,
			.44444,
			0,
			0,
			.63889
		],
		111: [
			0,
			.44444,
			0,
			0,
			.575
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.63889
		],
		113: [
			.19444,
			.44444,
			0,
			0,
			.60694
		],
		114: [
			0,
			.44444,
			0,
			0,
			.47361
		],
		115: [
			0,
			.44444,
			0,
			0,
			.45361
		],
		116: [
			0,
			.63492,
			0,
			0,
			.44722
		],
		117: [
			0,
			.44444,
			0,
			0,
			.63889
		],
		118: [
			0,
			.44444,
			.01597,
			0,
			.60694
		],
		119: [
			0,
			.44444,
			.01597,
			0,
			.83055
		],
		120: [
			0,
			.44444,
			0,
			0,
			.60694
		],
		121: [
			.19444,
			.44444,
			.01597,
			0,
			.60694
		],
		122: [
			0,
			.44444,
			0,
			0,
			.51111
		],
		123: [
			.25,
			.75,
			0,
			0,
			.575
		],
		124: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		125: [
			.25,
			.75,
			0,
			0,
			.575
		],
		126: [
			.35,
			.34444,
			0,
			0,
			.575
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		163: [
			0,
			.69444,
			0,
			0,
			.86853
		],
		168: [
			0,
			.69444,
			0,
			0,
			.575
		],
		172: [
			0,
			.44444,
			0,
			0,
			.76666
		],
		176: [
			0,
			.69444,
			0,
			0,
			.86944
		],
		177: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		184: [
			.17014,
			0,
			0,
			0,
			.51111
		],
		198: [
			0,
			.68611,
			0,
			0,
			1.04166
		],
		215: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		216: [
			.04861,
			.73472,
			0,
			0,
			.89444
		],
		223: [
			0,
			.69444,
			0,
			0,
			.59722
		],
		230: [
			0,
			.44444,
			0,
			0,
			.83055
		],
		247: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		248: [
			.09722,
			.54167,
			0,
			0,
			.575
		],
		305: [
			0,
			.44444,
			0,
			0,
			.31944
		],
		338: [
			0,
			.68611,
			0,
			0,
			1.16944
		],
		339: [
			0,
			.44444,
			0,
			0,
			.89444
		],
		567: [
			.19444,
			.44444,
			0,
			0,
			.35139
		],
		710: [
			0,
			.69444,
			0,
			0,
			.575
		],
		711: [
			0,
			.63194,
			0,
			0,
			.575
		],
		713: [
			0,
			.59611,
			0,
			0,
			.575
		],
		714: [
			0,
			.69444,
			0,
			0,
			.575
		],
		715: [
			0,
			.69444,
			0,
			0,
			.575
		],
		728: [
			0,
			.69444,
			0,
			0,
			.575
		],
		729: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		730: [
			0,
			.69444,
			0,
			0,
			.86944
		],
		732: [
			0,
			.69444,
			0,
			0,
			.575
		],
		733: [
			0,
			.69444,
			0,
			0,
			.575
		],
		915: [
			0,
			.68611,
			0,
			0,
			.69166
		],
		916: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		920: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80555
		],
		926: [
			0,
			.68611,
			0,
			0,
			.76666
		],
		928: [
			0,
			.68611,
			0,
			0,
			.9
		],
		931: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		933: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		934: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		936: [
			0,
			.68611,
			0,
			0,
			.89444
		],
		937: [
			0,
			.68611,
			0,
			0,
			.83055
		],
		8211: [
			0,
			.44444,
			.03194,
			0,
			.575
		],
		8212: [
			0,
			.44444,
			.03194,
			0,
			1.14999
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.31944
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.60278
		],
		8224: [
			.19444,
			.69444,
			0,
			0,
			.51111
		],
		8225: [
			.19444,
			.69444,
			0,
			0,
			.51111
		],
		8242: [
			0,
			.55556,
			0,
			0,
			.34444
		],
		8407: [
			0,
			.72444,
			.15486,
			0,
			.575
		],
		8463: [
			0,
			.69444,
			0,
			0,
			.66759
		],
		8465: [
			0,
			.69444,
			0,
			0,
			.83055
		],
		8467: [
			0,
			.69444,
			0,
			0,
			.47361
		],
		8472: [
			.19444,
			.44444,
			0,
			0,
			.74027
		],
		8476: [
			0,
			.69444,
			0,
			0,
			.83055
		],
		8501: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8592: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8593: [
			.19444,
			.69444,
			0,
			0,
			.575
		],
		8594: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8595: [
			.19444,
			.69444,
			0,
			0,
			.575
		],
		8596: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8597: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8598: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8599: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8600: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8601: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		8636: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8637: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8640: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8641: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8656: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8657: [
			.19444,
			.69444,
			0,
			0,
			.70277
		],
		8658: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8659: [
			.19444,
			.69444,
			0,
			0,
			.70277
		],
		8660: [
			-.10889,
			.39111,
			0,
			0,
			1.14999
		],
		8661: [
			.25,
			.75,
			0,
			0,
			.70277
		],
		8704: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		8706: [
			0,
			.69444,
			.06389,
			0,
			.62847
		],
		8707: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		8709: [
			.05556,
			.75,
			0,
			0,
			.575
		],
		8711: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		8712: [
			.08556,
			.58556,
			0,
			0,
			.76666
		],
		8715: [
			.08556,
			.58556,
			0,
			0,
			.76666
		],
		8722: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8723: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8725: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8726: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8727: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		8728: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8729: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8730: [
			.18,
			.82,
			0,
			0,
			.95833
		],
		8733: [
			0,
			.44444,
			0,
			0,
			.89444
		],
		8734: [
			0,
			.44444,
			0,
			0,
			1.14999
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8739: [
			.25,
			.75,
			0,
			0,
			.31944
		],
		8741: [
			.25,
			.75,
			0,
			0,
			.575
		],
		8743: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8744: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8745: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8746: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8747: [
			.19444,
			.69444,
			.12778,
			0,
			.56875
		],
		8764: [
			-.10889,
			.39111,
			0,
			0,
			.89444
		],
		8768: [
			.19444,
			.69444,
			0,
			0,
			.31944
		],
		8771: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8773: [
			.027,
			.638,
			0,
			0,
			.894
		],
		8776: [
			.02444,
			.52444,
			0,
			0,
			.89444
		],
		8781: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8801: [
			.00222,
			.50222,
			0,
			0,
			.89444
		],
		8804: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8805: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8810: [
			.08556,
			.58556,
			0,
			0,
			1.14999
		],
		8811: [
			.08556,
			.58556,
			0,
			0,
			1.14999
		],
		8826: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8827: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8834: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8835: [
			.08556,
			.58556,
			0,
			0,
			.89444
		],
		8838: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8839: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8846: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8849: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8850: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		8851: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8852: [
			0,
			.55556,
			0,
			0,
			.76666
		],
		8853: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8854: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8855: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8856: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8857: [
			.13333,
			.63333,
			0,
			0,
			.89444
		],
		8866: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8867: [
			0,
			.69444,
			0,
			0,
			.70277
		],
		8868: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		8869: [
			0,
			.69444,
			0,
			0,
			.89444
		],
		8900: [
			-.02639,
			.47361,
			0,
			0,
			.575
		],
		8901: [
			-.02639,
			.47361,
			0,
			0,
			.31944
		],
		8902: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		8968: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8969: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8970: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8971: [
			.25,
			.75,
			0,
			0,
			.51111
		],
		8994: [
			-.13889,
			.36111,
			0,
			0,
			1.14999
		],
		8995: [
			-.13889,
			.36111,
			0,
			0,
			1.14999
		],
		9651: [
			.19444,
			.69444,
			0,
			0,
			1.02222
		],
		9657: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		9661: [
			.19444,
			.69444,
			0,
			0,
			1.02222
		],
		9667: [
			-.02778,
			.47222,
			0,
			0,
			.575
		],
		9711: [
			.19444,
			.69444,
			0,
			0,
			1.14999
		],
		9824: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9825: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9826: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9827: [
			.12963,
			.69444,
			0,
			0,
			.89444
		],
		9837: [
			0,
			.75,
			0,
			0,
			.44722
		],
		9838: [
			.19444,
			.69444,
			0,
			0,
			.44722
		],
		9839: [
			.19444,
			.69444,
			0,
			0,
			.44722
		],
		10216: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		10217: [
			.25,
			.75,
			0,
			0,
			.44722
		],
		10815: [
			0,
			.68611,
			0,
			0,
			.9
		],
		10927: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		10928: [
			.19667,
			.69667,
			0,
			0,
			.89444
		],
		57376: [
			.19444,
			.69444,
			0,
			0,
			0
		]
	},
	"Main-BoldItalic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.11417,
			0,
			.38611
		],
		34: [
			0,
			.69444,
			.07939,
			0,
			.62055
		],
		35: [
			.19444,
			.69444,
			.06833,
			0,
			.94444
		],
		37: [
			.05556,
			.75,
			.12861,
			0,
			.94444
		],
		38: [
			0,
			.69444,
			.08528,
			0,
			.88555
		],
		39: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		40: [
			.25,
			.75,
			.15806,
			0,
			.47333
		],
		41: [
			.25,
			.75,
			.03306,
			0,
			.47333
		],
		42: [
			0,
			.75,
			.14333,
			0,
			.59111
		],
		43: [
			.10333,
			.60333,
			.03306,
			0,
			.88555
		],
		44: [
			.19444,
			.14722,
			0,
			0,
			.35555
		],
		45: [
			0,
			.44444,
			.02611,
			0,
			.41444
		],
		46: [
			0,
			.14722,
			0,
			0,
			.35555
		],
		47: [
			.25,
			.75,
			.15806,
			0,
			.59111
		],
		48: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		49: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		50: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		51: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		52: [
			.19444,
			.64444,
			.13167,
			0,
			.59111
		],
		53: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		54: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		55: [
			.19444,
			.64444,
			.13167,
			0,
			.59111
		],
		56: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		57: [
			0,
			.64444,
			.13167,
			0,
			.59111
		],
		58: [
			0,
			.44444,
			.06695,
			0,
			.35555
		],
		59: [
			.19444,
			.44444,
			.06695,
			0,
			.35555
		],
		61: [
			-.10889,
			.39111,
			.06833,
			0,
			.88555
		],
		63: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		64: [
			0,
			.69444,
			.09208,
			0,
			.88555
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86555
		],
		66: [
			0,
			.68611,
			.0992,
			0,
			.81666
		],
		67: [
			0,
			.68611,
			.14208,
			0,
			.82666
		],
		68: [
			0,
			.68611,
			.09062,
			0,
			.87555
		],
		69: [
			0,
			.68611,
			.11431,
			0,
			.75666
		],
		70: [
			0,
			.68611,
			.12903,
			0,
			.72722
		],
		71: [
			0,
			.68611,
			.07347,
			0,
			.89527
		],
		72: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		73: [
			0,
			.68611,
			.15681,
			0,
			.47166
		],
		74: [
			0,
			.68611,
			.145,
			0,
			.61055
		],
		75: [
			0,
			.68611,
			.14208,
			0,
			.89499
		],
		76: [
			0,
			.68611,
			0,
			0,
			.69777
		],
		77: [
			0,
			.68611,
			.17208,
			0,
			1.07277
		],
		78: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		79: [
			0,
			.68611,
			.09062,
			0,
			.85499
		],
		80: [
			0,
			.68611,
			.0992,
			0,
			.78721
		],
		81: [
			.19444,
			.68611,
			.09062,
			0,
			.85499
		],
		82: [
			0,
			.68611,
			.02559,
			0,
			.85944
		],
		83: [
			0,
			.68611,
			.11264,
			0,
			.64999
		],
		84: [
			0,
			.68611,
			.12903,
			0,
			.7961
		],
		85: [
			0,
			.68611,
			.17208,
			0,
			.88083
		],
		86: [
			0,
			.68611,
			.18625,
			0,
			.86555
		],
		87: [
			0,
			.68611,
			.18625,
			0,
			1.15999
		],
		88: [
			0,
			.68611,
			.15681,
			0,
			.86555
		],
		89: [
			0,
			.68611,
			.19803,
			0,
			.86555
		],
		90: [
			0,
			.68611,
			.14208,
			0,
			.70888
		],
		91: [
			.25,
			.75,
			.1875,
			0,
			.35611
		],
		93: [
			.25,
			.75,
			.09972,
			0,
			.35611
		],
		94: [
			0,
			.69444,
			.06709,
			0,
			.59111
		],
		95: [
			.31,
			.13444,
			.09811,
			0,
			.59111
		],
		97: [
			0,
			.44444,
			.09426,
			0,
			.59111
		],
		98: [
			0,
			.69444,
			.07861,
			0,
			.53222
		],
		99: [
			0,
			.44444,
			.05222,
			0,
			.53222
		],
		100: [
			0,
			.69444,
			.10861,
			0,
			.59111
		],
		101: [
			0,
			.44444,
			.085,
			0,
			.53222
		],
		102: [
			.19444,
			.69444,
			.21778,
			0,
			.4
		],
		103: [
			.19444,
			.44444,
			.105,
			0,
			.53222
		],
		104: [
			0,
			.69444,
			.09426,
			0,
			.59111
		],
		105: [
			0,
			.69326,
			.11387,
			0,
			.35555
		],
		106: [
			.19444,
			.69326,
			.1672,
			0,
			.35555
		],
		107: [
			0,
			.69444,
			.11111,
			0,
			.53222
		],
		108: [
			0,
			.69444,
			.10861,
			0,
			.29666
		],
		109: [
			0,
			.44444,
			.09426,
			0,
			.94444
		],
		110: [
			0,
			.44444,
			.09426,
			0,
			.64999
		],
		111: [
			0,
			.44444,
			.07861,
			0,
			.59111
		],
		112: [
			.19444,
			.44444,
			.07861,
			0,
			.59111
		],
		113: [
			.19444,
			.44444,
			.105,
			0,
			.53222
		],
		114: [
			0,
			.44444,
			.11111,
			0,
			.50167
		],
		115: [
			0,
			.44444,
			.08167,
			0,
			.48694
		],
		116: [
			0,
			.63492,
			.09639,
			0,
			.385
		],
		117: [
			0,
			.44444,
			.09426,
			0,
			.62055
		],
		118: [
			0,
			.44444,
			.11111,
			0,
			.53222
		],
		119: [
			0,
			.44444,
			.11111,
			0,
			.76777
		],
		120: [
			0,
			.44444,
			.12583,
			0,
			.56055
		],
		121: [
			.19444,
			.44444,
			.105,
			0,
			.56166
		],
		122: [
			0,
			.44444,
			.13889,
			0,
			.49055
		],
		126: [
			.35,
			.34444,
			.11472,
			0,
			.59111
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.69444,
			.11473,
			0,
			.59111
		],
		176: [
			0,
			.69444,
			0,
			0,
			.94888
		],
		184: [
			.17014,
			0,
			0,
			0,
			.53222
		],
		198: [
			0,
			.68611,
			.11431,
			0,
			1.02277
		],
		216: [
			.04861,
			.73472,
			.09062,
			0,
			.88555
		],
		223: [
			.19444,
			.69444,
			.09736,
			0,
			.665
		],
		230: [
			0,
			.44444,
			.085,
			0,
			.82666
		],
		248: [
			.09722,
			.54167,
			.09458,
			0,
			.59111
		],
		305: [
			0,
			.44444,
			.09426,
			0,
			.35555
		],
		338: [
			0,
			.68611,
			.11431,
			0,
			1.14054
		],
		339: [
			0,
			.44444,
			.085,
			0,
			.82666
		],
		567: [
			.19444,
			.44444,
			.04611,
			0,
			.385
		],
		710: [
			0,
			.69444,
			.06709,
			0,
			.59111
		],
		711: [
			0,
			.63194,
			.08271,
			0,
			.59111
		],
		713: [
			0,
			.59444,
			.10444,
			0,
			.59111
		],
		714: [
			0,
			.69444,
			.08528,
			0,
			.59111
		],
		715: [
			0,
			.69444,
			0,
			0,
			.59111
		],
		728: [
			0,
			.69444,
			.10333,
			0,
			.59111
		],
		729: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		730: [
			0,
			.69444,
			0,
			0,
			.94888
		],
		732: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		733: [
			0,
			.69444,
			.11472,
			0,
			.59111
		],
		915: [
			0,
			.68611,
			.12903,
			0,
			.69777
		],
		916: [
			0,
			.68611,
			0,
			0,
			.94444
		],
		920: [
			0,
			.68611,
			.09062,
			0,
			.88555
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80666
		],
		926: [
			0,
			.68611,
			.15092,
			0,
			.76777
		],
		928: [
			0,
			.68611,
			.17208,
			0,
			.8961
		],
		931: [
			0,
			.68611,
			.11431,
			0,
			.82666
		],
		933: [
			0,
			.68611,
			.10778,
			0,
			.88555
		],
		934: [
			0,
			.68611,
			.05632,
			0,
			.82666
		],
		936: [
			0,
			.68611,
			.10778,
			0,
			.88555
		],
		937: [
			0,
			.68611,
			.0992,
			0,
			.82666
		],
		8211: [
			0,
			.44444,
			.09811,
			0,
			.59111
		],
		8212: [
			0,
			.44444,
			.09811,
			0,
			1.18221
		],
		8216: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		8217: [
			0,
			.69444,
			.12945,
			0,
			.35555
		],
		8220: [
			0,
			.69444,
			.16772,
			0,
			.62055
		],
		8221: [
			0,
			.69444,
			.07939,
			0,
			.62055
		]
	},
	"Main-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		34: [
			0,
			.69444,
			.06961,
			0,
			.51444
		],
		35: [
			.19444,
			.69444,
			.06616,
			0,
			.81777
		],
		37: [
			.05556,
			.75,
			.13639,
			0,
			.81777
		],
		38: [
			0,
			.69444,
			.09694,
			0,
			.76666
		],
		39: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		40: [
			.25,
			.75,
			.16194,
			0,
			.40889
		],
		41: [
			.25,
			.75,
			.03694,
			0,
			.40889
		],
		42: [
			0,
			.75,
			.14917,
			0,
			.51111
		],
		43: [
			.05667,
			.56167,
			.03694,
			0,
			.76666
		],
		44: [
			.19444,
			.10556,
			0,
			0,
			.30667
		],
		45: [
			0,
			.43056,
			.02826,
			0,
			.35778
		],
		46: [
			0,
			.10556,
			0,
			0,
			.30667
		],
		47: [
			.25,
			.75,
			.16194,
			0,
			.51111
		],
		48: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		49: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		50: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		51: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		52: [
			.19444,
			.64444,
			.13556,
			0,
			.51111
		],
		53: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		54: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		55: [
			.19444,
			.64444,
			.13556,
			0,
			.51111
		],
		56: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		57: [
			0,
			.64444,
			.13556,
			0,
			.51111
		],
		58: [
			0,
			.43056,
			.0582,
			0,
			.30667
		],
		59: [
			.19444,
			.43056,
			.0582,
			0,
			.30667
		],
		61: [
			-.13313,
			.36687,
			.06616,
			0,
			.76666
		],
		63: [
			0,
			.69444,
			.1225,
			0,
			.51111
		],
		64: [
			0,
			.69444,
			.09597,
			0,
			.76666
		],
		65: [
			0,
			.68333,
			0,
			0,
			.74333
		],
		66: [
			0,
			.68333,
			.10257,
			0,
			.70389
		],
		67: [
			0,
			.68333,
			.14528,
			0,
			.71555
		],
		68: [
			0,
			.68333,
			.09403,
			0,
			.755
		],
		69: [
			0,
			.68333,
			.12028,
			0,
			.67833
		],
		70: [
			0,
			.68333,
			.13305,
			0,
			.65277
		],
		71: [
			0,
			.68333,
			.08722,
			0,
			.77361
		],
		72: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		73: [
			0,
			.68333,
			.15806,
			0,
			.38555
		],
		74: [
			0,
			.68333,
			.14028,
			0,
			.525
		],
		75: [
			0,
			.68333,
			.14528,
			0,
			.76888
		],
		76: [
			0,
			.68333,
			0,
			0,
			.62722
		],
		77: [
			0,
			.68333,
			.16389,
			0,
			.89666
		],
		78: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		79: [
			0,
			.68333,
			.09403,
			0,
			.76666
		],
		80: [
			0,
			.68333,
			.10257,
			0,
			.67833
		],
		81: [
			.19444,
			.68333,
			.09403,
			0,
			.76666
		],
		82: [
			0,
			.68333,
			.03868,
			0,
			.72944
		],
		83: [
			0,
			.68333,
			.11972,
			0,
			.56222
		],
		84: [
			0,
			.68333,
			.13305,
			0,
			.71555
		],
		85: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		86: [
			0,
			.68333,
			.18361,
			0,
			.74333
		],
		87: [
			0,
			.68333,
			.18361,
			0,
			.99888
		],
		88: [
			0,
			.68333,
			.15806,
			0,
			.74333
		],
		89: [
			0,
			.68333,
			.19383,
			0,
			.74333
		],
		90: [
			0,
			.68333,
			.14528,
			0,
			.61333
		],
		91: [
			.25,
			.75,
			.1875,
			0,
			.30667
		],
		93: [
			.25,
			.75,
			.10528,
			0,
			.30667
		],
		94: [
			0,
			.69444,
			.06646,
			0,
			.51111
		],
		95: [
			.31,
			.12056,
			.09208,
			0,
			.51111
		],
		97: [
			0,
			.43056,
			.07671,
			0,
			.51111
		],
		98: [
			0,
			.69444,
			.06312,
			0,
			.46
		],
		99: [
			0,
			.43056,
			.05653,
			0,
			.46
		],
		100: [
			0,
			.69444,
			.10333,
			0,
			.51111
		],
		101: [
			0,
			.43056,
			.07514,
			0,
			.46
		],
		102: [
			.19444,
			.69444,
			.21194,
			0,
			.30667
		],
		103: [
			.19444,
			.43056,
			.08847,
			0,
			.46
		],
		104: [
			0,
			.69444,
			.07671,
			0,
			.51111
		],
		105: [
			0,
			.65536,
			.1019,
			0,
			.30667
		],
		106: [
			.19444,
			.65536,
			.14467,
			0,
			.30667
		],
		107: [
			0,
			.69444,
			.10764,
			0,
			.46
		],
		108: [
			0,
			.69444,
			.10333,
			0,
			.25555
		],
		109: [
			0,
			.43056,
			.07671,
			0,
			.81777
		],
		110: [
			0,
			.43056,
			.07671,
			0,
			.56222
		],
		111: [
			0,
			.43056,
			.06312,
			0,
			.51111
		],
		112: [
			.19444,
			.43056,
			.06312,
			0,
			.51111
		],
		113: [
			.19444,
			.43056,
			.08847,
			0,
			.46
		],
		114: [
			0,
			.43056,
			.10764,
			0,
			.42166
		],
		115: [
			0,
			.43056,
			.08208,
			0,
			.40889
		],
		116: [
			0,
			.61508,
			.09486,
			0,
			.33222
		],
		117: [
			0,
			.43056,
			.07671,
			0,
			.53666
		],
		118: [
			0,
			.43056,
			.10764,
			0,
			.46
		],
		119: [
			0,
			.43056,
			.10764,
			0,
			.66444
		],
		120: [
			0,
			.43056,
			.12042,
			0,
			.46389
		],
		121: [
			.19444,
			.43056,
			.08847,
			0,
			.48555
		],
		122: [
			0,
			.43056,
			.12292,
			0,
			.40889
		],
		126: [
			.35,
			.31786,
			.11585,
			0,
			.51111
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.66786,
			.10474,
			0,
			.51111
		],
		176: [
			0,
			.69444,
			0,
			0,
			.83129
		],
		184: [
			.17014,
			0,
			0,
			0,
			.46
		],
		198: [
			0,
			.68333,
			.12028,
			0,
			.88277
		],
		216: [
			.04861,
			.73194,
			.09403,
			0,
			.76666
		],
		223: [
			.19444,
			.69444,
			.10514,
			0,
			.53666
		],
		230: [
			0,
			.43056,
			.07514,
			0,
			.71555
		],
		248: [
			.09722,
			.52778,
			.09194,
			0,
			.51111
		],
		338: [
			0,
			.68333,
			.12028,
			0,
			.98499
		],
		339: [
			0,
			.43056,
			.07514,
			0,
			.71555
		],
		710: [
			0,
			.69444,
			.06646,
			0,
			.51111
		],
		711: [
			0,
			.62847,
			.08295,
			0,
			.51111
		],
		713: [
			0,
			.56167,
			.10333,
			0,
			.51111
		],
		714: [
			0,
			.69444,
			.09694,
			0,
			.51111
		],
		715: [
			0,
			.69444,
			0,
			0,
			.51111
		],
		728: [
			0,
			.69444,
			.10806,
			0,
			.51111
		],
		729: [
			0,
			.66786,
			.11752,
			0,
			.30667
		],
		730: [
			0,
			.69444,
			0,
			0,
			.83129
		],
		732: [
			0,
			.66786,
			.11585,
			0,
			.51111
		],
		733: [
			0,
			.69444,
			.1225,
			0,
			.51111
		],
		915: [
			0,
			.68333,
			.13305,
			0,
			.62722
		],
		916: [
			0,
			.68333,
			0,
			0,
			.81777
		],
		920: [
			0,
			.68333,
			.09403,
			0,
			.76666
		],
		923: [
			0,
			.68333,
			0,
			0,
			.69222
		],
		926: [
			0,
			.68333,
			.15294,
			0,
			.66444
		],
		928: [
			0,
			.68333,
			.16389,
			0,
			.74333
		],
		931: [
			0,
			.68333,
			.12028,
			0,
			.71555
		],
		933: [
			0,
			.68333,
			.11111,
			0,
			.76666
		],
		934: [
			0,
			.68333,
			.05986,
			0,
			.71555
		],
		936: [
			0,
			.68333,
			.11111,
			0,
			.76666
		],
		937: [
			0,
			.68333,
			.10257,
			0,
			.71555
		],
		8211: [
			0,
			.43056,
			.09208,
			0,
			.51111
		],
		8212: [
			0,
			.43056,
			.09208,
			0,
			1.02222
		],
		8216: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		8217: [
			0,
			.69444,
			.12417,
			0,
			.30667
		],
		8220: [
			0,
			.69444,
			.1685,
			0,
			.51444
		],
		8221: [
			0,
			.69444,
			.06961,
			0,
			.51444
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		]
	},
	"Main-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		34: [
			0,
			.69444,
			0,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		39: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		42: [
			0,
			.75,
			0,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		44: [
			.19444,
			.10556,
			0,
			0,
			.27778
		],
		45: [
			0,
			.43056,
			0,
			0,
			.33333
		],
		46: [
			0,
			.10556,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			0,
			0,
			.5
		],
		48: [
			0,
			.64444,
			0,
			0,
			.5
		],
		49: [
			0,
			.64444,
			0,
			0,
			.5
		],
		50: [
			0,
			.64444,
			0,
			0,
			.5
		],
		51: [
			0,
			.64444,
			0,
			0,
			.5
		],
		52: [
			0,
			.64444,
			0,
			0,
			.5
		],
		53: [
			0,
			.64444,
			0,
			0,
			.5
		],
		54: [
			0,
			.64444,
			0,
			0,
			.5
		],
		55: [
			0,
			.64444,
			0,
			0,
			.5
		],
		56: [
			0,
			.64444,
			0,
			0,
			.5
		],
		57: [
			0,
			.64444,
			0,
			0,
			.5
		],
		58: [
			0,
			.43056,
			0,
			0,
			.27778
		],
		59: [
			.19444,
			.43056,
			0,
			0,
			.27778
		],
		60: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		61: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		62: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		65: [
			0,
			.68333,
			0,
			0,
			.75
		],
		66: [
			0,
			.68333,
			0,
			0,
			.70834
		],
		67: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		68: [
			0,
			.68333,
			0,
			0,
			.76389
		],
		69: [
			0,
			.68333,
			0,
			0,
			.68056
		],
		70: [
			0,
			.68333,
			0,
			0,
			.65278
		],
		71: [
			0,
			.68333,
			0,
			0,
			.78472
		],
		72: [
			0,
			.68333,
			0,
			0,
			.75
		],
		73: [
			0,
			.68333,
			0,
			0,
			.36111
		],
		74: [
			0,
			.68333,
			0,
			0,
			.51389
		],
		75: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		76: [
			0,
			.68333,
			0,
			0,
			.625
		],
		77: [
			0,
			.68333,
			0,
			0,
			.91667
		],
		78: [
			0,
			.68333,
			0,
			0,
			.75
		],
		79: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		80: [
			0,
			.68333,
			0,
			0,
			.68056
		],
		81: [
			.19444,
			.68333,
			0,
			0,
			.77778
		],
		82: [
			0,
			.68333,
			0,
			0,
			.73611
		],
		83: [
			0,
			.68333,
			0,
			0,
			.55556
		],
		84: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		85: [
			0,
			.68333,
			0,
			0,
			.75
		],
		86: [
			0,
			.68333,
			.01389,
			0,
			.75
		],
		87: [
			0,
			.68333,
			.01389,
			0,
			1.02778
		],
		88: [
			0,
			.68333,
			0,
			0,
			.75
		],
		89: [
			0,
			.68333,
			.025,
			0,
			.75
		],
		90: [
			0,
			.68333,
			0,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		92: [
			.25,
			.75,
			0,
			0,
			.5
		],
		93: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		94: [
			0,
			.69444,
			0,
			0,
			.5
		],
		95: [
			.31,
			.12056,
			.02778,
			0,
			.5
		],
		97: [
			0,
			.43056,
			0,
			0,
			.5
		],
		98: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		99: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		101: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.07778,
			0,
			.30556
		],
		103: [
			.19444,
			.43056,
			.01389,
			0,
			.5
		],
		104: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		105: [
			0,
			.66786,
			0,
			0,
			.27778
		],
		106: [
			.19444,
			.66786,
			0,
			0,
			.30556
		],
		107: [
			0,
			.69444,
			0,
			0,
			.52778
		],
		108: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		109: [
			0,
			.43056,
			0,
			0,
			.83334
		],
		110: [
			0,
			.43056,
			0,
			0,
			.55556
		],
		111: [
			0,
			.43056,
			0,
			0,
			.5
		],
		112: [
			.19444,
			.43056,
			0,
			0,
			.55556
		],
		113: [
			.19444,
			.43056,
			0,
			0,
			.52778
		],
		114: [
			0,
			.43056,
			0,
			0,
			.39167
		],
		115: [
			0,
			.43056,
			0,
			0,
			.39445
		],
		116: [
			0,
			.61508,
			0,
			0,
			.38889
		],
		117: [
			0,
			.43056,
			0,
			0,
			.55556
		],
		118: [
			0,
			.43056,
			.01389,
			0,
			.52778
		],
		119: [
			0,
			.43056,
			.01389,
			0,
			.72222
		],
		120: [
			0,
			.43056,
			0,
			0,
			.52778
		],
		121: [
			.19444,
			.43056,
			.01389,
			0,
			.52778
		],
		122: [
			0,
			.43056,
			0,
			0,
			.44445
		],
		123: [
			.25,
			.75,
			0,
			0,
			.5
		],
		124: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		125: [
			.25,
			.75,
			0,
			0,
			.5
		],
		126: [
			.35,
			.31786,
			0,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		163: [
			0,
			.69444,
			0,
			0,
			.76909
		],
		167: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		168: [
			0,
			.66786,
			0,
			0,
			.5
		],
		172: [
			0,
			.43056,
			0,
			0,
			.66667
		],
		176: [
			0,
			.69444,
			0,
			0,
			.75
		],
		177: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		182: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		198: [
			0,
			.68333,
			0,
			0,
			.90278
		],
		215: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		216: [
			.04861,
			.73194,
			0,
			0,
			.77778
		],
		223: [
			0,
			.69444,
			0,
			0,
			.5
		],
		230: [
			0,
			.43056,
			0,
			0,
			.72222
		],
		247: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		248: [
			.09722,
			.52778,
			0,
			0,
			.5
		],
		305: [
			0,
			.43056,
			0,
			0,
			.27778
		],
		338: [
			0,
			.68333,
			0,
			0,
			1.01389
		],
		339: [
			0,
			.43056,
			0,
			0,
			.77778
		],
		567: [
			.19444,
			.43056,
			0,
			0,
			.30556
		],
		710: [
			0,
			.69444,
			0,
			0,
			.5
		],
		711: [
			0,
			.62847,
			0,
			0,
			.5
		],
		713: [
			0,
			.56778,
			0,
			0,
			.5
		],
		714: [
			0,
			.69444,
			0,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			0,
			0,
			.5
		],
		729: [
			0,
			.66786,
			0,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.75
		],
		732: [
			0,
			.66786,
			0,
			0,
			.5
		],
		733: [
			0,
			.69444,
			0,
			0,
			.5
		],
		915: [
			0,
			.68333,
			0,
			0,
			.625
		],
		916: [
			0,
			.68333,
			0,
			0,
			.83334
		],
		920: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		923: [
			0,
			.68333,
			0,
			0,
			.69445
		],
		926: [
			0,
			.68333,
			0,
			0,
			.66667
		],
		928: [
			0,
			.68333,
			0,
			0,
			.75
		],
		931: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		933: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		934: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		936: [
			0,
			.68333,
			0,
			0,
			.77778
		],
		937: [
			0,
			.68333,
			0,
			0,
			.72222
		],
		8211: [
			0,
			.43056,
			.02778,
			0,
			.5
		],
		8212: [
			0,
			.43056,
			.02778,
			0,
			1
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8224: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		8225: [
			.19444,
			.69444,
			0,
			0,
			.44445
		],
		8230: [
			0,
			.123,
			0,
			0,
			1.172
		],
		8242: [
			0,
			.55556,
			0,
			0,
			.275
		],
		8407: [
			0,
			.71444,
			.15382,
			0,
			.5
		],
		8463: [
			0,
			.68889,
			0,
			0,
			.54028
		],
		8465: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8467: [
			0,
			.69444,
			0,
			.11111,
			.41667
		],
		8472: [
			.19444,
			.43056,
			0,
			.11111,
			.63646
		],
		8476: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8501: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8592: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8593: [
			.19444,
			.69444,
			0,
			0,
			.5
		],
		8594: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8595: [
			.19444,
			.69444,
			0,
			0,
			.5
		],
		8596: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8597: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8598: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8599: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8600: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8601: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		8614: [
			.011,
			.511,
			0,
			0,
			1
		],
		8617: [
			.011,
			.511,
			0,
			0,
			1.126
		],
		8618: [
			.011,
			.511,
			0,
			0,
			1.126
		],
		8636: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8637: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8640: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8641: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8652: [
			.011,
			.671,
			0,
			0,
			1
		],
		8656: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8657: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		8658: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8659: [
			.19444,
			.69444,
			0,
			0,
			.61111
		],
		8660: [
			-.13313,
			.36687,
			0,
			0,
			1
		],
		8661: [
			.25,
			.75,
			0,
			0,
			.61111
		],
		8704: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		8706: [
			0,
			.69444,
			.05556,
			.08334,
			.5309
		],
		8707: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		8709: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		8711: [
			0,
			.68333,
			0,
			0,
			.83334
		],
		8712: [
			.0391,
			.5391,
			0,
			0,
			.66667
		],
		8715: [
			.0391,
			.5391,
			0,
			0,
			.66667
		],
		8722: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8723: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8725: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8726: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8727: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		8728: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8729: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8730: [
			.2,
			.8,
			0,
			0,
			.83334
		],
		8733: [
			0,
			.43056,
			0,
			0,
			.77778
		],
		8734: [
			0,
			.43056,
			0,
			0,
			1
		],
		8736: [
			0,
			.69224,
			0,
			0,
			.72222
		],
		8739: [
			.25,
			.75,
			0,
			0,
			.27778
		],
		8741: [
			.25,
			.75,
			0,
			0,
			.5
		],
		8743: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8744: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8745: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8746: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8747: [
			.19444,
			.69444,
			.11111,
			0,
			.41667
		],
		8764: [
			-.13313,
			.36687,
			0,
			0,
			.77778
		],
		8768: [
			.19444,
			.69444,
			0,
			0,
			.27778
		],
		8771: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8773: [
			-.022,
			.589,
			0,
			0,
			.778
		],
		8776: [
			-.01688,
			.48312,
			0,
			0,
			.77778
		],
		8781: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8784: [
			-.133,
			.673,
			0,
			0,
			.778
		],
		8801: [
			-.03625,
			.46375,
			0,
			0,
			.77778
		],
		8804: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8805: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8810: [
			.0391,
			.5391,
			0,
			0,
			1
		],
		8811: [
			.0391,
			.5391,
			0,
			0,
			1
		],
		8826: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8827: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8834: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8835: [
			.0391,
			.5391,
			0,
			0,
			.77778
		],
		8838: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8839: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8846: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8849: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8850: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		8851: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8852: [
			0,
			.55556,
			0,
			0,
			.66667
		],
		8853: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8854: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8855: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8856: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8857: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		8866: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8867: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		8868: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		8869: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		8872: [
			.249,
			.75,
			0,
			0,
			.867
		],
		8900: [
			-.05555,
			.44445,
			0,
			0,
			.5
		],
		8901: [
			-.05555,
			.44445,
			0,
			0,
			.27778
		],
		8902: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		8904: [
			.005,
			.505,
			0,
			0,
			.9
		],
		8942: [
			.03,
			.903,
			0,
			0,
			.278
		],
		8943: [
			-.19,
			.313,
			0,
			0,
			1.172
		],
		8945: [
			-.1,
			.823,
			0,
			0,
			1.282
		],
		8968: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8969: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8970: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8971: [
			.25,
			.75,
			0,
			0,
			.44445
		],
		8994: [
			-.14236,
			.35764,
			0,
			0,
			1
		],
		8995: [
			-.14236,
			.35764,
			0,
			0,
			1
		],
		9136: [
			.244,
			.744,
			0,
			0,
			.412
		],
		9137: [
			.244,
			.745,
			0,
			0,
			.412
		],
		9651: [
			.19444,
			.69444,
			0,
			0,
			.88889
		],
		9657: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		9661: [
			.19444,
			.69444,
			0,
			0,
			.88889
		],
		9667: [
			-.03472,
			.46528,
			0,
			0,
			.5
		],
		9711: [
			.19444,
			.69444,
			0,
			0,
			1
		],
		9824: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9825: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9826: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9827: [
			.12963,
			.69444,
			0,
			0,
			.77778
		],
		9837: [
			0,
			.75,
			0,
			0,
			.38889
		],
		9838: [
			.19444,
			.69444,
			0,
			0,
			.38889
		],
		9839: [
			.19444,
			.69444,
			0,
			0,
			.38889
		],
		10216: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		10217: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		10222: [
			.244,
			.744,
			0,
			0,
			.412
		],
		10223: [
			.244,
			.745,
			0,
			0,
			.412
		],
		10229: [
			.011,
			.511,
			0,
			0,
			1.609
		],
		10230: [
			.011,
			.511,
			0,
			0,
			1.638
		],
		10231: [
			.011,
			.511,
			0,
			0,
			1.859
		],
		10232: [
			.024,
			.525,
			0,
			0,
			1.609
		],
		10233: [
			.024,
			.525,
			0,
			0,
			1.638
		],
		10234: [
			.024,
			.525,
			0,
			0,
			1.858
		],
		10236: [
			.011,
			.511,
			0,
			0,
			1.638
		],
		10815: [
			0,
			.68333,
			0,
			0,
			.75
		],
		10927: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		10928: [
			.13597,
			.63597,
			0,
			0,
			.77778
		],
		57376: [
			.19444,
			.69444,
			0,
			0,
			0
		]
	},
	"Math-BoldItalic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		48: [
			0,
			.44444,
			0,
			0,
			.575
		],
		49: [
			0,
			.44444,
			0,
			0,
			.575
		],
		50: [
			0,
			.44444,
			0,
			0,
			.575
		],
		51: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		52: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		53: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		54: [
			0,
			.64444,
			0,
			0,
			.575
		],
		55: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		56: [
			0,
			.64444,
			0,
			0,
			.575
		],
		57: [
			.19444,
			.44444,
			0,
			0,
			.575
		],
		65: [
			0,
			.68611,
			0,
			0,
			.86944
		],
		66: [
			0,
			.68611,
			.04835,
			0,
			.8664
		],
		67: [
			0,
			.68611,
			.06979,
			0,
			.81694
		],
		68: [
			0,
			.68611,
			.03194,
			0,
			.93812
		],
		69: [
			0,
			.68611,
			.05451,
			0,
			.81007
		],
		70: [
			0,
			.68611,
			.15972,
			0,
			.68889
		],
		71: [
			0,
			.68611,
			0,
			0,
			.88673
		],
		72: [
			0,
			.68611,
			.08229,
			0,
			.98229
		],
		73: [
			0,
			.68611,
			.07778,
			0,
			.51111
		],
		74: [
			0,
			.68611,
			.10069,
			0,
			.63125
		],
		75: [
			0,
			.68611,
			.06979,
			0,
			.97118
		],
		76: [
			0,
			.68611,
			0,
			0,
			.75555
		],
		77: [
			0,
			.68611,
			.11424,
			0,
			1.14201
		],
		78: [
			0,
			.68611,
			.11424,
			0,
			.95034
		],
		79: [
			0,
			.68611,
			.03194,
			0,
			.83666
		],
		80: [
			0,
			.68611,
			.15972,
			0,
			.72309
		],
		81: [
			.19444,
			.68611,
			0,
			0,
			.86861
		],
		82: [
			0,
			.68611,
			.00421,
			0,
			.87235
		],
		83: [
			0,
			.68611,
			.05382,
			0,
			.69271
		],
		84: [
			0,
			.68611,
			.15972,
			0,
			.63663
		],
		85: [
			0,
			.68611,
			.11424,
			0,
			.80027
		],
		86: [
			0,
			.68611,
			.25555,
			0,
			.67778
		],
		87: [
			0,
			.68611,
			.15972,
			0,
			1.09305
		],
		88: [
			0,
			.68611,
			.07778,
			0,
			.94722
		],
		89: [
			0,
			.68611,
			.25555,
			0,
			.67458
		],
		90: [
			0,
			.68611,
			.06979,
			0,
			.77257
		],
		97: [
			0,
			.44444,
			0,
			0,
			.63287
		],
		98: [
			0,
			.69444,
			0,
			0,
			.52083
		],
		99: [
			0,
			.44444,
			0,
			0,
			.51342
		],
		100: [
			0,
			.69444,
			0,
			0,
			.60972
		],
		101: [
			0,
			.44444,
			0,
			0,
			.55361
		],
		102: [
			.19444,
			.69444,
			.11042,
			0,
			.56806
		],
		103: [
			.19444,
			.44444,
			.03704,
			0,
			.5449
		],
		104: [
			0,
			.69444,
			0,
			0,
			.66759
		],
		105: [
			0,
			.69326,
			0,
			0,
			.4048
		],
		106: [
			.19444,
			.69326,
			.0622,
			0,
			.47083
		],
		107: [
			0,
			.69444,
			.01852,
			0,
			.6037
		],
		108: [
			0,
			.69444,
			.0088,
			0,
			.34815
		],
		109: [
			0,
			.44444,
			0,
			0,
			1.0324
		],
		110: [
			0,
			.44444,
			0,
			0,
			.71296
		],
		111: [
			0,
			.44444,
			0,
			0,
			.58472
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.60092
		],
		113: [
			.19444,
			.44444,
			.03704,
			0,
			.54213
		],
		114: [
			0,
			.44444,
			.03194,
			0,
			.5287
		],
		115: [
			0,
			.44444,
			0,
			0,
			.53125
		],
		116: [
			0,
			.63492,
			0,
			0,
			.41528
		],
		117: [
			0,
			.44444,
			0,
			0,
			.68102
		],
		118: [
			0,
			.44444,
			.03704,
			0,
			.56666
		],
		119: [
			0,
			.44444,
			.02778,
			0,
			.83148
		],
		120: [
			0,
			.44444,
			0,
			0,
			.65903
		],
		121: [
			.19444,
			.44444,
			.03704,
			0,
			.59028
		],
		122: [
			0,
			.44444,
			.04213,
			0,
			.55509
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		915: [
			0,
			.68611,
			.15972,
			0,
			.65694
		],
		916: [
			0,
			.68611,
			0,
			0,
			.95833
		],
		920: [
			0,
			.68611,
			.03194,
			0,
			.86722
		],
		923: [
			0,
			.68611,
			0,
			0,
			.80555
		],
		926: [
			0,
			.68611,
			.07458,
			0,
			.84125
		],
		928: [
			0,
			.68611,
			.08229,
			0,
			.98229
		],
		931: [
			0,
			.68611,
			.05451,
			0,
			.88507
		],
		933: [
			0,
			.68611,
			.15972,
			0,
			.67083
		],
		934: [
			0,
			.68611,
			0,
			0,
			.76666
		],
		936: [
			0,
			.68611,
			.11653,
			0,
			.71402
		],
		937: [
			0,
			.68611,
			.04835,
			0,
			.8789
		],
		945: [
			0,
			.44444,
			0,
			0,
			.76064
		],
		946: [
			.19444,
			.69444,
			.03403,
			0,
			.65972
		],
		947: [
			.19444,
			.44444,
			.06389,
			0,
			.59003
		],
		948: [
			0,
			.69444,
			.03819,
			0,
			.52222
		],
		949: [
			0,
			.44444,
			0,
			0,
			.52882
		],
		950: [
			.19444,
			.69444,
			.06215,
			0,
			.50833
		],
		951: [
			.19444,
			.44444,
			.03704,
			0,
			.6
		],
		952: [
			0,
			.69444,
			.03194,
			0,
			.5618
		],
		953: [
			0,
			.44444,
			0,
			0,
			.41204
		],
		954: [
			0,
			.44444,
			0,
			0,
			.66759
		],
		955: [
			0,
			.69444,
			0,
			0,
			.67083
		],
		956: [
			.19444,
			.44444,
			0,
			0,
			.70787
		],
		957: [
			0,
			.44444,
			.06898,
			0,
			.57685
		],
		958: [
			.19444,
			.69444,
			.03021,
			0,
			.50833
		],
		959: [
			0,
			.44444,
			0,
			0,
			.58472
		],
		960: [
			0,
			.44444,
			.03704,
			0,
			.68241
		],
		961: [
			.19444,
			.44444,
			0,
			0,
			.6118
		],
		962: [
			.09722,
			.44444,
			.07917,
			0,
			.42361
		],
		963: [
			0,
			.44444,
			.03704,
			0,
			.68588
		],
		964: [
			0,
			.44444,
			.13472,
			0,
			.52083
		],
		965: [
			0,
			.44444,
			.03704,
			0,
			.63055
		],
		966: [
			.19444,
			.44444,
			0,
			0,
			.74722
		],
		967: [
			.19444,
			.44444,
			0,
			0,
			.71805
		],
		968: [
			.19444,
			.69444,
			.03704,
			0,
			.75833
		],
		969: [
			0,
			.44444,
			.03704,
			0,
			.71782
		],
		977: [
			0,
			.69444,
			0,
			0,
			.69155
		],
		981: [
			.19444,
			.69444,
			0,
			0,
			.7125
		],
		982: [
			0,
			.44444,
			.03194,
			0,
			.975
		],
		1009: [
			.19444,
			.44444,
			0,
			0,
			.6118
		],
		1013: [
			0,
			.44444,
			0,
			0,
			.48333
		],
		57649: [
			0,
			.44444,
			0,
			0,
			.39352
		],
		57911: [
			.19444,
			.44444,
			0,
			0,
			.43889
		]
	},
	"Math-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		48: [
			0,
			.43056,
			0,
			0,
			.5
		],
		49: [
			0,
			.43056,
			0,
			0,
			.5
		],
		50: [
			0,
			.43056,
			0,
			0,
			.5
		],
		51: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		52: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		53: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		54: [
			0,
			.64444,
			0,
			0,
			.5
		],
		55: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		56: [
			0,
			.64444,
			0,
			0,
			.5
		],
		57: [
			.19444,
			.43056,
			0,
			0,
			.5
		],
		65: [
			0,
			.68333,
			0,
			.13889,
			.75
		],
		66: [
			0,
			.68333,
			.05017,
			.08334,
			.75851
		],
		67: [
			0,
			.68333,
			.07153,
			.08334,
			.71472
		],
		68: [
			0,
			.68333,
			.02778,
			.05556,
			.82792
		],
		69: [
			0,
			.68333,
			.05764,
			.08334,
			.7382
		],
		70: [
			0,
			.68333,
			.13889,
			.08334,
			.64306
		],
		71: [
			0,
			.68333,
			0,
			.08334,
			.78625
		],
		72: [
			0,
			.68333,
			.08125,
			.05556,
			.83125
		],
		73: [
			0,
			.68333,
			.07847,
			.11111,
			.43958
		],
		74: [
			0,
			.68333,
			.09618,
			.16667,
			.55451
		],
		75: [
			0,
			.68333,
			.07153,
			.05556,
			.84931
		],
		76: [
			0,
			.68333,
			0,
			.02778,
			.68056
		],
		77: [
			0,
			.68333,
			.10903,
			.08334,
			.97014
		],
		78: [
			0,
			.68333,
			.10903,
			.08334,
			.80347
		],
		79: [
			0,
			.68333,
			.02778,
			.08334,
			.76278
		],
		80: [
			0,
			.68333,
			.13889,
			.08334,
			.64201
		],
		81: [
			.19444,
			.68333,
			0,
			.08334,
			.79056
		],
		82: [
			0,
			.68333,
			.00773,
			.08334,
			.75929
		],
		83: [
			0,
			.68333,
			.05764,
			.08334,
			.6132
		],
		84: [
			0,
			.68333,
			.13889,
			.08334,
			.58438
		],
		85: [
			0,
			.68333,
			.10903,
			.02778,
			.68278
		],
		86: [
			0,
			.68333,
			.22222,
			0,
			.58333
		],
		87: [
			0,
			.68333,
			.13889,
			0,
			.94445
		],
		88: [
			0,
			.68333,
			.07847,
			.08334,
			.82847
		],
		89: [
			0,
			.68333,
			.22222,
			0,
			.58056
		],
		90: [
			0,
			.68333,
			.07153,
			.08334,
			.68264
		],
		97: [
			0,
			.43056,
			0,
			0,
			.52859
		],
		98: [
			0,
			.69444,
			0,
			0,
			.42917
		],
		99: [
			0,
			.43056,
			0,
			.05556,
			.43276
		],
		100: [
			0,
			.69444,
			0,
			.16667,
			.52049
		],
		101: [
			0,
			.43056,
			0,
			.05556,
			.46563
		],
		102: [
			.19444,
			.69444,
			.10764,
			.16667,
			.48959
		],
		103: [
			.19444,
			.43056,
			.03588,
			.02778,
			.47697
		],
		104: [
			0,
			.69444,
			0,
			0,
			.57616
		],
		105: [
			0,
			.65952,
			0,
			0,
			.34451
		],
		106: [
			.19444,
			.65952,
			.05724,
			0,
			.41181
		],
		107: [
			0,
			.69444,
			.03148,
			0,
			.5206
		],
		108: [
			0,
			.69444,
			.01968,
			.08334,
			.29838
		],
		109: [
			0,
			.43056,
			0,
			0,
			.87801
		],
		110: [
			0,
			.43056,
			0,
			0,
			.60023
		],
		111: [
			0,
			.43056,
			0,
			.05556,
			.48472
		],
		112: [
			.19444,
			.43056,
			0,
			.08334,
			.50313
		],
		113: [
			.19444,
			.43056,
			.03588,
			.08334,
			.44641
		],
		114: [
			0,
			.43056,
			.02778,
			.05556,
			.45116
		],
		115: [
			0,
			.43056,
			0,
			.05556,
			.46875
		],
		116: [
			0,
			.61508,
			0,
			.08334,
			.36111
		],
		117: [
			0,
			.43056,
			0,
			.02778,
			.57246
		],
		118: [
			0,
			.43056,
			.03588,
			.02778,
			.48472
		],
		119: [
			0,
			.43056,
			.02691,
			.08334,
			.71592
		],
		120: [
			0,
			.43056,
			0,
			.02778,
			.57153
		],
		121: [
			.19444,
			.43056,
			.03588,
			.05556,
			.49028
		],
		122: [
			0,
			.43056,
			.04398,
			.05556,
			.46505
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		915: [
			0,
			.68333,
			.13889,
			.08334,
			.61528
		],
		916: [
			0,
			.68333,
			0,
			.16667,
			.83334
		],
		920: [
			0,
			.68333,
			.02778,
			.08334,
			.76278
		],
		923: [
			0,
			.68333,
			0,
			.16667,
			.69445
		],
		926: [
			0,
			.68333,
			.07569,
			.08334,
			.74236
		],
		928: [
			0,
			.68333,
			.08125,
			.05556,
			.83125
		],
		931: [
			0,
			.68333,
			.05764,
			.08334,
			.77986
		],
		933: [
			0,
			.68333,
			.13889,
			.05556,
			.58333
		],
		934: [
			0,
			.68333,
			0,
			.08334,
			.66667
		],
		936: [
			0,
			.68333,
			.11,
			.05556,
			.61222
		],
		937: [
			0,
			.68333,
			.05017,
			.08334,
			.7724
		],
		945: [
			0,
			.43056,
			.0037,
			.02778,
			.6397
		],
		946: [
			.19444,
			.69444,
			.05278,
			.08334,
			.56563
		],
		947: [
			.19444,
			.43056,
			.05556,
			0,
			.51773
		],
		948: [
			0,
			.69444,
			.03785,
			.05556,
			.44444
		],
		949: [
			0,
			.43056,
			0,
			.08334,
			.46632
		],
		950: [
			.19444,
			.69444,
			.07378,
			.08334,
			.4375
		],
		951: [
			.19444,
			.43056,
			.03588,
			.05556,
			.49653
		],
		952: [
			0,
			.69444,
			.02778,
			.08334,
			.46944
		],
		953: [
			0,
			.43056,
			0,
			.05556,
			.35394
		],
		954: [
			0,
			.43056,
			0,
			0,
			.57616
		],
		955: [
			0,
			.69444,
			0,
			0,
			.58334
		],
		956: [
			.19444,
			.43056,
			0,
			.02778,
			.60255
		],
		957: [
			0,
			.43056,
			.06366,
			.02778,
			.49398
		],
		958: [
			.19444,
			.69444,
			.04601,
			.11111,
			.4375
		],
		959: [
			0,
			.43056,
			0,
			.05556,
			.48472
		],
		960: [
			0,
			.43056,
			.03588,
			0,
			.57003
		],
		961: [
			.19444,
			.43056,
			0,
			.08334,
			.51702
		],
		962: [
			.09722,
			.43056,
			.07986,
			.08334,
			.36285
		],
		963: [
			0,
			.43056,
			.03588,
			0,
			.57141
		],
		964: [
			0,
			.43056,
			.1132,
			.02778,
			.43715
		],
		965: [
			0,
			.43056,
			.03588,
			.02778,
			.54028
		],
		966: [
			.19444,
			.43056,
			0,
			.08334,
			.65417
		],
		967: [
			.19444,
			.43056,
			0,
			.05556,
			.62569
		],
		968: [
			.19444,
			.69444,
			.03588,
			.11111,
			.65139
		],
		969: [
			0,
			.43056,
			.03588,
			0,
			.62245
		],
		977: [
			0,
			.69444,
			0,
			.08334,
			.59144
		],
		981: [
			.19444,
			.69444,
			0,
			.08334,
			.59583
		],
		982: [
			0,
			.43056,
			.02778,
			0,
			.82813
		],
		1009: [
			.19444,
			.43056,
			0,
			.08334,
			.51702
		],
		1013: [
			0,
			.43056,
			0,
			.05556,
			.4059
		],
		57649: [
			0,
			.43056,
			0,
			.02778,
			.32246
		],
		57911: [
			.19444,
			.43056,
			0,
			.08334,
			.38403
		]
	},
	"SansSerif-Bold": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.36667
		],
		34: [
			0,
			.69444,
			0,
			0,
			.55834
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.91667
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.55
		],
		37: [
			.05556,
			.75,
			0,
			0,
			1.02912
		],
		38: [
			0,
			.69444,
			0,
			0,
			.83056
		],
		39: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		40: [
			.25,
			.75,
			0,
			0,
			.42778
		],
		41: [
			.25,
			.75,
			0,
			0,
			.42778
		],
		42: [
			0,
			.75,
			0,
			0,
			.55
		],
		43: [
			.11667,
			.61667,
			0,
			0,
			.85556
		],
		44: [
			.10556,
			.13056,
			0,
			0,
			.30556
		],
		45: [
			0,
			.45833,
			0,
			0,
			.36667
		],
		46: [
			0,
			.13056,
			0,
			0,
			.30556
		],
		47: [
			.25,
			.75,
			0,
			0,
			.55
		],
		48: [
			0,
			.69444,
			0,
			0,
			.55
		],
		49: [
			0,
			.69444,
			0,
			0,
			.55
		],
		50: [
			0,
			.69444,
			0,
			0,
			.55
		],
		51: [
			0,
			.69444,
			0,
			0,
			.55
		],
		52: [
			0,
			.69444,
			0,
			0,
			.55
		],
		53: [
			0,
			.69444,
			0,
			0,
			.55
		],
		54: [
			0,
			.69444,
			0,
			0,
			.55
		],
		55: [
			0,
			.69444,
			0,
			0,
			.55
		],
		56: [
			0,
			.69444,
			0,
			0,
			.55
		],
		57: [
			0,
			.69444,
			0,
			0,
			.55
		],
		58: [
			0,
			.45833,
			0,
			0,
			.30556
		],
		59: [
			.10556,
			.45833,
			0,
			0,
			.30556
		],
		61: [
			-.09375,
			.40625,
			0,
			0,
			.85556
		],
		63: [
			0,
			.69444,
			0,
			0,
			.51945
		],
		64: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		65: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		66: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		67: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		68: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		69: [
			0,
			.69444,
			0,
			0,
			.64167
		],
		70: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		71: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		72: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		73: [
			0,
			.69444,
			0,
			0,
			.33056
		],
		74: [
			0,
			.69444,
			0,
			0,
			.51945
		],
		75: [
			0,
			.69444,
			0,
			0,
			.76389
		],
		76: [
			0,
			.69444,
			0,
			0,
			.58056
		],
		77: [
			0,
			.69444,
			0,
			0,
			.97778
		],
		78: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		79: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		80: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		81: [
			.10556,
			.69444,
			0,
			0,
			.79445
		],
		82: [
			0,
			.69444,
			0,
			0,
			.70278
		],
		83: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		84: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		85: [
			0,
			.69444,
			0,
			0,
			.76389
		],
		86: [
			0,
			.69444,
			.01528,
			0,
			.73334
		],
		87: [
			0,
			.69444,
			.01528,
			0,
			1.03889
		],
		88: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		89: [
			0,
			.69444,
			.0275,
			0,
			.73334
		],
		90: [
			0,
			.69444,
			0,
			0,
			.67223
		],
		91: [
			.25,
			.75,
			0,
			0,
			.34306
		],
		93: [
			.25,
			.75,
			0,
			0,
			.34306
		],
		94: [
			0,
			.69444,
			0,
			0,
			.55
		],
		95: [
			.35,
			.10833,
			.03056,
			0,
			.55
		],
		97: [
			0,
			.45833,
			0,
			0,
			.525
		],
		98: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		99: [
			0,
			.45833,
			0,
			0,
			.48889
		],
		100: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		101: [
			0,
			.45833,
			0,
			0,
			.51111
		],
		102: [
			0,
			.69444,
			.07639,
			0,
			.33611
		],
		103: [
			.19444,
			.45833,
			.01528,
			0,
			.55
		],
		104: [
			0,
			.69444,
			0,
			0,
			.56111
		],
		105: [
			0,
			.69444,
			0,
			0,
			.25556
		],
		106: [
			.19444,
			.69444,
			0,
			0,
			.28611
		],
		107: [
			0,
			.69444,
			0,
			0,
			.53056
		],
		108: [
			0,
			.69444,
			0,
			0,
			.25556
		],
		109: [
			0,
			.45833,
			0,
			0,
			.86667
		],
		110: [
			0,
			.45833,
			0,
			0,
			.56111
		],
		111: [
			0,
			.45833,
			0,
			0,
			.55
		],
		112: [
			.19444,
			.45833,
			0,
			0,
			.56111
		],
		113: [
			.19444,
			.45833,
			0,
			0,
			.56111
		],
		114: [
			0,
			.45833,
			.01528,
			0,
			.37222
		],
		115: [
			0,
			.45833,
			0,
			0,
			.42167
		],
		116: [
			0,
			.58929,
			0,
			0,
			.40417
		],
		117: [
			0,
			.45833,
			0,
			0,
			.56111
		],
		118: [
			0,
			.45833,
			.01528,
			0,
			.5
		],
		119: [
			0,
			.45833,
			.01528,
			0,
			.74445
		],
		120: [
			0,
			.45833,
			0,
			0,
			.5
		],
		121: [
			.19444,
			.45833,
			.01528,
			0,
			.5
		],
		122: [
			0,
			.45833,
			0,
			0,
			.47639
		],
		126: [
			.35,
			.34444,
			0,
			0,
			.55
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.69444,
			0,
			0,
			.55
		],
		176: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		180: [
			0,
			.69444,
			0,
			0,
			.55
		],
		184: [
			.17014,
			0,
			0,
			0,
			.48889
		],
		305: [
			0,
			.45833,
			0,
			0,
			.25556
		],
		567: [
			.19444,
			.45833,
			0,
			0,
			.28611
		],
		710: [
			0,
			.69444,
			0,
			0,
			.55
		],
		711: [
			0,
			.63542,
			0,
			0,
			.55
		],
		713: [
			0,
			.63778,
			0,
			0,
			.55
		],
		728: [
			0,
			.69444,
			0,
			0,
			.55
		],
		729: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		730: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		732: [
			0,
			.69444,
			0,
			0,
			.55
		],
		733: [
			0,
			.69444,
			0,
			0,
			.55
		],
		915: [
			0,
			.69444,
			0,
			0,
			.58056
		],
		916: [
			0,
			.69444,
			0,
			0,
			.91667
		],
		920: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		923: [
			0,
			.69444,
			0,
			0,
			.67223
		],
		926: [
			0,
			.69444,
			0,
			0,
			.73334
		],
		928: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		931: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		933: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		934: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		936: [
			0,
			.69444,
			0,
			0,
			.85556
		],
		937: [
			0,
			.69444,
			0,
			0,
			.79445
		],
		8211: [
			0,
			.45833,
			.03056,
			0,
			.55
		],
		8212: [
			0,
			.45833,
			.03056,
			0,
			1.10001
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.30556
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.55834
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.55834
		]
	},
	"SansSerif-Italic": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			.05733,
			0,
			.31945
		],
		34: [
			0,
			.69444,
			.00316,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			.05087,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			.11156,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			.03126,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			.03058,
			0,
			.75834
		],
		39: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			.13164,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			.02536,
			0,
			.38889
		],
		42: [
			0,
			.75,
			.11775,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			.02536,
			0,
			.77778
		],
		44: [
			.125,
			.08333,
			0,
			0,
			.27778
		],
		45: [
			0,
			.44444,
			.01946,
			0,
			.33333
		],
		46: [
			0,
			.08333,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			.13164,
			0,
			.5
		],
		48: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		49: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		50: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		51: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		52: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		53: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		54: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		55: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		56: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		57: [
			0,
			.65556,
			.11156,
			0,
			.5
		],
		58: [
			0,
			.44444,
			.02502,
			0,
			.27778
		],
		59: [
			.125,
			.44444,
			.02502,
			0,
			.27778
		],
		61: [
			-.13,
			.37,
			.05087,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			.11809,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			.07555,
			0,
			.66667
		],
		65: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		66: [
			0,
			.69444,
			.08293,
			0,
			.66667
		],
		67: [
			0,
			.69444,
			.11983,
			0,
			.63889
		],
		68: [
			0,
			.69444,
			.07555,
			0,
			.72223
		],
		69: [
			0,
			.69444,
			.11983,
			0,
			.59722
		],
		70: [
			0,
			.69444,
			.13372,
			0,
			.56945
		],
		71: [
			0,
			.69444,
			.11983,
			0,
			.66667
		],
		72: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		73: [
			0,
			.69444,
			.13372,
			0,
			.27778
		],
		74: [
			0,
			.69444,
			.08094,
			0,
			.47222
		],
		75: [
			0,
			.69444,
			.11983,
			0,
			.69445
		],
		76: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		77: [
			0,
			.69444,
			.08094,
			0,
			.875
		],
		78: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		79: [
			0,
			.69444,
			.07555,
			0,
			.73611
		],
		80: [
			0,
			.69444,
			.08293,
			0,
			.63889
		],
		81: [
			.125,
			.69444,
			.07555,
			0,
			.73611
		],
		82: [
			0,
			.69444,
			.08293,
			0,
			.64584
		],
		83: [
			0,
			.69444,
			.09205,
			0,
			.55556
		],
		84: [
			0,
			.69444,
			.13372,
			0,
			.68056
		],
		85: [
			0,
			.69444,
			.08094,
			0,
			.6875
		],
		86: [
			0,
			.69444,
			.1615,
			0,
			.66667
		],
		87: [
			0,
			.69444,
			.1615,
			0,
			.94445
		],
		88: [
			0,
			.69444,
			.13372,
			0,
			.66667
		],
		89: [
			0,
			.69444,
			.17261,
			0,
			.66667
		],
		90: [
			0,
			.69444,
			.11983,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			.15942,
			0,
			.28889
		],
		93: [
			.25,
			.75,
			.08719,
			0,
			.28889
		],
		94: [
			0,
			.69444,
			.0799,
			0,
			.5
		],
		95: [
			.35,
			.09444,
			.08616,
			0,
			.5
		],
		97: [
			0,
			.44444,
			.00981,
			0,
			.48056
		],
		98: [
			0,
			.69444,
			.03057,
			0,
			.51667
		],
		99: [
			0,
			.44444,
			.08336,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			.09483,
			0,
			.51667
		],
		101: [
			0,
			.44444,
			.06778,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.21705,
			0,
			.30556
		],
		103: [
			.19444,
			.44444,
			.10836,
			0,
			.5
		],
		104: [
			0,
			.69444,
			.01778,
			0,
			.51667
		],
		105: [
			0,
			.67937,
			.09718,
			0,
			.23889
		],
		106: [
			.19444,
			.67937,
			.09162,
			0,
			.26667
		],
		107: [
			0,
			.69444,
			.08336,
			0,
			.48889
		],
		108: [
			0,
			.69444,
			.09483,
			0,
			.23889
		],
		109: [
			0,
			.44444,
			.01778,
			0,
			.79445
		],
		110: [
			0,
			.44444,
			.01778,
			0,
			.51667
		],
		111: [
			0,
			.44444,
			.06613,
			0,
			.5
		],
		112: [
			.19444,
			.44444,
			.0389,
			0,
			.51667
		],
		113: [
			.19444,
			.44444,
			.04169,
			0,
			.51667
		],
		114: [
			0,
			.44444,
			.10836,
			0,
			.34167
		],
		115: [
			0,
			.44444,
			.0778,
			0,
			.38333
		],
		116: [
			0,
			.57143,
			.07225,
			0,
			.36111
		],
		117: [
			0,
			.44444,
			.04169,
			0,
			.51667
		],
		118: [
			0,
			.44444,
			.10836,
			0,
			.46111
		],
		119: [
			0,
			.44444,
			.10836,
			0,
			.68334
		],
		120: [
			0,
			.44444,
			.09169,
			0,
			.46111
		],
		121: [
			.19444,
			.44444,
			.10836,
			0,
			.46111
		],
		122: [
			0,
			.44444,
			.08752,
			0,
			.43472
		],
		126: [
			.35,
			.32659,
			.08826,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.67937,
			.06385,
			0,
			.5
		],
		176: [
			0,
			.69444,
			0,
			0,
			.73752
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		305: [
			0,
			.44444,
			.04169,
			0,
			.23889
		],
		567: [
			.19444,
			.44444,
			.04169,
			0,
			.26667
		],
		710: [
			0,
			.69444,
			.0799,
			0,
			.5
		],
		711: [
			0,
			.63194,
			.08432,
			0,
			.5
		],
		713: [
			0,
			.60889,
			.08776,
			0,
			.5
		],
		714: [
			0,
			.69444,
			.09205,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			.09483,
			0,
			.5
		],
		729: [
			0,
			.67937,
			.07774,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.73752
		],
		732: [
			0,
			.67659,
			.08826,
			0,
			.5
		],
		733: [
			0,
			.69444,
			.09205,
			0,
			.5
		],
		915: [
			0,
			.69444,
			.13372,
			0,
			.54167
		],
		916: [
			0,
			.69444,
			0,
			0,
			.83334
		],
		920: [
			0,
			.69444,
			.07555,
			0,
			.77778
		],
		923: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		926: [
			0,
			.69444,
			.12816,
			0,
			.66667
		],
		928: [
			0,
			.69444,
			.08094,
			0,
			.70834
		],
		931: [
			0,
			.69444,
			.11983,
			0,
			.72222
		],
		933: [
			0,
			.69444,
			.09031,
			0,
			.77778
		],
		934: [
			0,
			.69444,
			.04603,
			0,
			.72222
		],
		936: [
			0,
			.69444,
			.09031,
			0,
			.77778
		],
		937: [
			0,
			.69444,
			.08293,
			0,
			.72222
		],
		8211: [
			0,
			.44444,
			.08616,
			0,
			.5
		],
		8212: [
			0,
			.44444,
			.08616,
			0,
			1
		],
		8216: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			.07816,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			.14205,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			.00316,
			0,
			.5
		]
	},
	"SansSerif-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		33: [
			0,
			.69444,
			0,
			0,
			.31945
		],
		34: [
			0,
			.69444,
			0,
			0,
			.5
		],
		35: [
			.19444,
			.69444,
			0,
			0,
			.83334
		],
		36: [
			.05556,
			.75,
			0,
			0,
			.5
		],
		37: [
			.05556,
			.75,
			0,
			0,
			.83334
		],
		38: [
			0,
			.69444,
			0,
			0,
			.75834
		],
		39: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		40: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		41: [
			.25,
			.75,
			0,
			0,
			.38889
		],
		42: [
			0,
			.75,
			0,
			0,
			.5
		],
		43: [
			.08333,
			.58333,
			0,
			0,
			.77778
		],
		44: [
			.125,
			.08333,
			0,
			0,
			.27778
		],
		45: [
			0,
			.44444,
			0,
			0,
			.33333
		],
		46: [
			0,
			.08333,
			0,
			0,
			.27778
		],
		47: [
			.25,
			.75,
			0,
			0,
			.5
		],
		48: [
			0,
			.65556,
			0,
			0,
			.5
		],
		49: [
			0,
			.65556,
			0,
			0,
			.5
		],
		50: [
			0,
			.65556,
			0,
			0,
			.5
		],
		51: [
			0,
			.65556,
			0,
			0,
			.5
		],
		52: [
			0,
			.65556,
			0,
			0,
			.5
		],
		53: [
			0,
			.65556,
			0,
			0,
			.5
		],
		54: [
			0,
			.65556,
			0,
			0,
			.5
		],
		55: [
			0,
			.65556,
			0,
			0,
			.5
		],
		56: [
			0,
			.65556,
			0,
			0,
			.5
		],
		57: [
			0,
			.65556,
			0,
			0,
			.5
		],
		58: [
			0,
			.44444,
			0,
			0,
			.27778
		],
		59: [
			.125,
			.44444,
			0,
			0,
			.27778
		],
		61: [
			-.13,
			.37,
			0,
			0,
			.77778
		],
		63: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		64: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		65: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		66: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		67: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		68: [
			0,
			.69444,
			0,
			0,
			.72223
		],
		69: [
			0,
			.69444,
			0,
			0,
			.59722
		],
		70: [
			0,
			.69444,
			0,
			0,
			.56945
		],
		71: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		72: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		73: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		74: [
			0,
			.69444,
			0,
			0,
			.47222
		],
		75: [
			0,
			.69444,
			0,
			0,
			.69445
		],
		76: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		77: [
			0,
			.69444,
			0,
			0,
			.875
		],
		78: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		79: [
			0,
			.69444,
			0,
			0,
			.73611
		],
		80: [
			0,
			.69444,
			0,
			0,
			.63889
		],
		81: [
			.125,
			.69444,
			0,
			0,
			.73611
		],
		82: [
			0,
			.69444,
			0,
			0,
			.64584
		],
		83: [
			0,
			.69444,
			0,
			0,
			.55556
		],
		84: [
			0,
			.69444,
			0,
			0,
			.68056
		],
		85: [
			0,
			.69444,
			0,
			0,
			.6875
		],
		86: [
			0,
			.69444,
			.01389,
			0,
			.66667
		],
		87: [
			0,
			.69444,
			.01389,
			0,
			.94445
		],
		88: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		89: [
			0,
			.69444,
			.025,
			0,
			.66667
		],
		90: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		91: [
			.25,
			.75,
			0,
			0,
			.28889
		],
		93: [
			.25,
			.75,
			0,
			0,
			.28889
		],
		94: [
			0,
			.69444,
			0,
			0,
			.5
		],
		95: [
			.35,
			.09444,
			.02778,
			0,
			.5
		],
		97: [
			0,
			.44444,
			0,
			0,
			.48056
		],
		98: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		99: [
			0,
			.44444,
			0,
			0,
			.44445
		],
		100: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		101: [
			0,
			.44444,
			0,
			0,
			.44445
		],
		102: [
			0,
			.69444,
			.06944,
			0,
			.30556
		],
		103: [
			.19444,
			.44444,
			.01389,
			0,
			.5
		],
		104: [
			0,
			.69444,
			0,
			0,
			.51667
		],
		105: [
			0,
			.67937,
			0,
			0,
			.23889
		],
		106: [
			.19444,
			.67937,
			0,
			0,
			.26667
		],
		107: [
			0,
			.69444,
			0,
			0,
			.48889
		],
		108: [
			0,
			.69444,
			0,
			0,
			.23889
		],
		109: [
			0,
			.44444,
			0,
			0,
			.79445
		],
		110: [
			0,
			.44444,
			0,
			0,
			.51667
		],
		111: [
			0,
			.44444,
			0,
			0,
			.5
		],
		112: [
			.19444,
			.44444,
			0,
			0,
			.51667
		],
		113: [
			.19444,
			.44444,
			0,
			0,
			.51667
		],
		114: [
			0,
			.44444,
			.01389,
			0,
			.34167
		],
		115: [
			0,
			.44444,
			0,
			0,
			.38333
		],
		116: [
			0,
			.57143,
			0,
			0,
			.36111
		],
		117: [
			0,
			.44444,
			0,
			0,
			.51667
		],
		118: [
			0,
			.44444,
			.01389,
			0,
			.46111
		],
		119: [
			0,
			.44444,
			.01389,
			0,
			.68334
		],
		120: [
			0,
			.44444,
			0,
			0,
			.46111
		],
		121: [
			.19444,
			.44444,
			.01389,
			0,
			.46111
		],
		122: [
			0,
			.44444,
			0,
			0,
			.43472
		],
		126: [
			.35,
			.32659,
			0,
			0,
			.5
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		168: [
			0,
			.67937,
			0,
			0,
			.5
		],
		176: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		184: [
			.17014,
			0,
			0,
			0,
			.44445
		],
		305: [
			0,
			.44444,
			0,
			0,
			.23889
		],
		567: [
			.19444,
			.44444,
			0,
			0,
			.26667
		],
		710: [
			0,
			.69444,
			0,
			0,
			.5
		],
		711: [
			0,
			.63194,
			0,
			0,
			.5
		],
		713: [
			0,
			.60889,
			0,
			0,
			.5
		],
		714: [
			0,
			.69444,
			0,
			0,
			.5
		],
		715: [
			0,
			.69444,
			0,
			0,
			.5
		],
		728: [
			0,
			.69444,
			0,
			0,
			.5
		],
		729: [
			0,
			.67937,
			0,
			0,
			.27778
		],
		730: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		732: [
			0,
			.67659,
			0,
			0,
			.5
		],
		733: [
			0,
			.69444,
			0,
			0,
			.5
		],
		915: [
			0,
			.69444,
			0,
			0,
			.54167
		],
		916: [
			0,
			.69444,
			0,
			0,
			.83334
		],
		920: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		923: [
			0,
			.69444,
			0,
			0,
			.61111
		],
		926: [
			0,
			.69444,
			0,
			0,
			.66667
		],
		928: [
			0,
			.69444,
			0,
			0,
			.70834
		],
		931: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		933: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		934: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		936: [
			0,
			.69444,
			0,
			0,
			.77778
		],
		937: [
			0,
			.69444,
			0,
			0,
			.72222
		],
		8211: [
			0,
			.44444,
			.02778,
			0,
			.5
		],
		8212: [
			0,
			.44444,
			.02778,
			0,
			1
		],
		8216: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8217: [
			0,
			.69444,
			0,
			0,
			.27778
		],
		8220: [
			0,
			.69444,
			0,
			0,
			.5
		],
		8221: [
			0,
			.69444,
			0,
			0,
			.5
		]
	},
	"Script-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		65: [
			0,
			.7,
			.22925,
			0,
			.80253
		],
		66: [
			0,
			.7,
			.04087,
			0,
			.90757
		],
		67: [
			0,
			.7,
			.1689,
			0,
			.66619
		],
		68: [
			0,
			.7,
			.09371,
			0,
			.77443
		],
		69: [
			0,
			.7,
			.18583,
			0,
			.56162
		],
		70: [
			0,
			.7,
			.13634,
			0,
			.89544
		],
		71: [
			0,
			.7,
			.17322,
			0,
			.60961
		],
		72: [
			0,
			.7,
			.29694,
			0,
			.96919
		],
		73: [
			0,
			.7,
			.19189,
			0,
			.80907
		],
		74: [
			.27778,
			.7,
			.19189,
			0,
			1.05159
		],
		75: [
			0,
			.7,
			.31259,
			0,
			.91364
		],
		76: [
			0,
			.7,
			.19189,
			0,
			.87373
		],
		77: [
			0,
			.7,
			.15981,
			0,
			1.08031
		],
		78: [
			0,
			.7,
			.3525,
			0,
			.9015
		],
		79: [
			0,
			.7,
			.08078,
			0,
			.73787
		],
		80: [
			0,
			.7,
			.08078,
			0,
			1.01262
		],
		81: [
			0,
			.7,
			.03305,
			0,
			.88282
		],
		82: [
			0,
			.7,
			.06259,
			0,
			.85
		],
		83: [
			0,
			.7,
			.19189,
			0,
			.86767
		],
		84: [
			0,
			.7,
			.29087,
			0,
			.74697
		],
		85: [
			0,
			.7,
			.25815,
			0,
			.79996
		],
		86: [
			0,
			.7,
			.27523,
			0,
			.62204
		],
		87: [
			0,
			.7,
			.27523,
			0,
			.80532
		],
		88: [
			0,
			.7,
			.26006,
			0,
			.94445
		],
		89: [
			0,
			.7,
			.2939,
			0,
			.70961
		],
		90: [
			0,
			.7,
			.24037,
			0,
			.8212
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		]
	},
	"Size1-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.35001,
			.85,
			0,
			0,
			.45834
		],
		41: [
			.35001,
			.85,
			0,
			0,
			.45834
		],
		47: [
			.35001,
			.85,
			0,
			0,
			.57778
		],
		91: [
			.35001,
			.85,
			0,
			0,
			.41667
		],
		92: [
			.35001,
			.85,
			0,
			0,
			.57778
		],
		93: [
			.35001,
			.85,
			0,
			0,
			.41667
		],
		123: [
			.35001,
			.85,
			0,
			0,
			.58334
		],
		125: [
			.35001,
			.85,
			0,
			0,
			.58334
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		732: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		770: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		771: [
			0,
			.72222,
			0,
			0,
			.55556
		],
		8214: [
			-99e-5,
			.601,
			0,
			0,
			.77778
		],
		8593: [
			1e-5,
			.6,
			0,
			0,
			.66667
		],
		8595: [
			1e-5,
			.6,
			0,
			0,
			.66667
		],
		8657: [
			1e-5,
			.6,
			0,
			0,
			.77778
		],
		8659: [
			1e-5,
			.6,
			0,
			0,
			.77778
		],
		8719: [
			.25001,
			.75,
			0,
			0,
			.94445
		],
		8720: [
			.25001,
			.75,
			0,
			0,
			.94445
		],
		8721: [
			.25001,
			.75,
			0,
			0,
			1.05556
		],
		8730: [
			.35001,
			.85,
			0,
			0,
			1
		],
		8739: [
			-.00599,
			.606,
			0,
			0,
			.33333
		],
		8741: [
			-.00599,
			.606,
			0,
			0,
			.55556
		],
		8747: [
			.30612,
			.805,
			.19445,
			0,
			.47222
		],
		8748: [
			.306,
			.805,
			.19445,
			0,
			.47222
		],
		8749: [
			.306,
			.805,
			.19445,
			0,
			.47222
		],
		8750: [
			.30612,
			.805,
			.19445,
			0,
			.47222
		],
		8896: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8897: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8898: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8899: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		8968: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8969: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8970: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		8971: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		9168: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		10216: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		10217: [
			.35001,
			.85,
			0,
			0,
			.47222
		],
		10752: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10753: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10754: [
			.25001,
			.75,
			0,
			0,
			1.11111
		],
		10756: [
			.25001,
			.75,
			0,
			0,
			.83334
		],
		10758: [
			.25001,
			.75,
			0,
			0,
			.83334
		]
	},
	"Size2-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.65002,
			1.15,
			0,
			0,
			.59722
		],
		41: [
			.65002,
			1.15,
			0,
			0,
			.59722
		],
		47: [
			.65002,
			1.15,
			0,
			0,
			.81111
		],
		91: [
			.65002,
			1.15,
			0,
			0,
			.47222
		],
		92: [
			.65002,
			1.15,
			0,
			0,
			.81111
		],
		93: [
			.65002,
			1.15,
			0,
			0,
			.47222
		],
		123: [
			.65002,
			1.15,
			0,
			0,
			.66667
		],
		125: [
			.65002,
			1.15,
			0,
			0,
			.66667
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.75,
			0,
			0,
			1
		],
		732: [
			0,
			.75,
			0,
			0,
			1
		],
		770: [
			0,
			.75,
			0,
			0,
			1
		],
		771: [
			0,
			.75,
			0,
			0,
			1
		],
		8719: [
			.55001,
			1.05,
			0,
			0,
			1.27778
		],
		8720: [
			.55001,
			1.05,
			0,
			0,
			1.27778
		],
		8721: [
			.55001,
			1.05,
			0,
			0,
			1.44445
		],
		8730: [
			.65002,
			1.15,
			0,
			0,
			1
		],
		8747: [
			.86225,
			1.36,
			.44445,
			0,
			.55556
		],
		8748: [
			.862,
			1.36,
			.44445,
			0,
			.55556
		],
		8749: [
			.862,
			1.36,
			.44445,
			0,
			.55556
		],
		8750: [
			.86225,
			1.36,
			.44445,
			0,
			.55556
		],
		8896: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8897: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8898: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8899: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		8968: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8969: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8970: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		8971: [
			.65002,
			1.15,
			0,
			0,
			.52778
		],
		10216: [
			.65002,
			1.15,
			0,
			0,
			.61111
		],
		10217: [
			.65002,
			1.15,
			0,
			0,
			.61111
		],
		10752: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10753: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10754: [
			.55001,
			1.05,
			0,
			0,
			1.51112
		],
		10756: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		],
		10758: [
			.55001,
			1.05,
			0,
			0,
			1.11111
		]
	},
	"Size3-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			.95003,
			1.45,
			0,
			0,
			.73611
		],
		41: [
			.95003,
			1.45,
			0,
			0,
			.73611
		],
		47: [
			.95003,
			1.45,
			0,
			0,
			1.04445
		],
		91: [
			.95003,
			1.45,
			0,
			0,
			.52778
		],
		92: [
			.95003,
			1.45,
			0,
			0,
			1.04445
		],
		93: [
			.95003,
			1.45,
			0,
			0,
			.52778
		],
		123: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		125: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		732: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		770: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		771: [
			0,
			.75,
			0,
			0,
			1.44445
		],
		8730: [
			.95003,
			1.45,
			0,
			0,
			1
		],
		8968: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8969: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8970: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		8971: [
			.95003,
			1.45,
			0,
			0,
			.58334
		],
		10216: [
			.95003,
			1.45,
			0,
			0,
			.75
		],
		10217: [
			.95003,
			1.45,
			0,
			0,
			.75
		]
	},
	"Size4-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.25
		],
		40: [
			1.25003,
			1.75,
			0,
			0,
			.79167
		],
		41: [
			1.25003,
			1.75,
			0,
			0,
			.79167
		],
		47: [
			1.25003,
			1.75,
			0,
			0,
			1.27778
		],
		91: [
			1.25003,
			1.75,
			0,
			0,
			.58334
		],
		92: [
			1.25003,
			1.75,
			0,
			0,
			1.27778
		],
		93: [
			1.25003,
			1.75,
			0,
			0,
			.58334
		],
		123: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		125: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		160: [
			0,
			0,
			0,
			0,
			.25
		],
		710: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		732: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		770: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		771: [
			0,
			.825,
			0,
			0,
			1.8889
		],
		8730: [
			1.25003,
			1.75,
			0,
			0,
			1
		],
		8968: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8969: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8970: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		8971: [
			1.25003,
			1.75,
			0,
			0,
			.63889
		],
		9115: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9116: [
			1e-5,
			.6,
			0,
			0,
			.875
		],
		9117: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9118: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9119: [
			1e-5,
			.6,
			0,
			0,
			.875
		],
		9120: [
			.64502,
			1.155,
			0,
			0,
			.875
		],
		9121: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9122: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		9123: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9124: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9125: [
			-99e-5,
			.601,
			0,
			0,
			.66667
		],
		9126: [
			.64502,
			1.155,
			0,
			0,
			.66667
		],
		9127: [
			1e-5,
			.9,
			0,
			0,
			.88889
		],
		9128: [
			.65002,
			1.15,
			0,
			0,
			.88889
		],
		9129: [
			.90001,
			0,
			0,
			0,
			.88889
		],
		9130: [
			0,
			.3,
			0,
			0,
			.88889
		],
		9131: [
			1e-5,
			.9,
			0,
			0,
			.88889
		],
		9132: [
			.65002,
			1.15,
			0,
			0,
			.88889
		],
		9133: [
			.90001,
			0,
			0,
			0,
			.88889
		],
		9143: [
			.88502,
			.915,
			0,
			0,
			1.05556
		],
		10216: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		10217: [
			1.25003,
			1.75,
			0,
			0,
			.80556
		],
		57344: [
			-.00499,
			.605,
			0,
			0,
			1.05556
		],
		57345: [
			-.00499,
			.605,
			0,
			0,
			1.05556
		],
		57680: [
			0,
			.12,
			0,
			0,
			.45
		],
		57681: [
			0,
			.12,
			0,
			0,
			.45
		],
		57682: [
			0,
			.12,
			0,
			0,
			.45
		],
		57683: [
			0,
			.12,
			0,
			0,
			.45
		]
	},
	"Typewriter-Regular": {
		32: [
			0,
			0,
			0,
			0,
			.525
		],
		33: [
			0,
			.61111,
			0,
			0,
			.525
		],
		34: [
			0,
			.61111,
			0,
			0,
			.525
		],
		35: [
			0,
			.61111,
			0,
			0,
			.525
		],
		36: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		37: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		38: [
			0,
			.61111,
			0,
			0,
			.525
		],
		39: [
			0,
			.61111,
			0,
			0,
			.525
		],
		40: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		41: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		42: [
			0,
			.52083,
			0,
			0,
			.525
		],
		43: [
			-.08056,
			.53055,
			0,
			0,
			.525
		],
		44: [
			.13889,
			.125,
			0,
			0,
			.525
		],
		45: [
			-.08056,
			.53055,
			0,
			0,
			.525
		],
		46: [
			0,
			.125,
			0,
			0,
			.525
		],
		47: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		48: [
			0,
			.61111,
			0,
			0,
			.525
		],
		49: [
			0,
			.61111,
			0,
			0,
			.525
		],
		50: [
			0,
			.61111,
			0,
			0,
			.525
		],
		51: [
			0,
			.61111,
			0,
			0,
			.525
		],
		52: [
			0,
			.61111,
			0,
			0,
			.525
		],
		53: [
			0,
			.61111,
			0,
			0,
			.525
		],
		54: [
			0,
			.61111,
			0,
			0,
			.525
		],
		55: [
			0,
			.61111,
			0,
			0,
			.525
		],
		56: [
			0,
			.61111,
			0,
			0,
			.525
		],
		57: [
			0,
			.61111,
			0,
			0,
			.525
		],
		58: [
			0,
			.43056,
			0,
			0,
			.525
		],
		59: [
			.13889,
			.43056,
			0,
			0,
			.525
		],
		60: [
			-.05556,
			.55556,
			0,
			0,
			.525
		],
		61: [
			-.19549,
			.41562,
			0,
			0,
			.525
		],
		62: [
			-.05556,
			.55556,
			0,
			0,
			.525
		],
		63: [
			0,
			.61111,
			0,
			0,
			.525
		],
		64: [
			0,
			.61111,
			0,
			0,
			.525
		],
		65: [
			0,
			.61111,
			0,
			0,
			.525
		],
		66: [
			0,
			.61111,
			0,
			0,
			.525
		],
		67: [
			0,
			.61111,
			0,
			0,
			.525
		],
		68: [
			0,
			.61111,
			0,
			0,
			.525
		],
		69: [
			0,
			.61111,
			0,
			0,
			.525
		],
		70: [
			0,
			.61111,
			0,
			0,
			.525
		],
		71: [
			0,
			.61111,
			0,
			0,
			.525
		],
		72: [
			0,
			.61111,
			0,
			0,
			.525
		],
		73: [
			0,
			.61111,
			0,
			0,
			.525
		],
		74: [
			0,
			.61111,
			0,
			0,
			.525
		],
		75: [
			0,
			.61111,
			0,
			0,
			.525
		],
		76: [
			0,
			.61111,
			0,
			0,
			.525
		],
		77: [
			0,
			.61111,
			0,
			0,
			.525
		],
		78: [
			0,
			.61111,
			0,
			0,
			.525
		],
		79: [
			0,
			.61111,
			0,
			0,
			.525
		],
		80: [
			0,
			.61111,
			0,
			0,
			.525
		],
		81: [
			.13889,
			.61111,
			0,
			0,
			.525
		],
		82: [
			0,
			.61111,
			0,
			0,
			.525
		],
		83: [
			0,
			.61111,
			0,
			0,
			.525
		],
		84: [
			0,
			.61111,
			0,
			0,
			.525
		],
		85: [
			0,
			.61111,
			0,
			0,
			.525
		],
		86: [
			0,
			.61111,
			0,
			0,
			.525
		],
		87: [
			0,
			.61111,
			0,
			0,
			.525
		],
		88: [
			0,
			.61111,
			0,
			0,
			.525
		],
		89: [
			0,
			.61111,
			0,
			0,
			.525
		],
		90: [
			0,
			.61111,
			0,
			0,
			.525
		],
		91: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		92: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		93: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		94: [
			0,
			.61111,
			0,
			0,
			.525
		],
		95: [
			.09514,
			0,
			0,
			0,
			.525
		],
		96: [
			0,
			.61111,
			0,
			0,
			.525
		],
		97: [
			0,
			.43056,
			0,
			0,
			.525
		],
		98: [
			0,
			.61111,
			0,
			0,
			.525
		],
		99: [
			0,
			.43056,
			0,
			0,
			.525
		],
		100: [
			0,
			.61111,
			0,
			0,
			.525
		],
		101: [
			0,
			.43056,
			0,
			0,
			.525
		],
		102: [
			0,
			.61111,
			0,
			0,
			.525
		],
		103: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		104: [
			0,
			.61111,
			0,
			0,
			.525
		],
		105: [
			0,
			.61111,
			0,
			0,
			.525
		],
		106: [
			.22222,
			.61111,
			0,
			0,
			.525
		],
		107: [
			0,
			.61111,
			0,
			0,
			.525
		],
		108: [
			0,
			.61111,
			0,
			0,
			.525
		],
		109: [
			0,
			.43056,
			0,
			0,
			.525
		],
		110: [
			0,
			.43056,
			0,
			0,
			.525
		],
		111: [
			0,
			.43056,
			0,
			0,
			.525
		],
		112: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		113: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		114: [
			0,
			.43056,
			0,
			0,
			.525
		],
		115: [
			0,
			.43056,
			0,
			0,
			.525
		],
		116: [
			0,
			.55358,
			0,
			0,
			.525
		],
		117: [
			0,
			.43056,
			0,
			0,
			.525
		],
		118: [
			0,
			.43056,
			0,
			0,
			.525
		],
		119: [
			0,
			.43056,
			0,
			0,
			.525
		],
		120: [
			0,
			.43056,
			0,
			0,
			.525
		],
		121: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		122: [
			0,
			.43056,
			0,
			0,
			.525
		],
		123: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		124: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		125: [
			.08333,
			.69444,
			0,
			0,
			.525
		],
		126: [
			0,
			.61111,
			0,
			0,
			.525
		],
		127: [
			0,
			.61111,
			0,
			0,
			.525
		],
		160: [
			0,
			0,
			0,
			0,
			.525
		],
		176: [
			0,
			.61111,
			0,
			0,
			.525
		],
		184: [
			.19445,
			0,
			0,
			0,
			.525
		],
		305: [
			0,
			.43056,
			0,
			0,
			.525
		],
		567: [
			.22222,
			.43056,
			0,
			0,
			.525
		],
		711: [
			0,
			.56597,
			0,
			0,
			.525
		],
		713: [
			0,
			.56555,
			0,
			0,
			.525
		],
		714: [
			0,
			.61111,
			0,
			0,
			.525
		],
		715: [
			0,
			.61111,
			0,
			0,
			.525
		],
		728: [
			0,
			.61111,
			0,
			0,
			.525
		],
		730: [
			0,
			.61111,
			0,
			0,
			.525
		],
		770: [
			0,
			.61111,
			0,
			0,
			.525
		],
		771: [
			0,
			.61111,
			0,
			0,
			.525
		],
		776: [
			0,
			.61111,
			0,
			0,
			.525
		],
		915: [
			0,
			.61111,
			0,
			0,
			.525
		],
		916: [
			0,
			.61111,
			0,
			0,
			.525
		],
		920: [
			0,
			.61111,
			0,
			0,
			.525
		],
		923: [
			0,
			.61111,
			0,
			0,
			.525
		],
		926: [
			0,
			.61111,
			0,
			0,
			.525
		],
		928: [
			0,
			.61111,
			0,
			0,
			.525
		],
		931: [
			0,
			.61111,
			0,
			0,
			.525
		],
		933: [
			0,
			.61111,
			0,
			0,
			.525
		],
		934: [
			0,
			.61111,
			0,
			0,
			.525
		],
		936: [
			0,
			.61111,
			0,
			0,
			.525
		],
		937: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8216: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8217: [
			0,
			.61111,
			0,
			0,
			.525
		],
		8242: [
			0,
			.61111,
			0,
			0,
			.525
		],
		9251: [
			.11111,
			.21944,
			0,
			0,
			.525
		]
	}
}, Ke = {
	slant: [
		.25,
		.25,
		.25
	],
	space: [
		0,
		0,
		0
	],
	stretch: [
		0,
		0,
		0
	],
	shrink: [
		0,
		0,
		0
	],
	xHeight: [
		.431,
		.431,
		.431
	],
	quad: [
		1,
		1.171,
		1.472
	],
	extraSpace: [
		0,
		0,
		0
	],
	num1: [
		.677,
		.732,
		.925
	],
	num2: [
		.394,
		.384,
		.387
	],
	num3: [
		.444,
		.471,
		.504
	],
	denom1: [
		.686,
		.752,
		1.025
	],
	denom2: [
		.345,
		.344,
		.532
	],
	sup1: [
		.413,
		.503,
		.504
	],
	sup2: [
		.363,
		.431,
		.404
	],
	sup3: [
		.289,
		.286,
		.294
	],
	sub1: [
		.15,
		.143,
		.2
	],
	sub2: [
		.247,
		.286,
		.4
	],
	supDrop: [
		.386,
		.353,
		.494
	],
	subDrop: [
		.05,
		.071,
		.1
	],
	delim1: [
		2.39,
		1.7,
		1.98
	],
	delim2: [
		1.01,
		1.157,
		1.42
	],
	axisHeight: [
		.25,
		.25,
		.25
	],
	defaultRuleThickness: [
		.04,
		.049,
		.049
	],
	bigOpSpacing1: [
		.111,
		.111,
		.111
	],
	bigOpSpacing2: [
		.166,
		.166,
		.166
	],
	bigOpSpacing3: [
		.2,
		.2,
		.2
	],
	bigOpSpacing4: [
		.6,
		.611,
		.611
	],
	bigOpSpacing5: [
		.1,
		.143,
		.143
	],
	sqrtRuleThickness: [
		.04,
		.04,
		.04
	],
	ptPerEm: [
		10,
		10,
		10
	],
	doubleRuleSep: [
		.2,
		.2,
		.2
	],
	arrayRuleWidth: [
		.04,
		.04,
		.04
	],
	fboxsep: [
		.3,
		.3,
		.3
	],
	fboxrule: [
		.04,
		.04,
		.04
	]
}, qe = {
	Å: "A",
	Ð: "D",
	Þ: "o",
	å: "a",
	ð: "d",
	þ: "o",
	А: "A",
	Б: "B",
	В: "B",
	Г: "F",
	Д: "A",
	Е: "E",
	Ж: "K",
	З: "3",
	И: "N",
	Й: "N",
	К: "K",
	Л: "N",
	М: "M",
	Н: "H",
	О: "O",
	П: "N",
	Р: "P",
	С: "C",
	Т: "T",
	У: "y",
	Ф: "O",
	Х: "X",
	Ц: "U",
	Ч: "h",
	Ш: "W",
	Щ: "W",
	Ъ: "B",
	Ы: "X",
	Ь: "B",
	Э: "3",
	Ю: "X",
	Я: "R",
	а: "a",
	б: "b",
	в: "a",
	г: "r",
	д: "y",
	е: "e",
	ж: "m",
	з: "e",
	и: "n",
	й: "n",
	к: "n",
	л: "n",
	м: "m",
	н: "n",
	о: "o",
	п: "n",
	р: "p",
	с: "c",
	т: "o",
	у: "y",
	ф: "b",
	х: "x",
	ц: "n",
	ч: "n",
	ш: "w",
	щ: "w",
	ъ: "a",
	ы: "m",
	ь: "a",
	э: "e",
	ю: "m",
	я: "r"
};
function Je(e, t) {
	Ge[e] = t;
}
function Ye(e, t, n) {
	if (!Ge[t]) throw Error("Font metrics not found for font: " + t + ".");
	var r = e.charCodeAt(0), i = Ge[t][r];
	if (!i && e[0] in qe && (r = qe[e[0]].charCodeAt(0), i = Ge[t][r]), !i && n === "text" && ue(r) && (i = Ge[t][77]), i) return {
		depth: i[0],
		height: i[1],
		italic: i[2],
		skew: i[3],
		width: i[4]
	};
}
var Xe = {};
function Ze(e) {
	var t = e >= 5 ? 0 : e >= 3 ? 1 : 2;
	if (!Xe[t]) {
		var n = Xe[t] = { cssEmPerMu: Ke.quad[t] / 18 };
		for (var r of Object.keys(Ke)) n[r] = Ke[r][t];
	}
	return Xe[t];
}
var k = {
	math: {},
	text: {}
};
function A(e, t, n, r, i, a) {
	k[e][i] = {
		font: t,
		group: n,
		replace: r
	}, a && r && (k[e][r] = k[e][i]);
}
var j = "math", M = "text", N = "main", P = "ams", F = "accent-token", I = "bin", Qe = "close", $e = "inner", L = "mathord", R = "op-token", et = "open", tt = "punct", z = "rel", nt = "spacing", B = "textord";
A(j, N, z, "≡", "\\equiv", !0), A(j, N, z, "≺", "\\prec", !0), A(j, N, z, "≻", "\\succ", !0), A(j, N, z, "∼", "\\sim", !0), A(j, N, z, "⊥", "\\perp"), A(j, N, z, "⪯", "\\preceq", !0), A(j, N, z, "⪰", "\\succeq", !0), A(j, N, z, "≃", "\\simeq", !0), A(j, N, z, "∣", "\\mid", !0), A(j, N, z, "≪", "\\ll", !0), A(j, N, z, "≫", "\\gg", !0), A(j, N, z, "≍", "\\asymp", !0), A(j, N, z, "∥", "\\parallel"), A(j, N, z, "⋈", "\\bowtie", !0), A(j, N, z, "⌣", "\\smile", !0), A(j, N, z, "⊑", "\\sqsubseteq", !0), A(j, N, z, "⊒", "\\sqsupseteq", !0), A(j, N, z, "≐", "\\doteq", !0), A(j, N, z, "⌢", "\\frown", !0), A(j, N, z, "∋", "\\ni", !0), A(j, N, z, "∝", "\\propto", !0), A(j, N, z, "⊢", "\\vdash", !0), A(j, N, z, "⊣", "\\dashv", !0), A(j, N, z, "∋", "\\owns"), A(j, N, tt, ".", "\\ldotp"), A(j, N, tt, "⋅", "\\cdotp"), A(j, N, tt, "⋅", "·"), A(M, N, B, "⋅", "·"), A(j, N, B, "#", "\\#"), A(M, N, B, "#", "\\#"), A(j, N, B, "&", "\\&"), A(M, N, B, "&", "\\&"), A(j, N, B, "ℵ", "\\aleph", !0), A(j, N, B, "∀", "\\forall", !0), A(j, N, B, "ℏ", "\\hbar", !0), A(j, N, B, "∃", "\\exists", !0), A(j, N, B, "∇", "\\nabla", !0), A(j, N, B, "♭", "\\flat", !0), A(j, N, B, "ℓ", "\\ell", !0), A(j, N, B, "♮", "\\natural", !0), A(j, N, B, "♣", "\\clubsuit", !0), A(j, N, B, "℘", "\\wp", !0), A(j, N, B, "♯", "\\sharp", !0), A(j, N, B, "♢", "\\diamondsuit", !0), A(j, N, B, "ℜ", "\\Re", !0), A(j, N, B, "♡", "\\heartsuit", !0), A(j, N, B, "ℑ", "\\Im", !0), A(j, N, B, "♠", "\\spadesuit", !0), A(j, N, B, "§", "\\S", !0), A(M, N, B, "§", "\\S"), A(j, N, B, "¶", "\\P", !0), A(M, N, B, "¶", "\\P"), A(j, N, B, "†", "\\dag"), A(M, N, B, "†", "\\dag"), A(M, N, B, "†", "\\textdagger"), A(j, N, B, "‡", "\\ddag"), A(M, N, B, "‡", "\\ddag"), A(M, N, B, "‡", "\\textdaggerdbl"), A(j, N, Qe, "⎱", "\\rmoustache", !0), A(j, N, et, "⎰", "\\lmoustache", !0), A(j, N, Qe, "⟯", "\\rgroup", !0), A(j, N, et, "⟮", "\\lgroup", !0), A(j, N, I, "∓", "\\mp", !0), A(j, N, I, "⊖", "\\ominus", !0), A(j, N, I, "⊎", "\\uplus", !0), A(j, N, I, "⊓", "\\sqcap", !0), A(j, N, I, "∗", "\\ast"), A(j, N, I, "⊔", "\\sqcup", !0), A(j, N, I, "◯", "\\bigcirc", !0), A(j, N, I, "∙", "\\bullet", !0), A(j, N, I, "‡", "\\ddagger"), A(j, N, I, "≀", "\\wr", !0), A(j, N, I, "⨿", "\\amalg"), A(j, N, I, "&", "\\And"), A(j, N, z, "⟵", "\\longleftarrow", !0), A(j, N, z, "⇐", "\\Leftarrow", !0), A(j, N, z, "⟸", "\\Longleftarrow", !0), A(j, N, z, "⟶", "\\longrightarrow", !0), A(j, N, z, "⇒", "\\Rightarrow", !0), A(j, N, z, "⟹", "\\Longrightarrow", !0), A(j, N, z, "↔", "\\leftrightarrow", !0), A(j, N, z, "⟷", "\\longleftrightarrow", !0), A(j, N, z, "⇔", "\\Leftrightarrow", !0), A(j, N, z, "⟺", "\\Longleftrightarrow", !0), A(j, N, z, "↦", "\\mapsto", !0), A(j, N, z, "⟼", "\\longmapsto", !0), A(j, N, z, "↗", "\\nearrow", !0), A(j, N, z, "↩", "\\hookleftarrow", !0), A(j, N, z, "↪", "\\hookrightarrow", !0), A(j, N, z, "↘", "\\searrow", !0), A(j, N, z, "↼", "\\leftharpoonup", !0), A(j, N, z, "⇀", "\\rightharpoonup", !0), A(j, N, z, "↙", "\\swarrow", !0), A(j, N, z, "↽", "\\leftharpoondown", !0), A(j, N, z, "⇁", "\\rightharpoondown", !0), A(j, N, z, "↖", "\\nwarrow", !0), A(j, N, z, "⇌", "\\rightleftharpoons", !0), A(j, P, z, "≮", "\\nless", !0), A(j, P, z, "", "\\@nleqslant"), A(j, P, z, "", "\\@nleqq"), A(j, P, z, "⪇", "\\lneq", !0), A(j, P, z, "≨", "\\lneqq", !0), A(j, P, z, "", "\\@lvertneqq"), A(j, P, z, "⋦", "\\lnsim", !0), A(j, P, z, "⪉", "\\lnapprox", !0), A(j, P, z, "⊀", "\\nprec", !0), A(j, P, z, "⋠", "\\npreceq", !0), A(j, P, z, "⋨", "\\precnsim", !0), A(j, P, z, "⪹", "\\precnapprox", !0), A(j, P, z, "≁", "\\nsim", !0), A(j, P, z, "", "\\@nshortmid"), A(j, P, z, "∤", "\\nmid", !0), A(j, P, z, "⊬", "\\nvdash", !0), A(j, P, z, "⊭", "\\nvDash", !0), A(j, P, z, "⋪", "\\ntriangleleft"), A(j, P, z, "⋬", "\\ntrianglelefteq", !0), A(j, P, z, "⊊", "\\subsetneq", !0), A(j, P, z, "", "\\@varsubsetneq"), A(j, P, z, "⫋", "\\subsetneqq", !0), A(j, P, z, "", "\\@varsubsetneqq"), A(j, P, z, "≯", "\\ngtr", !0), A(j, P, z, "", "\\@ngeqslant"), A(j, P, z, "", "\\@ngeqq"), A(j, P, z, "⪈", "\\gneq", !0), A(j, P, z, "≩", "\\gneqq", !0), A(j, P, z, "", "\\@gvertneqq"), A(j, P, z, "⋧", "\\gnsim", !0), A(j, P, z, "⪊", "\\gnapprox", !0), A(j, P, z, "⊁", "\\nsucc", !0), A(j, P, z, "⋡", "\\nsucceq", !0), A(j, P, z, "⋩", "\\succnsim", !0), A(j, P, z, "⪺", "\\succnapprox", !0), A(j, P, z, "≆", "\\ncong", !0), A(j, P, z, "", "\\@nshortparallel"), A(j, P, z, "∦", "\\nparallel", !0), A(j, P, z, "⊯", "\\nVDash", !0), A(j, P, z, "⋫", "\\ntriangleright"), A(j, P, z, "⋭", "\\ntrianglerighteq", !0), A(j, P, z, "", "\\@nsupseteqq"), A(j, P, z, "⊋", "\\supsetneq", !0), A(j, P, z, "", "\\@varsupsetneq"), A(j, P, z, "⫌", "\\supsetneqq", !0), A(j, P, z, "", "\\@varsupsetneqq"), A(j, P, z, "⊮", "\\nVdash", !0), A(j, P, z, "⪵", "\\precneqq", !0), A(j, P, z, "⪶", "\\succneqq", !0), A(j, P, z, "", "\\@nsubseteqq"), A(j, P, I, "⊴", "\\unlhd"), A(j, P, I, "⊵", "\\unrhd"), A(j, P, z, "↚", "\\nleftarrow", !0), A(j, P, z, "↛", "\\nrightarrow", !0), A(j, P, z, "⇍", "\\nLeftarrow", !0), A(j, P, z, "⇏", "\\nRightarrow", !0), A(j, P, z, "↮", "\\nleftrightarrow", !0), A(j, P, z, "⇎", "\\nLeftrightarrow", !0), A(j, P, z, "△", "\\vartriangle"), A(j, P, B, "ℏ", "\\hslash"), A(j, P, B, "▽", "\\triangledown"), A(j, P, B, "◊", "\\lozenge"), A(j, P, B, "Ⓢ", "\\circledS"), A(j, P, B, "®", "\\circledR"), A(M, P, B, "®", "\\circledR"), A(j, P, B, "∡", "\\measuredangle", !0), A(j, P, B, "∄", "\\nexists"), A(j, P, B, "℧", "\\mho"), A(j, P, B, "Ⅎ", "\\Finv", !0), A(j, P, B, "⅁", "\\Game", !0), A(j, P, B, "‵", "\\backprime"), A(j, P, B, "▲", "\\blacktriangle"), A(j, P, B, "▼", "\\blacktriangledown"), A(j, P, B, "■", "\\blacksquare"), A(j, P, B, "⧫", "\\blacklozenge"), A(j, P, B, "★", "\\bigstar"), A(j, P, B, "∢", "\\sphericalangle", !0), A(j, P, B, "∁", "\\complement", !0), A(j, P, B, "ð", "\\eth", !0), A(M, N, B, "ð", "ð"), A(j, P, B, "╱", "\\diagup"), A(j, P, B, "╲", "\\diagdown"), A(j, P, B, "□", "\\square"), A(j, P, B, "□", "\\Box"), A(j, P, B, "◊", "\\Diamond"), A(j, P, B, "¥", "\\yen", !0), A(M, P, B, "¥", "\\yen", !0), A(j, P, B, "✓", "\\checkmark", !0), A(M, P, B, "✓", "\\checkmark"), A(j, P, B, "ℶ", "\\beth", !0), A(j, P, B, "ℸ", "\\daleth", !0), A(j, P, B, "ℷ", "\\gimel", !0), A(j, P, B, "ϝ", "\\digamma", !0), A(j, P, B, "ϰ", "\\varkappa"), A(j, P, et, "┌", "\\@ulcorner", !0), A(j, P, Qe, "┐", "\\@urcorner", !0), A(j, P, et, "└", "\\@llcorner", !0), A(j, P, Qe, "┘", "\\@lrcorner", !0), A(j, P, z, "≦", "\\leqq", !0), A(j, P, z, "⩽", "\\leqslant", !0), A(j, P, z, "⪕", "\\eqslantless", !0), A(j, P, z, "≲", "\\lesssim", !0), A(j, P, z, "⪅", "\\lessapprox", !0), A(j, P, z, "≊", "\\approxeq", !0), A(j, P, I, "⋖", "\\lessdot"), A(j, P, z, "⋘", "\\lll", !0), A(j, P, z, "≶", "\\lessgtr", !0), A(j, P, z, "⋚", "\\lesseqgtr", !0), A(j, P, z, "⪋", "\\lesseqqgtr", !0), A(j, P, z, "≑", "\\doteqdot"), A(j, P, z, "≓", "\\risingdotseq", !0), A(j, P, z, "≒", "\\fallingdotseq", !0), A(j, P, z, "∽", "\\backsim", !0), A(j, P, z, "⋍", "\\backsimeq", !0), A(j, P, z, "⫅", "\\subseteqq", !0), A(j, P, z, "⋐", "\\Subset", !0), A(j, P, z, "⊏", "\\sqsubset", !0), A(j, P, z, "≼", "\\preccurlyeq", !0), A(j, P, z, "⋞", "\\curlyeqprec", !0), A(j, P, z, "≾", "\\precsim", !0), A(j, P, z, "⪷", "\\precapprox", !0), A(j, P, z, "⊲", "\\vartriangleleft"), A(j, P, z, "⊴", "\\trianglelefteq"), A(j, P, z, "⊨", "\\vDash", !0), A(j, P, z, "⊪", "\\Vvdash", !0), A(j, P, z, "⌣", "\\smallsmile"), A(j, P, z, "⌢", "\\smallfrown"), A(j, P, z, "≏", "\\bumpeq", !0), A(j, P, z, "≎", "\\Bumpeq", !0), A(j, P, z, "≧", "\\geqq", !0), A(j, P, z, "⩾", "\\geqslant", !0), A(j, P, z, "⪖", "\\eqslantgtr", !0), A(j, P, z, "≳", "\\gtrsim", !0), A(j, P, z, "⪆", "\\gtrapprox", !0), A(j, P, I, "⋗", "\\gtrdot"), A(j, P, z, "⋙", "\\ggg", !0), A(j, P, z, "≷", "\\gtrless", !0), A(j, P, z, "⋛", "\\gtreqless", !0), A(j, P, z, "⪌", "\\gtreqqless", !0), A(j, P, z, "≖", "\\eqcirc", !0), A(j, P, z, "≗", "\\circeq", !0), A(j, P, z, "≜", "\\triangleq", !0), A(j, P, z, "∼", "\\thicksim"), A(j, P, z, "≈", "\\thickapprox"), A(j, P, z, "⫆", "\\supseteqq", !0), A(j, P, z, "⋑", "\\Supset", !0), A(j, P, z, "⊐", "\\sqsupset", !0), A(j, P, z, "≽", "\\succcurlyeq", !0), A(j, P, z, "⋟", "\\curlyeqsucc", !0), A(j, P, z, "≿", "\\succsim", !0), A(j, P, z, "⪸", "\\succapprox", !0), A(j, P, z, "⊳", "\\vartriangleright"), A(j, P, z, "⊵", "\\trianglerighteq"), A(j, P, z, "⊩", "\\Vdash", !0), A(j, P, z, "∣", "\\shortmid"), A(j, P, z, "∥", "\\shortparallel"), A(j, P, z, "≬", "\\between", !0), A(j, P, z, "⋔", "\\pitchfork", !0), A(j, P, z, "∝", "\\varpropto"), A(j, P, z, "◀", "\\blacktriangleleft"), A(j, P, z, "∴", "\\therefore", !0), A(j, P, z, "∍", "\\backepsilon"), A(j, P, z, "▶", "\\blacktriangleright"), A(j, P, z, "∵", "\\because", !0), A(j, P, z, "⋘", "\\llless"), A(j, P, z, "⋙", "\\gggtr"), A(j, P, I, "⊲", "\\lhd"), A(j, P, I, "⊳", "\\rhd"), A(j, P, z, "≂", "\\eqsim", !0), A(j, N, z, "⋈", "\\Join"), A(j, P, z, "≑", "\\Doteq", !0), A(j, P, I, "∔", "\\dotplus", !0), A(j, P, I, "∖", "\\smallsetminus"), A(j, P, I, "⋒", "\\Cap", !0), A(j, P, I, "⋓", "\\Cup", !0), A(j, P, I, "⩞", "\\doublebarwedge", !0), A(j, P, I, "⊟", "\\boxminus", !0), A(j, P, I, "⊞", "\\boxplus", !0), A(j, P, I, "⋇", "\\divideontimes", !0), A(j, P, I, "⋉", "\\ltimes", !0), A(j, P, I, "⋊", "\\rtimes", !0), A(j, P, I, "⋋", "\\leftthreetimes", !0), A(j, P, I, "⋌", "\\rightthreetimes", !0), A(j, P, I, "⋏", "\\curlywedge", !0), A(j, P, I, "⋎", "\\curlyvee", !0), A(j, P, I, "⊝", "\\circleddash", !0), A(j, P, I, "⊛", "\\circledast", !0), A(j, P, I, "⋅", "\\centerdot"), A(j, P, I, "⊺", "\\intercal", !0), A(j, P, I, "⋒", "\\doublecap"), A(j, P, I, "⋓", "\\doublecup"), A(j, P, I, "⊠", "\\boxtimes", !0), A(j, P, z, "⇢", "\\dashrightarrow", !0), A(j, P, z, "⇠", "\\dashleftarrow", !0), A(j, P, z, "⇇", "\\leftleftarrows", !0), A(j, P, z, "⇆", "\\leftrightarrows", !0), A(j, P, z, "⇚", "\\Lleftarrow", !0), A(j, P, z, "↞", "\\twoheadleftarrow", !0), A(j, P, z, "↢", "\\leftarrowtail", !0), A(j, P, z, "↫", "\\looparrowleft", !0), A(j, P, z, "⇋", "\\leftrightharpoons", !0), A(j, P, z, "↶", "\\curvearrowleft", !0), A(j, P, z, "↺", "\\circlearrowleft", !0), A(j, P, z, "↰", "\\Lsh", !0), A(j, P, z, "⇈", "\\upuparrows", !0), A(j, P, z, "↿", "\\upharpoonleft", !0), A(j, P, z, "⇃", "\\downharpoonleft", !0), A(j, N, z, "⊶", "\\origof", !0), A(j, N, z, "⊷", "\\imageof", !0), A(j, P, z, "⊸", "\\multimap", !0), A(j, P, z, "↭", "\\leftrightsquigarrow", !0), A(j, P, z, "⇉", "\\rightrightarrows", !0), A(j, P, z, "⇄", "\\rightleftarrows", !0), A(j, P, z, "↠", "\\twoheadrightarrow", !0), A(j, P, z, "↣", "\\rightarrowtail", !0), A(j, P, z, "↬", "\\looparrowright", !0), A(j, P, z, "↷", "\\curvearrowright", !0), A(j, P, z, "↻", "\\circlearrowright", !0), A(j, P, z, "↱", "\\Rsh", !0), A(j, P, z, "⇊", "\\downdownarrows", !0), A(j, P, z, "↾", "\\upharpoonright", !0), A(j, P, z, "⇂", "\\downharpoonright", !0), A(j, P, z, "⇝", "\\rightsquigarrow", !0), A(j, P, z, "⇝", "\\leadsto"), A(j, P, z, "⇛", "\\Rrightarrow", !0), A(j, P, z, "↾", "\\restriction"), A(j, N, B, "‘", "`"), A(j, N, B, "$", "\\$"), A(M, N, B, "$", "\\$"), A(M, N, B, "$", "\\textdollar"), A(j, N, B, "%", "\\%"), A(M, N, B, "%", "\\%"), A(j, N, B, "_", "\\_"), A(M, N, B, "_", "\\_"), A(M, N, B, "_", "\\textunderscore"), A(j, N, B, "∠", "\\angle", !0), A(j, N, B, "∞", "\\infty", !0), A(j, N, B, "′", "\\prime"), A(j, N, B, "△", "\\triangle"), A(j, N, B, "Γ", "\\Gamma", !0), A(j, N, B, "Δ", "\\Delta", !0), A(j, N, B, "Θ", "\\Theta", !0), A(j, N, B, "Λ", "\\Lambda", !0), A(j, N, B, "Ξ", "\\Xi", !0), A(j, N, B, "Π", "\\Pi", !0), A(j, N, B, "Σ", "\\Sigma", !0), A(j, N, B, "Υ", "\\Upsilon", !0), A(j, N, B, "Φ", "\\Phi", !0), A(j, N, B, "Ψ", "\\Psi", !0), A(j, N, B, "Ω", "\\Omega", !0), A(j, N, B, "A", "Α"), A(j, N, B, "B", "Β"), A(j, N, B, "E", "Ε"), A(j, N, B, "Z", "Ζ"), A(j, N, B, "H", "Η"), A(j, N, B, "I", "Ι"), A(j, N, B, "K", "Κ"), A(j, N, B, "M", "Μ"), A(j, N, B, "N", "Ν"), A(j, N, B, "O", "Ο"), A(j, N, B, "P", "Ρ"), A(j, N, B, "T", "Τ"), A(j, N, B, "X", "Χ"), A(j, N, B, "¬", "\\neg", !0), A(j, N, B, "¬", "\\lnot"), A(j, N, B, "⊤", "\\top"), A(j, N, B, "⊥", "\\bot"), A(j, N, B, "∅", "\\emptyset"), A(j, P, B, "∅", "\\varnothing"), A(j, N, L, "α", "\\alpha", !0), A(j, N, L, "β", "\\beta", !0), A(j, N, L, "γ", "\\gamma", !0), A(j, N, L, "δ", "\\delta", !0), A(j, N, L, "ϵ", "\\epsilon", !0), A(j, N, L, "ζ", "\\zeta", !0), A(j, N, L, "η", "\\eta", !0), A(j, N, L, "θ", "\\theta", !0), A(j, N, L, "ι", "\\iota", !0), A(j, N, L, "κ", "\\kappa", !0), A(j, N, L, "λ", "\\lambda", !0), A(j, N, L, "μ", "\\mu", !0), A(j, N, L, "ν", "\\nu", !0), A(j, N, L, "ξ", "\\xi", !0), A(j, N, L, "ο", "\\omicron", !0), A(j, N, L, "π", "\\pi", !0), A(j, N, L, "ρ", "\\rho", !0), A(j, N, L, "σ", "\\sigma", !0), A(j, N, L, "τ", "\\tau", !0), A(j, N, L, "υ", "\\upsilon", !0), A(j, N, L, "ϕ", "\\phi", !0), A(j, N, L, "χ", "\\chi", !0), A(j, N, L, "ψ", "\\psi", !0), A(j, N, L, "ω", "\\omega", !0), A(j, N, L, "ε", "\\varepsilon", !0), A(j, N, L, "ϑ", "\\vartheta", !0), A(j, N, L, "ϖ", "\\varpi", !0), A(j, N, L, "ϱ", "\\varrho", !0), A(j, N, L, "ς", "\\varsigma", !0), A(j, N, L, "φ", "\\varphi", !0), A(j, N, I, "∗", "*", !0), A(j, N, I, "+", "+"), A(j, N, I, "−", "-", !0), A(j, N, I, "⋅", "\\cdot", !0), A(j, N, I, "∘", "\\circ", !0), A(j, N, I, "÷", "\\div", !0), A(j, N, I, "±", "\\pm", !0), A(j, N, I, "×", "\\times", !0), A(j, N, I, "∩", "\\cap", !0), A(j, N, I, "∪", "\\cup", !0), A(j, N, I, "∖", "\\setminus", !0), A(j, N, I, "∧", "\\land"), A(j, N, I, "∨", "\\lor"), A(j, N, I, "∧", "\\wedge", !0), A(j, N, I, "∨", "\\vee", !0), A(j, N, B, "√", "\\surd"), A(j, N, et, "⟨", "\\langle", !0), A(j, N, et, "∣", "\\lvert"), A(j, N, et, "∥", "\\lVert"), A(j, N, Qe, "?", "?"), A(j, N, Qe, "!", "!"), A(j, N, Qe, "⟩", "\\rangle", !0), A(j, N, Qe, "∣", "\\rvert"), A(j, N, Qe, "∥", "\\rVert"), A(j, N, z, "=", "="), A(j, N, z, ":", ":"), A(j, N, z, "≈", "\\approx", !0), A(j, N, z, "≅", "\\cong", !0), A(j, N, z, "≥", "\\ge"), A(j, N, z, "≥", "\\geq", !0), A(j, N, z, "←", "\\gets"), A(j, N, z, ">", "\\gt", !0), A(j, N, z, "∈", "\\in", !0), A(j, N, z, "", "\\@not"), A(j, N, z, "⊂", "\\subset", !0), A(j, N, z, "⊃", "\\supset", !0), A(j, N, z, "⊆", "\\subseteq", !0), A(j, N, z, "⊇", "\\supseteq", !0), A(j, P, z, "⊈", "\\nsubseteq", !0), A(j, P, z, "⊉", "\\nsupseteq", !0), A(j, N, z, "⊨", "\\models"), A(j, N, z, "←", "\\leftarrow", !0), A(j, N, z, "≤", "\\le"), A(j, N, z, "≤", "\\leq", !0), A(j, N, z, "<", "\\lt", !0), A(j, N, z, "→", "\\rightarrow", !0), A(j, N, z, "→", "\\to"), A(j, P, z, "≱", "\\ngeq", !0), A(j, P, z, "≰", "\\nleq", !0), A(j, N, nt, "\xA0", "\\ "), A(j, N, nt, "\xA0", "\\space"), A(j, N, nt, "\xA0", "\\nobreakspace"), A(M, N, nt, "\xA0", "\\ "), A(M, N, nt, "\xA0", " "), A(M, N, nt, "\xA0", "\\space"), A(M, N, nt, "\xA0", "\\nobreakspace"), A(j, N, nt, "", "\\nobreak"), A(j, N, nt, "", "\\allowbreak"), A(j, N, tt, ",", ","), A(j, N, tt, ";", ";"), A(j, P, I, "⊼", "\\barwedge", !0), A(j, P, I, "⊻", "\\veebar", !0), A(j, N, I, "⊙", "\\odot", !0), A(j, N, I, "⊕", "\\oplus", !0), A(j, N, I, "⊗", "\\otimes", !0), A(j, N, B, "∂", "\\partial", !0), A(j, N, I, "⊘", "\\oslash", !0), A(j, P, I, "⊚", "\\circledcirc", !0), A(j, P, I, "⊡", "\\boxdot", !0), A(j, N, I, "△", "\\bigtriangleup"), A(j, N, I, "▽", "\\bigtriangledown"), A(j, N, I, "†", "\\dagger"), A(j, N, I, "⋄", "\\diamond"), A(j, N, I, "⋆", "\\star"), A(j, N, I, "◃", "\\triangleleft"), A(j, N, I, "▹", "\\triangleright"), A(j, N, et, "{", "\\{"), A(M, N, B, "{", "\\{"), A(M, N, B, "{", "\\textbraceleft"), A(j, N, Qe, "}", "\\}"), A(M, N, B, "}", "\\}"), A(M, N, B, "}", "\\textbraceright"), A(j, N, et, "{", "\\lbrace"), A(j, N, Qe, "}", "\\rbrace"), A(j, N, et, "[", "\\lbrack", !0), A(M, N, B, "[", "\\lbrack", !0), A(j, N, Qe, "]", "\\rbrack", !0), A(M, N, B, "]", "\\rbrack", !0), A(j, N, et, "(", "\\lparen", !0), A(j, N, Qe, ")", "\\rparen", !0), A(M, N, B, "<", "\\textless", !0), A(M, N, B, ">", "\\textgreater", !0), A(j, N, et, "⌊", "\\lfloor", !0), A(j, N, Qe, "⌋", "\\rfloor", !0), A(j, N, et, "⌈", "\\lceil", !0), A(j, N, Qe, "⌉", "\\rceil", !0), A(j, N, B, "\\", "\\backslash"), A(j, N, B, "∣", "|"), A(j, N, B, "∣", "\\vert"), A(M, N, B, "|", "\\textbar", !0), A(j, N, B, "∥", "\\|"), A(j, N, B, "∥", "\\Vert"), A(M, N, B, "∥", "\\textbardbl"), A(M, N, B, "~", "\\textasciitilde"), A(M, N, B, "\\", "\\textbackslash"), A(M, N, B, "^", "\\textasciicircum"), A(j, N, z, "↑", "\\uparrow", !0), A(j, N, z, "⇑", "\\Uparrow", !0), A(j, N, z, "↓", "\\downarrow", !0), A(j, N, z, "⇓", "\\Downarrow", !0), A(j, N, z, "↕", "\\updownarrow", !0), A(j, N, z, "⇕", "\\Updownarrow", !0), A(j, N, R, "∐", "\\coprod"), A(j, N, R, "⋁", "\\bigvee"), A(j, N, R, "⋀", "\\bigwedge"), A(j, N, R, "⨄", "\\biguplus"), A(j, N, R, "⋂", "\\bigcap"), A(j, N, R, "⋃", "\\bigcup"), A(j, N, R, "∫", "\\int"), A(j, N, R, "∫", "\\intop"), A(j, N, R, "∬", "\\iint"), A(j, N, R, "∭", "\\iiint"), A(j, N, R, "∏", "\\prod"), A(j, N, R, "∑", "\\sum"), A(j, N, R, "⨂", "\\bigotimes"), A(j, N, R, "⨁", "\\bigoplus"), A(j, N, R, "⨀", "\\bigodot"), A(j, N, R, "∮", "\\oint"), A(j, N, R, "∯", "\\oiint"), A(j, N, R, "∰", "\\oiiint"), A(j, N, R, "⨆", "\\bigsqcup"), A(j, N, R, "∫", "\\smallint"), A(M, N, $e, "…", "\\textellipsis"), A(j, N, $e, "…", "\\mathellipsis"), A(M, N, $e, "…", "\\ldots", !0), A(j, N, $e, "…", "\\ldots", !0), A(j, N, $e, "⋯", "\\@cdots", !0), A(j, N, $e, "⋱", "\\ddots", !0), A(j, N, B, "⋮", "\\varvdots"), A(M, N, B, "⋮", "\\varvdots"), A(j, N, F, "ˊ", "\\acute"), A(j, N, F, "ˋ", "\\grave"), A(j, N, F, "¨", "\\ddot"), A(j, N, F, "~", "\\tilde"), A(j, N, F, "ˉ", "\\bar"), A(j, N, F, "˘", "\\breve"), A(j, N, F, "ˇ", "\\check"), A(j, N, F, "^", "\\hat"), A(j, N, F, "⃗", "\\vec"), A(j, N, F, "˙", "\\dot"), A(j, N, F, "˚", "\\mathring"), A(j, N, L, "", "\\@imath"), A(j, N, L, "", "\\@jmath"), A(j, N, B, "ı", "ı"), A(j, N, B, "ȷ", "ȷ"), A(M, N, B, "ı", "\\i", !0), A(M, N, B, "ȷ", "\\j", !0), A(M, N, B, "ß", "\\ss", !0), A(M, N, B, "æ", "\\ae", !0), A(M, N, B, "œ", "\\oe", !0), A(M, N, B, "ø", "\\o", !0), A(M, N, B, "Æ", "\\AE", !0), A(M, N, B, "Œ", "\\OE", !0), A(M, N, B, "Ø", "\\O", !0), A(M, N, F, "ˊ", "\\'"), A(M, N, F, "ˋ", "\\`"), A(M, N, F, "ˆ", "\\^"), A(M, N, F, "˜", "\\~"), A(M, N, F, "ˉ", "\\="), A(M, N, F, "˘", "\\u"), A(M, N, F, "˙", "\\."), A(M, N, F, "¸", "\\c"), A(M, N, F, "˚", "\\r"), A(M, N, F, "ˇ", "\\v"), A(M, N, F, "¨", "\\\""), A(M, N, F, "˝", "\\H"), A(M, N, F, "◯", "\\textcircled");
var rt = {
	"--": !0,
	"---": !0,
	"``": !0,
	"''": !0
};
A(M, N, B, "–", "--", !0), A(M, N, B, "–", "\\textendash"), A(M, N, B, "—", "---", !0), A(M, N, B, "—", "\\textemdash"), A(M, N, B, "‘", "`", !0), A(M, N, B, "‘", "\\textquoteleft"), A(M, N, B, "’", "'", !0), A(M, N, B, "’", "\\textquoteright"), A(M, N, B, "“", "``", !0), A(M, N, B, "“", "\\textquotedblleft"), A(M, N, B, "”", "''", !0), A(M, N, B, "”", "\\textquotedblright"), A(j, N, B, "°", "\\degree", !0), A(M, N, B, "°", "\\degree"), A(M, N, B, "°", "\\textdegree", !0), A(j, N, B, "£", "\\pounds"), A(j, N, B, "£", "\\mathsterling", !0), A(M, N, B, "£", "\\pounds"), A(M, N, B, "£", "\\textsterling", !0), A(j, P, B, "✠", "\\maltese"), A(M, P, B, "✠", "\\maltese");
for (var it = "0123456789/@.\"", at = 0; at < it.length; at++) {
	var ot = it.charAt(at);
	A(j, N, B, ot, ot);
}
for (var st = "0123456789!@*()-=+\";:?/.,", ct = 0; ct < st.length; ct++) {
	var lt = st.charAt(ct);
	A(M, N, B, lt, lt);
}
for (var ut = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", dt = 0; dt < ut.length; dt++) {
	var ft = ut.charAt(dt);
	A(j, N, L, ft, ft), A(M, N, B, ft, ft);
}
A(j, P, B, "C", "ℂ"), A(M, P, B, "C", "ℂ"), A(j, P, B, "H", "ℍ"), A(M, P, B, "H", "ℍ"), A(j, P, B, "N", "ℕ"), A(M, P, B, "N", "ℕ"), A(j, P, B, "P", "ℙ"), A(M, P, B, "P", "ℙ"), A(j, P, B, "Q", "ℚ"), A(M, P, B, "Q", "ℚ"), A(j, P, B, "R", "ℝ"), A(M, P, B, "R", "ℝ"), A(j, P, B, "Z", "ℤ"), A(M, P, B, "Z", "ℤ"), A(j, N, L, "h", "ℎ"), A(M, N, L, "h", "ℎ");
for (var V, pt = 0; pt < ut.length; pt++) {
	var H = ut.charAt(pt);
	V = String.fromCharCode(55349, 56320 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56372 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56424 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56580 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56684 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56736 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56788 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56840 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56944 + pt), A(j, N, L, H, V), A(M, N, B, H, V), pt < 26 && (V = String.fromCharCode(55349, 56632 + pt), A(j, N, L, H, V), A(M, N, B, H, V), V = String.fromCharCode(55349, 56476 + pt), A(j, N, L, H, V), A(M, N, B, H, V));
}
V = String.fromCharCode(55349, 56668), A(j, N, L, "k", V), A(M, N, B, "k", V);
for (var mt = 0; mt < 10; mt++) {
	var ht = mt.toString();
	V = String.fromCharCode(55349, 57294 + mt), A(j, N, L, ht, V), A(M, N, B, ht, V), V = String.fromCharCode(55349, 57314 + mt), A(j, N, L, ht, V), A(M, N, B, ht, V), V = String.fromCharCode(55349, 57324 + mt), A(j, N, L, ht, V), A(M, N, B, ht, V), V = String.fromCharCode(55349, 57334 + mt), A(j, N, L, ht, V), A(M, N, B, ht, V);
}
for (var gt = "ÐÞþ", _t = 0; _t < gt.length; _t++) {
	var vt = gt.charAt(_t);
	A(j, N, L, vt, vt), A(M, N, B, vt, vt);
}
var yt = {
	mathClass: "mathbf",
	textClass: "textbf",
	font: "Main-Bold"
}, bt = {
	mathClass: "mathnormal",
	textClass: "textit",
	font: "Math-Italic"
}, xt = {
	mathClass: "boldsymbol",
	textClass: "boldsymbol",
	font: "Main-BoldItalic"
}, St = {
	mathClass: "mathscr",
	textClass: "textscr",
	font: "Script-Regular"
}, Ct = {
	mathClass: "",
	textClass: "",
	font: ""
}, wt = {
	mathClass: "mathfrak",
	textClass: "textfrak",
	font: "Fraktur-Regular"
}, Tt = {
	mathClass: "mathbb",
	textClass: "textbb",
	font: "AMS-Regular"
}, Et = {
	mathClass: "mathboldfrak",
	textClass: "textboldfrak",
	font: "Fraktur-Regular"
}, Dt = {
	mathClass: "mathsf",
	textClass: "textsf",
	font: "SansSerif-Regular"
}, Ot = {
	mathClass: "mathboldsf",
	textClass: "textboldsf",
	font: "SansSerif-Bold"
}, kt = {
	mathClass: "mathitsf",
	textClass: "textitsf",
	font: "SansSerif-Italic"
}, At = {
	mathClass: "mathtt",
	textClass: "texttt",
	font: "Typewriter-Regular"
}, jt = [
	yt,
	yt,
	bt,
	bt,
	xt,
	xt,
	St,
	Ct,
	Ct,
	Ct,
	wt,
	wt,
	Tt,
	Tt,
	Et,
	Et,
	Dt,
	Dt,
	Ot,
	Ot,
	kt,
	kt,
	Ct,
	Ct,
	At,
	At
], Mt = [
	yt,
	Ct,
	Dt,
	Ot,
	At
], Nt = (e) => {
	var n = e.charCodeAt(0), r = e.charCodeAt(1), i = (n - 55296) * 1024 + (r - 56320) + 65536;
	if (119808 <= i && i < 120484) return jt[Math.floor((i - 119808) / 26)];
	if (120782 <= i && i <= 120831) return Mt[Math.floor((i - 120782) / 10)];
	if (i === 120485 || i === 120486) return jt[0];
	if (120486 < i && i < 120782) return Ct;
	throw new t("Unsupported character: " + e);
};
function Pt(e) {
	var n = e.strict, r = e.errorCode, i = e.errorMsg, a = e.token, o = e.report, s = n;
	if (typeof n == "function") {
		if (o) s = n(r, i, a);
		else try {
			s = n(r, i, a);
		} catch {
			s = "error";
		}
	}
	switch (s) {
		case !0:
		case "error":
			if (o) throw new t("LaTeX-incompatible input and strict mode is set to 'error': " + (i + " [" + r + "]"), a);
			return !0;
		case !1:
		case "ignore":
			if (!o) return !1;
			break;
		default: if (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (i + " [" + r + "]")), !o) return !1;
	}
}
var Ft = function(e, t, n) {
	if (k[n][e]) {
		var r = k[n][e].replace;
		r && (e = r);
	}
	return {
		value: e,
		metrics: Ye(e, t, n)
	};
}, It = function(e, t, n, r, i) {
	var a = Ft(e, t, n), o = a.metrics;
	e = a.value;
	var s;
	if (o) {
		var c = o.italic;
		(n === "text" || r && r.font === "mathit") && (c = 0), s = new Re(e, o.height, o.depth, c, o.skew, o.width, i);
	} else Pt({
		strict: r.strict,
		errorCode: "symbolNotInFont",
		errorMsg: "No character metrics for '" + e + "' in style '" + t + "' and mode '" + n + "'",
		report: !0
	}), s = new Re(e, 0, 0, 0, 0, 0, i);
	s.maxFontSize = r.sizeMultiplier, r.style.isTight() && s.classes.push("mtight");
	var l = r.getColor();
	return l && (s.style.color = l), s;
}, Lt = function(e, t, n, r) {
	return r === void 0 && (r = []), n.font === "boldsymbol" && Ft(e, "Main-Bold", t).metrics ? It(e, "Main-Bold", t, n, r.concat(["mathbf"])) : e === "\\" || k[t][e].font === "main" ? It(e, "Main-Regular", t, n, r) : It(e, "AMS-Regular", t, n, r.concat(["amsrm"]));
}, Rt = function(e, t, n) {
	return n !== "textord" && Ft(e, "Math-BoldItalic", t).metrics ? {
		fontName: "Math-BoldItalic",
		fontClass: "boldsymbol"
	} : {
		fontName: "Main-Bold",
		fontClass: "mathbf"
	};
}, zt = function(e, t) {
	var n = e.type === "mathord" ? "mathord" : "textord", r = e.mode, i = e.text, a = ["mord"], o = t.font, s = t.fontFamily, c = t.fontWeight, l = t.fontShape, u = r === "math" || r === "text" && !!o, d = u ? o : s, f = "", p = "";
	if (i.charCodeAt(0) === 55349) {
		var m = Nt(i);
		f = m.font, p = m[r + "Class"];
	}
	if (f) return It(i, f, r, t, a.concat(p));
	if (d) {
		var h, g;
		if (d === "boldsymbol") {
			var _ = Rt(i, r, n);
			h = _.fontName, g = [_.fontClass];
		} else u ? (h = Zt[o].fontName, g = [o]) : (h = Xt(s, c, l), g = [
			s,
			c,
			l
		]);
		if (Ft(i, h, r).metrics) return It(i, h, r, t, a.concat(g));
		if (Object.prototype.hasOwnProperty.call(rt, i) && h.slice(0, 10) === "Typewriter") {
			for (var v = [], y = 0; y < i.length; y++) v.push(It(i[y], h, r, t, a.concat(g)));
			return Kt(v);
		}
	}
	if (n === "mathord") return It(i, "Math-Italic", r, t, a.concat(["mathnormal"]));
	if (n === "textord") {
		var b = k[r][i] && k[r][i].font;
		if (b === "ams") return It(i, Xt("amsrm", c, l), r, t, a.concat("amsrm", c, l));
		if (b === "main" || !b) return It(i, Xt("textrm", c, l), r, t, a.concat(c, l));
		var x = Xt(b, c, l);
		return It(i, x, r, t, a.concat(x, c, l));
	}
	throw Error("unexpected type: " + n + " in makeOrd");
}, Bt = (e, t) => {
	if (Oe(e.classes) !== Oe(t.classes) || e.skew !== t.skew || e.maxFontSize !== t.maxFontSize || e.italic !== 0 && e.hasClass("mathnormal")) return !1;
	if (e.classes.length === 1) {
		var n = e.classes[0];
		if (n === "mbin" || n === "mord") return !1;
	}
	for (var r of Object.keys(e.style)) if (e.style[r] !== t.style[r]) return !1;
	for (var i of Object.keys(t.style)) if (e.style[i] !== t.style[i]) return !1;
	return !0;
}, Vt = (e) => {
	for (var t = 0; t < e.length - 1; t++) {
		var n = e[t], r = e[t + 1];
		n instanceof Re && r instanceof Re && Bt(n, r) && (n.text += r.text, n.height = Math.max(n.height, r.height), n.depth = Math.max(n.depth, r.depth), n.italic = r.italic, e.splice(t + 1, 1), t--);
	}
	return e;
}, Ht = function(e) {
	for (var t = 0, n = 0, r = 0, i = 0; i < e.children.length; i++) {
		var a = e.children[i];
		a.height > t && (t = a.height), a.depth > n && (n = a.depth), a.maxFontSize > r && (r = a.maxFontSize);
	}
	e.height = t, e.depth = n, e.maxFontSize = r;
}, U = function(e, t, n, r) {
	var i = new Pe(e, t, n, r);
	return Ht(i), i;
}, Ut = (e, t, n, r) => new Pe(e, t, n, r), Wt = function(e, t, n) {
	var r = U([e], [], t);
	return r.height = Math.max(n || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), r.style.borderBottomWidth = O(r.height), r.maxFontSize = 1, r;
}, Gt = function(e, t, n, r) {
	var i = new Fe(e, t, n, r);
	return Ht(i), i;
}, Kt = function(e) {
	var t = new we(e);
	return Ht(t), t;
}, qt = function(e, t) {
	return e instanceof we ? U([], [e], t) : e;
}, Jt = function(e) {
	if (e.positionType === "individualShift") {
		for (var t = e.children, n = [t[0]], r = -t[0].shift - t[0].elem.depth, i = r, a = 1; a < t.length; a++) {
			var o = -t[a].shift - i - t[a].elem.depth, s = o - (t[a - 1].elem.height + t[a - 1].elem.depth);
			i += o, n.push({
				type: "kern",
				size: s
			}), n.push(t[a]);
		}
		return {
			children: n,
			depth: r
		};
	}
	var c;
	if (e.positionType === "top") {
		for (var l = e.positionData, u = 0; u < e.children.length; u++) {
			var d = e.children[u];
			l -= d.type === "kern" ? d.size : d.elem.height + d.elem.depth;
		}
		c = l;
	} else if (e.positionType === "bottom") c = -e.positionData;
	else {
		var f = e.children[0];
		if (f.type !== "elem") throw Error("First child must have type \"elem\".");
		if (e.positionType === "shift") c = -f.elem.depth - e.positionData;
		else if (e.positionType === "firstBaseline") c = -f.elem.depth;
		else throw Error("Invalid positionType " + e.positionType + ".");
	}
	return {
		children: e.children,
		depth: c
	};
}, W = function(e, t) {
	for (var n = Jt(e), r = n.children, i = n.depth, a = 0, o = 0; o < r.length; o++) {
		var s = r[o];
		if (s.type === "elem") {
			var c = s.elem;
			a = Math.max(a, c.maxFontSize, c.height);
		}
	}
	a += 2;
	var l = U(["pstrut"], []);
	l.style.height = O(a);
	for (var u = [], d = i, f = i, p = i, m = 0; m < r.length; m++) {
		var h = r[m];
		if (h.type === "kern") p += h.size;
		else {
			var g = h.elem, _ = h.wrapperClasses || [], v = h.wrapperStyle || {}, y = U(_, [l, g], void 0, v);
			y.style.top = O(-a - p - g.depth), h.marginLeft && (y.style.marginLeft = h.marginLeft), h.marginRight && (y.style.marginRight = h.marginRight), u.push(y), p += g.height + g.depth;
		}
		d = Math.min(d, p), f = Math.max(f, p);
	}
	var b = U(["vlist"], u);
	b.style.height = O(f);
	var x;
	if (d < 0) {
		var S = U(["vlist"], [U([], [])]);
		S.style.height = O(-d), x = [U(["vlist-r"], [b, U(["vlist-s"], [new Re("​")])]), U(["vlist-r"], [S])];
	} else x = [U(["vlist-r"], [b])];
	var C = U(["vlist-t"], x);
	return x.length === 2 && C.classes.push("vlist-t2"), C.height = f, C.depth = -d, C;
}, Yt = (e, t) => {
	var n = U(["mspace"], [], t), r = D(e, t);
	return n.style.marginRight = O(r), n;
}, Xt = (e, t, n) => {
	var r, i;
	switch (e) {
		case "amsrm":
			r = "AMS";
			break;
		case "textrm":
			r = "Main";
			break;
		case "textsf":
			r = "SansSerif";
			break;
		case "texttt":
			r = "Typewriter";
			break;
		default: r = e;
	}
	return i = t === "textbf" && n === "textit" ? "BoldItalic" : t === "textbf" ? "Bold" : n === "textit" ? "Italic" : "Regular", r + "-" + i;
}, Zt = {
	mathbf: {
		variant: "bold",
		fontName: "Main-Bold"
	},
	mathrm: {
		variant: "normal",
		fontName: "Main-Regular"
	},
	textit: {
		variant: "italic",
		fontName: "Main-Italic"
	},
	mathit: {
		variant: "italic",
		fontName: "Main-Italic"
	},
	mathnormal: {
		variant: "italic",
		fontName: "Math-Italic"
	},
	mathsfit: {
		variant: "sans-serif-italic",
		fontName: "SansSerif-Italic"
	},
	mathbb: {
		variant: "double-struck",
		fontName: "AMS-Regular"
	},
	mathcal: {
		variant: "script",
		fontName: "Caligraphic-Regular"
	},
	mathfrak: {
		variant: "fraktur",
		fontName: "Fraktur-Regular"
	},
	mathscr: {
		variant: "script",
		fontName: "Script-Regular"
	},
	mathsf: {
		variant: "sans-serif",
		fontName: "SansSerif-Regular"
	},
	mathtt: {
		variant: "monospace",
		fontName: "Typewriter-Regular"
	}
}, Qt = {
	vec: [
		"vec",
		.471,
		.714
	],
	oiintSize1: [
		"oiintSize1",
		.957,
		.499
	],
	oiintSize2: [
		"oiintSize2",
		1.472,
		.659
	],
	oiiintSize1: [
		"oiiintSize1",
		1.304,
		.499
	],
	oiiintSize2: [
		"oiiintSize2",
		1.98,
		.659
	]
}, $t = function(e, t) {
	var n = Qt[e], r = n[0], i = n[1], a = n[2], o = Ut(["katex-overlay"], [new ze([new Be(r)], {
		width: O(i),
		height: O(a),
		style: "width:" + O(i),
		viewBox: "0 0 " + 1e3 * i + " " + 1e3 * a,
		preserveAspectRatio: "xMinYMin"
	})], t);
	return o.height = a, o.style.height = O(a), o.style.width = O(i), o;
}, G = {
	number: 3,
	unit: "mu"
}, en = {
	number: 4,
	unit: "mu"
}, tn = {
	number: 5,
	unit: "mu"
}, nn = {
	mord: {
		mop: G,
		mbin: en,
		mrel: tn,
		minner: G
	},
	mop: {
		mord: G,
		mop: G,
		mrel: tn,
		minner: G
	},
	mbin: {
		mord: en,
		mop: en,
		mopen: en,
		minner: en
	},
	mrel: {
		mord: tn,
		mop: tn,
		mopen: tn,
		minner: tn
	},
	mopen: {},
	mclose: {
		mop: G,
		mbin: en,
		mrel: tn,
		minner: G
	},
	mpunct: {
		mord: G,
		mop: G,
		mrel: tn,
		mopen: G,
		mclose: G,
		mpunct: G,
		minner: G
	},
	minner: {
		mord: G,
		mop: G,
		mbin: en,
		mrel: tn,
		mopen: G,
		mpunct: G,
		minner: G
	}
}, rn = {
	mord: { mop: G },
	mop: {
		mord: G,
		mop: G
	},
	mbin: {},
	mrel: {},
	mopen: {},
	mclose: { mop: G },
	mpunct: {},
	minner: { mop: G }
}, an = {}, on = {}, sn = {};
function K(e) {
	for (var t = e.type, n = e.names, r = e.htmlBuilder, i = e.mathmlBuilder, a = 0; a < n.length; ++a) an[n[a]] = e;
	t && (r && (on[t] = r), i && (sn[t] = i));
}
function cn(e) {
	var t = e.type, n = e.htmlBuilder, r = e.mathmlBuilder;
	n && (on[t] = n), r && (sn[t] = r);
}
var ln = function(e) {
	return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e;
}, un = function(e) {
	return e.type === "ordgroup" ? e.body : [e];
}, dn = /* @__PURE__ */ new Set([
	"leftmost",
	"mbin",
	"mopen",
	"mrel",
	"mop",
	"mpunct"
]), fn = /* @__PURE__ */ new Set([
	"rightmost",
	"mrel",
	"mclose",
	"mpunct"
]), pn = {
	display: T.DISPLAY,
	text: T.TEXT,
	script: T.SCRIPT,
	scriptscript: T.SCRIPTSCRIPT
}, mn = {
	mord: "mord",
	mop: "mop",
	mbin: "mbin",
	mrel: "mrel",
	mopen: "mopen",
	mclose: "mclose",
	mpunct: "mpunct",
	minner: "minner"
}, hn = function(e, t, n, r) {
	r === void 0 && (r = [null, null]);
	for (var i = [], a = 0; a < e.length; a++) {
		var o = q(e[a], t);
		if (o instanceof we) {
			var s = o.children;
			i.push(...s);
		} else i.push(o);
	}
	if (Vt(i), !n) return i;
	var c = t;
	if (e.length === 1) {
		var l = e[0];
		l.type === "sizing" ? c = t.havingSize(l.size) : l.type === "styling" && (c = t.havingStyle(pn[l.style]));
	}
	var u = U([r[0] || "leftmost"], [], t), d = U([r[1] || "rightmost"], [], t), f = n === "root";
	return gn(i, (e, t) => {
		var n = t.classes[0], r = e.classes[0];
		n === "mbin" && fn.has(r) ? t.classes[0] = "mord" : r === "mbin" && dn.has(n) && (e.classes[0] = "mord");
	}, { node: u }, d, f), gn(i, (e, t) => {
		var n = yn(t), r = yn(e), i = n && r ? e.hasClass("mtight") ? rn[n]?.[r] : nn[n]?.[r] : null;
		if (i) return Yt(i, c);
	}, { node: u }, d, f), i;
}, gn = function(e, t, n, r, i) {
	r && e.push(r);
	for (var a = 0; a < e.length; a++) {
		var o = e[a], s = _n(o);
		if (s) gn(s.children, t, n, null, i);
		else {
			var c = !o.hasClass("mspace");
			if (c) {
				var l = t(o, n.node);
				l && (n.insertAfter ? n.insertAfter(l) : (e.unshift(l), a++));
			}
			c ? n.node = o : i && o.hasClass("katex-newline") && (n.node = U(["leftmost"])), n.insertAfter = ((t) => (n) => {
				e.splice(t + 1, 0, n), a++;
			})(a);
		}
	}
	r && e.pop();
}, _n = function(e) {
	return e instanceof we || e instanceof Fe || e instanceof Pe && e.hasClass("enclosing") ? e : null;
}, vn = function(e, t) {
	var n = _n(e);
	if (n) {
		var r = n.children;
		if (r.length) {
			if (t === "right") return vn(r[r.length - 1], "right");
			if (t === "left") return vn(r[0], "left");
		}
	}
	return e;
}, yn = function(e, t) {
	return e ? (t && (e = vn(e, t)), mn[e.classes[0]] || null) : null;
}, bn = function(e, t) {
	var n = ["nulldelimiter"].concat(e.baseSizingClasses());
	return U(t.concat(n));
}, q = function(e, n, r) {
	if (!e) return U();
	if (on[e.type]) {
		var i = on[e.type](e, n);
		if (r && n.size !== r.size) {
			i = U(n.sizingClasses(r), [i], n);
			var a = n.sizeMultiplier / r.sizeMultiplier;
			i.height *= a, i.depth *= a;
		}
		return i;
	}
	throw new t("Got group of unknown type: '" + e.type + "'");
};
function xn(e, t) {
	var n = U(["katex-base"], e, t), r = U(["katex-strut"]);
	return r.style.height = O(n.height + n.depth), n.depth && (r.style.verticalAlign = O(-n.depth)), n.children.unshift(r), n;
}
function Sn(e, t) {
	var n = null;
	e.length === 1 && e[0].type === "tag" && (n = e[0].tag, e = e[0].body);
	var r = hn(e, t, "root"), i;
	r.length === 2 && r[1].hasClass("katex-tag") && (i = r.pop());
	for (var a = [], o = [], s = 0; s < r.length; s++) if (o.push(r[s]), r[s].hasClass("mbin") || r[s].hasClass("mrel") || r[s].hasClass("allowbreak")) {
		for (var c = !1; s < r.length - 1 && r[s + 1].hasClass("mspace") && !r[s + 1].hasClass("katex-newline");) s++, o.push(r[s]), r[s].hasClass("nobreak") && (c = !0);
		c || (a.push(xn(o, t)), o = []);
	} else r[s].hasClass("katex-newline") && (o.pop(), o.length > 0 && (a.push(xn(o, t)), o = []), a.push(r[s]));
	o.length > 0 && a.push(xn(o, t));
	var l;
	n ? (l = xn(hn(n, t, !0), t), l.classes = ["katex-tag"], a.push(l)) : i && a.push(i);
	var u = U(["katex-html"], a);
	if (u.setAttribute("aria-hidden", "true"), l) {
		var d = l.children[0];
		d.style.height = O(u.height + u.depth), u.depth && (d.style.verticalAlign = O(-u.depth));
	}
	return u;
}
function Cn(e) {
	return new we(e);
}
var J = class {
	constructor(e, t, n) {
		this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = n || [];
	}
	setAttribute(e, t) {
		this.attributes[e] = t;
	}
	getAttribute(e) {
		return this.attributes[e];
	}
	toNode() {
		var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type);
		for (var t of Object.entries(this.attributes)) {
			var n = t[0], r = t[1];
			e.setAttribute(n, r);
		}
		this.classes.length > 0 && (e.className = Oe(this.classes));
		for (var i = 0; i < this.children.length; i++) if (this.children[i] instanceof wn && this.children[i + 1] instanceof wn) {
			for (var a = this.children[i].toText() + this.children[++i].toText(); this.children[i + 1] instanceof wn;) a += this.children[++i].toText();
			e.appendChild(new wn(a).toNode());
		} else e.appendChild(this.children[i].toNode());
		return e;
	}
	toMarkup() {
		var e = "<" + this.type;
		for (var t of Object.entries(this.attributes)) {
			var n = t[0], r = t[1];
			e += " " + n + "=\"", e += o(r), e += "\"";
		}
		this.classes.length > 0 && (e += " class =\"" + o(Oe(this.classes)) + "\""), e += ">";
		for (var i = 0; i < this.children.length; i++) e += this.children[i].toMarkup();
		return e += "</" + this.type + ">", e;
	}
	toText() {
		return this.children.map((e) => e.toText()).join("");
	}
}, wn = class {
	constructor(e) {
		this.text = void 0, this.text = e;
	}
	toNode() {
		return document.createTextNode(this.text);
	}
	toMarkup() {
		return o(this.toText());
	}
	toText() {
		return this.text;
	}
}, Tn = class {
	constructor(e) {
		this.width = void 0, this.character = void 0, this.width = e, this.character = e >= .05555 && e <= .05556 ? " " : e >= .1666 && e <= .1667 ? " " : e >= .2222 && e <= .2223 ? " " : e >= .2777 && e <= .2778 ? "  " : e >= -.05556 && e <= -.05555 ? " ⁣" : e >= -.1667 && e <= -.1666 ? " ⁣" : e >= -.2223 && e <= -.2222 ? " ⁣" : e >= -.2778 && e <= -.2777 ? " ⁣" : null;
	}
	toNode() {
		if (this.character) return document.createTextNode(this.character);
		var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace");
		return e.setAttribute("width", O(this.width)), e;
	}
	toMarkup() {
		return this.character ? "<mtext>" + this.character + "</mtext>" : "<mspace width=\"" + O(this.width) + "\"/>";
	}
	toText() {
		return this.character ? this.character : " ";
	}
}, En = /* @__PURE__ */ new Set(["\\imath", "\\jmath"]), Dn = /* @__PURE__ */ new Set(["mrow", "mtable"]), On = function(e, t, n) {
	var r, i;
	return k[t][e] && k[t][e].replace && e.charCodeAt(0) !== 55349 && (!Object.prototype.hasOwnProperty.call(rt, e) || (n == null || (r = n.fontFamily) == null ? void 0 : r.slice(4, 6)) !== "tt" && (n == null || (i = n.font) == null ? void 0 : i.slice(4, 6)) !== "tt") && (e = k[t][e].replace), new wn(e);
}, kn = function(e) {
	return e.length === 1 ? e[0] : new J("mrow", e);
}, An = {
	mathit: "italic",
	boldsymbol: (e) => e.type === "textord" ? "bold" : "bold-italic",
	mathbf: "bold",
	mathbb: "double-struck",
	mathsfit: "sans-serif-italic",
	mathfrak: "fraktur",
	mathscr: "script",
	mathcal: "script",
	mathsf: "sans-serif",
	mathtt: "monospace"
}, jn = (e, t) => {
	if (e.mode === "text") {
		if (t.fontFamily === "texttt") return "monospace";
		if (t.fontFamily === "textsf") return t.fontShape === "textit" && t.fontWeight === "textbf" ? "sans-serif-bold-italic" : t.fontShape === "textit" ? "sans-serif-italic" : t.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
		if (t.fontShape === "textit" && t.fontWeight === "textbf") return "bold-italic";
		if (t.fontShape === "textit") return "italic";
		if (t.fontWeight === "textbf") return "bold";
	}
	var n = t.font;
	if (!n || n === "mathnormal") return null;
	var r = e.mode, i = An[n];
	if (i) return typeof i == "function" ? i(e) : i;
	var a = e.text;
	if (En.has(a)) return null;
	if (k[r][a]) {
		var o = k[r][a].replace;
		o && (a = o);
	}
	var s = Zt[n].fontName;
	return Ye(a, s, r) ? Zt[n].variant : null;
};
function Mn(e) {
	if (!e) return !1;
	if (e.type === "mi" && e.children.length === 1) {
		var t = e.children[0];
		return t instanceof wn && t.text === ".";
	}
	if (e.type === "mo" && e.children.length === 1 && e.getAttribute("separator") === "true" && e.getAttribute("lspace") === "0em" && e.getAttribute("rspace") === "0em") {
		var n = e.children[0];
		return n instanceof wn && n.text === ",";
	}
	return !1;
}
var Nn = function(e, t, n) {
	if (e.length === 1) {
		var r = Y(e[0], t);
		return n && r instanceof J && r.type === "mo" && (r.setAttribute("lspace", "0em"), r.setAttribute("rspace", "0em")), [r];
	}
	for (var i = [], a, o = 0; o < e.length; o++) {
		var s = Y(e[o], t);
		if (s instanceof J && a instanceof J) {
			if (s.type === "mtext" && a.type === "mtext" && s.getAttribute("mathvariant") === a.getAttribute("mathvariant") || s.type === "mn" && a.type === "mn" || Mn(s) && a.type === "mn") {
				a.children.push(...s.children);
				continue;
			}
			if (s.type === "mn" && Mn(a)) s.children = [...a.children, ...s.children], i.pop();
			else if ((s.type === "msup" || s.type === "msub") && s.children.length >= 1 && (a.type === "mn" || Mn(a))) {
				var c = s.children[0];
				c instanceof J && c.type === "mn" && (c.children = [...a.children, ...c.children], i.pop());
			} else if (a.type === "mi" && a.children.length === 1) {
				var l = a.children[0];
				if (l instanceof wn && l.text === "̸" && (s.type === "mo" || s.type === "mi" || s.type === "mn")) {
					var u = s.children[0];
					u instanceof wn && u.text.length > 0 && (u.text = u.text.slice(0, 1) + "̸" + u.text.slice(1), i.pop());
				}
			}
		}
		i.push(s), a = s;
	}
	return i;
}, Pn = function(e, t, n) {
	return kn(Nn(e, t, n));
}, Y = function(e, n) {
	if (!e) return new J("mrow");
	if (sn[e.type]) return sn[e.type](e, n);
	throw new t("Got group of unknown type: '" + e.type + "'");
};
function Fn(e, t, n, r, i) {
	var a = Nn(e, n), o = a.length === 1 && a[0] instanceof J && Dn.has(a[0].type) ? a[0] : new J("mrow", a), s = new J("annotation", [new wn(t)]);
	s.setAttribute("encoding", "application/x-tex");
	var c = new J("math", [new J("semantics", [o, s])]);
	return c.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), r && c.setAttribute("display", "block"), U([i ? "katex" : "katex-mathml"], [c]);
}
var In = [
	[
		1,
		1,
		1
	],
	[
		2,
		1,
		1
	],
	[
		3,
		1,
		1
	],
	[
		4,
		2,
		1
	],
	[
		5,
		2,
		1
	],
	[
		6,
		3,
		1
	],
	[
		7,
		4,
		2
	],
	[
		8,
		6,
		3
	],
	[
		9,
		7,
		6
	],
	[
		10,
		8,
		7
	],
	[
		11,
		10,
		9
	]
], Ln = [
	.5,
	.6,
	.7,
	.8,
	.9,
	1,
	1.2,
	1.44,
	1.728,
	2.074,
	2.488
], Rn = function(e, t) {
	return t.size < 2 ? e : In[e - 1][t.size - 1];
}, zn = class e {
	constructor(t) {
		this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.strict = void 0, this.style = t.style, this.color = t.color, this.size = t.size || e.BASESIZE, this.textSize = t.textSize || this.size, this.phantom = !!t.phantom, this.font = t.font || "", this.fontFamily = t.fontFamily || "", this.fontWeight = t.fontWeight || "", this.fontShape = t.fontShape || "", this.sizeMultiplier = Ln[this.size - 1], this.maxSize = t.maxSize, this.minRuleThickness = t.minRuleThickness, this.strict = t.strict, this._fontMetrics = void 0;
	}
	extend(t) {
		var n = {
			style: this.style,
			size: this.size,
			textSize: this.textSize,
			color: this.color,
			phantom: this.phantom,
			font: this.font,
			fontFamily: this.fontFamily,
			fontWeight: this.fontWeight,
			fontShape: this.fontShape,
			maxSize: this.maxSize,
			minRuleThickness: this.minRuleThickness,
			strict: this.strict
		};
		return Object.assign(n, t), new e(n);
	}
	havingStyle(e) {
		return this.style === e ? this : this.extend({
			style: e,
			size: Rn(this.textSize, e)
		});
	}
	havingCrampedStyle() {
		return this.havingStyle(this.style.cramp());
	}
	havingSize(e) {
		return this.size === e && this.textSize === e ? this : this.extend({
			style: this.style.text(),
			size: e,
			textSize: e,
			sizeMultiplier: Ln[e - 1]
		});
	}
	havingBaseStyle(t) {
		t ||= this.style.text();
		var n = Rn(e.BASESIZE, t);
		return this.size === n && this.textSize === e.BASESIZE && this.style === t ? this : this.extend({
			style: t,
			size: n
		});
	}
	havingBaseSizing() {
		var e;
		switch (this.style.id) {
			case 4:
			case 5:
				e = 3;
				break;
			case 6:
			case 7:
				e = 1;
				break;
			default: e = 6;
		}
		return this.extend({
			style: this.style.text(),
			size: e
		});
	}
	withColor(e) {
		return this.extend({ color: e });
	}
	withPhantom() {
		return this.extend({ phantom: !0 });
	}
	withFont(e) {
		return this.extend({ font: e });
	}
	withTextFontFamily(e) {
		return this.extend({
			fontFamily: e,
			font: ""
		});
	}
	withTextFontWeight(e) {
		return this.extend({
			fontWeight: e,
			font: ""
		});
	}
	withTextFontShape(e) {
		return this.extend({
			fontShape: e,
			font: ""
		});
	}
	sizingClasses(e) {
		return e.size === this.size ? [] : [
			"katex-sizing",
			"reset-size" + e.size,
			"size" + this.size
		];
	}
	baseSizingClasses() {
		return this.size === e.BASESIZE ? [] : [
			"katex-sizing",
			"reset-size" + this.size,
			"size" + e.BASESIZE
		];
	}
	fontMetrics() {
		return this._fontMetrics ||= Ze(this.size), this._fontMetrics;
	}
	getColor() {
		return this.phantom ? "transparent" : this.color;
	}
};
zn.BASESIZE = 6;
var Bn = (e) => new zn({
	style: e.displayMode ? T.DISPLAY : T.TEXT,
	maxSize: e.maxSize,
	minRuleThickness: e.minRuleThickness,
	strict: e.strict
}), Vn = function(e, t) {
	if (t.displayMode) {
		var n = ["katex-display"];
		t.leqno && n.push("leqno"), t.fleqn && n.push("fleqn"), e = U(n, [e]);
	}
	return e;
}, Hn = function(e, t, n) {
	var r = Bn(n), i;
	return n.output === "mathml" ? Fn(e, t, r, n.displayMode, !0) : (i = n.output === "html" ? U(["katex"], [Sn(e, r)]) : U(["katex"], [Fn(e, t, r, n.displayMode, !1), Sn(e, r)]), Vn(i, n));
}, Un = function(e, t) {
	return Vn(U(["katex"], [Sn(e, Bn(t))]), t);
}, Wn = {
	widehat: "^",
	widecheck: "ˇ",
	widetilde: "~",
	utilde: "~",
	overleftarrow: "←",
	underleftarrow: "←",
	xleftarrow: "←",
	overrightarrow: "→",
	underrightarrow: "→",
	xrightarrow: "→",
	underbrace: "⏟",
	overbrace: "⏞",
	underbracket: "⎵",
	overbracket: "⎴",
	overgroup: "⏠",
	undergroup: "⏡",
	overleftrightarrow: "↔",
	underleftrightarrow: "↔",
	xleftrightarrow: "↔",
	Overrightarrow: "⇒",
	xRightarrow: "⇒",
	overleftharpoon: "↼",
	xleftharpoonup: "↼",
	overrightharpoon: "⇀",
	xrightharpoonup: "⇀",
	xLeftarrow: "⇐",
	xLeftrightarrow: "⇔",
	xhookleftarrow: "↩",
	xhookrightarrow: "↪",
	xmapsto: "↦",
	xrightharpoondown: "⇁",
	xleftharpoondown: "↽",
	xrightleftharpoons: "⇌",
	xleftrightharpoons: "⇋",
	xtwoheadleftarrow: "↞",
	xtwoheadrightarrow: "↠",
	xlongequal: "=",
	xtofrom: "⇄",
	xrightleftarrows: "⇄",
	xrightequilibrium: "⇌",
	xleftequilibrium: "⇋",
	"\\cdrightarrow": "→",
	"\\cdleftarrow": "←",
	"\\cdlongequal": "="
}, Gn = function(e) {
	var t = new J("mo", [new wn(Wn[e.replace(/^\\/, "")])]);
	return t.setAttribute("stretchy", "true"), t;
}, Kn = {
	overrightarrow: [
		["rightarrow"],
		.888,
		522,
		"xMaxYMin"
	],
	overleftarrow: [
		["leftarrow"],
		.888,
		522,
		"xMinYMin"
	],
	underrightarrow: [
		["rightarrow"],
		.888,
		522,
		"xMaxYMin"
	],
	underleftarrow: [
		["leftarrow"],
		.888,
		522,
		"xMinYMin"
	],
	xrightarrow: [
		["rightarrow"],
		1.469,
		522,
		"xMaxYMin"
	],
	"\\cdrightarrow": [
		["rightarrow"],
		3,
		522,
		"xMaxYMin"
	],
	xleftarrow: [
		["leftarrow"],
		1.469,
		522,
		"xMinYMin"
	],
	"\\cdleftarrow": [
		["leftarrow"],
		3,
		522,
		"xMinYMin"
	],
	Overrightarrow: [
		["doublerightarrow"],
		.888,
		560,
		"xMaxYMin"
	],
	xRightarrow: [
		["doublerightarrow"],
		1.526,
		560,
		"xMaxYMin"
	],
	xLeftarrow: [
		["doubleleftarrow"],
		1.526,
		560,
		"xMinYMin"
	],
	overleftharpoon: [
		["leftharpoon"],
		.888,
		522,
		"xMinYMin"
	],
	xleftharpoonup: [
		["leftharpoon"],
		.888,
		522,
		"xMinYMin"
	],
	xleftharpoondown: [
		["leftharpoondown"],
		.888,
		522,
		"xMinYMin"
	],
	overrightharpoon: [
		["rightharpoon"],
		.888,
		522,
		"xMaxYMin"
	],
	xrightharpoonup: [
		["rightharpoon"],
		.888,
		522,
		"xMaxYMin"
	],
	xrightharpoondown: [
		["rightharpoondown"],
		.888,
		522,
		"xMaxYMin"
	],
	xlongequal: [
		["longequal"],
		.888,
		334,
		"xMinYMin"
	],
	"\\cdlongequal": [
		["longequal"],
		3,
		334,
		"xMinYMin"
	],
	xtwoheadleftarrow: [
		["twoheadleftarrow"],
		.888,
		334,
		"xMinYMin"
	],
	xtwoheadrightarrow: [
		["twoheadrightarrow"],
		.888,
		334,
		"xMaxYMin"
	],
	overleftrightarrow: [
		["leftarrow", "rightarrow"],
		.888,
		522
	],
	overbrace: [
		[
			"leftbrace",
			"midbrace",
			"rightbrace"
		],
		1.6,
		548
	],
	underbrace: [
		[
			"leftbraceunder",
			"midbraceunder",
			"rightbraceunder"
		],
		1.6,
		548
	],
	underleftrightarrow: [
		["leftarrow", "rightarrow"],
		.888,
		522
	],
	xleftrightarrow: [
		["leftarrow", "rightarrow"],
		1.75,
		522
	],
	xLeftrightarrow: [
		["doubleleftarrow", "doublerightarrow"],
		1.75,
		560
	],
	xrightleftharpoons: [
		["leftharpoondownplus", "rightharpoonplus"],
		1.75,
		716
	],
	xleftrightharpoons: [
		["leftharpoonplus", "rightharpoondownplus"],
		1.75,
		716
	],
	xhookleftarrow: [
		["leftarrow", "righthook"],
		1.08,
		522
	],
	xhookrightarrow: [
		["lefthook", "rightarrow"],
		1.08,
		522
	],
	overlinesegment: [
		["leftlinesegment", "rightlinesegment"],
		.888,
		522
	],
	underlinesegment: [
		["leftlinesegment", "rightlinesegment"],
		.888,
		522
	],
	overbracket: [
		["leftbracketover", "rightbracketover"],
		1.6,
		440
	],
	underbracket: [
		["leftbracketunder", "rightbracketunder"],
		1.6,
		410
	],
	overgroup: [
		["leftgroup", "rightgroup"],
		.888,
		342
	],
	undergroup: [
		["leftgroupunder", "rightgroupunder"],
		.888,
		342
	],
	xmapsto: [
		["leftmapsto", "rightarrow"],
		1.5,
		522
	],
	xtofrom: [
		["leftToFrom", "rightToFrom"],
		1.75,
		528
	],
	xrightleftarrows: [
		["baraboveleftarrow", "rightarrowabovebar"],
		1.75,
		901
	],
	xrightequilibrium: [
		["baraboveshortleftharpoon", "rightharpoonaboveshortbar"],
		1.75,
		716
	],
	xleftequilibrium: [
		["shortbaraboveleftharpoon", "shortrightharpoonabovebar"],
		1.75,
		716
	]
}, qn = /* @__PURE__ */ new Set([
	"widehat",
	"widecheck",
	"widetilde",
	"utilde"
]), Jn = function(e, t) {
	function n() {
		var n = 4e5, r = e.label.slice(1);
		if (qn.has(r) && "base" in e) {
			var i = e.base.type === "ordgroup" ? e.base.body.length : 1, a, o, s;
			if (i > 5) r === "widehat" || r === "widecheck" ? (a = 420, n = 2364, s = .42, o = r + "4") : (a = 312, n = 2340, s = .34, o = "tilde4");
			else {
				var c = [
					1,
					1,
					2,
					2,
					3,
					3
				][i];
				r === "widehat" || r === "widecheck" ? (n = [
					0,
					1062,
					2364,
					2364,
					2364
				][c], a = [
					0,
					239,
					300,
					360,
					420
				][c], s = [
					0,
					.24,
					.3,
					.3,
					.36,
					.42
				][c], o = r + c) : (n = [
					0,
					600,
					1033,
					2339,
					2340
				][c], a = [
					0,
					260,
					286,
					306,
					312
				][c], s = [
					0,
					.26,
					.286,
					.3,
					.306,
					.34
				][c], o = "tilde" + c);
			}
			return {
				span: Ut([], [new ze([new Be(o)], {
					width: "100%",
					height: O(s),
					viewBox: "0 0 " + n + " " + a,
					preserveAspectRatio: "none"
				})], t),
				minWidth: 0,
				height: s
			};
		}
		var l = [], u = Kn[r];
		if (!u) throw Error("No SVG data for \"" + r + "\".");
		var d = u[0], f = u[1], p = u[2], m = p / 1e3, h = d.length, g, _;
		if (h === 1) {
			if (u.length !== 4) throw Error("Expected 4-tuple for single-path SVG data \"" + r + "\".");
			g = ["hide-tail"], _ = [u[3]];
		} else if (h === 2) g = ["halfarrow-left", "halfarrow-right"], _ = ["xMinYMin", "xMaxYMin"];
		else if (h === 3) g = [
			"brace-left",
			"brace-center",
			"brace-right"
		], _ = [
			"xMinYMin",
			"xMidYMin",
			"xMaxYMin"
		];
		else throw Error("Correct katexImagesData or update code here to support\n                    " + h + " children.");
		for (var v = 0; v < h; v++) {
			var y = new ze([new Be(d[v])], {
				width: "400em",
				height: O(m),
				viewBox: "0 0 " + n + " " + p,
				preserveAspectRatio: _[v] + " slice"
			}), b = Ut([g[v]], [y], t);
			if (h === 1) return {
				span: b,
				minWidth: f,
				height: m
			};
			b.style.height = O(m), l.push(b);
		}
		return {
			span: U(["katex-stretchy"], l, t),
			minWidth: f,
			height: m
		};
	}
	var r = n(), i = r.span, a = r.minWidth, o = r.height;
	return i.height = o, i.style.height = O(o), a > 0 && (i.style.minWidth = O(a)), i;
}, Yn = function(e, t, n, r, i) {
	var a, o = e.height + e.depth + n + r;
	if (/fbox|color|angl/.test(t)) {
		if (a = U(["katex-stretchy", t], [], i), t === "fbox") {
			var s = i.color && i.getColor();
			s && (a.style.borderColor = s);
		}
	} else {
		var c = [];
		/^[bx]cancel$/.test(t) && c.push(new Ve({
			x1: "0",
			y1: "0",
			x2: "100%",
			y2: "100%",
			"stroke-width": "0.046em"
		})), /^x?cancel$/.test(t) && c.push(new Ve({
			x1: "0",
			y1: "100%",
			x2: "100%",
			y2: "0",
			"stroke-width": "0.046em"
		})), a = Ut([], [new ze(c, {
			width: "100%",
			height: O(o)
		})], i);
	}
	return a.height = o, a.style.height = O(o), a;
}, Xn = [
	"bin",
	"close",
	"inner",
	"open",
	"punct",
	"rel"
], Zn = [
	"accent-token",
	"mathord",
	"op-token",
	"spacing",
	"textord"
], Qn = new Set(Xn), $n = new Set(Zn);
function er(e) {
	return Qn.has(e);
}
function X(e, t) {
	if (!e || e.type !== t) throw Error("Expected node of type " + t + ", but got " + (e ? "node of type " + e.type : String(e)));
	return e;
}
function tr(e) {
	var t = nr(e);
	if (!t) throw Error("Expected node of symbol group type, but got " + (e ? "node of type " + e.type : String(e)));
	return t;
}
function nr(e) {
	return e.type === "atom" || $n.has(e.type) ? e : null;
}
function rr(e, n, r) {
	var i = "";
	for (var a of e.body) if (a.type === "textord") i += a.text;
	else if (r && a.type === "spacing" && a.text === " ") i += " ";
	else throw new t(n, e);
	return i;
}
var ir = (e) => {
	if (e instanceof Re) return e;
	if (We(e) && e.children.length === 1) return ir(e.children[0]);
}, ar = (e, t) => {
	var n, r, i;
	e && e.type === "supsub" ? (r = X(e.base, "accent"), n = r.base, e.base = n, i = Ue(q(e, t)), e.base = r) : (r = X(e, "accent"), n = r.base);
	var a = q(n, t.havingCrampedStyle()), o = r.isShifty && l(n), s = 0;
	o && (s = ir(a)?.skew ?? 0);
	var c = r.label === "\\c", u = c ? a.height + a.depth : Math.min(a.height, t.fontMetrics().xHeight), d;
	if (r.isStretchy) d = Jn(r, t), d = W({
		positionType: "firstBaseline",
		children: [{
			type: "elem",
			elem: a
		}, {
			type: "elem",
			elem: d,
			wrapperClasses: ["svg-align"],
			wrapperStyle: s > 0 ? {
				width: "calc(100% - " + O(2 * s) + ")",
				marginLeft: O(2 * s)
			} : void 0
		}]
	});
	else {
		var f, p;
		r.label === "\\vec" ? (f = $t("vec", t), p = Qt.vec[1]) : (f = zt({
			type: "textord",
			mode: r.mode,
			text: r.label
		}, t), f = He(f), f.italic = 0, p = f.width, c && (u += f.depth)), d = U(["accent-body"], [f]);
		var m = r.label === "\\textcircled";
		m && (d.classes.push("accent-full"), u = a.height);
		var h = s;
		m || (h -= p / 2), d.style.left = O(h), r.label === "\\textcircled" && (d.style.top = ".2em"), d = W({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: a
				},
				{
					type: "kern",
					size: -u
				},
				{
					type: "elem",
					elem: d
				}
			]
		});
	}
	var g = U(["mord", "katex-accent"], [d], t);
	return i ? (i.children[0] = g, i.height = Math.max(g.height, i.height), i.classes[0] = "mord", i) : g;
}, or = (e, t) => {
	var n = e.isStretchy ? Gn(e.label) : new J("mo", [On(e.label, e.mode)]), r = new J("mover", [Y(e.base, t), n]);
	return r.setAttribute("accent", "true"), r;
}, sr = new RegExp([
	"\\acute",
	"\\grave",
	"\\ddot",
	"\\tilde",
	"\\bar",
	"\\breve",
	"\\check",
	"\\hat",
	"\\vec",
	"\\dot",
	"\\mathring"
].map((e) => "\\" + e).join("|"));
K({
	type: "accent",
	names: [
		"\\acute",
		"\\grave",
		"\\ddot",
		"\\tilde",
		"\\bar",
		"\\breve",
		"\\check",
		"\\hat",
		"\\vec",
		"\\dot",
		"\\mathring",
		"\\widecheck",
		"\\widehat",
		"\\widetilde",
		"\\overrightarrow",
		"\\overleftarrow",
		"\\Overrightarrow",
		"\\overleftrightarrow",
		"\\overgroup",
		"\\overlinesegment",
		"\\overleftharpoon",
		"\\overrightharpoon"
	],
	numArgs: 1,
	handler: (e, t) => {
		var n = ln(t[0]), r = !sr.test(e.funcName), i = !r || e.funcName === "\\widehat" || e.funcName === "\\widetilde" || e.funcName === "\\widecheck";
		return {
			type: "accent",
			mode: e.parser.mode,
			label: e.funcName,
			isStretchy: r,
			isShifty: i,
			base: n
		};
	},
	htmlBuilder: ar,
	mathmlBuilder: or
}), K({
	type: "accent",
	names: [
		"\\'",
		"\\`",
		"\\^",
		"\\~",
		"\\=",
		"\\u",
		"\\.",
		"\\\"",
		"\\c",
		"\\r",
		"\\H",
		"\\v",
		"\\textcircled"
	],
	numArgs: 1,
	allowedInText: !0,
	allowedInMath: !0,
	argTypes: ["primitive"],
	handler: (e, t) => {
		var n = t[0], r = e.parser.mode;
		return r === "math" && (Pt({
			strict: e.parser.settings.strict,
			errorCode: "mathVsTextAccents",
			errorMsg: "LaTeX's accent " + e.funcName + " works only in text mode",
			report: !0
		}), r = "text"), {
			type: "accent",
			mode: r,
			label: e.funcName,
			isStretchy: !1,
			isShifty: !0,
			base: n
		};
	}
}), K({
	type: "accentUnder",
	names: [
		"\\underleftarrow",
		"\\underrightarrow",
		"\\underleftrightarrow",
		"\\undergroup",
		"\\underlinesegment",
		"\\utilde"
	],
	numArgs: 1,
	handler: (e, t) => {
		var n = e.parser, r = e.funcName, i = t[0];
		return {
			type: "accentUnder",
			mode: n.mode,
			label: r,
			base: i
		};
	},
	htmlBuilder: (e, t) => {
		var n = q(e.base, t), r = Jn(e, t), i = e.label === "\\utilde" ? .12 : 0;
		return U(["mord", "accentunder"], [W({
			positionType: "top",
			positionData: n.height,
			children: [
				{
					type: "elem",
					elem: r,
					wrapperClasses: ["svg-align"]
				},
				{
					type: "kern",
					size: i
				},
				{
					type: "elem",
					elem: n
				}
			]
		})], t);
	},
	mathmlBuilder: (e, t) => {
		var n = Gn(e.label), r = new J("munder", [Y(e.base, t), n]);
		return r.setAttribute("accentunder", "true"), r;
	}
});
var cr = (e) => {
	var t = new J("mpadded", e ? [e] : []);
	return t.setAttribute("width", "+0.6em"), t.setAttribute("lspace", "0.3em"), t;
};
K({
	type: "xArrow",
	names: [
		"\\xleftarrow",
		"\\xrightarrow",
		"\\xLeftarrow",
		"\\xRightarrow",
		"\\xleftrightarrow",
		"\\xLeftrightarrow",
		"\\xhookleftarrow",
		"\\xhookrightarrow",
		"\\xmapsto",
		"\\xrightharpoondown",
		"\\xrightharpoonup",
		"\\xleftharpoondown",
		"\\xleftharpoonup",
		"\\xrightleftharpoons",
		"\\xleftrightharpoons",
		"\\xlongequal",
		"\\xtwoheadrightarrow",
		"\\xtwoheadleftarrow",
		"\\xtofrom",
		"\\xrightleftarrows",
		"\\xrightequilibrium",
		"\\xleftequilibrium",
		"\\\\cdrightarrow",
		"\\\\cdleftarrow",
		"\\\\cdlongequal"
	],
	numArgs: 1,
	numOptionalArgs: 1,
	handler(e, t, n) {
		var r = e.parser, i = e.funcName;
		return {
			type: "xArrow",
			mode: r.mode,
			label: i,
			body: t[0],
			below: n[0]
		};
	},
	htmlBuilder(e, t) {
		var n = t.style, r = t.havingStyle(n.sup()), i = qt(q(e.body, r, t), t), a = e.label.slice(0, 2) === "\\x" ? "x" : "cd";
		i.classes.push(a + "-arrow-pad");
		var o;
		e.below && (r = t.havingStyle(n.sub()), o = qt(q(e.below, r, t), t), o.classes.push(a + "-arrow-pad"));
		var s = Jn(e, t), c = -t.fontMetrics().axisHeight + .5 * s.height, l = -t.fontMetrics().axisHeight - .5 * s.height - .111;
		(i.depth > .25 || e.label === "\\xleftequilibrium") && (l -= i.depth);
		var u;
		if (o) {
			var d = -t.fontMetrics().axisHeight + o.height + .5 * s.height + .111;
			u = W({
				positionType: "individualShift",
				children: [
					{
						type: "elem",
						elem: i,
						shift: l
					},
					{
						type: "elem",
						elem: s,
						shift: c,
						wrapperClasses: ["svg-align"]
					},
					{
						type: "elem",
						elem: o,
						shift: d
					}
				]
			});
		} else u = W({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: i,
				shift: l
			}, {
				type: "elem",
				elem: s,
				shift: c,
				wrapperClasses: ["svg-align"]
			}]
		});
		return U(["mrel", "x-arrow"], [u], t);
	},
	mathmlBuilder(e, t) {
		var n = Gn(e.label);
		n.setAttribute("minsize", e.label.charAt(0) === "x" ? "1.75em" : "3.0em");
		var r;
		if (e.body) {
			var i = cr(Y(e.body, t));
			r = e.below ? new J("munderover", [
				n,
				cr(Y(e.below, t)),
				i
			]) : new J("mover", [n, i]);
		} else e.below ? r = new J("munder", [n, cr(Y(e.below, t))]) : (r = cr(), r = new J("mover", [n, r]));
		return r;
	}
});
function lr(e, t) {
	var n = hn(e.body, t, !0);
	return U([e.mclass], n, t);
}
function ur(e, t) {
	var n, r = Nn(e.body, t);
	return e.mclass === "minner" ? n = new J("mpadded", r) : e.mclass === "mord" ? e.isCharacterBox ? (n = r[0], n.type = "mi") : n = new J("mi", r) : (e.isCharacterBox ? (n = r[0], n.type = "mo") : n = new J("mo", r), e.mclass === "mbin" ? (n.attributes.lspace = "0.22em", n.attributes.rspace = "0.22em") : e.mclass === "mpunct" ? (n.attributes.lspace = "0em", n.attributes.rspace = "0.17em") : (e.mclass === "mopen" || e.mclass === "mclose") && (n.attributes.lspace = "0em", n.attributes.rspace = "0em")), n;
}
K({
	type: "mclass",
	names: [
		"\\mathord",
		"\\mathbin",
		"\\mathrel",
		"\\mathopen",
		"\\mathclose",
		"\\mathpunct",
		"\\mathinner"
	],
	numArgs: 1,
	primitive: !0,
	handler(e, t) {
		var n = e.parser, r = e.funcName, i = t[0];
		return {
			type: "mclass",
			mode: n.mode,
			mclass: "m" + r.slice(5),
			body: un(i),
			isCharacterBox: l(i)
		};
	},
	htmlBuilder: lr,
	mathmlBuilder: ur
});
var dr = (e) => {
	var t = e.type === "ordgroup" && e.body.length ? e.body[0] : e;
	return t.type === "atom" && (t.family === "bin" || t.family === "rel") ? "m" + t.family : "mord";
};
K({
	type: "mclass",
	names: ["\\@binrel"],
	numArgs: 2,
	handler(e, t) {
		return {
			type: "mclass",
			mode: e.parser.mode,
			mclass: dr(t[0]),
			body: un(t[1]),
			isCharacterBox: l(t[1])
		};
	}
}), K({
	type: "mclass",
	names: [
		"\\stackrel",
		"\\overset",
		"\\underset"
	],
	numArgs: 2,
	handler(e, t) {
		var n = e.parser, r = e.funcName, i = t[1], a = t[0], o = r === "\\stackrel" ? "mrel" : dr(i), s = {
			type: "op",
			mode: i.mode,
			limits: !0,
			alwaysHandleSupSub: !0,
			parentIsSupSub: !1,
			symbol: !1,
			suppressBaseShift: r !== "\\stackrel",
			body: un(i)
		}, c = r === "\\underset" ? {
			type: "supsub",
			mode: a.mode,
			base: s,
			sub: a
		} : {
			type: "supsub",
			mode: a.mode,
			base: s,
			sup: a
		};
		return {
			type: "mclass",
			mode: n.mode,
			mclass: o,
			body: [c],
			isCharacterBox: l(c)
		};
	}
}), K({
	type: "pmb",
	names: ["\\pmb"],
	numArgs: 1,
	allowedInText: !0,
	handler(e, t) {
		return {
			type: "pmb",
			mode: e.parser.mode,
			mclass: dr(t[0]),
			body: un(t[0])
		};
	},
	htmlBuilder(e, t) {
		var n = hn(e.body, t, !0), r = U([e.mclass], n, t);
		return r.style.textShadow = "0.02em 0.01em 0.04px", r;
	},
	mathmlBuilder(e, t) {
		var n = new J("mstyle", Nn(e.body, t));
		return n.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), n;
	}
});
var fr = {
	">": "\\\\cdrightarrow",
	"<": "\\\\cdleftarrow",
	"=": "\\\\cdlongequal",
	A: "\\uparrow",
	V: "\\downarrow",
	"|": "\\Vert",
	".": "no arrow"
}, pr = () => ({
	type: "styling",
	body: [],
	mode: "math",
	style: "display",
	resetFont: !0
}), mr = (e) => e.type === "textord" && e.text === "@", hr = (e, t) => (e.type === "mathord" || e.type === "atom") && e.text === t;
function gr(e, t, n) {
	var r = fr[e];
	switch (r) {
		case "\\\\cdrightarrow":
		case "\\\\cdleftarrow": return n.callFunction(r, [t[0]], [t[1]]);
		case "\\uparrow":
		case "\\downarrow":
			var i = n.callFunction("\\\\cdleft", [t[0]], []), a = {
				type: "atom",
				text: r,
				mode: "math",
				family: "rel"
			}, o = {
				type: "ordgroup",
				mode: "math",
				body: [
					i,
					n.callFunction("\\Big", [a], []),
					n.callFunction("\\\\cdright", [t[1]], [])
				]
			};
			return n.callFunction("\\\\cdparent", [o], []);
		case "\\\\cdlongequal": return n.callFunction("\\\\cdlongequal", [], []);
		case "\\Vert": return n.callFunction("\\Big", [{
			type: "textord",
			text: "\\Vert",
			mode: "math"
		}], []);
		default: return {
			type: "textord",
			text: " ",
			mode: "math"
		};
	}
}
function _r(e) {
	var n = [];
	for (e.gullet.beginGroup(), e.gullet.macros.set("\\cr", "\\\\\\relax"), e.gullet.beginGroup();;) {
		n.push(e.parseExpression(!1, "\\\\")), e.gullet.endGroup(), e.gullet.beginGroup();
		var r = e.fetch().text;
		if (r === "&" || r === "\\\\") e.consume();
		else if (r === "\\end") {
			n[n.length - 1].length === 0 && n.pop();
			break;
		} else throw new t("Expected \\\\ or \\cr or \\end", e.nextToken);
	}
	for (var i = [], a = [i], o = 0; o < n.length; o++) {
		for (var s = n[o], c = pr(), l = 0; l < s.length; l++) if (!mr(s[l])) c.body.push(s[l]);
		else {
			i.push(c), l += 1;
			var u = tr(s[l]).text, d = [, ,];
			if (d[0] = {
				type: "ordgroup",
				mode: "math",
				body: []
			}, d[1] = {
				type: "ordgroup",
				mode: "math",
				body: []
			}, !"=|.".includes(u)) {
				if ("<>AV".includes(u)) for (var f = 0; f < 2; f++) {
					for (var p = !0, m = l + 1; m < s.length; m++) {
						if (hr(s[m], u)) {
							p = !1, l = m;
							break;
						}
						if (mr(s[m])) throw new t("Missing a " + u + " character to complete a CD arrow.", s[m]);
						d[f].body.push(s[m]);
					}
					if (p) throw new t("Missing a " + u + " character to complete a CD arrow.", s[l]);
				}
				else throw new t("Expected one of \"<>AV=|.\" after @", s[l]);
			}
			var h = {
				type: "styling",
				body: [gr(u, d, e)],
				mode: "math",
				style: "display",
				resetFont: !0
			};
			i.push(h), c = pr();
		}
		o % 2 == 0 ? i.push(c) : i.shift(), i = [], a.push(i);
	}
	return e.gullet.endGroup(), e.gullet.endGroup(), {
		type: "array",
		mode: "math",
		body: a,
		arraystretch: 1,
		addJot: !0,
		rowGaps: [null],
		cols: Array(a[0].length).fill({
			type: "align",
			align: "c",
			pregap: .25,
			postgap: .25
		}),
		colSeparationType: "CD",
		hLinesBeforeRow: Array(a.length + 1).fill([])
	};
}
K({
	type: "cdlabel",
	names: ["\\\\cdleft", "\\\\cdright"],
	numArgs: 1,
	handler(e, t) {
		var n = e.parser, r = e.funcName;
		return {
			type: "cdlabel",
			mode: n.mode,
			side: r.slice(4),
			label: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = t.havingStyle(t.style.sup()), r = qt(q(e.label, n, t), t);
		return r.classes.push("cd-label-" + e.side), r.style.bottom = O(.8 - r.depth), r.height = 0, r.depth = 0, r;
	},
	mathmlBuilder(e, t) {
		var n = new J("mrow", [Y(e.label, t)]);
		return n = new J("mpadded", [n]), n.setAttribute("width", "0"), e.side === "left" && n.setAttribute("lspace", "-1width"), n.setAttribute("voffset", "0.7em"), n = new J("mstyle", [n]), n.setAttribute("displaystyle", "false"), n.setAttribute("scriptlevel", "1"), n;
	}
}), K({
	type: "cdlabelparent",
	names: ["\\\\cdparent"],
	numArgs: 1,
	handler(e, t) {
		return {
			type: "cdlabelparent",
			mode: e.parser.mode,
			fragment: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = qt(q(e.fragment, t), t);
		return n.classes.push("cd-vert-arrow"), n;
	},
	mathmlBuilder(e, t) {
		return new J("mrow", [Y(e.fragment, t)]);
	}
}), K({
	type: "textord",
	names: ["\\@char"],
	numArgs: 1,
	allowedInText: !0,
	handler(e, n) {
		var r = e.parser, i = rr(X(n[0], "ordgroup"), "\\@char has non-numeric argument"), a = parseInt(i), o;
		if (isNaN(a)) throw new t("\\@char has non-numeric argument " + i);
		if (a < 0 || a > 1114111) throw new t("\\@char with invalid code point " + i);
		return a <= 65535 ? o = String.fromCharCode(a) : (a -= 65536, o = String.fromCharCode((a >> 10) + 55296, (a & 1023) + 56320)), {
			type: "textord",
			mode: r.mode,
			text: o
		};
	}
}), K({
	type: "color",
	names: ["\\textcolor"],
	numArgs: 2,
	allowedInText: !0,
	argTypes: ["color", "original"],
	handler(e, t) {
		var n = e.parser, r = X(t[0], "color-token").color, i = t[1];
		return {
			type: "color",
			mode: n.mode,
			color: r,
			body: un(i)
		};
	},
	htmlBuilder: (e, t) => Kt(hn(e.body, t.withColor(e.color), !1)),
	mathmlBuilder: (e, t) => {
		var n = new J("mstyle", Nn(e.body, t.withColor(e.color)));
		return n.setAttribute("mathcolor", e.color), n;
	}
}), K({
	type: "color",
	names: ["\\color"],
	numArgs: 1,
	allowedInText: !0,
	argTypes: ["color"],
	handler(e, t) {
		var n = e.parser, r = e.breakOnTokenText, i = X(t[0], "color-token").color;
		n.gullet.macros.set("\\current@color", i);
		var a = n.parseExpression(!0, r);
		return {
			type: "color",
			mode: n.mode,
			color: i,
			body: a
		};
	}
}), K({
	type: "cr",
	names: ["\\\\"],
	numArgs: 0,
	numOptionalArgs: 0,
	allowedInText: !0,
	handler(e) {
		var t = e.parser, n = t.gullet.future().text === "[" ? t.parseSizeGroup(!0) : null, r = !t.settings.displayMode || !Pt({
			strict: t.settings.strict,
			errorCode: "newLineInDisplayMode",
			errorMsg: "In LaTeX, \\\\ or \\newline does nothing in display mode",
			report: !1
		});
		return {
			type: "cr",
			mode: t.mode,
			newLine: r,
			size: n && X(n, "size").value
		};
	},
	htmlBuilder(e, t) {
		var n = U(["mspace"], [], t);
		return e.newLine && (n.classes.push("katex-newline"), e.size && (n.style.marginTop = O(D(e.size, t)))), n;
	},
	mathmlBuilder(e, t) {
		var n = new J("mspace");
		return e.newLine && (n.setAttribute("linebreak", "newline"), e.size && n.setAttribute("height", O(D(e.size, t)))), n;
	}
});
var vr = {
	"\\global": "\\global",
	"\\long": "\\\\globallong",
	"\\\\globallong": "\\\\globallong",
	"\\def": "\\gdef",
	"\\gdef": "\\gdef",
	"\\edef": "\\xdef",
	"\\xdef": "\\xdef",
	"\\let": "\\\\globallet",
	"\\futurelet": "\\\\globalfuture"
}, yr = (e) => {
	var n = e.text;
	if (/^(?:[\\{}$&#^_]|EOF)$/.test(n)) throw new t("Expected a control sequence", e);
	return n;
}, br = (e) => {
	var t = e.gullet.popToken();
	return t.text === "=" && (t = e.gullet.popToken(), t.text === " " && (t = e.gullet.popToken())), t;
}, xr = (e, t, n, r) => {
	var i = e.gullet.macros.get(n.text);
	i ??= (n.noexpand = !0, {
		tokens: [n],
		numArgs: 0,
		unexpandable: !e.gullet.isExpandable(n.text)
	}), e.gullet.macros.set(t, i, r);
};
K({
	type: "internal",
	names: [
		"\\global",
		"\\long",
		"\\\\globallong"
	],
	numArgs: 0,
	allowedInText: !0,
	handler(e) {
		var n = e.parser, r = e.funcName;
		n.consumeSpaces();
		var i = n.fetch();
		if (vr[i.text]) return (r === "\\global" || r === "\\\\globallong") && (i.text = vr[i.text]), X(n.parseFunction(), "internal");
		throw new t("Invalid token after macro prefix", i);
	}
}), K({
	type: "internal",
	names: [
		"\\def",
		"\\gdef",
		"\\edef",
		"\\xdef"
	],
	numArgs: 0,
	allowedInText: !0,
	primitive: !0,
	handler(e) {
		var n = e.parser, r = e.funcName, i = n.gullet.popToken(), a = i.text;
		if (/^(?:[\\{}$&#^_]|EOF)$/.test(a)) throw new t("Expected a control sequence", i);
		for (var o = 0, s, c = [[]]; n.gullet.future().text !== "{";) if (i = n.gullet.popToken(), i.text === "#") {
			if (n.gullet.future().text === "{") {
				s = n.gullet.future(), c[o].push("{");
				break;
			}
			if (i = n.gullet.popToken(), !/^[1-9]$/.test(i.text)) throw new t("Invalid argument number \"" + i.text + "\"");
			if (parseInt(i.text) !== o + 1) throw new t("Argument number \"" + i.text + "\" out of order");
			o++, c.push([]);
		} else if (i.text === "EOF") throw new t("Expected a macro definition");
		else c[o].push(i.text);
		var l = n.gullet.consumeArg().tokens;
		return s && l.unshift(s), (r === "\\edef" || r === "\\xdef") && (l = n.gullet.expandTokens(l), l.reverse()), n.gullet.macros.set(a, {
			tokens: l,
			numArgs: o,
			delimiters: c
		}, r === vr[r]), {
			type: "internal",
			mode: n.mode
		};
	}
}), K({
	type: "internal",
	names: ["\\let", "\\\\globallet"],
	numArgs: 0,
	allowedInText: !0,
	primitive: !0,
	handler(e) {
		var t = e.parser, n = e.funcName, r = yr(t.gullet.popToken());
		return t.gullet.consumeSpaces(), xr(t, r, br(t), n === "\\\\globallet"), {
			type: "internal",
			mode: t.mode
		};
	}
}), K({
	type: "internal",
	names: ["\\futurelet", "\\\\globalfuture"],
	numArgs: 0,
	allowedInText: !0,
	primitive: !0,
	handler(e) {
		var t = e.parser, n = e.funcName, r = yr(t.gullet.popToken()), i = t.gullet.popToken(), a = t.gullet.popToken();
		return xr(t, r, a, n === "\\\\globalfuture"), t.gullet.pushToken(a), t.gullet.pushToken(i), {
			type: "internal",
			mode: t.mode
		};
	}
});
var Sr = function(e, t, n) {
	var r = Ye(k.math[e] && k.math[e].replace || e, t, n);
	if (!r) throw Error("Unsupported symbol " + e + " and font size " + t + ".");
	return r;
}, Cr = function(e, t, n, r) {
	var i = n.havingBaseStyle(t), a = U(r.concat(i.sizingClasses(n)), [e], n), o = i.sizeMultiplier / n.sizeMultiplier;
	return a.height *= o, a.depth *= o, a.maxFontSize = i.sizeMultiplier, a;
}, wr = function(e, t, n) {
	var r = t.havingBaseStyle(n), i = (1 - t.sizeMultiplier / r.sizeMultiplier) * t.fontMetrics().axisHeight;
	e.classes.push("delimcenter"), e.style.top = O(i), e.height -= i, e.depth += i;
}, Tr = function(e, t, n, r, i, a) {
	var o = Cr(It(e, "Main-Regular", i, r), t, r, a);
	return n && wr(o, r, t), o;
}, Er = function(e, t, n, r) {
	return It(e, "Size" + t + "-Regular", n, r);
}, Dr = function(e, t, n, r, i, a) {
	var o = Er(e, t, i, r), s = Cr(U(["delimsizing", "size" + t], [o], r), T.TEXT, r, a);
	return n && wr(s, r, T.TEXT), s;
}, Or = function(e, t, n, r) {
	return {
		type: "elem",
		elem: U(["delimsizinginner", t === "Size1-Regular" ? "delim-size1" : "delim-size4"], [U([], [It(e, t, n, r)])])
	};
}, kr = function(e, t, n) {
	var r = Ge["Size4-Regular"][e.charCodeAt(0)] ? Ge["Size4-Regular"][e.charCodeAt(0)][4] : Ge["Size1-Regular"][e.charCodeAt(0)][4], i = Ut([], [new ze([new Be("inner", be(e, Math.round(1e3 * t)))], {
		width: O(r),
		height: O(t),
		style: "width:" + O(r),
		viewBox: "0 0 " + 1e3 * r + " " + Math.round(1e3 * t),
		preserveAspectRatio: "xMinYMin"
	})], n);
	return i.height = t, i.style.height = O(t), i.style.width = O(r), {
		type: "elem",
		elem: i
	};
}, Ar = .008, jr = {
	type: "kern",
	size: -1 * Ar
}, Mr = /* @__PURE__ */ new Set([
	"|",
	"\\lvert",
	"\\rvert",
	"\\vert"
]), Nr = /* @__PURE__ */ new Set([
	"\\|",
	"\\lVert",
	"\\rVert",
	"\\Vert"
]), Pr = function(e, t, n, r, i, a) {
	var o, s, c, l, u = "", d = 0;
	o = c = l = e, s = null;
	var f = "Size1-Regular";
	e === "\\uparrow" ? c = l = "⏐" : e === "\\Uparrow" ? c = l = "‖" : e === "\\downarrow" ? o = c = "⏐" : e === "\\Downarrow" ? o = c = "‖" : e === "\\updownarrow" ? (o = "\\uparrow", c = "⏐", l = "\\downarrow") : e === "\\Updownarrow" ? (o = "\\Uparrow", c = "‖", l = "\\Downarrow") : Mr.has(e) ? (c = "∣", u = "vert", d = 333) : Nr.has(e) ? (c = "∥", u = "doublevert", d = 556) : e === "[" || e === "\\lbrack" ? (o = "⎡", c = "⎢", l = "⎣", f = "Size4-Regular", u = "lbrack", d = 667) : e === "]" || e === "\\rbrack" ? (o = "⎤", c = "⎥", l = "⎦", f = "Size4-Regular", u = "rbrack", d = 667) : e === "\\lfloor" || e === "⌊" ? (c = o = "⎢", l = "⎣", f = "Size4-Regular", u = "lfloor", d = 667) : e === "\\lceil" || e === "⌈" ? (o = "⎡", c = l = "⎢", f = "Size4-Regular", u = "lceil", d = 667) : e === "\\rfloor" || e === "⌋" ? (c = o = "⎥", l = "⎦", f = "Size4-Regular", u = "rfloor", d = 667) : e === "\\rceil" || e === "⌉" ? (o = "⎤", c = l = "⎥", f = "Size4-Regular", u = "rceil", d = 667) : e === "(" || e === "\\lparen" ? (o = "⎛", c = "⎜", l = "⎝", f = "Size4-Regular", u = "lparen", d = 875) : e === ")" || e === "\\rparen" ? (o = "⎞", c = "⎟", l = "⎠", f = "Size4-Regular", u = "rparen", d = 875) : e === "\\{" || e === "\\lbrace" ? (o = "⎧", s = "⎨", l = "⎩", c = "⎪", f = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (o = "⎫", s = "⎬", l = "⎭", c = "⎪", f = "Size4-Regular") : e === "\\lgroup" || e === "⟮" ? (o = "⎧", l = "⎩", c = "⎪", f = "Size4-Regular") : e === "\\rgroup" || e === "⟯" ? (o = "⎫", l = "⎭", c = "⎪", f = "Size4-Regular") : e === "\\lmoustache" || e === "⎰" ? (o = "⎧", l = "⎭", c = "⎪", f = "Size4-Regular") : (e === "\\rmoustache" || e === "⎱") && (o = "⎫", l = "⎩", c = "⎪", f = "Size4-Regular");
	var p = Sr(o, f, i), m = p.height + p.depth, h = Sr(c, f, i), g = h.height + h.depth, _ = Sr(l, f, i), v = _.height + _.depth, y = 0, b = 1;
	if (s !== null) {
		var x = Sr(s, f, i);
		y = x.height + x.depth, b = 2;
	}
	var S = m + v + y, C = S + Math.max(0, Math.ceil((t - S) / (b * g))) * b * g, w = r.fontMetrics().axisHeight;
	n && (w *= r.sizeMultiplier);
	var ee = C / 2 - w, te = [];
	if (u.length > 0) {
		var ne = C - m - v, re = Math.round(C * 1e3), ie = Se(u, Math.round(ne * 1e3)), ae = new Be(u, ie), oe = O(d / 1e3), se = O(re / 1e3), ce = Ut([], [new ze([ae], {
			width: oe,
			height: se,
			viewBox: "0 0 " + d + " " + re
		})], r);
		ce.height = re / 1e3, ce.style.width = oe, ce.style.height = se, te.push({
			type: "elem",
			elem: ce
		});
	} else {
		if (te.push(Or(l, f, i, r)), te.push(jr), s === null) {
			var le = C - m - v + 2 * Ar;
			te.push(kr(c, le, r));
		} else {
			var ue = (C - m - v - y) / 2 + 2 * Ar;
			te.push(kr(c, ue, r)), te.push(jr), te.push(Or(s, f, i, r)), te.push(jr), te.push(kr(c, ue, r));
		}
		te.push(jr), te.push(Or(o, f, i, r));
	}
	var E = r.havingBaseStyle(T.TEXT);
	return Cr(U(["delimsizing", "mult"], [W({
		positionType: "bottom",
		positionData: ee,
		children: te
	})], E), T.TEXT, r, a);
}, Fr = 80, Ir = .08, Lr = function(e, t, n, r, i) {
	return Ut(["hide-tail"], [new ze([new Be(e, ye(e, r, n))], {
		width: "400em",
		height: O(t),
		viewBox: "0 0 400000 " + n,
		preserveAspectRatio: "xMinYMin slice"
	})], i);
}, Rr = function(e, t) {
	var n = t.havingBaseSizing(), r = Jr("\\surd", e * n.sizeMultiplier, Kr, n), i = n.sizeMultiplier, a = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), o, s, c, l, u;
	return r.type === "small" ? (l = 1e3 + 1e3 * a + Fr, e < 1 ? i = 1 : e < 1.4 && (i = .7), s = (1 + a + Ir) / i, c = (1 + a) / i, o = Lr("sqrtMain", s, l, a, t), o.style.minWidth = "0.853em", u = .833 / i) : r.type === "large" ? (l = (1e3 + Fr) * Hr[r.size], c = (Hr[r.size] + a) / i, s = (Hr[r.size] + a + Ir) / i, o = Lr("sqrtSize" + r.size, s, l, a, t), o.style.minWidth = "1.02em", u = 1 / i) : (s = e + a + Ir, c = e + a, l = Math.floor(1e3 * e + a) + Fr, o = Lr("sqrtTall", s, l, a, t), o.style.minWidth = "0.742em", u = 1.056), o.height = c, o.style.height = O(s), {
		span: o,
		advanceWidth: u,
		ruleWidth: (t.fontMetrics().sqrtRuleThickness + a) * i
	};
}, zr = /* @__PURE__ */ new Set([
	"(",
	"\\lparen",
	")",
	"\\rparen",
	"[",
	"\\lbrack",
	"]",
	"\\rbrack",
	"\\{",
	"\\lbrace",
	"\\}",
	"\\rbrace",
	"\\lfloor",
	"\\rfloor",
	"⌊",
	"⌋",
	"\\lceil",
	"\\rceil",
	"⌈",
	"⌉",
	"\\surd"
]), Br = /* @__PURE__ */ new Set([
	"\\uparrow",
	"\\downarrow",
	"\\updownarrow",
	"\\Uparrow",
	"\\Downarrow",
	"\\Updownarrow",
	"|",
	"\\|",
	"\\vert",
	"\\Vert",
	"\\lvert",
	"\\rvert",
	"\\lVert",
	"\\rVert",
	"\\lgroup",
	"\\rgroup",
	"⟮",
	"⟯",
	"\\lmoustache",
	"\\rmoustache",
	"⎰",
	"⎱"
]), Vr = /* @__PURE__ */ new Set([
	"<",
	">",
	"\\langle",
	"\\rangle",
	"/",
	"\\backslash",
	"\\lt",
	"\\gt"
]), Hr = [
	0,
	1.2,
	1.8,
	2.4,
	3
], Ur = function(e, n, r, i, a) {
	if (e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle"), zr.has(e) || Vr.has(e)) return Dr(e, n, !1, r, i, a);
	if (Br.has(e)) return Pr(e, Hr[n], !1, r, i, a);
	throw new t("Illegal delimiter: '" + e + "'");
}, Wr = [
	{
		type: "small",
		style: T.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: T.SCRIPT
	},
	{
		type: "small",
		style: T.TEXT
	},
	{
		type: "large",
		size: 1
	},
	{
		type: "large",
		size: 2
	},
	{
		type: "large",
		size: 3
	},
	{
		type: "large",
		size: 4
	}
], Gr = [
	{
		type: "small",
		style: T.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: T.SCRIPT
	},
	{
		type: "small",
		style: T.TEXT
	},
	{ type: "stack" }
], Kr = [
	{
		type: "small",
		style: T.SCRIPTSCRIPT
	},
	{
		type: "small",
		style: T.SCRIPT
	},
	{
		type: "small",
		style: T.TEXT
	},
	{
		type: "large",
		size: 1
	},
	{
		type: "large",
		size: 2
	},
	{
		type: "large",
		size: 3
	},
	{
		type: "large",
		size: 4
	},
	{ type: "stack" }
], qr = function(e) {
	if (e.type === "small") return "Main-Regular";
	if (e.type === "large") return "Size" + e.size + "-Regular";
	if (e.type === "stack") return "Size4-Regular";
	var t = e.type;
	throw Error("Add support for delim type '" + t + "' here.");
}, Jr = function(e, t, n, r) {
	for (var i = Math.min(2, 3 - r.style.size); i < n.length; i++) {
		var a = n[i];
		if (a.type === "stack") break;
		var o = Sr(e, qr(a), "math"), s = o.height + o.depth;
		if (a.type === "small") {
			var c = r.havingBaseStyle(a.style);
			s *= c.sizeMultiplier;
		}
		if (s > t) return a;
	}
	return n[n.length - 1];
}, Yr = function(e, t, n, r, i, a) {
	e === "<" || e === "\\lt" || e === "⟨" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "⟩") && (e = "\\rangle");
	var o = Vr.has(e) ? Wr : zr.has(e) ? Kr : Gr, s = Jr(e, t, o, r);
	return s.type === "small" ? Tr(e, s.style, n, r, i, a) : s.type === "large" ? Dr(e, s.size, n, r, i, a) : Pr(e, t, n, r, i, a);
}, Xr = function(e, t, n, r, i, a) {
	var o = r.fontMetrics().axisHeight * r.sizeMultiplier, s = 901, c = 5 / r.fontMetrics().ptPerEm, l = Math.max(t - o, n + o);
	return Yr(e, Math.max(l / 500 * s, 2 * l - c), !0, r, i, a);
}, Zr = {
	"\\bigl": {
		mclass: "mopen",
		size: 1
	},
	"\\Bigl": {
		mclass: "mopen",
		size: 2
	},
	"\\biggl": {
		mclass: "mopen",
		size: 3
	},
	"\\Biggl": {
		mclass: "mopen",
		size: 4
	},
	"\\bigr": {
		mclass: "mclose",
		size: 1
	},
	"\\Bigr": {
		mclass: "mclose",
		size: 2
	},
	"\\biggr": {
		mclass: "mclose",
		size: 3
	},
	"\\Biggr": {
		mclass: "mclose",
		size: 4
	},
	"\\bigm": {
		mclass: "mrel",
		size: 1
	},
	"\\Bigm": {
		mclass: "mrel",
		size: 2
	},
	"\\biggm": {
		mclass: "mrel",
		size: 3
	},
	"\\Biggm": {
		mclass: "mrel",
		size: 4
	},
	"\\big": {
		mclass: "mord",
		size: 1
	},
	"\\Big": {
		mclass: "mord",
		size: 2
	},
	"\\bigg": {
		mclass: "mord",
		size: 3
	},
	"\\Bigg": {
		mclass: "mord",
		size: 4
	}
}, Qr = /* @__PURE__ */ new Set(/* @__PURE__ */ "(,\\lparen,),\\rparen,[,\\lbrack,],\\rbrack,\\{,\\lbrace,\\},\\rbrace,\\lfloor,\\rfloor,⌊,⌋,\\lceil,\\rceil,⌈,⌉,<,>,\\langle,⟨,\\rangle,⟩,\\lt,\\gt,\\lvert,\\rvert,\\lVert,\\rVert,\\lgroup,\\rgroup,⟮,⟯,\\lmoustache,\\rmoustache,⎰,⎱,/,\\backslash,|,\\vert,\\|,\\Vert,\\uparrow,\\Uparrow,\\downarrow,\\Downarrow,\\updownarrow,\\Updownarrow,.".split(","));
function $r(e) {
	return "isMiddle" in e;
}
function ei(e, n) {
	var r = nr(e);
	if (r && Qr.has(r.text)) return r;
	throw r ? new t("Invalid delimiter '" + r.text + "' after '" + n.funcName + "'", e) : new t("Invalid delimiter type '" + e.type + "'", e);
}
K({
	type: "delimsizing",
	names: [
		"\\bigl",
		"\\Bigl",
		"\\biggl",
		"\\Biggl",
		"\\bigr",
		"\\Bigr",
		"\\biggr",
		"\\Biggr",
		"\\bigm",
		"\\Bigm",
		"\\biggm",
		"\\Biggm",
		"\\big",
		"\\Big",
		"\\bigg",
		"\\Bigg"
	],
	numArgs: 1,
	argTypes: ["primitive"],
	handler: (e, t) => {
		var n = ei(ln(t[0]), e);
		return {
			type: "delimsizing",
			mode: e.parser.mode,
			size: Zr[e.funcName].size,
			mclass: Zr[e.funcName].mclass,
			delim: n.text
		};
	},
	htmlBuilder: (e, t) => e.delim === "." ? U([e.mclass]) : Ur(e.delim, e.size, t, e.mode, [e.mclass]),
	mathmlBuilder: (e) => {
		var t = [];
		e.delim !== "." && t.push(On(e.delim, e.mode));
		var n = new J("mo", t);
		e.mclass === "mopen" || e.mclass === "mclose" ? n.setAttribute("fence", "true") : n.setAttribute("fence", "false"), n.setAttribute("stretchy", "true");
		var r = O(Hr[e.size]);
		return n.setAttribute("minsize", r), n.setAttribute("maxsize", r), n;
	}
});
function ti(e) {
	if (!e.body) throw Error("Bug: The leftright ParseNode wasn't fully parsed.");
}
K({
	type: "leftright-right",
	names: ["\\right"],
	numArgs: 1,
	primitive: !0,
	handler: (e, n) => {
		var r = e.parser.gullet.macros.get("\\current@color");
		if (r && typeof r != "string") throw new t("\\current@color set to non-string in \\right");
		return {
			type: "leftright-right",
			mode: e.parser.mode,
			delim: ei(n[0], e).text,
			color: r
		};
	}
}), K({
	type: "leftright",
	names: ["\\left"],
	numArgs: 1,
	primitive: !0,
	handler: (e, t) => {
		var n = ei(t[0], e), r = e.parser;
		++r.leftrightDepth;
		var i = r.parseExpression(!1);
		--r.leftrightDepth, r.expect("\\right", !1);
		var a = X(r.parseFunction(), "leftright-right");
		return {
			type: "leftright",
			mode: r.mode,
			body: i,
			left: n.text,
			right: a.delim,
			rightColor: a.color
		};
	},
	htmlBuilder: (e, t) => {
		ti(e);
		for (var n = hn(e.body, t, !0, ["mopen", "mclose"]), r = 0, i = 0, a = !1, o = 0; o < n.length; o++) {
			var s = n[o];
			$r(s) ? a = !0 : (r = Math.max(n[o].height, r), i = Math.max(n[o].depth, i));
		}
		r *= t.sizeMultiplier, i *= t.sizeMultiplier;
		var c = e.left === "." ? bn(t, ["mopen"]) : Xr(e.left, r, i, t, e.mode, ["mopen"]);
		if (n.unshift(c), a) for (var l = 1; l < n.length; l++) {
			var u = n[l];
			if ($r(u)) {
				var d = u.isMiddle;
				n[l] = Xr(d.delim, r, i, d.options, e.mode, []);
			}
		}
		var f;
		if (e.right === ".") f = bn(t, ["mclose"]);
		else {
			var p = e.rightColor ? t.withColor(e.rightColor) : t;
			f = Xr(e.right, r, i, p, e.mode, ["mclose"]);
		}
		return n.push(f), U(["minner"], n, t);
	},
	mathmlBuilder: (e, t) => {
		ti(e);
		var n = Nn(e.body, t);
		if (e.left !== ".") {
			var r = new J("mo", [On(e.left, e.mode)]);
			r.setAttribute("fence", "true"), n.unshift(r);
		}
		if (e.right !== ".") {
			var i = new J("mo", [On(e.right, e.mode)]);
			i.setAttribute("fence", "true"), e.rightColor && i.setAttribute("mathcolor", e.rightColor), n.push(i);
		}
		return kn(n);
	}
}), K({
	type: "middle",
	names: ["\\middle"],
	numArgs: 1,
	primitive: !0,
	handler: (e, n) => {
		var r = ei(n[0], e);
		if (!e.parser.leftrightDepth) throw new t("\\middle without preceding \\left", r);
		return {
			type: "middle",
			mode: e.parser.mode,
			delim: r.text
		};
	},
	htmlBuilder: (e, t) => {
		var n;
		return e.delim === "." ? n = bn(t, []) : (n = Ur(e.delim, 1, t, e.mode, []), n.isMiddle = {
			delim: e.delim,
			options: t
		}), n;
	},
	mathmlBuilder: (e, t) => {
		var n = new J("mo", [e.delim === "\\vert" || e.delim === "|" ? On("|", "text") : On(e.delim, e.mode)]);
		return n.setAttribute("fence", "true"), n.setAttribute("lspace", "0.05em"), n.setAttribute("rspace", "0.05em"), n;
	}
}), K({
	type: "enclose",
	names: ["\\colorbox"],
	numArgs: 2,
	allowedInText: !0,
	argTypes: ["color", "hbox"],
	handler(e, t, n) {
		var r = e.parser, i = e.funcName, a = X(t[0], "color-token").color, o = t[1];
		return {
			type: "enclose",
			mode: r.mode,
			label: i,
			backgroundColor: a,
			body: o
		};
	},
	htmlBuilder: (e, t) => {
		var n = qt(q(e.body, t), t), r = e.label.slice(1), i = t.sizeMultiplier, a, o, s = l(e.body);
		if (r === "sout") a = U(["katex-stretchy", "katex-sout"]), a.height = t.fontMetrics().defaultRuleThickness / i, o = -.5 * t.fontMetrics().xHeight;
		else if (r === "phase") {
			var c = D({
				number: .6,
				unit: "pt"
			}, t), u = D({
				number: .35,
				unit: "ex"
			}, t), d = t.havingBaseSizing();
			i /= d.sizeMultiplier;
			var f = n.height + n.depth + c + u;
			n.style.paddingLeft = O(f / 2 + c);
			var p = Math.floor(1e3 * f * i);
			a = Ut(["hide-tail"], [new ze([new Be("phase", _e(p))], {
				width: "400em",
				height: O(p / 1e3),
				viewBox: "0 0 400000 " + p,
				preserveAspectRatio: "xMinYMin slice"
			})], t), a.style.height = O(f), o = n.depth + c + u;
		} else {
			/cancel/.test(r) ? s || n.classes.push("cancel-pad") : r === "angl" ? n.classes.push("anglpad") : n.classes.push("boxpad");
			var m, h, g = 0;
			/box/.test(r) ? (g = Math.max(t.fontMetrics().fboxrule, t.minRuleThickness), m = t.fontMetrics().fboxsep + (r === "colorbox" ? 0 : g), h = m) : r === "angl" ? (g = Math.max(t.fontMetrics().defaultRuleThickness, t.minRuleThickness), m = 4 * g, h = Math.max(0, .25 - n.depth)) : (m = s ? .2 : 0, h = m), a = Yn(n, r, m, h, t), /fbox|boxed|fcolorbox/.test(r) ? (a.style.borderStyle = "solid", a.style.borderWidth = O(g)) : r === "angl" && g !== .049 && (a.style.borderTopWidth = O(g), a.style.borderRightWidth = O(g)), o = n.depth + h, e.backgroundColor && (a.style.backgroundColor = e.backgroundColor, e.borderColor && (a.style.borderColor = e.borderColor));
		}
		var _;
		if (e.backgroundColor) _ = W({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: a,
				shift: o
			}, {
				type: "elem",
				elem: n,
				shift: 0
			}]
		});
		else {
			var v = /cancel|phase/.test(r) ? ["svg-align"] : [];
			_ = W({
				positionType: "individualShift",
				children: [{
					type: "elem",
					elem: n,
					shift: 0
				}, {
					type: "elem",
					elem: a,
					shift: o,
					wrapperClasses: v
				}]
			});
		}
		return /cancel/.test(r) && (_.height = n.height, _.depth = n.depth), /cancel/.test(r) && !s ? U(["mord", "cancel-lap"], [_], t) : U(["mord"], [_], t);
	},
	mathmlBuilder: (e, t) => {
		var n, r = new J(e.label.includes("colorbox") ? "mpadded" : "menclose", [Y(e.body, t)]);
		switch (e.label) {
			case "\\cancel":
				r.setAttribute("notation", "updiagonalstrike");
				break;
			case "\\bcancel":
				r.setAttribute("notation", "downdiagonalstrike");
				break;
			case "\\phase":
				r.setAttribute("notation", "phasorangle");
				break;
			case "\\sout":
				r.setAttribute("notation", "horizontalstrike");
				break;
			case "\\fbox":
				r.setAttribute("notation", "box");
				break;
			case "\\angl":
				r.setAttribute("notation", "actuarial");
				break;
			case "\\fcolorbox":
			case "\\colorbox":
				if (n = t.fontMetrics().fboxsep * t.fontMetrics().ptPerEm, r.setAttribute("width", "+" + 2 * n + "pt"), r.setAttribute("height", "+" + 2 * n + "pt"), r.setAttribute("lspace", n + "pt"), r.setAttribute("voffset", n + "pt"), e.label === "\\fcolorbox") {
					var i = Math.max(t.fontMetrics().fboxrule, t.minRuleThickness);
					r.setAttribute("style", "border: " + O(i) + " solid " + e.borderColor);
				}
				break;
			case "\\xcancel": r.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
		}
		return e.backgroundColor && r.setAttribute("mathbackground", e.backgroundColor), r;
	}
}), K({
	type: "enclose",
	names: ["\\fcolorbox"],
	numArgs: 3,
	allowedInText: !0,
	argTypes: [
		"color",
		"color",
		"hbox"
	],
	handler(e, t, n) {
		var r = e.parser, i = e.funcName, a = X(t[0], "color-token").color, o = X(t[1], "color-token").color, s = t[2];
		return {
			type: "enclose",
			mode: r.mode,
			label: i,
			backgroundColor: o,
			borderColor: a,
			body: s
		};
	}
}), K({
	type: "enclose",
	names: ["\\fbox"],
	numArgs: 1,
	argTypes: ["hbox"],
	allowedInText: !0,
	handler(e, t) {
		return {
			type: "enclose",
			mode: e.parser.mode,
			label: "\\fbox",
			body: t[0]
		};
	}
}), K({
	type: "enclose",
	names: [
		"\\cancel",
		"\\bcancel",
		"\\xcancel",
		"\\phase"
	],
	numArgs: 1,
	handler(e, t) {
		var n = e.parser, r = e.funcName, i = t[0];
		return {
			type: "enclose",
			mode: n.mode,
			label: r,
			body: i
		};
	}
}), K({
	type: "enclose",
	names: ["\\sout"],
	numArgs: 1,
	allowedInText: !0,
	handler(e, t) {
		var n = e.parser, r = e.funcName;
		n.mode === "math" && Pt({
			strict: n.settings.strict,
			errorCode: "mathVsSout",
			errorMsg: "LaTeX's \\sout works only in text mode",
			report: !0
		});
		var i = t[0];
		return {
			type: "enclose",
			mode: n.mode,
			label: r,
			body: i
		};
	}
}), K({
	type: "enclose",
	names: ["\\angl"],
	numArgs: 1,
	argTypes: ["hbox"],
	allowedInText: !1,
	handler(e, t) {
		return {
			type: "enclose",
			mode: e.parser.mode,
			label: "\\angl",
			body: t[0]
		};
	}
});
var ni = {};
function ri(e) {
	for (var t = e.type, n = e.names, r = e.props, i = e.handler, a = e.htmlBuilder, o = e.mathmlBuilder, s = {
		type: t,
		numArgs: r.numArgs || 0,
		allowedInText: !1,
		numOptionalArgs: 0,
		handler: i
	}, c = 0; c < n.length; ++c) ni[n[c]] = s;
	a && (on[t] = a), o && (sn[t] = o);
}
var ii = {};
function Z(e, t) {
	ii[e] = t;
}
var ai = class e {
	constructor(e, t, n) {
		this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = n;
	}
	static range(t, n) {
		return n ? !t || !t.loc || !n.loc || t.loc.lexer !== n.loc.lexer ? null : new e(t.loc.lexer, t.loc.start, n.loc.end) : t && t.loc;
	}
}, oi = class e {
	constructor(e, t) {
		this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t;
	}
	range(t, n) {
		return new e(n, ai.range(this, t));
	}
};
function si(e) {
	var t = [];
	e.consumeSpaces();
	var n = e.fetch().text;
	for (n === "\\relax" && (e.consume(), e.consumeSpaces(), n = e.fetch().text); n === "\\hline" || n === "\\hdashline";) e.consume(), t.push(n === "\\hdashline"), e.consumeSpaces(), n = e.fetch().text;
	return t;
}
var ci = (e) => {
	if (!e.parser.settings.displayMode) throw new t("{" + e.envName + "} can be used only in display mode.");
}, li = /* @__PURE__ */ new Set(["gather", "gather*"]);
function ui(e) {
	if (!e.includes("ed")) return !e.includes("*");
}
function di(e, n, r) {
	var i = n.hskipBeforeAndAfter, a = n.addJot, o = n.cols, s = n.arraystretch, c = n.colSeparationType, l = n.autoTag, u = n.singleRow, d = n.emptySingleRow, f = n.maxNumCols, p = n.leqno;
	if (e.gullet.beginGroup(), u || e.gullet.macros.set("\\cr", "\\\\\\relax"), !s) {
		var m = e.gullet.expandMacroAsText("\\arraystretch");
		if (m == null) s = 1;
		else if (s = parseFloat(m), !s || s < 0) throw new t("Invalid \\arraystretch: " + m);
	}
	e.gullet.beginGroup();
	var h = [], g = [h], _ = [], v = [], y = l == null ? void 0 : [];
	function b() {
		l && e.gullet.macros.set("\\@eqnsw", "1", !0);
	}
	function x() {
		y && (e.gullet.macros.get("\\df@tag") ? (y.push(e.subparse([new oi("\\df@tag")])), e.gullet.macros.set("\\df@tag", void 0, !0)) : y.push(!!l && e.gullet.macros.get("\\@eqnsw") === "1"));
	}
	for (b(), v.push(si(e));;) {
		var S = e.parseExpression(!1, u ? "\\end" : "\\\\");
		e.gullet.endGroup(), e.gullet.beginGroup();
		var C = {
			type: "ordgroup",
			mode: e.mode,
			body: S
		};
		r && (C = {
			type: "styling",
			mode: e.mode,
			style: r,
			resetFont: !0,
			body: [C]
		}), h.push(C);
		var w = e.fetch().text;
		if (w === "&") {
			if (f && h.length === f) {
				if (u || c) throw new t("Too many tab characters: &", e.nextToken);
				Pt({
					strict: e.settings.strict,
					errorCode: "textEnv",
					errorMsg: "Too few columns specified in the {array} column argument.",
					report: !0
				});
			}
			e.consume();
		} else if (w === "\\end") {
			x(), h.length === 1 && C.type === "styling" && C.body.length === 1 && C.body[0].type === "ordgroup" && C.body[0].body.length === 0 && (g.length > 1 || !d) && !Array.isArray(y?.[y.length - 1]) && !(l && y?.[y.length - 1] === !0) && g.pop(), v.length < g.length + 1 && v.push([]);
			break;
		} else if (w === "\\\\") {
			e.consume();
			var ee = void 0;
			e.gullet.future().text !== " " && (ee = e.parseSizeGroup(!0)), _.push(ee ? ee.value : null), x(), v.push(si(e)), h = [], g.push(h), b();
		} else throw new t("Expected & or \\\\ or \\cr or \\end", e.nextToken);
	}
	return e.gullet.endGroup(), e.gullet.endGroup(), {
		type: "array",
		mode: e.mode,
		addJot: a,
		arraystretch: s,
		body: g,
		cols: o,
		rowGaps: _,
		hskipBeforeAndAfter: i,
		hLinesBeforeRow: v,
		colSeparationType: c,
		tags: y,
		leqno: p
	};
}
function fi(e) {
	return e.slice(0, 1) === "d" ? "display" : "text";
}
var pi = function(e, n) {
	var r, i, a = e.body.length, o = e.hLinesBeforeRow, s = 0, c = Array(a), l = [], u = Math.max(n.fontMetrics().arrayRuleWidth, n.minRuleThickness), d = 1 / n.fontMetrics().ptPerEm, f = 5 * d;
	e.colSeparationType && e.colSeparationType === "small" && (f = .2778 * (n.havingStyle(T.SCRIPT).sizeMultiplier / n.sizeMultiplier));
	var p = e.colSeparationType === "CD" ? D({
		number: 3,
		unit: "ex"
	}, n) : 12 * d, m = 3 * d, h = e.arraystretch * p, g = .7 * h, _ = .3 * h, v = 0;
	function y(e) {
		for (var t = 0; t < e.length; ++t) t > 0 && (v += .25), l.push({
			pos: v,
			isDashed: e[t]
		});
	}
	for (y(o[0]), r = 0; r < e.body.length; ++r) {
		var b = e.body[r], x = g, S = _;
		s < b.length && (s = b.length);
		var C = {
			cells: Array(b.length),
			height: 0,
			depth: 0,
			pos: 0
		};
		for (i = 0; i < b.length; ++i) {
			var w = q(b[i], n);
			S < w.depth && (S = w.depth), x < w.height && (x = w.height), C.cells[i] = w;
		}
		var ee = e.rowGaps[r], te = 0;
		ee && (te = D(ee, n), te > 0 && (te += _, S < te && (S = te), te = 0)), e.addJot && r < e.body.length - 1 && (S += m), C.height = x, C.depth = S, v += x, C.pos = v, v += S + te, c[r] = C, y(o[r + 1]);
	}
	var ne = v / 2 + n.fontMetrics().axisHeight, re = e.cols || [], ie = [], ae, oe, se = [];
	if (e.tags && e.tags.some((e) => e)) for (r = 0; r < a; ++r) {
		var ce = c[r], le = ce.pos - ne, ue = e.tags[r], E = void 0;
		E = ue === !0 ? U(["eqn-num"], [], n) : ue === !1 ? U([], [], n) : U([], hn(ue, n, !0), n), E.depth = ce.depth, E.height = ce.height, se.push({
			type: "elem",
			elem: E,
			shift: le
		});
	}
	for (i = 0, oe = 0; i < s || oe < re.length; ++i, ++oe) {
		for (var de = re[oe], fe = !0; (pe = de)?.type === "separator";) {
			var pe;
			if (fe || (ae = U(["arraycolsep"], []), ae.style.width = O(n.fontMetrics().doubleRuleSep), ie.push(ae)), de.separator === "|" || de.separator === ":") {
				var me = de.separator === "|" ? "solid" : "dashed", he = U(["vertical-separator"], [], n);
				he.style.height = O(v), he.style.borderRightWidth = O(u), he.style.borderRightStyle = me, he.style.margin = "0 " + O(-u / 2);
				var ge = v - ne;
				ge && (he.style.verticalAlign = O(-ge)), ie.push(he);
			} else throw new t("Invalid separator type: " + de.separator);
			oe++, de = re[oe], fe = !1;
		}
		if (!(i >= s)) {
			var _e = void 0;
			(i > 0 || e.hskipBeforeAndAfter) && (_e = de?.pregap ?? f, _e !== 0 && (ae = U(["arraycolsep"], []), ae.style.width = O(_e), ie.push(ae)));
			var ve = [];
			for (r = 0; r < a; ++r) {
				var ye = c[r], be = ye.cells[i];
				if (be) {
					var xe = ye.pos - ne;
					be.depth = ye.depth, be.height = ye.height, ve.push({
						type: "elem",
						elem: be,
						shift: xe
					});
				}
			}
			var Se = W({
				positionType: "individualShift",
				children: ve
			}), Ce = U(["col-align-" + (de?.align || "c")], [Se]);
			ie.push(Ce), (i < s - 1 || e.hskipBeforeAndAfter) && (_e = de?.postgap ?? f, _e !== 0 && (ae = U(["arraycolsep"], []), ae.style.width = O(_e), ie.push(ae)));
		}
	}
	var we = U(["mtable"], ie);
	if (l.length > 0) {
		for (var Te = Wt("katex-hline", n, u), Ee = Wt("katex-hdashline", n, u), De = [{
			type: "elem",
			elem: we,
			shift: 0
		}]; l.length > 0;) {
			var Oe = l.pop(), ke = Oe.pos - ne;
			Oe.isDashed ? De.push({
				type: "elem",
				elem: Ee,
				shift: ke
			}) : De.push({
				type: "elem",
				elem: Te,
				shift: ke
			});
		}
		we = W({
			positionType: "individualShift",
			children: De
		});
	}
	if (se.length === 0) return U(["mord"], [we], n);
	var Ae = U(["katex-tag"], [W({
		positionType: "individualShift",
		children: se
	})], n);
	return Kt([we, Ae]);
}, mi = {
	c: "center ",
	l: "left ",
	r: "right "
}, hi = function(e, t) {
	for (var n = [], r = new J("mtd", [], ["mtr-glue"]), i = new J("mtd", [], ["mml-eqn-num"]), a = 0; a < e.body.length; a++) {
		for (var o = e.body[a], s = [], c = 0; c < o.length; c++) s.push(new J("mtd", [Y(o[c], t)]));
		e.tags && e.tags[a] && (s.unshift(r), s.push(r), e.leqno ? s.unshift(i) : s.push(i)), n.push(new J("mtr", s));
	}
	var l = new J("mtable", n), u = e.arraystretch === .5 ? .1 : .16 + e.arraystretch - 1 + (e.addJot ? .09 : 0);
	l.setAttribute("rowspacing", O(u));
	var d = "", f = "";
	if (e.cols && e.cols.length > 0) {
		var p = e.cols, m = "", h = !1, g = 0, _ = p.length;
		p[0].type === "separator" && (d += "top ", g = 1), p[p.length - 1].type === "separator" && (d += "bottom ", --_);
		for (var v = g; v < _; v++) {
			var y = p[v];
			y.type === "align" ? (f += mi[y.align], h && (m += "none "), h = !0) : y.type === "separator" && (h &&= (m += y.separator === "|" ? "solid " : "dashed ", !1));
		}
		l.setAttribute("columnalign", f.trim()), /[sd]/.test(m) && l.setAttribute("columnlines", m.trim());
	}
	if (e.colSeparationType === "align") {
		for (var b = e.cols || [], x = "", S = 1; S < b.length; S++) x += S % 2 ? "0em " : "1em ";
		l.setAttribute("columnspacing", x.trim());
	} else e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? l.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? l.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? l.setAttribute("columnspacing", "0.5em") : l.setAttribute("columnspacing", "1em");
	var C = "", w = e.hLinesBeforeRow;
	d += w[0].length > 0 ? "left " : "", d += w[w.length - 1].length > 0 ? "right " : "";
	for (var ee = 1; ee < w.length - 1; ee++) C += w[ee].length === 0 ? "none " : w[ee][0] ? "dashed " : "solid ";
	return /[sd]/.test(C) && l.setAttribute("rowlines", C.trim()), d !== "" && (l = new J("menclose", [l]), l.setAttribute("notation", d.trim())), e.arraystretch && e.arraystretch < 1 && (l = new J("mstyle", [l]), l.setAttribute("scriptlevel", "1")), l;
}, gi = function(e, n) {
	e.envName.includes("ed") || ci(e);
	var r = [], i = e.envName === "split", a = di(e.parser, {
		cols: r,
		addJot: !0,
		autoTag: i ? void 0 : ui(e.envName),
		emptySingleRow: !0,
		colSeparationType: e.envName.includes("at") ? "alignat" : "align",
		maxNumCols: i ? 2 : void 0,
		leqno: e.parser.settings.leqno
	}, "display"), o = 0, s = 0, c = {
		type: "ordgroup",
		mode: e.mode,
		body: []
	};
	if (n[0] && n[0].type === "ordgroup") {
		var l = "Number of columns should be a positive integer", u = rr(n[0], l);
		if (!/^[0-9]+$/.test(u) || Number(u) < 1) throw new t(l, n[0]);
		o = Number(u), s = o * 2;
	}
	var d = !s;
	a.body.forEach(function(e) {
		for (var n = 1; n < e.length; n += 2) X(X(e[n], "styling").body[0], "ordgroup").body.unshift(c);
		if (d) s < e.length && (s = e.length);
		else {
			var r = e.length / 2;
			if (o < r) throw new t("Too many math in a row: " + ("expected " + o + ", but got " + r), e[0]);
		}
	});
	for (var f = 0; f < s; ++f) {
		var p = "r", m = 0;
		f % 2 == 1 ? p = "l" : f > 0 && d && (m = 1), r[f] = {
			type: "align",
			align: p,
			pregap: m,
			postgap: 0
		};
	}
	return a.colSeparationType = d ? "align" : "alignat", a;
};
ri({
	type: "array",
	names: ["array", "darray"],
	props: { numArgs: 1 },
	handler(e, n) {
		var r = (nr(n[0]) ? [n[0]] : X(n[0], "ordgroup").body).map(function(e) {
			var n = tr(e).text;
			if ("lcr".includes(n)) return {
				type: "align",
				align: n
			};
			if (n === "|") return {
				type: "separator",
				separator: "|"
			};
			if (n === ":") return {
				type: "separator",
				separator: ":"
			};
			throw new t("Unknown column alignment: " + n, e);
		}), i = {
			cols: r,
			hskipBeforeAndAfter: !0,
			maxNumCols: r.length
		};
		return di(e.parser, i, fi(e.envName));
	},
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: [
		"matrix",
		"pmatrix",
		"bmatrix",
		"Bmatrix",
		"vmatrix",
		"Vmatrix",
		"matrix*",
		"pmatrix*",
		"bmatrix*",
		"Bmatrix*",
		"vmatrix*",
		"Vmatrix*"
	],
	props: { numArgs: 0 },
	handler(e) {
		var n = {
			matrix: null,
			pmatrix: ["(", ")"],
			bmatrix: ["[", "]"],
			Bmatrix: ["\\{", "\\}"],
			vmatrix: ["|", "|"],
			Vmatrix: ["\\Vert", "\\Vert"]
		}[e.envName.replace("*", "")], r = "c", i = {
			hskipBeforeAndAfter: !1,
			cols: [{
				type: "align",
				align: r
			}]
		};
		if (e.envName.charAt(e.envName.length - 1) === "*") {
			var a = e.parser;
			if (a.consumeSpaces(), a.fetch().text === "[") {
				if (a.consume(), a.consumeSpaces(), r = a.fetch().text, !"lcr".includes(r)) throw new t("Expected l or c or r", a.nextToken);
				a.consume(), a.consumeSpaces(), a.expect("]"), a.consume(), i.cols = [{
					type: "align",
					align: r
				}];
			}
		}
		var o = di(e.parser, i, fi(e.envName)), s = Math.max(0, ...o.body.map((e) => e.length));
		return o.cols = Array(s).fill({
			type: "align",
			align: r
		}), n ? {
			type: "leftright",
			mode: e.mode,
			body: [o],
			left: n[0],
			right: n[1],
			rightColor: void 0
		} : o;
	},
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: ["smallmatrix"],
	props: { numArgs: 0 },
	handler(e) {
		var t = di(e.parser, { arraystretch: .5 }, "script");
		return t.colSeparationType = "small", t;
	},
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: ["subarray"],
	props: { numArgs: 1 },
	handler(e, n) {
		var r = (nr(n[0]) ? [n[0]] : X(n[0], "ordgroup").body).map(function(e) {
			var n = tr(e).text;
			if ("lc".includes(n)) return {
				type: "align",
				align: n
			};
			throw new t("Unknown column alignment: " + n, e);
		});
		if (r.length > 1) throw new t("{subarray} can contain only one column");
		var i = {
			cols: r,
			hskipBeforeAndAfter: !1,
			arraystretch: .5
		}, a = di(e.parser, i, "script");
		if (a.body.length > 0 && a.body[0].length > 1) throw new t("{subarray} can contain only one column");
		return a;
	},
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: [
		"cases",
		"dcases",
		"rcases",
		"drcases"
	],
	props: { numArgs: 0 },
	handler(e) {
		var t = di(e.parser, {
			arraystretch: 1.2,
			cols: [{
				type: "align",
				align: "l",
				pregap: 0,
				postgap: 1
			}, {
				type: "align",
				align: "l",
				pregap: 0,
				postgap: 0
			}]
		}, fi(e.envName));
		return {
			type: "leftright",
			mode: e.mode,
			body: [t],
			left: e.envName.includes("r") ? "." : "\\{",
			right: e.envName.includes("r") ? "\\}" : ".",
			rightColor: void 0
		};
	},
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: [
		"align",
		"align*",
		"aligned",
		"split"
	],
	props: { numArgs: 0 },
	handler: gi,
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: [
		"gathered",
		"gather",
		"gather*"
	],
	props: { numArgs: 0 },
	handler(e) {
		li.has(e.envName) && ci(e);
		var t = {
			cols: [{
				type: "align",
				align: "c"
			}],
			addJot: !0,
			colSeparationType: "gather",
			autoTag: ui(e.envName),
			emptySingleRow: !0,
			leqno: e.parser.settings.leqno
		};
		return di(e.parser, t, "display");
	},
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: [
		"alignat",
		"alignat*",
		"alignedat"
	],
	props: { numArgs: 1 },
	handler: gi,
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: ["equation", "equation*"],
	props: { numArgs: 0 },
	handler(e) {
		ci(e);
		var t = {
			autoTag: ui(e.envName),
			emptySingleRow: !0,
			singleRow: !0,
			maxNumCols: 1,
			leqno: e.parser.settings.leqno
		};
		return di(e.parser, t, "display");
	},
	htmlBuilder: pi,
	mathmlBuilder: hi
}), ri({
	type: "array",
	names: ["CD"],
	props: { numArgs: 0 },
	handler(e) {
		return ci(e), _r(e.parser);
	},
	htmlBuilder: pi,
	mathmlBuilder: hi
}), Z("\\nonumber", "\\gdef\\@eqnsw{0}"), Z("\\notag", "\\nonumber"), K({
	type: "text",
	names: ["\\hline", "\\hdashline"],
	numArgs: 0,
	allowedInText: !0,
	allowedInMath: !0,
	handler(e, n) {
		throw new t(e.funcName + " valid only within array environment");
	}
});
var _i = ni;
K({
	type: "environment",
	names: ["\\begin", "\\end"],
	numArgs: 1,
	argTypes: ["text"],
	handler(e, n) {
		var r = e.parser, i = e.funcName, a = n[0];
		if (a.type !== "ordgroup") throw new t("Invalid environment name", a);
		var o = rr(a, "Environment name should contain only text characters and spaces", !0);
		if (i === "\\begin") {
			if (!Object.prototype.hasOwnProperty.call(_i, o)) throw new t("No such environment: " + o, a);
			var s = _i[o], c = r.parseArguments("\\begin{" + o + "}", s), l = c.args, u = c.optArgs, d = {
				mode: r.mode,
				envName: o,
				parser: r
			}, f = s.handler(d, l, u);
			r.expect("\\end", !1);
			var p = r.nextToken, m = X(r.parseFunction(), "environment");
			if (m.name !== o) throw new t("Mismatch: \\begin{" + o + "} matched by \\end{" + m.name + "}", p);
			return f;
		}
		return {
			type: "environment",
			mode: r.mode,
			name: o,
			nameGroup: a
		};
	}
});
var vi = (e, t) => {
	var n = e.font, r = t.withFont(n);
	return q(e.body, r);
}, yi = (e, t) => {
	var n = e.font, r = t.withFont(n);
	return Y(e.body, r);
}, bi = {
	"\\Bbb": "\\mathbb",
	"\\bold": "\\mathbf",
	"\\frak": "\\mathfrak"
};
K({
	type: "font",
	names: [
		"\\mathrm",
		"\\mathit",
		"\\mathbf",
		"\\mathnormal",
		"\\mathsfit",
		"\\mathbb",
		"\\mathcal",
		"\\mathfrak",
		"\\mathscr",
		"\\mathsf",
		"\\mathtt",
		"\\Bbb",
		"\\bold",
		"\\frak"
	],
	numArgs: 1,
	allowedInArgument: !0,
	handler: (e, t) => {
		var n = e.parser, r = e.funcName, i = ln(t[0]), a = r in bi ? bi[r] : r;
		return {
			type: "font",
			mode: n.mode,
			font: a.slice(1),
			body: i
		};
	},
	htmlBuilder: vi,
	mathmlBuilder: yi
}), K({
	type: "mclass",
	names: ["\\boldsymbol", "\\bm"],
	numArgs: 1,
	handler: (e, t) => {
		var n = e.parser, r = t[0];
		return {
			type: "mclass",
			mode: n.mode,
			mclass: dr(r),
			body: [{
				type: "font",
				mode: n.mode,
				font: "boldsymbol",
				body: r
			}],
			isCharacterBox: l(r)
		};
	}
}), K({
	type: "font",
	names: [
		"\\rm",
		"\\sf",
		"\\tt",
		"\\bf",
		"\\it",
		"\\cal"
	],
	numArgs: 0,
	allowedInText: !0,
	handler: (e, t) => {
		var n = e.parser, r = e.funcName, i = e.breakOnTokenText, a = n.mode, o = n.parseExpression(!0, i);
		return {
			type: "font",
			mode: a,
			font: "math" + r.slice(1),
			body: {
				type: "ordgroup",
				mode: n.mode,
				body: o
			}
		};
	}
});
var xi = (e, t) => {
	var n = t.style, r = n.fracNum(), i = n.fracDen(), a = t.havingStyle(r), o = q(e.numer, a, t);
	if (e.continued) {
		var s = 8.5 / t.fontMetrics().ptPerEm, c = 3.5 / t.fontMetrics().ptPerEm;
		o.height = o.height < s ? s : o.height, o.depth = o.depth < c ? c : o.depth;
	}
	a = t.havingStyle(i);
	var l = q(e.denom, a, t), u, d, f;
	e.hasBarLine ? (e.barSize ? (d = D(e.barSize, t), u = Wt("frac-line", t, d)) : u = Wt("frac-line", t), d = u.height, f = u.height) : (u = null, d = 0, f = t.fontMetrics().defaultRuleThickness);
	var p, m, h;
	n.size === T.DISPLAY.size ? (p = t.fontMetrics().num1, m = d > 0 ? 3 * f : 7 * f, h = t.fontMetrics().denom1) : (d > 0 ? (p = t.fontMetrics().num2, m = f) : (p = t.fontMetrics().num3, m = 3 * f), h = t.fontMetrics().denom2);
	var g;
	if (u) {
		var _ = t.fontMetrics().axisHeight;
		p - o.depth - (_ + .5 * d) < m && (p += m - (p - o.depth - (_ + .5 * d))), _ - .5 * d - (l.height - h) < m && (h += m - (_ - .5 * d - (l.height - h)));
		var v = -(_ - .5 * d);
		g = W({
			positionType: "individualShift",
			children: [
				{
					type: "elem",
					elem: l,
					shift: h
				},
				{
					type: "elem",
					elem: u,
					shift: v
				},
				{
					type: "elem",
					elem: o,
					shift: -p
				}
			]
		});
	} else {
		var y = p - o.depth - (l.height - h);
		y < m && (p += .5 * (m - y), h += .5 * (m - y)), g = W({
			positionType: "individualShift",
			children: [{
				type: "elem",
				elem: l,
				shift: h
			}, {
				type: "elem",
				elem: o,
				shift: -p
			}]
		});
	}
	a = t.havingStyle(n), g.height *= a.sizeMultiplier / t.sizeMultiplier, g.depth *= a.sizeMultiplier / t.sizeMultiplier;
	var b = n.size === T.DISPLAY.size ? t.fontMetrics().delim1 : n.size === T.SCRIPTSCRIPT.size ? t.havingStyle(T.SCRIPT).fontMetrics().delim2 : t.fontMetrics().delim2, x = e.leftDelim == null ? bn(t, ["mopen"]) : Yr(e.leftDelim, b, !0, t.havingStyle(n), e.mode, ["mopen"]), S = e.continued ? U([]) : e.rightDelim == null ? bn(t, ["mclose"]) : Yr(e.rightDelim, b, !0, t.havingStyle(n), e.mode, ["mclose"]);
	return U(["mord"].concat(a.sizingClasses(t)), [
		x,
		U(["mfrac"], [g]),
		S
	], t);
}, Si = (e, t) => {
	var n = new J("mfrac", [Y(e.numer, t), Y(e.denom, t)]);
	if (!e.hasBarLine) n.setAttribute("linethickness", "0px");
	else if (e.barSize) {
		var r = D(e.barSize, t);
		n.setAttribute("linethickness", O(r));
	}
	if (e.leftDelim != null || e.rightDelim != null) {
		var i = [];
		if (e.leftDelim != null) {
			var a = new J("mo", [new wn(e.leftDelim.replace("\\", ""))]);
			a.setAttribute("fence", "true"), i.push(a);
		}
		if (i.push(n), e.rightDelim != null) {
			var o = new J("mo", [new wn(e.rightDelim.replace("\\", ""))]);
			o.setAttribute("fence", "true"), i.push(o);
		}
		return kn(i);
	}
	return n;
}, Ci = (e, t) => t ? {
	type: "styling",
	mode: e.mode,
	style: t,
	body: [e]
} : e;
K({
	type: "genfrac",
	names: [
		"\\cfrac",
		"\\dfrac",
		"\\frac",
		"\\tfrac",
		"\\dbinom",
		"\\binom",
		"\\tbinom",
		"\\\\atopfrac",
		"\\\\bracefrac",
		"\\\\brackfrac"
	],
	numArgs: 2,
	allowedInArgument: !0,
	handler: (e, t) => {
		var n = e.parser, r = e.funcName, i = t[0], a = t[1], o, s = null, c = null;
		switch (r) {
			case "\\cfrac":
			case "\\dfrac":
			case "\\frac":
			case "\\tfrac":
				o = !0;
				break;
			case "\\\\atopfrac":
				o = !1;
				break;
			case "\\dbinom":
			case "\\binom":
			case "\\tbinom":
				o = !1, s = "(", c = ")";
				break;
			case "\\\\bracefrac":
				o = !1, s = "\\{", c = "\\}";
				break;
			case "\\\\brackfrac":
				o = !1, s = "[", c = "]";
				break;
			default: throw Error("Unrecognized genfrac command");
		}
		var l = r === "\\cfrac", u = null;
		return l || r.startsWith("\\d") ? u = "display" : r.startsWith("\\t") && (u = "text"), Ci({
			type: "genfrac",
			mode: n.mode,
			numer: i,
			denom: a,
			continued: l,
			hasBarLine: o,
			leftDelim: s,
			rightDelim: c,
			barSize: null
		}, u);
	},
	htmlBuilder: xi,
	mathmlBuilder: Si
}), K({
	type: "infix",
	names: [
		"\\over",
		"\\choose",
		"\\atop",
		"\\brace",
		"\\brack"
	],
	numArgs: 0,
	infix: !0,
	handler(e) {
		var t = e.parser, n = e.funcName, r = e.token, i;
		switch (n) {
			case "\\over":
				i = "\\frac";
				break;
			case "\\choose":
				i = "\\binom";
				break;
			case "\\atop":
				i = "\\\\atopfrac";
				break;
			case "\\brace":
				i = "\\\\bracefrac";
				break;
			case "\\brack":
				i = "\\\\brackfrac";
				break;
			default: throw Error("Unrecognized infix genfrac command");
		}
		return {
			type: "infix",
			mode: t.mode,
			replaceWith: i,
			token: r
		};
	}
});
var wi = [
	"display",
	"text",
	"script",
	"scriptscript"
], Ti = function(e) {
	var t = null;
	return e.length > 0 && (t = e, t = t === "." ? null : t), t;
};
K({
	type: "genfrac",
	names: ["\\genfrac"],
	numArgs: 6,
	allowedInArgument: !0,
	argTypes: [
		"math",
		"math",
		"size",
		"text",
		"math",
		"math"
	],
	handler(e, t) {
		var n = e.parser, r = t[4], i = t[5], a = ln(t[0]), o = a.type === "atom" && a.family === "open" ? Ti(a.text) : null, s = ln(t[1]), c = s.type === "atom" && s.family === "close" ? Ti(s.text) : null, l = X(t[2], "size"), u, d = null;
		l.isBlank ? u = !0 : (d = l.value, u = d.number > 0);
		var f = null, p = t[3];
		if (p.type === "ordgroup") {
			if (p.body.length > 0) {
				var m = X(p.body[0], "textord");
				f = wi[Number(m.text)];
			}
		} else p = X(p, "textord"), f = wi[Number(p.text)];
		return Ci({
			type: "genfrac",
			mode: n.mode,
			numer: r,
			denom: i,
			continued: !1,
			hasBarLine: u,
			barSize: d,
			leftDelim: o,
			rightDelim: c
		}, f);
	}
}), K({
	type: "infix",
	names: ["\\above"],
	numArgs: 1,
	argTypes: ["size"],
	infix: !0,
	handler(e, t) {
		var n = e.parser;
		e.funcName;
		var r = e.token;
		return {
			type: "infix",
			mode: n.mode,
			replaceWith: "\\\\abovefrac",
			size: X(t[0], "size").value,
			token: r
		};
	}
}), K({
	type: "genfrac",
	names: ["\\\\abovefrac"],
	numArgs: 3,
	argTypes: [
		"math",
		"size",
		"math"
	],
	handler: (e, t) => {
		var n = e.parser;
		e.funcName;
		var r = t[0], i = X(t[1], "infix").size;
		if (!i) throw Error("\\\\abovefrac expected size, but got " + String(i));
		var a = t[2], o = i.number > 0;
		return {
			type: "genfrac",
			mode: n.mode,
			numer: r,
			denom: a,
			continued: !1,
			hasBarLine: o,
			barSize: i,
			leftDelim: null,
			rightDelim: null
		};
	}
});
var Ei = (e, t) => {
	var n = t.style, r, i;
	e.type === "supsub" ? (r = e.sup ? q(e.sup, t.havingStyle(n.sup()), t) : q(e.sub, t.havingStyle(n.sub()), t), i = X(e.base, "horizBrace")) : i = X(e, "horizBrace");
	var a = q(i.base, t.havingBaseStyle(T.DISPLAY)), o = Jn(i, t), s = i.isOver ? W({
		positionType: "firstBaseline",
		children: [
			{
				type: "elem",
				elem: a
			},
			{
				type: "kern",
				size: .1
			},
			{
				type: "elem",
				elem: o,
				wrapperClasses: ["svg-align"]
			}
		]
	}) : W({
		positionType: "bottom",
		positionData: a.depth + .1 + o.height,
		children: [
			{
				type: "elem",
				elem: o,
				wrapperClasses: ["svg-align"]
			},
			{
				type: "kern",
				size: .1
			},
			{
				type: "elem",
				elem: a
			}
		]
	});
	if (r) {
		var c = U(["minner", i.isOver ? "mover" : "munder"], [s], t);
		s = i.isOver ? W({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: c
				},
				{
					type: "kern",
					size: .2
				},
				{
					type: "elem",
					elem: r
				}
			]
		}) : W({
			positionType: "bottom",
			positionData: c.depth + .2 + r.height + r.depth,
			children: [
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: .2
				},
				{
					type: "elem",
					elem: c
				}
			]
		});
	}
	return U(["minner", i.isOver ? "mover" : "munder"], [s], t);
};
K({
	type: "horizBrace",
	names: [
		"\\overbrace",
		"\\underbrace",
		"\\overbracket",
		"\\underbracket"
	],
	numArgs: 1,
	handler(e, t) {
		var n = e.parser, r = e.funcName;
		return {
			type: "horizBrace",
			mode: n.mode,
			label: r,
			isOver: r.includes("\\over"),
			base: t[0]
		};
	},
	htmlBuilder: Ei,
	mathmlBuilder: (e, t) => {
		var n = Gn(e.label);
		return new J(e.isOver ? "mover" : "munder", [Y(e.base, t), n]);
	}
}), K({
	type: "href",
	names: ["\\href"],
	numArgs: 2,
	argTypes: ["url", "original"],
	allowedInText: !0,
	handler: (e, t) => {
		var n = e.parser, r = t[1], i = X(t[0], "url").url;
		return n.settings.isTrusted({
			command: "\\href",
			url: i
		}) ? {
			type: "href",
			mode: n.mode,
			href: i,
			body: un(r)
		} : n.formatUnsupportedCmd("\\href");
	},
	htmlBuilder: (e, t) => {
		var n = hn(e.body, t, !1);
		return Gt(e.href, [], n, t);
	},
	mathmlBuilder: (e, t) => {
		var n = Pn(e.body, t);
		return n instanceof J || (n = new J("mrow", [n])), n.setAttribute("href", e.href), n;
	}
}), K({
	type: "href",
	names: ["\\url"],
	numArgs: 1,
	argTypes: ["url"],
	allowedInText: !0,
	handler: (e, t) => {
		var n = e.parser, r = X(t[0], "url").url;
		if (!n.settings.isTrusted({
			command: "\\url",
			url: r
		})) return n.formatUnsupportedCmd("\\url");
		for (var i = [], a = 0; a < r.length; a++) {
			var o = r[a];
			o === "~" && (o = "\\textasciitilde"), i.push({
				type: "textord",
				mode: "text",
				text: o
			});
		}
		var s = {
			type: "text",
			mode: n.mode,
			font: "\\texttt",
			body: i
		};
		return {
			type: "href",
			mode: n.mode,
			href: r,
			body: un(s)
		};
	}
}), K({
	type: "hbox",
	names: ["\\hbox"],
	numArgs: 1,
	argTypes: ["text"],
	allowedInText: !0,
	primitive: !0,
	handler(e, t) {
		return {
			type: "hbox",
			mode: e.parser.mode,
			body: un(t[0])
		};
	},
	htmlBuilder(e, t) {
		return Kt(hn(e.body, t.withFont(""), !1));
	},
	mathmlBuilder(e, t) {
		return new J("mrow", Nn(e.body, t.withFont("")));
	}
}), K({
	type: "html",
	names: [
		"\\htmlClass",
		"\\htmlId",
		"\\htmlStyle",
		"\\htmlData"
	],
	numArgs: 2,
	argTypes: ["raw", "original"],
	allowedInText: !0,
	handler: (e, n) => {
		var r = e.parser, i = e.funcName;
		e.token;
		var a = X(n[0], "raw").string, o = n[1];
		r.settings.strict && Pt({
			strict: r.settings.strict,
			errorCode: "htmlExtension",
			errorMsg: "HTML extension is disabled on strict mode",
			report: !0
		});
		var s, c = {};
		switch (i) {
			case "\\htmlClass":
				c.class = a, s = {
					command: "\\htmlClass",
					class: a
				};
				break;
			case "\\htmlId":
				c.id = a, s = {
					command: "\\htmlId",
					id: a
				};
				break;
			case "\\htmlStyle":
				c.style = a, s = {
					command: "\\htmlStyle",
					style: a
				};
				break;
			case "\\htmlData":
				for (var l = "{,}", u = [], d = "", f = 0; f < a.length; f++) a.startsWith(l, f) ? (d += ",", f += l.length - 1) : a[f] === "," ? (u.push(d), d = "") : d += a[f];
				u.push(d);
				for (var p = 0; p < u.length; p++) {
					var m = u[p], h = m.indexOf("=");
					if (h < 0) throw new t("\\htmlData key/value '" + m + "' missing equals sign");
					var g = m.slice(0, h), _ = m.slice(h + 1);
					c["data-" + g.trim()] = _;
				}
				s = {
					command: "\\htmlData",
					attributes: c
				};
				break;
			default: throw Error("Unrecognized html command");
		}
		return r.settings.isTrusted(s) ? {
			type: "html",
			mode: r.mode,
			attributes: c,
			body: un(o)
		} : r.formatUnsupportedCmd(i);
	},
	htmlBuilder: (e, t) => {
		var n = hn(e.body, t, !1), r = ["enclosing"];
		e.attributes.class && r.push(...e.attributes.class.trim().split(/\s+/));
		var i = U(r, n, t);
		for (var a of Object.entries(e.attributes)) {
			var o = a[0], s = a[1];
			o !== "class" && i.setAttribute(o, s);
		}
		return i;
	},
	mathmlBuilder: (e, t) => Pn(e.body, t)
}), K({
	type: "htmlmathml",
	names: ["\\html@mathml"],
	numArgs: 2,
	allowedInArgument: !0,
	allowedInText: !0,
	handler: (e, t) => ({
		type: "htmlmathml",
		mode: e.parser.mode,
		html: un(t[0]),
		mathml: un(t[1])
	}),
	htmlBuilder: (e, t) => Kt(hn(e.html, t, !1)),
	mathmlBuilder: (e, t) => Pn(e.mathml, t)
});
var Di = function(e) {
	if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e)) return {
		number: +e,
		unit: "bp"
	};
	var n = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e);
	if (!n) throw new t("Invalid size: '" + e + "' in \\includegraphics");
	var r = {
		number: +(n[1] + n[2]),
		unit: n[3]
	};
	if (!De(r)) throw new t("Invalid unit: '" + r.unit + "' in \\includegraphics.");
	return r;
};
K({
	type: "includegraphics",
	names: ["\\includegraphics"],
	numArgs: 1,
	numOptionalArgs: 1,
	argTypes: ["raw", "url"],
	allowedInText: !1,
	handler: (e, n, r) => {
		var i = e.parser, a = {
			number: 0,
			unit: "em"
		}, o = {
			number: .9,
			unit: "em"
		}, s = {
			number: 0,
			unit: "em"
		}, c = "";
		if (r[0]) for (var l = X(r[0], "raw").string.split(","), u = 0; u < l.length; u++) {
			var d = l[u].split("=");
			if (d.length === 2) {
				var f = d[1].trim();
				switch (d[0].trim()) {
					case "alt":
						c = f;
						break;
					case "width":
						a = Di(f);
						break;
					case "height":
						o = Di(f);
						break;
					case "totalheight":
						s = Di(f);
						break;
					default: throw new t("Invalid key: '" + d[0] + "' in \\includegraphics.");
				}
			}
		}
		var p = X(n[0], "url").url;
		return c === "" && (c = p, c = c.replace(/^.*[\\/]/, ""), c = c.substring(0, c.lastIndexOf("."))), i.settings.isTrusted({
			command: "\\includegraphics",
			url: p
		}) ? {
			type: "includegraphics",
			mode: i.mode,
			alt: c,
			width: a,
			height: o,
			totalheight: s,
			src: p
		} : i.formatUnsupportedCmd("\\includegraphics");
	},
	htmlBuilder: (e, t) => {
		var n = D(e.height, t), r = 0;
		e.totalheight.number > 0 && (r = D(e.totalheight, t) - n);
		var i = 0;
		e.width.number > 0 && (i = D(e.width, t));
		var a = { height: O(n + r) };
		i > 0 && (a.width = O(i)), r > 0 && (a.verticalAlign = O(-r));
		var o = new Ie(e.src, e.alt, a);
		return o.height = n, o.depth = r, o;
	},
	mathmlBuilder: (e, t) => {
		var n = new J("mglyph", []);
		n.setAttribute("alt", e.alt);
		var r = D(e.height, t), i = 0;
		if (e.totalheight.number > 0 && (i = D(e.totalheight, t) - r, n.setAttribute("valign", O(-i))), n.setAttribute("height", O(r + i)), e.width.number > 0) {
			var a = D(e.width, t);
			n.setAttribute("width", O(a));
		}
		return n.setAttribute("src", e.src), n;
	}
}), K({
	type: "kern",
	names: [
		"\\kern",
		"\\mkern",
		"\\hskip",
		"\\mskip"
	],
	numArgs: 1,
	argTypes: ["size"],
	primitive: !0,
	allowedInText: !0,
	handler(e, t) {
		var n = e.parser, r = e.funcName, i = X(t[0], "size");
		if (n.settings.strict) {
			var a = r[1] === "m", o = i.value.unit === "mu";
			a ? (o || Pt({
				strict: n.settings.strict,
				errorCode: "mathVsTextUnits",
				errorMsg: "LaTeX's " + r + " supports only mu units, " + ("not " + i.value.unit + " units"),
				report: !0
			}), n.mode !== "math" && Pt({
				strict: n.settings.strict,
				errorCode: "mathVsTextUnits",
				errorMsg: "LaTeX's " + r + " works only in math mode",
				report: !0
			})) : o && Pt({
				strict: n.settings.strict,
				errorCode: "mathVsTextUnits",
				errorMsg: "LaTeX's " + r + " doesn't support mu units",
				report: !0
			});
		}
		return {
			type: "kern",
			mode: n.mode,
			dimension: i.value
		};
	},
	htmlBuilder(e, t) {
		return Yt(e.dimension, t);
	},
	mathmlBuilder(e, t) {
		return new Tn(D(e.dimension, t));
	}
}), K({
	type: "lap",
	names: [
		"\\mathllap",
		"\\mathrlap",
		"\\mathclap"
	],
	numArgs: 1,
	allowedInText: !0,
	handler: (e, t) => {
		var n = e.parser, r = e.funcName, i = t[0];
		return {
			type: "lap",
			mode: n.mode,
			alignment: r.slice(5),
			body: i
		};
	},
	htmlBuilder: (e, t) => {
		var n;
		e.alignment === "clap" ? (n = U([], [q(e.body, t)]), n = U(["katex-inner"], [n], t)) : n = U(["katex-inner"], [q(e.body, t)]);
		var r = U(["katex-fix"], []), i = U([e.alignment], [n, r], t), a = U(["katex-strut"]);
		return a.style.height = O(i.height + i.depth), i.depth && (a.style.verticalAlign = O(-i.depth)), i.children.unshift(a), i = U(["katex-thinbox"], [i], t), U(["mord", "katex-vbox"], [i], t);
	},
	mathmlBuilder: (e, t) => {
		var n = new J("mpadded", [Y(e.body, t)]);
		if (e.alignment !== "rlap") {
			var r = e.alignment === "llap" ? "-1" : "-0.5";
			n.setAttribute("lspace", r + "width");
		}
		return n.setAttribute("width", "0px"), n;
	}
}), K({
	type: "styling",
	names: ["\\(", "$"],
	numArgs: 0,
	allowedInText: !0,
	allowedInMath: !1,
	handler(e, t) {
		var n = e.funcName, r = e.parser, i = r.mode;
		r.switchMode("math");
		var a = n === "\\(" ? "\\)" : "$", o = r.parseExpression(!1, a);
		return r.expect(a), r.switchMode(i), {
			type: "styling",
			mode: r.mode,
			style: "text",
			resetFont: !0,
			body: o
		};
	}
}), K({
	type: "text",
	names: ["\\)", "\\]"],
	numArgs: 0,
	allowedInText: !0,
	allowedInMath: !1,
	handler(e, n) {
		throw new t("Mismatched " + e.funcName);
	}
});
var Oi = (e, t) => {
	switch (t.style.size) {
		case T.DISPLAY.size: return e.display;
		case T.TEXT.size: return e.text;
		case T.SCRIPT.size: return e.script;
		case T.SCRIPTSCRIPT.size: return e.scriptscript;
		default: return e.text;
	}
};
K({
	type: "mathchoice",
	names: ["\\mathchoice"],
	numArgs: 4,
	primitive: !0,
	handler: (e, t) => ({
		type: "mathchoice",
		mode: e.parser.mode,
		display: un(t[0]),
		text: un(t[1]),
		script: un(t[2]),
		scriptscript: un(t[3])
	}),
	htmlBuilder: (e, t) => Kt(hn(Oi(e, t), t, !1)),
	mathmlBuilder: (e, t) => Pn(Oi(e, t), t)
});
var ki = (e, t, n, r, i, a, o) => {
	e = U([], [e]);
	var s = n && l(n), c, u;
	if (t) {
		var d = q(t, r.havingStyle(i.sup()), r);
		u = {
			elem: d,
			kern: Math.max(r.fontMetrics().bigOpSpacing1, r.fontMetrics().bigOpSpacing3 - d.depth)
		};
	}
	if (n) {
		var f = q(n, r.havingStyle(i.sub()), r);
		c = {
			elem: f,
			kern: Math.max(r.fontMetrics().bigOpSpacing2, r.fontMetrics().bigOpSpacing4 - f.height)
		};
	}
	var p;
	if (u && c) p = W({
		positionType: "bottom",
		positionData: r.fontMetrics().bigOpSpacing5 + c.elem.height + c.elem.depth + c.kern + e.depth + o,
		children: [
			{
				type: "kern",
				size: r.fontMetrics().bigOpSpacing5
			},
			{
				type: "elem",
				elem: c.elem,
				marginLeft: O(-a)
			},
			{
				type: "kern",
				size: c.kern
			},
			{
				type: "elem",
				elem: e
			},
			{
				type: "kern",
				size: u.kern
			},
			{
				type: "elem",
				elem: u.elem,
				marginLeft: O(a)
			},
			{
				type: "kern",
				size: r.fontMetrics().bigOpSpacing5
			}
		]
	});
	else if (c) p = W({
		positionType: "top",
		positionData: e.height - o,
		children: [
			{
				type: "kern",
				size: r.fontMetrics().bigOpSpacing5
			},
			{
				type: "elem",
				elem: c.elem,
				marginLeft: O(-a)
			},
			{
				type: "kern",
				size: c.kern
			},
			{
				type: "elem",
				elem: e
			}
		]
	});
	else if (u) p = W({
		positionType: "bottom",
		positionData: e.depth + o,
		children: [
			{
				type: "elem",
				elem: e
			},
			{
				type: "kern",
				size: u.kern
			},
			{
				type: "elem",
				elem: u.elem,
				marginLeft: O(a)
			},
			{
				type: "kern",
				size: r.fontMetrics().bigOpSpacing5
			}
		]
	});
	else return e;
	var m = [p];
	if (c && a !== 0 && !s) {
		var h = U(["mspace"], [], r);
		h.style.marginRight = O(a), m.unshift(h);
	}
	return U(["mop", "op-limits"], m, r);
}, Ai = /* @__PURE__ */ new Set(["\\smallint"]), ji = (e, t) => {
	var n, r, i = !1, a;
	e.type === "supsub" ? (n = e.sup, r = e.sub, a = X(e.base, "op"), i = !0) : a = X(e, "op");
	var o = t.style, s = !1;
	o.size === T.DISPLAY.size && a.symbol && !Ai.has(a.name) && (s = !0);
	var c, l;
	if (a.symbol) {
		var u = s ? "Size2-Regular" : "Size1-Regular", d = "";
		if ((a.name === "\\oiint" || a.name === "\\oiiint") && (d = a.name.slice(1), a.name = d === "oiint" ? "\\iint" : "\\iiint"), c = It(a.name, u, "math", t, [
			"mop",
			"op-symbol",
			s ? "large-op" : "small-op"
		]), l = c.italic, d.length > 0) {
			var f = $t(d + "Size" + (s ? "2" : "1"), t);
			c = W({
				positionType: "individualShift",
				children: [{
					type: "elem",
					elem: c,
					shift: 0
				}, {
					type: "elem",
					elem: f,
					shift: s ? .08 : 0
				}]
			}), a.name = "\\" + d, c.classes.unshift("mop"), c.italic = l;
		}
	} else if (a.body) {
		var p = hn(a.body, t, !0);
		p.length === 1 && p[0] instanceof Re ? (c = p[0], c.classes[0] = "mop") : c = U(["mop"], p, t);
	} else {
		for (var m = [], h = 1; h < a.name.length; h++) m.push(Lt(a.name[h], a.mode, t));
		c = U(["mop"], m, t);
	}
	var g = 0, _ = 0;
	return (c instanceof Re || a.name === "\\oiint" || a.name === "\\oiiint") && !a.suppressBaseShift && (g = (c.height - c.depth) / 2 - t.fontMetrics().axisHeight, _ = c.italic ?? 0), i ? ki(c, n, r, t, o, _, g) : (g && (c.style.position = "relative", c.style.top = O(g)), c);
}, Mi = (e, t) => {
	var n;
	if (e.symbol) n = new J("mo", [On(e.name, e.mode)]), Ai.has(e.name) && n.setAttribute("largeop", "false");
	else if (e.body) n = new J("mo", Nn(e.body, t));
	else {
		n = new J("mi", [new wn(e.name.slice(1))]);
		var r = new J("mo", [On("⁡", "text")]);
		n = e.parentIsSupSub ? new J("mrow", [n, r]) : Cn([n, r]);
	}
	return n;
}, Ni = {
	"∏": "\\prod",
	"∐": "\\coprod",
	"∑": "\\sum",
	"⋀": "\\bigwedge",
	"⋁": "\\bigvee",
	"⋂": "\\bigcap",
	"⋃": "\\bigcup",
	"⨀": "\\bigodot",
	"⨁": "\\bigoplus",
	"⨂": "\\bigotimes",
	"⨄": "\\biguplus",
	"⨆": "\\bigsqcup"
};
K({
	type: "op",
	names: /* @__PURE__ */ "\\coprod.\\bigvee.\\bigwedge.\\biguplus.\\bigcap.\\bigcup.\\intop.\\prod.\\sum.\\bigotimes.\\bigoplus.\\bigodot.\\bigsqcup.\\smallint.∏.∐.∑.⋀.⋁.⋂.⋃.⨀.⨁.⨂.⨄.⨆".split("."),
	numArgs: 0,
	handler: (e, t) => {
		var n = e.parser, r = e.funcName;
		return r.length === 1 && (r = Ni[r]), {
			type: "op",
			mode: n.mode,
			limits: !0,
			parentIsSupSub: !1,
			symbol: !0,
			name: r
		};
	},
	htmlBuilder: ji,
	mathmlBuilder: Mi
}), K({
	type: "op",
	names: ["\\mathop"],
	numArgs: 1,
	primitive: !0,
	handler: (e, t) => {
		var n = e.parser, r = t[0];
		return {
			type: "op",
			mode: n.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !1,
			body: un(r)
		};
	}
});
var Pi = {
	"∫": "\\int",
	"∬": "\\iint",
	"∭": "\\iiint",
	"∮": "\\oint",
	"∯": "\\oiint",
	"∰": "\\oiiint"
};
K({
	type: "op",
	names: /* @__PURE__ */ "\\arcsin.\\arccos.\\arctan.\\arctg.\\arcctg.\\arg.\\ch.\\cos.\\cosec.\\cosh.\\cot.\\cotg.\\coth.\\csc.\\ctg.\\cth.\\deg.\\dim.\\exp.\\hom.\\ker.\\lg.\\ln.\\log.\\sec.\\sin.\\sinh.\\sh.\\tan.\\tanh.\\tg.\\th".split("."),
	numArgs: 0,
	handler(e) {
		var t = e.parser, n = e.funcName;
		return {
			type: "op",
			mode: t.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !1,
			name: n
		};
	}
}), K({
	type: "op",
	names: [
		"\\det",
		"\\gcd",
		"\\inf",
		"\\lim",
		"\\max",
		"\\min",
		"\\Pr",
		"\\sup"
	],
	numArgs: 0,
	handler(e) {
		var t = e.parser, n = e.funcName;
		return {
			type: "op",
			mode: t.mode,
			limits: !0,
			parentIsSupSub: !1,
			symbol: !1,
			name: n
		};
	}
}), K({
	type: "op",
	names: [
		"\\int",
		"\\iint",
		"\\iiint",
		"\\oint",
		"\\oiint",
		"\\oiiint",
		"∫",
		"∬",
		"∭",
		"∮",
		"∯",
		"∰"
	],
	numArgs: 0,
	allowedInArgument: !0,
	handler(e) {
		var t = e.parser, n = e.funcName;
		return n.length === 1 && (n = Pi[n]), {
			type: "op",
			mode: t.mode,
			limits: !1,
			parentIsSupSub: !1,
			symbol: !0,
			name: n
		};
	}
});
var Fi = (e, t) => {
	var n, r, i = !1, a;
	e.type === "supsub" ? (n = e.sup, r = e.sub, a = X(e.base, "operatorname"), i = !0) : a = X(e, "operatorname");
	var o;
	if (a.body.length > 0) {
		for (var s = hn(a.body.map((e) => {
			var t = "text" in e ? e.text : void 0;
			return typeof t == "string" ? {
				type: "textord",
				mode: e.mode,
				text: t
			} : e;
		}), t.withFont("mathrm"), !0), c = 0; c < s.length; c++) {
			var l = s[c];
			l instanceof Re && (l.text = l.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
		}
		o = U(["mop"], s, t);
	} else o = U(["mop"], [], t);
	return i ? ki(o, n, r, t, t.style, 0, 0) : o;
};
K({
	type: "operatorname",
	names: ["\\operatorname@", "\\operatornamewithlimits"],
	numArgs: 1,
	handler: (e, t) => {
		var n = e.parser, r = e.funcName, i = t[0];
		return {
			type: "operatorname",
			mode: n.mode,
			body: un(i),
			alwaysHandleSupSub: r === "\\operatornamewithlimits",
			limits: !1,
			parentIsSupSub: !1
		};
	},
	htmlBuilder: Fi,
	mathmlBuilder: (e, t) => {
		for (var n = Nn(e.body, t.withFont("mathrm")), r = !0, i = 0; i < n.length; i++) {
			var a = n[i];
			if (!(a instanceof Tn)) {
				if (a instanceof J) switch (a.type) {
					case "mi":
					case "mn":
					case "mspace":
					case "mtext": break;
					case "mo":
						var o = a.children[0];
						a.children.length === 1 && o instanceof wn ? o.text = o.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : r = !1;
						break;
					default: r = !1;
				}
				else r = !1;
			}
		}
		r && (n = [new wn(n.map((e) => e.toText()).join(""))]);
		var s = new J("mi", n);
		s.setAttribute("mathvariant", "normal");
		var c = new J("mo", [On("⁡", "text")]);
		return e.parentIsSupSub ? new J("mrow", [s, c]) : Cn([s, c]);
	}
}), Z("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@"), cn({
	type: "ordgroup",
	htmlBuilder(e, t) {
		return e.semisimple ? Kt(hn(e.body, t, !1)) : U(["mord"], hn(e.body, t, !0), t);
	},
	mathmlBuilder(e, t) {
		return Pn(e.body, t, !0);
	}
}), K({
	type: "overline",
	names: ["\\overline"],
	numArgs: 1,
	handler(e, t) {
		var n = e.parser, r = t[0];
		return {
			type: "overline",
			mode: n.mode,
			body: r
		};
	},
	htmlBuilder(e, t) {
		var n = q(e.body, t.havingCrampedStyle()), r = Wt("overline-line", t), i = t.fontMetrics().defaultRuleThickness;
		return U(["mord", "katex-overline"], [W({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: n
				},
				{
					type: "kern",
					size: 3 * i
				},
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: i
				}
			]
		})], t);
	},
	mathmlBuilder(e, t) {
		var n = new J("mo", [new wn("‾")]);
		n.setAttribute("stretchy", "true");
		var r = new J("mover", [Y(e.body, t), n]);
		return r.setAttribute("accent", "true"), r;
	}
}), K({
	type: "phantom",
	names: ["\\phantom"],
	numArgs: 1,
	allowedInText: !0,
	handler: (e, t) => {
		var n = e.parser, r = t[0];
		return {
			type: "phantom",
			mode: n.mode,
			body: un(r)
		};
	},
	htmlBuilder: (e, t) => Kt(hn(e.body, t.withPhantom(), !1)),
	mathmlBuilder: (e, t) => new J("mphantom", Nn(e.body, t))
}), Z("\\hphantom", "\\smash{\\phantom{#1}}"), K({
	type: "vphantom",
	names: ["\\vphantom"],
	numArgs: 1,
	allowedInText: !0,
	handler: (e, t) => {
		var n = e.parser, r = t[0];
		return {
			type: "vphantom",
			mode: n.mode,
			body: r
		};
	},
	htmlBuilder: (e, t) => U(["mord", "rlap"], [U(["katex-inner"], [q(e.body, t.withPhantom())]), U(["katex-fix"], [])], t),
	mathmlBuilder: (e, t) => {
		var n = new J("mpadded", [new J("mphantom", Nn(un(e.body), t))]);
		return n.setAttribute("width", "0px"), n;
	}
}), K({
	type: "raisebox",
	names: ["\\raisebox"],
	numArgs: 2,
	argTypes: ["size", "hbox"],
	allowedInText: !0,
	handler(e, t) {
		var n = e.parser, r = X(t[0], "size").value, i = t[1];
		return {
			type: "raisebox",
			mode: n.mode,
			dy: r,
			body: i
		};
	},
	htmlBuilder(e, t) {
		var n = q(e.body, t);
		return W({
			positionType: "shift",
			positionData: -D(e.dy, t),
			children: [{
				type: "elem",
				elem: n
			}]
		});
	},
	mathmlBuilder(e, t) {
		var n = new J("mpadded", [Y(e.body, t)]), r = e.dy.number + e.dy.unit;
		return n.setAttribute("voffset", r), n;
	}
});
var Ii = (e, t) => ({
	type: "reflectbox",
	mode: e.parser.mode,
	body: t[0]
});
K({
	type: "reflectbox",
	names: ["\\reflectbox"],
	numArgs: 1,
	argTypes: ["hbox"],
	allowedInText: !0,
	handler: Ii,
	htmlBuilder(e, t) {
		return U(["mord", "reflectbox"], [q(e.body, t)], t);
	},
	mathmlBuilder(e, t) {
		return Y(e.body, t);
	}
}), K({
	type: "reflectbox",
	names: ["\\mathreflectbox"],
	numArgs: 1,
	argTypes: ["math"],
	handler: Ii
}), K({
	type: "internal",
	names: ["\\relax"],
	numArgs: 0,
	allowedInText: !0,
	allowedInArgument: !0,
	handler(e) {
		return {
			type: "internal",
			mode: e.parser.mode
		};
	}
}), K({
	type: "rule",
	names: ["\\rule"],
	numArgs: 2,
	numOptionalArgs: 1,
	allowedInText: !0,
	allowedInMath: !0,
	argTypes: [
		"size",
		"size",
		"size"
	],
	handler(e, t, n) {
		var r = e.parser, i = n[0], a = X(t[0], "size"), o = X(t[1], "size");
		return {
			type: "rule",
			mode: r.mode,
			shift: i && X(i, "size").value,
			width: a.value,
			height: o.value
		};
	},
	htmlBuilder(e, t) {
		var n = U(["mord", "katex-rule"], [], t), r = D(e.width, t), i = D(e.height, t), a = e.shift ? D(e.shift, t) : 0;
		return n.style.borderRightWidth = O(r), n.style.borderTopWidth = O(i), n.style.bottom = O(a), n.width = r, n.height = i + a, n.depth = -a, n.maxFontSize = i * 1.125 * t.sizeMultiplier, n;
	},
	mathmlBuilder(e, t) {
		var n = D(e.width, t), r = D(e.height, t), i = e.shift ? D(e.shift, t) : 0, a = t.color && t.getColor() || "black", o = new J("mspace");
		o.setAttribute("mathbackground", a), o.setAttribute("width", O(n)), o.setAttribute("height", O(r));
		var s = new J("mpadded", [o]);
		return i >= 0 ? s.setAttribute("height", O(i)) : (s.setAttribute("height", O(i)), s.setAttribute("depth", O(-i))), s.setAttribute("voffset", O(i)), s;
	}
});
function Li(e, t, n) {
	for (var r = hn(e, t, !1), i = t.sizeMultiplier / n.sizeMultiplier, a = 0; a < r.length; a++) {
		var o = r[a].classes.indexOf("katex-sizing");
		o < 0 ? Array.prototype.push.apply(r[a].classes, t.sizingClasses(n)) : r[a].classes[o + 1] === "reset-size" + t.size && (r[a].classes[o + 1] = "reset-size" + n.size), r[a].height *= i, r[a].depth *= i;
	}
	return Kt(r);
}
var Ri = [
	"\\tiny",
	"\\sixptsize",
	"\\scriptsize",
	"\\footnotesize",
	"\\small",
	"\\normalsize",
	"\\large",
	"\\Large",
	"\\LARGE",
	"\\huge",
	"\\Huge"
];
K({
	type: "sizing",
	names: Ri,
	numArgs: 0,
	allowedInText: !0,
	handler: (e, t) => {
		var n = e.breakOnTokenText, r = e.funcName, i = e.parser, a = i.parseExpression(!1, n);
		return {
			type: "sizing",
			mode: i.mode,
			size: Ri.indexOf(r) + 1,
			body: a
		};
	},
	htmlBuilder: (e, t) => {
		var n = t.havingSize(e.size);
		return Li(e.body, n, t);
	},
	mathmlBuilder: (e, t) => {
		var n = t.havingSize(e.size), r = new J("mstyle", Nn(e.body, n));
		return r.setAttribute("mathsize", O(n.sizeMultiplier)), r;
	}
}), K({
	type: "smash",
	names: ["\\smash"],
	numArgs: 1,
	numOptionalArgs: 1,
	allowedInText: !0,
	handler: (e, t, n) => {
		var r = e.parser, i = !1, a = !1, o = n[0] && X(n[0], "ordgroup");
		if (o) for (var s, c = 0; c < o.body.length; ++c) {
			var l = o.body[c];
			if (s = tr(l).text, s === "t") i = !0;
			else if (s === "b") a = !0;
			else {
				i = !1, a = !1;
				break;
			}
		}
		else i = !0, a = !0;
		var u = t[0];
		return {
			type: "smash",
			mode: r.mode,
			body: u,
			smashHeight: i,
			smashDepth: a
		};
	},
	htmlBuilder: (e, t) => {
		var n = U([], [q(e.body, t)]);
		if (!e.smashHeight && !e.smashDepth) return n;
		if (e.smashHeight && (n.height = 0), e.smashDepth && (n.depth = 0), e.smashHeight && e.smashDepth) return U(["mord", "katex-smash"], [n], t);
		if (n.children) for (var r = 0; r < n.children.length; r++) e.smashHeight && (n.children[r].height = 0), e.smashDepth && (n.children[r].depth = 0);
		return U(["mord"], [W({
			positionType: "firstBaseline",
			children: [{
				type: "elem",
				elem: n
			}]
		})], t);
	},
	mathmlBuilder: (e, t) => {
		var n = new J("mpadded", [Y(e.body, t)]);
		return e.smashHeight && n.setAttribute("height", "0px"), e.smashDepth && n.setAttribute("depth", "0px"), n;
	}
}), K({
	type: "sqrt",
	names: ["\\sqrt"],
	numArgs: 1,
	numOptionalArgs: 1,
	handler(e, t, n) {
		var r = e.parser, i = n[0], a = t[0];
		return {
			type: "sqrt",
			mode: r.mode,
			body: a,
			index: i
		};
	},
	htmlBuilder(e, t) {
		var n = q(e.body, t.havingCrampedStyle());
		n.height === 0 && (n.height = t.fontMetrics().xHeight), n = qt(n, t);
		var r = t.fontMetrics().defaultRuleThickness, i = r;
		t.style.id < T.TEXT.id && (i = t.fontMetrics().xHeight);
		var a = r + i / 4, o = Rr(n.height + n.depth + a + r, t), s = o.span, c = o.ruleWidth, l = o.advanceWidth, u = s.height - c;
		u > n.height + n.depth + a && (a = (a + u - n.height - n.depth) / 2);
		var d = s.height - n.height - a - c;
		n.style.paddingLeft = O(l);
		var f = W({
			positionType: "firstBaseline",
			children: [
				{
					type: "elem",
					elem: n,
					wrapperClasses: ["svg-align"]
				},
				{
					type: "kern",
					size: -(n.height + d)
				},
				{
					type: "elem",
					elem: s
				},
				{
					type: "kern",
					size: c
				}
			]
		});
		if (e.index) {
			var p = t.havingStyle(T.SCRIPTSCRIPT), m = q(e.index, p, t);
			return U(["mord", "sqrt"], [U(["katex-root"], [W({
				positionType: "shift",
				positionData: -(.6 * (f.height - f.depth)),
				children: [{
					type: "elem",
					elem: m
				}]
			})]), f], t);
		}
		return U(["mord", "sqrt"], [f], t);
	},
	mathmlBuilder(e, t) {
		var n = e.body, r = e.index;
		return r ? new J("mroot", [Y(n, t), Y(r, t)]) : new J("msqrt", [Y(n, t)]);
	}
});
var zi = {
	display: T.DISPLAY,
	text: T.TEXT,
	script: T.SCRIPT,
	scriptscript: T.SCRIPTSCRIPT
};
function Bi(e) {
	return e in zi;
}
K({
	type: "styling",
	names: [
		"\\displaystyle",
		"\\textstyle",
		"\\scriptstyle",
		"\\scriptscriptstyle"
	],
	numArgs: 0,
	allowedInText: !0,
	primitive: !0,
	handler(e, t) {
		var n = e.breakOnTokenText, r = e.funcName, i = e.parser, a = i.parseExpression(!0, n), o = r.slice(1, r.length - 5);
		if (!Bi(o)) throw Error("Unknown style: " + o);
		return {
			type: "styling",
			mode: i.mode,
			style: o,
			body: a
		};
	},
	htmlBuilder(e, t) {
		var n = zi[e.style], r = t.havingStyle(n);
		return e.resetFont && (r = r.withFont("")), Li(e.body, r, t);
	},
	mathmlBuilder(e, t) {
		var n = zi[e.style], r = t.havingStyle(n);
		e.resetFont && (r = r.withFont(""));
		var i = new J("mstyle", Nn(e.body, r)), a = {
			display: ["0", "true"],
			text: ["0", "false"],
			script: ["1", "false"],
			scriptscript: ["2", "false"]
		}[e.style];
		return i.setAttribute("scriptlevel", a[0]), i.setAttribute("displaystyle", a[1]), i;
	}
});
var Vi = function(e, t) {
	var n = e.base;
	return n ? n.type === "op" ? n.limits && (t.style.size === T.DISPLAY.size || n.alwaysHandleSupSub) ? ji : null : n.type === "operatorname" ? n.alwaysHandleSupSub && (t.style.size === T.DISPLAY.size || n.limits) ? Fi : null : n.type === "accent" ? l(n.base) ? ar : null : n.type === "horizBrace" && !e.sub === n.isOver ? Ei : null : null;
};
cn({
	type: "supsub",
	htmlBuilder(e, t) {
		var n = Vi(e, t);
		if (n) return n(e, t);
		var r = e.base, i = e.sup, a = e.sub, o = q(r, t), s, c, u = t.fontMetrics(), d = 0, f = 0, p = r && l(r);
		if (i) {
			var m = t.havingStyle(t.style.sup());
			s = q(i, m, t), p || (d = o.height - m.fontMetrics().supDrop * m.sizeMultiplier / t.sizeMultiplier);
		}
		if (a) {
			var h = t.havingStyle(t.style.sub());
			c = q(a, h, t), p || (f = o.depth + h.fontMetrics().subDrop * h.sizeMultiplier / t.sizeMultiplier);
		}
		var g = t.style === T.DISPLAY ? u.sup1 : t.style.cramped ? u.sup3 : u.sup2, _ = t.sizeMultiplier, v = O(.5 / u.ptPerEm / _), y = null;
		if (c) {
			var b = e.base && e.base.type === "op" && e.base.name && (e.base.name === "\\oiint" || e.base.name === "\\oiiint");
			(o instanceof Re || b) && (y = O(-(o.italic ?? 0)));
		}
		var x;
		if (s && c) {
			d = Math.max(d, g, s.depth + .25 * u.xHeight), f = Math.max(f, u.sub2);
			var S = 4 * u.defaultRuleThickness;
			if (d - s.depth - (c.height - f) < S) {
				f = S - (d - s.depth) + c.height;
				var C = .8 * u.xHeight - (d - s.depth);
				C > 0 && (d += C, f -= C);
			}
			x = W({
				positionType: "individualShift",
				children: [{
					type: "elem",
					elem: c,
					shift: f,
					marginRight: v,
					marginLeft: y
				}, {
					type: "elem",
					elem: s,
					shift: -d,
					marginRight: v
				}]
			});
		} else if (c) f = Math.max(f, u.sub1, c.height - .8 * u.xHeight), x = W({
			positionType: "shift",
			positionData: f,
			children: [{
				type: "elem",
				elem: c,
				marginLeft: y,
				marginRight: v
			}]
		});
		else if (s) d = Math.max(d, g, s.depth + .25 * u.xHeight), x = W({
			positionType: "shift",
			positionData: -d,
			children: [{
				type: "elem",
				elem: s,
				marginRight: v
			}]
		});
		else throw Error("supsub must have either sup or sub.");
		return U([yn(o, "right") || "mord"], [o, U(["msupsub"], [x])], t);
	},
	mathmlBuilder(e, t) {
		var n = !1, r, i;
		e.base && e.base.type === "horizBrace" && (i = !!e.sup, i === e.base.isOver && (n = !0, r = e.base.isOver)), e.base && (e.base.type === "op" || e.base.type === "operatorname") && (e.base.parentIsSupSub = !0);
		var a = [Y(e.base, t)];
		e.sub && a.push(Y(e.sub, t)), e.sup && a.push(Y(e.sup, t));
		var o;
		if (n) o = r ? "mover" : "munder";
		else if (!e.sub) {
			var s = e.base;
			o = s && s.type === "op" && s.limits && (t.style === T.DISPLAY || s.alwaysHandleSupSub) || s && s.type === "operatorname" && s.alwaysHandleSupSub && (s.limits || t.style === T.DISPLAY) ? "mover" : "msup";
		} else if (e.sup) {
			var c = e.base;
			o = c && c.type === "op" && c.limits && t.style === T.DISPLAY || c && c.type === "operatorname" && c.alwaysHandleSupSub && (t.style === T.DISPLAY || c.limits) ? "munderover" : "msubsup";
		} else {
			var l = e.base;
			o = l && l.type === "op" && l.limits && (t.style === T.DISPLAY || l.alwaysHandleSupSub) || l && l.type === "operatorname" && l.alwaysHandleSupSub && (l.limits || t.style === T.DISPLAY) ? "munder" : "msub";
		}
		return new J(o, a);
	}
}), cn({
	type: "atom",
	htmlBuilder(e, t) {
		return Lt(e.text, e.mode, t, ["m" + e.family]);
	},
	mathmlBuilder(e, t) {
		var n = new J("mo", [On(e.text, e.mode)]);
		if (e.family === "bin") {
			var r = jn(e, t);
			r === "bold-italic" && n.setAttribute("mathvariant", r);
		} else e.family === "punct" ? n.setAttribute("separator", "true") : (e.family === "open" || e.family === "close") && n.setAttribute("stretchy", "false");
		return n;
	}
});
var Hi = {
	mi: "italic",
	mn: "normal",
	mtext: "normal"
};
cn({
	type: "mathord",
	htmlBuilder(e, t) {
		return zt(e, t);
	},
	mathmlBuilder(e, t) {
		var n = new J("mi", [On(e.text, e.mode, t)]), r = jn(e, t) || "italic";
		return r !== Hi[n.type] && n.setAttribute("mathvariant", r), n;
	}
}), cn({
	type: "textord",
	htmlBuilder(e, t) {
		return zt(e, t);
	},
	mathmlBuilder(e, t) {
		var n = On(e.text, e.mode, t), r = jn(e, t) || "normal", i = e.mode === "text" ? new J("mtext", [n]) : /[0-9]/.test(e.text) ? new J("mn", [n]) : e.text === "\\prime" ? new J("mo", [n]) : new J("mi", [n]);
		return r !== Hi[i.type] && i.setAttribute("mathvariant", r), i;
	}
});
var Ui = /* @__PURE__ */ new Map([["\\nobreak", "nobreak"], ["\\allowbreak", "allowbreak"]]), Wi = /* @__PURE__ */ new Map([
	[" ", {}],
	["\\ ", {}],
	["~", { className: "nobreak" }],
	["\\space", {}],
	["\\nobreakspace", { className: "nobreak" }]
]);
cn({
	type: "spacing",
	htmlBuilder(e, n) {
		var r = Wi.get(e.text), i = Ui.get(e.text);
		if (r) {
			var a = r.className || "";
			if (e.mode === "text") {
				var o = zt(e, n);
				return o.classes.push(a), o;
			}
			return U(["mspace", a], [Lt(e.text, e.mode, n)], n);
		}
		if (i) return U(["mspace", i], [], n);
		throw new t("Unknown type of space \"" + e.text + "\"");
	},
	mathmlBuilder(e, n) {
		var r;
		if (Wi.has(e.text)) r = new J("mtext", [new wn("\xA0")]);
		else if (Ui.has(e.text)) return new J("mspace");
		else throw new t("Unknown type of space \"" + e.text + "\"");
		return r;
	}
});
var Gi = () => {
	var e = new J("mtd", []);
	return e.setAttribute("width", "50%"), e;
};
cn({
	type: "tag",
	mathmlBuilder(e, t) {
		var n = new J("mtable", [new J("mtr", [
			Gi(),
			new J("mtd", [Pn(e.body, t)]),
			Gi(),
			new J("mtd", [Pn(e.tag, t)])
		])]);
		return n.setAttribute("width", "100%"), n;
	}
});
var Ki = {
	"\\text": void 0,
	"\\textrm": "textrm",
	"\\textsf": "textsf",
	"\\texttt": "texttt",
	"\\textnormal": "textrm"
}, qi = {
	"\\textbf": "textbf",
	"\\textmd": "textmd"
}, Ji = {
	"\\textit": "textit",
	"\\textup": "textup"
}, Yi = (e, t) => {
	var n = e.font;
	return n ? Ki[n] ? t.withTextFontFamily(Ki[n]) : qi[n] ? t.withTextFontWeight(qi[n]) : n === "\\emph" ? t.fontShape === "textit" ? t.withTextFontShape("textup") : t.withTextFontShape("textit") : t.withTextFontShape(Ji[n]) : t;
};
K({
	type: "text",
	names: [
		"\\text",
		"\\textrm",
		"\\textsf",
		"\\texttt",
		"\\textnormal",
		"\\textbf",
		"\\textmd",
		"\\textit",
		"\\textup",
		"\\emph"
	],
	numArgs: 1,
	argTypes: ["text"],
	allowedInArgument: !0,
	allowedInText: !0,
	handler(e, t) {
		var n = e.parser, r = e.funcName, i = t[0];
		return {
			type: "text",
			mode: n.mode,
			body: un(i),
			font: r
		};
	},
	htmlBuilder(e, t) {
		var n = Yi(e, t);
		return U(["mord", "text"], hn(e.body, n, !0), n);
	},
	mathmlBuilder(e, t) {
		var n = Yi(e, t);
		return Pn(e.body, n);
	}
}), K({
	type: "underline",
	names: ["\\underline"],
	numArgs: 1,
	allowedInText: !0,
	handler(e, t) {
		return {
			type: "underline",
			mode: e.parser.mode,
			body: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = q(e.body, t), r = Wt("underline-line", t), i = t.fontMetrics().defaultRuleThickness;
		return U(["mord", "katex-underline"], [W({
			positionType: "top",
			positionData: n.height,
			children: [
				{
					type: "kern",
					size: i
				},
				{
					type: "elem",
					elem: r
				},
				{
					type: "kern",
					size: 3 * i
				},
				{
					type: "elem",
					elem: n
				}
			]
		})], t);
	},
	mathmlBuilder(e, t) {
		var n = new J("mo", [new wn("‾")]);
		n.setAttribute("stretchy", "true");
		var r = new J("munder", [Y(e.body, t), n]);
		return r.setAttribute("accentunder", "true"), r;
	}
}), K({
	type: "vcenter",
	names: ["\\vcenter"],
	numArgs: 1,
	argTypes: ["original"],
	allowedInText: !1,
	handler(e, t) {
		return {
			type: "vcenter",
			mode: e.parser.mode,
			body: t[0]
		};
	},
	htmlBuilder(e, t) {
		var n = q(e.body, t), r = t.fontMetrics().axisHeight;
		return W({
			positionType: "shift",
			positionData: .5 * (n.height - r - (n.depth + r)),
			children: [{
				type: "elem",
				elem: n
			}]
		});
	},
	mathmlBuilder(e, t) {
		return new J("mrow", [new J("mpadded", [Y(e.body, t)], ["vcenter"])]);
	}
}), K({
	type: "verb",
	names: ["\\verb"],
	numArgs: 0,
	allowedInText: !0,
	handler(e, n, r) {
		throw new t("\\verb ended by end of line instead of matching delimiter");
	},
	htmlBuilder(e, t) {
		for (var n = Xi(e), r = [], i = t.havingStyle(t.style.text()), a = 0; a < n.length; a++) {
			var o = n[a];
			o === "~" && (o = "\\textasciitilde"), r.push(It(o, "Typewriter-Regular", e.mode, i, ["mord", "texttt"]));
		}
		return U(["mord", "text"].concat(i.sizingClasses(t)), Vt(r), i);
	},
	mathmlBuilder(e, t) {
		var n = new J("mtext", [new wn(Xi(e))]);
		return n.setAttribute("mathvariant", "monospace"), n;
	}
});
var Xi = (e) => e.body.replace(/ /g, e.star ? "␣" : "\xA0"), Zi = an, Qi = "[ \r\n	]", $i = "\\\\[a-zA-Z@]+", ea = "\\\\[^\ud800-\udfff]", ta = "(" + $i + ")" + Qi + "*", na = "\\\\(\n|[ \r	]+\n?)[ \r	]*", ra = "[̀-ͯ]", ia = RegExp(ra + "+$"), aa = "(" + Qi + "+)|" + (na + "|") + "([!-\\[\\]-‧‪-퟿豈-￿]" + (ra + "*") + "|[\ud800-\udbff][\udc00-\udfff]" + (ra + "*") + "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + ("|" + ta) + ("|" + ea + ")"), oa = class {
	constructor(e, t) {
		this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = e, this.settings = t, this.tokenRegex = new RegExp(aa, "g"), this.catcodes = {
			"%": 14,
			"~": 13
		};
	}
	setCatcode(e, t) {
		this.catcodes[e] = t;
	}
	lex() {
		var e = this.input, n = this.tokenRegex.lastIndex;
		if (n === e.length) return new oi("EOF", new ai(this, n, n));
		var r = this.tokenRegex.exec(e);
		if (r === null || r.index !== n) throw new t("Unexpected character: '" + e[n] + "'", new oi(e[n], new ai(this, n, n + 1)));
		var i = r[6] || r[3] || (r[2] ? "\\ " : " ");
		if (this.catcodes[i] === 14) {
			var a = e.indexOf("\n", this.tokenRegex.lastIndex);
			return a === -1 ? (this.tokenRegex.lastIndex = e.length, Pt({
				strict: this.settings.strict,
				errorCode: "commentAtEnd",
				errorMsg: "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)",
				report: !0
			})) : this.tokenRegex.lastIndex = a + 1, this.lex();
		}
		return new oi(i, new ai(this, n, this.tokenRegex.lastIndex));
	}
}, sa = class {
	constructor(e, t) {
		e === void 0 && (e = {}), t === void 0 && (t = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = t, this.builtins = e, this.undefStack = [];
	}
	beginGroup() {
		this.undefStack.push({});
	}
	endGroup() {
		if (this.undefStack.length === 0) throw new t("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug");
		var e = this.undefStack.pop();
		for (var n of Object.keys(e)) e[n] === void 0 ? delete this.current[n] : this.current[n] = e[n];
	}
	endGroups() {
		for (; this.undefStack.length > 0;) this.endGroup();
	}
	has(e) {
		return Object.prototype.hasOwnProperty.call(this.current, e) || Object.prototype.hasOwnProperty.call(this.builtins, e);
	}
	get(e) {
		if (Object.prototype.hasOwnProperty.call(this.current, e)) return this.current[e];
		if (Object.prototype.hasOwnProperty.call(this.builtins, e)) return this.builtins[e];
	}
	set(e, t, n) {
		if (n === void 0 && (n = !1), n) {
			for (var r = 0; r < this.undefStack.length; r++) delete this.undefStack[r][e];
			this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][e] = t);
		} else {
			var i = this.undefStack[this.undefStack.length - 1];
			i && !Object.prototype.hasOwnProperty.call(i, e) && (i[e] = Object.prototype.hasOwnProperty.call(this.current, e) ? this.current[e] : void 0);
		}
		t == null ? delete this.current[e] : this.current[e] = t;
	}
}, ca = ii;
Z("\\noexpand", function(e) {
	var t = e.popToken();
	return e.isExpandable(t.text) && (t.noexpand = !0, t.treatAsRelax = !0), {
		tokens: [t],
		numArgs: 0
	};
}), Z("\\expandafter", function(e) {
	var t = e.popToken();
	return e.expandOnce(!0), {
		tokens: [t],
		numArgs: 0
	};
}), Z("\\@firstoftwo", function(e) {
	return {
		tokens: e.consumeArgs(2)[0],
		numArgs: 0
	};
}), Z("\\@secondoftwo", function(e) {
	return {
		tokens: e.consumeArgs(2)[1],
		numArgs: 0
	};
}), Z("\\@ifnextchar", function(e) {
	var t = e.consumeArgs(3);
	e.consumeSpaces();
	var n = e.future();
	return t[0].length === 1 && t[0][0].text === n.text ? {
		tokens: t[1],
		numArgs: 0
	} : {
		tokens: t[2],
		numArgs: 0
	};
}), Z("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}"), Z("\\TextOrMath", function(e) {
	var t = e.consumeArgs(2);
	return e.mode === "text" ? {
		tokens: t[0],
		numArgs: 0
	} : {
		tokens: t[1],
		numArgs: 0
	};
});
var la = {
	0: 0,
	1: 1,
	2: 2,
	3: 3,
	4: 4,
	5: 5,
	6: 6,
	7: 7,
	8: 8,
	9: 9,
	a: 10,
	A: 10,
	b: 11,
	B: 11,
	c: 12,
	C: 12,
	d: 13,
	D: 13,
	e: 14,
	E: 14,
	f: 15,
	F: 15
};
Z("\\char", function(e) {
	var n = e.popToken(), r, i = 0;
	if (n.text === "'") r = 8, n = e.popToken();
	else if (n.text === "\"") r = 16, n = e.popToken();
	else if (n.text === "`") {
		if (n = e.popToken(), n.text[0] === "\\") i = n.text.charCodeAt(1);
		else if (n.text === "EOF") throw new t("\\char` missing argument");
		else i = n.text.charCodeAt(0);
	} else r = 10;
	if (r) {
		if (i = la[n.text], i == null || i >= r) throw new t("Invalid base-" + r + " digit " + n.text);
		for (var a; (a = la[e.future().text]) != null && a < r;) i *= r, i += a, e.popToken();
	}
	return "\\@char{" + i + "}";
});
var ua = (e, n, r, i) => {
	var a = e.consumeArg().tokens;
	if (a.length !== 1) throw new t("\\newcommand's first argument must be a macro name");
	var o = a[0].text, s = e.isDefined(o);
	if (s && !n) throw new t("\\newcommand{" + o + "} attempting to redefine " + (o + "; use \\renewcommand"));
	if (!s && !r) throw new t("\\renewcommand{" + o + "} when command " + o + " does not yet exist; use \\newcommand");
	var c = 0;
	if (a = e.consumeArg().tokens, a.length === 1 && a[0].text === "[") {
		for (var l = "", u = e.expandNextToken(); u.text !== "]" && u.text !== "EOF";) l += u.text, u = e.expandNextToken();
		if (!l.match(/^\s*[0-9]+\s*$/)) throw new t("Invalid number of arguments: " + l);
		c = parseInt(l), a = e.consumeArg().tokens;
	}
	return s && i || e.macros.set(o, {
		tokens: a,
		numArgs: c
	}), "";
};
Z("\\newcommand", (e) => ua(e, !1, !0, !1)), Z("\\renewcommand", (e) => ua(e, !0, !1, !1)), Z("\\providecommand", (e) => ua(e, !0, !0, !0)), Z("\\message", (e) => {
	var t = e.consumeArgs(1)[0];
	return console.log(t.reverse().map((e) => e.text).join("")), "";
}), Z("\\errmessage", (e) => {
	var t = e.consumeArgs(1)[0];
	return console.error(t.reverse().map((e) => e.text).join("")), "";
}), Z("\\show", (e) => {
	var t = e.popToken(), n = t.text;
	return console.log(t, e.macros.get(n), Zi[n], k.math[n], k.text[n]), "";
}), Z("\\bgroup", "{"), Z("\\egroup", "}"), Z("~", "\\nobreakspace"), Z("\\lq", "`"), Z("\\rq", "'"), Z("\\aa", "\\r a"), Z("\\AA", "\\r A"), Z("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`©}"), Z("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}"), Z("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`®}"), Z("ℬ", "\\mathscr{B}"), Z("ℰ", "\\mathscr{E}"), Z("ℱ", "\\mathscr{F}"), Z("ℋ", "\\mathscr{H}"), Z("ℐ", "\\mathscr{I}"), Z("ℒ", "\\mathscr{L}"), Z("ℳ", "\\mathscr{M}"), Z("ℛ", "\\mathscr{R}"), Z("ℭ", "\\mathfrak{C}"), Z("ℌ", "\\mathfrak{H}"), Z("ℨ", "\\mathfrak{Z}"), Z("\\Bbbk", "\\Bbb{k}"), Z("\\llap", "\\mathllap{\\textrm{#1}}"), Z("\\rlap", "\\mathrlap{\\textrm{#1}}"), Z("\\clap", "\\mathclap{\\textrm{#1}}"), Z("\\mathstrut", "\\vphantom{(}"), Z("\\underbar", "\\underline{\\text{#1}}"), Z("\\not", "\\html@mathml{\\mathrel{\\mathrlap\\@not}\\nobreak}{\\char\"338}"), Z("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`≠}}"), Z("\\ne", "\\neq"), Z("≠", "\\neq"), Z("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`∉}}"), Z("∉", "\\notin"), Z("≘", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`≘}}"), Z("≙", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`≘}}"), Z("≚", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`≚}}"), Z("≛", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`≛}}"), Z("≝", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`≝}}"), Z("≞", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`≞}}"), Z("≟", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`≟}}"), Z("⟂", "\\perp"), Z("‼", "\\mathclose{!\\mkern-0.8mu!}"), Z("∌", "\\notni"), Z("⌜", "\\ulcorner"), Z("⌝", "\\urcorner"), Z("⌞", "\\llcorner"), Z("⌟", "\\lrcorner"), Z("©", "\\copyright"), Z("®", "\\textregistered"), Z("\\ulcorner", "\\html@mathml{\\@ulcorner}{\\mathop{\\char\"231c}}"), Z("\\urcorner", "\\html@mathml{\\@urcorner}{\\mathop{\\char\"231d}}"), Z("\\llcorner", "\\html@mathml{\\@llcorner}{\\mathop{\\char\"231e}}"), Z("\\lrcorner", "\\html@mathml{\\@lrcorner}{\\mathop{\\char\"231f}}"), Z("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}"), Z("⋮", "\\vdots"), Z("\\varGamma", "\\mathit{\\Gamma}"), Z("\\varDelta", "\\mathit{\\Delta}"), Z("\\varTheta", "\\mathit{\\Theta}"), Z("\\varLambda", "\\mathit{\\Lambda}"), Z("\\varXi", "\\mathit{\\Xi}"), Z("\\varPi", "\\mathit{\\Pi}"), Z("\\varSigma", "\\mathit{\\Sigma}"), Z("\\varUpsilon", "\\mathit{\\Upsilon}"), Z("\\varPhi", "\\mathit{\\Phi}"), Z("\\varPsi", "\\mathit{\\Psi}"), Z("\\varOmega", "\\mathit{\\Omega}"), Z("\\substack", "\\begin{subarray}{c}#1\\end{subarray}"), Z("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax"), Z("\\boxed", "\\fbox{$\\displaystyle{#1}$}"), Z("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;"), Z("\\implies", "\\DOTSB\\;\\Longrightarrow\\;"), Z("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;"), Z("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}"), Z("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var da = {
	",": "\\dotsc",
	"\\not": "\\dotsb",
	"+": "\\dotsb",
	"=": "\\dotsb",
	"<": "\\dotsb",
	">": "\\dotsb",
	"-": "\\dotsb",
	"*": "\\dotsb",
	":": "\\dotsb",
	"\\DOTSB": "\\dotsb",
	"\\coprod": "\\dotsb",
	"\\bigvee": "\\dotsb",
	"\\bigwedge": "\\dotsb",
	"\\biguplus": "\\dotsb",
	"\\bigcap": "\\dotsb",
	"\\bigcup": "\\dotsb",
	"\\prod": "\\dotsb",
	"\\sum": "\\dotsb",
	"\\bigotimes": "\\dotsb",
	"\\bigoplus": "\\dotsb",
	"\\bigodot": "\\dotsb",
	"\\bigsqcup": "\\dotsb",
	"\\And": "\\dotsb",
	"\\longrightarrow": "\\dotsb",
	"\\Longrightarrow": "\\dotsb",
	"\\longleftarrow": "\\dotsb",
	"\\Longleftarrow": "\\dotsb",
	"\\longleftrightarrow": "\\dotsb",
	"\\Longleftrightarrow": "\\dotsb",
	"\\mapsto": "\\dotsb",
	"\\longmapsto": "\\dotsb",
	"\\hookrightarrow": "\\dotsb",
	"\\doteq": "\\dotsb",
	"\\mathbin": "\\dotsb",
	"\\mathrel": "\\dotsb",
	"\\relbar": "\\dotsb",
	"\\Relbar": "\\dotsb",
	"\\xrightarrow": "\\dotsb",
	"\\xleftarrow": "\\dotsb",
	"\\DOTSI": "\\dotsi",
	"\\int": "\\dotsi",
	"\\oint": "\\dotsi",
	"\\iint": "\\dotsi",
	"\\iiint": "\\dotsi",
	"\\iiiint": "\\dotsi",
	"\\idotsint": "\\dotsi",
	"\\DOTSX": "\\dotsx"
}, fa = /* @__PURE__ */ new Set(["bin", "rel"]);
Z("\\dots", function(e) {
	var t = "\\dotso", n = e.expandAfterFuture().text;
	return n in da ? t = da[n] : (n.slice(0, 4) === "\\not" || n in k.math && fa.has(k.math[n].group)) && (t = "\\dotsb"), t;
});
var pa = {
	")": !0,
	"]": !0,
	"\\rbrack": !0,
	"\\}": !0,
	"\\rbrace": !0,
	"\\rangle": !0,
	"\\rceil": !0,
	"\\rfloor": !0,
	"\\rgroup": !0,
	"\\rmoustache": !0,
	"\\right": !0,
	"\\bigr": !0,
	"\\biggr": !0,
	"\\Bigr": !0,
	"\\Biggr": !0,
	$: !0,
	";": !0,
	".": !0,
	",": !0
};
Z("\\dotso", function(e) {
	return e.future().text in pa ? "\\ldots\\," : "\\ldots";
}), Z("\\dotsc", function(e) {
	var t = e.future().text;
	return t in pa && t !== "," ? "\\ldots\\," : "\\ldots";
}), Z("\\cdots", function(e) {
	return e.future().text in pa ? "\\@cdots\\," : "\\@cdots";
}), Z("\\dotsb", "\\cdots"), Z("\\dotsm", "\\cdots"), Z("\\dotsi", "\\!\\cdots"), Z("\\dotsx", "\\ldots\\,"), Z("\\DOTSI", "\\relax"), Z("\\DOTSB", "\\relax"), Z("\\DOTSX", "\\relax"), Z("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax"), Z("\\,", "\\tmspace+{3mu}{.1667em}"), Z("\\thinspace", "\\,"), Z("\\>", "\\mskip{4mu}"), Z("\\:", "\\tmspace+{4mu}{.2222em}"), Z("\\medspace", "\\:"), Z("\\;", "\\tmspace+{5mu}{.2777em}"), Z("\\thickspace", "\\;"), Z("\\!", "\\tmspace-{3mu}{.1667em}"), Z("\\negthinspace", "\\!"), Z("\\negmedspace", "\\tmspace-{4mu}{.2222em}"), Z("\\negthickspace", "\\tmspace-{5mu}{.277em}"), Z("\\enspace", "\\kern.5em "), Z("\\enskip", "\\hskip.5em\\relax"), Z("\\quad", "\\hskip1em\\relax"), Z("\\qquad", "\\hskip2em\\relax"), Z("\\tag", "\\@ifstar\\tag@literal\\tag@paren"), Z("\\tag@paren", "\\tag@literal{({#1})}"), Z("\\tag@literal", (e) => {
	if (e.macros.get("\\df@tag")) throw new t("Multiple \\tag");
	return "\\gdef\\df@tag{\\text{#1}}";
}), Z("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}"), Z("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)"), Z("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}"), Z("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1"), Z("\\newline", "\\\\\\relax"), Z("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var ma = O(Ge["Main-Regular"][84][1] - .7 * Ge["Main-Regular"][65][1]);
Z("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + ma + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}"), Z("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + ma + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}"), Z("\\hspace", "\\@ifstar\\@hspacer\\@hspace"), Z("\\@hspace", "\\hskip #1\\relax"), Z("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax"), Z("\\ordinarycolon", ":"), Z("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}"), Z("\\dblcolon", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char\"2237}}"), Z("\\coloneqq", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char\"2254}}"), Z("\\Coloneqq", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char\"2237\\char\"3d}}"), Z("\\coloneq", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char\"3a\\char\"2212}}"), Z("\\Coloneq", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char\"2237\\char\"2212}}"), Z("\\eqqcolon", "\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char\"2255}}"), Z("\\Eqqcolon", "\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char\"3d\\char\"2237}}"), Z("\\eqcolon", "\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char\"2239}}"), Z("\\Eqcolon", "\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char\"2212\\char\"2237}}"), Z("\\colonapprox", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char\"3a\\char\"2248}}"), Z("\\Colonapprox", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char\"2237\\char\"2248}}"), Z("\\colonsim", "\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char\"3a\\char\"223c}}"), Z("\\Colonsim", "\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char\"2237\\char\"223c}}"), Z("∷", "\\dblcolon"), Z("∹", "\\eqcolon"), Z("≔", "\\coloneqq"), Z("≕", "\\eqqcolon"), Z("⩴", "\\Coloneqq"), Z("\\ratio", "\\vcentcolon"), Z("\\coloncolon", "\\dblcolon"), Z("\\colonequals", "\\coloneqq"), Z("\\coloncolonequals", "\\Coloneqq"), Z("\\equalscolon", "\\eqqcolon"), Z("\\equalscoloncolon", "\\Eqqcolon"), Z("\\colonminus", "\\coloneq"), Z("\\coloncolonminus", "\\Coloneq"), Z("\\minuscolon", "\\eqcolon"), Z("\\minuscoloncolon", "\\Eqcolon"), Z("\\coloncolonapprox", "\\Colonapprox"), Z("\\coloncolonsim", "\\Colonsim"), Z("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), Z("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}"), Z("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}"), Z("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}"), Z("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`∌}}"), Z("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}"), Z("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}"), Z("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}"), Z("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}"), Z("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}"), Z("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}"), Z("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}"), Z("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}"), Z("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{≩}"), Z("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{≨}"), Z("\\ngeqq", "\\html@mathml{\\@ngeqq}{≱}"), Z("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{≱}"), Z("\\nleqq", "\\html@mathml{\\@nleqq}{≰}"), Z("\\nleqslant", "\\html@mathml{\\@nleqslant}{≰}"), Z("\\nshortmid", "\\html@mathml{\\@nshortmid}{∤}"), Z("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{∦}"), Z("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{⊈}"), Z("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{⊉}"), Z("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{⊊}"), Z("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{⫋}"), Z("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{⊋}"), Z("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{⫌}"), Z("\\imath", "\\html@mathml{\\@imath}{ı}"), Z("\\jmath", "\\html@mathml{\\@jmath}{ȷ}"), Z("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`⟦}}"), Z("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`⟧}}"), Z("⟦", "\\llbracket"), Z("⟧", "\\rrbracket"), Z("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`⦃}}"), Z("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`⦄}}"), Z("↤", "\\mapsfrom"), Z("\\mapsfrom", "\\html@mathml{\\mathrel{\\mathreflectbox{\\mapsto}}}{\\mathrel{\\char`↤}}"), Z("⦃", "\\lBrace"), Z("⦄", "\\rBrace"), Z("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`⦵}}"), Z("⦵", "\\minuso"), Z("\\darr", "\\downarrow"), Z("\\dArr", "\\Downarrow"), Z("\\Darr", "\\Downarrow"), Z("\\lang", "\\langle"), Z("\\rang", "\\rangle"), Z("\\uarr", "\\uparrow"), Z("\\uArr", "\\Uparrow"), Z("\\Uarr", "\\Uparrow"), Z("\\N", "\\mathbb{N}"), Z("\\R", "\\mathbb{R}"), Z("\\Z", "\\mathbb{Z}"), Z("\\alef", "\\aleph"), Z("\\alefsym", "\\aleph"), Z("\\Alpha", "\\mathrm{A}"), Z("\\Beta", "\\mathrm{B}"), Z("\\bull", "\\bullet"), Z("\\Chi", "\\mathrm{X}"), Z("\\clubs", "\\clubsuit"), Z("\\cnums", "\\mathbb{C}"), Z("\\Complex", "\\mathbb{C}"), Z("\\Dagger", "\\ddagger"), Z("\\diamonds", "\\diamondsuit"), Z("\\empty", "\\emptyset"), Z("\\Epsilon", "\\mathrm{E}"), Z("\\Eta", "\\mathrm{H}"), Z("\\exist", "\\exists"), Z("\\harr", "\\leftrightarrow"), Z("\\hArr", "\\Leftrightarrow"), Z("\\Harr", "\\Leftrightarrow"), Z("\\hearts", "\\heartsuit"), Z("\\image", "\\Im"), Z("\\infin", "\\infty"), Z("\\Iota", "\\mathrm{I}"), Z("\\isin", "\\in"), Z("\\Kappa", "\\mathrm{K}"), Z("\\larr", "\\leftarrow"), Z("\\lArr", "\\Leftarrow"), Z("\\Larr", "\\Leftarrow"), Z("\\lrarr", "\\leftrightarrow"), Z("\\lrArr", "\\Leftrightarrow"), Z("\\Lrarr", "\\Leftrightarrow"), Z("\\Mu", "\\mathrm{M}"), Z("\\natnums", "\\mathbb{N}"), Z("\\Nu", "\\mathrm{N}"), Z("\\Omicron", "\\mathrm{O}"), Z("\\plusmn", "\\pm"), Z("\\rarr", "\\rightarrow"), Z("\\rArr", "\\Rightarrow"), Z("\\Rarr", "\\Rightarrow"), Z("\\real", "\\Re"), Z("\\reals", "\\mathbb{R}"), Z("\\Reals", "\\mathbb{R}"), Z("\\Rho", "\\mathrm{P}"), Z("\\sdot", "\\cdot"), Z("\\sect", "\\S"), Z("\\spades", "\\spadesuit"), Z("\\sub", "\\subset"), Z("\\sube", "\\subseteq"), Z("\\supe", "\\supseteq"), Z("\\Tau", "\\mathrm{T}"), Z("\\thetasym", "\\vartheta"), Z("\\weierp", "\\wp"), Z("\\Zeta", "\\mathrm{Z}"), Z("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}"), Z("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}"), Z("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits"), Z("\\bra", "\\mathinner{\\langle{#1}|}"), Z("\\ket", "\\mathinner{|{#1}\\rangle}"), Z("\\braket", "\\mathinner{\\langle{#1}\\rangle}"), Z("\\Bra", "\\left\\langle#1\\right|"), Z("\\Ket", "\\left|#1\\right\\rangle");
var ha = (e) => (t) => {
	var n = t.consumeArg().tokens, r = t.consumeArg().tokens, i = t.consumeArg().tokens, a = t.consumeArg().tokens, o = t.macros.get("|"), s = t.macros.get("\\|");
	t.macros.beginGroup();
	var c = (t) => (n) => {
		e && (n.macros.set("|", o), i.length && n.macros.set("\\|", s));
		var a = t;
		return !t && i.length && n.future().text === "|" && (n.popToken(), a = !0), {
			tokens: a ? i : r,
			numArgs: 0
		};
	};
	t.macros.set("|", c(!1)), i.length && t.macros.set("\\|", c(!0));
	var l = t.consumeArg().tokens, u = t.expandTokens([
		...a,
		...l,
		...n
	]);
	return t.macros.endGroup(), {
		tokens: u.reverse(),
		numArgs: 0
	};
};
Z("\\bra@ket", ha(!1)), Z("\\bra@set", ha(!0)), Z("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}"), Z("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}"), Z("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}"), Z("\\angln", "{\\angl n}"), Z("\\blue", "\\textcolor{##6495ed}{#1}"), Z("\\orange", "\\textcolor{##ffa500}{#1}"), Z("\\pink", "\\textcolor{##ff00af}{#1}"), Z("\\red", "\\textcolor{##df0030}{#1}"), Z("\\green", "\\textcolor{##28ae7b}{#1}"), Z("\\gray", "\\textcolor{gray}{#1}"), Z("\\purple", "\\textcolor{##9d38bd}{#1}"), Z("\\blueA", "\\textcolor{##ccfaff}{#1}"), Z("\\blueB", "\\textcolor{##80f6ff}{#1}"), Z("\\blueC", "\\textcolor{##63d9ea}{#1}"), Z("\\blueD", "\\textcolor{##11accd}{#1}"), Z("\\blueE", "\\textcolor{##0c7f99}{#1}"), Z("\\tealA", "\\textcolor{##94fff5}{#1}"), Z("\\tealB", "\\textcolor{##26edd5}{#1}"), Z("\\tealC", "\\textcolor{##01d1c1}{#1}"), Z("\\tealD", "\\textcolor{##01a995}{#1}"), Z("\\tealE", "\\textcolor{##208170}{#1}"), Z("\\greenA", "\\textcolor{##b6ffb0}{#1}"), Z("\\greenB", "\\textcolor{##8af281}{#1}"), Z("\\greenC", "\\textcolor{##74cf70}{#1}"), Z("\\greenD", "\\textcolor{##1fab54}{#1}"), Z("\\greenE", "\\textcolor{##0d923f}{#1}"), Z("\\goldA", "\\textcolor{##ffd0a9}{#1}"), Z("\\goldB", "\\textcolor{##ffbb71}{#1}"), Z("\\goldC", "\\textcolor{##ff9c39}{#1}"), Z("\\goldD", "\\textcolor{##e07d10}{#1}"), Z("\\goldE", "\\textcolor{##a75a05}{#1}"), Z("\\redA", "\\textcolor{##fca9a9}{#1}"), Z("\\redB", "\\textcolor{##ff8482}{#1}"), Z("\\redC", "\\textcolor{##f9685d}{#1}"), Z("\\redD", "\\textcolor{##e84d39}{#1}"), Z("\\redE", "\\textcolor{##bc2612}{#1}"), Z("\\maroonA", "\\textcolor{##ffbde0}{#1}"), Z("\\maroonB", "\\textcolor{##ff92c6}{#1}"), Z("\\maroonC", "\\textcolor{##ed5fa6}{#1}"), Z("\\maroonD", "\\textcolor{##ca337c}{#1}"), Z("\\maroonE", "\\textcolor{##9e034e}{#1}"), Z("\\purpleA", "\\textcolor{##ddd7ff}{#1}"), Z("\\purpleB", "\\textcolor{##c6b9fc}{#1}"), Z("\\purpleC", "\\textcolor{##aa87ff}{#1}"), Z("\\purpleD", "\\textcolor{##7854ab}{#1}"), Z("\\purpleE", "\\textcolor{##543b78}{#1}"), Z("\\mintA", "\\textcolor{##f5f9e8}{#1}"), Z("\\mintB", "\\textcolor{##edf2df}{#1}"), Z("\\mintC", "\\textcolor{##e0e5cc}{#1}"), Z("\\grayA", "\\textcolor{##f6f7f7}{#1}"), Z("\\grayB", "\\textcolor{##f0f1f2}{#1}"), Z("\\grayC", "\\textcolor{##e3e5e6}{#1}"), Z("\\grayD", "\\textcolor{##d6d8da}{#1}"), Z("\\grayE", "\\textcolor{##babec2}{#1}"), Z("\\grayF", "\\textcolor{##888d93}{#1}"), Z("\\grayG", "\\textcolor{##626569}{#1}"), Z("\\grayH", "\\textcolor{##3b3e40}{#1}"), Z("\\grayI", "\\textcolor{##21242c}{#1}"), Z("\\kaBlue", "\\textcolor{##314453}{#1}"), Z("\\kaGreen", "\\textcolor{##71B307}{#1}");
var ga = {
	"^": !0,
	_: !0,
	"\\limits": !0,
	"\\nolimits": !0
}, _a = class {
	constructor(e, t, n) {
		this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = t, this.expansionCount = 0, this.feed(e), this.macros = new sa(ca, t.macros), this.mode = n, this.stack = [];
	}
	feed(e) {
		this.lexer = new oa(e, this.settings);
	}
	switchMode(e) {
		this.mode = e;
	}
	beginGroup() {
		this.macros.beginGroup();
	}
	endGroup() {
		this.macros.endGroup();
	}
	endGroups() {
		this.macros.endGroups();
	}
	future() {
		return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1];
	}
	popToken() {
		return this.future(), this.stack.pop();
	}
	pushToken(e) {
		this.stack.push(e);
	}
	pushTokens(e) {
		this.stack.push(...e);
	}
	scanArgument(e) {
		var t, n, r;
		if (e) {
			if (this.consumeSpaces(), this.future().text !== "[") return null;
			t = this.popToken();
			var i = this.consumeArg(["]"]);
			r = i.tokens, n = i.end;
		} else {
			var a = this.consumeArg();
			r = a.tokens, t = a.start, n = a.end;
		}
		return this.pushToken(new oi("EOF", n.loc)), this.pushTokens(r), new oi("", ai.range(t, n));
	}
	consumeSpaces() {
		for (; this.future().text === " ";) this.stack.pop();
	}
	consumeArg(e) {
		var n = [], r = e && e.length > 0;
		r || this.consumeSpaces();
		var i = this.future(), a, o = 0, s = 0;
		do {
			if (a = this.popToken(), n.push(a), a.text === "{") ++o;
			else if (a.text === "}") {
				if (--o, o === -1) throw new t("Extra }", a);
			} else if (a.text === "EOF") throw new t("Unexpected end of input in a macro argument, expected '" + (e && r ? e[s] : "}") + "'", a);
			if (e && r) {
				if ((o === 0 || o === 1 && e[s] === "{") && a.text === e[s]) {
					if (++s, s === e.length) {
						n.splice(-s, s);
						break;
					}
				} else s = 0;
			}
		} while (o !== 0 || r);
		return i.text === "{" && n[n.length - 1].text === "}" && (n.pop(), n.shift()), n.reverse(), {
			tokens: n,
			start: i,
			end: a
		};
	}
	consumeArgs(e, n) {
		if (n) {
			if (n.length !== e + 1) throw new t("The length of delimiters doesn't match the number of args!");
			for (var r = n[0], i = 0; i < r.length; i++) {
				var a = this.popToken();
				if (r[i] !== a.text) throw new t("Use of the macro doesn't match its definition", a);
			}
		}
		for (var o = [], s = 0; s < e; s++) o.push(this.consumeArg(n && n[s + 1]).tokens);
		return o;
	}
	countExpansion(e) {
		if (this.expansionCount += e, this.expansionCount > this.settings.maxExpand) throw new t("Too many expansions: infinite loop or need to increase maxExpand setting");
	}
	expandOnce(e) {
		var n = this.popToken(), r = n.text, i = n.noexpand ? null : this._getExpansion(r);
		if (i == null || e && i.unexpandable) {
			if (e && i == null && r[0] === "\\" && !this.isDefined(r)) throw new t("Undefined control sequence: " + r);
			return this.pushToken(n), !1;
		}
		this.countExpansion(1);
		var a = i.tokens, o = this.consumeArgs(i.numArgs, i.delimiters);
		if (i.numArgs) {
			a = a.slice();
			for (var s = a.length - 1; s >= 0; --s) {
				var c = a[s];
				if (c.text === "#") {
					if (s === 0) throw new t("Incomplete placeholder at end of macro body", c);
					if (c = a[--s], c.text === "#") a.splice(s + 1, 1);
					else if (/^[1-9]$/.test(c.text)) a.splice(s, 2, ...o[c.text - 1]);
					else throw new t("Not a valid argument number", c);
				}
			}
		}
		return this.pushTokens(a), a.length;
	}
	expandAfterFuture() {
		return this.expandOnce(), this.future();
	}
	expandNextToken() {
		for (;;) if (this.expandOnce() === !1) {
			var e = this.stack.pop();
			return e.treatAsRelax && (e.text = "\\relax"), e;
		}
	}
	expandMacro(e) {
		return this.macros.has(e) ? this.expandTokens([new oi(e)]) : void 0;
	}
	expandTokens(e) {
		var t = [], n = this.stack.length;
		for (this.pushTokens(e); this.stack.length > n;) if (this.expandOnce(!0) === !1) {
			var r = this.stack.pop();
			r.treatAsRelax &&= (r.noexpand = !1, !1), t.push(r);
		}
		return this.countExpansion(t.length), t;
	}
	expandMacroAsText(e) {
		var t = this.expandMacro(e);
		return t && t.map((e) => e.text).join("");
	}
	_getExpansion(e) {
		var t = this.macros.get(e);
		if (t == null) return t;
		if (e.length === 1) {
			var n = this.lexer.catcodes[e];
			if (n != null && n !== 13) return;
		}
		var r = typeof t == "function" ? t(this) : t;
		if (typeof r == "string") {
			var i = 0;
			if (r.includes("#")) for (var a = r.replace(/##/g, ""); a.includes("#" + (i + 1));) ++i;
			for (var o = new oa(r, this.settings), s = [], c = o.lex(); c.text !== "EOF";) s.push(c), c = o.lex();
			return s.reverse(), {
				tokens: s,
				numArgs: i
			};
		}
		return r;
	}
	isDefined(e) {
		return this.macros.has(e) || Object.prototype.hasOwnProperty.call(Zi, e) || Object.prototype.hasOwnProperty.call(k.math, e) || Object.prototype.hasOwnProperty.call(k.text, e) || Object.prototype.hasOwnProperty.call(ga, e);
	}
	isExpandable(e) {
		var t = this.macros.get(e);
		return t == null ? Object.prototype.hasOwnProperty.call(Zi, e) && !Zi[e].primitive : typeof t == "string" || typeof t == "function" || !t.unexpandable;
	}
}, va = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, ya = Object.freeze({
	"₊": "+",
	"₋": "-",
	"₌": "=",
	"₍": "(",
	"₎": ")",
	"₀": "0",
	"₁": "1",
	"₂": "2",
	"₃": "3",
	"₄": "4",
	"₅": "5",
	"₆": "6",
	"₇": "7",
	"₈": "8",
	"₉": "9",
	ₐ: "a",
	ₑ: "e",
	ₕ: "h",
	ᵢ: "i",
	ⱼ: "j",
	ₖ: "k",
	ₗ: "l",
	ₘ: "m",
	ₙ: "n",
	ₒ: "o",
	ₚ: "p",
	ᵣ: "r",
	ₛ: "s",
	ₜ: "t",
	ᵤ: "u",
	ᵥ: "v",
	ₓ: "x",
	ᵦ: "β",
	ᵧ: "γ",
	ᵨ: "ρ",
	ᵩ: "ϕ",
	ᵪ: "χ",
	"⁺": "+",
	"⁻": "-",
	"⁼": "=",
	"⁽": "(",
	"⁾": ")",
	"⁰": "0",
	"¹": "1",
	"²": "2",
	"³": "3",
	"⁴": "4",
	"⁵": "5",
	"⁶": "6",
	"⁷": "7",
	"⁸": "8",
	"⁹": "9",
	ᴬ: "A",
	ᴮ: "B",
	ᴰ: "D",
	ᴱ: "E",
	ᴳ: "G",
	ᴴ: "H",
	ᴵ: "I",
	ᴶ: "J",
	ᴷ: "K",
	ᴸ: "L",
	ᴹ: "M",
	ᴺ: "N",
	ᴼ: "O",
	ᴾ: "P",
	ᴿ: "R",
	ᵀ: "T",
	ᵁ: "U",
	ⱽ: "V",
	ᵂ: "W",
	ᵃ: "a",
	ᵇ: "b",
	ᶜ: "c",
	ᵈ: "d",
	ᵉ: "e",
	ᶠ: "f",
	ᵍ: "g",
	ʰ: "h",
	ⁱ: "i",
	ʲ: "j",
	ᵏ: "k",
	ˡ: "l",
	ᵐ: "m",
	ⁿ: "n",
	ᵒ: "o",
	ᵖ: "p",
	ʳ: "r",
	ˢ: "s",
	ᵗ: "t",
	ᵘ: "u",
	ᵛ: "v",
	ʷ: "w",
	ˣ: "x",
	ʸ: "y",
	ᶻ: "z",
	ᵝ: "β",
	ᵞ: "γ",
	ᵟ: "δ",
	ᵠ: "ϕ",
	ᵡ: "χ",
	ᶿ: "θ"
}), ba = {
	"́": {
		text: "\\'",
		math: "\\acute"
	},
	"̀": {
		text: "\\`",
		math: "\\grave"
	},
	"̈": {
		text: "\\\"",
		math: "\\ddot"
	},
	"̃": {
		text: "\\~",
		math: "\\tilde"
	},
	"̄": {
		text: "\\=",
		math: "\\bar"
	},
	"̆": {
		text: "\\u",
		math: "\\breve"
	},
	"̌": {
		text: "\\v",
		math: "\\check"
	},
	"̂": {
		text: "\\^",
		math: "\\hat"
	},
	"̇": {
		text: "\\.",
		math: "\\dot"
	},
	"̊": {
		text: "\\r",
		math: "\\mathring"
	},
	"̋": { text: "\\H" },
	"̧": { text: "\\c" }
}, xa = {
	á: "á",
	à: "à",
	ä: "ä",
	ǟ: "ǟ",
	ã: "ã",
	ā: "ā",
	ă: "ă",
	ắ: "ắ",
	ằ: "ằ",
	ẵ: "ẵ",
	ǎ: "ǎ",
	â: "â",
	ấ: "ấ",
	ầ: "ầ",
	ẫ: "ẫ",
	ȧ: "ȧ",
	ǡ: "ǡ",
	å: "å",
	ǻ: "ǻ",
	ḃ: "ḃ",
	ć: "ć",
	ḉ: "ḉ",
	č: "č",
	ĉ: "ĉ",
	ċ: "ċ",
	ç: "ç",
	ď: "ď",
	ḋ: "ḋ",
	ḑ: "ḑ",
	é: "é",
	è: "è",
	ë: "ë",
	ẽ: "ẽ",
	ē: "ē",
	ḗ: "ḗ",
	ḕ: "ḕ",
	ĕ: "ĕ",
	ḝ: "ḝ",
	ě: "ě",
	ê: "ê",
	ế: "ế",
	ề: "ề",
	ễ: "ễ",
	ė: "ė",
	ȩ: "ȩ",
	ḟ: "ḟ",
	ǵ: "ǵ",
	ḡ: "ḡ",
	ğ: "ğ",
	ǧ: "ǧ",
	ĝ: "ĝ",
	ġ: "ġ",
	ģ: "ģ",
	ḧ: "ḧ",
	ȟ: "ȟ",
	ĥ: "ĥ",
	ḣ: "ḣ",
	ḩ: "ḩ",
	í: "í",
	ì: "ì",
	ï: "ï",
	ḯ: "ḯ",
	ĩ: "ĩ",
	ī: "ī",
	ĭ: "ĭ",
	ǐ: "ǐ",
	î: "î",
	ǰ: "ǰ",
	ĵ: "ĵ",
	ḱ: "ḱ",
	ǩ: "ǩ",
	ķ: "ķ",
	ĺ: "ĺ",
	ľ: "ľ",
	ļ: "ļ",
	ḿ: "ḿ",
	ṁ: "ṁ",
	ń: "ń",
	ǹ: "ǹ",
	ñ: "ñ",
	ň: "ň",
	ṅ: "ṅ",
	ņ: "ņ",
	ó: "ó",
	ò: "ò",
	ö: "ö",
	ȫ: "ȫ",
	õ: "õ",
	ṍ: "ṍ",
	ṏ: "ṏ",
	ȭ: "ȭ",
	ō: "ō",
	ṓ: "ṓ",
	ṑ: "ṑ",
	ŏ: "ŏ",
	ǒ: "ǒ",
	ô: "ô",
	ố: "ố",
	ồ: "ồ",
	ỗ: "ỗ",
	ȯ: "ȯ",
	ȱ: "ȱ",
	ő: "ő",
	ṕ: "ṕ",
	ṗ: "ṗ",
	ŕ: "ŕ",
	ř: "ř",
	ṙ: "ṙ",
	ŗ: "ŗ",
	ś: "ś",
	ṥ: "ṥ",
	š: "š",
	ṧ: "ṧ",
	ŝ: "ŝ",
	ṡ: "ṡ",
	ş: "ş",
	ẗ: "ẗ",
	ť: "ť",
	ṫ: "ṫ",
	ţ: "ţ",
	ú: "ú",
	ù: "ù",
	ü: "ü",
	ǘ: "ǘ",
	ǜ: "ǜ",
	ǖ: "ǖ",
	ǚ: "ǚ",
	ũ: "ũ",
	ṹ: "ṹ",
	ū: "ū",
	ṻ: "ṻ",
	ŭ: "ŭ",
	ǔ: "ǔ",
	û: "û",
	ů: "ů",
	ű: "ű",
	ṽ: "ṽ",
	ẃ: "ẃ",
	ẁ: "ẁ",
	ẅ: "ẅ",
	ŵ: "ŵ",
	ẇ: "ẇ",
	ẘ: "ẘ",
	ẍ: "ẍ",
	ẋ: "ẋ",
	ý: "ý",
	ỳ: "ỳ",
	ÿ: "ÿ",
	ỹ: "ỹ",
	ȳ: "ȳ",
	ŷ: "ŷ",
	ẏ: "ẏ",
	ẙ: "ẙ",
	ź: "ź",
	ž: "ž",
	ẑ: "ẑ",
	ż: "ż",
	Á: "Á",
	À: "À",
	Ä: "Ä",
	Ǟ: "Ǟ",
	Ã: "Ã",
	Ā: "Ā",
	Ă: "Ă",
	Ắ: "Ắ",
	Ằ: "Ằ",
	Ẵ: "Ẵ",
	Ǎ: "Ǎ",
	Â: "Â",
	Ấ: "Ấ",
	Ầ: "Ầ",
	Ẫ: "Ẫ",
	Ȧ: "Ȧ",
	Ǡ: "Ǡ",
	Å: "Å",
	Ǻ: "Ǻ",
	Ḃ: "Ḃ",
	Ć: "Ć",
	Ḉ: "Ḉ",
	Č: "Č",
	Ĉ: "Ĉ",
	Ċ: "Ċ",
	Ç: "Ç",
	Ď: "Ď",
	Ḋ: "Ḋ",
	Ḑ: "Ḑ",
	É: "É",
	È: "È",
	Ë: "Ë",
	Ẽ: "Ẽ",
	Ē: "Ē",
	Ḗ: "Ḗ",
	Ḕ: "Ḕ",
	Ĕ: "Ĕ",
	Ḝ: "Ḝ",
	Ě: "Ě",
	Ê: "Ê",
	Ế: "Ế",
	Ề: "Ề",
	Ễ: "Ễ",
	Ė: "Ė",
	Ȩ: "Ȩ",
	Ḟ: "Ḟ",
	Ǵ: "Ǵ",
	Ḡ: "Ḡ",
	Ğ: "Ğ",
	Ǧ: "Ǧ",
	Ĝ: "Ĝ",
	Ġ: "Ġ",
	Ģ: "Ģ",
	Ḧ: "Ḧ",
	Ȟ: "Ȟ",
	Ĥ: "Ĥ",
	Ḣ: "Ḣ",
	Ḩ: "Ḩ",
	Í: "Í",
	Ì: "Ì",
	Ï: "Ï",
	Ḯ: "Ḯ",
	Ĩ: "Ĩ",
	Ī: "Ī",
	Ĭ: "Ĭ",
	Ǐ: "Ǐ",
	Î: "Î",
	İ: "İ",
	Ĵ: "Ĵ",
	Ḱ: "Ḱ",
	Ǩ: "Ǩ",
	Ķ: "Ķ",
	Ĺ: "Ĺ",
	Ľ: "Ľ",
	Ļ: "Ļ",
	Ḿ: "Ḿ",
	Ṁ: "Ṁ",
	Ń: "Ń",
	Ǹ: "Ǹ",
	Ñ: "Ñ",
	Ň: "Ň",
	Ṅ: "Ṅ",
	Ņ: "Ņ",
	Ó: "Ó",
	Ò: "Ò",
	Ö: "Ö",
	Ȫ: "Ȫ",
	Õ: "Õ",
	Ṍ: "Ṍ",
	Ṏ: "Ṏ",
	Ȭ: "Ȭ",
	Ō: "Ō",
	Ṓ: "Ṓ",
	Ṑ: "Ṑ",
	Ŏ: "Ŏ",
	Ǒ: "Ǒ",
	Ô: "Ô",
	Ố: "Ố",
	Ồ: "Ồ",
	Ỗ: "Ỗ",
	Ȯ: "Ȯ",
	Ȱ: "Ȱ",
	Ő: "Ő",
	Ṕ: "Ṕ",
	Ṗ: "Ṗ",
	Ŕ: "Ŕ",
	Ř: "Ř",
	Ṙ: "Ṙ",
	Ŗ: "Ŗ",
	Ś: "Ś",
	Ṥ: "Ṥ",
	Š: "Š",
	Ṧ: "Ṧ",
	Ŝ: "Ŝ",
	Ṡ: "Ṡ",
	Ş: "Ş",
	Ť: "Ť",
	Ṫ: "Ṫ",
	Ţ: "Ţ",
	Ú: "Ú",
	Ù: "Ù",
	Ü: "Ü",
	Ǘ: "Ǘ",
	Ǜ: "Ǜ",
	Ǖ: "Ǖ",
	Ǚ: "Ǚ",
	Ũ: "Ũ",
	Ṹ: "Ṹ",
	Ū: "Ū",
	Ṻ: "Ṻ",
	Ŭ: "Ŭ",
	Ǔ: "Ǔ",
	Û: "Û",
	Ů: "Ů",
	Ű: "Ű",
	Ṽ: "Ṽ",
	Ẃ: "Ẃ",
	Ẁ: "Ẁ",
	Ẅ: "Ẅ",
	Ŵ: "Ŵ",
	Ẇ: "Ẇ",
	Ẍ: "Ẍ",
	Ẋ: "Ẋ",
	Ý: "Ý",
	Ỳ: "Ỳ",
	Ÿ: "Ÿ",
	Ỹ: "Ỹ",
	Ȳ: "Ȳ",
	Ŷ: "Ŷ",
	Ẏ: "Ẏ",
	Ź: "Ź",
	Ž: "Ž",
	Ẑ: "Ẑ",
	Ż: "Ż",
	ά: "ά",
	ὰ: "ὰ",
	ᾱ: "ᾱ",
	ᾰ: "ᾰ",
	έ: "έ",
	ὲ: "ὲ",
	ή: "ή",
	ὴ: "ὴ",
	ί: "ί",
	ὶ: "ὶ",
	ϊ: "ϊ",
	ΐ: "ΐ",
	ῒ: "ῒ",
	ῑ: "ῑ",
	ῐ: "ῐ",
	ό: "ό",
	ὸ: "ὸ",
	ύ: "ύ",
	ὺ: "ὺ",
	ϋ: "ϋ",
	ΰ: "ΰ",
	ῢ: "ῢ",
	ῡ: "ῡ",
	ῠ: "ῠ",
	ώ: "ώ",
	ὼ: "ὼ",
	Ύ: "Ύ",
	Ὺ: "Ὺ",
	Ϋ: "Ϋ",
	Ῡ: "Ῡ",
	Ῠ: "Ῠ",
	Ώ: "Ώ",
	Ὼ: "Ὼ"
}, Sa = class e {
	constructor(e, t) {
		this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new _a(e, t, this.mode), this.settings = t, this.leftrightDepth = 0, this.nextToken = null;
	}
	expect(e, n) {
		if (n === void 0 && (n = !0), this.fetch().text !== e) throw new t("Expected '" + e + "', got '" + this.fetch().text + "'", this.fetch());
		n && this.consume();
	}
	consume() {
		this.nextToken = null;
	}
	fetch() {
		return this.nextToken ??= this.gullet.expandNextToken(), this.nextToken;
	}
	switchMode(e) {
		this.mode = e, this.gullet.switchMode(e);
	}
	parse() {
		this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor");
		try {
			var e = this.parseExpression(!1);
			return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), e;
		} finally {
			this.gullet.endGroups();
		}
	}
	subparse(e) {
		var t = this.nextToken;
		this.consume(), this.gullet.pushToken(new oi("}")), this.gullet.pushTokens(e);
		var n = this.parseExpression(!1);
		return this.expect("}"), this.nextToken = t, n;
	}
	parseExpression(t, n) {
		for (var r = [];;) {
			this.mode === "math" && this.consumeSpaces();
			var i = this.fetch();
			if (e.endOfExpression.has(i.text) || n && i.text === n || t && Zi[i.text] && Zi[i.text].infix) break;
			var a = this.parseAtom(n);
			if (!a) break;
			a.type !== "internal" && r.push(a);
		}
		return this.mode === "text" && this.formLigatures(r), this.handleInfixNodes(r);
	}
	handleInfixNodes(e) {
		for (var n = -1, r, i = 0; i < e.length; i++) {
			var a = e[i];
			if (a.type === "infix") {
				if (n !== -1) throw new t("only one infix operator per group", a.token);
				n = i, r = a.replaceWith;
			}
		}
		if (n !== -1 && r) {
			var o, s, c = e.slice(0, n), l = e.slice(n + 1);
			return o = c.length === 1 && c[0].type === "ordgroup" ? c[0] : {
				type: "ordgroup",
				mode: this.mode,
				body: c
			}, s = l.length === 1 && l[0].type === "ordgroup" ? l[0] : {
				type: "ordgroup",
				mode: this.mode,
				body: l
			}, [r === "\\\\abovefrac" ? this.callFunction(r, [
				o,
				e[n],
				s
			], []) : this.callFunction(r, [o, s], [])];
		}
		return e;
	}
	handleSupSubscript(e) {
		var n = this.fetch(), r = n.text;
		this.consume(), this.consumeSpaces();
		var i;
		do
			i = this.parseGroup(e);
		while (i?.type === "internal");
		if (!i) throw new t("Expected group after '" + r + "'", n);
		return i;
	}
	formatUnsupportedCmd(e) {
		for (var t = [], n = 0; n < e.length; n++) t.push({
			type: "textord",
			mode: "text",
			text: e[n]
		});
		var r = {
			type: "text",
			mode: this.mode,
			body: t
		};
		return {
			type: "color",
			mode: this.mode,
			color: this.settings.errorColor,
			body: [r]
		};
	}
	parseAtom(e) {
		var n = this.parseGroup("atom", e);
		if (n?.type === "internal" || this.mode === "text") return n;
		for (var r, i;;) {
			this.consumeSpaces();
			var a = this.fetch();
			if (a.text === "\\limits" || a.text === "\\nolimits") {
				if (n && n.type === "op") n.limits = a.text === "\\limits", n.alwaysHandleSupSub = !0;
				else if (n && n.type === "operatorname") n.alwaysHandleSupSub && (n.limits = a.text === "\\limits");
				else throw new t("Limit controls must follow a math operator", a);
				this.consume();
			} else if (a.text === "^") {
				if (r) throw new t("Double superscript", a);
				r = this.handleSupSubscript("superscript");
			} else if (a.text === "_") {
				if (i) throw new t("Double subscript", a);
				i = this.handleSupSubscript("subscript");
			} else if (a.text === "'") {
				if (r) throw new t("Double superscript", a);
				var o = {
					type: "textord",
					mode: this.mode,
					text: "\\prime"
				}, s = [o];
				for (this.consume(); this.fetch().text === "'";) s.push(o), this.consume();
				this.fetch().text === "^" && s.push(this.handleSupSubscript("superscript")), r = {
					type: "ordgroup",
					mode: this.mode,
					body: s
				};
			} else if (ya[a.text]) {
				var c = va.test(a.text), l = [];
				for (l.push(new oi(ya[a.text])), this.consume();;) {
					var u = this.fetch().text;
					if (!ya[u] || va.test(u) !== c) break;
					l.unshift(new oi(ya[u])), this.consume();
				}
				var d = this.subparse(l);
				c ? i = {
					type: "ordgroup",
					mode: "math",
					body: d
				} : r = {
					type: "ordgroup",
					mode: "math",
					body: d
				};
			} else break;
		}
		return r && i ? {
			type: "supsub",
			mode: this.mode,
			base: n,
			sup: r,
			sub: i
		} : r ? {
			type: "supsub",
			mode: this.mode,
			base: n,
			sup: r
		} : i ? {
			type: "supsub",
			mode: this.mode,
			base: n,
			sub: i
		} : n;
	}
	parseFunction(e, n) {
		var r = this.fetch(), i = r.text, a = Zi[i];
		if (!a) return null;
		if (this.consume(), n && n !== "atom" && !a.allowedInArgument) throw new t("Got function '" + i + "' with no arguments" + (n ? " as " + n : ""), r);
		if (this.mode === "text" && !a.allowedInText) throw new t("Can't use function '" + i + "' in text mode", r);
		if (this.mode === "math" && a.allowedInMath === !1) throw new t("Can't use function '" + i + "' in math mode", r);
		var o = this.parseArguments(i, a), s = o.args, c = o.optArgs;
		return this.callFunction(i, s, c, r, e);
	}
	callFunction(e, n, r, i, a) {
		var o = {
			funcName: e,
			parser: this,
			token: i,
			breakOnTokenText: a
		}, s = Zi[e];
		if (s && s.handler) return s.handler(o, n, r);
		throw new t("No function handler for " + e);
	}
	parseArguments(e, n) {
		var r = n.numOptionalArgs ?? 0, i = n.numArgs + r;
		if (i === 0) return {
			args: [],
			optArgs: []
		};
		for (var a = [], o = [], s = 0; s < i; s++) {
			var c = n.argTypes?.[s], l = s < r;
			("primitive" in n && n.primitive && c == null || n.type === "sqrt" && s === 1 && o[0] == null) && (c = "primitive");
			var u = this.parseGroupOfType("argument to '" + e + "'", c, l);
			if (l) o.push(u);
			else if (u != null) a.push(u);
			else throw new t("Null argument, please report this as a bug");
		}
		return {
			args: a,
			optArgs: o
		};
	}
	parseGroupOfType(e, n, r) {
		switch (n) {
			case "color": return this.parseColorGroup(r);
			case "size": return this.parseSizeGroup(r);
			case "url": return this.parseUrlGroup(r);
			case "math":
			case "text": return this.parseArgumentGroup(r, n);
			case "hbox":
				var i = this.parseArgumentGroup(r, "text");
				return i == null ? null : {
					type: "styling",
					mode: i.mode,
					body: [i],
					style: "text",
					resetFont: !0
				};
			case "raw":
				this.gullet.consumeSpaces();
				var a = this.gullet.lexer.catcodes["%"];
				this.gullet.lexer.setCatcode("%", 12);
				var o = this.parseStringGroup(r);
				return this.gullet.lexer.setCatcode("%", a), o == null ? null : {
					type: "raw",
					mode: "text",
					string: o.text
				};
			case "primitive":
				if (r) throw new t("A primitive argument cannot be optional");
				var s = this.parseGroup(e);
				if (s == null) throw new t("Expected group as " + e, this.fetch());
				return s;
			case "original":
			case void 0: return this.parseArgumentGroup(r);
			default: throw new t("Unknown group type as " + e, this.fetch());
		}
	}
	consumeSpaces() {
		for (; this.fetch().text === " ";) this.consume();
	}
	parseStringGroup(e) {
		var t = this.gullet.scanArgument(e);
		if (t == null) return null;
		for (var n = "", r; (r = this.fetch()).text !== "EOF";) n += r.text, this.consume();
		return this.consume(), t.text = n, t;
	}
	parseRegexGroup(e, n) {
		for (var r = this.fetch(), i = r, a = "", o; (o = this.fetch()).text !== "EOF" && e.test(a + o.text);) i = o, a += i.text, this.consume();
		if (a === "") throw new t("Invalid " + n + ": '" + r.text + "'", r);
		return r.range(i, a);
	}
	parseColorGroup(e) {
		var n = this.parseStringGroup(e);
		if (n == null) return null;
		var r = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(n.text);
		if (!r) throw new t("Invalid color: '" + n.text + "'", n);
		var i = r[0];
		return /^[0-9a-f]{6}$/i.test(i) && (i = "#" + i), {
			type: "color-token",
			mode: this.mode,
			color: i
		};
	}
	parseSizeGroup(e) {
		var n, r = !1;
		if (this.gullet.consumeSpaces(), n = !e && this.gullet.future().text !== "{" ? this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : this.parseStringGroup(e), !n) return null;
		!e && n.text.length === 0 && (n.text = "0pt", r = !0);
		var i = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(n.text);
		if (!i) throw new t("Invalid size: '" + n.text + "'", n);
		var a = {
			number: +(i[1] + i[2]),
			unit: i[3]
		};
		if (!De(a)) throw new t("Invalid unit: '" + a.unit + "'", n);
		return {
			type: "size",
			mode: this.mode,
			value: a,
			isBlank: r
		};
	}
	parseUrlGroup(e) {
		var t = this.gullet.lexer.catcodes["%"], n = this.gullet.lexer.catcodes["~"];
		this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12);
		var r = this.parseStringGroup(e);
		if (this.gullet.lexer.setCatcode("%", t), this.gullet.lexer.setCatcode("~", n), r == null) return null;
		var i = r.text.replace(/\\([#$%&~_^{}])/g, "$1");
		return {
			type: "url",
			mode: this.mode,
			url: i
		};
	}
	parseArgumentGroup(e, t) {
		var n = this.gullet.scanArgument(e);
		if (n == null) return null;
		var r = this.mode;
		t && this.switchMode(t), this.gullet.beginGroup();
		var i = this.parseExpression(!1, "EOF");
		this.expect("EOF"), this.gullet.endGroup();
		var a = {
			type: "ordgroup",
			mode: this.mode,
			loc: n.loc,
			body: i
		};
		return t && this.switchMode(r), a;
	}
	parseGroup(e, n) {
		var r = this.fetch(), i = r.text, a;
		if (i === "{" || i === "\\begingroup") {
			this.consume();
			var o = i === "{" ? "}" : "\\endgroup";
			this.gullet.beginGroup();
			var s = this.parseExpression(!1, o), c = this.fetch();
			this.expect(o), this.gullet.endGroup(), a = {
				type: "ordgroup",
				mode: this.mode,
				loc: ai.range(r, c),
				body: s,
				semisimple: i === "\\begingroup" || void 0
			};
		} else if (a = this.parseFunction(n, e) || this.parseSymbol(), a == null && i[0] === "\\" && !Object.prototype.hasOwnProperty.call(ga, i)) {
			if (this.settings.throwOnError) throw new t("Undefined control sequence: " + i, r);
			a = this.formatUnsupportedCmd(i), this.consume();
		}
		return a;
	}
	formLigatures(e) {
		for (var t = e.length - 1, n = 0; n < t; ++n) {
			var r = e[n];
			if (r.type === "textord") {
				var i = r.text, a = e[n + 1];
				if (a && a.type === "textord") {
					if (i === "-" && a.text === "-") {
						var o = e[n + 2];
						n + 1 < t && o && o.type === "textord" && o.text === "-" ? (e.splice(n, 3, {
							type: "textord",
							mode: "text",
							loc: ai.range(r, o),
							text: "---"
						}), t -= 2) : (e.splice(n, 2, {
							type: "textord",
							mode: "text",
							loc: ai.range(r, a),
							text: "--"
						}), --t);
					}
					(i === "'" || i === "`") && a.text === i && (e.splice(n, 2, {
						type: "textord",
						mode: "text",
						loc: ai.range(r, a),
						text: i + i
					}), --t);
				}
			}
		}
	}
	parseSymbol() {
		var e = this.fetch(), n = e.text;
		if (/^\\verb[^a-zA-Z]/.test(n)) {
			this.consume();
			var r = n.slice(5), i = r.charAt(0) === "*";
			if (i && (r = r.slice(1)), r.length < 2 || r.charAt(0) !== r.slice(-1)) throw new t("\\verb assertion failed --\n                    please report what input caused this bug");
			return r = r.slice(1, -1), {
				type: "verb",
				mode: "text",
				body: r,
				star: i
			};
		}
		Object.prototype.hasOwnProperty.call(xa, n[0]) && !k[this.mode][n[0]] && (this.settings.strict && this.mode === "math" && Pt({
			strict: this.settings.strict,
			errorCode: "unicodeTextInMathMode",
			errorMsg: "Accented Unicode text character \"" + n[0] + "\" used in math mode",
			report: !0,
			token: e
		}), n = xa[n[0]] + n.slice(1));
		var a = ia.exec(n);
		a && (n = n.substring(0, a.index), n === "i" ? n = "ı" : n === "j" && (n = "ȷ"));
		var o;
		if (k[this.mode][n]) {
			this.settings.strict && this.mode === "math" && gt.includes(n) && Pt({
				strict: this.settings.strict,
				errorCode: "unicodeTextInMathMode",
				errorMsg: "Latin-1/Unicode text character \"" + n[0] + "\" used in math mode",
				report: !0,
				token: e
			});
			var s = k[this.mode][n].group, c = ai.range(e);
			o = er(s) ? {
				type: "atom",
				mode: this.mode,
				family: s,
				loc: c,
				text: n
			} : {
				type: s,
				mode: this.mode,
				loc: c,
				text: n
			};
		} else if (n.charCodeAt(0) >= 128) this.settings.strict && (ue(n.charCodeAt(0)) ? this.mode === "math" && Pt({
			strict: this.settings.strict,
			errorCode: "unicodeTextInMathMode",
			errorMsg: "Unicode text character \"" + n[0] + "\" used in math mode",
			report: !0,
			token: e
		}) : Pt({
			strict: this.settings.strict,
			errorCode: "unknownSymbol",
			errorMsg: "Unrecognized Unicode character \"" + n[0] + "\"" + (" (" + n.charCodeAt(0) + ")"),
			report: !0,
			token: e
		})), o = {
			type: "textord",
			mode: "text",
			loc: ai.range(e),
			text: n
		};
		else return null;
		if (this.consume(), a) for (var l = 0; l < a[0].length; l++) {
			var u = a[0][l];
			if (!ba[u]) throw new t("Unknown accent ' " + u + "'", e);
			var d = ba[u][this.mode] || ba[u].text;
			if (!d) throw new t("Accent " + u + " unsupported in " + this.mode + " mode", e);
			o = {
				type: "accent",
				mode: this.mode,
				loc: ai.range(e),
				label: d,
				isStretchy: !1,
				isShifty: !0,
				base: o
			};
		}
		return o;
	}
};
Sa.endOfExpression = /* @__PURE__ */ new Set([
	"}",
	"\\endgroup",
	"\\end",
	"\\right",
	"&"
]);
var Ca = function(e, n) {
	if (!(typeof e == "string" || e instanceof String)) throw TypeError("KaTeX can only parse string typed expression");
	var r = new Sa(e, n);
	delete r.gullet.macros.current["\\df@tag"];
	var i = r.parse();
	if (delete r.gullet.macros.current["\\current@color"], delete r.gullet.macros.current["\\color"], r.gullet.macros.get("\\df@tag")) {
		if (!n.displayMode) throw new t("\\tag works only in display equations");
		i = [{
			type: "tag",
			mode: "text",
			body: i,
			tag: r.subparse([new oi("\\df@tag")])
		}];
	}
	return i;
}, wa = function(e, t, n) {
	t.textContent = "";
	var r = Oa(e, n).toNode();
	t.appendChild(r);
};
typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), wa = function() {
	throw new t("KaTeX doesn't work in quirks mode.");
});
var Ta = function(e, t) {
	return Oa(e, t).toMarkup();
}, Ea = function(e, t) {
	return Ca(e, new h(t));
}, Da = function(e, n, r) {
	if (r.throwOnError || !(e instanceof t)) throw e;
	var i = U(["katex-error"], [new Re(n)]);
	return i.setAttribute("title", e.toString()), i.setAttribute("style", "color:" + r.errorColor), i;
}, Oa = function(e, t) {
	var n = new h(t);
	try {
		return Hn(Ca(e, n), e, n);
	} catch (t) {
		return Da(t, e, n);
	}
}, ka = {
	version: "0.19.1",
	render: wa,
	renderToString: Ta,
	ParseError: t,
	SETTINGS_SCHEMA: d,
	__parse: Ea,
	__renderToDomTree: Oa,
	__renderToHTMLTree: function(e, t) {
		var n = new h(t);
		try {
			return Un(Ca(e, n), n);
		} catch (t) {
			return Da(t, e, n);
		}
	},
	__setFontMetrics: Je,
	__defineSymbol: A,
	__defineFunction: K,
	__defineMacro: Z,
	__domTree: {
		Span: Pe,
		Anchor: Fe,
		SymbolNode: Re,
		SvgNode: ze,
		PathNode: Be,
		LineNode: Ve
	}
};
ka.__defineMacro("\\ce", function(e) {
	return Aa(e.consumeArgs(1)[0], "ce");
}), ka.__defineMacro("\\pu", function(e) {
	return Aa(e.consumeArgs(1)[0], "pu");
}), ka.__defineMacro("\\tripledash", "{\\vphantom{-}\\raisebox{2.56mu}{$\\mkern2mu\\tiny\\text{-}\\mkern1mu\\text{-}\\mkern1mu\\text{-}\\mkern2mu$}}");
var Aa = function(e, t) {
	for (var n = "", r = e.length && e[e.length - 1].loc.start, i = e.length - 1; i >= 0; i--) e[i].loc.start > r && (n += " ", r = e[i].loc.start), n += e[i].text, r += e[i].text.length;
	return $.go(Q.go(n, t));
}, Q = {
	go: function(e, t) {
		if (!e) return [];
		t === void 0 && (t = "ce");
		var n = "0", r = {};
		r.parenthesisLevel = 0, e = e.replace(/\n/g, " "), e = e.replace(/[\u2212\u2013\u2014\u2010]/g, "-"), e = e.replace(/[\u2026]/g, "...");
		for (var i, a = 10, o = [];;) {
			i === e ? a-- : (a = 10, i = e);
			var s = Q.stateMachines[t], c = s.transitions[n] || s.transitions["*"];
			iterateTransitions: for (var l = 0; l < c.length; l++) {
				var u = Q.patterns.match_(c[l].pattern, e);
				if (u) {
					for (var d = c[l].task, f = 0; f < d.action_.length; f++) {
						var p;
						if (s.actions[d.action_[f].type_]) p = s.actions[d.action_[f].type_](r, u.match_, d.action_[f].option);
						else if (Q.actions[d.action_[f].type_]) p = Q.actions[d.action_[f].type_](r, u.match_, d.action_[f].option);
						else throw ["MhchemBugA", "mhchem bug A. Please report. (" + d.action_[f].type_ + ")"];
						Q.concatArray(o, p);
					}
					if (n = d.nextState || n, e.length > 0) {
						if (d.revisit || (e = u.remainder), !d.toContinue) break iterateTransitions;
					} else return o;
				}
			}
			if (a <= 0) throw ["MhchemBugU", "mhchem bug U. Please report."];
		}
	},
	concatArray: function(e, t) {
		if (t) {
			if (Array.isArray(t)) for (var n = 0; n < t.length; n++) e.push(t[n]);
			else e.push(t);
		}
	},
	patterns: {
		patterns: {
			empty: /^$/,
			else: /^./,
			else2: /^./,
			space: /^\s/,
			"space A": /^\s(?=[A-Z\\$])/,
			space$: /^\s$/,
			"a-z": /^[a-z]/,
			x: /^x/,
			x$: /^x$/,
			i$: /^i$/,
			letters: /^(?:[a-zA-Z\u03B1-\u03C9\u0391-\u03A9?@]|(?:\\(?:alpha|beta|gamma|delta|epsilon|zeta|eta|theta|iota|kappa|lambda|mu|nu|xi|omicron|pi|rho|sigma|tau|upsilon|phi|chi|psi|omega|Gamma|Delta|Theta|Lambda|Xi|Pi|Sigma|Upsilon|Phi|Psi|Omega)(?:\s+|\{\}|(?![a-zA-Z]))))+/,
			"\\greek": /^\\(?:alpha|beta|gamma|delta|epsilon|zeta|eta|theta|iota|kappa|lambda|mu|nu|xi|omicron|pi|rho|sigma|tau|upsilon|phi|chi|psi|omega|Gamma|Delta|Theta|Lambda|Xi|Pi|Sigma|Upsilon|Phi|Psi|Omega)(?:\s+|\{\}|(?![a-zA-Z]))/,
			"one lowercase latin letter $": /^(?:([a-z])(?:$|[^a-zA-Z]))$/,
			"$one lowercase latin letter$ $": /^\$(?:([a-z])(?:$|[^a-zA-Z]))\$$/,
			"one lowercase greek letter $": /^(?:\$?[\u03B1-\u03C9]\$?|\$?\\(?:alpha|beta|gamma|delta|epsilon|zeta|eta|theta|iota|kappa|lambda|mu|nu|xi|omicron|pi|rho|sigma|tau|upsilon|phi|chi|psi|omega)\s*\$?)(?:\s+|\{\}|(?![a-zA-Z]))$/,
			digits: /^[0-9]+/,
			"-9.,9": /^[+\-]?(?:[0-9]+(?:[,.][0-9]+)?|[0-9]*(?:\.[0-9]+))/,
			"-9.,9 no missing 0": /^[+\-]?[0-9]+(?:[.,][0-9]+)?/,
			"(-)(9.,9)(e)(99)": function(e) {
				var t = e.match(/^(\+\-|\+\/\-|\+|\-|\\pm\s?)?([0-9]+(?:[,.][0-9]+)?|[0-9]*(?:\.[0-9]+))?(\((?:[0-9]+(?:[,.][0-9]+)?|[0-9]*(?:\.[0-9]+))\))?(?:([eE]|\s*(\*|x|\\times|\u00D7)\s*10\^)([+\-]?[0-9]+|\{[+\-]?[0-9]+\}))?/);
				return t && t[0] ? {
					match_: t.splice(1),
					remainder: e.substr(t[0].length)
				} : null;
			},
			"(-)(9)^(-9)": function(e) {
				var t = e.match(/^(\+\-|\+\/\-|\+|\-|\\pm\s?)?([0-9]+(?:[,.][0-9]+)?|[0-9]*(?:\.[0-9]+)?)\^([+\-]?[0-9]+|\{[+\-]?[0-9]+\})/);
				return t && t[0] ? {
					match_: t.splice(1),
					remainder: e.substr(t[0].length)
				} : null;
			},
			"state of aggregation $": function(e) {
				var t = Q.patterns.findObserveGroups(e, "", /^\([a-z]{1,3}(?=[\),])/, ")", "");
				if (t && t.remainder.match(/^($|[\s,;\)\]\}])/)) return t;
				var n = e.match(/^(?:\((?:\\ca\s?)?\$[amothc]\$\))/);
				return n ? {
					match_: n[0],
					remainder: e.substr(n[0].length)
				} : null;
			},
			"_{(state of aggregation)}$": /^_\{(\([a-z]{1,3}\))\}/,
			"{[(": /^(?:\\\{|\[|\()/,
			")]}": /^(?:\)|\]|\\\})/,
			", ": /^[,;]\s*/,
			",": /^[,;]/,
			".": /^[.]/,
			". ": /^([.\u22C5\u00B7\u2022])\s*/,
			"...": /^\.\.\.(?=$|[^.])/,
			"* ": /^([*])\s*/,
			"^{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "^{", "", "", "}");
			},
			"^($...$)": function(e) {
				return Q.patterns.findObserveGroups(e, "^", "$", "$", "");
			},
			"^a": /^\^([0-9]+|[^\\_])/,
			"^\\x{}{}": function(e) {
				return Q.patterns.findObserveGroups(e, "^", /^\\[a-zA-Z]+\{/, "}", "", "", "{", "}", "", !0);
			},
			"^\\x{}": function(e) {
				return Q.patterns.findObserveGroups(e, "^", /^\\[a-zA-Z]+\{/, "}", "");
			},
			"^\\x": /^\^(\\[a-zA-Z]+)\s*/,
			"^(-1)": /^\^(-?\d+)/,
			"'": /^'/,
			"_{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "_{", "", "", "}");
			},
			"_($...$)": function(e) {
				return Q.patterns.findObserveGroups(e, "_", "$", "$", "");
			},
			_9: /^_([+\-]?[0-9]+|[^\\])/,
			"_\\x{}{}": function(e) {
				return Q.patterns.findObserveGroups(e, "_", /^\\[a-zA-Z]+\{/, "}", "", "", "{", "}", "", !0);
			},
			"_\\x{}": function(e) {
				return Q.patterns.findObserveGroups(e, "_", /^\\[a-zA-Z]+\{/, "}", "");
			},
			"_\\x": /^_(\\[a-zA-Z]+)\s*/,
			"^_": /^(?:\^(?=_)|\_(?=\^)|[\^_]$)/,
			"{}": /^\{\}/,
			"{...}": function(e) {
				return Q.patterns.findObserveGroups(e, "", "{", "}", "");
			},
			"{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "{", "", "", "}");
			},
			"$...$": function(e) {
				return Q.patterns.findObserveGroups(e, "", "$", "$", "");
			},
			"${(...)}$": function(e) {
				return Q.patterns.findObserveGroups(e, "${", "", "", "}$");
			},
			"$(...)$": function(e) {
				return Q.patterns.findObserveGroups(e, "$", "", "", "$");
			},
			"=<>": /^[=<>]/,
			"#": /^[#\u2261]/,
			"+": /^\+/,
			"-$": /^-(?=[\s_},;\]/]|$|\([a-z]+\))/,
			"-9": /^-(?=[0-9])/,
			"- orbital overlap": /^-(?=(?:[spd]|sp)(?:$|[\s,;\)\]\}]))/,
			"-": /^-/,
			"pm-operator": /^(?:\\pm|\$\\pm\$|\+-|\+\/-)/,
			operator: /^(?:\+|(?:[\-=<>]|<<|>>|\\approx|\$\\approx\$)(?=\s|$|-?[0-9]))/,
			arrowUpDown: /^(?:v|\(v\)|\^|\(\^\))(?=$|[\s,;\)\]\}])/,
			"\\bond{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "\\bond{", "", "", "}");
			},
			"->": /^(?:<->|<-->|->|<-|<=>>|<<=>|<=>|[\u2192\u27F6\u21CC])/,
			CMT: /^[CMT](?=\[)/,
			"[(...)]": function(e) {
				return Q.patterns.findObserveGroups(e, "[", "", "", "]");
			},
			"1st-level escape": /^(&|\\\\|\\hline)\s*/,
			"\\,": /^(?:\\[,\ ;:])/,
			"\\x{}{}": function(e) {
				return Q.patterns.findObserveGroups(e, "", /^\\[a-zA-Z]+\{/, "}", "", "", "{", "}", "", !0);
			},
			"\\x{}": function(e) {
				return Q.patterns.findObserveGroups(e, "", /^\\[a-zA-Z]+\{/, "}", "");
			},
			"\\ca": /^\\ca(?:\s+|(?![a-zA-Z]))/,
			"\\x": /^(?:\\[a-zA-Z]+\s*|\\[_&{}%])/,
			orbital: /^(?:[0-9]{1,2}[spdfgh]|[0-9]{0,2}sp)(?=$|[^a-zA-Z])/,
			others: /^[\/~|]/,
			"\\frac{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "\\frac{", "", "", "}", "{", "", "", "}");
			},
			"\\overset{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "\\overset{", "", "", "}", "{", "", "", "}");
			},
			"\\underset{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "\\underset{", "", "", "}", "{", "", "", "}");
			},
			"\\underbrace{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "\\underbrace{", "", "", "}_", "{", "", "", "}");
			},
			"\\color{(...)}0": function(e) {
				return Q.patterns.findObserveGroups(e, "\\color{", "", "", "}");
			},
			"\\color{(...)}{(...)}1": function(e) {
				return Q.patterns.findObserveGroups(e, "\\color{", "", "", "}", "{", "", "", "}");
			},
			"\\color(...){(...)}2": function(e) {
				return Q.patterns.findObserveGroups(e, "\\color", "\\", "", /^(?=\{)/, "{", "", "", "}");
			},
			"\\ce{(...)}": function(e) {
				return Q.patterns.findObserveGroups(e, "\\ce{", "", "", "}");
			},
			oxidation$: /^(?:[+-][IVX]+|\\pm\s*0|\$\\pm\$\s*0)$/,
			"d-oxidation$": /^(?:[+-]?\s?[IVX]+|\\pm\s*0|\$\\pm\$\s*0)$/,
			"roman numeral": /^[IVX]+/,
			"1/2$": /^[+\-]?(?:[0-9]+|\$[a-z]\$|[a-z])\/[0-9]+(?:\$[a-z]\$|[a-z])?$/,
			amount: function(e) {
				var t = e.match(/^(?:(?:(?:\([+\-]?[0-9]+\/[0-9]+\)|[+\-]?(?:[0-9]+|\$[a-z]\$|[a-z])\/[0-9]+|[+\-]?[0-9]+[.,][0-9]+|[+\-]?\.[0-9]+|[+\-]?[0-9]+)(?:[a-z](?=\s*[A-Z]))?)|[+\-]?[a-z](?=\s*[A-Z])|\+(?!\s))/);
				if (t) return {
					match_: t[0],
					remainder: e.substr(t[0].length)
				};
				var n = Q.patterns.findObserveGroups(e, "", "$", "$", "");
				return n && (t = n.match_.match(/^\$(?:\(?[+\-]?(?:[0-9]*[a-z]?[+\-])?[0-9]*[a-z](?:[+\-][0-9]*[a-z]?)?\)?|\+|-)\$$/), t) ? {
					match_: t[0],
					remainder: e.substr(t[0].length)
				} : null;
			},
			amount2: function(e) {
				return this.amount(e);
			},
			"(KV letters),": /^(?:[A-Z][a-z]{0,2}|i)(?=,)/,
			formula$: function(e) {
				if (e.match(/^\([a-z]+\)$/)) return null;
				var t = e.match(/^(?:[a-z]|(?:[0-9\ \+\-\,\.\(\)]+[a-z])+[0-9\ \+\-\,\.\(\)]*|(?:[a-z][0-9\ \+\-\,\.\(\)]+)+[a-z]?)$/);
				return t ? {
					match_: t[0],
					remainder: e.substr(t[0].length)
				} : null;
			},
			uprightEntities: /^(?:pH|pOH|pC|pK|iPr|iBu)(?=$|[^a-zA-Z])/,
			"/": /^\s*(\/)\s*/,
			"//": /^\s*(\/\/)\s*/,
			"*": /^\s*[*.]\s*/
		},
		findObserveGroups: function(e, t, n, r, i, a, o, s, c, l) {
			var u = function(e, t) {
				if (typeof t == "string") return e.indexOf(t) === 0 ? t : null;
				var n = e.match(t);
				return n ? n[0] : null;
			}, d = function(e, t, n) {
				for (var r = 0; t < e.length;) {
					var i = e.charAt(t), a = u(e.substr(t), n);
					if (a !== null && r === 0) return {
						endMatchBegin: t,
						endMatchEnd: t + a.length
					};
					if (i === "{") r++;
					else if (i === "}") {
						if (r === 0) throw ["ExtraCloseMissingOpen", "Extra close brace or missing open brace"];
						r--;
					}
					t++;
				}
				return null;
			}, f = u(e, t);
			if (f === null || (e = e.substr(f.length), f = u(e, n), f === null)) return null;
			var p = d(e, f.length, r || i);
			if (p === null) return null;
			var m = e.substring(0, r ? p.endMatchEnd : p.endMatchBegin);
			if (a || o) {
				var h = this.findObserveGroups(e.substr(p.endMatchEnd), a, o, s, c);
				if (h === null) return null;
				var g = [m, h.match_];
				return {
					match_: l ? g.join("") : g,
					remainder: h.remainder
				};
			}
			return {
				match_: m,
				remainder: e.substr(p.endMatchEnd)
			};
		},
		match_: function(e, t) {
			var n = Q.patterns.patterns[e];
			if (n === void 0) throw ["MhchemBugP", "mhchem bug P. Please report. (" + e + ")"];
			if (typeof n == "function") return Q.patterns.patterns[e](t);
			var r = t.match(n);
			return r ? {
				match_: r[2] ? [r[1], r[2]] : r[1] ? r[1] : r[0],
				remainder: t.substr(r[0].length)
			} : null;
		}
	},
	actions: {
		"a=": function(e, t) {
			e.a = (e.a || "") + t;
		},
		"b=": function(e, t) {
			e.b = (e.b || "") + t;
		},
		"p=": function(e, t) {
			e.p = (e.p || "") + t;
		},
		"o=": function(e, t) {
			e.o = (e.o || "") + t;
		},
		"q=": function(e, t) {
			e.q = (e.q || "") + t;
		},
		"d=": function(e, t) {
			e.d = (e.d || "") + t;
		},
		"rm=": function(e, t) {
			e.rm = (e.rm || "") + t;
		},
		"text=": function(e, t) {
			e.text_ = (e.text_ || "") + t;
		},
		insert: function(e, t, n) {
			return { type_: n };
		},
		"insert+p1": function(e, t, n) {
			return {
				type_: n,
				p1: t
			};
		},
		"insert+p1+p2": function(e, t, n) {
			return {
				type_: n,
				p1: t[0],
				p2: t[1]
			};
		},
		copy: function(e, t) {
			return t;
		},
		rm: function(e, t) {
			return {
				type_: "rm",
				p1: t || ""
			};
		},
		text: function(e, t) {
			return Q.go(t, "text");
		},
		"{text}": function(e, t) {
			var n = ["{"];
			return Q.concatArray(n, Q.go(t, "text")), n.push("}"), n;
		},
		"tex-math": function(e, t) {
			return Q.go(t, "tex-math");
		},
		"tex-math tight": function(e, t) {
			return Q.go(t, "tex-math tight");
		},
		bond: function(e, t, n) {
			return {
				type_: "bond",
				kind_: n || t
			};
		},
		"color0-output": function(e, t) {
			return {
				type_: "color0",
				color: t[0]
			};
		},
		ce: function(e, t) {
			return Q.go(t);
		},
		"1/2": function(e, t) {
			var n = [];
			t.match(/^[+\-]/) && (n.push(t.substr(0, 1)), t = t.substr(1));
			var r = t.match(/^([0-9]+|\$[a-z]\$|[a-z])\/([0-9]+)(\$[a-z]\$|[a-z])?$/);
			return r[1] = r[1].replace(/\$/g, ""), n.push({
				type_: "frac",
				p1: r[1],
				p2: r[2]
			}), r[3] && (r[3] = r[3].replace(/\$/g, ""), n.push({
				type_: "tex-math",
				p1: r[3]
			})), n;
		},
		"9,9": function(e, t) {
			return Q.go(t, "9,9");
		}
	},
	createTransitions: function(e) {
		var t, n, r, i, a = {};
		for (t in e) for (n in e[t]) for (r = n.split("|"), e[t][n].stateArray = r, i = 0; i < r.length; i++) a[r[i]] = [];
		for (t in e) for (n in e[t]) for (r = e[t][n].stateArray || [], i = 0; i < r.length; i++) {
			var o = e[t][n];
			if (o.action_) {
				o.action_ = [].concat(o.action_);
				for (var s = 0; s < o.action_.length; s++) typeof o.action_[s] == "string" && (o.action_[s] = { type_: o.action_[s] });
			} else o.action_ = [];
			for (var c = t.split("|"), l = 0; l < c.length; l++) if (r[i] === "*") for (var u in a) a[u].push({
				pattern: c[l],
				task: o
			});
			else a[r[i]].push({
				pattern: c[l],
				task: o
			});
		}
		return a;
	},
	stateMachines: {}
};
Q.stateMachines = {
	ce: {
		transitions: Q.createTransitions({
			empty: { "*": { action_: "output" } },
			else: { "0|1|2": {
				action_: "beginsWithBond=false",
				revisit: !0,
				toContinue: !0
			} },
			oxidation$: { 0: { action_: "oxidation-output" } },
			CMT: {
				r: {
					action_: "rdt=",
					nextState: "rt"
				},
				rd: {
					action_: "rqt=",
					nextState: "rdt"
				}
			},
			arrowUpDown: { "0|1|2|as": {
				action_: [
					"sb=false",
					"output",
					"operator"
				],
				nextState: "1"
			} },
			uprightEntities: { "0|1|2": {
				action_: ["o=", "output"],
				nextState: "1"
			} },
			orbital: { "0|1|2|3": {
				action_: "o=",
				nextState: "o"
			} },
			"->": {
				"0|1|2|3": {
					action_: "r=",
					nextState: "r"
				},
				"a|as": {
					action_: ["output", "r="],
					nextState: "r"
				},
				"*": {
					action_: ["output", "r="],
					nextState: "r"
				}
			},
			"+": {
				o: {
					action_: "d= kv",
					nextState: "d"
				},
				"d|D": {
					action_: "d=",
					nextState: "d"
				},
				q: {
					action_: "d=",
					nextState: "qd"
				},
				"qd|qD": {
					action_: "d=",
					nextState: "qd"
				},
				dq: {
					action_: ["output", "d="],
					nextState: "d"
				},
				3: {
					action_: [
						"sb=false",
						"output",
						"operator"
					],
					nextState: "0"
				}
			},
			amount: { "0|2": {
				action_: "a=",
				nextState: "a"
			} },
			"pm-operator": { "0|1|2|a|as": {
				action_: [
					"sb=false",
					"output",
					{
						type_: "operator",
						option: "\\pm"
					}
				],
				nextState: "0"
			} },
			operator: { "0|1|2|a|as": {
				action_: [
					"sb=false",
					"output",
					"operator"
				],
				nextState: "0"
			} },
			"-$": {
				"o|q": {
					action_: ["charge or bond", "output"],
					nextState: "qd"
				},
				d: {
					action_: "d=",
					nextState: "d"
				},
				D: {
					action_: ["output", {
						type_: "bond",
						option: "-"
					}],
					nextState: "3"
				},
				q: {
					action_: "d=",
					nextState: "qd"
				},
				qd: {
					action_: "d=",
					nextState: "qd"
				},
				"qD|dq": {
					action_: ["output", {
						type_: "bond",
						option: "-"
					}],
					nextState: "3"
				}
			},
			"-9": { "3|o": {
				action_: ["output", {
					type_: "insert",
					option: "hyphen"
				}],
				nextState: "3"
			} },
			"- orbital overlap": {
				o: {
					action_: ["output", {
						type_: "insert",
						option: "hyphen"
					}],
					nextState: "2"
				},
				d: {
					action_: ["output", {
						type_: "insert",
						option: "hyphen"
					}],
					nextState: "2"
				}
			},
			"-": {
				"0|1|2": {
					action_: [
						{
							type_: "output",
							option: 1
						},
						"beginsWithBond=true",
						{
							type_: "bond",
							option: "-"
						}
					],
					nextState: "3"
				},
				3: { action_: {
					type_: "bond",
					option: "-"
				} },
				a: {
					action_: ["output", {
						type_: "insert",
						option: "hyphen"
					}],
					nextState: "2"
				},
				as: {
					action_: [{
						type_: "output",
						option: 2
					}, {
						type_: "bond",
						option: "-"
					}],
					nextState: "3"
				},
				b: { action_: "b=" },
				o: {
					action_: {
						type_: "- after o/d",
						option: !1
					},
					nextState: "2"
				},
				q: {
					action_: {
						type_: "- after o/d",
						option: !1
					},
					nextState: "2"
				},
				"d|qd|dq": {
					action_: {
						type_: "- after o/d",
						option: !0
					},
					nextState: "2"
				},
				"D|qD|p": {
					action_: ["output", {
						type_: "bond",
						option: "-"
					}],
					nextState: "3"
				}
			},
			amount2: { "1|3": {
				action_: "a=",
				nextState: "a"
			} },
			letters: {
				"0|1|2|3|a|as|b|p|bp|o": {
					action_: "o=",
					nextState: "o"
				},
				"q|dq": {
					action_: ["output", "o="],
					nextState: "o"
				},
				"d|D|qd|qD": {
					action_: "o after d",
					nextState: "o"
				}
			},
			digits: {
				o: {
					action_: "q=",
					nextState: "q"
				},
				"d|D": {
					action_: "q=",
					nextState: "dq"
				},
				q: {
					action_: ["output", "o="],
					nextState: "o"
				},
				a: {
					action_: "o=",
					nextState: "o"
				}
			},
			"space A": { "b|p|bp": {} },
			space: {
				a: { nextState: "as" },
				0: { action_: "sb=false" },
				"1|2": { action_: "sb=true" },
				"r|rt|rd|rdt|rdq": {
					action_: "output",
					nextState: "0"
				},
				"*": {
					action_: ["output", "sb=true"],
					nextState: "1"
				}
			},
			"1st-level escape": {
				"1|2": { action_: ["output", {
					type_: "insert+p1",
					option: "1st-level escape"
				}] },
				"*": {
					action_: ["output", {
						type_: "insert+p1",
						option: "1st-level escape"
					}],
					nextState: "0"
				}
			},
			"[(...)]": {
				"r|rt": {
					action_: "rd=",
					nextState: "rd"
				},
				"rd|rdt": {
					action_: "rq=",
					nextState: "rdq"
				}
			},
			"...": {
				"o|d|D|dq|qd|qD": {
					action_: ["output", {
						type_: "bond",
						option: "..."
					}],
					nextState: "3"
				},
				"*": {
					action_: [{
						type_: "output",
						option: 1
					}, {
						type_: "insert",
						option: "ellipsis"
					}],
					nextState: "1"
				}
			},
			". |* ": { "*": {
				action_: ["output", {
					type_: "insert",
					option: "addition compound"
				}],
				nextState: "1"
			} },
			"state of aggregation $": { "*": {
				action_: ["output", "state of aggregation"],
				nextState: "1"
			} },
			"{[(": {
				"a|as|o": {
					action_: [
						"o=",
						"output",
						"parenthesisLevel++"
					],
					nextState: "2"
				},
				"0|1|2|3": {
					action_: [
						"o=",
						"output",
						"parenthesisLevel++"
					],
					nextState: "2"
				},
				"*": {
					action_: [
						"output",
						"o=",
						"output",
						"parenthesisLevel++"
					],
					nextState: "2"
				}
			},
			")]}": {
				"0|1|2|3|b|p|bp|o": {
					action_: ["o=", "parenthesisLevel--"],
					nextState: "o"
				},
				"a|as|d|D|q|qd|qD|dq": {
					action_: [
						"output",
						"o=",
						"parenthesisLevel--"
					],
					nextState: "o"
				}
			},
			", ": { "*": {
				action_: ["output", "comma"],
				nextState: "0"
			} },
			"^_": { "*": {} },
			"^{(...)}|^($...$)": {
				"0|1|2|as": {
					action_: "b=",
					nextState: "b"
				},
				p: {
					action_: "b=",
					nextState: "bp"
				},
				"3|o": {
					action_: "d= kv",
					nextState: "D"
				},
				q: {
					action_: "d=",
					nextState: "qD"
				},
				"d|D|qd|qD|dq": {
					action_: ["output", "d="],
					nextState: "D"
				}
			},
			"^a|^\\x{}{}|^\\x{}|^\\x|'": {
				"0|1|2|as": {
					action_: "b=",
					nextState: "b"
				},
				p: {
					action_: "b=",
					nextState: "bp"
				},
				"3|o": {
					action_: "d= kv",
					nextState: "d"
				},
				q: {
					action_: "d=",
					nextState: "qd"
				},
				"d|qd|D|qD": { action_: "d=" },
				dq: {
					action_: ["output", "d="],
					nextState: "d"
				}
			},
			"_{(state of aggregation)}$": { "d|D|q|qd|qD|dq": {
				action_: ["output", "q="],
				nextState: "q"
			} },
			"_{(...)}|_($...$)|_9|_\\x{}{}|_\\x{}|_\\x": {
				"0|1|2|as": {
					action_: "p=",
					nextState: "p"
				},
				b: {
					action_: "p=",
					nextState: "bp"
				},
				"3|o": {
					action_: "q=",
					nextState: "q"
				},
				"d|D": {
					action_: "q=",
					nextState: "dq"
				},
				"q|qd|qD|dq": {
					action_: ["output", "q="],
					nextState: "q"
				}
			},
			"=<>": { "0|1|2|3|a|as|o|q|d|D|qd|qD|dq": {
				action_: [{
					type_: "output",
					option: 2
				}, "bond"],
				nextState: "3"
			} },
			"#": { "0|1|2|3|a|as|o": {
				action_: [{
					type_: "output",
					option: 2
				}, {
					type_: "bond",
					option: "#"
				}],
				nextState: "3"
			} },
			"{}": { "*": {
				action_: {
					type_: "output",
					option: 1
				},
				nextState: "1"
			} },
			"{...}": {
				"0|1|2|3|a|as|b|p|bp": {
					action_: "o=",
					nextState: "o"
				},
				"o|d|D|q|qd|qD|dq": {
					action_: ["output", "o="],
					nextState: "o"
				}
			},
			"$...$": {
				a: { action_: "a=" },
				"0|1|2|3|as|b|p|bp|o": {
					action_: "o=",
					nextState: "o"
				},
				"as|o": { action_: "o=" },
				"q|d|D|qd|qD|dq": {
					action_: ["output", "o="],
					nextState: "o"
				}
			},
			"\\bond{(...)}": { "*": {
				action_: [{
					type_: "output",
					option: 2
				}, "bond"],
				nextState: "3"
			} },
			"\\frac{(...)}": { "*": {
				action_: [{
					type_: "output",
					option: 1
				}, "frac-output"],
				nextState: "3"
			} },
			"\\overset{(...)}": { "*": {
				action_: [{
					type_: "output",
					option: 2
				}, "overset-output"],
				nextState: "3"
			} },
			"\\underset{(...)}": { "*": {
				action_: [{
					type_: "output",
					option: 2
				}, "underset-output"],
				nextState: "3"
			} },
			"\\underbrace{(...)}": { "*": {
				action_: [{
					type_: "output",
					option: 2
				}, "underbrace-output"],
				nextState: "3"
			} },
			"\\color{(...)}{(...)}1|\\color(...){(...)}2": { "*": {
				action_: [{
					type_: "output",
					option: 2
				}, "color-output"],
				nextState: "3"
			} },
			"\\color{(...)}0": { "*": { action_: [{
				type_: "output",
				option: 2
			}, "color0-output"] } },
			"\\ce{(...)}": { "*": {
				action_: [{
					type_: "output",
					option: 2
				}, "ce"],
				nextState: "3"
			} },
			"\\,": { "*": {
				action_: [{
					type_: "output",
					option: 1
				}, "copy"],
				nextState: "1"
			} },
			"\\x{}{}|\\x{}|\\x": {
				"0|1|2|3|a|as|b|p|bp|o|c0": {
					action_: ["o=", "output"],
					nextState: "3"
				},
				"*": {
					action_: [
						"output",
						"o=",
						"output"
					],
					nextState: "3"
				}
			},
			others: { "*": {
				action_: [{
					type_: "output",
					option: 1
				}, "copy"],
				nextState: "3"
			} },
			else2: {
				a: {
					action_: "a to o",
					nextState: "o",
					revisit: !0
				},
				as: {
					action_: ["output", "sb=true"],
					nextState: "1",
					revisit: !0
				},
				"r|rt|rd|rdt|rdq": {
					action_: ["output"],
					nextState: "0",
					revisit: !0
				},
				"*": {
					action_: ["output", "copy"],
					nextState: "3"
				}
			}
		}),
		actions: {
			"o after d": function(e, t) {
				var n;
				if ((e.d || "").match(/^[0-9]+$/)) {
					var r = e.d;
					e.d = void 0, n = this.output(e), e.b = r;
				} else n = this.output(e);
				return Q.actions["o="](e, t), n;
			},
			"d= kv": function(e, t) {
				e.d = t, e.dType = "kv";
			},
			"charge or bond": function(e, t) {
				if (e.beginsWithBond) {
					var n = [];
					return Q.concatArray(n, this.output(e)), Q.concatArray(n, Q.actions.bond(e, t, "-")), n;
				}
				e.d = t;
			},
			"- after o/d": function(e, t, n) {
				var r = Q.patterns.match_("orbital", e.o || ""), i = Q.patterns.match_("one lowercase greek letter $", e.o || ""), a = Q.patterns.match_("one lowercase latin letter $", e.o || ""), o = Q.patterns.match_("$one lowercase latin letter$ $", e.o || ""), s = t === "-" && (r && r.remainder === "" || i || a || o);
				!s || e.a || e.b || e.p || e.d || e.q || r || !a || (e.o = "$" + e.o + "$");
				var c = [];
				return s ? (Q.concatArray(c, this.output(e)), c.push({ type_: "hyphen" })) : (r = Q.patterns.match_("digits", e.d || ""), n && r && r.remainder === "" ? (Q.concatArray(c, Q.actions["d="](e, t)), Q.concatArray(c, this.output(e))) : (Q.concatArray(c, this.output(e)), Q.concatArray(c, Q.actions.bond(e, t, "-")))), c;
			},
			"a to o": function(e) {
				e.o = e.a, e.a = void 0;
			},
			"sb=true": function(e) {
				e.sb = !0;
			},
			"sb=false": function(e) {
				e.sb = !1;
			},
			"beginsWithBond=true": function(e) {
				e.beginsWithBond = !0;
			},
			"beginsWithBond=false": function(e) {
				e.beginsWithBond = !1;
			},
			"parenthesisLevel++": function(e) {
				e.parenthesisLevel++;
			},
			"parenthesisLevel--": function(e) {
				e.parenthesisLevel--;
			},
			"state of aggregation": function(e, t) {
				return {
					type_: "state of aggregation",
					p1: Q.go(t, "o")
				};
			},
			comma: function(e, t) {
				var n = t.replace(/\s*$/, "");
				return n !== t && e.parenthesisLevel === 0 ? {
					type_: "comma enumeration L",
					p1: n
				} : {
					type_: "comma enumeration M",
					p1: n
				};
			},
			output: function(e, t, n) {
				var r;
				if (!e.r) r = [], (e.a || e.b || e.p || e.o || e.q || e.d || n) && (e.sb && r.push({ type_: "entitySkip" }), !e.o && !e.q && !e.d && !e.b && !e.p && n !== 2 ? (e.o = e.a, e.a = void 0) : !e.o && !e.q && !e.d && (e.b || e.p) ? (e.o = e.a, e.d = e.b, e.q = e.p, e.a = e.b = e.p = void 0) : e.o && e.dType === "kv" && Q.patterns.match_("d-oxidation$", e.d || "") ? e.dType = "oxidation" : e.o && e.dType === "kv" && !e.q && (e.dType = void 0), r.push({
					type_: "chemfive",
					a: Q.go(e.a, "a"),
					b: Q.go(e.b, "bd"),
					p: Q.go(e.p, "pq"),
					o: Q.go(e.o, "o"),
					q: Q.go(e.q, "pq"),
					d: Q.go(e.d, e.dType === "oxidation" ? "oxidation" : "bd"),
					dType: e.dType
				}));
				else {
					var i = e.rdt === "M" ? Q.go(e.rd, "tex-math") : e.rdt === "T" ? [{
						type_: "text",
						p1: e.rd || ""
					}] : Q.go(e.rd), a = e.rqt === "M" ? Q.go(e.rq, "tex-math") : e.rqt === "T" ? [{
						type_: "text",
						p1: e.rq || ""
					}] : Q.go(e.rq);
					r = {
						type_: "arrow",
						r: e.r,
						rd: i,
						rq: a
					};
				}
				for (var o in e) o !== "parenthesisLevel" && o !== "beginsWithBond" && delete e[o];
				return r;
			},
			"oxidation-output": function(e, t) {
				var n = ["{"];
				return Q.concatArray(n, Q.go(t, "oxidation")), n.push("}"), n;
			},
			"frac-output": function(e, t) {
				return {
					type_: "frac-ce",
					p1: Q.go(t[0]),
					p2: Q.go(t[1])
				};
			},
			"overset-output": function(e, t) {
				return {
					type_: "overset",
					p1: Q.go(t[0]),
					p2: Q.go(t[1])
				};
			},
			"underset-output": function(e, t) {
				return {
					type_: "underset",
					p1: Q.go(t[0]),
					p2: Q.go(t[1])
				};
			},
			"underbrace-output": function(e, t) {
				return {
					type_: "underbrace",
					p1: Q.go(t[0]),
					p2: Q.go(t[1])
				};
			},
			"color-output": function(e, t) {
				return {
					type_: "color",
					color1: t[0],
					color2: Q.go(t[1])
				};
			},
			"r=": function(e, t) {
				e.r = t;
			},
			"rdt=": function(e, t) {
				e.rdt = t;
			},
			"rd=": function(e, t) {
				e.rd = t;
			},
			"rqt=": function(e, t) {
				e.rqt = t;
			},
			"rq=": function(e, t) {
				e.rq = t;
			},
			operator: function(e, t, n) {
				return {
					type_: "operator",
					kind_: n || t
				};
			}
		}
	},
	a: {
		transitions: Q.createTransitions({
			empty: { "*": {} },
			"1/2$": { 0: { action_: "1/2" } },
			else: { 0: {
				nextState: "1",
				revisit: !0
			} },
			"$(...)$": { "*": {
				action_: "tex-math tight",
				nextState: "1"
			} },
			",": { "*": { action_: {
				type_: "insert",
				option: "commaDecimal"
			} } },
			else2: { "*": { action_: "copy" } }
		}),
		actions: {}
	},
	o: {
		transitions: Q.createTransitions({
			empty: { "*": {} },
			"1/2$": { 0: { action_: "1/2" } },
			else: { 0: {
				nextState: "1",
				revisit: !0
			} },
			letters: { "*": { action_: "rm" } },
			"\\ca": { "*": { action_: {
				type_: "insert",
				option: "circa"
			} } },
			"\\x{}{}|\\x{}|\\x": { "*": { action_: "copy" } },
			"${(...)}$|$(...)$": { "*": { action_: "tex-math" } },
			"{(...)}": { "*": { action_: "{text}" } },
			else2: { "*": { action_: "copy" } }
		}),
		actions: {}
	},
	text: {
		transitions: Q.createTransitions({
			empty: { "*": { action_: "output" } },
			"{...}": { "*": { action_: "text=" } },
			"${(...)}$|$(...)$": { "*": { action_: "tex-math" } },
			"\\greek": { "*": { action_: ["output", "rm"] } },
			"\\,|\\x{}{}|\\x{}|\\x": { "*": { action_: ["output", "copy"] } },
			else: { "*": { action_: "text=" } }
		}),
		actions: { output: function(e) {
			if (e.text_) {
				var t = {
					type_: "text",
					p1: e.text_
				};
				for (var n in e) delete e[n];
				return t;
			}
		} }
	},
	pq: {
		transitions: Q.createTransitions({
			empty: { "*": {} },
			"state of aggregation $": { "*": { action_: "state of aggregation" } },
			i$: { 0: {
				nextState: "!f",
				revisit: !0
			} },
			"(KV letters),": { 0: {
				action_: "rm",
				nextState: "0"
			} },
			formula$: { 0: {
				nextState: "f",
				revisit: !0
			} },
			"1/2$": { 0: { action_: "1/2" } },
			else: { 0: {
				nextState: "!f",
				revisit: !0
			} },
			"${(...)}$|$(...)$": { "*": { action_: "tex-math" } },
			"{(...)}": { "*": { action_: "text" } },
			"a-z": { f: { action_: "tex-math" } },
			letters: { "*": { action_: "rm" } },
			"-9.,9": { "*": { action_: "9,9" } },
			",": { "*": { action_: {
				type_: "insert+p1",
				option: "comma enumeration S"
			} } },
			"\\color{(...)}{(...)}1|\\color(...){(...)}2": { "*": { action_: "color-output" } },
			"\\color{(...)}0": { "*": { action_: "color0-output" } },
			"\\ce{(...)}": { "*": { action_: "ce" } },
			"\\,|\\x{}{}|\\x{}|\\x": { "*": { action_: "copy" } },
			else2: { "*": { action_: "copy" } }
		}),
		actions: {
			"state of aggregation": function(e, t) {
				return {
					type_: "state of aggregation subscript",
					p1: Q.go(t, "o")
				};
			},
			"color-output": function(e, t) {
				return {
					type_: "color",
					color1: t[0],
					color2: Q.go(t[1], "pq")
				};
			}
		}
	},
	bd: {
		transitions: Q.createTransitions({
			empty: { "*": {} },
			x$: { 0: {
				nextState: "!f",
				revisit: !0
			} },
			formula$: { 0: {
				nextState: "f",
				revisit: !0
			} },
			else: { 0: {
				nextState: "!f",
				revisit: !0
			} },
			"-9.,9 no missing 0": { "*": { action_: "9,9" } },
			".": { "*": { action_: {
				type_: "insert",
				option: "electron dot"
			} } },
			"a-z": { f: { action_: "tex-math" } },
			x: { "*": { action_: {
				type_: "insert",
				option: "KV x"
			} } },
			letters: { "*": { action_: "rm" } },
			"'": { "*": { action_: {
				type_: "insert",
				option: "prime"
			} } },
			"${(...)}$|$(...)$": { "*": { action_: "tex-math" } },
			"{(...)}": { "*": { action_: "text" } },
			"\\color{(...)}{(...)}1|\\color(...){(...)}2": { "*": { action_: "color-output" } },
			"\\color{(...)}0": { "*": { action_: "color0-output" } },
			"\\ce{(...)}": { "*": { action_: "ce" } },
			"\\,|\\x{}{}|\\x{}|\\x": { "*": { action_: "copy" } },
			else2: { "*": { action_: "copy" } }
		}),
		actions: { "color-output": function(e, t) {
			return {
				type_: "color",
				color1: t[0],
				color2: Q.go(t[1], "bd")
			};
		} }
	},
	oxidation: {
		transitions: Q.createTransitions({
			empty: { "*": {} },
			"roman numeral": { "*": { action_: "roman-numeral" } },
			"${(...)}$|$(...)$": { "*": { action_: "tex-math" } },
			else: { "*": { action_: "copy" } }
		}),
		actions: { "roman-numeral": function(e, t) {
			return {
				type_: "roman numeral",
				p1: t || ""
			};
		} }
	},
	"tex-math": {
		transitions: Q.createTransitions({
			empty: { "*": { action_: "output" } },
			"\\ce{(...)}": { "*": { action_: ["output", "ce"] } },
			"{...}|\\,|\\x{}{}|\\x{}|\\x": { "*": { action_: "o=" } },
			else: { "*": { action_: "o=" } }
		}),
		actions: { output: function(e) {
			if (e.o) {
				var t = {
					type_: "tex-math",
					p1: e.o
				};
				for (var n in e) delete e[n];
				return t;
			}
		} }
	},
	"tex-math tight": {
		transitions: Q.createTransitions({
			empty: { "*": { action_: "output" } },
			"\\ce{(...)}": { "*": { action_: ["output", "ce"] } },
			"{...}|\\,|\\x{}{}|\\x{}|\\x": { "*": { action_: "o=" } },
			"-|+": { "*": { action_: "tight operator" } },
			else: { "*": { action_: "o=" } }
		}),
		actions: {
			"tight operator": function(e, t) {
				e.o = (e.o || "") + "{" + t + "}";
			},
			output: function(e) {
				if (e.o) {
					var t = {
						type_: "tex-math",
						p1: e.o
					};
					for (var n in e) delete e[n];
					return t;
				}
			}
		}
	},
	"9,9": {
		transitions: Q.createTransitions({
			empty: { "*": {} },
			",": { "*": { action_: "comma" } },
			else: { "*": { action_: "copy" } }
		}),
		actions: { comma: function() {
			return { type_: "commaDecimal" };
		} }
	},
	pu: {
		transitions: Q.createTransitions({
			empty: { "*": { action_: "output" } },
			space$: { "*": { action_: ["output", "space"] } },
			"{[(|)]}": { "0|a": { action_: "copy" } },
			"(-)(9)^(-9)": { 0: {
				action_: "number^",
				nextState: "a"
			} },
			"(-)(9.,9)(e)(99)": { 0: {
				action_: "enumber",
				nextState: "a"
			} },
			space: { "0|a": {} },
			"pm-operator": { "0|a": {
				action_: {
					type_: "operator",
					option: "\\pm"
				},
				nextState: "0"
			} },
			operator: { "0|a": {
				action_: "copy",
				nextState: "0"
			} },
			"//": { d: {
				action_: "o=",
				nextState: "/"
			} },
			"/": { d: {
				action_: "o=",
				nextState: "/"
			} },
			"{...}|else": {
				"0|d": {
					action_: "d=",
					nextState: "d"
				},
				a: {
					action_: ["space", "d="],
					nextState: "d"
				},
				"/|q": {
					action_: "q=",
					nextState: "q"
				}
			}
		}),
		actions: {
			enumber: function(e, t) {
				var n = [];
				return t[0] === "+-" || t[0] === "+/-" ? n.push("\\pm ") : t[0] && n.push(t[0]), t[1] && (Q.concatArray(n, Q.go(t[1], "pu-9,9")), t[2] && (t[2].match(/[,.]/) ? Q.concatArray(n, Q.go(t[2], "pu-9,9")) : n.push(t[2])), t[3] = t[4] || t[3], t[3] && (t[3] = t[3].trim(), t[3] === "e" || t[3].substr(0, 1) === "*" ? n.push({ type_: "cdot" }) : n.push({ type_: "times" }))), t[3] && n.push("10^{" + t[5] + "}"), n;
			},
			"number^": function(e, t) {
				var n = [];
				return t[0] === "+-" || t[0] === "+/-" ? n.push("\\pm ") : t[0] && n.push(t[0]), Q.concatArray(n, Q.go(t[1], "pu-9,9")), n.push("^{" + t[2] + "}"), n;
			},
			operator: function(e, t, n) {
				return {
					type_: "operator",
					kind_: n || t
				};
			},
			space: function() {
				return { type_: "pu-space-1" };
			},
			output: function(e) {
				var t, n = Q.patterns.match_("{(...)}", e.d || "");
				n && n.remainder === "" && (e.d = n.match_);
				var r = Q.patterns.match_("{(...)}", e.q || "");
				if (r && r.remainder === "" && (e.q = r.match_), e.d &&= (e.d = e.d.replace(/\u00B0C|\^oC|\^{o}C/g, "{}^{\\circ}C"), e.d.replace(/\u00B0F|\^oF|\^{o}F/g, "{}^{\\circ}F")), e.q) {
					e.q = e.q.replace(/\u00B0C|\^oC|\^{o}C/g, "{}^{\\circ}C"), e.q = e.q.replace(/\u00B0F|\^oF|\^{o}F/g, "{}^{\\circ}F");
					var i = {
						d: Q.go(e.d, "pu"),
						q: Q.go(e.q, "pu")
					};
					e.o === "//" ? t = {
						type_: "pu-frac",
						p1: i.d,
						p2: i.q
					} : (t = i.d, i.d.length > 1 || i.q.length > 1 ? t.push({ type_: " / " }) : t.push({ type_: "/" }), Q.concatArray(t, i.q));
				} else t = Q.go(e.d, "pu-2");
				for (var a in e) delete e[a];
				return t;
			}
		}
	},
	"pu-2": {
		transitions: Q.createTransitions({
			empty: { "*": { action_: "output" } },
			"*": { "*": {
				action_: ["output", "cdot"],
				nextState: "0"
			} },
			"\\x": { "*": { action_: "rm=" } },
			space: { "*": {
				action_: ["output", "space"],
				nextState: "0"
			} },
			"^{(...)}|^(-1)": { 1: { action_: "^(-1)" } },
			"-9.,9": {
				0: {
					action_: "rm=",
					nextState: "0"
				},
				1: {
					action_: "^(-1)",
					nextState: "0"
				}
			},
			"{...}|else": { "*": {
				action_: "rm=",
				nextState: "1"
			} }
		}),
		actions: {
			cdot: function() {
				return { type_: "tight cdot" };
			},
			"^(-1)": function(e, t) {
				e.rm += "^{" + t + "}";
			},
			space: function() {
				return { type_: "pu-space-2" };
			},
			output: function(e) {
				var t = [];
				if (e.rm) {
					var n = Q.patterns.match_("{(...)}", e.rm || "");
					t = n && n.remainder === "" ? Q.go(n.match_, "pu") : {
						type_: "rm",
						p1: e.rm
					};
				}
				for (var r in e) delete e[r];
				return t;
			}
		}
	},
	"pu-9,9": {
		transitions: Q.createTransitions({
			empty: {
				0: { action_: "output-0" },
				o: { action_: "output-o" }
			},
			",": { 0: {
				action_: ["output-0", "comma"],
				nextState: "o"
			} },
			".": { 0: {
				action_: ["output-0", "copy"],
				nextState: "o"
			} },
			else: { "*": { action_: "text=" } }
		}),
		actions: {
			comma: function() {
				return { type_: "commaDecimal" };
			},
			"output-0": function(e) {
				var t = [];
				if (e.text_ = e.text_ || "", e.text_.length > 4) {
					var n = e.text_.length % 3;
					n === 0 && (n = 3);
					for (var r = e.text_.length - 3; r > 0; r -= 3) t.push(e.text_.substr(r, 3)), t.push({ type_: "1000 separator" });
					t.push(e.text_.substr(0, n)), t.reverse();
				} else t.push(e.text_);
				for (var i in e) delete e[i];
				return t;
			},
			"output-o": function(e) {
				var t = [];
				if (e.text_ = e.text_ || "", e.text_.length > 4) {
					for (var n = e.text_.length - 3, r = 0; r < n; r += 3) t.push(e.text_.substr(r, 3)), t.push({ type_: "1000 separator" });
					t.push(e.text_.substr(r));
				} else t.push(e.text_);
				for (var i in e) delete e[i];
				return t;
			}
		}
	}
};
var $ = {
	go: function(e, t) {
		if (!e) return "";
		for (var n = "", r = !1, i = 0; i < e.length; i++) {
			var a = e[i];
			typeof a == "string" ? n += a : (n += $._go2(a), a.type_ === "1st-level escape" && (r = !0));
		}
		return !t && !r && n && (n = "{" + n + "}"), n;
	},
	_goInner: function(e) {
		return e && $.go(e, !0);
	},
	_go2: function(e) {
		var t;
		switch (e.type_) {
			case "chemfive":
				t = "";
				var n = {
					a: $._goInner(e.a),
					b: $._goInner(e.b),
					p: $._goInner(e.p),
					o: $._goInner(e.o),
					q: $._goInner(e.q),
					d: $._goInner(e.d)
				};
				n.a && (n.a.match(/^[+\-]/) && (n.a = "{" + n.a + "}"), t += n.a + "\\,"), (n.b || n.p) && (t += "{\\vphantom{X}}", t += "^{\\hphantom{" + (n.b || "") + "}}_{\\hphantom{" + (n.p || "") + "}}", t += "{\\vphantom{X}}", t += "^{\\smash[t]{\\vphantom{2}}\\mathllap{" + (n.b || "") + "}}", t += "_{\\vphantom{2}\\mathllap{\\smash[t]{" + (n.p || "") + "}}}"), n.o && (n.o.match(/^[+\-]/) && (n.o = "{" + n.o + "}"), t += n.o), e.dType === "kv" ? ((n.d || n.q) && (t += "{\\vphantom{X}}"), n.d && (t += "^{" + n.d + "}"), n.q && (t += "_{\\smash[t]{" + n.q + "}}")) : e.dType === "oxidation" ? (n.d && (t += "{\\vphantom{X}}", t += "^{" + n.d + "}"), n.q && (t += "{\\vphantom{X}}", t += "_{\\smash[t]{" + n.q + "}}")) : (n.q && (t += "{\\vphantom{X}}", t += "_{\\smash[t]{" + n.q + "}}"), n.d && (t += "{\\vphantom{X}}", t += "^{" + n.d + "}"));
				break;
			case "rm":
				t = "\\mathrm{" + e.p1 + "}";
				break;
			case "text":
				e.p1.match(/[\^_]/) ? (e.p1 = e.p1.replace(" ", "~").replace("-", "\\text{-}"), t = "\\mathrm{" + e.p1 + "}") : t = "\\text{" + e.p1 + "}";
				break;
			case "roman numeral":
				t = "\\mathrm{" + e.p1 + "}";
				break;
			case "state of aggregation":
				t = "\\mskip2mu " + $._goInner(e.p1);
				break;
			case "state of aggregation subscript":
				t = "\\mskip1mu " + $._goInner(e.p1);
				break;
			case "bond":
				if (t = $._getBond(e.kind_), !t) throw ["MhchemErrorBond", "mhchem Error. Unknown bond type (" + e.kind_ + ")"];
				break;
			case "frac":
				var r = "\\frac{" + e.p1 + "}{" + e.p2 + "}";
				t = "\\mathchoice{\\textstyle" + r + "}{" + r + "}{" + r + "}{" + r + "}";
				break;
			case "pu-frac":
				var i = "\\frac{" + $._goInner(e.p1) + "}{" + $._goInner(e.p2) + "}";
				t = "\\mathchoice{\\textstyle" + i + "}{" + i + "}{" + i + "}{" + i + "}";
				break;
			case "tex-math":
				t = e.p1 + " ";
				break;
			case "frac-ce":
				t = "\\frac{" + $._goInner(e.p1) + "}{" + $._goInner(e.p2) + "}";
				break;
			case "overset":
				t = "\\overset{" + $._goInner(e.p1) + "}{" + $._goInner(e.p2) + "}";
				break;
			case "underset":
				t = "\\underset{" + $._goInner(e.p1) + "}{" + $._goInner(e.p2) + "}";
				break;
			case "underbrace":
				t = "\\underbrace{" + $._goInner(e.p1) + "}_{" + $._goInner(e.p2) + "}";
				break;
			case "color":
				t = "{\\color{" + e.color1 + "}{" + $._goInner(e.color2) + "}}";
				break;
			case "color0":
				t = "\\color{" + e.color + "}";
				break;
			case "arrow":
				var a = {
					rd: $._goInner(e.rd),
					rq: $._goInner(e.rq)
				}, o = "\\x" + $._getArrow(e.r);
				a.rq && (o += "[{" + a.rq + "}]"), a.rd ? o += "{" + a.rd + "}" : o += "{}", t = o;
				break;
			case "operator":
				t = $._getOperator(e.kind_);
				break;
			case "1st-level escape":
				t = e.p1 + " ";
				break;
			case "space":
				t = " ";
				break;
			case "entitySkip":
				t = "~";
				break;
			case "pu-space-1":
				t = "~";
				break;
			case "pu-space-2":
				t = "\\mkern3mu ";
				break;
			case "1000 separator":
				t = "\\mkern2mu ";
				break;
			case "commaDecimal":
				t = "{,}";
				break;
			case "comma enumeration L":
				t = "{" + e.p1 + "}\\mkern6mu ";
				break;
			case "comma enumeration M":
				t = "{" + e.p1 + "}\\mkern3mu ";
				break;
			case "comma enumeration S":
				t = "{" + e.p1 + "}\\mkern1mu ";
				break;
			case "hyphen":
				t = "\\text{-}";
				break;
			case "addition compound":
				t = "\\,{\\cdot}\\,";
				break;
			case "electron dot":
				t = "\\mkern1mu \\bullet\\mkern1mu ";
				break;
			case "KV x":
				t = "{\\times}";
				break;
			case "prime":
				t = "\\prime ";
				break;
			case "cdot":
				t = "\\cdot ";
				break;
			case "tight cdot":
				t = "\\mkern1mu{\\cdot}\\mkern1mu ";
				break;
			case "times":
				t = "\\times ";
				break;
			case "circa":
				t = "{\\sim}";
				break;
			case "^":
				t = "uparrow";
				break;
			case "v":
				t = "downarrow";
				break;
			case "ellipsis":
				t = "\\ldots ";
				break;
			case "/":
				t = "/";
				break;
			case " / ":
				t = "\\,/\\,";
				break;
			default: throw ["MhchemBugT", "mhchem bug T. Please report."];
		}
		return t;
	},
	_getArrow: function(e) {
		switch (e) {
			case "->": return "rightarrow";
			case "→": return "rightarrow";
			case "⟶": return "rightarrow";
			case "<-": return "leftarrow";
			case "<->": return "leftrightarrow";
			case "<-->": return "rightleftarrows";
			case "<=>": return "rightleftharpoons";
			case "⇌": return "rightleftharpoons";
			case "<=>>": return "rightequilibrium";
			case "<<=>": return "leftequilibrium";
			default: throw ["MhchemBugT", "mhchem bug T. Please report."];
		}
	},
	_getBond: function(e) {
		switch (e) {
			case "-": return "{-}";
			case "1": return "{-}";
			case "=": return "{=}";
			case "2": return "{=}";
			case "#": return "{\\equiv}";
			case "3": return "{\\equiv}";
			case "~": return "{\\tripledash}";
			case "~-": return "{\\mathrlap{\\raisebox{-.1em}{$-$}}\\raisebox{.1em}{$\\tripledash$}}";
			case "~=": return "{\\mathrlap{\\raisebox{-.2em}{$-$}}\\mathrlap{\\raisebox{.2em}{$\\tripledash$}}-}";
			case "~--": return "{\\mathrlap{\\raisebox{-.2em}{$-$}}\\mathrlap{\\raisebox{.2em}{$\\tripledash$}}-}";
			case "-~-": return "{\\mathrlap{\\raisebox{-.2em}{$-$}}\\mathrlap{\\raisebox{.2em}{$-$}}\\tripledash}";
			case "...": return "{{\\cdot}{\\cdot}{\\cdot}}";
			case "....": return "{{\\cdot}{\\cdot}{\\cdot}{\\cdot}}";
			case "->": return "{\\rightarrow}";
			case "<-": return "{\\leftarrow}";
			case "<": return "{<}";
			case ">": return "{>}";
			default: throw ["MhchemBugT", "mhchem bug T. Please report."];
		}
	},
	_getOperator: function(e) {
		switch (e) {
			case "+": return " {}+{} ";
			case "-": return " {}-{} ";
			case "=": return " {}={} ";
			case "<": return " {}<{} ";
			case ">": return " {}>{} ";
			case "<<": return " {}\\ll{} ";
			case ">>": return " {}\\gg{} ";
			case "\\pm": return " {}\\pm{} ";
			case "\\approx": return " {}\\approx{} ";
			case "$\\approx$": return " {}\\approx{} ";
			case "v": return " \\downarrow{} ";
			case "(v)": return " \\downarrow{} ";
			case "^": return " \\uparrow{} ";
			case "(^)": return " \\uparrow{} ";
			default: throw ["MhchemBugT", "mhchem bug T. Please report."];
		}
	}
}, ja = "local.math.display", Ma = {
	"unsupported-command": "local.math.display.unsupported-command",
	"unsupported-environment": "local.math.display.unsupported-environment",
	budget: "local.math.display.budget",
	"stray-end": "local.math.display.stray-end",
	"environment-unclosed": "local.math.display.environment-unclosed",
	"environment-missing-name": "local.math.display.environment-missing-name",
	syntax: "local.math.display.syntax"
}, Na = 5e4, Pa = 2e4, Fa = 2e3, Ia = 50, La = 64, Ra = 1e3, za = 20, Ba = /* @__PURE__ */ new Set(/* @__PURE__ */ "def.gdef.edef.xdef.let.futurelet.global.newcommand.renewcommand.providecommand.newenvironment.renewenvironment.csname.endcsname.expandafter.noexpand.long.outer.protected.catcode.makeatletter.makeatother.chardef.mathchardef.countdef.dimendef.skipdef.toksdef.newcount.newdimen.newskip.newtoks.newbox.newif.href.url.includegraphics.htmlClass.htmlId.htmlStyle.htmlData.input.include.includeonly.openin.openout.read.write.immediate.special.shipout".split(".")), Va = /* @__PURE__ */ new Set(/* @__PURE__ */ "sqrt.frac.dfrac.tfrac.binom.dbinom.tbinom.overline.underline.hat.tilde.vec.dot.ddot.overrightarrow.overleftarrow.widehat.widetilde.overbrace.underbrace.boxed.pmod.not.overset.stackrel.underset.xrightarrow.xleftarrow.xrightleftharpoons.xleftrightharpoons.xleftrightarrow.mathchoice.mathrm.mathbf.mathit.mathsf.mathbb.mathcal.mathscr.mathfrak.mathnormal.operatorname.text.textrm.mbox.textbf.textit.textsf.texttt.phantom.hphantom.vphantom.smash.llap.rlap.raisebox.rule.kern.mkern.mskip.raise.lower.color.textcolor.fcolorbox.ce.pu".split("."));
function Ha(e, t, n) {
	let r = Math.max(0, Math.min(e, t)), i = Math.max(r, Math.min(e, n));
	if (i === r && e > 0) {
		if (r < e) i = r + 1;
		else return {
			start: e - 1,
			end: e
		};
	}
	return {
		start: r,
		end: i
	};
}
function Ua(t, n, r, i, a, o) {
	let s = Ha(t, a, o), c = e(r, "en", i);
	return {
		...s,
		reason: n,
		message: c || r,
		code: ja,
		messageKey: r,
		...i ? { params: i } : {}
	};
}
function Wa(e, t, n, r, i) {
	return Ua(e, "budget", Ma.budget, {
		limit: n,
		kind: t
	}, r, i);
}
function Ga(e) {
	return e.length > La ? `${e.slice(0, 63)}…` : e;
}
var Ka = class extends Error {
	kind;
	limit;
	offset;
	constructor(e, t, n) {
		super("Formula exceeds a display resource budget."), this.kind = e, this.limit = t, this.offset = n;
	}
};
function qa(e) {
	let t = [], n = (e) => {
		if (t.length >= 2e4) throw new Ka("tokens", Pa, e.start);
		t.push(e);
	}, r = 0;
	for (; r < e.length;) {
		let t = e[r];
		if (t === " " || t === "	" || t === "\r" || t === "\n") r += 1;
		else if (t === "%") for (; r < e.length && e[r] !== "\n";) r += 1;
		else if (t === "\\") {
			if (r + 1 >= e.length) {
				n({
					kind: "command",
					value: "\\",
					start: r,
					end: r + 1
				}), r += 1;
				continue;
			}
			let t = e[r + 1];
			if (t === "\\") {
				n({
					kind: "newline",
					value: "\\\\",
					start: r,
					end: r + 2
				}), r += 2;
				continue;
			}
			if (/[A-Za-z]/.test(t)) {
				let t = r + 1;
				for (; t < e.length && /[A-Za-z]/.test(e[t]);) t += 1;
				n({
					kind: "command",
					value: e.slice(r + 1, t),
					start: r,
					end: t
				}), r = t;
				continue;
			}
			n({
				kind: "command",
				value: t,
				start: r,
				end: r + 2
			}), r += 2;
		} else if (t >= "0" && t <= "9") {
			let t = /^\d+(?:\.\d*)?/.exec(e.slice(r));
			n({
				kind: "number",
				value: t[0],
				start: r,
				end: r + t[0].length
			}), r += t[0].length;
		} else if (t === "." && e[r + 1] >= "0" && e[r + 1] <= "9") {
			let t = /^(?:\d+(?:\.\d*)?|\.\d+)/.exec(e.slice(r));
			n({
				kind: "number",
				value: t[0],
				start: r,
				end: r + t[0].length
			}), r += t[0].length;
		} else /[A-Za-z]/.test(t) ? (n({
			kind: "letter",
			value: t,
			start: r,
			end: r + 1
		}), r += 1) : (n({
			kind: "punct",
			value: t,
			start: r,
			end: r + 1
		}), r += 1);
	}
	return n({
		kind: "eof",
		value: "",
		start: e.length,
		end: e.length
	}), t;
}
function Ja(e, t, n) {
	let r = e[n];
	if (!r || r.kind !== "punct" || r.value !== "{") return null;
	let i = 1;
	for (let a = n + 1; a < e.length; a += 1) {
		let n = e[a];
		if (n.kind === "eof") break;
		if (n.kind === "punct") {
			if (n.value === "{") i += 1;
			else if (n.value === "}" && (--i, i === 0)) return {
				name: t.slice(r.end, n.start).trim(),
				groupEnd: n.end,
				terminated: !0
			};
		}
	}
	return {
		name: t.slice(r.end).trim(),
		groupEnd: t.length,
		terminated: !1
	};
}
function Ya(e) {
	let t = qa(e), n = [], r = /* @__PURE__ */ new Map(), i = [], a = [], o = 0, s = 0, c = 0, l = !1, u = (e) => {
		if (o + s + a.length + c > 120) throw new Ka("depth", 120, e);
	}, d = (t, r, i, a, o) => {
		n.length >= Ia || n.push(Ua(e.length, t, r, i, a, o));
	};
	for (let n = 0; n < t.length; n += 1) {
		let f = t[n];
		if (f.kind === "eof") break;
		if (f.kind === "command") {
			let o = f.value, p = r.get(o);
			if (p ? p.push({
				start: f.start,
				end: f.end
			}) : r.set(o, [{
				start: f.start,
				end: f.end
			}]), Ba.has(o) && d("unsupported-command", Ma["unsupported-command"], { name: Ga(o) }, f.start, f.end), o === "left" ? (s += 1, u(f.start)) : o === "right" && (s = Math.max(0, s - 1)), o === "begin" || o === "end") {
				let r = Ja(t, e, n + 1);
				if (o === "begin") {
					if (!r) d("syntax", Ma["environment-missing-name"], void 0, f.start, f.end);
					else if (!r.terminated) d("syntax", Ma["environment-unclosed"], { name: Ga(r.name) || "?" }, f.start, r.groupEnd);
					else if (!r.name) d("syntax", Ma["environment-missing-name"], void 0, f.start, r.groupEnd);
					else {
						let e = {
							name: r.name,
							start: f.start,
							groupEnd: r.groupEnd
						};
						i.push(e), a.push(e), u(f.start);
					}
				} else !r || !r.terminated || !r.name ? d("syntax", Ma["stray-end"], void 0, f.start, r?.groupEnd ?? f.end) : a.length === 0 ? d("syntax", Ma["stray-end"], void 0, f.start, r.groupEnd) : a.pop().name !== r.name && d("syntax", Ma.syntax, void 0, f.start, r.groupEnd);
				c = 0, l = !1;
				continue;
			}
			Va.has(o) ? (c = l ? c + 1 : 1, u(f.start), l = !0) : (c = 0, l = !1);
		} else f.kind === "punct" && (f.value === "{" ? (o += 1, u(f.start)) : f.value === "}" && (o = Math.max(0, o - 1))), c = 0, l = !1;
	}
	for (let e of a) d("syntax", Ma["environment-unclosed"], { name: Ga(e.name) }, e.start, e.groupEnd);
	return n.sort((e, t) => e.start - t.start || e.end - t.end), {
		issues: n,
		commands: r,
		environments: i
	};
}
function Xa(e) {
	if (typeof e != "object" || !e) return {};
	let t = e, n = {};
	return typeof t.position == "number" && Number.isFinite(t.position) && (n.position = t.position), typeof t.length == "number" && Number.isFinite(t.length) && (n.length = t.length), typeof t.rawMessage == "string" && (n.rawMessage = t.rawMessage), typeof t.message == "string" && (n.message = t.message), n;
}
function Za(e, t) {
	if (t.position !== void 0) {
		let n = t.length !== void 0 && t.length > 0 ? t.length : 1;
		return Ha(e, t.position, t.position + n);
	}
	return {
		start: 0,
		end: e
	};
}
function Qa(e, t, n) {
	let r = e.commands.get(t);
	if (!r || r.length === 0) return null;
	if (n !== void 0) {
		let e = r.find((e) => e.start === n);
		if (e) return e;
		let t = r.find((e) => e.start >= n);
		if (t) return t;
	}
	return r[0];
}
function $a(e, t, n) {
	let r = null;
	for (let i of e.environments) i.name === t && (n === void 0 || i.start <= n ? r = i : r ||= i);
	return r ? {
		start: r.start,
		end: r.groupEnd
	} : null;
}
function eo(e, t, n) {
	let r = Xa(n), i = r.rawMessage ?? r.message ?? "", a = /Undefined control sequence: (\\\S+)/.exec(i);
	if (a) {
		let n = Ga(a[1].slice(1)), i = Qa(t, n, r.position) ?? Za(e.length, r);
		return Ua(e.length, "unsupported-command", Ma["unsupported-command"], { name: n }, i.start, i.end);
	}
	let o = /No such environment: (.+)$/.exec(i);
	if (o) {
		let n = Ga(o[1].trim()), i = $a(t, n, r.position) ?? Za(e.length, r);
		return Ua(e.length, "unsupported-environment", Ma["unsupported-environment"], { name: n }, i.start, i.end);
	}
	if (/Too many expansions/i.test(i)) {
		let t = Za(e.length, r);
		return Wa(e.length, "tokens", Ra, t.start, t.end);
	}
	let s = /\\tag works only in display/.test(i) ? Qa(t, "tag", r.position) ?? Za(e.length, r) : Za(e.length, r);
	return Ua(e.length, "syntax", Ma.syntax, void 0, s.start, s.end);
}
function to(e) {
	return e.length > 2e3 ? `${e.slice(0, Fa)}…` : e;
}
function no(e, t = !1) {
	if (e.length > 5e4) return {
		html: null,
		issues: [Wa(e.length, "source", Na, 0, e.length)]
	};
	let n;
	try {
		n = Ya(e);
	} catch (t) {
		return t instanceof Ka ? {
			html: null,
			issues: [Wa(e.length, t.kind, t.limit, t.offset, t.offset + 1)]
		} : {
			html: null,
			issues: [Ua(e.length, "syntax", Ma.syntax, void 0, 0, e.length)]
		};
	}
	if (n.issues.length > 0) return {
		html: null,
		issues: n.issues
	};
	try {
		return {
			html: ka.renderToString(e, {
				displayMode: t,
				output: "htmlAndMathml",
				throwOnError: !0,
				strict: "ignore",
				trust: !1,
				maxExpand: Ra,
				maxSize: za,
				macros: {}
			}),
			issues: []
		};
	} catch (t) {
		return {
			html: null,
			issues: [eo(e, n, t)]
		};
	}
}
function ro(e, t = !0) {
	return no(e, t).issues;
}
export { ro as n, no as r, to as t };
