import { _ as e, g as t, t as n, y as r } from "./compiler-core-MF3N1RCF.js";
import { d as i } from "./validation-BXMN-r9R.js";
import { n as a } from "./math-display-DWZ_IJQh.js";
import { o, t as s } from "./parser-standard-_UZ5nkj3.js";
import { t as c } from "./default-d2u6mrJW.js";
import { i as l, r as u, t as d } from "./types-BJGidUZ1.js";
// src/compiler/standard.ts
function f(e) {
	let t = i(e, c.components, s);
	if (t.ok) return t;
	throw new d(t.message, {
		code: t.key,
		...t.detail === void 0 ? {} : { detail: t.detail }
	});
}
function p(e) {
	return e === void 0 ? void 0 : Object.freeze({ ...e });
}
function m(i) {
	let s = f(i), c = p(i), d = {
		display: a,
		htmlDocument: o,
		plotMath: {
			kind: r,
			gridSize: e,
			compile: t
		}
	};
	return { compile(e) {
		return l(n(e, c, s, d), u);
	} };
}
export { d as CompilerConfigurationError, m as createStandardCompiler };
