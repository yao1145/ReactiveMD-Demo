// src/runtime-services/identity.ts
var e = new TextEncoder(), t = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/, n = /^[^\u0000-\u001f\u007f]{1,256}$/;
function r(t) {
	let n = e.encode(t), r = 2166136261;
	for (let e = 0; e < n.length; e += 1) r ^= n[e], r = Math.imul(r, 16777619) >>> 0;
	return r >>> 0;
}
function i(e) {
	if (typeof e != "string") throw TypeError("localSourceDigest requires a source string.");
	return `fnv1a32:${r(e).toString(16).padStart(8, "0")}`;
}
function a(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	return n.test(t) ? t : void 0;
}
function o(e) {
	if (typeof e != "string") return;
	let n = e.trim();
	return t.test(n) ? n : void 0;
}
function s(e) {
	return a(e.documentId) ?? e.sourceDigest;
}
function c(e) {
	let t = s(e), n = o(e.stateKey), i = n === void 0 ? `node:${e.nodeId}` : `state:${n}`, a = encodeURIComponent(t);
	return `doc:${a.length <= 256 ? a : `h${r(t).toString(16).padStart(8, "0")}`}:${i}`;
}
function l(e, t) {
	return r(`${e >>> 0}:${t}`);
}
function u(e) {
	if (typeof e.explicitSeed == "number" && Number.isFinite(e.explicitSeed)) return Math.trunc(e.explicitSeed) >>> 0;
	let t = o(e.stateKey), n = t === void 0 ? `node:${e.nodeId}` : `state:${t}`;
	return l(e.documentSeed, `${e.componentId}|${n}`);
}
function d(e) {
	return Number.isFinite(e) ? Math.trunc(e) >>> 0 : 0;
}
// src/runtime-services/random.ts
var f = "mulberry32", p = 1;
function m(e) {
	return Object.freeze({
		algorithm: f,
		version: 1,
		state: d(e)
	});
}
function h(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return null;
	let t = e;
	if (t.algorithm !== "mulberry32" || t.version !== 1 || typeof t.state != "number" || !Number.isFinite(t.state)) return null;
	let n = d(t.state);
	return n === t.state ? Object.freeze({
		algorithm: f,
		version: 1,
		state: n
	}) : null;
}
function g(e) {
	let t = d(e.state + 1831565813), n = Math.imul(t ^ t >>> 15, t | 1);
	return n ^= n + Math.imul(n ^ n >>> 7, n | 61), {
		value: ((n ^ n >>> 14) >>> 0) / 4294967296,
		state: Object.freeze({
			algorithm: f,
			version: 1,
			state: t
		})
	};
}
function _(e, t, n) {
	let r = g(e);
	if (!Number.isFinite(t) || !Number.isFinite(n)) return {
		value: 0,
		state: r.state
	};
	let i = Math.ceil(Math.min(t, n)), a = Math.floor(Math.max(t, n));
	return a < i ? {
		value: i,
		state: r.state
	} : {
		value: i + Math.floor(r.value * (a - i + 1)),
		state: r.state
	};
}
function v(e, t) {
	let n = t.slice(), r = e;
	for (let e = n.length - 1; e > 0; --e) {
		let t = _(r, 0, e);
		r = t.state;
		let i = n[e];
		n[e] = n[t.value], n[t.value] = i;
	}
	return {
		items: n,
		state: r
	};
}
function y(e, t) {
	return m(l(e, t));
}
function b(e, t = .5) {
	let n = g(e);
	return {
		value: n.value < t,
		state: n.state
	};
}
// src/runtime-services/component-state.ts
var x = "reactive-md-component-state/v1", S = "reactive-md-component-state-document/v1", C = 16384, w = 262144, T = 16, E = 1e4, D = 1e5, O = 1048576, k = 128, A = 64, j = 512, M = 1e6, N = new TextEncoder();
function P(e, t) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function F(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function I(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function L(e, t) {
	if (e === null) return null;
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw TypeError("numbers must be finite");
		return e;
	}
	if (typeof e == "string") {
		if (e.length > 1e5) throw RangeError(`strings exceed ${D} characters`);
		if (!I(e)) throw TypeError("strings must be well-formed Unicode");
		return e;
	}
	if (t >= 16) throw RangeError("nesting exceeds 16 levels");
	if (Array.isArray(e)) {
		if (e.length > 1e4) throw RangeError(`arrays exceed ${E} items`);
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("arrays cannot use symbol keys");
		return e.map((e) => L(e, t + 1));
	}
	if (F(e)) {
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("objects cannot use symbol keys");
		let n = Object.keys(e);
		if (n.length > 1e4) throw RangeError(`objects exceed ${E} keys`);
		let r = {};
		for (let i of n) {
			if (i === "__proto__") throw TypeError("the key \"__proto__\" is not allowed");
			if (i.length > 1e5) throw RangeError(`keys exceed ${D} characters`);
			if (!I(i)) throw TypeError("keys must be well-formed Unicode");
			r[i] = L(e[i], t + 1);
		}
		return r;
	}
	throw TypeError("values must be JSON-safe primitives, arrays or plain objects");
}
function R(e) {
	return L(e, 0);
}
function z(e) {
	return Object.freeze({
		...e,
		data: L(e.data, 0),
		...e.random === void 0 ? {} : { random: h(e.random) ?? e.random }
	});
}
function B(e) {
	if (!F(e)) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.shape", "A component state record must be a plain object.")]
	};
	let t = /* @__PURE__ */ new Set([
		"format",
		"component",
		"componentVersion",
		"stateVersion",
		"key",
		"documentId",
		"data",
		"random"
	]);
	for (let n of Object.keys(e)) if (!t.has(n)) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.key", `Unknown component state key "${n}".`)]
	};
	if (e.format !== "reactive-md-component-state/v1") return {
		ok: !1,
		diagnostics: [P("local.runtime.state.format", `Unsupported component state format; expected "${x}".`)]
	};
	let n = e.component;
	if (typeof n != "string" || n.trim() === "" || n.length > k) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.component", "Component name must be a non-empty string.")]
	};
	let r = e.componentVersion;
	if (typeof r != "string" || r.trim() === "" || r.length > A) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.component-version", "Component version must be a non-empty string.")]
	};
	let i = e.stateVersion;
	if (typeof i != "number" || !Number.isInteger(i) || i < 0 || i > M) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.version", "State version must be a non-negative integer.")]
	};
	let a = e.key;
	if (typeof a != "string" || a.trim() === "" || a.length > j) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.key-name", "State key must be a non-empty string.")]
	};
	let o = e.documentId;
	if (o !== void 0 && (typeof o != "string" || o.trim() === "" || o.length > 256)) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.document", "State documentId must be a non-empty string.")]
	};
	let s;
	try {
		s = R(e.data);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [P("local.runtime.state.data", `Invalid component state data: ${e instanceof Error ? e.message : String(e)}.`)]
		};
	}
	let c;
	if (e.random !== void 0 && (c = h(e.random) ?? void 0, c === void 0)) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.random", "Invalid random state.")]
	};
	let l = {
		format: x,
		component: n,
		componentVersion: r,
		stateVersion: i,
		key: a,
		...o === void 0 ? {} : { documentId: o },
		data: s,
		...c === void 0 ? {} : { random: c }
	};
	return N.encode(JSON.stringify(l)).length > 16384 ? {
		ok: !1,
		diagnostics: [P("local.runtime.state.size", `Component state exceeds the ${C}-byte limit.`)]
	} : {
		ok: !0,
		record: Object.freeze(l)
	};
}
function V(e) {
	let t = e;
	if (typeof e == "string") {
		if (e.length > 1048576) return {
			ok: !1,
			diagnostics: [P("local.runtime.state.size", "The component state payload is too large.")]
		};
		try {
			t = JSON.parse(e);
		} catch {
			return {
				ok: !1,
				diagnostics: [P("local.runtime.state.json", "The component state payload is not valid JSON.")]
			};
		}
	}
	if (!F(t)) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.shape", "The component state document must be a plain object.")]
	};
	if (t.format !== "reactive-md-component-state-document/v1") return {
		ok: !1,
		diagnostics: [P("local.runtime.state.document-format", `Unsupported component state document format; expected "${S}".`)]
	};
	if (!F(t.records)) return {
		ok: !1,
		diagnostics: [P("local.runtime.state.records", "Component state records must be a plain object.")]
	};
	let n = {}, r = [], i = [], a = 0;
	for (let e of Object.keys(t.records)) {
		let o = B(t.records[e]);
		o.ok ? o.record.key === e ? (a += N.encode(JSON.stringify(o.record)).length, a > 262144 ? (i.push(e), r.push(P("local.runtime.state.total-size", `Component state exceeds the ${w}-byte document limit.`))) : n[e] = o.record) : (i.push(e), r.push(P("local.runtime.state.key-mismatch", `Component state record "${e}" declares a different key "${o.record.key}".`))) : (i.push(e), r.push(...o.diagnostics));
	}
	return {
		ok: !0,
		records: n,
		diagnostics: r,
		skipped: i
	};
}
function H(e) {
	let t = s(e), n = e.sourceDigest, r = e.knownKeys, i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Set(), l = /* @__PURE__ */ new Set(), u = [], d = () => {
		for (let e of l) e();
	}, f = (e) => {
		let t = 0;
		for (let [n, r] of i) n !== e && (t += N.encode(JSON.stringify(r)).length);
		return t;
	}, p = {
		documentId: t,
		sourceDigest: n,
		key(e) {
			return c({
				documentId: t,
				sourceDigest: n,
				nodeId: e.nodeId,
				stateKey: e.stateKey
			});
		},
		handle(e) {
			let n = p.key({
				nodeId: e.nodeId,
				stateKey: e.stateKey
			}), r = a.get(n), s = !1;
			r !== void 0 && r !== e.nodeId ? (s = !0, o.has(n) || (o.add(n), u.push(P("local.runtime.state.duplicate-key", `Component state key "${n}" is used by more than one component instance.`)))) : a.set(n, e.nodeId);
			let c = {
				key: n,
				component: e.component,
				componentVersion: e.componentVersion,
				duplicate: s,
				load() {
					if (s) return null;
					let e = i.get(n);
					return e === void 0 ? null : z(e);
				},
				save(r, a) {
					if (s) return {
						ok: !1,
						diagnostics: [P("local.runtime.state.duplicate-key", `Component state key "${n}" is used by more than one component instance.`)]
					};
					let o = a?.version ?? e.stateVersion ?? 0, c = B({
						format: x,
						component: e.component,
						componentVersion: e.componentVersion,
						stateVersion: o,
						key: n,
						documentId: t,
						data: r,
						...a?.random === void 0 ? {} : { random: a.random }
					});
					if (!c.ok) return {
						ok: !1,
						diagnostics: c.diagnostics
					};
					let l = N.encode(JSON.stringify(c.record)).length;
					return f(n) + l > 262144 ? {
						ok: !1,
						diagnostics: [P("local.runtime.state.total-size", `Component state exceeds the ${w}-byte document limit.`)]
					} : (i.set(n, c.record), d(), {
						ok: !0,
						diagnostics: [],
						record: z(c.record)
					});
				},
				clear() {
					s || i.delete(n) && d();
				}
			};
			return Object.freeze(c);
		},
		load(e) {
			let t = i.get(e);
			return t === void 0 ? null : z(t);
		},
		clear(e) {
			i.delete(e) && d();
		},
		snapshot() {
			let e = {};
			for (let [t, n] of i) e[t] = z(n);
			return Object.freeze({
				format: S,
				records: Object.freeze(e)
			});
		},
		restore(e) {
			let n = V(e);
			if (!n.ok) return u.push(...n.diagnostics), {
				accepted: [],
				skipped: [],
				diagnostics: n.diagnostics
			};
			let a = [], o = typeof r == "function" ? r() : r;
			for (let [e, r] of Object.entries(n.records)) r.documentId !== void 0 && r.documentId !== t ? (n.skipped.push(e), n.diagnostics.push(P("local.runtime.state.document-mismatch", `Saved state key "${e}" belongs to a different document.`))) : o !== void 0 && !o.has(e) ? (n.skipped.push(e), n.diagnostics.push(P("local.runtime.state.unknown-component", `Saved state key "${e}" does not match any component in this document.`))) : (i.set(e, r), a.push(e));
			return n.diagnostics.length && u.push(...n.diagnostics), a.length && d(), {
				accepted: a,
				skipped: n.skipped,
				diagnostics: n.diagnostics
			};
		},
		diagnostics() {
			return Object.freeze([...u]);
		},
		subscribe(e) {
			return l.add(e), () => {
				l.delete(e);
			};
		}
	};
	return e.initial !== void 0 && p.restore(e.initial).accepted.length && d(), Object.freeze(p);
}
// src/runtime-services/scheduler.ts
var U = 64, W = 16;
function G() {
	let e = () => typeof performance < "u" && typeof performance.now == "function" ? performance.now() : Date.now(), t = (e, t) => globalThis.setTimeout(e, t), n = (e) => {
		globalThis.clearTimeout(e);
	}, r = typeof globalThis.requestAnimationFrame == "function" ? globalThis.requestAnimationFrame.bind(globalThis) : void 0, i = typeof globalThis.cancelAnimationFrame == "function" ? globalThis.cancelAnimationFrame.bind(globalThis) : void 0, a = typeof document > "u" ? void 0 : document;
	return {
		now: e,
		setTimeout: t,
		clearTimeout: n,
		...r === void 0 ? {} : { requestAnimationFrame: r },
		...i === void 0 ? {} : { cancelAnimationFrame: i },
		isHidden: () => a !== void 0 && a.visibilityState === "hidden",
		subscribeVisibility: (e) => {
			if (a === void 0) return () => {};
			let t = () => e(a.visibilityState === "hidden");
			return a.addEventListener("visibilitychange", t), () => a.removeEventListener("visibilitychange", t);
		}
	};
}
function K(e) {
	let t = G(), n = e?.ports ?? {};
	return {
		now: n.now ?? t.now,
		setTimeout: n.setTimeout ?? t.setTimeout,
		clearTimeout: n.clearTimeout ?? t.clearTimeout,
		...n.requestAnimationFrame ?? t.requestAnimationFrame ? { requestAnimationFrame: n.requestAnimationFrame ?? t.requestAnimationFrame } : {},
		...n.cancelAnimationFrame ?? t.cancelAnimationFrame ? { cancelAnimationFrame: n.cancelAnimationFrame ?? t.cancelAnimationFrame } : {},
		...n.isHidden ?? t.isHidden ? { isHidden: n.isHidden ?? t.isHidden } : {},
		...n.subscribeVisibility ?? t.subscribeVisibility ? { subscribeVisibility: n.subscribeVisibility ?? t.subscribeVisibility } : {}
	};
}
function q(e) {
	let t = K(e), n = e?.maxSubscriptions ?? U, r = e?.minIntervalMs ?? W, i = e?.onError ?? (() => {}), a = /* @__PURE__ */ new Map(), o = 1, s = !1, c = !1, l = 0, u = 0, d = 0, f = null, p = () => {
		let e = t.now();
		return d = Math.max(d, e), d;
	}, m = () => {
		let e = p();
		return e - u - (c ? e - l : 0);
	}, h = (e) => {
		e.timer !== null && (t.clearTimeout(e.timer), e.timer = null), e.frame !== null && t.cancelAnimationFrame && (t.cancelAnimationFrame(e.frame), e.frame = null);
	}, g = (e, t) => {
		try {
			e.kind === "frame" ? e.run(t ?? 0) : e.run();
		} catch (e) {
			try {
				i(e);
			} catch {}
		}
	}, _ = (e, n) => {
		if (s || c || e.removed) return;
		let r = Math.max(0, n);
		e.deadline = p() + r, e.timer = t.setTimeout(() => {
			e.timer = null, !(s || c || e.removed) && (g(e), e.kind === "every" ? (e.deadline = p() + e.interval, _(e, e.interval)) : (e.removed = !0, a.delete(e.id)));
		}, r);
	}, v = (e) => {
		if (s || c || e.removed) return;
		let n = (t) => {
			if (e.frame = null, s || c || e.removed) return;
			let n = e.lastFrameAt;
			e.lastFrameAt = t, g(e, Math.max(0, t - n)), v(e);
		};
		t.requestAnimationFrame && t.cancelAnimationFrame ? e.frame = t.requestAnimationFrame(n) : e.timer = t.setTimeout(() => {
			e.timer = null, n(p());
		}, r);
	}, y = (e) => {
		e.removed = !0, h(e), a.delete(e.id);
	}, b = (e, t, r, i) => {
		if (s) throw Error("The local scheduler has been disposed.");
		if (a.size >= n) throw RangeError(`Local scheduler subscriptions exceed the limit of ${n}.`);
		let l = {
			id: o,
			kind: e,
			interval: t,
			background: r,
			run: i,
			timer: null,
			frame: null,
			deadline: p() + t,
			remaining: t,
			lastFrameAt: p(),
			removed: !1
		};
		return o += 1, a.set(l.id, l), e === "frame" ? v(l) : c || _(l, t), () => y(l);
	}, x = () => {
		if (!(s || c)) {
			c = !0, l = p();
			for (let e of a.values()) h(e), e.kind !== "frame" && e.background === "pause" && (e.remaining = Math.max(0, e.deadline - p()));
		}
	}, S = () => {
		if (!s && c) {
			c = !1, u += Math.max(0, p() - l);
			for (let e of [...a.values()]) e.removed || (e.kind === "frame" ? (e.lastFrameAt = p(), v(e)) : e.background === "pause" ? _(e, e.remaining) : p() >= e.deadline ? (g(e), e.kind === "every" ? (e.deadline = p() + e.interval, _(e, e.interval)) : y(e)) : _(e, e.deadline - p()));
		}
	};
	return t.subscribeVisibility && (f = t.subscribeVisibility((e) => {
		e ? x() : S();
	})), t.isHidden?.() === !0 && x(), Object.freeze({
		now: p,
		activeNow: m,
		get suspended() {
			return c;
		},
		get size() {
			return a.size;
		},
		every(e, t, n) {
			return b("every", Number.isFinite(e) ? Math.max(r, e) : r, n?.background ?? "pause", t);
		},
		after(e, t, n) {
			return b("after", Number.isFinite(e) ? Math.max(0, e) : 0, n?.background ?? "wall-clock", t);
		},
		frame(e) {
			return b("frame", r, "pause", e);
		},
		suspend: x,
		resume: S,
		dispose() {
			if (!s) {
				s = !0;
				for (let e of a.values()) h(e);
				a.clear(), f?.(), f = null;
			}
		}
	});
}
// src/runtime-services/runtime.ts
function J(e) {
	return {
		now: () => e.now(),
		activeNow: () => e.activeNow(),
		get suspended() {
			return e.suspended;
		}
	};
}
function Y(e) {
	let t = s(e), n = e.scheduler ?? q(e.schedulerOptions), i = typeof e.randomSeed == "number" && Number.isFinite(e.randomSeed) ? Math.trunc(e.randomSeed) >>> 0 : r(t);
	return Object.freeze({
		documentId: t,
		sourceDigest: e.sourceDigest,
		randomSeed: i,
		clock: J(n),
		scheduler: n,
		state: H({
			documentId: t,
			sourceDigest: e.sourceDigest,
			initial: e.componentState,
			...e.knownStateKeys === void 0 ? {} : { knownKeys: e.knownStateKeys }
		})
	});
}
function X(e) {
	let t = e?.sourceDigest ?? i(""), n = q({ ports: {
		now: () => 0,
		setTimeout: () => 0,
		clearTimeout: () => {},
		isHidden: () => !1,
		subscribeVisibility: () => () => {}
	} });
	return Y({
		...e,
		sourceDigest: t,
		scheduler: n
	});
}
export { d as A, l as C, o as D, a as E, u as O, c as S, i as T, g as _, x as a, _ as b, O as c, w as d, H as f, y as g, m as h, S as i, s as k, E as l, p as m, Y as n, C as o, f as p, q as r, T as s, X as t, D as u, h as v, r as w, v as x, b as y };
