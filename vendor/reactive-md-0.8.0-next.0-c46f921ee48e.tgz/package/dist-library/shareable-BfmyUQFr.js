import { C as e, F as t, L as n, P as r, k as i, q as a, x as o } from "./manifest-gj41AWZb.js";
import { w as s } from "./validation-BXMN-r9R.js";
import { a as c, c as l, l as u, o as d, s as f } from "./parser-standard-_UZ5nkj3.js";
import { s as p, u as m } from "./registry-B9eKQgGq.js";
import { n as h } from "./options-CnU6rJZf.js";
import { t as g } from "./runtime-BURmhlg5.js";
import { T as _ } from "./runtime-CXAWSoln.js";
import { i as ee, t as v } from "./resources-BSaYBwu7.js";
// src/local/runtime/state.ts
var y = "reactive-md-state/v1", b = 1048576, x = /^fnv1a32:[0-9a-f]{8}$/, S = /* @__PURE__ */ new Set([
	"format",
	"syntax",
	"sourceDigest",
	"parameters",
	"generator"
]), C = /* @__PURE__ */ new Set(["name", "version"]), w = new TextEncoder();
function T(e, t) {
	return {
		code: e,
		message: t.length > 2e3 ? `${t.slice(0, a - 1)}…` : t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function E(e, t, n) {
	e.length < 100 && e.push(T(t, n));
}
function D(e) {
	return e instanceof Error ? e.message : String(e);
}
function O(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function k(e) {
	if (typeof e == "string") return O(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "contains malformed Unicode."
	};
	if (typeof e == "number") return Number.isFinite(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "must be a finite number."
	};
	if (typeof e == "boolean" || e === null) return {
		ok: !0,
		value: e
	};
	if (Array.isArray(e)) {
		let t = [], n = e.length === 0 ? "string" : typeof e[0];
		for (let r = 0; r < e.length; r += 1) {
			let i = e[r];
			if (n === "string" && typeof i == "string") {
				if (!O(i)) return {
					ok: !1,
					message: "contains malformed Unicode."
				};
				t.push(i);
			} else if (n === "number" && typeof i == "number" && Number.isFinite(i)) t.push(i);
			else return {
				ok: !1,
				message: "must be an array of strings or finite numbers of one kind."
			};
		}
		return {
			ok: !0,
			value: Object.freeze(t)
		};
	}
	return {
		ok: !1,
		message: "must be a string, finite number, boolean, null or homogeneous primitive array."
	};
}
function A(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function j(e) {
	return Object.freeze(e.parameters), e.generator && Object.freeze(e.generator), Object.freeze(e);
}
function M(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("generator must be an object with string name and version.");
	if (typeof e.name != "string" || typeof e.version != "string") throw TypeError("generator must have string name and version.");
	if (!O(e.name) || !O(e.version)) throw TypeError("generator name and version must be well-formed Unicode strings.");
	return Object.freeze({
		name: e.name,
		version: e.version
	});
}
function N(e) {
	return typeof e == "string" ? `"${e.length > 48 ? `${e.slice(0, 48)}…` : e}"` : e === null ? "null" : Array.isArray(e) ? "an array" : typeof e;
}
function P(e, t) {
	return e.length > t ? e.length : w.encode(e).byteLength;
}
function te(e, t) {
	let n;
	try {
		let t = JSON.stringify(e);
		if (typeof t != "string") return null;
		n = t;
	} catch {
		return null;
	}
	return P(n, t);
}
function ne(e) {
	if (e === void 0) return b;
	if (typeof e != "object" || !e) throw TypeError("parseLocalState options must be an object.");
	let { maxLength: t } = e;
	if (t === void 0) return b;
	if (typeof t != "number" || !Number.isSafeInteger(t) || t <= 0) throw RangeError("maxLength must be a finite positive integer.");
	return t;
}
function F(e, t, n) {
	if (!e || e.syntax !== "local" || typeof e.source != "string") throw TypeError("createLocalStateFile requires a compiled local document.");
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("createLocalStateFile requires a state object.");
	let r = Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort(), i = new Set(r), a = /* @__PURE__ */ new Map();
	for (let n of Object.keys(t)) {
		if (Object.hasOwn(e.computations ?? {}, n)) continue;
		if (n.startsWith("@")) {
			if (!Object.hasOwn(e.bindings, n)) throw Error(`Cannot persist parameter "${n}": it is not a binding of this document.`);
			continue;
		}
		if (!i.has(n)) throw Error(`Cannot persist parameter "${n}": it is not a public binding of this document.`);
		let r = k(t[n]);
		if (!r.ok) throw TypeError(`Cannot persist parameter "${n}": the value ${r.message}`);
		a.set(n, r.value);
	}
	let o = {};
	for (let e of r) {
		if (!a.has(e)) throw Error(`Cannot persist the document: parameter "${e}" is missing from the supplied state.`);
		o[e] = a.get(e);
	}
	let c = {
		format: y,
		syntax: s,
		sourceDigest: _(e.source),
		parameters: o
	};
	return n !== void 0 && (c.generator = M(n)), j(c);
}
function re(e, t) {
	let n = [], r = (e, t) => E(n, e, t), i = e;
	if (typeof e == "string") {
		if (P(e, t) > t) return {
			ok: !1,
			diagnostics: [T("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
		if (!O(e)) return {
			ok: !1,
			diagnostics: [T("local.state.utf", "The state payload contains malformed Unicode.")]
		};
		try {
			i = JSON.parse(e);
		} catch (e) {
			return {
				ok: !1,
				diagnostics: [T("local.state.json", `The state payload is not valid JSON: ${D(e)}`)]
			};
		}
	} else {
		let n = te(e, t);
		if (n === null) return {
			ok: !1,
			diagnostics: [T("local.state.shape", "The state payload must be a JSON object.")]
		};
		if (n > t) return {
			ok: !1,
			diagnostics: [T("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
	}
	if (!A(i)) return {
		ok: !1,
		diagnostics: [T("local.state.shape", "The state payload must be a JSON object.")]
	};
	Object.getOwnPropertySymbols(i).length > 0 && r("local.state.shape", "The state payload cannot use symbol keys.");
	for (let e of Object.keys(i)) S.has(e) || r("local.state.key", `Unknown top-level state key "${e}".`);
	let a = i.format;
	a !== "reactive-md-state/v1" && r("local.state.format", `Unsupported state format ${N(a)}; expected "${y}".`);
	let o = i.syntax;
	o !== "local-draft-3" && r("local.state.syntax", `Unsupported state syntax ${N(o)}; expected "${s}".`);
	let c = i.sourceDigest;
	typeof c == "string" && x.test(c) || r("local.state.digest", "sourceDigest must match \"fnv1a32:\" followed by 8 lowercase hexadecimal digits.");
	let l = {}, u = i.parameters;
	if (!A(u)) r("local.state.parameters", "parameters must be a JSON object of public binding values.");
	else for (let e of Object.keys(u).sort()) {
		if (e === "__proto__") {
			r("local.state.parameter.prototype", "Parameter names cannot be \"__proto__\".");
			continue;
		}
		if (e.startsWith("@")) {
			r("local.state.parameter.internal", `Internal parameter "${e}" cannot be persisted.`);
			continue;
		}
		let t = k(u[e]);
		t.ok ? l[e] = t.value : r("local.state.parameter.value", `Parameter "${e}" ${t.message}`);
	}
	let d;
	if (Object.hasOwn(i, "generator")) {
		let e = i.generator;
		if (!A(e)) r("local.state.generator", "generator must be an object with string name and version.");
		else {
			for (let t of Object.keys(e)) C.has(t) || r("local.state.generator", `generator has unknown key "${t}".`);
			typeof e.name != "string" || typeof e.version != "string" ? r("local.state.generator", "generator must have string name and version.") : !O(e.name) || !O(e.version) ? r("local.state.utf", "generator contains malformed Unicode.") : d = Object.freeze({
				name: e.name,
				version: e.version
			});
		}
	}
	if (n.length) return {
		ok: !1,
		diagnostics: n
	};
	let f = {
		format: y,
		syntax: s,
		sourceDigest: c,
		parameters: l
	};
	return d && (f.generator = d), {
		ok: !0,
		file: j(f)
	};
}
function I(e, t) {
	let n = ne(t);
	try {
		return re(e, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.invalid", `Cannot read the local state: ${D(e)}`)]
		};
	}
}
function ie(e) {
	let t = /* @__PURE__ */ new Map(), n = (e) => {
		for (let r of e) t.set(r.id, r), r.children && n(r.children);
	};
	return n(e.nodes), t;
}
function L(e) {
	let t = ie(e), n = /* @__PURE__ */ new Map(), r = [];
	for (let [i, a] of Object.entries(e.bindingSlots ?? {})) {
		let e = t.get(i);
		if (!e) continue;
		let o = {
			node: e,
			slots: []
		};
		for (let [t, r] of Object.entries(a)) o.slots.push({
			slot: t,
			key: r
		}), r.startsWith("@") || n.set(r, {
			node: e,
			slot: t
		});
		o.slots.length && r.push(o);
	}
	let i = [];
	for (let [r, a] of Object.entries(e.bindings)) {
		if (r.startsWith("@")) continue;
		let e = n.get(r);
		if (e) {
			i.push({
				key: r,
				binding: a,
				node: e.node,
				slot: e.slot
			});
			continue;
		}
		let o = a.owner && t.has(a.owner) ? a.owner : a.nodeIds.find((e) => t.has(e));
		i.push({
			key: r,
			binding: a,
			node: o ? t.get(o) : void 0
		});
	}
	return {
		plans: i,
		groups: r
	};
}
function R(e, t, n) {
	let r = [];
	for (let i of t.plans) i.slot === void 0 && Object.hasOwn(n, i.key) && (i.node ? Object.is(e.get(i.node), n[i.key]) || r.push(...e.set(i.node, n[i.key])) : r.push(T("local.state.document", `The document has no component for parameter "${i.key}".`)));
	for (let i of t.groups) {
		let t = {}, a = !1;
		for (let { slot: e, key: r } of i.slots) Object.hasOwn(n, r) && (t[e] = n[r], a = !0);
		a && r.push(...e.setMany(i.node, t));
	}
	return r;
}
function ae(e, t) {
	let n = e.snapshot(), r = {};
	for (let e of t) {
		let t = n.state[e];
		r[e] = Array.isArray(t) ? Object.freeze([...t]) : t;
	}
	return Object.freeze(r);
}
function z(e, t, n, r) {
	let i = I(t, r);
	if (!i.ok) return i;
	if (!e || e.syntax !== "local" || typeof e.source != "string" || !Array.isArray(e.nodes) || !e.bindings) return {
		ok: !1,
		diagnostics: [T("local.state.document", "resolveLocalState requires a compiled local document.")]
	};
	if (i.file.syntax !== "local-draft-3") return {
		ok: !1,
		diagnostics: [T("local.state.syntax", `This state file uses syntax "${i.file.syntax}", but this build accepts "${s}".`)]
	};
	if (i.file.sourceDigest !== _(e.source)) return {
		ok: !1,
		diagnostics: [T("local.state.source", "This state file was created for a different document (source digest mismatch).")]
	};
	let a = L(e), o = new Set(a.plans.map((e) => e.key)), c = [];
	for (let e of Object.keys(i.file.parameters)) o.has(e) || E(c, "local.state.parameter.unknown", `The state contains unknown parameter "${e}" for this document.`);
	for (let e of o) Object.hasOwn(i.file.parameters, e) || E(c, "local.state.parameter.missing", `The state is missing parameter "${e}".`);
	if (c.length) return {
		ok: !1,
		diagnostics: c
	};
	let l;
	try {
		l = g(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.document", `Cannot validate this document: ${D(e)}`)]
		};
	}
	try {
		if (n) {
			let e = R(l, a, n);
			if (e.length) return {
				ok: !1,
				diagnostics: e
			};
		}
		let e = R(l, a, i.file.parameters);
		if (e.length) return {
			ok: !1,
			diagnostics: e
		};
		let t = [...o].sort();
		return {
			ok: !0,
			file: i.file,
			state: ae(l, t)
		};
	} finally {
		l.dispose();
	}
}
function B(e, t, n) {
	try {
		return z(e, t, void 0, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.invalid", `Cannot resolve the local state: ${D(e)}`)]
		};
	}
}
function V(e, t, n) {
	let r;
	try {
		r = z(e.document, t, e.snapshot().state, n);
	} catch (e) {
		return [T("local.state.invalid", `Cannot apply the local state: ${D(e)}`)];
	}
	if (!r.ok) return r.diagnostics;
	let i = L(e.document);
	try {
		return R(e, i, r.state);
	} catch (e) {
		return [T("local.state.invalid", `Cannot apply the local state: ${D(e)}`)];
	}
}
function oe(e, t) {
	return F(e.document, e.getParameters(), t);
}
function se(e, t, n) {
	let r = I(t, n);
	return r.ok ? V(e, r.file, n) : r.diagnostics;
}
function ce(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("serializeLocalState requires a state file.");
	if (!e.parameters || typeof e.parameters != "object" || Array.isArray(e.parameters)) throw TypeError("serializeLocalState requires an object of parameters.");
	let t = Object.create(null);
	for (let n of Object.keys(e.parameters).sort()) {
		if (n === "__proto__" || n.startsWith("@")) throw TypeError(`Cannot serialize parameter "${n}".`);
		let r = k(e.parameters[n]);
		if (!r.ok) throw TypeError(`Cannot serialize parameter "${n}": the value ${r.message}`);
		t[n] = r.value;
	}
	let n = {
		format: e.format,
		syntax: e.syntax,
		sourceDigest: e.sourceDigest,
		parameters: t
	};
	if (e.generator !== void 0) {
		let t = M(e.generator);
		n.generator = {
			name: t.name,
			version: t.version
		};
	}
	return JSON.stringify(n);
}
// src/local/configuration/portable-options.ts
function H(e) {
	if (e === void 0) return;
	let t = h(e);
	if (!t.ok) throw TypeError(`Invalid portable compile options: ${t.message}`);
	return {
		enableCss: t.html.enableCss,
		enableJavaScript: t.html.enableJavaScript,
		enableExtendedHtml: t.html.enableExtendedHtml,
		...Object.hasOwn(e, "strict") && e.strict !== void 0 ? { strict: t.strict } : {},
		...e.markdownBreaks === void 0 ? {} : { markdownBreaks: t.markdownBreaks },
		...e.config === void 0 ? t.hostComponents.length ? { hostComponents: t.hostComponents } : {} : { config: m(e.config) },
		...e.limits === void 0 ? {} : { limits: {
			...e.limits.maxSyntaxNodes === void 0 ? {} : { maxSyntaxNodes: t.maxSyntaxNodes },
			...e.limits.maxParseWork === void 0 ? {} : { maxParseWork: t.maxParseWork },
			...e.limits.maxMarkdownDepth === void 0 ? {} : { maxMarkdownDepth: t.maxMarkdownDepth }
		} }
	};
}
// src/export/restoration.ts
var le = n;
function U(e) {
	return n(JSON.stringify([
		e.id,
		e.name,
		e.version,
		e.protocol,
		e.colorSchemes,
		e.css.map(({ id: e, css: t }) => [e, t])
	]));
}
function ue(e, t) {
	let r = m(t);
	return Object.freeze({
		protocol: "reactive-md-bundle/v1",
		sdkVersion: i,
		configKey: r.key,
		scriptDigest: n(e),
		themes: Object.freeze(r.themes.map((e) => Object.freeze({
			id: e.id,
			name: e.name,
			version: e.version,
			digest: U(e)
		})))
	});
}
function W(e, t, r, a = []) {
	let s = m(t), c = /* @__PURE__ */ new Set(), l = [...e.nodes];
	for (; l.length;) {
		let e = l.pop();
		(e.type === "component" || e.type === "hostComponent") && e.name && c.add(e.name), e.children && l.push(...e.children);
	}
	let u = s.registry.filter((e) => c.has(e.name)).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		range: e.version,
		digest: o(e)
	})).sort((e, t) => e.id.localeCompare(t.id)), d = s.themes.filter((t) => t.name === e.theme).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: U(e)
	}));
	return Object.freeze({
		protocol: "reactive-md-restore/v1",
		sdk: `^${i}`,
		configKey: s.key,
		sourceDigest: n(e.source),
		target: r,
		components: Object.freeze(u),
		themes: Object.freeze(d),
		resources: Object.freeze(a.map((e) => Object.freeze({
			id: e.id,
			digest: n(e.css)
		})))
	});
}
function G(e) {
	return typeof e == "object" && !!e && !Array.isArray(e) && [Object.prototype, null].includes(Object.getPrototypeOf(e));
}
function K(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 256;
}
function de(a, s) {
	if (a === void 0) return [];
	let c = [], l = (e, t) => c.push({
		code: `local.extension.restore-${e}`,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	});
	try {
		if (!G(a) || e(a) > 262144 || a.protocol !== "reactive-md-restore/v1" || !K(a.sdk) || !K(a.configKey) || !K(a.sourceDigest) || ![
			"static",
			"ssr",
			"offline"
		].includes(a.target) || !Array.isArray(a.components) || a.components.length > 192 || !Array.isArray(a.themes) || a.themes.length > 16 || !Array.isArray(a.resources) || a.resources.length > 128) return l("metadata", "Invalid or oversized restoration requirements."), c;
		let u = /* @__PURE__ */ new Set([
			"protocol",
			"sdk",
			"configKey",
			"sourceDigest",
			"target",
			"components",
			"themes",
			"resources"
		]);
		Object.keys(a).some((e) => !u.has(e)) && l("metadata", "Unknown restoration requirement field.");
		let d = s.config === void 0 ? p() : m(s.config);
		t(a.sdk) && r("0.7.0", a.sdk) || l("sdk", `SDK ${i} does not satisfy ${a.sdk}.`), d.key !== a.configKey && l("config", "The installed configuration differs from the exported configuration."), n(s.source) !== a.sourceDigest && l("source", "The source differs from the exported source. Recompile before restoring state.");
		let f = /* @__PURE__ */ new Set();
		for (let e of a.components) {
			if (!G(e) || ![
				"id",
				"name",
				"version",
				"range",
				"digest"
			].every((t) => K(e[t])) || !t(e.range) || f.has(e.id)) {
				l("metadata", "Invalid or duplicate component restoration requirement.");
				continue;
			}
			f.add(e.id);
			let n = d.registry.find((t) => t.id === e.id);
			if (!n) {
				l("component-missing", `Required component ${e.id}@${e.version} is not installed.`);
				continue;
			}
			r(n.version, e.range) || l("version", `Component ${e.id}@${n.version} does not satisfy ${e.range}.`), (n.version !== e.version || n.name !== e.name || o(n) !== e.digest) && l("contract", `Component ${e.id}@${e.version} differs from the installed contract. Recompile and validate state before upgrading.`);
			let i = a.target === "offline" ? [
				"interactive",
				"static",
				"offline"
			] : [a.target];
			for (let t of i) n.capabilities[t] || l("capability", `Component ${e.id} cannot render ${t}.`);
		}
		if (s.document) {
			let e = W(s.document, d, a.target);
			for (let t of e.components) f.has(t.id) || l("component-missing", `Used component ${t.id} is missing from restoration requirements.`);
		}
		f.clear();
		for (let e of a.themes) {
			if (!G(e) || ![
				"id",
				"name",
				"version",
				"digest"
			].every((t) => K(e[t])) || f.has(e.id)) {
				l("metadata", "Invalid or duplicate theme restoration requirement.");
				continue;
			}
			f.add(e.id);
			let t = d.themes.find((t) => t.id === e.id);
			t && t.name === e.name && t.version === e.version && U(t) === e.digest || l("theme", `Required theme ${e.id}@${e.version} does not match the installed theme.`);
		}
		if (s.document) {
			let e = d.themes.find((e) => e.name === s.document.theme);
			e && !f.has(e.id) && l("theme", `Selected theme ${e.id} is missing from restoration requirements.`);
		}
		let h = v(s.resources ?? []);
		c.push(...h.diagnostics);
		let g = new Map(h.resources.map((e) => [e.id, e.css]));
		f.clear();
		for (let e of a.resources) {
			if (!G(e) || !K(e.id) || !K(e.digest) || f.has(e.id)) {
				l("metadata", "Invalid or duplicate style restoration requirement.");
				continue;
			}
			f.add(e.id);
			let t = g.get(e.id);
			t === void 0 ? l("resource-missing", `Required style resource ${e.id} is missing before state restoration.`) : n(t) !== e.digest && l("resource-digest", `Style resource ${e.id} differs from the exported content.`);
		}
		if (s.document) {
			let e = W(s.document, d, a.target), t = new Set(e.components.map((e) => e.id)), n = d.registry.filter((e) => t.has(e.id)).flatMap((e) => e.styles ?? []);
			n.push(...d.themes.filter((e) => e.name === s.document.theme).flatMap((e) => e.css.map((e) => e.id)));
			for (let e of n) f.has(e) && g.has(e) || l("resource-missing", `Used style resource ${e} is required before state restoration.`);
		}
	} catch (e) {
		l("metadata", e instanceof Error ? e.message : String(e));
	}
	return c;
}
// src/shareable.ts
var q = "reactive-md-html/v1", J = "reactive-md-html/v2", fe = /^[A-Za-z][A-Za-z0-9_-]*$/, pe = /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/, me = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, he = /[\u0000-\u001f\u007f-\u009f]/, Y = 64, ge = 41943040, _e = 4096;
function X(e, t = !1) {
	let n = e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return t && (n = n.replace(/"/g, "&quot;").replace(/'/g, "&#39;")), n;
}
function ve(e) {
	return e.replace(/<\/style/gi, "<\\/style");
}
function ye(e) {
	return e.replace(/<\/script/gi, "<\\/script").replace(/<!--/g, "<\\!--");
}
function Z(e) {
	return X(e, !0);
}
function Q(e) {
	let t = JSON.stringify(e);
	if (typeof t != "string") throw TypeError("Cannot serialize a non-JSON value for an inline script.");
	return t.replace(/[<>&\u2028\u2029]/g, (e) => {
		switch (e) {
			case "<": return "\\u003c";
			case ">": return "\\u003e";
			case "&": return "\\u0026";
			case "\u2028": return "\\u2028";
			default: return "\\u2029";
		}
	});
}
function $(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function be(e) {
	try {
		return H(e);
	} catch (e) {
		throw TypeError(`createShareableHtml received invalid compileOptions: ${e instanceof Error ? e.message : String(e)}`);
	}
}
function xe(e) {
	let t = [];
	for (let n of e.childNodes) {
		if (u.isElementNode(n)) {
			let e = n.tagName.toLowerCase();
			if (e === "script") continue;
			xe(e === "template" ? u.getTemplateContent(n) : n);
		}
		t.push(n);
	}
	e.childNodes = t;
}
function Se(e, t, n) {
	let r = !1;
	for (let i of e.childNodes) if (u.isElementNode(i)) {
		if (i.tagName.toLowerCase() === "iframe") {
			let e = i.attrs.filter((e) => {
				let t = e.name.toLowerCase();
				return t !== "srcdoc" && t !== "sandbox";
			});
			e.push({
				name: "srcdoc",
				value: t
			}), e.push({
				name: "sandbox",
				value: n
			}), i.attrs = e, r = !0;
		}
		Se(i, t, n) && (r = !0);
	}
	return r;
}
function Ce(e) {
	let t = "";
	for (let n of e.childNodes) t += l(n, { scriptingEnabled: !1 });
	return t;
}
function we(e, t, n) {
	try {
		let r = f(e, { scriptingEnabled: !1 });
		if (xe(r), Se(r, t, n)) return Ce(r);
	} catch {}
	return `<div class="reactive-md-native-document"><iframe class="reactive-md-native-frame" title="Reactive MD document" sandbox="${X(n, !0)}" style="display:block;width:100%;min-height:60vh;border:0;background:#fff" srcdoc="${X(t, !0)}"></iframe></div>`;
}
function Te(e, t) {
	let n = t?.enableExtendedHtml === !0, r = t ? `frame-src about:${n ? " data: blob: http: https:" : ""}` : "frame-src 'none'", i = n ? "base-uri 'self' http: https:" : "base-uri 'none'", a = n ? "form-action http: https:" : "form-action 'none'";
	return e ? `default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; font-src data:; connect-src 'none'; media-src 'none'; object-src 'none'; ${r}; ${i}; ${a}` : `default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:; object-src 'none'; ${r}; ${i}; ${a}`;
}
function Ee(e) {
	if (e === void 0) return;
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("images must be an object mapping relative URLs to data: image URLs.");
	let t = Object.entries(e);
	if (t.length > Y) throw RangeError(`images cannot contain more than ${Y} entries.`);
	let n = 0;
	for (let [e, r] of t) {
		if (!e || e.length > _e || he.test(e) || e === "__proto__") throw TypeError("Every image key must be a bounded, control-free URL.");
		if (typeof r != "string" || !me.test(r)) throw TypeError(`The image map for "${e}" must contain a base64 PNG, JPEG, GIF or WebP data URL.`);
		if (n += r.length, n > ge) throw RangeError("The embedded image map exceeds the 40 MiB budget.");
	}
	return Object.fromEntries(t);
}
function De(e, t) {
	let n = B(e, t);
	if (!n.ok) return n;
	let r = {};
	for (let [t, i] of Object.entries(e.bindings)) r[t] = Object.hasOwn(n.state, t) ? {
		...i,
		initial: $(n.state[t])
	} : i;
	let i = { ...e.initialState };
	for (let [e, t] of Object.entries(n.state)) i[e] = $(t);
	return {
		ok: !0,
		baseline: {
			document: {
				...e,
				bindings: r,
				initialState: i
			},
			state: n.state
		}
	};
}
var Oe = "\n:root { color-scheme: light; background: #f5f7fb; }\nhtml, body { margin: 0; }\nbody.reactive-md-export {\n  min-height: 100vh;\n  padding: clamp(16px, 4vw, 48px);\n  background: #f5f7fb;\n  color: #17233d;\n  font-family: system-ui, -apple-system, \"Segoe UI\", sans-serif;\n}\n.reactive-md-export-root { max-width: 840px; margin: 0 auto; }\n@media print {\n  :root, html, body.reactive-md-export { background: #fff !important; }\n  body.reactive-md-export { min-height: 0; padding: 0 !important; }\n  .reactive-md-export-root { max-width: none !important; margin: 0 !important; }\n}\n";
function ke(e) {
	let t = e.targetId ?? "reactive-md-document";
	if (!fe.test(t)) throw TypeError("targetId must start with a letter and contain only letters, digits, underscores or hyphens.");
	let n = e.mode === "static" ? "static" : "interactive";
	if (!e.staticMarkup.trim()) throw TypeError("createShareableHtml requires rendered document markup.");
	if (!e.css.trim()) throw TypeError("createShareableHtml requires the document stylesheet.");
	if (e.state.sourceDigest !== _(e.source)) throw Error("The state file does not belong to the exported source.");
	if (n === "interactive" && !e.runtimeScript?.trim()) throw TypeError("Interactive HTML requires the standalone runtime script.");
	let r = be(e.compileOptions), i = ee(e.extensions, r?.config);
	if (i.push(...de(e.restoration, {
		config: r?.config,
		source: e.source,
		resources: e.resources
	})), i.length) throw TypeError(i.map((e) => e.message).join(" "));
	let a = h(r);
	if (!a.ok) throw TypeError(`createShareableHtml received invalid compileOptions: ${a.message}`);
	let o = a.htmlActive, s = e.staticMarkup;
	if (o && (n === "static" || !a.html.enableJavaScript)) {
		let t = {
			enableCss: a.html.enableCss,
			enableJavaScript: !1,
			enableExtendedHtml: a.html.enableExtendedHtml
		}, n = d(e.source, t, a.maxSyntaxNodes);
		if (!n.markup) throw Error("The native HTML document could not be regenerated without author JavaScript.");
		s = we(e.staticMarkup, n.markup, c(t));
	}
	let l = e.locale === "zh" ? "zh" : "en", u = l === "zh" ? "zh-CN" : "en", f = e.colorScheme === "light" || e.colorScheme === "dark" ? e.colorScheme : "auto", p = e.assets === "omit" ? "omit" : "inline", m = e.generator ?? {
		name: "reactive-md",
		version: "unknown"
	}, g = Ee(e.images), v = Number.isSafeInteger(e.imageCount) && (e.imageCount ?? 0) > 0 ? String(e.imageCount) : String(Object.keys(g ?? {}).length), y = n === "interactive", b = {
		version: e.restoration ? 2 : 1,
		target: t,
		source: e.source,
		state: e.state,
		locale: l,
		colorScheme: f,
		hydrate: !0,
		...r === void 0 ? {} : { compileOptions: r },
		...e.extensions === void 0 ? {} : { extensions: e.extensions },
		...e.restoration === void 0 ? {} : {
			restoration: e.restoration,
			resources: e.resources ?? []
		},
		...g ? { images: g } : {}
	}, x = Te(y, o ? a.html : void 0), S = y ? `<script type="application/reactive-md+json" data-reactive-md-auto>${Q(b)}<\/script>
<script>${ye(e.runtimeScript)}<\/script>` : "", C = e.notices?.trim() ? `<template id="reactive-md-notices"><pre>${X(e.notices)}</pre></template>` : "", w = !y && e.extensions ? `<template id="reactive-md-extensions">${X(JSON.stringify(e.extensions))}</template>` : "";
	return `<!doctype html>
<html lang="${X(pe.test(u) ? u : "en", !0)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="${Z(x)}">
<meta name="generator" content="${Z(`${m.name} ${m.version}`)}">
<meta name="reactive-md-html-format" content="${e.restoration ? J : q}">
<meta name="reactive-md-syntax" content="${Z(e.state.syntax)}">
<meta name="reactive-md-output" content="${n}">
<meta name="reactive-md-state" content="${Z(e.state.sourceDigest)}">
<meta name="reactive-md-images" content="${p}">
<meta name="reactive-md-image-count" content="${v}">
<title>${X(e.title || "Reactive MD document")}</title>
<style>${ve(e.css)}${Oe}</style>
</head>
<body class="reactive-md-export">
<div id="${t}" class="reactive-md-export-root">${s}</div>
${S}
${w}
${C}
</body>
</html>
`;
}
export { I as _, Q as a, le as c, H as d, y as f, se as g, oe as h, De as i, U as l, F as m, J as n, ue as o, V as p, ke as r, W as s, q as t, de as u, B as v, ce as y };
