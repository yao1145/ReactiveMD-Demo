import { useCallback as e, useEffect as t, useRef as n, useState as r } from "react";
// src/react/runtime/common.ts
function i(e, t, n) {
	return {
		code: t,
		message: n,
		severity: "error",
		range: { ...e.content.range },
		line: 1,
		column: 1
	};
}
function a(e, t, n) {
	let r = n instanceof Error ? n.message : String(n);
	try {
		e.report([i(e, t, r)]);
	} catch {}
}
// src/react/runtime/useTicker.ts
function o(e, r, i, o) {
	let s = n(i);
	s.current = i;
	let c = n(e);
	c.current = e;
	let l = e.services.scheduler, u = o?.background ?? "pause", d = e.mode !== "static" && e.visible && !e.disabled && (o?.enabled ?? !0), f = o?.restartOnReset === !0 ? e.resetToken : 0;
	t(() => {
		if (!d) return;
		let e = null;
		try {
			e = l.every(r, () => {
				try {
					s.current();
				} catch (e) {
					a(c.current, "local.runtime.scheduler", e);
				}
			}, { background: u });
		} catch (e) {
			a(c.current, "local.runtime.scheduler", e);
		}
		return () => {
			e?.();
		};
	}, [
		l,
		r,
		u,
		d,
		f
	]);
}
function s(e, r, i) {
	let o = n(r);
	o.current = r;
	let s = n(e);
	s.current = e;
	let c = e.services.scheduler, l = e.mode !== "static" && e.visible && !e.disabled && (i?.enabled ?? !0), u = i?.restartOnReset === !0 ? e.resetToken : 0;
	t(() => {
		if (!l) return;
		let e = null;
		try {
			e = c.frame((e) => {
				try {
					o.current(e);
				} catch (e) {
					a(s.current, "local.runtime.scheduler", e);
				}
			});
		} catch (e) {
			a(s.current, "local.runtime.scheduler", e);
		}
		return () => {
			e?.();
		};
	}, [
		c,
		l,
		u
	]);
}
// src/react/runtime/useSwipe.ts
function c(e, t, n = "both", r = 24) {
	let i = Math.abs(e), a = Math.abs(t);
	return Math.max(i, a) < r ? null : n === "horizontal" ? i >= a ? e < 0 ? "left" : "right" : null : n === "vertical" ? a >= i ? t < 0 ? "up" : "down" : null : i >= a ? e < 0 ? "left" : "right" : t < 0 ? "up" : "down";
}
function l(e, r, i) {
	let a = n(r);
	a.current = r;
	let o = Math.max(1, i?.threshold ?? 24), s = i?.axis ?? "both", l = i?.preventScroll ?? !1, u = i?.disabled ?? !1, d = i?.pointerTypes, f = d === void 0 ? "" : d.join(",");
	t(() => {
		let t = e.current;
		if (t === null || u) return;
		let n = f === "" ? void 0 : f.split(","), r = t.style.touchAction;
		l && (t.style.touchAction = "none");
		let i = null, d = 0, p = 0, m = !1, h = (e) => e.isPrimary ? n === void 0 || n.includes(e.pointerType) : !1, g = (e) => {
			if (h(e)) {
				i = e.pointerId, d = e.clientX, p = e.clientY, m = !1;
				try {
					t.setPointerCapture(e.pointerId);
				} catch {}
			}
		}, _ = (e) => {
			if (i !== e.pointerId || m) return;
			let t = e.clientX - d, n = e.clientY - p, r = Math.abs(t), u = Math.abs(n);
			if (Math.max(r, u) < o) return;
			if (s === "horizontal" && u > r || s === "vertical" && r > u) {
				m = !0;
				return;
			}
			let f = c(t, n, s, o);
			f !== null && (m = !0, l && e.preventDefault(), a.current.onSwipe(f, e));
		}, v = (e) => {
			if (i === e.pointerId) {
				i = null, m = !1;
				try {
					t.hasPointerCapture(e.pointerId) && t.releasePointerCapture(e.pointerId);
				} catch {}
			}
		};
		return t.addEventListener("pointerdown", g), t.addEventListener("pointermove", _, { passive: !1 }), t.addEventListener("pointerup", v), t.addEventListener("pointercancel", v), () => {
			t.removeEventListener("pointerdown", g), t.removeEventListener("pointermove", _), t.removeEventListener("pointerup", v), t.removeEventListener("pointercancel", v), t.style.touchAction = r;
		};
	}, [
		e,
		o,
		s,
		l,
		u,
		f
	]);
}
// src/react/runtime/useKeys.ts
var u = "input,textarea,select,[contenteditable=\"\"],[contenteditable=\"true\"],[contenteditable=\"plaintext-only\"]";
function d(e) {
	return typeof Element > "u" || !(e instanceof Element) ? !1 : e.closest(u) !== null;
}
function f(e, r, i) {
	let a = n(r);
	a.current = r;
	let o = i?.disabled ?? !1, s = i?.ignoreEditable ?? !0, c = i?.preventDefault ?? "handled", l = i?.repeat ?? !1;
	t(() => {
		let t = e.current;
		if (t === null || o) return;
		let n = (e) => {
			if (!l && e.repeat || s && d(e.target)) return;
			let t = a.current[e.key], n = e.key.length === 1 ? a.current[e.key.toLowerCase()] : void 0, r = t ?? n;
			r !== void 0 && ((c === !0 || c === "handled") && e.preventDefault(), r(e));
		};
		return t.addEventListener("keydown", n), () => t.removeEventListener("keydown", n);
	}, [
		e,
		o,
		s,
		c,
		l
	]);
}
// src/react/runtime/useComponentState.ts
function p(i, a) {
	let o = i.services.state, s = a.version ?? 0, c = n(a.initial);
	c.current = a.initial;
	let l = n(a.validate);
	l.current = a.validate;
	let u = n(i.report);
	u.current = i.report;
	let d = n(!1), f = n(null), [p, m] = r(() => {
		let e = o.load();
		if (e !== null) {
			if (e.component !== o.component) f.current = `Saved state belongs to component "${e.component}", not "${o.component}".`;
			else if (e.stateVersion !== s) f.current = `Saved state version ${e.stateVersion} is not supported (expected ${s}).`;
			else if (l.current !== void 0 && !l.current(e.data)) f.current = "Saved state does not match the current component shape.";
			else return d.current = !0, e.data;
		}
		return c.current();
	}), [h, g] = r(f.current), _ = n(i.resetToken);
	t(() => {
		if (_.current === i.resetToken) return;
		_.current = i.resetToken;
		let e = c.current();
		if (m(e), g(null), d.current = !1, a.autoSave === !0) {
			let t = o.save(e, { version: s });
			if (!t.ok) {
				let e = t.diagnostics.map((e) => e.message).join("; ");
				g(e);
				try {
					u.current(t.diagnostics);
				} catch {}
			}
		}
	}, [
		i.resetToken,
		o,
		s,
		a.autoSave
	]), t(() => {
		let e = f.current;
		if (e !== null) {
			f.current = null;
			try {
				u.current([{
					code: "local.runtime.state.restore",
					message: e,
					severity: "error",
					range: { ...i.content.range },
					line: 1,
					column: 1
				}]);
			} catch {}
		}
	}, [i.content.range]);
	let v = e((e) => {
		let t = o.save(e === void 0 ? p : e, { version: s });
		if (t.ok) g(null);
		else {
			let e = t.diagnostics.map((e) => e.message).join("; ");
			g(e);
			try {
				u.current(t.diagnostics);
			} catch {}
		}
		return t;
	}, [
		o,
		p,
		s
	]), y = e(() => {
		o.clear(), g(null);
	}, [o]);
	return {
		value: p,
		setValue: e((e) => {
			if (m(e), a.autoSave === !0) {
				let t = o.save(e, { version: s });
				if (!t.ok) {
					g(t.diagnostics.map((e) => e.message).join("; "));
					try {
						u.current(t.diagnostics);
					} catch {}
				}
			}
		}, [
			o,
			a.autoSave,
			s
		]),
		save: v,
		clear: y,
		loaded: d.current,
		error: h
	};
}
export { c as classifySwipe, d as isEditableTarget, p as useComponentState, s as useFrame, f as useKeys, l as useSwipe, o as useTicker };
