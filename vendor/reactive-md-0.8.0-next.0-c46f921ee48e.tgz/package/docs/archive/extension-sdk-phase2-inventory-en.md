# Phase 2 component migration inventory

**English** · [中文](extension-sdk-phase2-inventory-ch.md)

Status: 46 components migrated, 3 kernel declarations retained. Baseline: `d227fc09c503f8094883c33be87ad0a13d866213`, package version `0.6.1`.

The inventory contains all 49 declarations before migration. The 46 render or structure components are provided by the default preset, while `computed`, `const` and `external` remain kernel language declarations. Each component's attributes, bindings and rules follow the publicly validated manifest in `src/presets/default-components.ts`.

The "Original structure" column records pre-migration semantic requirements for compatibility checking; implementation files are under `src/components/`. Structural children also have ordinary registrations and are consumed by containers through public content projection.

| Declaration | Original binding family / slot | Original structure | Implementation | Current acceptance status |
| --- | --- | --- | --- | --- |
| `input` | text | none | `controls.tsx / InputView` | Baseline and regressions pass |
| `textarea` | text | none | `controls.tsx / TextareaView` | Baseline and regressions pass |
| `number` | number | none | `controls.tsx / NumberView` | Baseline and regressions pass |
| `slider` | number | none | `controls.tsx / SliderView` | Baseline and regressions pass |
| `range-slider` | start:number, end:number | none | `controls.tsx / RangeSliderView` | Baseline and regressions pass |
| `coordinate` | x:number, y:number | none | `controls.tsx / CoordinateView` | Baseline and regressions pass |
| `toggle` | boolean | none | `controls.tsx / ToggleView` | Baseline and regressions pass |
| `checkbox` | boolean | none | `controls.tsx / CheckboxView` | Baseline and regressions pass |
| `date` | date | none | `controls.tsx / DateView` | Baseline and regressions pass |
| `select` | choice | options | `controls.tsx / SelectView` | Baseline and regressions pass |
| `choices` | choice | options | `controls.tsx / ChoicesView` | Baseline and regressions pass |
| `radio-group` | choice | options | `controls.tsx / RadioGroupView` | Baseline and regressions pass |
| `multi-select` | multi-select | options | `controls.tsx / MultiSelectView` | Baseline and regressions pass |
| `option` | none | inline | `layout.tsx / OptionView` | Baseline and regressions pass |
| `counter` | number | none | `controls.tsx / CounterView` | Baseline and regressions pass |
| `timer` | timer | none | `controls.tsx / TimerView` | Baseline and regressions pass |
| `checklist` | checklist | content | `controls.tsx / ChecklistView` | Baseline and regressions pass |
| `progress` | none | none | `controls.tsx / ProgressView` | Baseline and regressions pass |
| `jump` | none | inline | `layout.tsx / JumpView` | Baseline and regressions pass |
| `anchor` | none | none | `layout.tsx / AnchorView` | Baseline and regressions pass |
| `text` | none | inline | `layout.tsx / TextView` | Baseline and regressions pass |
| `section` | none | any | `layout.tsx / SectionView` | Baseline and regressions pass |
| `quiz` | none | quiz | `controls.tsx / QuizView` | Baseline and regressions pass |
| `panel` | none | any | `layout.tsx / PanelView` | Baseline and regressions pass |
| `card` | none | any | `layout.tsx / CardView` | Baseline and regressions pass |
| `grid` | none | cards | `layout.tsx / GridView` | Baseline and regressions pass |
| `tabs` | tabs | tabs | `layout.tsx / TabsView` | Baseline and regressions pass |
| `tab` | none | any | `layout.tsx / TabView` | Baseline and regressions pass |
| `steps` | steps | steps | `layout.tsx / StepsView` | Baseline and regressions pass |
| `step` | none | any | `layout.tsx / StepView` | Baseline and regressions pass |
| `accordion` | none | disclosures | `layout.tsx / AccordionView` | Baseline and regressions pass |
| `disclosure` | none | any | `layout.tsx / DisclosureView` | Baseline and regressions pass |
| `if` | none | any | `layout.tsx / IfView` | Baseline and regressions pass |
| `alert` | none | any | `layout.tsx / AlertView` | Baseline and regressions pass |
| `badge` | none | inline | `layout.tsx / BadgeView` | Baseline and regressions pass |
| `tooltip` | none | inline | `layout.tsx / TooltipView` | Baseline and regressions pass |
| `computed` | none | none | Kernel declaration | Baseline and regressions pass |
| `const` | none | none | Kernel declaration | Baseline and regressions pass |
| `external` | none | none | Kernel declaration | Baseline and regressions pass |
| `validation` | none | none | `layout.tsx / ValidationView` | Baseline and regressions pass |
| `data-table` | none | columns | `data-table.tsx / DataTableView` | Baseline and regressions pass |
| `column` | none | none | `visuals.tsx / ColumnView` | Baseline and regressions pass |
| `table` | selection | table | `visuals.tsx / TableView` | Baseline and regressions pass |
| `chart` | selection | table | `visuals.tsx / ChartView` | Baseline and regressions pass |
| `plot` | none | plot | `visuals.tsx / PlotView` | Baseline and regressions pass |
| `timeline` | none | table | `visuals.tsx / TimelineView` | Baseline and regressions pass |
| `diagram` | diagram | diagram | `visuals.tsx / DiagramView` | Baseline and regressions pass |
| `node` | none | content | `visuals.tsx / NodeView` | Baseline and regressions pass |
| `edge` | none | none | `layout.tsx / EdgeView` | Baseline and regressions pass |

## Acceptance basis

- `tests/sdk-phase2-baseline.test.tsx`: 85 groups of cases recorded with pre-migration artifacts, checking diagnostics, initial state, binding constraints, state writes and static output. The baseline is stored in `tests/fixtures/sdk-phase2-baseline.json`.
- `tests/sdk-phase2-boundary.test.ts`: checks that default definitions pass the public validator, the import boundaries of implementation modules, the semantics of all external aliases, plus Worker data cloning, compile-result patches and incremental editing.
- Existing compile, runtime, React and browser regressions for each component continue to constrain interaction behavior.
- `examples/integration/extension-sdk/advanced.tsx`: an independent consumption project covers coordinate, collection and Markdown containers. `scripts/verify-sdk-consumer.mjs` verifies types, SSR, static mode and desktop/phone offline recovery from a real installed package.

Full results are in the [consolidated acceptance record](extension-sdk-acceptance-en.md). The manifest for each row is provided by the same-named default definition, while structure and state are enforced by common kernel rules; component structure styles reuse the public `src/styles.css`, with no new built-in special distribution.
