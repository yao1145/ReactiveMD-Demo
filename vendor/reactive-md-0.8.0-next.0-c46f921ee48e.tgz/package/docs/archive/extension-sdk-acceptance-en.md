# Extension SDK delivery and consolidated acceptance record

**English** · [中文](extension-sdk-acceptance-ch.md)

Consolidated: 2026-10-30. Phases 1–3 are all implemented, and the full acceptance items passed in segments. This document merges the three original phase acceptance records; the [architecture plan](extension-sdk-plan-en.md) retains the design and implementation order, and the [component migration inventory](extension-sdk-phase2-inventory-en.md) retains item-by-item results.

Delivery is a source SDK preview on package version `0.6.1`. The `0.6.1` in the existing registry does not contain these new entries; development and verification use a tarball built from the current source. npm publication and Demo deployment are scheduled separately.

Plugin development starts with the [component plugin development guide](../development/component-development-en.md); the full API is in the [SDK guide](../integration/extension-sdk-en.md). Test numbers here are historical snapshots from each phase's acceptance; the three suites overlap and do not add up to a total test count.

## 1. Architecture and final delivery

The stable kernel handles syntax parsing, expressions, dependency scheduling, state and shared constraints, resource budgets and source locations. Built-in and user components share manifests, compile rules and React distribution; themes combine as independent resources.

| Public entry | Responsibility |
| --- | --- |
| `reactive-md/sdk` | Component manifests, instance configuration, versions, attribute normalization, theme definition and composition |
| `reactive-md/presets/default` | Public contracts for 46 default render and structure components |
| `reactive-md/react`, `reactive-md/react/server` | React implementation assembly, public context, strict static and SSR rendering |
| `reactive-md/authoring` | Component catalog, descriptions, templates, insertion, structural context and template compliance checks |
| `reactive-md/export`, `reactive-md/standalone` | Export precheck, bundle seal, version requirements, resource recovery and mounting |
| `reactive-md/build` | Node build adapter, CSS/resource collection within allowed directories, notices, single-file bundle and manifest |
| `reactive-md/testing` | Manifest, attribute and real binding behavior tests without React/DOM dependencies |
| `reactive-md/testing/react`, `reactive-md/testing/browser` | Static, SSR, lifecycle, error isolation, hydration and offline evidence |

`config.components` retains user components, while `config.registry` contains the full set; default component definitions are in `src/presets/default-components.ts`, and actual views are in `src/components/`. `src/local/schema.ts` is a compatibility projection and retains the three kernel language declarations `computed`, `const` and `external`. The migration inventory totals 49 items, of which 46 are components.

## 2. Phase 1: public extension SDK

This phase established an out-of-repository consumption loop, validating the public interface with a rating control, a Markdown hint container and the paper theme.

| Task | Delivery and acceptance |
| --- | --- |
| P1.1 Contracts and compatibility mapping | `reactive-md-component/v1`, configuration and requirement inventory; public context; legacy host input compatibility |
| P1.2 Validation and immutable configuration | Name/id conflicts, protocol, dependency versions and cycles, defaults, budgets, deterministic digest; NodeNext consumption without React/DOM |
| P1.3 Compilation and Worker | `LocalCompileOptions.config`, actual component requirements, incremental cache keys; main-thread and real-Worker comparison, invalidation on configuration changes |
| P1.4 React context | Normalized props, binding handles, child content, source ranges, disabled/visible/reset, error boundaries and server entry |
| P1.5 Authoring and theme integration | Configuration-generated catalog, templates and closing completion; theme validation, ordered composition, scoping and preserved light/dark parameters |
| P1.6 Minimal export | Capability and resource precheck, host-specific bundle, static and offline interactive HTML |
| P1.7 Independent consumption | Real tarball installation; rating and built-in number controls write to each other; offline recovery at 1280px/390px, zero external requests and unmount cleanup |

Historical acceptance passed 129 core test files and 1,703 tests, plus 16 Demo test files and 254 tests. Independent SDK consumption passed 9 groups of checks, along with type, build, package-entry, CLI, SSR and bundled-documentation checks.

At this point multi-slot, collections, complete built-in migration, a unified editor menu and general build tools had not been delivered; they were completed in phases 2 and 3 respectively. Phase-one examples remain in the [independent SDK consumption project](../../examples/integration/extension-sdk/README.md).

## 3. Phase 2: built-in and user components share contracts

The migration baseline is `d227fc09c503f8094883c33be87ad0a13d866213`, and the completion commit is `2eadc8c`.

| Task | Delivery and acceptance |
| --- | --- |
| P2.1 `slider`, `card` | Definitions pass public validation; actual views use only public props, bindings and child-content interfaces |
| P2.2 Ranges and coordinates | Numeric named slots, exclusivity rules, ordering relationships, atomic `setMany`; invalid updates preserve all parameters and the revision |
| P2.3 Collections and structural containers | String/number collections, JSON initial values, length budgets and state recovery; tabs, steps and others use common structural rules |
| P2.4 Remaining components | Timers, graphics, tables, navigation and structural children move into the component catalog; adapters provide public content and services |
| P2.5 Unified registration source | The default preset is authoritative; compilation, Worker, authoring tools, runtime metadata and React distribution consume the same configuration |

The main slot supports scalars and collections; public array reads return immutable copies. Numeric named slots use exclusive bindings, and the main slot and named slots can update in the same transaction. Collection limits use literals or static numeric attributes; other unsupported combinations are rejected at registration.

Numeric literals and valid complete interpolations both provide numbers to the implementation; invalid explicit values preserve diagnostics. Components receive `visible`, `disabled`, `mode` and `resetToken`; static context rejects state writes. Content, tables, options, source and navigation are provided through public projections, so component implementations need no access to the internal AST.

Historical acceptance passed 136 core test files and 1,866 tests, plus 16 Demo test files and 254 tests. The 85 pre-migration cases kept diagnostics, state and static output consistent, and the external aliases of the 46 default components passed the same semantic corpus. External coordinates, string collections, numeric collections and Markdown containers also passed atomic rollback, copying, SSR, static and offline acceptance.

Identity conflicts, static write signals, dynamic attribute diagnostics, mixed slots, document contract coverage and anchor cache issues found by independent review were all fixed with added regressions. Related historical logs are in local `artifacts/sdk-phase2/`. This round did not establish performance thresholds before and after migration on the same device; performance work is verified under a separate plan.

## 4. Phase 3: complete consumption flow

The baseline is `2eadc8c5ea5afc14c685731f8b02e10079e01310`. The authoring-tools commit is `8d35f6b`, the build, recovery and compliance tools commit is `da8421d`, and the composition-input fix in consolidated acceptance is `9837cd1`.

| Task | Delivery and acceptance |
| --- | --- |
| P3.1 Editor and Demo | The same manifest catalog generates menus, search, help, insertion and structural context; external components' Chinese/English, undo/redo and registration removal pass real-editor checks |
| P3.2 Build adapter | Node can load host entry-declared implementation, root, allowlist, resources and notices; collect CSS, fonts and images, build one IIFE, and generate a digest manifest |
| P3.3 Versions and recovery | SDK/component/theme/resource requirements, bundle seal and digest checks; missing or mismatched items fail before state application and React mounting; legacy v1 payloads remain usable |
| P3.4 Compliance and templates | Public manifest, binding, React and browser test tools; the copyable component package has compiled JS, types, theme and CSS exports |
| P3.5 Documentation and release shape | Bilingual SDK, theme and migration documentation; a second consumption project for the real tarball and the component package itself; full gate items pass in segments |

In the default preset, 34 components have independent insertion-menu information, while structural children continue to receive completion and constraints from the schema. Externally provided insertion templates expand placeholders and validate under the same configuration; parent-scoped components validate in legal containers. Authoring-information changes update the menu while the compile semantic digest remains stable.

The build entry exports `config`, `reactConfig`, `root` and `allowlist`, and optionally `resources` and `notices`. JavaScript dependencies are imported by normal module rules; resource collection restricts file access by root and allowlist. Missing, remote or out-of-bounds resources, symlink escapes, circular references, budgets and resource identity conflicts produce diagnostics. Vite 8 is an optional peer and loads only during an actual build.

`buildLocalStandaloneBundle` returns flat `script`, `extensions`, `seal`, `configKey`, `resources`, `assets`, `css`, `notices` and `manifest`. The manifest uses `reactive-md-build/v1`, and the seal uses `reactive-md-bundle/v1`. SDK HTML uses a v2 payload and `reactive-md-restore/v1` requirements; ordinary export still defaults to v1. The state format remains `reactive-md-state/v1`.

Recovery validation covers SDK ranges, configuration and source, the identity/version/contract of actually used components, capabilities, the selected theme and resource digests. A compatible version range cannot replace contract validation; when an upgrade changes a contract, recompile and validate saved state. Component code is installed actively by the host; document declarations never trigger downloads or execution of third-party code.

## 5. Final acceptance evidence

The acceptance environment was Windows x64, Node 22.17.0, npm 10.9.2 and Playwright 1.64.1. First run `npm run verify:release`, fix the issues found, then rerun the remaining items and affected editor checks in a consolidated pass. All 27 gate items have pass records, including 19 browser items; original failure records and post-fix logs are both retained, and execution was segmented acceptance.

| Check | Recorded result |
| --- | --- |
| Build and types | Library, Node build entry, editor, standalone, production Demo and 140 ESM declaration files pass |
| Core and Demo | 146 core test files and 1,935 tests; 17 Demo files and 257 tests pass; after the composition-input fix, 4 related files and 28 tests were additionally verified |
| Authoring tools | 9 checks on the real public editor pass, including external registration, help, search, Chinese/English, insertion, undo/redo and registration removal |
| Compliance tools | 46 default manifests, external alias comparison, named-slot atomic rollback, collection budgets and copies, reset; Node and NodeNext consumption without React/DOM pass |
| Component package | Out-of-repository template `npm test` passes; the template is then packed and consumed by a second project for JS, React, theme, CSS and strict NodeNext types |
| Capability evidence | Rating control 74 items and hint container 62 items pass; one unconfigured optional server-error probe for the container is skipped; all four declared capabilities have execution evidence |
| Offline recovery | Interactive HTML at 1280px/390px, static HTML with JavaScript disabled, CSS/SVG and 5 notices, with zero network requests; four corruptions—resources, theme, version and missing component—fail before mounting |
| Browser | Editor, Markdown, math, native HTML, media, Demo, new components, export, computation, constraints, themes, render equivalence, composition scenarios, Firefox/WebKit, host forms and tooltips pass |
| Packaged consumption | Isolated offline install, core/React/editor types, SSR, CLI, standalone, CSS and bundled-documentation links pass |

Firefox checks found that analysis redraw during multi-line composition replacement could clear the document; refresh is now deferred until after composition commit, and pending tasks are cleaned up on unmount. Public editor, CM6, Firefox and WebKit regressions pass. HTML fixtures now create documents per individual case; guide-anchor checks now target the outer document, avoiding matches inside nested examples.

| Local record | Purpose |
| --- | --- |
| `artifacts/sdk-phase3/verification.json` | Segmented summary of the 27 gates plus source and installed-package information |
| `artifacts/release-verification.json` | Original full-gate attempt, preserving the failures at that time |
| `artifacts/sdk-phase3/remainder.json`, `postfix.json` | Remaining items and verification after the composition-input fix |
| `artifacts/sdk-consumer/verification.json` | Independent consumption directory, tarball digest, Worker, SSR, editor and offline results |
| `artifacts/release-package/package-verification.json` | SHA256, npm integrity and consumption results of the verified installed package |

These directories are local verification artifacts and are not guaranteed to exist alongside the documentation; this document keeps the result summary, and raw logs are for local audit.

## 6. Re-verification and version boundaries

After modifying the SDK, build first and then run checks that depend on artifacts:

```powershell
npm.cmd run build:demo
npm.cmd run test:package
npm.cmd run test:docs
npm.cmd run test:packed
$env:PLAYWRIGHT_CHANNEL = 'msedge'
npm.cmd run test:sdk-consumer
```

Cross-system changes or releases use `npm.cmd run verify:release`; configure the browser channel and cache per the [release process](../development/releasing-en.md). When only documentation changes, check content, links and diff; historical acceptance numbers do not thereby become results of a new test round.

Legacy `hostComponents`, `hostRenderer` and `hostData` keep compatible input paths; mixing the new configuration with corresponding legacy registration parameters rejects the conflict. Recompile documents and rebuild bundles after migration. Same-name overrides of default components, runtime registry mutation, auto-loading plugins inside documents and third-party code sandboxes remain outside this SDK contract.

New components should first extend the public contract and compliance cases, then be verified jointly by default components and out-of-repository components. Component, theme, SDK, syntax and release versions are managed separately.

## 7. Demo single-entry integration supplementary verification (2026-10-31)

This section records acceptance for commit `ef89377`. Tetris later switched to consuming the installed package; see the [Demo instructions](https://github.com/yao1145/ReactiveMD/blob/main/demo/README.md) for the current integration and update flow.

The Demo now assembles component implementations, styles, themes, examples and notices from `demo/extensions.ts`. Tetris directly reuses the in-package source and examples; the compiler, Worker, preview, editor catalog and export use the same configuration. The offline runtime is built by the public `buildLocalStandaloneBundle`; the intermediate JSX transform in development mode is fixed to production mode, preventing exported files from calling an unavailable `jsxDEV`.

Checks in this round:

- `npm run build:demo`: library types, library artifacts and the Demo build pass.
- Demo unit tests: 20 files and 266 tests pass, including real external component SSR/static export, missing and conflicting styles, nested npm installation and offline capability diagnostics.
- `npm run test:package`: public entries and the core/React consumption boundary pass.
- `npm run test:docs`: 76 documents, 812 local links and anchors pass.
- `node demo/scripts/verify-extensions.mjs` and `--dev`: 6 items each pass in Edge production and development modes, covering the real Worker, game controls, editor catalog, phone layout, and opening and operating exported interactive HTML offline; static HTML includes component styles and contains no scripts. Both rounds have no page errors or offline HTTP requests.
- Existing `demo/scripts/verify-export.mjs`: 4 items pass for built-in component current values, state download, interactive offline HTML and static HTML.

Browser records and example files from this round are in `artifacts/demo-extensions/`. These results belong to this Demo integration supplementary verification and are recorded separately from the historical release gates of the first three phases.

## 8. Tetris installed-package integration supplementary verification (2026-10-31)

The Demo now installs the Tetris npm tarball from `demo/vendor/` and reads the implementation, styles, examples and notices from the package's public entries. The package uses host-provided ReactiveMD, React and React DOM peer dependencies. `npm run update:demo-tetris` builds the component, generates an install package with content digests, and updates the Demo dependency and lockfile.

This round passed the Demo build, root-project typecheck, 267 Demo tests across 21 files and documentation link checks. A new install-boundary test confirms that the component comes from the unpacked `node_modules` distribution package, includes declarations and license, excludes `src/components.tsx`, and that the tarball SHA512 matches the lockfile integrity. 6 browser acceptance items each pass in production and development modes, covering the Worker, preview interaction, editor catalog, phone layout, and static and interactive offline files; the exported game remains operable while offline.

## 9. Convenience entries and independent integration acceptance (2026-10-31)

Added defineReactComponentPackage and createReactHost; the convenience entries fill in defaults for protocol, form and style identity, while underlying manifest reading remains strictly validated. Public reactive-md/vite unifies the virtual host, styles, dependency prebundling, React deduplication and offline runtime. Added the reactive-md init component scaffold and Chinese/English quick starts, retaining the original long guide as the full contract page. renderStatic keeps its existing optional semantics; this round uses examples to demonstrate ctx.mode and static binding restrictions.

Compile results carry componentConfigKey, and Worker and incremental patches preserve it. A mismatched compile configuration reports local.extension.config-mismatch; when a manifest exists but the React implementation is missing, it reports local.extension.renderer-missing, and strict SSR rejects before executing the component. Old documents and legacy host paths remain compatible.

Per the user's request, a fresh Claude Code session was started to integrate Tetris again; the session modified only its assigned implementation and Demo wiring, while the main agent reviewed, rebuilt the install package and ran acceptance. Tetris continues to install from the npm tarball in demo/vendor and integrates through the public component package and Vite plugin; the old private adapter and alias were removed.

Before the user asked to stop testing, the following was complete: 150 core files and 1975 tests, 21 Demo files and 267 tests; library and Demo builds, public package boundaries and real tarball consumption checks; 6 browser checks each for Tetris development/production; after installing the real SDK, 6 consumption checks covering the CLI, the same example in both languages, types and Node/SSR compliance, production preview, static/interactive offline HTML, and development-time style updates. Acceptance logs are in artifacts/sdk-ease/ and artifacts/demo-extensions/. Testing then stopped per the user's instruction, with only records and commits finalized.

## 10. 2048 component package integration (2026-10-31)

Added `examples/game-2048-package`, providing a seeded 2048 component under the `<game-2048>` tag, including a pure-function engine, React implementation, static/SSR preview, styles, examples and compliance scripts. The tag name must follow the SDK's letter-first rule, so `<2048>` is not used; the package documentation records this restriction and its reason.

Integration follows the same pattern as Tetris: `npm run update:demo-2048` builds, packs and installs the tarball in `demo/vendor/`; `demo/extensions.ts` reads the implementation, CSS, examples and attribution from the public `./react` and `./notices` entries, and passes them together with `tetrisPackage` to the same `createReactHost`. Examples enter the catalog through extended `examples` metadata. 7 browser checks each pass in Demo production and development modes, covering Worker compilation of both plugins, preview interaction, editor catalog, phone layout and offline export, with new 2048 catalog, rendering, movement and locking scenarios.

The package's own `npm test` passes all Node, SSR, browser lifecycle and offline export checks (74 items), with execution evidence for all four capabilities: `interactive / static / ssr / offline`. The root project `package.json` adds `update:demo-2048`, and `demo/vendor/README.md` records the update commands for both install packages.
