# Extension SDK and unified component architecture plan

**English** · [中文](extension-sdk-plan-ch.md)

Status: all three phases have been implemented. Date: 2026-10-30. Delivery and verification are in the [consolidated acceptance record](extension-sdk-acceptance-en.md). The SDK uses a source-built install-package preview; npm publication is scheduled separately.

This document retains the original architecture design, source baseline and implementation order. Delivered entries and contracts are governed by the [SDK guide](../integration/extension-sdk-en.md); actual implementation and results are consolidated in the acceptance record.

## 1. Architecture goals and delivery boundaries

The stable kernel provides document execution capability; built-in and user components follow the same extension protocol, and themes install and compose independently.

After installing the npm package, a developer should be able to define and register components in their own project and obtain attribute validation, reactive bindings, editor support and declared render capabilities. Development uses only public entries. Built-in components must also be implemented through these public contracts; this is the final acceptance criterion for this architecture work.

The kernel uniformly maintains syntax parsing, expression evaluation, dependency scheduling, state and shared constraint validation, resource budgets and source locations. Components provide features, interaction and presentation; themes provide visual variables and style overrides. Markdown base nodes and language declarations such as `theme`, `computed` and `external` continue to be handled by the kernel.

This round uses one npm package with multiple public sub-entries. First complete instance-level configuration and extension contracts, then migrate built-in components in batches, and finally complete editor and sharing consumption flows. Release versions, npm publishing and Demo deployment are scheduled separately based on actual delivery.

Out of scope: component marketplace, remote plugin downloads, arbitrary JavaScript inside documents, third-party code sandbox, runtime registry mutation, and same-name overrides of built-in components. Component code is actively installed and imported by the host.

## 2. Source baseline and existing capabilities

The user proposal is based on `7810d28`, `0.6.1`. The HEAD checked for this work is `984e93adf373d025fb1ca1fa7e49080902f484e9`, and the root package version is still `0.6.1`. Commits between them modify documentation only; the following architecture judgments apply to the relevant implementation at both commits.

| Area | Current state verified | Planned handling |
| --- | --- | --- |
| Component definitions | Built-ins use `LocalComponentSchema` and the frozen `LOCAL_COMPONENTS`; external components use `LocalHostComponentSchema` | Merge into a unified definition, then have the default preset assemble the built-in set |
| Parsing and compilation | The parser has a built-in form set and host branches; the compiler separately parses built-in and host bindings | Drive form, attribute, structure and binding parsing from a registration snapshot |
| Binding capabilities | Host schema exposes a single scalar binding; the kernel already has string arrays, number arrays, named slots and `setMany` | Organize existing capabilities into component context and gradually unify constraint mechanisms |
| React rendering | Built-ins use `COMPONENTS`; hosts use a single `hostRenderer` | Look up implementations by component identity and unify instance context |
| Attribute values | `resolveHostProp` preserves the scalar type of complete interpolation; ordinary literals return text through `runtime.text()` | Build an attribute-reading layer for the new SDK that normalizes per declaration |
| Authoring tools | Already reads host schema; closing-tag candidates do not include host components; insertion catalogs are maintained separately | Generate candidates, insertion menus and attribute descriptions from definitions |
| Themes | Have `LocalThemeDefinition`, protocol validation, instance scope, light/dark mode and public variables | Add package conventions, explicit composition and resource collection |
| Export | `normalizeCompileOptions` does not preserve host schema; standalone mount options have no host renderer | Connect compile configuration, implementation binding and resource packaging |
| Isolation | Host renderer currently catches synchronous exceptions from direct calls | Add handling contracts for React subtree errors, SSR and async tasks |

Local references:

- [schema.ts](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/schema.ts), [types.ts](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/types.ts), [options.ts](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/options.ts).
- [parser.ts](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/parser.ts), [compiler.ts](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/compiler.ts), [runtime.ts](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/runtime.ts).
- [render context](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/render-types.ts), [React renderer](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/LocalDocumentView.tsx).
- [authoring analysis and completion](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/authoring.ts), [editor catalog](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/editor/native-components.ts), [Demo catalog](https://github.com/yao1145/ReactiveMD/blob/7810d28/demo/src/native-components.ts).
- [HTML export](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/shareable.ts), [standalone mounting](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/standalone/session.tsx), [Worker protocol](https://github.com/yao1145/ReactiveMD/blob/7810d28/src/local/worker.ts).
- [host integration](../integration/local-integration-en.md), [current component protocol](../development/component-protocol-en.md), [current theme protocol](../reference/theme-protocol-en.md).

## 3. Path selection

| Path | Benefits | Costs and scope |
| --- | --- | --- |
| Recommended: unified registration model, staged migration | Compilation, state, rendering and authoring tools ultimately share contracts; each batch can be verified independently | Initial work to organize special compiler branches; compatibility adapters retained during migration |
| Only wrap existing `hostComponents` and `hostRenderer` | Fastest way to provide an external development entry | Still two sets of component capabilities; suitable as a short-term compatibility bridge, not a final state |
| Migrate all built-ins and split packages at once | Complete catalog and dependency reorganization in one pass | Changes compilation, rendering, build and consumption paths at the same time; regression surface is too large |

Adopt the first path. Phase 1 may reuse the host extension foundation, but new public contracts should directly express the target capabilities; phase 2 eliminates built-in-only registration, binding and distribution channels item by item.

## 4. Target structure and data flow

```mermaid
flowchart TD
  A[默认预设与用户组件 manifest] --> R[实例级配置校验与冻结]
  T[独立主题包与组合配置] --> R
  R --> S[可序列化的注册快照]
  S --> C[解析 编译 作者分析 Worker]
  C --> D[文档与组件需求清单]
  D --> K[内核运行时]
  R --> I[宿主显式导入的实现与资源映射]
  I --> V[React 与静态渲染适配器]
  K --> V
  S --> E[编辑器目录与补全]
  D --> X[导出能力预检与打包]
  I --> X
  X --> H[可恢复的离线 HTML]
```

### 4.1 Instance-level configuration

Add a configuration factory such as `createLocalConfig` that accepts component presets, user components and theme collections, validates them, and forms immutable configuration. The name is provisional and will be confirmed during review.

Configuration has two layers:

1. A serializable registration snapshot containing component manifests, theme metadata, protocol requirements and a deterministic semantic digest. The compiler, authoring tools and Worker receive only this layer.
2. Host implementations and resource mappings, containing React implementations, static implementations, CSS and export module descriptions. These are held by the corresponding adapters; functions and React objects do not enter the Worker or document payload.

All consumer surfaces derive the data they need from the same configuration. Ordinary compilation can still use the default component behavior of `compileLocal(source)`; advanced hosts explicitly select presets. Configuration is frozen after creation; changing the component set creates a new configuration and triggers the corresponding compilation and capability precheck.

Compile results record the stable identities, protocol requirements and semantic digest of the components used. The renderer validates before mounting that implementations match the compile result, preventing compilation with configuration A and rendering with configuration B. The component digest is separate from the overall configuration cache key: document dependencies record only the components actually used, while the cache covers all configuration that affects compile semantics.

Changes to theme colors or descriptive text should not clear document state. Changes to component semantic configuration require recompilation, followed by validation of reusable parameters under the existing state-retention rules.

### 4.2 Public entries

| Proposed entry | Responsibility | Dependency requirements |
| --- | --- | --- |
| `reactive-md` | Retain the existing core API and default behavior | Remain Node-usable, with no React import side effects |
| `reactive-md/sdk` | Definitions, manifest validation, configuration composition, public context base types | Pure data and kernel types |
| `reactive-md/presets/default` | Default component declarations and default preset description | Schema portion remains React-free |
| `reactive-md/react` | React binding factory, default implementations and document view | React 19; default convenience usage retained |
| `reactive-md/authoring` | Generate analysis, completion and insertion catalogs from configuration | Continue supporting React-free analysis calls |
| `reactive-md/testing` | Manifest and behavior compliance tools | Heavy test adapter dependencies imported on demand |
| `reactive-md/export` | Host build-side component resource collection and offline packaging | Browser payload separated from Node packaging dependencies |

The last two entries are delivered by phase. Phase 1 provides minimal internal validation tools and a host build example; phase 3 stabilizes the general public interfaces. Build configuration, declaration generation and real tarball consumption tests cover the new entries at the same time.

`/sdk` does not re-export React types or Node bundlers. Default preset declarations and implementations are imported separately; a host selecting a few components need not load the entire graphics implementation. Specific per-component sub-entries will be determined during migration based on artifact analysis.

## 5. Executable component contract

### 5.1 Separation of definition and implementation

A component consists of a pure-data manifest and one or more adapter implementations. Component stable identity is independent of the source tag name; we recommend a package or organization namespace plus component name. Tags continue to use existing lower-case kebab-case.

| Declaration item | Content | Validation location |
| --- | --- | --- |
| Identity | Stable id, tag name, implementation version, SDK protocol, compatible kernel version range | At registration |
| Form | leaf, inline, container | At registration and parsing |
| Attributes | Type, default, required, enum, range, static or dynamic, description | At registration, compilation and runtime evaluation |
| Children | Markdown/inline content, allowed structural children, count and parent constraints | At compilation |
| Bindings | Slot, type, family, initial-value rules, constraint source, shared or exclusive | At compilation and runtime writes |
| Capabilities | Interactive DOM, static, SSR, offline interaction, required environment and host services | At implementation binding and before consumption |
| Editor | Multilingual title, description, category, template, examples, attribute help | At registration and authoring generation |
| Styles and assets | Component style identity, theme variable requirements, export resource identity | At build and export precheck |
| Dependencies | Other component ids and compatible version ranges | At configuration assembly |

Manifests use bounded JSON data; defaults are also subject to type and budget checks. Functions, cyclic references, prototype-pollution keys and unsupported regex patterns are prohibited. Continue using the existing linear-time-safe pattern subset.

Registration budgets separately constrain component count, attribute and slot count, string length, dependency depth and total manifest size. The default preset and external components are counted separately and then subject to a combined total; the legacy host limit of at most 32 schemas remains in the old interface and cannot be applied directly to a new configuration containing all built-in components. Compilation and runtime continue to enforce document budgets; export has separate resource-count and total-byte budgets.

Dependencies are satisfied by the component set supplied by the host. Missing dependencies, dependency cycles, duplicate ids, duplicate tags, unsupported protocols or incompatible versions make configuration creation fail and list the paths. Configuration assembly does not access a registry or the network.

### 5.2 Interface sketch

The following shows call relationships; fields and function names are not yet implemented. The full discriminated union and generics will converge in phase 1.

```ts
// 提案：纯数据 manifest 可独立进入 Worker。
const rating = defineLocalComponent({
  id: 'example/rating',
  name: 'rating',
  version: '1.0.0',
  protocol: 'reactive-md-component/v1',
  form: 'leaf',
  props: {
    label: { kind: 'string', required: true },
    max: { kind: 'number', dynamic: true, default: 5, min: 1, max: 10, integer: true },
  },
  bindings: {
    value: {
      kind: 'number', family: 'number',
      bind: 'bind', initial: 'initial',
      initialRule: 'nearest-zero',
      constraints: { min: { literal: 0 }, max: { prop: 'max' }, step: { literal: 1 } },
    },
  },
  capabilities: { interactive: true, static: true, ssr: true, offline: true },
  authoring: {
    title: { zh: '评分', en: 'Rating' },
    category: 'input',
    insertText: '<rating bind="score" label="评分" initial="3">',
  },
});

// 提案：React 类型只出现在 React 入口。
const ratingReact = defineReactComponent(rating, {
  render: RatingControl,
  renderStatic: RatingText,
});

const config = createLocalConfig({
  presets: [defaultPreset],
  components: [rating, hint],
  themes: [paperTheme],
});
const reactConfig = createReactConfig(config, {
  presets: [defaultReactPreset],
  components: [ratingReact, hintReact],
});
```

`hint`, themes and implementations are explicitly imported by the consuming project. `offline: true` declares a capability requirement; offline packaging must also provide a build-side entry and resource evidence, and this field alone cannot pass precheck. `defineReactComponent` binds an implementation to the manifest's identity and digest, preventing mismatches.

### 5.3 Attribute normalization

The new SDK normalizes attributes before component execution. Valid numeric literals and valid complete numeric interpolations both produce `number`, and likewise for boolean attributes. Interpolations with mixed text are only used for string attributes; array attributes use restricted collection expressions or complete typed interpolation, with syntax revised separately when needed.

Process in this order: fill defaults, parse literals or evaluate expressions, type-check, range and enum check, generate read-only props. `0`, `false`, the empty string, omission and `null` are handled separately. When a required attribute fails evaluation, the component enters a visible invalid state and reports the attribute, source location and reason; optional attributes use defaults only when a fallback rule is declared.

Defaults are used automatically only when an attribute is omitted; illegal explicit input is not silently swallowed. Dynamic attributes are revalidated after each dependency change; dynamic constraints and shared bindings follow the kernel's current consistency rules. Legal combinations of `static` and `dynamic` declarations are fixed in manifest validation, and the same attribute cannot declare conflicting evaluation modes. Legacy `hostRenderer` props behavior is preserved by a compatibility adapter.

### 5.4 Child content and structural children

Ordinary containers declare Markdown or inline content and use `children.render()` to render compiled child content. The SDK provides components with a typed structural-child view, attributes and source locations, so components need not read the internal AST.

Complex containers describe children with serializable parent-child relationships, count rules and structured projections. Built-in specialized rules for options, tabs, cards, table and others must be organized item by item into reusable mechanisms. The same rules are open to built-in and user components and are subject to unified depth and work budgets.

Components may request rendering only of child content or named content slots they own. The rendering API does not accept arbitrary forged AST or reparse unregistered source. Host containers inherit parent visibility and cannot re-show hidden content through child rendering parameters.

## 6. State, lifecycle and error handling

### 6.1 Public component context

The context provides normalized props, component instance identity, source range, render mode, effective visibility and disabled state, binding slots, child-content interfaces, a reset token and a diagnostic reporting interface. Public code works through these interfaces; internal nodes are held by the adapter.

The binding interface is proposed as `bindings.value.get()`, `bindings.value.set(next)` and `bindings.setMany({ x, y })`. Writes return a unified success/diagnostic result; the default single slot may provide a convenience alias. Multi-slot writes call the existing kernel transaction; one legal commit notifies once, and failure keeps state and revision unchanged.

Components receive write handles only for bindings they declare. Cross-component sharing is implemented through same-named public bindings; hosts managing all parameters still use the existing runtime API.

### 6.2 Multiple slots, collections and shared constraints

Phase 1 covers a single scalar slot and retains the type structure for extension to named slots. Phase 2 opens multiple slots, `string[]` and `number[]`, reusing existing kernel value domains, array copying, budgets and validation.

Multiple slots first keep the existing exclusivity rules for `range-slider` and `coordinate`. Public sharing between multiple slots is an independent capability, opened later through an explicit contract; single-slot sharing between the rating control and the built-in number control must pass in phase 1.

Unify the responsibilities of family and type: type describes the value domain, family describes shared semantics and how constraints merge. First expose rules and rule combinations already supported by the kernel. When complex components need new constraints, add versioned, serializable and budgetable public constraint primitives before migrating the components; built-in components must not retain private callbacks that bypass validation.

### 6.3 Lifecycle rules

| Event | Kernel and adapter semantics | Component responsibility |
| --- | --- | --- |
| Initial mount | Provide validated initial bindings and props | Create local UI state and necessary resources |
| Binding or dynamic attribute change | Update context after dependency scheduling | Present new values without recreating the document runtime |
| Conditional hide | Keep document bindings by default; pass `visible=false` to components that remain mounted | Pause pausable tasks such as timers and observers |
| Reset | Restore bindings for the target subtree and advance the reset token | Use the token to clear local state that must reset, such as expansion and drafts |
| Unmount | Adapter removes the component's subscriptions and resource scope | Clean up effects, event listeners and self-created tasks |
| Static/SSR | Provide read-only context; no mount side effects | Output deterministic content without starting timers or accessing the DOM |

Concrete hide and reset behavior of existing components first enters the regression list. If migration needs to change observable semantics, list it as a separate compatibility change. Local UI state does not enter the document state file by default; state that needs persistence should be declared as a kernel-managed binding.

### 6.4 Capabilities and error isolation

Interactive DOM, static output, SSR and offline interaction are declared and verified separately. Static capability does not automatically imply SSR: a DOM-dependent static implementation may still fail in Node. Offline capability also requires the implementation, dependencies, CSS and resources to be locally recoverable.

The React adapter establishes an Error Boundary for the component subtree; direct calls, event handlers and async tasks use their own error-reporting wrappers. SSR exceptions that Error Boundary cannot cover are handled at the component execution boundary by the static render pipeline. Process-level isolation for infinite loops in arbitrary host code cannot be provided by this protocol.

A single component failure shows a placeholder with source location and reports a diagnostic. Interactive preview can continue reading the remaining content; strict export aborts when an implementation is missing or rendering fails. After the user explicitly chooses degraded export, the output retains the placeholder and a degradation list.

## 7. Editor auto-integration

Generate tag candidates, attribute candidates, enum and binding candidates, hover descriptions, insertion catalogs, examples and paired closing-tag candidates from the registration snapshot. leaf components generate no closing tag; structural children are filtered by context; code, comments, escapes and other literal regions follow existing rules.

Phase 1 provides the basic paths for tag, attribute and closing completion, plus one insertion catalog generated from configuration. Phase 3 unifies catalog consumption in the editor and Demo, covering search, grouping, multiple languages, selection insertion, undo/redo and structural context.

Generate a minimal legal template when a component provides none; if required children or required attributes are insufficient to generate legal content, registration validation requires the component to provide a template. Templates are compiled with the same configuration in compliance tools, preventing errors immediately after menu insertion.

The editor displays static description text, avoiding executing package descriptions as arbitrary HTML. When a language description is missing, use an explicit locale fallback order. Worker analysis and main-thread completion use the same semantic digest and reject analysis results produced from stale configuration.

## 8. Export and recovery

### 8.1 Handle declarations and code separately

A document's companion requirement inventory records the component ids actually used, compatible version requirements, implementation versions and semantic digests, plus themes, resources and target capabilities. Embedded schema data passes the existing trust and budget validation; the requirement inventory only describes requirements. The recovery host explicitly provides installed implementations; package names, URLs or declarations in a document never trigger download or execution.

The requirement inventory and state file evolve separately, retaining the purpose of `reactive-md-state/v1`. Matching source digests alone are insufficient to prove identical extension semantics; on recovery, check component contracts first, then validate and apply state. Legacy payloads continue through the default preset, and extension fields are explicitly identified by payload version.

### 8.2 Export capability matrix

| Target | Minimum conditions | Handling when missing |
| --- | --- | --- |
| Online interactive preview | Schema match, interactive implementation, required host services available | Component placeholder with a specific diagnostic |
| Static HTML | Static implementation, current state and all required style assets | Strict mode blocks; explicit degradation may retain a placeholder |
| SSR | Static implementation executable on the server, deterministic first-screen output | Precheck fails before mounting, or a component error is reported during render execution |
| Offline interactive HTML | The above static result, a packable interactive implementation, all local dependencies and resources | List components, resources or host services that cannot go offline |

### 8.3 Minimal path and full packaging

Phase 1 validates the loop with a host-built dedicated standalone bundle: the entry explicitly imports the rating, hint container and theme, the build tool merges them with the runtime, and the exporter accepts the trusted bundle and resource table. The export side retains the registration snapshot, and the recovery side assembles the same implementation set. This phase does not derive modules from function objects in the browser or require a general automatic bundler.

Phase 3 provides build-side resource description and packaging adaptation: component packages export manifests, React/static entries, CSS and resource tables; the builder collects dependencies from the host allowlist and generates the target bundle and inlinable resources. In-browser export uses a prebuilt matching bundle; a general editor cannot automatically recover source dependencies from arbitrary functions registered by users.

Resources are deduplicated by stable id and content digest, use a fixed order, and record licenses and notices. CSS `url()`, fonts, images and other resources declared by components must be resolved and localized; omissions, budget overruns or unavailability produce diagnostics. Component offline output follows the existing CSP; when network access, dynamic remote modules, Workers or other unallowed environment capabilities are required, fail early or choose a compatible implementation.

Export precheck first generates a structured plan, then performs resource collection and packaging. Proposed diagnostics include component id, version, target, capability or resource gap, source range and remediation suggestions, such as `local.extension.export-capability` and `local.extension.resource-missing`. Final naming will be reviewed together with the existing diagnostic system.

Offline acceptance opens the file in a new browser context with the network disconnected and no cache, checks state recovery, binding writes, reset and theme, and asserts that there are no external network requests. SSR hydration separately tests first-screen consistency; readable static HTML cannot substitute for interactive recovery verification.

## 9. Theme packages and style composition

Reuse `reactive-md-theme-1` theme selection, default fallback, light/dark mode and instance scope. Add a theme package manifest recording package version, theme id, protocol, CSS resources, variable requirements, optional component enhancement styles and export resource description.

We recommend defining composition as one base theme plus ordered token overrides and component enhancement styles. The host explicitly composes them and generates one optional theme name; documents continue to select through a single `<theme name="...">`. Do not introduce in-document theme list syntax yet.

Style order is fixed as: kernel structure and default variables, component structure and default styles, base theme, composition overrides, component theme enhancements. Cascade layer names and scoping rules are written into the protocol, avoiding reliance on call timing or accidental CSS file load order. Structurally required styles and overridable visual styles are maintained separately; the `unstyled` usage must also specify the source of minimal structural styles.

New components should prefer existing semantic variables such as `--ink`, `--surface`, `--accent`, `--focus-*` and `--space-*`. Component-specific variables use `--rmd-<component-prefix>-<purpose>`; in-package classes and data markers follow the same namespace convention and are limited to the document root.

Themes need not know every component in advance. Components must be readable and operable under the default theme; theme packages may provide enhancement styles for known components. Theme composition checks missing variables, circular inheritance, duplicate identities and incompatible protocols; export collects CSS, fonts and images according to the selected resource closure.

Instance A's theme must not change instance B or the host page. Theme switching only updates styles and selection, without rebuilding the runtime or losing bindings. Accessibility acceptance covers light/dark mode, keyboard focus, disabled state, error state and narrow screens.

## 10. Compatibility and migration strategy

### 10.1 Existing callers

`compileLocal(source)`, existing React views, default component names and default themes remain available. They adapt to the unified path through an internal default configuration. Existing `hostComponents`, `hostData` and `hostRenderer` retain their behavior throughout migration, and documentation provides examples mapping to the SDK; removal requires a separate version decision.

If one call uses both the new configuration and legacy host registration parameters, report a configuration conflict directly, avoiding implicit merging that makes names, renderers or budget meanings ambiguous. The legacy renderer runs through a compatibility bridge and maintains legacy props parsing behavior; the new SDK uses the typed normalization contract.

Namespaces continue to protect built-in tags, language declarations and related HTML names. Duplicate component names are rejected by default, including importing the same preset twice; the error should identify both sources. Built-in replacement, aliases and explicit override mechanisms will be designed separately later.

### 10.2 Protocols and versions

Distinguish the npm package version, authoring syntax revision, current component contribution protocol, SDK manifest protocol, theme protocol and export payload version. Each independently records its compatibility range, avoiding one change raising all versions at once.

For additions of instance configuration and equivalent migration only, choose the package version per public API compatibility rules. When changing existing authoring syntax, default values, binding semantics or error-handling results, use the [current compatibility rules](../development/component-protocol-en.md) to decide whether to revise `LOCAL_SYNTAX_VERSION`. The relationship between the new SDK protocol and the contribution protocol must be clarified in phase 1; this document uses `reactive-md-component/v1` for the new data contract.

Component version ranges are used for dependency resolution, and semantic digests identify the actual contract. If a same-version manifest changes, digest validation should detect the difference. Static/interactive implementations separately record their binding information to the manifest. Compatible version upgrades that change schema or state constraints should recompile and validate state; semver alone must not skip checks.

### 10.3 Gradual migration and recovery

Switch implementations in component batches, with each batch retaining pre-migration semantic cases and a recoverable commit boundary. Dual-path comparison occurs in tests; the production runtime selects only one distribution path, avoiding duplicate bindings and subscriptions.

First freeze the minimum capabilities of the new protocol, then migrate representative components. When an SDK gap is found, add the public capability and compliance cases first, then migrate the component. If a batch has a semantic regression, revert that batch and keep passing public contracts and other component migration results.

## 11. Implementation milestones

### Phase 1: public extension SDK and independent consumption loop

Goal: a consuming project uses public entries for a rating control, hint container and theme, and verifies the minimal sharing path.

| ID | Work and order | Delivery and completion criteria |
| --- | --- | --- |
| P1.1 | Finalize registration, type normalization, single-slot sharing and requirement-inventory design | SDK protocol draft, compatibility mapping, manifest example; review Section 14 decisions |
| P1.2 | Implement manifest validation, configuration factory and immutable snapshot | Conflict, dependency, version, budget and deterministic-digest tests pass |
| P1.3 | Connect parser/compiler/Worker configuration entries | Main thread and Worker produce identical results with the same configuration; configuration changes invalidate incremental caches |
| P1.4 | Implement public React context and per-component distribution | Rating props have consistent types, share a binding with `<number>`, and containers render Markdown |
| P1.5 | Integrate basic authoring information and theme package resource description | After registration, completion, closing and insertion catalogs work; themes load independently |
| P1.6 | Fix export configuration propagation and build a dedicated extension standalone | Static export and minimal offline interactive export restore components, themes and initial state |
| P1.7 | Establish out-of-repository consumption verification from a verified tarball | All imports come from public exports; form a rerunnable consumption example and result record |

P1.4 and P1.5 can be implemented separately after the P1.3 contract stabilizes; P1.6 depends on P1.4 and the theme resource convention, and P1.7 verifies the complete path.

Phase 1 exit criteria: the independent consumption project never imports `src/local/*` or modifies ReactiveMD; rating, hint container and theme all participate in preview and export; legacy host APIs pass regression; record built-in special capabilities that still need phase 2. At this point an SDK preview delivery can be evaluated; the stability promise is confirmed after representative built-in migration verification.

### Phase 2: migrate built-in components to the public protocol

Goal: the same validation, state and render distribution mechanisms cover built-in and external components.

| ID | Migration batch | Key verification |
| --- | --- | --- |
| P2.1 | `slider`, `card` | Single-slot constraints, dynamic attributes, shared bindings, Markdown child content; depend only on the public SDK |
| P2.2 | `range-slider`, `coordinate` | Public multiple slots and atomic updates; retain existing exclusivity and relationship constraints |
| P2.3 | Collections and structural containers, such as `multi-select`, `tabs` | Array budgets, option projection, required children, reset and hide |
| P2.4 | Remaining components such as timers, graphics, tables and navigation, plus structural children | Inventory specialized compile/runtime rules item by item and migrate after extracting public capabilities |
| P2.5 | Default preset becomes the unified registration source | Remove validation and distribution split by built-in/host, retaining an input adapter for legacy interfaces |

Complete P2.1 first, then evaluate whether to adjust the protocol; after P2.2 and P2.3 semantics stabilize, advance complex components that depend on them. At phase start, generate the actual component inventory, listing schema, compile branches, runtime family, renderer, styles and regression cases for each item, and mark completion item by item, avoiding handwritten totals replacing the migration inventory.

Phase 2 exit criteria: built-in component implementations use only the public SDK and adapter interfaces; old and new semantic results match; external components can use the same rules. If privileged built-in branches remain, list them explicitly as incomplete. Syntax, expressions, scheduling and common constraint primitives remain in the kernel.

### Phase 3: complete consumption flow and stable contracts

Goal: third-party components have tested paths from installation and authoring through editing to offline sharing.

| ID | Work | Completion criteria |
| --- | --- | --- |
| P3.1 | Editor and Demo uniformly consume the registration catalog | Automatic menus, help, examples, contextual closing, analysis diagnostics and insertion editing behavior are complete |
| P3.2 | Build-side component and theme packaging adaptation | Can collect implementations, CSS, resources and notices; prebuilt bundles and configuration can be checked |
| P3.3 | Version requirements and payload recovery | Missing components, incompatible versions, digest mismatches and missing resources all produce clear diagnostics before execution |
| P3.4 | Publish compliance tools and a component package template | Authors can run manifest, binding, lifecycle, static and offline tests outside the repository |
| P3.5 | Organize public documentation and release verification | Bilingual SDK/theme/migration docs, real tarball consumption and the full release gate pass |

Final exit criteria: every environment declared as supported can run; missing capabilities can be located before use; built-in and user components pass the same compliance tests. Release actions still follow the project release process separately.

## 12. First independent experiment

Use an independent temporary consumption directory to install the local verification tarball. The test directory must not use monorepo source aliases, relative-path imports or shared source; templates may be stored in the repository but are copied to an isolated directory when executed.

The consuming project provides:

- `rating`: a numeric rating control with numeric attributes, defaults, disabled, keyboard input and a static text implementation.
- `hint`: a hint container that displays ordinary Markdown, interpolation and one built-in control through the public child-content interface.
- `paper`: an independent theme with light/dark mode, base variables and optional enhancement styles for the rating control.

Test document:

```markdown
<theme name="paper">

<number bind="score" label="评分" min="0" max="5" initial="3">
<rating bind="score" label="你的评分" max="5">

<hint title="说明">
当前评分为 **{{ score }}**。

- 修改任一控件，另一个控件同步。
- 普通 Markdown 在容器中正常呈现。
</hint>
```

Acceptance order:

1. Create the configuration and compile; verify that both controls share the same public binding.
2. Write through the built-in control and the rating control separately, assert identical results; invalid values are rejected by the shared constraints.
3. Compare the types delivered to the component by `max="5"` and an equivalent complete interpolation; test omission, `0`, `false` and expression failure.
4. Switch light/dark mode, reset, hide, re-show and unmount components, verifying state and resource cleanup.
5. The editor recognizes templates, attributes, container closure and descriptions; the inserted result compiles with the same configuration.
6. Output SSR in Node, then mount in the browser; check deterministic content and hydration diagnostics.
7. Export static HTML and offline interactive HTML supported by the dedicated bundle, and recover them in a fresh offline context.
8. Remove the implementation, use a mismatched version, and delete the CSS resource; confirm specific diagnostics and the agreed failure behavior.

Success evidence includes the public import list, install-package digest, test results, exported files and recovered parameter values. Multi-slot and collection components add the same external consumption cases in phase 2.

## 13. Change surface, verification and risks

### 13.1 Estimated change surface

| Module | Current location | Estimated work |
| --- | --- | --- |
| Public declarations and registration | `src/local/types.ts`, `schema.ts`, `options.ts` | Add SDK manifest/registry modules and gradually adapt existing declarations |
| Compile chain | `parser.ts`, `compiler.ts`, `incremental.ts`, `worker.ts` | Use snapshots, unified validation and bindings, and add semantic cache keys |
| Runtime and state | `runtime.ts`, `state.ts` | Provide binding handles, public constraints and dependency verification, retaining existing atomic writes |
| React | `render-types.ts`, `LocalDocumentView.tsx`, `visuals.tsx`, `src/react/` | Public context, component distribution, subtree error isolation and default implementation migration |
| Editor | `src/local/authoring.ts`, `src/editor/`, `demo/src/native-components.ts` | Generate authoring information from snapshots and remove duplicate catalog sources |
| Themes and styles | `src/local/theme.ts`, `src/styles.css`, theme protocol | Package resource description, composition order and variable naming |
| Sharing and standalone operation | `src/shareable.ts`, `src/standalone/`, `cli/` | Requirement inventory, implementation assembly, resource plan and recovery validation |
| Build and verification | `package.json`, `vite.lib.config.ts`, `vite.standalone.config.ts`, declaration generation and packaging scripts | New exports, on-demand artifacts, public package consumption and notices |

The directories in the table are known landing points; specific new files are determined by module boundaries, avoiding further enlargement of `LocalDocumentView.tsx` and `compiler.ts`.

### 13.2 Layered verification

| Layer | Behavior to prove | Existing foundation and new cases |
| --- | --- | --- |
| manifest | Structure, defaults, conflicts, dependencies, versions, budgets, serialization | New SDK schema/config tests |
| Compilation and Worker | Same results with the same configuration, structural diagnostics, cache invalidation, legacy option compatibility | `local-host-components`, `local-compile-options`, `local-compile-worker` and new unified-path tests |
| State | Shared constraints, single slot, multi-slot atomic writes, collections, reset, retention and recovery | `local-host-binding`, state and runtime tests and component compliance data |
| Rendering | Props types, child content, static/SSR, error placeholders, subscription scope | `local-host-renderer`, theme and per-component rendering tests |
| Authoring tools | Completion, closing, templates and diagnostics generated from the same configuration | `local-authoring`, editor integration and toolbar browser verification |
| Real consumption | No private imports, pure core without React, usable declarations, complete styles | Extend existing `verify-package`, `verify-packed` and independent consumption experiment |
| Offline | Implementation and theme recovery, no external requests, version errors rejected early | Extend `verify-shareable`, standalone and browser fixtures |

Run the corresponding tests, type checks and necessary builds at each milestone. Actual acceptance records are maintained separately in phase delivery documents. After entering release preparation, run the full `verify:release`.

### 13.3 Risks requiring active control

| Risk | Response and evidence |
| --- | --- |
| The SDK is only a new wrapper around legacy host APIs | `slider` and `card` must migrate using the public SDK; the final check requires the built-in-only branch list to be empty |
| Unified attribute parsing changes legacy renderer input | Adapt old and new contracts separately; test boundary values for literals and interpolation |
| Special binding families cannot be expressed in a pure-data protocol | Inventory before complex migration; add general primitives and equivalent external cases |
| Worker and main-thread configurations diverge | Semantic digest, full compilation on configuration change, stale-response rejection tests |
| SSR or deep React errors are not isolated | Test direct throws, subtree throws, event and async failures, and server execution failures separately |
| Export misses implementation, font or CSS resources | Export-plan precheck, resource digests, offline no-cache recovery tests |
| Theme composition depends on CSS specificity and load order | Fixed cascade rules, scope checks, multi-instance browser acceptance |
| Registration expands render subscriptions and bundles | Reuse dependency indexes; compare notification counts, render counts and artifact size for the same fixture before and after migration |

Performance thresholds are established from measured baselines in the same environment. Do not scan all registered components on every render, and do not let the core entry introduce React or browser side effects because of the default preset.

## 14. Review decision checklist

The following recommendations together form the implementation premises of this draft; review may modify them by ID.

| ID | Decision | Recommended default | Impact |
| --- | --- | --- | --- |
| D1 | Package organization | One npm package with added SDK, presets, testing and export sub-entries | Keeps the current installation method; split packages later based on dependencies |
| D2 | Registration model | Instance-level, immutable, reject duplicates by default, retain built-in names | Ensures predictable behavior across multiple documents, SSR and Worker |
| D3 | Legacy interface compatibility | Retain throughout migration; report a conflict when passed together with new configuration | Preserves existing consumption behavior and reduces dual-configuration ambiguity |
| D4 | Phase 1 export scope | Static export plus a host-specific bundle for the minimal offline interactive path | Validates the main line early; general packaging tools completed in phase 3 |
| D5 | SDK stability promise | Phase 1 provides a preview; confirm the stable contract after representative built-in migration and external consumption pass | Validate interface completeness with actual capabilities |
| D6 | Theme composition | One base theme plus explicit ordered overrides, generating a single theme name | Reuses existing theme declaration syntax |
| D7 | Extension capability order | Single-slot scalars first, multiple slots and collections in phase 2; retain existing exclusivity rules | Controls initial implementation scope and retains a unified type structure |
| D8 | Final architecture gate | Built-in components use only public protocols and common kernel primitives; unmigrated privileged branches count as incomplete | Ensures built-in and user components have equal capabilities long term |

Implementation starts with P1.1 manifest, configuration and component-context contracts, and fixes the out-of-repository consumption experiment. All three phases completed per their exit criteria; further extensions continue to be verified through public contracts, default components and out-of-package consumption.
