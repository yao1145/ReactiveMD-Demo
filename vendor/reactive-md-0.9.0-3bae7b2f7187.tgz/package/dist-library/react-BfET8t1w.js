import { n as e } from "./sdk-core-CW2JhTlm.js";
import { a as t } from "./LocalDocumentView-B57DN0Tz.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
