import { M as e, w as t } from "./config-validation-F47AcE6o.js";
import { s as n } from "./config-BadfhjdP.js";
import { n as r, r as ee, t as te } from "./options-DTGPzSTZ.js";
import { n as ne } from "./incremental-DosOfN2u.js";
import { i as re, n as ie, r as ae } from "./runtime-D5iLwh6z.js";
import { a as oe, c as i, i as se, n as ce, o as le, r as ue, s as de, t as fe } from "./LocalDocumentViewCore-BM6fvwBr.js";
import { useCallback as a, useEffect as o, useMemo as pe, useRef as s } from "react";
import { jsx as c, jsxs as me } from "react/jsx-runtime";
// src/local/rendering/document/LocalReactiveDocumentCore.tsx
var he = Symbol("implicit document identity");
function l({ source: l, onDiagnostics: ge, urlPolicy: _e, locale: u = "en", themes: d, colorScheme: ve = "auto", mode: f = "interactive", staticFirst: ye = !1, imageResolver: be, hostData: p, hostRenderer: xe, reactConfig: m, useBaseCompileConfig: Se, externalValues: h, network: Ce, documentId: g, randomSeed: _, componentState: we, componentStateStorage: v, componentStateWriteDelayMs: y, onComponentStateChange: b, initialParameters: x, onParametersChange: S, onSourceNavigate: Te, compileOptions: C, capabilityGrants: w, allowedFrameOrigins: Ee, getBaseConfig: De }) {
	if (de(m, {
		hostData: p,
		hostRenderer: xe,
		themes: d
	}), m !== void 0) {
		let e = C?.config;
		if (e !== void 0 && e !== m.config) {
			let t = !1;
			try {
				t = n(e).key === m.config.key;
			} catch {
				t = !1;
			}
			if (!t) throw Error("reactConfig and compileOptions.config must be the same local config.");
		}
		if (C?.hostComponents !== void 0) throw Error("reactConfig cannot be combined with compileOptions.hostComponents.");
	}
	let T = m === void 0 && Se ? De() : void 0, Oe = T !== void 0 && C?.config === void 0 && C?.hostComponents === void 0, E = m === void 0 ? Oe ? {
		...C ?? {},
		config: T.config
	} : C : {
		...C ?? {},
		config: m.config
	}, D = m?.themes ?? d ?? T?.themes, O = te(E), k = `${r(E)}|${g ?? ""}|${_ ?? ""}`, ke = s(h);
	ke.current = h;
	let Ae = s(g);
	Ae.current = g;
	let je = s(_);
	je.current = _;
	let Me = s(we);
	Me.current = we;
	let A = s(v);
	A.current = v;
	let j = s(y);
	j.current = y;
	let M = s(b);
	M.current = b;
	let N = s(x);
	N.current = x;
	let P = s(S);
	P.current = S;
	let F = s([]), I = E?.config, L = I?.key, R = I?.legacyKeys.map((e) => e.key) ?? [], z = (e) => {
		let t = ie(e, {
			externalValues: ke.current,
			documentId: Ae.current,
			randomSeed: je.current,
			componentState: Me.current,
			...A.current === void 0 ? {} : { componentStateStorage: A.current },
			...j.current === void 0 ? {} : { componentStateWriteDelayMs: j.current },
			...(L ?? e.componentConfigKey) === void 0 ? {} : { configKey: L ?? e.componentConfigKey },
			...R.length === 0 ? {} : { legacyConfigKeys: R }
		}), n = N.current;
		return F.current = n && Object.keys(n).length ? t.setParameters(ce(n)) : [], t;
	}, B = s(null), V = s(null), H = pe(() => {
		B.current && V.current === O || (B.current?.dispose(), B.current = ne(), V.current = O);
		let e = B.current;
		return typeof e.compileShared == "function" ? e.compileShared(l, E) : e.compile(l, E);
	}, [l, O]), U = s(null), W = s(null), G = s([]), K = s(!1), q = U.current;
	if (!H.ok) q = null;
	else {
		let e = H.document;
		if (q && W.current !== k) {
			try {
				q.services?.state.flush();
			} catch {}
			G.current.push(q), q = null, U.current = null;
		}
		if (!q) {
			try {
				q = z(e);
			} catch {
				q = null;
			}
			U.current = q;
		} else if (q.document !== e) {
			let t = !1;
			try {
				let n = re(q, e, { notify: !1 });
				t = n.ok, n.ok && n.changed && (K.current = !0);
			} catch {
				t = !1;
			}
			if (!t) {
				try {
					q.services?.state.flush();
				} catch {}
				G.current.push(q);
				let t = null;
				try {
					t = z(e);
				} catch {
					t = null;
				}
				q = t, U.current = t;
			}
		}
		W.current = k;
	}
	let Ne = s(ge);
	Ne.current = ge;
	let J = s(0), Pe = le(D), Fe = pe(() => {
		if (!H.ok) return [];
		try {
			return t(H.document.theme, D, H.document.themeRange, H.document.source).diagnostics;
		} catch {
			return [];
		}
	}, [H, Pe]), Ie = s(null), Le = a((e) => {
		let t = se(e);
		t !== Ie.current && (Ie.current = t, Ne.current?.(e));
	}, []), Y = s([]), X = s([]), Z = a(() => {
		Le(ue(H.diagnostics, Fe, F.current, Y.current, X.current));
	}, [
		H,
		Fe,
		Le
	]), Q = s(Z);
	Q.current = Z, o(() => {
		let e = q?.services, t = e === void 0 ? [] : e.state.diagnostics(), n = X.current;
		t.length === n.length && t.every((e, t) => e === n[t]) || (X.current = [...t], Q.current());
	}), o(() => {
		Y.current = [];
	}, [H]), o(() => {
		Z();
	}, [Z]);
	let Re = a((e) => {
		Y.current = e, Q.current();
	}, []);
	if (o(() => {
		if (!q) return;
		Q.current();
		let e = !0, t;
		try {
			t = q.getParameters();
		} catch {
			return;
		}
		let n = () => {};
		try {
			n = q.subscribe(() => {
				if (!e) return;
				let n, r;
				try {
					n = q.getParameters(), r = q.snapshot();
				} catch {
					return;
				}
				if (!oe(t, n)) {
					t = n;
					try {
						P.current?.(n, r);
					} catch {}
				}
			});
		} catch {
			return;
		}
		return () => {
			e = !1, n();
		};
	}, [q]), o(() => (J.current += 1, () => {
		--J.current, queueMicrotask(() => {
			if (J.current !== 0) return;
			let e = U.current;
			U.current = null;
			try {
				e?.dispose();
			} catch {}
			try {
				B.current?.dispose();
			} catch {}
			B.current = null, V.current = null;
		});
	}), []), o(() => {
		let e = G.current;
		G.current = [];
		for (let t of e) queueMicrotask(() => {
			if (U.current !== t) try {
				t.dispose();
			} catch {}
		});
		if (!H.ok || !q) {
			let e = U.current;
			e && (U.current = null, W.current = null, queueMicrotask(() => {
				if (U.current !== e) try {
					e.dispose();
				} catch {}
			})), B.current && (B.current.dispose(), B.current = null, V.current = null);
		}
		if (K.current) {
			K.current = !1;
			let e = U.current;
			e && ae(e);
		}
	}), o(() => {
		let e = q?.services;
		if (e && b !== void 0) return e.state.subscribe(() => {
			M.current?.(e.state.snapshot());
		});
	}, [q, b]), o(() => {
		let e = q?.services?.state;
		if (e === void 0) return;
		let t = () => e.flush(), n = () => {
			document.visibilityState === "hidden" && t();
		};
		return window.addEventListener("pagehide", t), document.addEventListener("visibilitychange", n), () => {
			window.removeEventListener("pagehide", t), document.removeEventListener("visibilitychange", n);
		};
	}, [q]), !H.ok || !q) return /* @__PURE__ */ me("div", {
		className: `md-document local-document local-inactive${f === "static" ? " local-static" : ""}`,
		"data-render-mode": f,
		role: "alert",
		children: [/* @__PURE__ */ c("p", {
			className: "local-inactive-title",
			children: H.ok ? i(u, "Interactive initialization failed; preview is disabled.", "交互初始化失败，预览已停用。") : i(u, "The document contains syntax errors; interactive preview is disabled.", "文档包含语法错误，交互预览已停用。")
		}), H.diagnostics.length ? /* @__PURE__ */ c("ul", {
			className: "local-inactive-list",
			children: H.diagnostics.map((t, n) => /* @__PURE__ */ me("li", { children: [e(t, u), i(u, ` (line ${t.line}, column ${t.column})`, `（第 ${t.line} 行，第 ${t.column} 列）`)] }, `${t.code}-${n}`))
		}) : null]
	});
	let $ = ee(E), ze = $.ok ? {
		enableCss: $.html.enableCss && (w?.enableCss ?? !0) === !0,
		enableJavaScript: $.html.enableJavaScript && (w?.enableJavaScript ?? !0) === !0,
		enableExtendedHtml: $.html.enableExtendedHtml && (w?.enableExtendedHtml ?? !0) === !0
	} : void 0;
	return /* @__PURE__ */ c(fe, {
		document: H.document,
		runtime: q,
		capabilityGrants: ze,
		allowedFrameOrigins: Ee,
		network: Ce,
		networkScope: g ?? he,
		onDiagnostics: Re,
		urlPolicy: _e,
		locale: u,
		themes: m === void 0 ? D : void 0,
		colorScheme: ve,
		mode: f,
		staticFirst: ye,
		imageResolver: be,
		hostData: p,
		hostRenderer: xe,
		reactConfig: m,
		getBaseConfig: De,
		externalValues: h,
		onSourceNavigate: Te
	}, k);
}
export { l as t };
