import { a as e, i as t, s as n } from "./latex-1w7aQgD5.js";
import { n as r } from "./compiler-core-BMF0MNj7.js";
import { v as i } from "./validation-Dds_T0Wx.js";
import { n as a } from "./display-B-VhqVND.js";
import { t as o } from "./parser-standard-L8ypEr7g.js";
import { i as s } from "./html-ChuLIBPr.js";
import c from "./reactive-md-default-preset.js";
import { i as l, r as u, t as d } from "./types-VOvHPlsL.js";
// src/compiler/standard.ts
function f(e) {
	let t = i(e, c.components, o);
	if (t.ok) return t;
	throw new d(t.message, {
		code: t.key,
		...t.detail === void 0 ? {} : { detail: t.detail }
	});
}
function p(e) {
	return e === void 0 ? void 0 : Object.freeze({ ...e });
}
function m(i) {
	let o = f(i), c = p(i), d = {
		display: a,
		htmlFragment: s,
		plotMath: {
			kind: n,
			gridSize: e,
			compile: t
		}
	};
	return { compile(e) {
		return l(r(e, c, o, d), u);
	} };
}
export { d as CompilerConfigurationError, m as createStandardCompiler };
