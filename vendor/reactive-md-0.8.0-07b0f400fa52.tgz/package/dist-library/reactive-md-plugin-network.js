import { B as e, P as t, R as n, T as r, a as i, t as a } from "./preset-core-CKc5YXSM.js";
import { A as o, D as s, M as c, O as l } from "./component-utils-BvHL8VGt.js";
import { t as u } from "./mount-preset-CTGKvK1D.js";
import { useCallback as d, useId as f, useLayoutEffect as p, useRef as m, useState as h } from "react";
import { jsx as g, jsxs as _ } from "react/jsx-runtime";
// src/components/network/submit-button.tsx
var v = r({
	id: "reactive-md/submit-button",
	name: "submit-button",
	version: e,
	protocol: t,
	form: "leaf",
	props: {
		channel: {
			kind: "string",
			static: !0,
			required: !0
		},
		fields: {
			kind: "string",
			static: !0,
			required: !0
		},
		label: {
			kind: "string",
			coerce: "text"
		},
		disabled: {
			kind: "boolean",
			dynamic: !0,
			default: !1
		}
	},
	structure: {
		rule: "none",
		label: "none"
	},
	rules: [
		{
			kind: "nonempty",
			attribute: "channel"
		},
		{
			kind: "nonempty",
			attribute: "fields"
		},
		{
			kind: "dynamic-constraints",
			attributes: ["disabled"]
		}
	],
	capabilities: {
		interactive: !0,
		static: !0,
		ssr: !0,
		offline: !0
	},
	styles: ["reactive-md/network.css"],
	authoring: {
		title: {
			en: "Submit button",
			zh: "提交按钮"
		},
		description: {
			en: "Send the selected fields to a channel the host enabled.",
			zh: "把所选字段提交到宿主开放的通道。"
		},
		category: "action",
		insertText: "<submit-button channel=\"answers\" fields=\"choice comment\">"
	}
});
function y(e) {
	if (e === void 0) return null;
	let t = e.trim().split(/\s+/).filter((e) => e !== "");
	return t.length === 0 || new Set(t).size !== t.length || t.some((e) => !/^[A-Za-z_][A-Za-z0-9_]*$/.test(e)) ? null : t;
}
function b(e, t) {
	if (!e || t === "") return !1;
	try {
		return e.supports(t, "submit");
	} catch {
		return !1;
	}
}
function x() {
	let e = globalThis.crypto;
	if (e?.randomUUID) return e.randomUUID();
	if (e?.getRandomValues) {
		let t = e.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
		return Array.from(t, (e) => e.toString(16).padStart(2, "0")).join("");
	}
	return `submit-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
function S(e) {
	let t = o(e), n = f(), { mode: r, visible: i, t: a } = t, u = e.services.network, v = e.props.channel, S = typeof v == "string" ? v.trim() : "", C = e.props.fields, w = typeof C == "string" ? y(C) : null, T = l(e, "label", a("Submit", "提交")), [E, D] = h(null), O = E?.tone === "pending", k = m(null), A = m(null), j = d(() => {
		let e = k.current;
		k.current = null, e?.abort();
	}, []);
	if (p(() => (A.current = null, D(null), j), [
		S,
		C,
		u,
		r,
		j
	]), c(e, () => {
		j(), A.current = null, D(null);
	}), r === "static") return /* @__PURE__ */ g("span", {
		className: "local-submit-button local-submit-button-static",
		"data-rmd-static-submit": "",
		"aria-disabled": "true",
		hidden: !i || void 0,
		children: s(T)
	});
	let M = S === "" ? a("This button has no submit channel.", "此按钮未配置提交通道。") : w === null ? a("List valid field names without duplicates.", "请填写有效且不重复的字段名。") : b(u, S) ? void 0 : a("Submitting is not enabled for this channel.", "此通道未开放提交。");
	return /* @__PURE__ */ _("div", {
		className: "local-submit-button-control",
		"data-rmd-component": "submit-button",
		"data-field": E?.field,
		hidden: !i || void 0,
		children: [/* @__PURE__ */ g("button", {
			type: "button",
			className: "md-button md-button-primary local-submit-button",
			disabled: e.disabled || O || M !== void 0,
			"aria-busy": O || void 0,
			"aria-describedby": `${n}-submit-status`,
			onClick: () => {
				if (!i || e.disabled || k.current || !w || !b(u, S)) return;
				let t;
				try {
					t = e.runtime.readSubmissionFields?.(w) ?? {
						ok: !1,
						field: w[0],
						reason: "unavailable"
					};
				} catch {
					t = {
						ok: !1,
						field: w[0],
						reason: "unavailable"
					};
				}
				if (!t.ok) {
					let e = t.field, n = t.reason === "required" ? a(`Field "${e}" is required.`, `字段“${e}”为必填项。`) : t.reason === "invalid" ? a(`Field "${e}" has an invalid value.`, `字段“${e}”的值无效。`) : a(`Field "${e}" is unavailable.`, `无法读取字段“${e}”。`);
					D({
						tone: "error",
						text: n,
						field: e
					});
					return;
				}
				let n = t.payload, r = JSON.stringify(n);
				A.current?.signature !== r && (A.current = null);
				let o = A.current?.key ?? x(), s = new AbortController();
				k.current = s, D({
					tone: "pending",
					text: a("Submitting…", "正在提交…")
				}), (async () => {
					let e;
					try {
						e = await u.submit(S, n, {
							signal: s.signal,
							idempotencyKey: o
						});
					} catch {
						e = {
							ok: !1,
							error: {
								code: "transport",
								message: ""
							}
						};
					}
					if (k.current !== s) return;
					if (k.current = null, e.ok) {
						A.current = null, D({
							tone: "success",
							text: a("Submitted.", "已提交。")
						});
						return;
					}
					let t = e.error, i = t.message.trim();
					t.code === "cancelled" ? D(null) : t.code === "unconfirmed" ? (A.current = {
						key: o,
						signature: r
					}, D({
						tone: "warning",
						text: a("Submission result is unconfirmed. Retry to send the same fields again.", "提交结果未确认。可手动重试同一组字段。")
					})) : t.code === "transport" ? D({
						tone: "error",
						text: i || a("The submission could not be sent.", "发送提交失败。")
					}) : t.code === "rejected" || t.code === "invalid-data" ? (A.current = null, D({
						tone: "error",
						text: i ? a(`Submission was rejected: ${i}`, `提交被拒绝：${i}`) : a("Submission was rejected.", "提交被拒绝。")
					})) : (A.current = null, D({
						tone: "error",
						text: a("Submitting is not enabled for this channel.", "此通道未开放提交。")
					}));
				})();
			},
			children: T
		}), /* @__PURE__ */ g("span", {
			id: `${n}-submit-status`,
			className: "local-submit-button-status",
			role: "status",
			"data-tone": M ? "error" : E?.tone ?? "idle",
			children: M ?? E?.text ?? ""
		})]
	});
}
// src/components/network/network.css?inline
var C = "@layer rmd.components{.local-submit-button-control:where(.md-document,.md-document *){align-items:center;gap:var(--space-2);flex-wrap:wrap;margin:.7em 0;display:flex}.local-document .md-button.local-submit-button{min-height:var(--control-height);padding:0 var(--control-inset-x);font-size:var(--text-sm);margin:0}:is(.local-submit-button-control,.local-submit-button-static)[hidden]:where(.md-document,.md-document *){display:none}.local-submit-button-status:where(.md-document,.md-document *){min-height:1.2em;color:var(--ink-muted);font-size:var(--text-xs);font-weight:var(--weight-semibold)}.local-submit-button-status[data-tone=success]:where(.md-document,.md-document *){color:var(--success)}.local-submit-button-status[data-tone=warning]:where(.md-document,.md-document *){color:var(--warning,var(--ink-soft))}.local-submit-button-status[data-tone=error]:where(.md-document,.md-document *){color:var(--danger)}.local-submit-button-static:where(.md-document,.md-document *){padding:0 var(--space-2);border:1px solid var(--line-strong);border-radius:var(--radius-pill);color:var(--ink);font-size:var(--text-sm);font-weight:var(--weight-semibold);display:inline-block}}", w = a({
	id: "reactive-md/network",
	version: i,
	protocol: n,
	components: [v]
}), T = u(w, { "submit-button": S }, [{
	id: "reactive-md/network.css",
	css: C
}]);
export { T as default };
