import { t as e } from "./data-table-DfvytZKQ.js";
import { a as t, o as n } from "./visuals-CHB2aX3M.js";
import { o as r } from "./layout-CAWbQTHq.js";
import { t as i } from "./plugin-packs-Capd7aq4.js";
import { t as a } from "./mount-preset-CTGKvK1D.js";
import { t as o } from "./visuals-DT0qsc1V.js";
// src/components/plugins/data.ts
var s = {
	column: r,
	"data-table": e,
	table: t,
	timeline: n
}, c = i("reactive-md/data", Object.keys(s)), l = a(c, s, [{
	id: "reactive-md/visuals.css",
	css: o
}]);
export { l as default };
