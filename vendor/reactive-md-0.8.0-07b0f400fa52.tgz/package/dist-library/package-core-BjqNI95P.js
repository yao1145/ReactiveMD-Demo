import { O as e, P as t, T as n, z as r } from "./preset-core-CKc5YXSM.js";
import { f as i, i as a } from "./config-BUo-8O5C.js";
import { t as o } from "./resources-IeJomeUT.js";
import { c as s, n as c } from "./sdk-core-BJLJaVR5.js";
// src/react/package-core.ts
function l(e) {
	let t = o(e);
	if (t.diagnostics.length) throw TypeError(t.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	return t.resources;
}
function u(t) {
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("defineReactPreset requires a preset package object.");
	if (t.protocol !== "reactive-md-react-preset/v1") throw TypeError(`React preset protocol must be "${r}".`);
	let n = i(t.preset);
	if (!Array.isArray(t.components)) throw TypeError("React preset components must be an array.");
	let a = new Map(n.components.map((e) => [e.id, e])), o = /* @__PURE__ */ new Set(), s = [];
	for (let r of t.components) {
		let t = r?.definition;
		if (!t || typeof t.id != "string") throw TypeError("React preset contains a component without a manifest definition.");
		let i = a.get(t.id);
		if (!i) throw TypeError(`React preset "${n.id}" has no semantic component "${t.id}".`);
		if (e(i) !== e(t) || r.digest !== e(t)) throw TypeError(`React preset component "${t.id}" does not match its semantic manifest.`);
		if (o.has(t.id)) throw TypeError(`React preset "${n.id}" declares "${t.id}" more than once.`);
		o.add(t.id), s.push(r);
	}
	let c = n.components.filter((e) => !o.has(e.id)).map((e) => e.id);
	if (c.length > 0) throw TypeError(`React preset "${n.id}" is missing implementations for: ${c.join(", ")}.`);
	let u = t.resources === void 0 ? Object.freeze([]) : l(t.resources);
	return Object.freeze({
		protocol: r,
		preset: n,
		components: Object.freeze(s),
		resources: u,
		...t.notices === void 0 ? {} : { notices: Object.freeze([...t.notices]) }
	});
}
function d(e) {
	let { render: r, renderStatic: i, css: a, resources: o = [], ...c } = e, u = c.styles ?? [...new Set(a === void 0 ? o.map((e) => e.id) : [`${c.id}.css`, ...o.map((e) => e.id)])];
	if (a !== void 0 && u.length === 0) throw TypeError("Inline css requires a style resource identity.");
	let d = n({
		...c,
		protocol: c.protocol === void 0 ? t : c.protocol,
		form: c.form === void 0 ? "leaf" : c.form,
		props: c.props === void 0 ? {} : c.props,
		...u.length ? { styles: u } : {}
	});
	if (a !== void 0 && typeof a != "string") throw TypeError("Component css must be an inline string.");
	let f = l([...a === void 0 ? [] : [{
		id: u[0] ?? `${d.id}.css`,
		css: a
	}], ...o]);
	for (let e of d.styles ?? []) if (!f.some((t) => t.id === e)) throw TypeError(`Component ${d.id} is missing style resource ${e}.`);
	let p = s(d, {
		render: r,
		...i === void 0 ? {} : { renderStatic: i }
	});
	return Object.freeze({
		definition: d,
		components: Object.freeze([p]),
		resources: f
	});
}
function f(e, t, n, r) {
	let i = /* @__PURE__ */ new Map(), a = (e, t) => {
		let n = i.get(e.id);
		if (n !== void 0 && n !== e.css) throw TypeError(`Style resource "${e.id}" has conflicting contents in ${t}.`);
		n === void 0 && i.set(e.id, e.css);
	};
	for (let e of l(t)) a(e, "a component or preset package");
	for (let e of l(n)) a(e, "host resources");
	for (let e of r) for (let t of e.css) a(t, `theme "${e.id}"`);
	let o = [], s = /* @__PURE__ */ new Set();
	for (let t of e.registry) for (let e of t.styles ?? []) {
		if (s.has(e)) continue;
		let n = i.get(e);
		if (n === void 0) throw TypeError(`Component ${t.id} is missing style resource ${e}.`);
		s.add(e), o.push(Object.freeze({
			id: e,
			css: n
		}));
	}
	for (let e of n) {
		if (s.has(e.id)) continue;
		let t = i.get(e.id);
		s.add(e.id), o.push(Object.freeze({
			id: e.id,
			css: t
		}));
	}
	for (let e of r) for (let t of e.css) s.has(t.id) || (s.add(t.id), o.push(Object.freeze({
		id: t.id,
		css: t.css
	})));
	return Object.freeze(o);
}
function p(e, t) {
	let n = e.presets, r = (n ?? ["default"]).map((e) => e === "default" ? t.preset : e.preset), i = n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.components), o = n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.resources ?? []), s = e.packages ?? [], l = [...s.flatMap((e) => e.components), ...e.components ?? []], u = a({
		presets: r,
		components: l.map((e) => e.definition),
		...e.replacements === void 0 ? {} : { replacements: e.replacements },
		themes: [...s.flatMap((e) => e.themes ?? []), ...e.themes ?? []]
	}), d = c(u, { components: [...i, ...l] }, n === void 0 || n.includes("default") ? t.components : []), p = f(u, s.flatMap((e) => e.resources ?? []), [...o, ...e.resources ?? []], u.themes), m = Object.freeze([
		...n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.notices ?? []),
		...s.flatMap((e) => e.notices ?? []),
		...e.notices ?? []
	]);
	return Object.freeze({
		config: d.config,
		reactConfig: d,
		compileOptions: Object.freeze({ config: d.config }),
		resources: p,
		css: p.map((e) => e.css).join("\n"),
		notices: m
	});
}
export { d as n, u as r, p as t };
