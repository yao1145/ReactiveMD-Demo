import { dt as e } from "./preset-core-CKc5YXSM.js";
import { B as t, H as n, P as r, j as i } from "./config-validation-C5kJYk-J.js";
import { a, c as o, r as s, s as c, t as l } from "./compile-LhpTKqCR.js";
import { a as u, b as d, c as f, h as p, i as m, l as h, n as g, o as _, p as v, r as ee, t as y, u as b, x } from "./validation-BlDL2uD9.js";
import { i as S } from "./registry-core-Bbad9Bm2.js";
import { t as C } from "./registry-05JiqmEp.js";
import { A as te, C as ne, b as w } from "./component-state-BoLCGee4.js";
import { n as T } from "./runtime-B2fxeveq.js";
// src/local/runtime/runtime-values.ts
function E(e, t) {
	return e.attrs?.[t];
}
function D(e, t) {
	let n = E(e, t);
	if (n === "true") return !0;
	if (n === "false") return !1;
}
function O(e, t) {
	let n = E(e, t);
	if (n === void 0) return;
	let r = Number(n);
	return Number.isFinite(r) ? r : void 0;
}
function k(e) {
	return t(e);
}
function A(e, t) {
	return {
		ok: !1,
		detail: r(e, t)
	};
}
function j(e, t) {
	if (t !== void 0) return E(e, t);
}
function M(e, t) {
	if (t !== void 0) return O(e, t);
}
function N(t, n, r, i = {}) {
	for (let a of r) if (a.kind === "date") {
		if (!S(n)) return A("local.runtime.value.date-invalid");
		let e = i.required ?? (a.required !== void 0 && D(t, a.required) === !0);
		if (n === "" && e) return A("local.runtime.value.date-required");
		let r = i.min ?? j(t, a.min), o = i.max ?? j(t, a.max);
		if (n !== "" && r && n < r) return A("local.runtime.value.date-earlier", { min: r });
		if (n !== "" && o && n > o) return A("local.runtime.value.date-later", { max: o });
	} else if (a.kind === "required") {
		let e = i.required ?? D(t, a.required) === !0;
		if (n === "" && e) return A("local.runtime.value.field-required");
	} else if (a.kind === "length") {
		let e = k(n), r = M(t, a.min), i = M(t, a.max);
		if (r !== void 0 && r > 0 && n !== "" && e < r) return A("local.runtime.value.min-length", { min: r });
		if (i !== void 0 && e > i) return A("local.runtime.value.max-length", { max: i });
	} else if (a.kind === "email" && (j(t, a.type) ?? "text") === a.value && n !== "") {
		if (n.length > 254) return A("local.runtime.value.email-length", { limit: 254 });
		if (!e(n)) return A("local.runtime.value.email-invalid");
	}
	return {
		ok: !0,
		value: n
	};
}
var P = /* @__PURE__ */ new Map();
function F(e) {
	if (!e.name) return I;
	let t = P.get(e.name);
	if (t !== void 0) return t ?? I;
	let n = C(e.name), r = n ? p(n) : I;
	return P.set(e.name, n ? r : null), r;
}
var I = Object.freeze([]);
function L(e, t, n, r, a, s = !1) {
	switch (e.type) {
		case "number": {
			if (typeof n != "number" || !Number.isFinite(n)) return A("local.runtime.value.finite-number", { name: e.name });
			let i = e.step ?? 1, a = e.min ?? 0;
			for (let i of t) {
				let t = r(i, "min");
				if (t.present && !t.ok) return A("local.runtime.value.constraint", {
					name: e.name,
					attribute: "min"
				});
				if (t.present && t.ok) {
					if (typeof t.value != "number" || !Number.isFinite(t.value)) return A("local.runtime.value.constraint", {
						name: e.name,
						attribute: "min"
					});
					if (a = t.value, n < t.value) return A("local.runtime.value.min", {
						name: e.name,
						min: t.value
					});
				}
				let o = r(i, "max");
				if (o.present && !o.ok) return A("local.runtime.value.constraint", {
					name: e.name,
					attribute: "max"
				});
				if (o.present && o.ok) {
					if (typeof o.value != "number" || !Number.isFinite(o.value)) return A("local.runtime.value.constraint", {
						name: e.name,
						attribute: "max"
					});
					if (n > o.value) return A("local.runtime.value.max", {
						name: e.name,
						max: o.value
					});
				}
				if (t.present && t.ok && o.present && o.ok && typeof t.value == "number" && typeof o.value == "number" && t.value > o.value) return A("local.runtime.value.constraint-range", { name: e.name });
			}
			return e.min !== void 0 && n < e.min ? A("local.runtime.value.min", {
				name: e.name,
				min: e.min
			}) : e.max !== void 0 && n > e.max ? A("local.runtime.value.max", {
				name: e.name,
				max: e.max
			}) : i > 0 && !B(n, a, i) ? A("local.runtime.value.step", {
				name: e.name,
				step: i,
				base: a
			}) : {
				ok: !0,
				value: n
			};
		}
		case "boolean": return typeof n == "boolean" ? {
			ok: !0,
			value: n
		} : A("local.runtime.value.boolean", { name: e.name });
		case "string": {
			if (typeof n != "string") return A("local.runtime.value.string", { name: e.name });
			let c = o(n);
			if (c) return A("local.runtime.value.budget", {
				name: e.name,
				detail: i(c),
				detailKey: c.key,
				...c.params
			});
			for (let i of t) {
				let t = a?.get(i.id) ?? (s ? F(i) : I);
				if (!t.length) continue;
				let o = {};
				for (let n of t) {
					if (n.kind === "date") {
						for (let t of ["min", "max"]) {
							if (n[t] === void 0) continue;
							let a = r(i, t);
							if (a.present) {
								if (!a.ok || typeof a.value != "string" || !S(a.value)) return A("local.runtime.value.constraint-date", {
									name: e.name,
									attribute: t
								});
								o[t] = a.value;
							}
						}
						let t = o.min ?? j(i, n.min), a = o.max ?? j(i, n.max);
						if (t && a && S(t) && S(a) && t > a) return A("local.runtime.value.constraint-range", { name: e.name });
					}
					if ((n.kind === "date" || n.kind === "required" ? n.required : void 0) !== void 0) {
						let t = r(i, "required");
						if (t.present) {
							if (!t.ok || typeof t.value != "boolean") return A("local.runtime.value.constraint", {
								name: e.name,
								attribute: "required"
							});
							o.required = t.value;
						}
					}
				}
				let c = N(i, n, t, o);
				if (!c.ok) return c;
			}
			return e.options?.length && !e.options.includes(n) ? A("local.runtime.value.option", {
				value: n,
				options: e.options.join(", ")
			}) : {
				ok: !0,
				value: n
			};
		}
		case "array": {
			if (!Array.isArray(n)) return A("local.runtime.value.array", { name: e.name });
			let t = o(n);
			if (t) return A("local.runtime.value.budget", {
				name: e.name,
				detail: i(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "string") return A("local.runtime.value.array-members", { name: e.name });
			if (e.family === "collection") return e.maxItems !== void 0 && n.length > e.maxItems ? A("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
			let r = /* @__PURE__ */ new Set();
			for (let t of n) {
				if (e.options && !e.options.includes(t)) return A("local.runtime.value.checklist-option", { value: t });
				r.add(t);
			}
			let a = e.options ? e.options.filter((e) => r.has(e)) : [...r];
			return e.maxItems !== void 0 && a.length > e.maxItems ? A("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: a
			};
		}
		case "number-array": {
			if (!Array.isArray(n)) return A("local.runtime.value.number-array", { name: e.name });
			let t = o(n);
			if (t) return A("local.runtime.value.budget", {
				name: e.name,
				detail: i(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "number" || !Number.isFinite(t)) return A("local.runtime.value.number-array-members", { name: e.name });
			return e.maxItems !== void 0 && n.length > e.maxItems ? A("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
		}
		case "null": return n === null ? {
			ok: !0,
			value: n
		} : A("local.runtime.value.null", { name: e.name });
	}
	return A("local.runtime.value.unsupported-type", { name: e.name });
}
function re(e) {
	return e instanceof a ? e : new a("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function ie(e, t) {
	switch (e) {
		case "string": {
			if (typeof t != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t
			};
		}
		case "number": return typeof t == "number" && Number.isFinite(t) ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "number" }
		};
		case "boolean": return typeof t == "boolean" ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "boolean" }
		};
		case "array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			for (let e of t) if (typeof e != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		case "number-array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			for (let e of t) if (typeof e != "number" || !Number.isFinite(e)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		default: return {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: String(e) }
		};
	}
}
var R = 1e-9;
function z(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function B(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= R * Math.max(1, Math.abs(r));
}
function V(e, t, n, r) {
	let a = Math.max(0, Math.min(e.source.length, t.range.start)), o = e.source.slice(0, a).split("\n");
	return {
		code: n,
		message: i(r),
		severity: "error",
		range: {
			start: a,
			end: Math.max(a + 1, Math.min(e.source.length, t.range.end))
		},
		line: o.length,
		column: (o.at(-1) ?? "").length + 1,
		messageKey: r.key,
		...r.params ? { params: r.params } : {}
	};
}
function H(e, t, n) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1,
		...n ? {
			messageKey: n.key,
			...n.params ? { params: n.params } : {}
		} : {}
	};
}
// src/local/runtime/runtime-document.ts
function U(e, t) {
	let n = e.document.bindings[t];
	if (!n) return;
	let { nodeIds: r, owner: i, ...a } = n, o = (e.controls.get(t) ?? []).map((t) => {
		let n = e.document.dynamicConstraints?.[t.id] ?? {};
		return {
			name: t.name ?? null,
			attrs: t.attrs ?? {},
			dynamic: Object.fromEntries(Object.entries(n).map(([e, t]) => [e, t ? {
				source: t.source,
				numeric: t.numeric ?? null
			} : null])),
			rules: e.valueRules.get(t.id) ?? null
		};
	});
	return JSON.stringify({
		facts: a,
		legacy: e.legacyValueRules,
		controls: o
	});
}
function ae(e, t) {
	let n = t.get(e);
	if (n) return {
		expression: n,
		error: null
	};
	try {
		let n = l(e);
		if (t.size >= 200) {
			let e = t.keys().next().value;
			e !== void 0 && t.delete(e);
		}
		return t.set(e, n), {
			expression: n,
			error: null
		};
	} catch (e) {
		return {
			expression: null,
			error: re(e)
		};
	}
}
function oe(e, t) {
	let r = /* @__PURE__ */ new Map();
	for (let t of n(e.nodes)) r.set(t.id, t);
	let s = {}, l = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) {
		let e = o(n.initial);
		if (e) throw new a("expression-budget", `Parameter "${t}": ${i(e)}`, 0);
		s[t] = z(n.initial);
		let c = [];
		for (let e of n.nodeIds) {
			let t = r.get(e);
			t && c.push(t);
		}
		l.set(t, c);
	}
	let d = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots ?? {})) d.set(t, { ...n });
	let f = v(e), p = new Map(Object.entries(f?.valueRules ?? {})), m = f === void 0, h = /* @__PURE__ */ new Map();
	if (f) for (let e of f.slotRelations) {
		let t = d.get(e.nodeId), n = t?.[e.lower], r = t?.[e.upper];
		if (!n || !r) continue;
		let i = h.get(e.nodeId) ?? [];
		i.push({
			lower: n,
			upper: r
		}), h.set(e.nodeId, i);
	}
	else for (let [e, t] of d) t.start && t.end && h.set(e, [{
		lower: t.start,
		upper: t.end
	}]);
	let g = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) for (let e of n.nodeIds) {
		if (d.has(e)) continue;
		let n = g.get(e);
		(n === void 0 || n.startsWith("@") && !t.startsWith("@")) && g.set(e, t);
	}
	let ee = Object.freeze(Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort()), y = /* @__PURE__ */ new Map();
	for (let [e, t] of d) for (let n of Object.values(t)) {
		if (n.startsWith("@")) continue;
		let t = y.get(n) ?? /* @__PURE__ */ new Set();
		t.add(e), y.set(n, t);
	}
	let x = e.computations ?? {}, S = Object.keys(x), C = /* @__PURE__ */ new Map();
	for (let [e, n] of Object.entries(x)) {
		let r = ae(n.source, t);
		r.expression && C.set(e, r.expression);
	}
	let { order: te, cyclic: ne } = b(x), w = {}, T = /* @__PURE__ */ new Map();
	for (let e of te) {
		let t = x[e];
		if (!t || t.kind !== "const") continue;
		if (Object.hasOwn(t, "value")) {
			let n = t.value, r = c(n);
			if (r) {
				T.set(e, new a("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			w[e] = z(n);
			continue;
		}
		let n = C.get(e);
		if (!n) T.set(e, new a("expression-eval", `Constant "${e}" cannot be evaluated.`, 0));
		else try {
			let t = n.evaluate({ ...w }), r = c(t);
			if (r) {
				T.set(e, new a("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			w[e] = z(t);
		} catch (t) {
			T.set(e, re(t));
		}
	}
	let E = /* @__PURE__ */ new Map();
	for (let e of ne) E.set(e, new a("expression-cycle", `Computation "${e}" is part of a dependency cycle.`, 0));
	let D = [];
	if (Array.isArray(e.validations)) for (let n of e.validations) {
		if (!u(n)) continue;
		let e = ae(n.expression, t);
		D.push({
			rule: n,
			expression: e.expression,
			error: e.error
		});
	}
	return {
		document: e,
		nodeIndex: r,
		controls: l,
		slotKeys: d,
		publicNames: ee,
		publicSlotOwners: y,
		initial: s,
		valueRules: p,
		legacyValueRules: m,
		slotRelations: h,
		bindingByNode: g,
		computationMetadata: x,
		computationNames: S,
		computationOrder: te,
		cyclicComputations: ne,
		computationExpressions: C,
		constValues: w,
		constErrors: T,
		cycleErrors: E,
		validationRules: D,
		validationLineStarts: _(typeof e.source == "string" ? e.source : "")
	};
}
function se(e) {
	return !e || e.syntax !== "local" ? "createLocalRuntime requires a local interaction document." : e.syntaxVersion !== void 0 && e.syntaxVersion !== "local-draft-3" || e.versionDeclaration && e.versionDeclaration.version !== "local-draft-3" ? `createLocalRuntime requires ${d}; migrate the source before constructing a runtime.` : null;
}
function W(e, t) {
	return (e.controls.get(t.name) ?? [])[0] ?? (t.owner ? e.nodeIndex.get(t.owner) : void 0) ?? (t.nodeIds[0] ? e.nodeIndex.get(t.nodeIds[0]) : void 0);
}
function ce(e, t, n) {
	let r = W(e, t);
	return r ? V(e.document, r, "local.runtime.value", n) : H("local.runtime.value", i(n));
}
function G(e, t, n) {
	let r = e.slotRelations.get(t);
	return r?.length ? r.some(({ lower: e, upper: t }) => {
		let r = n[e], i = n[t];
		return typeof r == "number" && typeof i == "number" && r > i;
	}) : !1;
}
function le(e, t) {
	let n = e.nodeIndex.get(t);
	return n ? V(e.document, n, "local.runtime.value", r("local.runtime.value.range-order")) : H("local.runtime.value", i(r("local.runtime.value.range-order")));
}
// src/local/runtime/retention.ts
function K(e) {
	let t = /* @__PURE__ */ new Map();
	for (let r of n(e.nodes)) t.set(r.id, r);
	return t;
}
function ue(e, t, n) {
	let r = e.bindingSlots?.[t.id];
	return r !== void 0 && Object.values(r).includes(n);
}
function q(e, t, n) {
	let r = t.name ? C(t.name) : void 0;
	if (r?.bindings) {
		let i = e.bindingSlots?.[t.id];
		for (let [e, a] of Object.entries(r.bindings)) if (t.attrs?.[a.bind] === n || e !== "value" && i?.[e] === n) return a.retain === !1 ? void 0 : a.initial;
	} else if (t.attrs?.bind === n || ue(e, t, n)) return "initial";
}
function J(e) {
	let t = K(e), n = v(e), r = new Set(n?.retentionExclusions ?? []), i = /* @__PURE__ */ new Map();
	for (let [a, o] of Object.entries(e.bindings)) {
		let s = o.nodeIds.flatMap((e) => {
			let n = t.get(e);
			return n ? [n] : [];
		});
		if (!s.length || a.startsWith("@") || r.has(a)) continue;
		let c;
		if (n === void 0) {
			let t = s.map((t) => q(e, t, a));
			if (t.some((e) => e === void 0)) continue;
			c = t;
		} else {
			let e = n.bindingAttributes?.[a]?.initial ?? "initial";
			c = s.map(() => e);
		}
		let l = s.flatMap((e, t) => Object.hasOwn(e.attrs ?? {}, c[t]) ? [e.attrs[c[t]]] : []).sort();
		i.set(a, {
			type: o.type,
			initialDefinition: JSON.stringify([o.initial, l])
		});
	}
	return i;
}
function Y(e, t) {
	return Object.freeze({
		name: e,
		reason: t
	});
}
function X(e) {
	let t = J(e.previous), n = J(e.next), r = {}, i = [], a = [];
	for (let o of Object.keys(e.state).sort()) {
		if (o.startsWith("@")) {
			a.push(Y(o, "internal"));
			continue;
		}
		if (!Object.hasOwn(e.previous.bindings, o) || !Object.hasOwn(e.next.bindings, o)) {
			a.push(Y(o, "unknown"));
			continue;
		}
		let s = t.get(o), c = n.get(o);
		if (!s || !c) {
			a.push(Y(o, "unretainable"));
			continue;
		}
		if (s.type !== c.type) {
			a.push(Y(o, "type"));
			continue;
		}
		if (s.initialDefinition !== c.initialDefinition) {
			a.push(Y(o, "initial"));
			continue;
		}
		let l = e.state[o];
		r[o] = Array.isArray(l) ? Object.freeze([...l]) : l, i.push(o);
	}
	return Object.freeze({
		values: Object.freeze(r),
		retained: Object.freeze(i),
		dropped: Object.freeze(a)
	});
}
function Z(e, t, n) {
	return Object.freeze({
		retained: Object.freeze([...e]),
		dropped: Object.freeze(t.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...n])
	});
}
function Q(e, t) {
	let n = Object.keys(t.values).sort();
	if (!e.setParameters(t.values).length) return Z(n, t.dropped, []);
	let r = [], i = n, a = [];
	for (; i.length;) {
		let n = [];
		a = [];
		for (let o of i) {
			let i = e.setParameter(o, t.values[o]);
			i.length ? (n.push(o), a.push(...i)) : r.push(o);
		}
		if (n.length === i.length) break;
		i = n;
	}
	r.sort();
	let o = [...t.dropped, ...i.map((e) => Y(e, "invalid"))];
	return o.sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name)), Z(r, o, a);
}
// src/local/runtime/runtime-migration.ts
function de(e, t, n, r, i) {
	let a = X({
		previous: e.document,
		state: t,
		next: n
	}), o = {};
	for (let [e, t] of Object.entries(n.bindings)) o[e] = z(t.initial);
	let s = /* @__PURE__ */ new Map();
	for (let e of a.dropped) s.set(e.name, Object.freeze({ ...e }));
	let c = [], l = {}, u = [], d = /* @__PURE__ */ new Set(), f, p = (n) => {
		let o = e.document.bindings[n], s = e.controls.get(n) ?? [];
		return !o || !s.some((t) => e.document.dynamicConstraints?.[t.id]) || (f ??= i({}, e, t), L(o, s, a.values[n], f, e.valueRules, e.legacyValueRules).ok) ? !1 : U(e, n) === U(r, n);
	};
	for (let e of a.retained) {
		let t = n.bindings[e];
		if (!t) continue;
		if (p(e)) {
			d.add(e), l[e] = z(a.values[e]), u.push(e);
			continue;
		}
		let f = L(t, r.controls.get(e) ?? [], a.values[e], i(a.values, r, o), r.valueRules, r.legacyValueRules);
		f.ok ? (l[e] = z(f.value), u.push(e)) : (c.push(ce(r, t, f.detail)), s.set(e, Object.freeze({
			name: e,
			reason: "invalid"
		})));
	}
	let m = {
		...o,
		...l
	}, h = /* @__PURE__ */ new Set();
	for (let e of u) for (let t of r.publicSlotOwners.get(e) ?? []) h.add(t);
	let g = !1;
	for (let e of [...h].sort()) if (G(r, e, m)) {
		g = !0;
		break;
	}
	let _;
	if (!g) Object.assign(o, l), _ = u;
	else {
		_ = [];
		for (let e of u) {
			let t = o[e];
			o[e] = l[e];
			let n = !1;
			for (let t of [...r.publicSlotOwners.get(e) ?? []].sort()) G(r, t, o) && (c.push(le(r, t)), n = !0);
			n ? (o[e] = t, s.set(e, Object.freeze({
				name: e,
				reason: "invalid"
			}))) : _.push(e);
		}
	}
	for (let [e, t] of r.slotRelations) if (G(r, e, o)) {
		for (let e of t) for (let t of [e.lower, e.upper]) {
			let e = n.bindings[t];
			if (!e) continue;
			o[t] = z(e.initial);
			let r = _.indexOf(t);
			r >= 0 && _.splice(r, 1), s.set(t, Object.freeze({
				name: t,
				reason: "invalid"
			}));
		}
		if (c.push(le(r, e)), G(r, e, o)) return {
			values: {},
			retained: [],
			dropped: [],
			diagnostics: []
		};
	}
	let v = !0;
	for (; v;) {
		let e = i({}, r, o), t = [];
		for (let i of _) {
			if (d.has(i)) continue;
			let a = n.bindings[i], s = L(a, r.controls.get(i) ?? [], o[i], e, r.valueRules, r.legacyValueRules);
			s.ok || (c.push(ce(r, a, s.detail)), t.push(i));
		}
		for (let e of t) o[e] = z(n.bindings[e].initial), _.splice(_.indexOf(e), 1), s.set(e, Object.freeze({
			name: e,
			reason: "invalid"
		}));
		v = t.length > 0;
	}
	let ee = [...s.values()].sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name));
	return _.sort(), {
		values: o,
		retained: _,
		dropped: ee,
		diagnostics: c
	};
}
// src/local/runtime/runtime.ts
function fe(e) {
	return {
		...e,
		range: { ...e.range }
	};
}
function pe(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => e === t[n]) : e === t;
}
function me(e) {
	for (let [t, n] of Object.entries(e)) Array.isArray(n) && !Object.isFrozen(n) && (e[t] = Object.freeze([...n]));
	return Object.freeze(e);
}
var he = /* @__PURE__ */ new WeakMap();
function $(e) {
	return Object.freeze({
		ok: e.ok,
		changed: e.changed,
		revision: e.revision,
		retained: Object.freeze([...e.retained]),
		dropped: Object.freeze(e.dropped.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...e.diagnostics])
	});
}
function ge(e, t, n) {
	let r = he.get(e);
	if (!r) throw TypeError("updateLocalRuntime requires a runtime created by createLocalRuntime.");
	return r.update(t, n?.notify !== !1);
}
function _e(e) {
	he.get(e)?.notify();
}
function ve(e, t, n) {
	return he.get(e)?.bindNetworkExternals(t, n) ?? (() => {});
}
function ye(e, t) {
	let c = se(e);
	if (c) throw Error(c);
	let u = t?.services === void 0, d = te(t?.network), p = /* @__PURE__ */ new Map(), _ = ne(e.source), v = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Map(), S = oe(e, b), C = () => S, E = () => {
		let e = /* @__PURE__ */ new Set();
		for (let r of n(S.document.nodes)) r.name !== void 0 && e.add(w({
			documentId: t?.documentId,
			sourceDigest: _,
			nodeId: r.id,
			stateKey: r.attrs?.["state-key"]
		}));
		return e;
	}, D = t?.services ?? T({
		documentId: t?.documentId,
		sourceDigest: _,
		randomSeed: t?.randomSeed,
		componentState: t?.componentState,
		...t?.componentStateStorage === void 0 ? {} : { componentStateStorage: t.componentStateStorage },
		...t?.componentStateWriteDelayMs === void 0 ? {} : { componentStateWriteDelayMs: t.componentStateWriteDelayMs },
		...t?.configKey === void 0 ? {} : { configKey: t.configKey },
		...t?.legacyConfigKeys === void 0 ? {} : { legacyConfigKeys: t.legacyConfigKeys },
		...u ? { knownStateKeys: E } : {}
	}), O = {}, k = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e.externals ?? {})) {
		let e = t?.externalValues?.[n];
		if (e === void 0) continue;
		let i = ie(r.type, e);
		i.ok && (O[n] = i.value);
	}
	let A = (e, t) => {
		let n = {};
		for (let [r, i] of Object.entries(e.document.externals ?? {})) {
			if (!Object.hasOwn(t, r)) continue;
			let e = ie(i.type, t[r]);
			e.ok && (n[r] = e.value);
		}
		return n;
	}, j = (e) => {
		let t = A(e, O);
		for (let n of k.keys()) Object.assign(t, A(e, n));
		return t;
	}, M = (e, t, n, r = C()) => {
		let i = r.document.dynamicConstraints?.[e.id]?.[t];
		if (!i) return { present: !1 };
		let a = ae(i.source, b);
		if (!a.expression) return {
			present: !0,
			ok: !1
		};
		try {
			let e = a.expression.evaluate(n), t = i.numeric;
			return t && (typeof e != "number" || !Number.isFinite(e) || t.integer === !0 && !Number.isInteger(e) || t.min !== void 0 && e < t.min || t.max !== void 0 && e > t.max) ? {
				present: !0,
				ok: !1
			} : {
				present: !0,
				ok: !0,
				value: e
			};
		} catch {
			return {
				present: !0,
				ok: !1
			};
		}
	}, N = S.initial, P = 0, F = {}, I = {}, re = {
		revision: 0,
		state: me({})
	}, R = !1, B = null, U = /* @__PURE__ */ new Set(), W = /* @__PURE__ */ new Map(), K = () => {
		if (R) throw Error("The local interaction runtime has been disposed.");
	};
	function ue(e, t) {
		if (!t.startsWith("@") && Object.hasOwn(e.document.bindings, t)) return Object.hasOwn(N, t) ? N[t] : void 0;
	}
	let q = (e, t) => {
		let n = j(e), r = /* @__PURE__ */ new Map();
		for (let t of Object.keys(e.document.externals ?? {})) Object.hasOwn(n, t) || r.set(t, new a("external-missing", "External data \"" + t + "\" is not available.", 0));
		let i = {}, o = /* @__PURE__ */ new Map();
		if (e.computationNames.length > 0) {
			let a = h(e.computationMetadata, e.computationOrder, e.computationExpressions, {
				...t,
				...n
			}, e.constValues, r);
			i = a.values, o = a.errors;
			for (let [t, n] of e.constErrors) Object.hasOwn(i, t) || o.set(t, n);
			for (let [t, n] of e.cycleErrors) Object.hasOwn(i, t) || o.set(t, n);
		}
		let s = {};
		for (let [e, n] of Object.entries(t)) s[e] = n;
		for (let [e, t] of Object.entries(n)) s[e] = t;
		for (let [e, t] of Object.entries(i)) s[e] = t;
		for (let [e, t] of [...r, ...o]) Object.hasOwn(i, e) || Object.defineProperty(s, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw t;
			}
		});
		let c = {};
		for (let [e, n] of Object.entries(t)) c[e] = n;
		for (let [e, t] of Object.entries(n)) c[e] = t;
		for (let [e, t] of Object.entries(i)) c[e] = t;
		return {
			environment: s,
			snapshotState: c
		};
	}, J = () => {
		let e = q(C(), N);
		F = e.environment, I = e.snapshotState;
	}, Y = (e, t = C(), n = N) => {
		let r;
		return (i, a) => t.document.dynamicConstraints?.[i.id]?.[a] ? (r ??= q(t, {
			...n,
			...e
		}).environment, M(i, a, r, t)) : { present: !1 };
	}, X = () => {
		re = {
			revision: P,
			state: me(I)
		};
	}, Z = () => {
		for (let e of U) e();
	}, Q = (e) => {
		N = e, P += 1, J(), X(), Z();
	}, ge = () => {
		P += 1, J(), X(), Z();
	}, _e = (e, t = O) => {
		if (K(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setExternalValues requires an object of external values.");
		let n = [], a = {}, o = Object.keys(e).sort();
		for (let t of o) {
			if (t === "__proto__") {
				n.push(H("local.runtime.external", "External names cannot be \"__proto__\"."));
				continue;
			}
			let o = C().document.externals ?? {}, s = Object.hasOwn(o, t) ? o[t] : void 0;
			if (!s) {
				let e = r("local.runtime.external", { name: t });
				n.push(H("local.runtime.external", i(e), e));
				continue;
			}
			let c = ie(s.type, e[t]);
			if (c.ok) a[t] = c.value;
			else {
				let e = r(c.key, {
					name: t,
					...c.params ?? {}
				});
				n.push(H("local.runtime.external", i(e), e));
			}
		}
		return n.length ? n : (o.some((e) => !pe(t[e], a[e])) && (Object.assign(t, a), ge()), []);
	}, ve = (e, t) => {
		if (R) return () => {};
		let n = {}, r = e.bindExternalValues((e) => {
			if (R || !k.has(n)) return;
			let r = _e(e, n);
			r.length && t?.(r);
		});
		return r ? (k.set(n, r), () => {
			k.delete(n) && (r(), !R && Object.keys(n).length && ge());
		}) : () => {};
	}, ye = (e) => {
		K();
		let t = C(), n = [], r = {}, i = Object.keys(e).sort(), a = Y(e);
		for (let o of i) {
			if (o === "__proto__") {
				n.push(H("local.runtime.parameter", "Parameter names cannot be \"__proto__\"."));
				continue;
			}
			if (o.startsWith("@")) {
				n.push(H("local.runtime.parameter", `Internal parameter "${o}" cannot be written by name.`));
				continue;
			}
			if (!Object.hasOwn(t.document.bindings, o)) {
				n.push(H("local.runtime.parameter", `Unknown parameter "${o}".`));
				continue;
			}
			let i = t.document.bindings[o], s = L(i, t.controls.get(o) ?? [], e[o], a, t.valueRules, t.legacyValueRules);
			s.ok ? r[o] = z(s.value) : n.push(ce(t, i, s.detail));
		}
		if (n.length) return n;
		if (!i.some((e) => !pe(N[e], r[e]))) return [];
		let o = {
			...N,
			...r
		}, s = /* @__PURE__ */ new Set();
		for (let e of i) for (let n of t.publicSlotOwners.get(e) ?? []) s.add(n);
		for (let e of [...s].sort()) G(t, e, o) && n.push(le(t, e));
		return n.length ? n : (Q(o), []);
	}, be = (e) => {
		let t = v.get(e);
		if (!t) {
			if (t = l(e), v.size >= 200) {
				let e = v.keys().next().value;
				e !== void 0 && v.delete(e);
			}
			v.set(e, t);
		}
		return t;
	}, xe = () => {
		let e = C(), t = [], n = typeof e.document.source == "string" ? e.document.source : "";
		for (let r of e.validationRules) {
			if (r.error) {
				t.push(f(n, e.validationLineStarts, r.rule.range, y, m(`Validation expression is invalid: ${r.error.message}`)));
				continue;
			}
			if (!r.expression) continue;
			let i;
			try {
				i = r.expression.evaluate(F);
			} catch (i) {
				t.push(f(n, e.validationLineStarts, r.rule.range, y, m(`Validation expression failed: ${i instanceof Error ? i.message : String(i)}`)));
				continue;
			}
			typeof i == "boolean" ? i || t.push(f(n, e.validationLineStarts, r.rule.range, g, Se(r.rule.message))) : t.push(f(n, e.validationLineStarts, r.rule.range, y, "Validation expression must evaluate to a boolean."));
		}
		return t;
	}, Se = (e) => {
		let t;
		try {
			t = s(e, F);
		} catch {
			t = ee;
		}
		return m(t);
	}, Ce = (e, t) => {
		if (K(), e === S.document) return $({
			ok: !0,
			changed: !1,
			revision: P,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		if (se(e)) return $({
			ok: !1,
			changed: !1,
			revision: P,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let n;
		try {
			n = oe(e, b);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: P,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let r = de(S, N, e, n, Y);
		if (Object.keys(r.values).length === 0 && Object.keys(e.bindings).length > 0) return $({
			ok: !1,
			changed: !1,
			revision: P,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let i;
		try {
			i = q(n, r.values);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: P,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		for (let e of [O, ...k.keys()]) {
			let t = A(n, e);
			for (let t of Object.keys(e)) delete e[t];
			Object.assign(e, t);
		}
		if (S = n, N = r.values, F = i.environment, I = i.snapshotState, B = null, P += 1, X(), t) for (let e of U) e();
		return $({
			ok: !0,
			changed: !0,
			revision: P,
			retained: r.retained,
			dropped: r.dropped,
			diagnostics: r.diagnostics
		});
	}, we = (e) => {
		let t = /* @__PURE__ */ new Set();
		for (let r of n([e])) t.add(r.id);
		return t;
	}, Te = {
		network: d.network,
		get document() {
			return S.document;
		},
		services: D,
		snapshot() {
			return K(), re;
		},
		get(e, t) {
			K();
			let n = C(), r = n.nodeIndex.get(e.id);
			if (!r) return null;
			let i = t === void 0 ? n.slotKeys.get(r.id)?.value ?? n.bindingByNode.get(r.id) ?? x(r) : n.slotKeys.get(r.id)?.[t];
			return i && Object.hasOwn(N, i) ? z(N[i]) : null;
		},
		set(e, t, n) {
			K();
			let i = C(), a = i.nodeIndex.get(e.id);
			if (!a) return [V(i.document, e, "local.runtime.binding", r("local.runtime.binding.no-writable"))];
			let o = i.slotKeys.get(a.id), s;
			if (n === void 0) {
				if (o && !o.value) return [V(i.document, a, "local.runtime.binding", r("local.runtime.binding.needs-slot"))];
				s = o?.value ?? i.bindingByNode.get(a.id) ?? x(a);
			} else if (s = o?.[n], !s) return [V(i.document, a, "local.runtime.binding", r("local.runtime.binding.unknown-slot", { slot: n }))];
			let c = Object.hasOwn(i.document.bindings, s) ? i.document.bindings[s] : void 0;
			if (!c) return [V(i.document, a, "local.runtime.binding", r("local.runtime.binding.no-writable"))];
			let l = L(c, i.controls.get(s) ?? [], t, Y({ [s]: t }), i.valueRules, i.legacyValueRules);
			if (!l.ok) return [V(i.document, a, "local.runtime.value", l.detail)];
			let u = z(l.value);
			if (pe(N[s], u)) return [];
			let d = {
				...N,
				[s]: u
			};
			return G(i, a.id, d) ? [V(i.document, a, "local.runtime.value", r("local.runtime.value.range-order"))] : (Q(d), []);
		},
		setMany(e, t) {
			K();
			let n = C(), i = n.nodeIndex.get(e.id);
			if (!i) return [V(n.document, e, "local.runtime.binding", r("local.runtime.binding.no-writable"))];
			let a = n.slotKeys.get(i.id);
			if (!a) return [V(n.document, i, "local.runtime.binding", r("local.runtime.binding.no-multi-slot"))];
			let o = Object.entries(t);
			if (!o.length) return [];
			let s = { ...N }, c = q(n, {
				...N,
				...Object.fromEntries(o.map(([e, t]) => [a[e], t]))
			}).environment;
			for (let [e, t] of o) {
				let o = a[e];
				if (!o || !Object.hasOwn(n.document.bindings, o)) return [V(n.document, i, "local.runtime.binding", r("local.runtime.binding.unknown-slot", { slot: e }))];
				let l = L(n.document.bindings[o], n.controls.get(o) ?? [], t, (e, t) => M(e, t, c), n.valueRules, n.legacyValueRules);
				if (!l.ok) return [V(n.document, i, "local.runtime.value", l.detail)];
				s[o] = z(l.value);
			}
			return G(n, i.id, s) ? [V(n.document, i, "local.runtime.value", r("local.runtime.value.range-order"))] : (o.every(([e, t]) => pe(N[a[e]], t)) || Q(s), []);
		},
		parameterNames() {
			return K(), C().publicNames;
		},
		getParameter(e) {
			K();
			let t = ue(C(), e);
			return t === void 0 ? void 0 : z(t);
		},
		getParameters() {
			K();
			let e = C(), t = {};
			for (let n of e.publicNames) {
				let e = N[n];
				t[n] = Array.isArray(e) ? Object.freeze([...e]) : e;
			}
			return Object.freeze(t);
		},
		readSubmissionFields(e) {
			K();
			let t = C(), n = /* @__PURE__ */ new Map(), r = (e, n) => M(e, n, F, t);
			if (e.length === 0) return {
				ok: !1,
				field: "",
				reason: "unavailable"
			};
			for (let i of e) {
				let e = ue(t, i);
				if (e === void 0 || n.has(i)) return {
					ok: !1,
					field: i,
					reason: "unavailable"
				};
				let a = L(t.document.bindings[i], t.controls.get(i) ?? [], e, r, t.valueRules, t.legacyValueRules);
				if (!a.ok) {
					let e = a.detail.key;
					return {
						ok: !1,
						field: i,
						reason: e === "local.runtime.value.field-required" || e === "local.runtime.value.date-required" ? "required" : "invalid"
					};
				}
				n.set(i, e);
			}
			let i = Object.create(null);
			for (let [e, r] of n) {
				for (let [n, i] of p.get(e) ?? []) {
					if (!t.controls.get(e)?.some((e) => e.id === i)) continue;
					let a = n(z(r));
					if (a) return {
						ok: !1,
						field: e,
						reason: a
					};
				}
				i[e] = Array.isArray(r) ? Object.freeze([...r]) : r;
			}
			return {
				ok: !0,
				payload: Object.freeze(i)
			};
		},
		registerSubmissionField(e, t) {
			if (R) return () => {};
			let n = C(), r = n.slotKeys.get(e.id)?.value ?? n.bindingByNode.get(e.id);
			if (!r || r.startsWith("@")) return () => {};
			let i = p.get(r);
			return i || p.set(r, i = /* @__PURE__ */ new Map()), i.set(t, e.id), () => {
				i.delete(t), i.size === 0 && p.get(r) === i && p.delete(r);
			};
		},
		setParameter(e, t) {
			K();
			let n = Object.create(null);
			return n[e] = t, ye(n);
		},
		setParameters(e) {
			if (K(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setParameters requires an object of parameter values.");
			return ye(e);
		},
		getExternal(e) {
			if (K(), Object.hasOwn(C().document.externals ?? {}, e) && Object.hasOwn(I, e)) return z(I[e]);
		},
		getExternalValues() {
			K();
			let e = {};
			for (let [t, n] of Object.entries(j(C()))) e[t] = Array.isArray(n) ? Object.freeze([...n]) : n;
			return Object.freeze(e);
		},
		setExternalValues(e) {
			return _e(e);
		},
		evaluate(e) {
			K();
			let t = be(e).evaluate(F);
			return Array.isArray(t) ? t.slice() : t;
		},
		validate() {
			if (K(), B && B.revision === P) return B.diagnostics.map(fe);
			let e = xe();
			return B = {
				revision: P,
				diagnostics: e
			}, e.map(fe);
		},
		text(e) {
			return K(), s(e, F);
		},
		reset(e) {
			K();
			let t = C(), n = t.nodeIndex.get(e.id);
			if (!n) return;
			let r = we(n), s = { ...N };
			for (let [e, n] of Object.entries(t.document.bindings)) {
				if (!(t.controls.get(e) ?? []).some((e) => r.has(e.id))) continue;
				let c = o(n.initial);
				if (c) throw new a("expression-budget", `Parameter "${e}": ${i(c)}`, 0);
				s[e] = z(n.initial);
			}
			for (let e of r) W.set(e, (W.get(e) ?? 0) + 1);
			Q(s);
		},
		resetToken(e) {
			K();
			let t = C().nodeIndex.get(e.id);
			return t ? W.get(t.id) ?? 0 : 0;
		},
		subscribe(e) {
			return K(), U.add(e), () => {
				U.delete(e);
			};
		},
		dispose() {
			if (!R) {
				R = !0, d.dispose();
				for (let e of k.values()) e();
				k.clear(), p.clear(), D.state.flush(), u && D.scheduler.dispose(), U.clear(), v.clear(), b.clear(), S.computationExpressions.clear(), S.constErrors.clear(), S.cycleErrors.clear(), S.validationRules.length = 0, W.clear();
			}
		}
	};
	return he.set(Te, {
		update: Ce,
		bindNetworkExternals: ve,
		notify() {
			if (!R) for (let e of U) e();
		}
	}), J(), X(), ve(d), Te;
}
export { Q as a, ge as i, ye as n, X as o, _e as r, ve as t };
