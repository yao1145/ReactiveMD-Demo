import { M as e, w as t } from "./config-validation-C5kJYk-J.js";
import { s as n } from "./config-BUo-8O5C.js";
import { n as r, t as ee } from "./options-CdSKOi7p.js";
import { n as te } from "./incremental-D_6vwAAE.js";
import { i as ne, n as re, r as ie } from "./runtime-CuOyRe9f.js";
import { a as ae, c as oe, i as se, l as i, n as ce, o as le, r as ue, s as de, t as fe } from "./LocalDocumentViewCore-BLG4hMuO.js";
import { useCallback as a, useEffect as o, useMemo as s, useRef as c } from "react";
import { jsx as l, jsxs as u } from "react/jsx-runtime";
// src/local/rendering/document/LocalReactiveDocumentCore.tsx
var pe = Symbol("implicit document identity");
function d({ source: d, onDiagnostics: me, urlPolicy: he, locale: f = "en", themes: ge, colorScheme: _e = "auto", mode: p = "interactive", staticFirst: ve = !1, imageResolver: ye, hostData: be, hostRenderer: m, reactConfig: h, useBaseCompileConfig: xe, externalValues: g, network: Se, documentId: _, randomSeed: v, componentState: y, componentStateStorage: b, componentStateWriteDelayMs: x, onComponentStateChange: S, initialParameters: C, onParametersChange: w, onSourceNavigate: Ce, compileOptions: T, getBaseConfig: E }) {
	if (oe(h, {
		hostData: be,
		hostRenderer: m,
		themes: ge
	}), h !== void 0) {
		let e = T?.config;
		if (e !== void 0 && e !== h.config) {
			let t = !1;
			try {
				t = n(e).key === h.config.key;
			} catch {
				t = !1;
			}
			if (!t) throw Error("reactConfig and compileOptions.config must be the same local config.");
		}
		if (T?.hostComponents !== void 0) throw Error("reactConfig cannot be combined with compileOptions.hostComponents.");
	}
	let D = h === void 0 && xe ? E() : void 0, we = D !== void 0 && T?.config === void 0 && T?.hostComponents === void 0, O = h === void 0 ? we ? {
		...T ?? {},
		config: D.config
	} : T : {
		...T ?? {},
		config: h.config
	}, k = h?.themes ?? ge ?? D?.themes, A = ee(O), j = `${A}|${_ ?? ""}|${v ?? ""}`, M = c(g);
	M.current = g;
	let N = c(_);
	N.current = _;
	let P = c(v);
	P.current = v;
	let F = c(y);
	F.current = y;
	let I = c(b);
	I.current = b;
	let L = c(x);
	L.current = x;
	let R = c(S);
	R.current = S;
	let z = c(C);
	z.current = C;
	let B = c(w);
	B.current = w;
	let Te = c([]), Ee = O?.config, De = Ee?.key, Oe = Ee?.legacyKeys.map((e) => e.key) ?? [], ke = (e) => {
		let t = re(e, {
			externalValues: M.current,
			documentId: N.current,
			randomSeed: P.current,
			componentState: F.current,
			...I.current === void 0 ? {} : { componentStateStorage: I.current },
			...L.current === void 0 ? {} : { componentStateWriteDelayMs: L.current },
			...(De ?? e.componentConfigKey) === void 0 ? {} : { configKey: De ?? e.componentConfigKey },
			...Oe.length === 0 ? {} : { legacyConfigKeys: Oe }
		}), n = z.current;
		return Te.current = n && Object.keys(n).length ? t.setParameters(ue(n)) : [], t;
	}, V = c(null), H = c(null), U = s(() => {
		V.current && H.current === A || (V.current?.dispose(), V.current = te(), H.current = A);
		let e = V.current;
		return typeof e.compileShared == "function" ? e.compileShared(d, O) : e.compile(d, O);
	}, [d, A]), W = c(null), G = c(null), K = c([]), q = c(!1), J = W.current;
	if (!U.ok) J = null;
	else {
		let e = U.document;
		if (J && G.current !== j) {
			try {
				J.services?.state.flush();
			} catch {}
			K.current.push(J), J = null, W.current = null;
		}
		if (!J) {
			try {
				J = ke(e);
			} catch {
				J = null;
			}
			W.current = J;
		} else if (J.document !== e) {
			let t = !1;
			try {
				let n = ne(J, e, { notify: !1 });
				t = n.ok, n.ok && n.changed && (q.current = !0);
			} catch {
				t = !1;
			}
			if (!t) {
				try {
					J.services?.state.flush();
				} catch {}
				K.current.push(J);
				let t = null;
				try {
					t = ke(e);
				} catch {
					t = null;
				}
				J = t, W.current = t;
			}
		}
		G.current = j;
	}
	let Ae = c(me);
	Ae.current = me;
	let Y = c(0), je = de(k), Me = s(() => {
		if (!U.ok) return [];
		try {
			return t(U.document.theme, k, U.document.themeRange, U.document.source).diagnostics;
		} catch {
			return [];
		}
	}, [U, je]), Ne = c(null), Pe = a((e) => {
		let t = ae(e);
		t !== Ne.current && (Ne.current = t, Ae.current?.(e));
	}, []), X = c([]), Z = c([]), Q = a(() => {
		Pe(se(U.diagnostics, Me, Te.current, X.current, Z.current));
	}, [
		U,
		Me,
		Pe
	]), $ = c(Q);
	$.current = Q, o(() => {
		let e = J?.services, t = e === void 0 ? [] : e.state.diagnostics(), n = Z.current;
		t.length === n.length && t.every((e, t) => e === n[t]) || (Z.current = [...t], $.current());
	}), o(() => {
		X.current = [];
	}, [U]), o(() => {
		Q();
	}, [Q]);
	let Fe = a((e) => {
		X.current = e, $.current();
	}, []);
	if (o(() => {
		if (!J) return;
		$.current();
		let e = !0, t;
		try {
			t = J.getParameters();
		} catch {
			return;
		}
		let n = () => {};
		try {
			n = J.subscribe(() => {
				if (!e) return;
				let n, r;
				try {
					n = J.getParameters(), r = J.snapshot();
				} catch {
					return;
				}
				if (!le(t, n)) {
					t = n;
					try {
						B.current?.(n, r);
					} catch {}
				}
			});
		} catch {
			return;
		}
		return () => {
			e = !1, n();
		};
	}, [J]), o(() => (Y.current += 1, () => {
		--Y.current, queueMicrotask(() => {
			if (Y.current !== 0) return;
			let e = W.current;
			W.current = null;
			try {
				e?.dispose();
			} catch {}
			try {
				V.current?.dispose();
			} catch {}
			V.current = null, H.current = null;
		});
	}), []), o(() => {
		let e = K.current;
		K.current = [];
		for (let t of e) queueMicrotask(() => {
			if (W.current !== t) try {
				t.dispose();
			} catch {}
		});
		if (!U.ok || !J) {
			let e = W.current;
			e && (W.current = null, G.current = null, queueMicrotask(() => {
				if (W.current !== e) try {
					e.dispose();
				} catch {}
			})), V.current && (V.current.dispose(), V.current = null, H.current = null);
		}
		if (q.current) {
			q.current = !1;
			let e = W.current;
			e && ie(e);
		}
	}), o(() => {
		let e = J?.services;
		if (e && S !== void 0) return e.state.subscribe(() => {
			R.current?.(e.state.snapshot());
		});
	}, [J, S]), o(() => {
		let e = J?.services?.state;
		if (e === void 0) return;
		let t = () => e.flush(), n = () => {
			document.visibilityState === "hidden" && t();
		};
		return window.addEventListener("pagehide", t), document.addEventListener("visibilitychange", n), () => {
			window.removeEventListener("pagehide", t), document.removeEventListener("visibilitychange", n);
		};
	}, [J]), !U.ok || !J) {
		let t = r(O);
		return typeof d == "string" && t.ok && t.htmlActive ? /* @__PURE__ */ l(ce, {
			source: d,
			mode: p
		}) : /* @__PURE__ */ u("div", {
			className: `md-document local-document local-inactive${p === "static" ? " local-static" : ""}`,
			"data-render-mode": p,
			role: "alert",
			children: [/* @__PURE__ */ l("p", {
				className: "local-inactive-title",
				children: U.ok ? i(f, "Interactive initialization failed; preview is disabled.", "交互初始化失败，预览已停用。") : i(f, "The document contains syntax errors; interactive preview is disabled.", "文档包含语法错误，交互预览已停用。")
			}), U.diagnostics.length ? /* @__PURE__ */ l("ul", {
				className: "local-inactive-list",
				children: U.diagnostics.map((t, n) => /* @__PURE__ */ u("li", { children: [e(t, f), i(f, ` (line ${t.line}, column ${t.column})`, `（第 ${t.line} 行，第 ${t.column} 列）`)] }, `${t.code}-${n}`))
			}) : null]
		});
	}
	return /* @__PURE__ */ l(fe, {
		document: U.document,
		runtime: J,
		network: Se,
		networkScope: _ ?? pe,
		onDiagnostics: Fe,
		urlPolicy: he,
		locale: f,
		themes: h === void 0 ? k : void 0,
		colorScheme: _e,
		mode: p,
		staticFirst: ve,
		imageResolver: ye,
		hostData: be,
		hostRenderer: m,
		reactConfig: h,
		getBaseConfig: E,
		externalValues: g,
		onSourceNavigate: Ce
	}, A);
}
export { d as t };
