import { b as e, g as t, y as n } from "./validation-BEBA_HvS.js";
import { t as r } from "./parser-standard-Yuf3A_VI.js";
import i from "./reactive-md-default-preset.js";
import { a, o, s } from "./config-BadfhjdP.js";
import { n as c } from "./registry-B9NGct4d.js";
// src/local/configuration/options.ts
function l(e) {
	return n(e, {
		defaults: c(),
		preset: {
			id: i.id,
			version: i.version
		},
		defaultConfigKey: a(),
		readConfig: (e) => s(e),
		configKey: (e) => a(e),
		capabilities: r
	});
}
function u(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var d = 256, f = 4096, p = /* @__PURE__ */ new WeakMap(), m = /* @__PURE__ */ new Map(), h = /* @__PURE__ */ new WeakMap(), g = 0;
function _() {
	return g += 1, g;
}
function v(e) {
	if (typeof e == "object" && e || typeof e == "function") {
		let t = e, n = h.get(t);
		return n === void 0 && (n = _(), h.set(t, n)), `unreadable#${n}`;
	}
	return `unreadable:${typeof e}:${String(e)}`;
}
function y(e) {
	let t = [], n = 0, r = (e) => {
		if (n += 1, n > f) throw RangeError("signature budget");
		switch (typeof e) {
			case "string": return `s${JSON.stringify(e)}`;
			case "number": return `n${Object.is(e, -0) ? "-0" : String(e)}`;
			case "boolean": return e ? "b1" : "b0";
			case "undefined": return "u";
			case "bigint": return `g${e.toString()}`;
			case "symbol": {
				let t = m.get(e);
				return t === void 0 && (t = _(), m.set(e, t)), `y${t}`;
			}
			case "function": {
				let t = p.get(e);
				return t === void 0 && (t = _(), p.set(e, t)), `f${t}`;
			}
		}
		if (e === null) return "null";
		let i = e, a = t.indexOf(i);
		if (a >= 0) return `r${a}`;
		t.push(i);
		try {
			if (Array.isArray(i)) {
				let e = Math.min(i.length, 8);
				if (i.length > d) {
					let t = `a#${i.length}[`;
					for (let n = 0; n < e; n += 1) t += `${r(i[n])},`;
					return `${t}]`;
				}
				let t = `a${i.length}[`;
				for (let e = 0; e < i.length; e += 1) t += `${r(i[e])},`;
				return `${t}]`;
			}
			let e = Object.keys(i);
			if (e.length > d) {
				let t = `o#${e.length}{`;
				for (let n of e.slice(0, 8)) t += `${r(n)},`;
				return `${t}}`;
			}
			e.sort();
			let t = "o{";
			for (let n of e) t += `${r(n)}:${r(i[n])},`;
			return `${t}}`;
		} finally {
			t.pop();
		}
	};
	try {
		return r(e);
	} catch {
		return v(e);
	}
}
function b(e) {
	return S(e, !0);
}
function x(e) {
	return S(e, !1);
}
function S(n, r) {
	if (n === void 0 && (n = {}), !u(n)) return "invalid";
	let i = r ? t.map((t) => {
		let r = Object.hasOwn(n, t) ? n[t] : void 0;
		return r === void 0 ? e[t] ? "1" : "0" : r === !0 ? "1" : r === !1 ? "0" : "!";
	}).join("") : "", a = "";
	if (Object.hasOwn(n, "limits")) {
		let e = n.limits;
		if (e === void 0) a = "default";
		else if (!u(e)) a = "invalid";
		else {
			let t = (t) => !Object.hasOwn(e, t) || e[t] === void 0 ? "default" : String(e[t]);
			a = `${t("maxSyntaxNodes")}:${t("maxParseWork")}:${t("maxMarkdownDepth")}`;
		}
	}
	let s = "";
	if (Object.hasOwn(n, "hostComponents") && n.hostComponents !== void 0) {
		let e = n.hostComponents;
		try {
			Array.isArray(e) ? e.length > 0 && (s = e.length > 32 ? `:hosts=oversize:${e.length}` : `:hosts=${y(e)}`) : s = `:hosts=${y(e)}`;
		} catch {
			s = `:hosts=${v(e)}`;
		}
	}
	let c = !Object.hasOwn(n, "markdownBreaks") || n.markdownBreaks === void 0 ? "-" : n.markdownBreaks === !0 ? "1" : n.markdownBreaks === !1 ? "0" : "!", l = !Object.hasOwn(n, "strict") || n.strict === void 0 || n.strict === !0 ? "strict=1" : n.strict === !1 ? "strict=0:recovery=2" : "strict=!", d = "";
	return Object.hasOwn(n, "config") && n.config !== void 0 && (d = `:config=${o(n.config)}`), `${i}:${a}:${c}:${l}${s}${d}`;
}
export { x as n, l as r, b as t };
