import { dt as e } from "./preset-core-CKc5YXSM.js";
import { B as t, H as n, P as r, j as i } from "./config-validation-F47AcE6o.js";
import { a, c as o, r as s, s as c, t as l } from "./compile-wUv8KEge.js";
import { C as u, S as d, a as f, c as p, h as m, i as h, l as g, n as _, o as v, p as y, r as b, t as x, u as S } from "./validation-BEBA_HvS.js";
import { i as C } from "./registry-core-Bbad9Bm2.js";
import { t as w } from "./registry-B9NGct4d.js";
import { A as ee, C as te, b as T } from "./component-state-BoLCGee4.js";
import { n as E } from "./runtime-B2fxeveq.js";
// src/local/runtime/runtime-values.ts
function D(e, t) {
	return e.attrs?.[t];
}
function O(e, t) {
	let n = D(e, t);
	if (n === "true") return !0;
	if (n === "false") return !1;
}
function k(e, t) {
	let n = D(e, t);
	if (n === void 0) return;
	let r = Number(n);
	return Number.isFinite(r) ? r : void 0;
}
function A(e) {
	return t(e);
}
function j(e, t) {
	return {
		ok: !1,
		detail: r(e, t)
	};
}
function M(e, t) {
	if (t !== void 0) return D(e, t);
}
function N(e, t) {
	if (t !== void 0) return k(e, t);
}
function P(t, n, r, i = {}) {
	for (let a of r) if (a.kind === "date") {
		if (!C(n)) return j("local.runtime.value.date-invalid");
		let e = i.required ?? (a.required !== void 0 && O(t, a.required) === !0);
		if (n === "" && e) return j("local.runtime.value.date-required");
		let r = i.min ?? M(t, a.min), o = i.max ?? M(t, a.max);
		if (n !== "" && r && n < r) return j("local.runtime.value.date-earlier", { min: r });
		if (n !== "" && o && n > o) return j("local.runtime.value.date-later", { max: o });
	} else if (a.kind === "required") {
		let e = i.required ?? O(t, a.required) === !0;
		if (n === "" && e) return j("local.runtime.value.field-required");
	} else if (a.kind === "length") {
		let e = A(n), r = N(t, a.min), i = N(t, a.max);
		if (r !== void 0 && r > 0 && n !== "" && e < r) return j("local.runtime.value.min-length", { min: r });
		if (i !== void 0 && e > i) return j("local.runtime.value.max-length", { max: i });
	} else if (a.kind === "email" && (M(t, a.type) ?? "text") === a.value && n !== "") {
		if (n.length > 254) return j("local.runtime.value.email-length", { limit: 254 });
		if (!e(n)) return j("local.runtime.value.email-invalid");
	}
	return {
		ok: !0,
		value: n
	};
}
var F = /* @__PURE__ */ new Map();
function I(e) {
	if (!e.name) return L;
	let t = F.get(e.name);
	if (t !== void 0) return t ?? L;
	let n = w(e.name), r = n ? m(n) : L;
	return F.set(e.name, n ? r : null), r;
}
var L = Object.freeze([]);
function R(e, t, n, r, a, s = !1) {
	switch (e.type) {
		case "number": {
			if (typeof n != "number" || !Number.isFinite(n)) return j("local.runtime.value.finite-number", { name: e.name });
			let i = e.step ?? 1, a = e.min ?? 0;
			for (let i of t) {
				let t = r(i, "min");
				if (t.present && !t.ok) return j("local.runtime.value.constraint", {
					name: e.name,
					attribute: "min"
				});
				if (t.present && t.ok) {
					if (typeof t.value != "number" || !Number.isFinite(t.value)) return j("local.runtime.value.constraint", {
						name: e.name,
						attribute: "min"
					});
					if (a = t.value, n < t.value) return j("local.runtime.value.min", {
						name: e.name,
						min: t.value
					});
				}
				let o = r(i, "max");
				if (o.present && !o.ok) return j("local.runtime.value.constraint", {
					name: e.name,
					attribute: "max"
				});
				if (o.present && o.ok) {
					if (typeof o.value != "number" || !Number.isFinite(o.value)) return j("local.runtime.value.constraint", {
						name: e.name,
						attribute: "max"
					});
					if (n > o.value) return j("local.runtime.value.max", {
						name: e.name,
						max: o.value
					});
				}
				if (t.present && t.ok && o.present && o.ok && typeof t.value == "number" && typeof o.value == "number" && t.value > o.value) return j("local.runtime.value.constraint-range", { name: e.name });
			}
			return e.min !== void 0 && n < e.min ? j("local.runtime.value.min", {
				name: e.name,
				min: e.min
			}) : e.max !== void 0 && n > e.max ? j("local.runtime.value.max", {
				name: e.name,
				max: e.max
			}) : i > 0 && !V(n, a, i) ? j("local.runtime.value.step", {
				name: e.name,
				step: i,
				base: a
			}) : {
				ok: !0,
				value: n
			};
		}
		case "boolean": return typeof n == "boolean" ? {
			ok: !0,
			value: n
		} : j("local.runtime.value.boolean", { name: e.name });
		case "string": {
			if (typeof n != "string") return j("local.runtime.value.string", { name: e.name });
			let c = o(n);
			if (c) return j("local.runtime.value.budget", {
				name: e.name,
				detail: i(c),
				detailKey: c.key,
				...c.params
			});
			for (let i of t) {
				let t = a?.get(i.id) ?? (s ? I(i) : L);
				if (!t.length) continue;
				let o = {};
				for (let n of t) {
					if (n.kind === "date") {
						for (let t of ["min", "max"]) {
							if (n[t] === void 0) continue;
							let a = r(i, t);
							if (a.present) {
								if (!a.ok || typeof a.value != "string" || !C(a.value)) return j("local.runtime.value.constraint-date", {
									name: e.name,
									attribute: t
								});
								o[t] = a.value;
							}
						}
						let t = o.min ?? M(i, n.min), a = o.max ?? M(i, n.max);
						if (t && a && C(t) && C(a) && t > a) return j("local.runtime.value.constraint-range", { name: e.name });
					}
					if ((n.kind === "date" || n.kind === "required" ? n.required : void 0) !== void 0) {
						let t = r(i, "required");
						if (t.present) {
							if (!t.ok || typeof t.value != "boolean") return j("local.runtime.value.constraint", {
								name: e.name,
								attribute: "required"
							});
							o.required = t.value;
						}
					}
				}
				let c = P(i, n, t, o);
				if (!c.ok) return c;
			}
			return e.options?.length && !e.options.includes(n) ? j("local.runtime.value.option", {
				value: n,
				options: e.options.join(", ")
			}) : {
				ok: !0,
				value: n
			};
		}
		case "array": {
			if (!Array.isArray(n)) return j("local.runtime.value.array", { name: e.name });
			let t = o(n);
			if (t) return j("local.runtime.value.budget", {
				name: e.name,
				detail: i(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "string") return j("local.runtime.value.array-members", { name: e.name });
			if (e.family === "collection") return e.maxItems !== void 0 && n.length > e.maxItems ? j("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
			let r = /* @__PURE__ */ new Set();
			for (let t of n) {
				if (e.options && !e.options.includes(t)) return j("local.runtime.value.checklist-option", { value: t });
				r.add(t);
			}
			let a = e.options ? e.options.filter((e) => r.has(e)) : [...r];
			return e.maxItems !== void 0 && a.length > e.maxItems ? j("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: a
			};
		}
		case "number-array": {
			if (!Array.isArray(n)) return j("local.runtime.value.number-array", { name: e.name });
			let t = o(n);
			if (t) return j("local.runtime.value.budget", {
				name: e.name,
				detail: i(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "number" || !Number.isFinite(t)) return j("local.runtime.value.number-array-members", { name: e.name });
			return e.maxItems !== void 0 && n.length > e.maxItems ? j("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
		}
		case "null": return n === null ? {
			ok: !0,
			value: n
		} : j("local.runtime.value.null", { name: e.name });
	}
	return j("local.runtime.value.unsupported-type", { name: e.name });
}
function ne(e) {
	return e instanceof a ? e : new a("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function re(e, t) {
	switch (e) {
		case "string": {
			if (typeof t != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t
			};
		}
		case "number": return typeof t == "number" && Number.isFinite(t) ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "number" }
		};
		case "boolean": return typeof t == "boolean" ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "boolean" }
		};
		case "array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			for (let e of t) if (typeof e != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		case "number-array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			for (let e of t) if (typeof e != "number" || !Number.isFinite(e)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		default: return {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: String(e) }
		};
	}
}
var z = 1e-9;
function B(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function V(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= z * Math.max(1, Math.abs(r));
}
function H(e, t, n, r) {
	let a = Math.max(0, Math.min(e.source.length, t.range.start)), o = e.source.slice(0, a).split("\n");
	return {
		code: n,
		message: i(r),
		severity: "error",
		range: {
			start: a,
			end: Math.max(a + 1, Math.min(e.source.length, t.range.end))
		},
		line: o.length,
		column: (o.at(-1) ?? "").length + 1,
		messageKey: r.key,
		...r.params ? { params: r.params } : {}
	};
}
function U(e, t, n) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1,
		...n ? {
			messageKey: n.key,
			...n.params ? { params: n.params } : {}
		} : {}
	};
}
// src/local/runtime/runtime-document.ts
function W(e, t) {
	let n = e.document.bindings[t];
	if (!n) return;
	let { nodeIds: r, owner: i, ...a } = n, o = (e.controls.get(t) ?? []).map((t) => {
		let n = e.document.dynamicConstraints?.[t.id] ?? {};
		return {
			name: t.name ?? null,
			attrs: t.attrs ?? {},
			dynamic: Object.fromEntries(Object.entries(n).map(([e, t]) => [e, t ? {
				source: t.source,
				numeric: t.numeric ?? null
			} : null])),
			rules: e.valueRules.get(t.id) ?? null
		};
	});
	return JSON.stringify({
		facts: a,
		legacy: e.legacyValueRules,
		controls: o
	});
}
function ie(e, t) {
	let n = t.get(e);
	if (n) return {
		expression: n,
		error: null
	};
	try {
		let n = l(e);
		if (t.size >= 200) {
			let e = t.keys().next().value;
			e !== void 0 && t.delete(e);
		}
		return t.set(e, n), {
			expression: n,
			error: null
		};
	} catch (e) {
		return {
			expression: null,
			error: ne(e)
		};
	}
}
function ae(e, t) {
	let r = /* @__PURE__ */ new Map();
	for (let t of n(e.nodes)) r.set(t.id, t);
	let s = {}, l = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) {
		let e = o(n.initial);
		if (e) throw new a("expression-budget", `Parameter "${t}": ${i(e)}`, 0);
		s[t] = B(n.initial);
		let c = [];
		for (let e of n.nodeIds) {
			let t = r.get(e);
			t && c.push(t);
		}
		l.set(t, c);
	}
	let u = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots ?? {})) u.set(t, { ...n });
	let d = y(e), p = new Map(Object.entries(d?.valueRules ?? {})), m = d === void 0, h = /* @__PURE__ */ new Map();
	if (d) for (let e of d.slotRelations) {
		let t = u.get(e.nodeId), n = t?.[e.lower], r = t?.[e.upper];
		if (!n || !r) continue;
		let i = h.get(e.nodeId) ?? [];
		i.push({
			lower: n,
			upper: r
		}), h.set(e.nodeId, i);
	}
	else for (let [e, t] of u) t.start && t.end && h.set(e, [{
		lower: t.start,
		upper: t.end
	}]);
	let g = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) for (let e of n.nodeIds) {
		if (u.has(e)) continue;
		let n = g.get(e);
		(n === void 0 || n.startsWith("@") && !t.startsWith("@")) && g.set(e, t);
	}
	let _ = Object.freeze(Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort()), b = /* @__PURE__ */ new Map();
	for (let [e, t] of u) for (let n of Object.values(t)) {
		if (n.startsWith("@")) continue;
		let t = b.get(n) ?? /* @__PURE__ */ new Set();
		t.add(e), b.set(n, t);
	}
	let x = e.computations ?? {}, C = Object.keys(x), w = /* @__PURE__ */ new Map();
	for (let [e, n] of Object.entries(x)) {
		let r = ie(n.source, t);
		r.expression && w.set(e, r.expression);
	}
	let { order: ee, cyclic: te } = S(x), T = {}, E = /* @__PURE__ */ new Map();
	for (let e of ee) {
		let t = x[e];
		if (!t || t.kind !== "const") continue;
		if (Object.hasOwn(t, "value")) {
			let n = t.value, r = c(n);
			if (r) {
				E.set(e, new a("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			T[e] = B(n);
			continue;
		}
		let n = w.get(e);
		if (!n) E.set(e, new a("expression-eval", `Constant "${e}" cannot be evaluated.`, 0));
		else try {
			let t = n.evaluate({ ...T }), r = c(t);
			if (r) {
				E.set(e, new a("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			T[e] = B(t);
		} catch (t) {
			E.set(e, ne(t));
		}
	}
	let D = /* @__PURE__ */ new Map();
	for (let e of te) D.set(e, new a("expression-cycle", `Computation "${e}" is part of a dependency cycle.`, 0));
	let O = [];
	if (Array.isArray(e.validations)) for (let n of e.validations) {
		if (!f(n)) continue;
		let e = ie(n.expression, t);
		O.push({
			rule: n,
			expression: e.expression,
			error: e.error
		});
	}
	return {
		document: e,
		nodeIndex: r,
		controls: l,
		slotKeys: u,
		publicNames: _,
		publicSlotOwners: b,
		initial: s,
		valueRules: p,
		legacyValueRules: m,
		slotRelations: h,
		bindingByNode: g,
		computationMetadata: x,
		computationNames: C,
		computationOrder: ee,
		cyclicComputations: te,
		computationExpressions: w,
		constValues: T,
		constErrors: E,
		cycleErrors: D,
		validationRules: O,
		validationLineStarts: v(typeof e.source == "string" ? e.source : "")
	};
}
function oe(e) {
	return !e || e.syntax !== "local" ? "createLocalRuntime requires a local interaction document." : e.syntaxVersion !== void 0 && e.syntaxVersion !== "local-draft-3" || e.versionDeclaration && e.versionDeclaration.version !== "local-draft-3" ? `createLocalRuntime requires ${d}; migrate the source before constructing a runtime.` : null;
}
function G(e, t) {
	return (e.controls.get(t.name) ?? [])[0] ?? (t.owner ? e.nodeIndex.get(t.owner) : void 0) ?? (t.nodeIds[0] ? e.nodeIndex.get(t.nodeIds[0]) : void 0);
}
function se(e, t, n) {
	let r = G(e, t);
	return r ? H(e.document, r, "local.runtime.value", n) : U("local.runtime.value", i(n));
}
function K(e, t, n) {
	let r = e.slotRelations.get(t);
	return r?.length ? r.some(({ lower: e, upper: t }) => {
		let r = n[e], i = n[t];
		return typeof r == "number" && typeof i == "number" && r > i;
	}) : !1;
}
function ce(e, t) {
	let n = e.nodeIndex.get(t);
	return n ? H(e.document, n, "local.runtime.value", r("local.runtime.value.range-order")) : U("local.runtime.value", i(r("local.runtime.value.range-order")));
}
// src/local/runtime/retention.ts
function q(e) {
	let t = /* @__PURE__ */ new Map();
	for (let r of n(e.nodes)) t.set(r.id, r);
	return t;
}
function le(e, t, n) {
	let r = e.bindingSlots?.[t.id];
	return r !== void 0 && Object.values(r).includes(n);
}
function J(e, t, n) {
	let r = t.name ? w(t.name) : void 0;
	if (r?.bindings) {
		let i = e.bindingSlots?.[t.id];
		for (let [e, a] of Object.entries(r.bindings)) if (t.attrs?.[a.bind] === n || e !== "value" && i?.[e] === n) return a.retain === !1 ? void 0 : a.initial;
	} else if (t.attrs?.bind === n || le(e, t, n)) return "initial";
}
function Y(e) {
	let t = q(e), n = y(e), r = new Set(n?.retentionExclusions ?? []), i = /* @__PURE__ */ new Map();
	for (let [a, o] of Object.entries(e.bindings)) {
		let s = o.nodeIds.flatMap((e) => {
			let n = t.get(e);
			return n ? [n] : [];
		});
		if (!s.length || a.startsWith("@") || r.has(a)) continue;
		let c;
		if (n === void 0) {
			let t = s.map((t) => J(e, t, a));
			if (t.some((e) => e === void 0)) continue;
			c = t;
		} else {
			let e = n.bindingAttributes?.[a]?.initial ?? "initial";
			c = s.map(() => e);
		}
		let l = s.flatMap((e, t) => Object.hasOwn(e.attrs ?? {}, c[t]) ? [e.attrs[c[t]]] : []).sort();
		i.set(a, {
			type: o.type,
			initialDefinition: JSON.stringify([o.initial, l])
		});
	}
	return i;
}
function X(e, t) {
	return Object.freeze({
		name: e,
		reason: t
	});
}
function Z(e) {
	let t = Y(e.previous), n = Y(e.next), r = {}, i = [], a = [];
	for (let o of Object.keys(e.state).sort()) {
		if (o.startsWith("@")) {
			a.push(X(o, "internal"));
			continue;
		}
		if (!Object.hasOwn(e.previous.bindings, o) || !Object.hasOwn(e.next.bindings, o)) {
			a.push(X(o, "unknown"));
			continue;
		}
		let s = t.get(o), c = n.get(o);
		if (!s || !c) {
			a.push(X(o, "unretainable"));
			continue;
		}
		if (s.type !== c.type) {
			a.push(X(o, "type"));
			continue;
		}
		if (s.initialDefinition !== c.initialDefinition) {
			a.push(X(o, "initial"));
			continue;
		}
		let l = e.state[o];
		r[o] = Array.isArray(l) ? Object.freeze([...l]) : l, i.push(o);
	}
	return Object.freeze({
		values: Object.freeze(r),
		retained: Object.freeze(i),
		dropped: Object.freeze(a)
	});
}
function ue(e, t, n) {
	return Object.freeze({
		retained: Object.freeze([...e]),
		dropped: Object.freeze(t.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...n])
	});
}
function Q(e, t) {
	let n = Object.keys(t.values).sort();
	if (!e.setParameters(t.values).length) return ue(n, t.dropped, []);
	let r = [], i = n, a = [];
	for (; i.length;) {
		let n = [];
		a = [];
		for (let o of i) {
			let i = e.setParameter(o, t.values[o]);
			i.length ? (n.push(o), a.push(...i)) : r.push(o);
		}
		if (n.length === i.length) break;
		i = n;
	}
	r.sort();
	let o = [...t.dropped, ...i.map((e) => X(e, "invalid"))];
	return o.sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name)), ue(r, o, a);
}
// src/local/runtime/runtime-migration.ts
function de(e, t, n, r, i) {
	let a = Z({
		previous: e.document,
		state: t,
		next: n
	}), o = {};
	for (let [e, t] of Object.entries(n.bindings)) o[e] = B(t.initial);
	let s = /* @__PURE__ */ new Map();
	for (let e of a.dropped) s.set(e.name, Object.freeze({ ...e }));
	let c = [], l = {}, u = [], d = /* @__PURE__ */ new Set(), f, p = (n) => {
		let o = e.document.bindings[n], s = e.controls.get(n) ?? [];
		return !o || !s.some((t) => e.document.dynamicConstraints?.[t.id]) || (f ??= i({}, e, t), R(o, s, a.values[n], f, e.valueRules, e.legacyValueRules).ok) ? !1 : W(e, n) === W(r, n);
	};
	for (let e of a.retained) {
		let t = n.bindings[e];
		if (!t) continue;
		if (p(e)) {
			d.add(e), l[e] = B(a.values[e]), u.push(e);
			continue;
		}
		let f = R(t, r.controls.get(e) ?? [], a.values[e], i(a.values, r, o), r.valueRules, r.legacyValueRules);
		f.ok ? (l[e] = B(f.value), u.push(e)) : (c.push(se(r, t, f.detail)), s.set(e, Object.freeze({
			name: e,
			reason: "invalid"
		})));
	}
	let m = {
		...o,
		...l
	}, h = /* @__PURE__ */ new Set();
	for (let e of u) for (let t of r.publicSlotOwners.get(e) ?? []) h.add(t);
	let g = !1;
	for (let e of [...h].sort()) if (K(r, e, m)) {
		g = !0;
		break;
	}
	let _;
	if (!g) Object.assign(o, l), _ = u;
	else {
		_ = [];
		for (let e of u) {
			let t = o[e];
			o[e] = l[e];
			let n = !1;
			for (let t of [...r.publicSlotOwners.get(e) ?? []].sort()) K(r, t, o) && (c.push(ce(r, t)), n = !0);
			n ? (o[e] = t, s.set(e, Object.freeze({
				name: e,
				reason: "invalid"
			}))) : _.push(e);
		}
	}
	for (let [e, t] of r.slotRelations) if (K(r, e, o)) {
		for (let e of t) for (let t of [e.lower, e.upper]) {
			let e = n.bindings[t];
			if (!e) continue;
			o[t] = B(e.initial);
			let r = _.indexOf(t);
			r >= 0 && _.splice(r, 1), s.set(t, Object.freeze({
				name: t,
				reason: "invalid"
			}));
		}
		if (c.push(ce(r, e)), K(r, e, o)) return {
			values: {},
			retained: [],
			dropped: [],
			diagnostics: []
		};
	}
	let v = !0;
	for (; v;) {
		let e = i({}, r, o), t = [];
		for (let i of _) {
			if (d.has(i)) continue;
			let a = n.bindings[i], s = R(a, r.controls.get(i) ?? [], o[i], e, r.valueRules, r.legacyValueRules);
			s.ok || (c.push(se(r, a, s.detail)), t.push(i));
		}
		for (let e of t) o[e] = B(n.bindings[e].initial), _.splice(_.indexOf(e), 1), s.set(e, Object.freeze({
			name: e,
			reason: "invalid"
		}));
		v = t.length > 0;
	}
	let y = [...s.values()].sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name));
	return _.sort(), {
		values: o,
		retained: _,
		dropped: y,
		diagnostics: c
	};
}
// src/local/runtime/runtime.ts
function fe(e) {
	return {
		...e,
		range: { ...e.range }
	};
}
function pe(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => e === t[n]) : e === t;
}
function me(e) {
	for (let [t, n] of Object.entries(e)) Array.isArray(n) && !Object.isFrozen(n) && (e[t] = Object.freeze([...n]));
	return Object.freeze(e);
}
var he = /* @__PURE__ */ new WeakMap();
function $(e) {
	return Object.freeze({
		ok: e.ok,
		changed: e.changed,
		revision: e.revision,
		retained: Object.freeze([...e.retained]),
		dropped: Object.freeze(e.dropped.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...e.diagnostics])
	});
}
function ge(e, t, n) {
	let r = he.get(e);
	if (!r) throw TypeError("updateLocalRuntime requires a runtime created by createLocalRuntime.");
	return r.update(t, n?.notify !== !1);
}
function _e(e) {
	he.get(e)?.notify();
}
function ve(e, t, n) {
	return he.get(e)?.bindNetworkExternals(t, n) ?? (() => {});
}
function ye(e, t) {
	let c = oe(e);
	if (c) throw Error(c);
	let d = t?.services === void 0, f = ee(t?.network), m = /* @__PURE__ */ new Map(), v = te(e.source), y = /* @__PURE__ */ new Map(), S = /* @__PURE__ */ new Map(), C = ae(e, S), w = () => C, D = () => {
		let e = /* @__PURE__ */ new Set();
		for (let r of n(C.document.nodes)) r.name !== void 0 && e.add(T({
			documentId: t?.documentId,
			sourceDigest: v,
			nodeId: r.id,
			stateKey: r.attrs?.["state-key"]
		}));
		return e;
	}, O = t?.services ?? E({
		documentId: t?.documentId,
		sourceDigest: v,
		randomSeed: t?.randomSeed,
		componentState: t?.componentState,
		...t?.componentStateStorage === void 0 ? {} : { componentStateStorage: t.componentStateStorage },
		...t?.componentStateWriteDelayMs === void 0 ? {} : { componentStateWriteDelayMs: t.componentStateWriteDelayMs },
		...t?.configKey === void 0 ? {} : { configKey: t.configKey },
		...t?.legacyConfigKeys === void 0 ? {} : { legacyConfigKeys: t.legacyConfigKeys },
		...d ? { knownStateKeys: D } : {}
	}), k = {}, A = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e.externals ?? {})) {
		let e = t?.externalValues?.[n];
		if (e === void 0) continue;
		let i = re(r.type, e);
		i.ok && (k[n] = i.value);
	}
	let j = (e, t) => {
		let n = {};
		for (let [r, i] of Object.entries(e.document.externals ?? {})) {
			if (!Object.hasOwn(t, r)) continue;
			let e = re(i.type, t[r]);
			e.ok && (n[r] = e.value);
		}
		return n;
	}, M = (e) => {
		let t = j(e, k);
		for (let n of A.keys()) Object.assign(t, j(e, n));
		return t;
	}, N = (e, t, n, r = w()) => {
		let i = r.document.dynamicConstraints?.[e.id]?.[t];
		if (!i) return { present: !1 };
		let a = ie(i.source, S);
		if (!a.expression) return {
			present: !0,
			ok: !1
		};
		try {
			let e = a.expression.evaluate(n), t = i.numeric;
			return t && (typeof e != "number" || !Number.isFinite(e) || t.integer === !0 && !Number.isInteger(e) || t.min !== void 0 && e < t.min || t.max !== void 0 && e > t.max) ? {
				present: !0,
				ok: !1
			} : {
				present: !0,
				ok: !0,
				value: e
			};
		} catch {
			return {
				present: !0,
				ok: !1
			};
		}
	}, P = C.initial, F = 0, I = {}, L = {}, ne = {
		revision: 0,
		state: me({})
	}, z = !1, V = null, W = /* @__PURE__ */ new Set(), G = /* @__PURE__ */ new Map(), q = () => {
		if (z) throw Error("The local interaction runtime has been disposed.");
	};
	function le(e, t) {
		if (!t.startsWith("@") && Object.hasOwn(e.document.bindings, t)) return Object.hasOwn(P, t) ? P[t] : void 0;
	}
	let J = (e, t) => {
		let n = M(e), r = /* @__PURE__ */ new Map();
		for (let t of Object.keys(e.document.externals ?? {})) Object.hasOwn(n, t) || r.set(t, new a("external-missing", "External data \"" + t + "\" is not available.", 0));
		let i = {}, o = /* @__PURE__ */ new Map();
		if (e.computationNames.length > 0) {
			let a = g(e.computationMetadata, e.computationOrder, e.computationExpressions, {
				...t,
				...n
			}, e.constValues, r);
			i = a.values, o = a.errors;
			for (let [t, n] of e.constErrors) Object.hasOwn(i, t) || o.set(t, n);
			for (let [t, n] of e.cycleErrors) Object.hasOwn(i, t) || o.set(t, n);
		}
		let s = {};
		for (let [e, n] of Object.entries(t)) s[e] = n;
		for (let [e, t] of Object.entries(n)) s[e] = t;
		for (let [e, t] of Object.entries(i)) s[e] = t;
		for (let [e, t] of [...r, ...o]) Object.hasOwn(i, e) || Object.defineProperty(s, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw t;
			}
		});
		let c = {};
		for (let [e, n] of Object.entries(t)) c[e] = n;
		for (let [e, t] of Object.entries(n)) c[e] = t;
		for (let [e, t] of Object.entries(i)) c[e] = t;
		return {
			environment: s,
			snapshotState: c
		};
	}, Y = () => {
		let e = J(w(), P);
		I = e.environment, L = e.snapshotState;
	}, X = (e, t = w(), n = P) => {
		let r;
		return (i, a) => t.document.dynamicConstraints?.[i.id]?.[a] ? (r ??= J(t, {
			...n,
			...e
		}).environment, N(i, a, r, t)) : { present: !1 };
	}, Z = () => {
		ne = {
			revision: F,
			state: me(L)
		};
	}, ue = () => {
		for (let e of W) e();
	}, Q = (e) => {
		P = e, F += 1, Y(), Z(), ue();
	}, ge = () => {
		F += 1, Y(), Z(), ue();
	}, _e = (e, t = k) => {
		if (q(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setExternalValues requires an object of external values.");
		let n = [], a = {}, o = Object.keys(e).sort();
		for (let t of o) {
			if (t === "__proto__") {
				n.push(U("local.runtime.external", "External names cannot be \"__proto__\"."));
				continue;
			}
			let o = w().document.externals ?? {}, s = Object.hasOwn(o, t) ? o[t] : void 0;
			if (!s) {
				let e = r("local.runtime.external", { name: t });
				n.push(U("local.runtime.external", i(e), e));
				continue;
			}
			let c = re(s.type, e[t]);
			if (c.ok) a[t] = c.value;
			else {
				let e = r(c.key, {
					name: t,
					...c.params ?? {}
				});
				n.push(U("local.runtime.external", i(e), e));
			}
		}
		return n.length ? n : (o.some((e) => !pe(t[e], a[e])) && (Object.assign(t, a), ge()), []);
	}, ve = (e, t) => {
		if (z) return () => {};
		let n = {}, r = e.bindExternalValues((e) => {
			if (z || !A.has(n)) return;
			let r = _e(e, n);
			r.length && t?.(r);
		});
		return r ? (A.set(n, r), () => {
			A.delete(n) && (r(), !z && Object.keys(n).length && ge());
		}) : () => {};
	}, ye = (e) => {
		q();
		let t = w(), n = [], r = {}, i = Object.keys(e).sort(), a = X(e);
		for (let o of i) {
			if (o === "__proto__") {
				n.push(U("local.runtime.parameter", "Parameter names cannot be \"__proto__\"."));
				continue;
			}
			if (o.startsWith("@")) {
				n.push(U("local.runtime.parameter", `Internal parameter "${o}" cannot be written by name.`));
				continue;
			}
			if (!Object.hasOwn(t.document.bindings, o)) {
				n.push(U("local.runtime.parameter", `Unknown parameter "${o}".`));
				continue;
			}
			let i = t.document.bindings[o], s = R(i, t.controls.get(o) ?? [], e[o], a, t.valueRules, t.legacyValueRules);
			s.ok ? r[o] = B(s.value) : n.push(se(t, i, s.detail));
		}
		if (n.length) return n;
		if (!i.some((e) => !pe(P[e], r[e]))) return [];
		let o = {
			...P,
			...r
		}, s = /* @__PURE__ */ new Set();
		for (let e of i) for (let n of t.publicSlotOwners.get(e) ?? []) s.add(n);
		for (let e of [...s].sort()) K(t, e, o) && n.push(ce(t, e));
		return n.length ? n : (Q(o), []);
	}, be = (e) => {
		let t = y.get(e);
		if (!t) {
			if (t = l(e), y.size >= 200) {
				let e = y.keys().next().value;
				e !== void 0 && y.delete(e);
			}
			y.set(e, t);
		}
		return t;
	}, xe = () => {
		let e = w(), t = [], n = typeof e.document.source == "string" ? e.document.source : "";
		for (let r of e.validationRules) {
			if (r.error) {
				t.push(p(n, e.validationLineStarts, r.rule.range, x, h(`Validation expression is invalid: ${r.error.message}`)));
				continue;
			}
			if (!r.expression) continue;
			let i;
			try {
				i = r.expression.evaluate(I);
			} catch (i) {
				t.push(p(n, e.validationLineStarts, r.rule.range, x, h(`Validation expression failed: ${i instanceof Error ? i.message : String(i)}`)));
				continue;
			}
			typeof i == "boolean" ? i || t.push(p(n, e.validationLineStarts, r.rule.range, _, Se(r.rule.message))) : t.push(p(n, e.validationLineStarts, r.rule.range, x, "Validation expression must evaluate to a boolean."));
		}
		return t;
	}, Se = (e) => {
		let t;
		try {
			t = s(e, I);
		} catch {
			t = b;
		}
		return h(t);
	}, Ce = (e, t) => {
		if (q(), e === C.document) return $({
			ok: !0,
			changed: !1,
			revision: F,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		if (oe(e)) return $({
			ok: !1,
			changed: !1,
			revision: F,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let n;
		try {
			n = ae(e, S);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: F,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let r = de(C, P, e, n, X);
		if (Object.keys(r.values).length === 0 && Object.keys(e.bindings).length > 0) return $({
			ok: !1,
			changed: !1,
			revision: F,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let i;
		try {
			i = J(n, r.values);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: F,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		for (let e of [k, ...A.keys()]) {
			let t = j(n, e);
			for (let t of Object.keys(e)) delete e[t];
			Object.assign(e, t);
		}
		if (C = n, P = r.values, I = i.environment, L = i.snapshotState, V = null, F += 1, Z(), t) for (let e of W) e();
		return $({
			ok: !0,
			changed: !0,
			revision: F,
			retained: r.retained,
			dropped: r.dropped,
			diagnostics: r.diagnostics
		});
	}, we = (e) => {
		let t = /* @__PURE__ */ new Set();
		for (let r of n([e])) t.add(r.id);
		return t;
	}, Te = {
		network: f.network,
		get document() {
			return C.document;
		},
		services: O,
		snapshot() {
			return q(), ne;
		},
		get(e, t) {
			q();
			let n = w(), r = n.nodeIndex.get(e.id);
			if (!r) return null;
			let i = t === void 0 ? n.slotKeys.get(r.id)?.value ?? n.bindingByNode.get(r.id) ?? u(r) : n.slotKeys.get(r.id)?.[t];
			return i && Object.hasOwn(P, i) ? B(P[i]) : null;
		},
		set(e, t, n) {
			q();
			let i = w(), a = i.nodeIndex.get(e.id);
			if (!a) return [H(i.document, e, "local.runtime.binding", r("local.runtime.binding.no-writable"))];
			let o = i.slotKeys.get(a.id), s;
			if (n === void 0) {
				if (o && !o.value) return [H(i.document, a, "local.runtime.binding", r("local.runtime.binding.needs-slot"))];
				s = o?.value ?? i.bindingByNode.get(a.id) ?? u(a);
			} else if (s = o?.[n], !s) return [H(i.document, a, "local.runtime.binding", r("local.runtime.binding.unknown-slot", { slot: n }))];
			let c = Object.hasOwn(i.document.bindings, s) ? i.document.bindings[s] : void 0;
			if (!c) return [H(i.document, a, "local.runtime.binding", r("local.runtime.binding.no-writable"))];
			let l = R(c, i.controls.get(s) ?? [], t, X({ [s]: t }), i.valueRules, i.legacyValueRules);
			if (!l.ok) return [H(i.document, a, "local.runtime.value", l.detail)];
			let d = B(l.value);
			if (pe(P[s], d)) return [];
			let f = {
				...P,
				[s]: d
			};
			return K(i, a.id, f) ? [H(i.document, a, "local.runtime.value", r("local.runtime.value.range-order"))] : (Q(f), []);
		},
		setMany(e, t) {
			q();
			let n = w(), i = n.nodeIndex.get(e.id);
			if (!i) return [H(n.document, e, "local.runtime.binding", r("local.runtime.binding.no-writable"))];
			let a = n.slotKeys.get(i.id);
			if (!a) return [H(n.document, i, "local.runtime.binding", r("local.runtime.binding.no-multi-slot"))];
			let o = Object.entries(t);
			if (!o.length) return [];
			let s = { ...P }, c = J(n, {
				...P,
				...Object.fromEntries(o.map(([e, t]) => [a[e], t]))
			}).environment;
			for (let [e, t] of o) {
				let o = a[e];
				if (!o || !Object.hasOwn(n.document.bindings, o)) return [H(n.document, i, "local.runtime.binding", r("local.runtime.binding.unknown-slot", { slot: e }))];
				let l = R(n.document.bindings[o], n.controls.get(o) ?? [], t, (e, t) => N(e, t, c), n.valueRules, n.legacyValueRules);
				if (!l.ok) return [H(n.document, i, "local.runtime.value", l.detail)];
				s[o] = B(l.value);
			}
			return K(n, i.id, s) ? [H(n.document, i, "local.runtime.value", r("local.runtime.value.range-order"))] : (o.every(([e, t]) => pe(P[a[e]], t)) || Q(s), []);
		},
		parameterNames() {
			return q(), w().publicNames;
		},
		getParameter(e) {
			q();
			let t = le(w(), e);
			return t === void 0 ? void 0 : B(t);
		},
		getParameters() {
			q();
			let e = w(), t = {};
			for (let n of e.publicNames) {
				let e = P[n];
				t[n] = Array.isArray(e) ? Object.freeze([...e]) : e;
			}
			return Object.freeze(t);
		},
		readSubmissionFields(e) {
			q();
			let t = w(), n = /* @__PURE__ */ new Map(), r = (e, n) => N(e, n, I, t);
			if (e.length === 0) return {
				ok: !1,
				field: "",
				reason: "unavailable"
			};
			for (let i of e) {
				let e = le(t, i);
				if (e === void 0 || n.has(i)) return {
					ok: !1,
					field: i,
					reason: "unavailable"
				};
				let a = R(t.document.bindings[i], t.controls.get(i) ?? [], e, r, t.valueRules, t.legacyValueRules);
				if (!a.ok) {
					let e = a.detail.key;
					return {
						ok: !1,
						field: i,
						reason: e === "local.runtime.value.field-required" || e === "local.runtime.value.date-required" ? "required" : "invalid"
					};
				}
				n.set(i, e);
			}
			let i = Object.create(null);
			for (let [e, r] of n) {
				for (let [n, i] of m.get(e) ?? []) {
					if (!t.controls.get(e)?.some((e) => e.id === i)) continue;
					let a = n(B(r));
					if (a) return {
						ok: !1,
						field: e,
						reason: a
					};
				}
				i[e] = Array.isArray(r) ? Object.freeze([...r]) : r;
			}
			return {
				ok: !0,
				payload: Object.freeze(i)
			};
		},
		registerSubmissionField(e, t) {
			if (z) return () => {};
			let n = w(), r = n.slotKeys.get(e.id)?.value ?? n.bindingByNode.get(e.id);
			if (!r || r.startsWith("@")) return () => {};
			let i = m.get(r);
			return i || m.set(r, i = /* @__PURE__ */ new Map()), i.set(t, e.id), () => {
				i.delete(t), i.size === 0 && m.get(r) === i && m.delete(r);
			};
		},
		setParameter(e, t) {
			q();
			let n = Object.create(null);
			return n[e] = t, ye(n);
		},
		setParameters(e) {
			if (q(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setParameters requires an object of parameter values.");
			return ye(e);
		},
		getExternal(e) {
			if (q(), Object.hasOwn(w().document.externals ?? {}, e) && Object.hasOwn(L, e)) return B(L[e]);
		},
		getExternalValues() {
			q();
			let e = {};
			for (let [t, n] of Object.entries(M(w()))) e[t] = Array.isArray(n) ? Object.freeze([...n]) : n;
			return Object.freeze(e);
		},
		setExternalValues(e) {
			return _e(e);
		},
		evaluate(e) {
			q();
			let t = be(e).evaluate(I);
			return Array.isArray(t) ? t.slice() : t;
		},
		validate() {
			if (q(), V && V.revision === F) return V.diagnostics.map(fe);
			let e = xe();
			return V = {
				revision: F,
				diagnostics: e
			}, e.map(fe);
		},
		text(e) {
			return q(), s(e, I);
		},
		reset(e) {
			q();
			let t = w(), n = t.nodeIndex.get(e.id);
			if (!n) return;
			let r = we(n), s = { ...P };
			for (let [e, n] of Object.entries(t.document.bindings)) {
				if (!(t.controls.get(e) ?? []).some((e) => r.has(e.id))) continue;
				let c = o(n.initial);
				if (c) throw new a("expression-budget", `Parameter "${e}": ${i(c)}`, 0);
				s[e] = B(n.initial);
			}
			for (let e of r) G.set(e, (G.get(e) ?? 0) + 1);
			Q(s);
		},
		resetToken(e) {
			q();
			let t = w().nodeIndex.get(e.id);
			return t ? G.get(t.id) ?? 0 : 0;
		},
		subscribe(e) {
			return q(), W.add(e), () => {
				W.delete(e);
			};
		},
		dispose() {
			if (!z) {
				z = !0, f.dispose();
				for (let e of A.values()) e();
				A.clear(), m.clear(), O.state.flush(), d && O.scheduler.dispose(), W.clear(), y.clear(), S.clear(), C.computationExpressions.clear(), C.constErrors.clear(), C.cycleErrors.clear(), C.validationRules.length = 0, G.clear();
			}
		}
	};
	return he.set(Te, {
		update: Ce,
		bindNetworkExternals: ve,
		notify() {
			if (!z) for (let e of W) e();
		}
	}), Y(), Z(), ve(f), Te;
}
export { Q as a, ge as i, ye as n, Z as o, _e as r, ve as t };
