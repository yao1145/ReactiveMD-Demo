import { A as e, B as t, G as n, J as r, K as i, O as a, it as o } from "./preset-core-CKc5YXSM.js";
import { V as s, f as c, l, u } from "./config-validation-F47AcE6o.js";
import { S as d } from "./validation-BEBA_HvS.js";
import { l as f, o as p } from "./parser-standard-Yuf3A_VI.js";
import { i as m, s as h } from "./config-BadfhjdP.js";
import { r as g } from "./options-1aDLK7JY.js";
import { C as _, u as ee, w as te } from "./component-state-BoLCGee4.js";
import { n as v } from "./runtime-kcA7bG7G.js";
import { i as ne, t as y } from "./resources-D2GDQS0p.js";
// src/local/runtime/state.ts
var b = "reactive-md-state/v1", x = 1048576, S = /^fnv1a32:[0-9a-f]{8}$/, C = /* @__PURE__ */ new Set([
	"format",
	"syntax",
	"sourceDigest",
	"parameters",
	"generator"
]), re = /* @__PURE__ */ new Set(["name", "version"]), ie = new TextEncoder();
function w(e, t) {
	return {
		code: e,
		message: t.length > 2e3 ? `${s(t, o - 1)}…` : t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function T(e, t, n) {
	e.length < 100 && e.push(w(t, n));
}
function E(e) {
	return e instanceof Error ? e.message : String(e);
}
function D(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function O(e) {
	if (typeof e == "string") return D(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "contains malformed Unicode."
	};
	if (typeof e == "number") return Number.isFinite(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "must be a finite number."
	};
	if (typeof e == "boolean" || e === null) return {
		ok: !0,
		value: e
	};
	if (Array.isArray(e)) {
		let t = [], n = e.length === 0 ? "string" : typeof e[0];
		for (let r = 0; r < e.length; r += 1) {
			let i = e[r];
			if (n === "string" && typeof i == "string") {
				if (!D(i)) return {
					ok: !1,
					message: "contains malformed Unicode."
				};
				t.push(i);
			} else if (n === "number" && typeof i == "number" && Number.isFinite(i)) t.push(i);
			else return {
				ok: !1,
				message: "must be an array of strings or finite numbers of one kind."
			};
		}
		return {
			ok: !0,
			value: Object.freeze(t)
		};
	}
	return {
		ok: !1,
		message: "must be a string, finite number, boolean, null or homogeneous primitive array."
	};
}
function k(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function A(e) {
	return Object.freeze(e.parameters), e.generator && Object.freeze(e.generator), Object.freeze(e);
}
function j(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("generator must be an object with string name and version.");
	if (typeof e.name != "string" || typeof e.version != "string") throw TypeError("generator must have string name and version.");
	if (!D(e.name) || !D(e.version)) throw TypeError("generator name and version must be well-formed Unicode strings.");
	return Object.freeze({
		name: e.name,
		version: e.version
	});
}
function M(e) {
	return typeof e == "string" ? `"${e.length > 48 ? `${s(e, 48)}…` : e}"` : e === null ? "null" : Array.isArray(e) ? "an array" : typeof e;
}
function N(e, t) {
	return e.length > t ? e.length : ie.encode(e).byteLength;
}
function ae(e, t) {
	let n;
	try {
		let t = JSON.stringify(e);
		if (typeof t != "string") return null;
		n = t;
	} catch {
		return null;
	}
	return N(n, t);
}
function oe(e) {
	if (e === void 0) return x;
	if (typeof e != "object" || !e) throw TypeError("parseLocalState options must be an object.");
	let { maxLength: t } = e;
	if (t === void 0) return x;
	if (typeof t != "number" || !Number.isSafeInteger(t) || t <= 0) throw RangeError("maxLength must be a finite positive integer.");
	return t;
}
function P(e, t, n) {
	if (!e || e.syntax !== "local" || typeof e.source != "string") throw TypeError("createLocalStateFile requires a compiled local document.");
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("createLocalStateFile requires a state object.");
	let r = Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort(), i = new Set(r), a = /* @__PURE__ */ new Map();
	for (let n of Object.keys(t)) {
		if (Object.hasOwn(e.computations ?? {}, n)) continue;
		if (n.startsWith("@")) {
			if (!Object.hasOwn(e.bindings, n)) throw Error(`Cannot persist parameter "${n}": it is not a binding of this document.`);
			continue;
		}
		if (!i.has(n)) throw Error(`Cannot persist parameter "${n}": it is not a public binding of this document.`);
		let r = O(t[n]);
		if (!r.ok) throw TypeError(`Cannot persist parameter "${n}": the value ${r.message}`);
		a.set(n, r.value);
	}
	let o = {};
	for (let e of r) {
		if (!a.has(e)) throw Error(`Cannot persist the document: parameter "${e}" is missing from the supplied state.`);
		o[e] = a.get(e);
	}
	let s = {
		format: b,
		syntax: d,
		sourceDigest: _(e.source),
		parameters: o
	};
	return n !== void 0 && (s.generator = j(n)), A(s);
}
function se(e, t) {
	let n = [], r = (e, t) => T(n, e, t), i = e;
	if (typeof e == "string") {
		if (N(e, t) > t) return {
			ok: !1,
			diagnostics: [w("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
		if (!D(e)) return {
			ok: !1,
			diagnostics: [w("local.state.utf", "The state payload contains malformed Unicode.")]
		};
		try {
			i = JSON.parse(e);
		} catch (e) {
			return {
				ok: !1,
				diagnostics: [w("local.state.json", `The state payload is not valid JSON: ${E(e)}`)]
			};
		}
	} else {
		let n = ae(e, t);
		if (n === null) return {
			ok: !1,
			diagnostics: [w("local.state.shape", "The state payload must be a JSON object.")]
		};
		if (n > t) return {
			ok: !1,
			diagnostics: [w("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
	}
	if (!k(i)) return {
		ok: !1,
		diagnostics: [w("local.state.shape", "The state payload must be a JSON object.")]
	};
	Object.getOwnPropertySymbols(i).length > 0 && r("local.state.shape", "The state payload cannot use symbol keys.");
	for (let e of Object.keys(i)) C.has(e) || r("local.state.key", `Unknown top-level state key "${e}".`);
	let a = i.format;
	a !== "reactive-md-state/v1" && r("local.state.format", `Unsupported state format ${M(a)}; expected "${b}".`);
	let o = i.syntax;
	o !== "local-draft-3" && r("local.state.syntax", `Unsupported state syntax ${M(o)}; expected "${d}".`);
	let s = i.sourceDigest;
	typeof s == "string" && S.test(s) || r("local.state.digest", "sourceDigest must match \"fnv1a32:\" followed by 8 lowercase hexadecimal digits.");
	let c = {}, l = i.parameters;
	if (!k(l)) r("local.state.parameters", "parameters must be a JSON object of public binding values.");
	else for (let e of Object.keys(l).sort()) {
		if (e === "__proto__") {
			r("local.state.parameter.prototype", "Parameter names cannot be \"__proto__\".");
			continue;
		}
		if (e.startsWith("@")) {
			r("local.state.parameter.internal", `Internal parameter "${e}" cannot be persisted.`);
			continue;
		}
		let t = O(l[e]);
		t.ok ? c[e] = t.value : r("local.state.parameter.value", `Parameter "${e}" ${t.message}`);
	}
	let u;
	if (Object.hasOwn(i, "generator")) {
		let e = i.generator;
		if (!k(e)) r("local.state.generator", "generator must be an object with string name and version.");
		else {
			for (let t of Object.keys(e)) re.has(t) || r("local.state.generator", `generator has unknown key "${t}".`);
			typeof e.name != "string" || typeof e.version != "string" ? r("local.state.generator", "generator must have string name and version.") : !D(e.name) || !D(e.version) ? r("local.state.utf", "generator contains malformed Unicode.") : u = Object.freeze({
				name: e.name,
				version: e.version
			});
		}
	}
	if (n.length) return {
		ok: !1,
		diagnostics: n
	};
	let f = {
		format: b,
		syntax: d,
		sourceDigest: s,
		parameters: c
	};
	return u && (f.generator = u), {
		ok: !0,
		file: A(f)
	};
}
function F(e, t) {
	let n = oe(t);
	try {
		return se(e, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [w("local.state.invalid", `Cannot read the local state: ${E(e)}`)]
		};
	}
}
function ce(e) {
	let t = /* @__PURE__ */ new Map(), n = (e) => {
		for (let r of e) t.set(r.id, r), r.children && n(r.children);
	};
	return n(e.nodes), t;
}
function I(e) {
	let t = ce(e), n = /* @__PURE__ */ new Map(), r = [];
	for (let [i, a] of Object.entries(e.bindingSlots ?? {})) {
		let e = t.get(i);
		if (!e) continue;
		let o = {
			node: e,
			slots: []
		};
		for (let [t, r] of Object.entries(a)) o.slots.push({
			slot: t,
			key: r
		}), r.startsWith("@") || n.set(r, {
			node: e,
			slot: t
		});
		o.slots.length && r.push(o);
	}
	let i = [];
	for (let [r, a] of Object.entries(e.bindings)) {
		if (r.startsWith("@")) continue;
		let e = n.get(r);
		if (e) {
			i.push({
				key: r,
				binding: a,
				node: e.node,
				slot: e.slot
			});
			continue;
		}
		let o = a.owner && t.has(a.owner) ? a.owner : a.nodeIds.find((e) => t.has(e));
		i.push({
			key: r,
			binding: a,
			node: o ? t.get(o) : void 0
		});
	}
	return {
		plans: i,
		groups: r
	};
}
function L(e, t, n) {
	let r = [], i = Object.create(null);
	for (let a of t.plans) a.slot === void 0 && Object.hasOwn(n, a.key) && (a.node ? Object.is(e.get(a.node), n[a.key]) || (i[a.key] = n[a.key]) : r.push(w("local.state.document", `The document has no component for parameter "${a.key}".`)));
	if (r.length) return r;
	r.push(...e.setParameters(i));
	for (let i of t.groups) {
		let t = {}, a = !1;
		for (let { slot: e, key: r } of i.slots) Object.hasOwn(n, r) && (t[e] = n[r], a = !0);
		a && r.push(...e.setMany(i.node, t));
	}
	return r;
}
function le(e, t) {
	let n = e.snapshot(), r = {};
	for (let e of t) {
		let t = n.state[e];
		r[e] = Array.isArray(t) ? Object.freeze([...t]) : t;
	}
	return Object.freeze(r);
}
function R(e, t, n, r) {
	let i = F(t, r);
	if (!i.ok) return i;
	if (!e || e.syntax !== "local" || typeof e.source != "string" || !Array.isArray(e.nodes) || !e.bindings) return {
		ok: !1,
		diagnostics: [w("local.state.document", "resolveLocalState requires a compiled local document.")]
	};
	if (i.file.syntax !== "local-draft-3") return {
		ok: !1,
		diagnostics: [w("local.state.syntax", `This state file uses syntax "${i.file.syntax}", but this build accepts "${d}".`)]
	};
	if (i.file.sourceDigest !== _(e.source)) return {
		ok: !1,
		diagnostics: [w("local.state.source", "This state file was created for a different document (source digest mismatch).")]
	};
	let a = I(e), o = new Set(a.plans.map((e) => e.key)), s = [];
	for (let e of Object.keys(i.file.parameters)) o.has(e) || T(s, "local.state.parameter.unknown", `The state contains unknown parameter "${e}" for this document.`);
	for (let e of o) Object.hasOwn(i.file.parameters, e) || T(s, "local.state.parameter.missing", `The state is missing parameter "${e}".`);
	if (s.length) return {
		ok: !1,
		diagnostics: s
	};
	let c;
	try {
		c = v(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [w("local.state.document", `Cannot validate this document: ${E(e)}`)]
		};
	}
	try {
		if (n) {
			let e = L(c, a, n);
			if (e.length) return {
				ok: !1,
				diagnostics: e
			};
		}
		let e = L(c, a, i.file.parameters);
		if (e.length) return {
			ok: !1,
			diagnostics: e
		};
		let t = [...o].sort();
		return {
			ok: !0,
			file: i.file,
			state: le(c, t)
		};
	} finally {
		c.dispose();
	}
}
function z(e, t, n) {
	try {
		return R(e, t, void 0, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [w("local.state.invalid", `Cannot resolve the local state: ${E(e)}`)]
		};
	}
}
function B(e, t, n) {
	let r;
	try {
		r = R(e.document, t, e.snapshot().state, n);
	} catch (e) {
		return [w("local.state.invalid", `Cannot apply the local state: ${E(e)}`)];
	}
	if (!r.ok) return r.diagnostics;
	let i = I(e.document);
	try {
		return L(e, i, r.state);
	} catch (e) {
		return [w("local.state.invalid", `Cannot apply the local state: ${E(e)}`)];
	}
}
function ue(e, t) {
	return P(e.document, e.getParameters(), t);
}
function de(e, t, n) {
	let r = F(t, n);
	return r.ok ? B(e, r.file, n) : r.diagnostics;
}
function fe(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("serializeLocalState requires a state file.");
	if (!e.parameters || typeof e.parameters != "object" || Array.isArray(e.parameters)) throw TypeError("serializeLocalState requires an object of parameters.");
	let t = Object.create(null);
	for (let n of Object.keys(e.parameters).sort()) {
		if (n === "__proto__" || n.startsWith("@")) throw TypeError(`Cannot serialize parameter "${n}".`);
		let r = O(e.parameters[n]);
		if (!r.ok) throw TypeError(`Cannot serialize parameter "${n}": the value ${r.message}`);
		t[n] = r.value;
	}
	let n = {
		format: e.format,
		syntax: e.syntax,
		sourceDigest: e.sourceDigest,
		parameters: t
	};
	if (e.generator !== void 0) {
		let t = j(e.generator);
		n.generator = {
			name: t.name,
			version: t.version
		};
	}
	return JSON.stringify(n);
}
// src/local/configuration/portable-options.ts
function V(e) {
	if (e === void 0) return;
	let t = g(e);
	if (!t.ok) throw TypeError(`Invalid portable compile options: ${t.message}`);
	return {
		enableCss: t.html.enableCss,
		enableJavaScript: t.html.enableJavaScript,
		enableExtendedHtml: t.html.enableExtendedHtml,
		...Object.hasOwn(e, "strict") && e.strict !== void 0 ? { strict: t.strict } : {},
		...e.markdownBreaks === void 0 ? {} : { markdownBreaks: t.markdownBreaks },
		...e.config === void 0 ? t.hostComponents.length ? { hostComponents: t.hostComponents } : {} : { config: h(e.config) },
		...e.limits === void 0 ? {} : { limits: {
			...e.limits.maxSyntaxNodes === void 0 ? {} : { maxSyntaxNodes: t.maxSyntaxNodes },
			...e.limits.maxParseWork === void 0 ? {} : { maxParseWork: t.maxParseWork },
			...e.limits.maxMarkdownDepth === void 0 ? {} : { maxMarkdownDepth: t.maxMarkdownDepth }
		} }
	};
}
// src/export/restoration.ts
var pe = r;
function H(e) {
	return r(JSON.stringify([
		e.id,
		e.name,
		e.version,
		e.protocol,
		e.colorSchemes,
		e.css.map(({ id: e, css: t }) => [e, t])
	]));
}
function me(e, n) {
	let i = h(n), a = l(i);
	return Object.freeze({
		protocol: "reactive-md-bundle/v1",
		sdkVersion: t,
		configKey: i.key,
		scriptDigest: r(e),
		assembly: a,
		seal: u(i),
		themes: Object.freeze(i.themes.map((e) => Object.freeze({
			id: e.id,
			name: e.name,
			version: e.version,
			digest: H(e)
		})))
	});
}
function U(e, n, i, o = []) {
	let s = h(n), c = /* @__PURE__ */ new Set(), u = [...e.nodes];
	for (; u.length;) {
		let e = u.pop();
		(e.type === "component" || e.type === "hostComponent") && e.name && c.add(e.name), e.children && u.push(...e.children);
	}
	let d = s.registry.filter((e) => c.has(e.name)).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		range: e.version,
		digest: a(e)
	})).sort((e, t) => e.id.localeCompare(t.id)), f = s.themes.filter((t) => t.name === e.theme).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: H(e)
	}));
	return Object.freeze({
		protocol: "reactive-md-restore/v1",
		sdk: `^${t}`,
		configKey: s.key,
		sourceDigest: r(e.source),
		target: i,
		components: Object.freeze(d),
		themes: Object.freeze(f),
		assembly: l(s),
		resources: Object.freeze(o.map((e) => Object.freeze({
			id: e.id,
			digest: r(e.css)
		})))
	});
}
function W(e) {
	return typeof e == "object" && !!e && !Array.isArray(e) && [Object.prototype, null].includes(Object.getPrototypeOf(e));
}
function G(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 256;
}
function K(o, s) {
	if (o === void 0) return [];
	let l = [], u = (e, t) => l.push({
		code: `local.extension.restore-${e}`,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	});
	try {
		if (!W(o) || e(o) > 262144 || o.protocol !== "reactive-md-restore/v1" || !G(o.sdk) || !G(o.configKey) || !G(o.sourceDigest) || ![
			"static",
			"ssr",
			"offline"
		].includes(o.target) || !Array.isArray(o.components) || o.components.length > 192 || !Array.isArray(o.themes) || o.themes.length > 16 || !Array.isArray(o.resources) || o.resources.length > 128) return u("metadata", "Invalid or oversized restoration requirements."), l;
		let d = /* @__PURE__ */ new Set([
			"protocol",
			"sdk",
			"configKey",
			"sourceDigest",
			"target",
			"components",
			"themes",
			"resources",
			"assembly"
		]);
		Object.keys(o).some((e) => !d.has(e)) && u("metadata", "Unknown restoration requirement field.");
		let f = s.config === void 0 ? m() : h(s.config);
		i(o.sdk) && n("0.7.0", o.sdk) || u("sdk", `SDK ${t} does not satisfy ${o.sdk}.`), c(f, o.configKey) || u("config", "The installed configuration differs from the exported configuration."), o.assembly !== void 0 && (W(o.assembly) && o.assembly.protocol === "reactive-md-assembly-seal/v1" && G(o.assembly.configKey) && c(f, o.assembly.configKey) || u("assembly", "The exported assembly identity is invalid or belongs to another configuration.")), r(s.source) !== o.sourceDigest && u("source", "The source differs from the exported source. Recompile before restoring state.");
		let p = /* @__PURE__ */ new Set();
		for (let e of o.components) {
			if (!W(e) || ![
				"id",
				"name",
				"version",
				"range",
				"digest"
			].every((t) => G(e[t])) || !i(e.range) || p.has(e.id)) {
				u("metadata", "Invalid or duplicate component restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = f.registry.find((t) => t.id === e.id);
			if (!t) {
				u("component-missing", `Required component ${e.id}@${e.version} is not installed.`);
				continue;
			}
			n(t.version, e.range) || u("version", `Component ${e.id}@${t.version} does not satisfy ${e.range}.`), (t.version !== e.version || t.name !== e.name || a(t) !== e.digest) && u("contract", `Component ${e.id}@${e.version} differs from the installed contract. Recompile and validate state before upgrading.`);
			let r = o.target === "offline" ? [
				"interactive",
				"static",
				"offline"
			] : [o.target];
			for (let n of r) t.capabilities[n] || u("capability", `Component ${e.id} cannot render ${n}.`);
		}
		if (s.document) {
			let e = U(s.document, f, o.target);
			for (let t of e.components) p.has(t.id) || u("component-missing", `Used component ${t.id} is missing from restoration requirements.`);
		}
		p.clear();
		for (let e of o.themes) {
			if (!W(e) || ![
				"id",
				"name",
				"version",
				"digest"
			].every((t) => G(e[t])) || p.has(e.id)) {
				u("metadata", "Invalid or duplicate theme restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = f.themes.find((t) => t.id === e.id);
			t && t.name === e.name && t.version === e.version && H(t) === e.digest || u("theme", `Required theme ${e.id}@${e.version} does not match the installed theme.`);
		}
		if (s.document) {
			let e = f.themes.find((e) => e.name === s.document.theme);
			e && !p.has(e.id) && u("theme", `Selected theme ${e.id} is missing from restoration requirements.`);
		}
		let g = y(s.resources ?? []);
		l.push(...g.diagnostics);
		let _ = new Map(g.resources.map((e) => [e.id, e.css]));
		p.clear();
		for (let e of o.resources) {
			if (!W(e) || !G(e.id) || !G(e.digest) || p.has(e.id)) {
				u("metadata", "Invalid or duplicate style restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = _.get(e.id);
			t === void 0 ? u("resource-missing", `Required style resource ${e.id} is missing before state restoration.`) : r(t) !== e.digest && u("resource-digest", `Style resource ${e.id} differs from the exported content.`);
		}
		if (s.document) {
			let e = U(s.document, f, o.target), t = new Set(e.components.map((e) => e.id)), n = f.registry.filter((e) => t.has(e.id)).flatMap((e) => e.styles ?? []);
			n.push(...f.themes.filter((e) => e.name === s.document.theme).flatMap((e) => e.css.map((e) => e.id)));
			for (let e of n) p.has(e) && _.has(e) || u("resource-missing", `Used style resource ${e} is required before state restoration.`);
		}
	} catch (e) {
		u("metadata", e instanceof Error ? e.message : String(e));
	}
	return l;
}
// src/shareable.ts
var q = "reactive-md-html/v1", J = "reactive-md-html/v2", he = /^[A-Za-z][A-Za-z0-9_-]*$/, ge = /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/, _e = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, ve = /[\u0000-\u001f\u007f-\u009f]/, Y = 64, ye = 41943040, be = 4096;
function X(e, t = !1) {
	let n = e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return t && (n = n.replace(/"/g, "&quot;").replace(/'/g, "&#39;")), n;
}
function xe(e) {
	return e.replace(/<\/style/gi, "<\\/style");
}
function Se(e) {
	return e.replace(/<\/script/gi, "<\\/script").replace(/<!--/g, "<\\!--");
}
function Z(e) {
	return X(e, !0);
}
function Q(e) {
	let t = JSON.stringify(e);
	if (typeof t != "string") throw TypeError("Cannot serialize a non-JSON value for an inline script.");
	return t.replace(/[<>&\u2028\u2029]/g, (e) => {
		switch (e) {
			case "<": return "\\u003c";
			case ">": return "\\u003e";
			case "&": return "\\u0026";
			case "\u2028": return "\\u2028";
			default: return "\\u2029";
		}
	});
}
function $(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function Ce(e) {
	try {
		return V(e);
	} catch (e) {
		throw TypeError(`createShareableHtml received invalid compileOptions: ${e instanceof Error ? e.message : String(e)}`);
	}
}
function we(e, t) {
	let n = t.enableExtendedHtml ? "frame-src about: data: blob:" : "frame-src 'none'", r = e ? "script-src 'unsafe-inline'" + (t.enableJavaScript ? " 'wasm-unsafe-eval'" : "") : "script-src 'none'", i = e && t.enableJavaScript ? "worker-src blob:" : "worker-src 'none'";
	return `default-src 'none'; img-src data:; style-src 'unsafe-inline'; ${r}; font-src data:; ${e ? "connect-src 'none'; media-src 'none'; " : ""}object-src 'none'; ${n}; ${i}; base-uri 'none'; form-action 'none'`;
}
function Te(e, t) {
	if (t.enableCss && t.enableExtendedHtml || !/data-(?:rmd-(?:snapshot|author)-css|extended-html)/i.test(e)) return;
	let n = [...p(e).childNodes];
	for (; n.length;) {
		let e = n.pop();
		if (f.isElementNode(e)) {
			for (let { name: n, value: r } of e.attrs) {
				if (!t.enableCss && (n === "data-rmd-snapshot-css" || e.tagName === "style" && n === "data-rmd-author-css")) throw TypeError("Render staticMarkup with author CSS disabled before exporting with enableCss: false.");
				if (!t.enableExtendedHtml && n === "data-extended-html" && (r === "direct" || r === "sandbox")) throw TypeError("Render staticMarkup with Extended HTML disabled before exporting with enableExtendedHtml: false.");
			}
			for (let t of e.childNodes) n.push(t);
		}
	}
}
function Ee(e) {
	if (e === void 0) return;
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("images must be an object mapping relative URLs to data: image URLs.");
	let t = Object.entries(e);
	if (t.length > Y) throw RangeError(`images cannot contain more than ${Y} entries.`);
	let n = 0;
	for (let [e, r] of t) {
		if (!e || e.length > be || ve.test(e) || e === "__proto__") throw TypeError("Every image key must be a bounded, control-free URL.");
		if (typeof r != "string" || !_e.test(r)) throw TypeError(`The image map for "${e}" must contain a base64 PNG, JPEG, GIF or WebP data URL.`);
		if (n += r.length, n > ye) throw RangeError("The embedded image map exceeds the 40 MiB budget.");
	}
	return Object.fromEntries(t);
}
function De(e, t) {
	let n = z(e, t);
	if (!n.ok) return n;
	let r = {};
	for (let [t, i] of Object.entries(e.bindings)) r[t] = Object.hasOwn(n.state, t) ? {
		...i,
		initial: $(n.state[t])
	} : i;
	let i = { ...e.initialState };
	for (let [e, t] of Object.entries(n.state)) i[e] = $(t);
	return {
		ok: !0,
		baseline: {
			document: {
				...e,
				bindings: r,
				initialState: i
			},
			state: n.state
		}
	};
}
var Oe = "\n:root { color-scheme: light; background: #f5f7fb; }\nhtml, body { margin: 0; }\nbody.reactive-md-export {\n  min-height: 100vh;\n  padding: clamp(16px, 4vw, 48px);\n  background: #f5f7fb;\n  color: #17233d;\n  font-family: system-ui, -apple-system, \"Segoe UI\", sans-serif;\n}\n.reactive-md-export-root { max-width: 840px; margin: 0 auto; }\n@media print {\n  :root, html, body.reactive-md-export { background: #fff !important; }\n  body.reactive-md-export { min-height: 0; padding: 0 !important; }\n  .reactive-md-export-root { max-width: none !important; margin: 0 !important; }\n}\n";
function ke(e) {
	let t = e.targetId ?? "reactive-md-document";
	if (!he.test(t)) throw TypeError("targetId must start with a letter and contain only letters, digits, underscores or hyphens.");
	let n = e.mode === "static" ? "static" : "interactive";
	if (!e.staticMarkup.trim()) throw TypeError("createShareableHtml requires rendered document markup.");
	if (!e.css.trim()) throw TypeError("createShareableHtml requires the document stylesheet.");
	if (e.state.sourceDigest !== _(e.source)) throw Error("The state file does not belong to the exported source.");
	if (n === "interactive" && !e.runtimeScript?.trim()) throw TypeError("Interactive HTML requires the standalone runtime script.");
	let r = Ce(e.compileOptions), i = ne(e.extensions, r?.config);
	if (i.push(...K(e.restoration, {
		config: r?.config,
		source: e.source,
		resources: e.resources
	})), i.length) throw TypeError(i.map((e) => e.message).join(" "));
	let a = g(r);
	if (!a.ok) throw TypeError(`createShareableHtml received invalid compileOptions: ${a.message}`);
	Te(e.staticMarkup, a.html);
	let o = e.documentId === void 0 ? void 0 : te(e.documentId);
	if (e.documentId !== void 0 && o === void 0) throw TypeError("createShareableHtml received an invalid documentId.");
	let s;
	if (e.randomSeed !== void 0) {
		if (!Number.isInteger(e.randomSeed) || e.randomSeed < 0 || e.randomSeed > 4294967295) throw TypeError("createShareableHtml received an invalid randomSeed; expected a 32-bit unsigned integer.");
		s = e.randomSeed;
	}
	let c;
	if (e.componentState !== void 0) {
		let t = ee(e.componentState);
		if (!t.ok || t.diagnostics.length > 0) {
			let e = t.diagnostics.map((e) => e.message).join(" ");
			throw TypeError(`createShareableHtml received an invalid component state${e ? `: ${e}` : "."}`);
		}
		c = t.document;
	}
	let l = e.locale === "zh" ? "zh" : "en", u = l === "zh" ? "zh-CN" : "en", d = e.colorScheme === "light" || e.colorScheme === "dark" ? e.colorScheme : "auto", f = e.assets === "omit" ? "omit" : "inline", p = e.generator ?? {
		name: "reactive-md",
		version: "unknown"
	}, m = Ee(e.images), h = Number.isSafeInteger(e.imageCount) && (e.imageCount ?? 0) > 0 ? String(e.imageCount) : String(Object.keys(m ?? {}).length), v = n === "interactive", y = {
		version: e.restoration ? 2 : 1,
		sourceSemantics: "mixed-rmd-v1",
		target: t,
		source: e.source,
		state: e.state,
		locale: l,
		colorScheme: d,
		hydrate: !0,
		compileOptions: {
			...r,
			...a.html
		},
		...e.extensions === void 0 ? {} : { extensions: e.extensions },
		...e.restoration === void 0 ? {} : {
			restoration: e.restoration,
			resources: e.resources ?? []
		},
		...m ? { images: m } : {},
		...o === void 0 ? {} : { documentId: o },
		...s === void 0 ? {} : { randomSeed: s },
		...c === void 0 ? {} : { componentState: c }
	}, b = we(v, a.html), x = v ? `<script type="application/reactive-md+json" data-reactive-md-auto>${Q(y)}<\/script>
<script>${Se(e.runtimeScript)}<\/script>` : "", S = e.notices?.trim() ? `<template id="reactive-md-notices"><pre>${X(e.notices)}</pre></template>` : "", C = !v && e.extensions ? `<template id="reactive-md-extensions">${X(JSON.stringify(e.extensions))}</template>` : "";
	return `<!doctype html>
<html lang="${X(ge.test(u) ? u : "en", !0)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="${Z(b)}">
<meta name="generator" content="${Z(`${p.name} ${p.version}`)}">
<meta name="reactive-md-html-format" content="${e.restoration ? J : q}">
<meta name="reactive-md-syntax" content="${Z(e.state.syntax)}">
<meta name="reactive-md-output" content="${n}">
<meta name="reactive-md-state" content="${Z(e.state.sourceDigest)}">
<meta name="reactive-md-images" content="${f}">
<meta name="reactive-md-image-count" content="${h}">
<title>${X(e.title || "Reactive MD document")}</title>
<style>${xe(e.css)}${Oe}</style>
</head>
<body class="reactive-md-export">
<div id="${t}" class="reactive-md-export-root">${e.staticMarkup}</div>
${x}
${C}
${S}
</body>
</html>
`;
}
export { F as _, Q as a, pe as c, V as d, b as f, de as g, ue as h, De as i, H as l, P as m, J as n, me as o, B as p, ke as r, U as s, q as t, K as u, z as v, fe as y };
