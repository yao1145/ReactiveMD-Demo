import { O as e, P as t, T as n, z as r } from "./preset-core-CKc5YXSM.js";
import { f as i, i as a, y as o } from "./config-BadfhjdP.js";
import { t as s } from "./resources-D2GDQS0p.js";
import { G as c, n as l } from "./sdk-core-BoJT1SIt.js";
// src/react/package-core.ts
function u(e) {
	let t = s(e);
	if (t.diagnostics.length) throw TypeError(t.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	return t.resources;
}
function d(t) {
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("defineReactPreset requires a preset package object.");
	if (t.protocol !== "reactive-md-react-preset/v1") throw TypeError(`React preset protocol must be "${r}".`);
	let n = i(t.preset);
	if (!Array.isArray(t.components)) throw TypeError("React preset components must be an array.");
	let a = new Map(n.components.map((e) => [e.id, e])), o = /* @__PURE__ */ new Set(), s = [];
	for (let r of t.components) {
		let t = r?.definition;
		if (!t || typeof t.id != "string") throw TypeError("React preset contains a component without a manifest definition.");
		let i = a.get(t.id);
		if (!i) throw TypeError(`React preset "${n.id}" has no semantic component "${t.id}".`);
		if (e(i) !== e(t) || r.digest !== e(t)) throw TypeError(`React preset component "${t.id}" does not match its semantic manifest.`);
		if (o.has(t.id)) throw TypeError(`React preset "${n.id}" declares "${t.id}" more than once.`);
		o.add(t.id), s.push(r);
	}
	let c = n.components.filter((e) => !o.has(e.id)).map((e) => e.id);
	if (c.length > 0) throw TypeError(`React preset "${n.id}" is missing implementations for: ${c.join(", ")}.`);
	let l = t.resources === void 0 ? Object.freeze([]) : u(t.resources);
	return Object.freeze({
		protocol: r,
		preset: n,
		components: Object.freeze(s),
		resources: l,
		...t.notices === void 0 ? {} : { notices: Object.freeze([...t.notices]) }
	});
}
function f(e) {
	let { render: r, renderStatic: i, css: a, resources: o = [], ...s } = e, l = s.styles ?? [...new Set(a === void 0 ? o.map((e) => e.id) : [`${s.id}.css`, ...o.map((e) => e.id)])];
	if (a !== void 0 && l.length === 0) throw TypeError("Inline css requires a style resource identity.");
	let d = n({
		...s,
		protocol: s.protocol === void 0 ? t : s.protocol,
		form: s.form === void 0 ? "leaf" : s.form,
		props: s.props === void 0 ? {} : s.props,
		...l.length ? { styles: l } : {}
	});
	if (a !== void 0 && typeof a != "string") throw TypeError("Component css must be an inline string.");
	let f = u([...a === void 0 ? [] : [{
		id: l[0] ?? `${d.id}.css`,
		css: a
	}], ...o]);
	for (let e of d.styles ?? []) if (!f.some((t) => t.id === e)) throw TypeError(`Component ${d.id} is missing style resource ${e}.`);
	let p = c(d, {
		render: r,
		...i === void 0 ? {} : { renderStatic: i }
	});
	return Object.freeze({
		definition: d,
		components: Object.freeze([p]),
		resources: f
	});
}
function p(e, t, n, r) {
	let i = /* @__PURE__ */ new Map(), a = (e, t) => {
		let n = i.get(e.id);
		if (n !== void 0 && n !== e.css) throw TypeError(`Style resource "${e.id}" has conflicting contents in ${t}.`);
		n === void 0 && i.set(e.id, e.css);
	};
	for (let e of u(t)) a(e, "a component or preset package");
	for (let e of u(n)) a(e, "host resources");
	for (let e of r) for (let t of e.css) a(t, `theme "${e.id}"`);
	let o = [], s = /* @__PURE__ */ new Set();
	for (let t of e.registry) for (let e of t.styles ?? []) {
		if (s.has(e)) continue;
		let n = i.get(e);
		if (n === void 0) throw TypeError(`Component ${t.id} is missing style resource ${e}.`);
		s.add(e), o.push(Object.freeze({
			id: e,
			css: n
		}));
	}
	for (let e of n) {
		if (s.has(e.id)) continue;
		let t = i.get(e.id);
		s.add(e.id), o.push(Object.freeze({
			id: e.id,
			css: t
		}));
	}
	for (let e of r) for (let t of e.css) s.has(t.id) || (s.add(t.id), o.push(Object.freeze({
		id: t.id,
		css: t.css
	})));
	return Object.freeze(o);
}
function m(e, t) {
	let n = e.presets, r = (n ?? ["default"]).map((e) => e === "default" ? t.preset : e.preset), i = n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.components), s = n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.resources ?? []), c = e.packages ?? [], u = [...c.flatMap((e) => e.components), ...e.components ?? []], d = a({
		presets: r,
		components: u.map((e) => e.definition),
		...e.replacements === void 0 ? {} : { replacements: e.replacements },
		themes: [...c.flatMap((e) => e.themes ?? []), ...e.themes ?? []]
	}), f = l(d, { components: [...i, ...u] }, n === void 0 || n.includes("default") ? t.components : []), m = p(d, c.flatMap((e) => e.resources ?? []), [...s, ...e.resources ?? []], d.themes), h = Object.freeze([
		...n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.notices ?? []),
		...c.flatMap((e) => e.notices ?? []),
		...e.notices ?? []
	]);
	return Object.freeze({
		config: f.config,
		reactConfig: f,
		compileOptions: Object.freeze({ config: f.config }),
		resources: m,
		css: `${o}\n${m.map((e) => e.css).join("\n")}`,
		notices: h
	});
}
export { f as n, d as r, m as t };
