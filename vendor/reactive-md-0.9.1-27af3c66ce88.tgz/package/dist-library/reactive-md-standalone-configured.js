import { t as e } from "./LocalDocumentViewCore-GiWV3bey.js";
import { i as t } from "./session-core-nmJHuR9c.js";
import { jsx as n } from "react/jsx-runtime";
// src/standalone/host.tsx
function r(t) {
	let { reactConfig: r } = t;
	if (!r) throw TypeError("A standalone host requires an installed React configuration.");
	return /* @__PURE__ */ n(e, {
		...t,
		getBaseConfig: () => r
	});
}
function i(e, n) {
	return t(r, e, n);
}
export { i as mountAll };
