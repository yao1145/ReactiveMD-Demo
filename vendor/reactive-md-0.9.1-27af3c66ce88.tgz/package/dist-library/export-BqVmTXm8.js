import { O as e } from "./preset-core-CKc5YXSM.js";
import { f as t, l as n, u as r } from "./config-validation-F47AcE6o.js";
import { a as i, l as a, o, s } from "./parser-standard-Yuf3A_VI.js";
import { l as c, s as l, y as u } from "./config-BadfhjdP.js";
import { n as d } from "./registry-B9NGct4d.js";
import { _ as f, c as p, i as m, l as h, o as g, r as _, s as v } from "./shareable-DpbE-59H.js";
import { i as y, n as b, r as x, t as S } from "./resources-D2GDQS0p.js";
// src/export/render-markup.ts
var C = "data-rmd-extension-error", ee = "data-local-extension-error", te = "data-local-host-component", ne = "local-sdk-unavailable", w = 300, T = /(?:data-rmd-extension-error|data-local-extension-error|local-sdk-unavailable)/i;
function E(e, t) {
	for (let n of e.attrs) if (n.name.toLowerCase() === t) return n.value;
}
function D(e, t) {
	let n = E(e, "class");
	return n !== void 0 && n.split(/\s+/).includes(t);
}
function O(e) {
	let t = e?.replace(/\s+/g, " ").trim();
	if (t) return t.length > w ? `${t.slice(0, w)}…` : t;
}
function k(e) {
	let t = E(e, C);
	if (t !== void 0) {
		let e = O(t);
		return {
			reason: "extension-error",
			...e === void 0 ? {} : { detail: e }
		};
	}
	if (E(e, ee) !== void 0) return { reason: "extension-error" };
	let n = E(e, te);
	if (n !== void 0 && D(e, ne)) {
		let e = O(n);
		return {
			reason: "sdk-unavailable",
			...e === void 0 ? {} : { component: e }
		};
	}
}
function A(e) {
	if (typeof e != "string" || e.trim() === "" || !T.test(e)) return null;
	let t;
	try {
		t = o(e, { scriptingEnabled: !1 });
	} catch {
		return null;
	}
	let n = [];
	for (j(t, n); n.length > 0;) {
		let e = n.pop();
		if (!a.isElementNode(e)) continue;
		let t = k(e);
		if (t) return t;
		let r = e.tagName.toLowerCase() === "template" ? a.getTemplateContent(e).childNodes : e.childNodes;
		for (let e = r.length - 1; e >= 0; --e) n.push(r[e]);
	}
	return null;
}
function j(e, t) {
	for (let n = e.childNodes.length - 1; n >= 0; --n) t.push(e.childNodes[n]);
}
function M(e) {
	return e.reason === "sdk-unavailable" ? e.component ? `Rendered output leaves host component <${e.component}> unavailable.` : "Rendered output leaves a host component unavailable." : e.detail ? `Rendered output contains an unavailable extension component: ${e.detail}` : "Rendered output contains an unavailable extension component.";
}
// src/export/print-document.ts
var N = "reactive-md-native-document", P = "reactive-md-native-frame", F = "reactive-md-export-root", I = "local-extended-fragment-frame", re = "http://www.w3.org/1999/xhtml", ie = /* @__PURE__ */ new Set(/* @__PURE__ */ "article.section.header.footer.div.p.span.figure.figcaption.h1.h2.h3.h4.h5.h6.blockquote.pre.code.br.hr.b.strong.i.em.u.s.del.mark.sub.sup.img.dl.dd.dt.ol.ul.li.table.caption.colgroup.col.thead.tbody.tfoot.tr.th.td".split(".")), ae = /* @__PURE__ */ new Set([
	"alt",
	"title",
	"dir",
	"lang",
	"start",
	"colspan",
	"rowspan",
	"scope"
]), oe = /^data:image\/(?:png|jpeg|gif|webp);base64,[a-z0-9+/]+=*$/i, se = /^reactive-md-html\/v[0-9]+$/, ce = /^\s*<!doctype html>/i, L = /* @__PURE__ */ new Set([
	"script",
	"base",
	"link"
]), R = /* @__PURE__ */ new Set([
	"src",
	"srcset",
	"poster",
	"data",
	"xlink:href",
	"background"
]);
function z(e) {
	return a.isElementNode(e);
}
function B(e) {
	return a.isTextNode(e);
}
function V(e) {
	return a.getTemplateContent(e);
}
function H(e, t) {
	return e.attrs.find((e) => e.name.toLowerCase() === t)?.value;
}
function U(e) {
	let t = H(e, "class");
	return t === void 0 ? [] : t.split(/\s+/).filter(Boolean);
}
function W(e, t) {
	return U(e).includes(t);
}
function G(e, t) {
	for (let n of e.childNodes) if (z(n) && n.tagName.toLowerCase() === t) return n;
	return null;
}
function K(e, t) {
	for (let n of e.childNodes) if (z(n) && n.tagName === "meta" && H(n, "name")?.trim().toLowerCase() === t) return H(n, "content");
}
function le(e) {
	let t = K(e, "reactive-md-html-format");
	return t !== void 0 && se.test(t.trim()) && K(e, "reactive-md-output")?.trim().toLowerCase() === "static";
}
function q(e) {
	let t = e.childNodes.filter((e) => !(B(e) && e.value.trim() === ""));
	return t.length === 1 && z(t[0]) ? t[0] : null;
}
function ue(e) {
	let t = e.childNodes.find((e) => z(e) && W(e, F));
	if (!t || !z(t)) return;
	let n = q(t);
	if (!n || !W(n, N)) return;
	let r = q(n);
	if (!r || r.tagName !== "iframe" || !W(r, P)) return;
	let i = H(r, "sandbox");
	if (!(i === void 0 || /\ballow-(?:same-origin|scripts)\b/i.test(i))) return H(r, "srcdoc");
}
function J(e) {
	return e.childNodes.some((e) => z(e) && e.tagName === "meta" && H(e, "http-equiv")?.trim().toLowerCase() === "content-security-policy");
}
function de(e) {
	return e.split(/[\s,]+/).some((e) => {
		let t = e.trim();
		if (t === "" || t.startsWith("#") || t.startsWith("//")) return t.startsWith("//");
		let n = /^([a-z][a-z0-9+.-]*):/i.exec(t)?.[1].toLowerCase();
		return n !== void 0 && n !== "data" && n !== "about";
	});
}
function Y(e) {
	let t = [];
	for (let n of e) {
		if (!z(n)) {
			t.push(n);
			continue;
		}
		let e = n.tagName.toLowerCase();
		if (!(L.has(e) || e === "meta" && H(n, "http-equiv") !== void 0)) {
			if (n.attrs = n.attrs.filter((e) => {
				let t = e.name.toLowerCase();
				return t.startsWith("on") ? !1 : !R.has(t) || !de(e.value);
			}), e === "template") {
				let e = V(n);
				e.childNodes = Y(e.childNodes);
			}
			n.childNodes = Y(n.childNodes), t.push(n);
		}
	}
	return t;
}
function X(e, t) {
	let n = H(e, "srcdoc"), r = H(e, "sandbox");
	if (n && r !== void 0 && !/\ballow-(?:same-origin|scripts)\b/i.test(r) && t < 5) {
		let e = G(i(n, { scriptingEnabled: !1 }), "html"), r = e && G(e, "head"), a = e && G(e, "body");
		if (r && a && J(r)) return Z(a.childNodes, t + 1);
	}
	let a = H(e, "title");
	return a ? [{
		nodeName: "#text",
		value: a,
		parentNode: null
	}] : [];
}
function Z(e, t) {
	let n = [];
	for (let r of e) {
		if (B(r)) {
			n.push(r);
			continue;
		}
		if (!z(r) || r.namespaceURI !== re) continue;
		if (r.tagName === "iframe") {
			let e = a.createElement("div", r.namespaceURI, []);
			for (let n of X(r, t)) a.appendChild(e, n);
			n.push(e);
			continue;
		}
		if (L.has(r.tagName) || r.tagName === "style" || r.tagName === "template") continue;
		let e = Z(r.childNodes, t);
		ie.has(r.tagName) ? (r.attrs = r.attrs.filter(({ name: e, value: t, namespace: n }) => !n && (ae.has(e) || r.tagName === "img" && e === "src" && oe.test(t))), r.childNodes = e, n.push(r)) : n.push(...e);
	}
	return n;
}
function Q(e) {
	let t = !1;
	for (let n of e.childNodes) {
		if (!z(n)) continue;
		if (H(n, "data-extended-html") !== "sandbox") {
			Q(n) && (t = !0);
			continue;
		}
		let e = q(n);
		e && e.tagName === "iframe" && W(e, I) && (n.childNodes = X(e, 0), t = !0);
	}
	return t;
}
function fe(e) {
	if (!(e.includes(N) && e.includes(P)) && !e.includes(I)) return e;
	let t = i(e, { scriptingEnabled: !1 }), n = G(t, "html"), r = n && G(n, "head"), o = n && G(n, "body");
	if (!r || !o || !le(r)) return e;
	let c = ue(o);
	if (!c || !ce.test(c)) {
		let n = o.childNodes.find((e) => z(e) && W(e, F));
		return n && z(n) && Q(n) ? s(t, { scriptingEnabled: !1 }) : e;
	}
	let l = i(c, { scriptingEnabled: !1 }), u = G(l, "html"), d = u && G(u, "head"), f = u && G(u, "body");
	if (!d || !f || !J(d)) return e;
	let p = a.createElement("meta", r.namespaceURI, [{
		name: "http-equiv",
		value: "Content-Security-Policy"
	}, {
		name: "content",
		value: "default-src 'none'; style-src 'unsafe-inline'; img-src data:; font-src data:; frame-src about: data: blob:; base-uri 'none'; form-action 'none'"
	}]), m = r.childNodes.filter((e) => z(e) && e.tagName === "style"), h = d.childNodes.filter((e) => z(e) && e.tagName === "style");
	return d.childNodes = [
		p,
		...r.childNodes.filter((e) => z(e) && (e.tagName === "meta" || e.tagName === "title") && H(e, "http-equiv")?.toLowerCase() !== "refresh"),
		...m,
		...Y(h)
	], f.childNodes = Y(f.childNodes), s(l, { scriptingEnabled: !1 });
}
async function pe(e) {
	let t = /[\u0000-\u001f\u007f-\u009f]/g, n = (e, n) => {
		let r = typeof e.alt == "string" ? e.alt.replace(t, " ").trim() : "", i = r === "" || /^[a-z][a-z0-9+.-]*:/i.test(r) || r.startsWith("//") ? "" : r, a = i === "" ? `#${n + 1}` : i;
		return a.length > 120 ? `${a.slice(0, 117)}...` : a;
	}, r = e ?? (typeof document > "u" ? void 0 : document);
	if (!r) return [];
	let i = Array.from(r.images ?? []);
	for (let e of i) try {
		e.loading = "eager";
	} catch {}
	let a = r.fonts;
	if (a && typeof a.ready?.then == "function") try {
		await a.ready;
	} catch {}
	let o = await Promise.all(i.map(async (e) => {
		let t;
		try {
			return await Promise.race([e.decode(), new Promise((e, n) => {
				t = setTimeout(() => n(/* @__PURE__ */ Error("image decode timed out")), 15e3);
			})]), !0;
		} catch {
			return !1;
		} finally {
			t !== void 0 && clearTimeout(t);
		}
	})), s = [];
	return o.forEach((e, t) => {
		e || s.push(n(i[t], t));
	}), s;
}
// src/export/index.ts
function me(t, n) {
	let r = l(n);
	if (typeof t != "string" || !t.trim() || t.length > 33554432) throw TypeError("A standalone bundle must contain a nonempty script of at most 32 MiB.");
	return Object.freeze({
		script: t,
		seal: g(t, r),
		extensions: Object.freeze({
			protocol: "reactive-md-extensions/v1",
			components: Object.freeze(r.registry.map((t) => Object.freeze({
				id: t.id,
				name: t.name,
				version: t.version,
				digest: e(t)
			})))
		})
	});
}
function $(e) {
	let i = l(e.config), a = e.document.extensions ?? {
		protocol: "reactive-md-extensions/v1",
		components: []
	}, o = y(a, i);
	o.push(...c(e.document, i)), o.push(...x({
		document: e.document,
		installed: d(i),
		externalNames: new Set(i.components.map((e) => e.name))
	}));
	let s = new Set(e.requiredResources ?? []), f = e.target;
	if (![
		"static",
		"ssr",
		"offline"
	].includes(f)) throw TypeError("Unknown export target.");
	for (let e of a.components) {
		let t = i.registry.find((t) => t.id === e.id);
		if (!t) continue;
		for (let e of t.styles ?? []) s.add(e);
		let n = f === "offline" ? [
			"static",
			"interactive",
			"offline"
		] : [f];
		for (let e of n) t.capabilities[e] || o.push(b("local.extension.export-capability", `${t.id}@${t.version} does not support ${e} for ${f} export.`));
	}
	if (f === "offline") {
		if (!e.bundle?.script?.trim()) o.push(b("local.extension.bundle-missing", "Offline output requires an explicitly built standalone bundle."));
		else {
			o.push(...y(e.bundle.extensions, i));
			let s = e.bundle.seal;
			if (s && (s.protocol !== "reactive-md-bundle/v1" || s.sdkVersion !== "0.7.0" || !t(i, s.configKey) || s.scriptDigest !== p(e.bundle.script)) && o.push(b("local.extension.bundle-integrity", "The bundle script or installed configuration differs from its sealed build manifest.")), s?.assembly !== void 0) {
				let e = n(i);
				(JSON.stringify(s.assembly) !== JSON.stringify(e) || s.seal !== void 0 && s.seal !== r(i)) && o.push(b("local.extension.bundle-assembly", "The bundle assembly identity differs from the installed assembly."));
			}
			for (let t of a.components) e.bundle.extensions.components.some((e) => e.id === t.id && e.digest === t.digest) || o.push(b("local.extension.bundle-mismatch", `The standalone bundle does not include ${t.id}@${t.version}.`));
		}
	}
	let m = e.document.theme ?? "default", g = i.themes.find((e) => e.name === m);
	if (f === "offline" && g && e.bundle?.seal) {
		let t = e.bundle.seal.themes;
		Array.isArray(t) && t.some((e) => e.id === g.id && e.name === g.name && e.version === g.version && e.digest === h(g)) || o.push(b("local.extension.bundle-theme", `Bundle theme ${g.id}@${g.version} differs from the selected export theme. Rebuild the bundle.`));
	}
	m !== "default" && !g && o.push(b("local.extension.theme-missing", `Theme ${m} is not installed for export.`));
	let _ = S([...e.resources ?? [], ...g?.css ?? []]);
	o.push(..._.diagnostics);
	let v = new Map(_.resources.map((e) => [e.id, e]));
	for (let e of s) v.has(e) || o.push(b("local.extension.resource-missing", `Required style resource ${e} is missing.`));
	let C = Object.freeze([...v.values()]);
	return Object.freeze({
		target: f,
		extensions: a,
		resources: C,
		css: `${u}\n${C.map((e) => e.css).join("\n")}`,
		diagnostics: Object.freeze(o),
		ok: o.length === 0
	});
}
function he(e) {
	if (e.document.source !== e.source) throw TypeError("The compiled document does not belong to this source.");
	let t = f(e.state);
	if (!t.ok) throw TypeError(t.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let n = m(e.document, t.file);
	if (!n.ok) throw TypeError(n.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let r = l(e.config);
	if (e.compileOptions?.hostComponents !== void 0 || e.compileOptions?.config && l(e.compileOptions.config).key !== r.key) throw TypeError("Conflicting export component configuration.");
	let i = $({
		...e,
		target: e.mode === "static" ? "static" : "offline"
	});
	if (!i.ok) throw TypeError(i.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let a = A(e.staticMarkup);
	if (a) throw TypeError(M(a));
	return _({
		...e,
		compileOptions: {
			...e.compileOptions,
			config: r
		},
		extensions: i.extensions,
		restoration: v(e.document, r, i.target, i.resources),
		resources: i.resources,
		runtimeScript: e.bundle?.script,
		css: `${e.css}\n${i.css}`
	});
}
export { pe as a, fe as i, he as n, A as o, me as r, M as s, $ as t };
