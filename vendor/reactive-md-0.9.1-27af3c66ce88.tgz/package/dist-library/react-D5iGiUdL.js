import { n as e } from "./sdk-core-BoJT1SIt.js";
import { a as t } from "./LocalDocumentView-sthUP0ct.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
