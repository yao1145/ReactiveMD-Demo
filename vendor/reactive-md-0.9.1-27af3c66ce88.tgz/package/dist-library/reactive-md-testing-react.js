import { s as e } from "./config-BadfhjdP.js";
import { n as t } from "./registry-B9NGct4d.js";
import { t as n } from "./compiler-eOfcinZs.js";
import { n as r } from "./runtime-kcA7bG7G.js";
import { t as i } from "./LocalDocumentView-sthUP0ct.js";
import { O as a, b as o, c as s, g as c, h as l, k as u, l as d, m as f, o as p, p as m, t as h, u as g, y as _ } from "./values-CIt8AjiU.js";
import { o as v } from "./export-BqVmTXm8.js";
import { renderLocalStaticDocument as y } from "./reactive-md-react-server.js";
import { createElement as b } from "react";
import { renderToString as x } from "react-dom/server";
// src/testing/react.tsx
var S = /* @__PURE__ */ new Set([
	"protocol",
	"source",
	"staticMarkupIncludes",
	"staticMarkupExcludes",
	"ssrMarkupIncludes",
	"ssrMarkupExcludes",
	"error"
]), C = /* @__PURE__ */ new Set([
	"source",
	"config",
	"reactConfig",
	"code",
	"messageIncludes"
]), w = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
function T(e, t) {
	if (e === void 0) return;
	let n = d(e, t, 16);
	for (let e of n) if (e.length === 0) throw TypeError(`${t} must not contain empty strings.`);
	return n;
}
function E(t) {
	let n = g(t, "spec.error");
	if (h(n, C, "spec.error"), n.source === void 0) throw TypeError("spec.error.source is required.");
	let r = s(n.source, "spec.error.source", a);
	if (r.trim() === "") throw TypeError("spec.error.source must not be empty.");
	let i;
	n.config !== void 0 && (i = e(n.config));
	let o;
	if (n.reactConfig !== void 0) {
		let e = g(n.reactConfig, "spec.error.reactConfig");
		if (!e.config || typeof e != "object") throw TypeError("spec.error.reactConfig must expose a config object.");
		o = n.reactConfig;
	}
	let c = n.code === void 0 ? void 0 : s(n.code, "spec.error.code", 128), l = n.messageIncludes === void 0 ? void 0 : s(n.messageIncludes, "spec.error.messageIncludes", u);
	return Object.freeze({
		source: r,
		...i === void 0 ? {} : { config: i },
		...o === void 0 ? {} : { reactConfig: o },
		...c === void 0 ? {} : { code: c },
		...l === void 0 ? {} : { messageIncludes: l }
	});
}
function D(e) {
	let t = g(e, "spec");
	if (h(t, S, "spec"), t.protocol !== "reactive-md-react-spec/v1") throw TypeError(`spec.protocol must be "${o}".`);
	let n = s(t.source, "spec.source", a);
	if (n.trim() === "") throw TypeError("spec.source must not be empty.");
	let r = T(t.staticMarkupIncludes, "spec.staticMarkupIncludes"), i = T(t.staticMarkupExcludes, "spec.staticMarkupExcludes"), c = T(t.ssrMarkupIncludes, "spec.ssrMarkupIncludes"), l = T(t.ssrMarkupExcludes, "spec.ssrMarkupExcludes");
	for (let [e, t] of [[r, i], [c, l]]) for (let n of e ?? []) if (t?.includes(n)) throw TypeError(`spec requires and forbids markup "${n}" at the same time.`);
	let u = t.error === void 0 ? void 0 : E(t.error);
	return Object.freeze({
		protocol: o,
		source: n,
		...r === void 0 ? {} : { staticMarkupIncludes: r },
		...i === void 0 ? {} : { staticMarkupExcludes: i },
		...c === void 0 ? {} : { ssrMarkupIncludes: c },
		...l === void 0 ? {} : { ssrMarkupExcludes: l },
		...u === void 0 ? {} : { error: u }
	});
}
function O(e, t) {
	let n = [], r = [...e];
	for (; r.length > 0;) {
		let e = r.pop();
		if (e && (e.type !== "text" && e.name === t && n.push(e), Array.isArray(e.children))) for (let t of e.children) r.push(t);
	}
	return n;
}
function k(e, t, n, r) {
	let i = [];
	e.trim() === "" && i.push(`${r} markup is empty.`), v(e) && i.push(`${r} markup contains an unavailable component placeholder.`);
	for (let n of t ?? []) e.includes(n) || i.push(`${r} markup does not include ${JSON.stringify(n)}.`);
	for (let t of n ?? []) e.includes(t) && i.push(`${r} markup unexpectedly includes ${JSON.stringify(t)}.`);
	return i;
}
function A(e) {
	return e.some((e) => e.severity === "error");
}
function j(a) {
	if (!a || typeof a != "object") throw TypeError("runLocalReactCompliance requires an options object.");
	let o = e(a.config), u = D(a.spec), d = s(a.component, "component", 128);
	if (!w.test(d)) throw TypeError("component must be a lowercase kebab-case tag name.");
	let h = a.reactConfig;
	if (!h || typeof h != "object" || !h.config) throw TypeError("reactConfig must be a LocalReactConfig.");
	if (e(h.config).key !== o.key) throw TypeError("reactConfig was built for a different LocalConfig.");
	let g = t(o).find((e) => e.name === d), v = [], S = g ? Object.freeze({
		id: g.id,
		name: g.name,
		version: g.version
	}) : null;
	if (!g) return v.push(m("react.component", "react", `Component <${d}> is not installed in this configuration.`)), Object.freeze({
		protocol: _,
		suite: "react",
		configKey: o.key,
		component: S,
		cases: Object.freeze(v)
	});
	let C = g, T = n(u.source, { config: o });
	if (!T.ok) return v.push(m("react.compile", "react", "The compliance source did not compile.", T.diagnostics)), v.push(l("react.static", "react", "Skipped because the source did not compile.", ["static"])), v.push(l("react.ssr", "react", "Skipped because the source did not compile.", ["ssr"])), Object.freeze({
		protocol: _,
		suite: "react",
		configKey: o.key,
		component: S,
		cases: Object.freeze(v)
	});
	if (v.push(f("react.compile", "react")), O(T.document.nodes, d).length === 0) return v.push(m("react.node", "react", `The source does not use <${d}>.`)), Object.freeze({
		protocol: _,
		suite: "react",
		configKey: o.key,
		component: S,
		cases: Object.freeze(v)
	});
	v.push(f("react.node", "react"));
	let E = r(T.document);
	try {
		let e = a.locale === "zh" ? "zh" : "en";
		if (C.capabilities.static !== !0) v.push(c("react.static", "react", "The manifest does not declare static rendering.", ["static"]));
		else {
			let t = [];
			try {
				let n = x(b(i, {
					document: T.document,
					runtime: E,
					reactConfig: h,
					mode: "static",
					staticFirst: !1,
					locale: e,
					onDiagnostics(e) {
						t.push(...e);
					}
				})), r = k(n, u.staticMarkupIncludes, u.staticMarkupExcludes, "Static");
				A(t) && r.push(`Static rendering reported ${t.length} diagnostics.`), v.push(r.length === 0 ? f("react.static", "react", {
					capabilities: ["static"],
					observed: { bytes: n.length }
				}) : m("react.static", "react", r.join(" "), t));
			} catch (e) {
				v.push(m("react.static", "react", `Static rendering threw: ${p(e)}`));
			}
		}
		if (C.capabilities.ssr !== !0) v.push(c("react.ssr", "react", "The manifest does not declare SSR.", ["ssr"]));
		else {
			let t = [], n = [];
			try {
				let r = y({
					document: T.document,
					runtime: E,
					reactConfig: h,
					locale: e,
					resources: a.resources,
					onDiagnostics(e) {
						t.push(...e);
					}
				}), i = y({
					document: T.document,
					runtime: E,
					reactConfig: h,
					locale: e,
					resources: a.resources,
					onDiagnostics(e) {
						n.push(...e);
					}
				}), o = [];
				if (!r.ok || !i.ok) {
					let e = [...r.diagnostics, ...i.diagnostics];
					v.push(m("react.ssr", "react", "Strict SSR execution failed.", e));
				} else r.markup !== i.markup && o.push("Two SSR executions produced different markup."), o.push(...k(r.markup, u.ssrMarkupIncludes, u.ssrMarkupExcludes, "SSR")), (A(t) || A(n)) && o.push("SSR reported error diagnostics."), v.push(o.length === 0 ? f("react.ssr", "react", {
					capabilities: ["ssr"],
					observed: { bytes: r.markup.length }
				}) : m("react.ssr", "react", o.join(" ")));
			} catch (e) {
				v.push(m("react.ssr", "react", `SSR threw instead of returning diagnostics: ${p(e)}`));
			}
		}
		if (!u.error) v.push(l("react.error-isolation", "react", "No server error probe was supplied; error isolation is not claimed."));
		else {
			let t = u.error, i = t.config ?? o, s = t.reactConfig ?? h, c = n(t.source, { config: i });
			if (!c.ok) v.push(m("react.error-isolation", "react", "The error probe source did not compile.", c.diagnostics));
			else {
				let n = r(c.document);
				try {
					let r = y({
						document: c.document,
						runtime: n,
						reactConfig: s,
						locale: e,
						resources: a.resources
					}), i = t.code ?? "local.extension.ssr-render", o = !r.ok && r.diagnostics.some((e) => e.code === i && (t.messageIncludes === void 0 || e.message.includes(t.messageIncludes)));
					v.push(o ? f("react.error-isolation", "react") : m("react.error-isolation", "react", `Expected a ${i} diagnostic from the server error probe.`, r.ok ? [] : r.diagnostics));
				} catch (e) {
					v.push(m("react.error-isolation", "react", `The server error probe threw instead of returning diagnostics: ${p(e)}`));
				} finally {
					n.dispose();
				}
			}
		}
	} finally {
		E.dispose();
	}
	return Object.freeze({
		protocol: _,
		suite: "react",
		configKey: o.key,
		component: S,
		cases: Object.freeze(v)
	});
}
function M(e, t, n) {
	return Object.freeze(k(e, t, n, "Rendered"));
}
var N = Object.freeze(["static", "ssr"]);
export { N as REACT_COMPLIANCE_CAPABILITIES, M as checkLocalComplianceMarkup, D as readLocalReactSpec, j as runLocalReactCompliance };
