import { z as e } from "./preset-core-CKc5YXSM.js";
import { G as t } from "./sdk-core-BoJT1SIt.js";
import { r as n } from "./package-core-WFK1RhAZ.js";
// src/components/mount-preset.ts
function r(r, i, a = []) {
	return n({
		protocol: e,
		preset: r,
		components: r.components.map((e) => t(e, { render: i[e.name] })),
		resources: a
	});
}
export { r as t };
