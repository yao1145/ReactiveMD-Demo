import { a as e, i as t, r as n, s as r } from "./latex-1w7aQgD5.js";
import { A as i, B as a, C as o, F as s, I as c, M as l, N as u, P as d, S as f, j as p, w as m, x as h } from "./config-validation-F47AcE6o.js";
import { a as g, t as _ } from "./compile-wUv8KEge.js";
import { d as v } from "./compiler-core-As_m-MNm.js";
import { S as y, g as b } from "./validation-BEBA_HvS.js";
import { c as x } from "./config-BadfhjdP.js";
import { t as S } from "./options-1aDLK7JY.js";
import { t as ee } from "./compiler-eOfcinZs.js";
import { i as te, n as ne, r as re, t as C } from "./authoring-Dsune4Hy.js";
import { c as w } from "./schema-BufhKUSM.js";
import { n as T, t as ie } from "./incremental-Dv0FSp_U.js";
import { C as ae } from "./component-state-BoLCGee4.js";
import { a as oe, i as se, n as ce, o as le, r as ue } from "./runtime-kcA7bG7G.js";
import { i as de, n as fe, r as pe, t as me } from "./sample-bP4zHB3L.js";
import { _ as he, a as ge, f as _e, g as ve, h as ye, i as be, m as xe, n as Se, p as Ce, r as we, t as Te, v as Ee, y as De } from "./shareable-DpbE-59H.js";
import { t as Oe } from "./component-state-C52ZFJGl.js";
// src/local/source/source-migration.ts
var E = /* @__PURE__ */ new Set([
	"sum",
	"average",
	"minOf",
	"maxOf",
	"formatNumber",
	"formatPercent",
	"formatScientific",
	"formatCurrency",
	"trim",
	"lower",
	"upper",
	"startsWith",
	"endsWith",
	"replace",
	"slice",
	"dateCompare",
	"dateDiff"
]), ke = /* @__PURE__ */ new Set([
	"jump",
	"anchor",
	"text",
	"section",
	"multi-select",
	"range-slider",
	"coordinate",
	"quiz",
	"steps",
	"step",
	"computed",
	"const",
	"validation",
	"data-table",
	"column",
	"external"
]), Ae = /* @__PURE__ */ new Set(["external"]), je = /* @__PURE__ */ new Set([
	"local-draft-1",
	"local-draft-2",
	y
]), Me = `<!-- reactive-md: ${y} -->`;
function Ne(e) {
	let t = e.diagnostics.filter((t) => t.code.startsWith("local.version.") || t.code === "local.budget" || t.code === "local.parse" && !e.nodes.length), n = e.versionDeclaration?.version ?? null;
	return {
		declaredVersion: n,
		effectiveVersion: n ?? "local-draft-3",
		supported: !t.some((e) => e.severity === "error"),
		range: e.versionDeclaration ? { ...e.versionDeclaration.range } : null,
		diagnostics: t
	};
}
function Pe(e) {
	return Ne(w(e));
}
function Fe(e, t, n, r, i = "error") {
	let a = d(t, r), o = e.slice(0, n.start), s = o.lastIndexOf("\n");
	return {
		code: t,
		severity: i,
		range: { ...n },
		message: p(a),
		line: o.split("\n").length,
		column: n.start - s,
		messageKey: a.key,
		...a.params ? { params: a.params } : {}
	};
}
function Ie(e, t = {}) {
	let n = w(e), r = Ne(n), i = typeof t == "object" && !!t && !Array.isArray(t), a = i ? t.fromVersion ?? r.effectiveVersion : r.effectiveVersion, o = typeof a == "string" ? a : "", s = {
		ok: !1,
		fromVersion: o,
		toVersion: y,
		needsMigration: !n.versionDeclaration || o !== "local-draft-3",
		diagnostics: r.diagnostics.filter((e) => e.code !== "local.version.unsupported")
	}, c = {
		report: s,
		declaration: n.versionDeclaration
	};
	if (typeof e != "string" || s.diagnostics.some((e) => e.severity === "error")) return c;
	let l = r.range ?? {
		start: 0,
		end: 0
	}, u = (e) => {
		if (s.diagnostics.length >= 100) {
			if (e.severity === "warning") return;
			let t = s.diagnostics.length - 1;
			for (; t >= 0 && s.diagnostics[t].severity !== "warning";) --t;
			if (t < 0) return;
			s.diagnostics.splice(t, 1);
		}
		s.diagnostics.push(e);
	}, d = (t, n, r, i) => {
		u(Fe(e, t, n, r, i));
	};
	if (!i || typeof a != "string" || !je.has(o) || t.allowSemanticChanges !== void 0 && typeof t.allowSemanticChanges != "boolean" || t.fromVersion !== void 0 && r.declaredVersion !== null && o !== r.declaredVersion) return d("local.upgrade.from-version", l, {
		from: o,
		detail: "use local-draft-1, local-draft-2 or local-draft-3 and match the source declaration"
	}), c;
	let f = n.versionDeclaration ? e.slice(0, l.start) + e.slice(l.start, l.end).replace(/[^\r\n]/g, " ") + e.slice(l.end) : e, p = n.versionDeclaration ? w(f) : n;
	if (o === "local-draft-1" || o === "local-draft-2") {
		let e = o === "local-draft-1" ? ke : Ae, n = (r) => {
			for (let i of r) if (i.name && e.has(i.name)) d("local.upgrade.tag", i.range, { name: i.name });
			else {
				if (o === "local-draft-1") {
					for (let e of [
						"bind",
						"bind-start",
						"bind-end",
						"bind-x",
						"bind-y"
					]) {
						let t = i.attrs?.[e];
						t && E.has(t) && d("local.upgrade.reserved-binding", i.range, { name: t });
					}
					(i.name === "input" || i.name === "textarea") && (i.attrs?.["max-length"] !== void 0 || Number(i.attrs?.["min-length"] ?? 0) > 0) && d("local.upgrade.text-length", i.range, void 0, t.allowSemanticChanges ? "warning" : "error");
					let e = [...i.type === "interpolation" ? [i.value ?? ""] : [], ...Object.values(i.attrs ?? {}).flatMap((e) => [...e.matchAll(/\{\{([\s\S]*?)\}\}/g)].map((e) => e[1]))];
					for (let t of e) {
						let e = t.replace(/'(?:\\.|[^'\\])*'|"(?:\\.|[^"\\])*"/g, "");
						(e.includes("[") || [...E].some((t) => RegExp(`\\b${t}\\s*\\(`).test(e))) && d("local.upgrade.expression", i.range);
					}
				}
				i.type !== "fallback" && i.children && n(i.children);
			}
		};
		n(p.nodes);
	}
	if (s.diagnostics.some((e) => e.severity === "error")) return c;
	let m = ee(f);
	for (let e of m.diagnostics) u(e);
	return m.ok && (!n.versionDeclaration && s.diagnostics.length < 100 && d("local.upgrade.version-missing", {
		start: +(e.charCodeAt(0) === 65279),
		end: +(e.charCodeAt(0) === 65279)
	}, { version: y }, "warning"), s.ok = !0), c;
}
function Le(e, t) {
	return Ie(e, t).report;
}
function Re(e, t) {
	let { report: n, declaration: r } = Ie(e, t), i = {
		...n,
		source: e,
		changed: !1,
		edits: []
	};
	if (!n.ok || !n.needsMigration) return i;
	let a = +(e.charCodeAt(0) === 65279), o = r?.range ?? {
		start: a,
		end: a
	}, s = e.includes("\r\n") ? "\r\n" : "\n", c = r ? Me : `${Me}${s}${s}`, l = e.slice(0, o.start) + c + e.slice(o.end);
	return {
		...n,
		source: l,
		changed: l !== e,
		edits: [{
			range: { ...o },
			text: c
		}]
	};
}
// src/local/transport/compile-patch.ts
var D = "patch-v1", O = 1, ze = 4096, k = [
	"initialState",
	"bindings",
	"bindingSlots",
	"computations",
	"dependencies",
	"tableShapes"
];
function A(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function j(e) {
	return A(e) && typeof e.start == "number" && Number.isFinite(e.start) && typeof e.end == "number" && Number.isFinite(e.end);
}
function M() {
	throw TypeError("Invalid local compile result patch");
}
function N(e, t) {
	if (e === t) return !0;
	if (typeof e != "object" || typeof t != "object" || e === null || t === null) return !1;
	let n = Array.isArray(e);
	if (n !== Array.isArray(t)) return !1;
	if (n) {
		let n = e, r = t;
		if (n.length !== r.length) return !1;
		for (let e = 0; e < n.length; e += 1) if (!N(n[e], r[e])) return !1;
		return !0;
	}
	let r = e, i = t, a = Object.keys(r);
	if (a.length !== Object.keys(i).length) return !1;
	for (let e of a) if (!Object.hasOwn(i, e) || !N(r[e], i[e])) return !1;
	return !0;
}
function P(e) {
	return v(e, !1);
}
function F(e, t) {
	if (typeof e != "string" || typeof t != "string" || e === t) return null;
	let n = Math.min(e.length, t.length), r = 0;
	for (; r < n && e.charCodeAt(r) === t.charCodeAt(r);) r += 1;
	let i = e.length, a = t.length;
	for (; i > r && a > r && e.charCodeAt(i - 1) === t.charCodeAt(a - 1);) --i, --a;
	return {
		from: r,
		to: i,
		insert: t.slice(r, a)
	};
}
function Be(e) {
	if (!A(e)) return null;
	let { from: t, to: n, insert: r } = e;
	return typeof t != "number" || !Number.isSafeInteger(t) || typeof n != "number" || !Number.isSafeInteger(n) || typeof r != "string" || t < 0 || n < t ? null : {
		from: t,
		to: n,
		insert: r
	};
}
function Ve(e, t) {
	let n = Be(t);
	return n === null || typeof e != "string" || n.to > e.length ? null : e.slice(0, n.from) + n.insert + e.slice(n.to);
}
function I(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) n !== "children" && (t[n] = r);
	return t;
}
function L(e, t) {
	let n = Object.keys(e).filter((e) => e !== "children"), r = Object.keys(t).filter((e) => e !== "children");
	if (n.length !== r.length) return !1;
	for (let r of n) if (!Object.hasOwn(t, r) || !N(e[r], t[r])) return !1;
	return !0;
}
function R(e) {
	return e.children === void 0 ? void 0 : e.children.map((e) => e.id);
}
function z(e, t) {
	let n = R(e), r = R(t);
	if (n === void 0 || r === void 0) return n === r;
	if (n.length !== r.length) return !1;
	for (let e = 0; e < n.length; e += 1) if (n[e] !== r[e]) return !1;
	return !0;
}
function He(e, t) {
	if (!L(e, t) || !z(e, t)) return !1;
	if (!e.children || !t.children) return !0;
	for (let n = 0; n < e.children.length; n += 1) if (!He(e.children[n], t.children[n])) return !1;
	return !0;
}
function Ue(e, t) {
	let n = Object.keys(e).filter((e) => e !== "children" && e !== "range"), r = Object.keys(t).filter((e) => e !== "children" && e !== "range");
	if (n.length !== r.length) return null;
	for (let r of n) if (!Object.hasOwn(t, r) || !N(e[r], t[r])) return null;
	if (!j(e.range) || !j(t.range)) return null;
	let i = e.range.start - t.range.start;
	if (e.range.end !== t.range.end + i) return null;
	let a = R(e), o = R(t);
	if (a === void 0 || o === void 0) {
		if (a !== o) return null;
	} else {
		if (a.length !== o.length) return null;
		for (let n = 0; n < a.length; n += 1) if (a[n] !== o[n] || Ue(e.children[n], t.children[n]) !== i) return null;
	}
	return i;
}
function We(e, t) {
	let n = Object.keys(e).filter((e) => e !== "children" && e !== "range"), r = Object.keys(t).filter((e) => e !== "children" && e !== "range");
	if (n.length !== r.length) return null;
	for (let r of n) if (!Object.hasOwn(t, r) || !N(e[r], t[r])) return null;
	if (!j(e.range) || !j(t.range)) return null;
	let i = e.range.start - t.range.start;
	return e.range.end === t.range.end + i ? i : null;
}
function Ge(e) {
	let t = /* @__PURE__ */ new Map(), n = [...e].reverse();
	for (; n.length > 0;) {
		let e = n.pop();
		if (t.set(e.id, e), e.children) for (let t = e.children.length - 1; t >= 0; --t) n.push(e.children[t]);
	}
	return t;
}
function Ke(e, t, n, r) {
	if (t !== void 0 && He(e, t)) return;
	if (t === void 0) {
		r.push({
			id: e.id,
			node: e
		});
		return;
	}
	let i = Ue(e, t);
	if (i !== null) {
		i !== 0 && r.push({
			id: e.id,
			shift: i,
			subtree: !0
		});
		return;
	}
	let a = { id: e.id };
	if (!L(e, t)) {
		let n = We(e, t);
		n !== null && n !== 0 ? a.shift = n : a.data = I(e);
	}
	z(e, t) || (a.children = e.children === void 0 ? null : e.children.map((e) => e.id));
	let o = r.length;
	if (e.children) for (let t of e.children) Ke(t, n.get(t.id), n, r);
	Object.keys(a).length > 1 ? r.splice(o, 0, a) : r.length > o && r.splice(o, 0, { id: e.id });
}
function qe(e, t) {
	if (!A(e)) return { set: t };
	let n = {}, r = [];
	for (let [r, i] of Object.entries(t)) Object.hasOwn(e, r) && N(e[r], i) || (n[r] = i);
	for (let n of Object.keys(e)) Object.hasOwn(t, n) || r.push(n);
	return Object.keys(n).length === 0 && r.length === 0 ? null : {
		...Object.keys(n).length === 0 ? {} : { set: n },
		...r.length === 0 ? {} : { remove: r }
	};
}
var Je = /* @__PURE__ */ new WeakMap();
function Ye(e) {
	let t = 2;
	for (let n = 0; n < e.length; n++) {
		let r = e.charCodeAt(n);
		if (r === 34 || r === 92) t += 2;
		else if (r < 32) t += r === 8 || r === 9 || r === 10 || r === 12 || r === 13 ? 2 : 6;
		else if (r < 128) t++;
		else if (r < 2048) t += 2;
		else if (r >= 55296 && r <= 56319) {
			let r = e.charCodeAt(n + 1);
			r >= 56320 && r <= 57343 ? (t += 4, n++) : t += 6;
		} else t += r >= 56320 && r <= 57343 ? 6 : 3;
	}
	return t;
}
function B(e, t) {
	if (e === null) return {
		bytes: 4,
		nodes: 0
	};
	let n = typeof e;
	if (n === "string") return {
		bytes: Ye(e),
		nodes: 0
	};
	if (n === "number") return {
		bytes: Number.isFinite(e) ? String(e).length : 4,
		nodes: 0
	};
	if (n === "boolean") return {
		bytes: e === !0 ? 4 : 5,
		nodes: 0
	};
	if (n !== "object") return {
		bytes: 0,
		nodes: 0
	};
	let r = e, i = Je.get(r);
	if (i !== void 0) return i;
	if (t.has(r)) return {
		bytes: 0,
		nodes: 0
	};
	t.add(r);
	let a, o = +!!nt(e);
	if (Array.isArray(e)) {
		a = 2;
		for (let n = 0; n < e.length; n += 1) {
			n > 0 && (a += 1);
			let r = B(e[n], t);
			a += r.bytes || 4, o += r.nodes;
		}
	} else {
		a = 2;
		let e = 0;
		for (let n in r) {
			if (!Object.hasOwn(r, n)) continue;
			let i = r[n];
			if (i === void 0) continue;
			e > 0 && (a += 1), e += 1, a += Ye(n) + 1;
			let s = B(i, t);
			a += s.bytes, o += s.nodes;
		}
	}
	t.delete(r);
	let s = {
		bytes: a,
		nodes: o
	};
	return Je.set(r, s), s;
}
function Xe(e, t) {
	let n = e.document.nodes ?? [];
	try {
		let r = B(e, /* @__PURE__ */ new Set()), i = t.ok && typeof t.document.source == "string" ? t.document.source.length : 0;
		if (r.bytes <= Math.max(i, ze)) return {
			patchBytes: r.bytes,
			patchNodes: n.length,
			preferFull: !1
		};
		let a = B(t, /* @__PURE__ */ new Set()), o = 0;
		for (let e of n) e.node === void 0 ? e.data !== void 0 && (o += 1) : o += B(e.node, /* @__PURE__ */ new Set()).nodes;
		let s = r.bytes * O >= a.bytes, c = a.nodes > 0 && o * O >= a.nodes;
		return {
			patchBytes: r.bytes,
			fullBytes: a.bytes,
			patchNodes: n.length,
			fullNodes: a.nodes,
			preferFull: s || c,
			...s ? { reason: "bytes" } : c ? { reason: "nodes" } : {}
		};
	} catch {
		return {
			patchBytes: 0,
			patchNodes: n.length,
			preferFull: !1
		};
	}
}
function Ze(e, t) {
	return et(e, t);
}
function Qe(e, t) {
	let n = et(e, t);
	return n ? {
		patch: n,
		cost: Xe(n, t)
	} : null;
}
function $e(e, t) {
	let n = e.recoveries, r = t.recoveries;
	return n === void 0 ? r === void 0 ? {} : { recoveries: r } : r !== void 0 && N(n, r) ? {} : { recoveries: r === void 0 ? null : r };
}
function et(e, t) {
	try {
		if (!e.ok || !t.ok) return null;
		let n = e.document, r = t.document;
		if (!A(n) || !A(r)) return null;
		let i = {};
		if (typeof n.source == "string" && typeof r.source == "string") {
			let e = F(n.source, r.source);
			e !== null && (i.source = e);
		} else if (n.source !== r.source) return null;
		let a = [], o = {}, s = {}, c = new Set(k), l = /* @__PURE__ */ new Set([...Object.keys(n), ...Object.keys(r)]);
		for (let e of l) {
			if (e === "source" || e === "nodes" || c.has(e)) continue;
			let t = Object.hasOwn(r, e) && r[e] !== void 0, i = Object.hasOwn(n, e) && n[e] !== void 0;
			t ? i && N(n[e], r[e]) || (o[e] = r[e]) : i && a.push(e);
		}
		for (let e of k) {
			let t = Object.hasOwn(r, e) && r[e] !== void 0, i = Object.hasOwn(n, e) && n[e] !== void 0, c = i ? n[e] : void 0, l = t ? r[e] : void 0;
			if (!t) {
				i && a.push(e);
				continue;
			}
			if (!A(l)) {
				i && N(c, l) || (o[e] = l);
				continue;
			}
			if (!i) {
				s[e] = { set: l };
				continue;
			}
			if (!A(c)) {
				o[e] = l;
				continue;
			}
			let u = qe(c, l);
			u !== null && (s[e] = u);
		}
		let u = Array.isArray(n.nodes) ? n.nodes : [], d = Array.isArray(r.nodes) ? r.nodes : [], f = u.map((e) => e.id), p = d.map((e) => e.id), m = f.length !== p.length;
		if (!m) {
			for (let e = 0; e < f.length; e += 1) if (f[e] !== p[e]) {
				m = !0;
				break;
			}
		}
		let h = [], g = Ge(u);
		for (let e of d) Ke(e, g.get(e.id), g, h);
		return m && (i.roots = p), h.length > 0 && (i.nodes = h), a.length > 0 && (i.removed = a), Object.keys(o).length > 0 && (i.values = o), Object.keys(s).length > 0 && (i.records = s), {
			kind: "result-patch",
			protocol: D,
			document: i,
			...N(e.diagnostics, t.diagnostics) ? {} : { diagnostics: t.diagnostics },
			...$e(e, t)
		};
	} catch {
		return null;
	}
}
function tt(e, t) {
	let n = I(e);
	return j(n.range) || M(), n.range = {
		start: n.range.start + t,
		end: n.range.end + t
	}, e.children && (n.children = e.children.map((e) => tt(e, t))), n;
}
function nt(e) {
	return A(e) && typeof e.id == "string" && typeof e.type == "string" && j(e.range);
}
function rt(e, t) {
	A(t) || M(), t.set !== void 0 && !A(t.set) && M(), t.remove !== void 0 && !Array.isArray(t.remove) && M();
	let n = {};
	if (A(e)) for (let [t, r] of Object.entries(e)) Object.defineProperty(n, t, {
		value: r,
		enumerable: !0,
		configurable: !0,
		writable: !0
	});
	else e !== void 0 && M();
	if (t.set) for (let [e, r] of Object.entries(t.set)) Object.defineProperty(n, e, {
		value: P(r),
		enumerable: !0,
		configurable: !0,
		writable: !0
	});
	if (t.remove) for (let e of t.remove) typeof e != "string" && M(), delete n[e];
	return n;
}
function it(e, t) {
	try {
		if (!e.ok || !A(t) || t.kind !== "result-patch" || t.protocol !== "patch-v1") return null;
		let n = t.document;
		if (!A(n)) return null;
		let r = e.document;
		if (!A(r)) return null;
		let i = {};
		for (let [e, t] of Object.entries(r)) Object.defineProperty(i, e, {
			value: t,
			enumerable: !0,
			configurable: !0,
			writable: !0
		});
		if (n.removed !== void 0) {
			if (!Array.isArray(n.removed)) return null;
			for (let e of n.removed) {
				if (typeof e != "string" || e === "nodes" || e === "source") return null;
				delete i[e];
			}
		}
		if (n.values !== void 0) {
			if (!A(n.values)) return null;
			for (let [e, t] of Object.entries(n.values)) {
				if (e === "nodes" || e === "source") return null;
				Object.defineProperty(i, e, {
					value: P(t),
					enumerable: !0,
					configurable: !0,
					writable: !0
				});
			}
		}
		if (n.records !== void 0) {
			if (!A(n.records)) return null;
			for (let e of Object.keys(n.records)) {
				if (!k.includes(e)) return null;
				let t = n.records[e];
				t !== void 0 && (i[e] = rt(r[e], t));
			}
		}
		let a = typeof r.source == "string" ? r.source : null;
		if (a === null) return null;
		if (n.source !== void 0) {
			let e = Be(n.source);
			if (e === null) return null;
			let t = Ve(a, e);
			if (t === null) return null;
			a = t;
		}
		i.source = a;
		let o = Array.isArray(r.nodes) ? r.nodes : [], s = Ge(o), c = /* @__PURE__ */ new Map();
		if (n.nodes !== void 0) {
			if (!Array.isArray(n.nodes)) return null;
			for (let e of n.nodes) {
				if (!A(e) || typeof e.id != "string" || c.has(e.id)) return null;
				c.set(e.id, e);
			}
		}
		let l;
		if (n.roots !== void 0) {
			if (!Array.isArray(n.roots)) return null;
			l = [];
			for (let e of n.roots) {
				if (typeof e != "string") return null;
				l.push(e);
			}
		} else l = o.map((e) => e.id);
		let u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set(), f = (e) => {
			let t = u.get(e);
			if (t !== void 0) return t;
			d.has(e) && M();
			let n = c.get(e), r = s.get(e);
			if (n === void 0) return r === void 0 && M(), u.set(e, r), r;
			if (A(n) || M(), n.node !== void 0) {
				(n.data !== void 0 || n.children !== void 0 || n.shift !== void 0 || n.subtree) && M(), nt(n.node) && n.node.id === e || M();
				let t = P(n.node);
				return u.set(e, t), t;
			}
			r === void 0 && n.data === void 0 && M(), n.subtree !== void 0 && n.subtree !== !0 && M(), n.shift !== void 0 && !Number.isSafeInteger(n.shift) && M(), n.data !== void 0 && n.shift !== void 0 && M(), n.children !== void 0 && n.children !== null && (!Array.isArray(n.children) || n.children.some((e) => typeof e != "string")) && M(), d.add(e);
			let i;
			if (n.subtree === !0) (r === void 0 || n.shift === void 0 || n.data !== void 0 || n.children !== void 0) && M(), i = tt(r, n.shift);
			else {
				let t;
				n.data === void 0 ? (r === void 0 && M(), t = I(r), n.shift !== void 0 && (j(t.range) || M(), t.range = {
					start: t.range.start + n.shift,
					end: t.range.end + n.shift
				})) : (A(n.data) || M(), t = P(n.data), delete t.children, t.id !== e && M());
				let a;
				if (n.children !== void 0) a = n.children === null ? null : [...n.children];
				else {
					let e = r?.children;
					a = e === void 0 ? void 0 : e.map((e) => e.id);
				}
				a === null ? delete t.children : a !== void 0 && (t.children = a.map(f)), i = t;
			}
			return d.delete(e), u.set(e, i), i;
		}, p = l.map(f);
		i.nodes = n.roots === void 0 && n.nodes === void 0 ? r.nodes : p;
		let m = t.diagnostics === void 0 ? e.diagnostics : Array.isArray(t.diagnostics) ? P(t.diagnostics) : M();
		if (t.recoveries !== void 0 && t.recoveries !== null && !Array.isArray(t.recoveries)) return null;
		let h = e.status === void 0 ? {} : { status: e.status };
		if (t.recoveries === null) return {
			ok: !0,
			document: i,
			diagnostics: m,
			...h
		};
		let g = t.recoveries === void 0 ? e.recoveries : P([...t.recoveries]);
		return {
			ok: !0,
			document: i,
			diagnostics: m,
			...h,
			...g === void 0 ? {} : { recoveries: g }
		};
	} catch {
		return null;
	}
}
// src/local/transport/flat-compiled-data.ts
var V = "flat-v1";
function at(e) {
	if (!e.ok) return !1;
	let t = e.document.nodes.map((e) => ({
		node: e,
		depth: 0
	}));
	for (; t.length;) {
		let { node: e, depth: n } = t.pop();
		if (n >= 100) return !0;
		if (e.children) for (let r of e.children) t.push({
			node: r,
			depth: n + 1
		});
	}
	return !1;
}
function ot(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = [], i = (e) => {
		if (typeof e == "object" && e) {
			let i = n.get(e);
			if (i !== void 0) return i;
			let a = t.length, o = Array.isArray(e) ? [
				1,
				e.length,
				[]
			] : [2, []];
			return n.set(e, a), t.push(o), r.push({
				value: e,
				record: o
			}), a;
		}
		if (e !== null && ![
			"string",
			"number",
			"boolean",
			"undefined"
		].includes(typeof e)) throw TypeError("Unsupported compiler wire value");
		let i = t.length;
		return t.push([0, e]), i;
	};
	for (i(e); r.length;) {
		let { value: e, record: t } = r.pop(), n = t[0] === 1 ? t[2] : t[1];
		for (let t of Object.keys(e)) n.push([t, i(e[t])]);
	}
	return {
		version: V,
		records: t
	};
}
function st(e) {
	if (!e || typeof e != "object") return null;
	let t = e;
	if (t.version !== "flat-v1" || !Array.isArray(t.records) || t.records.length === 0 || t.records.length > 2e6) return null;
	let n = t.records, r = Array(n.length), i = Array(n.length), a = 0;
	for (let e = 0; e < n.length; e++) {
		let t = n[e];
		if (!Array.isArray(t)) return null;
		if (t[0] === 0) {
			if (t.length !== 2 || t[1] !== null && ![
				"string",
				"number",
				"boolean",
				"undefined"
			].includes(typeof t[1])) return null;
			r[e] = t[1], i[e] = [];
			continue;
		}
		let o = t[0] === 1;
		if (!o && t[0] !== 2 || t.length !== (o ? 3 : 2) || o && (!Number.isSafeInteger(t[1]) || t[1] < 0 || t[1] > 1e6)) return null;
		let s = o ? t[2] : t[1];
		if (!Array.isArray(s)) return null;
		let c = /* @__PURE__ */ new Set(), l = [];
		for (let e of s) if (!Array.isArray(e) || e.length !== 2 || typeof e[0] != "string" || !Number.isSafeInteger(e[1]) || e[1] < 0 || e[1] >= n.length || c.has(e[0]) || o && (e[0] === "length" || !/^(0|[1-9][0-9]*)$/.test(e[0]) || Number(e[0]) >= t[1]) || (c.add(e[0]), l.push(e[1]), ++a > 4e6)) return null;
		r[e] = o ? Array(t[1]) : {}, i[e] = l;
	}
	let o = new Uint8Array(n.length), s = [{
		index: 0,
		child: 0
	}];
	o[0] = 1;
	let c = 1;
	for (; s.length;) {
		let e = s[s.length - 1], t = i[e.index];
		if (e.child === t.length) {
			o[e.index] = 2, s.pop();
			continue;
		}
		let n = t[e.child++];
		if (o[n] === 1) return null;
		o[n] === 0 && (o[n] = 1, c++, s.push({
			index: n,
			child: 0
		}));
	}
	if (c !== n.length) return null;
	for (let e = 0; e < n.length; e++) {
		let t = n[e];
		if (t[0] === 0) continue;
		let i = t[0] === 1 ? t[2] : t[1];
		for (let [t, n] of i) Object.defineProperty(r[e], t, {
			value: r[n],
			enumerable: !0,
			writable: !0,
			configurable: !0
		});
	}
	return r[0];
}
// src/local/transport/worker-job.ts
var ct = 150, lt = 200, ut = [
	"maxSyntaxNodes",
	"maxParseWork",
	"maxMarkdownDepth"
];
function H(e) {
	return e instanceof Error ? e.message : String(e);
}
function U() {
	return typeof performance < "u" ? performance.now() : Date.now();
}
function W(e) {
	return Number.isFinite(e) ? Math.max(0, Math.round(e)) : 0;
}
function G(e, t, n) {
	let r = {
		tokens: [],
		bindings: [],
		diagnostics: []
	};
	if (n.ok && n.document.source !== e || !n.ok && n.diagnostics.some((e) => e.code.startsWith("local.budget") || e.code.startsWith("local.options."))) return r;
	try {
		return C(e, t, {
			...n.ok ? { document: n.document } : {},
			diagnostics: !1
		});
	} catch {
		return {
			tokens: [],
			bindings: [],
			diagnostics: []
		};
	}
}
function dt(e) {
	return Array.isArray(e) ? e.length > 32 ? Array(33) : e.map((e) => {
		if (!e || typeof e != "object" || Array.isArray(e)) return e;
		let t = e, n = { ...t }, r = t.props;
		if (!r || typeof r != "object" || Array.isArray(r)) return n.props = r, n;
		let i = {};
		for (let [e, t] of Object.entries(r)) {
			if (!t || typeof t != "object" || Array.isArray(t)) {
				i[e] = t;
				continue;
			}
			let n = t, r = { ...n };
			Array.isArray(n.enum) && n.enum.length <= 64 && (r.enum = [...n.enum]), i[e] = r;
		}
		return n.props = i, n;
	}) : e;
}
function ft(e) {
	if (e !== void 0) try {
		if (typeof e != "object" || !e || Array.isArray(e)) return e;
		let t = e, n = {};
		for (let e of b) Object.hasOwn(t, e) && (n[e] = t[e]);
		if (Object.hasOwn(t, "markdownBreaks") && (n.markdownBreaks = t.markdownBreaks), Object.hasOwn(t, "sourcePhase") && (n.sourcePhase = t.sourcePhase), Object.hasOwn(t, "strict") && (n.strict = t.strict), Object.hasOwn(t, "limits")) {
			let e = t.limits;
			if (e && typeof e == "object" && !Array.isArray(e)) {
				let t = {};
				for (let n of ut) Object.hasOwn(e, n) && (t[n] = e[n]);
				n.limits = t;
			} else n.limits = e;
		}
		return Object.hasOwn(t, "hostComponents") && (n.hostComponents = dt(t.hostComponents)), Object.hasOwn(t, "config") && (n.config = x(t.config)), n;
	} catch {
		return e;
	}
}
function pt(e) {
	try {
		if (!e || typeof e != "object" || Array.isArray(e)) return "";
		let t = e.limits;
		if (!t || typeof t != "object" || Array.isArray(t)) return "";
		let n = (e) => {
			let n = t;
			if (!Object.hasOwn(n, e) || n[e] === void 0) return "-";
			let r = n[e];
			return `${typeof r}:${String(r)}`;
		};
		return `:${n("maxParseWork")}:${n("maxMarkdownDepth")}`;
	} catch {
		return ":unreadable";
	}
}
function mt(e) {
	let t = S(e);
	if (t !== "invalid") return t;
	try {
		return `invalid:${JSON.stringify(e)}`;
	} catch {
		return "invalid";
	}
}
function K(e) {
	return `${mt(e)}${pt(e)}`;
}
// src/local/transport/worker-handler.ts
function ht(e, t, n, r) {
	let i = e;
	return typeof i.compileShared == "function" ? i.compileShared(t, n, r) : e.compile(t, n, r);
}
function gt(e) {
	return e === "streaming" || e === "final";
}
function q(e) {
	return e.stats;
}
function J(e, t, n) {
	try {
		e.postMessage({
			id: t,
			ok: !1,
			message: n
		});
	} catch {}
}
function _t(e, t, n, r, i) {
	try {
		e.postMessage({
			id: t,
			ok: !1,
			message: n,
			retryFull: !0,
			code: r,
			...i === void 0 ? {} : { revision: i }
		});
	} catch {}
}
function vt(e) {
	return !!e && typeof e == "object" && (e.control === "dispose" || e.control === "cancel-preparation");
}
function yt(e) {
	if (!e || typeof e != "object") return !1;
	let t = e;
	return typeof t.from == "number" && Number.isSafeInteger(t.from) && typeof t.to == "number" && Number.isSafeInteger(t.to) && t.from >= 0 && t.to >= t.from && typeof t.insert == "string";
}
function bt(e, t = {}) {
	let n = e === void 0 ? globalThis : e;
	if (!n || typeof n.postMessage != "function") throw TypeError("startLocalCompileWorker requires a worker scope with postMessage");
	let r = t.createSession ? t.createSession() : T(), i = r, a = t.preparationDelay, o = typeof a == "number" && Number.isFinite(a) ? Math.max(0, a) : 200, s = typeof i.prepareAsync == "function", c = null, l = 0, u = !1, d = null, f = null, p = 0, m, h = () => {
		p += 1, f !== null && (f.aborted = !0, f = null), d !== null && (clearTimeout(d), d = null);
	}, g = () => new Promise((e) => {
		typeof setTimeout == "function" ? setTimeout(e, 0) : e();
	}), _ = async (e) => {
		if (u || e !== p) return;
		let t = i.prepareAsync;
		if (typeof t != "function") return;
		let n = { aborted: !1 };
		f = n;
		let r = U(), a = !1;
		try {
			a = await t.call(i, n, g);
		} catch {} finally {
			f === n && (f = null), a && !n.aborted && !u && e === p && (m = W(U() - r));
		}
	}, v = () => {
		if (u || !s) return;
		h();
		let e = p;
		d = setTimeout(() => {
			d = null, _(e);
		}, o);
	}, y = () => {
		if (!u) {
			u = !0, h();
			try {
				r.dispose();
			} catch {}
			n.onmessage = null;
		}
	}, b = (e) => ({
		compileMs: e,
		...m === void 0 ? {} : { preparationMs: m }
	}), x = (e) => {
		let t = typeof e == "number" && Number.isSafeInteger(e) && e > 0 ? e : null;
		return t === null ? l + 1 : t > l ? t : l + 1;
	}, S = (e, t, i, a, o = !1, s) => {
		let l = c;
		if (l === null) return !1;
		let u = W(i), d = s === void 0 ? b(u) : {
			...b(u),
			...s
		};
		try {
			let i = a ? {
				id: e,
				ok: !0,
				result: l.result,
				duration: u,
				incremental: q(r),
				...l.sourcePhase === void 0 ? {} : { sourcePhase: l.sourcePhase },
				protocol: D,
				revision: t,
				metrics: d
			} : {
				id: e,
				ok: !0,
				result: l.result,
				duration: u,
				incremental: q(r),
				...l.sourcePhase === void 0 ? {} : { sourcePhase: l.sourcePhase }
			};
			if (o && i.ok) {
				let e = U();
				i.analysis = G(l.source, l.options, l.result), i.metrics = {
					...i.metrics,
					analysisMs: W(U() - e)
				};
			}
			if (l.deep && l.flatResults && i.ok) {
				let { result: e, ...t } = i, r = {
					...t,
					flatResult: ot(e)
				};
				n.postMessage(r);
			} else n.postMessage(i);
			return !0;
		} catch (t) {
			return J(n, e, `Could not return the compile result: ${H(t)}`), !1;
		}
	};
	return n.onmessage = (e) => {
		let t = e?.data;
		if (vt(t)) {
			t.control === "dispose" ? y() : h();
			return;
		}
		if (!t || typeof t.id != "number") return;
		if (typeof t.source == "string") {
			let e = t, i = ft(e.options), a = e.sourcePhase === void 0 ? i?.sourcePhase : e.sourcePhase;
			if (a !== void 0 && !gt(a)) {
				J(n, e.id, "The requested source phase is not supported: expected \"streaming\" or \"final\"");
				return;
			}
			let o = a;
			h();
			let s = K(i), u = e.protocol === D, d = x(e.revision), f = U();
			try {
				if (c !== null && c.optionsKey !== s) try {
					r.clear();
				} catch {}
				let t = ht(r, e.source, i, o), n = W(U() - f);
				l = d, c = {
					source: e.source,
					revision: d,
					options: i,
					optionsKey: s,
					result: t,
					deep: at(t),
					flatResults: e.flatResults === V,
					...o === void 0 ? {} : { sourcePhase: o }
				}, S(e.id, d, n, u, e.includeAuthorAnalysis === !0) && v();
			} catch (t) {
				J(n, e.id, H(t));
			}
			return;
		}
		if (t.protocol !== "patch-v1") return;
		h();
		let i = t, a = c, o = (e, t) => {
			_t(n, i.id, e, t, a?.revision);
		};
		if (a === null) {
			o("No complete compile is available to patch", "stale-base");
			return;
		}
		if ((a.sourcePhase ?? "final") !== "final") {
			o("The baseline was compiled from a streaming snapshot", "phase-mismatch");
			return;
		}
		if (typeof i.baseRevision != "number" || i.baseRevision !== a.revision) {
			o("The requested base revision is not current", "stale-base");
			return;
		}
		if (i.optionsKey !== void 0 && i.optionsKey !== a.optionsKey) {
			o("The options signature changed since the baseline", "options-mismatch");
			return;
		}
		if (!yt(i.edit)) {
			o("The source edit is invalid", "invalid-edit");
			return;
		}
		let s = i.edit;
		if (s.to > a.source.length) {
			o("The source edit does not fit the baseline", "invalid-edit");
			return;
		}
		let u = a.source.slice(0, s.from) + s.insert + a.source.slice(s.to);
		if (typeof i.targetLength == "number" && u.length !== i.targetLength) {
			o("The source edit produced an unexpected length", "invalid-edit");
			return;
		}
		let d = x(i.revision), f = U();
		try {
			let e = ht(r, u, a.options, a.sourcePhase), t = W(U() - f), o = a.revision, s = a.result;
			l = d, c = {
				source: u,
				revision: d,
				options: a.options,
				optionsKey: a.optionsKey,
				result: e,
				deep: at(e),
				flatResults: a.flatResults,
				...a.sourcePhase === void 0 ? {} : { sourcePhase: a.sourcePhase }
			};
			let p = null, h = 0;
			if (e.ok && s.ok && !c.deep && !a.deep) {
				let t = U();
				p = Qe(s, e), h = W(U() - t);
			}
			let g = p?.patch ?? null;
			if (g === null) {
				S(i.id, d, t, !0, i.includeAuthorAnalysis === !0) && v();
				return;
			}
			if (p !== null && p.cost.preferFull) {
				let e = p.cost, n = {
					patchEncodeMs: h,
					patchFallback: "cost",
					patchBytes: e.patchBytes,
					...e.fullBytes === void 0 ? {} : { fullBytes: e.fullBytes }
				};
				S(i.id, d, t, !0, i.includeAuthorAnalysis === !0, n) && v();
				return;
			}
			let _ = {
				compileMs: t,
				patchEncodeMs: h,
				patchNodes: g.document.nodes?.length ?? 0,
				...m === void 0 ? {} : { preparationMs: m }
			};
			try {
				let s = {
					id: i.id,
					ok: !0,
					protocol: D,
					baseRevision: o,
					revision: d,
					patch: g,
					duration: t,
					incremental: q(r),
					...a.sourcePhase === void 0 ? {} : { sourcePhase: a.sourcePhase },
					metrics: _
				};
				if (i.includeAuthorAnalysis === !0) {
					let t = U();
					s.analysis = G(u, a.options, e), _.analysisMs = W(U() - t);
				}
				n.postMessage(s), v();
			} catch (e) {
				J(n, i.id, `Could not return the compile result: ${H(e)}`);
			}
		} catch (e) {
			J(n, i.id, H(e));
		}
	}, {
		dispose: y,
		cancelPreparation: h,
		get disposed() {
			return u;
		}
	};
}
// src/local/transport/worker.ts
function xt(e, t) {
	if (!e || typeof e != "object") return !1;
	let n = e, r = (e) => e && Number.isSafeInteger(e.start) && Number.isSafeInteger(e.end) && e.start >= 0 && e.end >= e.start && e.end <= t;
	if (!Array.isArray(n.tokens) || n.tokens.length > t + 1 || !Array.isArray(n.bindings) || n.bindings.length > t + 1 || !Array.isArray(n.diagnostics)) return !1;
	let i = 0, a = 0;
	for (let e of n.tokens) {
		if (!e || typeof e.kind != "string" || !r(e.range) || e.range.start < i) return !1;
		i = e.range.end;
	}
	for (let e of n.bindings) if (!e || typeof e.name != "string" || !Array.isArray(e.declarations) || !Array.isArray(e.references) || (a += e.declarations.length + e.references.length, a > t + 1 || !e.declarations.every(r) || !e.references.every(r))) return !1;
	return !0;
}
function St(e, t, n) {
	let r = ft(t), i = n === void 0 ? Ct(t) : n, a = i === "streaming" || i === "final" ? i : void 0, o = i !== void 0 && a === void 0 ? i : void 0;
	return {
		source: e,
		options: r,
		optionsKey: K(r),
		scheduledAt: U(),
		sourcePhase: a === "streaming" ? "streaming" : "final",
		explicitPhase: i !== void 0,
		...o === void 0 ? {} : { invalidPhase: o }
	};
}
function Ct(e) {
	try {
		return !e || typeof e != "object" || Array.isArray(e) ? void 0 : e.sourcePhase;
	} catch {
		return;
	}
}
function Y(e, t) {
	return e.source === t.source && e.optionsKey === t.optionsKey && e.sourcePhase === t.sourcePhase && e.explicitPhase === t.explicitPhase && e.invalidPhase === t.invalidPhase;
}
function X(e) {
	return e.sourcePhase === "streaming" || e.explicitPhase ? { sourcePhase: e.sourcePhase } : {};
}
function Z(e, t) {
	return e.explicitPhase ? {
		ok: !1,
		diagnostics: [t],
		status: "failed"
	} : {
		ok: !1,
		diagnostics: [t]
	};
}
function wt() {
	return {
		ok: !1,
		status: "failed",
		diagnostics: [{
			code: "local.options.invalid",
			message: "Compile option sourcePhase must be \"streaming\" or \"final\".",
			severity: "error",
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: "local.options.invalid.source-phase"
		}]
	};
}
function Q(e) {
	if (!e || typeof e != "object") return !1;
	let t = e;
	return !(typeof t.ok != "boolean" || !Array.isArray(t.diagnostics) || t.ok && (!t.document || typeof t.document != "object"));
}
function Tt(e) {
	return e.ok && "patch" in e && e.patch !== void 0;
}
function $(e) {
	return {
		code: "local.worker.compile",
		message: `Compilation failed: ${H(e)}`,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
var Et = class {
	options;
	delay;
	worker = null;
	timer = null;
	queued = null;
	inFlight = null;
	nextId = 1;
	nextRevision = 1;
	pending = !1;
	fallbackSession = null;
	disposed = !1;
	baseline = null;
	patchState = "unknown";
	constructor(e) {
		this.options = e;
		let t = e.delay;
		this.delay = typeof t == "number" && Number.isFinite(t) ? Math.max(0, t) : 150;
		try {
			let t = e.createWorker();
			t.onmessage = (e) => this.receive(e.data), t.onerror = (e) => {
				let t = e && typeof e.message == "string" ? String(e.message) : "";
				this.handleWorkerFailure(t || "The compile worker encountered an error");
			}, t.onmessageerror = () => this.handleWorkerFailure("The compile worker could not deliver the compile result"), this.worker = t;
		} catch (t) {
			this.worker = null, e.onModeChange?.("fallback", `Could not start the compile worker: ${H(t)}`);
		}
	}
	schedule(e, t, n, r) {
		if (this.disposed) return;
		let i = St(e, t, r);
		this.queued = i, n && typeof n.baseSource == "string" && yt(n.edit) && n.edit.to <= n.baseSource.length && n.baseSource.slice(0, n.edit.from) + n.edit.insert + n.baseSource.slice(n.edit.to) === e && (this.queued.editHint = {
			baseSource: n.baseSource,
			edit: { ...n.edit }
		}), this.clearTimer(), i.sourcePhase === "streaming" && (this.baseline = null), this.setPending(!0), i.sourcePhase === "streaming" || !i.explicitPhase ? this.timer = setTimeout(() => {
			this.timer = null, this.drain();
		}, this.delay) : this.drain();
	}
	dispose() {
		if (this.disposed) return;
		this.disposed = !0, this.clearTimer(), this.queued = null, this.inFlight = null, this.resetProtocol();
		let e = this.worker;
		if (this.worker = null, e) {
			e.onmessage = null, e.onerror = null, e.onmessageerror = null;
			try {
				e.terminate();
			} catch {}
		}
		this.pending = !1, this.fallbackSession?.dispose(), this.fallbackSession = null;
	}
	drain() {
		if (this.disposed || this.timer !== null || this.inFlight !== null) return;
		let e = this.queued;
		e === null ? this.setPending(!1) : (this.queued = null, this.compile(e));
	}
	compile(e) {
		if (e.invalidPhase !== void 0) {
			this.deliver({
				source: e.source,
				result: wt(),
				duration: 0,
				mode: this.worker === null ? "fallback" : "worker",
				...e.options === void 0 ? {} : { options: e.options },
				metrics: { queueMs: W(U() - e.scheduledAt) }
			}), this.finishRun();
			return;
		}
		let t = this.worker;
		if (!t) {
			this.compileFallback(e);
			return;
		}
		e.sourcePhase === "streaming" && (this.baseline = null);
		let n = this.nextId++, r = this.nextRevision++, i = U(), a = this.baseline, o = e.sourcePhase === "final" && this.patchState === "enabled" && a !== null && a.optionsKey === e.optionsKey ? {
			id: n,
			protocol: D,
			baseRevision: a.revision,
			revision: r,
			edit: e.editHint?.baseSource === a.source ? e.editHint.edit : F(a.source, e.source) ?? {
				from: 0,
				to: 0,
				insert: ""
			},
			targetLength: e.source.length,
			optionsKey: e.optionsKey
		} : {
			id: n,
			source: e.source,
			...e.options === void 0 ? {} : { options: e.options },
			protocol: D,
			revision: r,
			flatResults: V,
			...e.sourcePhase === "streaming" || e.explicitPhase ? { sourcePhase: e.sourcePhase } : {}
		};
		this.inFlight = {
			id: n,
			job: e,
			startedAt: i,
			revision: r
		}, this.options.includeAuthorAnalysis && (o.includeAuthorAnalysis = !0);
		try {
			t.postMessage(o);
		} catch (t) {
			this.inFlight = null;
			let n = `Could not send the source to the compile worker: ${H(t)}`, r = this.queued;
			if (r !== null && !Y(r, e)) {
				this.resetProtocol(), this.degrade(n), this.finishRun();
				return;
			}
			r !== null && (this.queued = null, this.clearTimer()), this.resetProtocol(), this.degrade(n), this.compileFallback(e);
		}
	}
	compileFallback(e) {
		if (this.disposed) return;
		e.sourcePhase === "streaming" && (this.baseline = null);
		let t = U(), n;
		try {
			let t = this.options.fallbackCompile ?? ((e, t, n) => (this.fallbackSession ??= T(), this.fallbackSession.compile(e, t, n)));
			n = e.explicitPhase ? t(e.source, e.options, e.sourcePhase) : e.options === void 0 ? t(e.source) : t(e.source, e.options);
		} catch (t) {
			n = Z(e, $(t));
		}
		this.deliver({
			source: e.source,
			result: n,
			duration: W(U() - t),
			mode: "fallback",
			...this.options.includeAuthorAnalysis ? { analysis: G(e.source, e.options, n) } : {},
			...e.options === void 0 ? {} : { options: e.options },
			...X(e),
			metrics: { queueMs: W(t - e.scheduledAt) }
		}), this.finishRun();
	}
	receive(e) {
		if (this.disposed) return;
		let t = this.inFlight;
		if (!t || !e || e.id !== t.id) return;
		let n, r = 0;
		if (e.ok && "flatResult" in e) {
			let t = U(), i = st(e.flatResult);
			r = W(U() - t), n = Q(i) ? {
				...e,
				result: i
			} : {
				id: e.id,
				ok: !1,
				retryFull: !0,
				message: "Invalid flat compile result"
			};
		} else n = e;
		this.inFlight = null;
		let i = t.job, a = W(U() - t.startedAt), o = W(t.startedAt - i.scheduledAt), s = null, c = r, l = null, u = "worker", d;
		if (n.ok) {
			if (Tt(n)) {
				let e = U(), t = this.applyResponsePatch(i, n);
				c = W(U() - e), t !== null && (s = t, d = n.revision);
			} else {
				let e = n;
				Q(e.result) ? (s = e.result, d = typeof e.revision == "number" ? e.revision : void 0, i.sourcePhase === "streaming" || e.sourcePhase === "streaming" ? this.baseline = null : e.protocol === "patch-v1" && typeof e.revision == "number" && Number.isSafeInteger(e.revision) ? (this.patchState = "enabled", this.baseline = e.result.ok ? {
					source: i.source,
					optionsKey: i.optionsKey,
					revision: e.revision,
					result: e.result
				} : null) : (this.patchState = "legacy", this.baseline = null)) : l = "The compile worker returned an invalid result";
			}
		} else n.retryFull !== !0 && (l = n.message);
		let f = this.queued, p = f !== null && !Y(f, i);
		f !== null && !p && (this.queued = null, this.clearTimer()), s === null ? l === null ? (p || !this.recoverWithFullResult(i)) && (p ? this.resetProtocol() : (this.patchState = "disabled", this.baseline = null, this.deliver({
			source: i.source,
			result: Z(i, $("The compile worker could not apply an incremental result patch")),
			duration: 0,
			mode: u,
			...i.options === void 0 ? {} : { options: i.options },
			...X(i),
			metrics: {
				queueMs: o,
				roundTripMs: a,
				...c > 0 ? { applyMs: c } : {}
			}
		})), this.finishRun()) : (p || this.deliver({
			source: i.source,
			result: Z(i, $(l)),
			duration: 0,
			mode: u,
			...i.options === void 0 ? {} : { options: i.options },
			...X(i),
			metrics: {
				queueMs: o,
				roundTripMs: a
			}
		}), this.finishRun()) : (p || this.deliver({
			source: i.source,
			result: s,
			duration: W(n.ok ? n.duration : 0),
			mode: u,
			...n.ok && this.options.includeAuthorAnalysis && xt(n.analysis, i.source.length) ? { analysis: n.analysis } : {},
			...i.options === void 0 ? {} : { options: i.options },
			...X(i),
			metrics: {
				queueMs: o,
				roundTripMs: a,
				...c > 0 ? { applyMs: c } : {},
				...n.ok && n.metrics ? { worker: n.metrics } : {}
			},
			...d === void 0 ? {} : { revision: d }
		}), this.finishRun());
	}
	applyResponsePatch(e, t) {
		if (e.sourcePhase !== "final") return null;
		let n = this.baseline;
		if (n === null || n.optionsKey !== e.optionsKey || !Number.isSafeInteger(t.revision) || t.revision <= n.revision || t.baseRevision !== n.revision || t.protocol !== "patch-v1") return null;
		let r = it(n.result, t.patch);
		if (r === null || !r.ok || r.document.source !== e.source) return null;
		let i;
		if (e.sourcePhase === "final" && e.explicitPhase) i = r.recoveries === void 0 ? {
			...r,
			status: "valid"
		} : {
			...r,
			status: "recovered"
		};
		else if (r.ok && r.status !== void 0) {
			let e = { ...r };
			delete e.status, i = e;
		} else i = r;
		return this.baseline = {
			source: e.source,
			optionsKey: e.optionsKey,
			revision: t.revision,
			result: i
		}, i;
	}
	recoverWithFullResult(e) {
		if (this.worker === null || (e.recovery ?? 0) >= 1) return !1;
		let t = this.queued;
		return t !== null && !Y(t, e) ? !1 : (t !== null && (this.queued = null, this.clearTimer()), this.resetProtocol(), this.compile({
			...e,
			recovery: (e.recovery ?? 0) + 1
		}), !0);
	}
	handleWorkerFailure(e) {
		if (this.disposed) return;
		this.resetProtocol(), this.degrade(e);
		let t = this.inFlight;
		this.inFlight = null, t && (this.queued === null || Y(this.queued, t.job)) && (this.queued !== null && (this.queued = null, this.clearTimer()), this.compileFallback(t.job)), this.finishRun();
	}
	degrade(e) {
		let t = this.worker;
		if (t) {
			this.worker = null, t.onmessage = null, t.onerror = null, t.onmessageerror = null;
			try {
				t.terminate();
			} catch {}
			this.options.onModeChange?.("fallback", e);
		}
	}
	resetProtocol() {
		this.baseline = null, this.patchState = "unknown";
	}
	finishRun() {
		this.disposed || (this.drain(), !this.disposed && this.setPending(this.timer !== null || this.inFlight !== null || this.queued !== null));
	}
	deliver(e) {
		if (this.disposed) return;
		let t = this.baseline !== null && this.baseline.result === e.result, n = this.options.shareResults === !0 || !t ? e.result : P(e.result);
		this.options.onResult({
			...e,
			result: n
		});
	}
	setPending(e) {
		this.pending !== e && (this.pending = e, this.options.onPendingChange?.(e));
	}
	clearTimer() {
		this.timer !== null && (clearTimeout(this.timer), this.timer = null);
	}
};
export { h as DEFAULT_LOCAL_THEME, ct as LOCAL_COMPILE_DELAY_MS, lt as LOCAL_COMPILE_PREPARATION_DELAY_MS, i as LOCAL_DIAGNOSTIC_CODES, D as LOCAL_RESULT_PATCH_PROTOCOL, _e as LOCAL_STATE_FORMAT, y as LOCAL_SYNTAX_VERSION, f as LOCAL_THEME_PROTOCOL, Et as LocalCompileScheduler, ie as LocalCompileSession, g as LocalExpressionError, Te as SHAREABLE_HTML_FORMAT, Se as SHAREABLE_HTML_FORMAT_V2, C as analyzeLocalSource, it as applyLocalResultPatch, Ce as applyLocalState, oe as applyLocalStateRetention, Ve as applySourceEdit, Le as checkLocalUpgrade, _ as compileExpression, $ as compileFailureDiagnostic, n as compileLatex, ee as compileLocal, t as compilePlotFormula, ne as completeLocalSource, a as countLocalCodePoints, T as createLocalCompileSession, ce as createLocalRuntime, xe as createLocalStateFile, we as createShareableHtml, F as diffSourceEdit, Ze as encodeLocalResultPatch, ye as exportLocalState, l as formatLocalDiagnostic, re as formatLocalSource, e as implicitGridSize, ve as importLocalState, Pe as inspectLocalSourceVersion, u as isLocalDiagnosticCode, o as isLocalThemeName, S as localCompileOptionsKey, s as localDiagnosticTemplate, c as localDiagnosticTemplateKeys, ae as localSourceDigest, K as localWorkerOptionsKey, Re as migrateLocalSource, ue as notifyLocalRuntime, he as parseLocalState, le as planLocalStateRetention, r as plotFormulaKind, te as renameLocalBinding, Oe as resolveLocalComponentStateExport, Ee as resolveLocalState, be as resolveLocalStateBaseline, m as resolveLocalTheme, me as sampleImplicit, fe as sampleParametric, pe as samplePlot, de as samplePolar, ge as serializeForScript, De as serializeLocalState, bt as startLocalCompileWorker, se as updateLocalRuntime };
