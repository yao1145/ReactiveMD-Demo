import { $ as e, A as t, F as n, I as r, N as i, Q as a, R as o, X as s, Z as c, a as l, i as u, it as d, q as f, st as p, t as m } from "./preset-core-CKc5YXSM.js";
import { D as h, E as g, O as _, T as v, V as y, _ as b, a as x, c as S, d as C, h as w, i as T, m as ee, n as E, o as te, p as ne, r as D, s as re, t as ie, v as ae, y as O } from "./config-validation-F47AcE6o.js";
import { a as k, n as oe, s as se, t as ce } from "./compile-wUv8KEge.js";
import { n as le } from "./props-sJ8vk0cr.js";
import { p as ue, r as de, x as fe } from "./registry-core-Bbad9Bm2.js";
// node_modules/devlop/lib/default.js
function pe() {}
// node_modules/mdast-util-to-string/lib/index.js
var me = {};
function he(e, t) {
	let n = t || me;
	return ge(e, typeof n.includeImageAlt != "boolean" || n.includeImageAlt, typeof n.includeHtml != "boolean" || n.includeHtml);
}
function ge(e, t, n) {
	if (ve(e)) {
		if ("value" in e) return e.type === "html" && !n ? "" : e.value;
		if (t && "alt" in e && e.alt) return e.alt;
		if ("children" in e) return _e(e.children, t, n);
	}
	return Array.isArray(e) ? _e(e, t, n) : "";
}
function _e(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) r[i] = ge(e[i], t, n);
	return r.join("");
}
function ve(e) {
	return !!(e && typeof e == "object");
}
// node_modules/micromark-util-chunked/index.js
function A(e, t, n, r) {
	let i = e.length, a = 0, o;
	if (t = t < 0 ? -t > i ? 0 : i + t : t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4) o = Array.from(r), o.unshift(t, n), e.splice(...o);
	else for (n && e.splice(t, n); a < r.length;) o = r.slice(a, a + 1e4), o.unshift(t, 0), e.splice(...o), a += 1e4, t += 1e4;
}
function ye(e, t) {
	return e.length > 0 ? (A(e, e.length, 0, t), e) : t;
}
// node_modules/micromark-util-combine-extensions/index.js
var j = {}.hasOwnProperty;
function be(e) {
	let t = {}, n = -1;
	for (; ++n < e.length;) xe(t, e[n]);
	return t;
}
function xe(e, t) {
	let n;
	for (n in t) {
		let r = (j.call(e, n) ? e[n] : void 0) || (e[n] = {}), i = t[n], a;
		if (i) for (a in i) {
			j.call(r, a) || (r[a] = []);
			let e = i[a];
			Se(r[a], Array.isArray(e) ? e : e ? [e] : []);
		}
	}
}
function Se(e, t) {
	let n = -1, r = [];
	for (; ++n < t.length;) (t[n].add === "after" ? e : r).push(t[n]);
	A(e, 0, 0, r);
}
// node_modules/micromark-util-normalize-identifier/index.js
function Ce(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
// node_modules/micromark-util-character/index.js
var we = L(/[A-Za-z]/), Te = L(/[\dA-Za-z]/), Ee = L(/[#-'*+\--9=?A-Z^-~]/);
function De(e) {
	return e !== null && (e < 32 || e === 127);
}
var Oe = L(/\d/), ke = L(/[\dA-Fa-f]/), Ae = L(/[!-/:-@[-`{-~]/);
function M(e) {
	return e !== null && e < -2;
}
function N(e) {
	return e !== null && (e < 0 || e === 32);
}
function P(e) {
	return e === -2 || e === -1 || e === 32;
}
var F = L(/\p{P}|\p{S}/u), I = L(/\s/);
function L(e) {
	return t;
	function t(t) {
		return t !== null && t > -1 && e.test(String.fromCharCode(t));
	}
}
// node_modules/micromark-factory-space/index.js
function R(e, t, n, r) {
	let i = r ? r - 1 : Infinity, a = 0;
	return o;
	function o(r) {
		return P(r) ? (e.enter(n), s(r)) : t(r);
	}
	function s(r) {
		return P(r) && a++ < i ? (e.consume(r), s) : (e.exit(n), t(r));
	}
}
function je(e, t, n, r, i, a) {
	let o = 0;
	return s;
	function s(t) {
		return a > 0 && P(t) ? (e.enter(r), c(t)) : l(t);
	}
	function c(t) {
		return P(t) && o < a ? (e.consume(t), o++, c) : (e.exit(r), l(t));
	}
	function l(e) {
		return o >= i ? t(e) : n(e);
	}
}
// node_modules/micromark-util-classify-character/index.js
function Me(e) {
	if (e === null || N(e) || I(e)) return 1;
	if (F(e)) return 2;
}
// node_modules/micromark-util-resolve-all/index.js
function Ne(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) {
		let a = e[i].resolveAll;
		a && !r.includes(a) && (t = a(t, n), r.push(a));
	}
	return t;
}
// node_modules/micromark-core-commonmark/lib/blank-line.js
var Pe = {
	partial: !0,
	tokenize: Fe
};
function Fe(e, t, n) {
	return r;
	function r(t) {
		return P(t) ? R(e, i, "linePrefix")(t) : i(t);
	}
	function i(e) {
		return e === null || M(e) ? t(e) : n(e);
	}
}
// src/local/html/html-table-names.ts
var Ie = /* @__PURE__ */ new Set([
	"table",
	"caption",
	"colgroup",
	"col",
	"thead",
	"tbody",
	"tfoot",
	"tr",
	"th",
	"td"
]), z = {
	colgroup: /* @__PURE__ */ new Set(["span"]),
	col: /* @__PURE__ */ new Set(["span"]),
	td: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"align"
	]),
	th: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"scope",
		"abbr",
		"align"
	])
};
function B(e, t) {
	let n = t.trim();
	return [
		"colspan",
		"rowspan",
		"span"
	].includes(e) ? /^\d{1,5}$/.test(n) && Number(n) <= (e === "rowspan" ? 65534 : 1e3) && Number(n) >= (e === "rowspan" ? 0 : 1) : e === "align" ? _(t) !== null : e !== "scope" || [
		"row",
		"col",
		"rowgroup",
		"colgroup"
	].includes(n.toLowerCase());
}
// src/local/html/html-policy.ts
var Le = {
	b: "strong",
	strong: "strong",
	i: "emphasis",
	em: "emphasis",
	s: "delete",
	del: "delete",
	u: "underline",
	mark: "mark",
	sup: "sup",
	sub: "sub"
}, Re = /* @__PURE__ */ new Set([
	"br",
	"hr",
	"img",
	"col"
]), ze = /* @__PURE__ */ new Set([
	"pre",
	"code",
	"script",
	"style",
	"textarea",
	"title",
	"xmp",
	"iframe",
	"noembed",
	"noframes",
	"plaintext"
]), Be = /* @__PURE__ */ new Set([
	"id",
	"title",
	"lang",
	"dir"
]), Ve = {
	a: g,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...z
};
function He(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") return i + 1;
	}
	return -1;
}
function Ue(e, t, n) {
	if (e.startsWith("<!-->", t)) return Math.min(n, t + 5);
	if (e.startsWith("<!--->", t)) return Math.min(n, t + 6);
	let r = e.indexOf("-->", t + 4);
	return r < 0 || r + 3 > n ? n : r + 3;
}
function We(e) {
	return e.trim().replace(/[\u0000- ]+/g, "");
}
function V(e, t) {
	let n = /^([a-z][a-z0-9+.-]*):/i.exec(We(e));
	if (!n) return !1;
	let r = n[1].toLowerCase();
	return t === "image" ? r !== "http" && r !== "https" : r !== "http" && r !== "https" && r !== "mailto" && r !== "tel";
}
function Ge(e, t) {
	return t === "class" || t === "style" || /^on[a-z]/i.test(t) ? !1 : t === "align" && v.has(e) || Be.has(t) || /^aria-[a-z0-9_.-]+$/.test(t) || /^data-[a-z0-9_.-]+$/.test(t) ? !0 : Ve[e]?.has(t) ?? !1;
}
function Ke(e, t) {
	return !(e === "dir" && ![
		"ltr",
		"rtl",
		"auto"
	].includes(t.trim().toLowerCase()) || e === "id" && t.trim() === "" || (e === "width" || e === "height") && !/^\d{1,6}$/.test(t.trim()) || e === "start" && !/^-?\d{1,9}$/.test(t.trim()) || !B(e, t) || e === "href" && V(t, "link") || e === "src" && V(t, "image"));
}
function qe(e, t) {
	return v.has(e) ? _(t) : null;
}
// src/local/types.ts
var Je = (e) => e.attrs?.bind ?? `@${e.id}`, Ye = "local-draft-3", Xe = Object.freeze({}), Ze = Object.freeze([
	"anchor",
	"checkbox",
	"column",
	"coordinate",
	"counter",
	"date",
	"edge",
	"input",
	"number",
	"progress",
	"range-slider",
	"slider",
	"textarea",
	"timer",
	"toggle",
	"validation"
]);
function Qe(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of Ze) e(n) || t.add(n);
	return t;
}
// src/sdk/compiler-config.ts
var H = Object.freeze({
	id: u,
	version: l
}), U = /* @__PURE__ */ new WeakMap(), W = /* @__PURE__ */ new WeakMap();
function G(e, t = H) {
	if (e.length === 0) return;
	let n = t.id === H.id && t.version === H.version;
	if (n) {
		let t = U.get(e);
		if (t) return t;
	}
	let r = m({
		protocol: o,
		id: t.id,
		version: t.version,
		components: e
	});
	return n && U.set(e, r), r;
}
function $e(e, t, n, r, i = "reactive-md-config/v1") {
	let a = w(e, { legacyProfiles: t.length > 0 ? n : [] }), o = [...a.legacyKeys, ...r !== void 0 && !a.legacyKeys.some((e) => e.key === r) ? [Object.freeze({
		profile: i,
		key: r
	})] : []];
	return C(e, a, o);
}
function et(e) {
	return x(e) || T("assembly", "must be an object."), D(e, /* @__PURE__ */ new Set([
		"protocol",
		"presets",
		"components",
		"replacementPolicy",
		"themes"
	]), "assembly"), e.protocol !== "reactive-md-assembly/v1" && T("assembly.protocol", `must be "${i}".`), ee(e);
}
function tt(e, a = [], o = []) {
	let s = ae(o);
	if (x(e) || T("config", "must be an object."), D(e, ie, "config"), e.protocol === "reactive-md-config/v2") {
		let n = et(e.assembly), r = $e(n, a, s);
		return t(n) > 16777216 && T("config", `serialized size exceeds the ${E}-byte budget.`), r;
	}
	e.protocol !== "reactive-md-config/v1" && T("config.protocol", `must be "${r}" (or legacy "${n}").`);
	let c = re(e.presets, H, s)[0] ?? H, l = b(c, s);
	l === void 0 && T("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${c.id}" ${c.version}.`);
	let u = l.legacyKeys[0];
	u === void 0 && T("presets", `local.config.migration-unsupported: profile "${l.name}" has no legacy key mapping.`), S(l, a);
	let d = te(e.components, a);
	d.some((e) => e.replaces !== void 0) && T("config", "replaces is not supported by reactive-md-config/v1.");
	let f = G(a, l.preset), p = Object.freeze({
		protocol: i,
		presets: Object.freeze(f ? [f] : []),
		components: d,
		replacementPolicy: "forbid",
		themes: Object.freeze([])
	}), m = $e(p, a, s, a.length > 0 ? ne(l.preset, d) : void 0, u.profile);
	return t(p) > 16777216 && T("config", `serialized size exceeds the ${E}-byte budget.`), m;
}
function nt(e) {
	let t = W.get(e);
	if (t !== void 0) return t;
	let n = G(e), r = Object.freeze({
		protocol: i,
		presets: Object.freeze(n ? [n] : []),
		components: Object.freeze([]),
		replacementPolicy: "forbid",
		themes: Object.freeze([])
	}), a = w(r).key;
	return W.set(e, a), a;
}
// src/local/configuration/capability-policy.ts
var K = Object.freeze({
	enableCss: !0,
	enableJavaScript: !1,
	enableExtendedHtml: !1
});
function rt(e, t) {
	return {
		enableCss: e?.enableCss === !0 && (t?.enableCss ?? K.enableCss) === !0,
		enableJavaScript: e?.enableJavaScript === !0 && t?.enableJavaScript === !0,
		enableExtendedHtml: e?.enableExtendedHtml === !0 && t?.enableExtendedHtml === !0
	};
}
// src/local/configuration/options-core.ts
var it = [
	"enableCss",
	"enableJavaScript",
	"enableExtendedHtml"
], at = H;
function q(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var ot = "local.options.invalid.host-components", st = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, ct = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), lt = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), ut = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean"
]), dt = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]), ft = /* @__PURE__ */ new Set([
	"maxSyntaxNodes",
	"maxParseWork",
	"maxMarkdownDepth"
]);
function J(e, t, n) {
	if (!Object.hasOwn(e, t)) return {
		ok: !0,
		value: n
	};
	let r = e[t];
	if (r === void 0) return {
		ok: !0,
		value: n
	};
	if (typeof r != "number" || !Number.isSafeInteger(r) || r < 1) {
		let e = t === "maxSyntaxNodes" ? "max-syntax-nodes" : t === "maxParseWork" ? "max-parse-work" : "max-markdown-depth";
		return {
			ok: !1,
			message: `Compile option limits.${t} must be a positive safe integer.`,
			key: `local.options.invalid.${e}`
		};
	}
	return {
		ok: !0,
		value: r
	};
}
function Y(e) {
	return {
		ok: !1,
		message: `Compile option hostComponents is invalid: ${e}`,
		key: ot,
		detail: e
	};
}
function pt(e, t) {
	if (e === void 0) return {
		ok: !0,
		binding: void 0
	};
	if (!q(e)) return Y(`${t} "binding" must be an object.`);
	for (let n of Object.keys(e)) if (![
		"kind",
		"initialRule",
		"min",
		"max",
		"step",
		"options",
		"exclusive"
	].includes(n)) return Y(`${t} "binding" has unknown field "${n}".`);
	let n = e.kind;
	if (typeof n != "string" || !ut.has(n)) return Y(`${t} "binding.kind" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
	let r = { kind: n };
	if (Object.hasOwn(e, "exclusive") && e.exclusive !== void 0) {
		if (typeof e.exclusive != "boolean") return Y(`${t} "binding.exclusive" must be a boolean.`);
		r.exclusive = e.exclusive;
	}
	if (Object.hasOwn(e, "initialRule") && e.initialRule !== void 0) {
		let n = e.initialRule;
		if (typeof n != "string" || ![
			"empty",
			"false",
			"nearest-zero",
			"min",
			"first-option"
		].includes(n)) return Y(`${t} "binding.initialRule" is not supported.`);
		r.initialRule = n;
	}
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (!Object.hasOwn(e, n) || e[n] === void 0) continue;
		if (r.kind !== "number") return Y(`${t} "binding.${n}" is only valid for number bindings.`);
		let i = e[n];
		if (typeof i != "number" || !Number.isFinite(i)) return Y(`${t} "binding.${n}" must be a finite number.`);
		r[n] = i;
	}
	if (r.kind === "number") {
		if (r.step !== void 0 && !(r.step > 0)) return Y(`${t} "binding.step" must be greater than 0.`);
		if (r.min !== void 0 && r.max !== void 0 && r.min > r.max) return Y(`${t} "binding.min" cannot exceed "binding.max".`);
		if (r.initialRule !== void 0 && !["min", "nearest-zero"].includes(r.initialRule)) return Y(`${t} "binding.initialRule" must be "min" or "nearest-zero" for number bindings.`);
		r.initialRule ??= "nearest-zero";
	}
	let i = Object.hasOwn(e, "options") && e.options !== void 0;
	if (i) {
		if (r.kind !== "string") return Y(`${t} "binding.options" is only valid for string bindings.`);
		let n = e.options;
		if (!Array.isArray(n) || n.length === 0) return Y(`${t} "binding.options" must be a non-empty string array.`);
		if (n.length > 64) return Y(`${t} "binding.options" accepts at most 64 values.`);
		let i = /* @__PURE__ */ new Set(), a = [];
		for (let e of n) {
			if (typeof e != "string" || e === "") return Y(`${t} "binding.options" must be a non-empty string array.`);
			if (e.length > 128) return Y(`${t} "binding.options" value exceeds the 128-character limit.`);
			if (i.has(e)) return Y(`${t} "binding.options" value "${e}" is declared more than once.`);
			i.add(e), a.push(e);
		}
		r.options = a, r.initialRule ??= "first-option";
	}
	if (r.kind === "string") {
		let e = i ? "first-option" : "empty";
		if (r.initialRule !== void 0 && r.initialRule !== e) return Y(`${t} "binding.initialRule" must be "${e}" for ${i ? "choice" : "string"} bindings.`);
		r.initialRule ??= e;
	}
	if (r.kind === "boolean") {
		if (r.initialRule !== void 0 && r.initialRule !== "false") return Y(`${t} "binding.initialRule" must be "false" for boolean bindings.`);
		r.initialRule ??= "false";
	}
	return {
		ok: !0,
		binding: r
	};
}
function mt(e, t) {
	let n = [], r = /* @__PURE__ */ new Map();
	if (e === void 0) return {
		ok: !0,
		hostComponents: n,
		hostByName: r
	};
	if (!Array.isArray(e)) return Y("must be an array.");
	if (e.length > 32) return Y("accepts at most 32 components.");
	let i = /* @__PURE__ */ new Set();
	for (let e of t) i.add(e.name.toLowerCase());
	for (let e of O) i.add(e.name.toLowerCase());
	for (let e of h) i.add(e.toLowerCase());
	i.add("theme");
	for (let t = 0; t < e.length; t += 1) {
		let a = e[t], o = `hostComponents[${t}]`;
		if (!q(a)) return Y(`${o} must be an object.`);
		let s = a.name;
		if (typeof s != "string") return Y(`${o} "name" must be a string.`);
		if (s.length > 128) return Y(`${o} "name" exceeds the 128-character limit.`);
		if (!st.test(s)) return Y(`${o} "name" ${s} must use lowercase kebab-case.`);
		if (i.has(s.toLowerCase())) return Y(`${o} "name" ${s} conflicts with a built-in component, HTML tag or theme.`);
		if (r.has(s.toLowerCase())) return Y(`${o} "name" ${s} is declared more than once.`);
		if (typeof a.form != "string" || !lt.has(a.form)) return Y(`${o} "form" must be "leaf", "inline" or "container".`);
		let c = a.form, l = pt(a.binding, o);
		if (!l.ok) return l;
		let u = l.binding, d = a.props;
		if (!q(d)) return Y(`${o} "props" must be an object.`);
		let p = {};
		for (let e of Object.keys(d)) {
			if (!st.test(e)) return Y(`${o} property "${e}" must use lowercase kebab-case.`);
			if (u && dt.has(e)) return Y(`${o} property "${e}" is reserved by the host binding.`);
			let t = d[e];
			if (!q(t)) return Y(`${o} property "${e}" must be an object.`);
			let n = t.kind;
			if (typeof n != "string" || !ct.has(n)) return Y(`property "${e}" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
			let r = { kind: n };
			for (let n of ["required", "static"]) if (Object.hasOwn(t, n) && t[n] !== void 0) {
				if (typeof t[n] != "boolean") return Y(`${o} property "${e}" "${n}" must be a boolean.`);
				r[n] = t[n];
			}
			let i = Object.hasOwn(t, "enum") && t.enum !== void 0;
			if (n !== "enum") {
				if (i) return Y(`${o} property "${e}" has "enum" but kind is "${n}".`);
			} else {
				let n = t.enum;
				if (!Array.isArray(n) || n.length === 0) return Y(`${o} property "${e}" "enum" must be a non-empty string array.`);
				if (n.length > 64) return Y(`${o} property "${e}" "enum" accepts at most 64 values.`);
				let i = /* @__PURE__ */ new Set();
				for (let t of n) {
					if (typeof t != "string") return Y(`${o} property "${e}" "enum" must be a non-empty string array.`);
					if (t.length > 128) return Y(`${o} property "${e}" enum value exceeds the 128-character limit.`);
					if (i.has(t)) return Y(`${o} property "${e}" enum value "${t}" is declared more than once.`);
					i.add(t);
				}
				r.enum = [...n];
			}
			let a = Object.hasOwn(t, "pattern") && t.pattern !== void 0;
			if (n !== "string") {
				if (a) return Y(`${o} property "${e}" has "pattern" but kind is "${n}".`);
			} else if (a) {
				let n = t.pattern;
				if (typeof n != "string") return Y(`${o} property "${e}" "pattern" must be a string.`);
				if (n.length > 512) return Y(`${o} property "${e}" "pattern" exceeds the 512-character limit.`);
				try {
					new RegExp(n);
				} catch {
					return Y(`${o} property "${e}" "pattern" is not a valid regular expression.`);
				}
				if (!f(n)) return Y(`${o} property "${e}" "pattern" uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected.`);
				r.pattern = n;
			}
			p[e] = r;
		}
		let m = {
			name: s,
			form: c,
			props: p,
			...u ? { binding: u } : {}
		};
		n.push(m), r.set(s, m);
	}
	return {
		ok: !0,
		hostComponents: n,
		hostByName: r
	};
}
function ht(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function gt(e) {
	let t = e.static === !0 || e.dynamic === !1;
	if (e.kind === "enum") {
		let n = `^(?:${(e.enum ?? []).map(ht).join("|")})$`;
		if (n.length <= 512) return {
			kind: "string",
			...e.required === !0 ? { required: !0 } : {},
			...t ? { static: !0 } : {},
			pattern: n
		};
	}
	let n = { kind: e.kind };
	return e.required === !0 && e.default === void 0 && (n.required = !0), t && (n.static = !0), e.enum && (n.enum = [...e.enum]), e.pattern !== void 0 && (n.pattern = e.pattern), n;
}
function _t(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
	for (let i of e.components) {
		let e = {};
		for (let t of Object.keys(i.props)) e[t] = gt(i.props[t]);
		let a = le(i), o = {
			name: i.name,
			form: i.form,
			props: e,
			...a ? { binding: a } : {}
		};
		t.push(o), n.set(i.name, o), r.set(i.name, i);
	}
	return {
		hostComponents: t,
		hostByName: n,
		sdkByName: r
	};
}
function X(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.name, t);
	let r = /* @__PURE__ */ new Map();
	for (let e of t.values()) r.set(e.name, e);
	for (let e of O) r.has(e.name) || r.set(e.name, fe(e));
	return {
		componentByName: n,
		schemaByName: r
	};
}
function Z(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name, de(n));
	return t;
}
function vt(e, t) {
	let n = t.defaults, r = new Set(n.map((e) => e.name));
	if (e !== void 0 && !q(e)) return {
		ok: !1,
		message: "Compile options must be an object.",
		key: "local.options.invalid.object"
	};
	let i = e ?? {}, o = { ...K };
	for (let e of it) {
		if (!Object.hasOwn(i, e)) continue;
		let t = i[e];
		if (t !== void 0) {
			if (typeof t != "boolean") return {
				ok: !1,
				message: `Compile option ${e} must be a boolean.`,
				key: "local.options.invalid.html-flag"
			};
			o[e] = t;
		}
	}
	let l = !1;
	if (Object.hasOwn(i, "markdownBreaks")) {
		let e = i.markdownBreaks;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option markdownBreaks must be a boolean.",
				key: "local.options.invalid.markdown-breaks"
			};
			l = e;
		}
	}
	let u = !0;
	if (Object.hasOwn(i, "strict")) {
		let e = i.strict;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option strict must be a boolean.",
				key: "local.options.invalid.strict"
			};
			u = e;
		}
	}
	if (Object.hasOwn(i, "sourcePhase")) {
		let e = i.sourcePhase;
		if (e !== void 0 && e !== "streaming" && e !== "final") return {
			ok: !1,
			message: "Compile option sourcePhase must be \"streaming\" or \"final\".",
			key: "local.options.invalid.source-phase"
		};
	}
	let d = i.limits, f = a, p = c, m = s;
	if (d !== void 0) {
		if (!q(d)) return {
			ok: !1,
			message: "Compile option limits must be an object.",
			key: "local.options.invalid.limits"
		};
		for (let e of Object.keys(d)) if (!ft.has(e) && d[e] !== void 0) return {
			ok: !1,
			message: `Compile option limits.${e} is not supported.`,
			key: "local.options.invalid.limits-unknown",
			detail: e
		};
		let e = J(d, "maxSyntaxNodes", f);
		if (!e.ok) return e;
		f = e.value;
		let t = J(d, "maxParseWork", p);
		if (!t.ok) return t;
		p = t.value;
		let n = J(d, "maxMarkdownDepth", m);
		if (!n.ok) return n;
		m = n.value;
	}
	let h = Object.hasOwn(i, "config") && i.config !== void 0, g = Object.hasOwn(i, "hostComponents") && i.hostComponents !== void 0;
	if (h && g) return {
		ok: !1,
		message: "Compile option config cannot be combined with hostComponents.",
		key: "local.options.invalid.config-conflict"
	};
	let _, v, y, b, x, S, C, w, T;
	if (h) {
		try {
			_ = t.readConfig(i.config, n);
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return {
				ok: !1,
				message: `Compile option config is invalid: ${t}`,
				key: "local.options.invalid.config",
				detail: t
			};
		}
		let e = _t(_);
		v = e.hostComponents, y = e.hostByName, b = e.sdkByName, x = _.registry;
		let r = X(x, Z(x));
		S = r.schemaByName, C = r.componentByName, w = new Set(_.components.map((e) => e.name)), T = /* @__PURE__ */ new Set();
	} else if (g) {
		let e = mt(i.hostComponents, n);
		if (!e.ok) return e;
		v = e.hostComponents, y = e.hostByName, b = /* @__PURE__ */ new Map(), x = n;
		let t = Z(n);
		for (let [n, r] of e.hostByName) t.set(n, fe({
			...r,
			legacyHost: !0
		}));
		let r = X(n, t);
		S = r.schemaByName, C = r.componentByName, w = new Set(e.hostByName.keys()), T = new Set(e.hostByName.keys());
	} else {
		v = [], y = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Map(), x = n;
		let e = X(n, Z(n));
		S = e.schemaByName, C = e.componentByName, w = /* @__PURE__ */ new Set(), T = /* @__PURE__ */ new Set();
	}
	return {
		ok: !0,
		maxSyntaxNodes: f,
		maxParseWork: p,
		maxMarkdownDepth: m,
		html: o,
		markdownBreaks: l,
		strict: u,
		hostComponents: v,
		hostByName: y,
		..._ ? { config: _ } : {},
		sdkByName: b,
		registry: x,
		componentByName: C,
		schemaByName: S,
		defaultComponentNames: r,
		unmountedLeafNames: _?.presets.some((e) => e.id === "reactive-md/minimal") ? Qe((e) => S.has(e)) : /* @__PURE__ */ new Set(),
		externalComponentNames: w,
		legacyHostNames: T,
		componentConfigKey: _ ? t.configKey(_) : t.defaultConfigKey,
		capabilities: t.capabilities ?? Xe,
		...t.preset ? { preset: t.preset } : {}
	};
}
function yt(e, t = [], n) {
	let r = t.length > 0 ? at : void 0;
	return vt(e, {
		defaults: t,
		...r ? { preset: r } : {},
		defaultConfigKey: nt(t),
		readConfig: tt,
		configKey: (e) => e.key,
		...n ? { capabilities: n } : {}
	});
}
function bt(e) {
	return e.componentConfigKey;
}
// src/local/configuration/kernel-value-rules.ts
function Q(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) r !== void 0 && (t[n] = r);
	return t;
}
function xt(e) {
	let t = [];
	for (let n of ue(e)) switch (n.kind) {
		case "value-date":
			t.push(Q({
				kind: "date",
				min: n.min,
				max: n.max,
				required: n.required
			}));
			break;
		case "value-length":
			t.push(Q({
				kind: "length",
				min: n.min,
				max: n.max
			})), (n.email !== void 0 || n.emailType !== void 0) && t.push(Q({
				kind: "email",
				type: n.email ?? "type",
				value: n.emailType ?? "email"
			}));
			break;
		case "value-email":
			t.push(Q({
				kind: "email",
				type: n.type ?? "type",
				value: n.value ?? "email"
			}));
			break;
		case "value-required": t.push({
			kind: "required",
			required: n.required
		});
	}
	return t;
}
function St(e) {
	if (!e || typeof e != "object") return;
	let t = e.kernel;
	if (t && typeof t == "object") return t;
}
var Ct = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function wt(e) {
	return Ct.test(e);
}
function Tt(e, t, n) {
	let r = [];
	for (let i of e) {
		let e = i.target;
		e ? e.startsWith("#") || /\s/.test(e) ? r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" must be a bare heading slug or anchor id without "#" or whitespace.`,
			start: i.offset,
			key: "local.jump.bad-target",
			params: { target: e }
		}) : !t.has(e) && !n.has(e) && r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" does not resolve to a heading or explicit anchor in this document.`,
			start: i.offset,
			key: "local.jump.unresolved",
			params: { target: e }
		}) : r.push({
			code: "local.jump.target",
			message: "<jump> target cannot be empty.",
			start: i.offset,
			key: "local.jump.empty"
		});
	}
	return r;
}
Object.freeze({
	arrayLength: e,
	dataTableColumns: 20,
	plotCurves: 16,
	plotPoints: p
});
// src/local/evaluation/computations.ts
function $(e, t, n) {
	let r = t ? oe(t, n) : void 0;
	return e.expressionOffset + (r ?? Math.max(0, e.source.indexOf(n)));
}
function Et(e, t, n, r = "local.expression") {
	t instanceof k ? e(`${r}.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0)) : e(`${r}.invalid`, `Expression error: ${t instanceof Error ? t.message : String(t)}`, n);
}
function Dt(e) {
	return e instanceof k ? e : new k("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function Ot(e, t) {
	let n = new Set(e), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let t of e) r.set(t, 0);
	for (let a of e) for (let e of t(a)) {
		if (!n.has(e)) continue;
		r.set(a, (r.get(a) ?? 0) + 1);
		let t = i.get(e);
		t ? t.push(a) : i.set(e, [a]);
	}
	let a = [];
	for (let t of e) (r.get(t) ?? 0) === 0 && a.push(t);
	let o = [];
	for (let e = 0; e < a.length; e += 1) {
		let t = a[e];
		o.push(t);
		for (let e of i.get(t) ?? []) {
			let t = (r.get(e) ?? 0) - 1;
			r.set(e, t), t === 0 && a.push(e);
		}
	}
	let s = new Set(o);
	return {
		order: o,
		cyclic: e.filter((e) => !s.has(e))
	};
}
function kt(e) {
	let t = Object.keys(e), n = new Set(t);
	return Ot(t, (t) => {
		let r = e[t];
		return r ? r.dependencies.filter((e) => n.has(e)) : [];
	});
}
function At(e, t, n, r = /* @__PURE__ */ new Set(), i) {
	let a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = [], l = /* @__PURE__ */ new Set();
	for (let t of e) s.has(t.name) || (s.set(t.name, t), c.push(t.name));
	let u = new Set(c);
	for (let e of c) {
		let t = s.get(e), r;
		try {
			r = i?.expression(t.source) ?? ce(t.source);
		} catch (r) {
			Et(n, r, t.expressionOffset), l.add(e);
			continue;
		}
		a.set(e, r), o.set(e, [...r.dependencies]);
	}
	for (let e of c) if (!l.has(e)) {
		for (let r of o.get(e) ?? []) if (!(u.has(r) || Object.hasOwn(t, r))) {
			n("local.computation.unknown", `Reference to undeclared parameter ${r} in computation "${e}".`, $(s.get(e), a.get(e), r)), l.add(e);
			break;
		}
	}
	let d = /* @__PURE__ */ new Set();
	for (let e of c) {
		if (l.has(e)) continue;
		let i = s.get(e);
		if (i.kind === "const") for (let c of o.get(e) ?? []) {
			let o = u.has(c) ? s.get(c).kind : null;
			Object.hasOwn(t, c) ? (n("local.computation.const", `Constant "${e}" cannot depend on ${r.has(c) ? "external data" : "control parameter"} "${c}".`, $(i, a.get(e), c)), d.add(e)) : o === "computed" && (n("local.computation.const", `Constant "${e}" cannot depend on computed value "${c}".`, $(i, a.get(e), c)), d.add(e));
		}
	}
	let { order: f, cyclic: p } = Ot(c, (e) => o.get(e) ?? []);
	if (p.length > 0) {
		let e = new Set(p), t = [], r = /* @__PURE__ */ new Map(), i = p[0];
		for (; !r.has(i);) {
			r.set(i, t.length), t.push(i);
			let n = (o.get(i) ?? []).find((t) => e.has(t));
			if (n === void 0) break;
			i = n;
		}
		let a = r.has(i) ? t.slice(r.get(i)) : [p[0]], c = a.slice(0, 12).join(" → ") + (a.length > 12 ? " → …" : ` → ${a[0]}`);
		for (let e of a.slice(0, 100)) {
			let t = s.get(e);
			n("local.computation.cycle", `Computation "${e}" is part of a dependency cycle: ${c}.`, t.range.start, t.range.end);
		}
		for (let e of p) l.add(e);
	}
	for (let e of f) if (!l.has(e) && !(s.get(e).kind !== "const" || d.has(e)) && (o.get(e) ?? []).some((e) => u.has(e) ? s.get(e).kind === "const" && d.has(e) : !1)) {
		let t = s.get(e);
		n("local.computation.const", `Constant "${e}" indirectly depends on a value that is not a constant.`, t.expressionOffset), d.add(e);
	}
	let m = {}, h = { ...t };
	for (let e of f) {
		if (l.has(e)) continue;
		let t = s.get(e);
		if ((o.get(e) ?? []).some((e) => l.has(e))) {
			l.add(e);
			continue;
		}
		let r = a.get(e);
		try {
			let t = i ? i.infer(r, h) : r.inferType(h);
			m[e] = t, h[e] = t;
		} catch (r) {
			Et(n, r, t.expressionOffset), l.add(e);
		}
	}
	let g = {}, _ = {}, v = /* @__PURE__ */ Error("failed constant read"), y = (e) => {
		l.add(e), Object.defineProperty(_, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw v;
			}
		});
	};
	for (let e of f) {
		if (l.has(e) || s.get(e).kind !== "const" || d.has(e)) continue;
		let t = s.get(e), r = a.get(e);
		try {
			let i = r.evaluate(_), a = se(i);
			if (a) {
				n("local.computation.budget", `Constant "${e}": ${a}`, t.expressionOffset), y(e);
				continue;
			}
			g[e] = Array.isArray(i) ? i.slice() : i, _[e] = g[e];
		} catch (r) {
			if (r === v) {
				y(e);
				continue;
			}
			let i = Dt(r);
			n("local.computation.expression", `Constant "${e}" cannot be evaluated: ${i.message}`, t.expressionOffset + (Number.isFinite(i.offset) ? i.offset : 0)), y(e);
		}
	}
	let b = {};
	for (let e of c) {
		let t = s.get(e);
		if (l.has(e) || m[e] === void 0) continue;
		let n = {
			name: e,
			kind: t.kind,
			source: t.source,
			dependencies: [...o.get(e) ?? []],
			type: m[e],
			nodeId: t.nodeId,
			range: { ...t.range }
		};
		t.kind === "const" && Object.hasOwn(g, e) && (n.value = g[e]), b[e] = n;
	}
	return {
		computations: b,
		kinds: m,
		order: f.filter((e) => !l.has(e)),
		expressions: a,
		constValues: g
	};
}
function jt(e, t, n, r, i, a = /* @__PURE__ */ new Map()) {
	let o = {}, s = /* @__PURE__ */ new Map(), c = {};
	for (let [e, t] of Object.entries(r)) c[e] = t;
	for (let [e, t] of a) Object.defineProperty(c, e, {
		enumerable: !0,
		configurable: !0,
		get() {
			throw t;
		}
	});
	for (let [e, t] of Object.entries(i)) o[e] = t, c[e] = t;
	for (let r of t) {
		let t = e[r];
		if (!t || t.kind === "const") continue;
		let i = n.get(r);
		if (i) try {
			let e = i.evaluate(c), t = se(e);
			if (t) throw new k("expression-budget", t, 0);
			o[r] = e, c[r] = e;
		} catch (e) {
			let t = Dt(e);
			s.set(r, t), Object.defineProperty(c, r, {
				enumerable: !0,
				configurable: !0,
				get() {
					throw t;
				}
			});
		}
	}
	return {
		values: o,
		errors: s
	};
}
// src/local/evaluation/validation.ts
var Mt = "local.validation.failed", Nt = "local.validation.expression", Pt = "Validation failed.";
function Ft(e) {
	return e.length > 2e3 ? `${y(e, d - 1)}…` : e;
}
function It(e) {
	let t = e.trim();
	return t ? t.split(/\s+/) : [];
}
function Lt(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function Rt(e) {
	if (!e || typeof e != "object") return !1;
	let t = e, n = t.range;
	return typeof t.expression == "string" && typeof t.message == "string" && Array.isArray(t.fields) && !!n && Number.isFinite(n.start) && Number.isFinite(n.end);
}
function zt(e, t, n, r, i) {
	let a = e.length, o = Math.max(0, Math.min(a, Math.trunc(n.start))), s = Math.max(o + 1, Math.min(a, Math.trunc(n.end))), c = 0, l = Math.max(0, t.length - 1);
	for (; c < l;) {
		let e = Math.ceil((c + l) / 2);
		t[e] <= o ? c = e : l = e - 1;
	}
	return {
		code: r,
		message: i,
		severity: "error",
		range: {
			start: o,
			end: s
		},
		line: c + 1,
		column: o - t[c] + 1
	};
}
export { be as $, Ge as A, we as B, Je as C, qe as D, Re as E, Pe as F, ke as G, Ee as H, Ne as I, N as J, Ae as K, Me as L, z as M, Ie as N, Ue as O, B as P, Ce as Q, R, Ye as S, ze as T, De as U, Te as V, Oe as W, F as X, P as Y, I as Z, bt as _, Rt as a, K as b, zt as c, At as d, ye as et, wt as f, it as g, xt as h, Ft as i, Ke as j, He as k, jt as l, Tt as m, Mt as n, he as nt, Lt as o, St as p, M as q, Pt as r, pe as rt, It as s, Nt as t, A as tt, kt as u, yt as v, Le as w, rt as x, vt as y, je as z };
