# Security policy

**English** · [中文](SECURITY-ch.md)

Reactive MD renders local interactive documents written by authors. When document content is untrusted input, the renderer, expressions and math evaluation all stay within the boundaries below. The host remains responsible for authorization, network policy and server-side data.

## Supported versions

Current maintenance covers the latest 0.x preview. Security fixes may ship in minor releases and are described in the [changelog](CHANGELOG.md) with impact and migration steps.

## Threat boundary

The guarantees below are covered by compiler, runtime and renderer tests; capabilities not listed here are not promised.

### Document content

- P0 HTML is rebuilt as typed nodes and React elements. Author CSS is limited to inline declarations and document-scoped rules. JavaScript and extended HTML require separate grants. See [HTML compatibility](docs/reference/html-compatibility-en.md).
- Document scripts run in a dedicated worker with a bounded QuickJS interpreter. The host validates the worker's binding updates and confines registrations to the current view. Extended HTML fragments use a sandbox with an independent origin and a source policy.
- The React renderer escapes author text and error messages. KaTeX generates formula markup, and the HTML sanitizer prepares iframe content for its isolated document.
- Expressions use their own parser and AST evaluator, with no `eval` or `new Function`, and no support for assignment, method calls, property access, prototype paths or imports. Expressions can only read parameters declared by the document and built-in functions.
- KaTeX typesets formulas as HTML with accessible MathML. Input, expansion and user-specified dimensions are bounded; author-defined macros, files, network and HTML entry points are disabled. Invalid or unsupported formulas fall back to bounded source text. Plot evaluation uses its separate budget-limited parser.
- Expressions, templates, tables and charts do not make network requests; chart data must be written in the document.

### URLs and networking

- All images are rejected by default, including relative paths and protocol-relative addresses, so loading the document itself triggers no image requests.
- Images load only when the host passes `urlPolicy` and the policy returns `true`. Images with a protocol still have that protocol checked first: only `http:` and `https:` are allowed. Relative addresses are decided by the policy. Addresses such as `javascript:` or dangerous `data:` URLs are rejected even if the policy allows them.
- Links allow relative addresses and `http:`, `https:`, `mailto:` and `tel:` by default; external HTTP links open in a new tab with `noopener noreferrer`. Dangerous protocols are always rejected.
- If the policy throws, the address is rejected. Images that are allowed to load use `referrerPolicy="no-referrer"`; same-origin images may still carry cookies, so image allowlists should avoid business APIs.
- A trusted `imageResolver` runs only after the image URL passes protocol checks and `urlPolicy`. It maps an accepted URL to host-controlled output; exported files use only verified `data:image/png|jpeg|gif|webp;base64` values, and links never reach it.
- `urlPolicy` is a URL allowlist, not server-side authorization. The host still needs to configure CSP, network egress, an image proxy or a sandboxed iframe (when authors are fully untrusted).

### Resource limits

`src/local/configuration/limits.ts` defines shared limits used by compilation, the runtime and visualizations:

| Limit | Value |
| --- | --- |
| Source per document | 1,000,000 characters |
| Syntax nodes created cumulatively during parsing | 10,000 by default, configured per call by the host |
| A single string value or template | 100,000 characters |
| A single array | 10,000 items |
| Total string length within an array | 100,000 characters |
| Email address | 254 characters, validated in linear time |
| Number of diagnostics | 100 |
| Text of a single diagnostic | 2,000 characters |
| Curves per plot component | 16 |
| Curve sample points requested by the whole document | 20,000 |
| Shared computation steps for plotting | 2,000,000 |

Writes over a limit are rejected and the runtime keeps the last valid state; compile-time overruns return diagnostics. Plotting and math evaluation also have their own depth, token and node budgets. Budgets bound the work for a single document; they do not replace host control over request size, concurrency and timeouts.

Hosts can adjust the syntax node budget for a single compilation with `compileLocal(source, { limits: { maxSyntaxNodes } })`; the value must be a positive safe integer. Document content cannot change this setting. When omitted, the default budget of 10,000 applies; raising the node budget does not change the source length, array, expression or plotting limits. The count covers every `LocalNode` created during parsing, including intermediate nodes that are not kept in the final tree.

### State and isolation

- Parameter state exists only in the memory of the current document instance. Each `LocalReactiveDocument` or `LocalDocumentView` instance is independent; disposal clears subscriptions, expression caches and timers.
- `createLocalRuntime` validates initial values and constraints on shared controls; `set` relies on the controls registered in the document, ignores forged node metadata from the caller, and commits atomically only when every shared control accepts the write.
- `snapshot()` returns a stable frozen snapshot, including frozen arrays; `get()` and `evaluate()` return array copies. State updates are committed through validated `set()` calls.
- `disabled` and `if` are display states only, not permission control. Business permissions and value validation must be enforced by the host when submitting to the server.

### Shareable HTML export

- `reactive-md-state/v1` stores only public binding names and serializable values. It excludes `@` internal bindings, revisions, node IDs, AST data, UI state and timers. Source digest, syntax, parameter set and every value are validated before import; unknown or conflicting keys reject the whole file.
- Default ReactiveMD interactive exports embed a fixed standalone runtime and a CSP with no network connections, frames, objects, base injection or form submission. Native HTML exports additionally permit the sandboxed `srcdoc` frame that holds the document; its own CSP governs author CSS and scripts. JSON, source, titles and notices are escaped for their HTML/script context.
- The CLI inlines only relative raster files that resolve inside the document directory or an explicit asset root. It rejects remote images, URL schemes, absolute paths, traversal, symlink escapes, SVG, forged formats and oversized assets. The demo export dialog disables HTML export when images are present.
- Static HTML contains no runtime script or auto-mount payload. Static-first hydration is covered only in the single-file Chromium/Edge path; it is not a general hydration or sandboxing guarantee. Use a sandboxed iframe for fully untrusted authors.
- Exporting current parameters is an explicit host/reader action. Treat the generated state file and HTML as potentially sensitive; choose initial values unless current values are intentionally meant to be shared.

## Host responsibilities

- Decide who may write, submit and share documents; limit request size, concurrency and execution time for untrusted authors. Compiling a 1,000,000-character document is still real CPU work.
- Configure `urlPolicy` for images and links; maintain CSP, network egress control and image allowlists.
- Revalidate form values, permissions and business constraints on the server; do not trust `disabled`, conditional visibility or client state inside the document.
- When persistence is needed, store the original `.reactive.md` source securely; runtime state and `LocalDocument` should not be treated as a persistence format.
- Before statically rendering untrusted documents on the server, assess the resource limits of the rendering process. General SSR hydration remains unverified; only the single-file static-first path has Chromium/Edge coverage. Hydration is not a security boundary.
- Report vulnerabilities in third-party dependencies upstream as well; this package is responsible only for its own integration code.

## Reporting vulnerabilities

The repository has GitHub private vulnerability reporting enabled. Submit affected versions, a minimal reproduction, expected impact and remediation suggestions through [Report a vulnerability](https://github.com/yao1145/ReactiveMD/security/advisories/new).

Use the private channel to report vulnerability details; remove exploit code, credentials, user data and information about affected deployments from public issues and PRs.
