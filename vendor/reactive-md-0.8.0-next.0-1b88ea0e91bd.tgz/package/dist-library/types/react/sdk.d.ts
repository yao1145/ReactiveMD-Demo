import { type ReactNode } from 'react';
import type { Diagnostic, LocalNode, LocalRuntime } from '../local/contracts/types.js';
import type { LocalHostRenderer, LocalRenderMode } from '../local/rendering/render-types.js';
import type { LocalUrlPolicy } from '../local/rendering/LocalDocumentView.js';
import type { LocalLocale } from '../local/theme/i18n.js';
import type { LocalThemePackage } from '../sdk/theme.js';
import type { LocalRuntimeServices } from '../runtime-services/runtime.js';
import type { LocalComponentDefinition, LocalConfig } from '../sdk/types.js';
import { type LocalComponentContext, type LocalReactComponent, type LocalReactPreset } from './component-api.js';
export type { LocalComponentRender } from './component-api.js';
export { defineReactComponent, type LocalComponentBindingHandle, type LocalComponentContext, type LocalComponentInstance, type LocalComponentPropValue, type LocalComponentSetResult, type LocalComponentValue, type LocalReactComponent, type LocalReactComponentImplementation, type LocalReactPreset, } from './component-api.js';
/** Everything a renderer needs from the document view. */
export interface LocalReactRenderEnvironment {
    runtime: LocalRuntime;
    /** Runtime-scoped services; omitted only by hand-built render environments. */
    services?: LocalRuntimeServices;
    mode: LocalRenderMode;
    visible: boolean;
    disabled: boolean;
    disabledInvalid: boolean;
    resetToken: number;
    /** UI locale for built-in labels and diagnostics inside components. */
    locale: LocalLocale;
    /** Render this component's children at the inherited visibility. */
    renderChildren(nodes: LocalNode[] | undefined, visible: boolean): ReactNode;
    /** Render projected children as inline content. */
    renderInline(nodes: LocalNode[] | undefined, visible: boolean): ReactNode;
    /** Plain text projection of nodes. */
    renderToText(nodes: LocalNode[] | undefined): string;
    report(diagnostics: Diagnostic[]): void;
    positionOf?(offset: number): {
        line: number;
        column: number;
    };
    definitionFor(name: string): LocalComponentDefinition | undefined;
    validationField(node: LocalNode): {
        describedBy?: string;
        invalid: boolean;
    };
    validationHint(node: LocalNode): {
        id: string;
        failed: boolean;
        error: boolean;
        message: string;
    } | null;
    sourceAttributes(node: LocalNode, componentName?: string): Record<string, string>;
    targetId(to: string): string | undefined;
    anchorId(node: LocalNode): string | undefined;
    jumpAllowed(to: string): boolean;
    jumpTo(target: string): 'ok' | 'missing' | 'hidden';
    urlPolicy?: LocalUrlPolicy;
    imageResolver?: (url: string) => string | null;
}
export type LocalReactExtensionRenderer = (node: LocalNode, environment: LocalReactRenderEnvironment) => ReactNode;
export interface CreateLocalReactConfigOptions {
    /** One implementation per external component declared by the config. */
    components: readonly LocalReactComponent[];
    /**
     * Additional installed component implementations grouped into presets.
     * The default preset is always installed; duplicate names are rejected.
     */
    presets?: readonly LocalReactPreset[];
}
/**
 * Host implementation map for one immutable `LocalConfig`. The serializable
 * config is available as `.config`; React functions stay on this object and
 * never enter it.
 */
export interface LocalReactConfig {
    readonly config: LocalConfig;
    /** Selected implementations that are not supplied by the default React preset. */
    readonly components: readonly LocalReactComponent[];
    /** Every implementation selected for the active registry, in registry order. */
    readonly implementations: readonly LocalReactComponent[];
    /** Derived from `config.themes`; pass straight to the document view. */
    readonly themes: readonly LocalThemePackage[];
    /** Compatibility bridge for the legacy `hostRenderer` prop. */
    readonly hostRenderer: LocalHostRenderer;
}
/**
 * Validate implementations against an immutable config and expose the bridge
 * used by the document views. Implementations are selected by manifest
 * identity (id, name, version and semantic digest), not by preset identity.
 * Candidates that are not active in the registry are ignored, so packs and
 * replacements can ship a superset without duplicating implementations.
 */
export declare function createReactConfig(input: LocalConfig, options: CreateLocalReactConfigOptions): LocalReactConfig;
export declare class LocalReactExtensionMissingError extends Error {
    readonly componentName: string;
    constructor(name: string);
}
/**
 * Renderer for `hostComponent` nodes produced from an SDK config. Unlike the
 * legacy host bridge it does not require host data, so a stateless leaf can
 * render on its own.
 */
export declare function localReactExtensionRenderer(config: LocalReactConfig): LocalReactExtensionRenderer;
/**
 * Validate a compiled document against the React config before rendering.
 * Missing or mismatched components are reported instead of executed.
 */
export declare function validateLocalReactExtensions(config: LocalReactConfig, requirements: unknown): Diagnostic[];
/**
 * Safely report an error raised outside React's render phase (an event handler
 * or an effect). The component itself stays mounted and the diagnostic points
 * at its source range.
 */
export declare function reportLocalComponentError(context: Pick<LocalComponentContext, 'report' | 'instance'>, error: unknown, source?: string): void;
/** Wrap an event handler so an exception is reported instead of escaping. */
export declare function safeLocalComponentEvent<T extends unknown[]>(context: Pick<LocalComponentContext, 'report' | 'instance'>, handler: (...args: T) => void, source?: string): (...args: T) => void;
