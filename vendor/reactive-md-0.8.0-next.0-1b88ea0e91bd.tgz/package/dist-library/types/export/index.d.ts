import { type ShareableHtmlOptions } from '../shareable.js';
import type { LocalStyleResource } from '../sdk/theme.js';
import type { LocalConfig, LocalExtensionRequirements } from '../sdk/types.js';
import type { Diagnostic, LocalDocument } from '../local/contracts/types.js';
import { type LocalStandaloneBundleManifest } from './restoration.js';
export * from './restoration.js';
export * from './component-state.js';
export { readLocalExportResources } from './resources.js';
export { validateLocalComponentContracts, validateLocalExtensionRequirements, } from './requirements.js';
export type LocalExportTarget = 'static' | 'ssr' | 'offline';
/** A trusted host build artifact, never reconstructed from function.toString(). */
export interface LocalStandaloneBundle {
    readonly script: string;
    readonly extensions: LocalExtensionRequirements;
    /** Present on bundles sealed by the public build/export API. */
    readonly seal?: LocalStandaloneBundleManifest;
}
export interface LocalExportPlan {
    readonly target: LocalExportTarget;
    readonly extensions: LocalExtensionRequirements;
    readonly resources: readonly LocalStyleResource[];
    readonly css: string;
    readonly diagnostics: readonly Diagnostic[];
    readonly ok: boolean;
}
export interface LocalExportPlanOptions {
    readonly document: LocalDocument;
    readonly config: LocalConfig;
    readonly target: LocalExportTarget;
    readonly resources?: readonly LocalStyleResource[];
    /** Resource identities declared by the host build's component style manifest. */
    readonly requiredResources?: readonly string[];
    readonly bundle?: LocalStandaloneBundle;
}
/** Bind an explicitly built standalone script to the installed manifest set. */
export declare function defineLocalStandaloneBundle(script: string, config: LocalConfig): LocalStandaloneBundle;
/** Preflight a target before state serialization or any output is generated. */
export declare function createLocalExportPlan(options: LocalExportPlanOptions): LocalExportPlan;
export interface LocalExtensionShareableOptions extends Omit<ShareableHtmlOptions, 'runtimeScript' | 'extensions'> {
    readonly document: LocalDocument;
    readonly config: LocalConfig;
    readonly bundle?: LocalStandaloneBundle;
    readonly resources?: readonly LocalStyleResource[];
    readonly requiredResources?: readonly string[];
}
/** First-phase export: the host supplies its prebuilt implementation bundle. */
export declare function createLocalShareableHtml(options: LocalExtensionShareableOptions): string;
