/**
 * Validate a component-state sidecar for a single-file export.
 *
 * The exported HTML restores state through the standalone runtime, whose
 * document identity defaults to the source digest. This module applies the same
 * identity and the same known-component scope before the sidecar is embedded,
 * so an export never ships records the runtime would silently skip.
 */
import type { Diagnostic, LocalDocument } from '../local/contracts/types.js';
import { type LocalComponentStateDocument } from '../runtime-services/component-state.js';
export type LocalComponentStateExportOutcome = {
    readonly ok: true;
    readonly componentState: LocalComponentStateDocument;
    /** Record-level problems. Warnings are skippable; errors are not. */
    readonly diagnostics: Diagnostic[];
} | {
    readonly ok: false;
    readonly diagnostics: Diagnostic[];
};
export interface ResolveLocalComponentStateExportOptions {
    /** Host identity for this export; defaults to the source digest. */
    readonly documentId?: string;
    /**
     * Current semantic configuration key. When supplied, matching records are
     * stamped with it and records from another configuration are dropped.
     * Omitted leaves the sidecar's own `configKey` untouched.
     */
    readonly configKey?: string;
    /** Legacy configuration identities accepted while resolving. */
    readonly legacyConfigKeys?: readonly string[];
}
/**
 * Resolve the component-state sidecar embedded in an interactive export.
 *
 * Structural payload errors fail the export. Invalid records keep their
 * `error` severity; records for another document identity or for components
 * that no longer exist are dropped with a warning.
 */
export declare function resolveLocalComponentStateExport(document: LocalDocument, input: unknown, options?: ResolveLocalComponentStateExportOptions): LocalComponentStateExportOutcome;
