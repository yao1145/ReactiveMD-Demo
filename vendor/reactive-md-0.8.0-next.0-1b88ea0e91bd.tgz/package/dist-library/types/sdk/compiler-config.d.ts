import type { LocalCompatProfile } from './compat-profile.js';
import type { LocalComponentDefinition, LocalConfig } from './types.js';
/**
 * Semantic SDK-configuration reader for single compilation.
 *
 * This module validates the data that affects compilation: presets, component
 * manifests, replacements and their dependency graph. It intentionally imports
 * neither `config.ts` nor any theme implementation, so a compiler that installs
 * no default preset can still accept a host configuration.
 */
/**
 * Phase-one default preset identity, kept as protocol data rather than by
 * importing the preset implementation. The standard compiler and this reader
 * must agree for semantic keys to remain compatible.
 */
export declare const DEFAULT_COMPILER_PRESET: {
    readonly id: string;
    readonly version: string;
};
/**
 * Validate configuration data for compilation. Caller-supplied derived fields
 * are ignored; they are rebuilt from the assembly.
 *
 * `defaults` is the assembled built-in registry used when reading a legacy v1
 * payload and when validating host component names. A v2 payload carries its
 * own assembly and does not depend on `defaults`.
 */
export declare function readCompilerConfig(value: unknown, defaults?: readonly LocalComponentDefinition[], additionalProfiles?: readonly LocalCompatProfile[]): LocalConfig;
/**
 * Default semantic key for one assembled compiler profile. This replaces the
 * old preset-reference hash so the standard compiler and SDK agree on v2 keys.
 */
export declare function compilerDefaultConfigKey(defaults: readonly LocalComponentDefinition[]): string;
