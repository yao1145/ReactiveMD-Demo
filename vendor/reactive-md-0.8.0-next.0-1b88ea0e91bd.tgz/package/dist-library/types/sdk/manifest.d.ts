import { type LocalComponentChildren, type LocalComponentDefinition, type LocalComponentRequirement, type LocalComponentStructure } from './types.js';
/** Bounded registration budgets for external manifests. */
export declare const MAX_LOCAL_SDK_COMPONENTS = 64;
export declare const MAX_LOCAL_SDK_PROPS = 64;
export declare const MAX_LOCAL_SDK_NAME_LENGTH = 128;
export declare const MAX_LOCAL_SDK_ID_LENGTH = 160;
export declare const MAX_LOCAL_SDK_VERSION_LENGTH = 64;
export declare const MAX_LOCAL_SDK_ENUM_VALUES = 64;
export declare const MAX_LOCAL_SDK_PATTERN_LENGTH = 512;
export declare const MAX_LOCAL_SDK_STRING_LENGTH = 4096;
export declare const MAX_LOCAL_SDK_DEPENDENCIES = 16;
export declare const MAX_LOCAL_SDK_STYLES = 32;
export declare const MAX_LOCAL_SDK_STYLE_ID_LENGTH = 256;
/** Aggregate serialized-size budget for one component manifest. */
export declare const MAX_LOCAL_SDK_MANIFEST_BYTES: number;
/** Bounded public rule/slot counts for one manifest. */
export declare const MAX_LOCAL_SDK_BINDINGS = 16;
export declare const MAX_LOCAL_SDK_RULES = 32;
export declare const MAX_LOCAL_SDK_RULE_SLOTS = 16;
export declare const MAX_LOCAL_SDK_STRUCTURE_ITEMS = 32;
/** Attributes owned implicitly by a declared binding. */
export declare const LOCAL_BINDING_ATTRIBUTES: ReadonlySet<string>;
/** UTF-8 byte length of JSON-compatible data, bounded by the caller. */
export declare function localJsonByteLength(value: unknown): number;
/** Map a legacy `children` declaration to the equivalent public structure. */
export declare function localStructureFromChildren(children: LocalComponentChildren | undefined): LocalComponentStructure | undefined;
/**
 * Validate and normalize one component manifest. Unknown fields, unsafe
 * regexes, conflicting prop modes and invalid defaults are rejected; the
 * result is fresh, bounded, JSON-only data.
 */
export declare function readLocalComponentManifest(value: unknown): LocalComponentDefinition;
/** `defineLocalComponent` validates, clones and freezes a manifest. */
export declare function defineLocalComponent(input: LocalComponentDefinition): LocalComponentDefinition;
/**
 * Deterministic, key-order-independent view of a normalized manifest.
 *
 * Authoring metadata and per-prop descriptions are deliberately excluded:
 * editor copy must not change a component's compile semantic digest.
 */
export declare function canonicalLocalComponent(definition: LocalComponentDefinition): unknown;
/** Stable semantic digest of one manifest. */
export declare function localComponentDigest(definition: LocalComponentDefinition): string;
/** Plain requirement record used by compiled documents and export checks. */
export declare function localComponentRequirement(definition: LocalComponentDefinition): LocalComponentRequirement;
/** Read-only check used by registry validation and tests. */
export declare function isLocalComponentName(value: unknown): value is string;
/** Read-only namespaced-id check shared by presets and replacement records. */
export declare function isLocalComponentId(value: unknown): value is string;
