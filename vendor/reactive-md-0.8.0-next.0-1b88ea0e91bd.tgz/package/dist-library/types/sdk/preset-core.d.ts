import type { LocalPresetPackage } from './types.js';
/** Validate, clone and freeze one preset package. */
export declare function readLocalPresetPackage(value: unknown): LocalPresetPackage;
/** Public factory mirroring `defineLocalComponent`. */
export declare function defineLocalPreset(input: LocalPresetPackage): LocalPresetPackage;
/**
 * Semantic preset digest: sorted component id/version/digest plus exact
 * dependency references. Authoring, metadata, themes and declaration order are
 * intentionally excluded.
 */
export declare function localPresetDigest(preset: LocalPresetPackage): string;
