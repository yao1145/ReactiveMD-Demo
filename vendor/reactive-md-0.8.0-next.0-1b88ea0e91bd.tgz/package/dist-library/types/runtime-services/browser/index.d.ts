/**
 * Browser adapter for the component-state persistence port.
 *
 * This module belongs to the browser layer, not the pure `reactive-md/runtime`
 * entry: it reads `localStorage` lazily and never at import time, so server
 * builds can import it without touching `window`.
 */
import type { LocalComponentStateStorage } from '../component-state.js';
/** The subset of the Web Storage API this adapter needs. */
export interface LocalWebStorageLike {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
export interface CreateLocalBrowserStateStorageOptions {
    /**
     * Document identity used to scope the storage key. Use the same value the
     * runtime receives as `documentId`; a source digest is a valid identity but
     * changes when the source changes.
     */
    readonly documentId: string;
    /** Defaults to `globalThis.localStorage`. */
    readonly storage?: LocalWebStorageLike;
    /** Defaults to `reactive-md:component-state:v1:`. */
    readonly keyPrefix?: string;
}
export interface LocalBrowserStateStorage extends LocalComponentStateStorage {
    /** The exact key this backend reads and writes. */
    readonly key: string;
}
export declare const LOCAL_COMPONENT_STATE_STORAGE_PREFIX = "reactive-md:component-state:v1:";
/**
 * Persist one document's component-state sidecar in Web Storage. The backend
 * performs no cross-tab synchronization: the registry reads once at creation
 * and writes the complete sidecar after each save or clear.
 */
export declare function createLocalBrowserStateStorage(options: CreateLocalBrowserStateStorageOptions): LocalBrowserStateStorage;
