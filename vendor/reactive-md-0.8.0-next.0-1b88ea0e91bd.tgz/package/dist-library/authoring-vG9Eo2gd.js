import { v as e } from "./compiler-core-Cx4zHwWJ.js";
import { D as t } from "./config-validation-DXTynAw7.js";
import { $ as n, S as r } from "./validation-BFE38wGe.js";
import { n as i } from "./options-Do4oc74k.js";
import { t as a } from "./compiler-C9P4lwjR.js";
import { c as o } from "./schema-Dw4QXdis.js";
// src/local/source/authoring.ts
var s = /^[A-Za-z_][A-Za-z0-9_]*$/, c = 128, l = /* @__PURE__ */ new Set([
	"code",
	"inlineCode",
	"math",
	"inlineMath",
	"fallback",
	"comment",
	"footnoteDefinition"
]), u = /* @__PURE__ */ new Set([
	"local.version.unsupported",
	"local.version.malformed",
	"local.version.duplicate",
	"local.version.placement",
	"local.parse",
	"local.interpolation",
	"local.tag.unclosed",
	"local.tag.mismatch",
	"local.tag.closing",
	"local.tag.shape",
	"local.attribute",
	"local.budget"
]);
function d(e) {
	return e !== void 0 && /[A-Za-z_]/.test(e);
}
function f(e) {
	return e !== void 0 && /[A-Za-z0-9_]/.test(e);
}
function p(e) {
	return e !== void 0 && /\s/.test(e);
}
function m(e) {
	return e.length > 0 && e.length <= c && s.test(e) && !n.has(e);
}
function h(e) {
	return {
		start: e.start,
		end: e.end
	};
}
function g(e, t) {
	try {
		return a(e, t).diagnostics;
	} catch {
		return [];
	}
}
function _(e) {
	let t = i(e);
	return t.ok ? t.htmlActive ? "html" : "markdown" : "invalid";
}
function v(e) {
	let t = i(e);
	return t.ok ? [...t.schemaByName.values()] : [];
}
var y = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/;
function b(e, t) {
	if (e[t] !== "<") return null;
	let n = y.exec(e.slice(t));
	if (!n) return null;
	let r = !!n[1], i = n[2], a = t + (r ? 2 : 1), o = "", s = t + n[0].length;
	for (; s < e.length; s += 1) {
		let t = e[s];
		if (o) t === o && (o = "");
		else if (t === "\"" || t === "'") o = t;
		else if (t === ">") break;
	}
	if (s >= e.length) return null;
	let c = s, l = s + 1;
	if (r) return {
		start: t,
		end: l,
		contentEnd: c,
		name: i,
		nameRange: {
			start: a,
			end: a + i.length
		},
		closing: !0,
		selfClosing: !1,
		attrs: []
	};
	let u = [], d = a + i.length;
	for (; d < c;) {
		for (; d < c && p(e[d]);) d += 1;
		if (d >= c) break;
		if (e[d] === "/") {
			d += 1;
			continue;
		}
		let t = /^[A-Za-z][A-Za-z0-9_-]*/.exec(e.slice(d, c));
		if (!t) {
			d += 1;
			continue;
		}
		let n = d, r = t[0];
		d += r.length;
		let i = d, a = d;
		for (; a < c && p(e[a]);) a += 1;
		if (e[a] !== "=") {
			u.push({
				name: r,
				nameRange: {
					start: n,
					end: n + r.length
				}
			}), d = i;
			continue;
		}
		for (d = a + 1; d < c && p(e[d]);) d += 1;
		let o = e[d];
		if (o === "\"" || o === "'") {
			let t = d, i = d + 1, a = e.indexOf(o, i);
			if (a < 0 || a > c) {
				u.push({
					name: r,
					nameRange: {
						start: n,
						end: n + r.length
					},
					valueRange: {
						start: i,
						end: c
					},
					quoteStart: t,
					quoteEnd: c
				}), d = c;
				continue;
			}
			u.push({
				name: r,
				nameRange: {
					start: n,
					end: n + r.length
				},
				valueRange: {
					start: i,
					end: a
				},
				quoteStart: t,
				quoteEnd: a
			}), d = a + 1;
			continue;
		}
		let s = d;
		for (; d < c && !p(e[d]);) d += 1;
		u.push({
			name: r,
			nameRange: {
				start: n,
				end: n + r.length
			},
			valueRange: {
				start: s,
				end: d
			},
			unquoted: !0
		});
	}
	return {
		start: t,
		end: l,
		contentEnd: c,
		name: i,
		nameRange: {
			start: a,
			end: a + i.length
		},
		closing: !1,
		selfClosing: /\/\s*$/.test(e.slice(a + i.length, c)),
		attrs: u
	};
}
function x(e, n, i) {
	if (n.range.end <= i) return null;
	let a = e.lastIndexOf("</", n.range.end - 1);
	if (a < i) return null;
	let o = b(e, a);
	return !o || !o.closing || o.end > n.range.end || o.name !== n.name && (!t.has(o.name.toLowerCase()) && !r.has(o.name.toLowerCase()) || o.name.toLowerCase() !== n.name?.toLowerCase()) ? null : o;
}
function S(e, t, n) {
	let r = [];
	for (let i = t; i < n;) {
		if (e[i] === "\\" && e.startsWith("{{", i + 1)) {
			i += 3;
			continue;
		}
		if (!e.startsWith("{{", i)) {
			i += 1;
			continue;
		}
		let t = "", a = i + 2;
		for (; a < n - 1; a += 1) {
			let n = e[a];
			if (t) n === "\\" ? a += 1 : n === t && (t = "");
			else if (n === "\"" || n === "'") t = n;
			else if (n === "}" && e[a + 1] === "}") break;
		}
		if (a >= n - 1) break;
		r.push({
			start: i,
			end: a + 2,
			innerStart: i + 2,
			innerEnd: a
		}), i = a + 2;
	}
	return r;
}
function C(e, t) {
	let n = {
		quot: "\"",
		apos: "'",
		amp: "&",
		lt: "<",
		gt: ">"
	}, r = [t.start], i = "";
	for (let a = t.start; a < t.end;) {
		let o = e[a] === "&" ? /^&(quot|apos|amp|lt|gt);/.exec(e.slice(a, t.end)) : null;
		i += o ? n[o[1]] : e[a], a += o ? o[0].length : 1, r.push(a);
	}
	return {
		text: i,
		offsets: r
	};
}
function w(e, t, r) {
	let i = [];
	for (let a = t; a < r;) {
		let t = e[a];
		if (t === "\"" || t === "'") {
			let n = t;
			for (a += 1; a < r;) if (e[a] === "\\") a += 2;
			else {
				if (e[a] === n) {
					a += 1;
					break;
				}
				a += 1;
			}
		} else {
			if (/[0-9]/.test(t) || t === "." && e[a + 1] !== void 0 && /[0-9]/.test(e[a + 1])) {
				let t = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/.exec(e.slice(a, r));
				if (t) {
					a += t[0].length;
					continue;
				}
			}
			if (d(t)) {
				let t = a;
				for (a += 1; a < r && f(e[a]);) a += 1;
				let o = e.slice(t, a), s = a;
				for (; s < r && p(e[s]);) s += 1;
				if (e[s] === "(" || o === "true" || o === "false" || o === "null" || o === "pi" || o === "e" || n.has(o)) continue;
				i.push({
					name: o,
					range: {
						start: t,
						end: a
					}
				});
			} else a += 1;
		}
	}
	return i;
}
function T(e, t) {
	return Object.values(e.bindings ?? {}).some((e) => e.bind === t);
}
function E(e, t = []) {
	for (let n of e) l.has(n.type) && t.push(h(n.range)), n.type !== "fallback" && n.children && E(n.children, t);
	return t;
}
function D(e, t) {
	let n = E(t), r = (t) => {
		for (let i of t) {
			if (i.type === "component" || i.type === "hostComponent") {
				let t = b(e, i.range.start);
				t && n.push({
					start: t.start,
					end: t.end
				});
			}
			i.type !== "fallback" && i.children && r(i.children);
		}
	};
	r(t), n.sort((e, t) => e.start - t.start || t.end - e.end);
	let i = [], a = 0, o = 0;
	for (; a < e.length;) {
		let t = e.indexOf("<!--", a);
		if (t < 0) break;
		for (; o < n.length && n[o].end <= t;) o++;
		let r = n[o];
		if (r && r.start <= t) {
			a = r.end;
			continue;
		}
		let s = e.indexOf("-->", t + 4), c = s < 0 ? e.length : s + 3;
		i.push({
			start: t,
			end: c
		}), a = c;
	}
	return i;
}
function O(e, t) {
	return t.find((t) => t.name === e)?.props;
}
function k(n, i, a, o) {
	let s = [];
	o?.themeRange && s.push({
		type: "component",
		name: "theme",
		id: "author-theme",
		range: o.themeRange
	});
	for (let e of Object.values(o?.computations ?? {})) s.push({
		type: "component",
		name: e.kind,
		id: e.nodeId,
		range: e.range
	});
	let c = s.length ? i.concat(s) : i, u = /* @__PURE__ */ new Set(), d = [], f = /* @__PURE__ */ new Map(), p = [], g = [], _ = (e, t) => {
		for (let r of w(n, e, t)) p.push(r);
	}, v = (e, t) => {
		let n = f.get(e);
		n ? n.push(h(t)) : f.set(e, [h(t)]);
	}, y = (e, t) => {
		if (u.has(e.range.start)) return;
		let r = b(n, e.range.start);
		if (!r || r.closing) return;
		u.add(e.range.start), d.push({
			kind: "tag",
			range: h(r.nameRange)
		});
		let i = a.find((t) => t.name === e.name);
		for (let t of r.attrs) {
			if (d.push({
				kind: "attribute",
				range: h(t.nameRange)
			}), !t.valueRange) continue;
			let o = O(e.name ?? "", a)?.[t.name], s = i !== void 0 && T(i, t.name) && Object.values(i.bindings ?? {}).some((e) => e.bind === t.name && (e.requiresAttributes ?? []).every((e) => r.attrs.some((t) => t.name === e))), c = (e.name === "computed" || e.name === "const" || e.name === "external") && t.name === "name", l = n.slice(t.valueRange.start, t.valueRange.end), u = C(n, t.valueRange);
			if (i?.rules?.some((e) => e.kind === "validation-rule" && e.fields === t.name)) {
				for (let e of u.text.matchAll(/\S+/g)) {
					if (!m(e[0])) continue;
					let t = {
						start: u.offsets[e.index],
						end: u.offsets[e.index + e[0].length]
					};
					p.push({
						name: e[0],
						range: t
					}), d.push({
						kind: "binding",
						range: t
					});
				}
				continue;
			}
			let f = o && !o.static ? S(u.text, 0, u.text.length) : [];
			if (f.length > 0) {
				let e = 0;
				for (let n of f) {
					n.start > e && d.push({
						kind: "string",
						range: {
							start: u.offsets[e],
							end: u.offsets[n.start]
						}
					}), d.push({
						kind: "expression",
						range: {
							start: u.offsets[n.start],
							end: u.offsets[n.end]
						}
					});
					for (let e of w(u.text, n.innerStart, n.innerEnd)) (!i?.rules?.some((e) => e.kind === "scoped-expressions" && e.scope === "row" && e.attributes.includes(t.name) || e.kind === "row-values" && e.key === t.name) || e.name !== "item" && e.name !== "index") && p.push({
						name: e.name,
						range: {
							start: u.offsets[e.range.start],
							end: u.offsets[e.range.end]
						}
					});
					e = n.end;
				}
				e < u.text.length && d.push({
					kind: "string",
					range: {
						start: u.offsets[e],
						end: t.valueRange.end
					}
				});
			} else (s || c) && m(l) ? (d.push({
				kind: "binding",
				range: h(t.valueRange)
			}), v(l, t.valueRange)) : t.valueRange.end > t.valueRange.start && d.push({
				kind: "string",
				range: h(t.valueRange)
			});
		}
		let o = x(n, e, r.end);
		o && d.push({
			kind: "tag",
			range: h(o.nameRange)
		});
	}, E = (i, o) => {
		for (let s of i) {
			if ((s.type === "component" || s.type === "hostComponent") && s.name) y(s, o);
			else if (s.type === "interpolation") d.push({
				kind: "expression",
				range: h(s.range)
			}), _(s.range.start + 2, Math.max(s.range.start + 2, s.range.end - 2));
			else if (s.type === "math" || s.type === "inlineMath") {
				if (d.push({
					kind: "math",
					range: h(s.range)
				}), a.find((e) => e.name === o)?.rules?.some((e) => e.kind === "inline-math-reads") && s.type === "math") {
					let t = s.range.start + 2;
					try {
						for (let r of e(n.slice(t, s.range.end - 2))) {
							let e = {
								name: r.name,
								range: {
									start: t + r.range.start,
									end: t + r.range.end
								}
							};
							p.push(e), g.push(e);
						}
					} catch {}
				}
			} else s.type === "code" || s.type === "inlineCode" ? d.push({
				kind: "code",
				range: h(s.range)
			}) : s.type === "comment" && d.push({
				kind: "comment",
				range: h(s.range)
			});
			if (!l.has(s.type) && n[s.range.start] === "<" && !u.has(s.range.start)) {
				let e = b(n, s.range.start);
				e && !e.closing && (t.has(e.name.toLowerCase()) || r.has(e.name.toLowerCase())) && y({
					...s,
					name: e.name
				}, o);
			}
			s.type !== "fallback" && s.children && E(s.children, s.name);
		}
	};
	E(c);
	for (let e of D(n, c)) d.push({
		kind: "comment",
		range: e
	});
	d.sort((e, t) => e.range.start - t.range.start || e.range.end - t.range.end);
	let k = [];
	for (let e of d) {
		if (e.range.end <= e.range.start) continue;
		let t = k[k.length - 1];
		t && e.range.start < t.range.end || k.push(e);
	}
	let A = [];
	for (let [e, t] of f) {
		let n = [], r = /* @__PURE__ */ new Set();
		for (let t of p) {
			if (t.name !== e) continue;
			let i = `${t.range.start}:${t.range.end}`;
			r.has(i) || (r.add(i), n.push(h(t.range)));
		}
		n.sort((e, t) => e.start - t.start || e.end - t.end), t.sort((e, t) => e.start - t.start || e.end - t.end), A.push({
			name: e,
			declarations: t,
			references: n
		});
	}
	return A.sort((e, t) => e.declarations[0].start - t.declarations[0].start || e.name.localeCompare(t.name)), {
		tokens: k,
		bindings: A,
		mathReferences: g
	};
}
function A(e, t, n = {}) {
	if (typeof e != "string") return {
		tokens: [],
		bindings: [],
		diagnostics: []
	};
	if (_(t) !== "markdown") return {
		tokens: [],
		bindings: [],
		diagnostics: n.diagnostics === !1 ? [] : g(e, t)
	};
	let r = n.document?.source === e ? n.document : o(e, t), i = k(e, r.nodes, v(t), r);
	return {
		tokens: i.tokens,
		bindings: i.bindings,
		diagnostics: n.diagnostics === !1 ? [] : g(e, t)
	};
}
function j(e, t, n) {
	let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)/.exec(e.slice(t, Math.min(e.length, n + 1)));
	if (!r) return null;
	let i = !!r[1], a = r[2], o = t + r[0].length, s = [], c = !1, l, u = !1;
	if (!i) {
		let t = o;
		for (; t < n;) {
			for (; t < n && p(e[t]);) t += 1;
			if (t >= n) break;
			if (e[t] === "/") {
				u = !0, t += 1;
				continue;
			}
			let r = /^[A-Za-z][A-Za-z0-9_-]*/.exec(e.slice(t, n));
			if (!r) {
				t += 1;
				continue;
			}
			let i = r[0], a = t;
			t += i.length;
			let o = t, d = t;
			for (; d < n && p(e[d]);) d += 1;
			if (e[d] !== "=") {
				s.push({
					name: i,
					nameStart: a,
					nameEnd: o,
					nameRange: {
						start: a,
						end: o
					}
				}), t = o;
				continue;
			}
			for (t = d + 1; t < n && p(e[t]);) t += 1;
			let f = e[t];
			if (f === "\"" || f === "'") {
				let r = t, u = t + 1, d = e.indexOf(f, u);
				if (d < 0 || d >= n) {
					let e = {
						name: i,
						nameStart: a,
						nameEnd: o,
						nameRange: {
							start: a,
							end: o
						},
						valueRange: {
							start: u,
							end: n
						},
						quoteStart: r,
						quoteEnd: d < 0 ? n : d
					};
					s.push(e), l = e, c = !0, t = n;
					break;
				}
				s.push({
					name: i,
					nameStart: a,
					nameEnd: o,
					nameRange: {
						start: a,
						end: o
					},
					valueRange: {
						start: u,
						end: d
					},
					quoteStart: r,
					quoteEnd: d
				}), t = d + 1;
				continue;
			}
			let m = t;
			for (; t < n && !p(e[t]);) t += 1;
			s.push({
				name: i,
				nameStart: a,
				nameEnd: o,
				nameRange: {
					start: a,
					end: o
				},
				valueRange: {
					start: m,
					end: t
				},
				unquoted: !0
			});
		}
	}
	let d = -1;
	if (!c) {
		let t = n;
		for (; t > o && /[A-Za-z0-9_-]/.test(e[t - 1]);) --t;
		t > o && p(e[t - 1]) && (d = t);
	}
	return {
		name: a,
		closing: i,
		selfClosing: u,
		inValue: c,
		currentAttribute: l,
		attrs: s,
		partialStart: d
	};
}
function M(e, t, n) {
	let r = [], i = (e) => {
		for (let t of e) t.type === "component" && r.push(t.range.start), t.type !== "fallback" && t.children && i(t.children);
	};
	i(n), r.sort((e, t) => e - t);
	for (let n = r.length - 1; n >= 0; --n) {
		let i = r[n];
		if (i >= t) continue;
		let a = b(e, i);
		if (a && t <= a.end) return i;
		if (a && a.end < t) break;
	}
	let a = t;
	for (; a > 0;) {
		let n = e.lastIndexOf("<", a - 1);
		if (n < 0) return -1;
		if (e[n - 1] === "\\") {
			a = n;
			continue;
		}
		let r = e[n + 1];
		if (r !== "/" && !d(r)) a = n;
		else if (N(e, n, t)) a = n;
		else return n;
	}
	return -1;
}
function N(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") return !0;
	}
	return !1;
}
function P(e, t) {
	let n = t;
	for (; n > 0;) {
		let r = e.lastIndexOf("{{", n - 1);
		if (r < 0) return null;
		if (e[r - 1] === "\\") {
			n = r;
			continue;
		}
		let i = "", a = r + 2, o = -1;
		for (; a < e.length - 1; a += 1) {
			let t = e[a];
			if (i) t === "\\" ? a += 1 : t === i && (i = "");
			else if (t === "\"" || t === "'") i = t;
			else if (t === "}" && e[a + 1] === "}") {
				o = a;
				break;
			}
		}
		if (o >= 0 && o + 2 <= t) n = r;
		else return {
			start: r,
			end: o < 0 ? e.length : o + 2,
			innerStart: r + 2,
			innerEnd: o < 0 ? e.length : o
		};
	}
	return null;
}
function F(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		r ? t === "\\" ? i += 1 : t === r && (r = "") : (t === "\"" || t === "'") && (r = t);
	}
	return r !== "";
}
function I(e, t) {
	let n = 0, r = e.length - 1;
	for (; n <= r;) {
		let i = n + r >> 1, a = e[i];
		if (t < a.start) r = i - 1;
		else if (t >= a.end) n = i + 1;
		else return !0;
	}
	return !1;
}
function L(e, t, n, r) {
	let i = e.slice(t, n), a = i && r.startsWith(i) ? r.slice(i.length) : "";
	return {
		start: t,
		end: a && e.startsWith(a, n) ? n + a.length : n
	};
}
function R(e, t, n, r) {
	if (F(e, n.innerStart, t)) return [];
	let i = t;
	for (; i > n.innerStart && f(e[i - 1]);) --i;
	if (e[i - 1] === ".") return [];
	let a = e.slice(i, t);
	return a && !d(a[0]) ? [] : r.filter((e) => e.name.startsWith(a)).map((n) => ({
		label: n.name,
		insertText: n.name,
		range: L(e, i, t, n.name),
		kind: "binding",
		detail: `${n.declarations.length} declaration${n.declarations.length === 1 ? "" : "s"}, ${n.references.length} reference${n.references.length === 1 ? "" : "s"}`
	}));
}
function z(e, t, n, r) {
	let i = n.currentAttribute;
	if (!i) return [];
	let a = O(n.name, r)?.[i.name];
	if (!a || a.kind !== "enum" || !a.values) return [];
	let o = i.valueRange?.start ?? t, s = e.slice(o, t);
	return a.values.filter((e) => e.startsWith(s)).map((n) => ({
		label: n,
		insertText: n,
		range: L(e, o, t, n),
		kind: "value",
		detail: `${i.name} value`
	}));
}
function B(e, t, n, r) {
	if (n.closing || n.inValue || n.partialStart < 0) return [];
	let i = O(n.name, r);
	if (!i) return [];
	let a = e.slice(n.partialStart, t);
	if (a && !/^[A-Za-z0-9_-]*$/.test(a)) return [];
	let o = new Set(n.attrs.filter((e) => e.nameEnd < n.partialStart).map((e) => e.name));
	return Object.entries(i).filter(([e]) => !o.has(e) && e.startsWith(a)).map(([r, i]) => ({
		label: r,
		insertText: r,
		range: L(e, n.partialStart, t, r),
		kind: "attribute",
		detail: i.required ? `${i.kind}, required` : i.kind
	}));
}
function V(e, t, n) {
	let r = Math.max(0, t - 256), i = e.slice(r, t), a = /<\/?([A-Za-z][A-Za-z0-9-]*)?$/.exec(i);
	if (!a) return [];
	let o = r + a.index;
	if (e[o] !== "<" || e[o - 1] === "\\") return [];
	let s = e[o + 1] === "/", c = o + (s ? 2 : 1);
	if (c > t) return [];
	let l = a[1] ?? "";
	return (s ? n.filter((e) => e.form !== "leaf").map((e) => e.name) : n.map((e) => e.name)).filter((e) => e.startsWith(l)).map((n) => ({
		label: n,
		insertText: n,
		range: L(e, c, t, n),
		kind: "tag",
		detail: s ? "closing tag" : "component"
	}));
}
function H(e, t, n) {
	if (typeof e != "string" || !Number.isFinite(t) || _(n) !== "markdown") return [];
	let r = Math.max(0, Math.min(e.length, Math.floor(t))), i = v(n), a = o(e, n), s = [...E(a.nodes), ...D(e, a.nodes)].sort((e, t) => e.start - t.start);
	if (I(s, r) || r === e.length && s.some((e) => e.end === r && e.start < r)) return [];
	let c = k(e, a.nodes, i), l = P(e, r);
	if (l) {
		let t = M(e, r, a.nodes);
		if (t >= 0) {
			let n = j(e, t, r);
			if (n?.inValue && n.currentAttribute && O(n.name, i)?.[n.currentAttribute.name]?.static) return [];
		}
		return R(e, r, l, c.bindings);
	}
	let u = M(e, r, a.nodes);
	if (u >= 0) {
		let t = j(e, u, r);
		if (t?.inValue) return z(e, r, t, i);
	}
	let d = V(e, r, i);
	if (d.length > 0) return d;
	if (u >= 0) {
		let t = j(e, u, r);
		if (t) return B(e, r, t, i);
	}
	return [];
}
function U(e, t) {
	let n = "", r = 0;
	for (let i of t) n += e.slice(r, i.range.start) + i.text, r = i.range.end;
	return n + e.slice(r);
}
function W(e, t, n, r) {
	if (typeof e != "string" || typeof t != "string" || typeof n != "string") throw Error("Rename requires string arguments.");
	if (_(r) === "html") throw Error("Bindings cannot be renamed in HTML mode.");
	if (!m(n)) throw Error(`"${n}" is not a valid binding name. Use [A-Za-z_][A-Za-z0-9_]* and avoid reserved names.`);
	let i = k(e, o(e, r).nodes, v(r)), s = i.bindings.find((e) => e.name === t);
	if (!s || s.declarations.length === 0) throw Error(`Binding "${t}" is not declared in this document.`);
	if (t === n) return {
		source: e,
		edits: []
	};
	if (i.bindings.some((e) => e.name === n)) throw Error(`Binding "${n}" already exists.`);
	if (g(e, r).some((e) => e.severity === "error" && u.has(e.code))) throw Error("The document cannot be renamed safely while parse errors remain.");
	let c = /* @__PURE__ */ new Set(), l = [];
	for (let e of [...s.declarations, ...s.references]) {
		let t = `${e.start}:${e.end}`;
		c.has(t) || (c.add(t), l.push(h(e)));
	}
	l.sort((e, t) => e.start - t.start || e.end - t.end);
	let d = new Set(i.mathReferences.filter((e) => e.name === t).map((e) => `${e.range.start}:${e.range.end}`)), f = l.map((e) => ({
		range: h(e),
		text: d.has(`${e.start}:${e.end}`) ? `\\mathrm{${n}}` : n
	})), p = U(e, f);
	if (a(e, r).ok && !a(p, r).ok) throw Error("Rename could not preserve all binding references; the source was left unchanged.");
	return {
		source: p,
		edits: f
	};
}
function G(e, t) {
	let n = e.slice(t.nameRange.start, t.nameRange.end), r = t.attrs.map((t) => {
		let n = e.slice(t.nameRange.start, t.nameRange.end);
		return t.valueRange === void 0 ? n : t.quoteStart !== void 0 && t.quoteEnd !== void 0 ? `${n}=${e.slice(t.quoteStart, t.quoteEnd + 1)}` : n;
	}), i = r.length > 0 ? `<${n} ${r.join(" ")}` : `<${n}`;
	return t.selfClosing ? `${i} />` : `${i}>`;
}
function K(e, t) {
	if (typeof e != "string" || _(t) !== "markdown") return e;
	let n;
	try {
		n = a(e, t);
	} catch {
		return e;
	}
	if (n.diagnostics.some((e) => e.severity === "error")) return e;
	let r = o(e, t), i = [], s = (t) => {
		for (let n of t) {
			if ((n.type === "component" || n.type === "hostComponent") && n.name) {
				let t = b(e, n.range.start);
				if (t && !t.closing && !/[\r\n]/.test(e.slice(t.start, t.end))) {
					let n = G(e, t);
					n !== e.slice(t.start, t.end) && i.push({
						start: t.start,
						end: t.end,
						text: n
					});
				}
				if (t) {
					let r = x(e, n, t.end);
					if (r && !/[\r\n]/.test(e.slice(r.start, r.end))) {
						let t = `</${e.slice(r.nameRange.start, r.nameRange.end)}>`;
						t !== e.slice(r.start, r.end) && i.push({
							start: r.start,
							end: r.end,
							text: t
						});
					}
				}
			}
			n.type !== "fallback" && n.children && s(n.children);
		}
	};
	s(r.nodes), i.sort((e, t) => e.start - t.start || e.end - t.end);
	let c = "", l = 0;
	for (let t of i) t.start < l || (c += e.slice(l, t.start) + t.text, l = t.end);
	return c + e.slice(l);
}
export { W as i, H as n, K as r, A as t };
