import { a as e, w as t } from "./component-state-BD9i9iwP.js";
// src/runtime-services/browser/index.ts
var n = "reactive-md:component-state:v1:", r = 128;
function i() {
	let e;
	try {
		e = globalThis.localStorage;
	} catch (e) {
		throw TypeError(`localStorage is unavailable in this context: ${e instanceof Error ? e.message : String(e)}`);
	}
	if (typeof e != "object" || !e || typeof e.getItem != "function" || typeof e.setItem != "function" || typeof e.removeItem != "function") throw TypeError("localStorage is unavailable in this context; pass options.storage instead.");
	return e;
}
function a(n) {
	if (typeof n != "object" || !n) throw TypeError("createLocalBrowserStateStorage requires an options object.");
	let a = t(n.documentId);
	if (a === void 0) throw TypeError("createLocalBrowserStateStorage requires a valid documentId.");
	let o = n.keyPrefix ?? "reactive-md:component-state:v1:";
	if (typeof o != "string" || o.length === 0 || o.length > r) throw TypeError(`keyPrefix must be a non-empty string of at most ${r} characters.`);
	let s = n.storage ?? i(), c = `${o}${a}`;
	return Object.freeze({
		key: c,
		read() {
			let e = s.getItem(c);
			return e === null ? null : e;
		},
		write(t) {
			let n = JSON.stringify(t);
			if (n.length > 1048576) throw RangeError(`The serialized component state exceeds the ${e}-character storage budget.`);
			s.setItem(c, n);
		},
		remove() {
			s.removeItem(c);
		}
	});
}
export { n as LOCAL_COMPONENT_STATE_STORAGE_PREFIX, a as createLocalBrowserStateStorage };
