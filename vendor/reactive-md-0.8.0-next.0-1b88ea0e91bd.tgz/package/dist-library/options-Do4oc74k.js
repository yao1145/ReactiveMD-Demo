import { f as e, l as t } from "./validation-BFE38wGe.js";
import { t as n } from "./parser-standard-Yl2fhqEB.js";
import r from "./reactive-md-default-preset.js";
import { c as i, l as a, n as o, u as s } from "./registry-De2QLL87.js";
// src/local/configuration/options.ts
function c(t) {
	return e(t, {
		defaults: o(),
		preset: {
			id: r.id,
			version: r.version
		},
		defaultConfigKey: i(),
		readConfig: (e) => s(e),
		configKey: (e) => i(e),
		capabilities: n
	});
}
function l(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var u = 256, d = 4096, f = /* @__PURE__ */ new WeakMap(), p = /* @__PURE__ */ new Map(), m = /* @__PURE__ */ new WeakMap(), h = 0;
function g() {
	return h += 1, h;
}
function _(e) {
	if (typeof e == "object" && e || typeof e == "function") {
		let t = e, n = m.get(t);
		return n === void 0 && (n = g(), m.set(t, n)), `unreadable#${n}`;
	}
	return `unreadable:${typeof e}:${String(e)}`;
}
function v(e) {
	let t = [], n = 0, r = (e) => {
		if (n += 1, n > d) throw RangeError("signature budget");
		switch (typeof e) {
			case "string": return `s${JSON.stringify(e)}`;
			case "number": return `n${Object.is(e, -0) ? "-0" : String(e)}`;
			case "boolean": return e ? "b1" : "b0";
			case "undefined": return "u";
			case "bigint": return `g${e.toString()}`;
			case "symbol": {
				let t = p.get(e);
				return t === void 0 && (t = g(), p.set(e, t)), `y${t}`;
			}
			case "function": {
				let t = f.get(e);
				return t === void 0 && (t = g(), f.set(e, t)), `f${t}`;
			}
		}
		if (e === null) return "null";
		let i = e, a = t.indexOf(i);
		if (a >= 0) return `r${a}`;
		t.push(i);
		try {
			if (Array.isArray(i)) {
				let e = Math.min(i.length, 8);
				if (i.length > u) {
					let t = `a#${i.length}[`;
					for (let n = 0; n < e; n += 1) t += `${r(i[n])},`;
					return `${t}]`;
				}
				let t = `a${i.length}[`;
				for (let e = 0; e < i.length; e += 1) t += `${r(i[e])},`;
				return `${t}]`;
			}
			let e = Object.keys(i);
			if (e.length > u) {
				let t = `o#${e.length}{`;
				for (let n of e.slice(0, 8)) t += `${r(n)},`;
				return `${t}}`;
			}
			e.sort();
			let t = "o{";
			for (let n of e) t += `${r(n)}:${r(i[n])},`;
			return `${t}}`;
		} finally {
			t.pop();
		}
	};
	try {
		return r(e);
	} catch {
		return _(e);
	}
}
function y(e) {
	if (e === void 0 && (e = {}), !l(e)) return "invalid";
	let n = t.map((t) => {
		if (!Object.hasOwn(e, t)) return "-";
		let n = e[t];
		return n === void 0 ? "-" : n === !0 ? "1" : n === !1 ? "0" : "!";
	}).join(""), r = "";
	if (Object.hasOwn(e, "limits")) {
		let t = e.limits;
		if (t === void 0) r = "default";
		else if (!l(t)) r = "invalid";
		else {
			let e = (e) => !Object.hasOwn(t, e) || t[e] === void 0 ? "default" : String(t[e]);
			r = `${e("maxSyntaxNodes")}:${e("maxParseWork")}:${e("maxMarkdownDepth")}`;
		}
	}
	let i = "";
	if (Object.hasOwn(e, "hostComponents") && e.hostComponents !== void 0) {
		let t = e.hostComponents;
		try {
			Array.isArray(t) ? t.length > 0 && (i = t.length > 32 ? `:hosts=oversize:${t.length}` : `:hosts=${v(t)}`) : i = `:hosts=${v(t)}`;
		} catch {
			i = `:hosts=${_(t)}`;
		}
	}
	let o = !Object.hasOwn(e, "markdownBreaks") || e.markdownBreaks === void 0 ? "-" : e.markdownBreaks === !0 ? "1" : e.markdownBreaks === !1 ? "0" : "!", s = !Object.hasOwn(e, "strict") || e.strict === void 0 || e.strict === !0 ? "strict=1" : e.strict === !1 ? "strict=0:recovery=2" : "strict=!", c = "";
	return Object.hasOwn(e, "config") && e.config !== void 0 && (c = `:config=${a(e.config)}`), `${n}:${r}:${o}:${s}${i}${c}`;
}
export { c as n, y as t };
