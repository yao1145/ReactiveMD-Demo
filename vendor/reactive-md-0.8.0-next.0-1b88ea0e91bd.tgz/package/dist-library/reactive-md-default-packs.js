import { L as e, n as t, r as n } from "./identity-MYJXKSkB.js";
import { t as r } from "./default-components-CmcEmEkA.js";
// src/presets/packs.ts
var i = /* @__PURE__ */ new Set([
	"input",
	"textarea",
	"number",
	"slider",
	"range-slider",
	"coordinate",
	"toggle",
	"checkbox",
	"date",
	"select",
	"choices",
	"radio-group",
	"multi-select",
	"option",
	"progress",
	"timer",
	"quiz",
	"counter",
	"checklist"
]), a = /* @__PURE__ */ new Set([
	"jump",
	"anchor",
	"text",
	"section",
	"panel",
	"card",
	"grid",
	"column",
	"tabs",
	"tab",
	"steps",
	"step",
	"accordion",
	"disclosure",
	"if",
	"alert",
	"badge",
	"tooltip",
	"validation"
]), o = /* @__PURE__ */ new Set([
	"data-table",
	"table",
	"column",
	"timeline"
]), s = /* @__PURE__ */ new Set([
	"chart",
	"plot",
	"diagram",
	"node",
	"edge"
]);
function c(i, a, o = []) {
	return n({
		protocol: e,
		id: i,
		version: t,
		components: r.filter((e) => a.has(e.name)),
		...o.length === 0 ? {} : { dependencies: o.map((e) => ({
			id: e,
			version: t
		})) }
	});
}
var l = c("reactive-md/default-controls", i), u = c("reactive-md/default-layout", a), d = c("reactive-md/default-data", o), f = c("reactive-md/default-visuals", s, [d.id]);
export { l as controlsPack, d as dataPack, u as layoutPack, f as visualsPack };
