// src/runtime-services/identity.ts
var e = new TextEncoder(), t = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/, n = /^[^\u0000-\u001f\u007f]{1,256}$/;
function r(t) {
	let n = e.encode(t), r = 2166136261;
	for (let e = 0; e < n.length; e += 1) r ^= n[e], r = Math.imul(r, 16777619) >>> 0;
	return r >>> 0;
}
function i(e) {
	if (typeof e != "string") throw TypeError("localSourceDigest requires a source string.");
	return `fnv1a32:${r(e).toString(16).padStart(8, "0")}`;
}
function a(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	return n.test(t) ? t : void 0;
}
function o(e) {
	if (typeof e != "string") return;
	let n = e.trim();
	return t.test(n) ? n : void 0;
}
function s(e) {
	return a(e.documentId) ?? e.sourceDigest;
}
function c(e) {
	let t = s(e), n = o(e.stateKey), i = n === void 0 ? `node:${e.nodeId}` : `state:${n}`, a = encodeURIComponent(t);
	return `doc:${a.length <= 256 ? a : `h${r(t).toString(16).padStart(8, "0")}`}:${i}`;
}
function l(e, t) {
	return r(`${e >>> 0}:${t}`);
}
function u(e) {
	if (typeof e.explicitSeed == "number" && Number.isFinite(e.explicitSeed)) return Math.trunc(e.explicitSeed) >>> 0;
	let t = o(e.stateKey), n = t === void 0 ? `node:${e.nodeId}` : `state:${t}`;
	return l(e.documentSeed, `${e.componentId}|${n}`);
}
function d(e) {
	return Number.isFinite(e) ? Math.trunc(e) >>> 0 : 0;
}
// src/runtime-services/random.ts
var f = "mulberry32", p = 1;
function m(e) {
	return Object.freeze({
		algorithm: f,
		version: 1,
		state: d(e)
	});
}
function h(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return null;
	let t = e;
	if (t.algorithm !== "mulberry32" || t.version !== 1 || typeof t.state != "number" || !Number.isFinite(t.state)) return null;
	let n = d(t.state);
	return n === t.state ? Object.freeze({
		algorithm: f,
		version: 1,
		state: n
	}) : null;
}
function g(e) {
	let t = d(e.state + 1831565813), n = Math.imul(t ^ t >>> 15, t | 1);
	return n ^= n + Math.imul(n ^ n >>> 7, n | 61), {
		value: ((n ^ n >>> 14) >>> 0) / 4294967296,
		state: Object.freeze({
			algorithm: f,
			version: 1,
			state: t
		})
	};
}
function _(e, t, n) {
	let r = g(e);
	if (!Number.isFinite(t) || !Number.isFinite(n)) return {
		value: 0,
		state: r.state
	};
	let i = Math.ceil(Math.min(t, n)), a = Math.floor(Math.max(t, n));
	return a < i ? {
		value: i,
		state: r.state
	} : {
		value: i + Math.floor(r.value * (a - i + 1)),
		state: r.state
	};
}
function v(e, t) {
	let n = t.slice(), r = e;
	for (let e = n.length - 1; e > 0; --e) {
		let t = _(r, 0, e);
		r = t.state;
		let i = n[e];
		n[e] = n[t.value], n[t.value] = i;
	}
	return {
		items: n,
		state: r
	};
}
function y(e, t) {
	return m(l(e, t));
}
function b(e, t = .5) {
	let n = g(e);
	return {
		value: n.value < t,
		state: n.state
	};
}
// src/runtime-services/component-state.ts
var x = "reactive-md-component-state/v1", S = "reactive-md-component-state-document/v1", C = 16384, w = 262144, T = 16, E = 1e4, D = 1e5, O = 1048576, k = 128, A = 64, j = 512, M = 1e6, N = 128, P = /[\u0000-\u001f\u007f-\u009f]/, F = new TextEncoder();
function I(e, t, n = "error") {
	return {
		code: e,
		message: t,
		severity: n,
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function L(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function R(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function z(e) {
	return typeof e == "string" && e.length > 0 && e.length <= N && !P.test(e) && R(e);
}
function B(e, t, n) {
	return t === void 0 || e === t || n.includes(e);
}
function V(e, t) {
	if (e === null) return null;
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw TypeError("numbers must be finite");
		return e;
	}
	if (typeof e == "string") {
		if (e.length > 1e5) throw RangeError(`strings exceed ${D} characters`);
		if (!R(e)) throw TypeError("strings must be well-formed Unicode");
		return e;
	}
	if (t >= 16) throw RangeError("nesting exceeds 16 levels");
	if (Array.isArray(e)) {
		if (e.length > 1e4) throw RangeError(`arrays exceed ${E} items`);
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("arrays cannot use symbol keys");
		return e.map((e) => V(e, t + 1));
	}
	if (L(e)) {
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("objects cannot use symbol keys");
		let n = Object.keys(e);
		if (n.length > 1e4) throw RangeError(`objects exceed ${E} keys`);
		let r = {};
		for (let i of n) {
			if (i === "__proto__") throw TypeError("the key \"__proto__\" is not allowed");
			if (i.length > 1e5) throw RangeError(`keys exceed ${D} characters`);
			if (!R(i)) throw TypeError("keys must be well-formed Unicode");
			r[i] = V(e[i], t + 1);
		}
		return r;
	}
	throw TypeError("values must be JSON-safe primitives, arrays or plain objects");
}
function H(e) {
	return V(e, 0);
}
function U(e) {
	return Object.freeze({
		...e,
		data: V(e.data, 0),
		...e.random === void 0 ? {} : { random: h(e.random) ?? e.random }
	});
}
function W(e) {
	if (!L(e)) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.shape", "A component state record must be a plain object.")]
	};
	let t = /* @__PURE__ */ new Set([
		"format",
		"component",
		"componentVersion",
		"stateVersion",
		"key",
		"documentId",
		"data",
		"random"
	]);
	for (let n of Object.keys(e)) if (!t.has(n)) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.key", `Unknown component state key "${n}".`)]
	};
	if (e.format !== "reactive-md-component-state/v1") return {
		ok: !1,
		diagnostics: [I("local.runtime.state.format", `Unsupported component state format; expected "${x}".`)]
	};
	let n = e.component;
	if (typeof n != "string" || n.trim() === "" || n.length > k) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.component", "Component name must be a non-empty string.")]
	};
	let r = e.componentVersion;
	if (typeof r != "string" || r.trim() === "" || r.length > A) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.component-version", "Component version must be a non-empty string.")]
	};
	let i = e.stateVersion;
	if (typeof i != "number" || !Number.isInteger(i) || i < 0 || i > M) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.version", "State version must be a non-negative integer.")]
	};
	let a = e.key;
	if (typeof a != "string" || a.trim() === "" || a.length > j) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.key-name", "State key must be a non-empty string.")]
	};
	let o = e.documentId;
	if (o !== void 0 && (typeof o != "string" || o.trim() === "" || o.length > 256)) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.document", "State documentId must be a non-empty string.")]
	};
	let s;
	try {
		s = H(e.data);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [I("local.runtime.state.data", `Invalid component state data: ${e instanceof Error ? e.message : String(e)}.`)]
		};
	}
	let c;
	if (e.random !== void 0 && (c = h(e.random) ?? void 0, c === void 0)) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.random", "Invalid random state.")]
	};
	let l = {
		format: x,
		component: n,
		componentVersion: r,
		stateVersion: i,
		key: a,
		...o === void 0 ? {} : { documentId: o },
		data: s,
		...c === void 0 ? {} : { random: c }
	};
	return F.encode(JSON.stringify(l)).length > 16384 ? {
		ok: !1,
		diagnostics: [I("local.runtime.state.size", `Component state exceeds the ${C}-byte limit.`)]
	} : {
		ok: !0,
		record: Object.freeze(l)
	};
}
function G(e) {
	let t = e;
	if (typeof e == "string") {
		if (e.length > 1048576) return {
			ok: !1,
			diagnostics: [I("local.runtime.state.size", "The component state payload is too large.")]
		};
		try {
			t = JSON.parse(e);
		} catch {
			return {
				ok: !1,
				diagnostics: [I("local.runtime.state.json", "The component state payload is not valid JSON.")]
			};
		}
	}
	if (!L(t)) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.shape", "The component state document must be a plain object.")]
	};
	if (t.format !== "reactive-md-component-state-document/v1") return {
		ok: !1,
		diagnostics: [I("local.runtime.state.document-format", `Unsupported component state document format; expected "${S}".`)]
	};
	let n = t.configKey;
	if (n !== void 0 && !z(n)) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.config-key", "The component state configKey must be a non-empty bounded string.")]
	};
	if (!L(t.records)) return {
		ok: !1,
		diagnostics: [I("local.runtime.state.records", "Component state records must be a plain object.")]
	};
	let r = {}, i = [], a = [], o = 0;
	for (let e of Object.keys(t.records)) {
		let n = W(t.records[e]);
		n.ok ? n.record.key === e ? (o += F.encode(JSON.stringify(n.record)).length, o > 262144 ? (a.push(e), i.push(I("local.runtime.state.total-size", `Component state exceeds the ${w}-byte document limit.`))) : r[e] = n.record) : (a.push(e), i.push(I("local.runtime.state.key-mismatch", `Component state record "${e}" declares a different key "${n.record.key}".`))) : (a.push(e), i.push(...n.diagnostics));
	}
	return {
		ok: !0,
		...n === void 0 ? {} : { configKey: n },
		records: r,
		diagnostics: i,
		skipped: a
	};
}
function K(e) {
	let t = G(e);
	if (!t.ok) return t;
	let n = {};
	for (let [e, r] of Object.entries(t.records)) n[e] = r;
	return {
		ok: !0,
		document: Object.freeze({
			format: S,
			...t.configKey === void 0 ? {} : { configKey: t.configKey },
			records: Object.freeze(n)
		}),
		records: Object.freeze(n),
		diagnostics: t.diagnostics,
		skipped: t.skipped
	};
}
function q(e) {
	let t = s(e), n = e.sourceDigest, r = e.knownKeys, i = e.configKey;
	if (i !== void 0 && !z(i)) throw TypeError("configKey must be a non-empty bounded string.");
	let a = Object.freeze((e.legacyConfigKeys ?? []).filter(z)), o = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Set(), d = /* @__PURE__ */ new Set(), f = [], p = e.storage, m = null, h = () => {
		for (let e of d) e();
	};
	function g() {
		if (p !== void 0) try {
			let e = v.snapshot();
			Object.keys(e.records).length === 0 ? p.remove() : p.write(e), m = null;
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			if (t === m) return;
			m = t, f.push(I("local.runtime.state.storage", `The component state could not be persisted: ${t}`, "warning"));
		}
	}
	let _ = (e) => {
		let t = 0;
		for (let [n, r] of o) n !== e && (t += F.encode(JSON.stringify(r)).length);
		return t;
	}, v = {
		documentId: t,
		sourceDigest: n,
		key(e) {
			return c({
				documentId: t,
				sourceDigest: n,
				nodeId: e.nodeId,
				stateKey: e.stateKey
			});
		},
		handle(e) {
			let n = v.key({
				nodeId: e.nodeId,
				stateKey: e.stateKey
			}), r = l.get(n), i = !1;
			r !== void 0 && r !== e.nodeId ? (i = !0, u.has(n) || (u.add(n), f.push(I("local.runtime.state.duplicate-key", `Component state key "${n}" is used by more than one component instance.`)))) : l.set(n, e.nodeId);
			let a = {
				key: n,
				component: e.component,
				componentVersion: e.componentVersion,
				duplicate: i,
				load() {
					if (i) return null;
					let e = o.get(n);
					return e === void 0 ? null : U(e);
				},
				save(r, a) {
					if (i) return {
						ok: !1,
						diagnostics: [I("local.runtime.state.duplicate-key", `Component state key "${n}" is used by more than one component instance.`)]
					};
					let s = a?.version ?? e.stateVersion ?? 0, c = W({
						format: x,
						component: e.component,
						componentVersion: e.componentVersion,
						stateVersion: s,
						key: n,
						documentId: t,
						data: r,
						...a?.random === void 0 ? {} : { random: a.random }
					});
					if (!c.ok) return {
						ok: !1,
						diagnostics: c.diagnostics
					};
					let l = F.encode(JSON.stringify(c.record)).length;
					return _(n) + l > 262144 ? {
						ok: !1,
						diagnostics: [I("local.runtime.state.total-size", `Component state exceeds the ${w}-byte document limit.`)]
					} : (o.set(n, c.record), h(), g(), {
						ok: !0,
						diagnostics: [],
						record: U(c.record)
					});
				},
				clear() {
					i || o.delete(n) && (h(), g());
				}
			};
			return Object.freeze(a);
		},
		load(e) {
			let t = o.get(e);
			return t === void 0 ? null : U(t);
		},
		clear(e) {
			o.delete(e) && (h(), g());
		},
		snapshot() {
			let e = {};
			for (let [t, n] of o) e[t] = U(n);
			return Object.freeze({
				format: S,
				...i === void 0 ? {} : { configKey: i },
				records: Object.freeze(e)
			});
		},
		restore(e) {
			let n = G(e);
			if (!n.ok) return f.push(...n.diagnostics), {
				accepted: [],
				skipped: [],
				diagnostics: n.diagnostics
			};
			if (n.configKey !== void 0 && !B(n.configKey, i, a)) {
				let e = [.../* @__PURE__ */ new Set([...n.skipped, ...Object.keys(n.records)])];
				return n.diagnostics.push(I("local.runtime.state.config-mismatch", `Saved component state belongs to configuration "${n.configKey}", not "${i}".`, "warning")), f.push(...n.diagnostics), {
					accepted: [],
					skipped: e,
					diagnostics: n.diagnostics
				};
			}
			let s = [], c = typeof r == "function" ? r() : r;
			for (let [e, r] of Object.entries(n.records)) r.documentId !== void 0 && r.documentId !== t ? (n.skipped.push(e), n.diagnostics.push(I("local.runtime.state.document-mismatch", `Saved state key "${e}" belongs to a different document.`))) : c !== void 0 && !c.has(e) ? (n.skipped.push(e), n.diagnostics.push(I("local.runtime.state.unknown-component", `Saved state key "${e}" does not match any component in this document.`))) : (o.set(e, r), s.push(e));
			return n.diagnostics.length && f.push(...n.diagnostics), s.length && h(), {
				accepted: s,
				skipped: n.skipped,
				diagnostics: n.diagnostics
			};
		},
		diagnostics() {
			return Object.freeze([...f]);
		},
		subscribe(e) {
			return d.add(e), () => {
				d.delete(e);
			};
		}
	}, y = e.initial;
	if (y === void 0 && p !== void 0) try {
		let e = p.read();
		e !== null && (y = e);
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		f.push(I("local.runtime.state.storage", `The component state could not be read: ${t}`, "warning"));
	}
	return y !== void 0 && v.restore(y), Object.freeze(v);
}
export { i as C, s as D, u as E, d as O, r as S, o as T, b as _, O as a, c as b, w as c, f as d, p as f, h as g, g as h, T as i, q as l, y as m, x as n, E as o, m as p, C as r, D as s, S as t, K as u, _ as v, a as w, l as x, v as y };
