import { D as e, j as t, k as n } from "./identity-MYJXKSkB.js";
import { u as r, y as i } from "./registry-De2QLL87.js";
// src/export/requirements.ts
var a = 128, o = 16777216, s = 5e5;
function c(e, t) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function l(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function u(t, n) {
	if (t === void 0) return [];
	let i = [], a = (e) => i.push(c("local.extension.requirements", e));
	try {
		if (!t || typeof t != "object" || Array.isArray(t)) return a("Extension requirements must be a plain object."), i;
		let o = t;
		if (o.protocol !== "reactive-md-extensions/v1" || !Array.isArray(o.components) || o.components.length > 64) return a("Unsupported or oversized extension requirements."), i;
		let s = n === void 0 ? void 0 : r(n), c = /* @__PURE__ */ new Set();
		for (let t of o.components) {
			if (!t || typeof t != "object" || typeof t.id != "string" || typeof t.name != "string" || typeof t.version != "string" || typeof t.digest != "string" || [
				t.id,
				t.name,
				t.version,
				t.digest
			].some((e) => e.length > 256) || c.has(t.id)) {
				a("Invalid or duplicate component requirement.");
				continue;
			}
			c.add(t.id);
			let n = s?.registry.find((e) => e.id === t.id);
			n ? (n.name !== t.name || n.version !== t.version || e(n) !== t.digest) && a(`Component ${t.id}@${t.version} does not match the installed component contract.`) : a(`Component ${t.id}@${t.version} is not installed in this host.`);
		}
	} catch (e) {
		a(e instanceof Error ? e.message : String(e));
	}
	return i;
}
function d(e) {
	let r = [], i = (e) => r.push(c("local.extension.contract-metadata", e)), s = e.componentDefinitions;
	if (s === void 0) return {
		definitions: [],
		diagnostics: r
	};
	if (!Array.isArray(s)) return i("Carried component definitions must be an array."), {
		definitions: [],
		diagnostics: r
	};
	if (s.length > a) return i(`Carried component definitions exceed the ${a}-entry budget.`), {
		definitions: [],
		diagnostics: r
	};
	let l = n(s);
	if (!Number.isFinite(l) || l > o) return i(`Carried component definitions exceed the ${o}-byte budget.`), {
		definitions: [],
		diagnostics: r
	};
	let u = [];
	for (let e = 0; e < s.length; e += 1) try {
		u.push(t(s[e]));
	} catch (t) {
		i(`Carried component definition ${e} is invalid: ${t instanceof Error ? t.message : String(t)}`);
	}
	return {
		definitions: u,
		diagnostics: r
	};
}
function f(e) {
	let t = /* @__PURE__ */ new Map(), n = e.extensions;
	if (!l(n) || n.protocol !== "reactive-md-extensions/v1" || !Array.isArray(n.components) || n.components.length > 64) return t;
	for (let e of n.components) {
		if (!l(e)) continue;
		let { id: n, name: r, version: i, digest: a } = e;
		typeof n == "string" && typeof r == "string" && typeof i == "string" && typeof a == "string" && t.set(r, {
			id: n,
			name: r,
			version: i,
			digest: a
		});
	}
	return t;
}
function p(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	if (!Array.isArray(e.nodes)) return n.push(c("local.extension.contract-metadata", "Document nodes must be an array.")), {
		names: t,
		diagnostics: n
	};
	let r = [...e.nodes], i = 0;
	for (; r.length > 0;) {
		let e = r.pop();
		if (e && typeof e == "object") {
			if (i += 1, i > s) {
				n.push(c("local.extension.contract-metadata", "Document component scan exceeded its node budget."));
				break;
			}
			if (e.type === "hostComponent" || e.type === "component") {
				let n = typeof e.name == "string" ? e.name : "";
				n && t.add(n);
			}
			if (Array.isArray(e.children)) for (let t of e.children) r.push(t);
		}
	}
	return {
		names: t,
		diagnostics: n
	};
}
function m(t) {
	let n = [], r = (e) => n.push(c("local.extension.contract", e));
	try {
		let { document: i, installed: a } = t, o = d(i);
		n.push(...o.diagnostics);
		let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map();
		for (let e of a) s.set(e.id, e), c.set(e.name, e);
		let l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map();
		for (let t of o.definitions) {
			if (l.has(t.id) || u.has(t.name)) {
				r(`Carried component definition ${t.id} is declared more than once.`);
				continue;
			}
			l.set(t.id, t), u.set(t.name, t);
			let n = s.get(t.id) ?? c.get(t.name);
			n ? (n.id !== t.id || n.name !== t.name || n.version !== t.version || e(n) !== e(t)) && r(`Carried component ${t.id}@${t.version} does not match the installed component contract.`) : r(`Carried component ${t.id}@${t.version} is not installed in this host.`);
		}
		let m = t.externalNames ?? /* @__PURE__ */ new Set();
		if (m.size > 0) {
			let t = p(i);
			n.push(...t.diagnostics);
			let a = f(i);
			for (let n of t.names) {
				if (!m.has(n)) continue;
				let t = c.get(n);
				if (!t) {
					r(`Component <${n}> is used but no matching installed component contract exists.`);
					continue;
				}
				let i = a.get(n);
				i ? (i.id !== t.id || i.version !== t.version || i.digest !== e(t)) && r(`Component <${n}> requirement does not match the installed ${t.id}@${t.version}.`) : r(`Component <${n}> is used but the document has no extension requirement for ${t.id}@${t.version}.`);
			}
		}
	} catch (e) {
		r(e instanceof Error ? e.message : String(e));
	}
	return n;
}
// src/export/resources.ts
function h(e) {
	return i(e);
}
function g(e) {
	let t = [], n = (e, n) => t.push({
		code: e,
		message: n,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}), r = /* @__PURE__ */ new Map();
	if (!Array.isArray(e) || e.length > 256) return n("local.extension.resource-budget", "Styles must be a bounded resource array."), {
		resources: [],
		diagnostics: t
	};
	let i = 0;
	for (let t of e) {
		if (!t || typeof t != "object" || typeof t.id != "string" || !t.id || t.id.length > 256 || /[\u0000-\u001f]/.test(t.id) || typeof t.css != "string" || !h(t.css)) {
			n("local.extension.resource-invalid", "Export styles must be identified inline CSS without network resources.");
			continue;
		}
		if (t.css.length > 4194304) {
			n("local.extension.resource-budget", "A style resource exceeds the 4 MiB budget.");
			break;
		}
		let e = r.get(t.id);
		if (e && e.css !== t.css && n("local.extension.resource-conflict", `Style resource ${t.id} has conflicting contents.`), !e) {
			if (i += new TextEncoder().encode(t.css).byteLength, r.size >= 128 || i > 4194304) {
				n("local.extension.resource-budget", "Export styles exceed 128 resources or 4 MiB.");
				break;
			}
			r.set(t.id, Object.freeze({
				id: t.id,
				css: t.css
			}));
		}
	}
	return {
		resources: Object.freeze([...r.values()]),
		diagnostics: t
	};
}
export { u as i, c as n, m as r, g as t };
