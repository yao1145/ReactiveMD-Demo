import { _ as e, b as t, g as n, h as r, s as i, t as a, v as o, x as s } from "./layout-BBB2VF0S.js";
import { t as c } from "./plugin-packs-Bh1HhLym.js";
import { t as l } from "./mount-preset-DMZ5wd3t.js";
// src/components/plugins/navigation.ts
var u = {
	tabs: o,
	tab: e,
	steps: n,
	step: r,
	accordion: a,
	disclosure: i,
	tooltip: t,
	validation: s
}, d = c("reactive-md/navigation", Object.keys(u)), f = l(d, u);
export { f as default };
