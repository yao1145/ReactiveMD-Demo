import { c as e, m as t, p as n, w as r } from "./version-DAxuGOG2.js";
import { v as i } from "./document-theme-C8J6UyNO.js";
import { f as a, l as o, u as s } from "./config-validation-D3D7Dy2J.js";
import { t as c } from "./types-daDo2c_w.js";
import { A as l, O as u, P as d } from "./preset-core-DeZPA8IE.js";
import { l as f, o as p } from "./parser-standard-CBA1-hdG.js";
import { i as m, s as h } from "./config-DXLvctiZ.js";
import { r as g } from "./options-BBp9IcHm.js";
import { u as _ } from "./component-state-CwKX_SN5.js";
import { n as v } from "./runtime-BpQdZmFI.js";
import { a as ee, i as y } from "./identity-BUx0Q_-d.js";
import { i as te, t as b } from "./resources-B0x_w3s9.js";
// src/local/runtime/state.ts
var x = "reactive-md-state/v1", S = 1048576, C = /^fnv1a32:[0-9a-f]{8}$/, w = /* @__PURE__ */ new Set([
	"format",
	"syntax",
	"sourceDigest",
	"parameters",
	"generator"
]), ne = /* @__PURE__ */ new Set(["name", "version"]), re = new TextEncoder();
function T(e, t) {
	return {
		code: e,
		message: t.length > 2e3 ? `${i(t, r - 1)}…` : t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function E(e, t, n) {
	e.length < 100 && e.push(T(t, n));
}
function D(e) {
	return e instanceof Error ? e.message : String(e);
}
function O(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function k(e) {
	if (typeof e == "string") return O(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "contains malformed Unicode."
	};
	if (typeof e == "number") return Number.isFinite(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "must be a finite number."
	};
	if (typeof e == "boolean" || e === null) return {
		ok: !0,
		value: e
	};
	if (Array.isArray(e)) {
		let t = [], n = e.length === 0 ? "string" : typeof e[0];
		for (let r = 0; r < e.length; r += 1) {
			let i = e[r];
			if (n === "string" && typeof i == "string") {
				if (!O(i)) return {
					ok: !1,
					message: "contains malformed Unicode."
				};
				t.push(i);
			} else if (n === "number" && typeof i == "number" && Number.isFinite(i)) t.push(i);
			else return {
				ok: !1,
				message: "must be an array of strings or finite numbers of one kind."
			};
		}
		return {
			ok: !0,
			value: Object.freeze(t)
		};
	}
	return {
		ok: !1,
		message: "must be a string, finite number, boolean, null or homogeneous primitive array."
	};
}
function A(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function j(e) {
	return Object.freeze(e.parameters), e.generator && Object.freeze(e.generator), Object.freeze(e);
}
function M(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("generator must be an object with string name and version.");
	if (typeof e.name != "string" || typeof e.version != "string") throw TypeError("generator must have string name and version.");
	if (!O(e.name) || !O(e.version)) throw TypeError("generator name and version must be well-formed Unicode strings.");
	return Object.freeze({
		name: e.name,
		version: e.version
	});
}
function N(e) {
	return typeof e == "string" ? `"${e.length > 48 ? `${i(e, 48)}…` : e}"` : e === null ? "null" : Array.isArray(e) ? "an array" : typeof e;
}
function P(e, t) {
	return e.length > t ? e.length : re.encode(e).byteLength;
}
function ie(e, t) {
	let n;
	try {
		let t = JSON.stringify(e);
		if (typeof t != "string") return null;
		n = t;
	} catch {
		return null;
	}
	return P(n, t);
}
function ae(e) {
	if (e === void 0) return S;
	if (typeof e != "object" || !e) throw TypeError("parseLocalState options must be an object.");
	let { maxLength: t } = e;
	if (t === void 0) return S;
	if (typeof t != "number" || !Number.isSafeInteger(t) || t <= 0) throw RangeError("maxLength must be a finite positive integer.");
	return t;
}
function F(e, t, n) {
	if (!e || e.syntax !== "local" || typeof e.source != "string") throw TypeError("createLocalStateFile requires a compiled local document.");
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("createLocalStateFile requires a state object.");
	let r = Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort(), i = new Set(r), a = /* @__PURE__ */ new Map();
	for (let n of Object.keys(t)) {
		if (Object.hasOwn(e.computations ?? {}, n)) continue;
		if (n.startsWith("@")) {
			if (!Object.hasOwn(e.bindings, n)) throw Error(`Cannot persist parameter "${n}": it is not a binding of this document.`);
			continue;
		}
		if (!i.has(n)) throw Error(`Cannot persist parameter "${n}": it is not a public binding of this document.`);
		let r = k(t[n]);
		if (!r.ok) throw TypeError(`Cannot persist parameter "${n}": the value ${r.message}`);
		a.set(n, r.value);
	}
	let o = {};
	for (let e of r) {
		if (!a.has(e)) throw Error(`Cannot persist the document: parameter "${e}" is missing from the supplied state.`);
		o[e] = a.get(e);
	}
	let s = {
		format: x,
		syntax: c,
		sourceDigest: y(e.source),
		parameters: o
	};
	return n !== void 0 && (s.generator = M(n)), j(s);
}
function oe(e, t) {
	let n = [], r = (e, t) => E(n, e, t), i = e;
	if (typeof e == "string") {
		if (P(e, t) > t) return {
			ok: !1,
			diagnostics: [T("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
		if (!O(e)) return {
			ok: !1,
			diagnostics: [T("local.state.utf", "The state payload contains malformed Unicode.")]
		};
		try {
			i = JSON.parse(e);
		} catch (e) {
			return {
				ok: !1,
				diagnostics: [T("local.state.json", `The state payload is not valid JSON: ${D(e)}`)]
			};
		}
	} else {
		let n = ie(e, t);
		if (n === null) return {
			ok: !1,
			diagnostics: [T("local.state.shape", "The state payload must be a JSON object.")]
		};
		if (n > t) return {
			ok: !1,
			diagnostics: [T("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
	}
	if (!A(i)) return {
		ok: !1,
		diagnostics: [T("local.state.shape", "The state payload must be a JSON object.")]
	};
	Object.getOwnPropertySymbols(i).length > 0 && r("local.state.shape", "The state payload cannot use symbol keys.");
	for (let e of Object.keys(i)) w.has(e) || r("local.state.key", `Unknown top-level state key "${e}".`);
	let a = i.format;
	a !== "reactive-md-state/v1" && r("local.state.format", `Unsupported state format ${N(a)}; expected "${x}".`);
	let o = i.syntax;
	o !== "local-draft-3" && r("local.state.syntax", `Unsupported state syntax ${N(o)}; expected "${c}".`);
	let s = i.sourceDigest;
	typeof s == "string" && C.test(s) || r("local.state.digest", "sourceDigest must match \"fnv1a32:\" followed by 8 lowercase hexadecimal digits.");
	let l = {}, u = i.parameters;
	if (!A(u)) r("local.state.parameters", "parameters must be a JSON object of public binding values.");
	else for (let e of Object.keys(u).sort()) {
		if (e === "__proto__") {
			r("local.state.parameter.prototype", "Parameter names cannot be \"__proto__\".");
			continue;
		}
		if (e.startsWith("@")) {
			r("local.state.parameter.internal", `Internal parameter "${e}" cannot be persisted.`);
			continue;
		}
		let t = k(u[e]);
		t.ok ? l[e] = t.value : r("local.state.parameter.value", `Parameter "${e}" ${t.message}`);
	}
	let d;
	if (Object.hasOwn(i, "generator")) {
		let e = i.generator;
		if (!A(e)) r("local.state.generator", "generator must be an object with string name and version.");
		else {
			for (let t of Object.keys(e)) ne.has(t) || r("local.state.generator", `generator has unknown key "${t}".`);
			typeof e.name != "string" || typeof e.version != "string" ? r("local.state.generator", "generator must have string name and version.") : !O(e.name) || !O(e.version) ? r("local.state.utf", "generator contains malformed Unicode.") : d = Object.freeze({
				name: e.name,
				version: e.version
			});
		}
	}
	if (n.length) return {
		ok: !1,
		diagnostics: n
	};
	let f = {
		format: x,
		syntax: c,
		sourceDigest: s,
		parameters: l
	};
	return d && (f.generator = d), {
		ok: !0,
		file: j(f)
	};
}
function I(e, t) {
	let n = ae(t);
	try {
		return oe(e, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.invalid", `Cannot read the local state: ${D(e)}`)]
		};
	}
}
function se(e) {
	let t = /* @__PURE__ */ new Map(), n = (e) => {
		for (let r of e) t.set(r.id, r), r.children && n(r.children);
	};
	return n(e.nodes), t;
}
function ce(e) {
	let t = se(e), n = /* @__PURE__ */ new Map(), r = [];
	for (let [i, a] of Object.entries(e.bindingSlots ?? {})) {
		let e = t.get(i);
		if (!e) continue;
		let o = {
			node: e,
			slots: []
		};
		for (let [t, r] of Object.entries(a)) o.slots.push({
			slot: t,
			key: r
		}), r.startsWith("@") || n.set(r, {
			node: e,
			slot: t
		});
		o.slots.length && r.push(o);
	}
	let i = [];
	for (let [r, a] of Object.entries(e.bindings)) {
		if (r.startsWith("@")) continue;
		let e = n.get(r);
		if (e) {
			i.push({
				key: r,
				binding: a,
				node: e.node,
				slot: e.slot
			});
			continue;
		}
		let o = a.owner && t.has(a.owner) ? a.owner : a.nodeIds.find((e) => t.has(e));
		i.push({
			key: r,
			binding: a,
			node: o ? t.get(o) : void 0
		});
	}
	return {
		plans: i,
		groups: r
	};
}
function L(e, t, n) {
	let r = [], i = Object.create(null);
	for (let a of t.plans) a.slot === void 0 && Object.hasOwn(n, a.key) && (a.node ? Object.is(e.get(a.node), n[a.key]) || (i[a.key] = n[a.key]) : r.push(T("local.state.document", `The document has no component for parameter "${a.key}".`)));
	if (r.length) return r;
	r.push(...e.setParameters(i));
	for (let i of t.groups) {
		let t = {}, a = !1;
		for (let { slot: e, key: r } of i.slots) Object.hasOwn(n, r) && (t[e] = n[r], a = !0);
		a && r.push(...e.setMany(i.node, t));
	}
	return r;
}
function le(e, t) {
	let n = e.snapshot(), r = {};
	for (let e of t) {
		let t = n.state[e];
		r[e] = Array.isArray(t) ? Object.freeze([...t]) : t;
	}
	return Object.freeze(r);
}
function R(e, t, n, r) {
	let i = I(t, r);
	if (!i.ok) return i;
	if (!e || e.syntax !== "local" || typeof e.source != "string" || !Array.isArray(e.nodes) || !e.bindings) return {
		ok: !1,
		diagnostics: [T("local.state.document", "resolveLocalState requires a compiled local document.")]
	};
	if (i.file.syntax !== "local-draft-3") return {
		ok: !1,
		diagnostics: [T("local.state.syntax", `This state file uses syntax "${i.file.syntax}", but this build accepts "${c}".`)]
	};
	if (i.file.sourceDigest !== y(e.source)) return {
		ok: !1,
		diagnostics: [T("local.state.source", "This state file was created for a different document (source digest mismatch).")]
	};
	let a = ce(e), o = new Set(a.plans.map((e) => e.key)), s = [];
	for (let e of Object.keys(i.file.parameters)) o.has(e) || E(s, "local.state.parameter.unknown", `The state contains unknown parameter "${e}" for this document.`);
	for (let e of o) Object.hasOwn(i.file.parameters, e) || E(s, "local.state.parameter.missing", `The state is missing parameter "${e}".`);
	if (s.length) return {
		ok: !1,
		diagnostics: s
	};
	let l;
	try {
		l = v(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.document", `Cannot validate this document: ${D(e)}`)]
		};
	}
	try {
		if (n) {
			let e = L(l, a, n);
			if (e.length) return {
				ok: !1,
				diagnostics: e
			};
		}
		let e = L(l, a, i.file.parameters);
		if (e.length) return {
			ok: !1,
			diagnostics: e
		};
		let t = [...o].sort();
		return {
			ok: !0,
			file: i.file,
			state: le(l, t)
		};
	} finally {
		l.dispose();
	}
}
function z(e, t, n) {
	try {
		return R(e, t, void 0, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [T("local.state.invalid", `Cannot resolve the local state: ${D(e)}`)]
		};
	}
}
function B(e, t, n) {
	let r;
	try {
		r = R(e.document, t, e.snapshot().state, n);
	} catch (e) {
		return [T("local.state.invalid", `Cannot apply the local state: ${D(e)}`)];
	}
	if (!r.ok) return r.diagnostics;
	let i = ce(e.document);
	try {
		return L(e, i, r.state);
	} catch (e) {
		return [T("local.state.invalid", `Cannot apply the local state: ${D(e)}`)];
	}
}
function ue(e, t) {
	return F(e.document, e.getParameters(), t);
}
function de(e, t, n) {
	let r = I(t, n);
	return r.ok ? B(e, r.file, n) : r.diagnostics;
}
function fe(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("serializeLocalState requires a state file.");
	if (!e.parameters || typeof e.parameters != "object" || Array.isArray(e.parameters)) throw TypeError("serializeLocalState requires an object of parameters.");
	let t = Object.create(null);
	for (let n of Object.keys(e.parameters).sort()) {
		if (n === "__proto__" || n.startsWith("@")) throw TypeError(`Cannot serialize parameter "${n}".`);
		let r = k(e.parameters[n]);
		if (!r.ok) throw TypeError(`Cannot serialize parameter "${n}": the value ${r.message}`);
		t[n] = r.value;
	}
	let n = {
		format: e.format,
		syntax: e.syntax,
		sourceDigest: e.sourceDigest,
		parameters: t
	};
	if (e.generator !== void 0) {
		let t = M(e.generator);
		n.generator = {
			name: t.name,
			version: t.version
		};
	}
	return JSON.stringify(n);
}
// src/local/configuration/portable-options.ts
function V(e) {
	if (e === void 0) return;
	let t = g(e);
	if (!t.ok) throw TypeError(`Invalid portable compile options: ${t.message}`);
	return {
		enableCss: t.html.enableCss,
		enableJavaScript: t.html.enableJavaScript,
		enableExtendedHtml: t.html.enableExtendedHtml,
		...Object.hasOwn(e, "strict") && e.strict !== void 0 ? { strict: t.strict } : {},
		...e.markdownBreaks === void 0 ? {} : { markdownBreaks: t.markdownBreaks },
		...e.config === void 0 ? t.hostComponents.length ? { hostComponents: t.hostComponents } : {} : { config: h(e.config) },
		...e.limits === void 0 ? {} : { limits: {
			...e.limits.maxSyntaxNodes === void 0 ? {} : { maxSyntaxNodes: t.maxSyntaxNodes },
			...e.limits.maxParseWork === void 0 ? {} : { maxParseWork: t.maxParseWork },
			...e.limits.maxMarkdownDepth === void 0 ? {} : { maxMarkdownDepth: t.maxMarkdownDepth }
		} }
	};
}
// src/export/restoration.ts
var pe = d;
function H(e) {
	return d(JSON.stringify([
		e.id,
		e.name,
		e.version,
		e.protocol,
		e.colorSchemes,
		e.css.map(({ id: e, css: t }) => [e, t])
	]));
}
function me(t, n) {
	let r = h(n), i = o(r);
	return Object.freeze({
		protocol: "reactive-md-bundle/v1",
		sdkVersion: e,
		configKey: r.key,
		scriptDigest: d(t),
		assembly: i,
		seal: s(r),
		themes: Object.freeze(r.themes.map((e) => Object.freeze({
			id: e.id,
			name: e.name,
			version: e.version,
			digest: H(e)
		})))
	});
}
function U(t, n, r, i = []) {
	let a = h(n), s = /* @__PURE__ */ new Set(), c = [...t.nodes];
	for (; c.length;) {
		let e = c.pop();
		(e.type === "component" || e.type === "hostComponent") && e.name && s.add(e.name), e.children && c.push(...e.children);
	}
	let l = a.registry.filter((e) => s.has(e.name)).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		range: e.version,
		digest: u(e)
	})).sort((e, t) => e.id.localeCompare(t.id)), f = a.themes.filter((e) => e.name === t.theme).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: H(e)
	}));
	return Object.freeze({
		protocol: "reactive-md-restore/v1",
		sdk: `^${e}`,
		configKey: a.key,
		sourceDigest: d(t.source),
		target: r,
		components: Object.freeze(l),
		themes: Object.freeze(f),
		assembly: o(a),
		resources: Object.freeze(i.map((e) => Object.freeze({
			id: e.id,
			digest: d(e.css)
		})))
	});
}
function W(e) {
	return typeof e == "object" && !!e && !Array.isArray(e) && [Object.prototype, null].includes(Object.getPrototypeOf(e));
}
function G(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 256;
}
function K(r, i) {
	if (r === void 0) return [];
	let o = [], s = (e, t) => o.push({
		code: `local.extension.restore-${e}`,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	});
	try {
		if (!W(r) || l(r) > 262144 || r.protocol !== "reactive-md-restore/v1" || !G(r.sdk) || !G(r.configKey) || !G(r.sourceDigest) || ![
			"static",
			"ssr",
			"offline"
		].includes(r.target) || !Array.isArray(r.components) || r.components.length > 192 || !Array.isArray(r.themes) || r.themes.length > 16 || !Array.isArray(r.resources) || r.resources.length > 128) return s("metadata", "Invalid or oversized restoration requirements."), o;
		let c = /* @__PURE__ */ new Set([
			"protocol",
			"sdk",
			"configKey",
			"sourceDigest",
			"target",
			"components",
			"themes",
			"resources",
			"assembly"
		]);
		Object.keys(r).some((e) => !c.has(e)) && s("metadata", "Unknown restoration requirement field.");
		let f = i.config === void 0 ? m() : h(i.config);
		t(r.sdk) && n("0.7.0", r.sdk) || s("sdk", `SDK ${e} does not satisfy ${r.sdk}.`), a(f, r.configKey) || s("config", "The installed configuration differs from the exported configuration."), r.assembly !== void 0 && (W(r.assembly) && r.assembly.protocol === "reactive-md-assembly-seal/v1" && G(r.assembly.configKey) && a(f, r.assembly.configKey) || s("assembly", "The exported assembly identity is invalid or belongs to another configuration.")), d(i.source) !== r.sourceDigest && s("source", "The source differs from the exported source. Recompile before restoring state.");
		let p = /* @__PURE__ */ new Set();
		for (let e of r.components) {
			if (!W(e) || ![
				"id",
				"name",
				"version",
				"range",
				"digest"
			].every((t) => G(e[t])) || !t(e.range) || p.has(e.id)) {
				s("metadata", "Invalid or duplicate component restoration requirement.");
				continue;
			}
			p.add(e.id);
			let i = f.registry.find((t) => t.id === e.id);
			if (!i) {
				s("component-missing", `Required component ${e.id}@${e.version} is not installed.`);
				continue;
			}
			n(i.version, e.range) || s("version", `Component ${e.id}@${i.version} does not satisfy ${e.range}.`), (i.version !== e.version || i.name !== e.name || u(i) !== e.digest) && s("contract", `Component ${e.id}@${e.version} differs from the installed contract. Recompile and validate state before upgrading.`);
			let a = r.target === "offline" ? [
				"interactive",
				"static",
				"offline"
			] : [r.target];
			for (let t of a) i.capabilities[t] || s("capability", `Component ${e.id} cannot render ${t}.`);
		}
		if (i.document) {
			let e = U(i.document, f, r.target);
			for (let t of e.components) p.has(t.id) || s("component-missing", `Used component ${t.id} is missing from restoration requirements.`);
		}
		p.clear();
		for (let e of r.themes) {
			if (!W(e) || ![
				"id",
				"name",
				"version",
				"digest"
			].every((t) => G(e[t])) || p.has(e.id)) {
				s("metadata", "Invalid or duplicate theme restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = f.themes.find((t) => t.id === e.id);
			t && t.name === e.name && t.version === e.version && H(t) === e.digest || s("theme", `Required theme ${e.id}@${e.version} does not match the installed theme.`);
		}
		if (i.document) {
			let e = f.themes.find((e) => e.name === i.document.theme);
			e && !p.has(e.id) && s("theme", `Selected theme ${e.id} is missing from restoration requirements.`);
		}
		let g = b(i.resources ?? []);
		o.push(...g.diagnostics);
		let _ = new Map(g.resources.map((e) => [e.id, e.css]));
		p.clear();
		for (let e of r.resources) {
			if (!W(e) || !G(e.id) || !G(e.digest) || p.has(e.id)) {
				s("metadata", "Invalid or duplicate style restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = _.get(e.id);
			t === void 0 ? s("resource-missing", `Required style resource ${e.id} is missing before state restoration.`) : d(t) !== e.digest && s("resource-digest", `Style resource ${e.id} differs from the exported content.`);
		}
		if (i.document) {
			let e = U(i.document, f, r.target), t = new Set(e.components.map((e) => e.id)), n = f.registry.filter((e) => t.has(e.id)).flatMap((e) => e.styles ?? []);
			n.push(...f.themes.filter((e) => e.name === i.document.theme).flatMap((e) => e.css.map((e) => e.id)));
			for (let e of n) p.has(e) && _.has(e) || s("resource-missing", `Used style resource ${e} is required before state restoration.`);
		}
	} catch (e) {
		s("metadata", e instanceof Error ? e.message : String(e));
	}
	return o;
}
// src/shareable.ts
var q = "reactive-md-html/v1", J = "reactive-md-html/v2", he = /^[A-Za-z][A-Za-z0-9_-]*$/, ge = /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/, _e = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, ve = /[\u0000-\u001f\u007f-\u009f]/, Y = 64, ye = 41943040, be = 4096;
function X(e, t = !1) {
	let n = e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return t && (n = n.replace(/"/g, "&quot;").replace(/'/g, "&#39;")), n;
}
function xe(e) {
	return e.replace(/<\/style/gi, "<\\/style");
}
function Se(e) {
	return e.replace(/<\/script/gi, "<\\/script").replace(/<!--/g, "<\\!--");
}
function Z(e) {
	return X(e, !0);
}
function Q(e) {
	let t = JSON.stringify(e);
	if (typeof t != "string") throw TypeError("Cannot serialize a non-JSON value for an inline script.");
	return t.replace(/[<>&\u2028\u2029]/g, (e) => {
		switch (e) {
			case "<": return "\\u003c";
			case ">": return "\\u003e";
			case "&": return "\\u0026";
			case "\u2028": return "\\u2028";
			default: return "\\u2029";
		}
	});
}
function $(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function Ce(e) {
	try {
		return V(e);
	} catch (e) {
		throw TypeError(`createShareableHtml received invalid compileOptions: ${e instanceof Error ? e.message : String(e)}`);
	}
}
function we(e, t) {
	let n = t.enableExtendedHtml ? "frame-src about: data: blob:" : "frame-src 'none'", r = e ? "script-src 'unsafe-inline'" + (t.enableJavaScript ? " 'wasm-unsafe-eval'" : "") : "script-src 'none'", i = e && t.enableJavaScript ? "worker-src blob:" : "worker-src 'none'";
	return `default-src 'none'; img-src data:; style-src 'unsafe-inline'; ${r}; font-src data:; ${e ? "connect-src 'none'; media-src 'none'; " : ""}object-src 'none'; ${n}; ${i}; base-uri 'none'; form-action 'none'`;
}
function Te(e, t) {
	if (t.enableCss && t.enableExtendedHtml || !/data-(?:rmd-(?:snapshot|author)-css|extended-html)/i.test(e)) return;
	let n = [...p(e).childNodes];
	for (; n.length;) {
		let e = n.pop();
		if (f.isElementNode(e)) {
			for (let { name: n, value: r } of e.attrs) {
				if (!t.enableCss && (n === "data-rmd-snapshot-css" || e.tagName === "style" && n === "data-rmd-author-css")) throw TypeError("Render staticMarkup with author CSS disabled before exporting with enableCss: false.");
				if (!t.enableExtendedHtml && n === "data-extended-html" && (r === "direct" || r === "sandbox")) throw TypeError("Render staticMarkup with Extended HTML disabled before exporting with enableExtendedHtml: false.");
			}
			for (let t of e.childNodes) n.push(t);
		}
	}
}
function Ee(e) {
	if (e === void 0) return;
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("images must be an object mapping relative URLs to data: image URLs.");
	let t = Object.entries(e);
	if (t.length > Y) throw RangeError(`images cannot contain more than ${Y} entries.`);
	let n = 0;
	for (let [e, r] of t) {
		if (!e || e.length > be || ve.test(e) || e === "__proto__") throw TypeError("Every image key must be a bounded, control-free URL.");
		if (typeof r != "string" || !_e.test(r)) throw TypeError(`The image map for "${e}" must contain a base64 PNG, JPEG, GIF or WebP data URL.`);
		if (n += r.length, n > ye) throw RangeError("The embedded image map exceeds the 40 MiB budget.");
	}
	return Object.fromEntries(t);
}
function De(e, t) {
	let n = z(e, t);
	if (!n.ok) return n;
	let r = {};
	for (let [t, i] of Object.entries(e.bindings)) r[t] = Object.hasOwn(n.state, t) ? {
		...i,
		initial: $(n.state[t])
	} : i;
	let i = { ...e.initialState };
	for (let [e, t] of Object.entries(n.state)) i[e] = $(t);
	return {
		ok: !0,
		baseline: {
			document: {
				...e,
				bindings: r,
				initialState: i
			},
			state: n.state
		}
	};
}
var Oe = "\n:root { color-scheme: light; background: #f5f7fb; }\nhtml, body { margin: 0; }\nbody.reactive-md-export {\n  min-height: 100vh;\n  padding: clamp(16px, 4vw, 48px);\n  background: #f5f7fb;\n  color: #17233d;\n  font-family: system-ui, -apple-system, \"Segoe UI\", sans-serif;\n}\n.reactive-md-export-root { max-width: 840px; margin: 0 auto; }\n@media print {\n  :root, html, body.reactive-md-export { background: #fff !important; }\n  body.reactive-md-export { min-height: 0; padding: 0 !important; }\n  .reactive-md-export-root { max-width: none !important; margin: 0 !important; }\n}\n";
function ke(e) {
	let t = e.targetId ?? "reactive-md-document";
	if (!he.test(t)) throw TypeError("targetId must start with a letter and contain only letters, digits, underscores or hyphens.");
	let n = e.mode === "static" ? "static" : "interactive";
	if (!e.staticMarkup.trim()) throw TypeError("createShareableHtml requires rendered document markup.");
	if (!e.css.trim()) throw TypeError("createShareableHtml requires the document stylesheet.");
	if (e.state.sourceDigest !== y(e.source)) throw Error("The state file does not belong to the exported source.");
	if (n === "interactive" && !e.runtimeScript?.trim()) throw TypeError("Interactive HTML requires the standalone runtime script.");
	let r = Ce(e.compileOptions), i = te(e.extensions, r?.config);
	if (i.push(...K(e.restoration, {
		config: r?.config,
		source: e.source,
		resources: e.resources
	})), i.length) throw TypeError(i.map((e) => e.message).join(" "));
	let a = g(r);
	if (!a.ok) throw TypeError(`createShareableHtml received invalid compileOptions: ${a.message}`);
	Te(e.staticMarkup, a.html);
	let o = e.documentId === void 0 ? void 0 : ee(e.documentId);
	if (e.documentId !== void 0 && o === void 0) throw TypeError("createShareableHtml received an invalid documentId.");
	let s;
	if (e.randomSeed !== void 0) {
		if (!Number.isInteger(e.randomSeed) || e.randomSeed < 0 || e.randomSeed > 4294967295) throw TypeError("createShareableHtml received an invalid randomSeed; expected a 32-bit unsigned integer.");
		s = e.randomSeed;
	}
	let c;
	if (e.componentState !== void 0) {
		let t = _(e.componentState);
		if (!t.ok || t.diagnostics.length > 0) {
			let e = t.diagnostics.map((e) => e.message).join(" ");
			throw TypeError(`createShareableHtml received an invalid component state${e ? `: ${e}` : "."}`);
		}
		c = t.document;
	}
	let l = e.locale === "zh" ? "zh" : "en", u = l === "zh" ? "zh-CN" : "en", d = e.colorScheme === "light" || e.colorScheme === "dark" ? e.colorScheme : "auto", f = e.assets === "omit" ? "omit" : "inline", p = e.generator ?? {
		name: "reactive-md",
		version: "unknown"
	}, m = Ee(e.images), h = Number.isSafeInteger(e.imageCount) && (e.imageCount ?? 0) > 0 ? String(e.imageCount) : String(Object.keys(m ?? {}).length), v = n === "interactive", b = {
		version: e.restoration ? 2 : 1,
		sourceSemantics: "mixed-rmd-v1",
		target: t,
		source: e.source,
		state: e.state,
		locale: l,
		colorScheme: d,
		hydrate: !0,
		compileOptions: {
			...r,
			...a.html
		},
		...e.extensions === void 0 ? {} : { extensions: e.extensions },
		...e.restoration === void 0 ? {} : {
			restoration: e.restoration,
			resources: e.resources ?? []
		},
		...m ? { images: m } : {},
		...o === void 0 ? {} : { documentId: o },
		...s === void 0 ? {} : { randomSeed: s },
		...c === void 0 ? {} : { componentState: c }
	}, x = we(v, a.html), S = v ? `<script type="application/reactive-md+json" data-reactive-md-auto>${Q(b)}<\/script>
<script>${Se(e.runtimeScript)}<\/script>` : "", C = e.notices?.trim() ? `<template id="reactive-md-notices"><pre>${X(e.notices)}</pre></template>` : "", w = !v && e.extensions ? `<template id="reactive-md-extensions">${X(JSON.stringify(e.extensions))}</template>` : "";
	return `<!doctype html>
<html lang="${X(ge.test(u) ? u : "en", !0)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="${Z(x)}">
<meta name="generator" content="${Z(`${p.name} ${p.version}`)}">
<meta name="reactive-md-html-format" content="${e.restoration ? J : q}">
<meta name="reactive-md-syntax" content="${Z(e.state.syntax)}">
<meta name="reactive-md-output" content="${n}">
<meta name="reactive-md-state" content="${Z(e.state.sourceDigest)}">
<meta name="reactive-md-images" content="${f}">
<meta name="reactive-md-image-count" content="${h}">
<title>${X(e.title || "Reactive MD document")}</title>
<style>${xe(e.css)}${Oe}</style>
</head>
<body class="reactive-md-export">
<div id="${t}" class="reactive-md-export-root">${e.staticMarkup}</div>
${S}
${w}
${C}
</body>
</html>
`;
}
export { I as _, Q as a, pe as c, V as d, x as f, de as g, ue as h, De as i, H as l, F as m, J as n, me as o, B as p, ke as r, U as s, q as t, K as u, z as v, fe as y };
