import { t as e } from "./data-table-8-3F15Jf.js";
import { a as t, o as n } from "./visuals-DkDhNdEZ.js";
import { o as r } from "./layout-BBB2VF0S.js";
import { t as i } from "./plugin-packs-Bh1HhLym.js";
import { t as a } from "./mount-preset-DMZ5wd3t.js";
import { t as o } from "./visuals-B5KSafVk.js";
// src/components/plugins/data.ts
var s = {
	column: r,
	"data-table": e,
	table: t,
	timeline: n
}, c = i("reactive-md/data", Object.keys(s)), l = a(c, s, [{
	id: "reactive-md/visuals.css",
	css: o
}]);
export { l as default };
