# ReactiveMD architecture and remaining work

**English** · [中文](README-ch.md)

Updated: 2026-11-07.

Delivered plans are in [archive/](archive/README-en.md). This directory tracks only unfinished work. Some items land in the editor or Demo repositories; ownership is noted inline.

## Partial

### 1. Independent runtime entry and phase split

Landed: `reactive-md/compiler` and `reactive-md/compiler/standard` compile without a session or Worker.

Remaining:

- Add an independent `reactive-md/runtime` entry that hosts can consume without compiling.
- Continue splitting `compiler/source`, `frontend`, `passes` and `emit`; first-party optimizations use the internal service protocol instead of a public plugin surface.

Entry points: [compiler-core.ts](../../src/local/compilation/compiler-core.ts), [runtime.ts](../../src/local/runtime/runtime.ts), [package.json](../../package.json), [verify-compiler-entry.mjs](../../scripts/verify-compiler-entry.mjs).

Done when: the runtime entry can be imported on its own, its import graph has no compiler/parser dependency, the strict corpus still passes through the split reference path, and existing root-entry signatures and default diagnostics are unchanged.

### 2. Optional package boundaries

Remaining:

- Split Lezer, GFM, parse5 and other optional capabilities from the core; remove hidden dependencies on default presets, themes and KaTeX from the core runtime and declarations.
- Expose the configuration identity, driver and language services the editor needs, and continue replacing internal imports with tarball consumption.
- Keep parse5 loading only with the HTML capability. Verify direct ESM imports and production builds, not only tree-shaking configuration.

Done when: core runtime and `.d.ts` have no optional dependencies, the engine and editor build separately, and independent consumers pass the gates in [the archived plan, Section 7.2](archive/near-term-plan-en.md#72-four-final-gates).

### 3. Component runtime services

Landed: identity, seeded randomness, scheduler, component-state protocol, React hooks, the export CLI sidecar, the browser storage backend and the Demo game save/reset UI; Tetris and 2048 background switching and touch have passed real-use verification. See [component runtime services](component-runtime-services-ch.md) (Chinese).

Remaining:

- Add size measurement and accessibility announcements when a shipped component needs them; none does yet.

Done when: state round-trips through exported HTML, and new backends implement the existing protocol without changing compile identity.

## Not started

### 4. Host recovery display and language capability reduction

- The host recovery panel, preview defaults and author check entry consume the same strict mode and source revision; old previews and exports must not masquerade as current results.
- Reduce optional language capabilities through semantic configuration and version them; every meaning-changing capability belongs in the configuration identity.

Done when: mode switches never reuse stale results, completing a closing tag after recovery restores interaction, and capability changes have documented migration behavior.

### 5. Theme semantic tokens and base controls

Start after the engine/host boundaries stabilize. Improve semantic tokens, document scoping, low-priority overrides and exit mechanisms; verify light/dark, keyboard, narrow-screen (390px) and offline behavior; ordinary controls follow the theme.

### 6. Daily authoring tools

Build VS Code support, templates, save and resource import on public language services. Browser and desktop previews and export share semantics. Custom packages load only in trusted project environments.

### 7. Scenario and adoption validation

Validate complete authoring tasks with interactive handouts, parameter estimates and technical notes; collect evidence of repeated use and independent host upgrades.

### 8. Component and theme catalogs

After protocols and public consumption stabilize: maintain a curated catalog, distribute through npm, show verification records by exact version, and isolate third-party previews. The catalog stays out of compile/runtime dependencies.

### 9. 1.0 stabilization and ecosystem

Manage versions separately for packages, authoring syntax, components, themes and state formats. Stabilize public entries and maintain migration notes and historical corpora. Deprecation periods follow real upgrade experience.

### 10. Triggered future work

Cloud sync, multi-user collaboration, an open marketplace, more renderers and AI writing start only when sustained usage requires them. Accessibility, offline assets and extension compatibility checks continue with implementation.

## Working rules

- Keep the consistency and identity rules from archived [Section 5](archive/near-term-plan-en.md#5-sessions-workers-and-state-consistency); verification gates are in archived [Section 7](archive/near-term-plan-en.md#7-verification-and-completion-criteria).
- Mark an item complete only with a commit, test commands, results and dependency/build evidence; then move its plan text to `archive/` and remove it from this page.
