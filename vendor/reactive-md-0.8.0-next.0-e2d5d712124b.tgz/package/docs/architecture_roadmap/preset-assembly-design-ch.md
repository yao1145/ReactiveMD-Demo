# 可组装预设与组件装配设计

状态：Phase 0-4 与 Phase 5 工具链已落地（2026-11-10 更新）；浏览器能力证据与独立 tarball 全流程待补

目标版本：0.9 开发线，配置协议 v2

范围：预设协议、装配与传输、空预设、组件子集、显式替换、React 与资源装配、配置兼容、工具链

本文中的新增类型、入口和选项是拟议接口。npm 包版本、`LOCAL_SDK_VERSION`、预设版本和配置协议分别演进；进入 0.9 开发线不自动把它们都改成 `0.9.0`。

## 1. 结论

内核已经可以在零预设下运行：`createCompiler` 不安装默认组件，`readCompilerConfig(value, defaults = [])` 接受空的默认组件表。当前限制集中在装配入口：

- `src/sdk/config.ts` 的 `buildConfig` 无条件拼接默认预设，`readPresetReferences` 拒绝空数组和外部预设。
- `src/sdk/config.ts` 与 `src/sdk/compiler-config.ts` 都会忽略调用方提供的 registry，重新构造组件表。配置跨 Worker 后依赖这一校验路径。
- 标准编译器、编译选项、schema 和 authoring 仍直接依赖默认组件集合。
- `src/react/sdk.tsx` 的 `createReactConfig` 先注册完整默认 React 预设，再注册外部实现；`createReactHost` 没有预设选择参数。
- `src/sdk/config-validation.ts` 的配置 key 包含预设 id/version 和外部组件摘要，未包含默认预设的语义清单。

本设计开放装配层，保持 Markdown 语法、编译器核心、运行时模型和内核声明（`theme`、`computed`、`const`、`external`）的职责。

装配分为两条路径：纯数据装配生成可重新校验的配置快照；宿主依据快照中的激活结果安装 React 实现和资源。主线程、Worker、SSR 与离线构建共享语义身份，函数和文件系统扫描留在宿主及构建层。

实施顺序为：快照与身份协议、完整兼容链、空预设与宿主装配、预设组合、显式替换、工具链。每阶段同时验证其编译与渲染出口。

## 2. 目标与边界

### 2.1 目标

- 省略 `presets` 保持默认体验；`presets: []` 不安装预设组件，显式组件仍可安装。
- 支持宿主明确提供的预设组合、命名组件包（pack）和细粒度子集。
- 重名默认报错，替换由组件声明与宿主策略共同决定。
- 配置经过 `structuredClone` 或 JSON 传输后，能重新校验并恢复相同的语义身份与 registry。
- React、SSR、authoring、目录发现和离线导出按同一激活结果工作。
- 提供可在独立 tarball 消费者中执行的 init、check、test、build、export 流程。

### 2.2 边界

- 组件替换针对预设与显式组件 manifest。Markdown 段落等内核节点的替换不在本协议中。
- 外部预设由宿主导入。解析器按本次输入中的对象查找依赖，不执行远程安装或加载代码。
- 同一配置中的预设 id 只允许一个版本；替换链在首版中报错。
- 组件代码变化通过构建产物摘要和发布版本追踪。配置 key 标识语义清单，不承担 React 函数内容的哈希职责。
- 本次不引入运行时组件热替换。开发期目录监听继续由 Vite 适配器处理。

## 3. 术语

| 术语 | 含义 |
| --- | --- |
| 语义预设 | 带身份、manifest、依赖及可选 authoring/themes 的纯数据包。 |
| React 预设包 | 将语义预设与宿主安装的 React 实现、资源和 notices 配对的包。 |
| 原始贡献 | 替换前的预设组件与显式组件，保留来源和完整语义定义。 |
| 装配快照 | 规范化、冻结、可传输的完整装配输入。 |
| 激活 registry | 完成替换、名称和依赖校验后的组件清单。 |
| 语义摘要 | 组件 manifest 的稳定摘要，排除 authoring 文案和主题 CSS。 |
| 兼容 profile | SDK 内置的旧协议、旧身份及语义映射规则，用于受支持的迁移。 |

## 4. 预设包协议

新增 `reactive-md-preset/v1`：

```ts
export interface LocalPresetAuthoring {
  readonly componentId: string;
  readonly authoring: LocalComponentAuthoring;
}

export interface LocalPresetPackage {
  readonly protocol: 'reactive-md-preset/v1';
  readonly id: string;
  readonly version: string;
  readonly components: readonly LocalComponentDefinition[];
  readonly authoring?: readonly LocalPresetAuthoring[];
  readonly themes?: readonly LocalThemePackage[];
  readonly dependencies?: readonly LocalPresetReference[];
  readonly metadata?: {
    readonly title?: LocalComponentText;
    readonly description?: LocalComponentText;
  };
}

export function defineLocalPreset(input: LocalPresetPackage): LocalPresetPackage;
```

规则：

- id 和版本沿用 SDK 规则。组件经 `defineLocalComponent` 校验；包、数组及嵌套数据均复制并冻结。
- 包内 id/name 唯一；替换默认组件时，将替换者放在另一个预设或显式组件输入中。
- 预设依赖的 `LocalPresetReference` 使用确切 id/version，并引用本次输入中提供的包。缺失、版本不符和环均报错。
- authoring 条目的 componentId 必须属于本包，且每个 id 最多一项。它覆盖该 manifest 的对应作者数据；替换后的回退规则见第 7 节。
- themes 经主题协议独立校验。authoring、metadata 与主题 CSS 不进入配置 key。
- 分别限制预设数、替换前贡献数、激活组件数、依赖深度与完整快照字节数。派生字段的重复存储也计入序列化预算。

默认预设改为该协议的实例，id/version 从共同的纯数据常量读取。`src/presets/default.ts` 与 `src/sdk/compiler-config.ts` 使用同一身份来源，最小编译入口仍不导入默认预设实现模块。

### 4.1 命名组件包

公开入口 `reactive-md/presets/default/packs` 提供 `controlsPack`、`layoutPack`、`dataPack`、`visualsPack`。它们共享默认 manifest 对象；一个 pack 必须包含自身规则所需的子组件，或明确声明预设依赖。

默认预设保持完整集合。default 与其 pack 同时进入装配会因组件重复而报错。需要更细的子集时，可从公开的 `DEFAULT_COMPONENT_DEFINITIONS` 过滤后调用 `defineLocalPreset`；依赖、父子结构引用和渲染实现仍需通过验收。

`preset.components` 的声明顺序是包的有序载荷，用于保持现有默认 registry 与作者目录顺序。宿主传入的预设列表和显式组件列表按集合处理，具体排序见第 6 节。

## 5. 装配输入与可传输配置

### 5.1 宿主输入

```ts
export type LocalPresetInput = LocalPresetPackage | 'default' | LocalPresetReference;

export interface LocalConfigInput {
  readonly presets?: readonly LocalPresetInput[];
  readonly components?: readonly LocalComponentDefinition[];
  readonly replacements?: 'allow' | 'forbid';
  readonly themes?: readonly LocalThemeInput[];
}
```

- presets 省略时选择默认预设，空数组选择零预设。
- 顶层字符串或引用仅用于内置默认预设；外部预设传完整包对象。依赖引用只在本次完整包集合中解析。
- replacements 默认 `allow`，只应用明确的 `replaces`；`forbid` 拒绝任何替换声明。
- 显式组件与预设组件进入同一个冲突池，不通过输入先后来决定优先级。

### 5.2 装配快照与派生字段

```ts
export interface LocalAssemblySnapshot {
  readonly protocol: 'reactive-md-assembly/v1';
  // 完整规范化包，包含其替换前 manifest、依赖及纯数据元信息。
  readonly presets: readonly LocalPresetPackage[];
  // 显式输入的替换前贡献，包含可能被另一个显式组件替换的基础定义。
  readonly components: readonly LocalComponentDefinition[];
  readonly replacementPolicy: 'allow' | 'forbid';
  // 仅宿主直接提供的主题，包内主题仍留在 presets 中。
  readonly themes: readonly LocalThemePackage[];
}

export interface LocalResolvedPreset {
  readonly id: string;
  readonly version: string;
  readonly digest: string;
}

export interface LocalReplacementRecord {
  readonly id: string;
  readonly name: string;
  readonly fromVersion: string;
  readonly toVersion: string;
  readonly fromDigest: string;
  readonly toDigest: string;
  readonly fromPreset?: string; // 省略表示 external
  readonly toPreset?: string;
}

export interface LocalLegacyConfigKey {
  readonly profile: string;
  readonly key: string;
}

export interface LocalConfig {
  readonly protocol: 'reactive-md-config/v2';
  readonly assembly: LocalAssemblySnapshot;
  readonly key: string;
  readonly presets: readonly LocalResolvedPreset[];
  // 激活且来自显式输入的组件，延续 v1 的 external-only 含义。
  readonly components: readonly LocalComponentDefinition[];
  readonly replacements: readonly LocalReplacementRecord[];
  readonly registry: readonly LocalComponentDefinition[];
  readonly themes: readonly LocalThemePackage[];
  readonly legacyKeys: readonly LocalLegacyConfigKey[];
}
```

`assembly` 是重建语义的输入来源。key、presets 摘要、registry、components、replacements、合并后的 themes 和 legacyKeys 都是派生结果。保留替换前 manifest，才能重新核对被替换版本、兼容性、来源与预设摘要。

`readLocalConfig` 对 v2 做以下处理：

1. 检查整个输入的纯数据形状、协议、危险字段、深度和字节预算。
2. 校验 assembly 中每个完整包、manifest、主题与依赖，不从网络或本地模块补全内容。
3. 用同一个解析器重建所有派生字段；调用方传入的 key、registry、替换记录和 legacyKeys 均不作为依据。
4. 冻结重建结果，并再次检查完整输出预算。

`readCompilerConfig` 使用同一语义解析器，从 assembly 重算预设摘要、激活 registry、替换记录与 key。它不加载主题实现或 React；authoring、metadata 和主题内容在编译器语义投影中省略。完整 SDK 读者负责资源校验。两种读者的语义投影必须一致，不要求其资源字段相同。

SDK 往返必须满足 `readLocalConfig(structuredClone(config))` 与 JSON 往返后得到同一规范化配置；编译器往返必须得到相同 key、语义 registry 与替换记录。缓存仅使用 SDK 已验证并冻结的快照，调用方可变输入不按对象身份直接缓存。

## 6. 解析与排序

```text
resolve(normalizedAssembly):
  1. 建立预设池，检查 id/version、重复选择、缺少依赖和依赖环
  2. 以稳定拓扑顺序收集原始组件贡献，标记 preset:<id> 或 external
  3. 按组件 id 分组，应用唯一替换边，保存基础定义与胜者的身份
  4. 校验激活名称、完整替换契约、requires.kernel 与组件依赖
  5. 按稳定位置构造 registry，投影激活的 external components
  6. 合并 authoring/themes，计算摘要、key、兼容别名并冻结结果
```

每个组件 id 分组的规则：

- 一个无替换声明的贡献直接激活。
- 一个带替换声明的贡献但没有基础目标，报 `replacement-missing-target`。
- 恰好一个基础贡献和一个替换者时，检查第 7 节规则。
- 多个基础贡献、多个替换者或替换链均报错；相同内容不会使重复选择合法。

排序规则：

稳定序列化时，对象键及字符串身份按 Unicode 码元序比较，不依赖系统区域设置；数组按下表及各协议明确的声明顺序处理。

| 数据 | 规则 |
| --- | --- |
| assembly.presets | 按预设 id 排序；保留每个包内部的 components 声明顺序。 |
| assembly.components | 按 id、是否为替换者、version、语义 digest 排序。 |
| 依赖引用、authoring 映射、主题集合 | 分别按 id/componentId 排序，重复先报错。 |
| 预设解析顺序 | 稳定拓扑排序；每次从可解析集合中选择 id 最小者。 |
| registry 基础位置 | 预设拓扑顺序及包内声明顺序，随后是按 id 排序的显式基础组件。 |
| 替换后的 registry | 胜者占用基础目标的位置，不在后续位置重复出现。 |
| key 内的组件、预设与替换边 | 按 id 及完整身份排序后的语义视图。 |
| 诊断 | 按阶段、组件/预设 id、来源身份排序。 |

洗牌宿主的 presets 列表和显式 components 列表，结果必须相同。修改某个包内部的 components 顺序属于修改包载荷，不纳入这项洗牌不变性；其展示顺序允许变化，语义 key 仍按清单内容计算。默认预设保留原来的包内顺序，因此无外部组件、无替换时的 registry 逐项顺序保持兼容。

## 7. 显式替换

### 7.1 声明与唯一性

```ts
export interface LocalComponentReplacement {
  readonly id: string;       // 必须等于本 manifest.id
  readonly version?: string; // 目标版本范围，省略表示任意基础版本
}

export interface LocalComponentDefinition {
  // 现有字段保留。
  readonly replaces?: LocalComponentReplacement;
}
```

替换者与目标必须同 id、同 name，目标版本必须匹配，宿主策略必须允许替换。目标不能带 replaces；每个 id 只能有一个基础贡献和一个替换者。manifest 的字段白名单、规范化视图和 `localComponentDigest` 均包含 replaces。

### 7.2 首版兼容规则

替换用于改变实现和扩展能力。旧的合法文档用法、绑定类型与子结构必须保留。首版采用下表的保守判定，无法证明兼容的改变直接拒绝。

| 项目 | 判定 |
| --- | --- |
| id/name/form | 完全相同。 |
| 已有 props | 所有属性都须保留，不限于 required；去掉 description 后的语义定义相同，包括 kind、required、default、nullable、static/dynamic、enum、范围、pattern 等。 |
| 新增 props | 可新增可选属性；不得新增必填属性。新增属性的默认值不得使原有省略写法变成非法输入。 |
| bindings | 槽名及完整规范化定义相同，包括 kind、family、bind/initial 属性名、初始化、约束与独占/保留策略；首版不增删槽。 |
| structure/children | 旧 children 先规范化为 structure，再要求语义相同，包括父子标签、数量、标签内容和投影约束。 |
| rules/slotRelations/legacyHost | 规范化语义相同。新增语义规则、移除旧规则或放宽关系均不在首版兼容集合中。 |
| capabilities | 装配时覆盖目标声明为 true 的全部能力；check/CI 验证这些能力的实际执行证据。 |
| styles/resources | 选择胜者的资源关联；不为胜者自动追加基础目标的资源依赖。共享资源仍由其他激活组件引用时可以保留。 |
| requires/dependencies | 允许调整，但按胜者的实际要求验证整个激活 registry；新依赖缺失或版本不符时报错。 |
| authoring | 按字段使用胜者数据，缺失字段从目标回退；回退结果不进入语义 key。 |

运行时装配只检查 manifest 能力位。check/CI 按组件 id/version/digest 核对已执行证据，作为包检查与发布门禁；测试代码和宿主文件路径不进入 assembly。

比较已有 prop 与绑定约束时，引用的属性也必须满足上述保留规则。把 slider 的 value 绑定删掉、把 range-slider 的数值槽改成字符串、缩窄已有 enum 或改变已有默认值，均属于不兼容替换。

每个替换记录包含基础与胜者的版本、digest 和来源。它进入配置 key、导出清单及诊断展示。调用方不能仅提交替换记录而省略基础定义。

### 7.3 示例

默认预设包含 `<slider>`。Markdown 段落不在这份组件表中。

```ts
import { createLocalConfig, defineLocalComponent } from 'reactive-md/sdk';
import { defaultPreset } from 'reactive-md/presets/default';

const baseSlider = defaultPreset.components.find(component => component.name === 'slider');
if (!baseSlider) throw new Error('The selected default preset has no slider.');

const sliderPro = defineLocalComponent({
  ...baseSlider,
  version: '1.0.0',
  replaces: { id: baseSlider.id, version: baseSlider.version },
  // 保留原有属性、绑定与结构契约；React 实现可以改变外观。
});

const config = createLocalConfig({ components: [sliderPro] });
```

这段示例装配纯数据。React 宿主还需提供与 sliderPro 身份匹配的实现，见第 9 节。

## 8. 配置身份与兼容

### 8.1 key v2

组件 digest 沿用规范化 manifest，排除 authoring 和属性说明文字。预设 digest 对排序后的组件 id/version/digest 与确切的预设依赖引用计算摘要；metadata、主题 CSS 和包内展示顺序不参与计算。

配置 key 哈希以下稳定视图：

```text
protocol: reactive-md-config/v2
presets:      sorted [{ id, version, digest }]
registry:     sorted [{ id, name, version, digest }]  // 全部激活组件
replacements: sorted [{ id, name, from/toVersion, from/toDigest, from/toPreset }]
```

key 必须使用完整激活 registry，不能只哈希 external components。输入池中的基础 manifest 还会通过预设摘要或替换记录的 fromDigest 影响身份。

改变组件语义、预设依赖或替换边会改变 key；改变 authoring、主题或纯 CSS 内容保持 key。React 实现的可执行产物变化时，语义 key 可以保持；脚本摘要及 seal.scriptDigest 按实际脚本字节重算。

### 8.2 v1 兼容 profile

兼容 profile 作为 SDK 内置、版本化的纯数据规则随发布提供，包含：旧配置协议和 key 序列化算法、旧默认预设确切身份及语义快照、允许映射的目标版本，以及已验证的 SDK/文档/状态协议组合。旧版本身份从 profile 读取，不用当前 `LOCAL_SDK_VERSION` 推测。内置表当前只包含 0.7.0；0.5/0.6 标签早于 v1 配置协议，没有可映射的 v1 产物。

首版只为“完整默认预设、无替换、外部 manifest 可由 v1 表达”的装配生成兼容别名。目标默认组件必须通过 profile 的逐组件语义映射；除明确批准的身份版本映射外，属性、绑定、结构、规则和能力须相符。样式、主题及外部组件还有各自的恢复检查。

`legacyKeys` 由验证后的 assembly 和 SDK 内置 profile 计算。快照提供的同名字段会被重建；改变默认语义、选择 pack、自定义预设或发生替换后，不生成该别名。外部组件按 profile 的原 v1 算法进入旧 key，不通过省略它们来放宽匹配。

v1 配置输入先按对应旧协议校验，再用 profile 补全旧默认语义并迁移为 v2 assembly。v1 中声称的 registry/key 仍不可信。没有对应 profile 或语义映射失败时给出迁移诊断，要求用当前宿主重新编译。

### 8.3 各入口的兼容边界

新增共同的配置兼容判定，返回 `exact`、`legacy(profile)` 或 mismatch。`validateLocalDocumentConfig`、Worker、React/SSR 与 authoring 的文档预检均使用它；旧文档携带的默认组件定义也按同一 profile 做身份映射。外部组件仍需精确契约匹配。

| 输入或产物 | 新运行时的处理 |
| --- | --- |
| v1 配置/Worker 快照 | 校验旧载荷，应用 profile，生成 v2 装配和语义 key；输出不再使用 v1 配置格式。 |
| 旧编译文档 | 配置兼容判定通过后，继续校验携带的组件契约；不凭一个旧 key 跳过语义检查。 |
| 旧 restoration requirements | 核对 profile 允许的 SDK 组合、sourceDigest、组件、主题、资源及状态协议，再恢复或迁移；不能只改 configKey。 |
| 已有离线 HTML | 使用其中自带的旧运行时打开，不需要重写其历史 seal。 |
| 将旧 HTML/bundle 导入新宿主 | 先用原协议校验原脚本摘要、旧配置身份、SDK 和资源记录；迁移源文档/状态后，以新宿主重新编译、构建并生成新 seal。 |
| 新 bundle | seal 的配置 key、SDK 版本与脚本摘要仍须精确匹配，不能通过 legacyKeys 宽松接受另一份脚本。 |

修改点覆盖 `src/export/restoration.ts`、`src/export/index.ts` 的预检、bundle seal、standalone/session 和 Worker 协议；实际实现时清点所有直接比较 configKey 的调用方。解析旧产物只使用结构化元数据或宿主明确提供的原配置，不通过执行、反编译旧脚本补全装配。旧产物缺少足够配置时，可以保留源文档重新编译；状态须单独通过来源与协议校验才能恢复。需要构建但当前环境不能重建时，返回明确的重新构建诊断，不将旧脚本伪装成新 bundle。

兼容 profile 至少保留一个 minor，移除前由历史夹具回归和发布说明确认支持边界。包版本、SDK 版本及 preset 版本的映射在 profile 中分别记录。

## 9. React、资源与各层接线

### 9.1 React 预设包与宿主参数

```ts
export interface LocalReactPresetPackage {
  readonly protocol: 'reactive-md-react-preset/v1';
  readonly preset: LocalPresetPackage;
  readonly components: readonly LocalReactComponent[];
  readonly resources?: readonly LocalStyleResource[];
  readonly notices?: readonly LocalPackageNotice[];
}

export function defineReactPreset(input: LocalReactPresetPackage): LocalReactPresetPackage;

export interface LocalReactHostInput {
  readonly presets?: readonly (LocalReactPresetPackage | 'default')[];
  readonly replacements?: 'allow' | 'forbid';
  // 现有输入继续可用，作为显式组件、资源与主题贡献。
  readonly packages?: readonly LocalReactPackage[];
  readonly components?: readonly LocalReactComponent[];
  readonly themes?: readonly LocalThemePackage[];
  readonly resources?: readonly LocalStyleResource[];
  readonly notices?: readonly LocalPackageNotice[];
}
```

`defineReactPreset` 校验包内语义预设与 React 表的对应关系。默认适配器提供 `defaultReactPresetPackage`，将 defaultPreset 与现有默认 React 实现表配对；现有 `defaultReactPreset` 导出保留兼容适配。

`createReactHost` 的 presets 省略时使用默认 React 预设包；`[]` 使用零预设。packages/components 继续提供显式组件，不能通过它们悄悄恢复默认预设。输出字段保持 host.config、host.reactConfig、host.compileOptions、resources、css、notices。

### 9.2 激活实现与资源选择

1. 先将 React 预设包投影为纯数据输入，连同显式 manifest 生成 LocalConfig。
2. 建立宿主候选实现表，来源与 assembly 中的贡献配对。
3. 只为激活 registry 选择实现，匹配来源、id、name、version 和语义 digest。
4. 默认实现表也是候选来源，不再先无条件注册。目标被替换后只选胜者，基础实现不参与重复实现校验。
5. 每个激活定义恰好对应一个匹配实现。缺失、同身份多实现和契约不符均在预览/SSR/构建前报错。
6. 依据激活身份收集组件资源，再合并宿主显式资源与选定主题资源；notices 按稳定顺序收集，内容相同的同 id 去重，内容冲突报错。

manifest 的 styles 与目录约定附加 CSS 均记录到宿主资源所有权表，关联完整组件身份。共享资源可被多个身份引用；没有激活引用的组件资源不随基础实现自动进入结果。宿主显式资源保持显式，不能通过替换冒用另一组件的资源身份。CSS 内联、预算、路径与内容冲突检查继续使用现有构建协议。

资源按激活 registry 顺序读取各组件的关联列表，列表内保留声明顺序，按资源 id 首次出现去重；随后追加宿主显式资源的声明顺序，再追加按主题 id 排序的主题资源，主题内部 CSS 顺序保持。相同 id 的资源必须内容一致。notices 按包来源身份和 notice id 排序，再做内容一致性去重。

`createReactConfig` 根据已解析的 registry 工作，但这需要改造当前的默认实现注入逻辑。空 registry 产生空实现索引；额外的未激活候选不会执行。SSR、静态和交互导出复用同一实现选择结果。

### 9.3 Vite 目录与手动模式

plugin 入口既可提供现有 LocalReactPackage，也可提供带明确 protocol 的 LocalReactPresetPackage。扫描器先识别预设协议，避免把预设实现数组误当成额外显式组件；默认导出优先、单一命名出口和来源冲突规则继续保留。

目录模式新增 `reactiveMd({ defaultPreset: false })`，表示不加入默认预设。已发现的预设包仍按目录结果安装；该选项与 `createLocalConfig({ presets: [] })` 的参数层级不同。生成器将“默认包（若启用）+ 发现的预设包”明确传给 host.presets，把普通组件包传给 host.packages。

同一份发现结果生成编译快照、React 候选表和资源所有权表。缺少预设依赖时指出入口文件，不扫描或安装其他包。手动 extensions 模式通过 createReactHost 的新参数选择预设，并与目录选项继续互斥。

### 9.4 编译器、schema 与 authoring

- `createStandardCompiler()` 无参保持默认体验；有 config 时以其重算的装配为准，不能再次注入默认组件。
- `createCompiler` 继续提供最小装配；收到自包含 v2 配置时可读取其中的纯数据预设，不加载 React 或 CSS。
- `readLocalCompileOptions`、`readCompilerOptions` 和 `readCompilerConfig` 共用语义解析器；默认包装只发生在输入省略处。
- schema、外部 host 投影和预设组件分类从装配来源与完整 registry 生成，不能继续把 config.components 当作全部非默认组件。
- authoring 从激活 manifest 生成目录，空 registry 返回空目录。预设侧 authoring、manifest 文案与替换回退的优先级在规范化时确定。
- authoring、导出 requirements 和构建 manifest 中扫描组件的路径均改用激活 registry；config.components 仍仅表示激活的显式组件。

### 9.5 主题与导出

预设主题和宿主主题按 id/name 检测冲突，沿用现有 readThemes 的拒绝策略，不按遍历顺序覆盖。主题影响资源清单与主题契约摘要，不进入编译语义 key。

`reactive-md-export.json` 记录激活 registry 的 requirements、预设摘要、替换来源和最终资源。Worker 只携带纯数据；React 函数、notices 的加载入口及资源所有权表留在宿主/构建侧。

基础 `reactive-md/styles.css` 仍由宿主选择导入。它是共享基础样式，不构成安装默认预设或默认 React 实现的依据。空预设的源码编译、React/SSR、authoring 和离线导出都必须独立验收。

## 10. 诊断

装配错误继续使用 `Invalid local SDK config (path): message` 形式并携带可消费的错误码。文档期错误沿用现有诊断系统。

| 错误码 | 含义 |
| --- | --- |
| `local.config.preset-invalid` | 包形状、身份或 manifest 无效。 |
| `local.config.preset-duplicate` / `preset-missing` / `preset-cycle` | 重复选择、缺少确切依赖、依赖环。 |
| `local.config.snapshot-invalid` | 装配快照协议、字段、纯数据或预算无效。 |
| `local.config.component-duplicate` | 组件 id/name 冲突或基础贡献不唯一。 |
| `local.config.replacement-forbidden` / `replacement-missing-target` | 策略禁止替换或目标不存在。 |
| `local.config.replacement-version` / `replacement-ambiguous` / `replacement-chain` | 版本不符、多替换者或链式替换。 |
| `local.config.replacement-shape` / `replacement-binding` / `replacement-rules` | 属性/结构、绑定或语义规则不兼容。 |
| `local.config.replacement-capability` | manifest 声明的能力降级。 |
| `local.check.capability-evidence` | 包检查缺少与 id/version/digest 匹配的能力执行证据。 |
| `local.config.implementation-missing` / `implementation-duplicate` / `implementation-mismatch` | 激活定义没有唯一匹配的宿主实现。 |
| `local.config.resource-conflict` / `resource-missing` | 所有权或内容冲突、必需资源缺失。 |
| `local.config.migration-unsupported` | 无兼容 profile、语义映射不成立或需要重建。 |
| `local.extension.config-mismatch` | 文档与宿主的完整语义配置不兼容。 |

消息提供冲突双方的 id/name/版本、preset 或 external 来源、期望契约和实际差异。构建层再附源文件；Worker 错误不依赖接收端的文件路径。替换失败建议指向具体不兼容字段，不笼统提示覆盖失败。

## 11. 开发与发布工具链

| 能力 | 交付 |
| --- | --- |
| 预设脚手架 | `reactive-md init preset <dir>`，生成纯语义入口、React 配对入口、目录预览、验证及打包脚本。 |
| 组件脚手架 | 保留目录预览，增加 `scripts/build-export.mjs` 与 `npm run export`。 |
| 包检查 | `reactive-md check <package>` 验证快照往返、激活实现、资源、替换契约和导出就绪状态。 |
| 能力证据 | 声明 interactive/offline 时运行浏览器 suite；缺证据返回非零退出。 |
| CI 接线 | 组件、预设脚手架和独立消费者检查写入 package.json 并由 CI 调用。 |
| 文档 lint | lint 面向文档，check 面向包；独立检查 npm 版本、SDK 协议和兼容 profile 的对应关系。 |

从 tarball 安装后，独立目录必须完成 init、typecheck、test、build、export，不使用仓库内别名或兄弟源码。兼容夹具保存由真实旧版本生成的配置、编译文档、恢复元数据和 HTML/bundle，不用新代码模拟所有旧格式。

## 12. 迁移计划

### Phase 0：快照与语义身份

- 定义预设协议、完整 assembly、派生字段语义和共同解析器；收敛默认身份来源。
- 提供 v2 SDK/编译器读者，验证完整输入与预算，重算 registry、预设摘要、替换记录和 key。
- 验收默认预设与显式组件的 clone/JSON/Worker 往返；伪造派生字段不能注入定义。

### Phase 1：兼容入口与历史夹具

- 落实支持的 v1 profile、旧版本身份映射和原 key 算法。
- 将文档、Worker、组件契约、restoration、standalone 和 bundle 校验接入相应迁移路径。
- 验收旧数据可在声明的范围内读取；不兼容语义被拒绝；旧 seal 不被修改后冒用，新导出使用新 seal。
- v2 发布前完成此阶段，不能先切协议再补迁移。

### Phase 2：空预设与完整宿主装配

- 支持 presets 空集，参数化 compiler/options/schema/catalog。
- 改造 createReactConfig 的默认实现注入，扩展 createReactHost 的 presets 参数和实现/资源选择。
- Vite 识别 React 预设包及 defaultPreset 开关。
- 验收零预设、仅显式组件宿主，覆盖浏览器、Worker、SSR、authoring 和离线导出。

### Phase 3：组合、pack 与依赖

- 实现多预设依赖与稳定拓扑解析，发布命名 pack。
- 明确包内顺序与宿主无序列表的不同语义。
- 验收只洗牌宿主列表时 key、registry、资源与诊断顺序一致；默认包内顺序保持兼容。

### Phase 4：显式替换

- 将 replaces 纳入 manifest 协议、语义 digest 和快照重建。
- 实现完整兼容表、唯一胜者、目标位置保持、React 候选选择与资源所有权过滤。
- 验收 slider 等真实组件的替换；缺少实现、绑定变化、可选属性收窄、结构或规则变化全部拒绝。

### Phase 5：工具链与发布

- 完成 init preset、包检查、导出脚本和浏览器证据的 CI 接线。
- 用独立 tarball 消费者跑通目录与手动模式的完整流程。
- 发布说明明确顺序语义、兼容 profile、旧产物处理路径及下线政策。

## 13. 测试矩阵

| 类别 | 必测用例 |
| --- | --- |
| 默认兼容 | 省略 presets 的有效组件、逐组件契约、包内 registry 顺序和渲染行为与现状相同；原 key 由受支持 profile 保留为别名。 |
| 传输 | default、空集、自定义预设、组合及替换的 structuredClone/JSON/真实 Worker 往返；SDK 与编译器语义投影一致；改变被覆盖的基础定义也必须重新校验替换。 |
| 重新校验 | 伪造 key/registry/replacements/legacyKeys 被重算；更改 assembly 的语义改变 key；缺失基础定义、非法包和超预算载荷被拒绝。 |
| 空预设 | 空 React 索引、CommonMark 文档、显式组件、空 authoring、SSR 与离线导出；未知组件诊断正确，基础 CSS 不恢复默认组件。 |
| 组合 | 预设重复/多版本/环/缺依赖；组件依赖与父子结构所需组件完整；pack 与 default 冲突。 |
| 排序 | 洗牌宿主 presets 与显式 components 后输出一致；包内声明顺序变化按包载荷处理；胜者占据目标位置。 |
| 替换契约 | optional prop 删除、enum 缩窄、默认值/动态性变化、bindings 改型、槽关系/结构/rules 改变、能力降级和多个替换者均拒绝。 |
| 实现与资源 | 默认与替换实现不同时注册；胜者缺实现/摘要不符报错；旧资源不被胜者自动继承；共享与宿主资源按所有权保留。 |
| 目录接入 | 复制 React 预设包入口后由 Vite 生成统一 host；defaultPreset 为 false；Worker、编辑器、SSR、离线资源一致。 |
| 配置身份 | 预设/激活 manifest 语义或依赖变化改变 key；authoring/主题变化不改 key；React 可执行产物变化改变脚本摘要。 |
| 历史兼容 | 真实 v1 配置、旧文档、Worker 快照、restoration 元数据和 HTML/bundle；SDK 版本映射、source/主题/资源/状态校验及重建分支。 |
| seal | 修改旧脚本字节、借用旧 key 或改写旧 seal 均拒绝；迁移后的导出使用新脚本和新 seal。 |
| 工具链 | tarball 消费者 init/check/test/build/export 全流程与浏览器证据；能力缺证据返回非零。 |

## 14. 风险与待实测项

- React 预设包装与现有默认 React 表需要避免重复初始化。空集、自定义预设和替换都是发布门禁。
- 按包内顺序保留目录位置，同时规范化宿主列表；代码与测试必须遵循同一排序定义。
- 首版的契约相等规则会拒绝部分实际可兼容的扩展。后续可单独定义放宽判定，不在首版依赖隐式推断。
- assembly 保存基础与胜者，快照会变大。完整输入和派生输出分别测预算，基准覆盖大型预设组合与 Worker 传输。
- 兼容 profile 的有效期、具体旧版本集合与 SDK 映射由发布清单列明；不以 npm 包版本推断协议兼容。

## 15. 验收标准

- 六类入口（SDK、最小/标准编译器、React/SSR、authoring、Vite、导出恢复）按同一 assembly 重建语义。
- 空集、组合、pack、自定义预设、显式组件和替换都具有明确输入、实现与资源来源。
- 同一宿主输入集合得到相同规范结果；默认包内顺序保持，替换不会靠输入先后决定胜者。
- 替换仅改变允许的实现与能力，完整既有属性、绑定和结构契约通过检查。
- 语义 key、脚本摘要与兼容 profile 各自承担确定职责，旧 key 不能绕过脚本完整性校验。
- 已声明支持的历史文档与产物通过实际夹具验收；需要重建时明确返回该要求。
- 从发布 tarball 开始，目录与手动模式的 init/check/test/build/export 可执行，能力证据完整。

## 16. 当前实现状态（2026-11-10）

已落地并经过类型检查、定向测试、库构建、公共包边界和编译器入口隔离验证：

- `reactive-md-preset/v1`、`defineLocalPreset`、共享默认预设身份、语义预设与主题校验拆分。
- `reactive-md-config/v2` 的 assembly 快照往返、派生字段重算、v1 默认 profile 的 legacy key 别名。
- 空预设、预设组合与依赖拓扑、命名 pack、显式 slider 替换及兼容性检查。
- React 实现按 manifest 身份选择；未激活候选被忽略；资源按激活 registry、显式资源和主题选择。
- bundle seal 与 restoration requirements 携带 assembly 身份；旧 bundle 缺少 seal 时保留 configKey/scriptDigest 校验路径。
- `createCompiler` 与 `createStandardCompiler` 共用语义解析器；编译器入口不加载主题 CSS 校验。
- Vite 目录发现识别 `LocalReactPresetPackage` 和 `defaultPreset: false` 选项。
- 版本化 v1 兼容 profile；内置表诚实收录已验证的 0.7.0 身份，未验证的历史线不伪造。
- 组件状态 sidecar 的 `configKey` 写入、legacy 匹配、迁移诊断与旧 sidecar 兼容。
- 预设 authoring 覆盖与替换字段回退投影到激活 registry，且不改变语义 key。
- `init preset`、`reactive-md check`、脚手架导出脚本、CI 接线和文档版本同步检查。

尚未完成：

- `reactive-md check` 的浏览器能力证据：interactive/offline 声明仍需真实浏览器 suite，当前只做静态与 SDK 校验。
- 独立 tarball 消费者的目录与手动模式完整 init/check/test/build/export 流程。
- 0.7.0 之后的新历史版本在产生 v1 产物后再加入兼容 profile。
- 参数状态目前没有独立持久化 sidecar；已有 restoration requirements 的 configKey 校验，新的参数 sidecar 按实际需求再补。

