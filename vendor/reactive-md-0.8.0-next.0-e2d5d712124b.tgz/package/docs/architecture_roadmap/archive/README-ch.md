# 架构方案归档

**中文** · [English](README-en.md)

归档日期：2026-11-07。

本目录保存已交付的规划文档。[当前路线图](../README-ch.md)只列出仍未完成的工作。

## 文档

| 文档 | 状态 | 内容 |
| --- | --- | --- |
| [near-term-plan-ch.md](near-term-plan-ch.md) | 已交付 | 编译内核、宽松恢复与三仓库拆分；任务 1–3 与阶段 M0–M6。 |
| [compiler-kernel-modularization-ch.md](compiler-kernel-modularization-ch.md) | 已合并 | 编译内核方案的旧路径，已并入近期规划。 |

## 已交付内容

| 项目 | 证据 |
| --- | --- |
| 独立单次编译入口 | `reactive-md/compiler` 与 `reactive-md/compiler/standard`；任务 1 提交 `8540086`；独立 tarball 消费与编译入口边界检查 |
| `strict` 与局部恢复 | 公开 `strict` 默认 true；RMD 文本降级与局部 HTML 修复贯通会话、Worker、补丁、作者分析与导出；任务 2 提交 `eeea87e` |
| 三仓库拆分 | 引擎 `ReactiveMD`、编辑器 `ReactiveMD-Editor`、Demo `ReactiveMD-Demo`；候选版本 0.8.0-next.0、0.1.0-next.0 与 0.1.0；使用 tarball 和锁文件消费；未发布、未部署 |
| 组件运行时服务核心 | `src/runtime-services` 的身份、种子随机、调度器与组件状态协议；`src/react/runtime` 钩子；Tetris 迁移到 `useTicker`，2048 迁移到 `useSwipe` |

## 未包含的工作

- 独立 runtime 入口，以及 `source` / `frontend` / `passes` / `emit` 的进一步阶段拆分（M1 遗留）。
- Lezer、GFM、parse5 等可选能力的完全拆分（M4 遗留）。
- 宿主恢复展示与语言能力精简，明确不在本轮范围内。
- 组件运行时服务的后续事项，现由当前路线图跟踪。

上述事项列在[当前路线图](../README-ch.md)。归档文本中的 commit、测试与产物记录只证明已交付范围，不代表后续工作已经完成。
