# Archived architecture plans

**English** · [中文](README-ch.md)

Archived: 2026-11-07.

This folder keeps delivered planning documents. The [active roadmap](../README-en.md) lists only work that is still open.

## Documents

| Document | Status | Contents |
| --- | --- | --- |
| [near-term-plan-en.md](near-term-plan-en.md) | Delivered | Compiler kernel, strict/local recovery and the three-repository split; tasks 1–3 and phases M0–M6. |
| [compiler-kernel-modularization-en.md](compiler-kernel-modularization-en.md) | Merged | Old path for the compiler kernel proposal, folded into the near-term plan. |

## Delivered work

| Item | Evidence |
| --- | --- |
| Standalone one-shot compilation entry | `reactive-md/compiler` and `reactive-md/compiler/standard`; task 1 commit `8540086`; independent tarball consumption and compiler-entry boundary check |
| `strict` and local recovery | Public `strict` defaulting to true; RMD literal fallback and local HTML repair through session, Worker, patches, authoring analysis and export; task 2 commit `eeea87e` |
| Three-repository split | Engine `ReactiveMD`, editor `ReactiveMD-Editor`, Demo `ReactiveMD-Demo`; candidate versions 0.8.0-next.0, 0.1.0-next.0 and 0.1.0; tarball and lockfile consumption; not published or deployed |
| Component runtime services core | `src/runtime-services` identity, seeded randomness, scheduler and component-state protocol; `src/react/runtime` hooks; Tetris migrated to `useTicker`, 2048 to `useSwipe` |

## What the plans did not deliver

- The independent runtime entry and further `source` / `frontend` / `passes` / `emit` phase split (M1 residual).
- Full separation of Lezer, GFM, parse5 and other optional capabilities (M4 residual).
- Host recovery display and language capability reduction, which were explicitly outside this round.
- The component runtime service follow-ups now tracked in the active roadmap.

These items are listed in the [active roadmap](../README-en.md). Historical commit, test and artifact references in the archived text are evidence for the delivered scope, not a statement that later work is complete.
