import { DEFAULT_LOCAL_BUILD_BUDGETS, LocalBuildError, buildLocalStandaloneBundle, collectLocalBuildResources, n as defineLocalTheme, r as LOCAL_REACT_PRESET_PROTOCOL, t as createLocalConfig } from "./reactive-md-build.js";
import { createHash } from "node:crypto";
import { mkdir, readFile, readdir, realpath, stat, writeFile } from "node:fs/promises";
import { basename, dirname, isAbsolute, join, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { existsSync, readFileSync } from "node:fs";
import { build } from "vite";
// src/vite/discovery.ts
var DEFAULT_THEME_DIR = "theme";
var DEFAULT_PLUGIN_DIR = "plugin";
var THEME_STYLESHEET = "theme.css";
var THEME_METADATA = "theme.json";
var COMPONENT_STYLESHEET = "component.css";
/** Entry names are ordered as documented; ambiguity errors list this order. */
var PLUGIN_ENTRIES = Object.freeze([
	"index.ts",
	"index.tsx",
	"index.js",
	"index.jsx",
	"index.mts",
	"index.mjs"
]);
var THEME_METADATA_KEYS = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"colorSchemes"
]);
function compareCodeUnits(left, right) {
	return left < right ? -1 : left > right ? 1 : 0;
}
function sortedUnique(values) {
	return [...new Set(values)].sort(compareCodeUnits);
}
function isInside(parent, child) {
	const path = relative(parent, child);
	return path === "" || !path.startsWith(`..${sep}`) && path !== ".." && !isAbsolute(path);
}
function posixRelative(root, file) {
	return relative(root, file).split(sep).join("/");
}
function messageOf$1(error) {
	return error instanceof Error ? error.message : String(error);
}
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
/** Canonical project root; a missing root keeps its normalized lexical path. */
async function canonicalRoot(root) {
	if (typeof root !== "string" || root.length === 0) throw new TypeError("discoverDirectories requires a project root path.");
	const normalized = resolve(root);
	try {
		return await realpath(normalized);
	} catch {
		return normalized;
	}
}
async function resolveScanDirectory(root, value, fallback, label) {
	const candidate = value ?? fallback;
	if (typeof candidate !== "string" || candidate.trim().length === 0) throw new TypeError(`${label} must be a non-empty directory path.`);
	const directory = resolve(root, candidate);
	if (!isInside(root, directory)) throw new Error(`${label} "${candidate}" resolves outside the project root.`);
	let real;
	try {
		real = await realpath(directory);
	} catch {
		return directory;
	}
	if (!isInside(root, real)) throw new Error(`${label} "${candidate}" resolves outside the project root through a symbolic link.`);
	return real;
}
/** Immediate child directories only. Missing roots scan as empty. */
async function childDirectories(directory) {
	let entries;
	try {
		entries = await readdir(directory, { withFileTypes: true });
	} catch (error) {
		const code = error.code;
		if (code === "ENOENT" || code === "ENOTDIR") return [];
		throw new Error(`Cannot scan ${directory}: ${messageOf$1(error)}`);
	}
	return entries.filter((entry) => entry.isDirectory()).map((entry) => join(directory, entry.name)).sort(compareCodeUnits);
}
async function isFile(file) {
	try {
		return (await stat(file)).isFile();
	} catch {
		return false;
	}
}
/** Read optional theme metadata under the shared file budget. */
async function readThemeMetadata(file) {
	let info;
	try {
		info = await stat(file);
	} catch (error) {
		const code = error.code;
		if (code === "ENOENT" || code === "ENOTDIR") return null;
		throw new Error(`Theme metadata ${file} is not readable: ${messageOf$1(error)}`);
	}
	if (!info.isFile()) return null;
	if (info.size > DEFAULT_LOCAL_BUILD_BUDGETS.maxFileBytes) throw new Error(`Theme metadata ${file} exceeds the ${DEFAULT_LOCAL_BUILD_BUDGETS.maxFileBytes}-byte budget.`);
	let text;
	try {
		text = await readFile(file, "utf8");
	} catch (error) {
		throw new Error(`Theme metadata ${file} is not readable: ${messageOf$1(error)}`);
	}
	let value;
	try {
		value = JSON.parse(text);
	} catch (error) {
		throw new Error(`Invalid theme metadata ${file}: ${messageOf$1(error)}`);
	}
	if (!isRecord(value)) throw new Error(`Invalid theme metadata ${file}: must be a JSON object.`);
	for (const key of Object.keys(value)) if (!THEME_METADATA_KEYS.has(key)) throw new Error(`Invalid theme metadata ${file}: unsupported key "${key}".`);
	return value;
}
function summarizeDiagnostics(collected) {
	return collected.diagnostics.map((item) => `[${item.code}] ${item.message}`).join("\n");
}
/** Inline one stylesheet through the shared collector; errors name the file. */
async function inlineStylesheet(file, id, root, config, budgets) {
	const declared = Object.freeze([Object.freeze({
		id,
		path: posixRelative(root, file)
	})]);
	const collected = await collectLocalBuildResources({
		config,
		declared,
		root,
		allowlist: Object.freeze([root]),
		budgets
	});
	if (collected.diagnostics.length > 0) throw new Error(`Cannot inline ${file}:\n${summarizeDiagnostics(collected)}`);
	const resource = collected.resources.find((item) => item.id === id);
	if (!resource) throw new Error(`Cannot inline ${file}: the stylesheet was not collected.`);
	return {
		css: resource.css,
		assets: collected.assets
	};
}
function metadataField(metadata, key) {
	return metadata !== null && Object.hasOwn(metadata, key) ? metadata[key] : void 0;
}
function buildThemeInput(folder, resourceId, css, metadata) {
	const id = metadataField(metadata, "id");
	const name = metadataField(metadata, "name");
	const version = metadataField(metadata, "version");
	const protocol = metadataField(metadata, "protocol");
	const colorSchemes = metadataField(metadata, "colorSchemes");
	return {
		id: id === void 0 ? `local/theme/${folder}` : id,
		name: name === void 0 ? folder : name,
		version: version === void 0 ? "0.0.0" : version,
		...protocol === void 0 ? {} : { protocol },
		...colorSchemes === void 0 ? {} : { colorSchemes },
		css: [{
			id: resourceId,
			css
		}]
	};
}
function mergeAsset(assets, asset) {
	const previous = assets.get(asset.path);
	if (previous !== void 0) {
		if (previous.digest !== asset.digest || previous.bytes !== asset.bytes || previous.mime !== asset.mime) throw new Error(`Resource ${asset.path} was read with conflicting contents.`);
		return;
	}
	assets.set(asset.path, asset);
}
/**
* Discover themes and plugins beneath a project root. Results and every nested
* package/resource are frozen, sorted by path, and independent of the current
* working directory. Missing roots produce empty results, but their normalized
* paths remain in `directories` so a watcher can observe later creation.
*/
async function discoverDirectories(root, options = {}) {
	const projectRoot = await canonicalRoot(root);
	const themeRoot = await resolveScanDirectory(projectRoot, options.themeDir, DEFAULT_THEME_DIR, "themeDir");
	const pluginRoot = await resolveScanDirectory(projectRoot, options.pluginDir, DEFAULT_PLUGIN_DIR, "pluginDir");
	const budgets = DEFAULT_LOCAL_BUILD_BUDGETS;
	const config = createLocalConfig();
	const files = /* @__PURE__ */ new Set();
	const directories = /* @__PURE__ */ new Set([themeRoot, pluginRoot]);
	const assets = /* @__PURE__ */ new Map();
	const themes = [];
	const plugins = [];
	const themeSources = /* @__PURE__ */ new Map();
	async function recordAssets(collectedAssets) {
		for (const asset of collectedAssets) {
			mergeAsset(assets, asset);
			files.add(resolve(projectRoot, asset.path));
		}
	}
	const themeDirectories = await childDirectories(themeRoot);
	for (const directory of themeDirectories) directories.add(directory);
	for (const directory of themeDirectories) {
		const stylesheet = join(directory, THEME_STYLESHEET);
		if (!await isFile(stylesheet)) continue;
		const folder = basename(directory);
		const resourceId = `directory-theme/${folder}.css`;
		const inlined = await inlineStylesheet(stylesheet, resourceId, projectRoot, config, budgets);
		files.add(stylesheet);
		await recordAssets(inlined.assets);
		const metadataFile = join(directory, THEME_METADATA);
		const metadata = await readThemeMetadata(metadataFile);
		files.add(metadataFile);
		let theme;
		try {
			theme = defineLocalTheme(buildThemeInput(folder, resourceId, inlined.css, metadata));
		} catch (error) {
			throw new Error(`Invalid theme ${metadata === null ? stylesheet : metadataFile}: ${messageOf$1(error)}`);
		}
		themes.push(Object.freeze({
			file: stylesheet,
			theme
		}));
		themeSources.set(stylesheet, metadata === null ? stylesheet : metadataFile);
	}
	themes.sort((left, right) => compareCodeUnits(left.file, right.file));
	const names = /* @__PURE__ */ new Map();
	const ids = /* @__PURE__ */ new Map();
	for (const discovered of themes) {
		const source = themeSources.get(discovered.file) ?? discovered.file;
		const previousName = names.get(discovered.theme.name);
		if (previousName !== void 0) throw new Error(`Theme name "${discovered.theme.name}" is declared by both ${previousName} and ${source}.`);
		names.set(discovered.theme.name, source);
		const previousId = ids.get(discovered.theme.id);
		if (previousId !== void 0) throw new Error(`Theme id "${discovered.theme.id}" is declared by both ${previousId} and ${source}.`);
		ids.set(discovered.theme.id, source);
	}
	const pluginDirectories = await childDirectories(pluginRoot);
	for (const directory of pluginDirectories) directories.add(directory);
	for (const directory of pluginDirectories) {
		const entries = [];
		for (const name of PLUGIN_ENTRIES) {
			const candidate = join(directory, name);
			if (await isFile(candidate)) entries.push(candidate);
		}
		if (entries.length === 0) continue;
		if (entries.length > 1) throw new Error(`Plugin directory ${directory} declares more than one entry: ${entries.join(", ")}.`);
		const entry = entries[0];
		const folder = basename(directory);
		files.add(entry);
		const stylesheet = join(directory, COMPONENT_STYLESHEET);
		files.add(stylesheet);
		const resources = [];
		if (await isFile(stylesheet)) {
			const resourceId = `directory-plugin/${folder}.css`;
			const inlined = await inlineStylesheet(stylesheet, resourceId, projectRoot, config, budgets);
			await recordAssets(inlined.assets);
			resources.push(Object.freeze({
				id: resourceId,
				css: inlined.css
			}));
		}
		plugins.push(Object.freeze({
			file: entry,
			resources: Object.freeze(resources)
		}));
	}
	plugins.sort((left, right) => compareCodeUnits(left.file, right.file));
	const sortedAssets = [...assets.values()].sort((left, right) => compareCodeUnits(left.path, right.path));
	return Object.freeze({
		themes: Object.freeze(themes),
		plugins: Object.freeze(plugins),
		files: Object.freeze(sortedUnique(files)),
		directories: Object.freeze(sortedUnique(directories)),
		assets: Object.freeze(sortedAssets)
	});
}
// src/vite/registration.ts
function normalize$1(file) {
	return file.replaceAll("\\", "/");
}
/**
* Resolve the package exported by one `plugin/` entry module and classify it.
*
* A `LocalReactPresetPackage` is recognized by its protocol before ordinary
* package validation, so its implementation array is not mistaken for explicit
* components. An entry that provides both kinds, or a preset-like export with a
* wrong or missing protocol, is an error instead of a guess. The same default
* and single-named-export precedence as {@link readLocalReactPackage} applies.
*
* The protocol is a parameter so the generated registration module can inline
* this function without depending on module scope.
*/
function classifyLocalEntryPackage(namespace, file, presetProtocol) {
	const isRecord = (value) => typeof value === "object" && value !== null && !Array.isArray(value);
	const isComponent = (value) => isRecord(value) && isRecord(value.definition) && typeof value.definition.id === "string" && typeof value.definition.name === "string" && typeof value.render === "function";
	const isPreset = (value) => isRecord(value) && value.protocol === presetProtocol && isRecord(value.preset) && Array.isArray(value.components) && value.components.every(isComponent) && (value.resources === void 0 || Array.isArray(value.resources)) && (value.notices === void 0 || Array.isArray(value.notices));
	const isPackage = (value) => isRecord(value) && Array.isArray(value.components) && value.components.every(isComponent) && (value.resources === void 0 || Array.isArray(value.resources)) && (value.themes === void 0 || Array.isArray(value.themes)) && (value.notices === void 0 || Array.isArray(value.notices));
	if (!isRecord(namespace)) throw new Error(`ReactiveMD package entry ${file} did not provide a module namespace.`);
	const entries = [];
	if (Object.hasOwn(namespace, "default")) entries.push({
		name: "default",
		value: namespace.default
	});
	for (const key of Object.keys(namespace)) if (key !== "default") entries.push({
		name: key,
		value: namespace[key]
	});
	const distinct = [];
	const seen = /* @__PURE__ */ new Set();
	for (const entry of entries) {
		const value = entry.value;
		if (typeof value !== "object" || value === null) continue;
		if (seen.has(value)) continue;
		seen.add(value);
		distinct.push(entry);
	}
	for (const entry of distinct) {
		const value = entry.value;
		if (!isRecord(value)) continue;
		if (!(Object.hasOwn(value, "preset") || Object.hasOwn(value, "protocol") && Array.isArray(value.components)) && value.protocol !== presetProtocol) continue;
		if (value.protocol !== presetProtocol) throw new Error(`ReactiveMD package entry ${file} export "${entry.name}" declares unsupported React preset protocol ${JSON.stringify(value.protocol)}; expected "${presetProtocol}".`);
		if (!isPreset(value)) throw new Error(`ReactiveMD package entry ${file} export "${entry.name}" declares protocol "${presetProtocol}" but is not a valid LocalReactPresetPackage.`);
	}
	const presets = distinct.filter((entry) => isPreset(entry.value));
	const packages = distinct.filter((entry) => !isPreset(entry.value) && isPackage(entry.value));
	if (presets.length > 0 && packages.length > 0) throw new Error(`ReactiveMD package entry ${file} exports both a LocalReactPresetPackage ("${presets[0].name}") and a LocalReactPackage ("${packages[0].name}"); export exactly one package or preset package.`);
	const candidates = presets.length > 0 ? presets : packages;
	const preferred = distinct.find((entry) => entry.name === "default");
	const chosen = preferred !== void 0 && candidates.includes(preferred) ? preferred : candidates.length === 1 ? candidates[0] : void 0;
	if (chosen !== void 0) return presets.length > 0 ? {
		kind: "preset",
		value: chosen.value
	} : {
		kind: "package",
		value: chosen.value
	};
	if (candidates.length > 1) {
		const kind = presets.length > 0 ? "LocalReactPresetPackage" : "LocalReactPackage";
		throw new Error(`ReactiveMD package entry ${file} exports more than one distinct ${kind} (${candidates.map((entry) => entry.name).join(", ")}); export one default package or exactly one distinct named package.`);
	}
	throw new Error(`ReactiveMD package entry ${file} must export a LocalReactPackage or LocalReactPresetPackage as its default export or as exactly one distinct named export.`);
}
/**
* Reject duplicate component identities and theme identities across entries.
*
* The first owner wins the reporting order; a later duplicate names both source
* entries so neither is silently overwritten.
*/
function assertUniqueRegistration(components, themes) {
	const componentIds = /* @__PURE__ */ new Map();
	const componentNames = /* @__PURE__ */ new Map();
	for (const item of components) {
		const priorId = componentIds.get(item.id);
		if (priorId !== void 0) throw new Error(`ReactiveMD component id "${item.id}" is declared by ${priorId} and ${item.file}.`);
		componentIds.set(item.id, item.file);
		const priorName = componentNames.get(item.name);
		if (priorName !== void 0) throw new Error(`ReactiveMD component tag <${item.name}> is declared by ${priorName} and ${item.file}.`);
		componentNames.set(item.name, item.file);
	}
	const themeIds = /* @__PURE__ */ new Map();
	const themeNames = /* @__PURE__ */ new Map();
	for (const item of themes) {
		const priorId = themeIds.get(item.id);
		if (priorId !== void 0) throw new Error(`ReactiveMD theme id "${item.id}" is declared by ${priorId} and ${item.file}.`);
		themeIds.set(item.id, item.file);
		const priorName = themeNames.get(item.name);
		if (priorName !== void 0) throw new Error(`ReactiveMD theme name "${item.name}" is declared by ${priorName} and ${item.file}.`);
		themeNames.set(item.name, item.file);
	}
}
/** Serialize discovery facts without functions or derived config. */
function discoveryMetadata(discovery) {
	return {
		files: Object.freeze(discovery.files.map(normalize$1)),
		directories: Object.freeze(discovery.directories.map(normalize$1)),
		themes: Object.freeze(discovery.themes.map((item) => Object.freeze({
			file: normalize$1(item.file),
			id: item.theme.id,
			name: item.theme.name
		}))),
		plugins: Object.freeze(discovery.plugins.map((item) => Object.freeze({
			file: normalize$1(item.file),
			resources: Object.freeze(item.resources.map((resource) => resource.id))
		}))),
		assets: Object.freeze(discovery.assets.map((asset) => Object.freeze({
			path: asset.path,
			digest: asset.digest,
			bytes: asset.bytes,
			mime: asset.mime
		})))
	};
}
/**
* Generate the single registration module used by every consumer.
*
* Themes are plain data, so the snapshot is embedded directly. Plugin entry
* modules are imported so their packages and implementations stay live under
* the normal Vite dependency graph. Preset entries go to `host.presets`; the
* built-in default is prepended unless `defaultPreset` is false. The generated
* module exports mutable bindings so a theme stylesheet refresh can replace the
* host without rebuilding the document runtime; the SDK host itself stays
* frozen.
*/
function createDirectoryRegistration(discovery, styleId, options = {}) {
	const installDefaultPreset = options.defaultPreset !== false;
	const themes = discovery.themes.map((item) => Object.freeze({
		file: normalize$1(item.file),
		theme: item.theme
	}));
	const plugins = discovery.plugins.map((item) => Object.freeze({
		file: normalize$1(item.file),
		resources: item.resources
	}));
	const imports = plugins.map((item, index) => `import * as __rmdPlugin${index} from ${JSON.stringify(item.file)};`).join("\n");
	const pluginTable = plugins.map((item, index) => `  { file: ${JSON.stringify(item.file)}, namespace: __rmdPlugin${index}, resources: ${JSON.stringify(item.resources)} }`).join(",\n");
	const metadata = discoveryMetadata(discovery);
	const code = `${imports}
import { createReactHost } from "reactive-md/react";

const __rmdClassifyEntry = ${classifyLocalEntryPackage.toString().replace(/^export\s+/, "")};

const __rmdAssertUnique = ${assertUniqueRegistration.toString().replace(/^export\s+/, "")};

const __rmdInstallDefaultPreset = ${JSON.stringify(installDefaultPreset)};
const __rmdPresetProtocol = ${JSON.stringify(LOCAL_REACT_PRESET_PROTOCOL)};
const __rmdThemeEntries = ${JSON.stringify(themes)};
const __rmdPluginEntries = [
${pluginTable}
];
export let discovery = ${JSON.stringify(metadata)};
export const extensions = Object.freeze({});

function __rmdCompose(directoryEntries) {
  const packages = [];
  const presets = __rmdInstallDefaultPreset ? ["default"] : [];
  const components = [];
  const themeOwners = [];
  for (const entry of __rmdPluginEntries) {
    const found = __rmdClassifyEntry(entry.namespace, entry.file, __rmdPresetProtocol);
    if (found.kind === "preset") {
      const preset = found.value;
      presets.push({ ...preset, resources: [...(preset.resources ?? []), ...entry.resources] });
      for (const component of preset.components) {
        const definition = component && component.definition;
        if (!definition || typeof definition.id !== "string" || typeof definition.name !== "string") {
          throw new Error("ReactiveMD preset entry " + entry.file + " contains a component without a manifest id and name.");
        }
        components.push({ file: entry.file, id: definition.id, name: definition.name });
      }
      continue;
    }
    const pkg = found.value;
    const resources = [...(pkg.resources ?? []), ...entry.resources];
    packages.push({ ...pkg, resources });
    for (const component of pkg.components) {
      const definition = component && component.definition;
      if (!definition || typeof definition.id !== "string" || typeof definition.name !== "string") {
        throw new Error("ReactiveMD package entry " + entry.file + " contains a component without a manifest id and name.");
      }
      components.push({ file: entry.file, id: definition.id, name: definition.name });
    }
    for (const theme of pkg.themes ?? []) {
      themeOwners.push({ file: entry.file, id: theme.id, name: theme.name });
    }
  }
  for (const entry of directoryEntries) {
    themeOwners.push({ file: entry.file, id: entry.theme.id, name: entry.theme.name });
  }
  __rmdAssertUnique(components, themeOwners);
  const notices = [];
  for (const entry of __rmdPluginEntries) {
    if (Array.isArray(entry.namespace.notices)) notices.push(...entry.namespace.notices);
  }
  const themes = directoryEntries.map((entry) => entry.theme);
  // Directory styles are host resources; manifests need not reference them.
  const resources = __rmdPluginEntries.flatMap(entry => entry.resources);
  const host = createReactHost({ packages, themes, notices, presets, resources });
  return { host };
}

let __rmdState = __rmdCompose(__rmdThemeEntries);
export let host = __rmdState.host;
export let config = host.config;
export let reactConfig = host.reactConfig;
export let resources = host.resources;
export let css = host.css;
export let notices = host.notices;
let __rmdStyle;
if (typeof document !== "undefined") {
  __rmdStyle = document.createElement("style");
  __rmdStyle.dataset.reactiveMdHost = ${JSON.stringify(styleId)};
  __rmdStyle.textContent = css;
  document.head.append(__rmdStyle);
}
if (import.meta.hot) {
  import.meta.hot.dispose(() => { __rmdStyle?.remove(); });
  import.meta.hot.on("reactive-md:themes", (payload) => {
    if (!payload || !Array.isArray(payload.themes)) return;
    __rmdState = __rmdCompose(payload.themes);
    host = __rmdState.host;
    config = host.config;
    reactConfig = host.reactConfig;
    resources = host.resources;
    css = host.css;
    notices = host.notices;
    if (payload.discovery !== undefined) discovery = payload.discovery;
    if (__rmdStyle) __rmdStyle.textContent = css;
  });
}
`;
	return Object.freeze({
		code,
		files: Object.freeze(discovery.files.map(normalize$1))
	});
}
/**
* Merge scanner assets into the offline build result. Later entries never
* replace a collector asset with the same path; the merged list drives both
* `bundle.assets` and the manifest's `inlinedAssets`.
*/
function mergeDiscoveredAssets(bundle, assets) {
	if (assets.length === 0) return bundle;
	const byPath = new Map(bundle.assets.map((asset) => [asset.path, asset]));
	let added = false;
	for (const asset of assets) {
		const existing = byPath.get(asset.path);
		if (existing) {
			if (existing.digest !== asset.digest || existing.bytes !== asset.bytes || existing.mime !== asset.mime) throw new Error("ReactiveMD asset " + asset.path + " has conflicting contents.");
			continue;
		}
		byPath.set(asset.path, asset);
		added = true;
	}
	if (!added) return bundle;
	const merged = Object.freeze([...byPath.values()].sort((a, b) => a.path < b.path ? -1 : a.path > b.path ? 1 : 0));
	return Object.freeze({
		...bundle,
		assets: merged,
		manifest: Object.freeze({
			...bundle.manifest,
			inlinedAssets: merged
		})
	});
}
/** Theme entries from one snapshot, for the development refresh payload. */
function discoveredThemes(discovery) {
	return Object.freeze(discovery.themes.map((item) => Object.freeze({
		file: normalize$1(item.file),
		theme: item.theme
	})));
}
// src/vite/index.ts
var HOST = "virtual:reactive-md/host";
var BUNDLE = "virtual:reactive-md/bundle";
var REGISTRATION = "virtual:reactive-md/registration";
var RESOLVED = (id) => `\0${id}`;
var PLUGIN_ENTRY = /^index\.(?:ts|tsx|js|jsx|mts|mjs)$/;
var normalize = (file) => file.replaceAll("\\", "/");
var messageOf = (error) => error instanceof Error ? error.message : String(error);
var OPTION_KEYS = /* @__PURE__ */ new Set([
	"extensions",
	"themeDir",
	"pluginDir",
	"defaultPreset"
]);
function readLocalModule(value) {
	if (typeof value !== "string" || !value.trim() || /^[a-z]+:\/\//i.test(value)) throw new TypeError("reactiveMd requires a local extensions module.");
	return value.trim();
}
function readRelativeDirectory(value, key) {
	if (typeof value !== "string" || !value.trim()) throw new TypeError(`reactiveMd ${key} must be a non-empty directory path.`);
	const path = value.trim();
	const normalized = normalize(path);
	if (/^[a-z]+:\/\//i.test(path) || isAbsolute(path) || normalized.startsWith("/") || /^[A-Za-z]:\//.test(normalized) || normalized.split("/").includes("..")) throw new TypeError(`reactiveMd ${key} must be a relative directory inside the Vite root.`);
	return path;
}
/** Directory and manual options cannot be combined; nothing is guessed. */
function readOptions(value) {
	if (value === void 0) return { kind: "directories" };
	if (typeof value !== "object" || value === null || Array.isArray(value)) throw new TypeError("reactiveMd options must be an object.");
	const record = value;
	for (const key of Object.keys(record)) if (!OPTION_KEYS.has(key)) throw new TypeError(`reactiveMd does not accept the "${key}" option.`);
	const hasExtensions = Object.hasOwn(record, "extensions");
	const hasThemeDir = Object.hasOwn(record, "themeDir");
	const hasPluginDir = Object.hasOwn(record, "pluginDir");
	const hasDefaultPreset = Object.hasOwn(record, "defaultPreset");
	if (hasExtensions && (hasThemeDir || hasPluginDir || hasDefaultPreset)) throw new TypeError("reactiveMd options cannot mix \"extensions\" with \"themeDir\", \"pluginDir\" or \"defaultPreset\".");
	if (hasDefaultPreset && typeof record.defaultPreset !== "boolean") throw new TypeError("reactiveMd defaultPreset must be a boolean.");
	if (hasExtensions) return {
		kind: "manual",
		entry: readLocalModule(record.extensions)
	};
	return {
		kind: "directories",
		...hasThemeDir ? { themeDir: readRelativeDirectory(record.themeDir, "themeDir") } : {},
		...hasPluginDir ? { pluginDir: readRelativeDirectory(record.pluginDir, "pluginDir") } : {},
		...hasDefaultPreset ? { defaultPreset: record.defaultPreset } : {}
	};
}
function packageEntries() {
	let directory = dirname(fileURLToPath(import.meta.url));
	for (let depth = 0; depth < 5; depth += 1) {
		try {
			const metadata = JSON.parse(readFileSync(join(directory, "package.json"), "utf8"));
			if (metadata.name === "reactive-md") return Object.entries(metadata.exports).filter(([, value]) => value && typeof value === "object" && "import" in value).map(([name]) => name === "." ? "reactive-md" : `reactive-md/${name.slice(2)}`);
		} catch {}
		directory = dirname(directory);
	}
	throw new Error("Cannot locate the installed reactive-md package exports.");
}
async function buildHost(config, source, watch) {
	const registration = source.registration;
	const nodeBuild = await build({
		root: config.root,
		configFile: false,
		logLevel: "warn",
		publicDir: false,
		ssr: { noExternal: true },
		oxc: { jsx: { development: false } },
		plugins: [{
			name: "reactive-md-node-host",
			resolveId(id) {
				if (id === "virtual:rmd-node-host") return "\0rmd-node-host";
				if (registration && id === REGISTRATION) return RESOLVED(REGISTRATION);
				return null;
			},
			load(id) {
				if (registration && id === RESOLVED(REGISTRATION)) return registration.code;
				if (id !== "\0rmd-node-host") return null;
				const entry = registration ? REGISTRATION : normalize(source.entry ?? "");
				return `import {host} from ${JSON.stringify(entry)};
export const {config,reactConfig,resources,notices}=host;
export const root=${JSON.stringify(config.root)};
export const allowlist=[root];`;
			},
			moduleParsed(info) {
				if (!info.id.startsWith("\0")) watch(normalize(info.id.split("?")[0]));
			}
		}],
		build: {
			write: false,
			ssr: true,
			minify: false,
			rolldownOptions: {
				input: "virtual:rmd-node-host",
				external: [
					/^reactive-md(?:\/|$)/,
					/^react(?:\/|$)/,
					/^react-dom(?:\/|$)/
				],
				output: {
					format: "es",
					codeSplitting: false
				}
			}
		}
	});
	if (Array.isArray(nodeBuild) || !("output" in nodeBuild)) throw new Error("Unexpected ReactiveMD host build output.");
	const chunks = nodeBuild.output.filter((item) => item.type === "chunk");
	if (chunks.length !== 1 || nodeBuild.output.length !== 1) throw new Error("The host must build to one ESM module with inline resources.");
	const code = chunks[0].code;
	const digest = createHash("sha256").update(code).digest("hex");
	const directory = join(config.root, ".reactive-md");
	await mkdir(directory, { recursive: true });
	const hostEntry = join(directory, `host-${digest}.mjs`);
	await writeFile(hostEntry, code);
	try {
		return await buildLocalStandaloneBundle({ entry: hostEntry });
	} catch (error) {
		if (error instanceof LocalBuildError && error.diagnostics.length > 0 && error.diagnostics.every((item) => item.code === "local.extension.export-capability")) return {
			error: error.message,
			diagnostics: error.diagnostics
		};
		throw error;
	}
}
function insidePath(file, directory) {
	return file === directory || file.startsWith(`${directory}/`);
}
/**
* Optional Node-only adapter. Directory mode discovers `theme/` and `plugin/`
* once per snapshot and generates one registration module; manual mode keeps
* the explicit `extensions` entry. Registration and code execution stay
* explicit on the consumer side.
*/
function reactiveMd(options = {}) {
	const mode = readOptions(options);
	const installDefaultPreset = mode.kind === "directories" ? mode.defaultPreset !== false : true;
	let config;
	let manualEntry;
	let themeOption;
	let pluginOption;
	let themeRoot = "";
	let pluginRoot = "";
	let state;
	let knownFiles = /* @__PURE__ */ new Set();
	let generation = 0;
	let inflight;
	let pending;
	const watched = /* @__PURE__ */ new Set();
	if (mode.kind === "directories") {
		themeOption = mode.themeDir;
		pluginOption = mode.pluginDir;
	}
	function invalidateAll() {
		generation += 1;
		state = void 0;
		inflight = void 0;
		pending = void 0;
	}
	async function loadSnapshot() {
		const discovery = await discoverDirectories(config.root, Object.freeze({
			...themeOption === void 0 ? {} : { themeDir: themeOption },
			...pluginOption === void 0 ? {} : { pluginDir: pluginOption }
		}));
		const registration = createDirectoryRegistration(discovery, createHash("sha256").update(config.root).digest("hex").slice(0, 16), { defaultPreset: installDefaultPreset });
		return Object.freeze({
			discovery,
			registration,
			themeRoot: resolve(config.root, themeOption ?? "theme"),
			pluginRoot: resolve(config.root, pluginOption ?? "plugin"),
			files: new Set(discovery.files.map(normalize))
		});
	}
	function snapshot() {
		if (state) return Promise.resolve(state);
		const current = generation;
		if (inflight?.generation === current) return inflight.promise;
		const promise = (async () => {
			const value = await loadSnapshot();
			if (current !== generation) return snapshot();
			state = value;
			knownFiles = value.files;
			return value;
		})();
		const record = {
			generation: current,
			promise
		};
		inflight = record;
		promise.finally(() => {
			if (inflight === record) inflight = void 0;
		}).catch(() => {});
		return promise;
	}
	/** `style` is a theme stylesheet/asset refresh; `structure` needs a reload. */
	function classify(file) {
		if (mode.kind !== "directories") return "none";
		const target = normalize(file);
		const theme = normalize(themeRoot);
		if (insidePath(target, normalize(pluginRoot))) {
			const name = target.slice(target.lastIndexOf("/") + 1);
			if (PLUGIN_ENTRY.test(name) || name === "component.css") return "structure";
			return knownFiles.has(target) ? "structure" : "none";
		}
		if (insidePath(target, theme)) return target.toLowerCase().endsWith(".json") ? "structure" : "style";
		return knownFiles.has(target) ? "structure" : "none";
	}
	function invalidateVirtualModules(server, ids) {
		for (const id of ids) {
			const module = server.moduleGraph.getModuleById(RESOLVED(id));
			if (module) server.moduleGraph.invalidateModule(module);
		}
	}
	function fullReload(server) {
		invalidateAll();
		invalidateVirtualModules(server, [
			HOST,
			REGISTRATION,
			BUNDLE
		]);
		server.ws.send({ type: "full-reload" });
	}
	/**
	* Re-run discovery and push the new theme packages to the page. The document
	* runtime keeps running; only the managed host stylesheet is replaced.
	*/
	async function refreshThemeStyles(server) {
		invalidateAll();
		let current;
		try {
			current = await snapshot();
		} catch (error) {
			server.config.logger.error(`[reactive-md] ${messageOf(error)}`);
			return;
		}
		server.watcher.add([...current.discovery.files]);
		invalidateVirtualModules(server, [
			HOST,
			REGISTRATION,
			BUNDLE
		]);
		server.ws.send({
			type: "custom",
			event: "reactive-md:themes",
			data: {
				themes: discoveredThemes(current.discovery),
				discovery: discoveryMetadata(current.discovery)
			}
		});
		const bundleModule = server.moduleGraph.getModuleById(RESOLVED(BUNDLE));
		if (bundleModule) await server.reloadModule(bundleModule);
	}
	async function bundle() {
		if (pending) return pending;
		const task = (async () => {
			if (mode.kind === "manual") return buildHost(config, { entry: manualEntry }, (file) => watched.add(file));
			const current = await snapshot();
			for (const file of current.discovery.files) watched.add(normalize(file));
			const built = await buildHost(config, { registration: current.registration }, (file) => watched.add(file));
			return "error" in built ? built : mergeDiscoveredAssets(built, current.discovery.assets);
		})();
		pending = task;
		task.catch(() => {
			if (pending === task) pending = void 0;
		});
		return task;
	}
	return {
		name: "reactive-md",
		config() {
			return {
				optimizeDeps: {
					exclude: packageEntries(),
					include: [
						"react",
						"react/jsx-runtime",
						"react/jsx-dev-runtime",
						"react-dom",
						"react-dom/client"
					]
				},
				resolve: { dedupe: ["react", "react-dom"] }
			};
		},
		configResolved(value) {
			config = value;
			if (mode.kind === "manual") {
				manualEntry = resolve(config.root, mode.entry);
				watched.add(normalize(manualEntry));
				return;
			}
			themeRoot = resolve(config.root, themeOption ?? "theme");
			pluginRoot = resolve(config.root, pluginOption ?? "plugin");
		},
		configureServer(server) {
			if (mode.kind !== "directories") return;
			server.watcher.add([themeRoot, pluginRoot]);
			const onDirectory = (directory) => {
				const target = normalize(directory);
				if (!insidePath(target, normalize(themeRoot)) && !insidePath(target, normalize(pluginRoot))) return;
				fullReload(server);
			};
			const onFile = (file) => {
				const kind = classify(file);
				if (kind === "structure" || normalize(file).endsWith("/theme.css") && insidePath(normalize(file), normalize(themeRoot))) fullReload(server);
				else if (kind === "style") refreshThemeStyles(server);
			};
			server.watcher.on("addDir", onDirectory);
			server.watcher.on("unlinkDir", onDirectory);
			server.watcher.on("add", onFile);
			server.watcher.on("unlink", onFile);
			const cleanup = () => {
				server.watcher.off("addDir", onDirectory);
				server.watcher.off("unlinkDir", onDirectory);
				server.watcher.off("add", onFile);
				server.watcher.off("unlink", onFile);
			};
			server.httpServer?.once("close", cleanup);
			snapshot().then((current) => {
				server.watcher.add([...current.discovery.directories, ...current.discovery.files]);
			}).catch(() => {});
		},
		resolveId(id) {
			if (id === HOST || id === BUNDLE) return RESOLVED(id);
			return mode.kind === "directories" && id === REGISTRATION ? RESOLVED(id) : null;
		},
		async load(id) {
			if (id === RESOLVED(HOST)) {
				if (mode.kind === "manual") {
					this.addWatchFile(manualEntry);
					const styleId = createHash("sha256").update(manualEntry).digest("hex").slice(0, 16);
					return `import * as extensions from ${JSON.stringify(normalize(manualEntry))};
const {host}=extensions;
export {host,extensions}; export const {config,reactConfig,resources,css,notices}=host;
export const discovery=undefined;
let style;
if(typeof document!=='undefined'){
 style=document.createElement('style');style.dataset.reactiveMdHost=${JSON.stringify(styleId)};
 style.textContent=host.css;document.head.append(style);
}
if(import.meta.hot)import.meta.hot.dispose(()=>style?.remove());`;
				}
				const current = await snapshot();
				for (const file of current.discovery.files) if (existsSync(file)) this.addWatchFile(normalize(file));
				return `export { host, config, reactConfig, resources, css, notices, discovery, extensions } from ${JSON.stringify(REGISTRATION)};`;
			}
			if (mode.kind === "directories" && id === RESOLVED(REGISTRATION)) {
				const current = await snapshot();
				for (const file of current.discovery.files) if (existsSync(file)) this.addWatchFile(normalize(file));
				return current.registration.code;
			}
			if (id !== RESOLVED(BUNDLE)) return null;
			const built = await bundle();
			for (const file of watched) if (existsSync(file)) this.addWatchFile(normalize(file));
			if (mode.kind === "manual") return `export default ${JSON.stringify(built)};`;
			return `let bundle=${JSON.stringify(built)};
export {bundle as default};
if(import.meta.hot)import.meta.hot.accept(next=>{if(next)bundle=next.default;});`;
		},
		async generateBundle() {
			const built = await bundle();
			if ("error" in built) this.emitFile({
				type: "asset",
				fileName: "reactive-md-export.json",
				source: JSON.stringify(built, null, 2)
			});
			else {
				const { script, ...metadata } = built;
				this.emitFile({
					type: "asset",
					fileName: "reactive-md-standalone.js",
					source: script
				});
				this.emitFile({
					type: "asset",
					fileName: "reactive-md-export.json",
					source: JSON.stringify({
						...metadata,
						scriptFile: "reactive-md-standalone.js"
					}, null, 2)
				});
			}
		},
		watchChange(id) {
			const file = normalize(id);
			if (mode.kind === "directories" && classify(file) !== "none") invalidateAll();
			else if (watched.has(file)) pending = void 0;
		},
		async handleHotUpdate(context) {
			if (mode.kind === "manual") {
				if (!watched.has(normalize(context.file))) return;
				pending = void 0;
				for (const id of [HOST, BUNDLE]) {
					const module = context.server.moduleGraph.getModuleById(RESOLVED(id));
					if (module) context.server.moduleGraph.invalidateModule(module);
				}
				context.server.ws.send({ type: "full-reload" });
				return [];
			}
			const kind = classify(context.file);
			if (kind === "none") return;
			if (kind === "structure") {
				fullReload(context.server);
				return [];
			}
			await refreshThemeStyles(context.server);
			return [];
		}
	};
}
export { reactiveMd as default, reactiveMd };
