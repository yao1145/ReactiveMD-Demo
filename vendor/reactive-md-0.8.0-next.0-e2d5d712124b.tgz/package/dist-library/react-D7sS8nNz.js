import { D as e, N as t, R as n, w as r } from "./identity-MYJXKSkB.js";
import i from "./reactive-md-default-preset.js";
import { h as a, s as o } from "./registry-De2QLL87.js";
import { t as s } from "./resources-haWO_iJb.js";
import { Q as c, i as l, l as u } from "./LocalDocumentView-BOYrrrCQ.js";
// src/react/package.ts
function d(e) {
	let t = s(e);
	if (t.diagnostics.length) throw TypeError(t.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	return t.resources;
}
function f(t) {
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("defineReactPreset requires a preset package object.");
	if (t.protocol !== "reactive-md-react-preset/v1") throw TypeError(`React preset protocol must be "${n}".`);
	let r = a(t.preset);
	if (!Array.isArray(t.components)) throw TypeError("React preset components must be an array.");
	let i = new Map(r.components.map((e) => [e.id, e])), o = /* @__PURE__ */ new Set(), s = [];
	for (let n of t.components) {
		let t = n?.definition;
		if (!t || typeof t.id != "string") throw TypeError("React preset contains a component without a manifest definition.");
		let a = i.get(t.id);
		if (!a) throw TypeError(`React preset "${r.id}" has no semantic component "${t.id}".`);
		if (e(a) !== e(t) || n.digest !== e(t)) throw TypeError(`React preset component "${t.id}" does not match its semantic manifest.`);
		if (o.has(t.id)) throw TypeError(`React preset "${r.id}" declares "${t.id}" more than once.`);
		o.add(t.id), s.push(n);
	}
	let c = r.components.filter((e) => !o.has(e.id)).map((e) => e.id);
	if (c.length > 0) throw TypeError(`React preset "${r.id}" is missing implementations for: ${c.join(", ")}.`);
	let l = t.resources === void 0 ? Object.freeze([]) : d(t.resources);
	return Object.freeze({
		protocol: n,
		preset: r,
		components: Object.freeze(s),
		resources: l,
		...t.notices === void 0 ? {} : { notices: Object.freeze([...t.notices]) }
	});
}
var p = f({
	protocol: n,
	preset: i,
	components: u().components
});
function m(e) {
	let { render: n, renderStatic: i, css: a, resources: o = [], ...s } = e, l = s.styles ?? [...new Set(a === void 0 ? o.map((e) => e.id) : [`${s.id}.css`, ...o.map((e) => e.id)])];
	if (a !== void 0 && l.length === 0) throw TypeError("Inline css requires a style resource identity.");
	let u = r({
		...s,
		protocol: s.protocol === void 0 ? t : s.protocol,
		form: s.form === void 0 ? "leaf" : s.form,
		props: s.props === void 0 ? {} : s.props,
		...l.length ? { styles: l } : {}
	});
	if (a !== void 0 && typeof a != "string") throw TypeError("Component css must be an inline string.");
	let f = d([...a === void 0 ? [] : [{
		id: l[0] ?? `${u.id}.css`,
		css: a
	}], ...o]);
	for (let e of u.styles ?? []) if (!f.some((t) => t.id === e)) throw TypeError(`Component ${u.id} is missing style resource ${e}.`);
	let p = c(u, {
		render: n,
		...i === void 0 ? {} : { renderStatic: i }
	});
	return Object.freeze({
		definition: u,
		components: Object.freeze([p]),
		resources: f
	});
}
function h(e, t, n, r) {
	let i = /* @__PURE__ */ new Map(), a = (e, t) => {
		let n = i.get(e.id);
		if (n !== void 0 && n !== e.css) throw TypeError(`Style resource "${e.id}" has conflicting contents in ${t}.`);
		n === void 0 && i.set(e.id, e.css);
	};
	for (let e of d(t)) a(e, "a component or preset package");
	for (let e of d(n)) a(e, "host resources");
	for (let e of r) for (let t of e.css) a(t, `theme "${e.id}"`);
	let o = [], s = /* @__PURE__ */ new Set();
	for (let t of e.registry) for (let e of t.styles ?? []) {
		if (s.has(e)) continue;
		let n = i.get(e);
		if (n === void 0) throw TypeError(`Component ${t.id} is missing style resource ${e}.`);
		s.add(e), o.push(Object.freeze({
			id: e,
			css: n
		}));
	}
	for (let e of n) {
		if (s.has(e.id)) continue;
		let t = i.get(e.id);
		s.add(e.id), o.push(Object.freeze({
			id: e.id,
			css: t
		}));
	}
	for (let e of r) for (let t of e.css) s.has(t.id) || (s.add(t.id), o.push(Object.freeze({
		id: t.id,
		css: t.css
	})));
	return Object.freeze(o);
}
function g(e = {}) {
	let t = e.presets, n = t === void 0 ? void 0 : t.map((e) => e === "default" ? i : e.preset), r = t === void 0 ? [] : t.flatMap((e) => e === "default" ? [] : e.components), a = t === void 0 ? [] : t.flatMap((e) => e === "default" ? [] : e.resources ?? []), s = e.packages ?? [], c = [...s.flatMap((e) => e.components), ...e.components ?? []], u = o({
		...n === void 0 ? {} : { presets: n },
		components: c.map((e) => e.definition),
		...e.replacements === void 0 ? {} : { replacements: e.replacements },
		themes: [...s.flatMap((e) => e.themes ?? []), ...e.themes ?? []]
	}), d = l(u, { components: [...r, ...c] }), f = h(u, [...a, ...s.flatMap((e) => e.resources ?? [])], e.resources ?? [], u.themes), p = Object.freeze([
		...t === void 0 ? [] : t.flatMap((e) => e === "default" ? [] : e.notices ?? []),
		...s.flatMap((e) => e.notices ?? []),
		...e.notices ?? []
	]);
	return Object.freeze({
		config: d.config,
		reactConfig: d,
		compileOptions: Object.freeze({ config: d.config }),
		resources: f,
		css: f.map((e) => e.css).join("\n"),
		notices: p
	});
}
export { f as i, p as n, m as r, g as t };
