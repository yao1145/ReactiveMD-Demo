import { w as e } from "./validation-W-bmny-x.js";
import { u as t } from "./registry-De2QLL87.js";
import { n } from "./options-D3KYx3nd.js";
import { t as r } from "./compiler-PuPLk1-_.js";
import { t as i } from "./runtime-BXjKrC6W.js";
import { u as a, w as o } from "./component-state-Cq2K5gkS.js";
import { _ as s, d as c, h as l, i as u, u as d } from "./shareable-Dyr3PMh9.js";
import { i as f, t as p } from "./resources-haWO_iJb.js";
import { t as m } from "./LocalDocumentView-BOYrrrCQ.js";
import { jsx as h } from "react/jsx-runtime";
import { createRoot as g, hydrateRoot as _ } from "react-dom/client";
// src/standalone/diagnostics.ts
function v(e, t) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function y(e, t = 8) {
	let n = e.slice(0, t).map((e) => `- [${e.code}] ${e.message} (line ${e.line}, column ${e.column})`);
	return e.length > n.length && n.push(`- ${e.length - n.length} more diagnostic(s).`), n.join("\n");
}
function b(e) {
	return e instanceof Error ? e.message : String(e);
}
var x = class extends Error {
	diagnostics;
	constructor(e, t) {
		let n = y(t);
		super(n ? `${e}\n${n}` : e), this.name = "ReactiveMDMountError", this.diagnostics = t;
	}
};
function S(e, t = "standalone.mount") {
	if (typeof e == "object" && e && Array.isArray(e.diagnostics)) {
		let t = e.diagnostics;
		if (t.length > 0) return t;
	}
	return [v(t, b(e))];
}
// src/standalone/events.ts
var C = "reactive-md-diagnostics", w = "reactive-md-state-change", T = /^[A-Za-z][A-Za-z0-9_-]*$/, E = 256, D = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, O = /[\u0000-\u001f\u007f-\u009f]/, k = 64, A = 4096, j = 41943040;
function M(e, t) {
	if (e === void 0) return;
	if (!P(e)) {
		t("standalone.payload.images", "images must be a JSON object mapping image URLs to data URLs.");
		return;
	}
	let n = Object.entries(e);
	if (n.length > k) {
		t("standalone.payload.images", `images cannot contain more than ${k} entries.`);
		return;
	}
	let r = Object.create(null), i = 0;
	for (let [e, a] of n) if (!e || e.length > A || e === "__proto__" || O.test(e) || typeof a != "string" || !D.test(a)) t("standalone.payload.images", "Every image entry must use a bounded URL key and a base64 raster data URL.");
	else {
		if (i += a.length, i > j) {
			t("standalone.payload.images", "The embedded image map exceeds the 40 MiB budget.");
			return;
		}
		r[e] = a;
	}
	return r;
}
function N(e, t) {
	if (e === void 0) return;
	let r = n(e);
	if (!r.ok) t("standalone.payload.compile-options", `The payload compile options are invalid: ${r.message}`);
	else return c(e);
}
function P(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function F(e, t) {
	if (e === void 0) return;
	let n = o(e);
	if (typeof e != "string" || n !== e) t("standalone.payload.document-id", "The payload documentId must be a canonical 1-256 character string.");
	else return n;
}
function I(e, t) {
	if (e !== void 0) {
		if (typeof e != "number" || !Number.isInteger(e) || e < 0 || e > 4294967295) t("standalone.payload.random-seed", "The payload randomSeed must be a 32-bit unsigned integer.");
		else return e;
	}
}
function L(e, t) {
	if (e === void 0) return;
	let n = a(e);
	if (!n.ok || n.diagnostics.length > 0) {
		let e = n.diagnostics;
		e.length === 0 && t("standalone.payload.component-state", "The payload component state is invalid.");
		for (let n of e) t("standalone.payload.component-state", n.message);
	} else return n.document;
}
function R(e) {
	let t = [], n = (e, n) => {
		t.push(v(e, n));
	};
	if (!P(e)) return {
		ok: !1,
		diagnostics: [v("standalone.payload.shape", "The reactive-md payload must be a JSON object.")]
	};
	e.version !== 1 && e.version !== 2 && n("standalone.payload.version", "The reactive-md payload must use version 1 or 2."), e.version === 2 && e.restoration === void 0 && n("standalone.payload.requirements", "Version 2 requires restoration contracts."), e.version === 1 && (e.restoration !== void 0 || e.resources !== void 0) && n("standalone.payload.version", "Restoration contracts require payload version 2.");
	let r = e.target;
	typeof r != "string" || r.length === 0 || r.length > E ? n("standalone.payload.target", `The payload target must be an element id of 1-${E} characters.`) : T.test(r) || n("standalone.payload.target", "The payload target must start with a letter and use only letters, digits, underscores or hyphens.");
	let i = e.source;
	typeof i != "string" && n("standalone.payload.source", "The payload source must be a string.");
	let a = e.locale === void 0 ? "en" : e.locale;
	a !== "en" && a !== "zh" && n("standalone.payload.locale", "The payload locale must be \"en\" or \"zh\".");
	let o = e.colorScheme === void 0 ? "auto" : e.colorScheme;
	o !== "light" && o !== "dark" && o !== "auto" && n("standalone.payload.color-scheme", "The payload colorScheme must be \"light\", \"dark\" or \"auto\".");
	let s = e.hydrate !== void 0 && e.hydrate;
	typeof s != "boolean" && n("standalone.payload.hydrate", "The payload hydrate flag must be a boolean.");
	let c = e.state;
	P(c) || n("standalone.payload.state", "The payload state must be a JSON object.");
	let l = N(e.compileOptions, n);
	t.push(...f(e.extensions, l?.config));
	let u = p(e.resources ?? []);
	t.push(...u.diagnostics), t.push(...d(e.restoration, {
		config: l?.config,
		source: typeof i == "string" ? i : "",
		resources: u.resources
	}));
	let m = M(e.images, n), h = F(e.documentId, n), g = I(e.randomSeed, n), _ = L(e.componentState, n);
	return t.length > 0 ? {
		ok: !1,
		diagnostics: t
	} : {
		ok: !0,
		payload: {
			version: e.version,
			target: r,
			source: i,
			state: c,
			locale: a,
			colorScheme: o,
			hydrate: s,
			...l === void 0 ? {} : { compileOptions: l },
			...e.extensions === void 0 ? {} : { extensions: e.extensions },
			...e.restoration === void 0 ? {} : {
				restoration: e.restoration,
				resources: u.resources
			},
			...m && Object.keys(m).length > 0 ? { images: m } : {},
			...h === void 0 ? {} : { documentId: h },
			...g === void 0 ? {} : { randomSeed: g },
			..._ === void 0 ? {} : { componentState: _ }
		}
	};
}
function z(e) {
	try {
		return R(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [v("standalone.payload.invalid", `The reactive-md payload could not be read: ${b(e)}`)]
		};
	}
}
// src/standalone/prepare.ts
function B(t, i, a, o, c) {
	if (typeof t != "string") throw new x("Cannot mount a Reactive MD document: source must be a string.", [v("standalone.source", "source must be a string.")]);
	let l = r(t, o), d;
	if (l.ok) d = l.document;
	else {
		let r = n(o);
		if (!r.ok || !r.htmlActive) throw new x("Cannot mount a Reactive MD document: the source contains syntax errors.", l.diagnostics);
		d = {
			syntax: "local",
			syntaxVersion: e,
			source: t,
			html: r.html,
			initialState: {},
			bindings: {},
			nodes: [{
				type: "fallback",
				id: "local-0",
				range: {
					start: 0,
					end: t.length
				},
				value: t
			}]
		};
	}
	if (c?.(d), i !== void 0) {
		let e = s(i);
		if (!e.ok) throw new x("Cannot mount a Reactive MD document: the state payload is invalid.", e.diagnostics);
		let t = u(d, e.file);
		if (!t.ok) throw new x("Cannot mount a Reactive MD document: the state does not match this source.", t.diagnostics);
		d = t.baseline.document;
	}
	return typeof a == "string" && a.trim().length > 0 && (d = {
		...d,
		theme: a.trim(),
		themeRange: void 0
	}), {
		document: d,
		diagnostics: l.diagnostics.slice()
	};
}
var V = Object.freeze({
	name: "reactive-md-standalone",
	version: "0.4.0"
}), H = "data-reactive-md-mounted", U = "script[type=\"application/reactive-md+json\"][data-reactive-md-auto]", W = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, G = 64;
function K(e) {
	if (!e) return {};
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e).slice(0, G)) typeof n == "string" && n.length > 0 && typeof r == "string" && W.test(r) && t.set(n, r);
	return t.size === 0 ? {} : {
		urlPolicy: (e, n) => n === "link" || t.has(e),
		imageResolver: (e) => t.get(e) ?? null
	};
}
var q = /* @__PURE__ */ new WeakSet();
function J(e) {
	return q.has(e) || e.hasAttribute("data-reactive-md-mounted");
}
function Y(e, t) {
	return l(e, t);
}
function X(e) {
	if (e) try {
		e();
	} catch {}
}
function Z(e) {
	let t = () => {
		let t = e.querySelector("article.local-document");
		t && (t.classList.remove("local-static-first", "reactive-md-static-first", "reactive-md-hydrating"), t.removeAttribute("data-static-first"), t.removeAttribute("data-reactive-md-static-first")), e.classList.remove("local-static-first", "reactive-md-static-first"), e.removeAttribute("data-static-first");
	};
	if (typeof requestAnimationFrame != "function") return t(), () => {};
	let n = 0, r = 0;
	return n = requestAnimationFrame(() => {
		t(), r = requestAnimationFrame(t);
	}), () => {
		typeof cancelAnimationFrame == "function" && (cancelAnimationFrame(n), r && cancelAnimationFrame(r));
	};
}
function Q(e, n, r = {}) {
	if (!e || typeof e != "object" || !("nodeType" in e) || !e.hasAttribute) throw new x("Cannot mount a Reactive MD document: element must be an HTMLElement.", [v("standalone.element", "element must be an HTMLElement.")]);
	if (J(e)) throw new x("Cannot mount a Reactive MD document: this element is already mounted.", [v("standalone.mount", "The target element already hosts a Reactive MD document.")]);
	if (!n || typeof n != "object") throw new x("Cannot mount a Reactive MD document: options are required.", [v("standalone.options", "mount requires an options object with a source string.")]);
	let a = n.compileOptions;
	if (n.reactConfig) {
		if (a?.hostComponents !== void 0 || n.themes !== void 0) throw new x("Conflicting extension registration.", [v("local.extension.config", "reactConfig cannot be combined with hostComponents or themes.")]);
		if (a?.config && t(a.config).key !== n.reactConfig.config.key) throw new x("The export configuration differs from the installed bundle.", [v("local.extension.config", "Compile configuration does not match installed implementations.")]);
		a = {
			...a,
			config: n.reactConfig.config
		};
	}
	let o = f(n.extensions, n.reactConfig?.config);
	if (o.length) throw new x("Extension requirements are not satisfied.", o);
	let s = d(n.restoration, {
		config: n.reactConfig?.config ?? a?.config,
		source: n.source,
		resources: n.resources
	});
	if (s.length) throw new x("Restoration requirements are not satisfied.", s);
	let c = p(n.resources ?? []);
	if (c.diagnostics.length) throw new x("Style resources are invalid.", c.diagnostics);
	let l = B(n.source, n.state, r.theme, a, (e) => {
		let t = f(e.extensions, n.reactConfig?.config);
		if (t.push(...d(n.restoration, {
			config: n.reactConfig?.config ?? a?.config,
			source: n.source,
			resources: n.resources,
			document: e
		})), t.length) throw new x("Installed contracts must match before state recovery.", t);
	}), u = f(l.document.extensions, n.reactConfig?.config);
	if (u.length) throw new x("Installed extension implementations are required.", u);
	let y = a?.config, C = y?.key ?? l.document.componentConfigKey, w = y?.legacyKeys.map((e) => e.key) ?? [], T;
	try {
		T = i(l.document, {
			documentId: n.documentId,
			randomSeed: n.randomSeed,
			componentState: n.componentState,
			...C === void 0 ? {} : { configKey: C },
			...w.length === 0 ? {} : { legacyConfigKeys: w }
		});
	} catch (e) {
		throw new x("Cannot mount a Reactive MD document: the interactive runtime could not be created.", [v("standalone.runtime", b(e))]);
	}
	let E = n.generator ?? V, D = K(n.images), O = n.urlPolicy ?? D.urlPolicy, k = n.imageResolver ?? D.imageResolver, A = () => Y(T, E), j;
	try {
		j = A();
	} catch (e) {
		try {
			T.dispose();
		} catch {}
		throw new x("Cannot mount a Reactive MD document: the initial state could not be captured.", [v("standalone.state", b(e))]);
	}
	let M = !1, N = (e) => {
		M || X(r.onDiagnostics ? () => r.onDiagnostics(e) : void 0);
	}, P = (() => {
		try {
			return T.services?.state.diagnostics() ?? [];
		} catch {
			return [];
		}
	})(), F = n.hydrate === !0 && e.hasChildNodes(), I = /* @__PURE__ */ h(m, {
		document: l.document,
		runtime: T,
		onDiagnostics: N,
		urlPolicy: O,
		locale: n.locale ?? "en",
		themes: n.themes,
		reactConfig: n.reactConfig,
		colorScheme: n.colorScheme ?? "auto",
		mode: "interactive",
		staticFirst: F,
		imageResolver: k
	});
	if (!F) for (; e.firstChild;) e.removeChild(e.firstChild);
	let L = null, R = [];
	try {
		for (let t of c.resources) {
			let n = e.ownerDocument.createElement("style");
			n.setAttribute("data-reactive-md-resource", t.id), n.textContent = t.css, (e.ownerDocument.head ?? e.ownerDocument.documentElement).appendChild(n), R.push(n);
		}
		L = F ? _(e, I) : g(e), F || L.render(I);
	} catch (e) {
		R.forEach((e) => e.remove());
		try {
			L?.unmount();
		} catch {}
		try {
			T.dispose();
		} catch {}
		throw new x("Cannot mount a Reactive MD document: React could not render the document.", S(e, "standalone.render"));
	}
	q.add(e), e.setAttribute(H, "");
	let z = r.onStateChange ? T.subscribe(() => {
		if (M) return;
		let e;
		try {
			e = A();
		} catch {
			return;
		}
		X(r.onStateChange ? () => r.onStateChange(e) : void 0);
	}) : () => {};
	X(r.onStateChange ? () => r.onStateChange(j) : void 0), l.diagnostics.length > 0 && N(l.diagnostics), P.length > 0 && N([...P]);
	let U = F ? Z(e) : () => {};
	return {
		element: e,
		getState() {
			if (M) throw Error("This Reactive MD document has been unmounted.");
			return A();
		},
		unmount: () => {
			if (!M) {
				M = !0, z(), U(), R.forEach((e) => e.remove());
				try {
					L?.unmount();
				} catch {}
				try {
					T.dispose();
				} catch {}
				q.delete(e), e.getAttribute("data-reactive-md-mounted") === "" && e.removeAttribute(H);
			}
		}
	};
}
function ee(e, t) {
	return Q(e, t);
}
function $(e, t, n) {
	if (typeof console < "u" && typeof console.error == "function") try {
		console.error(`Reactive MD: ${n.map((e) => `[${e.code}] ${e.message}`).join(" ")}`);
	} catch {}
	let r = e.defaultView?.CustomEvent;
	if (typeof r == "function") try {
		t.dispatchEvent(new r(C, {
			detail: n,
			bubbles: !0,
			composed: !0
		}));
	} catch {}
}
function te(e, t) {
	let n = t.defaultView?.HTMLElement;
	return n ? e instanceof n : e.namespaceURI === "http://www.w3.org/1999/xhtml";
}
function ne(e, t = {}) {
	if (typeof document > "u") return [];
	let n = e ?? document, r = n, i = r.nodeType === 9 ? n : r.ownerDocument ?? document, a = [], o;
	try {
		o = Array.from(n.querySelectorAll(U));
	} catch {
		return a;
	}
	for (let e of o) {
		let o;
		try {
			o = z(JSON.parse(e.textContent ?? ""));
		} catch (t) {
			$(i, e, [v("standalone.payload.json", `The reactive-md payload is not valid JSON: ${b(t)}`)]);
			continue;
		}
		if (!o.ok) {
			$(i, e, o.diagnostics);
			continue;
		}
		let s = o.payload, c = n, l = (typeof c.getElementById == "function" ? c.getElementById(s.target) : null) ?? i.getElementById(s.target);
		if (!l) $(i, e, [v("standalone.target.missing", `The reactive-md payload target "#${s.target}" was not found.`)]);
		else if (r !== i && !r.contains(l)) $(i, e, [v("standalone.target.scope", "The reactive-md payload target is outside the scanned root.")]);
		else if (!te(l, i)) $(i, e, [v("standalone.target.type", "The reactive-md payload target must be an HTML element.")]);
		else if (!J(l)) try {
			a.push(Q(l, {
				source: s.source,
				state: s.state,
				locale: s.locale,
				colorScheme: s.colorScheme,
				hydrate: s.hydrate,
				images: s.images,
				compileOptions: s.compileOptions,
				extensions: s.extensions,
				restoration: s.restoration,
				resources: s.resources,
				documentId: s.documentId,
				randomSeed: s.randomSeed,
				componentState: s.componentState,
				reactConfig: t.reactConfig
			}, { onDiagnostics: (e) => $(i, l, e) }));
		} catch (e) {
			$(i, l, S(e));
		}
	}
	return a;
}
export { C as REACTIVE_MD_DIAGNOSTICS_EVENT, H as REACTIVE_MD_MOUNTED_ATTRIBUTE, w as REACTIVE_MD_STATE_CHANGE_EVENT, x as ReactiveMDMountError, J as isReactiveMDMounted, ee as mount, ne as mountAll, z as parseMountPayload };
