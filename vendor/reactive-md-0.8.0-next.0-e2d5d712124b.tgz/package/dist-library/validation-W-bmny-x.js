import { n as e } from "./props-DGlBk0e5.js";
import { F as t, K as n, L as r, M as i, P as a, Q as o, X as s, Y as c, Z as l, ct as u, k as d, lt as f, n as p, r as m, rt as h, t as g } from "./identity-MYJXKSkB.js";
import { $ as _, C as v, D as y, E as b, O as x, T as S, Z as ee, _ as C, a as w, c as T, d as te, h as ne, i as E, m as re, n as ie, nt as D, o as ae, p as oe, r as se, s as ce, t as le, v as ue, x as de } from "./config-validation-DXTynAw7.js";
// src/local/source/text-length.ts
function fe(e) {
	if (typeof e != "string") return 0;
	let t = 0;
	for (let n of e) t += 1;
	return t;
}
// src/local/contracts/types.ts
var pe = (e) => e.attrs?.bind ?? `@${e.id}`, O = class extends Error {
	code;
	constructor(e, t) {
		super(t), this.name = "LocalFunctionError", this.code = e;
	}
}, me = [
	"en-US",
	"zh-CN",
	"de-DE",
	"fr-FR",
	"ja-JP"
], he = new Set(me), ge = /^[A-Z]{3}$/, _e = 20;
function k(e) {
	throw new O("expression-domain", e);
}
function A(e, t) {
	if (e.length > 1e5) throw new O("expression-budget", `${t} exceeds the ${u}-character limit.`);
	return e;
}
function j(e) {
	return he.has(e) || k(`Unsupported locale "${e}"; expected one of ${me.join(", ")}.`), e;
}
function ve(e, t) {
	return (!Number.isInteger(e) || e < 0 || e > _e) && k(`${t} digits must be an integer from 0 to ${_e}.`), e;
}
function ye(e) {
	if (!Number.isFinite(e)) throw new O("expression-number", "Value must be a finite number.");
	return e;
}
function be(e) {
	return e === 0 ? 0 : e;
}
function xe(e, t) {
	let n = ye(e);
	return n === 0 || Math.abs(n) < .5 * 10 ** -t ? 0 : n;
}
function Se(e, t) {
	let n = ye(e);
	return n === 0 || Math.abs(n) < .5 * 10 ** -(t + 2) ? 0 : n;
}
function Ce(e, t, n, r, i) {
	let a;
	try {
		a = new Intl.NumberFormat(e, t);
	} catch {
		a = void 0;
	}
	return a === void 0 && k(i), A(a.format(n), r);
}
function we(e, t = 2, n = "en-US", r = !0) {
	let i = j(n), a = ve(t, "formatNumber");
	return typeof r != "boolean" && k("formatNumber grouping must be a boolean."), e === null ? "" : Ce(i, {
		useGrouping: r,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, xe(e, a), "Formatted number", `Cannot format a number for locale "${i}".`);
}
function Te(e, t = 0, n = "en-US") {
	let r = j(n), i = ve(t, "formatPercent");
	return e === null ? "" : Ce(r, {
		style: "percent",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, Se(e, i), "Formatted percentage", `Cannot format a percentage for locale "${r}".`);
}
function Ee(e, t = 2, n = "en-US") {
	let r = j(n), i = ve(t, "formatScientific");
	return e === null ? "" : Ce(r, {
		notation: "scientific",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, be(ye(e)), "Formatted number", `Cannot format a number for locale "${r}".`);
}
function De(e, t = "USD", n = 2, r = "en-US") {
	let i = j(r);
	ge.test(t) || k(`Currency "${t}" must be a three-letter uppercase code such as "USD".`);
	let a = ve(n, "formatCurrency");
	return e === null ? "" : Ce(i, {
		style: "currency",
		currency: t,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, xe(e, a), "Formatted currency", `Currency code "${t}" is not accepted by Intl.`);
}
// src/local/evaluation/collection-functions.ts
function Oe() {
	throw new O("expression-number", "The result is not a finite number.");
}
function M(e) {
	if (!Number.isFinite(e)) throw new O("expression-value", "Numeric array members must be finite numbers.");
	return e;
}
function ke(e) {
	let t = 0;
	for (let n of e) t += M(n);
	return Number.isFinite(t) || Oe(), t;
}
function Ae(e) {
	if (e.length === 0) return null;
	let t = ke(e) / e.length;
	return Number.isFinite(t) || Oe(), t;
}
function je(e) {
	if (e.length === 0) return null;
	let t = M(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = M(e[n]);
		r < t && (t = r);
	}
	return t;
}
function Me(e) {
	if (e.length === 0) return null;
	let t = M(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = M(e[n]);
		r > t && (t = r);
	}
	return t;
}
// src/local/evaluation/dates.ts
function Ne(e) {
	let t = /^(\d{4})-(\d{2})-(\d{2})$/.exec(e);
	if (!t) return null;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	if (n < 1 || r < 1 || r > 12 || i < 1 || i > 31) return null;
	let a = /* @__PURE__ */ new Date(0);
	return a.setUTCFullYear(n, r - 1, i), a.getUTCFullYear() === n && a.getUTCMonth() === r - 1 && a.getUTCDate() === i ? a.getTime() : null;
}
// src/local/evaluation/data-functions.ts
function Pe(e) {
	throw new O("expression-domain", e);
}
function Fe(e) {
	return A(e.trim(), "trim result");
}
function Ie(e) {
	return A(e.toLowerCase(), "lower result");
}
function Le(e) {
	return A(e.toUpperCase(), "upper result");
}
function Re(e, t) {
	return e.startsWith(t);
}
function ze(e, t) {
	return e.endsWith(t);
}
function Be(e, t, n) {
	t.length === 0 && Pe("replace search text must not be empty.");
	let r = n.length - t.length;
	if (r > 0) {
		let n = 0, i = 0;
		for (;;) {
			let r = e.indexOf(t, i);
			if (r < 0) break;
			n += 1, i = r + t.length;
		}
		if (e.length + n * r > 1e5) throw new O("expression-budget", `replace result would exceed the ${u}-character limit.`);
	}
	let i = "", a = 0;
	for (;;) {
		let r = e.indexOf(t, a);
		if (r < 0) break;
		i += e.slice(a, r), i += n, a = r + t.length;
	}
	return i += e.slice(a), A(i, "replace result");
}
function Ve(e, t) {
	return e < 0 ? Math.max(t + e, 0) : Math.min(e, t);
}
function He(e, t, n) {
	Number.isInteger(t) || Pe("slice start must be an integer."), n !== void 0 && !Number.isInteger(n) && Pe("slice end must be an integer.");
	let r = Array.from(e), i = r.length, a = Ve(t, i), o = n === void 0 ? i : Ve(n, i);
	return o <= a ? "" : A(r.slice(a, o).join(""), "slice result");
}
var Ue = /* @__PURE__ */ new Map([
	["days", 864e5],
	["hours", 36e5],
	["minutes", 6e4],
	["seconds", 1e3],
	["milliseconds", 1]
]), We = "days, hours, minutes, seconds or milliseconds";
function N(e) {
	let t = Ne(e);
	if (t === null) throw new O("expression-domain", `Date "${e}" must be a valid YYYY-MM-DD calendar date in years 0001-9999.`);
	return t;
}
function Ge(e, t) {
	let n = N(e), r = N(t);
	return n === r ? 0 : n < r ? -1 : 1;
}
function Ke(e, t, n = "days") {
	let r = Ue.get(n);
	return r === void 0 && Pe(`dateDiff unit must be ${We}.`), (N(e) - N(t)) / r;
}
// src/local/evaluation/expression.ts
var P = class extends Error {
	offset;
	code;
	constructor(e, t, n = 0) {
		super(t), this.name = "LocalExpressionError", this.code = e, this.offset = n;
	}
}, qe = /* @__PURE__ */ "abs.sqrt.floor.ceil.round.min.max.pow.sin.cos.tan.asin.acos.atan.exp.log.len.contains.clamp.sum.average.minOf.maxOf.formatNumber.formatPercent.formatScientific.formatCurrency.trim.lower.upper.startsWith.endsWith.replace.slice.dateCompare.dateDiff".split("."), Je = new Set(qe), Ye = /* @__PURE__ */ new Map([["pi", Math.PI], ["e", Math.E]]), Xe = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]), Ze = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), Qe = /* @__PURE__ */ new Set([
	...qe,
	"x",
	"y",
	"pi",
	"e",
	"true",
	"false",
	"null",
	...Xe
]), $e = 4e3, et = 2e3, tt = 100, nt = 200, rt = 1e4, it = 250, at = u, ot = u, st = 500;
function ct(e) {
	if (e.length > 1e4) return {
		code: "expression-budget",
		...D("local.budget.value.array", { limit: o }),
		message: `Array exceeds the ${o}-item limit.`
	};
	let t = null, n = 0;
	for (let r of e) if (typeof r == "string") {
		if (t === "number") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (t = "string", r.length > 1e5) return {
			code: "expression-budget",
			...D("local.budget.value.array-member", { limit: u }),
			message: `Array member exceeds the ${u}-character limit.`
		};
		if (n += r.length, n > 1e5) return {
			code: "expression-budget",
			...D("local.budget.value.array-contents", { limit: f }),
			message: `Array contents exceed the ${f}-character limit.`
		};
	} else if (typeof r == "number") {
		if (t === "string") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (t = "number", !Number.isFinite(r)) return {
			code: "expression-value",
			key: "error.array.finite",
			message: "Array members must be finite numbers."
		};
	} else return {
		code: "expression-value",
		key: "error.array.members",
		message: "Array members must be strings or finite numbers."
	};
	return null;
}
function lt(e) {
	if (typeof e == "string") return e.length > 1e5 ? D("local.budget.value.string", { limit: u }) : null;
	if (Array.isArray(e)) {
		let t = ct(e);
		return t ? D(t.key, t.params) : null;
	}
	return null;
}
function F(e) {
	let t = lt(e);
	return t ? _(t) : null;
}
var ut = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/, dt = /[A-Za-z_]/, ft = /[A-Za-z0-9_]/;
function pt(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r >= "0" && r <= "9" || r === "." && /[0-9]/.test(e[n + 1] ?? "")) {
			let r = ut.exec(e.slice(n));
			if (!r) throw new P("expression-syntax", "Invalid number.", n);
			let i = r[0], a = Number(i);
			if (!Number.isFinite(a)) throw new P("expression-number", `Number must be finite: ${i}.`, n);
			t.push({
				kind: "number",
				value: i,
				start: n,
				number: a
			}), n += i.length;
			continue;
		}
		if (r === "\"" || r === "'") {
			let i = n, a = r, o = "", s = n + 1, c = !1;
			for (; s < e.length;) {
				let t = e[s];
				if (t === a) {
					c = !0, s += 1;
					break;
				}
				if (t === "\n" || t === "\r") throw new P("expression-string", "String literals cannot span lines.", i);
				if (t === "\\") {
					let t = e[s + 1];
					if (t === void 0) break;
					switch (t) {
						case "\\":
							o += "\\";
							break;
						case "'":
							o += "'";
							break;
						case "\"":
							o += "\"";
							break;
						case "n":
							o += "\n";
							break;
						case "t":
							o += "	";
							break;
						default: throw new P("expression-string", `Unsupported escape \\${t}.`, s);
					}
					s += 2;
				} else o += t, s += 1;
			}
			if (!c) throw new P("expression-string", "Unterminated string literal.", i);
			if (o.length > at) throw new P("expression-budget", "String literal exceeds the length limit.", i);
			t.push({
				kind: "string",
				value: o,
				start: i
			}), n = s;
			continue;
		}
		if (dt.test(r)) {
			let r = n + 1;
			for (; r < e.length && ft.test(e[r]);) r += 1;
			t.push({
				kind: "ident",
				value: e.slice(n, r),
				start: n
			}), n = r;
			continue;
		}
		let i = e.slice(n, n + 2);
		if (e.startsWith("!==", n) || e.startsWith("===", n)) throw new P("expression-syntax", `Unsupported operator ${e.slice(n, n + 3)}.`, n);
		if (i === "==" || i === "!=" || i === "<=" || i === ">=" || i === "&&" || i === "||") t.push({
			kind: "punct",
			value: i,
			start: n
		}), n += 2;
		else if ("+-*/%()!<>?:,[]".includes(r)) t.push({
			kind: "punct",
			value: r,
			start: n
		}), n += 1;
		else throw r === "=" ? new P("expression-assignment", "Assignments are not supported.", n) : r === "." ? new P("expression-property", "Property access is not supported.", n) : r === "&" || r === "|" ? new P("expression-syntax", `Use ${r}${r} for logical operations.`, n) : new P("expression-syntax", `Unrecognized character "${r}".`, n);
	}
	return t.push({
		kind: "eof",
		value: "",
		start: e.length
	}), t;
}
var mt = {
	abs: [1, 1],
	sqrt: [1, 1],
	floor: [1, 1],
	ceil: [1, 1],
	round: [1, 1],
	min: [1, 2 ** 53 - 1],
	max: [1, 2 ** 53 - 1],
	pow: [2, 2],
	sin: [1, 1],
	cos: [1, 1],
	tan: [1, 1],
	asin: [1, 1],
	acos: [1, 1],
	atan: [1, 1],
	exp: [1, 1],
	log: [1, 1],
	len: [1, 1],
	contains: [2, 2],
	clamp: [3, 3],
	sum: [1, 1],
	average: [1, 1],
	minOf: [1, 1],
	maxOf: [1, 1],
	formatNumber: [1, 4],
	formatPercent: [1, 3],
	formatScientific: [1, 3],
	formatCurrency: [1, 4],
	trim: [1, 1],
	lower: [1, 1],
	upper: [1, 1],
	startsWith: [2, 2],
	endsWith: [2, 2],
	replace: [3, 3],
	slice: [2, 3],
	dateCompare: [2, 2],
	dateDiff: [2, 3]
};
function ht(e) {
	let t = 0, n = [{
		node: e,
		depth: 1
	}];
	for (; n.length > 0;) {
		let { node: e, depth: r } = n.pop();
		switch (r > t && (t = r), e.kind) {
			case "unary":
				n.push({
					node: e.operand,
					depth: r + 1
				});
				break;
			case "binary":
				n.push({
					node: e.left,
					depth: r + 1
				}), n.push({
					node: e.right,
					depth: r + 1
				});
				break;
			case "conditional":
				n.push({
					node: e.test,
					depth: r + 1
				}), n.push({
					node: e.consequent,
					depth: r + 1
				}), n.push({
					node: e.alternate,
					depth: r + 1
				});
				break;
			case "call":
				for (let t of e.args) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "array":
				for (let t of e.elements) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "index": n.push({
				node: e.target,
				depth: r + 1
			}), n.push({
				node: e.index,
				depth: r + 1
			});
		}
	}
	return t;
}
var gt = class {
	tokens;
	position = 0;
	nodeCount = 0;
	dependencyNames = [];
	dependencySet = /* @__PURE__ */ new Set();
	constructor(e) {
		this.tokens = pt(e);
	}
	get dependencies() {
		return this.dependencyNames;
	}
	parse() {
		if (this.peek().kind === "eof") throw new P("expression-empty", "Expression is empty.", 0);
		let e = this.parseConditional(0), t = this.peek();
		if (t.kind !== "eof") throw new P("expression-syntax", `Unexpected content "${t.value}".`, t.start);
		if (ht(e) > nt) throw new P("expression-budget", "Expression is nested too deeply.", e.start);
		return e;
	}
	peek() {
		return this.tokens[this.position];
	}
	next() {
		let e = this.tokens[this.position];
		return this.position += 1, e;
	}
	isPunct(e) {
		let t = this.peek();
		return t.kind === "punct" && t.value === e;
	}
	expect(e) {
		let t = this.peek();
		if (t.kind !== "punct" || t.value !== e) throw new P("expression-syntax", `Missing "${e}".`, t.start);
		return this.next();
	}
	node(e, t, n) {
		if (this.nodeCount += 1, this.nodeCount > et) throw new P("expression-budget", "Expression is too complex.", n);
		if (t > tt) throw new P("expression-budget", "Expression is nested too deeply.", n);
		return e;
	}
	parseConditional(e) {
		let t = this.parseOr(e);
		if (!this.isPunct("?")) return t;
		let n = t.start;
		this.next();
		let r = this.parseConditional(e + 1);
		this.expect(":");
		let i = this.parseConditional(e + 1);
		return this.node({
			kind: "conditional",
			test: t,
			consequent: r,
			alternate: i,
			start: n
		}, e, n);
	}
	parseOr(e) {
		let t = this.parseAnd(e);
		for (; this.isPunct("||");) {
			let n = t.start;
			this.next();
			let r = this.parseAnd(e);
			t = this.node({
				kind: "binary",
				operator: "||",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAnd(e) {
		let t = this.parseEquality(e);
		for (; this.isPunct("&&");) {
			let n = t.start;
			this.next();
			let r = this.parseEquality(e);
			t = this.node({
				kind: "binary",
				operator: "&&",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseEquality(e) {
		let t = this.parseRelational(e);
		for (; this.isPunct("==") || this.isPunct("!=");) {
			let n = t.start, r = this.next().value, i = this.parseRelational(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseRelational(e) {
		let t = this.parseAdditive(e);
		for (; this.isPunct("<") || this.isPunct("<=") || this.isPunct(">") || this.isPunct(">=");) {
			let n = t.start, r = this.next().value, i = this.parseAdditive(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAdditive(e) {
		let t = this.parseMultiplicative(e);
		for (; this.isPunct("+") || this.isPunct("-");) {
			let n = t.start, r = this.next().value, i = this.parseMultiplicative(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseMultiplicative(e) {
		let t = this.parseUnary(e);
		for (; this.isPunct("*") || this.isPunct("/") || this.isPunct("%");) {
			let n = t.start, r = this.next().value, i = this.parseUnary(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseUnary(e) {
		let t = this.peek();
		if (t.kind === "punct" && (t.value === "-" || t.value === "+" || t.value === "!")) {
			this.next();
			let n = this.parseUnary(e + 1);
			return this.node({
				kind: "unary",
				operator: t.value,
				operand: n,
				start: t.start
			}, e, t.start);
		}
		return this.parsePrimary(e);
	}
	parsePrimary(e) {
		let t = this.parseAtom(e);
		for (; this.isPunct("[");) {
			let n = t.start;
			this.next();
			let r = this.parseConditional(e + 1);
			this.expect("]"), t = this.node({
				kind: "index",
				target: t,
				index: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAtom(e) {
		let t = this.peek();
		if (t.kind === "number") return this.next(), this.node({
			kind: "literal",
			value: t.number,
			start: t.start
		}, e, t.start);
		if (t.kind === "string") return this.next(), this.node({
			kind: "literal",
			value: t.value,
			start: t.start
		}, e, t.start);
		if (t.kind === "ident") {
			this.next();
			let n = t.value;
			if (this.isPunct("(")) {
				if (!Je.has(n)) throw new P("expression-unknown-function", `Unknown function "${n}".`, t.start);
				this.next();
				let r = [];
				if (!this.isPunct(")")) for (r.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), r.push(this.parseConditional(e + 1));
				this.expect(")");
				let [i, a] = mt[n];
				if (r.length < i || r.length > a) throw new P("expression-arity", `Function ${n} expects ${i === a ? `${i} ${i === 1 ? "argument" : "arguments"}` : i === 1 ? "at least one argument" : `${i}–${a} arguments`}.`, t.start);
				return this.node({
					kind: "call",
					name: n,
					args: r,
					start: t.start
				}, e, t.start);
			}
			if (n === "true" || n === "false") return this.node({
				kind: "literal",
				value: n === "true",
				start: t.start
			}, e, t.start);
			if (n === "null") return this.node({
				kind: "literal",
				value: null,
				start: t.start
			}, e, t.start);
			let r = Ye.get(n);
			if (r !== void 0) return this.node({
				kind: "literal",
				value: r,
				start: t.start
			}, e, t.start);
			if (Xe.has(n)) throw new P("expression-forbidden-name", `Name "${n}" is not allowed.`, t.start);
			if (Je.has(n)) throw new P("expression-syntax", `Function ${n} must be called with parentheses.`, t.start);
			return this.dependencySet.has(n) || (this.dependencySet.add(n), this.dependencyNames.push(n)), this.node({
				kind: "reference",
				name: n,
				start: t.start
			}, e, t.start);
		}
		if (t.kind === "punct" && t.value === "(") {
			this.next();
			let t = this.parseConditional(e + 1);
			return this.expect(")"), t;
		}
		if (t.kind === "punct" && t.value === "[") {
			this.next();
			let n = [];
			if (!this.isPunct("]")) for (n.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), n.push(this.parseConditional(e + 1));
			return this.expect("]"), this.node({
				kind: "array",
				elements: n,
				start: t.start
			}, e, t.start);
		}
		throw new P("expression-syntax", "Expected an expression.", t.start);
	}
};
function I(e) {
	switch (e) {
		case "string": return "string";
		case "number": return "number";
		case "boolean": return "boolean";
		case "null": return "null";
		case "array": return "array";
		case "number-array": return "number array";
	}
}
function _t(e) {
	return e === null ? "null" : Array.isArray(e) ? "array" : typeof e == "boolean" ? "boolean" : typeof e == "number" ? "number" : "string";
}
function L(e, t) {
	throw new P("expression-type", e, t);
}
function R(e, t, n, r) {
	e !== t && L(`${r}, got ${I(e)}.`, n);
}
function vt(e, t) {
	return e === t ? e : e === "null" ? t : t === "null" ? e : null;
}
function z(e, t) {
	switch (e.kind) {
		case "literal": return _t(e.value);
		case "reference": {
			if (typeof t != "object" || !t || !Object.prototype.hasOwnProperty.call(t, e.name)) throw new P("expression-unknown-name", `Variable "${e.name}" is not declared.`, e.start);
			let n = t[e.name];
			if (typeof n != "string" || !Ze.has(n)) throw new P("expression-value", `Variable "${e.name}" has an invalid type.`, e.start);
			return n;
		}
		case "unary": {
			let n = z(e.operand, t);
			return e.operator === "!" ? (R(n, "boolean", e.start, "Logical not requires a boolean"), "boolean") : (R(n, "number", e.start, `Unary ${e.operator} requires a number`), "number");
		}
		case "binary": {
			let n = z(e.left, t), r = z(e.right, t);
			switch (e.operator) {
				case "+": return n === "number" && r === "number" ? "number" : n === "string" && r === "string" ? "string" : L(`Operator "+" requires two numbers or two strings, got ${I(n)} and ${I(r)}.`, e.start);
				case "-":
				case "*":
				case "/":
				case "%": return R(n, "number", e.start, `Operator "${e.operator}" requires a number`), R(r, "number", e.start, `Operator "${e.operator}" requires a number`), "number";
				case "<":
				case "<=":
				case ">":
				case ">=": return n === "number" && r === "number" || n === "string" && r === "string" ? "boolean" : L(`Comparison operator "${e.operator}" requires two numbers or two strings, got ${I(n)} and ${I(r)}.`, e.start);
				case "==":
				case "!=": return n !== r && n !== "null" && r !== "null" ? L(`Equality comparison requires matching types, got ${I(n)} and ${I(r)}.`, e.start) : "boolean";
				case "&&":
				case "||": return R(n, "boolean", e.start, "Logical operators require booleans"), R(r, "boolean", e.start, "Logical operators require booleans"), "boolean";
			}
			break;
		}
		case "array": {
			if (e.elements.length === 0) return "number-array";
			let n = null;
			for (let r of e.elements) {
				let e = z(r, t);
				if (e !== "string" && e !== "number") return L(`Array literals require string or number elements, got ${I(e)}.`, r.start);
				if (n === null) n = e;
				else if (n !== e) return L(`Array literals require elements of one type, got ${I(n)} and ${I(e)}.`, r.start);
			}
			return n === "string" ? "array" : "number-array";
		}
		case "index": {
			let n = z(e.target, t);
			return R(z(e.index, t), "number", e.start, "Array index must be a number"), n === "array" ? "string" : n === "number-array" ? "number" : L(`Index access requires an array, got ${I(n)}.`, e.start);
		}
		case "conditional": {
			R(z(e.test, t), "boolean", e.start, "Conditional test must be a boolean");
			let n = z(e.consequent, t), r = z(e.alternate, t);
			if (n === "array" && e.alternate.kind === "array" && e.alternate.elements.length === 0 || r === "array" && e.consequent.kind === "array" && e.consequent.elements.length === 0) return "array";
			let i = vt(n, r);
			return i === null ? L(`Conditional branches must have matching types or one null, got ${I(n)} and ${I(r)}.`, e.start) : i;
		}
		case "call": {
			let n = e.args.map((e) => z(e, t));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": return R(n[0], "number", e.start, `Function ${e.name} requires a number`), "number";
				case "min":
				case "max":
				case "pow":
				case "clamp":
					for (let t of n) R(t, "number", e.start, `Function ${e.name} requires a number`);
					return "number";
				case "len": return n[0] !== "string" && n[0] !== "array" && n[0] !== "number-array" && L(`Function len requires a string or array, got ${I(n[0])}.`, e.start), "number";
				case "contains":
					if (n[0] === "number-array") return R(n[1], "number", e.start, "Function contains requires a numeric member"), "boolean";
					if (n[0] === "string" || n[0] === "array") return R(n[1], "string", e.start, "Function contains requires a string member"), "boolean";
					L(`Function contains requires a string or array, got ${I(n[0])}.`, e.start);
					break;
				case "sum":
				case "average":
				case "minOf":
				case "maxOf": return R(n[0], "number-array", e.start, `Function ${e.name} requires a numeric array`), "number";
				case "formatNumber":
				case "formatPercent":
				case "formatScientific": return n[0] !== "number" && n[0] !== "null" && L(`Function ${e.name} requires a number or null, got ${I(n[0])}.`, e.start), n[1] !== void 0 && R(n[1], "number", e.start, `Function ${e.name} requires numeric fraction digits`), n[2] !== void 0 && R(n[2], "string", e.start, `Function ${e.name} requires a string locale`), e.name === "formatNumber" && n[3] !== void 0 && R(n[3], "boolean", e.start, "Function formatNumber requires a boolean grouping flag"), "string";
				case "formatCurrency": return n[0] !== "number" && n[0] !== "null" && L(`Function formatCurrency requires a number or null, got ${I(n[0])}.`, e.start), n[1] !== void 0 && R(n[1], "string", e.start, "Function formatCurrency requires a string currency code"), n[2] !== void 0 && R(n[2], "number", e.start, "Function formatCurrency requires numeric fraction digits"), n[3] !== void 0 && R(n[3], "string", e.start, "Function formatCurrency requires a string locale"), "string";
				case "trim":
				case "lower":
				case "upper": return R(n[0], "string", e.start, `Function ${e.name} requires a string`), "string";
				case "startsWith":
				case "endsWith": return R(n[0], "string", e.start, `Function ${e.name} requires a string`), R(n[1], "string", e.start, `Function ${e.name} requires a string search value`), "boolean";
				case "replace": return R(n[0], "string", e.start, "Function replace requires a string"), R(n[1], "string", e.start, "Function replace requires a string search value"), R(n[2], "string", e.start, "Function replace requires a string replacement"), "string";
				case "slice": return R(n[0], "string", e.start, "Function slice requires a string"), R(n[1], "number", e.start, "Function slice requires a numeric start index"), n[2] !== void 0 && R(n[2], "number", e.start, "Function slice requires a numeric end index"), "string";
				case "dateCompare": return R(n[0], "string", e.start, "Function dateCompare requires a date string"), R(n[1], "string", e.start, "Function dateCompare requires a date string"), "number";
				case "dateDiff": return R(n[0], "string", e.start, "Function dateDiff requires a date string"), R(n[1], "string", e.start, "Function dateDiff requires a date string"), n[2] !== void 0 && R(n[2], "string", e.start, "Function dateDiff requires a string unit"), "number";
			}
			break;
		}
	}
	throw new P("expression-type", "Unsupported expression.", 0);
}
function B(e, t, n = "expression-eval") {
	throw new P(n, e, t);
}
function yt(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) throw new P("expression-value", "Expression environment must be an object.", 0);
}
function bt(e, t, n) {
	if (e === null) return null;
	if (typeof e == "string") {
		let r = F(e);
		if (r) throw new P("expression-budget", `Variable "${t}": ${r}`, n);
		return e;
	}
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new P("expression-value", `Variable "${t}" must be a finite number.`, n);
		return e;
	}
	if (Array.isArray(e)) {
		let r = ct(e);
		if (r) throw new P(r.code, `Variable "${t}": ${r.message}`, n);
		return e;
	}
	throw new P("expression-value", `Variable "${t}" has an invalid value type.`, n);
}
function xt(e, t, n) {
	return yt(e), Object.prototype.hasOwnProperty.call(e, t) || B(`Variable "${t}" is not declared.`, n, "expression-unknown-name"), bt(e[t], t, n);
}
function V(e, t, n = "Expected a number") {
	return typeof e == "number" && Number.isFinite(e) || B(`${n}.`, t, "expression-type"), e;
}
function H(e, t, n = "Expected a boolean") {
	return typeof e != "boolean" && B(`${n}.`, t, "expression-type"), e;
}
function U(e, t, n = "Expected a string") {
	return typeof e != "string" && B(`${n}.`, t, "expression-type"), e;
}
function W(e, t, n) {
	Array.isArray(e) || B(`${n}.`, t, "expression-type");
	for (let r of e) typeof r == "number" && Number.isFinite(r) || B(`${n}.`, t, "expression-type");
	return e;
}
function St(e, t) {
	let n = ct(e);
	return n && B(n.message, t, n.code), e;
}
function G(e, t) {
	try {
		return t();
	} catch (t) {
		throw t instanceof O ? new P(t.code, t.message, e) : t;
	}
}
function K(e, t) {
	return Number.isNaN(e) && B("The result is undefined.", t, "expression-domain"), Number.isFinite(e) || B("The result is not a finite number.", t, "expression-number"), e;
}
function Ct(e, t) {
	let n = Array.from(e), r = Array.from(t), i = Math.min(n.length, r.length);
	for (let e = 0; e < i; e += 1) {
		let t = n[e].codePointAt(0), i = r[e].codePointAt(0);
		if (t !== i) return t < i ? -1 : 1;
	}
	return n.length === r.length ? 0 : n.length < r.length ? -1 : 1;
}
function wt(e, t) {
	if (e === t) return !0;
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return !1;
		for (let n = 0; n < e.length; n += 1) if (e[n] !== t[n]) return !1;
		return !0;
	}
	return !1;
}
function Tt(e, t) {
	return q(e, t, { steps: 0 }, 1);
}
function q(e, t, n, r) {
	switch (n.steps += 1, n.steps > rt && B("Expression evaluation exceeded the step limit.", e.start, "expression-budget"), r > it && B("Expression evaluation is nested too deeply.", e.start, "expression-budget"), e.kind) {
		case "literal": return e.value;
		case "reference": return xt(t, e.name, e.start);
		case "unary": {
			let i = q(e.operand, t, n, r + 1);
			if (e.operator === "!") return !H(i, e.start, "Logical not requires a boolean");
			let a = V(i, e.start, `Unary ${e.operator} requires a number`);
			return K(e.operator === "-" ? -a : a, e.start);
		}
		case "binary": {
			if (e.operator === "&&" || e.operator === "||") {
				let i = H(q(e.left, t, n, r + 1), e.start, "Logical operators require booleans");
				return e.operator === "&&" && !i ? !1 : e.operator === "||" && i ? !0 : H(q(e.right, t, n, r + 1), e.start, "Logical operators require booleans");
			}
			let i = q(e.left, t, n, r + 1), a = q(e.right, t, n, r + 1);
			switch (e.operator) {
				case "+":
					if (typeof i == "number" && typeof a == "number") return K(i + a, e.start);
					if (typeof i == "string" && typeof a == "string") {
						let t = i + a;
						return t.length > at && B("String result exceeds the length limit.", e.start, "expression-budget"), t;
					}
					B("Operator \"+\" requires two numbers or two strings.", e.start, "expression-type");
				case "-":
				case "*":
				case "/":
				case "%": {
					let t = V(i, e.start, `Operator "${e.operator}" requires a number`), n = V(a, e.start, `Operator "${e.operator}" requires a number`);
					return (e.operator === "/" || e.operator === "%") && n === 0 && B("Division by zero.", e.start, "expression-divide-by-zero"), K(e.operator === "-" ? t - n : e.operator === "*" ? t * n : e.operator === "/" ? t / n : t % n, e.start);
				}
				case "==":
				case "!=": {
					let t = _t(i), n = _t(a);
					t !== n && t !== "null" && n !== "null" && B("Equality comparison requires matching types.", e.start, "expression-type");
					let r = wt(i, a);
					return e.operator === "==" ? r : !r;
				}
				case "<":
				case "<=":
				case ">":
				case ">=": {
					let t;
					return typeof i == "number" && typeof a == "number" ? t = i === a ? 0 : i < a ? -1 : 1 : typeof i == "string" && typeof a == "string" ? t = Ct(i, a) : B(`Comparison operator "${e.operator}" requires two numbers or two strings.`, e.start, "expression-type"), e.operator === "<" ? t < 0 : e.operator === "<=" ? t <= 0 : e.operator === ">" ? t > 0 : t >= 0;
				}
			}
			break;
		}
		case "conditional": return q(H(q(e.test, t, n, r + 1), e.start, "Conditional test must be a boolean") ? e.consequent : e.alternate, t, n, r + 1);
		case "array": {
			let i = [];
			for (let a of e.elements) i.push(q(a, t, n, r + 1));
			return St(i, e.start);
		}
		case "index": {
			let i = q(e.target, t, n, r + 1), a = V(q(e.index, t, n, r + 1), e.start, "Array index must be a number");
			return Number.isSafeInteger(a) || B("Array index must be a finite integer.", e.start, "expression-index"), Array.isArray(i) || B("Index access requires an array.", e.start, "expression-type"), a < 0 || a >= i.length ? null : i[a];
		}
		case "call": {
			let i = e.args.map((e) => q(e, t, n, r + 1));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": {
					let t = V(i[0], e.start, `Function ${e.name} requires a number`);
					e.name === "sqrt" && t < 0 && B("sqrt requires a non-negative argument.", e.start, "expression-domain"), e.name === "log" && t <= 0 && B("log requires a positive argument.", e.start, "expression-domain"), (e.name === "asin" || e.name === "acos") && (t < -1 || t > 1) && B(`${e.name} requires an argument between -1 and 1.`, e.start, "expression-domain");
					let n;
					switch (e.name) {
						case "abs":
							n = Math.abs(t);
							break;
						case "sqrt":
							n = Math.sqrt(t);
							break;
						case "floor":
							n = Math.floor(t);
							break;
						case "ceil":
							n = Math.ceil(t);
							break;
						case "round":
							n = Math.round(t);
							break;
						case "sin":
							n = Math.sin(t);
							break;
						case "cos":
							n = Math.cos(t);
							break;
						case "tan":
							n = Math.tan(t);
							break;
						case "asin":
							n = Math.asin(t);
							break;
						case "acos":
							n = Math.acos(t);
							break;
						case "atan":
							n = Math.atan(t);
							break;
						case "exp":
							n = Math.exp(t);
							break;
						default: n = Math.log(t);
					}
					return K(n, e.start);
				}
				case "min":
				case "max": {
					let t = V(i[0], e.start, `Function ${e.name} requires a number`);
					for (let n = 1; n < i.length; n += 1) {
						let r = V(i[n], e.start, `Function ${e.name} requires a number`);
						t = e.name === "min" ? Math.min(t, r) : Math.max(t, r);
					}
					return K(t, e.start);
				}
				case "pow": return K(V(i[0], e.start, "Function pow requires a number") ** +V(i[1], e.start, "Function pow requires a number"), e.start);
				case "clamp": {
					let t = V(i[0], e.start, "Function clamp requires a number"), n = V(i[1], e.start, "Function clamp requires a number"), r = V(i[2], e.start, "Function clamp requires a number");
					return n > r && B("clamp lower bound cannot exceed upper bound.", e.start, "expression-domain"), K(Math.min(r, Math.max(n, t)), e.start);
				}
				case "len": {
					let t = i[0];
					if (typeof t == "string") return fe(t);
					if (Array.isArray(t)) return t.length;
					B("Function len requires a string or array.", e.start, "expression-type");
				}
				case "contains": {
					let t = i[0], n = i[1];
					if (typeof t == "string") return t.includes(U(n, e.start, "Function contains requires a string member"));
					if (Array.isArray(t)) {
						if (typeof n == "string") {
							for (let n of t) typeof n != "string" && B("Function contains requires a string member for a string array.", e.start, "expression-type");
							return t.includes(n);
						}
						if (typeof n == "number" && Number.isFinite(n)) {
							for (let n of t) typeof n != "number" && B("Function contains requires a numeric member for a numeric array.", e.start, "expression-type");
							return t.includes(n);
						}
						B("Function contains requires a string or numeric member.", e.start, "expression-type");
					}
					B("Function contains requires a string or array.", e.start, "expression-type");
				}
				case "sum": {
					let t = W(i[0], e.start, "Function sum requires a numeric array");
					return G(e.start, () => ke(t));
				}
				case "average": {
					let t = W(i[0], e.start, "Function average requires a numeric array");
					return G(e.start, () => Ae(t));
				}
				case "minOf": {
					let t = W(i[0], e.start, "Function minOf requires a numeric array");
					return G(e.start, () => je(t));
				}
				case "maxOf": {
					let t = W(i[0], e.start, "Function maxOf requires a numeric array");
					return G(e.start, () => Me(t));
				}
				case "formatNumber": {
					let t = i[0] === null ? null : V(i[0], e.start, "Function formatNumber requires a number or null"), n = i[1] === void 0 ? 2 : V(i[1], e.start, "Function formatNumber requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : U(i[2], e.start, "Function formatNumber requires a string locale"), a = i[3] === void 0 || H(i[3], e.start, "Function formatNumber requires a boolean grouping flag");
					return G(e.start, () => we(t, n, r, a));
				}
				case "formatPercent": {
					let t = i[0] === null ? null : V(i[0], e.start, "Function formatPercent requires a number or null"), n = i[1] === void 0 ? 0 : V(i[1], e.start, "Function formatPercent requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : U(i[2], e.start, "Function formatPercent requires a string locale");
					return G(e.start, () => Te(t, n, r));
				}
				case "formatScientific": {
					let t = i[0] === null ? null : V(i[0], e.start, "Function formatScientific requires a number or null"), n = i[1] === void 0 ? 2 : V(i[1], e.start, "Function formatScientific requires numeric fraction digits"), r = i[2] === void 0 ? "en-US" : U(i[2], e.start, "Function formatScientific requires a string locale");
					return G(e.start, () => Ee(t, n, r));
				}
				case "formatCurrency": {
					let t = i[0] === null ? null : V(i[0], e.start, "Function formatCurrency requires a number or null"), n = i[1] === void 0 ? "USD" : U(i[1], e.start, "Function formatCurrency requires a string currency code"), r = i[2] === void 0 ? 2 : V(i[2], e.start, "Function formatCurrency requires numeric fraction digits"), a = i[3] === void 0 ? "en-US" : U(i[3], e.start, "Function formatCurrency requires a string locale");
					return G(e.start, () => De(t, n, r, a));
				}
				case "trim": return G(e.start, () => Fe(U(i[0], e.start, "Function trim requires a string")));
				case "lower": return G(e.start, () => Ie(U(i[0], e.start, "Function lower requires a string")));
				case "upper": return G(e.start, () => Le(U(i[0], e.start, "Function upper requires a string")));
				case "startsWith": return G(e.start, () => Re(U(i[0], e.start, "Function startsWith requires a string"), U(i[1], e.start, "Function startsWith requires a string search value")));
				case "endsWith": return G(e.start, () => ze(U(i[0], e.start, "Function endsWith requires a string"), U(i[1], e.start, "Function endsWith requires a string search value")));
				case "replace": {
					let t = U(i[0], e.start, "Function replace requires a string"), n = U(i[1], e.start, "Function replace requires a string search value"), r = U(i[2], e.start, "Function replace requires a string replacement");
					return G(e.start, () => Be(t, n, r));
				}
				case "slice": {
					let t = U(i[0], e.start, "Function slice requires a string"), n = V(i[1], e.start, "Function slice requires a numeric start index"), r = i[2] === void 0 ? void 0 : V(i[2], e.start, "Function slice requires a numeric end index");
					return G(e.start, () => He(t, n, r));
				}
				case "dateCompare": {
					let t = U(i[0], e.start, "Function dateCompare requires a date string"), n = U(i[1], e.start, "Function dateCompare requires a date string");
					return G(e.start, () => Ge(t, n));
				}
				case "dateDiff": {
					let t = U(i[0], e.start, "Function dateDiff requires a date string"), n = U(i[1], e.start, "Function dateDiff requires a date string"), r = i[2] === void 0 ? "days" : U(i[2], e.start, "Function dateDiff requires a string unit");
					return G(e.start, () => Ke(t, n, r));
				}
			}
			break;
		}
	}
	throw new P("expression-eval", "Unsupported expression.", 0);
}
var J = /* @__PURE__ */ new Map();
function Et(e) {
	if (typeof e != "string") throw new P("expression-syntax", "Expression must be a string.", 0);
	if (e.length > $e) throw new P("expression-budget", `Expression exceeds the ${$e}-character limit.`, 0);
	let t = J.get(e);
	if (t) return t;
	let n = new gt(e), r = n.parse(), i = [...n.dependencies], a = Object.freeze({
		source: e,
		dependencies: i,
		evaluate(e) {
			return Tt(r, e);
		},
		inferType(e) {
			return z(r, e);
		}
	});
	if (J.size >= st) {
		let e = J.keys().next().value;
		e !== void 0 && J.delete(e);
	}
	return J.set(e, a), a;
}
function Dt(e) {
	if (e.length > ot) throw new P("expression-budget", "Interpolation template exceeds the length limit.", 0);
	let t = [], n = 0;
	for (;;) {
		let r = e.indexOf("{{", n);
		if (r < 0) {
			n < e.length && t.push({
				kind: "text",
				value: e.slice(n)
			});
			break;
		}
		r > n && t.push({
			kind: "text",
			value: e.slice(n, r)
		});
		let i = r + 2, a = "", o = !1;
		for (; i < e.length;) {
			let t = e[i];
			if (a !== "") {
				if (t === "\\") {
					i += 2;
					continue;
				}
				t === a && (a = ""), i += 1;
			} else if (t === "\"" || t === "'") a = t, i += 1;
			else {
				if (t === "{" && e[i + 1] === "{") throw new P("expression-interpolation", "Interpolations cannot be nested.", i);
				if (t === "}" && e[i + 1] === "}") {
					o = !0;
					break;
				}
				i += 1;
			}
		}
		if (!o) throw new P("expression-interpolation", "Interpolation is missing }}.", r);
		let s = e.slice(r + 2, i);
		if (s.trim() === "") throw new P("expression-empty", "Interpolation expression is empty.", r + 2);
		t.push({
			kind: "expression",
			source: s,
			start: r + 2
		}), n = i + 2;
	}
	return t;
}
function Ot(e) {
	try {
		return Et(e.source);
	} catch (t) {
		throw t instanceof P ? new P(t.code, t.message, e.start + t.offset) : t;
	}
}
function kt(e, t, n) {
	try {
		return e.evaluate(t);
	} catch (e) {
		throw e instanceof P ? new P(e.code, e.message, n + e.offset) : e;
	}
}
function At(e, t) {
	if (e === null) return "";
	if (typeof e == "string") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new P("expression-value", "Cannot display a non-finite number.", t);
		return String(e);
	}
	if (typeof e == "boolean") return e ? "true" : "false";
	throw Array.isArray(e) ? new P("expression-type", "Cannot insert an array as text; convert it with a function such as len first.", t) : new P("expression-type", "Cannot display this value as text.", t);
}
function jt(e, t) {
	let n = [], r = 0;
	for (let i of e) {
		let e;
		if (e = i.kind === "text" ? i.value : At(kt(Ot(i), t, i.start), i.start), r += e.length, r > at) throw new P("expression-budget", "Interpolation result exceeds the length limit.", 0);
		n.push(e);
	}
	return n.join("");
}
function Mt(e, t) {
	if (typeof e != "string") throw new P("expression-interpolation", "Interpolation template must be a string.", 0);
	if (e.length > ot) throw new P("expression-budget", `Interpolation template exceeds the ${ot}-character limit.`, 0);
	return e.includes("{{") ? jt(Dt(e), t) : e;
}
function Nt(e) {
	if (typeof e != "string") throw new P("expression-interpolation", "Interpolation template must be a string.", 0);
	let t = /* @__PURE__ */ new Set();
	for (let n of Dt(e)) if (n.kind === "expression") for (let e of Ot(n).dependencies) t.add(e);
	return [...t];
}
// src/local/source/node-walk.ts
function* Pt(e, t = !1) {
	let n = [{
		nodes: e,
		index: 0
	}];
	for (; n.length;) {
		let e = n[n.length - 1];
		if (e.index === e.nodes.length) {
			n.pop(), t && e.owner && (yield e.owner);
			continue;
		}
		let r = e.nodes[e.index++];
		t || (yield r), r.children?.length ? n.push({
			nodes: r.children,
			index: 0,
			owner: r
		}) : t && (yield r);
	}
}
// src/local/evaluation/computations.ts
function Ft(e, t, n, r = "local.expression") {
	t instanceof P ? e(`${r}.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0)) : e(`${r}.invalid`, `Expression error: ${t instanceof Error ? t.message : String(t)}`, n);
}
function It(e) {
	return e instanceof P ? e : new P("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function Lt(e, t) {
	let n = new Set(e), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let t of e) r.set(t, 0);
	for (let a of e) for (let e of t(a)) {
		if (!n.has(e)) continue;
		r.set(a, (r.get(a) ?? 0) + 1);
		let t = i.get(e);
		t ? t.push(a) : i.set(e, [a]);
	}
	let a = [];
	for (let t of e) (r.get(t) ?? 0) === 0 && a.push(t);
	let o = [];
	for (let e = 0; e < a.length; e += 1) {
		let t = a[e];
		o.push(t);
		for (let e of i.get(t) ?? []) {
			let t = (r.get(e) ?? 0) - 1;
			r.set(e, t), t === 0 && a.push(e);
		}
	}
	let s = new Set(o);
	return {
		order: o,
		cyclic: e.filter((e) => !s.has(e))
	};
}
function Rt(e) {
	let t = Object.keys(e), n = new Set(t);
	return Lt(t, (t) => {
		let r = e[t];
		return r ? r.dependencies.filter((e) => n.has(e)) : [];
	});
}
function zt(e, t, n, r = /* @__PURE__ */ new Set(), i) {
	let a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = [], l = /* @__PURE__ */ new Set();
	for (let t of e) s.has(t.name) || (s.set(t.name, t), c.push(t.name));
	let u = new Set(c);
	for (let e of c) {
		let t = s.get(e), r;
		try {
			r = i?.expression(t.source) ?? Et(t.source);
		} catch (r) {
			Ft(n, r, t.expressionOffset), l.add(e);
			continue;
		}
		a.set(e, r), o.set(e, [...r.dependencies]);
	}
	for (let e of c) if (!l.has(e)) {
		for (let r of o.get(e) ?? []) if (!(u.has(r) || Object.hasOwn(t, r))) {
			n("local.computation.unknown", `Reference to undeclared parameter ${r} in computation "${e}".`, s.get(e).expressionOffset + Math.max(0, s.get(e).source.indexOf(r))), l.add(e);
			break;
		}
	}
	let d = /* @__PURE__ */ new Set();
	for (let e of c) {
		if (l.has(e)) continue;
		let i = s.get(e);
		if (i.kind === "const") for (let a of o.get(e) ?? []) {
			let o = u.has(a) ? s.get(a).kind : null;
			Object.hasOwn(t, a) ? (n("local.computation.const", `Constant "${e}" cannot depend on ${r.has(a) ? "external data" : "control parameter"} "${a}".`, i.expressionOffset + Math.max(0, i.source.indexOf(a))), d.add(e)) : o === "computed" && (n("local.computation.const", `Constant "${e}" cannot depend on computed value "${a}".`, i.expressionOffset + Math.max(0, i.source.indexOf(a))), d.add(e));
		}
	}
	let { order: f, cyclic: p } = Lt(c, (e) => o.get(e) ?? []);
	if (p.length > 0) {
		let e = new Set(p), t = [], r = /* @__PURE__ */ new Map(), i = p[0];
		for (; !r.has(i);) {
			r.set(i, t.length), t.push(i);
			let n = (o.get(i) ?? []).find((t) => e.has(t));
			if (n === void 0) break;
			i = n;
		}
		let a = r.has(i) ? t.slice(r.get(i)) : [p[0]], c = a.slice(0, 12).join(" → ") + (a.length > 12 ? " → …" : ` → ${a[0]}`);
		for (let e of a.slice(0, 100)) {
			let t = s.get(e);
			n("local.computation.cycle", `Computation "${e}" is part of a dependency cycle: ${c}.`, t.range.start, t.range.end);
		}
		for (let e of p) l.add(e);
	}
	for (let e of f) if (!l.has(e) && !(s.get(e).kind !== "const" || d.has(e)) && (o.get(e) ?? []).some((e) => u.has(e) ? s.get(e).kind === "const" && d.has(e) : !1)) {
		let t = s.get(e);
		n("local.computation.const", `Constant "${e}" indirectly depends on a value that is not a constant.`, t.expressionOffset), d.add(e);
	}
	let m = {}, h = { ...t };
	for (let e of f) {
		if (l.has(e)) continue;
		let t = s.get(e);
		if ((o.get(e) ?? []).some((e) => l.has(e))) {
			l.add(e);
			continue;
		}
		let r = a.get(e);
		try {
			let t = i ? i.infer(r, h) : r.inferType(h);
			m[e] = t, h[e] = t;
		} catch (r) {
			Ft(n, r, t.expressionOffset), l.add(e);
		}
	}
	let g = {}, _ = {};
	for (let e of f) {
		if (l.has(e) || s.get(e).kind !== "const" || d.has(e)) continue;
		let t = s.get(e), r = a.get(e);
		try {
			let i = r.evaluate(_), a = F(i);
			if (a) {
				n("local.computation.budget", `Constant "${e}": ${a}`, t.expressionOffset), l.add(e);
				continue;
			}
			g[e] = Array.isArray(i) ? i.slice() : i, _[e] = g[e];
		} catch (r) {
			let i = It(r);
			n("local.computation.expression", `Constant "${e}" cannot be evaluated: ${i.message}`, t.expressionOffset + (Number.isFinite(i.offset) ? i.offset : 0)), l.add(e);
		}
	}
	let v = {};
	for (let e of c) {
		let t = s.get(e);
		if (l.has(e) || m[e] === void 0) continue;
		let n = {
			name: e,
			kind: t.kind,
			source: t.source,
			dependencies: [...o.get(e) ?? []],
			type: m[e],
			nodeId: t.nodeId,
			range: { ...t.range }
		};
		t.kind === "const" && Object.hasOwn(g, e) && (n.value = g[e]), v[e] = n;
	}
	return {
		computations: v,
		kinds: m,
		order: f.filter((e) => !l.has(e)),
		expressions: a,
		constValues: g
	};
}
function Bt(e, t, n, r, i, a = /* @__PURE__ */ new Map()) {
	let o = {}, s = /* @__PURE__ */ new Map(), c = {};
	for (let [e, t] of Object.entries(r)) c[e] = t;
	for (let [e, t] of a) Object.defineProperty(c, e, {
		enumerable: !0,
		configurable: !0,
		get() {
			throw t;
		}
	});
	for (let [e, t] of Object.entries(i)) o[e] = t, c[e] = t;
	for (let r of t) {
		let t = e[r];
		if (!t || t.kind === "const") continue;
		let i = n.get(r);
		if (i) try {
			let e = i.evaluate(c), t = F(e);
			if (t) throw new P("expression-budget", t, 0);
			o[r] = e, c[r] = e;
		} catch (e) {
			let t = It(e);
			s.set(r, t), Object.defineProperty(c, r, {
				enumerable: !0,
				configurable: !0,
				get() {
					throw t;
				}
			});
		}
	}
	return {
		values: o,
		errors: s
	};
}
// node_modules/devlop/lib/default.js
function Vt() {}
// node_modules/mdast-util-to-string/lib/index.js
var Ht = {};
function Ut(e, t) {
	let n = t || Ht;
	return Wt(e, typeof n.includeImageAlt != "boolean" || n.includeImageAlt, typeof n.includeHtml != "boolean" || n.includeHtml);
}
function Wt(e, t, n) {
	if (Kt(e)) {
		if ("value" in e) return e.type === "html" && !n ? "" : e.value;
		if (t && "alt" in e && e.alt) return e.alt;
		if ("children" in e) return Gt(e.children, t, n);
	}
	return Array.isArray(e) ? Gt(e, t, n) : "";
}
function Gt(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) r[i] = Wt(e[i], t, n);
	return r.join("");
}
function Kt(e) {
	return !!(e && typeof e == "object");
}
// node_modules/micromark-util-chunked/index.js
function qt(e, t, n, r) {
	let i = e.length, a = 0, o;
	if (t = t < 0 ? -t > i ? 0 : i + t : t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4) o = Array.from(r), o.unshift(t, n), e.splice(...o);
	else for (n && e.splice(t, n); a < r.length;) o = r.slice(a, a + 1e4), o.unshift(t, 0), e.splice(...o), a += 1e4, t += 1e4;
}
function Jt(e, t) {
	return e.length > 0 ? (qt(e, e.length, 0, t), e) : t;
}
// node_modules/micromark-util-combine-extensions/index.js
var Yt = {}.hasOwnProperty;
function Xt(e) {
	let t = {}, n = -1;
	for (; ++n < e.length;) Zt(t, e[n]);
	return t;
}
function Zt(e, t) {
	let n;
	for (n in t) {
		let r = (Yt.call(e, n) ? e[n] : void 0) || (e[n] = {}), i = t[n], a;
		if (i) for (a in i) {
			Yt.call(r, a) || (r[a] = []);
			let e = i[a];
			Qt(r[a], Array.isArray(e) ? e : e ? [e] : []);
		}
	}
}
function Qt(e, t) {
	let n = -1, r = [];
	for (; ++n < t.length;) (t[n].add === "after" ? e : r).push(t[n]);
	qt(e, 0, 0, r);
}
// node_modules/micromark-util-normalize-identifier/index.js
function $t(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
// node_modules/micromark-util-character/index.js
var en = X(/[A-Za-z]/), tn = X(/[\dA-Za-z]/), nn = X(/[#-'*+\--9=?A-Z^-~]/);
function rn(e) {
	return e !== null && (e < 32 || e === 127);
}
var an = X(/\d/), on = X(/[\dA-Fa-f]/), sn = X(/[!-/:-@[-`{-~]/);
function cn(e) {
	return e !== null && e < -2;
}
function ln(e) {
	return e !== null && (e < 0 || e === 32);
}
function Y(e) {
	return e === -2 || e === -1 || e === 32;
}
var un = X(/\p{P}|\p{S}/u), dn = X(/\s/);
function X(e) {
	return t;
	function t(t) {
		return t !== null && t > -1 && e.test(String.fromCharCode(t));
	}
}
// node_modules/micromark-factory-space/index.js
function fn(e, t, n, r) {
	let i = r ? r - 1 : Infinity, a = 0;
	return o;
	function o(r) {
		return Y(r) ? (e.enter(n), s(r)) : t(r);
	}
	function s(r) {
		return Y(r) && a++ < i ? (e.consume(r), s) : (e.exit(n), t(r));
	}
}
function pn(e, t, n, r, i, a) {
	let o = 0;
	return s;
	function s(t) {
		return a > 0 && Y(t) ? (e.enter(r), c(t)) : l(t);
	}
	function c(t) {
		return Y(t) && o < a ? (e.consume(t), o++, c) : (e.exit(r), l(t));
	}
	function l(e) {
		return o >= i ? t(e) : n(e);
	}
}
// node_modules/micromark-util-classify-character/index.js
function mn(e) {
	if (e === null || ln(e) || dn(e)) return 1;
	if (un(e)) return 2;
}
// node_modules/micromark-util-resolve-all/index.js
function hn(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) {
		let a = e[i].resolveAll;
		a && !r.includes(a) && (t = a(t, n), r.push(a));
	}
	return t;
}
// node_modules/micromark-core-commonmark/lib/blank-line.js
var gn = {
	partial: !0,
	tokenize: _n
};
function _n(e, t, n) {
	return r;
	function r(t) {
		return Y(t) ? fn(e, i, "linePrefix")(t) : i(t);
	}
	function i(e) {
		return e === null || cn(e) ? t(e) : n(e);
	}
}
// src/local/contracts/version.ts
var vn = "local-draft-3", yn = /* @__PURE__ */ new Set([
	"table",
	"caption",
	"colgroup",
	"col",
	"thead",
	"tbody",
	"tfoot",
	"tr",
	"th",
	"td"
]), bn = {
	colgroup: /* @__PURE__ */ new Set(["span"]),
	col: /* @__PURE__ */ new Set(["span"]),
	td: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"align"
	]),
	th: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"scope",
		"abbr",
		"align"
	])
};
function xn(e, t) {
	let n = t.trim();
	return [
		"colspan",
		"rowspan",
		"span"
	].includes(e) ? /^\d{1,5}$/.test(n) && Number(n) <= (e === "rowspan" ? 65534 : 1e3) && Number(n) >= (e === "rowspan" ? 0 : 1) : e === "align" ? x(t) !== null : e !== "scope" || [
		"row",
		"col",
		"rowgroup",
		"colgroup"
	].includes(n.toLowerCase());
}
// src/local/html/html-policy.ts
var Sn = {
	b: "strong",
	strong: "strong",
	i: "emphasis",
	em: "emphasis",
	s: "delete",
	del: "delete",
	u: "underline",
	mark: "mark",
	sup: "sup",
	sub: "sub"
}, Cn = /* @__PURE__ */ new Set([
	"br",
	"hr",
	"img",
	"col"
]), wn = /* @__PURE__ */ new Set([
	"pre",
	"code",
	"script",
	"style",
	"textarea",
	"title",
	"xmp",
	"iframe",
	"noembed",
	"noframes",
	"plaintext"
]), Tn = /* @__PURE__ */ new Set([
	"id",
	"title",
	"lang",
	"dir"
]), En = {
	a: b,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...bn
};
function Dn(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") return i + 1;
	}
	return -1;
}
function On(e, t, n) {
	if (e.startsWith("<!-->", t)) return Math.min(n, t + 5);
	if (e.startsWith("<!--->", t)) return Math.min(n, t + 6);
	let r = e.indexOf("-->", t + 4);
	return r < 0 || r + 3 > n ? n : r + 3;
}
function kn(e) {
	return e.trim().replace(/[\u0000- ]+/g, "");
}
function An(e, t) {
	let n = /^([a-z][a-z0-9+.-]*):/i.exec(kn(e));
	if (!n) return !1;
	let r = n[1].toLowerCase();
	return t === "image" ? r !== "http" && r !== "https" : r !== "http" && r !== "https" && r !== "mailto" && r !== "tel";
}
function jn(e, t) {
	return t === "class" || t === "style" || /^on[a-z]/i.test(t) ? !1 : t === "align" && S.has(e) || Tn.has(t) || /^aria-[a-z0-9_.-]+$/.test(t) || /^data-[a-z0-9_.-]+$/.test(t) ? !0 : En[e]?.has(t) ?? !1;
}
function Mn(e, t) {
	return !(e === "dir" && ![
		"ltr",
		"rtl",
		"auto"
	].includes(t.trim().toLowerCase()) || e === "id" && t.trim() === "" || (e === "width" || e === "height") && !/^\d{1,6}$/.test(t.trim()) || e === "start" && !/^-?\d{1,9}$/.test(t.trim()) || !xn(e, t) || e === "href" && An(t, "link") || e === "src" && An(t, "image"));
}
function Nn(e, t) {
	return S.has(e) ? x(t) : null;
}
// src/local/parsing/parser-capabilities.ts
var Pn = Object.freeze({}), Z = Object.freeze({
	id: g,
	version: p
}), Fn = /* @__PURE__ */ new WeakMap(), In = /* @__PURE__ */ new WeakMap();
function Ln(e, t = Z) {
	if (e.length === 0) return;
	let n = t.id === Z.id && t.version === Z.version;
	if (n) {
		let t = Fn.get(e);
		if (t) return t;
	}
	let i = m({
		protocol: r,
		id: t.id,
		version: t.version,
		components: e
	});
	return n && Fn.set(e, i), i;
}
function Rn(e, t, n, r, i = "reactive-md-config/v1") {
	let a = ne(e, { legacyProfiles: t.length > 0 ? n : [] }), o = [...a.legacyKeys, ...r !== void 0 && !a.legacyKeys.some((e) => e.key === r) ? [Object.freeze({
		profile: i,
		key: r
	})] : []];
	return te(e, a, o);
}
function zn(e) {
	return w(e) || E("assembly", "must be an object."), se(e, /* @__PURE__ */ new Set([
		"protocol",
		"presets",
		"components",
		"replacementPolicy",
		"themes"
	]), "assembly"), e.protocol !== "reactive-md-assembly/v1" && E("assembly.protocol", `must be "${i}".`), re(e);
}
function Bn(e, n = [], r = []) {
	let o = ue(r);
	if (w(e) || E("config", "must be an object."), se(e, le, "config"), e.protocol === "reactive-md-config/v2") {
		let t = zn(e.assembly), r = Rn(t, n, o);
		return d(t) > 16777216 && E("config", `serialized size exceeds the ${ie}-byte budget.`), r;
	}
	e.protocol !== "reactive-md-config/v1" && E("config.protocol", `must be "${t}" (or legacy "${a}").`);
	let s = ce(e.presets, Z, o)[0] ?? Z, c = C(s, o);
	c === void 0 && E("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${s.id}" ${s.version}.`);
	let l = c.legacyKeys[0];
	l === void 0 && E("presets", `local.config.migration-unsupported: profile "${c.name}" has no legacy key mapping.`), T(c, n);
	let u = ae(e.components, n);
	u.some((e) => e.replaces !== void 0) && E("config", "replaces is not supported by reactive-md-config/v1.");
	let f = Ln(n, c.preset), p = Object.freeze({
		protocol: i,
		presets: Object.freeze(f ? [f] : []),
		components: u,
		replacementPolicy: "forbid",
		themes: Object.freeze([])
	}), m = Rn(p, n, o, n.length > 0 ? oe(c.preset, u) : void 0, l.profile);
	return d(p) > 16777216 && E("config", `serialized size exceeds the ${ie}-byte budget.`), m;
}
function Vn(e) {
	let t = In.get(e);
	if (t !== void 0) return t;
	let n = Ln(e), r = Object.freeze({
		protocol: i,
		presets: Object.freeze(n ? [n] : []),
		components: Object.freeze([]),
		replacementPolicy: "forbid",
		themes: Object.freeze([])
	}), a = ne(r).key;
	return In.set(e, a), a;
}
// src/local/configuration/options-core.ts
var Hn = [
	"enableCss",
	"enableJavaScript",
	"enableExtendedHtml"
], Un = Z;
function Q(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var Wn = "local.options.invalid.host-components", Gn = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, Kn = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), qn = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), Jn = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean"
]), Yn = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]), Xn = /* @__PURE__ */ new Set([
	"maxSyntaxNodes",
	"maxParseWork",
	"maxMarkdownDepth"
]);
function Zn(e, t, n) {
	if (!Object.hasOwn(e, t)) return {
		ok: !0,
		value: n
	};
	let r = e[t];
	if (r === void 0) return {
		ok: !0,
		value: n
	};
	if (typeof r != "number" || !Number.isSafeInteger(r) || r < 1) {
		let e = t === "maxSyntaxNodes" ? "max-syntax-nodes" : t === "maxParseWork" ? "max-parse-work" : "max-markdown-depth";
		return {
			ok: !1,
			message: `Compile option limits.${t} must be a positive safe integer.`,
			key: `local.options.invalid.${e}`
		};
	}
	return {
		ok: !0,
		value: r
	};
}
function $(e) {
	return {
		ok: !1,
		message: `Compile option hostComponents is invalid: ${e}`,
		key: Wn,
		detail: e
	};
}
function Qn(e, t) {
	if (e === void 0) return {
		ok: !0,
		binding: void 0
	};
	if (!Q(e)) return $(`${t} "binding" must be an object.`);
	for (let n of Object.keys(e)) if (![
		"kind",
		"initialRule",
		"min",
		"max",
		"step",
		"options",
		"exclusive"
	].includes(n)) return $(`${t} "binding" has unknown field "${n}".`);
	let n = e.kind;
	if (typeof n != "string" || !Jn.has(n)) return $(`${t} "binding.kind" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
	let r = { kind: n };
	if (Object.hasOwn(e, "exclusive") && e.exclusive !== void 0) {
		if (typeof e.exclusive != "boolean") return $(`${t} "binding.exclusive" must be a boolean.`);
		r.exclusive = e.exclusive;
	}
	if (Object.hasOwn(e, "initialRule") && e.initialRule !== void 0) {
		let n = e.initialRule;
		if (typeof n != "string" || ![
			"empty",
			"false",
			"nearest-zero",
			"min",
			"first-option"
		].includes(n)) return $(`${t} "binding.initialRule" is not supported.`);
		r.initialRule = n;
	}
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (!Object.hasOwn(e, n) || e[n] === void 0) continue;
		if (r.kind !== "number") return $(`${t} "binding.${n}" is only valid for number bindings.`);
		let i = e[n];
		if (typeof i != "number" || !Number.isFinite(i)) return $(`${t} "binding.${n}" must be a finite number.`);
		r[n] = i;
	}
	if (r.kind === "number") {
		if (r.step !== void 0 && !(r.step > 0)) return $(`${t} "binding.step" must be greater than 0.`);
		if (r.min !== void 0 && r.max !== void 0 && r.min > r.max) return $(`${t} "binding.min" cannot exceed "binding.max".`);
		if (r.initialRule !== void 0 && !["min", "nearest-zero"].includes(r.initialRule)) return $(`${t} "binding.initialRule" must be "min" or "nearest-zero" for number bindings.`);
		r.initialRule ??= "nearest-zero";
	}
	let i = Object.hasOwn(e, "options") && e.options !== void 0;
	if (i) {
		if (r.kind !== "string") return $(`${t} "binding.options" is only valid for string bindings.`);
		let n = e.options;
		if (!Array.isArray(n) || n.length === 0) return $(`${t} "binding.options" must be a non-empty string array.`);
		if (n.length > 64) return $(`${t} "binding.options" accepts at most 64 values.`);
		let i = /* @__PURE__ */ new Set(), a = [];
		for (let e of n) {
			if (typeof e != "string" || e === "") return $(`${t} "binding.options" must be a non-empty string array.`);
			if (e.length > 128) return $(`${t} "binding.options" value exceeds the 128-character limit.`);
			if (i.has(e)) return $(`${t} "binding.options" value "${e}" is declared more than once.`);
			i.add(e), a.push(e);
		}
		r.options = a, r.initialRule ??= "first-option";
	}
	if (r.kind === "string") {
		let e = i ? "first-option" : "empty";
		if (r.initialRule !== void 0 && r.initialRule !== e) return $(`${t} "binding.initialRule" must be "${e}" for ${i ? "choice" : "string"} bindings.`);
		r.initialRule ??= e;
	}
	if (r.kind === "boolean") {
		if (r.initialRule !== void 0 && r.initialRule !== "false") return $(`${t} "binding.initialRule" must be "false" for boolean bindings.`);
		r.initialRule ??= "false";
	}
	return {
		ok: !0,
		binding: r
	};
}
function $n(e, t) {
	let r = [], i = /* @__PURE__ */ new Map();
	if (e === void 0) return {
		ok: !0,
		hostComponents: r,
		hostByName: i
	};
	if (!Array.isArray(e)) return $("must be an array.");
	if (e.length > 32) return $("accepts at most 32 components.");
	let a = /* @__PURE__ */ new Set();
	for (let e of t) a.add(e.name.toLowerCase());
	for (let e of v) a.add(e.name.toLowerCase());
	for (let e of y) a.add(e.toLowerCase());
	a.add("theme");
	for (let t = 0; t < e.length; t += 1) {
		let o = e[t], s = `hostComponents[${t}]`;
		if (!Q(o)) return $(`${s} must be an object.`);
		let c = o.name;
		if (typeof c != "string") return $(`${s} "name" must be a string.`);
		if (c.length > 128) return $(`${s} "name" exceeds the 128-character limit.`);
		if (!Gn.test(c)) return $(`${s} "name" ${c} must use lowercase kebab-case.`);
		if (a.has(c.toLowerCase())) return $(`${s} "name" ${c} conflicts with a built-in component, HTML tag or theme.`);
		if (i.has(c.toLowerCase())) return $(`${s} "name" ${c} is declared more than once.`);
		if (typeof o.form != "string" || !qn.has(o.form)) return $(`${s} "form" must be "leaf", "inline" or "container".`);
		let l = o.form, u = Qn(o.binding, s);
		if (!u.ok) return u;
		let d = u.binding, f = o.props;
		if (!Q(f)) return $(`${s} "props" must be an object.`);
		let p = {};
		for (let e of Object.keys(f)) {
			if (!Gn.test(e)) return $(`${s} property "${e}" must use lowercase kebab-case.`);
			if (d && Yn.has(e)) return $(`${s} property "${e}" is reserved by the host binding.`);
			let t = f[e];
			if (!Q(t)) return $(`${s} property "${e}" must be an object.`);
			let r = t.kind;
			if (typeof r != "string" || !Kn.has(r)) return $(`property "${e}" has unsupported kind ${typeof r == "string" ? `"${r}"` : String(r)}.`);
			let i = { kind: r };
			for (let n of ["required", "static"]) if (Object.hasOwn(t, n) && t[n] !== void 0) {
				if (typeof t[n] != "boolean") return $(`${s} property "${e}" "${n}" must be a boolean.`);
				i[n] = t[n];
			}
			let a = Object.hasOwn(t, "enum") && t.enum !== void 0;
			if (r !== "enum") {
				if (a) return $(`${s} property "${e}" has "enum" but kind is "${r}".`);
			} else {
				let n = t.enum;
				if (!Array.isArray(n) || n.length === 0) return $(`${s} property "${e}" "enum" must be a non-empty string array.`);
				if (n.length > 64) return $(`${s} property "${e}" "enum" accepts at most 64 values.`);
				let r = /* @__PURE__ */ new Set();
				for (let t of n) {
					if (typeof t != "string") return $(`${s} property "${e}" "enum" must be a non-empty string array.`);
					if (t.length > 128) return $(`${s} property "${e}" enum value exceeds the 128-character limit.`);
					if (r.has(t)) return $(`${s} property "${e}" enum value "${t}" is declared more than once.`);
					r.add(t);
				}
				i.enum = [...n];
			}
			let o = Object.hasOwn(t, "pattern") && t.pattern !== void 0;
			if (r !== "string") {
				if (o) return $(`${s} property "${e}" has "pattern" but kind is "${r}".`);
			} else if (o) {
				let r = t.pattern;
				if (typeof r != "string") return $(`${s} property "${e}" "pattern" must be a string.`);
				if (r.length > 512) return $(`${s} property "${e}" "pattern" exceeds the 512-character limit.`);
				try {
					new RegExp(r);
				} catch {
					return $(`${s} property "${e}" "pattern" is not a valid regular expression.`);
				}
				if (!n(r)) return $(`${s} property "${e}" "pattern" uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected.`);
				i.pattern = r;
			}
			p[e] = i;
		}
		let m = {
			name: c,
			form: l,
			props: p,
			...d ? { binding: d } : {}
		};
		r.push(m), i.set(c, m);
	}
	return {
		ok: !0,
		hostComponents: r,
		hostByName: i
	};
}
function er(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function tr(e) {
	let t = e.static === !0 || e.dynamic === !1;
	if (e.kind === "enum") {
		let n = `^(?:${(e.enum ?? []).map(er).join("|")})$`;
		if (n.length <= 512) return {
			kind: "string",
			...e.required === !0 ? { required: !0 } : {},
			...t ? { static: !0 } : {},
			pattern: n
		};
	}
	let n = { kind: e.kind };
	return e.required === !0 && e.default === void 0 && (n.required = !0), t && (n.static = !0), e.enum && (n.enum = [...e.enum]), e.pattern !== void 0 && (n.pattern = e.pattern), n;
}
function nr(t) {
	let n = [], r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let a of t.components) {
		let t = {};
		for (let e of Object.keys(a.props)) t[e] = tr(a.props[e]);
		let o = e(a), s = {
			name: a.name,
			form: a.form,
			props: t,
			...o ? { binding: o } : {}
		};
		n.push(s), r.set(a.name, s), i.set(a.name, a);
	}
	return {
		hostComponents: n,
		hostByName: r,
		sdkByName: i
	};
}
function rr(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.name, t);
	let r = /* @__PURE__ */ new Map();
	for (let e of t.values()) r.set(e.name, e);
	for (let e of v) r.has(e.name) || r.set(e.name, ee(e));
	return {
		componentByName: n,
		schemaByName: r
	};
}
function ir(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name, de(n));
	return t;
}
function ar(e, t) {
	let n = t.defaults, r = new Set(n.map((e) => e.name));
	if (e !== void 0 && !Q(e)) return {
		ok: !1,
		message: "Compile options must be an object.",
		key: "local.options.invalid.object"
	};
	let i = e ?? {}, a = {
		enableCss: !1,
		enableJavaScript: !1,
		enableExtendedHtml: !1
	};
	for (let e of Hn) {
		if (!Object.hasOwn(i, e)) continue;
		let t = i[e];
		if (t !== void 0) {
			if (typeof t != "boolean") return {
				ok: !1,
				message: `Compile option ${e} must be a boolean.`,
				key: "local.options.invalid.html-flag"
			};
			a[e] = t;
		}
	}
	let o = !1;
	if (Object.hasOwn(i, "markdownBreaks")) {
		let e = i.markdownBreaks;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option markdownBreaks must be a boolean.",
				key: "local.options.invalid.markdown-breaks"
			};
			o = e;
		}
	}
	let u = !0;
	if (Object.hasOwn(i, "strict")) {
		let e = i.strict;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option strict must be a boolean.",
				key: "local.options.invalid.strict"
			};
			u = e;
		}
	}
	let d = i.limits, f = l, p = s, m = c;
	if (d !== void 0) {
		if (!Q(d)) return {
			ok: !1,
			message: "Compile option limits must be an object.",
			key: "local.options.invalid.limits"
		};
		for (let e of Object.keys(d)) if (!Xn.has(e) && d[e] !== void 0) return {
			ok: !1,
			message: `Compile option limits.${e} is not supported.`,
			key: "local.options.invalid.limits-unknown",
			detail: e
		};
		let e = Zn(d, "maxSyntaxNodes", f);
		if (!e.ok) return e;
		f = e.value;
		let t = Zn(d, "maxParseWork", p);
		if (!t.ok) return t;
		p = t.value;
		let n = Zn(d, "maxMarkdownDepth", m);
		if (!n.ok) return n;
		m = n.value;
	}
	let h = Object.hasOwn(i, "config") && i.config !== void 0, g = Object.hasOwn(i, "hostComponents") && i.hostComponents !== void 0;
	if (h && g) return {
		ok: !1,
		message: "Compile option config cannot be combined with hostComponents.",
		key: "local.options.invalid.config-conflict"
	};
	let _, v, y, b, x, S, C, w, T;
	if (h) {
		try {
			_ = t.readConfig(i.config, n);
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return {
				ok: !1,
				message: `Compile option config is invalid: ${t}`,
				key: "local.options.invalid.config",
				detail: t
			};
		}
		let e = nr(_);
		v = e.hostComponents, y = e.hostByName, b = e.sdkByName, x = _.registry;
		let r = rr(x, ir(x));
		S = r.schemaByName, C = r.componentByName, w = new Set(_.components.map((e) => e.name)), T = /* @__PURE__ */ new Set();
	} else if (g) {
		let e = $n(i.hostComponents, n);
		if (!e.ok) return e;
		v = e.hostComponents, y = e.hostByName, b = /* @__PURE__ */ new Map(), x = n;
		let t = ir(n);
		for (let [n, r] of e.hostByName) t.set(n, ee({
			...r,
			legacyHost: !0
		}));
		let r = rr(n, t);
		S = r.schemaByName, C = r.componentByName, w = new Set(e.hostByName.keys()), T = new Set(e.hostByName.keys());
	} else {
		v = [], y = /* @__PURE__ */ new Map(), b = /* @__PURE__ */ new Map(), x = n;
		let e = rr(n, ir(n));
		S = e.schemaByName, C = e.componentByName, w = /* @__PURE__ */ new Set(), T = /* @__PURE__ */ new Set();
	}
	return {
		ok: !0,
		maxSyntaxNodes: f,
		maxParseWork: p,
		maxMarkdownDepth: m,
		html: a,
		htmlActive: a.enableCss || a.enableJavaScript || a.enableExtendedHtml,
		markdownBreaks: o,
		strict: u,
		hostComponents: v,
		hostByName: y,
		..._ ? { config: _ } : {},
		sdkByName: b,
		registry: x,
		componentByName: C,
		schemaByName: S,
		defaultComponentNames: r,
		externalComponentNames: w,
		legacyHostNames: T,
		componentConfigKey: _ ? t.configKey(_) : t.defaultConfigKey,
		capabilities: t.capabilities ?? Pn,
		...t.preset ? { preset: t.preset } : {}
	};
}
function or(e, t = [], n) {
	let r = t.length > 0 ? Un : void 0;
	return ar(e, {
		defaults: t,
		...r ? { preset: r } : {},
		defaultConfigKey: Vn(t),
		readConfig: Bn,
		configKey: (e) => e.key,
		...n ? { capabilities: n } : {}
	});
}
function sr(e) {
	return e.componentConfigKey;
}
// src/local/evaluation/validation.ts
var cr = "local.validation.failed", lr = "local.validation.expression", ur = "Validation failed.";
function dr(e) {
	return e.length > 2e3 ? `${e.slice(0, h - 1)}…` : e;
}
function fr(e) {
	let t = e.trim();
	return t ? t.split(/\s+/) : [];
}
function pr(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function mr(e) {
	if (!e || typeof e != "object") return !1;
	let t = e, n = t.range;
	return typeof t.expression == "string" && typeof t.message == "string" && Array.isArray(t.fields) && !!n && Number.isFinite(n.start) && Number.isFinite(n.end);
}
function hr(e, t, n, r, i) {
	let a = e.length, o = Math.max(0, Math.min(a, Math.trunc(n.start))), s = Math.max(o + 1, Math.min(a, Math.trunc(n.end))), c = 0, l = Math.max(0, t.length - 1);
	for (; c < l;) {
		let e = Math.ceil((c + l) / 2);
		t[e] <= o ? c = e : l = e - 1;
	}
	return {
		code: r,
		message: i,
		severity: "error",
		range: {
			start: o,
			end: s
		},
		line: c + 1,
		column: o - t[c] + 1
	};
}
export { Qe as $, en as A, un as B, xn as C, mn as D, hn as E, on as F, qt as G, $t as H, sn as I, Bt as J, Ut as K, cn as L, nn as M, rn as N, fn as O, an as P, P as Q, ln as R, yn as S, gn as T, Xt as U, dn as V, Jt as W, zt as X, Rt as Y, Pt as Z, On as _, mr as a, pe as at, Mn as b, hr as c, or as d, Et as et, ar as f, Nn as g, Cn as h, dr as i, Nt as it, tn as j, pn as k, Hn as l, wn as m, cr as n, F as nt, pr as o, fe as ot, Sn as p, Vt as q, ur as r, lt as rt, fr as s, lr as t, Mt as tt, sr as u, Dn as v, vn as w, bn as x, jn as y, Y as z };
