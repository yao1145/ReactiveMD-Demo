/**
 * Browser adapter for the component-state persistence port.
 *
 * This module belongs to the browser layer, not the pure `reactive-md/runtime`
 * entry: it reads `localStorage` lazily and never at import time, so server
 * builds can import it without touching `window`.
 */
import type { LocalComponentStateStorage } from '../component-state.js';
/** The subset of the Web Storage API this adapter needs. */
export interface LocalWebStorageLike {
    getItem(key: string): string | null;
    setItem(key: string, value: string): void;
    removeItem(key: string): void;
}
export interface CreateLocalBrowserStateStorageOptions {
    /**
     * Document identity used to scope the storage key. Use the same value the
     * runtime receives as `documentId`; a source digest is a valid identity but
     * changes when the source changes.
     */
    readonly documentId: string;
    /** Defaults to `globalThis.localStorage`. */
    readonly storage?: LocalWebStorageLike;
    /** Defaults to `reactive-md:component-state:v1:`. */
    readonly keyPrefix?: string;
}
export interface LocalBrowserStateStorage extends LocalComponentStateStorage {
    /** The exact key this backend reads and writes. */
    readonly key: string;
}
export declare const LOCAL_COMPONENT_STATE_STORAGE_PREFIX = "reactive-md:component-state:v1:";
/** Anything that can write pending component state now. */
export interface ComponentStateFlushTarget {
    flush(): void;
}
interface PageLifecycleTarget {
    addEventListener(type: string, listener: () => void): void;
    removeEventListener(type: string, listener: () => void): void;
}
interface VisibilityLifecycleTarget extends PageLifecycleTarget {
    readonly visibilityState: string;
}
export interface ComponentStatePageLifecycle {
    /** Window-like object that receives `pagehide`; defaults to the global window. */
    readonly page?: PageLifecycleTarget;
    /** Document-like object that receives `visibilitychange`; defaults to the global document. */
    readonly document?: VisibilityLifecycleTarget;
}
/**
 * Flush pending component-state writes when the page is hidden or unloaded.
 * Timers stop in the background, so the last coalesced save would otherwise
 * wait for the next visible frame. Returns a disposer that only unsubscribes;
 * the runtime flushes on disposal.
 */
export declare function flushComponentStateOnPageHide(target: ComponentStateFlushTarget, lifecycle?: ComponentStatePageLifecycle): () => void;
/**
 * Persist one document's component-state sidecar in Web Storage. The backend
 * performs no cross-tab synchronization: the registry reads once at creation
 * and hands this backend a complete sidecar whenever it writes. Create the
 * registry with `writeDelayMs` to coalesce high-frequency saves.
 */
export declare function createLocalBrowserStateStorage(options: CreateLocalBrowserStateStorageOptions): LocalBrowserStateStorage;
export {};
