import { j as e } from "./preset-core-CKc5YXSM.js";
// src/local/configuration/component-kernel.ts
function t(e, t, n) {
	if (!e) return;
	let r = e, i = e.options ?? [], a = e.constraints ?? (r.min !== void 0 || r.max !== void 0 || r.step !== void 0 ? {
		...r.min === void 0 ? {} : { min: { literal: r.min } },
		...r.max === void 0 ? {} : { max: { literal: r.max } },
		...r.step === void 0 ? {} : { step: { literal: r.step } }
	} : void 0), o = e.family ?? (e.kind === "number" ? "number" : e.kind === "boolean" ? "boolean" : e.kind === "array" ? "multi-select" : i.length ? "choice" : "text");
	return {
		...e,
		family: o,
		bind: e.bind ?? "bind",
		initial: e.initial ?? "initial",
		initialRule: e.initialRule ?? n ?? (t === "value" ? e.kind === "boolean" ? "false" : e.kind === "number" ? "nearest-zero" : "empty" : "nearest-zero"),
		...a ? { constraints: a } : {}
	};
}
function n(e) {
	return e.bindings.value;
}
function r(e) {
	let t = [];
	for (let [n, r] of Object.entries(e.bindings)) n !== "value" && t.push({
		...r,
		slot: n
	});
	return t;
}
function i(e) {
	return e.slotRelations;
}
function a(e) {
	return e.structure ? e.structure : {
		rule: e.childRule ?? (e.form === "leaf" ? "none" : e.form === "inline" ? "inline" : "any"),
		label: e.label ?? "none",
		...e.parent ? { parents: e.parent } : {}
	};
}
function o(e) {
	return e.structure;
}
function s(e) {
	return e.rules ?? [];
}
function c(e, t) {
	for (let n of s(e)) if (n.kind === t) return n;
}
function l(e, t) {
	return s(e).filter((e) => e.kind === t);
}
function u(e) {
	return e.legacyHost === !0;
}
function d(e, t) {
	if (t === e.bind) return e.options, {
		kind: "string",
		static: !0
	};
	switch (e.kind) {
		case "number": return {
			kind: "number",
			static: !0
		};
		case "boolean": return {
			kind: "boolean",
			static: !0
		};
		default: return {
			kind: "string",
			static: !0
		};
	}
}
function f(e, t) {
	let n = { ...e.props }, r = t?.bindings ?? e.bindings, i = r?.value ?? e.binding, a = r ? Object.entries(r).filter(([e]) => e !== "value").map(([, e]) => e) : (e.slots ?? []).map((e) => ({
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule ?? "nearest-zero"
	}));
	for (let e of i ? [i] : []) Object.hasOwn(n, e.bind) || (n[e.bind] = d(e, e.bind)), Object.hasOwn(n, e.initial) || (n[e.initial] = d(e, e.initial)), Object.hasOwn(n, "disabled") || (n.disabled = {
		kind: "boolean",
		dynamic: !0,
		default: !1
	});
	for (let e of a) Object.hasOwn(n, e.bind) || (n[e.bind] = d(e, e.bind)), Object.hasOwn(n, e.initial) || (n[e.initial] = d(e, e.initial));
	return {
		...e,
		props: n,
		...t?.structure ?? e.structure ? { structure: t?.structure ?? e.structure } : {},
		...t?.rules ?? e.rules ? { rules: t?.rules ?? e.rules } : {},
		...r ? { bindings: r } : {},
		...t?.slotRelations ?? e.slotRelations ? { slotRelations: t?.slotRelations ?? e.slotRelations } : {},
		...t?.legacyHost === !0 || e.legacyHost === !0 ? { legacyHost: !0 } : {}
	};
}
function p(e, n) {
	let r = f(e, n), i = {}, o = n?.bindings ?? e.bindings;
	if (o) for (let [n, r] of Object.entries(o)) {
		let a = t(r, n, n === "value" ? e.initialRule : void 0);
		a && (i[n] = a);
	}
	else if (e.binding) {
		let n = t(e.binding, "value", e.initialRule);
		n && (i.value = n);
	}
	for (let n of e.slots ?? []) {
		if (i[n.name] !== void 0) continue;
		let e = t({
			kind: n.kind,
			family: n.family,
			bind: n.bind,
			initial: n.initial,
			...n.exclusive === void 0 ? {} : { exclusive: n.exclusive },
			...n.initialRule === void 0 ? {} : { initialRule: n.initialRule }
		}, n.name);
		e && (i[n.name] = e);
	}
	let s = {};
	for (let [e, t] of Object.entries(r.props)) {
		let n = t.values ?? t.enum;
		if (n === void 0) {
			s[e] = t;
			continue;
		}
		let { enum: r, ...i } = t;
		s[e] = {
			...i,
			values: n
		};
	}
	return Object.freeze({
		name: r.name,
		form: r.form,
		props: Object.freeze(s),
		bindings: Object.freeze(i),
		structure: a(r),
		rules: r.rules ?? [],
		slotRelations: r.slotRelations ?? [],
		legacyHost: r.legacyHost === !0
	});
}
function m(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function h(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "string" ? r.value : void 0;
	let i = e.props[n]?.default;
	return typeof i == "string" ? i : void 0;
}
function g(e, t, n) {
	return n === void 0 ? t : e[n]?.offset ?? t;
}
function _(e, t, n) {
	let r = [], i = e.name, a = i, o = (e, t, n, i, a) => {
		r.push({
			code: e,
			message: t,
			start: n,
			key: i,
			...a ? { params: a } : {}
		});
	};
	for (let r of s(e)) switch (r.kind) {
		case "numeric-range": {
			let s = m(e, t, r.min), c = m(e, t, r.max);
			s !== void 0 && c !== void 0 && (r.order === "increasing" ? !(s < c) : s > c) && o("local.constraint", r.order === "increasing" ? `${i} ${r.min ?? "min"} must be less than ${r.max ?? "max"}.` : `Component <${i}> min cannot exceed max.`, g(t, n.start, r.min), r.order === "increasing" ? "local.constraint.plot-range" : "local.constraint.number-min-max", r.order === "increasing" ? void 0 : { component: a });
			let l = m(e, t, r.step);
			l === void 0 || l > 0 && Number.isFinite(l) || o("local.constraint", `Component <${i}> step must be greater than 0.`, g(t, n.start, r.step), "local.constraint.number-step", { component: a });
			let u = r.integer;
			if (u !== void 0) {
				let r = m(e, t, u);
				r !== void 0 && !Number.isInteger(r) && o("local.constraint", `Attribute ${u} must be a whole number.`, g(t, n.start, u), "local.constraint.integer", {
					name: u,
					component: a
				});
			}
			if (r.positiveInteger !== void 0) {
				let i = m(e, t, r.positiveInteger);
				i !== void 0 && (!Number.isInteger(i) || i <= 0) && o("local.constraint", `Attribute ${r.positiveInteger} must be a positive whole number.`, g(t, n.start, r.positiveInteger), "local.constraint.positive-integer", {
					name: r.positiveInteger,
					component: a
				});
			}
			break;
		}
		case "text-length": {
			let i = m(e, t, r.min) ?? 0, a = m(e, t, r.max);
			a !== void 0 && a < i && o("local.constraint", "max-length cannot be less than min-length.", g(t, n.start, r.max), "local.constraint.length-order");
			break;
		}
		case "date-bounds": {
			let i = h(e, t, r.min), a = h(e, t, r.max);
			i !== void 0 && !y(i) && o("local.attribute.type", `Date lower bound ${i} is not a valid YYYY-MM-DD.`, g(t, n.start, r.min), "local.attribute.type.date-lower", { value: i }), a !== void 0 && !y(a) && o("local.attribute.type", `Date upper bound ${a} is not a valid YYYY-MM-DD.`, g(t, n.start, r.max), "local.attribute.type.date-upper", { value: a }), i && a && i > a && o("local.constraint", "Date min cannot be later than max.", g(t, n.start, r.min), "local.constraint.date-order");
			break;
		}
		case "nonempty": {
			let e = t[r.attribute];
			if (!e || e.dynamic) break;
			(typeof e.value == "string" ? e.value : String(e.raw ?? "")).trim() || o("local.constraint", `Attribute ${r.attribute} of <${i}> cannot be empty.`, e.offset, `local.constraint.${i}-${r.attribute}`, {
				name: r.attribute,
				component: a
			});
			break;
		}
		case "progress-bounds": {
			let n = m(e, t, r.max) ?? r.defaultMax, i = t[r.value];
			i && !i.dynamic && typeof i.value == "number" && (i.value < 0 || i.value > n) && o("local.constraint", `progress value must be between 0 and ${n}, got ${i.value}.`, i.offset, "local.constraint.progress-range", {
				max: n,
				value: i.value
			});
			break;
		}
		case "timer-duration": {
			let i = m(e, t, r.attribute) ?? r.default;
			(!Number.isInteger(i) || i <= 0) && o("local.constraint", "timer duration must be a positive whole number of seconds.", g(t, n.start, r.attribute), "local.constraint.timer-duration");
			break;
		}
		case "option-count": {
			let a = m(e, t, r.max);
			a !== void 0 && (!Number.isInteger(a) || a < 0) && o("local.constraint", `${i} ${r.max} must be a nonnegative whole number.`, g(t, n.start, r.max), `local.constraint.${i}`);
			break;
		}
		case "selection-requires":
			if (Object.hasOwn(t, r.key)) break;
			for (let e of r.attributes) {
				let n = t[e];
				n && o("local.selection.key", `<${i}> ${e} requires a key attribute naming the selection column.`, n.offset, "local.selection.key.required", {
					component: a,
					name: e
				});
			}
	}
	return r;
}
var v = /^(\d{4})-(\d{2})-(\d{2})$/;
function y(e) {
	if (e === "") return !0;
	let t = v.exec(e);
	if (!t) return !1;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	return n < 1 || r < 1 || r > 12 || i < 1 ? !1 : i <= [
		31,
		n % 4 == 0 && n % 100 != 0 || n % 400 == 0 ? 29 : 28,
		31,
		30,
		31,
		30,
		31,
		31,
		30,
		31,
		30,
		31
	][r - 1];
}
function b(e, t, n) {
	if (n === void 0) return;
	if ("literal" in n) return n.literal;
	let r = t[n.prop];
	if (r) return r.dynamic ? void 0 : typeof r.value == "number" ? r.value : void 0;
	let i = e.props[n.prop]?.default;
	return typeof i == "number" ? i : void 0;
}
function x(e, t, n) {
	let r = t.constraints;
	if (!r) return { step: 1 };
	let i = b(e, n, r.min), a = b(e, n, r.max), o = b(e, n, r.step) ?? 1, s = (e) => {
		if (e === void 0 || !("prop" in e)) return;
		let t = n[e.prop];
		return t?.dynamic ? (t.expression ?? "").trim() : void 0;
	}, c = s(r.min), l = s(r.max);
	return {
		...i === void 0 ? {} : { min: i },
		...a === void 0 ? {} : { max: a },
		step: o > 0 ? o : 1,
		...c === void 0 ? {} : { dynamicMin: c },
		...l === void 0 ? {} : { dynamicMax: l }
	};
}
function S(e, t, n) {
	return b(e, n, t.maxItems);
}
function C(e, t, n) {
	let r = n === "min" ? e.dynamicMin : e.dynamicMax, i = n === "min" ? t.dynamicMin : t.dynamicMax;
	return r !== void 0 || i !== void 0 ? r === i : e[n] === t[n];
}
function w(e) {
	return `[${e.dynamicMin === void 0 ? e.min === void 0 ? "-∞" : String(e.min) : `{{ ${e.dynamicMin} }}`}, ${e.dynamicMax === void 0 ? e.max === void 0 ? "∞" : String(e.max) : `{{ ${e.dynamicMax} }}`}] / ${e.step}`;
}
function T(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= 1e-9 * Math.max(1, Math.abs(r));
}
function E(e, t, n) {
	let r = e ?? 0, i = e === void 0 ? -Infinity : Math.ceil((e - r) / n), a = t === void 0 ? Infinity : Math.floor((t - r) / n);
	if (i > a) return null;
	let o = -r / n, s = null;
	for (let e of [Math.floor(o), Math.ceil(o)]) {
		let t = Math.min(a, Math.max(i, e));
		if (!Number.isFinite(t)) continue;
		if (s === null) {
			s = t;
			continue;
		}
		let o = r + t * n, c = r + s * n;
		(Math.abs(o) < Math.abs(c) || Math.abs(o) === Math.abs(c) && o < c) && (s = t);
	}
	if (s === null) return null;
	let c = r + s * n;
	return e !== void 0 && c < e || t !== void 0 && c > t ? null : c;
}
function D(e, t, n) {
	switch (e) {
		case "empty": return { value: "" };
		case "false": return { value: !1 };
		case "min": return { value: t?.min ?? 0 };
		case "nearest-zero": {
			let e = t ?? { step: 1 }, n = E(e.min, e.max, e.step);
			return n === null ? { error: "no-step" } : { value: n };
		}
		case "duration": return { value: t?.max ?? 60 };
		case "first-option":
		case "first-tab":
		case "first-step":
		case "first-node": return { value: n[0] ?? "" };
		case "checked": return { value: [] };
		case "empty-array": return { value: [] };
		case "max-step": {
			let e = t ?? { step: 1 }, n = e.min ?? 0, r = (e.max ?? n) - n, i = n + Math.max(0, Math.floor(r / e.step + 1e-9)) * e.step;
			return { value: Math.min(e.max ?? i, Math.max(e.min ?? i, i)) };
		}
		case "none": return { value: "" };
		default: return { error: "cannot-derive" };
	}
}
function O(e) {
	switch (e) {
		case "choice":
		case "multi-select": return "options";
		case "tabs": return "tabs";
		case "steps": return "steps";
		case "selection": return "selection";
		case "diagram": return "diagram-nodes";
		case "checklist": return "checklist";
		default: return;
	}
}
// src/sdk/registry-core.ts
var k = /* @__PURE__ */ new WeakMap();
function A(e) {
	return {
		kind: e.kind,
		...e.required === !0 ? { required: !0 } : {},
		...e.static === !0 ? { static: !0 } : {},
		...e.dynamic === void 0 ? {} : { dynamic: e.dynamic },
		...e.default === void 0 ? {} : { default: e.default },
		...e.nullable === !0 ? { nullable: !0 } : {},
		...e.enum ? { values: [...e.enum] } : {},
		...e.pattern === void 0 ? {} : { pattern: e.pattern },
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.integer === !0 ? { integer: !0 } : {},
		...e.positive === !0 ? { positive: !0 } : {},
		...e.color === !0 ? { color: !0 } : {},
		...e.coerce === void 0 ? {} : { coerce: e.coerce }
	};
}
function j(e) {
	return {
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule,
		required: e.required === !0,
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...e.options ? { options: e.options } : {},
		...e.constraints ? { constraints: e.constraints } : {},
		...e.maxItems ? { maxItems: e.maxItems } : {},
		...e.requiresAttributes ? { requiresAttributes: e.requiresAttributes } : {},
		...e.compare ? { compare: e.compare } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function M(e, t) {
	if (t === e.bind) return {
		kind: "string",
		static: !0
	};
	switch (e.kind) {
		case "number": return {
			kind: "number",
			static: !0
		};
		case "boolean": return {
			kind: "boolean",
			static: !0
		};
		default: return {
			kind: "string",
			static: !0
		};
	}
}
function N(e, t) {
	if (e === void 0) return t === "leaf" ? "none" : "any";
	switch (e.rule) {
		case "components": return e.child === "card" ? "cards" : e.child === "disclosure" ? "disclosures" : e.child === "column" ? "columns" : "any";
		default: return e.rule;
	}
}
function P(t) {
	let n = k.get(t);
	if (n !== void 0) return n;
	let r = t.bindings ?? {}, i = t.structure ?? e(t.children), a = r.value, o = [];
	for (let [e, t] of Object.entries(r)) e !== "value" && o.push(Object.freeze({
		name: e,
		bind: t.bind,
		initial: t.initial,
		kind: t.kind,
		family: t.family,
		exclusive: t.exclusive === !0,
		initialRule: t.initialRule
	}));
	let s = {};
	for (let [e, n] of Object.entries(t.props)) s[e] = A(n);
	for (let e of Object.values(r)) {
		let t = [e.bind, e.initial];
		for (let n of t) Object.hasOwn(s, n) || (n !== e.initial || e.initialRule !== "checked" && e.initialRule !== "duration") && (s[n] = M(e, n));
	}
	let c = Object.freeze({
		name: t.name,
		form: t.form,
		props: Object.freeze(s),
		...a ? { binding: Object.freeze(j(a)) } : {},
		...Object.keys(r).length ? { bindings: Object.freeze({ ...r }) } : {},
		...o.length ? { slots: Object.freeze(o) } : {},
		...i ? { structure: i } : {},
		...t.rules ? { rules: t.rules } : {},
		...t.slotRelations ? { slotRelations: t.slotRelations } : {},
		...t.legacyHost === !0 ? { legacyHost: !0 } : {},
		childRule: N(i, t.form),
		label: i?.label ?? "none",
		...i?.parents ? { parent: i.parents } : {},
		...a ? { initialRule: a.initialRule } : {}
	});
	return k.set(t, c), c;
}
function F(e) {
	return P(e);
}
var I = /* @__PURE__ */ new WeakMap();
function L(t) {
	let n = I.get(t);
	if (n !== void 0) return n;
	let r = t.structure ?? e(t.children), i = p({
		name: t.name,
		form: t.form,
		props: t.props,
		childRule: N(r, t.form)
	}, {
		...r ? { structure: r } : {},
		...t.rules ? { rules: t.rules } : {},
		...t.bindings ? { bindings: t.bindings } : {},
		...t.slotRelations ? { slotRelations: t.slotRelations } : {},
		...t.legacyHost ? { legacyHost: !0 } : {}
	});
	return I.set(t, i), i;
}
export { i as _, _ as a, n as b, S as c, O as d, c as f, r as g, C as h, y as i, x as l, l as m, F as n, D as o, s as p, L as r, w as s, P as t, T as u, o as v, p as x, u as y };
