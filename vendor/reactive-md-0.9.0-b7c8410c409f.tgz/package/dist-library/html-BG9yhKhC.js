import { E as e, O as t, P as n, T as r, k as i } from "./config-validation-F47AcE6o.js";
import { M as a, N as o, P as s } from "./validation-Dds_T0Wx.js";
import { a as c, c as l, l as u, o as d } from "./parser-standard-L8ypEr7g.js";
// src/local/html/html.ts
var f = "http://www.w3.org/1999/xhtml", p = /* @__PURE__ */ new Set([
	"b",
	"strong",
	"i",
	"em",
	"s",
	"del",
	"u",
	"mark",
	"sup",
	"sub",
	"br",
	"hr",
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"div",
	"span",
	"details",
	"summary",
	"blockquote",
	"code",
	"pre",
	"ul",
	"ol",
	"li",
	"a",
	"img",
	...o
]), m = /* @__PURE__ */ new Set([
	"html",
	"head",
	"body"
]), h = /* @__PURE__ */ new Set([
	"frameset",
	"frame",
	"noframes",
	"applet"
]), ee = /* @__PURE__ */ new Set([
	"animate",
	"animatemotion",
	"animatetransform",
	"set",
	"discard"
]), g = /* @__PURE__ */ new Set(/* @__PURE__ */ "alignment-baseline.baseline-shift.clip.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-rendering.cursor.direction.display.dominant-baseline.fill.fill-opacity.fill-rule.filter.flood-color.flood-opacity.font.font-family.font-size.font-size-adjust.font-stretch.font-style.font-variant.font-weight.glyph-orientation-horizontal.glyph-orientation-vertical.image-rendering.kerning.letter-spacing.lighting-color.marker.marker-end.marker-mid.marker-start.mask.opacity.overflow.paint-order.pointer-events.shape-rendering.stop-color.stop-opacity.stroke.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke-width.text-anchor.text-decoration.text-rendering.transform-origin.unicode-bidi.vector-effect.visibility.word-spacing.writing-mode".split(".")), _ = /* @__PURE__ */ new Set([
	"id",
	"class",
	"title",
	"lang",
	"dir"
]), v = /* @__PURE__ */ new Set([
	"align",
	"bgcolor",
	"background",
	"face",
	"text",
	"link",
	"alink",
	"vlink",
	"border",
	"cellpadding",
	"cellspacing",
	"frame",
	"rules",
	"hspace",
	"vspace"
]), y = {
	a: e,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...a,
	script: /* @__PURE__ */ new Set([
		"type",
		"src",
		"async",
		"defer",
		"nomodule",
		"crossorigin",
		"integrity",
		"referrerpolicy"
	]),
	style: /* @__PURE__ */ new Set(["type", "media"]),
	link: /* @__PURE__ */ new Set([
		"rel",
		"href",
		"type",
		"media",
		"crossorigin",
		"integrity",
		"referrerpolicy",
		"disabled"
	])
}, b = {
	href: "link",
	action: "form",
	formaction: "form",
	poster: "image",
	background: "image",
	data: "frame",
	src: "source",
	cite: "link",
	longdesc: "link"
}, te = 4, ne = 32, x = 64, S = class extends Error {
	start;
	end;
	limit;
	constructor(e, t, n) {
		super(`Syntax nodes exceed the limit of ${n}.`), this.start = e, this.end = t, this.limit = n, this.name = "HtmlBudgetError";
	}
};
function C(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function w(e, t, n) {
	let r = e.source.length, i = Math.max(0, Math.min(r, t)), a = Math.max(i, Math.min(r, Math.max(i, n))), o = 0, s = e.lines.starts.length - 1;
	for (; o < s;) {
		let t = Math.ceil((o + s) / 2);
		e.lines.starts[t] <= i ? o = t : s = t - 1;
	}
	return {
		start: i,
		end: a,
		line: o + 1,
		column: i - e.lines.starts[o] + 1
	};
}
function T(e, t, r, i, a, o) {
	if (e.diagnostics.length >= 100) return;
	let s = w(e, i, a), c = n(o?.key ?? t, o?.params);
	e.diagnostics.push({
		code: t,
		message: r,
		severity: "warning",
		range: {
			start: s.start,
			end: s.end
		},
		line: s.line,
		column: s.column,
		messageKey: c.key,
		...c.params ? { params: c.params } : {}
	});
}
function E(e, t) {
	let n = e.sourceCodeLocation, r = n && Number.isInteger(n.startOffset) ? n.startOffset : 0, i = n && Number.isInteger(n.endOffset) ? n.endOffset : r;
	return {
		start: Math.max(0, Math.min(t.source.length, r)),
		end: Math.max(0, Math.min(t.source.length, i))
	};
}
function re(e, t, n) {
	let r = e.sourceCodeLocation?.attrs, i = r && (r[t.name] ?? (t.prefix ? r[`${t.prefix}:${t.name}`] : void 0));
	return i && Number.isInteger(i.startOffset) && Number.isInteger(i.endOffset) ? {
		start: i.startOffset,
		end: i.endOffset
	} : E(e, n);
}
function D(e, t, n) {
	if (e.budget.nodes += 1, e.budget.nodes > e.maxNodes) throw new S(t, n, e.maxNodes);
}
function O(e, t) {
	let n = E(e, t);
	return t.source.slice(n.start, n.end).replace(/\u0000/g, "�");
}
function k(e) {
	return u.createTextNode(e.replace(/\u0000/g, "�"));
}
function ie(e) {
	return e.replace(/[\u0000- \u007f-\u009f]+/g, "");
}
function ae(e) {
	let t = /^([a-z][a-z0-9+.-]*):/i.exec(ie(e));
	return t ? t[1].toLowerCase() : null;
}
function A(e, t) {
	let n = e.trim();
	if (n === "") return !0;
	let r = ae(n);
	return r === null ? !0 : r === "javascript" || r === "vbscript" ? !1 : r === "data" ? t === "image" && /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/i.test(n.replace(/\s+/g, "")) : r === "http" || r === "https" || t === "link" && (r === "mailto" || r === "tel");
}
function j(e) {
	return Object.hasOwn(b, e) || e === "xlink:href";
}
function M(e, t) {
	return (e === "href" || e === "xlink:href") && t === "image" ? "image" : e === "href" && t === "base" ? "source" : e === "xlink:href" ? "link" : e === "src" ? t === "img" || t === "image" ? "image" : t === "iframe" || t === "frame" || t === "embed" ? "frame" : t === "audio" || t === "video" || t === "source" || t === "track" ? "media" : "source" : b[e] ?? "source";
}
function N(e, t) {
	return _.has(t) || t.startsWith("aria-") || t.startsWith("data-") ? !0 : y[e]?.has(t) ?? !1;
}
function P(e) {
	return /^on[a-z]/i.test(e);
}
function F(e, t) {
	return g.has(e) ? !0 : t && v.has(e);
}
function I(e) {
	return [...e.enableJavaScript ? ["allow-scripts"] : [], ...e.enableExtendedHtml ? ["allow-forms"] : []].join(" ");
}
function L(e, t) {
	return e.split(/\s+/).filter(Boolean).filter((e) => {
		let n = e.toLowerCase();
		return n === "allow-same-origin" || n === "allow-top-navigation" || n === "allow-top-navigation-by-user-activation" || n === "allow-parent-navigation" || n === "allow-popups" || n === "allow-popups-to-escape-sandbox" || n === "allow-modals" || n === "allow-downloads" || n === "allow-orientation-lock" || n === "allow-pointer-lock" || n === "allow-presentation" ? !1 : n === "allow-forms" ? t.enableExtendedHtml : n === "allow-scripts" && t.enableJavaScript;
	}).join(" ");
}
function R(e, t) {
	for (let n of e.childNodes) if (u.isElementNode(n) && n.tagName.toLowerCase() === t) return n;
	return null;
}
function z(e) {
	let t = "";
	for (let n of e.childNodes) t += l(n, { scriptingEnabled: !1 });
	return t;
}
function B(e) {
	return e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function V(e, t, n = !1) {
	let r = e.enableExtendedHtml, i = t === void 0 ? r ? [
		"about:",
		"data:",
		"blob:"
	] : [] : ["about:", ...U(t)];
	return [
		"default-src 'none'",
		n ? "base-uri 'none'" : r ? "base-uri 'self' http: https:" : "base-uri 'none'",
		n ? "form-action 'none'" : r ? "form-action http: https:" : "form-action 'none'",
		"object-src 'none'",
		"connect-src 'none'",
		"media-src 'none'",
		"font-src data:",
		"img-src data:",
		e.enableCss ? "style-src 'unsafe-inline'" : "style-src 'none'",
		e.enableJavaScript ? "script-src 'unsafe-inline'" : "script-src 'none'",
		i.length === 0 ? "frame-src 'none'" : `frame-src ${i.join(" ")}`
	].join("; ");
}
function H(e) {
	if (typeof e != "string") return null;
	let t = /^https:\/\/([a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)*)(?::([0-9]{1,5}))?\/?$/i.exec(e.trim());
	if (!t) return null;
	let n = t[2] ? Number(t[2]) : 443;
	if (!Number.isInteger(n) || n < 1 || n > 65535) return null;
	let r = t[1].toLowerCase();
	return n === 443 ? `https://${r}` : `https://${r}:${n}`;
}
function U(e) {
	let t = [];
	if (!Array.isArray(e)) return t;
	for (let n of e.slice(0, ne)) {
		let e = H(n);
		e && !t.includes(e) && t.push(e);
	}
	return t;
}
function W(e) {
	return new Set(U(e ?? []));
}
function oe(e, t) {
	let n = e.trim();
	if (/^about:blank$/i.test(n)) return !0;
	if (n === "") return !1;
	let r;
	try {
		r = new URL(n);
	} catch {
		return !1;
	}
	if (r.protocol !== "https:" || r.username !== "" || r.password !== "") return !1;
	let i = H(r.origin);
	return i !== null && t.has(i);
}
var G = 65536;
function se(e) {
	let t = e.trim();
	if (!/^data:/i.test(t)) return;
	if (t.length > G) return null;
	let n = t.indexOf(",");
	if (n < 0) return null;
	let r = t.slice(5, n).toLowerCase(), i = t.slice(n + 1), a = r.endsWith(";base64"), o = (a ? r.slice(0, -7) : r).split(";")[0].trim();
	if (o !== "text/html" && o !== "application/xhtml+xml") return null;
	let s;
	try {
		if (a) {
			let e = atob(i.replace(/\s+/g, "")), t = new Uint8Array(e.length);
			for (let n = 0; n < e.length; n += 1) t[n] = e.charCodeAt(n);
			s = new TextDecoder().decode(t);
		} else s = decodeURIComponent(i);
	} catch {
		return null;
	}
	return s.length > G ? null : s;
}
function K(e, t) {
	let n = R(t, "html"), r = n ? R(n, "head") : null, i = n ? R(n, "body") : null, a = r ? z(r) : "", o = z(i || n || t);
	e.bodyFallbacks.length > 0 && (o = e.bodyFallbacks.map((e) => l(k(e), { scriptingEnabled: !1 })).join("") + o);
	let s = B(V(e.policy, e.frameOrigins ? [...e.frameOrigins] : void 0, e.fragment)), c = (e) => (e?.attrs ?? []).map((e) => ` ${e.prefix ? `${e.prefix}:` : ""}${e.name}="${B(e.value)}"`).join("");
	return `<!doctype html><html${c(n)}><head${c(r)}><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${s}">${a}</head><body${c(i)}>${o}</body></html>`;
}
function q(e) {
	let t = e.source.replace(/\u0000/g, "�").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${B(V(e.policy, e.frameOrigins ? [...e.frameOrigins] : void 0, e.fragment))}"></head><body><pre data-local-html-fallback="document">\n${t}</pre></body></html>`;
}
function J(e, t, n) {
	if (t.depth >= te) return "";
	let r = t.diagnostics.length, i = () => (Q(t, r), T(t, "local.html.fallback", "Native HTML was safely converted to inert source text.", n.start, n.end), q({
		...t,
		source: e
	})), a;
	try {
		a = c(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch {
		return i();
	}
	let o = {
		...t,
		source: e,
		lines: { starts: C(e) },
		depth: t.depth + 1,
		bodyFallbacks: []
	};
	try {
		let e = R(a, "html");
		if (e) {
			let n = t.diagnostics.length;
			if (!Y(e, "html", !0, o)) return Q(o, n), q(o);
			$(e, o, !1);
		}
		return K(o, a);
	} catch (e) {
		if (e instanceof S) throw e;
		return i();
	}
}
function Y(e, n, a, c) {
	e.sourceCodeLocation;
	let l = [], u = !1, d = !0;
	for (let i of e.attrs) {
		let f = i.name.toLowerCase(), p = i.prefix ? `${i.prefix}:${i.name}` : i.name, m = re(e, i, c);
		if (a && o.has(n) && !s(f, i.value)) {
			d = !1, T(c, "local.html.table", `Invalid value for ${f} on native HTML <${n}>.`, m.start, m.end, {
				key: "html.table.value",
				params: {
					name: f,
					tag: n
				}
			});
			continue;
		}
		if (a && f === "align" && r.has(n)) {
			let e = t(i.value);
			e ? l.push({
				...i,
				value: e
			}) : (d = !1, T(c, "local.html.attribute", "HTML attribute align requires left, center, right or justify.", m.start, m.end, {
				key: "local.html.attribute",
				params: {
					name: p,
					tag: n
				}
			}));
			continue;
		}
		if (P(f)) {
			if (!c.policy.enableJavaScript) {
				T(c, "local.html.capability", `Author event handler attribute ${p} was disabled by the compile options.`, m.start, m.end, {
					key: "local.html.capability",
					params: { feature: "event handlers" }
				});
				continue;
			}
			l.push(i);
			continue;
		}
		if (f === "style" || F(f, a)) {
			if (!c.policy.enableCss) {
				T(c, "local.html.capability", `Author style attribute ${p} was disabled by the compile options.`, m.start, m.end, {
					key: "local.html.capability",
					params: { feature: "CSS" }
				});
				continue;
			}
			l.push(i);
			continue;
		}
		if (f === "srcset" || f === "imagesrcset") {
			T(c, "local.html.unsafe-url", `Unsafe URL in attribute ${p} was removed.`, m.start, m.end, {
				key: "local.html.unsafe-url",
				params: { name: p }
			});
			continue;
		}
		if (f === "srcdoc" && n === "iframe") {
			if (l.some((e) => e.name === "srcdoc")) continue;
			let e = J(i.value, c, m);
			if (e === "") continue;
			i.value = e, l.push(i);
			continue;
		}
		if (f === "sandbox" && n === "iframe") {
			i.value = L(i.value, c.policy), u = !0, l.push(i);
			continue;
		}
		let h = c.frameOrigins;
		if (h !== void 0 && n === "iframe") {
			if (f === "allow" || f === "allowfullscreen" || f === "allowpaymentrequest") {
				T(c, "local.html.capability", `Author frame permission ${p} was disabled.`, m.start, m.end, {
					key: "local.html.capability",
					params: { feature: "frame permission" }
				});
				continue;
			}
			if (f === "src") {
				let e = se(i.value);
				if (e === null) {
					T(c, "local.html.unsafe-url", `Unsafe frame source in attribute ${p} was removed.`, m.start, m.end, {
						key: "local.html.unsafe-url",
						params: { name: p }
					});
					continue;
				}
				if (e !== void 0) {
					if (l.some((e) => e.name === "srcdoc")) continue;
					let t = J(e, c, m);
					if (t === "") continue;
					l.push({
						name: "srcdoc",
						value: t
					});
					continue;
				}
				if (!oe(i.value, h)) {
					T(c, "local.html.unsafe-url", `Remote frame source ${p} is not an allowed origin.`, m.start, m.end, {
						key: "local.html.unsafe-url",
						params: { name: p }
					});
					continue;
				}
				l.push(i);
				continue;
			}
		}
		j(f) && !A(i.value, M(f, n)) ? T(c, "local.html.unsafe-url", `Unsafe URL in attribute ${p} was removed.`, m.start, m.end, {
			key: "local.html.unsafe-url",
			params: { name: p }
		}) : f === "target" && /^_(?:top|parent)$/i.test(i.value.trim()) ? T(c, "local.html.capability", `Navigation target ${i.value} was disabled.`, m.start, m.end, {
			key: "local.html.capability",
			params: { feature: "top-level navigation" }
		}) : !c.policy.enableExtendedHtml && !N(n, f) ? (d = !1, T(c, "local.html.attribute", `HTML attribute ${p} on <${n}> is not supported; the element is shown as source.`, m.start, m.end, {
			key: "local.html.attribute",
			params: {
				name: p,
				tag: n
			}
		})) : l.push(i);
	}
	if (n === "iframe" && !u && l.push({
		name: "sandbox",
		value: I(c.policy)
	}), n === "a") {
		let e = l.find((e) => e.name.toLowerCase() === "target")?.value, t = l.find((e) => e.name.toLowerCase() === "rel"), n = i(t?.value, e);
		n !== void 0 && (t ? t.value = n : l.push({
			name: "rel",
			value: n
		}));
	}
	return e.attrs = l, d;
}
function ce(e, t, n) {
	let r = t.diagnostics.length, i = E(e, t);
	D(t, i.start, i.end);
	let a = e.tagName.toLowerCase(), o = e.namespaceURI === f;
	if (h.has(a)) return t.fragment ? (T(t, "local.html.fallback", `HTML element <${a}> cannot be rendered in an extended fragment; it is shown as source.`, i.start, i.end, { key: "html.fallback" }), Z(e, t, n, r)) : (t.bodyFallbacks.push(O(e, t)), T(t, "local.html.fallback", `HTML element <${a}> requires enableExtendedHtml in this mode; it is shown as source.`, i.start, i.end, {
		key: "local.html.extended",
		params: { name: a }
	}), []);
	if (t.fragment && a === "base") return T(t, "local.html.capability", "Author HTML base was disabled in an extended fragment.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "document base" }
	}), [];
	if (!o && !t.policy.enableCss && ee.has(a)) return T(t, "local.html.capability", `Author animation <${a}> was disabled by the compile options.`, i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "animation" }
	}), [];
	if (a === "script") return t.policy.enableJavaScript ? Y(e, a, o, t) ? [e] : Z(e, t, n, r) : (T(t, "local.html.capability", "Author JavaScript was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "JavaScript" }
	}), []);
	if (a === "style") return t.policy.enableCss ? Y(e, a, o, t) ? [e] : Z(e, t, n, r) : (T(t, "local.html.capability", "Author CSS was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "CSS" }
	}), []);
	if (a === "link") return (e.attrs.find((e) => e.name.toLowerCase() === "rel")?.value.toLowerCase() ?? "").split(/\s+/).includes("stylesheet") ? t.policy.enableCss ? Y(e, a, o, t) ? [e] : Z(e, t, n, r) : (T(t, "local.html.capability", "Author CSS was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "CSS" }
	}), []) : t.policy.enableExtendedHtml ? Y(e, a, o, t) ? [e] : Z(e, t, n, r) : X(e, t);
	if (a === "meta") {
		if (!t.policy.enableExtendedHtml) return X(e, t);
		let s = e.attrs.find((e) => e.name.toLowerCase() === "http-equiv")?.value.trim().toLowerCase() ?? "";
		return s === "refresh" || s === "content-security-policy" || s === "set-cookie" ? (T(t, "local.html.capability", `Author metadata ${s} was disabled.`, i.start, i.end, {
			key: "local.html.capability",
			params: { feature: "document metadata" }
		}), []) : Y(e, a, o, t) ? [e] : Z(e, t, n, r);
	}
	return (a === "title" || a === "html" || a === "head" || a === "body") && !t.policy.enableExtendedHtml && a === "title" || !(o && (p.has(a) || m.has(a)) || t.policy.enableExtendedHtml) ? X(e, t, n) : Y(e, a, o, t) ? a === "template" ? ($(u.getTemplateContent(e), t, !1), [e]) : ($(e, t, n), [e]) : Z(e, t, n, r);
}
function X(e, t, n = !1) {
	let r = t.diagnostics.length, i = e.tagName.toLowerCase(), a = E(e, t);
	return T(t, "local.html.extended", `HTML element <${i}> requires enableExtendedHtml in this mode; it is shown as source.`, a.start, a.end, {
		key: "local.html.extended",
		params: { name: i }
	}), Z(e, t, n, r);
}
function Z(e, t, n, r) {
	return Q(t, r), n ? (t.bodyFallbacks.push(O(e, t)), []) : [k(O(e, t))];
}
function Q(e, t) {
	for (let n of e.diagnostics.slice(t)) n.severity === "warning" && (n.code = "local.html.fallback");
}
function $(e, t, n) {
	let r = [];
	for (let i of e.childNodes) if (u.isTextNode(i)) D(t, 0, 0), r.push(i);
	else if (u.isCommentNode(i)) D(t, 0, 0), r.push(i);
	else if (!u.isDocumentTypeNode(i) && u.isElementNode(i)) {
		let e = i.tagName.toLowerCase(), a = n || e === "head";
		r.push(...ce(i, t, a));
	}
	e.childNodes = r;
}
function le(e, t, n, r) {
	let i = [], a = {
		policy: t,
		source: e,
		lines: { starts: C(e) },
		diagnostics: i,
		maxNodes: n,
		depth: 0,
		...r === void 0 ? {} : { frameOrigins: W(r) },
		budget: { nodes: 0 },
		bodyFallbacks: [],
		stopped: !1
	}, o;
	try {
		o = c(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch (e) {
		return {
			markup: q(a),
			diagnostics: [{
				code: "local.parse",
				message: `Cannot parse the HTML document: ${e instanceof Error ? e.message : String(e)}`,
				severity: "error",
				range: {
					start: 0,
					end: 0
				},
				line: 1,
				column: 1,
				messageKey: "local.parse.document",
				params: { detail: e instanceof Error ? e.message : String(e) }
			}]
		};
	}
	try {
		let e = R(o, "html");
		if (e) {
			let t = a.diagnostics.length;
			if (!Y(e, "html", !0, a)) return Q(a, t), {
				markup: q(a),
				diagnostics: i
			};
			$(e, a, !1);
		} else $(o, a, !1);
		return {
			markup: K(a, o),
			diagnostics: i
		};
	} catch (e) {
		if (e instanceof S) {
			let t = w(a, e.start, e.end);
			return {
				markup: q(a),
				diagnostics: [{
					code: "local.budget",
					message: e.message,
					severity: "error",
					range: {
						start: t.start,
						end: t.end
					},
					line: t.line,
					column: t.column,
					messageKey: "local.budget.nodes",
					params: { limit: e.limit }
				}]
			};
		}
		return {
			markup: q(a),
			diagnostics: [{
				code: "local.parse",
				message: `Cannot parse the HTML document: ${e instanceof Error ? e.message : String(e)}`,
				severity: "error",
				range: {
					start: 0,
					end: 0
				},
				line: 1,
				column: 1,
				messageKey: "local.parse.document",
				params: { detail: e instanceof Error ? e.message : String(e) }
			}]
		};
	}
}
function ue(e, t) {
	let n = [{
		node: e,
		depth: 0
	}];
	for (; n.length > 0;) {
		let { node: e, depth: r } = n.pop();
		for (let i of e.childNodes) {
			if (!u.isElementNode(i)) continue;
			if (r + 1 > t) return !0;
			let e = i.tagName.toLowerCase() === "template" ? u.getTemplateContent(i) : i;
			n.push({
				node: e,
				depth: r + 1
			});
		}
	}
	return !1;
}
function de(e, t, n, r) {
	let i = [];
	if (typeof e != "string" || e.trim() === "") return {
		markup: "",
		diagnostics: i
	};
	let a = {
		policy: t,
		source: e,
		lines: { starts: C(e) },
		diagnostics: i,
		maxNodes: n,
		depth: 0,
		fragment: !0,
		...r === void 0 ? {} : { frameOrigins: W(r) },
		budget: { nodes: 0 },
		bodyFallbacks: [],
		stopped: !1
	}, o;
	try {
		o = d(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		return T(a, "local.parse", `Cannot parse the HTML fragment: ${t}`, 0, 0, {
			key: "local.parse.document",
			params: { detail: t }
		}), { diagnostics: i };
	}
	if (ue(o, x)) return { diagnostics: [{
		code: "local.budget",
		message: `HTML fragment exceeds ${x} nested element levels.`,
		severity: "error",
		range: {
			start: 0,
			end: e.length
		},
		line: 1,
		column: 1,
		messageKey: "local.budget.nodes",
		params: { limit: x }
	}] };
	try {
		return $(o, a, !1), {
			markup: a.bodyFallbacks.map((e) => l(k(e), { scriptingEnabled: !1 })).join("") + z(o),
			diagnostics: i
		};
	} catch (e) {
		if (e instanceof S) {
			let t = w(a, e.start, e.end);
			return { diagnostics: [{
				code: "local.budget",
				message: e.message,
				severity: "error",
				range: {
					start: t.start,
					end: t.end
				},
				line: t.line,
				column: t.column,
				messageKey: "local.budget.nodes",
				params: { limit: e.limit }
			}] };
		}
		return { diagnostics: i };
	}
}
export { de as i, I as n, le as r, V as t };
