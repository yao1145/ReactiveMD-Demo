// src/runtime-services/network.ts
var e = 65536, t = Object.freeze({
	code: "unavailable",
	message: "This channel operation is unavailable."
}), n = Object.freeze({
	code: "cancelled",
	message: "The operation was cancelled."
}), r = Object.freeze({
	code: "invalid-data",
	message: "The channel data is invalid."
}), i = Object.freeze({
	code: "transport",
	message: "The channel could not communicate with its endpoint."
}), a = Object.freeze({
	code: "rejected",
	message: "A channel listener failed."
}), o = 0;
function s(e) {
	return {
		ok: !1,
		error: e
	};
}
var c = Object.freeze({
	supports: () => !1,
	submit: async () => s(t),
	subscribe(e, n) {
		let r = !0;
		return queueMicrotask(() => {
			if (r) try {
				n({
					type: "error",
					error: t
				});
			} catch {}
		}), () => {
			r = !1;
		};
	}
});
function l(t = e) {
	if (!Number.isSafeInteger(t) || t < 1) throw TypeError("A channel byte budget must be a positive integer.");
	return t;
}
function u(e, t) {
	let n = t;
	function r(e) {
		if (n -= e, n < 0) throw RangeError();
	}
	function i(e, t) {
		if (r(1), t > 64) throw RangeError();
		if (e === null || typeof e == "boolean") return e;
		if (typeof e == "string") return r(e.length), e;
		if (typeof e == "number" && Number.isFinite(e)) return e;
		if (Array.isArray(e)) {
			if (e.length > n) throw RangeError();
			let r = [];
			for (let n = 0; n < e.length; n += 1) {
				let a = Object.getOwnPropertyDescriptor(e, String(n));
				if (!a || !("value" in a)) throw TypeError();
				r.push(i(a.value, t + 1));
			}
			return Object.freeze(r);
		}
		if (typeof e != "object" || !e) throw TypeError();
		let a = Object.getPrototypeOf(e);
		if (a !== Object.prototype && a !== null) throw TypeError();
		let o = Object.create(null);
		for (let n of Object.keys(e)) {
			r(n.length);
			let a = Object.getOwnPropertyDescriptor(e, n);
			if (!a || !("value" in a)) throw TypeError();
			o[n] = i(a.value, t + 1);
		}
		return Object.freeze(o);
	}
	let a = i(e, 0);
	if (new TextEncoder().encode(JSON.stringify(a)).length > t) throw RangeError();
	return a;
}
function d(t) {
	if (!t.ok) return t;
	try {
		let n = Object.getOwnPropertyDescriptor(t, "data");
		if (n && "value" in n && n.value !== void 0) return {
			ok: !0,
			data: u(n.value, e)
		};
	} catch {}
	return { ok: !0 };
}
function f(e, t) {
	let n = t(e);
	if (n !== !0) return typeof n == "string" && n.trim() ? Object.freeze({
		code: "invalid-data",
		message: n
	}) : r;
}
function p(e) {
	if (!e) return {
		network: c,
		bindExternalValues: () => void 0,
		dispose() {}
	};
	let p = /* @__PURE__ */ new Map(), m = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.channels)) {
		let { submit: e, subscribe: r, mapExternalValues: i } = n;
		if (e && (typeof e.validate != "function" || typeof e.send != "function")) throw TypeError("A submit channel requires a validator and a send function.");
		if (r && (typeof r.validate != "function" || typeof r.open != "function")) throw TypeError("A subscription channel requires a validator and an open function.");
		if (i !== void 0) {
			if (!r || typeof i != "function") throw TypeError("Mapping external values requires a subscription and a mapper function.");
			m.set(t, i.bind(n));
		}
		p.set(t, {
			...e && { submit: {
				maxBytes: l(e.maxBytes),
				validate: e.validate.bind(e),
				send: e.send.bind(e)
			} },
			...r && { subscribe: {
				maxBytes: l(r.maxBytes),
				validate: r.validate.bind(r),
				open: r.open.bind(r)
			} }
		});
	}
	let h = /* @__PURE__ */ new Map(), g = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Map(), v = !1;
	function y(e) {
		let t = h.get(e);
		return t || h.set(e, t = new AbortController()), t.signal;
	}
	function b(t, n) {
		try {
			t.notify(Object.freeze(n));
		} catch {
			try {
				e?.onListenerError?.(a);
			} catch {}
		}
	}
	function x(e) {
		try {
			e?.();
		} catch {}
	}
	function S(e, t) {
		_.delete(e), t.listeners.clear(), t.events.length = 0, t.controller.abort(), x(t.release);
	}
	function C(e, t) {
		if (!(v || e.controller.signal.aborted) && (e.events.push({
			event: t,
			recipients: [...e.listeners],
			status: e.status
		}), !e.dispatching)) {
			e.dispatching = !0;
			try {
				for (let t = 0; t < e.events.length; t += 1) {
					let { event: n, recipients: r, status: i } = e.events[t];
					for (let t of r) e.listeners.has(t) && (t.initial || (t.initial = !0, n.type !== "status" && b(t, {
						type: "status",
						state: i
					})), e.listeners.has(t) && b(t, n));
				}
			} finally {
				e.events.length = 0, e.dispatching = !1;
			}
		}
	}
	function w(e, t, n) {
		let a = t.controller.signal;
		if (a.aborted) return;
		let o = (e) => {
			a.aborted || t.status === e || (t.status = e, C(t, {
				type: "status",
				state: e
			}));
		}, s = (e) => {
			C(t, {
				type: "error",
				error: Object.freeze({ ...e })
			});
		}, c = (e) => {
			if (a.aborted) return;
			let i, o;
			try {
				i = u(e, n.maxBytes ?? 65536), o = f(i, n.validate);
			} catch {
				s(r);
				return;
			}
			o ? s(o) : C(t, {
				type: "data",
				value: i
			});
		}, l = () => {
			a.aborted || (s(i), o("closed"));
		}, d = (e) => {
			a.aborted ? x(e) : t.release = e;
		};
		try {
			let t = n.open({
				signal: a,
				sessionSignal: y(e),
				status: o,
				error: s,
				data: c
			});
			typeof t == "function" ? d(t) : Promise.resolve(t).then(d, l);
		} catch {
			l();
		}
	}
	let T = {
		supports(e, t) {
			return !v && (t === "submit" || t === "subscribe") && p.get(e)?.[t] !== void 0;
		},
		async submit(e, a, c) {
			let l = v ? void 0 : p.get(e)?.submit;
			if (!l) return s(t);
			if (c?.signal?.aborted) return s(n);
			let m;
			try {
				let e = u(a, l.maxBytes ?? 65536);
				if (typeof e != "object" || !e || Array.isArray(e)) return s(r);
				m = e;
				let t = f(m, l.validate);
				if (t) return s(t);
			} catch {
				return s(r);
			}
			let h = c?.signal;
			if (v || h?.aborted) return s(n);
			let _ = new AbortController();
			return new Promise((t) => {
				let r = !1, a = (e) => {
					r || (r = !0, h?.removeEventListener("abort", u), g.delete(u), t(d(e)));
				}, u = () => {
					a(s(n)), _.abort();
				};
				g.add(u), h?.addEventListener("abort", u, { once: !0 });
				try {
					let t = l.send(m, {
						signal: _.signal,
						sessionSignal: y(e),
						requestId: String(++o),
						...c?.idempotencyKey === void 0 ? {} : { idempotencyKey: c.idempotencyKey }
					});
					Promise.resolve(t).then(a, () => a(s(i)));
				} catch {
					a(s(i));
				}
			});
		},
		subscribe(e, n) {
			if (v) return c.subscribe(e, n);
			let r = {
				notify: n,
				initial: !1
			}, i = p.get(e)?.subscribe;
			if (!i) {
				let e = !0;
				return queueMicrotask(() => {
					e && !v && b(r, {
						type: "error",
						error: t
					});
				}), () => {
					e = !1;
				};
			}
			let a = _.get(e), o = a ?? {
				controller: new AbortController(),
				listeners: /* @__PURE__ */ new Set(),
				events: [],
				status: "connecting",
				dispatching: !1
			};
			return o.listeners.add(r), a || _.set(e, o), queueMicrotask(() => {
				o.listeners.has(r) && !r.initial && (r.initial = !0, b(r, {
					type: "status",
					state: o.status
				})), a || w(e, o, i);
			}), () => {
				o.listeners.delete(r) && o.listeners.size === 0 && S(e, o);
			};
		}
	};
	return {
		network: Object.freeze(T),
		bindExternalValues(e) {
			if (v || m.size === 0) return;
			let t = [...m].map(([t, n]) => T.subscribe(t, (t) => {
				if (t.type !== "data") return;
				let r = n(t.value);
				r !== void 0 && e(r);
			}));
			return () => {
				for (let e of t) e();
			};
		},
		dispose() {
			if (!v) {
				v = !0;
				for (let e of g) e();
				for (let [e, t] of _) S(e, t);
				for (let e of h.values()) e.abort();
				h.clear(), p.clear(), m.clear();
			}
		}
	};
}
// src/runtime-services/identity.ts
var m = 2166136261, h = 16777619, g = new TextEncoder(), _ = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/, v = /^[^\u0000-\u001f\u007f]{1,256}$/;
function y(e) {
	let t = g.encode(e), n = m;
	for (let e = 0; e < t.length; e += 1) n ^= t[e], n = Math.imul(n, h) >>> 0;
	return n >>> 0;
}
function b(e) {
	if (typeof e != "string") throw TypeError("localSourceDigest requires a source string.");
	return `fnv1a32:${y(e).toString(16).padStart(8, "0")}`;
}
function x(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	return v.test(t) ? t : void 0;
}
function S(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	return _.test(t) ? t : void 0;
}
function C(e) {
	return x(e.documentId) ?? e.sourceDigest;
}
function w(e) {
	let t = C(e), n = S(e.stateKey), r = n === void 0 ? `node:${e.nodeId}` : `state:${n}`, i = encodeURIComponent(t);
	return `doc:${i.length <= 256 ? i : `h${y(t).toString(16).padStart(8, "0")}`}:${r}`;
}
function T(e, t) {
	return y(`${e >>> 0}:${t}`);
}
function ee(e) {
	if (typeof e.explicitSeed == "number" && Number.isFinite(e.explicitSeed)) return Math.trunc(e.explicitSeed) >>> 0;
	let t = S(e.stateKey), n = t === void 0 ? `node:${e.nodeId}` : `state:${t}`;
	return T(e.documentSeed, `${e.componentId}|${n}`);
}
function E(e) {
	return Number.isFinite(e) ? Math.trunc(e) >>> 0 : 0;
}
// src/runtime-services/random.ts
var D = "mulberry32", te = 1;
function O(e) {
	return Object.freeze({
		algorithm: D,
		version: 1,
		state: E(e)
	});
}
function k(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return null;
	let t = e;
	if (t.algorithm !== "mulberry32" || t.version !== 1 || typeof t.state != "number" || !Number.isFinite(t.state)) return null;
	let n = E(t.state);
	return n === t.state ? Object.freeze({
		algorithm: D,
		version: 1,
		state: n
	}) : null;
}
function A(e) {
	let t = E(e.state + 1831565813), n = Math.imul(t ^ t >>> 15, t | 1);
	return n ^= n + Math.imul(n ^ n >>> 7, n | 61), {
		value: ((n ^ n >>> 14) >>> 0) / 4294967296,
		state: Object.freeze({
			algorithm: D,
			version: 1,
			state: t
		})
	};
}
function j(e, t, n) {
	let r = A(e);
	if (!Number.isFinite(t) || !Number.isFinite(n)) return {
		value: 0,
		state: r.state
	};
	let i = Math.ceil(Math.min(t, n)), a = Math.floor(Math.max(t, n));
	return a < i ? {
		value: i,
		state: r.state
	} : {
		value: i + Math.floor(r.value * (a - i + 1)),
		state: r.state
	};
}
function ne(e, t) {
	let n = t.slice(), r = e;
	for (let e = n.length - 1; e > 0; --e) {
		let t = j(r, 0, e);
		r = t.state;
		let i = n[e];
		n[e] = n[t.value], n[t.value] = i;
	}
	return {
		items: n,
		state: r
	};
}
function M(e, t) {
	return O(T(e, t));
}
function re(e, t = .5) {
	let n = A(e);
	return {
		value: n.value < t,
		state: n.state
	};
}
// src/runtime-services/component-state.ts
var N = "reactive-md-component-state/v1", P = "reactive-md-component-state-document/v1", F = 16384, I = 262144, ie = 16, L = 1e4, R = 1e5, z = 1048576, B = 128, V = 64, H = 512, U = 1e6, W = 128, ae = /[\u0000-\u001f\u007f-\u009f]/, G = new TextEncoder();
function K(e, t, n = "error") {
	return {
		code: e,
		message: t,
		severity: n,
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function q(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function J(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function Y(e) {
	return typeof e == "string" && e.length > 0 && e.length <= W && !ae.test(e) && J(e);
}
function oe(e, t, n) {
	return t === void 0 || e === t || n.includes(e);
}
function X(e, t) {
	if (e === null) return null;
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw TypeError("numbers must be finite");
		return e;
	}
	if (typeof e == "string") {
		if (e.length > 1e5) throw RangeError(`strings exceed ${R} characters`);
		if (!J(e)) throw TypeError("strings must be well-formed Unicode");
		return e;
	}
	if (t >= 16) throw RangeError("nesting exceeds 16 levels");
	if (Array.isArray(e)) {
		if (e.length > 1e4) throw RangeError(`arrays exceed ${L} items`);
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("arrays cannot use symbol keys");
		return e.map((e) => X(e, t + 1));
	}
	if (q(e)) {
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("objects cannot use symbol keys");
		let n = Object.keys(e);
		if (n.length > 1e4) throw RangeError(`objects exceed ${L} keys`);
		let r = {};
		for (let i of n) {
			if (i === "__proto__") throw TypeError("the key \"__proto__\" is not allowed");
			if (i.length > 1e5) throw RangeError(`keys exceed ${R} characters`);
			if (!J(i)) throw TypeError("keys must be well-formed Unicode");
			r[i] = X(e[i], t + 1);
		}
		return r;
	}
	throw TypeError("values must be JSON-safe primitives, arrays or plain objects");
}
function se(e) {
	return X(e, 0);
}
function Z(e) {
	return Object.freeze({
		...e,
		data: X(e.data, 0),
		...e.random === void 0 ? {} : { random: k(e.random) ?? e.random }
	});
}
function Q(e) {
	if (!q(e)) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.shape", "A component state record must be a plain object.")]
	};
	let t = /* @__PURE__ */ new Set([
		"format",
		"component",
		"componentVersion",
		"stateVersion",
		"key",
		"documentId",
		"data",
		"random"
	]);
	for (let n of Object.keys(e)) if (!t.has(n)) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.key", `Unknown component state key "${n}".`)]
	};
	if (e.format !== "reactive-md-component-state/v1") return {
		ok: !1,
		diagnostics: [K("local.runtime.state.format", `Unsupported component state format; expected "${N}".`)]
	};
	let n = e.component;
	if (typeof n != "string" || n.trim() === "" || n.length > B) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.component", "Component name must be a non-empty string.")]
	};
	let r = e.componentVersion;
	if (typeof r != "string" || r.trim() === "" || r.length > V) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.component-version", "Component version must be a non-empty string.")]
	};
	let i = e.stateVersion;
	if (typeof i != "number" || !Number.isInteger(i) || i < 0 || i > U) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.version", "State version must be a non-negative integer.")]
	};
	let a = e.key;
	if (typeof a != "string" || a.trim() === "" || a.length > H) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.key-name", "State key must be a non-empty string.")]
	};
	let o = e.documentId;
	if (o !== void 0 && (typeof o != "string" || o.trim() === "" || o.length > 256)) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.document", "State documentId must be a non-empty string.")]
	};
	let s;
	try {
		s = se(e.data);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [K("local.runtime.state.data", `Invalid component state data: ${e instanceof Error ? e.message : String(e)}.`)]
		};
	}
	let c;
	if (e.random !== void 0 && (c = k(e.random) ?? void 0, c === void 0)) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.random", "Invalid random state.")]
	};
	let l = {
		format: N,
		component: n,
		componentVersion: r,
		stateVersion: i,
		key: a,
		...o === void 0 ? {} : { documentId: o },
		data: s,
		...c === void 0 ? {} : { random: c }
	};
	return G.encode(JSON.stringify(l)).length > 16384 ? {
		ok: !1,
		diagnostics: [K("local.runtime.state.size", `Component state exceeds the ${F}-byte limit.`)]
	} : {
		ok: !0,
		record: Object.freeze(l)
	};
}
function $(e) {
	let t = e;
	if (typeof e == "string") {
		if (e.length > 1048576) return {
			ok: !1,
			diagnostics: [K("local.runtime.state.size", "The component state payload is too large.")]
		};
		try {
			t = JSON.parse(e);
		} catch {
			return {
				ok: !1,
				diagnostics: [K("local.runtime.state.json", "The component state payload is not valid JSON.")]
			};
		}
	}
	if (!q(t)) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.shape", "The component state document must be a plain object.")]
	};
	if (t.format !== "reactive-md-component-state-document/v1") return {
		ok: !1,
		diagnostics: [K("local.runtime.state.document-format", `Unsupported component state document format; expected "${P}".`)]
	};
	let n = t.configKey;
	if (n !== void 0 && !Y(n)) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.config-key", "The component state configKey must be a non-empty bounded string.")]
	};
	if (!q(t.records)) return {
		ok: !1,
		diagnostics: [K("local.runtime.state.records", "Component state records must be a plain object.")]
	};
	let r = {}, i = [], a = [], o = 0;
	for (let e of Object.keys(t.records)) {
		let n = Q(t.records[e]);
		n.ok ? n.record.key === e ? (o += G.encode(JSON.stringify(n.record)).length, o > 262144 ? (a.push(e), i.push(K("local.runtime.state.total-size", `Component state exceeds the ${I}-byte document limit.`))) : r[e] = n.record) : (a.push(e), i.push(K("local.runtime.state.key-mismatch", `Component state record "${e}" declares a different key "${n.record.key}".`))) : (a.push(e), i.push(...n.diagnostics));
	}
	return {
		ok: !0,
		...n === void 0 ? {} : { configKey: n },
		records: r,
		diagnostics: i,
		skipped: a
	};
}
function ce(e) {
	let t = $(e);
	if (!t.ok) return t;
	let n = {};
	for (let [e, r] of Object.entries(t.records)) n[e] = r;
	return {
		ok: !0,
		document: Object.freeze({
			format: P,
			...t.configKey === void 0 ? {} : { configKey: t.configKey },
			records: Object.freeze(n)
		}),
		records: Object.freeze(n),
		diagnostics: t.diagnostics,
		skipped: t.skipped
	};
}
function le(e) {
	let t = C(e), n = e.sourceDigest, r = e.knownKeys, i = e.configKey;
	if (i !== void 0 && !Y(i)) throw TypeError("configKey must be a non-empty bounded string.");
	let a = Object.freeze((e.legacyConfigKeys ?? []).filter(Y)), o = e.writeDelayMs ?? 0;
	if (typeof o != "number" || !Number.isFinite(o) || o < 0) throw TypeError("writeDelayMs must be a non-negative finite number.");
	let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Set(), u = /* @__PURE__ */ new Set(), d = [], f = e.storage, p = null, m = null, h = !1, g = () => {
		for (let e of u) e();
	};
	function _() {
		if (f === void 0) return !0;
		try {
			let e = S.snapshot();
			return Object.keys(e.records).length === 0 ? f.remove() : f.write(e), p = null, !0;
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return t !== p && (p = t, d.push(K("local.runtime.state.storage", `The component state could not be persisted: ${t}`, "warning"))), !1;
		}
	}
	let v = () => {
		m !== null && (clearTimeout(m), m = null);
	};
	function y() {
		h && (v(), _() && (h = !1));
	}
	let b = () => {
		f !== void 0 && (o <= 0 ? _() : (h = !0, m === null && (m = setTimeout(() => {
			m = null, y();
		}, Math.min(o, 2147483647)))));
	}, x = (e) => {
		let t = 0;
		for (let [n, r] of s) n !== e && (t += G.encode(JSON.stringify(r)).length);
		return t;
	}, S = {
		documentId: t,
		sourceDigest: n,
		key(e) {
			return w({
				documentId: t,
				sourceDigest: n,
				nodeId: e.nodeId,
				stateKey: e.stateKey
			});
		},
		handle(e) {
			let n = S.key({
				nodeId: e.nodeId,
				stateKey: e.stateKey
			}), r = c.get(n), i = !1;
			r !== void 0 && r !== e.nodeId ? (i = !0, l.has(n) || (l.add(n), d.push(K("local.runtime.state.duplicate-key", `Component state key "${n}" is used by more than one component instance.`)))) : c.set(n, e.nodeId);
			let a = {
				key: n,
				component: e.component,
				componentVersion: e.componentVersion,
				duplicate: i,
				load() {
					if (i) return null;
					let e = s.get(n);
					return e === void 0 ? null : Z(e);
				},
				save(r, a) {
					if (i) return {
						ok: !1,
						diagnostics: [K("local.runtime.state.duplicate-key", `Component state key "${n}" is used by more than one component instance.`)]
					};
					let o = a?.version ?? e.stateVersion ?? 0, c = Q({
						format: N,
						component: e.component,
						componentVersion: e.componentVersion,
						stateVersion: o,
						key: n,
						documentId: t,
						data: r,
						...a?.random === void 0 ? {} : { random: a.random }
					});
					if (!c.ok) return {
						ok: !1,
						diagnostics: c.diagnostics
					};
					let l = G.encode(JSON.stringify(c.record)).length;
					return x(n) + l > 262144 ? {
						ok: !1,
						diagnostics: [K("local.runtime.state.total-size", `Component state exceeds the ${I}-byte document limit.`)]
					} : (s.set(n, c.record), b(), g(), {
						ok: !0,
						diagnostics: [],
						record: Z(c.record)
					});
				},
				clear() {
					i || s.delete(n) && (b(), g());
				}
			};
			return Object.freeze(a);
		},
		load(e) {
			let t = s.get(e);
			return t === void 0 ? null : Z(t);
		},
		clear(e) {
			s.delete(e) && (b(), g());
		},
		snapshot() {
			let e = {};
			for (let [t, n] of s) e[t] = Z(n);
			return Object.freeze({
				format: P,
				...i === void 0 ? {} : { configKey: i },
				records: Object.freeze(e)
			});
		},
		restore(e) {
			let n = $(e);
			if (!n.ok) return d.push(...n.diagnostics), {
				accepted: [],
				skipped: [],
				diagnostics: n.diagnostics
			};
			if (n.configKey !== void 0 && !oe(n.configKey, i, a)) {
				let e = [.../* @__PURE__ */ new Set([...n.skipped, ...Object.keys(n.records)])];
				return n.diagnostics.push(K("local.runtime.state.config-mismatch", `Saved component state belongs to configuration "${n.configKey}", not "${i}".`, "warning")), d.push(...n.diagnostics), {
					accepted: [],
					skipped: e,
					diagnostics: n.diagnostics
				};
			}
			let o = [], c = typeof r == "function" ? r() : r;
			for (let [e, r] of Object.entries(n.records)) r.documentId !== void 0 && r.documentId !== t ? (n.skipped.push(e), n.diagnostics.push(K("local.runtime.state.document-mismatch", `Saved state key "${e}" belongs to a different document.`))) : c !== void 0 && !c.has(e) ? (n.skipped.push(e), n.diagnostics.push(K("local.runtime.state.unknown-component", `Saved state key "${e}" does not match any component in this document.`))) : (s.set(e, r), o.push(e));
			return n.diagnostics.length && d.push(...n.diagnostics), o.length && g(), {
				accepted: o,
				skipped: n.skipped,
				diagnostics: n.diagnostics
			};
		},
		flush() {
			y();
		},
		diagnostics() {
			return Object.freeze([...d]);
		},
		subscribe(e) {
			return u.add(e), () => {
				u.delete(e);
			};
		}
	}, T = e.initial;
	if (T === void 0 && f !== void 0) try {
		let e = f.read();
		e !== null && (T = e);
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		d.push(K("local.runtime.state.storage", `The component state could not be read: ${t}`, "warning"));
	}
	return T !== void 0 && S.restore(T), Object.freeze(S);
}
export { p as A, b as C, C as D, ee as E, E as O, y as S, S as T, re as _, z as a, w as b, I as c, D as d, te as f, k as g, A as h, ie as i, c as j, e as k, le as l, M as m, N as n, L as o, O as p, F as r, R as s, P as t, ce as u, j as v, x as w, T as x, ne as y };
