/**
 * Structural markers emitted by the renderer when an extension cannot render.
 * Text that merely contains these names (prose, inline code, attribute
 * examples) is not an error, so the check reads the parsed DOM instead of
 * scanning the serialized string.
 */
export type UnavailableExtensionReason = 'extension-error' | 'sdk-unavailable';
export interface UnavailableExtensionMarkup {
    /** `extension-error` is the document-level alert block; `sdk-unavailable` a component placeholder. */
    readonly reason: UnavailableExtensionReason;
    /** Host component tag name when the placeholder records one. */
    readonly component?: string;
    /** Renderer-supplied messages, bounded for diagnostics. */
    readonly detail?: string;
}
/**
 * Find the first unavailable-extension marker in rendered static markup.
 * Traverses in document order, including `<template>` contents. Text nodes,
 * attribute examples and `srcdoc` payloads are not inspected.
 */
export declare function findUnavailableExtensionMarkup(markup: string): UnavailableExtensionMarkup | null;
/** One-line diagnostic text for a marker found by {@link findUnavailableExtensionMarkup}. */
export declare function unavailableExtensionMessage(marker: UnavailableExtensionMarkup): string;
