import type { Diagnostic, LocalCompileOptions, LocalDocument, LocalHtmlOptions, LocalRuntime, LocalSnapshot, LocalValue } from '../../types.js';
import { type NetworkConfig } from '../../../runtime-services/network.js';
import { type Localize, type LocalLocale } from '../../../react/localization.js';
import { type LocalColorScheme, type LocalThemeDefinition } from '../../../themes/document-theme.js';
import type { LocalHostData, LocalHostRenderer, LocalRenderMode, LocalSourceTarget } from '../render-types.js';
import { type LocalReactConfig } from '../../../react/sdk-core.js';
import type { LocalComponentStateDocument, LocalComponentStateStorage } from '../../../runtime-services/component-state.js';
import { textProblem as componentTextProblem } from '../../../react/field-validation.js';
/**
 * Host-owned URL allowlist. It runs only after the renderer has validated the
 * protocol, and a thrown error denies the URL.
 */
export type LocalUrlPolicy = (url: string, kind: 'image' | 'link') => boolean;
/**
 * Trusted host mapping applied to an image URL that already passed the
 * protocol check and the host URL policy. It commonly turns a fetchable image
 * into a self-contained `data:` URL for export. Returning anything other than
 * a non-empty string rejects the image; links never reach this callback.
 */
export type LocalImageResolver = (url: string) => string | null;
export interface LocalDocumentViewProps {
    document: LocalDocument;
    runtime: LocalRuntime;
    /** Mount-local grants, bounded by the permissions recorded at compilation. */
    capabilityGrants?: LocalHtmlOptions;
    /** Exact HTTPS origins available to an extended iframe in this mount. */
    allowedFrameOrigins?: readonly string[];
    /** Optional view-scoped channels. Keep the reference stable while authorization is unchanged. */
    network?: NetworkConfig;
    onDiagnostics?: (diagnostics: Diagnostic[]) => void;
    urlPolicy?: LocalUrlPolicy;
    /** UI language for built-in labels and validation messages; defaults to English. */
    locale?: LocalLocale;
    /**
     * Trusted theme manifests. Their CSS is imported by the host separately; the
     * renderer only resolves names to a root attribute and never loads CSS.
     */
    themes?: readonly LocalThemeDefinition[];
    /** Document mode; `auto` follows the nearest host attribute or the OS. */
    colorScheme?: LocalColorScheme;
    /**
     * `interactive` (default) renders form controls; `static` renders read-only
     * values suitable for export while still evaluating the runtime.
     */
    mode?: LocalRenderMode;
    /**
     * Render static controls for the first pass, then switch to `mode` after
     * mount. The first client render matches static server markup during
     * hydration, and JavaScript-disabled readers keep the static document.
     */
    staticFirst?: boolean;
    /** Trusted image URL mapping; only called after the image URL passed validation. */
    imageResolver?: LocalImageResolver;
    /** JSON-safe host data keyed by `${kind}:${ref}`; never enters the worker. */
    hostData?: LocalHostData;
    /** Client-only renderer for hostComponent nodes; never enters the worker. */
    hostRenderer?: LocalHostRenderer;
    /**
     * SDK component implementations. It replaces `hostData`, `hostRenderer` and
     * `themes`; supplying any of them together is rejected, and themes are
     * derived from the config.
     */
    reactConfig?: LocalReactConfig;
    /**
     * Read-only host values for `<external>` declarations. Changing them updates
     * the given runtime without recompiling the source or resetting parameters.
     */
    externalValues?: Readonly<Record<string, LocalValue>>;
    /**
     * Report a preview location to the host, for example to select the matching
     * source range in an editor. Omit to keep the plain rendered output.
     */
    onSourceNavigate?: (target: LocalSourceTarget) => void;
}
export interface LocalReactiveDocumentProps {
    source: string;
    /** Further restrict the grants given by compileOptions for this mount. */
    capabilityGrants?: LocalHtmlOptions;
    allowedFrameOrigins?: readonly string[];
    /** Channels granted to the current document and user. */
    network?: NetworkConfig;
    onDiagnostics?: (diagnostics: Diagnostic[]) => void;
    urlPolicy?: LocalUrlPolicy;
    /** UI language for built-in labels and validation messages; defaults to English. */
    locale?: LocalLocale;
    /** Trusted theme manifests; their CSS stays host-owned. */
    themes?: readonly LocalThemeDefinition[];
    /** Document mode; `auto` follows the nearest host attribute or the OS. */
    colorScheme?: LocalColorScheme;
    /** Rendering mode forwarded to `LocalDocumentView`; defaults to `interactive`. */
    mode?: LocalRenderMode;
    /** Static-first hydration behavior forwarded to `LocalDocumentView`. */
    staticFirst?: boolean;
    /** Trusted image URL mapping forwarded to `LocalDocumentView`. */
    imageResolver?: LocalImageResolver;
    /** JSON-safe host data keyed by `${kind}:${ref}`; never enters the worker. */
    hostData?: LocalHostData;
    /** Client-only renderer for hostComponent nodes; never enters the worker. */
    hostRenderer?: LocalHostRenderer;
    /**
     * SDK component implementations forwarded to `LocalDocumentView`. It cannot
     * be combined with `hostData`, `hostRenderer` or `themes`.
     */
    reactConfig?: LocalReactConfig;
    /** Read-only host values for `<external>` declarations. */
    externalValues?: Readonly<Record<string, LocalValue>>;
    /** Stable host identity for component-scoped state. Defaults to the source digest. */
    documentId?: string;
    /** Document-level seed for component randomness. */
    randomSeed?: number;
    /** Component-state sidecar restored before the first render. */
    componentState?: unknown;
    /**
     * Persistence port applied when this document creates a runtime. Changing it
     * later does not migrate an existing runtime; pass a new `componentState`
     * sidecar or remount instead.
     */
    componentStateStorage?: LocalComponentStateStorage;
    /**
     * Coalesce component-state writes. Memory updates immediately; a positive
     * delay writes the stored sidecar at most once per window and flushes it when
     * the page is hidden or the runtime is disposed. Defaults to 0 (write after
     * every save or clear).
     */
    componentStateWriteDelayMs?: number;
    /** Called when a component explicitly saves or clears its state. */
    onComponentStateChange?: (state: LocalComponentStateDocument) => void;
    /**
     * Public parameter values applied once after each new runtime is created,
     * before the reader can interact. Invalid sets are rejected atomically and
     * reported through `onDiagnostics`.
     */
    initialParameters?: Readonly<Record<string, LocalValue>>;
    /**
     * Called once per commit when the public writable parameter set actually
     * changes. Initialization does not call it.
     */
    onParametersChange?: (parameters: Readonly<Record<string, LocalValue>>, snapshot: LocalSnapshot) => void;
    /** Report preview locations so a host editor can select the source range. */
    onSourceNavigate?: (target: LocalSourceTarget) => void;
    /**
     * Host-owned compile options. HTML capability flags select the temporary
     * whole-document native branch; Markdown capability options such as
     * `markdownBreaks` change the parsed tree. The component recompiles when a
     * flag, the soft-break option or the node budget changes, but not when an
     * equal object is recreated.
     */
    compileOptions?: LocalCompileOptions;
}
export type BaseConfigProps = {
    readonly getBaseConfig: () => LocalReactConfig;
};
type LocalDocumentViewCoreProps = LocalDocumentViewProps & BaseConfigProps & {
    readonly networkScope?: string | symbol;
};
/** Compatibility helper; controls and the renderer share the React-layer validation. */
export declare function textProblem(value: string, options: Parameters<typeof componentTextProblem>[1], t?: Localize): string | null;
export declare function LocalHtmlSourceFallback({ source, mode }: {
    source: string;
    mode: LocalRenderMode;
}): import("react").JSX.Element;
/** Keep the two render paths in separate components so mode changes obey hook ordering. */
export declare function LocalDocumentViewCore(props: LocalDocumentViewCoreProps): import("react").JSX.Element;
export {};
