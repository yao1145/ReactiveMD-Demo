import { type RenderEnv } from './view-render-context.js';
import type { LocalNode } from '../../types.js';
import { type ReactNode } from 'react';
import { type LocalFootnoteEntry } from '../../parsing/footnotes.js';
import type { Localize } from '../../../react/localization.js';
/**
 * Whitelist of source attributes that may reach a rendered P0 element. IDs are
 * always rewritten through this render instance's anchor namespace; source
 * `class`, `style`, URL schemes and event hooks never pass through here.
 */
export declare function safeHtmlProps(env: RenderEnv, node: LocalNode): Record<string, string>;
export declare function renderNodes(env: RenderEnv, nodes: LocalNode[] | undefined, visible: boolean, block?: boolean): ReactNode;
/** Render block-parsed children as inline content for labels and options. */
export declare function renderInlineNodes(env: RenderEnv, nodes: LocalNode[] | undefined, visible: boolean): ReactNode;
/**
 * One document-wide endnote list. Each item keeps every backlink for its
 * references so readers can return to any occurrence, not just the first.
 */
export declare function EndnotesView({ entries, env, t, titleId, }: {
    entries: readonly LocalFootnoteEntry[];
    env: RenderEnv;
    t: Localize;
    titleId: string;
}): import("react").JSX.Element;
