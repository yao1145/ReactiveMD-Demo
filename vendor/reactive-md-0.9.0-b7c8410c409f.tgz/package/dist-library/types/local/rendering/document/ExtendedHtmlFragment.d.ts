import type { Diagnostic, LocalHtmlPolicy } from '../../types.js';
export interface ExtendedHtmlFragmentProps {
    /** Raw fragment source as it appeared in the document, without its fence. */
    source: string;
    /** Effective policy for this mount (compile ceiling ∩ grants). */
    policy: LocalHtmlPolicy;
    /** Exact HTTPS origins this mount may frame; omission denies every remote frame. */
    allowedFrameOrigins?: readonly string[];
    inline?: boolean;
    sourceAttributes?: Record<string, string>;
    onDiagnostics?: (items: Diagnostic[]) => void;
}
/**
 * Isolated container for one extended HTML fragment.
 *
 * The fragment is sanitized locally and rendered inside a sandboxed `srcdoc`
 * iframe, so author markup never joins the host document: no event handlers
 * reach host nodes, no author style crosses the boundary, and the sandbox token
 * list excludes same-origin, top-level navigation and permission expansion.
 * A fragment that cannot be sanitized falls back to inert source text.
 *
 * Host grants are read at render time: a remote frame survives only when its
 * exact HTTPS origin is listed, and the same list becomes the container CSP's
 * `frame-src`. Everything else stays in the sanitizer's diagnostics; this
 * component renders the permitted subset. When the mount does not grant
 * extended HTML at all, the source is shown as inert text.
 */
export declare function ExtendedHtmlFragment({ source, policy, allowedFrameOrigins, inline, sourceAttributes, onDiagnostics, }: ExtendedHtmlFragmentProps): import("react").JSX.Element;
