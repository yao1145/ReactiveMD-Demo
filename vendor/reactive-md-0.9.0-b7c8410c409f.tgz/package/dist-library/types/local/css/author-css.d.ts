/**
 * Author CSS for independent documents.
 *
 * Two consumers share this module:
 *
 * - Component roots pass a declaration list (`css="max-width: 24rem"`) to
 *   `parseAuthorDeclarations`, which yields React style keys. Values keep a
 *   serializable `!important` suffix; interactive application should use
 *   `parseAuthorPriority` and `element.style.setProperty(name, value,
 *   'important')`, while SSR emits the same declaration text. React key names
 *   also make the record JSON-serializable without a second representation.
 * - Document `<css>` blocks pass a stylesheet to `scopeAuthorStyles`, which
 *   emits a single `@scope` rule rooted at the enclosing document or at a
 *   trusted selector, bounded by nested document roots.
 *
 * Everything here is pure string work. It runs unchanged in Node during SSR,
 * in a Worker, and in the browser; it never reads the DOM, and it never loads
 * an external resource. Unsupported constructs are dropped rather than
 * reinterpreted, so a hostile declaration cannot escape the `style` text or
 * the scope.
 */
/**
 * Attribute marking a mounted document root. Nested roots carrying it bound
 * the generated scope, so an inner document keeps its own author styles.
 */
export declare const LOCAL_AUTHOR_DOCUMENT_MARKER = "[data-rmd-document]";
export interface AuthorCssDeclaration {
    readonly property: string;
    readonly value: string;
    readonly important: boolean;
}
/**
 * Split a component `css` attribute into React style keys.
 *
 * Invalid declarations, unsupported property names and any value that would
 * load an external resource are skipped individually; the rest of the list is
 * still accepted. Duplicate properties follow CSS cascade order, including
 * `!important` precedence.
 */
export declare function parseAuthorDeclarations(source: string): Readonly<Record<string, string>>;
/** Split a serialized declaration value from its `!important` suffix. */
export declare function parseAuthorPriority(value: string): {
    value: string;
    important: boolean;
};
/**
 * Scope an author stylesheet to one mounted document.
 *
 * With no selector, the style element's parent is the scope root. An explicit
 * selector is validated for serialization. The lower bound excludes nested document
 * roots marked `[data-rmd-document]` together with their descendants, so an
 * inner document keeps its own author styles. Inherited properties still flow
 * in from the outer document by normal CSS inheritance.
 *
 * Returns an empty string when the stylesheet or selector yields nothing
 * usable. The result is safe to place inside a `<style>` element: every `<`
 * is CSS-escaped, so it cannot terminate the element.
 */
export declare function scopeAuthorStyles(source: string, selector?: string): string;
/** Locate unsupported global rules without rewriting comments or line endings. */
export declare function unsupportedAuthorCssRules(source: string, maxIssues: number): {
    name: string;
    start: number;
    end: number;
}[];
