import type { SourceRange } from '../types.js';
/** Repair the first Markdown code range that crosses a raw author block's end. */
export declare function maskLeakingAuthorBody(source: string, code: readonly SourceRange[], definitions: readonly SourceRange[], registered: {
    has(name: string): boolean;
}, from: number): {
    source: string;
    end: number;
} | undefined;
