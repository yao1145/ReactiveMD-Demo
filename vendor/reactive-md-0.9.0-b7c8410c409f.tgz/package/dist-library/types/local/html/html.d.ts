import type { Diagnostic, LocalHtmlPolicy } from '../types.js';
export interface LocalHtmlSanitizeResult {
    markup: string;
    diagnostics: Diagnostic[];
}
/** Fragment result: `markup` is absent when the fragment is not renderable. */
export interface LocalHtmlFragmentResult {
    markup?: string;
    diagnostics: Diagnostic[];
}
/** The sandbox always keeps author documents separate from their host. */
export declare function localHtmlSandbox(policy: LocalHtmlPolicy): string;
/**
 * Resources stay offline; extended HTML permits explicit HTTP(S) form
 * submissions. Passing `frameOrigins` restricts `frame-src` to those exact
 * HTTPS origins (an empty list keeps only `about:`). `fragment` selects the
 * stricter fragment scope, which also disables the document base and form
 * submission; omitting both arguments keeps the legacy whole-document policy.
 */
export declare function localHtmlContentSecurityPolicy(policy: LocalHtmlPolicy, frameOrigins?: readonly string[], fragment?: boolean): string;
/**
 * Normalize one host frame grant to an exact HTTPS origin. Anything with a
 * path, query, fragment, user info, wildcard, non-HTTPS scheme or an invalid
 * port is rejected rather than reinterpreted.
 */
export declare function normalizeLocalFrameOrigin(value: string): string | null;
/** Host grants for one mount; an empty list denies every remote frame. */
export declare function localHtmlFrameOrigins(allowedFrameOrigins?: readonly string[]): ReadonlySet<string>;
/**
 * Parse, sanitize and serialize a whole native HTML document. The result is a
 * complete document string suitable for a sandboxed `srcdoc` iframe.
 *
 * Host frame grants are optional; omitting them keeps the legacy behavior where
 * `frame-src` accepts `about:`, `data:` and `blob:`. Passing a list (including
 * an empty one) restricts frames to those exact HTTPS origins.
 */
export declare function sanitizeLocalHtmlDocument(source: string, policy: LocalHtmlPolicy, maxSyntaxNodes: number, allowedFrameOrigins?: readonly string[]): LocalHtmlSanitizeResult;
export declare const LOCAL_HTML_P0_ELEMENTS: Set<string>;
export declare const LOCAL_HTML_VOID_ELEMENTS: Set<string>;
/**
 * Parse, sanitize and serialize one extended HTML fragment. Unlike
 * `sanitizeLocalHtmlDocument` there is no document shell: the result is body
 * markup for an isolated container, and element offsets stay relative to the
 * fragment source. Every allow-list, attribute, URL, script, style and node
 * budget rule is shared with the whole-document pass.
 *
 * `markup` is absent only when the fragment cannot be rendered at all
 * (unparsable source or an exhausted node budget).
 */
export declare function sanitizeLocalHtmlFragment(source: string, policy: LocalHtmlPolicy, maxSyntaxNodes: number, allowedFrameOrigins?: readonly string[]): LocalHtmlFragmentResult;
