import { type RuntimeCore } from './runtime-document.js';
import type { Diagnostic, LocalDocument, LocalValue } from '../types.js';
import { validateValue } from './runtime-values.js';
import { type LocalStateRetentionDrop } from './retention.js';
/**
 * Migrate control state onto a new document. The retention plan decides what
 * is comparable at all; each surviving value is revalidated against the new
 * bindings and shared controls exactly like a parameter write would be.
 * Values the new constraints reject fall back to the new initial value,
 * except a value that a dependency had already narrowed out of range in the
 * previous document while the binding's constraint definition is unchanged:
 * dynamic constraints never reset such a value, so a migration must not either.
 */
export declare function migrateRuntimeState(core: RuntimeCore, state: Record<string, LocalValue>, next: LocalDocument, nextCore: RuntimeCore, prospectiveReader: (overrides: Readonly<Record<string, LocalValue>>, loaded: RuntimeCore, values: Record<string, LocalValue>) => Parameters<typeof validateValue>[3]): {
    values: Record<string, LocalValue>;
    retained: string[];
    dropped: LocalStateRetentionDrop[];
    diagnostics: Diagnostic[];
};
