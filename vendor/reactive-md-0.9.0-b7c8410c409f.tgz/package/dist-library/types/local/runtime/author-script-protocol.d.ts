import type { LocalValue } from '../types.js';
export declare const COUNTER_ACTIONS: readonly ['increment', 'decrement', 'reset'];
export type AuthorAction = (typeof COUNTER_ACTIONS)[number];
export type AuthorBindingRequest = {
    operation: 'get';
    name: string;
} | {
    operation: 'set';
    name: string;
    value: LocalValue;
} | {
    operation: 'setMany';
    values: Record<string, LocalValue>;
};
export type AuthorBindingReply = {
    ok: true;
    value?: LocalValue;
} | {
    ok: false;
    message: string;
};
export interface AuthorActionRegistration {
    target: string;
    action: AuthorAction;
    takeover: boolean;
}
export type AuthorWorkerInput = {
    kind: 'start';
    blocks: readonly string[];
    targets: readonly string[];
} | {
    kind: 'reply';
    id: number;
    result: AuthorBindingReply;
} | {
    kind: 'remove-targets';
    targets: string[];
} | {
    kind: 'action';
    target: string;
    action: AuthorAction;
};
export type AuthorWorkerOutput = {
    kind: 'request';
    id: number;
    request: AuthorBindingRequest;
    target?: string;
} | {
    kind: 'registered';
    registrations: AuthorActionRegistration[];
} | {
    kind: 'diagnostic';
    block: number;
    message: string;
} | {
    kind: 'failed';
    message: string;
};
