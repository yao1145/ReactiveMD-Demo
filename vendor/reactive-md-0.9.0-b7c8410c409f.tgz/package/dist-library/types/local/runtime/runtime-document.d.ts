import { type Diagnostic, type LocalBinding, type LocalComputation, type LocalDocument, type LocalNode, type LocalValidation, type LocalValue } from '../types.js';
import { LocalExpressionError, type LocalExpression } from '../evaluation/expression/compile.js';
import { type KernelValueRule } from '../configuration/kernel-value-rules.js';
import { type LocalDiagnosticDetails } from '../configuration/diagnostics.js';
interface RuntimeValidationRule {
    rule: LocalValidation;
    expression: LocalExpression | null;
    error: LocalExpressionError | null;
}
/**
 * Structural part of a runtime derived from one document. Rebuilt on every
 * document adoption; values, listeners and expression caches stay on the
 * runtime so identity survives an edit.
 */
export interface RuntimeCore {
    document: LocalDocument;
    nodeIndex: Map<string, LocalNode>;
    controls: Map<string, LocalNode[]>;
    slotKeys: Map<string, Record<string, string>>;
    publicNames: readonly string[];
    publicSlotOwners: Map<string, Set<string>>;
    initial: Record<string, LocalValue>;
    /** Compiled per-node string value rules; empty for hand-built documents. */
    valueRules: ReadonlyMap<string, readonly KernelValueRule[]>;
    /** True when the document has no kernel metadata (phase-one fixture). */
    legacyValueRules: boolean;
    /** Scalar binding key owned by a canonical node id (no multi-slot nodes). */
    bindingByNode: ReadonlyMap<string, string>;
    /** Node id -> declared ordered slot pairs, resolved to binding keys. */
    slotRelations: ReadonlyMap<string, readonly {
        lower: string;
        upper: string;
    }[]>;
    computationMetadata: Record<string, LocalComputation>;
    computationNames: string[];
    computationOrder: string[];
    cyclicComputations: string[];
    computationExpressions: Map<string, LocalExpression>;
    constValues: Record<string, LocalValue>;
    constErrors: Map<string, LocalExpressionError>;
    cycleErrors: Map<string, LocalExpressionError>;
    validationRules: RuntimeValidationRule[];
    validationLineStarts: number[];
}
/**
 * Position-free fingerprint of everything that constrains one binding: the
 * binding facts, each control's tag and attributes, its dynamic bound
 * expressions and its compiled value rules. Two documents with the same
 * fingerprint for a name validate that name identically given the same reads.
 */
export declare function constraintDefinition(loaded: RuntimeCore, name: string): string | undefined;
/**
 * Compile a metadata expression through the runtime-wide source cache. A
 * failed compile returns its error without caching it, so fixing the source
 * recovers on the next document adoption.
 */
export declare function compileMetadataExpression(source: string, cache: Map<string, LocalExpression>): {
    expression: LocalExpression;
    error: null;
} | {
    expression: null;
    error: LocalExpressionError;
};
export declare function loadRuntimeCore(document: LocalDocument, expressions: Map<string, LocalExpression>): RuntimeCore;
export declare function runtimeDocumentProblem(document: LocalDocument | null | undefined): string | null;
export declare function valueDiagnosticFor(core: RuntimeCore, binding: LocalBinding, detail: LocalDiagnosticDetails): Diagnostic;
/** Reject a range whose lower slot would cross its upper slot before any commit. */
export declare function slotRelationError(core: RuntimeCore, nodeId: string, next: Record<string, LocalValue>): boolean;
export declare function rangeOrderDiagnostic(core: RuntimeCore, nodeId: string): Diagnostic;
export declare const RUNTIME_EXPRESSION_CACHE_LIMIT = 200;
export {};
