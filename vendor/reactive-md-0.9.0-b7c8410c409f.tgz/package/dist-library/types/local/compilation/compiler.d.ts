/** Full local compile entry and tracked adapter for editing sessions. */
import type { LocalCompileOptions, LocalCompileResult } from '../types.js';
import { parseLocal } from '../parsing/parser.js';
import type { LocalTrackedSemanticService, SemanticCacheStats } from './compiler-services.js';
import type { InlinePlanLookup } from '../parsing/fast-markdown.js';
import type { SourceContext } from '../source/source-context.js';
/** Compile to plain data that can cross a React Server Component boundary. */
export declare function compileLocal(source: string, options?: LocalCompileOptions): LocalCompileResult;
/** Compiler-owned capture for editor sessions. Callers must copy before publishing. */
export interface LocalCompilerServices {
    parser?: {
        parse(source: string, options?: LocalCompileOptions, context?: SourceContext, rowPlans?: InlinePlanLookup): ReturnType<typeof parseLocal>;
    };
    semantic?: LocalTrackedSemanticService;
    /**
     * Per-row inline plans from the previous revision. Checked before the
     * session LRU so large sequential row blocks cannot thrash it.
     */
    rowPlans?: InlinePlanLookup;
}
export declare function compileLocalTracked(source: string, options?: LocalCompileOptions, services?: LocalCompilerServices): {
    result: LocalCompileResult;
    parsed?: ReturnType<typeof parseLocal>;
    semantic?: SemanticCacheStats;
    timings: Record<string, number>;
};
export declare function compileLocalDocument(source: string, options?: LocalCompileOptions): LocalCompileResult;
