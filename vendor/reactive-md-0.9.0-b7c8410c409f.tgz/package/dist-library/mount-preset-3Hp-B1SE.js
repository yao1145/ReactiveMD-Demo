import { z as e } from "./preset-core-CKc5YXSM.js";
import { G as t } from "./sdk-core-kYeF4_fO.js";
import { r as n } from "./package-core-BXKKPDuJ.js";
// src/components/mount-preset.ts
function r(r, i, a = []) {
	return n({
		protocol: e,
		preset: r,
		components: r.components.map((e) => t(e, { render: i[e.name] })),
		resources: a
	});
}
export { r as t };
