import { t as e } from "./compiler-core-BxgnUwc6.js";
import { S as t } from "./validation-Dds_T0Wx.js";
import { r as n } from "./html-BG9yhKhC.js";
import { s as r, y as i } from "./config-BadfhjdP.js";
import { r as a } from "./options-DTGPzSTZ.js";
import { t as o } from "./compiler-Cu4bKIyh.js";
import { u as s, w as c } from "./component-state-BoLCGee4.js";
import { n as l } from "./runtime-D5iLwh6z.js";
import { _ as u, d, h as f, i as p, u as m } from "./shareable-v9cEZH3r.js";
import { i as h, t as g } from "./resources-D2GDQS0p.js";
import { jsx as _ } from "react/jsx-runtime";
import { createRoot as v, hydrateRoot as y } from "react-dom/client";
// src/standalone/diagnostics.ts
function b(e, t) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function x(e, t = 8) {
	let n = e.slice(0, t).map((e) => `- [${e.code}] ${e.message} (line ${e.line}, column ${e.column})`);
	return e.length > n.length && n.push(`- ${e.length - n.length} more diagnostic(s).`), n.join("\n");
}
function S(e) {
	return e instanceof Error ? e.message : String(e);
}
var C = class extends Error {
	diagnostics;
	constructor(e, t) {
		let n = x(t);
		super(n ? `${e}\n${n}` : e), this.name = "ReactiveMDMountError", this.diagnostics = t;
	}
};
function w(e, t = "standalone.mount") {
	if (typeof e == "object" && e && Array.isArray(e.diagnostics)) {
		let t = e.diagnostics;
		if (t.length > 0) return t;
	}
	return [b(t, S(e))];
}
// src/standalone/events.ts
var T = "reactive-md-diagnostics", E = "reactive-md-state-change", D = /^[A-Za-z][A-Za-z0-9_-]*$/, O = 256, k = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, A = /[\u0000-\u001f\u007f-\u009f]/, j = 64, M = 4096, N = 41943040;
function P(e, t) {
	if (e === void 0) return;
	if (!I(e)) {
		t("standalone.payload.images", "images must be a JSON object mapping image URLs to data URLs.");
		return;
	}
	let n = Object.entries(e);
	if (n.length > j) {
		t("standalone.payload.images", `images cannot contain more than ${j} entries.`);
		return;
	}
	let r = Object.create(null), i = 0;
	for (let [e, a] of n) if (!e || e.length > M || e === "__proto__" || A.test(e) || typeof a != "string" || !k.test(a)) t("standalone.payload.images", "Every image entry must use a bounded URL key and a base64 raster data URL.");
	else {
		if (i += a.length, i > N) {
			t("standalone.payload.images", "The embedded image map exceeds the 40 MiB budget.");
			return;
		}
		r[e] = a;
	}
	return r;
}
function F(e, t) {
	if (e === void 0) return;
	let n = a(e);
	if (!n.ok) t("standalone.payload.compile-options", `The payload compile options are invalid: ${n.message}`);
	else return d(e);
}
function I(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function L(e, t) {
	if (e === void 0) return;
	let n = c(e);
	if (typeof e != "string" || n !== e) t("standalone.payload.document-id", "The payload documentId must be a canonical 1-256 character string.");
	else return n;
}
function R(e, t) {
	if (e !== void 0) {
		if (typeof e != "number" || !Number.isInteger(e) || e < 0 || e > 4294967295) t("standalone.payload.random-seed", "The payload randomSeed must be a 32-bit unsigned integer.");
		else return e;
	}
}
function z(e, t) {
	if (e === void 0) return;
	let n = s(e);
	if (!n.ok || n.diagnostics.length > 0) {
		let e = n.diagnostics;
		e.length === 0 && t("standalone.payload.component-state", "The payload component state is invalid.");
		for (let n of e) t("standalone.payload.component-state", n.message);
	} else return n.document;
}
function B(e) {
	let t = [], n = (e, n) => {
		t.push(b(e, n));
	};
	if (!I(e)) return {
		ok: !1,
		diagnostics: [b("standalone.payload.shape", "The reactive-md payload must be a JSON object.")]
	};
	e.version !== 1 && e.version !== 2 && n("standalone.payload.version", "The reactive-md payload must use version 1 or 2."), e.version === 2 && e.restoration === void 0 && n("standalone.payload.requirements", "Version 2 requires restoration contracts."), e.version === 1 && (e.restoration !== void 0 || e.resources !== void 0) && n("standalone.payload.version", "Restoration contracts require payload version 2.");
	let r = e.target;
	typeof r != "string" || r.length === 0 || r.length > O ? n("standalone.payload.target", `The payload target must be an element id of 1-${O} characters.`) : D.test(r) || n("standalone.payload.target", "The payload target must start with a letter and use only letters, digits, underscores or hyphens.");
	let i = e.source;
	typeof i != "string" && n("standalone.payload.source", "The payload source must be a string.");
	let a = e.locale === void 0 ? "en" : e.locale;
	a !== "en" && a !== "zh" && n("standalone.payload.locale", "The payload locale must be \"en\" or \"zh\".");
	let o = e.colorScheme === void 0 ? "auto" : e.colorScheme;
	o !== "light" && o !== "dark" && o !== "auto" && n("standalone.payload.color-scheme", "The payload colorScheme must be \"light\", \"dark\" or \"auto\".");
	let s = e.hydrate !== void 0 && e.hydrate;
	typeof s != "boolean" && n("standalone.payload.hydrate", "The payload hydrate flag must be a boolean.");
	let c = e.state;
	I(c) || n("standalone.payload.state", "The payload state must be a JSON object.");
	let l = e.sourceSemantics;
	l !== void 0 && l !== "mixed-rmd-v1" && n("standalone.payload.source-semantics", "Unsupported Reactive MD source semantics.");
	let u = F(l === void 0 && I(e.compileOptions) ? {
		enableCss: !1,
		...e.compileOptions
	} : e.compileOptions, n);
	t.push(...h(e.extensions, u?.config));
	let d = g(e.resources ?? []);
	t.push(...d.diagnostics), t.push(...m(e.restoration, {
		config: u?.config,
		source: typeof i == "string" ? i : "",
		resources: d.resources
	}));
	let f = P(e.images, n), p = L(e.documentId, n), _ = R(e.randomSeed, n), v = z(e.componentState, n);
	return t.length > 0 ? {
		ok: !1,
		diagnostics: t
	} : {
		ok: !0,
		payload: {
			version: e.version,
			...l === "mixed-rmd-v1" ? { sourceSemantics: l } : {},
			target: r,
			source: i,
			state: c,
			locale: a,
			colorScheme: o,
			hydrate: s,
			...u === void 0 ? {} : { compileOptions: u },
			...e.extensions === void 0 ? {} : { extensions: e.extensions },
			...e.restoration === void 0 ? {} : {
				restoration: e.restoration,
				resources: d.resources
			},
			...f && Object.keys(f).length > 0 ? { images: f } : {},
			...p === void 0 ? {} : { documentId: p },
			..._ === void 0 ? {} : { randomSeed: _ },
			...v === void 0 ? {} : { componentState: v }
		}
	};
}
function V(e) {
	try {
		return B(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [b("standalone.payload.invalid", `The reactive-md payload could not be read: ${S(e)}`)]
		};
	}
}
// src/standalone/prepare.ts
function H(r, i, s, c, l, d = !1) {
	if (typeof r != "string") throw new C("Cannot mount a Reactive MD document: source must be a string.", [b("standalone.source", "source must be a string.")]);
	let f = d && c?.enableCss === void 0 ? {
		...c,
		enableCss: !1
	} : c, m = a(f), h = d && m.ok && (m.html.enableCss || m.html.enableJavaScript || m.html.enableExtendedHtml), g = h ? e(r, m, n) : o(r, f), _;
	if (g.ok) _ = g.document;
	else {
		if (!h) throw new C("Cannot mount a Reactive MD document: the source contains syntax errors.", g.diagnostics);
		_ = {
			syntax: "local",
			syntaxVersion: t,
			source: r,
			html: m.html,
			initialState: {},
			bindings: {},
			nodes: [{
				type: "fallback",
				id: "local-0",
				range: {
					start: 0,
					end: r.length
				},
				value: r
			}]
		};
	}
	if (l?.(_), i !== void 0) {
		let e = u(i);
		if (!e.ok) throw new C("Cannot mount a Reactive MD document: the state payload is invalid.", e.diagnostics);
		let t = p(_, e.file);
		if (!t.ok) throw new C("Cannot mount a Reactive MD document: the state does not match this source.", t.diagnostics);
		_ = t.baseline.document;
	}
	return typeof s == "string" && s.trim().length > 0 && (_ = {
		..._,
		theme: s.trim(),
		themeRange: void 0
	}), {
		document: _,
		diagnostics: g.diagnostics.slice()
	};
}
var U = Object.freeze({
	name: "reactive-md-standalone",
	version: "0.4.0"
}), W = "data-reactive-md-mounted", G = "script[type=\"application/reactive-md+json\"][data-reactive-md-auto]", K = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, q = 64;
function J(e) {
	if (!e) return {};
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e).slice(0, q)) typeof n == "string" && n.length > 0 && typeof r == "string" && K.test(r) && t.set(n, r);
	return t.size === 0 ? {} : {
		urlPolicy: (e, n) => n === "link" || t.has(e),
		imageResolver: (e) => t.get(e) ?? null
	};
}
var Y = /* @__PURE__ */ new WeakSet();
function X(e) {
	return Y.has(e) || e.hasAttribute("data-reactive-md-mounted");
}
function ee(e, t) {
	return f(e, t);
}
function Z(e) {
	if (e) try {
		e();
	} catch {}
}
function te(e) {
	let t = () => {
		let t = e.querySelector("article.local-document");
		t && (t.classList.remove("local-static-first", "reactive-md-static-first", "reactive-md-hydrating"), t.removeAttribute("data-static-first"), t.removeAttribute("data-reactive-md-static-first")), e.classList.remove("local-static-first", "reactive-md-static-first"), e.removeAttribute("data-static-first");
	};
	if (typeof requestAnimationFrame != "function") return t(), () => {};
	let n = 0, r = 0;
	return n = requestAnimationFrame(() => {
		t(), r = requestAnimationFrame(t);
	}), () => {
		typeof cancelAnimationFrame == "function" && (cancelAnimationFrame(n), r && cancelAnimationFrame(r));
	};
}
function Q(e, t, n, a = {}) {
	if (!e || typeof e != "object" || !("nodeType" in e) || !e.hasAttribute) throw new C("Cannot mount a Reactive MD document: element must be an HTMLElement.", [b("standalone.element", "element must be an HTMLElement.")]);
	if (X(e)) throw new C("Cannot mount a Reactive MD document: this element is already mounted.", [b("standalone.mount", "The target element already hosts a Reactive MD document.")]);
	if (!t || typeof t != "object") throw new C("Cannot mount a Reactive MD document: options are required.", [b("standalone.options", "mount requires an options object with a source string.")]);
	let o = t.compileOptions;
	if (t.reactConfig) {
		if (o?.hostComponents !== void 0 || t.themes !== void 0) throw new C("Conflicting extension registration.", [b("local.extension.config", "reactConfig cannot be combined with hostComponents or themes.")]);
		if (o?.config && r(o.config).key !== t.reactConfig.config.key) throw new C("The export configuration differs from the installed bundle.", [b("local.extension.config", "Compile configuration does not match installed implementations.")]);
		o = {
			...o,
			config: t.reactConfig.config
		};
	}
	let s = h(t.extensions, t.reactConfig?.config);
	if (s.length) throw new C("Extension requirements are not satisfied.", s);
	let c = m(t.restoration, {
		config: t.reactConfig?.config ?? o?.config,
		source: t.source,
		resources: t.resources
	});
	if (c.length) throw new C("Restoration requirements are not satisfied.", c);
	let u = g(t.resources ?? []);
	if (u.diagnostics.length) throw new C("Style resources are invalid.", u.diagnostics);
	let d = H(t.source, t.state, a.theme, o, (e) => {
		let n = h(e.extensions, t.reactConfig?.config);
		if (n.push(...m(t.restoration, {
			config: t.reactConfig?.config ?? o?.config,
			source: t.source,
			resources: t.resources,
			document: e
		})), n.length) throw new C("Installed contracts must match before state recovery.", n);
	}, a.legacyPayload), f = h(d.document.extensions, t.reactConfig?.config);
	if (f.length) throw new C("Installed extension implementations are required.", f);
	let p = o?.config, x = p?.key ?? d.document.componentConfigKey, T = p?.legacyKeys.map((e) => e.key) ?? [], E;
	try {
		E = l(d.document, {
			documentId: t.documentId,
			randomSeed: t.randomSeed,
			componentState: t.componentState,
			...x === void 0 ? {} : { configKey: x },
			...T.length === 0 ? {} : { legacyConfigKeys: T }
		});
	} catch (e) {
		throw new C("Cannot mount a Reactive MD document: the interactive runtime could not be created.", [b("standalone.runtime", S(e))]);
	}
	let D = t.generator ?? U, O = J(t.images), k = t.urlPolicy ?? O.urlPolicy, A = t.imageResolver ?? O.imageResolver, j = () => ee(E, D), M;
	try {
		M = j();
	} catch (e) {
		try {
			E.dispose();
		} catch {}
		throw new C("Cannot mount a Reactive MD document: the initial state could not be captured.", [b("standalone.state", S(e))]);
	}
	let N = !1, P = (e) => {
		N || Z(a.onDiagnostics ? () => a.onDiagnostics(e) : void 0);
	}, F = (() => {
		try {
			return E.services?.state.diagnostics() ?? [];
		} catch {
			return [];
		}
	})(), I = t.hydrate === !0 && e.hasChildNodes(), L = /* @__PURE__ */ _(n, {
		document: d.document,
		capabilityGrants: o,
		runtime: E,
		onDiagnostics: P,
		urlPolicy: k,
		locale: t.locale ?? "en",
		themes: t.themes,
		reactConfig: t.reactConfig,
		colorScheme: t.colorScheme ?? "auto",
		mode: "interactive",
		staticFirst: I,
		imageResolver: A
	});
	if (!I) for (; e.firstChild;) e.removeChild(e.firstChild);
	let R = null, z = [];
	try {
		for (let [t, n] of u.resources.entries()) {
			let r = e.ownerDocument.createElement("style");
			r.setAttribute("data-reactive-md-resource", n.id), r.textContent = t === 0 ? `${i}\n${n.css}` : n.css, (e.ownerDocument.head ?? e.ownerDocument.documentElement).appendChild(r), z.push(r);
		}
		R = I ? y(e, L) : v(e), I || R.render(L);
	} catch (e) {
		z.forEach((e) => e.remove());
		try {
			R?.unmount();
		} catch {}
		try {
			E.dispose();
		} catch {}
		throw new C("Cannot mount a Reactive MD document: React could not render the document.", w(e, "standalone.render"));
	}
	Y.add(e), e.setAttribute(W, "");
	let B = a.onStateChange ? E.subscribe(() => {
		if (N) return;
		let e;
		try {
			e = j();
		} catch {
			return;
		}
		Z(a.onStateChange ? () => a.onStateChange(e) : void 0);
	}) : () => {};
	Z(a.onStateChange ? () => a.onStateChange(M) : void 0), d.diagnostics.length > 0 && P(d.diagnostics), F.length > 0 && P([...F]);
	let V = I ? te(e) : () => {};
	return {
		element: e,
		getState() {
			if (N) throw Error("This Reactive MD document has been unmounted.");
			return j();
		},
		unmount: () => {
			if (!N) {
				N = !0, B(), V(), z.forEach((e) => e.remove());
				try {
					R?.unmount();
				} catch {}
				try {
					E.dispose();
				} catch {}
				Y.delete(e), e.getAttribute("data-reactive-md-mounted") === "" && e.removeAttribute(W);
			}
		}
	};
}
function $(e, t, n) {
	if (typeof console < "u" && typeof console.error == "function") try {
		console.error(`Reactive MD: ${n.map((e) => `[${e.code}] ${e.message}`).join(" ")}`);
	} catch {}
	let r = e.defaultView?.CustomEvent;
	if (typeof r == "function") try {
		t.dispatchEvent(new r(T, {
			detail: n,
			bubbles: !0,
			composed: !0
		}));
	} catch {}
}
function ne(e, t) {
	let n = t.defaultView?.HTMLElement;
	return n ? e instanceof n : e.namespaceURI === "http://www.w3.org/1999/xhtml";
}
function re(e, t, n = {}) {
	if (typeof document > "u") return [];
	let r = t ?? document, i = r, a = i.nodeType === 9 ? r : i.ownerDocument ?? document, o = [], s;
	try {
		s = Array.from(r.querySelectorAll(G));
	} catch {
		return o;
	}
	for (let t of s) {
		let s;
		try {
			s = V(JSON.parse(t.textContent ?? ""));
		} catch (e) {
			$(a, t, [b("standalone.payload.json", `The reactive-md payload is not valid JSON: ${S(e)}`)]);
			continue;
		}
		if (!s.ok) {
			$(a, t, s.diagnostics);
			continue;
		}
		let c = s.payload, l = r, u = (typeof l.getElementById == "function" ? l.getElementById(c.target) : null) ?? a.getElementById(c.target);
		if (!u) $(a, t, [b("standalone.target.missing", `The reactive-md payload target "#${c.target}" was not found.`)]);
		else if (i !== a && !i.contains(u)) $(a, t, [b("standalone.target.scope", "The reactive-md payload target is outside the scanned root.")]);
		else if (!ne(u, a)) $(a, t, [b("standalone.target.type", "The reactive-md payload target must be an HTML element.")]);
		else if (!X(u)) try {
			o.push(Q(u, {
				source: c.source,
				state: c.state,
				locale: c.locale,
				colorScheme: c.colorScheme,
				hydrate: c.hydrate,
				images: c.images,
				compileOptions: c.compileOptions,
				extensions: c.extensions,
				restoration: c.restoration,
				resources: c.resources,
				documentId: c.documentId,
				randomSeed: c.randomSeed,
				componentState: c.componentState,
				reactConfig: n.reactConfig
			}, e, {
				legacyPayload: c.sourceSemantics === void 0,
				onDiagnostics: (e) => $(a, u, e)
			}));
		} catch (e) {
			$(a, u, w(e));
		}
	}
	return o;
}
export { V as a, C as c, re as i, Q as n, T as o, X as r, E as s, W as t };
