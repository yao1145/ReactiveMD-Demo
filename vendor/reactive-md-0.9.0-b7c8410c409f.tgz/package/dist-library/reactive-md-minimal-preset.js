import { o as e } from "./preset-core-CKc5YXSM.js";
import { t } from "./plugin-packs-B1XPWcFs.js";
// src/presets/minimal.ts
var n = t(e, [
	"input",
	"textarea",
	"number",
	"slider",
	"toggle",
	"date",
	"select",
	"option",
	"text",
	"if",
	"alert",
	"badge",
	"panel",
	"card",
	"grid",
	"section",
	"jump",
	"anchor"
]);
export { n as default, n as minimalPreset };
