import { R as e, a as t, i as n, t as r } from "./preset-core-CKc5YXSM.js";
import { t as i } from "./default-components-BwQf0oP-.js";
// src/presets/default.ts
var a = r({
	protocol: e,
	id: n,
	version: t,
	components: i
});
export { a as default, a as defaultPreset };
