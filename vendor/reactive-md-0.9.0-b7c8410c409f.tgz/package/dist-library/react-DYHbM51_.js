import { n as e } from "./sdk-core-kYeF4_fO.js";
import { a as t } from "./LocalDocumentView-DG3QT5C7.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
