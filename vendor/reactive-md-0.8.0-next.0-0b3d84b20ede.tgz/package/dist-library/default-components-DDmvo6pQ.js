import { $ as e, N as t, Q as n, et as r, nt as i, ot as a, w as o, z as s } from "./identity-MYJXKSkB.js";
// src/presets/default-authoring.ts
var c = Object.freeze([
	{
		id: "input",
		title: {
			en: "Input controls",
			zh: "输入控件"
		}
	},
	{
		id: "action",
		title: {
			en: "Interactive tools",
			zh: "交互工具"
		}
	},
	{
		id: "layout",
		title: {
			en: "Content layout",
			zh: "内容组织"
		}
	},
	{
		id: "data",
		title: {
			en: "Data visualization",
			zh: "数据可视化"
		}
	},
	{
		id: "hint",
		title: {
			en: "Feedback",
			zh: "提示反馈"
		}
	}
]), l = new Set(c.map((e) => e.id)), u = Object.freeze({
	jump: {
		title: {
			en: "Jump and anchor",
			zh: "跳转与锚点"
		},
		description: {
			en: "Link to a named position in this document.",
			zh: "跳到当前文档中的指定位置。"
		},
		category: "action",
		keywords: {
			en: [
				"jump",
				"anchor",
				"navigation"
			],
			zh: [
				"跳转",
				"锚点",
				"导航"
			]
		},
		insertText: {
			en: "<jump to=\"{{bind:destination}}\" appearance=\"button\" color=\"#2563eb\">View results</jump>\n\n<anchor id=\"{{bind:destination}}\">\n\n{{selection:Results appear here.}}",
			zh: "<jump to=\"{{bind:destination}}\" appearance=\"button\" color=\"#2563eb\">查看结果</jump>\n\n<anchor id=\"{{bind:destination}}\">\n\n{{selection:结果显示在这里。}}"
		},
		extended: !0
	},
	anchor: {
		title: {
			en: "Anchor",
			zh: "锚点"
		},
		description: {
			en: "Name a destination for document links.",
			zh: "为文档内的跳转指定目标位置。"
		},
		category: "layout",
		keywords: {
			en: [
				"anchor",
				"target",
				"destination"
			],
			zh: [
				"锚点",
				"目标",
				"位置"
			]
		},
		insertText: {
			en: "<anchor id=\"{{bind:destination}}\">",
			zh: "<anchor id=\"{{bind:destination}}\">"
		},
		extended: !0
	},
	text: {
		title: {
			en: "Colored text",
			zh: "文字颜色"
		},
		description: {
			en: "Give selected words a foreground color.",
			zh: "为选中的局部文字指定颜色。"
		},
		category: "hint",
		keywords: {
			en: [
				"text",
				"color",
				"foreground"
			],
			zh: [
				"文字",
				"颜色",
				"前景"
			]
		},
		inline: !0,
		insertText: {
			en: "<text color=\"#a2273a\">{{selection:Important reminder}}</text>",
			zh: "<text color=\"#a2273a\">{{selection:重要提醒}}</text>"
		},
		extended: !0
	},
	section: {
		title: {
			en: "Colored section",
			zh: "正文颜色"
		},
		description: {
			en: "Apply a shared text color to several paragraphs.",
			zh: "为一段或多段正文指定统一颜色。"
		},
		category: "layout",
		keywords: {
			en: [
				"section",
				"color",
				"paragraph"
			],
			zh: [
				"正文",
				"段落",
				"颜色"
			]
		},
		insertText: {
			en: "<section color=\"#45536f\">\n\n{{selection:Your paragraphs go here.}}\n\n</section>",
			zh: "<section color=\"#45536f\">\n\n{{selection:在这里填写正文。}}\n\n</section>"
		},
		extended: !0
	},
	"multi-select": {
		title: {
			en: "Multiple selection",
			zh: "多选"
		},
		description: {
			en: "Choose up to two items and read their values.",
			zh: "最多选择两个选项，公开选项值数组。"
		},
		category: "input",
		keywords: {
			en: [
				"multiple",
				"select",
				"subjects",
				"checkbox"
			],
			zh: [
				"多选",
				"选项",
				"主题"
			]
		},
		insertText: {
			en: "<multi-select bind=\"{{bind:subjects}}\" label=\"Subjects\" max-selected=\"2\">\n<option value=\"math\">Math</option>\n<option value=\"physics\">Physics</option>\n<option value=\"chemistry\">Chemistry</option>\n</multi-select>",
			zh: "<multi-select bind=\"{{bind:subjects}}\" label=\"主题\" max-selected=\"2\">\n<option value=\"math\">数学</option>\n<option value=\"physics\">物理</option>\n<option value=\"chemistry\">化学</option>\n</multi-select>"
		},
		extended: !0
	},
	"range-slider": {
		title: {
			en: "Interval slider",
			zh: "区间滑块"
		},
		description: {
			en: "Choose the lower and upper bounds of an interval.",
			zh: "同时选择区间的起点和终点。"
		},
		category: "input",
		keywords: {
			en: [
				"range",
				"interval",
				"slider",
				"bounds"
			],
			zh: [
				"区间",
				"滑块",
				"上下限"
			]
		},
		insertText: {
			en: "<range-slider label=\"Interval\" bind-start=\"{{bind:low}}\" bind-end=\"{{bind:high}}\" initial-start=\"20\" initial-end=\"80\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<range-slider label=\"观察区间\" bind-start=\"{{bind:low}}\" bind-end=\"{{bind:high}}\" initial-start=\"20\" initial-end=\"80\" min=\"0\" max=\"100\" step=\"1\">"
		},
		extended: !0
	},
	coordinate: {
		title: {
			en: "Coordinate point",
			zh: "二维坐标"
		},
		description: {
			en: "Drag a point or change its two coordinates.",
			zh: "拖动坐标点，或直接修改两个坐标。"
		},
		category: "input",
		keywords: {
			en: [
				"coordinate",
				"point",
				"drag",
				"geometry"
			],
			zh: [
				"坐标",
				"拖动",
				"几何"
			]
		},
		insertText: {
			en: "<coordinate label=\"Point\" bind-x=\"{{bind:px}}\" bind-y=\"{{bind:py}}\" initial-x=\"1\" initial-y=\"2\" x-min=\"-5\" x-max=\"5\" y-min=\"-5\" y-max=\"5\">",
			zh: "<coordinate label=\"坐标点\" bind-x=\"{{bind:px}}\" bind-y=\"{{bind:py}}\" initial-x=\"1\" initial-y=\"2\" x-min=\"-5\" x-max=\"5\" y-min=\"-5\" y-max=\"5\">"
		},
		extended: !0
	},
	quiz: {
		title: {
			en: "Practice question",
			zh: "练习题"
		},
		description: {
			en: "Check an answer and read a short explanation.",
			zh: "检查答案并阅读简短解析。"
		},
		category: "action",
		keywords: {
			en: [
				"quiz",
				"practice",
				"answer",
				"learn"
			],
			zh: [
				"练习",
				"题目",
				"答案"
			]
		},
		insertText: {
			en: "<quiz type=\"choice\" label=\"What is 2 + 3?\" answer=\"b\" explanation=\"The sum is 5.\">\n<option value=\"a\">4</option>\n<option value=\"b\">5</option>\n</quiz>",
			zh: "<quiz type=\"choice\" label=\"2 + 3 等于多少？\" answer=\"b\" explanation=\"相加得到 5。\">\n<option value=\"a\">4</option>\n<option value=\"b\">5</option>\n</quiz>"
		},
		extended: !0
	},
	steps: {
		title: {
			en: "Guided steps",
			zh: "分步阅读"
		},
		description: {
			en: "Read instructions one step at a time.",
			zh: "按顺序阅读说明，内置上一步和下一步。"
		},
		category: "layout",
		keywords: {
			en: [
				"steps",
				"guide",
				"previous",
				"next"
			],
			zh: [
				"步骤",
				"引导",
				"下一步"
			]
		},
		insertText: {
			en: "<steps label=\"Learning path\" bind=\"{{bind:lesson}}\">\n<step label=\"Observe\">\nChange a parameter.\n</step>\n<step label=\"Practice\">\nCheck an answer.\n</step>\n</steps>",
			zh: "<steps label=\"学习路线\" bind=\"{{bind:lesson}}\">\n<step label=\"观察\">\n调整参数。\n</step>\n<step label=\"练习\">\n检查答案。\n</step>\n</steps>"
		},
		extended: !0
	},
	slider: {
		title: {
			en: "Slider",
			zh: "滑块"
		},
		description: {
			en: "Drag the slider to choose a number within a range.",
			zh: "拖动滑块在指定范围内选择一个数值。"
		},
		category: "input",
		keywords: {
			en: [
				"slider",
				"range",
				"number",
				"drag",
				"value"
			],
			zh: [
				"滑块",
				"范围",
				"数值",
				"拖动",
				"滑动"
			]
		},
		insertText: {
			en: "<slider bind=\"{{bind:amount}}\" label=\"Amount\" initial=\"10\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<slider bind=\"{{bind:amount}}\" label=\"数量\" initial=\"10\" min=\"0\" max=\"100\" step=\"1\">"
		}
	},
	number: {
		title: {
			en: "Number input",
			zh: "数字输入"
		},
		description: {
			en: "Enter an exact number with an optional range and step.",
			zh: "输入精确数字，可限制范围和步长。"
		},
		category: "input",
		keywords: {
			en: [
				"number",
				"numeric",
				"input",
				"step",
				"quantity"
			],
			zh: [
				"数字",
				"数值",
				"输入",
				"步长",
				"数量"
			]
		},
		insertText: {
			en: "<number bind=\"{{bind:quantity}}\" label=\"Quantity\" initial=\"1\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<number bind=\"{{bind:quantity}}\" label=\"数量\" initial=\"1\" min=\"0\" max=\"100\" step=\"1\">"
		}
	},
	input: {
		title: {
			en: "Single-line text",
			zh: "单行文本"
		},
		description: {
			en: "Enter a name, title or other single-line text.",
			zh: "输入姓名、标题等单行文本。"
		},
		category: "input",
		keywords: {
			en: [
				"input",
				"text",
				"single-line",
				"field",
				"name"
			],
			zh: [
				"文本",
				"单行",
				"输入框",
				"名称",
				"输入"
			]
		},
		insertText: {
			en: "<input bind=\"{{bind:name}}\" label=\"Name\" placeholder=\"Enter a name\">",
			zh: "<input bind=\"{{bind:name}}\" label=\"名称\" placeholder=\"请输入名称\">"
		}
	},
	textarea: {
		title: {
			en: "Multi-line text",
			zh: "多行文本"
		},
		description: {
			en: "Enter notes, descriptions or other multi-line text.",
			zh: "输入说明、备注等多行文字。"
		},
		category: "input",
		keywords: {
			en: [
				"textarea",
				"text area",
				"multi-line",
				"notes",
				"description"
			],
			zh: [
				"文本域",
				"多行",
				"说明",
				"备注",
				"详细"
			]
		},
		insertText: {
			en: "<textarea bind=\"{{bind:message}}\" label=\"Details\" placeholder=\"Enter details\" rows=\"4\">",
			zh: "<textarea bind=\"{{bind:message}}\" label=\"详细说明\" placeholder=\"请输入详细说明\" rows=\"4\">"
		}
	},
	toggle: {
		title: {
			en: "Toggle",
			zh: "开关"
		},
		description: {
			en: "Switch a boolean option on or off.",
			zh: "在开启与关闭之间切换一个布尔选项。"
		},
		category: "input",
		keywords: {
			en: [
				"toggle",
				"switch",
				"boolean",
				"enable",
				"on"
			],
			zh: [
				"开关",
				"布尔",
				"启用",
				"切换",
				"选项"
			]
		},
		insertText: {
			en: "<toggle bind=\"{{bind:enabled}}\" label=\"Enable option\">",
			zh: "<toggle bind=\"{{bind:enabled}}\" label=\"启用选项\">"
		}
	},
	checkbox: {
		title: {
			en: "Checkbox",
			zh: "复选框"
		},
		description: {
			en: "Check or uncheck a boolean option.",
			zh: "勾选或取消一个布尔选项。"
		},
		category: "input",
		keywords: {
			en: [
				"checkbox",
				"check",
				"boolean",
				"confirm",
				"option"
			],
			zh: [
				"复选",
				"勾选",
				"布尔",
				"确认",
				"选项"
			]
		},
		insertText: {
			en: "<checkbox bind=\"{{bind:confirmed}}\" label=\"Confirm option\">",
			zh: "<checkbox bind=\"{{bind:confirmed}}\" label=\"确认选项\">"
		}
	},
	date: {
		title: {
			en: "Date picker",
			zh: "日期选择"
		},
		description: {
			en: "Pick a date; the value stays empty until one is chosen.",
			zh: "选择一个日期，未选择时为空字符串。"
		},
		category: "input",
		keywords: {
			en: [
				"date",
				"calendar",
				"picker",
				"day"
			],
			zh: [
				"日期",
				"日历",
				"时间",
				"选择"
			]
		},
		insertText: {
			en: "<date bind=\"{{bind:date}}\" label=\"Pick a date\">",
			zh: "<date bind=\"{{bind:date}}\" label=\"选择日期\">"
		}
	},
	choices: {
		title: {
			en: "Choice cards",
			zh: "选项卡片"
		},
		description: {
			en: "Pick one option from a set of cards.",
			zh: "从多个选项卡中选择一项。"
		},
		category: "input",
		keywords: {
			en: [
				"choices",
				"options",
				"cards",
				"select",
				"radio"
			],
			zh: [
				"选项",
				"选择",
				"卡片",
				"单选",
				"方案"
			]
		},
		insertText: {
			en: "<choices bind=\"{{bind:plan}}\" label=\"Choose a plan\">\n<option value=\"basic\">Basic</option>\n<option value=\"pro\">Pro</option>\n</choices>",
			zh: "<choices bind=\"{{bind:plan}}\" label=\"选择方案\">\n<option value=\"basic\">基础版</option>\n<option value=\"pro\">专业版</option>\n</choices>"
		}
	},
	counter: {
		title: {
			en: "Counter",
			zh: "计数器"
		},
		description: {
			en: "Adjust an integer with plus and minus buttons, then reset it in one click.",
			zh: "通过加减按钮调整整数，并可一键重置。"
		},
		category: "action",
		keywords: {
			en: [
				"counter",
				"count",
				"plus",
				"minus",
				"integer"
			],
			zh: [
				"计数",
				"加减",
				"整数",
				"调整",
				"重置"
			]
		},
		insertText: {
			en: "<counter bind=\"{{bind:count}}\" label=\"Count\" initial=\"0\" min=\"0\" max=\"99\">",
			zh: "<counter bind=\"{{bind:count}}\" label=\"计数\" initial=\"0\" min=\"0\" max=\"99\">"
		}
	},
	timer: {
		title: {
			en: "Countdown timer",
			zh: "倒计时"
		},
		description: {
			en: "Start, pause and reset a focus timer.",
			zh: "启动、暂停和重置一段专注计时。"
		},
		category: "action",
		keywords: {
			en: [
				"timer",
				"countdown",
				"focus",
				"seconds",
				"pause"
			],
			zh: [
				"计时",
				"倒计时",
				"专注",
				"秒",
				"暂停"
			]
		},
		insertText: {
			en: "<timer bind=\"{{bind:remaining}}\" label=\"Focus timer\" duration=\"60\">",
			zh: "<timer bind=\"{{bind:remaining}}\" label=\"专注计时\" duration=\"60\">"
		}
	},
	checklist: {
		title: {
			en: "Checklist",
			zh: "任务清单"
		},
		description: {
			en: "Track completion with a checkable task list.",
			zh: "用可勾选的任务列表记录完成情况。"
		},
		category: "action",
		keywords: {
			en: [
				"checklist",
				"tasks",
				"todo",
				"check",
				"done"
			],
			zh: [
				"清单",
				"任务",
				"勾选",
				"待办",
				"完成"
			]
		},
		insertText: {
			en: "<checklist bind=\"{{bind:done}}\" label=\"Task checklist\">\n- [ ] First task\n- [ ] Second task\n- [ ] Third task\n</checklist>",
			zh: "<checklist bind=\"{{bind:done}}\" label=\"完成清单\">\n- [ ] 第一项任务\n- [ ] 第二项任务\n- [ ] 第三项任务\n</checklist>"
		}
	},
	progress: {
		title: {
			en: "Progress bar",
			zh: "进度条"
		},
		description: {
			en: "Show completion from 0 to 100.",
			zh: "展示 0 到 100 之间的完成进度。"
		},
		category: "action",
		keywords: {
			en: [
				"progress",
				"completion",
				"bar",
				"percent"
			],
			zh: [
				"进度",
				"完成度",
				"进度条",
				"百分比"
			]
		},
		insertText: {
			en: "<progress label=\"Progress\" value=\"{{ 40 }}\">",
			zh: "<progress label=\"完成进度\" value=\"{{ 40 }}\">"
		}
	},
	panel: {
		title: {
			en: "Parameter panel",
			zh: "参数面板"
		},
		description: {
			en: "Group controls in a panel with a restore-defaults button.",
			zh: "把一组控件包进面板，并附带恢复默认按钮。"
		},
		category: "layout",
		keywords: {
			en: [
				"panel",
				"parameters",
				"reset",
				"form",
				"group"
			],
			zh: [
				"面板",
				"参数",
				"重置",
				"表单",
				"控件"
			]
		},
		insertText: {
			en: "<panel title=\"Parameters\">\n{{selection:Sample content}}\n</panel>",
			zh: "<panel title=\"参数面板\">\n{{selection:示例内容}}\n</panel>"
		}
	},
	card: {
		title: {
			en: "Content card",
			zh: "内容卡片"
		},
		description: {
			en: "Organize a self-contained piece of content in a card.",
			zh: "用卡片组织一段独立内容。"
		},
		category: "layout",
		keywords: {
			en: [
				"card",
				"container",
				"content",
				"section"
			],
			zh: [
				"卡片",
				"容器",
				"内容",
				"区块"
			]
		},
		insertText: {
			en: "<card title=\"Content card\">\n{{selection:Sample content}}\n</card>",
			zh: "<card title=\"内容卡片\">\n{{selection:示例内容}}\n</card>"
		}
	},
	if: {
		title: {
			en: "Conditional section",
			zh: "条件区域"
		},
		description: {
			en: "Show the contents only when a condition is true.",
			zh: "只有条件为真时才显示其中内容。"
		},
		category: "layout",
		keywords: {
			en: [
				"if",
				"condition",
				"when",
				"show",
				"visible"
			],
			zh: [
				"条件",
				"判断",
				"显示",
				"当"
			]
		},
		insertText: {
			en: "<if when=\"{{ {{select:true}} }}\">\n{{selection:Sample content}}\n</if>",
			zh: "<if when=\"{{ {{select:true}} }}\">\n{{selection:示例内容}}\n</if>"
		}
	},
	tabs: {
		title: {
			en: "Tabs",
			zh: "标签页"
		},
		description: {
			en: "Split content across switchable tabs.",
			zh: "把内容分到多个可切换的标签页中。"
		},
		category: "layout",
		keywords: {
			en: [
				"tabs",
				"switch",
				"sections",
				"groups"
			],
			zh: [
				"标签页",
				"切换",
				"分组",
				"选项卡"
			]
		},
		insertText: {
			en: "<tabs label=\"Content tabs\">\n<tab label=\"Tab one\">\n{{selection:Sample content}}\n</tab>\n\n<tab label=\"Tab two\">\nContent for the second tab.\n</tab>\n</tabs>",
			zh: "<tabs label=\"内容标签页\">\n<tab label=\"标签一\">\n{{selection:示例内容}}\n</tab>\n\n<tab label=\"标签二\">\n第二个标签页的内容。\n</tab>\n</tabs>"
		}
	},
	accordion: {
		title: {
			en: "Accordion",
			zh: "折叠面板"
		},
		description: {
			en: "Put notes into items that expand and collapse.",
			zh: "把说明放进可展开和收起的条目。"
		},
		category: "layout",
		keywords: {
			en: [
				"accordion",
				"collapse",
				"expand",
				"faq",
				"disclosure"
			],
			zh: [
				"折叠",
				"展开",
				"问答",
				"手风琴",
				"条目"
			]
		},
		insertText: {
			en: "<accordion label=\"FAQ\">\n<disclosure label=\"Question one\">\n{{selection:Sample content}}\n</disclosure>\n\n<disclosure label=\"Question two\">\nDetails for the second item.\n</disclosure>\n</accordion>",
			zh: "<accordion label=\"常见问题\">\n<disclosure label=\"问题一\">\n{{selection:示例内容}}\n</disclosure>\n\n<disclosure label=\"问题二\">\n第二个条目的说明。\n</disclosure>\n</accordion>"
		}
	},
	chart: {
		title: {
			en: "Bar chart",
			zh: "柱状图"
		},
		description: {
			en: "Turn a Markdown table into a bar chart.",
			zh: "把 Markdown 表格转换成柱状图。"
		},
		category: "data",
		keywords: {
			en: [
				"chart",
				"bar",
				"graph",
				"table",
				"data"
			],
			zh: [
				"图表",
				"柱状图",
				"表格",
				"数据",
				"对比"
			]
		},
		insertText: {
			en: "<chart kind=\"bar\" title=\"Category comparison\" y-label=\"Value\">\n| Item | Value |\n| --- | ---: |\n| Item A | 20 |\n| Item B | 35 |\n</chart>",
			zh: "<chart kind=\"bar\" title=\"分类对比\" y-label=\"数值\">\n| 项目 | 数值 |\n| --- | ---: |\n| 项目甲 | 20 |\n| 项目乙 | 35 |\n</chart>"
		}
	},
	table: {
		title: {
			en: "Enhanced table",
			zh: "增强表格"
		},
		description: {
			en: "A Markdown table with search, sorting and paging.",
			zh: "带搜索、排序和分页的 Markdown 表格。"
		},
		category: "data",
		keywords: {
			en: [
				"table",
				"search",
				"sort",
				"paging",
				"data"
			],
			zh: [
				"表格",
				"搜索",
				"排序",
				"分页",
				"数据"
			]
		},
		insertText: {
			en: "<table label=\"Data table\" page-size=\"5\">\n| Name | Category | Value |\n| --- | --- | ---: |\n| Item A | Category one | 20 |\n| Item B | Category two | 35 |\n</table>",
			zh: "<table label=\"数据表格\" page-size=\"5\">\n| 名称 | 分类 | 数值 |\n| --- | --- | ---: |\n| 项目甲 | 分类一 | 20 |\n| 项目乙 | 分类二 | 35 |\n</table>"
		}
	},
	timeline: {
		title: {
			en: "Timeline",
			zh: "时间轴"
		},
		description: {
			en: "Show task start times and durations in a table.",
			zh: "用表格展示任务的开始时间与时长。"
		},
		category: "data",
		keywords: {
			en: [
				"timeline",
				"schedule",
				"plan",
				"duration",
				"gantt"
			],
			zh: [
				"时间轴",
				"计划",
				"时长",
				"日程",
				"任务"
			]
		},
		insertText: {
			en: "<timeline title=\"Task timeline\">\n| Task | Start | Duration | Notes |\n| --- | ---: | ---: | --- |\n| Prepare | 0 | 10 | List the materials |\n| Execute | 10 | 20 | Complete the main work |\n| Review | 30 | 5 | Check the results |\n</timeline>",
			zh: "<timeline title=\"任务时间轴\">\n| 事项 | 开始 | 时长 | 说明 |\n| --- | ---: | ---: | --- |\n| 准备 | 0 | 10 | 列出所需材料 |\n| 执行 | 10 | 20 | 完成主要内容 |\n| 检查 | 30 | 5 | 复核结果 |\n</timeline>"
		}
	},
	diagram: {
		title: {
			en: "Interactive diagram",
			zh: "交互图解"
		},
		description: {
			en: "Show a flow with nodes and edges; click a node to read its notes.",
			zh: "用节点和连线展示流程，可点击查看说明。"
		},
		category: "data",
		keywords: {
			en: [
				"diagram",
				"flow",
				"node",
				"edge",
				"graph"
			],
			zh: [
				"图解",
				"流程",
				"节点",
				"连线",
				"关系图"
			]
		},
		insertText: {
			en: "<diagram label=\"Flow overview\">\n<node id=\"start\" label=\"Start\">\nWhere the flow begins.\n</node>\n\n<node id=\"process\" label=\"Process\">\nPerform the main step.\n</node>\n\n<node id=\"end\" label=\"End\">\nReview the result.\n</node>\n\n<edge from=\"start\" to=\"process\" label=\"Proceed\">\n<edge from=\"process\" to=\"end\" label=\"Complete\">\n</diagram>",
			zh: "<diagram label=\"流程示意\">\n<node id=\"start\" label=\"开始\">\n流程起点。\n</node>\n\n<node id=\"process\" label=\"处理\">\n执行主要步骤。\n</node>\n\n<node id=\"end\" label=\"结束\">\n查看结果。\n</node>\n\n<edge from=\"start\" to=\"process\" label=\"进入\">\n<edge from=\"process\" to=\"end\" label=\"完成\">\n</diagram>"
		}
	},
	plot: {
		title: {
			en: "Function plot",
			zh: "函数曲线"
		},
		description: {
			en: "Plot explicit, parametric or implicit curves from LaTeX formulas.",
			zh: "用 LaTeX 公式绘制显式、参数方程或隐函数曲线。"
		},
		category: "data",
		keywords: {
			en: [
				"plot",
				"curve",
				"function",
				"parametric",
				"implicit",
				"formula",
				"latex",
				"math"
			],
			zh: [
				"曲线",
				"函数",
				"参数方程",
				"隐函数",
				"公式",
				"数学",
				"绘图"
			]
		},
		insertText: {
			en: "<plot min=\"-5\" max=\"5\" label=\"Function plot\">\n$$ y = x^2 $$\n</plot>",
			zh: "<plot min=\"-5\" max=\"5\" label=\"函数曲线\">\n$$ y = x^2 $$\n</plot>"
		}
	},
	alert: {
		title: {
			en: "Alert",
			zh: "提示框"
		},
		description: {
			en: "Highlight info, success or warning messages with different tones.",
			zh: "用不同语气突出普通、成功或警告信息。"
		},
		category: "hint",
		keywords: {
			en: [
				"alert",
				"notice",
				"warning",
				"info",
				"message"
			],
			zh: [
				"提示",
				"警告",
				"通知",
				"信息",
				"消息"
			]
		},
		insertText: {
			en: "<alert tone=\"info\" title=\"Notice\">\n{{selection:Sample content}}\n</alert>",
			zh: "<alert tone=\"info\" title=\"提示\">\n{{selection:示例内容}}\n</alert>"
		}
	},
	badge: {
		title: {
			en: "Badge",
			zh: "徽标"
		},
		description: {
			en: "Show a short status marker inside a sentence.",
			zh: "在句子里显示一个简短状态标记。"
		},
		category: "hint",
		keywords: {
			en: [
				"badge",
				"label",
				"status",
				"inline",
				"tag"
			],
			zh: [
				"徽标",
				"标签",
				"状态",
				"行内",
				"标记"
			]
		},
		inline: !0,
		insertText: {
			en: "<badge tone=\"success\">Badge</badge>",
			zh: "<badge tone=\"success\">标签</badge>"
		}
	},
	tooltip: {
		title: {
			en: "Tooltip",
			zh: "行内提示"
		},
		description: {
			en: "Attach a hover or focus note to a word in a sentence.",
			zh: "为句中的词语附加悬停或聚焦说明。"
		},
		category: "hint",
		keywords: {
			en: [
				"tooltip",
				"hint",
				"hover",
				"focus",
				"inline"
			],
			zh: [
				"提示",
				"悬停",
				"说明",
				"行内",
				"气泡"
			]
		},
		inline: !0,
		insertText: {
			en: "<tooltip text=\"Extra details appear here.\">Hover to view</tooltip>",
			zh: "<tooltip text=\"这里显示补充说明。\">悬停查看</tooltip>"
		}
	}
}), d = Object.freeze(Object.keys(u));
function f(e) {
	return Object.hasOwn(u, e) ? u[e] : void 0;
}
function p(e, t, n = "") {
	if (e === void 0) return n;
	for (let n of [
		t,
		"en",
		"zh"
	]) {
		let t = e[n];
		if (typeof t == "string" && t.trim() !== "") return t;
	}
	for (let t of Object.values(e)) if (typeof t == "string" && t.trim() !== "") return t;
	return n;
}
function m(e, t) {
	let n = c.find((t) => t.id === e);
	return n ? p(n.title, t, n.id) : e;
}
function h(e) {
	let t = f(e);
	if (!t) return;
	let n = [];
	for (let e of [...t.keywords.en, ...t.keywords.zh]) {
		let t = e.toLowerCase();
		n.some((e) => e.toLowerCase() === t) || n.push(e);
	}
	return Object.freeze(n);
}
function g(e) {
	let t = f(e);
	if (!t) return;
	let n = t.insertText.en;
	if (typeof n == "string" && n.trim() !== "") return {
		title: t.title,
		description: t.description,
		category: l.has(t.category) ? t.category : void 0,
		insertText: n
	};
}
// src/presets/default-semantics.ts
var _ = s, v = {
	text: (e = {}) => ({
		kind: "string",
		coerce: "text",
		...e
	}),
	expressionText: (e = {}) => ({
		kind: "string",
		...e
	}),
	dynamicText: (e = {}) => ({
		kind: "string",
		dynamic: !0,
		...e
	}),
	staticText: (e = {}) => ({
		kind: "string",
		static: !0,
		...e
	}),
	number: (e = {}) => ({
		kind: "number",
		...e
	}),
	boolean: (e = {}) => ({
		kind: "boolean",
		...e
	}),
	choice: (e, t = {}) => ({
		kind: "enum",
		enum: e,
		...t
	})
}, y = (e = {}) => v.text(e), b = () => v.text(), x = () => v.text(), S = () => v.boolean({
	dynamic: !0,
	default: !1
}), C = () => v.staticText({ color: !0 });
function ee() {
	return Object.freeze({
		interactive: !0,
		static: !0,
		ssr: !0,
		offline: !0
	});
}
function w(e, t, n, r = {}) {
	return Object.freeze({
		kind: e,
		family: t,
		bind: "bind",
		initial: "initial",
		initialRule: n,
		...r
	});
}
function T(e, t, n = {}) {
	return Object.freeze({
		kind: "number",
		family: "number",
		bind: `bind-${e}`,
		initial: `initial-${e}`,
		initialRule: t,
		exclusive: !0,
		...n
	});
}
var E = (e, t, n = "step") => ({
	min: { prop: e },
	max: { prop: t },
	step: { prop: n }
});
function D(e) {
	return Object.freeze(e);
}
function O(...e) {
	return Object.freeze(e.map((e) => Object.freeze(e)));
}
function k(e, n, r) {
	return o({
		id: `reactive-md/${e}`,
		name: e,
		version: _,
		protocol: t,
		form: n,
		capabilities: ee(),
		...r
	});
}
var A = k("input", "leaf", {
	props: {
		label: y(),
		type: v.choice(["text", "email"], {
			static: !0,
			default: "text"
		}),
		placeholder: v.text(),
		required: v.boolean({
			dynamic: !0,
			default: !1
		}),
		"min-length": v.number({
			integer: !0,
			min: 0,
			default: 0
		}),
		"max-length": v.number({
			integer: !0,
			min: 0
		}),
		disabled: S()
	},
	bindings: { value: w("string", "text", "empty") },
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "text-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "dynamic-constraints",
		attributes: ["required"]
	}, {
		kind: "value-length",
		min: "min-length",
		max: "max-length",
		email: "type",
		emailType: "email"
	}, {
		kind: "value-required",
		required: "required"
	})
}), j = k("textarea", "leaf", {
	props: {
		label: y(),
		placeholder: v.text(),
		rows: v.number({
			integer: !0,
			positive: !0,
			default: 4
		}),
		required: v.boolean({
			dynamic: !0,
			default: !1
		}),
		"min-length": v.number({
			integer: !0,
			min: 0,
			default: 0
		}),
		"max-length": v.number({
			integer: !0,
			min: 0
		}),
		disabled: S()
	},
	bindings: { value: w("string", "text", "empty") },
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "text-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "dynamic-constraints",
		attributes: ["required"]
	}, {
		kind: "value-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "value-required",
		required: "required"
	})
}), M = k("number", "leaf", {
	props: {
		label: y(),
		min: v.number({ dynamic: !0 }),
		max: v.number({ dynamic: !0 }),
		step: v.number({
			positive: !0,
			default: 1
		}),
		disabled: S()
	},
	bindings: { value: w("number", "number", "nearest-zero", { constraints: E("min", "max") }) },
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	}, {
		kind: "dynamic-constraints",
		attributes: ["min", "max"]
	})
}), N = k("slider", "leaf", {
	props: {
		label: y(),
		min: v.number({
			dynamic: !0,
			default: 0
		}),
		max: v.number({
			dynamic: !0,
			default: 100
		}),
		step: v.number({
			positive: !0,
			default: 1
		}),
		disabled: S(),
		color: C()
	},
	bindings: { value: w("number", "number", "min", { constraints: E("min", "max") }) },
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	}, {
		kind: "dynamic-constraints",
		attributes: ["min", "max"]
	})
}), P = k("range-slider", "leaf", {
	props: {
		label: y(),
		min: v.number({ default: 0 }),
		max: v.number({ default: 100 }),
		step: v.number({
			positive: !0,
			default: 1
		}),
		disabled: S(),
		color: C()
	},
	bindings: {
		start: T("start", "min", { constraints: E("min", "max") }),
		end: T("end", "max-step", { constraints: E("min", "max") })
	},
	slotRelations: [{
		lower: "start",
		upper: "end"
	}],
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	})
}), F = k("coordinate", "leaf", {
	props: {
		label: y(),
		"x-min": v.number({ default: -5 }),
		"x-max": v.number({ default: 5 }),
		"y-min": v.number({ default: -5 }),
		"y-max": v.number({ default: 5 }),
		step: v.number({
			positive: !0,
			default: 1
		}),
		disabled: S(),
		color: C()
	},
	bindings: {
		x: T("x", "nearest-zero", { constraints: {
			min: { prop: "x-min" },
			max: { prop: "x-max" },
			step: { prop: "step" }
		} }),
		y: T("y", "nearest-zero", { constraints: {
			min: { prop: "y-min" },
			max: { prop: "y-max" },
			step: { prop: "step" }
		} })
	},
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "numeric-range",
		min: "x-min",
		max: "x-max",
		step: "step"
	}, {
		kind: "numeric-range",
		min: "y-min",
		max: "y-max"
	})
}), I = k("toggle", "leaf", {
	props: {
		label: y(),
		disabled: S(),
		color: C()
	},
	bindings: { value: w("boolean", "boolean", "false") },
	structure: D({
		rule: "none",
		label: "required"
	})
}), L = k("checkbox", "leaf", {
	props: {
		label: y(),
		disabled: S(),
		color: C()
	},
	bindings: { value: w("boolean", "boolean", "false") },
	structure: D({
		rule: "none",
		label: "required"
	})
}), R = k("date", "leaf", {
	props: {
		label: y(),
		min: v.dynamicText(),
		max: v.dynamicText(),
		required: v.boolean({
			dynamic: !0,
			default: !1
		}),
		disabled: S()
	},
	bindings: { value: w("string", "date", "empty") },
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "date-bounds",
		min: "min",
		max: "max"
	}, {
		kind: "dynamic-constraints",
		attributes: [
			"min",
			"max",
			"required"
		]
	}, {
		kind: "value-date",
		min: "min",
		max: "max",
		required: "required"
	})
});
function z(e, t = "container") {
	return k(e, t, {
		props: {
			label: y(),
			disabled: S(),
			color: C()
		},
		bindings: { value: w("string", "choice", "first-option") },
		structure: D({
			rule: "options",
			label: "required",
			child: "option",
			children: ["option"],
			min: 1,
			max: n,
			valueAttribute: "value"
		}),
		rules: O({
			kind: "options-body",
			child: "option",
			valueAttribute: "value",
			unique: !0,
			max: n
		})
	});
}
var B = z("select"), V = z("choices"), H = z("radio-group"), U = k("multi-select", "container", {
	props: {
		label: y(),
		"max-selected": v.number({
			integer: !0,
			min: 0
		}),
		disabled: S(),
		color: C()
	},
	bindings: { value: w("array", "multi-select", "empty-array", {
		exclusive: !0,
		maxItems: { prop: "max-selected" }
	}) },
	structure: D({
		rule: "options",
		label: "required",
		child: "option",
		children: ["option"],
		min: 1,
		max: n,
		valueAttribute: "value",
		forbidSeparator: ","
	}),
	rules: O({
		kind: "options-body",
		child: "option",
		valueAttribute: "value",
		unique: !0,
		max: n,
		forbidSeparator: ","
	}, {
		kind: "option-count",
		max: "max-selected"
	})
}), W = k("option", "container", {
	props: { value: v.staticText({ required: !0 }) },
	structure: D({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: O({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" })
}), G = k("counter", "leaf", {
	props: {
		label: y(),
		min: v.number({ default: 0 }),
		max: v.number(),
		step: v.number({
			positive: !0,
			default: 1
		}),
		disabled: S()
	},
	bindings: { value: w("number", "number", "nearest-zero", { constraints: E("min", "max") }) },
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	})
}), K = k("timer", "leaf", {
	props: {
		label: y(),
		duration: v.number({
			integer: !0,
			positive: !0,
			default: 60
		})
	},
	bindings: { value: w("number", "timer", "duration", {
		exclusive: !0,
		constraints: {
			min: { literal: 0 },
			max: { prop: "duration" },
			step: { literal: 1 }
		},
		retain: !1
	}) },
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "timer-duration",
		attribute: "duration",
		default: 60
	}, {
		kind: "retain",
		value: !1
	})
}), q = k("checklist", "container", {
	props: {
		label: y(),
		disabled: S(),
		color: C()
	},
	bindings: { value: w("array", "checklist", "checked", {
		exclusive: !0,
		retain: !1
	}) },
	structure: D({
		rule: "content",
		label: "required",
		noComponents: !0
	}),
	rules: O({
		kind: "checklist-body",
		itemLimit: n
	}, {
		kind: "retain",
		value: !1
	})
}), J = k("progress", "leaf", {
	props: {
		label: y(),
		value: v.number({
			dynamic: !0,
			required: !0
		}),
		max: v.number({
			positive: !0,
			default: 100
		}),
		color: C()
	},
	structure: D({
		rule: "none",
		label: "required"
	}),
	rules: O({
		kind: "progress-bounds",
		value: "value",
		max: "max",
		defaultMax: 100
	})
}), Y = k("jump", "inline", {
	props: {
		to: v.staticText({ required: !0 }),
		appearance: v.choice(["link", "button"], {
			static: !0,
			default: "link"
		}),
		color: C()
	},
	structure: D({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: O({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" }, {
		kind: "navigation",
		target: "to"
	})
}), X = k("anchor", "leaf", {
	props: { id: v.staticText({ required: !0 }) },
	structure: D({
		rule: "none",
		label: "none"
	}),
	rules: O({
		kind: "anchor",
		id: "id"
	})
}), Z = k("text", "inline", {
	props: { color: v.staticText({
		required: !0,
		color: !0
	}) },
	structure: D({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: O({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" })
}), te = k("section", "container", {
	props: { color: v.staticText({
		required: !0,
		color: !0
	}) },
	structure: D({
		rule: "any",
		label: "none"
	})
}), Q = k("quiz", "container", {
	props: {
		type: v.choice(["choice", "number"], {
			static: !0,
			default: "choice"
		}),
		label: y(),
		answer: v.staticText({ required: !0 }),
		explanation: v.text(),
		tolerance: v.number({
			min: 0,
			default: 0
		}),
		disabled: S()
	},
	structure: D({
		rule: "quiz",
		label: "required",
		child: "option",
		children: ["option"],
		max: n,
		valueAttribute: "value"
	}),
	rules: O({
		kind: "quiz-body",
		type: "type",
		answer: "answer",
		tolerance: "tolerance",
		child: "option",
		valueAttribute: "value",
		max: n
	}, {
		kind: "nonempty",
		attribute: "answer"
	})
}), ne = k("panel", "container", {
	props: {
		title: x(),
		reset: v.boolean({ default: !0 })
	},
	structure: D({
		rule: "any",
		label: "none"
	}),
	rules: O({
		kind: "self-binding-read",
		mode: "always"
	})
}), re = k("card", "container", {
	props: { title: x() },
	structure: D({
		rule: "any",
		label: "none"
	})
}), ie = k("grid", "container", {
	props: { columns: v.number({
		integer: !0,
		min: 1,
		max: 4,
		default: 2
	}) },
	structure: D({
		rule: "components",
		label: "none",
		child: "card",
		children: ["card"],
		min: 1
	}),
	rules: O({
		kind: "only-children",
		children: ["card"],
		min: 1
	})
}), ae = k("tabs", "container", {
	props: { label: b() },
	bindings: { value: w("string", "tabs", "first-tab", { exclusive: !0 }) },
	structure: D({
		rule: "tabs",
		label: "optional",
		child: "tab",
		children: ["tab"],
		min: 1,
		valueAttribute: "value",
		generatedPrefix: "tab-"
	}),
	rules: O({
		kind: "value-sequence",
		child: "tab",
		valueAttribute: "value",
		min: 1,
		generatedPrefix: "tab-",
		unique: !0
	})
}), oe = k("tab", "container", {
	props: {
		label: y(),
		value: v.staticText()
	},
	structure: D({
		rule: "any",
		label: "required",
		parents: ["tabs"]
	})
}), se = k("steps", "container", {
	props: { label: b() },
	bindings: { value: w("string", "steps", "first-step", { exclusive: !0 }) },
	structure: D({
		rule: "steps",
		label: "optional",
		child: "step",
		children: ["step"],
		min: 1,
		valueAttribute: "value",
		generatedPrefix: "step-"
	}),
	rules: O({
		kind: "value-sequence",
		child: "step",
		valueAttribute: "value",
		min: 1,
		generatedPrefix: "step-",
		unique: !0
	})
}), ce = k("step", "container", {
	props: {
		label: y(),
		value: v.staticText()
	},
	structure: D({
		rule: "any",
		label: "required",
		parents: ["steps"]
	})
}), le = k("accordion", "container", {
	props: { label: b() },
	structure: D({
		rule: "components",
		label: "optional",
		child: "disclosure",
		children: ["disclosure"],
		min: 1
	}),
	rules: O({
		kind: "only-children",
		children: ["disclosure"],
		min: 1
	})
}), ue = k("disclosure", "container", {
	props: {
		label: y(),
		open: v.boolean({ default: !1 })
	},
	structure: D({
		rule: "any",
		label: "required",
		parents: ["accordion"]
	})
}), de = k("if", "container", {
	props: { when: v.boolean({
		dynamic: !0,
		required: !0
	}) },
	structure: D({
		rule: "any",
		label: "none"
	}),
	rules: O({
		kind: "require-full-interpolation",
		attributes: ["when"]
	})
}), fe = k("alert", "container", {
	props: {
		title: x(),
		tone: v.choice([
			"info",
			"success",
			"warning"
		], {
			dynamic: !0,
			default: "info"
		})
	},
	structure: D({
		rule: "any",
		label: "none"
	})
}), pe = k("badge", "inline", {
	props: {
		tone: v.choice([
			"neutral",
			"success",
			"warning"
		], {
			dynamic: !0,
			default: "neutral"
		}),
		color: C()
	},
	structure: D({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: O({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" })
}), me = k("tooltip", "inline", {
	props: { text: v.text({ required: !0 }) },
	structure: D({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: O({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" })
}), he = k("validation", "leaf", {
	props: {
		when: v.boolean({
			dynamic: !0,
			required: !0
		}),
		message: v.text({ required: !0 }),
		fields: v.staticText({ required: !0 })
	},
	structure: D({
		rule: "none",
		label: "none"
	}),
	rules: O({
		kind: "validation-rule",
		when: "when",
		fields: "fields",
		message: "message",
		placement: "prose",
		max: 100
	}, {
		kind: "scoped-expressions",
		attributes: ["fields"],
		scope: "validation"
	})
}), ge = k("data-table", "container", {
	props: {
		label: v.staticText(),
		rows: v.expressionText({ required: !0 }),
		key: v.expressionText({ required: !0 }),
		"max-rows": v.number({
			integer: !0,
			positive: !0,
			max: i,
			default: 100
		})
	},
	structure: D({
		rule: "components",
		label: "required",
		child: "column",
		children: ["column"],
		min: 1,
		max: 20
	}),
	rules: O({
		kind: "data-table",
		rows: "rows",
		key: "key",
		child: "column",
		childValue: "value",
		label: "label",
		maxRows: "max-rows",
		defaultMaxRows: 100,
		documentRows: r,
		documentCells: e,
		maxColumns: 20
	}, {
		kind: "require-full-interpolation",
		attributes: ["rows", "key"]
	}, {
		kind: "scoped-expressions",
		attributes: ["key"],
		scope: "row"
	}, {
		kind: "row-values",
		rows: "rows",
		key: "key",
		child: "column",
		childValue: "value"
	})
}), _e = k("column", "leaf", {
	props: {
		label: v.staticText({ required: !0 }),
		value: v.expressionText({ required: !0 })
	},
	structure: D({
		rule: "none",
		label: "none",
		parents: ["data-table"]
	}),
	rules: O({
		kind: "require-full-interpolation",
		attributes: ["value"]
	}, {
		kind: "scoped-expressions",
		attributes: ["value"],
		scope: "row"
	})
}), ve = k("table", "container", {
	props: {
		label: b(),
		searchable: v.boolean({ default: !0 }),
		sortable: v.boolean({ default: !0 }),
		"page-size": v.number({
			integer: !0,
			positive: !0,
			default: 10
		}),
		key: v.staticText()
	},
	bindings: { value: w("string", "selection", "none", { requiresAttributes: ["key"] }) },
	structure: D({
		rule: "table",
		label: "optional"
	}),
	rules: O({ kind: "single-table" }, {
		kind: "selection-requires",
		key: "key",
		attributes: ["bind", "initial"]
	}, {
		kind: "table-selection",
		key: "key",
		bindings: ["bind"]
	}, {
		kind: "self-binding-read",
		mode: "attribute",
		attribute: "key"
	})
}), ye = k("chart", "container", {
	props: {
		kind: v.choice([
			"bar",
			"line",
			"area",
			"scatter",
			"donut",
			"pie"
		], {
			static: !0,
			default: "bar"
		}),
		title: x(),
		x: v.staticText(),
		y: v.staticText(),
		"x-label": v.text(),
		"y-label": v.text(),
		key: v.staticText()
	},
	bindings: { value: w("string", "selection", "none", { requiresAttributes: ["key"] }) },
	structure: D({
		rule: "table",
		label: "none"
	}),
	rules: O({ kind: "single-table" }, {
		kind: "chart-table",
		chartKind: "kind",
		x: "x",
		y: "y"
	}, {
		kind: "table-selection",
		key: "key",
		bindings: ["bind"]
	}, {
		kind: "selection-requires",
		key: "key",
		attributes: ["bind", "initial"]
	}, {
		kind: "self-binding-read",
		mode: "attribute",
		attribute: "key"
	})
}), be = k("plot", "container", {
	props: {
		label: b(),
		min: v.number({
			dynamic: !0,
			default: -10
		}),
		max: v.number({
			dynamic: !0,
			default: 10
		}),
		samples: v.number({
			integer: !0,
			min: 2,
			max: 2e3,
			static: !0,
			default: 200
		}),
		"x-label": v.text({ default: "x" }),
		"y-label": v.text({ default: "y" })
	},
	structure: D({
		rule: "plot",
		label: "optional"
	}),
	rules: O({ kind: "math-body" }, {
		kind: "numeric-range",
		min: "min",
		max: "max",
		order: "increasing"
	}, {
		kind: "plot-math",
		min: "min",
		max: "max",
		samples: "samples",
		curves: 16,
		points: a
	}, { kind: "inline-math-reads" })
}), xe = k("timeline", "container", {
	props: {
		title: x(),
		unit: v.text({ default: "minutes" })
	},
	structure: D({
		rule: "table",
		label: "none"
	}),
	rules: O({ kind: "single-table" }, {
		kind: "timeline-table",
		headerSets: [[
			"Task",
			"Start",
			"Duration",
			"Notes"
		], [
			"事项",
			"开始",
			"时长",
			"说明"
		]]
	})
}), Se = k("diagram", "container", {
	props: {
		label: b(),
		direction: v.choice(["right", "down"], {
			static: !0,
			default: "right"
		})
	},
	bindings: { value: w("string", "diagram", "first-node", { exclusive: !0 }) },
	structure: D({
		rule: "diagram",
		label: "optional",
		child: "node",
		children: ["node", "edge"],
		min: 1
	}),
	rules: O({
		kind: "diagram-body",
		node: "node",
		edge: "edge",
		id: "id",
		from: "from",
		to: "to",
		label: "label"
	}, {
		kind: "self-binding-read",
		mode: "always"
	})
}), Ce = k("node", "container", {
	props: {
		id: v.staticText({ required: !0 }),
		label: y(),
		tone: v.choice([
			"neutral",
			"success",
			"warning"
		], {
			dynamic: !0,
			default: "neutral"
		})
	},
	structure: D({
		rule: "content",
		label: "required",
		noComponents: !0,
		parents: ["diagram"]
	}),
	rules: O({ kind: "no-components" })
}), we = k("edge", "leaf", {
	props: {
		from: v.staticText({ required: !0 }),
		to: v.staticText({ required: !0 }),
		label: b()
	},
	structure: D({
		rule: "none",
		label: "none",
		parents: ["diagram"]
	})
}), $ = Object.freeze([
	A,
	j,
	M,
	N,
	P,
	F,
	I,
	L,
	R,
	B,
	V,
	H,
	U,
	W,
	G,
	K,
	q,
	J,
	Y,
	X,
	Z,
	te,
	Q,
	ne,
	re,
	ie,
	ae,
	oe,
	se,
	ce,
	le,
	ue,
	de,
	fe,
	pe,
	me,
	he,
	ge,
	_e,
	ve,
	ye,
	be,
	xe,
	Se,
	Ce,
	we
]), Te = Object.freeze($.map((e) => e.name));
// src/presets/default-components.ts
function Ee(e) {
	let t = g(e.name);
	return t ? o({
		...e,
		authoring: t
	}) : e;
}
var De = Object.freeze($.map(Ee));
export { u as a, f as c, d as i, g as l, Te as n, m as o, c as r, h as s, De as t, p as u };
