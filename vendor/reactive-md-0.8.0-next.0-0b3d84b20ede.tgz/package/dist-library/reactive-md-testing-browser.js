import { n as e, u as t } from "./registry-ct5OjJQp.js";
import { c as n, f as r, h as i, i as a, k as o, l as s, m as c, n as l, o as u, p as d, r as f, s as p, t as m, u as h, v as g, w as _, y as v } from "./values-CIt8AjiU.js";
// src/testing/browser.ts
var y = /* @__PURE__ */ new Set([
	"protocol",
	"url",
	"offline",
	"javaScriptEnabled",
	"timeoutMs",
	"cases",
	"expectedErrors",
	"unmountExpression",
	"requiredPhases"
]), b = /* @__PURE__ */ new Set([
	"id",
	"phase",
	"kind",
	"selector",
	"name",
	"value",
	"key",
	"expression",
	"expected",
	"trigger",
	"placeholder",
	"survivor"
]), x = [
	"mount",
	"hydration",
	"edit",
	"hide-show",
	"disabled",
	"reset",
	"descendant-error",
	"unmount"
], S = new Set(x), C = [
	"mount",
	"edit",
	"hide-show",
	"disabled",
	"reset",
	"descendant-error",
	"unmount"
], w = /* @__PURE__ */ new Set([
	"visible",
	"text",
	"attribute",
	"count",
	"enabled",
	"wait",
	"click",
	"fill",
	"press",
	"evaluate",
	"isolation",
	"unmount"
]), T = "(() => {\n  const hook = globalThis.__reactiveMdTestUnmount;\n  if (typeof hook === 'function') { hook(); return true; }\n  const root = document.querySelector('#reactive-md-document, reactive-md-doc');\n  if (root && root.parentNode) { root.remove(); return true; }\n  return false;\n})()";
function E(e, t) {
	let r = n(e, t, 512);
	if (r.trim() === "") throw TypeError(`${t} must not be empty.`);
	if (/[\u0000\r\n]/.test(r)) throw TypeError(`${t} contains an unsupported character.`);
	return r;
}
function D(e, t) {
	let n = a(e, t);
	if (Array.isArray(n)) throw TypeError(`${t} must be a scalar.`);
	return n;
}
function O(e, t, r) {
	let i = `spec.cases[${t}]`, a = h(e, i);
	m(a, b, i);
	let s = n(a.kind, `${i}.kind`, 32);
	if (!w.has(s)) throw TypeError(`${i}.kind is not supported.`);
	let c = n(a.phase, `${i}.phase`, 32);
	if (!S.has(c)) throw TypeError(`${i}.phase is not supported.`);
	let l = {
		id: f(a.id, `${i}.id`, r, `browser.${t}.${s}`),
		phase: c,
		kind: s
	};
	switch (s) {
		case "visible":
		case "enabled":
			if (typeof a.expected != "boolean") throw TypeError(`${i}.expected must be a boolean.`);
			return Object.freeze({
				...l,
				selector: E(a.selector, `${i}.selector`),
				expected: a.expected
			});
		case "text": return Object.freeze({
			...l,
			selector: E(a.selector, `${i}.selector`),
			expected: n(a.expected, `${i}.expected`, o)
		});
		case "attribute": {
			let e = a.expected;
			if (e !== null && typeof e != "string") throw TypeError(`${i}.expected must be a string or null.`);
			return Object.freeze({
				...l,
				selector: E(a.selector, `${i}.selector`),
				name: n(a.name, `${i}.name`, 128),
				expected: e === null ? null : n(e, `${i}.expected`, o)
			});
		}
		case "count": return Object.freeze({
			...l,
			selector: E(a.selector, `${i}.selector`),
			expected: p(a.expected, `${i}.expected`, 0, 1e4)
		});
		case "wait":
		case "click": return Object.freeze({
			...l,
			selector: E(a.selector, `${i}.selector`)
		});
		case "fill": return Object.freeze({
			...l,
			selector: E(a.selector, `${i}.selector`),
			value: n(a.value, `${i}.value`, o)
		});
		case "press": {
			let e = n(a.key, `${i}.key`, 32);
			if (e.trim() === "") throw TypeError(`${i}.key must not be empty.`);
			return Object.freeze({
				...l,
				selector: E(a.selector, `${i}.selector`),
				key: e
			});
		}
		case "evaluate": {
			let e = n(a.expression, `${i}.expression`, _);
			if (e.trim() === "") throw TypeError(`${i}.expression must not be empty.`);
			return Object.freeze({
				...l,
				expression: e,
				expected: D(a.expected, `${i}.expected`)
			});
		}
		case "isolation": return Object.freeze({
			...l,
			trigger: E(a.trigger, `${i}.trigger`),
			placeholder: E(a.placeholder, `${i}.placeholder`),
			survivor: E(a.survivor, `${i}.survivor`)
		});
		case "unmount": return Object.freeze({ ...l });
		default: throw TypeError(`${i}.kind is not supported.`);
	}
}
function k(e) {
	let t = h(e, "spec");
	if (m(t, y, "spec"), t.protocol !== "reactive-md-browser-spec/v1") throw TypeError(`spec.protocol must be "${g}".`);
	let r = n(t.url, "spec.url", 2048);
	if (!/^(?:file|data):/i.test(r)) throw TypeError("spec.url must be a local file: or data: URL.");
	let i = l(t.offline, "spec.offline"), a = t.javaScriptEnabled === void 0 ? void 0 : l(t.javaScriptEnabled, "spec.javaScriptEnabled"), o = t.timeoutMs === void 0 ? 5e3 : p(t.timeoutMs, "spec.timeoutMs", 1e3, 6e4);
	if (!Array.isArray(t.cases)) throw TypeError("spec.cases must be an array.");
	if (t.cases.length === 0) throw TypeError("spec.cases must not be empty.");
	if (t.cases.length > 128) throw TypeError("spec.cases accepts at most 128 entries.");
	let c = /* @__PURE__ */ new Set(), u = Object.freeze(t.cases.map((e, t) => O(e, t, c))), d = t.expectedErrors === void 0 ? void 0 : s(t.expectedErrors, "spec.expectedErrors", 16), f = t.unmountExpression === void 0 ? void 0 : n(t.unmountExpression, "spec.unmountExpression", _), v;
	if (t.requiredPhases !== void 0) {
		if (!Array.isArray(t.requiredPhases)) throw TypeError("spec.requiredPhases must be an array.");
		let e = [], n = /* @__PURE__ */ new Set();
		for (let r of t.requiredPhases) {
			if (typeof r != "string" || !S.has(r)) throw TypeError("spec.requiredPhases contains an unknown phase.");
			if (n.has(r)) throw TypeError(`spec.requiredPhases repeats "${r}".`);
			n.add(r), e.push(r);
		}
		v = Object.freeze(e);
	}
	return Object.freeze({
		protocol: g,
		url: r,
		offline: i,
		...a === void 0 ? {} : { javaScriptEnabled: a },
		timeoutMs: o,
		cases: u,
		...d === void 0 ? {} : { expectedErrors: d },
		...f === void 0 ? {} : { unmountExpression: f },
		...v === void 0 ? {} : { requiredPhases: v }
	});
}
function A(e, t, n) {
	return new Promise((r, i) => {
		let a = setTimeout(() => i(/* @__PURE__ */ Error(`Timed out after ${t}ms: ${n}`)), t);
		e.then((e) => {
			clearTimeout(a), r(e);
		}, (e) => {
			clearTimeout(a), i(e);
		});
	});
}
function j(e) {
	if (e === null || typeof e == "string" || typeof e == "boolean" || typeof e == "number" && Number.isFinite(e)) return e;
	if (Array.isArray(e) && e.every((e) => typeof e == "string") || Array.isArray(e) && e.every((e) => typeof e == "number" && Number.isFinite(e))) return Object.freeze(e.map((e) => e));
}
async function M(e, t, n, i) {
	switch (t.kind) {
		case "visible": {
			let n = await e.visible(t.selector);
			return n === t.expected ? {
				issues: [],
				observed: { visible: n }
			} : {
				issues: [`Expected ${t.selector} visible=${t.expected}, got ${n}.`],
				observed: { visible: n }
			};
		}
		case "enabled": {
			let n = await e.enabled(t.selector);
			return n === t.expected ? {
				issues: [],
				observed: { enabled: n }
			} : {
				issues: [`Expected ${t.selector} enabled=${t.expected}, got ${n}.`],
				observed: { enabled: n }
			};
		}
		case "text": {
			let n = await e.text(t.selector);
			if (n === null) return { issues: [`No element matched ${t.selector}.`] };
			let r = n.trim(), i = String(t.expected).trim();
			return r === i ? {
				issues: [],
				observed: { text: r }
			} : {
				issues: [`Expected text ${JSON.stringify(i)}, got ${JSON.stringify(r)}.`],
				observed: { text: r }
			};
		}
		case "attribute": {
			let n = await e.attribute(t.selector, t.name);
			return n === t.expected ? {
				issues: [],
				observed: { attribute: n ?? null }
			} : {
				issues: [`Expected ${t.selector} [${t.name}] = ${JSON.stringify(t.expected)}, got ${JSON.stringify(n)}.`],
				observed: { attribute: n ?? null }
			};
		}
		case "count": {
			let n = await e.count(t.selector);
			return n === t.expected ? {
				issues: [],
				observed: { count: n }
			} : {
				issues: [`Expected ${t.expected} matches for ${t.selector}, got ${n}.`],
				observed: { count: n }
			};
		}
		case "wait": return await e.waitFor(t.selector, n), { issues: [] };
		case "click": return await e.click(t.selector), { issues: [] };
		case "fill": return await e.fill(t.selector, t.value), { issues: [] };
		case "press": return await e.press(t.selector, t.key), { issues: [] };
		case "evaluate": {
			let n = j(await e.evaluate(t.expression));
			return n === void 0 ? { issues: ["The evaluated expression did not return a bounded scalar."] } : r(n, t.expected) ? {
				issues: [],
				observed: { result: n }
			} : {
				issues: [`Expected ${JSON.stringify(t.expected)}, got ${JSON.stringify(n)}.`],
				observed: { result: n }
			};
		}
		case "isolation": {
			await e.click(t.trigger), await e.waitFor(t.placeholder, n);
			let r = await e.visible(t.placeholder), i = await e.visible(t.survivor), a = [];
			return r || a.push(`The descendant error placeholder ${t.placeholder} is not visible.`), i || a.push(`The surviving sibling ${t.survivor} is not visible.`), a.length === 0 ? {
				issues: [],
				observed: {
					placeholder: r,
					survivor: i
				}
			} : {
				issues: a,
				observed: {
					placeholder: r,
					survivor: i
				}
			};
		}
		case "unmount": return await e.evaluate(i) === !0 ? { issues: [] } : { issues: ["The unmount expression did not return true."] };
		default: return { issues: [`Unknown case kind ${String(t.kind)}.`] };
	}
}
function N(e, t, n) {
	return e.some((e) => e.status === "passed" && e.id.startsWith(`browser.${t}.`) && n.some((n) => e.id.startsWith(`browser.${t}.${n}`)));
}
function P(e, t, n) {
	return e.filter((e) => e.status === "passed" && e.id.startsWith(`browser.${t}.`)).map((e) => e.observed?.[n]).filter((e) => e !== void 0);
}
function F(e, t, n) {
	return n.some((n) => e.startsWith(`browser.${t}.${n}`));
}
function I(e, t) {
	let n = e.filter((e) => e.status === "passed" && e.id.startsWith(`browser.${t}.`));
	for (let e = 0; e < n.length; e += 1) if (F(n[e].id, t, [
		"click",
		"fill",
		"press",
		"evaluate"
	]) && n.slice(e + 1).some((e) => F(e.id, t, [
		"visible",
		"text",
		"attribute",
		"count",
		"enabled",
		"evaluate"
	]))) return !0;
	return !1;
}
function L(e, t) {
	switch (e) {
		case "mount":
		case "hydration": return N(t, e, [
			"visible",
			"text",
			"attribute",
			"count",
			"enabled",
			"evaluate"
		]);
		case "edit": return I(t, e) && N(t, e, [
			"text",
			"attribute",
			"count",
			"enabled",
			"evaluate"
		]);
		case "hide-show": {
			let n = P(t, e, "visible");
			return n.includes(!0) && n.includes(!1);
		}
		case "disabled": {
			let n = P(t, e, "enabled");
			return n.includes(!0) && n.includes(!1);
		}
		case "reset": return N(t, e, ["click", "evaluate"]) && N(t, e, [
			"text",
			"attribute",
			"count",
			"enabled",
			"evaluate"
		]);
		case "descendant-error": return N(t, e, ["isolation"]);
		case "unmount": return N(t, e, ["unmount"]) && (N(t, e, ["count", "visible"]) || N(t, e, ["evaluate"]));
		default: return !1;
	}
}
function R(n, r) {
	if (n === void 0 || r === void 0) return null;
	let i = t(n), a = e(i).find((e) => e.name === r);
	return a ? Object.freeze({
		id: a.id,
		name: a.name,
		version: a.version
	}) : null;
}
function z(e) {
	return e === void 0 ? "browser" : t(e).key;
}
async function B(e) {
	if (!e || typeof e != "object") throw TypeError("runLocalBrowserCompliance requires an options object.");
	let t = e.driver;
	if (!t || typeof t != "object" || typeof t.open != "function") throw TypeError("options.driver must implement open().");
	let n = k(e.spec), r = z(e.config), a = R(e.config, e.component), o = [], s = n.timeoutMs ?? 5e3, l = n.unmountExpression ?? T, f = null;
	try {
		f = await A(t.open({
			url: n.url,
			offline: n.offline,
			...n.javaScriptEnabled === void 0 ? {} : { javaScriptEnabled: n.javaScriptEnabled },
			timeoutMs: s
		}), s, "driver.open");
	} catch (e) {
		return o.push(d("browser.open", "browser", `Could not open the document: ${u(e)}`)), Object.freeze({
			protocol: v,
			suite: "browser",
			configKey: r,
			component: a,
			cases: Object.freeze(o)
		});
	}
	if (!f) return o.push(d("browser.open", "browser", "The driver did not return a session.")), Object.freeze({
		protocol: v,
		suite: "browser",
		configKey: r,
		component: a,
		cases: Object.freeze(o)
	});
	let p = f;
	try {
		for (let e = 0; e < n.cases.length; e += 1) {
			let t = n.cases[e], r = `browser.${t.phase}.${t.kind}.${t.id.replace(/^browser\./, "")}`;
			try {
				let e = await A(M(p.page, t, s, l), s, r);
				o.push(e.issues.length === 0 ? c(r, "browser", e.observed === void 0 ? {} : { observed: e.observed }) : d(r, "browser", e.issues.join(" ")));
			} catch (e) {
				o.push(d(r, "browser", u(e)));
			}
		}
		if (n.offline) {
			p.offline === !0 ? o.push(c("browser.offline-context", "browser")) : o.push(d("browser.offline-context", "browser", "The driver session was not opened in an offline context."));
			let e = p.requests.filter((e) => /^(?:https?|wss?):/i.test(e));
			o.push(e.length === 0 ? c("browser.network", "browser", { observed: { requests: 0 } }) : d("browser.network", "browser", "The offline document made network requests.", [{
				code: "testing.browser-network",
				message: e.slice(0, 10).join(" ")
			}]));
		}
		let e = n.expectedErrors ?? [], t = p.errors.filter((t) => !e.some((e) => t.includes(e)));
		o.push(t.length === 0 ? c("browser.errors", "browser") : d("browser.errors", "browser", "Unexpected page or console errors.", [{
			code: "testing.browser-errors",
			message: t.slice(0, 10).join(" | ")
		}]));
	} finally {
		try {
			await p.close();
		} catch (e) {
			o.push(d("browser.close", "browser", u(e)));
		}
	}
	let m = n.requiredPhases ?? x;
	for (let e of m) L(e, o) ? o.push(c(`browser.phase.${e}`, "browser")) : o.some((t) => t.id.startsWith(`browser.${e}.`)) ? o.push(d(`browser.phase.${e}`, "browser", `The ${e} cases did not prove the required behavior.`)) : o.push(i(`browser.phase.${e}`, "browser", `No ${e} case was executed.`));
	let h = C.every((e) => L(e, o)), g = o.some((e) => e.status === "failed");
	h && !g ? o.push(c("browser.interactive", "browser", { capabilities: ["interactive"] })) : o.push(i("browser.interactive", "browser", "Interactive evidence requires mount, edit, hide/show, disabled, reset, descendant error and unmount phases without failures.", ["interactive"]));
	let _ = L("hydration", o);
	return n.offline && h && _ && !g ? o.push(c("browser.offline", "browser", { capabilities: ["offline"] })) : o.push(i("browser.offline", "browser", n.offline ? "Offline evidence requires hydration, the full interactive lifecycle, an offline context and no network requests or unexpected errors." : "The spec did not open the document in an offline context.", ["offline"])), Object.freeze({
		protocol: v,
		suite: "browser",
		configKey: r,
		component: a,
		cases: Object.freeze(o)
	});
}
function V(e) {
	if (!e || typeof e.newPage != "function") throw TypeError("createPlaywrightBrowserDriver requires a browser context.");
	return Object.freeze({
		name: "playwright",
		async open(t) {
			if (t.offline) {
				if (typeof e.setOffline != "function") throw TypeError("Offline compliance requires a browser context with setOffline().");
				await e.setOffline(!0);
			}
			let n = await e.newPage(), r = [], i = [];
			n.on("pageerror", (e) => {
				r.push(e instanceof Error ? e.message : String(e));
			}), n.on("console", (e) => {
				let t = e;
				try {
					t.type?.() === "error" && r.push(t.text?.() ?? "console.error");
				} catch {}
			}), n.on("request", (e) => {
				let t = e;
				try {
					let e = t.url?.();
					typeof e == "string" && /^(?:https?|wss?):/i.test(e) && i.push(e);
				} catch {}
			});
			try {
				await n.goto(t.url, {
					waitUntil: "load",
					timeout: t.timeoutMs
				});
			} catch (e) {
				throw await n.close(), e;
			}
			let a = (e) => n.locator(e);
			return Object.freeze({
				page: {
					async goto(e) {
						await n.goto(e, {
							waitUntil: "load",
							timeout: t.timeoutMs
						});
					},
					async reload() {
						await n.reload({ timeout: t.timeoutMs });
					},
					async waitFor(e, t) {
						await n.waitForSelector(e, {
							state: "attached",
							timeout: t
						});
					},
					async count(e) {
						return a(e).count();
					},
					async text(e) {
						return await a(e).count() === 0 ? null : a(e).first().textContent();
					},
					async attribute(e, t) {
						return await a(e).count() === 0 ? null : a(e).first().getAttribute(t);
					},
					async visible(e) {
						return await a(e).count() !== 0 && a(e).first().isVisible();
					},
					async enabled(e) {
						return await a(e).count() !== 0 && a(e).first().isEnabled();
					},
					async click(e) {
						await a(e).first().click();
					},
					async fill(e, t) {
						await a(e).first().fill(t);
					},
					async press(e, t) {
						await a(e).first().press(t);
					},
					async evaluate(e) {
						return n.evaluate(e);
					}
				},
				get errors() {
					return Object.freeze([...r]);
				},
				get requests() {
					return Object.freeze([...i]);
				},
				offline: t.offline,
				async close() {
					await n.close();
				}
			});
		}
	});
}
export { V as createPlaywrightBrowserDriver, k as readLocalBrowserSpec, B as runLocalBrowserCompliance };
