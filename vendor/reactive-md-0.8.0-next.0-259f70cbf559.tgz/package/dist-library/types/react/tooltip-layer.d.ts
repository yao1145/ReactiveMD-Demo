import { useLayoutEffect, type RefObject } from 'react';
/** Layout effect that stays silent during server rendering. */
export declare const useTooltipLayoutEffect: typeof useLayoutEffect;
/**
 * Keeps a `popover="manual"` bubble in the top layer while `open`. Bubbles are
 * positioned by the caller, so nothing but the clip changes. Closing waits for
 * the fade-out so the bubble does not drop back into a clipped ancestor mid
 * transition. Engines without the Popover API keep the inline presentation.
 */
export declare function useTooltipPopover(bubbleRef: RefObject<HTMLElement | null>, open: boolean): void;
