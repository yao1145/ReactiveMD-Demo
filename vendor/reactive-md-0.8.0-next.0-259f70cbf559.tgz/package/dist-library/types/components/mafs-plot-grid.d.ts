/**
 * Pure layout math for the Mafs-backed function plot.
 *
 * Mafs normally keeps one pixel-per-unit scale for both axes. A function plot
 * cannot do that when x and y live on wildly different magnitudes (for
 * example x = 0..20 and y = 50000..300000): either the curve collapses into a
 * line or one axis is padded by the other axis' span. Rendering with
 * `preserveAspectRatio={false}` lets each axis use its own scale, and this
 * module supplies one grid spacing per axis plus the visible ranges that make
 * every on-screen grid cell square again.
 *
 * The trick is that both spacings come from the same ladder of "nice" numbers
 * (1, 2, 2.5, 4, 5 x 10^k). Picking a pair whose cell sizes are already close
 * and then expanding the axis with the larger cell by a fraction of a cell
 * yields exactly square cells while the data stays tightly framed.
 */
export interface MafsGridRange {
    min: number;
    max: number;
}
export interface PlotGridLayoutInput {
    xDomain: MafsGridRange;
    yDomain: MafsGridRange;
    width: number;
    height: number;
    /** Fraction of each axis span added as breathing room around the data. */
    padding?: number;
    /** Preferred on-screen size of one grid cell, in CSS pixels. */
    targetCellPx?: number;
    /** Smallest sensible grid cell used when choosing a nice spacing. */
    minCellPx?: number;
    /** Largest sensible grid cell used when choosing a nice spacing. */
    maxCellPx?: number;
}
export interface PlotGridLayout {
    /** Grid spacing in x-axis units. */
    xLines: number;
    /** Grid spacing in y-axis units. */
    yLines: number;
    /** Visible x range, including padding and any square-cell correction. */
    xRange: MafsGridRange;
    /** Visible y range, including padding and any square-cell correction. */
    yRange: MafsGridRange;
    /** Resulting on-screen cell size, identical on both axes. */
    cellPx: number;
}
/** Return a finite, ordered range; degenerate inputs get a modest span. */
export declare function normalizeGridRange(range: MafsGridRange): MafsGridRange;
/** Largest "nice" number (1, 2, 2.5, 4 or 5 x 10^k) not above `value`. */
export declare function niceGridStep(value: number): number;
/**
 * Choose per-axis grid spacings and visible ranges so that:
 * - each axis frames its own data (small relative padding, never cropped);
 * - both axes use readable "nice" spacings;
 * - one grid cell renders as a square regardless of the axis magnitudes.
 */
export declare function plotGridLayout(input: PlotGridLayoutInput): PlotGridLayout;
