import { n as e } from "./sdk-core-Cp7nKlku.js";
import { a as t } from "./LocalDocumentView-DsGc-nc-.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
