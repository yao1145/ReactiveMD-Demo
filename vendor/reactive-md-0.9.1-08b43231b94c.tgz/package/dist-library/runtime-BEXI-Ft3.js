import { j as e } from "./version-DAxuGOG2.js";
import { _ as t, l as n, o as r, y as i } from "./document-theme-ByoHCvHV.js";
import { a, c as o, r as s, s as c, t as l } from "./compile-Bse2Oyua.js";
import { a as u, c as d, h as f, i as p, l as ee, n as m, o as h, p as g, r as _, t as v, u as y } from "./validation-BXGQlNQM.js";
import { n as b, t as x } from "./types-daDo2c_w.js";
import { i as S } from "./registry-core-C9xOunaw.js";
import { t as C } from "./registry-KzstBLYy.js";
import { x as te } from "./component-state-CwKX_SN5.js";
import { i as ne, t as w } from "./identity-BUx0Q_-d.js";
import { n as T } from "./runtime-BDnnimPA.js";
// src/local/runtime/runtime-values.ts
function E(e, t) {
	return e.attrs?.[t];
}
function D(e, t) {
	let n = E(e, t);
	if (n === "true") return !0;
	if (n === "false") return !1;
}
function O(e, t) {
	let n = E(e, t);
	if (n === void 0) return;
	let r = Number(n);
	return Number.isFinite(r) ? r : void 0;
}
function k(e) {
	return t(e);
}
function A(e, t) {
	return {
		ok: !1,
		detail: n(e, t)
	};
}
function j(e, t) {
	if (t !== void 0) return E(e, t);
}
function M(e, t) {
	if (t !== void 0) return O(e, t);
}
function N(t, n, r, i = {}) {
	for (let a of r) if (a.kind === "date") {
		if (!S(n)) return A("local.runtime.value.date-invalid");
		let e = i.required ?? (a.required !== void 0 && D(t, a.required) === !0);
		if (n === "" && e) return A("local.runtime.value.date-required");
		let r = i.min ?? j(t, a.min), o = i.max ?? j(t, a.max);
		if (n !== "" && r && n < r) return A("local.runtime.value.date-earlier", { min: r });
		if (n !== "" && o && n > o) return A("local.runtime.value.date-later", { max: o });
	} else if (a.kind === "required") {
		let e = i.required ?? D(t, a.required) === !0;
		if (n === "" && e) return A("local.runtime.value.field-required");
	} else if (a.kind === "length") {
		let e = k(n), r = M(t, a.min), i = M(t, a.max);
		if (r !== void 0 && r > 0 && n !== "" && e < r) return A("local.runtime.value.min-length", { min: r });
		if (i !== void 0 && e > i) return A("local.runtime.value.max-length", { max: i });
	} else if (a.kind === "email" && (j(t, a.type) ?? "text") === a.value && n !== "") {
		if (n.length > 254) return A("local.runtime.value.email-length", { limit: 254 });
		if (!e(n)) return A("local.runtime.value.email-invalid");
	}
	return {
		ok: !0,
		value: n
	};
}
var P = /* @__PURE__ */ new Map();
function F(e) {
	if (!e.name) return I;
	let t = P.get(e.name);
	if (t !== void 0) return t ?? I;
	let n = C(e.name), r = n ? f(n) : I;
	return P.set(e.name, n ? r : null), r;
}
var I = Object.freeze([]);
function L(e, t, n, i, a, s = !1) {
	switch (e.type) {
		case "number": {
			if (typeof n != "number" || !Number.isFinite(n)) return A("local.runtime.value.finite-number", { name: e.name });
			let r = e.step ?? 1, a = e.min ?? 0;
			for (let r of t) {
				let t = i(r, "min");
				if (t.present && !t.ok) return A("local.runtime.value.constraint", {
					name: e.name,
					attribute: "min"
				});
				if (t.present && t.ok) {
					if (typeof t.value != "number" || !Number.isFinite(t.value)) return A("local.runtime.value.constraint", {
						name: e.name,
						attribute: "min"
					});
					if (a = t.value, n < t.value) return A("local.runtime.value.min", {
						name: e.name,
						min: t.value
					});
				}
				let o = i(r, "max");
				if (o.present && !o.ok) return A("local.runtime.value.constraint", {
					name: e.name,
					attribute: "max"
				});
				if (o.present && o.ok) {
					if (typeof o.value != "number" || !Number.isFinite(o.value)) return A("local.runtime.value.constraint", {
						name: e.name,
						attribute: "max"
					});
					if (n > o.value) return A("local.runtime.value.max", {
						name: e.name,
						max: o.value
					});
				}
				if (t.present && t.ok && o.present && o.ok && typeof t.value == "number" && typeof o.value == "number" && t.value > o.value) return A("local.runtime.value.constraint-range", { name: e.name });
			}
			return e.min !== void 0 && n < e.min ? A("local.runtime.value.min", {
				name: e.name,
				min: e.min
			}) : e.max !== void 0 && n > e.max ? A("local.runtime.value.max", {
				name: e.name,
				max: e.max
			}) : r > 0 && !V(n, a, r) ? A("local.runtime.value.step", {
				name: e.name,
				step: r,
				base: a
			}) : {
				ok: !0,
				value: n
			};
		}
		case "boolean": return typeof n == "boolean" ? {
			ok: !0,
			value: n
		} : A("local.runtime.value.boolean", { name: e.name });
		case "string": {
			if (typeof n != "string") return A("local.runtime.value.string", { name: e.name });
			let c = o(n);
			if (c) return A("local.runtime.value.budget", {
				name: e.name,
				detail: r(c),
				detailKey: c.key,
				...c.params
			});
			for (let r of t) {
				let t = a?.get(r.id) ?? (s ? F(r) : I);
				if (!t.length) continue;
				let o = {};
				for (let n of t) {
					if (n.kind === "date") {
						for (let t of ["min", "max"]) {
							if (n[t] === void 0) continue;
							let a = i(r, t);
							if (a.present) {
								if (!a.ok || typeof a.value != "string" || !S(a.value)) return A("local.runtime.value.constraint-date", {
									name: e.name,
									attribute: t
								});
								o[t] = a.value;
							}
						}
						let t = o.min ?? j(r, n.min), a = o.max ?? j(r, n.max);
						if (t && a && S(t) && S(a) && t > a) return A("local.runtime.value.constraint-range", { name: e.name });
					}
					if ((n.kind === "date" || n.kind === "required" ? n.required : void 0) !== void 0) {
						let t = i(r, "required");
						if (t.present) {
							if (!t.ok || typeof t.value != "boolean") return A("local.runtime.value.constraint", {
								name: e.name,
								attribute: "required"
							});
							o.required = t.value;
						}
					}
				}
				let c = N(r, n, t, o);
				if (!c.ok) return c;
			}
			return e.options?.length && !e.options.includes(n) ? A("local.runtime.value.option", {
				value: n,
				options: e.options.join(", ")
			}) : {
				ok: !0,
				value: n
			};
		}
		case "array": {
			if (!Array.isArray(n)) return A("local.runtime.value.array", { name: e.name });
			let t = o(n);
			if (t) return A("local.runtime.value.budget", {
				name: e.name,
				detail: r(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "string") return A("local.runtime.value.array-members", { name: e.name });
			if (e.family === "collection") return e.maxItems !== void 0 && n.length > e.maxItems ? A("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
			let i = /* @__PURE__ */ new Set();
			for (let t of n) {
				if (e.options && !e.options.includes(t)) return A("local.runtime.value.checklist-option", { value: t });
				i.add(t);
			}
			let a = e.options ? e.options.filter((e) => i.has(e)) : [...i];
			return e.maxItems !== void 0 && a.length > e.maxItems ? A("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: a
			};
		}
		case "number-array": {
			if (!Array.isArray(n)) return A("local.runtime.value.number-array", { name: e.name });
			let t = o(n);
			if (t) return A("local.runtime.value.budget", {
				name: e.name,
				detail: r(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "number" || !Number.isFinite(t)) return A("local.runtime.value.number-array-members", { name: e.name });
			return e.maxItems !== void 0 && n.length > e.maxItems ? A("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
		}
		case "null": return n === null ? {
			ok: !0,
			value: n
		} : A("local.runtime.value.null", { name: e.name });
	}
	return A("local.runtime.value.unsupported-type", { name: e.name });
}
function R(e) {
	return e instanceof a ? e : new a("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function re(e, t) {
	switch (e) {
		case "string": {
			if (typeof t != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t
			};
		}
		case "number": return typeof t == "number" && Number.isFinite(t) ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "number" }
		};
		case "boolean": return typeof t == "boolean" ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "boolean" }
		};
		case "array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			for (let e of t) if (typeof e != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		case "number-array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			for (let e of t) if (typeof e != "number" || !Number.isFinite(e)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			let e = o(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		default: return {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: String(e) }
		};
	}
}
var z = 1e-9;
function B(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function V(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= z * Math.max(1, Math.abs(r));
}
function H(e, t, n, i) {
	let a = Math.max(0, Math.min(e.source.length, t.range.start)), o = e.source.slice(0, a).split("\n");
	return {
		code: n,
		message: r(i),
		severity: "error",
		range: {
			start: a,
			end: Math.max(a + 1, Math.min(e.source.length, t.range.end))
		},
		line: o.length,
		column: (o.at(-1) ?? "").length + 1,
		messageKey: i.key,
		phase: "runtime",
		recoverable: !0,
		...i.params ? { params: i.params } : {}
	};
}
function U(e, t, n) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1,
		phase: "runtime",
		recoverable: !0,
		...n ? {
			messageKey: n.key,
			...n.params ? { params: n.params } : {}
		} : {}
	};
}
// src/local/runtime/runtime-document.ts
function W(e, t) {
	let n = e.document.bindings[t];
	if (!n) return;
	let { nodeIds: r, owner: i, ...a } = n, o = (e.controls.get(t) ?? []).map((t) => {
		let n = e.document.dynamicConstraints?.[t.id] ?? {};
		return {
			name: t.name ?? null,
			attrs: t.attrs ?? {},
			dynamic: Object.fromEntries(Object.entries(n).map(([e, t]) => [e, t ? {
				source: t.source,
				numeric: t.numeric ?? null
			} : null])),
			rules: e.valueRules.get(t.id) ?? null
		};
	});
	return JSON.stringify({
		facts: a,
		legacy: e.legacyValueRules,
		controls: o
	});
}
function ie(e, t) {
	let n = t.get(e);
	if (n) return {
		expression: n,
		error: null
	};
	try {
		let n = l(e);
		if (t.size >= 200) {
			let e = t.keys().next().value;
			e !== void 0 && t.delete(e);
		}
		return t.set(e, n), {
			expression: n,
			error: null
		};
	} catch (e) {
		return {
			expression: null,
			error: R(e)
		};
	}
}
function ae(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of i(e.nodes)) n.set(t.id, t);
	let s = {}, l = /* @__PURE__ */ new Map();
	for (let [t, i] of Object.entries(e.bindings)) {
		let e = o(i.initial);
		if (e) throw new a("expression-budget", `Parameter "${t}": ${r(e)}`, 0);
		s[t] = B(i.initial);
		let c = [];
		for (let e of i.nodeIds) {
			let t = n.get(e);
			t && c.push(t);
		}
		l.set(t, c);
	}
	let d = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots ?? {})) d.set(t, { ...n });
	let f = g(e), p = new Map(Object.entries(f?.valueRules ?? {})), ee = f === void 0, m = /* @__PURE__ */ new Map();
	if (f) for (let e of f.slotRelations) {
		let t = d.get(e.nodeId), n = t?.[e.lower], r = t?.[e.upper];
		if (!n || !r) continue;
		let i = m.get(e.nodeId) ?? [];
		i.push({
			lower: n,
			upper: r
		}), m.set(e.nodeId, i);
	}
	else for (let [e, t] of d) t.start && t.end && m.set(e, [{
		lower: t.start,
		upper: t.end
	}]);
	let _ = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) for (let e of n.nodeIds) {
		if (d.has(e)) continue;
		let n = _.get(e);
		(n === void 0 || n.startsWith("@") && !t.startsWith("@")) && _.set(e, t);
	}
	let v = Object.freeze(Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort()), b = /* @__PURE__ */ new Map();
	for (let [e, t] of d) for (let n of Object.values(t)) {
		if (n.startsWith("@")) continue;
		let t = b.get(n) ?? /* @__PURE__ */ new Set();
		t.add(e), b.set(n, t);
	}
	let x = e.computations ?? {}, S = Object.keys(x), C = /* @__PURE__ */ new Map();
	for (let [e, n] of Object.entries(x)) {
		let r = ie(n.source, t);
		r.expression && C.set(e, r.expression);
	}
	let { order: te, cyclic: ne } = y(x), w = {}, T = /* @__PURE__ */ new Map();
	for (let e of te) {
		let t = x[e];
		if (!t || t.kind !== "const") continue;
		if (Object.hasOwn(t, "value")) {
			let n = t.value, r = c(n);
			if (r) {
				T.set(e, new a("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			w[e] = B(n);
			continue;
		}
		let n = C.get(e);
		if (!n) T.set(e, new a("expression-eval", `Constant "${e}" cannot be evaluated.`, 0));
		else try {
			let t = n.evaluate({ ...w }), r = c(t);
			if (r) {
				T.set(e, new a("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			w[e] = B(t);
		} catch (t) {
			T.set(e, R(t));
		}
	}
	let E = /* @__PURE__ */ new Map();
	for (let e of ne) E.set(e, new a("expression-cycle", `Computation "${e}" is part of a dependency cycle.`, 0));
	let D = [];
	if (Array.isArray(e.validations)) for (let n of e.validations) {
		if (!u(n)) continue;
		let e = ie(n.expression, t);
		D.push({
			rule: n,
			expression: e.expression,
			error: e.error
		});
	}
	return {
		document: e,
		nodeIndex: n,
		controls: l,
		slotKeys: d,
		publicNames: v,
		publicSlotOwners: b,
		initial: s,
		valueRules: p,
		legacyValueRules: ee,
		slotRelations: m,
		bindingByNode: _,
		computationMetadata: x,
		computationNames: S,
		computationOrder: te,
		cyclicComputations: ne,
		computationExpressions: C,
		constValues: w,
		constErrors: T,
		cycleErrors: E,
		validationRules: D,
		validationLineStarts: h(typeof e.source == "string" ? e.source : "")
	};
}
function oe(e) {
	return !e || e.syntax !== "local" ? "createLocalRuntime requires a local interaction document." : e.syntaxVersion !== void 0 && e.syntaxVersion !== "local-draft-3" || e.versionDeclaration && e.versionDeclaration.version !== "local-draft-3" ? `createLocalRuntime requires ${x}; migrate the source before constructing a runtime.` : null;
}
function G(e, t) {
	return (e.controls.get(t.name) ?? [])[0] ?? (t.owner ? e.nodeIndex.get(t.owner) : void 0) ?? (t.nodeIds[0] ? e.nodeIndex.get(t.nodeIds[0]) : void 0);
}
function se(e, t, n) {
	let i = G(e, t);
	return i ? H(e.document, i, "local.runtime.value", n) : U("local.runtime.value", r(n));
}
function K(e, t, n) {
	let r = e.slotRelations.get(t);
	return r?.length ? r.some(({ lower: e, upper: t }) => {
		let r = n[e], i = n[t];
		return typeof r == "number" && typeof i == "number" && r > i;
	}) : !1;
}
function ce(e, t) {
	let i = e.nodeIndex.get(t);
	return i ? H(e.document, i, "local.runtime.value", n("local.runtime.value.range-order")) : U("local.runtime.value", r(n("local.runtime.value.range-order")));
}
// src/local/runtime/retention.ts
function q(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of i(e.nodes)) t.set(n.id, n);
	return t;
}
function le(e, t, n) {
	let r = e.bindingSlots?.[t.id];
	return r !== void 0 && Object.values(r).includes(n);
}
function J(e, t, n) {
	let r = t.name ? C(t.name) : void 0;
	if (r?.bindings) {
		let i = e.bindingSlots?.[t.id];
		for (let [e, a] of Object.entries(r.bindings)) if (t.attrs?.[a.bind] === n || e !== "value" && i?.[e] === n) return a.retain === !1 ? void 0 : a.initial;
	} else if (t.attrs?.bind === n || le(e, t, n)) return "initial";
}
function Y(e) {
	let t = q(e), n = g(e), r = new Set(n?.retentionExclusions ?? []), i = /* @__PURE__ */ new Map();
	for (let [a, o] of Object.entries(e.bindings)) {
		let s = o.nodeIds.flatMap((e) => {
			let n = t.get(e);
			return n ? [n] : [];
		});
		if (!s.length || a.startsWith("@") || r.has(a)) continue;
		let c;
		if (n === void 0) {
			let t = s.map((t) => J(e, t, a));
			if (t.some((e) => e === void 0)) continue;
			c = t;
		} else {
			let e = n.bindingAttributes?.[a]?.initial ?? "initial";
			c = s.map(() => e);
		}
		let l = s.flatMap((e, t) => Object.hasOwn(e.attrs ?? {}, c[t]) ? [e.attrs[c[t]]] : []).sort();
		i.set(a, {
			type: o.type,
			initialDefinition: JSON.stringify([o.initial, l])
		});
	}
	return i;
}
function X(e, t) {
	return Object.freeze({
		name: e,
		reason: t
	});
}
function Z(e) {
	let t = Y(e.previous), n = Y(e.next), r = {}, i = [], a = [];
	for (let o of Object.keys(e.state).sort()) {
		if (o.startsWith("@")) {
			a.push(X(o, "internal"));
			continue;
		}
		if (!Object.hasOwn(e.previous.bindings, o) || !Object.hasOwn(e.next.bindings, o)) {
			a.push(X(o, "unknown"));
			continue;
		}
		let s = t.get(o), c = n.get(o);
		if (!s || !c) {
			a.push(X(o, "unretainable"));
			continue;
		}
		if (s.type !== c.type) {
			a.push(X(o, "type"));
			continue;
		}
		if (s.initialDefinition !== c.initialDefinition) {
			a.push(X(o, "initial"));
			continue;
		}
		let l = e.state[o];
		r[o] = Array.isArray(l) ? Object.freeze([...l]) : l, i.push(o);
	}
	return Object.freeze({
		values: Object.freeze(r),
		retained: Object.freeze(i),
		dropped: Object.freeze(a)
	});
}
function ue(e, t, n) {
	return Object.freeze({
		retained: Object.freeze([...e]),
		dropped: Object.freeze(t.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...n])
	});
}
function Q(e, t) {
	let n = Object.keys(t.values).sort();
	if (!e.setParameters(t.values).length) return ue(n, t.dropped, []);
	let r = [], i = n, a = [];
	for (; i.length;) {
		let n = [];
		a = [];
		for (let o of i) {
			let i = e.setParameter(o, t.values[o]);
			i.length ? (n.push(o), a.push(...i)) : r.push(o);
		}
		if (n.length === i.length) break;
		i = n;
	}
	r.sort();
	let o = [...t.dropped, ...i.map((e) => X(e, "invalid"))];
	return o.sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name)), ue(r, o, a);
}
// src/local/runtime/runtime-migration.ts
function de(e, t, n, r, i) {
	let a = Z({
		previous: e.document,
		state: t,
		next: n
	}), o = {};
	for (let [e, t] of Object.entries(n.bindings)) o[e] = B(t.initial);
	let s = /* @__PURE__ */ new Map();
	for (let e of a.dropped) s.set(e.name, Object.freeze({ ...e }));
	let c = [], l = {}, u = [], d = /* @__PURE__ */ new Set(), f, p = (n) => {
		let o = e.document.bindings[n], s = e.controls.get(n) ?? [];
		return !o || !s.some((t) => e.document.dynamicConstraints?.[t.id]) || (f ??= i({}, e, t), L(o, s, a.values[n], f, e.valueRules, e.legacyValueRules).ok) ? !1 : W(e, n) === W(r, n);
	};
	for (let e of a.retained) {
		let t = n.bindings[e];
		if (!t) continue;
		if (p(e)) {
			d.add(e), l[e] = B(a.values[e]), u.push(e);
			continue;
		}
		let f = L(t, r.controls.get(e) ?? [], a.values[e], i(a.values, r, o), r.valueRules, r.legacyValueRules);
		f.ok ? (l[e] = B(f.value), u.push(e)) : (c.push(se(r, t, f.detail)), s.set(e, Object.freeze({
			name: e,
			reason: "invalid"
		})));
	}
	let ee = {
		...o,
		...l
	}, m = /* @__PURE__ */ new Set();
	for (let e of u) for (let t of r.publicSlotOwners.get(e) ?? []) m.add(t);
	let h = !1;
	for (let e of [...m].sort()) if (K(r, e, ee)) {
		h = !0;
		break;
	}
	let g;
	if (!h) Object.assign(o, l), g = u;
	else {
		g = [];
		for (let e of u) {
			let t = o[e];
			o[e] = l[e];
			let n = !1;
			for (let t of [...r.publicSlotOwners.get(e) ?? []].sort()) K(r, t, o) && (c.push(ce(r, t)), n = !0);
			n ? (o[e] = t, s.set(e, Object.freeze({
				name: e,
				reason: "invalid"
			}))) : g.push(e);
		}
	}
	for (let [e, t] of r.slotRelations) if (K(r, e, o)) {
		for (let e of t) for (let t of [e.lower, e.upper]) {
			let e = n.bindings[t];
			if (!e) continue;
			o[t] = B(e.initial);
			let r = g.indexOf(t);
			r >= 0 && g.splice(r, 1), s.set(t, Object.freeze({
				name: t,
				reason: "invalid"
			}));
		}
		if (c.push(ce(r, e)), K(r, e, o)) return {
			values: {},
			retained: [],
			dropped: [],
			diagnostics: []
		};
	}
	let _ = !0;
	for (; _;) {
		let e = i({}, r, o), t = [];
		for (let i of g) {
			if (d.has(i)) continue;
			let a = n.bindings[i], s = L(a, r.controls.get(i) ?? [], o[i], e, r.valueRules, r.legacyValueRules);
			s.ok || (c.push(se(r, a, s.detail)), t.push(i));
		}
		for (let e of t) o[e] = B(n.bindings[e].initial), g.splice(g.indexOf(e), 1), s.set(e, Object.freeze({
			name: e,
			reason: "invalid"
		}));
		_ = t.length > 0;
	}
	let v = [...s.values()].sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name));
	return g.sort(), {
		values: o,
		retained: g,
		dropped: v,
		diagnostics: c
	};
}
// src/local/runtime/runtime.ts
function fe(e) {
	return {
		...e,
		range: { ...e.range }
	};
}
function pe(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => e === t[n]) : e === t;
}
function me(e) {
	for (let [t, n] of Object.entries(e)) Array.isArray(n) && !Object.isFrozen(n) && (e[t] = Object.freeze([...n]));
	return Object.freeze(e);
}
var he = /* @__PURE__ */ new WeakMap();
function $(e) {
	return Object.freeze({
		ok: e.ok,
		changed: e.changed,
		revision: e.revision,
		retained: Object.freeze([...e.retained]),
		dropped: Object.freeze(e.dropped.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...e.diagnostics])
	});
}
function ge(e, t, n) {
	let r = he.get(e);
	if (!r) throw TypeError("updateLocalRuntime requires a runtime created by createLocalRuntime.");
	return r.update(t, n?.notify !== !1);
}
function _e(e) {
	he.get(e)?.notify();
}
function ve(e, t, n) {
	return he.get(e)?.bindNetworkExternals(t, n) ?? (() => {});
}
function ye(e, t) {
	let c = oe(e);
	if (c) throw Error(c);
	let u = t?.services === void 0, f = te(t?.network), h = /* @__PURE__ */ new Map(), g = ne(e.source), y = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Map(), S = ae(e, x), C = () => S, E = () => {
		let e = /* @__PURE__ */ new Set();
		for (let n of i(S.document.nodes)) n.name !== void 0 && e.add(w({
			documentId: t?.documentId,
			sourceDigest: g,
			nodeId: n.id,
			stateKey: n.attrs?.["state-key"]
		}));
		return e;
	}, D = t?.services ?? T({
		documentId: t?.documentId,
		sourceDigest: g,
		randomSeed: t?.randomSeed,
		componentState: t?.componentState,
		...t?.componentStateStorage === void 0 ? {} : { componentStateStorage: t.componentStateStorage },
		...t?.componentStateWriteDelayMs === void 0 ? {} : { componentStateWriteDelayMs: t.componentStateWriteDelayMs },
		...t?.configKey === void 0 ? {} : { configKey: t.configKey },
		...t?.legacyConfigKeys === void 0 ? {} : { legacyConfigKeys: t.legacyConfigKeys },
		...u ? { knownStateKeys: E } : {}
	}), O = {}, k = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e.externals ?? {})) {
		let e = t?.externalValues?.[n];
		if (e === void 0) continue;
		let i = re(r.type, e);
		i.ok && (O[n] = i.value);
	}
	let A = (e, t) => {
		let n = {};
		for (let [r, i] of Object.entries(e.document.externals ?? {})) {
			if (!Object.hasOwn(t, r)) continue;
			let e = re(i.type, t[r]);
			e.ok && (n[r] = e.value);
		}
		return n;
	}, j = (e) => {
		let t = A(e, O);
		for (let n of k.keys()) Object.assign(t, A(e, n));
		return t;
	}, M = (e, t, n, r = C()) => {
		let i = r.document.dynamicConstraints?.[e.id]?.[t];
		if (!i) return { present: !1 };
		let a = ie(i.source, x);
		if (!a.expression) return {
			present: !0,
			ok: !1
		};
		try {
			let e = a.expression.evaluate(n), t = i.numeric;
			return t && (typeof e != "number" || !Number.isFinite(e) || t.integer === !0 && !Number.isInteger(e) || t.min !== void 0 && e < t.min || t.max !== void 0 && e > t.max) ? {
				present: !0,
				ok: !1
			} : {
				present: !0,
				ok: !0,
				value: e
			};
		} catch {
			return {
				present: !0,
				ok: !1
			};
		}
	}, N = S.initial, P = 0, F = {}, I = {}, R = {
		revision: 0,
		state: me({})
	}, z = !1, V = null, W = /* @__PURE__ */ new Set(), G = /* @__PURE__ */ new Map(), q = () => {
		if (z) throw Error("The local interaction runtime has been disposed.");
	};
	function le(e, t) {
		if (!t.startsWith("@") && Object.hasOwn(e.document.bindings, t)) return Object.hasOwn(N, t) ? N[t] : void 0;
	}
	let J = (e, t) => {
		let n = j(e), r = /* @__PURE__ */ new Map();
		for (let t of Object.keys(e.document.externals ?? {})) Object.hasOwn(n, t) || r.set(t, new a("external-missing", "External data \"" + t + "\" is not available.", 0));
		let i = {}, o = /* @__PURE__ */ new Map();
		if (e.computationNames.length > 0) {
			let a = ee(e.computationMetadata, e.computationOrder, e.computationExpressions, {
				...t,
				...n
			}, e.constValues, r);
			i = a.values, o = a.errors;
			for (let [t, n] of e.constErrors) Object.hasOwn(i, t) || o.set(t, n);
			for (let [t, n] of e.cycleErrors) Object.hasOwn(i, t) || o.set(t, n);
		}
		let s = {};
		for (let [e, n] of Object.entries(t)) s[e] = n;
		for (let [e, t] of Object.entries(n)) s[e] = t;
		for (let [e, t] of Object.entries(i)) s[e] = t;
		for (let [e, t] of [...r, ...o]) Object.hasOwn(i, e) || Object.defineProperty(s, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw t;
			}
		});
		let c = {};
		for (let [e, n] of Object.entries(t)) c[e] = n;
		for (let [e, t] of Object.entries(n)) c[e] = t;
		for (let [e, t] of Object.entries(i)) c[e] = t;
		return {
			environment: s,
			snapshotState: c
		};
	}, Y = () => {
		let e = J(C(), N);
		F = e.environment, I = e.snapshotState;
	}, X = (e, t = C(), n = N) => {
		let r;
		return (i, a) => t.document.dynamicConstraints?.[i.id]?.[a] ? (r ??= J(t, {
			...n,
			...e
		}).environment, M(i, a, r, t)) : { present: !1 };
	}, Z = () => {
		R = {
			revision: P,
			state: me(I)
		};
	}, ue = () => {
		for (let e of W) e();
	}, Q = (e) => {
		N = e, P += 1, Y(), Z(), ue();
	}, ge = () => {
		P += 1, Y(), Z(), ue();
	}, _e = (e, t = O) => {
		if (q(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setExternalValues requires an object of external values.");
		let i = [], a = {}, o = Object.keys(e).sort();
		for (let t of o) {
			if (t === "__proto__") {
				i.push(U("local.runtime.external", "External names cannot be \"__proto__\"."));
				continue;
			}
			let o = C().document.externals ?? {}, s = Object.hasOwn(o, t) ? o[t] : void 0;
			if (!s) {
				let e = n("local.runtime.external", { name: t });
				i.push(U("local.runtime.external", r(e), e));
				continue;
			}
			let c = re(s.type, e[t]);
			if (c.ok) a[t] = c.value;
			else {
				let e = n(c.key, {
					name: t,
					...c.params ?? {}
				});
				i.push(U("local.runtime.external", r(e), e));
			}
		}
		return i.length ? i : (o.some((e) => !pe(t[e], a[e])) && (Object.assign(t, a), ge()), []);
	}, ve = (e, t) => {
		if (z) return () => {};
		let n = {}, r = e.bindExternalValues((e) => {
			if (z || !k.has(n)) return;
			let r = _e(e, n);
			r.length && t?.(r);
		});
		return r ? (k.set(n, r), () => {
			k.delete(n) && (r(), !z && Object.keys(n).length && ge());
		}) : () => {};
	}, ye = (e) => {
		q();
		let t = C(), n = [], r = {}, i = Object.keys(e).sort(), a = X(e);
		for (let o of i) {
			if (o === "__proto__") {
				n.push(U("local.runtime.parameter", "Parameter names cannot be \"__proto__\"."));
				continue;
			}
			if (o.startsWith("@")) {
				n.push(U("local.runtime.parameter", `Internal parameter "${o}" cannot be written by name.`));
				continue;
			}
			if (!Object.hasOwn(t.document.bindings, o)) {
				n.push(U("local.runtime.parameter", `Unknown parameter "${o}".`));
				continue;
			}
			let i = t.document.bindings[o], s = L(i, t.controls.get(o) ?? [], e[o], a, t.valueRules, t.legacyValueRules);
			s.ok ? r[o] = B(s.value) : n.push(se(t, i, s.detail));
		}
		if (n.length) return n;
		if (!i.some((e) => !pe(N[e], r[e]))) return [];
		let o = {
			...N,
			...r
		}, s = /* @__PURE__ */ new Set();
		for (let e of i) for (let n of t.publicSlotOwners.get(e) ?? []) s.add(n);
		for (let e of [...s].sort()) K(t, e, o) && n.push(ce(t, e));
		return n.length ? n : (Q(o), []);
	}, be = (e) => {
		let t = y.get(e);
		if (!t) {
			if (t = l(e), y.size >= 200) {
				let e = y.keys().next().value;
				e !== void 0 && y.delete(e);
			}
			y.set(e, t);
		}
		return t;
	}, xe = () => {
		let e = C(), t = [], n = typeof e.document.source == "string" ? e.document.source : "";
		for (let r of e.validationRules) {
			if (r.error) {
				t.push(d(n, e.validationLineStarts, r.rule.range, v, p(`Validation expression is invalid: ${r.error.message}`)));
				continue;
			}
			if (!r.expression) continue;
			let i;
			try {
				i = r.expression.evaluate(F);
			} catch (i) {
				t.push(d(n, e.validationLineStarts, r.rule.range, v, p(`Validation expression failed: ${i instanceof Error ? i.message : String(i)}`)));
				continue;
			}
			typeof i == "boolean" ? i || t.push(d(n, e.validationLineStarts, r.rule.range, m, Se(r.rule.message))) : t.push(d(n, e.validationLineStarts, r.rule.range, v, "Validation expression must evaluate to a boolean."));
		}
		return t;
	}, Se = (e) => {
		let t;
		try {
			t = s(e, F);
		} catch {
			t = _;
		}
		return p(t);
	}, Ce = (e, t) => {
		if (q(), e === S.document) return $({
			ok: !0,
			changed: !1,
			revision: P,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		if (oe(e)) return $({
			ok: !1,
			changed: !1,
			revision: P,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let n;
		try {
			n = ae(e, x);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: P,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let r = de(S, N, e, n, X);
		if (Object.keys(r.values).length === 0 && Object.keys(e.bindings).length > 0) return $({
			ok: !1,
			changed: !1,
			revision: P,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let i;
		try {
			i = J(n, r.values);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: P,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		for (let e of [O, ...k.keys()]) {
			let t = A(n, e);
			for (let t of Object.keys(e)) delete e[t];
			Object.assign(e, t);
		}
		if (S = n, N = r.values, F = i.environment, I = i.snapshotState, V = null, P += 1, Z(), t) for (let e of W) e();
		return $({
			ok: !0,
			changed: !0,
			revision: P,
			retained: r.retained,
			dropped: r.dropped,
			diagnostics: r.diagnostics
		});
	}, we = (e) => {
		let t = /* @__PURE__ */ new Set();
		for (let n of i([e])) t.add(n.id);
		return t;
	}, Te = {
		network: f.network,
		get document() {
			return S.document;
		},
		services: D,
		snapshot() {
			return q(), R;
		},
		get(e, t) {
			q();
			let n = C(), r = n.nodeIndex.get(e.id);
			if (!r) return null;
			let i = t === void 0 ? n.slotKeys.get(r.id)?.value ?? n.bindingByNode.get(r.id) ?? b(r) : n.slotKeys.get(r.id)?.[t];
			return i && Object.hasOwn(N, i) ? B(N[i]) : null;
		},
		set(e, t, r) {
			q();
			let i = C(), a = i.nodeIndex.get(e.id);
			if (!a) return [H(i.document, e, "local.runtime.binding", n("local.runtime.binding.no-writable"))];
			let o = i.slotKeys.get(a.id), s;
			if (r === void 0) {
				if (o && !o.value) return [H(i.document, a, "local.runtime.binding", n("local.runtime.binding.needs-slot"))];
				s = o?.value ?? i.bindingByNode.get(a.id) ?? b(a);
			} else if (s = o?.[r], !s) return [H(i.document, a, "local.runtime.binding", n("local.runtime.binding.unknown-slot", { slot: r }))];
			let c = Object.hasOwn(i.document.bindings, s) ? i.document.bindings[s] : void 0;
			if (!c) return [H(i.document, a, "local.runtime.binding", n("local.runtime.binding.no-writable"))];
			let l = L(c, i.controls.get(s) ?? [], t, X({ [s]: t }), i.valueRules, i.legacyValueRules);
			if (!l.ok) return [H(i.document, a, "local.runtime.value", l.detail)];
			let u = B(l.value);
			if (pe(N[s], u)) return [];
			let d = {
				...N,
				[s]: u
			};
			return K(i, a.id, d) ? [H(i.document, a, "local.runtime.value", n("local.runtime.value.range-order"))] : (Q(d), []);
		},
		setMany(e, t) {
			q();
			let r = C(), i = r.nodeIndex.get(e.id);
			if (!i) return [H(r.document, e, "local.runtime.binding", n("local.runtime.binding.no-writable"))];
			let a = r.slotKeys.get(i.id);
			if (!a) return [H(r.document, i, "local.runtime.binding", n("local.runtime.binding.no-multi-slot"))];
			let o = Object.entries(t);
			if (!o.length) return [];
			let s = { ...N }, c = J(r, {
				...N,
				...Object.fromEntries(o.map(([e, t]) => [a[e], t]))
			}).environment;
			for (let [e, t] of o) {
				let o = a[e];
				if (!o || !Object.hasOwn(r.document.bindings, o)) return [H(r.document, i, "local.runtime.binding", n("local.runtime.binding.unknown-slot", { slot: e }))];
				let l = L(r.document.bindings[o], r.controls.get(o) ?? [], t, (e, t) => M(e, t, c), r.valueRules, r.legacyValueRules);
				if (!l.ok) return [H(r.document, i, "local.runtime.value", l.detail)];
				s[o] = B(l.value);
			}
			return K(r, i.id, s) ? [H(r.document, i, "local.runtime.value", n("local.runtime.value.range-order"))] : (o.every(([e, t]) => pe(N[a[e]], t)) || Q(s), []);
		},
		parameterNames() {
			return q(), C().publicNames;
		},
		getParameter(e) {
			q();
			let t = le(C(), e);
			return t === void 0 ? void 0 : B(t);
		},
		getParameters() {
			q();
			let e = C(), t = {};
			for (let n of e.publicNames) {
				let e = N[n];
				t[n] = Array.isArray(e) ? Object.freeze([...e]) : e;
			}
			return Object.freeze(t);
		},
		readSubmissionFields(e) {
			q();
			let t = C(), n = /* @__PURE__ */ new Map(), r = (e, n) => M(e, n, F, t);
			if (e.length === 0) return {
				ok: !1,
				field: "",
				reason: "unavailable"
			};
			for (let i of e) {
				let e = le(t, i);
				if (e === void 0 || n.has(i)) return {
					ok: !1,
					field: i,
					reason: "unavailable"
				};
				let a = L(t.document.bindings[i], t.controls.get(i) ?? [], e, r, t.valueRules, t.legacyValueRules);
				if (!a.ok) {
					let e = a.detail.key;
					return {
						ok: !1,
						field: i,
						reason: e === "local.runtime.value.field-required" || e === "local.runtime.value.date-required" ? "required" : "invalid"
					};
				}
				n.set(i, e);
			}
			let i = Object.create(null);
			for (let [e, r] of n) {
				for (let [n, i] of h.get(e) ?? []) {
					if (!t.controls.get(e)?.some((e) => e.id === i)) continue;
					let a = n(B(r));
					if (a) return {
						ok: !1,
						field: e,
						reason: a
					};
				}
				i[e] = Array.isArray(r) ? Object.freeze([...r]) : r;
			}
			return {
				ok: !0,
				payload: Object.freeze(i)
			};
		},
		registerSubmissionField(e, t) {
			if (z) return () => {};
			let n = C(), r = n.slotKeys.get(e.id)?.value ?? n.bindingByNode.get(e.id);
			if (!r || r.startsWith("@")) return () => {};
			let i = h.get(r);
			return i || h.set(r, i = /* @__PURE__ */ new Map()), i.set(t, e.id), () => {
				i.delete(t), i.size === 0 && h.get(r) === i && h.delete(r);
			};
		},
		setParameter(e, t) {
			q();
			let n = Object.create(null);
			return n[e] = t, ye(n);
		},
		setParameters(e) {
			if (q(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setParameters requires an object of parameter values.");
			return ye(e);
		},
		getExternal(e) {
			if (q(), Object.hasOwn(C().document.externals ?? {}, e) && Object.hasOwn(I, e)) return B(I[e]);
		},
		getExternalValues() {
			q();
			let e = {};
			for (let [t, n] of Object.entries(j(C()))) e[t] = Array.isArray(n) ? Object.freeze([...n]) : n;
			return Object.freeze(e);
		},
		setExternalValues(e) {
			return _e(e);
		},
		evaluate(e) {
			q();
			let t = be(e).evaluate(F);
			return Array.isArray(t) ? t.slice() : t;
		},
		validate() {
			if (q(), V && V.revision === P) return V.diagnostics.map(fe);
			let e = xe();
			return V = {
				revision: P,
				diagnostics: e
			}, e.map(fe);
		},
		text(e) {
			return q(), s(e, F);
		},
		reset(e) {
			q();
			let t = C(), n = t.nodeIndex.get(e.id);
			if (!n) return;
			let i = we(n), s = { ...N };
			for (let [e, n] of Object.entries(t.document.bindings)) {
				if (!(t.controls.get(e) ?? []).some((e) => i.has(e.id))) continue;
				let c = o(n.initial);
				if (c) throw new a("expression-budget", `Parameter "${e}": ${r(c)}`, 0);
				s[e] = B(n.initial);
			}
			for (let e of i) G.set(e, (G.get(e) ?? 0) + 1);
			Q(s);
		},
		resetToken(e) {
			q();
			let t = C().nodeIndex.get(e.id);
			return t ? G.get(t.id) ?? 0 : 0;
		},
		subscribe(e) {
			return q(), W.add(e), () => {
				W.delete(e);
			};
		},
		dispose() {
			if (!z) {
				z = !0, f.dispose();
				for (let e of k.values()) e();
				k.clear(), h.clear(), D.state.flush(), u && D.scheduler.dispose(), W.clear(), y.clear(), x.clear(), S.computationExpressions.clear(), S.constErrors.clear(), S.cycleErrors.clear(), S.validationRules.length = 0, G.clear();
			}
		}
	};
	return he.set(Te, {
		update: Ce,
		bindNetworkExternals: ve,
		notify() {
			if (!z) for (let e of W) e();
		}
	}), Y(), Z(), ve(f), Te;
}
export { Q as a, ge as i, ye as n, Z as o, _e as r, ve as t };
