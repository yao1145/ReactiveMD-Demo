import { A as e, k as t, y as n } from "./version-DAxuGOG2.js";
import { _ as r, l as i, o as a } from "./document-theme-ByoHCvHV.js";
// src/local/evaluation/expression/values.ts
var o = class extends Error {
	offset;
	code;
	constructor(e, t, n = 0) {
		super(t), this.name = "LocalExpressionError", this.code = e, this.offset = n;
	}
}, s = /* @__PURE__ */ "abs.sqrt.floor.ceil.round.min.max.pow.sin.cos.tan.asin.acos.atan.exp.log.len.contains.clamp.sum.average.minOf.maxOf.formatNumber.formatPercent.formatScientific.formatCurrency.trim.lower.upper.startsWith.endsWith.replace.slice.dateCompare.dateDiff".split("."), c = new Set(s), l = /* @__PURE__ */ new Map([["pi", Math.PI], ["e", Math.E]]), u = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]), ee = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), te = /* @__PURE__ */ new Set([
	...s,
	"x",
	"y",
	"pi",
	"e",
	"true",
	"false",
	"null",
	...u
]), ne = 4e3, d = t;
function f(r) {
	if (r.length > 1e4) return {
		code: "expression-budget",
		...i("local.budget.value.array", { limit: n }),
		message: `Array exceeds the ${n}-item limit.`
	};
	let a = null, o = 0;
	for (let n of r) if (typeof n == "string") {
		if (a === "number") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (a = "string", n.length > 1e5) return {
			code: "expression-budget",
			...i("local.budget.value.array-member", { limit: t }),
			message: `Array member exceeds the ${t}-character limit.`
		};
		if (o += n.length, o > 1e5) return {
			code: "expression-budget",
			...i("local.budget.value.array-contents", { limit: e }),
			message: `Array contents exceed the ${e}-character limit.`
		};
	} else if (typeof n == "number") {
		if (a === "string") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (a = "number", !Number.isFinite(n)) return {
			code: "expression-value",
			key: "error.array.finite",
			message: "Array members must be finite numbers."
		};
	} else return {
		code: "expression-value",
		key: "error.array.members",
		message: "Array members must be strings or finite numbers."
	};
	return null;
}
function p(e) {
	if (typeof e == "string") return e.length > 1e5 ? i("local.budget.value.string", { limit: t }) : null;
	if (Array.isArray(e)) {
		let t = f(e);
		return t ? i(t.key, t.params) : null;
	}
	return null;
}
function m(e) {
	let t = p(e);
	return t ? a(t) : null;
}
// src/local/evaluation/expression/syntax.ts
var re = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/, h = /[A-Za-z_]/, ie = /[A-Za-z0-9_]/;
function ae(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r >= "0" && r <= "9" || r === "." && /[0-9]/.test(e[n + 1] ?? "")) {
			let r = re.exec(e.slice(n));
			if (!r) throw new o("expression-syntax", "Invalid number.", n);
			let i = r[0], a = Number(i);
			if (!Number.isFinite(a)) throw new o("expression-number", `Number must be finite: ${i}.`, n);
			t.push({
				kind: "number",
				value: i,
				start: n,
				number: a
			}), n += i.length;
			continue;
		}
		if (r === "\"" || r === "'") {
			let i = n, a = r, s = "", c = n + 1, l = !1;
			for (; c < e.length;) {
				let t = e[c];
				if (t === a) {
					l = !0, c += 1;
					break;
				}
				if (t === "\n" || t === "\r") throw new o("expression-string", "String literals cannot span lines.", i);
				if (t === "\\") {
					let t = e[c + 1];
					if (t === void 0) break;
					switch (t) {
						case "\\":
							s += "\\";
							break;
						case "'":
							s += "'";
							break;
						case "\"":
							s += "\"";
							break;
						case "n":
							s += "\n";
							break;
						case "t":
							s += "	";
							break;
						default: throw new o("expression-string", `Unsupported escape \\${t}.`, c);
					}
					c += 2;
				} else s += t, c += 1;
			}
			if (!l) throw new o("expression-string", "Unterminated string literal.", i);
			if (s.length > d) throw new o("expression-budget", "String literal exceeds the length limit.", i);
			t.push({
				kind: "string",
				value: s,
				start: i
			}), n = c;
			continue;
		}
		if (h.test(r)) {
			let r = n + 1;
			for (; r < e.length && ie.test(e[r]);) r += 1;
			t.push({
				kind: "ident",
				value: e.slice(n, r),
				start: n
			}), n = r;
			continue;
		}
		let i = e.slice(n, n + 2);
		if (e.startsWith("!==", n) || e.startsWith("===", n)) throw new o("expression-syntax", `Unsupported operator ${e.slice(n, n + 3)}.`, n);
		if (i === "==" || i === "!=" || i === "<=" || i === ">=" || i === "&&" || i === "||") t.push({
			kind: "punct",
			value: i,
			start: n
		}), n += 2;
		else if ("+-*/%()!<>?:,[]".includes(r)) t.push({
			kind: "punct",
			value: r,
			start: n
		}), n += 1;
		else throw r === "=" ? new o("expression-assignment", "Assignments are not supported.", n) : r === "." ? new o("expression-property", "Property access is not supported.", n) : r === "&" || r === "|" ? new o("expression-syntax", `Use ${r}${r} for logical operations.`, n) : new o("expression-syntax", `Unrecognized character "${r}".`, n);
	}
	return t.push({
		kind: "eof",
		value: "",
		start: e.length
	}), t;
}
var oe = {
	abs: [1, 1],
	sqrt: [1, 1],
	floor: [1, 1],
	ceil: [1, 1],
	round: [1, 1],
	min: [1, 2 ** 53 - 1],
	max: [1, 2 ** 53 - 1],
	pow: [2, 2],
	sin: [1, 1],
	cos: [1, 1],
	tan: [1, 1],
	asin: [1, 1],
	acos: [1, 1],
	atan: [1, 1],
	exp: [1, 1],
	log: [1, 1],
	len: [1, 1],
	contains: [2, 2],
	clamp: [3, 3],
	sum: [1, 1],
	average: [1, 1],
	minOf: [1, 1],
	maxOf: [1, 1],
	formatNumber: [1, 4],
	formatPercent: [1, 3],
	formatScientific: [1, 3],
	formatCurrency: [1, 4],
	trim: [1, 1],
	lower: [1, 1],
	upper: [1, 1],
	startsWith: [2, 2],
	endsWith: [2, 2],
	replace: [3, 3],
	slice: [2, 3],
	dateCompare: [2, 2],
	dateDiff: [2, 3]
};
function se(e) {
	let t = 0, n = [{
		node: e,
		depth: 1
	}];
	for (; n.length > 0;) {
		let { node: e, depth: r } = n.pop();
		switch (r > t && (t = r), e.kind) {
			case "unary":
				n.push({
					node: e.operand,
					depth: r + 1
				});
				break;
			case "binary":
				n.push({
					node: e.left,
					depth: r + 1
				}), n.push({
					node: e.right,
					depth: r + 1
				});
				break;
			case "conditional":
				n.push({
					node: e.test,
					depth: r + 1
				}), n.push({
					node: e.consequent,
					depth: r + 1
				}), n.push({
					node: e.alternate,
					depth: r + 1
				});
				break;
			case "call":
				for (let t of e.args) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "array":
				for (let t of e.elements) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "index": n.push({
				node: e.target,
				depth: r + 1
			}), n.push({
				node: e.index,
				depth: r + 1
			});
		}
	}
	return t;
}
var ce = class {
	tokens;
	position = 0;
	nodeCount = 0;
	dependencyNames = [];
	dependencySet = /* @__PURE__ */ new Set();
	dependencyStarts = /* @__PURE__ */ new Map();
	constructor(e) {
		this.tokens = ae(e);
	}
	get dependencies() {
		return this.dependencyNames;
	}
	get dependencyOffsets() {
		return this.dependencyStarts;
	}
	parse() {
		if (this.peek().kind === "eof") throw new o("expression-empty", "Expression is empty.", 0);
		let e = this.parseConditional(0), t = this.peek();
		if (t.kind !== "eof") throw new o("expression-syntax", `Unexpected content "${t.value}".`, t.start);
		if (se(e) > 200) throw new o("expression-budget", "Expression is nested too deeply.", e.start);
		return e;
	}
	peek() {
		return this.tokens[this.position];
	}
	next() {
		let e = this.tokens[this.position];
		return this.position += 1, e;
	}
	isPunct(e) {
		let t = this.peek();
		return t.kind === "punct" && t.value === e;
	}
	expect(e) {
		let t = this.peek();
		if (t.kind !== "punct" || t.value !== e) throw new o("expression-syntax", `Missing "${e}".`, t.start);
		return this.next();
	}
	node(e, t, n) {
		if (this.nodeCount += 1, this.nodeCount > 2e3) throw new o("expression-budget", "Expression is too complex.", n);
		if (t > 100) throw new o("expression-budget", "Expression is nested too deeply.", n);
		return e;
	}
	parseConditional(e) {
		let t = this.parseOr(e);
		if (!this.isPunct("?")) return t;
		let n = t.start;
		this.next();
		let r = this.parseConditional(e + 1);
		this.expect(":");
		let i = this.parseConditional(e + 1);
		return this.node({
			kind: "conditional",
			test: t,
			consequent: r,
			alternate: i,
			start: n
		}, e, n);
	}
	parseOr(e) {
		let t = this.parseAnd(e);
		for (; this.isPunct("||");) {
			let n = t.start;
			this.next();
			let r = this.parseAnd(e);
			t = this.node({
				kind: "binary",
				operator: "||",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAnd(e) {
		let t = this.parseEquality(e);
		for (; this.isPunct("&&");) {
			let n = t.start;
			this.next();
			let r = this.parseEquality(e);
			t = this.node({
				kind: "binary",
				operator: "&&",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseEquality(e) {
		let t = this.parseRelational(e);
		for (; this.isPunct("==") || this.isPunct("!=");) {
			let n = t.start, r = this.next().value, i = this.parseRelational(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseRelational(e) {
		let t = this.parseAdditive(e);
		for (; this.isPunct("<") || this.isPunct("<=") || this.isPunct(">") || this.isPunct(">=");) {
			let n = t.start, r = this.next().value, i = this.parseAdditive(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAdditive(e) {
		let t = this.parseMultiplicative(e);
		for (; this.isPunct("+") || this.isPunct("-");) {
			let n = t.start, r = this.next().value, i = this.parseMultiplicative(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseMultiplicative(e) {
		let t = this.parseUnary(e);
		for (; this.isPunct("*") || this.isPunct("/") || this.isPunct("%");) {
			let n = t.start, r = this.next().value, i = this.parseUnary(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseUnary(e) {
		let t = this.peek();
		if (t.kind === "punct" && (t.value === "-" || t.value === "+" || t.value === "!")) {
			this.next();
			let n = this.parseUnary(e + 1);
			return this.node({
				kind: "unary",
				operator: t.value,
				operand: n,
				start: t.start
			}, e, t.start);
		}
		return this.parsePrimary(e);
	}
	parsePrimary(e) {
		let t = this.parseAtom(e);
		for (; this.isPunct("[");) {
			let n = t.start;
			this.next();
			let r = this.parseConditional(e + 1);
			this.expect("]"), t = this.node({
				kind: "index",
				target: t,
				index: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAtom(e) {
		let t = this.peek();
		if (t.kind === "number") return this.next(), this.node({
			kind: "literal",
			value: t.number,
			start: t.start
		}, e, t.start);
		if (t.kind === "string") return this.next(), this.node({
			kind: "literal",
			value: t.value,
			start: t.start
		}, e, t.start);
		if (t.kind === "ident") {
			this.next();
			let n = t.value;
			if (this.isPunct("(")) {
				if (!c.has(n)) throw new o("expression-unknown-function", `Unknown function "${n}".`, t.start);
				this.next();
				let r = [];
				if (!this.isPunct(")")) for (r.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), r.push(this.parseConditional(e + 1));
				this.expect(")");
				let [i, a] = oe[n];
				if (r.length < i || r.length > a) throw new o("expression-arity", `Function ${n} expects ${i === a ? `${i} ${i === 1 ? "argument" : "arguments"}` : i === 1 ? "at least one argument" : `${i}–${a} arguments`}.`, t.start);
				return this.node({
					kind: "call",
					name: n,
					args: r,
					start: t.start
				}, e, t.start);
			}
			if (n === "true" || n === "false") return this.node({
				kind: "literal",
				value: n === "true",
				start: t.start
			}, e, t.start);
			if (n === "null") return this.node({
				kind: "literal",
				value: null,
				start: t.start
			}, e, t.start);
			let r = l.get(n);
			if (r !== void 0) return this.node({
				kind: "literal",
				value: r,
				start: t.start
			}, e, t.start);
			if (u.has(n)) throw new o("expression-forbidden-name", `Name "${n}" is not allowed.`, t.start);
			if (c.has(n)) throw new o("expression-syntax", `Function ${n} must be called with parentheses.`, t.start);
			return this.dependencySet.has(n) || (this.dependencySet.add(n), this.dependencyNames.push(n), this.dependencyStarts.set(n, t.start)), this.node({
				kind: "reference",
				name: n,
				start: t.start
			}, e, t.start);
		}
		if (t.kind === "punct" && t.value === "(") {
			this.next();
			let t = this.parseConditional(e + 1);
			return this.expect(")"), t;
		}
		if (t.kind === "punct" && t.value === "[") {
			this.next();
			let n = [];
			if (!this.isPunct("]")) for (n.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), n.push(this.parseConditional(e + 1));
			return this.expect("]"), this.node({
				kind: "array",
				elements: n,
				start: t.start
			}, e, t.start);
		}
		throw new o("expression-syntax", "Expected an expression.", t.start);
	}
}, g = class extends Error {
	code;
	constructor(e, t) {
		super(t), this.name = "LocalFunctionError", this.code = e;
	}
}, _ = [
	"en-US",
	"zh-CN",
	"de-DE",
	"fr-FR",
	"ja-JP"
], le = new Set(_), ue = /^[A-Z]{3}$/, v = 20, de = { signDisplay: "negative" };
function y(e) {
	throw new g("expression-domain", e);
}
function b(e, n) {
	if (e.length > 1e5) throw new g("expression-budget", `${n} exceeds the ${t}-character limit.`);
	return e;
}
function x(e) {
	return le.has(e) || y(`Unsupported locale "${e}"; expected one of ${_.join(", ")}.`), e;
}
function S(e, t) {
	return (!Number.isInteger(e) || e < 0 || e > v) && y(`${t} digits must be an integer from 0 to ${v}.`), e;
}
function C(e) {
	if (!Number.isFinite(e)) throw new g("expression-number", "Value must be a finite number.");
	return e;
}
function w(e, t, n, r, i) {
	let a;
	try {
		a = new Intl.NumberFormat(e, {
			...t,
			...de
		});
	} catch {
		a = void 0;
	}
	return a === void 0 && y(i), b(a.format(n), r);
}
function fe(e, t = 2, n = "en-US", r = !0) {
	let i = x(n), a = S(t, "formatNumber");
	return typeof r != "boolean" && y("formatNumber grouping must be a boolean."), e === null ? "" : w(i, {
		useGrouping: r,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, C(e), "Formatted number", `Cannot format a number for locale "${i}".`);
}
function pe(e, t = 0, n = "en-US") {
	let r = x(n), i = S(t, "formatPercent");
	return e === null ? "" : w(r, {
		style: "percent",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, C(e), "Formatted percentage", `Cannot format a percentage for locale "${r}".`);
}
function me(e, t = 2, n = "en-US") {
	let r = x(n), i = S(t, "formatScientific");
	return e === null ? "" : w(r, {
		notation: "scientific",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, C(e), "Formatted number", `Cannot format a number for locale "${r}".`);
}
function he(e, t = "USD", n = 2, r = "en-US") {
	let i = x(r);
	ue.test(t) || y(`Currency "${t}" must be a three-letter uppercase code such as "USD".`);
	let a = S(n, "formatCurrency");
	return e === null ? "" : w(i, {
		style: "currency",
		currency: t,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, C(e), "Formatted currency", `Currency code "${t}" is not accepted by Intl.`);
}
// src/local/evaluation/expression/inference.ts
function T(e) {
	switch (e) {
		case "string": return "string";
		case "number": return "number";
		case "boolean": return "boolean";
		case "null": return "null";
		case "array": return "array";
		case "number-array": return "number array";
	}
}
function E(e) {
	return e === null ? "null" : Array.isArray(e) ? "array" : typeof e == "boolean" ? "boolean" : typeof e == "number" ? "number" : "string";
}
function D(e, t) {
	throw new o("expression-type", e, t);
}
function O(e, t, n, r) {
	e !== t && D(`${r}, got ${T(e)}.`, n);
}
function ge(e, t) {
	return e === t ? e : e === "null" ? t : t === "null" ? e : null;
}
function k(e, t) {
	switch (e.kind) {
		case "literal": return E(e.value);
		case "reference": {
			if (typeof t != "object" || !t || !Object.prototype.hasOwnProperty.call(t, e.name)) throw new o("expression-unknown-name", `Variable "${e.name}" is not declared.`, e.start);
			let n = t[e.name];
			if (typeof n != "string" || !ee.has(n)) throw new o("expression-value", `Variable "${e.name}" has an invalid type.`, e.start);
			return n;
		}
		case "unary": {
			let n = k(e.operand, t);
			return e.operator === "!" ? (O(n, "boolean", e.start, "Logical not requires a boolean"), "boolean") : (O(n, "number", e.start, `Unary ${e.operator} requires a number`), "number");
		}
		case "binary": {
			let n = k(e.left, t), r = k(e.right, t);
			switch (e.operator) {
				case "+": return n === "number" && r === "number" ? "number" : n === "string" && r === "string" ? "string" : D(`Operator "+" requires two numbers or two strings, got ${T(n)} and ${T(r)}.`, e.start);
				case "-":
				case "*":
				case "/":
				case "%": return O(n, "number", e.start, `Operator "${e.operator}" requires a number`), O(r, "number", e.start, `Operator "${e.operator}" requires a number`), "number";
				case "<":
				case "<=":
				case ">":
				case ">=": return n === "number" && r === "number" || n === "string" && r === "string" ? "boolean" : D(`Comparison operator "${e.operator}" requires two numbers or two strings, got ${T(n)} and ${T(r)}.`, e.start);
				case "==":
				case "!=": return n !== r && n !== "null" && r !== "null" ? D(`Equality comparison requires matching types, got ${T(n)} and ${T(r)}.`, e.start) : "boolean";
				case "&&":
				case "||": return O(n, "boolean", e.start, "Logical operators require booleans"), O(r, "boolean", e.start, "Logical operators require booleans"), "boolean";
			}
			break;
		}
		case "array": {
			if (e.elements.length === 0) return "number-array";
			let n = null;
			for (let r of e.elements) {
				let e = k(r, t);
				if (e !== "string" && e !== "number") return D(`Array literals require string or number elements, got ${T(e)}.`, r.start);
				if (n === null) n = e;
				else if (n !== e) return D(`Array literals require elements of one type, got ${T(n)} and ${T(e)}.`, r.start);
			}
			return n === "string" ? "array" : "number-array";
		}
		case "index": {
			let n = k(e.target, t);
			return O(k(e.index, t), "number", e.start, "Array index must be a number"), n === "array" ? "string" : n === "number-array" ? "number" : D(`Index access requires an array, got ${T(n)}.`, e.start);
		}
		case "conditional": {
			O(k(e.test, t), "boolean", e.start, "Conditional test must be a boolean");
			let n = k(e.consequent, t), r = k(e.alternate, t);
			if (n === "array" && e.alternate.kind === "array" && e.alternate.elements.length === 0 || r === "array" && e.consequent.kind === "array" && e.consequent.elements.length === 0) return "array";
			let i = ge(n, r);
			return i === null ? D(`Conditional branches must have matching types or one null, got ${T(n)} and ${T(r)}.`, e.start) : i;
		}
		case "call": {
			let n = e.args.map((e) => k(e, t));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": return O(n[0], "number", e.start, `Function ${e.name} requires a number`), "number";
				case "min":
				case "max":
				case "pow":
				case "clamp":
					for (let t of n) O(t, "number", e.start, `Function ${e.name} requires a number`);
					return "number";
				case "len": return n[0] !== "string" && n[0] !== "array" && n[0] !== "number-array" && D(`Function len requires a string or array, got ${T(n[0])}.`, e.start), "number";
				case "contains":
					if (n[0] === "number-array") return O(n[1], "number", e.start, "Function contains requires a numeric member"), "boolean";
					if (n[0] === "string" || n[0] === "array") return O(n[1], "string", e.start, "Function contains requires a string member"), "boolean";
					D(`Function contains requires a string or array, got ${T(n[0])}.`, e.start);
					break;
				case "sum":
				case "average":
				case "minOf":
				case "maxOf": return O(n[0], "number-array", e.start, `Function ${e.name} requires a numeric array`), "number";
				case "formatNumber":
				case "formatPercent":
				case "formatScientific": return n[0] !== "number" && n[0] !== "null" && D(`Function ${e.name} requires a number or null, got ${T(n[0])}.`, e.start), n[1] !== void 0 && O(n[1], "number", e.start, `Function ${e.name} requires numeric fraction digits`), n[2] !== void 0 && O(n[2], "string", e.start, `Function ${e.name} requires a string locale`), e.name === "formatNumber" && n[3] !== void 0 && O(n[3], "boolean", e.start, "Function formatNumber requires a boolean grouping flag"), "string";
				case "formatCurrency": return n[0] !== "number" && n[0] !== "null" && D(`Function formatCurrency requires a number or null, got ${T(n[0])}.`, e.start), n[1] !== void 0 && O(n[1], "string", e.start, "Function formatCurrency requires a string currency code"), n[2] !== void 0 && O(n[2], "number", e.start, "Function formatCurrency requires numeric fraction digits"), n[3] !== void 0 && O(n[3], "string", e.start, "Function formatCurrency requires a string locale"), "string";
				case "trim":
				case "lower":
				case "upper": return O(n[0], "string", e.start, `Function ${e.name} requires a string`), "string";
				case "startsWith":
				case "endsWith": return O(n[0], "string", e.start, `Function ${e.name} requires a string`), O(n[1], "string", e.start, `Function ${e.name} requires a string search value`), "boolean";
				case "replace": return O(n[0], "string", e.start, "Function replace requires a string"), O(n[1], "string", e.start, "Function replace requires a string search value"), O(n[2], "string", e.start, "Function replace requires a string replacement"), "string";
				case "slice": return O(n[0], "string", e.start, "Function slice requires a string"), O(n[1], "number", e.start, "Function slice requires a numeric start index"), n[2] !== void 0 && O(n[2], "number", e.start, "Function slice requires a numeric end index"), "string";
				case "dateCompare": return O(n[0], "string", e.start, "Function dateCompare requires a date string"), O(n[1], "string", e.start, "Function dateCompare requires a date string"), "number";
				case "dateDiff": return O(n[0], "string", e.start, "Function dateDiff requires a date string"), O(n[1], "string", e.start, "Function dateDiff requires a date string"), n[2] !== void 0 && O(n[2], "string", e.start, "Function dateDiff requires a string unit"), "number";
			}
			break;
		}
	}
	throw new o("expression-type", "Unsupported expression.", 0);
}
// src/local/evaluation/expression/collection-functions.ts
function A() {
	throw new g("expression-number", "The result is not a finite number.");
}
function j(e) {
	if (!Number.isFinite(e)) throw new g("expression-value", "Numeric array members must be finite numbers.");
	return e;
}
function M(e) {
	let t = 0;
	for (let n of e) t += j(n);
	return Number.isFinite(t) || A(), t;
}
function _e(e) {
	if (e.length === 0) return null;
	let t = M(e) / e.length;
	return Number.isFinite(t) || A(), t;
}
function N(e) {
	if (e.length === 0) return null;
	let t = j(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = j(e[n]);
		r < t && (t = r);
	}
	return t;
}
function P(e) {
	if (e.length === 0) return null;
	let t = j(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = j(e[n]);
		r > t && (t = r);
	}
	return t;
}
// src/local/evaluation/expression/data-functions.ts
function F(e) {
	throw new g("expression-domain", e);
}
function I(e) {
	return b(e.trim(), "trim result");
}
function ve(e) {
	return b(e.toLowerCase(), "lower result");
}
function ye(e) {
	return b(e.toUpperCase(), "upper result");
}
function be(e, t) {
	return e.startsWith(t);
}
function xe(e, t) {
	return e.endsWith(t);
}
function Se(e, n, r) {
	n.length === 0 && F("replace search text must not be empty.");
	let i = r.length - n.length;
	if (i > 0) {
		let r = 0, a = 0;
		for (;;) {
			let t = e.indexOf(n, a);
			if (t < 0) break;
			r += 1, a = t + n.length;
		}
		if (e.length + r * i > 1e5) throw new g("expression-budget", `replace result would exceed the ${t}-character limit.`);
	}
	let a = "", o = 0;
	for (;;) {
		let t = e.indexOf(n, o);
		if (t < 0) break;
		a += e.slice(o, t), a += r, o = t + n.length;
	}
	return a += e.slice(o), b(a, "replace result");
}
function L(e, t) {
	return e < 0 ? Math.max(t + e, 0) : Math.min(e, t);
}
function Ce(e, t, n) {
	Number.isInteger(t) || F("slice start must be an integer."), n !== void 0 && !Number.isInteger(n) && F("slice end must be an integer.");
	let r = Array.from(e), i = r.length, a = L(t, i), o = n === void 0 ? i : L(n, i);
	return o <= a ? "" : b(r.slice(a, o).join(""), "slice result");
}
var we = /* @__PURE__ */ new Map([
	["days", 864e5],
	["hours", 36e5],
	["minutes", 6e4],
	["seconds", 1e3],
	["milliseconds", 1]
]), Te = "days, hours, minutes, seconds or milliseconds";
function R(e) {
	let t = Oe(e);
	if (t === null) throw new g("expression-domain", `Date "${e}" must be a valid YYYY-MM-DD calendar date in years 0001-9999.`);
	return t;
}
function Ee(e, t) {
	let n = R(e), r = R(t);
	return n === r ? 0 : n < r ? -1 : 1;
}
function De(e, t, n = "days") {
	let r = we.get(n);
	return r === void 0 && F(`dateDiff unit must be ${Te}.`), (R(e) - R(t)) / r;
}
function Oe(e) {
	let t = /^(\d{4})-(\d{2})-(\d{2})$/.exec(e);
	if (!t) return null;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	if (n < 1 || r < 1 || r > 12 || i < 1 || i > 31) return null;
	let a = /* @__PURE__ */ new Date(0);
	return a.setUTCFullYear(n, r - 1, i), a.getUTCFullYear() === n && a.getUTCMonth() === r - 1 && a.getUTCDate() === i ? a.getTime() : null;
}
// src/local/evaluation/expression/evaluation.ts
function z(e, t, n = "expression-eval") {
	throw new o(n, e, t);
}
function ke(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) throw new o("expression-value", "Expression environment must be an object.", 0);
}
function Ae(e, t, n) {
	if (e === null) return null;
	if (typeof e == "string") {
		let r = m(e);
		if (r) throw new o("expression-budget", `Variable "${t}": ${r}`, n);
		return e;
	}
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new o("expression-value", `Variable "${t}" must be a finite number.`, n);
		return e;
	}
	if (Array.isArray(e)) {
		let r = f(e);
		if (r) throw new o(r.code, `Variable "${t}": ${r.message}`, n);
		return e;
	}
	throw new o("expression-value", `Variable "${t}" has an invalid value type.`, n);
}
function je(e, t, n) {
	return ke(e), Object.prototype.hasOwnProperty.call(e, t) || z(`Variable "${t}" is not declared.`, n, "expression-unknown-name"), Ae(e[t], t, n);
}
function B(e, t, n = "Expected a number") {
	return typeof e == "number" && Number.isFinite(e) || z(`${n}.`, t, "expression-type"), e;
}
function V(e, t, n = "Expected a boolean") {
	return typeof e != "boolean" && z(`${n}.`, t, "expression-type"), e;
}
function H(e, t, n = "Expected a string") {
	return typeof e != "string" && z(`${n}.`, t, "expression-type"), e;
}
function U(e, t, n) {
	Array.isArray(e) || z(`${n}.`, t, "expression-type");
	for (let r of e) typeof r == "number" && Number.isFinite(r) || z(`${n}.`, t, "expression-type");
	return e;
}
function Me(e, t) {
	let n = f(e);
	return n && z(n.message, t, n.code), e;
}
function W(e, t) {
	try {
		return t();
	} catch (t) {
		throw t instanceof g ? new o(t.code, t.message, e) : t;
	}
}
function G(e, t) {
	return Number.isNaN(e) && z("The result is undefined.", t, "expression-domain"), Number.isFinite(e) || z("The result is not a finite number.", t, "expression-number"), e;
}
function Ne(e, t) {
	let n = Array.from(e), r = Array.from(t), i = Math.min(n.length, r.length);
	for (let e = 0; e < i; e += 1) {
		let t = n[e].codePointAt(0), i = r[e].codePointAt(0);
		if (t !== i) return t < i ? -1 : 1;
	}
	return n.length === r.length ? 0 : n.length < r.length ? -1 : 1;
}
function Pe(e, t) {
	if (e === t) return !0;
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return !1;
		for (let n = 0; n < e.length; n += 1) if (e[n] !== t[n]) return !1;
		return !0;
	}
	return !1;
}
function Fe(e, t) {
	return K(e, t, { steps: 0 }, 1);
}
function K(e, t, n, i) {
	switch (n.steps += 1, n.steps > 1e4 && z("Expression evaluation exceeded the step limit.", e.start, "expression-budget"), i > 250 && z("Expression evaluation is nested too deeply.", e.start, "expression-budget"), e.kind) {
		case "literal": return e.value;
		case "reference": return je(t, e.name, e.start);
		case "unary": {
			let r = K(e.operand, t, n, i + 1);
			if (e.operator === "!") return !V(r, e.start, "Logical not requires a boolean");
			let a = B(r, e.start, `Unary ${e.operator} requires a number`);
			return G(e.operator === "-" ? -a : a, e.start);
		}
		case "binary": {
			if (e.operator === "&&" || e.operator === "||") {
				let r = V(K(e.left, t, n, i + 1), e.start, "Logical operators require booleans");
				return e.operator === "&&" && !r ? !1 : e.operator === "||" && r ? !0 : V(K(e.right, t, n, i + 1), e.start, "Logical operators require booleans");
			}
			let r = K(e.left, t, n, i + 1), a = K(e.right, t, n, i + 1);
			switch (e.operator) {
				case "+":
					if (typeof r == "number" && typeof a == "number") return G(r + a, e.start);
					if (typeof r == "string" && typeof a == "string") {
						let t = r + a;
						return t.length > d && z("String result exceeds the length limit.", e.start, "expression-budget"), t;
					}
					z("Operator \"+\" requires two numbers or two strings.", e.start, "expression-type");
				case "-":
				case "*":
				case "/":
				case "%": {
					let t = B(r, e.start, `Operator "${e.operator}" requires a number`), n = B(a, e.start, `Operator "${e.operator}" requires a number`);
					return (e.operator === "/" || e.operator === "%") && n === 0 && z("Division by zero.", e.start, "expression-divide-by-zero"), G(e.operator === "-" ? t - n : e.operator === "*" ? t * n : e.operator === "/" ? t / n : t % n, e.start);
				}
				case "==":
				case "!=": {
					let t = E(r), n = E(a);
					t !== n && t !== "null" && n !== "null" && z("Equality comparison requires matching types.", e.start, "expression-type");
					let i = Pe(r, a);
					return e.operator === "==" ? i : !i;
				}
				case "<":
				case "<=":
				case ">":
				case ">=": {
					let t;
					return typeof r == "number" && typeof a == "number" ? t = r === a ? 0 : r < a ? -1 : 1 : typeof r == "string" && typeof a == "string" ? t = Ne(r, a) : z(`Comparison operator "${e.operator}" requires two numbers or two strings.`, e.start, "expression-type"), e.operator === "<" ? t < 0 : e.operator === "<=" ? t <= 0 : e.operator === ">" ? t > 0 : t >= 0;
				}
			}
			break;
		}
		case "conditional": return K(V(K(e.test, t, n, i + 1), e.start, "Conditional test must be a boolean") ? e.consequent : e.alternate, t, n, i + 1);
		case "array": {
			let r = [];
			for (let a of e.elements) r.push(K(a, t, n, i + 1));
			return Me(r, e.start);
		}
		case "index": {
			let r = K(e.target, t, n, i + 1), a = B(K(e.index, t, n, i + 1), e.start, "Array index must be a number");
			return Number.isSafeInteger(a) || z("Array index must be a finite integer.", e.start, "expression-index"), Array.isArray(r) || z("Index access requires an array.", e.start, "expression-type"), a < 0 || a >= r.length ? null : r[a];
		}
		case "call": {
			let a = e.args.map((e) => K(e, t, n, i + 1));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": {
					let t = B(a[0], e.start, `Function ${e.name} requires a number`);
					e.name === "sqrt" && t < 0 && z("sqrt requires a non-negative argument.", e.start, "expression-domain"), e.name === "log" && t <= 0 && z("log requires a positive argument.", e.start, "expression-domain"), (e.name === "asin" || e.name === "acos") && (t < -1 || t > 1) && z(`${e.name} requires an argument between -1 and 1.`, e.start, "expression-domain");
					let n;
					switch (e.name) {
						case "abs":
							n = Math.abs(t);
							break;
						case "sqrt":
							n = Math.sqrt(t);
							break;
						case "floor":
							n = Math.floor(t);
							break;
						case "ceil":
							n = Math.ceil(t);
							break;
						case "round":
							n = Math.round(t);
							break;
						case "sin":
							n = Math.sin(t);
							break;
						case "cos":
							n = Math.cos(t);
							break;
						case "tan":
							n = Math.tan(t);
							break;
						case "asin":
							n = Math.asin(t);
							break;
						case "acos":
							n = Math.acos(t);
							break;
						case "atan":
							n = Math.atan(t);
							break;
						case "exp":
							n = Math.exp(t);
							break;
						default: n = Math.log(t);
					}
					return G(n, e.start);
				}
				case "min":
				case "max": {
					let t = B(a[0], e.start, `Function ${e.name} requires a number`);
					for (let n = 1; n < a.length; n += 1) {
						let r = B(a[n], e.start, `Function ${e.name} requires a number`);
						t = e.name === "min" ? Math.min(t, r) : Math.max(t, r);
					}
					return G(t, e.start);
				}
				case "pow": return G(B(a[0], e.start, "Function pow requires a number") ** +B(a[1], e.start, "Function pow requires a number"), e.start);
				case "clamp": {
					let t = B(a[0], e.start, "Function clamp requires a number"), n = B(a[1], e.start, "Function clamp requires a number"), r = B(a[2], e.start, "Function clamp requires a number");
					return n > r && z("clamp lower bound cannot exceed upper bound.", e.start, "expression-domain"), G(Math.min(r, Math.max(n, t)), e.start);
				}
				case "len": {
					let t = a[0];
					if (typeof t == "string") return r(t);
					if (Array.isArray(t)) return t.length;
					z("Function len requires a string or array.", e.start, "expression-type");
				}
				case "contains": {
					let t = a[0], n = a[1];
					if (typeof t == "string") return t.includes(H(n, e.start, "Function contains requires a string member"));
					if (Array.isArray(t)) {
						if (typeof n == "string") {
							for (let n of t) typeof n != "string" && z("Function contains requires a string member for a string array.", e.start, "expression-type");
							return t.includes(n);
						}
						if (typeof n == "number" && Number.isFinite(n)) {
							for (let n of t) typeof n != "number" && z("Function contains requires a numeric member for a numeric array.", e.start, "expression-type");
							return t.includes(n);
						}
						z("Function contains requires a string or numeric member.", e.start, "expression-type");
					}
					z("Function contains requires a string or array.", e.start, "expression-type");
				}
				case "sum": {
					let t = U(a[0], e.start, "Function sum requires a numeric array");
					return W(e.start, () => M(t));
				}
				case "average": {
					let t = U(a[0], e.start, "Function average requires a numeric array");
					return W(e.start, () => _e(t));
				}
				case "minOf": {
					let t = U(a[0], e.start, "Function minOf requires a numeric array");
					return W(e.start, () => N(t));
				}
				case "maxOf": {
					let t = U(a[0], e.start, "Function maxOf requires a numeric array");
					return W(e.start, () => P(t));
				}
				case "formatNumber": {
					let t = a[0] === null ? null : B(a[0], e.start, "Function formatNumber requires a number or null"), n = a[1] === void 0 ? 2 : B(a[1], e.start, "Function formatNumber requires numeric fraction digits"), r = a[2] === void 0 ? "en-US" : H(a[2], e.start, "Function formatNumber requires a string locale"), i = a[3] === void 0 || V(a[3], e.start, "Function formatNumber requires a boolean grouping flag");
					return W(e.start, () => fe(t, n, r, i));
				}
				case "formatPercent": {
					let t = a[0] === null ? null : B(a[0], e.start, "Function formatPercent requires a number or null"), n = a[1] === void 0 ? 0 : B(a[1], e.start, "Function formatPercent requires numeric fraction digits"), r = a[2] === void 0 ? "en-US" : H(a[2], e.start, "Function formatPercent requires a string locale");
					return W(e.start, () => pe(t, n, r));
				}
				case "formatScientific": {
					let t = a[0] === null ? null : B(a[0], e.start, "Function formatScientific requires a number or null"), n = a[1] === void 0 ? 2 : B(a[1], e.start, "Function formatScientific requires numeric fraction digits"), r = a[2] === void 0 ? "en-US" : H(a[2], e.start, "Function formatScientific requires a string locale");
					return W(e.start, () => me(t, n, r));
				}
				case "formatCurrency": {
					let t = a[0] === null ? null : B(a[0], e.start, "Function formatCurrency requires a number or null"), n = a[1] === void 0 ? "USD" : H(a[1], e.start, "Function formatCurrency requires a string currency code"), r = a[2] === void 0 ? 2 : B(a[2], e.start, "Function formatCurrency requires numeric fraction digits"), i = a[3] === void 0 ? "en-US" : H(a[3], e.start, "Function formatCurrency requires a string locale");
					return W(e.start, () => he(t, n, r, i));
				}
				case "trim": return W(e.start, () => I(H(a[0], e.start, "Function trim requires a string")));
				case "lower": return W(e.start, () => ve(H(a[0], e.start, "Function lower requires a string")));
				case "upper": return W(e.start, () => ye(H(a[0], e.start, "Function upper requires a string")));
				case "startsWith": return W(e.start, () => be(H(a[0], e.start, "Function startsWith requires a string"), H(a[1], e.start, "Function startsWith requires a string search value")));
				case "endsWith": return W(e.start, () => xe(H(a[0], e.start, "Function endsWith requires a string"), H(a[1], e.start, "Function endsWith requires a string search value")));
				case "replace": {
					let t = H(a[0], e.start, "Function replace requires a string"), n = H(a[1], e.start, "Function replace requires a string search value"), r = H(a[2], e.start, "Function replace requires a string replacement");
					return W(e.start, () => Se(t, n, r));
				}
				case "slice": {
					let t = H(a[0], e.start, "Function slice requires a string"), n = B(a[1], e.start, "Function slice requires a numeric start index"), r = a[2] === void 0 ? void 0 : B(a[2], e.start, "Function slice requires a numeric end index");
					return W(e.start, () => Ce(t, n, r));
				}
				case "dateCompare": {
					let t = H(a[0], e.start, "Function dateCompare requires a date string"), n = H(a[1], e.start, "Function dateCompare requires a date string");
					return W(e.start, () => Ee(t, n));
				}
				case "dateDiff": {
					let t = H(a[0], e.start, "Function dateDiff requires a date string"), n = H(a[1], e.start, "Function dateDiff requires a date string"), r = a[2] === void 0 ? "days" : H(a[2], e.start, "Function dateDiff requires a string unit");
					return W(e.start, () => De(t, n, r));
				}
			}
			break;
		}
	}
	throw new o("expression-eval", "Unsupported expression.", 0);
}
// src/local/evaluation/expression/compile.ts
var q = t, Ie = 500, J = /* @__PURE__ */ new Map(), Y = /* @__PURE__ */ new WeakMap();
function Le(e, t) {
	return Y.get(e)?.get(t);
}
function X(e) {
	if (typeof e != "string") throw new o("expression-syntax", "Expression must be a string.", 0);
	if (e.length > 4e3) throw new o("expression-budget", `Expression exceeds the ${ne}-character limit.`, 0);
	let t = J.get(e);
	if (t) return t;
	let n = new ce(e), r = n.parse(), i = [...n.dependencies], a = Object.freeze({
		source: e,
		dependencies: i,
		evaluate(e) {
			return Fe(r, e);
		},
		inferType(e) {
			return k(r, e);
		}
	});
	if (J.size >= Ie) {
		let e = J.keys().next().value;
		e !== void 0 && J.delete(e);
	}
	return Y.set(a, n.dependencyOffsets), J.set(e, a), a;
}
function Z(e) {
	if (e.length > q) throw new o("expression-budget", "Interpolation template exceeds the length limit.", 0);
	let t = [], n = 0;
	for (;;) {
		let r = e.indexOf("{{", n);
		if (r < 0) {
			n < e.length && t.push({
				kind: "text",
				value: e.slice(n)
			});
			break;
		}
		r > n && t.push({
			kind: "text",
			value: e.slice(n, r)
		});
		let i = r + 2, a = "", s = !1;
		for (; i < e.length;) {
			let t = e[i];
			if (a !== "") {
				if (t === "\\") {
					i += 2;
					continue;
				}
				t === a && (a = ""), i += 1;
			} else if (t === "\"" || t === "'") a = t, i += 1;
			else {
				if (t === "{" && e[i + 1] === "{") throw new o("expression-interpolation", "Interpolations cannot be nested.", i);
				if (t === "}" && e[i + 1] === "}") {
					s = !0;
					break;
				}
				i += 1;
			}
		}
		if (!s) throw new o("expression-interpolation", "Interpolation is missing }}.", r);
		let c = e.slice(r + 2, i);
		if (c.trim() === "") throw new o("expression-empty", "Interpolation expression is empty.", r + 2);
		t.push({
			kind: "expression",
			source: c,
			start: r + 2
		}), n = i + 2;
	}
	return t;
}
function Q(e) {
	try {
		return X(e.source);
	} catch (t) {
		throw t instanceof o ? new o(t.code, t.message, e.start + t.offset) : t;
	}
}
function $(e, t, n) {
	try {
		return e.evaluate(t);
	} catch (e) {
		throw e instanceof o ? new o(e.code, e.message, n + e.offset) : e;
	}
}
function Re(e, t) {
	if (e === null) return "";
	if (typeof e == "string") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new o("expression-value", "Cannot display a non-finite number.", t);
		return String(e);
	}
	if (typeof e == "boolean") return e ? "true" : "false";
	throw Array.isArray(e) ? new o("expression-type", "Cannot insert an array as text; convert it with a function such as len first.", t) : new o("expression-type", "Cannot display this value as text.", t);
}
function ze(e, t) {
	let n = [], r = 0;
	for (let i of e) {
		let e;
		if (e = i.kind === "text" ? i.value : Re($(Q(i), t, i.start), i.start), r += e.length, r > d) throw new o("expression-budget", "Interpolation result exceeds the length limit.", 0);
		n.push(e);
	}
	return n.join("");
}
function Be(e, t) {
	if (typeof e != "string") throw new o("expression-interpolation", "Interpolation template must be a string.", 0);
	if (e.length > q) throw new o("expression-budget", `Interpolation template exceeds the ${q}-character limit.`, 0);
	return e.includes("{{") ? ze(Z(e), t) : e;
}
function Ve(e) {
	if (typeof e != "string") throw new o("expression-interpolation", "Interpolation template must be a string.", 0);
	let t = /* @__PURE__ */ new Set();
	for (let n of Z(e)) if (n.kind === "expression") for (let e of Q(n).dependencies) t.add(e);
	return [...t];
}
export { o as a, p as c, Ve as i, Le as n, te as o, Be as r, m as s, X as t };
