import { _ as e, a as t, c as n, f as r, h as i, o as a, p as o } from "./controls-B0vYKFjX.js";
import { a as s, d as c, f as l, i as u, l as d, m as f, n as p, p as m, r as h, u as g, y as _ } from "./layout-CQT5rj_T.js";
import v from "./reactive-md-minimal-preset.js";
import { t as y } from "./mount-preset-HeqKAFtX.js";
// src/components/minimal-preset.ts
var b = y(v, {
	input: a,
	textarea: o,
	number: n,
	slider: e,
	toggle: i,
	date: t,
	select: r,
	option: l,
	text: _,
	if: g,
	alert: p,
	badge: u,
	panel: m,
	card: s,
	grid: d,
	section: f,
	jump: c,
	anchor: h
});
export { b as default, b as minimalReactPresetPackage };
