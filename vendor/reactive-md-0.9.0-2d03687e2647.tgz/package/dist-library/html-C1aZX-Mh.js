import { E as e, O as t, P as n, T as r, k as i } from "./config-validation-F47AcE6o.js";
import { M as a, N as o, P as s } from "./validation-BEBA_HvS.js";
import { a as c, c as l, l as u, o as d } from "./parser-standard-Yuf3A_VI.js";
// src/local/html/html.ts
var f = "http://www.w3.org/1999/xhtml", p = /* @__PURE__ */ new Set([
	"b",
	"strong",
	"i",
	"em",
	"s",
	"del",
	"u",
	"mark",
	"sup",
	"sub",
	"br",
	"hr",
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"div",
	"span",
	"details",
	"summary",
	"blockquote",
	"code",
	"pre",
	"ul",
	"ol",
	"li",
	"a",
	"img",
	...o
]), m = /* @__PURE__ */ new Set([
	"html",
	"head",
	"body"
]), h = /* @__PURE__ */ new Set([
	"frameset",
	"frame",
	"noframes",
	"applet"
]), ee = /* @__PURE__ */ new Set([
	"animate",
	"animatemotion",
	"animatetransform",
	"set",
	"discard"
]), te = /* @__PURE__ */ new Set(/* @__PURE__ */ "alignment-baseline.baseline-shift.clip.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-rendering.cursor.direction.display.dominant-baseline.fill.fill-opacity.fill-rule.filter.flood-color.flood-opacity.font.font-family.font-size.font-size-adjust.font-stretch.font-style.font-variant.font-weight.glyph-orientation-horizontal.glyph-orientation-vertical.image-rendering.kerning.letter-spacing.lighting-color.marker.marker-end.marker-mid.marker-start.mask.opacity.overflow.paint-order.pointer-events.shape-rendering.stop-color.stop-opacity.stroke.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke-width.text-anchor.text-decoration.text-rendering.transform-origin.unicode-bidi.vector-effect.visibility.word-spacing.writing-mode".split(".")), g = /* @__PURE__ */ new Set([
	"id",
	"class",
	"title",
	"lang",
	"dir"
]), _ = /* @__PURE__ */ new Set([
	"align",
	"bgcolor",
	"background",
	"face",
	"text",
	"link",
	"alink",
	"vlink",
	"border",
	"cellpadding",
	"cellspacing",
	"frame",
	"rules",
	"hspace",
	"vspace"
]), v = {
	a: e,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...a,
	script: /* @__PURE__ */ new Set([
		"type",
		"src",
		"async",
		"defer",
		"nomodule",
		"crossorigin",
		"integrity",
		"referrerpolicy"
	]),
	style: /* @__PURE__ */ new Set(["type", "media"]),
	link: /* @__PURE__ */ new Set([
		"rel",
		"href",
		"type",
		"media",
		"crossorigin",
		"integrity",
		"referrerpolicy",
		"disabled"
	])
}, y = {
	href: "link",
	action: "form",
	formaction: "form",
	poster: "image",
	background: "image",
	data: "frame",
	src: "source",
	cite: "link",
	longdesc: "link"
}, ne = 4, re = 32, b = 64, x = class extends Error {
	start;
	end;
	limit;
	constructor(e, t, n) {
		super(`Syntax nodes exceed the limit of ${n}.`), this.start = e, this.end = t, this.limit = n, this.name = "HtmlBudgetError";
	}
};
function S(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function C(e, t, n) {
	let r = e.source.length, i = Math.max(0, Math.min(r, t)), a = Math.max(i, Math.min(r, Math.max(i, n))), o = 0, s = e.lines.starts.length - 1;
	for (; o < s;) {
		let t = Math.ceil((o + s) / 2);
		e.lines.starts[t] <= i ? o = t : s = t - 1;
	}
	return {
		start: i,
		end: a,
		line: o + 1,
		column: i - e.lines.starts[o] + 1
	};
}
function w(e, t, r, i, a, o) {
	if (e.diagnostics.length >= 100) return;
	let s = C(e, i, a), c = n(o?.key ?? t, o?.params);
	e.diagnostics.push({
		code: t,
		message: r,
		severity: "warning",
		range: {
			start: s.start,
			end: s.end
		},
		line: s.line,
		column: s.column,
		messageKey: c.key,
		...c.params ? { params: c.params } : {}
	});
}
function T(e, t) {
	let n = e.sourceCodeLocation, r = n && Number.isInteger(n.startOffset) ? n.startOffset : 0, i = n && Number.isInteger(n.endOffset) ? n.endOffset : r;
	return {
		start: Math.max(0, Math.min(t.source.length, r)),
		end: Math.max(0, Math.min(t.source.length, i))
	};
}
function ie(e, t, n) {
	let r = e.sourceCodeLocation?.attrs, i = r && (r[t.name] ?? (t.prefix ? r[`${t.prefix}:${t.name}`] : void 0));
	return i && Number.isInteger(i.startOffset) && Number.isInteger(i.endOffset) ? {
		start: i.startOffset,
		end: i.endOffset
	} : T(e, n);
}
function E(e, t, n) {
	if (e.budget.nodes += 1, e.budget.nodes > e.maxNodes) throw new x(t, n, e.maxNodes);
}
function D(e, t) {
	let n = T(e, t);
	return t.source.slice(n.start, n.end).replace(/\u0000/g, "�");
}
function O(e) {
	return u.createTextNode(e.replace(/\u0000/g, "�"));
}
function ae(e) {
	return e.replace(/[\u0000- \u007f-\u009f]+/g, "");
}
function oe(e) {
	let t = /^([a-z][a-z0-9+.-]*):/i.exec(ae(e));
	return t ? t[1].toLowerCase() : null;
}
function se(e, t) {
	let n = e.trim();
	if (n === "") return !0;
	let r = oe(n);
	return r === null ? !0 : r === "javascript" || r === "vbscript" ? !1 : r === "data" ? t === "image" && /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/i.test(n.replace(/\s+/g, "")) : r === "http" || r === "https" || t === "link" && (r === "mailto" || r === "tel");
}
function k(e) {
	return Object.hasOwn(y, e) || e === "xlink:href";
}
function A(e, t) {
	return (e === "href" || e === "xlink:href") && t === "image" ? "image" : e === "href" && t === "base" ? "source" : e === "xlink:href" ? "link" : e === "src" ? t === "img" || t === "image" ? "image" : t === "iframe" || t === "frame" || t === "embed" ? "frame" : t === "audio" || t === "video" || t === "source" || t === "track" ? "media" : "source" : y[e] ?? "source";
}
function j(e, t) {
	return g.has(t) || t.startsWith("aria-") || t.startsWith("data-") ? !0 : v[e]?.has(t) ?? !1;
}
function M(e) {
	return /^on[a-z]/i.test(e);
}
function N(e, t) {
	return te.has(e) ? !0 : t && _.has(e);
}
function P(e) {
	return [...e.enableJavaScript ? ["allow-scripts"] : [], ...e.enableExtendedHtml ? ["allow-forms"] : []].join(" ");
}
function ce(e, t) {
	return e.split(/\s+/).filter(Boolean).filter((e) => {
		let n = e.toLowerCase();
		return n === "allow-same-origin" || n === "allow-top-navigation" || n === "allow-top-navigation-by-user-activation" || n === "allow-parent-navigation" || n === "allow-popups" || n === "allow-popups-to-escape-sandbox" || n === "allow-modals" || n === "allow-downloads" || n === "allow-orientation-lock" || n === "allow-pointer-lock" || n === "allow-presentation" ? !1 : n === "allow-forms" ? t.enableExtendedHtml : n === "allow-scripts" && t.enableJavaScript;
	}).join(" ");
}
function F(e, t) {
	for (let n of e.childNodes) if (u.isElementNode(n) && n.tagName.toLowerCase() === t) return n;
	return null;
}
function I(e) {
	let t = "";
	for (let n of e.childNodes) t += l(n, { scriptingEnabled: !1 });
	return t;
}
function L(e) {
	return e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function R(e, t, n = !1) {
	let r = e.enableExtendedHtml, i = t === void 0 ? r ? [
		"about:",
		"data:",
		"blob:"
	] : [] : ["about:", ...B(t)];
	return [
		"default-src 'none'",
		n ? "base-uri 'none'" : r ? "base-uri 'self' http: https:" : "base-uri 'none'",
		n ? "form-action 'none'" : r ? "form-action http: https:" : "form-action 'none'",
		"object-src 'none'",
		"connect-src 'none'",
		"media-src 'none'",
		"font-src data:",
		"img-src data:",
		e.enableCss ? "style-src 'unsafe-inline'" : "style-src 'none'",
		e.enableJavaScript ? "script-src 'unsafe-inline'" : "script-src 'none'",
		i.length === 0 ? "frame-src 'none'" : `frame-src ${i.join(" ")}`
	].join("; ");
}
function z(e) {
	if (typeof e != "string") return null;
	let t = /^https:\/\/([a-z0-9](?:[a-z0-9-]*[a-z0-9])?(?:\.[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)*)(?::([0-9]{1,5}))?\/?$/i.exec(e.trim());
	if (!t) return null;
	let n = t[2] ? Number(t[2]) : 443;
	if (!Number.isInteger(n) || n < 1 || n > 65535) return null;
	let r = t[1].toLowerCase();
	return n === 443 ? `https://${r}` : `https://${r}:${n}`;
}
function B(e) {
	let t = [];
	if (!Array.isArray(e)) return t;
	for (let n of e.slice(0, re)) {
		let e = z(n);
		e && !t.includes(e) && t.push(e);
	}
	return t;
}
function V(e) {
	return new Set(B(e ?? []));
}
function H(e, t) {
	let n = e.trim();
	if (/^about:blank$/i.test(n)) return !0;
	if (n === "") return !1;
	let r;
	try {
		r = new URL(n);
	} catch {
		return !1;
	}
	if (r.protocol !== "https:" || r.username !== "" || r.password !== "") return !1;
	let i = z(r.origin);
	return i !== null && t.has(i);
}
var U = 65536;
function W(e) {
	let t = e.trim();
	if (!/^data:/i.test(t)) return;
	if (t.length > U) return null;
	let n = t.indexOf(",");
	if (n < 0) return null;
	let r = t.slice(5, n).toLowerCase(), i = t.slice(n + 1), a = r.endsWith(";base64"), o = (a ? r.slice(0, -7) : r).split(";")[0].trim();
	if (o !== "text/html" && o !== "application/xhtml+xml") return null;
	let s;
	try {
		if (a) {
			let e = atob(i.replace(/\s+/g, "")), t = new Uint8Array(e.length);
			for (let n = 0; n < e.length; n += 1) t[n] = e.charCodeAt(n);
			s = new TextDecoder().decode(t);
		} else s = decodeURIComponent(i);
	} catch {
		return null;
	}
	return s.length > U ? null : s;
}
function G(e, t) {
	let n = F(t, "html"), r = n ? F(n, "head") : null, i = n ? F(n, "body") : null, a = r ? I(r) : "", o = I(i || n || t);
	e.bodyFallbacks.length > 0 && (o = e.bodyFallbacks.map((e) => l(O(e), { scriptingEnabled: !1 })).join("") + o);
	let s = L(R(e.policy, e.frameOrigins ? [...e.frameOrigins] : void 0, e.fragment)), c = (e) => (e?.attrs ?? []).map((e) => ` ${e.prefix ? `${e.prefix}:` : ""}${e.name}="${L(e.value)}"`).join("");
	return `<!doctype html><html${c(n)}><head${c(r)}><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${s}">${a}</head><body${c(i)}>${o}</body></html>`;
}
function K(e) {
	let t = e.source.replace(/\u0000/g, "�").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${L(R(e.policy, e.frameOrigins ? [...e.frameOrigins] : void 0, e.fragment))}"></head><body><pre data-local-html-fallback="document">\n${t}</pre></body></html>`;
}
function q(e, t, n) {
	if (t.depth >= ne) return "";
	let r = t.diagnostics.length, i = () => (Z(t, r), w(t, "local.html.fallback", "Native HTML was safely converted to inert source text.", n.start, n.end), K({
		...t,
		source: e
	})), a;
	try {
		a = c(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch {
		return i();
	}
	let o = {
		...t,
		source: e,
		lines: { starts: S(e) },
		depth: t.depth + 1,
		bodyFallbacks: []
	};
	try {
		let e = F(a, "html");
		if (e) {
			let n = t.diagnostics.length;
			if (!J(e, "html", !0, o)) return Z(o, n), K(o);
			Q(e, o, !1);
		}
		return G(o, a);
	} catch (e) {
		if (e instanceof x) throw e;
		return i();
	}
}
function J(e, n, a, c) {
	e.sourceCodeLocation;
	let l = [], u = !1, d = !0;
	for (let i of e.attrs) {
		let f = i.name.toLowerCase(), p = i.prefix ? `${i.prefix}:${i.name}` : i.name, m = ie(e, i, c);
		if (a && o.has(n) && !s(f, i.value)) {
			d = !1, w(c, "local.html.table", `Invalid value for ${f} on native HTML <${n}>.`, m.start, m.end, {
				key: "html.table.value",
				params: {
					name: f,
					tag: n
				}
			});
			continue;
		}
		if (a && f === "align" && r.has(n)) {
			let e = t(i.value);
			e ? l.push({
				...i,
				value: e
			}) : (d = !1, w(c, "local.html.attribute", "HTML attribute align requires left, center, right or justify.", m.start, m.end, {
				key: "local.html.attribute",
				params: {
					name: p,
					tag: n
				}
			}));
			continue;
		}
		if (M(f)) {
			if (!c.policy.enableJavaScript) {
				w(c, "local.html.capability", `Author event handler attribute ${p} was disabled by the compile options.`, m.start, m.end, {
					key: "local.html.capability",
					params: { feature: "event handlers" }
				});
				continue;
			}
			l.push(i);
			continue;
		}
		if (f === "style" || N(f, a)) {
			if (!c.policy.enableCss) {
				w(c, "local.html.capability", `Author style attribute ${p} was disabled by the compile options.`, m.start, m.end, {
					key: "local.html.capability",
					params: { feature: "CSS" }
				});
				continue;
			}
			l.push(i);
			continue;
		}
		if (f === "srcset" || f === "imagesrcset") {
			w(c, "local.html.unsafe-url", `Unsafe URL in attribute ${p} was removed.`, m.start, m.end, {
				key: "local.html.unsafe-url",
				params: { name: p }
			});
			continue;
		}
		if (f === "srcdoc" && n === "iframe") {
			if (l.some((e) => e.name === "srcdoc")) continue;
			let e = q(i.value, c, m);
			if (e === "") continue;
			i.value = e, l.push(i);
			continue;
		}
		if (f === "sandbox" && n === "iframe") {
			i.value = ce(i.value, c.policy), u = !0, l.push(i);
			continue;
		}
		let h = c.frameOrigins;
		if (h !== void 0 && n === "iframe") {
			if (f === "allow" || f === "allowfullscreen" || f === "allowpaymentrequest") {
				w(c, "local.html.capability", `Author frame permission ${p} was disabled.`, m.start, m.end, {
					key: "local.html.capability",
					params: { feature: "frame permission" }
				});
				continue;
			}
			if (f === "src") {
				let e = W(i.value);
				if (e === null) {
					w(c, "local.html.unsafe-url", `Unsafe frame source in attribute ${p} was removed.`, m.start, m.end, {
						key: "local.html.unsafe-url",
						params: { name: p }
					});
					continue;
				}
				if (e !== void 0) {
					if (l.some((e) => e.name === "srcdoc")) continue;
					let t = q(e, c, m);
					if (t === "") continue;
					l.push({
						name: "srcdoc",
						value: t
					});
					continue;
				}
				if (!H(i.value, h)) {
					w(c, "local.html.unsafe-url", `Remote frame source ${p} is not an allowed origin.`, m.start, m.end, {
						key: "local.html.unsafe-url",
						params: { name: p }
					});
					continue;
				}
				l.push(i);
				continue;
			}
		}
		k(f) && !se(i.value, A(f, n)) ? w(c, "local.html.unsafe-url", `Unsafe URL in attribute ${p} was removed.`, m.start, m.end, {
			key: "local.html.unsafe-url",
			params: { name: p }
		}) : f === "target" && /^_(?:top|parent)$/i.test(i.value.trim()) ? w(c, "local.html.capability", `Navigation target ${i.value} was disabled.`, m.start, m.end, {
			key: "local.html.capability",
			params: { feature: "top-level navigation" }
		}) : !c.policy.enableExtendedHtml && !j(n, f) ? (d = !1, w(c, "local.html.attribute", `HTML attribute ${p} on <${n}> is not supported; the element is shown as source.`, m.start, m.end, {
			key: "local.html.attribute",
			params: {
				name: p,
				tag: n
			}
		})) : l.push(i);
	}
	if (n === "iframe" && !u && l.push({
		name: "sandbox",
		value: P(c.policy)
	}), n === "a") {
		let e = l.find((e) => e.name.toLowerCase() === "target")?.value, t = l.find((e) => e.name.toLowerCase() === "rel"), n = i(t?.value, e);
		n !== void 0 && (t ? t.value = n : l.push({
			name: "rel",
			value: n
		}));
	}
	return e.attrs = l, d;
}
function le(e, t, n) {
	let r = t.diagnostics.length, i = T(e, t);
	E(t, i.start, i.end);
	let a = e.tagName.toLowerCase(), o = e.namespaceURI === f;
	if (h.has(a)) return t.fragment ? (w(t, "local.html.fallback", `HTML element <${a}> cannot be rendered in an extended fragment; it is shown as source.`, i.start, i.end, { key: "html.fallback" }), X(e, t, n, r)) : (t.bodyFallbacks.push(D(e, t)), w(t, "local.html.fallback", `HTML element <${a}> requires enableExtendedHtml in this mode; it is shown as source.`, i.start, i.end, {
		key: "local.html.extended",
		params: { name: a }
	}), []);
	if (t.fragment && a === "base") return w(t, "local.html.capability", "Author HTML base was disabled in an extended fragment.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "document base" }
	}), [];
	if (!o && !t.policy.enableCss && ee.has(a)) return w(t, "local.html.capability", `Author animation <${a}> was disabled by the compile options.`, i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "animation" }
	}), [];
	if (a === "script") return t.policy.enableJavaScript ? J(e, a, o, t) ? [e] : X(e, t, n, r) : (w(t, "local.html.capability", "Author JavaScript was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "JavaScript" }
	}), []);
	if (a === "style") return t.policy.enableCss ? J(e, a, o, t) ? [e] : X(e, t, n, r) : (w(t, "local.html.capability", "Author CSS was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "CSS" }
	}), []);
	if (a === "link") return (e.attrs.find((e) => e.name.toLowerCase() === "rel")?.value.toLowerCase() ?? "").split(/\s+/).includes("stylesheet") ? t.policy.enableCss ? J(e, a, o, t) ? [e] : X(e, t, n, r) : (w(t, "local.html.capability", "Author CSS was disabled by the compile options.", i.start, i.end, {
		key: "local.html.capability",
		params: { feature: "CSS" }
	}), []) : t.policy.enableExtendedHtml ? J(e, a, o, t) ? [e] : X(e, t, n, r) : Y(e, t);
	if (a === "meta") {
		if (!t.policy.enableExtendedHtml) return Y(e, t);
		let s = e.attrs.find((e) => e.name.toLowerCase() === "http-equiv")?.value.trim().toLowerCase() ?? "";
		return s === "refresh" || s === "content-security-policy" || s === "set-cookie" ? (w(t, "local.html.capability", `Author metadata ${s} was disabled.`, i.start, i.end, {
			key: "local.html.capability",
			params: { feature: "document metadata" }
		}), []) : J(e, a, o, t) ? [e] : X(e, t, n, r);
	}
	return (a === "title" || a === "html" || a === "head" || a === "body") && !t.policy.enableExtendedHtml && a === "title" || !(o && (p.has(a) || m.has(a)) || t.policy.enableExtendedHtml) ? Y(e, t, n) : J(e, a, o, t) ? a === "template" ? (Q(u.getTemplateContent(e), t, !1), [e]) : (Q(e, t, n), [e]) : X(e, t, n, r);
}
function Y(e, t, n = !1) {
	let r = t.diagnostics.length, i = e.tagName.toLowerCase(), a = T(e, t);
	return w(t, "local.html.extended", `HTML element <${i}> requires enableExtendedHtml in this mode; it is shown as source.`, a.start, a.end, {
		key: "local.html.extended",
		params: { name: i }
	}), X(e, t, n, r);
}
function X(e, t, n, r) {
	return Z(t, r), n ? (t.bodyFallbacks.push(D(e, t)), []) : [O(D(e, t))];
}
function Z(e, t) {
	for (let n of e.diagnostics.slice(t)) n.severity === "warning" && (n.code = "local.html.fallback");
}
function Q(e, t, n) {
	let r = [];
	for (let i of e.childNodes) if (u.isTextNode(i)) E(t, 0, 0), r.push(i);
	else if (u.isCommentNode(i)) E(t, 0, 0), r.push(i);
	else if (!u.isDocumentTypeNode(i) && u.isElementNode(i)) {
		let e = i.tagName.toLowerCase(), a = n || e === "head";
		r.push(...le(i, t, a));
	}
	e.childNodes = r;
}
function ue(e, t, n, r) {
	let i = [], a = {
		policy: t,
		source: e,
		lines: { starts: S(e) },
		diagnostics: i,
		maxNodes: n,
		depth: 0,
		...r === void 0 ? {} : { frameOrigins: V(r) },
		budget: { nodes: 0 },
		bodyFallbacks: [],
		stopped: !1
	}, o;
	try {
		o = c(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch (e) {
		return {
			markup: K(a),
			diagnostics: [{
				code: "local.parse",
				message: `Cannot parse the HTML document: ${e instanceof Error ? e.message : String(e)}`,
				severity: "error",
				range: {
					start: 0,
					end: 0
				},
				line: 1,
				column: 1,
				messageKey: "local.parse.document",
				params: { detail: e instanceof Error ? e.message : String(e) }
			}]
		};
	}
	try {
		let e = F(o, "html");
		if (e) {
			let t = a.diagnostics.length;
			if (!J(e, "html", !0, a)) return Z(a, t), {
				markup: K(a),
				diagnostics: i
			};
			Q(e, a, !1);
		} else Q(o, a, !1);
		return {
			markup: G(a, o),
			diagnostics: i
		};
	} catch (e) {
		if (e instanceof x) {
			let t = C(a, e.start, e.end);
			return {
				markup: K(a),
				diagnostics: [{
					code: "local.budget",
					message: e.message,
					severity: "error",
					range: {
						start: t.start,
						end: t.end
					},
					line: t.line,
					column: t.column,
					messageKey: "local.budget.nodes",
					params: { limit: e.limit }
				}]
			};
		}
		return {
			markup: K(a),
			diagnostics: [{
				code: "local.parse",
				message: `Cannot parse the HTML document: ${e instanceof Error ? e.message : String(e)}`,
				severity: "error",
				range: {
					start: 0,
					end: 0
				},
				line: 1,
				column: 1,
				messageKey: "local.parse.document",
				params: { detail: e instanceof Error ? e.message : String(e) }
			}]
		};
	}
}
var $ = /* @__PURE__ */ new Set([
	...p,
	"dl",
	"dt",
	"dd",
	"section",
	"figure",
	"figcaption"
]), de = /* @__PURE__ */ new Set([
	"class",
	"title",
	"lang",
	"dir",
	"role",
	"alt",
	"open",
	"start",
	"rowspan",
	"colspan",
	"scope"
]);
function fe(e) {
	let t = [...e.childNodes];
	for (; t.length;) {
		let e = t.pop();
		if (!u.isTextNode(e)) {
			if (!u.isElementNode(e) || e.namespaceURI !== f || !$.has(e.tagName) || e.attrs.some((e) => e.namespace || !de.has(e.name) && !/^aria-[a-z-]+$/.test(e.name))) return !1;
			for (let n of e.childNodes) t.push(n);
		}
	}
	return !0;
}
function pe(e, t) {
	let n = [{
		node: e,
		depth: 0
	}];
	for (; n.length > 0;) {
		let { node: e, depth: r } = n.pop();
		for (let i of e.childNodes) {
			if (!u.isElementNode(i)) continue;
			if (r + 1 > t) return !0;
			let e = i.tagName.toLowerCase() === "template" ? u.getTemplateContent(i) : i;
			n.push({
				node: e,
				depth: r + 1
			});
		}
	}
	return !1;
}
function me(e, t, n, r) {
	let i = [];
	if (typeof e != "string" || e.trim() === "") return {
		markup: "",
		diagnostics: i
	};
	let a = {
		policy: t,
		source: e,
		lines: { starts: S(e) },
		diagnostics: i,
		maxNodes: n,
		depth: 0,
		fragment: !0,
		...r === void 0 ? {} : { frameOrigins: V(r) },
		budget: { nodes: 0 },
		bodyFallbacks: [],
		stopped: !1
	}, o;
	try {
		o = d(e, {
			scriptingEnabled: !1,
			sourceCodeLocationInfo: !0
		});
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		return w(a, "local.parse", `Cannot parse the HTML fragment: ${t}`, 0, 0, {
			key: "local.parse.document",
			params: { detail: t }
		}), { diagnostics: i };
	}
	if (pe(o, b)) return { diagnostics: [{
		code: "local.budget",
		message: `HTML fragment exceeds ${b} nested element levels.`,
		severity: "error",
		range: {
			start: 0,
			end: e.length
		},
		line: 1,
		column: 1,
		messageKey: "local.budget.nodes",
		params: { limit: b }
	}] };
	try {
		return Q(o, a, !1), {
			markup: a.bodyFallbacks.map((e) => l(O(e), { scriptingEnabled: !1 })).join("") + I(o),
			inlineSafe: fe(o),
			diagnostics: i
		};
	} catch (e) {
		if (e instanceof x) {
			let t = C(a, e.start, e.end);
			return { diagnostics: [{
				code: "local.budget",
				message: e.message,
				severity: "error",
				range: {
					start: t.start,
					end: t.end
				},
				line: t.line,
				column: t.column,
				messageKey: "local.budget.nodes",
				params: { limit: e.limit }
			}] };
		}
		return { diagnostics: i };
	}
}
export { me as i, P as n, ue as r, R as t };
