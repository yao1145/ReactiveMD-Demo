import { a as e, i as t, s as n } from "./latex-1w7aQgD5.js";
import { n as r, u as i } from "./compiler-core-C6Xd9anm.js";
import { n as a } from "./display-B-VhqVND.js";
import { i as o } from "./html-C1aZX-Mh.js";
import { r as s, t as c } from "./options-1aDLK7JY.js";
// src/local/compilation/compiler.ts
function l(e, t) {
	return i(p(e, t));
}
function u(e, t, n, r) {
	let i, a = () => globalThis.performance?.now?.() ?? Date.now(), o = a(), s = {}, l = o, u = (e) => {
		let t = a();
		s[e] = t - l, l = t;
	};
	n?.semantic?.begin(c(t));
	let d = p(e, t, (e) => {
		i = e;
	}, n, u, r);
	return s.totalMs = a() - o, {
		result: d,
		parsed: i,
		...n?.semantic ? { semantic: n.semantic.stats } : {},
		timings: s
	};
}
function d(e) {
	return {
		ok: !1,
		diagnostics: [{
			code: "local.options.invalid",
			message: e.message,
			severity: "error",
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: e.key,
			...e.detail === void 0 ? {} : { params: { detail: e.detail } }
		}]
	};
}
function f(r) {
	return {
		...r?.parser ? { parser: r.parser } : {},
		...r?.semantic ? { semantic: r.semantic } : {},
		...r?.rowPlans ? { rowPlans: r.rowPlans } : {},
		display: r?.semantic ? (e, t) => r.semantic.display(e, t) : a,
		htmlFragment: o,
		plotMath: {
			kind: n,
			gridSize: e,
			compile: t
		}
	};
}
function p(e, t, n, i, a, o) {
	let c = s(t);
	return c.ok ? r(e, t, c, f(i), n, a, o) : d(c);
}
export { u as n, l as t };
