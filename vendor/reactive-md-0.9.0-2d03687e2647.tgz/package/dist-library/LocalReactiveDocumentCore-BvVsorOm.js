import { M as e, w as t } from "./config-validation-F47AcE6o.js";
import { s as n } from "./config-BadfhjdP.js";
import { n as r, r as ee, t as te } from "./options-1aDLK7JY.js";
import { n as ne } from "./incremental-iPiW7yzN.js";
import { i as re, n as ie, r as ae } from "./runtime-kcA7bG7G.js";
import { a as oe, c as i, i as a, n as se, o as ce, r as le, s as ue, t as de } from "./LocalDocumentViewCore-Cu7Xj5wF.js";
import { useCallback as o, useEffect as s, useMemo as fe, useRef as c } from "react";
import { jsx as l, jsxs as pe } from "react/jsx-runtime";
// src/local/rendering/document/LocalReactiveDocumentCore.tsx
var me = Symbol("implicit document identity");
function u({ source: u, onDiagnostics: he, sourcePhase: d, onTransientDiagnostics: ge, urlPolicy: _e, locale: f = "en", themes: p, colorScheme: ve = "auto", mode: m = "interactive", staticFirst: ye = !1, imageResolver: be, hostData: xe, hostRenderer: Se, reactConfig: h, useBaseCompileConfig: Ce, externalValues: g, network: we, documentId: _, randomSeed: v, componentState: Te, componentStateStorage: Ee, componentStateWriteDelayMs: De, onComponentStateChange: y, initialParameters: b, onParametersChange: x, onSourceNavigate: Oe, compileOptions: S, capabilityGrants: C, allowedFrameOrigins: ke, getBaseConfig: w }) {
	if (ue(h, {
		hostData: xe,
		hostRenderer: Se,
		themes: p
	}), h !== void 0) {
		let e = S?.config;
		if (e !== void 0 && e !== h.config) {
			let t = !1;
			try {
				t = n(e).key === h.config.key;
			} catch {
				t = !1;
			}
			if (!t) throw Error("reactConfig and compileOptions.config must be the same local config.");
		}
		if (S?.hostComponents !== void 0) throw Error("reactConfig cannot be combined with compileOptions.hostComponents.");
	}
	let T = h === void 0 && Ce ? w() : void 0, Ae = T !== void 0 && S?.config === void 0 && S?.hostComponents === void 0, E = h === void 0 ? Ae ? {
		...S ?? {},
		config: T.config
	} : S : {
		...S ?? {},
		config: h.config
	}, D = h?.themes ?? p ?? T?.themes, O = te(E), k = `${r(E)}|${_ ?? ""}|${v ?? ""}`, A = d === void 0 ? E?.sourcePhase : d, j = A === "streaming" || A === "final" ? A : A === void 0 ? "final" : A, M = j === "streaming", je = c(g);
	je.current = g;
	let N = c(_);
	N.current = _;
	let Me = c(v);
	Me.current = v;
	let Ne = c(Te);
	Ne.current = Te;
	let P = c(Ee);
	P.current = Ee;
	let F = c(De);
	F.current = De;
	let Pe = c(y);
	Pe.current = y;
	let Fe = c(b);
	Fe.current = b;
	let Ie = c(x);
	Ie.current = x;
	let Le = c([]), Re = E?.config, ze = Re?.key, Be = Re?.legacyKeys.map((e) => e.key) ?? [], Ve = (e) => {
		let t = ie(e, {
			externalValues: je.current,
			documentId: N.current,
			randomSeed: Me.current,
			componentState: Ne.current,
			...P.current === void 0 ? {} : { componentStateStorage: P.current },
			...F.current === void 0 ? {} : { componentStateWriteDelayMs: F.current },
			...(ze ?? e.componentConfigKey) === void 0 ? {} : { configKey: ze ?? e.componentConfigKey },
			...Be.length === 0 ? {} : { legacyConfigKeys: Be }
		}), n = Fe.current;
		return Le.current = n && Object.keys(n).length ? t.setParameters(se(n)) : [], t;
	}, I = c(null), L = c(null), R = fe(() => {
		I.current && L.current === O || (I.current?.dispose(), I.current = ne(), L.current = O);
		let e = I.current;
		return typeof e.compileShared == "function" ? e.compileShared(u, E, j) : e.compile(u, E, j);
	}, [
		u,
		O,
		j
	]), z = c(null), B = c(null), V = c([]), H = c(!1), U = z.current;
	if (!R.ok) U = null;
	else {
		let e = R.document;
		if (U && B.current !== k) {
			try {
				U.services?.state.flush();
			} catch {}
			V.current.push(U), U = null, z.current = null;
		}
		if (!U) {
			try {
				U = Ve(e);
			} catch {
				U = null;
			}
			z.current = U;
		} else if (U.document !== e) {
			let t = !1;
			try {
				let n = re(U, e, { notify: !1 });
				t = n.ok, n.ok && n.changed && (H.current = !0);
			} catch {
				t = !1;
			}
			if (!t) {
				try {
					U.services?.state.flush();
				} catch {}
				V.current.push(U);
				let t = null;
				try {
					t = Ve(e);
				} catch {
					t = null;
				}
				U = t, z.current = t;
			}
		}
		B.current = k;
	}
	let He = c(he);
	He.current = he;
	let W = c(0), G = c(ge);
	G.current = ge;
	let Ue = c(""), K = c(!1), q = R.transientDiagnostics ?? [], J = q.length === 0 ? "" : a(q);
	s(() => {
		if (J !== Ue.current) {
			if (Ue.current = J, q.length === 0) {
				if (!K.current) return;
				K.current = !1, G.current?.([]);
			} else K.current = !0, G.current?.(q);
		}
	}, [J]);
	let We = ce(D), Ge = fe(() => {
		if (!R.ok) return [];
		try {
			return t(R.document.theme, D, R.document.themeRange, R.document.source).diagnostics;
		} catch {
			return [];
		}
	}, [R, We]), Ke = c(null), qe = o((e) => {
		let t = a(e);
		t !== Ke.current && (Ke.current = t, He.current?.(e));
	}, []), Y = c([]), X = c([]), Z = o(() => {
		qe(le(R.diagnostics, Ge, Le.current, Y.current, X.current));
	}, [
		R,
		Ge,
		qe
	]), Q = c(Z);
	Q.current = Z, s(() => {
		let e = U?.services, t = e === void 0 ? [] : e.state.diagnostics(), n = X.current;
		t.length === n.length && t.every((e, t) => e === n[t]) || (X.current = [...t], Q.current());
	}), s(() => {
		Y.current = [];
	}, [R]), s(() => {
		Z();
	}, [Z]);
	let Je = o((e) => {
		Y.current = e, Q.current();
	}, []);
	if (s(() => {
		if (!U) return;
		Q.current();
		let e = !0, t;
		try {
			t = U.getParameters();
		} catch {
			return;
		}
		let n = () => {};
		try {
			n = U.subscribe(() => {
				if (!e) return;
				let n, r;
				try {
					n = U.getParameters(), r = U.snapshot();
				} catch {
					return;
				}
				if (!oe(t, n)) {
					t = n;
					try {
						Ie.current?.(n, r);
					} catch {}
				}
			});
		} catch {
			return;
		}
		return () => {
			e = !1, n();
		};
	}, [U]), s(() => (W.current += 1, () => {
		--W.current, queueMicrotask(() => {
			if (W.current !== 0) return;
			let e = z.current;
			z.current = null;
			try {
				e?.dispose();
			} catch {}
			try {
				I.current?.dispose();
			} catch {}
			I.current = null, L.current = null;
		});
	}), []), s(() => {
		let e = V.current;
		V.current = [];
		for (let t of e) queueMicrotask(() => {
			if (z.current !== t) try {
				t.dispose();
			} catch {}
		});
		if (!R.ok || !U) {
			let e = z.current;
			e && (z.current = null, B.current = null, queueMicrotask(() => {
				if (z.current !== e) try {
					e.dispose();
				} catch {}
			})), I.current && (I.current.dispose(), I.current = null, L.current = null);
		}
		if (H.current) {
			H.current = !1;
			let e = z.current;
			e && ae(e);
		}
	}), s(() => {
		let e = U?.services;
		if (e && y !== void 0) return e.state.subscribe(() => {
			Pe.current?.(e.state.snapshot());
		});
	}, [U, y]), s(() => {
		let e = U?.services?.state;
		if (e === void 0) return;
		let t = () => e.flush(), n = () => {
			document.visibilityState === "hidden" && t();
		};
		return window.addEventListener("pagehide", t), document.addEventListener("visibilitychange", n), () => {
			window.removeEventListener("pagehide", t), document.removeEventListener("visibilitychange", n);
		};
	}, [U]), !R.ok || !U) return /* @__PURE__ */ pe("div", {
		className: `md-document local-document local-inactive${m === "static" ? " local-static" : ""}`,
		"data-render-mode": m,
		role: "alert",
		children: [/* @__PURE__ */ l("p", {
			className: "local-inactive-title",
			children: R.ok ? i(f, "Interactive initialization failed; preview is disabled.", "交互初始化失败，预览已停用。") : i(f, "The document contains syntax errors; interactive preview is disabled.", "文档包含语法错误，交互预览已停用。")
		}), R.diagnostics.length ? /* @__PURE__ */ l("ul", {
			className: "local-inactive-list",
			children: R.diagnostics.map((t, n) => /* @__PURE__ */ pe("li", { children: [e(t, f), i(f, ` (line ${t.line}, column ${t.column})`, `（第 ${t.line} 行，第 ${t.column} 列）`)] }, `${t.code}-${n}`))
		}) : null]
	});
	let $ = ee(E), Ye = $.ok ? {
		enableCss: $.html.enableCss && (C?.enableCss ?? !0) === !0,
		enableJavaScript: $.html.enableJavaScript && (C?.enableJavaScript ?? !0) === !0,
		enableExtendedHtml: $.html.enableExtendedHtml && (C?.enableExtendedHtml ?? !0) === !0
	} : void 0;
	return /* @__PURE__ */ l(de, {
		document: R.document,
		runtime: U,
		capabilityGrants: Ye,
		allowedFrameOrigins: ke,
		network: we,
		networkScope: _ ?? me,
		onDiagnostics: Je,
		urlPolicy: _e,
		locale: f,
		themes: h === void 0 ? D : void 0,
		colorScheme: ve,
		mode: M ? "static" : m,
		staticFirst: !M && ye,
		imageResolver: be,
		hostData: xe,
		hostRenderer: Se,
		reactConfig: h,
		getBaseConfig: w,
		externalValues: g,
		onSourceNavigate: Oe
	}, k);
}
export { u as t };
