import { C as e, F as t, I as n, L as r, O as i, P as a, S as o, U as s, V as c, c as l, d as u, f as d, l as f, p, s as m, z as h } from "./sdk-core-CW2JhTlm.js";
import { n as g, t as _ } from "./tooltip-layer-HDLrSWs0.js";
import { useEffect as v, useId as y, useRef as b, useState as x } from "react";
import { Fragment as S, jsx as C, jsxs as w } from "react/jsx-runtime";
// src/components/layout/layout.tsx
function T(e) {
	let t = n(e), i = r(e), { content: o, runtime: s, mode: c, t: l } = i, u = a(e, "title", ""), d = p(e, "reset", !0) && c !== "static", [f, h] = x(null), g = () => {
		try {
			s.reset(o), h(null);
		} catch (e) {
			h(e instanceof Error ? e.message : l("Cannot reset", "无法恢复默认"));
		}
	};
	return /* @__PURE__ */ w("section", {
		...t(),
		className: "md-panel local-panel",
		"aria-label": u || l("Parameter panel", "参数面板"),
		children: [
			u || d ? /* @__PURE__ */ w("div", {
				className: "local-panel-head",
				children: [u ? /* @__PURE__ */ C("h3", {
					className: "md-panel-title local-panel-title",
					children: u
				}) : /* @__PURE__ */ C("span", {}), d ? /* @__PURE__ */ C("button", {
					type: "button",
					className: "md-button md-button-quiet local-panel-reset",
					onClick: g,
					"aria-label": u ? l(`Reset ${u}`, `${u} 恢复默认`) : l("Reset", "恢复默认"),
					children: l("Reset", "恢复默认")
				}) : null]
			}) : null,
			/* @__PURE__ */ C("div", {
				className: "md-panel-body local-panel-body",
				children: i.render()
			}),
			/* @__PURE__ */ C(m, { message: f })
		]
	});
}
function E(e) {
	let t = n(e), i = r(e), o = a(e, "title", "");
	return /* @__PURE__ */ w("section", {
		...t(),
		className: "md-card local-card",
		children: [o ? /* @__PURE__ */ C("h3", {
			className: "md-card-title",
			children: o
		}) : null, /* @__PURE__ */ C("div", {
			className: "md-card-body",
			children: i.render()
		})]
	});
}
function D(e) {
	let t = n(e), i = r(e), a = Math.min(4, Math.max(1, Math.floor(Number(e.props.columns ?? 2) || 2)));
	return /* @__PURE__ */ C("div", {
		className: "local-grid",
		...t({ "--local-grid-columns": String(a) }),
		children: i.render()
	});
}
function O(e) {
	let t = n(e), i = r(e);
	return /* @__PURE__ */ C("div", {
		...t(),
		className: "local-tabpanel-body",
		children: i.render()
	});
}
function k() {
	return null;
}
function A() {
	return null;
}
function j() {
	return null;
}
function M(e) {
	let t = n(e), u = r(e), d = y(), { content: p, mode: g, visible: _, t: v } = u, { write: S, error: T } = s(e), E = a(e, "label", ""), D = c(e), O = p.children.filter((e) => e.kind === "component" && e.name === "tab"), k = O.map((e, t) => i(e, "value") ?? `tab-${t + 1}`), A = O.map((t, n) => o(e, t, "label", k[n])), j = i(p, "initial") ?? k[0] ?? "", M = i(p, "bind") !== void 0, N = e.runtime.get(p), P = typeof N == "string" ? N : "", [F, I] = x(() => k.includes(j) ? j : k[0] ?? ""), L = b([]);
	if (h(e, () => {
		I(k.includes(j) ? j : k[0] ?? "");
	}), O.length === 0) return /* @__PURE__ */ C(l, { message: v("Tabs requires at least one tab", "标签页至少需要一个 tab") });
	if (g === "static") return /* @__PURE__ */ w("section", {
		...t(),
		className: "local-tabs local-static-tabs",
		"aria-label": E || v("Tabs", "选项卡"),
		children: [E ? /* @__PURE__ */ C("div", {
			className: "local-tabs-label",
			children: E
		}) : null, O.map((e, t) => /* @__PURE__ */ w("section", {
			className: "local-static-tab",
			children: [/* @__PURE__ */ C("h4", {
				className: "local-static-tab-label",
				children: A[t]
			}), /* @__PURE__ */ C("div", {
				className: "local-static-tab-body",
				children: u.render(e.children, _)
			})]
		}, e.id))]
	});
	let R = M ? k.includes(P) ? P : k[0] : k.includes(F) ? F : k[0], z = Math.max(0, k.indexOf(R)), B = (e) => {
		let t = k[e];
		t !== void 0 && (M ? S(t) : I(t), L.current[e]?.focus());
	}, V = (e) => {
		let t = -1;
		e.key === "ArrowRight" ? t = (z + 1) % O.length : e.key === "ArrowLeft" ? t = (z - 1 + O.length) % O.length : e.key === "Home" ? t = 0 : e.key === "End" && (t = O.length - 1), !(t < 0) && (e.preventDefault(), B(t));
	};
	return /* @__PURE__ */ w("section", {
		...t(),
		className: "md-tabs local-tabs",
		"aria-label": E || v("Tabs", "选项卡"),
		"aria-invalid": D.invalid || void 0,
		"aria-describedby": D.describedBy,
		children: [
			E ? /* @__PURE__ */ C("div", {
				className: "local-tabs-label",
				children: E
			}) : null,
			/* @__PURE__ */ C("div", {
				className: "md-tablist local-tablist",
				role: "tablist",
				"aria-label": E || v("Tabs", "选项卡"),
				onKeyDown: V,
				children: O.map((e, t) => {
					let n = k[t], r = n === R;
					return /* @__PURE__ */ C("button", {
						ref: (e) => {
							L.current[t] = e;
						},
						id: `${d}-tab-${t}`,
						type: "button",
						role: "tab",
						className: `md-tab local-tab${r ? " is-selected" : ""}`,
						"aria-selected": r,
						"aria-controls": `${d}-panel-${t}`,
						tabIndex: r ? 0 : -1,
						onClick: () => {
							M ? S(n) : I(n);
						},
						children: A[t]
					}, e.id);
				})
			}),
			O.map((e, t) => {
				let n = k[t] === R;
				return /* @__PURE__ */ w("div", {
					id: `${d}-panel-${t}`,
					className: "md-tabpanel local-tabpanel",
					role: "tabpanel",
					"aria-labelledby": `${d}-tab-${t}`,
					tabIndex: 0,
					hidden: !n,
					children: [/* @__PURE__ */ C(f, {
						block: !0,
						value: A[t]
					}), u.render(e.children, _ && n)]
				}, e.id);
			}),
			/* @__PURE__ */ C(m, { message: T })
		]
	});
}
function N(e) {
	let t = n(e), u = r(e), d = y(), { content: f, mode: p, visible: g, t: _ } = u, { write: x, error: S, setError: T } = s(e), E = a(e, "label", ""), D = c(e), O = f.children.filter((e) => e.kind === "component" && e.name === "step"), k = O.map((e, t) => i(e, "value") ?? `step-${t + 1}`), A = O.map((t, n) => o(e, t, "label", k[n])), j = i(f, "initial") ?? "", M = k.includes(j) ? j : k[0] ?? "", N = e.runtime.get(f), P = typeof N == "string" ? N : "", F = b([]), I = b(!1);
	h(e, () => {
		T(null), I.current = !1;
	});
	let L = k.includes(P) ? P : M, R = Math.max(0, k.indexOf(L));
	if (v(() => {
		I.current && (I.current = !1, F.current[R]?.focus({ preventScroll: !0 }));
	}, [R, L]), O.length === 0) return /* @__PURE__ */ C(l, { message: _("Steps requires at least one step", "步骤至少需要一个 step") });
	if (p === "static") {
		let e = O[R];
		return /* @__PURE__ */ w("section", {
			...t(),
			className: "local-steps local-static-steps",
			"aria-label": E || _("Steps", "步骤"),
			children: [
				E ? /* @__PURE__ */ C("div", {
					className: "local-steps-label",
					children: E
				}) : null,
				/* @__PURE__ */ C("ol", {
					className: "local-steps-rail",
					"aria-hidden": "true",
					style: { "--local-steps-progress": `${O.length <= 1 ? 100 : R / (O.length - 1) * 100}%` },
					children: O.map((e, t) => /* @__PURE__ */ C("li", {
						className: `local-steps-dot${t < R ? " is-complete" : t === R ? " is-current" : ""}`,
						children: /* @__PURE__ */ C("span", { children: t + 1 })
					}, e.id))
				}),
				/* @__PURE__ */ C("div", {
					className: "local-steps-nav local-static-steps-nav",
					children: /* @__PURE__ */ C("span", {
						className: "local-steps-status",
						role: "status",
						"aria-live": "polite",
						children: _(`Step ${R + 1} of ${O.length}`, `第 ${R + 1} 步，共 ${O.length} 步`)
					})
				}),
				/* @__PURE__ */ C("div", {
					className: "local-steps-panel",
					role: "group",
					"aria-label": A[R],
					children: u.render(e.children, g)
				})
			]
		});
	}
	let z = (e) => {
		let t = k[e];
		t !== void 0 && (I.current = !0, x(t));
	};
	return /* @__PURE__ */ w("section", {
		...t(),
		className: "local-steps",
		"aria-label": E || _("Steps", "步骤"),
		"aria-invalid": D.invalid || void 0,
		"aria-describedby": D.describedBy,
		children: [
			E ? /* @__PURE__ */ C("div", {
				className: "local-steps-label",
				children: E
			}) : null,
			/* @__PURE__ */ C("ol", {
				className: "local-steps-rail",
				"aria-hidden": "true",
				style: { "--local-steps-progress": `${O.length <= 1 ? 100 : R / (O.length - 1) * 100}%` },
				children: O.map((e, t) => /* @__PURE__ */ C("li", {
					className: `local-steps-dot${t < R ? " is-complete" : t === R ? " is-current" : ""}`,
					children: /* @__PURE__ */ C("span", { children: t + 1 })
				}, e.id))
			}),
			/* @__PURE__ */ w("div", {
				className: "local-steps-nav",
				children: [
					/* @__PURE__ */ C("button", {
						type: "button",
						className: "md-button md-button-secondary local-steps-prev",
						disabled: R <= 0,
						onClick: () => z(R - 1),
						children: _("Previous", "上一步")
					}),
					/* @__PURE__ */ C("span", {
						className: "local-steps-status",
						role: "status",
						"aria-live": "polite",
						children: _(`Step ${R + 1} of ${O.length}`, `第 ${R + 1} 步，共 ${O.length} 步`)
					}),
					/* @__PURE__ */ C("button", {
						type: "button",
						className: "md-button md-button-secondary local-steps-next",
						disabled: R >= O.length - 1,
						onClick: () => z(R + 1),
						children: _("Next", "下一步")
					})
				]
			}),
			O.map((e, t) => {
				let n = t === R;
				return /* @__PURE__ */ C("div", {
					id: `${d}-step-${t}`,
					ref: (e) => {
						F.current[t] = e;
					},
					className: "local-steps-panel",
					role: "group",
					"aria-label": A[t],
					tabIndex: -1,
					hidden: !n,
					children: u.render(e.children, g && n)
				}, e.id);
			}),
			/* @__PURE__ */ C(m, { message: S })
		]
	});
}
function P() {
	return null;
}
function F(e) {
	let t = n(e), i = r(e), o = a(e, "label", "");
	return /* @__PURE__ */ w("div", {
		...t(),
		className: "local-accordion",
		role: "group",
		"aria-label": o || i.t("Accordion", "折叠面板"),
		children: [o ? /* @__PURE__ */ C("div", {
			className: "local-accordion-label",
			children: o
		}) : null, i.render()]
	});
}
function I(e) {
	let t = n(e), i = r(e), o = y(), { mode: s, visible: c, t: l } = i, u = a(e, "label", l("Details", "折叠内容")), d = p(e, "open", !1), [m, g] = x(d);
	if (h(e, () => {
		g(d);
	}), s === "static") return /* @__PURE__ */ w("section", {
		...t(),
		className: "local-disclosure local-static-disclosure",
		children: [/* @__PURE__ */ C("h3", {
			className: "local-disclosure-heading",
			children: u
		}), /* @__PURE__ */ C("div", {
			className: "local-disclosure-panel",
			children: i.render()
		})]
	});
	let _ = `${o}-disclosure-trigger`, v = `${o}-disclosure-panel`;
	return /* @__PURE__ */ w("div", {
		...t(),
		className: "local-disclosure",
		children: [/* @__PURE__ */ w("h3", {
			className: "local-disclosure-heading",
			children: [/* @__PURE__ */ w("button", {
				id: _,
				type: "button",
				className: "local-disclosure-trigger",
				"data-rmd-appearance": "custom",
				"aria-expanded": m,
				"aria-controls": v,
				onClick: () => g((e) => !e),
				children: [/* @__PURE__ */ C("span", {
					className: "local-disclosure-label",
					children: u
				}), /* @__PURE__ */ C("svg", {
					className: `local-chevron${m ? " is-open" : ""}`,
					viewBox: "0 0 24 24",
					width: "17",
					height: "17",
					fill: "none",
					stroke: "currentColor",
					strokeWidth: "1.75",
					strokeLinecap: "round",
					strokeLinejoin: "round",
					"aria-hidden": "true",
					focusable: "false",
					children: /* @__PURE__ */ C("path", { d: "m6 9 6 6 6-6" })
				})]
			}), /* @__PURE__ */ C(f, { value: u })]
		}), /* @__PURE__ */ C("div", {
			id: v,
			className: "local-disclosure-panel",
			role: "region",
			"aria-labelledby": _,
			hidden: !m,
			inert: !m,
			children: /* @__PURE__ */ C("div", {
				className: "local-disclosure-body",
				children: i.render(void 0, c)
			})
		})]
	});
}
function L(e) {
	let t = n(e)(), a = r(e), { content: o, t: s, visible: c } = a, u = i(o, "when"), d = e.props.when, f = typeof d == "boolean" && d, p = u !== void 0 && typeof d != "boolean", m = b(null), h = b(f), g = b(!1);
	return v(() => {
		if (h.current && !f) {
			if (g.current) {
				let e = m.current?.closest(".local-document");
				e && (e.tabIndex = -1, e.focus({ preventScroll: !0 }));
			}
			g.current = !1;
		}
		h.current = f;
	}, [f]), /* @__PURE__ */ w(S, { children: [p ? /* @__PURE__ */ C(l, { message: s("Cannot compute", "无法计算") }) : null, /* @__PURE__ */ C("div", {
		style: t.style,
		ref: (e) => {
			m.current = e, t.ref?.(e);
		},
		className: "local-if md-if",
		role: "group",
		"aria-label": s("Conditional content", "条件内容"),
		tabIndex: -1,
		hidden: !f,
		"aria-hidden": !f,
		onFocus: () => {
			g.current = !0;
		},
		onBlur: (e) => {
			m.current?.contains(e.relatedTarget) || (g.current = !1);
		},
		children: a.render(void 0, c && f)
	})] });
}
function R(e) {
	let i = n(e), o = r(e), s = a(e, "title", ""), { tone: c, error: l } = t(e, "tone", [
		"info",
		"success",
		"warning",
		"error"
	], "info"), d = c === "warning" || c === "error" ? "alert" : "status";
	return /* @__PURE__ */ w(S, { children: [l ? /* @__PURE__ */ C(u, { message: o.t("Invalid tone; using the default style", "色调无效，已使用默认样式") }) : null, /* @__PURE__ */ w("div", {
		className: `md-alert md-alert-${c} local-alert local-alert-${c}`,
		role: d,
		...i(),
		children: [s ? /* @__PURE__ */ C("div", {
			className: "md-alert-title local-alert-title",
			children: s
		}) : null, /* @__PURE__ */ C("div", {
			className: "md-alert-body local-alert-body",
			children: o.render()
		})]
	})] });
}
function z(i) {
	let a = n(i), o = r(i), { tone: s, error: c } = t(i, "tone", [
		"neutral",
		"success",
		"warning"
	], "neutral"), l = e(o.content);
	return /* @__PURE__ */ w(S, { children: [c ? /* @__PURE__ */ C(u, { message: o.t("Invalid tone; using the default style", "色调无效，已使用默认样式") }) : null, /* @__PURE__ */ C("span", {
		className: `md-badge md-badge-${s} local-badge`,
		...a(l ? { color: l } : void 0),
		children: /* @__PURE__ */ C("span", {
			className: "md-badge-label",
			children: o.renderInline()
		})
	})] });
}
function B(e) {
	let t = n(e), i = r(e), o = y(), { mode: s, t: c } = i, l = a(e, "text", c("Tooltip", "提示")), [u, d] = x(!1), p = b(null), m = b(null), h = `${o}-tooltip`, S = u && e.visible && s !== "static";
	return g(m, S), v(() => d(!1), [
		e.visible,
		e.resetToken,
		s
	]), _(() => {
		let e = m.current, t = p.current;
		if (!S || !e || !t) return;
		let n = () => {
			let n = e.getBoundingClientRect(), r = t.getBoundingClientRect(), i = Number.parseFloat(getComputedStyle(e).getPropertyValue("--space-2")) || 8, a = Math.max(8, Math.min(r.left, window.innerWidth - n.width - 8)), o = r.top - n.height - i, s = o >= 8 ? o : Math.max(8, Math.min(r.bottom + i, window.innerHeight - n.height - 8));
			e.style.left = `${a}px`, e.style.top = `${s}px`;
		};
		n(), window.addEventListener("resize", n), window.addEventListener("scroll", n, {
			capture: !0,
			passive: !0
		});
		let r = new ResizeObserver(n);
		return r.observe(t), r.observe(e), () => {
			window.removeEventListener("resize", n), window.removeEventListener("scroll", n, !0), r.disconnect();
		};
	}, [S, l]), s === "static" ? /* @__PURE__ */ w("span", {
		...t(),
		className: "local-tooltip local-static-tooltip",
		children: [/* @__PURE__ */ C("span", {
			className: "local-tooltip-trigger",
			children: i.renderInline()
		}), /* @__PURE__ */ C("span", {
			className: "md-tooltip local-tooltip-bubble is-visible",
			role: "note",
			children: l
		})]
	}) : /* @__PURE__ */ w("span", {
		...t(),
		className: "local-tooltip",
		onMouseEnter: () => d(!0),
		onMouseLeave: () => d(!1),
		children: [
			/* @__PURE__ */ C("span", {
				className: "local-tooltip-trigger",
				ref: p,
				tabIndex: 0,
				"aria-describedby": h,
				onFocus: () => d(!0),
				onBlur: () => d(!1),
				onKeyDown: (e) => {
					e.key === "Escape" && (e.stopPropagation(), d(!1));
				},
				children: i.renderInline()
			}),
			/* @__PURE__ */ C("span", {
				id: h,
				ref: m,
				role: "tooltip",
				popover: "manual",
				className: `md-tooltip local-tooltip-bubble${S ? " is-visible" : ""}`,
				children: l
			}),
			/* @__PURE__ */ C(f, { value: l })
		]
	});
}
function V(t) {
	let a = n(t), o = r(t), s = y(), { content: c, mode: l, t: u } = o, f = `${s}-jump-feedback`, [p, m] = x(null), g = i(c, "to") ?? "", _ = o.navigation.targetId(g), v = i(c, "appearance") === "button" ? "button" : "link", b = e(c), T = _ ? `#${_}` : "#", E = _ !== void 0 && o.navigation.allowed(g);
	if (h(t, () => m(null)), l === "static") return E && _ ? /* @__PURE__ */ C("a", {
		href: `#${_}`,
		className: "local-jump local-jump-link local-jump-static",
		...a(d(b)),
		children: o.renderInline()
	}) : /* @__PURE__ */ C("span", {
		className: "local-jump local-jump-static-blocked",
		...a(d(b)),
		children: o.renderInline()
	});
	let D = (e) => {
		if (!E || !_) {
			e.preventDefault(), m(_ ? u("Jump is blocked by the host", "跳转已被主机策略阻止") : u("Jump target not found", "找不到跳转目标"));
			return;
		}
		if (e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
		let t = o.navigation.jump(g);
		t === "missing" ? (e.preventDefault(), m(u("Jump target not found", "找不到跳转目标"))) : t === "hidden" ? (e.preventDefault(), m(u("Jump target is hidden", "跳转目标当前隐藏"))) : (e.preventDefault(), m(null));
	};
	return /* @__PURE__ */ w(S, { children: [/* @__PURE__ */ C("a", {
		href: E ? T : "#",
		className: v === "button" ? "local-jump local-jump-button md-button md-button-secondary" : "local-jump local-jump-link",
		...a(d(b)),
		"data-local-custom-color": b ? "true" : void 0,
		"data-local-target-missing": _ ? void 0 : "true",
		"data-local-jump-blocked": _ && !E ? "true" : void 0,
		"aria-describedby": p ? f : void 0,
		onClick: D,
		children: o.renderInline()
	}), p ? /* @__PURE__ */ C("span", {
		id: f,
		className: "local-jump-feedback",
		role: "status",
		"aria-live": "polite",
		children: p
	}) : null] });
}
function H(e) {
	let t = n(e), i = r(e).navigation.anchorId();
	return i ? /* @__PURE__ */ C("span", {
		...t(),
		className: "local-anchor",
		id: i,
		"data-local-anchor": ""
	}) : null;
}
function U(t) {
	let i = n(t), a = r(t), o = e(a.content);
	return /* @__PURE__ */ C("span", {
		className: "local-text",
		...i(o ? { color: o } : void 0),
		children: a.renderInline()
	});
}
function W(t) {
	let i = n(t), a = r(t), o = e(a.content);
	return /* @__PURE__ */ C("div", {
		className: "local-section",
		...i(o ? { color: o } : void 0),
		children: a.render()
	});
}
function G(e) {
	let t = n(e), i = r(e), a = e.validation.hintFor(e.content);
	if (!a) return null;
	let o = a.failed || a.error, s = i.visible && o;
	return /* @__PURE__ */ C("span", {
		...t(),
		id: a.id,
		className: "local-validation-hint",
		"data-local-validation": a.error ? "error" : a.failed ? "failed" : "passed",
		role: s ? "status" : void 0,
		"aria-live": s ? "polite" : void 0,
		children: o ? a.message : null
	});
}
export { O as _, E as a, B as b, j as c, V as d, k as f, N as g, P as h, z as i, D as l, W as m, R as n, A as o, T as p, H as r, I as s, F as t, L as u, M as v, G as x, U as y };
