import { t as e } from "./LocalDocumentView-X4xfZ_DD.js";
import { a as t, c as n, i as r, n as i, o as a, r as o, s, t as c } from "./session-core-BTjbUl3R.js";
// src/standalone/session.tsx
function l(t, n, r) {
	return i(t, n, e, r);
}
function u(e, t) {
	return l(e, t);
}
function d(t, n = {}) {
	return r(e, t, n);
}
export { a as REACTIVE_MD_DIAGNOSTICS_EVENT, c as REACTIVE_MD_MOUNTED_ATTRIBUTE, s as REACTIVE_MD_STATE_CHANGE_EVENT, n as ReactiveMDMountError, o as isReactiveMDMounted, u as mount, d as mountAll, t as parseMountPayload };
