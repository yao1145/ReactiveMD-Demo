// src/local/observability-core.ts
function e() {
	return globalThis.crypto?.randomUUID?.() ?? `rmd-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
}
function t(e, t) {
	try {
		e?.onTrace?.({ ...t });
	} catch {}
}
function n(e, t) {
	if (!e?.onDiagnostic) return;
	let n = t.phase ?? (t.code.startsWith("local.budget") ? "resource" : t.code.startsWith("local.parse") || t.code.startsWith("local.tag") || t.code.startsWith("local.html") ? "parse" : t.code.startsWith("local.runtime") ? "runtime" : t.code.startsWith("local.worker") ? "worker" : t.code.startsWith("local.export") ? "export" : t.code.startsWith("host.") ? "host" : "semantic"), r = {
		...t,
		phase: n,
		recoverable: t.recoverable ?? t.severity === "warning",
		...t.range ? { range: { ...t.range } } : {},
		...t.params ? { params: { ...t.params } } : {},
		...t.details ? { details: { ...t.details } } : {}
	};
	try {
		e.onDiagnostic(r);
	} catch {}
}
export { n, t as r, e as t };
