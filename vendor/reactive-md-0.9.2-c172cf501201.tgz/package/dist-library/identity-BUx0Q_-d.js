// src/runtime-services/identity.ts
var e = new TextEncoder(), t = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/, n = /^[^\u0000-\u001f\u007f]{1,256}$/;
function r(t) {
	let n = e.encode(t), r = 2166136261;
	for (let e = 0; e < n.length; e += 1) r ^= n[e], r = Math.imul(r, 16777619) >>> 0;
	return r >>> 0;
}
function i(e) {
	if (typeof e != "string") throw TypeError("localSourceDigest requires a source string.");
	return `fnv1a32:${r(e).toString(16).padStart(8, "0")}`;
}
function a(e) {
	if (typeof e != "string") return;
	let t = e.trim();
	return n.test(t) ? t : void 0;
}
function o(e) {
	if (typeof e != "string") return;
	let n = e.trim();
	return t.test(n) ? n : void 0;
}
function s(e) {
	return a(e.documentId) ?? e.sourceDigest;
}
function c(e) {
	let t = s(e), n = o(e.stateKey), i = n === void 0 ? `node:${e.nodeId}` : `state:${n}`, a = encodeURIComponent(t);
	return `doc:${a.length <= 256 ? a : `h${r(t).toString(16).padStart(8, "0")}`}:${i}`;
}
function l(e, t) {
	return r(`${e >>> 0}:${t}`);
}
function u(e) {
	if (typeof e.explicitSeed == "number" && Number.isFinite(e.explicitSeed)) return Math.trunc(e.explicitSeed) >>> 0;
	let t = o(e.stateKey), n = t === void 0 ? `node:${e.nodeId}` : `state:${t}`;
	return l(e.documentSeed, `${e.componentId}|${n}`);
}
function d(e) {
	return Number.isFinite(e) ? Math.trunc(e) >>> 0 : 0;
}
export { a, s as c, i, d as l, l as n, o, r, u as s, c as t };
