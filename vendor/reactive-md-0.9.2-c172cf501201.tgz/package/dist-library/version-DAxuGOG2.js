// src/local/configuration/limits.ts
var e = 1e6, t = 1e4, n = 2e7, r = 1e3, i = 1e5, a = 1e4, o = 1e5, s = 2e3, c = 16, l = 2e4, u = 2e6, d = 1e3, f = 100, p = 20, m = 2e3, h = 1e4;
function g(e) {
	if (e.length > 254 || /\s/.test(e)) return !1;
	let t = e.indexOf("@");
	if (t < 1 || t !== e.lastIndexOf("@")) return !1;
	let n = e.lastIndexOf(".");
	return n > t + 1 && n < e.length - 1;
}
// src/sdk/version.ts
var _ = "0.7.0", v = "reactive-md-component/v1", y = "reactive-md-config/v1", b = "reactive-md-config/v2", x = "reactive-md-preset/v1", S = "reactive-md-react-preset/v1", C = "reactive-md-assembly/v1", w = "reactive-md-extensions/v1", T = 128, E = 8, D = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/, O = /^0\d+$/;
function k(e) {
	if (e === void 0) return Object.freeze([]);
	let t = e.split("."), n = [];
	for (let e of t) {
		if (e.length === 0 || O.test(e) && e !== "0" && /^\d+$/.test(e) || /^\d+$/.test(e) && !Number.isSafeInteger(Number(e))) return null;
		n.push(/^\d+$/.test(e) ? Number(e) : e);
	}
	return Object.freeze(n);
}
function A(e) {
	let t = D.exec(e);
	if (!t) return null;
	let [, n, r, i, a] = t;
	for (let e of [
		n,
		r,
		i
	]) if (e.length > 1 && e.startsWith("0") || !Number.isSafeInteger(Number(e))) return null;
	let o = k(a);
	return o === null ? null : {
		major: Number(n),
		minor: Number(r),
		patch: Number(i),
		prerelease: o
	};
}
function j(e, t) {
	return typeof e == "number" && typeof t == "number" ? e === t ? 0 : e < t ? -1 : 1 : typeof e == "number" ? -1 : typeof t == "number" ? 1 : e === t ? 0 : e < t ? -1 : 1;
}
function M(e, t) {
	for (let n of [
		"major",
		"minor",
		"patch"
	]) if (e[n] !== t[n]) return e[n] < t[n] ? -1 : 1;
	if (e.prerelease.length === 0 && t.prerelease.length === 0) return 0;
	if (e.prerelease.length === 0) return 1;
	if (t.prerelease.length === 0) return -1;
	let n = Math.min(e.prerelease.length, t.prerelease.length);
	for (let r = 0; r < n; r += 1) {
		let n = j(e.prerelease[r], t.prerelease[r]);
		if (n !== 0) return n;
	}
	return e.prerelease.length === t.prerelease.length ? 0 : e.prerelease.length < t.prerelease.length ? -1 : 1;
}
function N(e, t, n) {
	return {
		major: e,
		minor: t,
		patch: n,
		prerelease: Object.freeze([])
	};
}
function P(e, t) {
	if (e === "^") {
		let e = t.major > 0 ? N(t.major + 1, 0, 0) : t.minor > 0 ? N(0, t.minor + 1, 0) : N(0, 0, t.patch + 1);
		return [{
			operator: ">=",
			version: t
		}, {
			operator: "<",
			version: e
		}];
	}
	return e === "~" ? [{
		operator: ">=",
		version: t
	}, {
		operator: "<",
		version: N(t.major, t.minor + 1, 0)
	}] : [{
		operator: e,
		version: t
	}];
}
function F(e) {
	if (typeof e != "string") return null;
	let t = e.trim();
	if (t.length === 0 || t.length > 128) return null;
	let n = t.split(/\s+/);
	if (n.length === 0 || n.length > 8) return null;
	let r = [];
	try {
		for (let e of n) {
			let t = "=", n = e;
			e.startsWith(">=") || e.startsWith("<=") ? (t = e.slice(0, 2), n = e.slice(2)) : (e.startsWith(">") || e.startsWith("<") || e.startsWith("=") || e.startsWith("^") || e.startsWith("~")) && (t = e[0], n = e.slice(1));
			let i = A(n);
			if (i === null || (r.push(...P(t, i)), r.length > 16)) return null;
		}
	} catch {
		return null;
	}
	return Object.freeze({
		source: t,
		comparators: Object.freeze(r)
	});
}
function I(e) {
	return typeof e == "string" && A(e) !== null;
}
function L(e, t) {
	try {
		let n = A(e);
		if (n === null) return !1;
		let r = typeof t == "string" ? F(t) : t;
		if (!r || !Array.isArray(r.comparators) || r.comparators.length === 0 || n.prerelease.length && !r.comparators.some(({ version: e }) => e.prerelease.length && e.major === n.major && e.minor === n.minor && e.patch === n.patch)) return !1;
		for (let e of r.comparators) {
			let t = M(n, e.version);
			switch (e.operator) {
				case "=":
					if (t !== 0) return !1;
					break;
				case ">":
					if (t <= 0) return !1;
					break;
				case ">=":
					if (t < 0) return !1;
					break;
				case "<":
					if (t >= 0) return !1;
					break;
				case "<=":
					if (t > 0) return !1;
					break;
				default: return !1;
			}
		}
		return !0;
	} catch {
		return !1;
	}
}
function R(e) {
	return typeof e == "object" && !!e && typeof e.source == "string" && Array.isArray(e.comparators);
}
export { o as A, d as C, l as D, c as E, u as O, p as S, e as T, n as _, w as a, h as b, _ as c, I as d, R as f, r as g, f as h, b as i, g as j, i as k, E as l, F as m, v as n, x as o, L as p, y as r, S as s, C as t, T as u, t as v, s as w, m as x, a as y };
