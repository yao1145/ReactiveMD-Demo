import { c as e, d as t, i as n, m as r, p as i, r as a, t as o } from "./version-DAxuGOG2.js";
import { M as s, O as c, P as l, j as u, k as d, n as ee, r as te } from "./preset-core-DeZPA8IE.js";
// src/local/html/html-names.ts
var f = /* @__PURE__ */ new Set(/* @__PURE__ */ "b.strong.i.em.s.del.u.mark.sup.sub.br.hr.img.p.h1.h2.h3.h4.h5.h6.div.span.details.summary.blockquote.code.pre.ul.ol.li.a".split(".")), ne = /* @__PURE__ */ new Set([
	"div",
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6"
]);
function p(e) {
	let t = e.trim().toLowerCase();
	return t === "left" || t === "center" || t === "right" || t === "justify" ? t : null;
}
var m = /* @__PURE__ */ new Set([
	"href",
	"target",
	"rel"
]);
function h(e, t) {
	if (t?.toLowerCase() !== "_blank") return e;
	let n = [], r = /* @__PURE__ */ new Set();
	for (let t of (e ?? "").split(/[\t\n\f\r ]+/)) {
		let e = t.toLowerCase();
		t && e !== "opener" && !r.has(e) && (r.add(e), n.push(t));
	}
	for (let e of ["noopener", "noreferrer"]) r.has(e) || n.push(e);
	return n.join(" ");
}
var g = Object.freeze([
	Object.freeze({
		name: "computed",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			value: {
				kind: "string",
				required: !0
			}
		},
		structure: {
			rule: "none",
			label: "none"
		},
		rules: [{
			kind: "require-full-interpolation",
			attributes: ["value"]
		}]
	}),
	Object.freeze({
		name: "const",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			value: {
				kind: "string",
				required: !0
			}
		},
		structure: {
			rule: "none",
			label: "none"
		},
		rules: [{
			kind: "require-full-interpolation",
			attributes: ["value"]
		}]
	}),
	Object.freeze({
		name: "external",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: !0,
				required: !0
			},
			type: {
				kind: "enum",
				static: !0,
				required: !0,
				values: [
					"string",
					"number",
					"boolean",
					"string-array",
					"number-array"
				]
			}
		},
		structure: {
			rule: "none",
			label: "none"
		}
	})
]);
function re(e, t) {
	let n = Array.from({ length: t.length + 1 }, (e, t) => t);
	for (let r = 1; r <= e.length; r++) {
		let i = n[0];
		n[0] = r;
		for (let a = 1; a <= t.length; a++) {
			let o = n[a];
			n[a] = Math.min(n[a] + 1, n[a - 1] + 1, i + (e[r - 1] === t[a - 1] ? 0 : 1)), i = o;
		}
	}
	return n[t.length];
}
function ie(e, t) {
	let n, r = Infinity;
	for (let i of t) {
		let t = re(e, i);
		t < r && (n = i, r = t);
	}
	return r <= 2 ? n : void 0;
}
// src/sdk/compat-profile.ts
var _ = Object.freeze([Object.freeze({
	name: "reactive-md-config/v1@0.7.0",
	protocol: a,
	sdkRange: "0.7.0",
	targetProtocol: n,
	targetSdkRange: "0.7.0",
	preset: Object.freeze({
		id: "reactive-md/default",
		version: "0.7.0"
	}),
	legacyKeys: Object.freeze([Object.freeze({
		profile: a,
		algorithm: "external-components/v1"
	})]),
	source: "git tag v0.7.0:src/presets/default.ts and src/sdk/config.ts; docs/compatibility/compatibility-ch.md"
})]);
function v(e, t = _) {
	for (let n of t) if (n.preset.id === e.id && n.preset.version === e.version) return n;
}
function y(e = []) {
	return e.length === 0 ? _ : Object.freeze([..._, ...e]);
}
// src/sdk/assembly.ts
var b = /* @__PURE__ */ new Set([
	"protocol",
	"presets",
	"components",
	"replacementPolicy",
	"themes"
]), x = 32, S = 256, C = 32;
function w(e, t) {
	throw Error(`Invalid local SDK config (${e}): ${t}`);
}
function T(e, t) {
	return e < t ? -1 : +(e > t);
}
function E(e, t) {
	return [...e].sort((e, n) => T(t(e), t(n)));
}
function D(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function O(e) {
	if (Array.isArray(e)) return e.map(O);
	if (D(e)) {
		let t = {};
		for (let n of Object.keys(e).sort(T)) t[n] = O(e[n]);
		return t;
	}
	return e;
}
function k(e, t) {
	return JSON.stringify(O(e)) === JSON.stringify(O(t));
}
function A(e) {
	Array.isArray(e) || w("assembly.presets", "must be an array."), e.length > x && w("assembly.presets", `accepts at most ${x} packages.`);
	let t = E(e.map((e, t) => {
		try {
			return te(e);
		} catch (e) {
			w(`assembly.presets[${t}]`, e instanceof Error ? e.message : String(e));
		}
	}), (e) => e.id), n = /* @__PURE__ */ new Set();
	for (let e of t) n.has(e.id) && w("assembly.presets", `preset "${e.id}" is selected more than once.`), n.add(e.id);
	return Object.freeze(t);
}
function j(e) {
	Array.isArray(e) || w("assembly.components", "must be an array."), e.length > S && w("assembly.components", `accepts at most ${S} components.`);
	let t = E(e.map((e, t) => {
		try {
			return s(e);
		} catch (e) {
			w(`assembly.components[${t}]`, e instanceof Error ? e.message : String(e));
		}
	}), (e) => e.id);
	return Object.freeze(t);
}
function M(e) {
	Array.isArray(e) || w("assembly.themes", "must be an array."), e.length > C && w("assembly.themes", `accepts at most ${C} themes.`);
	let n = /* @__PURE__ */ new Set();
	return Object.freeze(E(e.map((e, r) => {
		D(e) || w(`assembly.themes[${r}]`, "must be an object.");
		let i = e.id, a = e.name, o = e.version;
		return (typeof i != "string" || i.length === 0) && w(`assembly.themes[${r}].id`, "must be a non-empty string."), (typeof a != "string" || a.length === 0) && w(`assembly.themes[${r}].name`, "must be a non-empty string."), typeof o == "string" && t(o) || w(`assembly.themes[${r}].version`, "must be a semantic version."), n.has(i) && w("assembly.themes", `theme id "${i}" is declared more than once.`), n.add(i), Object.freeze({ ...e });
	}), (e) => e.id));
}
function N(e) {
	D(e) || w("assembly", "must be an object.");
	for (let t of Object.keys(e)) b.has(t) || w("assembly", `unknown field "${t}".`);
	e.protocol !== "reactive-md-assembly/v1" && w("assembly.protocol", `must be "${o}".`);
	let t = e.replacementPolicy;
	return t !== "allow" && t !== "forbid" && w("assembly.replacementPolicy", "must be \"allow\" or \"forbid\"."), Object.freeze({
		protocol: o,
		presets: A(e.presets),
		components: j(e.components),
		replacementPolicy: t,
		themes: M(e.themes)
	});
}
function P(e) {
	let n = new Map(e.map((e) => [e.id, e])), r = /* @__PURE__ */ new Map(), i = [], a = (e) => {
		let o = r.get(e);
		if (o === "done") return;
		o === "visiting" && w("assembly.presets", `preset dependency cycle at "${e}".`);
		let s = n.get(e);
		s || w("assembly.presets", `missing preset dependency "${e}".`), r.set(e, "visiting");
		for (let e of E(s.dependencies ?? [], (e) => e.id)) {
			let r = n.get(e.id);
			r || w("assembly.presets", `preset "${s.id}" requires missing preset "${e.id}".`), t(e.version) || w("assembly.presets", `preset dependency "${e.id}" must use an exact version.`), r.version !== e.version && w("assembly.presets", `preset "${s.id}" requires "${e.id}" ${e.version}, but ${r.version} is installed.`), a(e.id);
		}
		r.set(e, "done"), i.push(s);
	};
	for (let e of [...n.keys()].sort(T)) a(e);
	return Object.freeze(i);
}
function F(e) {
	let { description: t, ...n } = e;
	return n;
}
function I(e) {
	return e.structure ?? u(e.children) ?? null;
}
function L(e, t) {
	for (let n of [
		"interactive",
		"static",
		"ssr",
		"offline"
	]) if (t.capabilities[n] && !e.capabilities[n]) return !1;
	return !0;
}
function R(e, t) {
	let n = e.definition, r = t.definition, i = `assembly.replacements["${n.id}"]`;
	(n.id !== r.id || n.name !== r.name) && w(i, "the replacement must keep the target id and tag name."), n.form !== r.form && w(i, "the replacement must keep the target form.");
	for (let e of Object.keys(n.props)) {
		let t = n.props[e], a = r.props[e];
		a || w(i, `the replacement removed prop "${e}".`), k(F(t), F(a)) || w(i, `the replacement changed the semantics of prop "${e}".`);
	}
	for (let e of Object.keys(r.props)) Object.hasOwn(n.props, e) || r.props[e].required === !0 && w(i, `the replacement added required prop "${e}".`);
	let a = n.bindings ?? {}, o = r.bindings ?? {}, s = Object.keys(a).sort(T);
	k(s, Object.keys(o).sort(T)) || w(i, "the replacement must keep the target binding slots unchanged.");
	for (let e of s) k(a[e], o[e]) || w(i, `the replacement changed binding slot "${e}".`);
	k(I(n), I(r)) || w(i, "the replacement changed the target child structure."), k(n.rules ?? [], r.rules ?? []) || w(i, "the replacement changed semantic rules."), k(n.slotRelations ?? [], r.slotRelations ?? []) || w(i, "the replacement changed slot relations."), n.legacyHost === !0 != (r.legacyHost === !0) && w(i, "the replacement changed legacyHost."), L(r, n) || w(i, "the replacement downgraded a declared capability.");
}
function z(e, t) {
	return e.id === t.id ? t.version === void 0 || r(t.version) !== null && i(e.version, t.version) : !1;
}
function B(e, t) {
	return Object.freeze({
		id: e.definition.id,
		name: e.definition.name,
		fromVersion: e.definition.version,
		toVersion: t.definition.version,
		fromDigest: c(e.definition),
		toDigest: c(t.definition),
		...e.origin.kind === "preset" ? { fromPreset: e.origin.id } : {},
		...t.origin.kind === "preset" ? { toPreset: t.origin.id } : {}
	});
}
function V(e, t) {
	let n = [], r = 0;
	for (let t of e) for (let e of t.components) n.push({
		definition: e,
		origin: {
			kind: "preset",
			id: t.id
		},
		index: r
	}), r += 1;
	for (let e of E(t, (e) => e.id)) n.push({
		definition: e,
		origin: { kind: "external" },
		index: r
	}), r += 1;
	return n;
}
function H(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) n.authoring !== void 0 && n.authoring.length !== 0 && t.set(n.id, new Map(n.authoring.map((e) => [e.componentId, e.authoring])));
	return t;
}
function U(e, t) {
	return t === void 0 ? e : e === void 0 ? t : Object.freeze({
		...e.title === void 0 ? {} : { title: e.title },
		...e.description === void 0 ? {} : { description: e.description },
		...e.category === void 0 ? {} : { category: e.category },
		...e.insertText === void 0 ? {} : { insertText: e.insertText },
		...t.title === void 0 ? {} : { title: t.title },
		...t.description === void 0 ? {} : { description: t.description },
		...t.category === void 0 ? {} : { category: t.category },
		...t.insertText === void 0 ? {} : { insertText: t.insertText }
	});
}
function W(e, t) {
	let n = e.origin.kind === "preset" ? t.get(e.origin.id)?.get(e.definition.id) : void 0;
	return U(e.definition.authoring, n);
}
function ae(e, t) {
	return t === void 0 || t === e.authoring ? e : s({
		...e,
		authoring: t
	});
}
function G(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = r.get(t.definition.id);
		e ? e.push(t) : r.set(t.definition.id, [t]);
	}
	let i = [], a = [];
	for (let e of r.values()) {
		if (e.length === 1) {
			let r = e[0];
			r.definition.replaces !== void 0 && (t === "forbid" && w("assembly.replacements", `replacement for "${r.definition.id}" is forbidden.`), w("assembly.replacements", `replacement for "${r.definition.id}" has no base contribution.`));
			let a = W(r, n);
			i.push({
				...r,
				position: r.index,
				...a === void 0 ? {} : { authoring: a }
			});
			continue;
		}
		let r = e.filter((e) => e.definition.replaces !== void 0);
		t === "forbid" && r.length > 0 && w("assembly.replacements", `replacement for "${e[0].definition.id}" is forbidden.`), r.length === 0 && w("assembly.components", `component id "${e[0].definition.id}" is declared more than once.`), r.length > 1 && w("assembly.replacements", `component id "${e[0].definition.id}" has more than one replacement.`), e.length > 2 && w("assembly.replacements", `component id "${e[0].definition.id}" has ambiguous base contributions.`);
		let o = r[0], s = e.filter((e) => e !== o);
		s.length !== 1 && w("assembly.replacements", `component id "${e[0].definition.id}" must have exactly one base.`);
		let c = s[0];
		c.definition.replaces !== void 0 && w("assembly.replacements", `component id "${e[0].definition.id}" uses a replacement chain.`);
		let l = o.definition.replaces;
		z(c.definition, l) || w("assembly.replacements", `replacement for "${c.definition.id}" does not match base version ${c.definition.version}.`), R(c, o);
		let u = U(W(c, n), W(o, n));
		i.push({
			...o,
			position: c.index,
			...u === void 0 ? {} : { authoring: u }
		}), a.push(B(c, o));
	}
	return i.sort((e, t) => e.position - t.position), {
		active: Object.freeze(i),
		replacements: Object.freeze(E(a, (e) => e.id))
	};
}
function K(t) {
	let n = /* @__PURE__ */ new Map(), r = new Map(t.map((e) => [e.definition.id, e.definition]));
	for (let a of t) {
		let t = a.definition, o = n.get(t.name);
		o !== void 0 && ((o.origin.kind === "preset" || a.origin.kind === "preset") && w("assembly.components", `name "${t.name}" conflicts with a built-in component "${o.definition.id}".`), w("assembly.components", `component name "${t.name}" is declared more than once by "${o.definition.id}" and "${t.id}".`)), n.set(t.name, a);
		let s = t.requires?.kernel;
		s !== void 0 && !i("0.7.0", s) && w("assembly.components", `component "${t.id}" requires kernel ${s}, but ${e} is installed.`);
		for (let e of t.dependencies ?? []) {
			let n = r.get(e.id);
			n || w("assembly.dependencies", `component "${t.id}" requires missing component "${e.id}".`), e.version !== void 0 && !i(n.version, e.version) && w("assembly.dependencies", `component "${t.id}" requires "${e.id}" ${e.version}, but version ${n.version} is installed.`);
		}
	}
	let a = /* @__PURE__ */ new Map(), o = (e, t) => {
		let n = a.get(e);
		if (n !== "done") {
			n === "visiting" && w("assembly.dependencies", `dependency cycle: ${[...t, e].join(" -> ")}.`), a.set(e, "visiting");
			for (let n of r.get(e)?.dependencies ?? []) r.has(n.id) && o(n.id, [...t, e]);
			a.set(e, "done");
		}
	};
	for (let e of [...r.keys()].sort(T)) o(e, []);
}
function q(e, t) {
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map(), i = (e, t) => {
		n.get(e.id) && w("assembly.themes", `theme id "${e.id}" is declared by both ${t} and another source.`), r.get(e.name) && w("assembly.themes", `theme name "${e.name}" is declared by both ${t} and another source.`), n.set(e.id, e), r.set(e.name, e);
	};
	for (let t of e) for (let e of t.themes ?? []) i(e, `preset:${t.id}`);
	for (let e of t) i(e, "external");
	return Object.freeze(E([...n.values()], (e) => e.id));
}
function J(e) {
	return Object.freeze(E(e.map((e) => ({
		id: e.id,
		version: e.version,
		digest: ee(e)
	})), (e) => e.id));
}
function oe(e, t, r) {
	let i = JSON.stringify({
		protocol: n,
		presets: E(e, (e) => e.id),
		registry: [...t].map((e) => ({
			id: e.id,
			name: e.name,
			version: e.version,
			digest: c(e)
		})).sort((e, t) => T(e.id, t.id)),
		replacements: E(r, (e) => e.id)
	});
	return l(i);
}
function Y(e, t) {
	let n = JSON.stringify({
		protocol: a,
		presets: [{
			id: e.id,
			version: e.version
		}],
		components: [...t].map((e) => ({
			id: e.id,
			version: e.version,
			digest: c(e)
		})).sort((e, t) => T(e.id, t.id))
	});
	return l(n);
}
function se(e, t = {}) {
	let n = P(e.presets), r = G(V(n, e.components), e.replacementPolicy, H(n));
	K(r.active);
	let i = Object.freeze(r.active.map((e) => ae(e.definition, e.authoring))), a = Object.freeze(E(r.active.filter((e) => e.origin.kind === "external").map((e) => e.definition), (e) => e.id)), o = J(n), s = q(n, e.themes), c = oe(o, i, r.replacements), l = [], u = t.legacyProfiles === void 0 || n.length !== 1 || r.replacements.length !== 0 ? void 0 : v({
		id: n[0].id,
		version: n[0].version
	}, t.legacyProfiles), d = u?.legacyKeys[0];
	return u !== void 0 && d !== void 0 && l.push(Object.freeze({
		profile: d.profile,
		key: Y(u.preset, a)
	})), Object.freeze({
		presets: o,
		components: a,
		replacements: r.replacements,
		registry: i,
		themes: s,
		key: c,
		legacyKeys: Object.freeze(l)
	});
}
function ce(e, t, r = t.legacyKeys) {
	return Object.freeze({
		protocol: n,
		assembly: e,
		key: t.key,
		presets: t.presets,
		components: t.components,
		replacements: t.replacements,
		registry: t.registry,
		themes: t.themes,
		legacyKeys: Object.freeze(r)
	});
}
function X(e) {
	return Object.freeze({
		protocol: "reactive-md-assembly-seal/v1",
		configKey: e.key,
		presets: Object.freeze(E(e.presets, (e) => e.id)),
		components: Object.freeze(E(e.registry.map(d), (e) => e.id)),
		replacements: Object.freeze(E(e.replacements, (e) => e.id)),
		legacyKeys: Object.freeze(E(e.legacyKeys, (e) => e.key))
	});
}
function le(e) {
	return l(JSON.stringify(X(e)));
}
function ue(e, t) {
	return e.key === t || e.legacyKeys.some((e) => e.key === t);
}
// src/sdk/config-validation.ts
var de = 16777216, fe = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), pe = /* @__PURE__ */ new Set([
	"protocol",
	"key",
	"assembly",
	"presets",
	"components",
	"replacements",
	"registry",
	"themes",
	"legacyKeys"
]);
function Z(e, t) {
	throw Error(`Invalid local SDK config (${e}): ${t}`);
}
function Q(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function $(e, t, n) {
	for (let r of Object.keys(e)) fe.has(r) && Z(n, `field "${r}" is not allowed.`), t.has(r) || Z(n, `unknown field "${r}".`);
}
function me(e, t, n = []) {
	if (e === void 0) return Object.freeze([t]);
	Array.isArray(e) || Z("presets", "must be an array."), e.length === 0 && Z("presets", "must select at least the default preset.");
	let r = [];
	for (let e of [t, ...n.map((e) => e.preset)]) r.some((t) => t.id === e.id && t.version === e.version) || r.push(e);
	let i = /* @__PURE__ */ new Set(), a = [];
	for (let n = 0; n < e.length; n += 1) {
		let o = e[n], s, c;
		typeof o == "string" ? s = o : Q(o) ? ((o.id === void 0 || typeof o.id != "string") && Z(`presets[${n}].id`, "must be a string."), s = o.id, o.version !== void 0 && (typeof o.version != "string" && Z(`presets[${n}].version`, "must be a string."), c = o.version)) : Z(`presets[${n}]`, "must be a preset id or preset reference.");
		let l = s === "default" ? t.id : s, u = r.filter((e) => e.id === l);
		u.length === 0 && Z(`presets[${n}]`, `unsupported preset "${s}"; local.config.migration-unsupported: no compatibility profile matches this identity.`);
		let d = c === void 0 ? u.length === 1 ? u[0] : void 0 : u.find((e) => e.version === c);
		d === void 0 && Z(`presets[${n}]`, `unsupported preset "${s}"${c === void 0 ? "" : ` version "${c}"`}; local.config.migration-unsupported: no compatibility profile matches this identity.`), i.has(d.id) && Z("presets", `"${d.id}" is selected more than once.`), a.length > 0 && a[0].id !== d.id && Z("presets", "reactive-md-config/v1 selects exactly one default preset identity."), i.add(d.id), a.push(d);
	}
	return Object.freeze(a);
}
function he(e, t) {
	if (e.components === void 0) return;
	let n = new Map(t.map((e) => [e.id, e]));
	for (let t of e.components) {
		let r = n.get(t.id);
		r && r.name === t.name && r.version === t.version && c(r) === t.digest || Z("presets", `local.config.migration-unsupported: profile "${e.name}" cannot map legacy component "${t.id}".`);
	}
}
function ge(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of e) t.add(n.name), t.add(n.id);
	return t;
}
function _e(t, n) {
	let r = new Map(t.map((e) => [e.id, e])), a = ge(n);
	for (let n of t) {
		let t = n.requires?.kernel;
		t !== void 0 && !i("0.7.0", t) && Z("requires", `component "${n.id}" requires kernel ${t}, but ${e} is installed.`);
		for (let e of n.dependencies ?? []) {
			let t = r.get(e.id)?.version ?? (a.has(e.id) ? "0.7.0" : null);
			t === null && Z("dependencies", `component "${n.id}" requires missing component "${e.id}".`), e.version !== void 0 && !i(t, e.version) && Z("dependencies", `component "${n.id}" requires "${e.id}" ${e.version}, but version ${t} is installed.`);
		}
	}
	let o = /* @__PURE__ */ new Map(), s = (e, t) => {
		let n = o.get(e);
		if (n === "done") return;
		n === "visiting" && Z("dependencies", `dependency cycle: ${[...t, e].join(" -> ")}.`), o.set(e, "visiting");
		let i = r.get(e);
		for (let n of i?.dependencies ?? []) r.has(n.id) && s(n.id, [...t, e]);
		o.set(e, "done");
	};
	for (let e of r.keys()) s(e, []);
}
function ve(e, t) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || Z("components", "must be an array."), e.length > 64 && Z("components", "accepts at most 64 external components.");
	let n = new Set([
		...t.map((e) => e.name),
		...g.map((e) => e.name),
		...f
	].map((e) => e.toLowerCase()));
	n.add("theme");
	let r = new Set(t.map((e) => e.id)), i = /* @__PURE__ */ new Set(), a = [];
	for (let t = 0; t < e.length; t += 1) {
		let o = s(e[t]);
		n.has(o.name.toLowerCase()) && Z(`components[${t}]`, `name "${o.name}" conflicts with a built-in component, HTML tag or theme declaration.`), r.has(o.id) && Z("components", `component id "${o.id}" is declared more than once.`), i.has(o.name) && Z("components", `component name "${o.name}" is declared more than once.`), r.add(o.id), i.add(o.name), a.push(o);
	}
	return _e(a, t), Object.freeze(a);
}
export { f as C, m as S, h as T, v as _, Q as a, ie as b, he as c, ce as d, ue as f, _ as g, se as h, Z as i, X as l, N as m, de as n, ve as o, Y as p, $ as r, me as s, pe as t, le as u, y as v, p as w, ne as x, g as y };
