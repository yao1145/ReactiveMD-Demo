import { a as e, i as t, s as n } from "./latex-1w7aQgD5.js";
import { d as r, n as i } from "./compiler-core-BY4xI9Vq.js";
import { n as a } from "./display-D4MXS2_1.js";
import { i as o } from "./html-DqHdWHgo.js";
import { r as s, t as c } from "./options-DZBudbaV.js";
import { n as l, r as u, t as d } from "./observability-core-Bcu7vpnl.js";
// src/local/compilation/compiler.ts
function f(e, t) {
	let n = t?.observer, i = n?.onTrace ? d() : void 0, a = i ? globalThis.performance?.now() ?? Date.now() : 0;
	i && u(n, {
		type: "compile-start",
		traceId: i,
		timestamp: Date.now()
	});
	let o = r(g(e, t));
	if (n?.onDiagnostic) {
		for (let e of o.diagnostics) l(n, e);
		for (let e of o.transientDiagnostics ?? []) l(n, e);
	}
	if (i) {
		let e = Math.max(0, Math.round((globalThis.performance?.now() ?? Date.now()) - a));
		u(n, {
			type: "compile-end",
			traceId: i,
			timestamp: Date.now(),
			status: o.ok ? "ok" : "failed",
			durationMs: e
		});
	}
	return o;
}
function p(e, t, n, r) {
	let i, a = () => globalThis.performance?.now?.() ?? Date.now(), o = a(), s = {}, l = o, u = (e) => {
		let t = a();
		s[e] = t - l, l = t;
	};
	n?.semantic?.begin(c(t));
	let d = g(e, t, (e) => {
		i = e;
	}, n, u, r);
	return s.totalMs = a() - o, {
		result: d,
		parsed: i,
		...n?.semantic ? { semantic: n.semantic.stats } : {},
		timings: s
	};
}
function m(e) {
	return {
		ok: !1,
		diagnostics: [{
			code: "local.options.invalid",
			message: e.message,
			severity: "error",
			phase: "host",
			recoverable: !1,
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: e.key,
			...e.detail === void 0 ? {} : { params: { detail: e.detail } }
		}]
	};
}
function h(r) {
	return {
		...r?.parser ? { parser: r.parser } : {},
		...r?.semantic ? { semantic: r.semantic } : {},
		...r?.rowPlans ? { rowPlans: r.rowPlans } : {},
		display: r?.semantic ? (e, t) => r.semantic.display(e, t) : a,
		htmlFragment: o,
		plotMath: {
			kind: n,
			gridSize: e,
			compile: t
		}
	};
}
function g(e, t, n, r, a, o) {
	let c = s(t);
	return c.ok ? i(e, t, c, h(r), n, a, o) : m(c);
}
export { p as n, f as t };
