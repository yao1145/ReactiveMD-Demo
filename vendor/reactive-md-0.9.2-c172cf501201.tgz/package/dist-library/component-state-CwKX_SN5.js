import { c as e, l as t, n, t as r } from "./identity-BUx0Q_-d.js";
// src/runtime-services/network.ts
var i = 65536, a = Object.freeze({
	code: "unavailable",
	message: "This channel operation is unavailable."
}), o = Object.freeze({
	code: "cancelled",
	message: "The operation was cancelled."
}), s = Object.freeze({
	code: "invalid-data",
	message: "The channel data is invalid."
}), c = Object.freeze({
	code: "transport",
	message: "The channel could not communicate with its endpoint."
}), l = Object.freeze({
	code: "rejected",
	message: "A channel listener failed."
}), u = 0;
function d(e) {
	return {
		ok: !1,
		error: e
	};
}
var f = Object.freeze({
	supports: () => !1,
	submit: async () => d(a),
	subscribe(e, t) {
		let n = !0;
		return queueMicrotask(() => {
			if (n) try {
				t({
					type: "error",
					error: a
				});
			} catch {}
		}), () => {
			n = !1;
		};
	}
});
function p(e = i) {
	if (!Number.isSafeInteger(e) || e < 1) throw TypeError("A channel byte budget must be a positive integer.");
	return e;
}
function m(e, t) {
	let n = t;
	function r(e) {
		if (n -= e, n < 0) throw RangeError();
	}
	function i(e, t) {
		if (r(1), t > 64) throw RangeError();
		if (e === null || typeof e == "boolean") return e;
		if (typeof e == "string") return r(e.length), e;
		if (typeof e == "number" && Number.isFinite(e)) return e;
		if (Array.isArray(e)) {
			if (e.length > n) throw RangeError();
			let r = [];
			for (let n = 0; n < e.length; n += 1) {
				let a = Object.getOwnPropertyDescriptor(e, String(n));
				if (!a || !("value" in a)) throw TypeError();
				r.push(i(a.value, t + 1));
			}
			return Object.freeze(r);
		}
		if (typeof e != "object" || !e) throw TypeError();
		let a = Object.getPrototypeOf(e);
		if (a !== Object.prototype && a !== null) throw TypeError();
		let o = Object.create(null);
		for (let n of Object.keys(e)) {
			r(n.length);
			let a = Object.getOwnPropertyDescriptor(e, n);
			if (!a || !("value" in a)) throw TypeError();
			o[n] = i(a.value, t + 1);
		}
		return Object.freeze(o);
	}
	let a = i(e, 0);
	if (new TextEncoder().encode(JSON.stringify(a)).length > t) throw RangeError();
	return a;
}
function h(e) {
	if (!e.ok) return e;
	try {
		let t = Object.getOwnPropertyDescriptor(e, "data");
		if (t && "value" in t && t.value !== void 0) return {
			ok: !0,
			data: m(t.value, i)
		};
	} catch {}
	return { ok: !0 };
}
function g(e, t) {
	let n = t(e);
	if (n !== !0) return typeof n == "string" && n.trim() ? Object.freeze({
		code: "invalid-data",
		message: n
	}) : s;
}
function _(e) {
	if (!e) return {
		network: f,
		bindExternalValues: () => void 0,
		dispose() {}
	};
	let t = /* @__PURE__ */ new Map(), n = /* @__PURE__ */ new Map();
	for (let [r, i] of Object.entries(e.channels)) {
		let { submit: e, subscribe: a, mapExternalValues: o } = i;
		if (e && (typeof e.validate != "function" || typeof e.send != "function")) throw TypeError("A submit channel requires a validator and a send function.");
		if (a && (typeof a.validate != "function" || typeof a.open != "function")) throw TypeError("A subscription channel requires a validator and an open function.");
		if (o !== void 0) {
			if (!a || typeof o != "function") throw TypeError("Mapping external values requires a subscription and a mapper function.");
			n.set(r, o.bind(i));
		}
		t.set(r, {
			...e && { submit: {
				maxBytes: p(e.maxBytes),
				validate: e.validate.bind(e),
				send: e.send.bind(e)
			} },
			...a && { subscribe: {
				maxBytes: p(a.maxBytes),
				validate: a.validate.bind(a),
				open: a.open.bind(a)
			} }
		});
	}
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Set(), _ = /* @__PURE__ */ new Map(), v = !1;
	function y(e) {
		let t = r.get(e);
		return t || r.set(e, t = new AbortController()), t.signal;
	}
	function b(t, n) {
		try {
			t.notify(Object.freeze(n));
		} catch {
			try {
				e?.onListenerError?.(l);
			} catch {}
		}
	}
	function x(e) {
		try {
			e?.();
		} catch {}
	}
	function S(e, t) {
		_.delete(e), t.listeners.clear(), t.events.length = 0, t.controller.abort(), x(t.release);
	}
	function C(e, t) {
		if (!(v || e.controller.signal.aborted) && (e.events.push({
			event: t,
			recipients: [...e.listeners],
			status: e.status
		}), !e.dispatching)) {
			e.dispatching = !0;
			try {
				for (let t = 0; t < e.events.length; t += 1) {
					let { event: n, recipients: r, status: i } = e.events[t];
					for (let t of r) e.listeners.has(t) && (t.initial || (t.initial = !0, n.type !== "status" && b(t, {
						type: "status",
						state: i
					})), e.listeners.has(t) && b(t, n));
				}
			} finally {
				e.events.length = 0, e.dispatching = !1;
			}
		}
	}
	function w(e, t, n) {
		let r = t.controller.signal;
		if (r.aborted) return;
		let i = (e) => {
			r.aborted || t.status === e || (t.status = e, C(t, {
				type: "status",
				state: e
			}));
		}, a = (e) => {
			C(t, {
				type: "error",
				error: Object.freeze({ ...e })
			});
		}, o = (e) => {
			if (r.aborted) return;
			let i, o;
			try {
				i = m(e, n.maxBytes ?? 65536), o = g(i, n.validate);
			} catch {
				a(s);
				return;
			}
			o ? a(o) : C(t, {
				type: "data",
				value: i
			});
		}, l = () => {
			r.aborted || (a(c), i("closed"));
		}, u = (e) => {
			r.aborted ? x(e) : t.release = e;
		};
		try {
			let t = n.open({
				signal: r,
				sessionSignal: y(e),
				status: i,
				error: a,
				data: o
			});
			typeof t == "function" ? u(t) : Promise.resolve(t).then(u, l);
		} catch {
			l();
		}
	}
	let T = {
		supports(e, n) {
			return !v && (n === "submit" || n === "subscribe") && t.get(e)?.[n] !== void 0;
		},
		async submit(e, n, r) {
			let l = v ? void 0 : t.get(e)?.submit;
			if (!l) return d(a);
			if (r?.signal?.aborted) return d(o);
			let f;
			try {
				let e = m(n, l.maxBytes ?? 65536);
				if (typeof e != "object" || !e || Array.isArray(e)) return d(s);
				f = e;
				let t = g(f, l.validate);
				if (t) return d(t);
			} catch {
				return d(s);
			}
			let p = r?.signal;
			if (v || p?.aborted) return d(o);
			let _ = new AbortController();
			return new Promise((t) => {
				let n = !1, a = (e) => {
					n || (n = !0, p?.removeEventListener("abort", s), i.delete(s), t(h(e)));
				}, s = () => {
					a(d(o)), _.abort();
				};
				i.add(s), p?.addEventListener("abort", s, { once: !0 });
				try {
					let t = l.send(f, {
						signal: _.signal,
						sessionSignal: y(e),
						requestId: String(++u),
						...r?.idempotencyKey === void 0 ? {} : { idempotencyKey: r.idempotencyKey }
					});
					Promise.resolve(t).then(a, () => a(d(c)));
				} catch {
					a(d(c));
				}
			});
		},
		subscribe(e, n) {
			if (v) return f.subscribe(e, n);
			let r = {
				notify: n,
				initial: !1
			}, i = t.get(e)?.subscribe;
			if (!i) {
				let e = !0;
				return queueMicrotask(() => {
					e && !v && b(r, {
						type: "error",
						error: a
					});
				}), () => {
					e = !1;
				};
			}
			let o = _.get(e), s = o ?? {
				controller: new AbortController(),
				listeners: /* @__PURE__ */ new Set(),
				events: [],
				status: "connecting",
				dispatching: !1
			};
			return s.listeners.add(r), o || _.set(e, s), queueMicrotask(() => {
				s.listeners.has(r) && !r.initial && (r.initial = !0, b(r, {
					type: "status",
					state: s.status
				})), o || w(e, s, i);
			}), () => {
				s.listeners.delete(r) && s.listeners.size === 0 && S(e, s);
			};
		}
	};
	return {
		network: Object.freeze(T),
		bindExternalValues(e) {
			if (v || n.size === 0) return;
			let t = [...n].map(([t, n]) => T.subscribe(t, (t) => {
				if (t.type !== "data") return;
				let r = n(t.value);
				r !== void 0 && e(r);
			}));
			return () => {
				for (let e of t) e();
			};
		},
		dispose() {
			if (!v) {
				v = !0;
				for (let e of i) e();
				for (let [e, t] of _) S(e, t);
				for (let e of r.values()) e.abort();
				r.clear(), t.clear(), n.clear();
			}
		}
	};
}
// src/runtime-services/random.ts
var v = "mulberry32", y = 1;
function b(e) {
	return Object.freeze({
		algorithm: v,
		version: 1,
		state: t(e)
	});
}
function x(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return null;
	let n = e;
	if (n.algorithm !== "mulberry32" || n.version !== 1 || typeof n.state != "number" || !Number.isFinite(n.state)) return null;
	let r = t(n.state);
	return r === n.state ? Object.freeze({
		algorithm: v,
		version: 1,
		state: r
	}) : null;
}
function S(e) {
	let n = t(e.state + 1831565813), r = Math.imul(n ^ n >>> 15, n | 1);
	return r ^= r + Math.imul(r ^ r >>> 7, r | 61), {
		value: ((r ^ r >>> 14) >>> 0) / 4294967296,
		state: Object.freeze({
			algorithm: v,
			version: 1,
			state: n
		})
	};
}
function C(e, t, n) {
	let r = S(e);
	if (!Number.isFinite(t) || !Number.isFinite(n)) return {
		value: 0,
		state: r.state
	};
	let i = Math.ceil(Math.min(t, n)), a = Math.floor(Math.max(t, n));
	return a < i ? {
		value: i,
		state: r.state
	} : {
		value: i + Math.floor(r.value * (a - i + 1)),
		state: r.state
	};
}
function w(e, t) {
	let n = t.slice(), r = e;
	for (let e = n.length - 1; e > 0; --e) {
		let t = C(r, 0, e);
		r = t.state;
		let i = n[e];
		n[e] = n[t.value], n[t.value] = i;
	}
	return {
		items: n,
		state: r
	};
}
function T(e, t) {
	return b(n(e, t));
}
function E(e, t = .5) {
	let n = S(e);
	return {
		value: n.value < t,
		state: n.state
	};
}
// src/runtime-services/component-state.ts
var D = "reactive-md-component-state/v1", O = "reactive-md-component-state-document/v1", k = 16384, A = 262144, j = 16, M = 1e4, N = 1e5, P = 1048576, F = 128, I = 64, L = 512, R = 1e6, z = 128, B = /[\u0000-\u001f\u007f-\u009f]/, V = new TextEncoder();
function H(e, t, n = "error") {
	return {
		code: e,
		message: t,
		severity: n,
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function U(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function W(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function G(e) {
	return typeof e == "string" && e.length > 0 && e.length <= z && !B.test(e) && W(e);
}
function K(e, t, n) {
	return t === void 0 || e === t || n.includes(e);
}
function q(e, t) {
	if (e === null) return null;
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw TypeError("numbers must be finite");
		return e;
	}
	if (typeof e == "string") {
		if (e.length > 1e5) throw RangeError(`strings exceed ${N} characters`);
		if (!W(e)) throw TypeError("strings must be well-formed Unicode");
		return e;
	}
	if (t >= 16) throw RangeError("nesting exceeds 16 levels");
	if (Array.isArray(e)) {
		if (e.length > 1e4) throw RangeError(`arrays exceed ${M} items`);
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("arrays cannot use symbol keys");
		return e.map((e) => q(e, t + 1));
	}
	if (U(e)) {
		if (Object.getOwnPropertySymbols(e).length > 0) throw TypeError("objects cannot use symbol keys");
		let n = Object.keys(e);
		if (n.length > 1e4) throw RangeError(`objects exceed ${M} keys`);
		let r = {};
		for (let i of n) {
			if (i === "__proto__") throw TypeError("the key \"__proto__\" is not allowed");
			if (i.length > 1e5) throw RangeError(`keys exceed ${N} characters`);
			if (!W(i)) throw TypeError("keys must be well-formed Unicode");
			r[i] = q(e[i], t + 1);
		}
		return r;
	}
	throw TypeError("values must be JSON-safe primitives, arrays or plain objects");
}
function J(e) {
	return q(e, 0);
}
function Y(e) {
	return Object.freeze({
		...e,
		data: q(e.data, 0),
		...e.random === void 0 ? {} : { random: x(e.random) ?? e.random }
	});
}
function X(e) {
	if (!U(e)) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.shape", "A component state record must be a plain object.")]
	};
	let t = /* @__PURE__ */ new Set([
		"format",
		"component",
		"componentVersion",
		"stateVersion",
		"key",
		"documentId",
		"data",
		"random"
	]);
	for (let n of Object.keys(e)) if (!t.has(n)) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.key", `Unknown component state key "${n}".`)]
	};
	if (e.format !== "reactive-md-component-state/v1") return {
		ok: !1,
		diagnostics: [H("local.runtime.state.format", `Unsupported component state format; expected "${D}".`)]
	};
	let n = e.component;
	if (typeof n != "string" || n.trim() === "" || n.length > F) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.component", "Component name must be a non-empty string.")]
	};
	let r = e.componentVersion;
	if (typeof r != "string" || r.trim() === "" || r.length > I) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.component-version", "Component version must be a non-empty string.")]
	};
	let i = e.stateVersion;
	if (typeof i != "number" || !Number.isInteger(i) || i < 0 || i > R) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.version", "State version must be a non-negative integer.")]
	};
	let a = e.key;
	if (typeof a != "string" || a.trim() === "" || a.length > L) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.key-name", "State key must be a non-empty string.")]
	};
	let o = e.documentId;
	if (o !== void 0 && (typeof o != "string" || o.trim() === "" || o.length > 256)) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.document", "State documentId must be a non-empty string.")]
	};
	let s;
	try {
		s = J(e.data);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [H("local.runtime.state.data", `Invalid component state data: ${e instanceof Error ? e.message : String(e)}.`)]
		};
	}
	let c;
	if (e.random !== void 0 && (c = x(e.random) ?? void 0, c === void 0)) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.random", "Invalid random state.")]
	};
	let l = {
		format: D,
		component: n,
		componentVersion: r,
		stateVersion: i,
		key: a,
		...o === void 0 ? {} : { documentId: o },
		data: s,
		...c === void 0 ? {} : { random: c }
	};
	return V.encode(JSON.stringify(l)).length > 16384 ? {
		ok: !1,
		diagnostics: [H("local.runtime.state.size", `Component state exceeds the ${k}-byte limit.`)]
	} : {
		ok: !0,
		record: Object.freeze(l)
	};
}
function Z(e) {
	let t = e;
	if (typeof e == "string") {
		if (e.length > 1048576) return {
			ok: !1,
			diagnostics: [H("local.runtime.state.size", "The component state payload is too large.")]
		};
		try {
			t = JSON.parse(e);
		} catch {
			return {
				ok: !1,
				diagnostics: [H("local.runtime.state.json", "The component state payload is not valid JSON.")]
			};
		}
	}
	if (!U(t)) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.shape", "The component state document must be a plain object.")]
	};
	if (t.format !== "reactive-md-component-state-document/v1") return {
		ok: !1,
		diagnostics: [H("local.runtime.state.document-format", `Unsupported component state document format; expected "${O}".`)]
	};
	let n = t.configKey;
	if (n !== void 0 && !G(n)) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.config-key", "The component state configKey must be a non-empty bounded string.")]
	};
	if (!U(t.records)) return {
		ok: !1,
		diagnostics: [H("local.runtime.state.records", "Component state records must be a plain object.")]
	};
	let r = {}, i = [], a = [], o = 0;
	for (let e of Object.keys(t.records)) {
		let n = X(t.records[e]);
		n.ok ? n.record.key === e ? (o += V.encode(JSON.stringify(n.record)).length, o > 262144 ? (a.push(e), i.push(H("local.runtime.state.total-size", `Component state exceeds the ${A}-byte document limit.`))) : r[e] = n.record) : (a.push(e), i.push(H("local.runtime.state.key-mismatch", `Component state record "${e}" declares a different key "${n.record.key}".`))) : (a.push(e), i.push(...n.diagnostics));
	}
	return {
		ok: !0,
		...n === void 0 ? {} : { configKey: n },
		records: r,
		diagnostics: i,
		skipped: a
	};
}
function Q(e) {
	let t = Z(e);
	if (!t.ok) return t;
	let n = {};
	for (let [e, r] of Object.entries(t.records)) n[e] = r;
	return {
		ok: !0,
		document: Object.freeze({
			format: O,
			...t.configKey === void 0 ? {} : { configKey: t.configKey },
			records: Object.freeze(n)
		}),
		records: Object.freeze(n),
		diagnostics: t.diagnostics,
		skipped: t.skipped
	};
}
function $(t) {
	let n = e(t), i = t.sourceDigest, a = t.knownKeys, o = t.configKey;
	if (o !== void 0 && !G(o)) throw TypeError("configKey must be a non-empty bounded string.");
	let s = Object.freeze((t.legacyConfigKeys ?? []).filter(G)), c = t.writeDelayMs ?? 0;
	if (typeof c != "number" || !Number.isFinite(c) || c < 0) throw TypeError("writeDelayMs must be a non-negative finite number.");
	let l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Set(), f = /* @__PURE__ */ new Set(), p = [], m = t.storage, h = null, g = null, _ = !1, v = () => {
		for (let e of f) e();
	};
	function y() {
		if (m === void 0) return !0;
		try {
			let e = w.snapshot();
			return Object.keys(e.records).length === 0 ? m.remove() : m.write(e), h = null, !0;
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return t !== h && (h = t, p.push(H("local.runtime.state.storage", `The component state could not be persisted: ${t}`, "warning"))), !1;
		}
	}
	let b = () => {
		g !== null && (clearTimeout(g), g = null);
	};
	function x() {
		_ && (b(), y() && (_ = !1));
	}
	let S = () => {
		m !== void 0 && (c <= 0 ? y() : (_ = !0, g === null && (g = setTimeout(() => {
			g = null, x();
		}, Math.min(c, 2147483647)))));
	}, C = (e) => {
		let t = 0;
		for (let [n, r] of l) n !== e && (t += V.encode(JSON.stringify(r)).length);
		return t;
	}, w = {
		documentId: n,
		sourceDigest: i,
		key(e) {
			return r({
				documentId: n,
				sourceDigest: i,
				nodeId: e.nodeId,
				stateKey: e.stateKey
			});
		},
		handle(e) {
			let t = w.key({
				nodeId: e.nodeId,
				stateKey: e.stateKey
			}), r = u.get(t), i = !1;
			r !== void 0 && r !== e.nodeId ? (i = !0, d.has(t) || (d.add(t), p.push(H("local.runtime.state.duplicate-key", `Component state key "${t}" is used by more than one component instance.`)))) : u.set(t, e.nodeId);
			let a = {
				key: t,
				component: e.component,
				componentVersion: e.componentVersion,
				duplicate: i,
				load() {
					if (i) return null;
					let e = l.get(t);
					return e === void 0 ? null : Y(e);
				},
				save(r, a) {
					if (i) return {
						ok: !1,
						diagnostics: [H("local.runtime.state.duplicate-key", `Component state key "${t}" is used by more than one component instance.`)]
					};
					let o = a?.version ?? e.stateVersion ?? 0, s = X({
						format: D,
						component: e.component,
						componentVersion: e.componentVersion,
						stateVersion: o,
						key: t,
						documentId: n,
						data: r,
						...a?.random === void 0 ? {} : { random: a.random }
					});
					if (!s.ok) return {
						ok: !1,
						diagnostics: s.diagnostics
					};
					let c = V.encode(JSON.stringify(s.record)).length;
					return C(t) + c > 262144 ? {
						ok: !1,
						diagnostics: [H("local.runtime.state.total-size", `Component state exceeds the ${A}-byte document limit.`)]
					} : (l.set(t, s.record), S(), v(), {
						ok: !0,
						diagnostics: [],
						record: Y(s.record)
					});
				},
				clear() {
					i || l.delete(t) && (S(), v());
				}
			};
			return Object.freeze(a);
		},
		load(e) {
			let t = l.get(e);
			return t === void 0 ? null : Y(t);
		},
		clear(e) {
			l.delete(e) && (S(), v());
		},
		snapshot() {
			let e = {};
			for (let [t, n] of l) e[t] = Y(n);
			return Object.freeze({
				format: O,
				...o === void 0 ? {} : { configKey: o },
				records: Object.freeze(e)
			});
		},
		restore(e) {
			let t = Z(e);
			if (!t.ok) return p.push(...t.diagnostics), {
				accepted: [],
				skipped: [],
				diagnostics: t.diagnostics
			};
			if (t.configKey !== void 0 && !K(t.configKey, o, s)) {
				let e = [.../* @__PURE__ */ new Set([...t.skipped, ...Object.keys(t.records)])];
				return t.diagnostics.push(H("local.runtime.state.config-mismatch", `Saved component state belongs to configuration "${t.configKey}", not "${o}".`, "warning")), p.push(...t.diagnostics), {
					accepted: [],
					skipped: e,
					diagnostics: t.diagnostics
				};
			}
			let r = [], i = typeof a == "function" ? a() : a;
			for (let [e, a] of Object.entries(t.records)) a.documentId !== void 0 && a.documentId !== n ? (t.skipped.push(e), t.diagnostics.push(H("local.runtime.state.document-mismatch", `Saved state key "${e}" belongs to a different document.`))) : i !== void 0 && !i.has(e) ? (t.skipped.push(e), t.diagnostics.push(H("local.runtime.state.unknown-component", `Saved state key "${e}" does not match any component in this document.`))) : (l.set(e, a), r.push(e));
			return t.diagnostics.length && p.push(...t.diagnostics), r.length && v(), {
				accepted: r,
				skipped: t.skipped,
				diagnostics: t.diagnostics
			};
		},
		flush() {
			x();
		},
		diagnostics() {
			return Object.freeze([...p]);
		},
		subscribe(e) {
			return f.add(e), () => {
				f.delete(e);
			};
		}
	}, T = t.initial;
	if (T === void 0 && m !== void 0) try {
		let e = m.read();
		e !== null && (T = e);
	} catch (e) {
		let t = e instanceof Error ? e.message : String(e);
		p.push(H("local.runtime.state.storage", `The component state could not be read: ${t}`, "warning"));
	}
	return T !== void 0 && w.restore(T), Object.freeze(w);
}
export { f as S, E as _, P as a, i as b, A as c, v as d, y as f, x as g, S as h, j as i, $ as l, T as m, D as n, M as o, b as p, k as r, N as s, O as t, Q as u, C as v, _ as x, w as y };
