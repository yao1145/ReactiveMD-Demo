import { readFileSync } from "node:fs";
// src/export-assets/index.ts
/**
* Build-time manifest for the files hosts embed in exported HTML.
* Node-only: this subpath reads the installed package and never enters a
* browser, React or compiler graph.
*/
var EXPORT_ASSETS_PROTOCOL = "reactive-md-export-assets/v1";
var ASSETS = Object.freeze([
	Object.freeze({
		id: "base-css",
		specifier: "reactive-md/styles.css",
		description: "Document stylesheet used by exported HTML and standalone pages."
	}),
	Object.freeze({
		id: "print-css",
		specifier: "reactive-md/print.css",
		description: "Print stylesheet appended after the base stylesheet."
	}),
	Object.freeze({
		id: "notices",
		specifier: "reactive-md/notices",
		description: "Third-party license notices embedded in exported HTML."
	}),
	Object.freeze({
		id: "package-json",
		specifier: "reactive-md/package.json",
		description: "Installed package metadata; exports record its version as the generator version."
	}),
	Object.freeze({
		id: "runtime",
		specifier: "reactive-md/assets/standalone.js",
		description: "Standalone browser runtime embedded in interactive exports."
	})
]);
var MANIFEST = Object.freeze({
	protocol: EXPORT_ASSETS_PROTOCOL,
	assets: ASSETS
});
/** The frozen manifest. Identical object on every call. */
function listExportAssets() {
	return MANIFEST;
}
function entryFor(id) {
	const entry = ASSETS.find((asset) => asset.id === id);
	if (!entry) throw new TypeError(`Unknown reactive-md export asset: ${String(id)}. Known ids: ${ASSETS.map((asset) => asset.id).join(", ")}.`);
	return entry;
}
/** File URL of an asset, resolved through the installed package exports. */
function resolveExportAsset(id) {
	return new URL(import.meta.resolve(entryFor(id).specifier));
}
/** UTF-8 contents of an asset. */
function readExportAsset(id) {
	return readFileSync(resolveExportAsset(id), "utf8");
}
export { EXPORT_ASSETS_PROTOCOL, listExportAssets, readExportAsset, resolveExportAsset };
