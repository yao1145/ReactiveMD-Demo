import { s as e } from "./version-DAxuGOG2.js";
import { G as t } from "./sdk-core-BG-HbMwE.js";
import { r as n } from "./package-core-pt508dWN.js";
// src/components/mount-preset.ts
function r(r, i, a = []) {
	return n({
		protocol: e,
		preset: r,
		components: r.components.map((e) => t(e, { render: i[e.name] })),
		resources: a
	});
}
export { r as t };
