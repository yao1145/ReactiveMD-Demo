import { n as e } from "./sdk-core-BG-HbMwE.js";
import { a as t } from "./LocalDocumentView-X4xfZ_DD.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
