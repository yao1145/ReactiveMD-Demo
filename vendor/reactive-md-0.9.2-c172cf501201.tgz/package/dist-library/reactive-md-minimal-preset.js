import { o as e } from "./preset-core-DeZPA8IE.js";
import { t } from "./plugin-packs-Bh1HhLym.js";
// src/presets/minimal.ts
var n = t(e, [
	"input",
	"textarea",
	"number",
	"slider",
	"toggle",
	"date",
	"select",
	"option",
	"text",
	"if",
	"alert",
	"badge",
	"panel",
	"card",
	"grid",
	"section",
	"jump",
	"anchor"
]);
export { n as default, n as minimalPreset };
