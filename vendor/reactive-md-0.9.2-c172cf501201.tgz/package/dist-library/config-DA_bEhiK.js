import { i as e, r as t, t as n } from "./version-DAxuGOG2.js";
import { n as r, r as i } from "./document-theme-Cvvc_EOe.js";
import { _ as a, a as o, c as s, d as c, g as l, h as u, i as d, m as f, n as p, o as ee, p as te, r as m, s as ne, t as h, v as g } from "./config-validation-D3D7Dy2J.js";
import { A as re, M as _, P as ie, n as ae, r as oe } from "./preset-core-DeZPA8IE.js";
import v from "./reactive-md-default-preset.js";
// src/themes/contract.ts
var se = "reactive-md-styles-1", ce = Object.freeze([
	"rmd.reset",
	"rmd.defaults",
	"rmd.components",
	"rmd.themes",
	"rmd.overrides"
]), y = "rmd.themes", b = `@layer ${ce.join(", ")};`, le = 128, ue = 32, de = 128, x = 262144, S = 524288, fe = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/, pe = /^[a-z][a-z0-9._/-]*$/, me = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/, he = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/, ge = /^(?::root|html|body)(?![A-Za-z0-9_-])/i, _e = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]), ve = 256, ye = /* @__PURE__ */ new Set([
	"serif",
	"sans-serif",
	"monospace",
	"cursive",
	"fantasy",
	"system-ui",
	"ui-serif",
	"ui-sans-serif",
	"ui-monospace",
	"ui-rounded",
	"math",
	"emoji",
	"fangsong",
	"-apple-system",
	"blinkmacsystemfont"
]), C = /* @__PURE__ */ new Set([
	"inherit",
	"initial",
	"unset",
	"revert",
	"revert-layer"
]), be = /* @__PURE__ */ new Set([
	"caption",
	"icon",
	"menu",
	"message-box",
	"small-caption",
	"status-bar"
]), xe = /* @__PURE__ */ new Set([
	"xx-small",
	"x-small",
	"small",
	"medium",
	"large",
	"x-large",
	"xx-large",
	"xxx-large",
	"smaller",
	"larger"
]), Se = /^rmd-theme-([a-z][a-z0-9-]*)-font-([0-9a-f]+)$/;
function w(e, t) {
	return /* @__PURE__ */ Error(`Invalid local theme ${e}: ${t}`);
}
function Ce(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function T(e, t) {
	if (!Ce(e)) throw w(t, "must be an object.");
	return e;
}
function E(e, t) {
	if (typeof e != "string" || e.length === 0) throw w(t, "must be a non-empty string.");
	if (e.length > le) throw w(t, `must not exceed ${le} characters.`);
	if (!fe.test(e)) throw w(t, `"${e}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return e;
}
function D(e, t) {
	if (!i(e)) throw w(t, "must be a lowercase kebab-case name that starts with a letter.");
	if (e === "default") throw w(t, "must not replace the reserved built-in \"default\" theme.");
	return e;
}
function O(e, t) {
	if (typeof e != "string" || !me.test(e)) throw w(t, "must be a semantic version such as \"1.0.0\".");
	return e;
}
function we(e, t) {
	if (e === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(e)) throw w(t, "must be an array of \"light\" and \"dark\".");
	let n = [];
	for (let r of e) {
		if (r !== "light" && r !== "dark") throw w(t, "may only contain \"light\" and \"dark\".");
		if (n.includes(r)) throw w(t, `must not repeat "${r}".`);
		n.push(r);
	}
	if (!n.includes("light") || !n.includes("dark")) throw w(t, "must declare both \"light\" and \"dark\".");
	return Object.freeze(n);
}
function k(e, t) {
	let n = e[t], r = t + 1;
	for (; r < e.length;) if (e[r] === "\\") r += 2;
	else {
		if (e[r] === n) return r + 1;
		r += 1;
	}
	return e.length;
}
function A(e, t, n, r) {
	let i = 0;
	for (let a = t; a < e.length; a += 1) {
		let t = e[a];
		if (t === "\"" || t === "'") a = k(e, a) - 1;
		else if (t === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === n) i += 1;
		else if (t === r && (--i, i === 0)) return a + 1;
	}
	return e.length;
}
function Te(e, t, n) {
	let r = t + 3;
	for (; r < e.length && /\s/.test(e[r]);) r += 1;
	if (e[r] !== "(") throw w(n, "has a malformed url() value.");
	for (r += 1; r < e.length && /\s/.test(e[r]);) r += 1;
	let i = e[r];
	if (i === "\"" || i === "'") {
		let t = e.indexOf(i, r + 1);
		if (t < 0) throw w(n, "has an unterminated url() string.");
		let a = e.slice(r + 1, t);
		for (r = t + 1; r < e.length && /\s/.test(e[r]);) r += 1;
		if (e[r] !== ")") throw w(n, "has a malformed url() value.");
		return {
			value: a.trim(),
			end: r + 1
		};
	}
	let a = e.indexOf(")", r);
	if (a < 0) throw w(n, "has an unterminated url() value.");
	return {
		value: e.slice(r, a).trim(),
		end: a + 1
	};
}
function Ee(e, t, n, r) {
	let i = t;
	for (; i < e.length && e[i] !== "(";) i += 1;
	if (i >= e.length) throw w(r, `has a malformed ${n}() value.`);
	let a = A(e, i, "(", ")");
	if (a <= i + 1 || e[a - 1] !== ")") throw w(r, `has an unterminated ${n}() value.`);
	return {
		body: e.slice(i + 1, a - 1),
		end: a
	};
}
function De(e, t) {
	let n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (r === "\"" || r === "'") {
			let i = k(e, n);
			if (i > e.length || e[i - 1] !== r) throw w(t, "has an unterminated image-set() string.");
			let a = e.slice(n + 1, i - 1).trim();
			if (!/^data:/i.test(a)) throw w(t, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			n = i;
		} else if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else n += 1;
	}
}
function Oe(e, t, n = !1) {
	if (e.toLowerCase().includes("</style")) throw w(t, "must not contain a closing style tag.");
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = k(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else {
			if (i === "\\") throw w(t, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
			if (i === "@" && /^@import\b/i.test(e.slice(r, r + 8))) throw w(t, "must not use @import; inline every resource.");
			if ((i === "i" || i === "I" || i === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(e.slice(r, r + 24))) {
				let { body: n } = Ee(e, r, "image-set", t);
				De(n, t), r += 1;
			} else if ((i === "u" || i === "U") && /^url\s*\(/i.test(e.slice(r, r + 12))) {
				let i = Te(e, r, t);
				if (!/^data:/i.test(i.value) && !(n && i.value.startsWith("#"))) throw w(t, "may only reference data: URLs; network and file URLs are not allowed.");
				r = i.end;
			} else {
				if ((i === "e" || i === "E") && /^expression\s*\(/i.test(e.slice(r, r + 16))) throw w(t, "must not use CSS expression().");
				r += 1;
			}
		}
	}
}
function ke(e) {
	if (typeof e != "string" || e.length > 4194304) return !1;
	try {
		return Oe(e, "css", !0), !0;
	} catch {
		return !1;
	}
}
function Ae(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		if (o === "\"" || o === "'") a = k(e, a) - 1;
		else if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else o === "\\" ? a += 1 : o === "(" ? r += 1 : o === ")" ? r = Math.max(0, r - 1) : o === "[" ? i += 1 : o === "]" ? i = Math.max(0, i - 1) : o === "," && r === 0 && i === 0 && (t.push(e.slice(n, a)), n = a + 1);
	}
	return t.push(e.slice(n)), t;
}
function je(e, t) {
	let n = e.trim(), r = `[data-rmd-theme="${t}"]`, i = he.exec(n);
	return i ? `${r}${n.slice(i[0].length)}` : `${r} ${n}`;
}
function j(e, t) {
	let n = t;
	for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
	else if (e[n] === "/" && e[n + 1] === "*") {
		let t = e.indexOf("*/", n + 2);
		n = t < 0 ? e.length : t + 2;
	} else break;
	return n;
}
function Me(e, t) {
	let n = e.toLowerCase(), r = /:has\s*\(/g;
	for (let i = r.exec(n); i; i = r.exec(n)) {
		if (r.lastIndex = i.index + 1, i.index >= t) continue;
		let n = i.index + i[0].length - 1, a = A(e, n, "(", ")"), o = e.slice(n + 1, Math.max(n + 1, a - 1));
		for (let t of Ae(o)) if (/^\s*[+~]/.test(t)) throw w("theme.css", `selector "${e.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
function Ne(e) {
	let t = e.trim();
	if (t === "") return;
	if (t[0] === "+" || t[0] === "~") throw w("theme.css", `selector "${t}" begins with a sibling combinator and cannot be scoped.`);
	let n = he.exec(t);
	if (n) {
		let e = n[0].length;
		for (; e < t.length;) {
			let n = t[e];
			if (/\s/.test(n) || n === "+" || n === "~" || n === ">" || n === ",") break;
			n === "[" ? e = A(t, e, "[", "]") : n === "(" ? e = A(t, e, "(", ")") : e += 1;
		}
		let r = j(t, e);
		if (t[r] === "+" || t[r] === "~") throw w("theme.css", `selector "${t}" uses a sibling combinator that can escape the theme root.`);
		Me(t, e);
	}
}
function Pe(e, t) {
	let n = Ae(e).map((e) => e.trim()).filter(Boolean);
	if (n.length === 0) return e.trim();
	for (let e of n) {
		if (ge.test(e)) throw w("theme.css", `selector "${e}" targets the host document; scope it under the theme root instead.`);
		Ne(e);
	}
	return n.map((e) => je(e, t)).join(", ");
}
function M(e, t) {
	let n = 1;
	for (let r = t; r < e.length; r += 1) {
		let t = e[r];
		if (t === "\"" || t === "'") r = k(e, r) - 1;
		else if (t === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return r;
	}
	return e.length;
}
function N(e) {
	return e.trim().replace(/\s+/g, " ").toLowerCase();
}
function Fe(e) {
	let t = [];
	for (let n of e) {
		let e = n.codePointAt(0);
		e <= 127 ? t.push(e) : e <= 2047 ? t.push(192 | e >> 6, 128 | e & 63) : e <= 65535 ? t.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : t.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63);
	}
	return t;
}
function Ie(e) {
	let t = "", n = 0;
	for (; n < e.length;) {
		let r = e[n], i, a;
		if (r <= 127) i = r, a = 1;
		else if (r >= 194 && r <= 223) i = r & 31, a = 2;
		else if (r >= 224 && r <= 239) i = r & 15, a = 3;
		else if (r >= 240 && r <= 244) i = r & 7, a = 4;
		else return null;
		if (n + a > e.length) return null;
		for (let t = 1; t < a; t += 1) {
			let r = e[n + t];
			if ((r & 192) != 128) return null;
			i = i << 6 | r & 63;
		}
		if (a === 3 && (i < 2048 || i >= 55296 && i <= 57343) || a === 4 && (i < 65536 || i > 1114111)) return null;
		t += String.fromCodePoint(i), n += a;
	}
	return t;
}
function Le(e, t) {
	return `rmd-theme-${e}-font-${Fe(t).map((e) => e.toString(16).padStart(2, "0")).join("")}`;
}
function P(e) {
	let t = Se.exec(e);
	if (!t || t[2].length % 2 != 0) return null;
	let n = [];
	for (let e = 0; e < t[2].length; e += 2) n.push(Number.parseInt(t[2].slice(e, e + 2), 16));
	let r = Ie(n);
	return r === null || r.length === 0 || N(r) !== r ? null : {
		themeName: t[1],
		original: r
	};
}
function F(e) {
	return e === void 0 ? !1 : /[A-Za-z0-9_-]/.test(e) || e.codePointAt(0) >= 128;
}
function Re(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (/[A-Za-z_]/.test(n) || n.codePointAt(0) >= 128) return !0;
	if (n === "-") {
		let n = e[t + 1];
		return n !== void 0 && (F(n) || n === "-");
	}
	return !1;
}
function ze(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (n >= "0" && n <= "9") return !0;
	let r = e[t + 1];
	return n === "+" || n === "-" ? r !== void 0 && (r >= "0" && r <= "9" || r === ".") : n === "." && r !== void 0 && r >= "0" && r <= "9";
}
function I(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
			continue;
		}
		let i = n;
		if (r === "\"" || r === "'") {
			let r = k(e, n);
			t.push({
				type: "string",
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: e.slice(i + 1, Math.max(i + 1, r - 1))
			}), n = r;
		} else if (r === ",") t.push({
			type: "comma",
			text: ",",
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
		else if (ze(e, n)) {
			let r = n;
			for ((e[r] === "+" || e[r] === "-") && (r += 1); e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === ".") for (r += 1; e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === "e" || e[r] === "E") {
				let t = r;
				r += 1, (e[r] === "+" || e[r] === "-") && (r += 1);
				let n = r;
				for (; e[r] >= "0" && e[r] <= "9";) r += 1;
				r === n && (r = t);
			}
			let a = "number";
			if (e[r] === "%") r += 1, a = "percentage";
			else if (Re(e, r)) {
				for (r += 1; F(e[r]);) r += 1;
				a = "dimension";
			}
			t.push({
				type: a,
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: ""
			}), n = r;
		} else if (Re(e, n)) {
			let r = n + 1;
			for (; F(e[r]);) r += 1;
			let a = e.slice(n, r).toLowerCase();
			if (e[r] === "(") {
				let o = A(e, r, "(", ")"), s = Math.min(o, e.length);
				t.push({
					type: "function",
					text: e.slice(n, s),
					start: i,
					end: s,
					name: a,
					stringValue: ""
				}), n = s;
				continue;
			}
			t.push({
				type: "ident",
				text: e.slice(n, r),
				start: i,
				end: r,
				name: a,
				stringValue: ""
			}), n = r;
		} else if (r === "(") {
			let r = A(e, n, "(", ")"), a = Math.min(r, e.length);
			t.push({
				type: "function",
				text: e.slice(n, a),
				start: i,
				end: a,
				name: "",
				stringValue: ""
			}), n = a;
		} else t.push({
			type: "delimiter",
			text: r,
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
	}
	return t;
}
function Be(e) {
	return j(e, 0) === e.length;
}
function L(e) {
	let t = I(e);
	if (t.length === 0) return null;
	if (t.length === 1 && t[0].type === "string") {
		let e = N(t[0].stringValue);
		return e === "" ? null : {
			key: e,
			start: t[0].start,
			end: t[0].end
		};
	}
	if (t[0].type === "string") return null;
	for (let n = 0; n < t.length; n += 1) if (t[n].type !== "ident" || n > 0 && !Be(e.slice(t[n - 1].end, t[n].start))) return null;
	if (t.length === 1 && (C.has(t[0].name) || ye.has(t[0].name))) return null;
	let n = N(t.map((e) => e.text).join(" "));
	return n === "" ? null : {
		key: n,
		start: t[0].start,
		end: t[t.length - 1].end
	};
}
function R(e) {
	let t = [], n = 0, r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = k(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else i === "(" || i === "[" ? r = A(e, r, i, i === "(" ? ")" : "]") : (i === "," && (t.push({
			start: n,
			end: r
		}), n = r + 1), r += 1);
	}
	return t.push({
		start: n,
		end: e.length
	}), t;
}
function z(e) {
	let t = I(e);
	if (t.length < 2) return {
		body: e,
		important: ""
	};
	let n = t[t.length - 1], r = t[t.length - 2];
	return n.type !== "ident" || n.name !== "important" || r.type !== "delimiter" || r.text !== "!" || !Be(e.slice(r.end, n.start)) ? {
		body: e,
		important: ""
	} : {
		body: e.slice(0, r.start),
		important: e.slice(r.start)
	};
}
function B(e, t) {
	if (t.length === 0) return e;
	let n = [...t].sort((e, t) => e.start - t.start), r = "", i = 0;
	for (let t of n) t.start < i || (r += e.slice(i, t.start) + t.text, i = t.end);
	return r + e.slice(i);
}
function Ve(e) {
	return `"${e}"`;
}
function V(e, t, n = 0) {
	if (t.size === 0) return e;
	if (n > 64) throw w("theme.css", "font-family fallback nesting exceeds 64 levels.");
	let { body: r, important: i } = z(e), a = [];
	for (let e of R(r)) {
		let i = r.slice(e.start, e.end), o = L(i);
		if (o) {
			let n = t.get(o.key);
			n && a.push({
				start: e.start + o.start,
				end: e.start + o.end,
				text: Ve(n)
			});
			continue;
		}
		let s = I(i);
		if (s.length !== 0 && (s.length !== 1 || s[0].type !== "ident" || !ye.has(s[0].name) && !C.has(s[0].name))) {
			if (s.length === 1 && s[0].type === "function" && s[0].name === "var") {
				let r = s[0], i = r.text.indexOf("("), o = r.text.slice(i + 1, -1), c = R(o), l = I(o.slice(0, c[0].end));
				if (!r.text.endsWith(")") || l.length !== 1 || l[0].type !== "ident" || !l[0].text.startsWith("--")) throw w("theme.css", "font-family var() must start with a custom property name.");
				if (c.length > 1) {
					let s = c[0].end + 1, l = o.slice(s);
					a.push({
						start: e.start + r.start + i + 1 + s,
						end: e.start + r.end - 1,
						text: V(l, t, n + 1)
					});
				}
			} else throw w("theme.css", "unsupported font-family syntax; use literal families or var() with a family-list fallback.");
		}
	}
	return B(r, a) + i;
}
function He(e) {
	let t = I(e);
	if (t.length === 0 || t.length === 1 && t[0].type === "ident" && (be.has(t[0].name) || C.has(t[0].name))) return null;
	let n = -1;
	for (let e = 0; e < t.length; e += 1) {
		let r = t[e];
		if (r.type === "dimension" && !/(?:deg|grad|rad|turn)$/i.test(r.text) || r.type === "percentage" || r.type === "ident" && xe.has(r.name) || r.type === "number" && Number(r.text) === 0) {
			n = e;
			break;
		}
		if (r.type === "function") {
			let i = t[e + 1];
			if ([
				"calc",
				"min",
				"max",
				"clamp"
			].includes(r.name) || r.name === "var" && i?.type === "delimiter" && i.text === "/") {
				n = e;
				break;
			}
		}
	}
	if (n < 0) return null;
	let r = n + 1, i = t[r];
	return i?.type === "delimiter" && i.text === "/" && (r += 2), r >= t.length ? null : t[r].start;
}
function Ue(e, t) {
	if (t.size === 0) return e;
	let { body: n, important: r } = z(e), i = He(n);
	if (i === null) {
		let t = I(n);
		if (t.length === 1 && t[0].type === "ident" && (be.has(t[0].name) || C.has(t[0].name)) || t.length === 1 && t[0].type === "function" && t[0].name === "var" && R(t[0].text.slice(t[0].text.indexOf("(") + 1, -1)).length === 1) return e;
		throw w("theme.css", "unsupported font shorthand; use an explicit font size (including calc/min/max/clamp) and a family list.");
	}
	let a = V(n.slice(i), t);
	return n.slice(0, i) + a + r;
}
function H(e, t = !1, n = 0) {
	if (n > 64) throw w("theme.css", "nested font declarations exceed 64 levels.");
	let r = [], i = (i) => {
		let a = M(e, i + 1);
		if (t) for (let t of H(e.slice(i + 1, a), !0, n + 1)) r.push({
			name: t.name,
			valueStart: i + 1 + t.valueStart,
			valueEnd: i + 1 + t.valueEnd
		});
		return Math.min(a + 1, e.length);
	}, a = 0;
	for (; a < e.length && (a = j(e, a), !(a >= e.length));) {
		if (e[a] === ";" || e[a] === "}") {
			a += 1;
			continue;
		}
		if (e[a] === "{") {
			a = i(a);
			continue;
		}
		let t = a, n = a;
		for (; n < e.length;) {
			let t = e[n];
			if (t === "\"" || t === "'") n = k(e, n);
			else if (t === "/" && e[n + 1] === "*") n = j(e, n);
			else if (t === "(" || t === "[") n = A(e, n, t, t === "(" ? ")" : "]");
			else {
				if (t === ":" || t === ";" || t === "{" || t === "}") break;
				n += 1;
			}
		}
		if (n >= e.length) break;
		if (e[n] !== ":") {
			a = e[n] === "{" ? i(n) : n + 1;
			continue;
		}
		let o = I(e.slice(t, n)), s = o.length === 1 && o[0].type === "ident" ? o[0] : void 0, c = s?.text ?? "", l = c.startsWith("--") ? c : c.toLowerCase(), u = n + 1, d = u;
		for (; d < e.length;) {
			let t = e[d];
			if (t === "\"" || t === "'") d = k(e, d);
			else if (t === "/" && e[d + 1] === "*") d = j(e, d);
			else if (t === "(" || t === "[") d = A(e, d, t, t === "(" ? ")" : "]");
			else if (t === "{" && c.startsWith("--")) d = M(e, d + 1) + 1;
			else {
				if (t === ";" || t === "{" || t === "}") break;
				d += 1;
			}
		}
		e[d] === "{" ? a = i(d) : (s && r.push({
			name: l,
			valueStart: u,
			valueEnd: d
		}), a = d, e[d] === ";" && (a += 1));
	}
	return r;
}
function We(e, t) {
	if (t.size === 0) return e;
	let n = [];
	for (let r of H(e, !0)) {
		let i = r.name === "font-family" || r.name === "--font-sans" || r.name === "--font-mono";
		if (!i && r.name !== "font") continue;
		let a = e.slice(r.valueStart, r.valueEnd), o = i ? V(a, t) : Ue(a, t);
		o !== a && n.push({
			start: r.valueStart,
			end: r.valueEnd,
			text: o
		});
	}
	return B(e, n);
}
function Ge(e, t, n) {
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (/\s/.test(i) || i === ";" || i === "}") {
			r += 1;
			continue;
		}
		if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
			continue;
		}
		if (i === "{") {
			r = M(e, r + 1) + 1;
			continue;
		}
		let a = r, o = r;
		for (; o < e.length;) {
			let t = e[o];
			if (t === "\"" || t === "'") o = k(e, o);
			else if (t === "/" && e[o + 1] === "*") {
				let t = e.indexOf("*/", o + 2);
				o = t < 0 ? e.length : t + 2;
			} else if (t === "(" || t === "[") o = A(e, o, t, t === "(" ? ")" : "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				o += 1;
			}
		}
		if (o >= e.length) break;
		if (e[o] !== "{") {
			r = o + 1;
			continue;
		}
		let s = M(e, o + 1), c = e.slice(a, o).trim();
		if (c.startsWith("@")) {
			let r = (/^@([A-Za-z-]+)/.exec(c)?.[1] ?? "").toLowerCase();
			r === "font-face" ? n(e.slice(o + 1, s), t) : _e.has(r) && Ge(e.slice(o + 1, s), t, n);
		}
		r = Math.min(s + 1, e.length);
	}
}
function Ke(e, t) {
	let n = H(e).filter((e) => e.name === "font-family");
	if (n.length === 0) throw w(t, "@font-face must declare a font-family descriptor.");
	if (n.length > 1) throw w(t, "@font-face may declare font-family only once.");
	let { body: r, important: i } = z(e.slice(n[0].valueStart, n[0].valueEnd));
	if (i !== "") throw w(t, "@font-face descriptors must not use !important.");
	if (R(r).length !== 1) throw w(t, "@font-face font-family must be a single family name, not a list.");
	let a = L(r);
	if (!a) throw w(t, "@font-face font-family must be one quoted or unquoted family name; generic families, keywords, var() and other functions are not allowed.");
	if (Fe(P(a.key)?.original ?? a.key).length > ve) throw w(t, `@font-face font-family must not exceed ${ve} UTF-8 bytes.`);
	return a.key;
}
function qe(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i of e) Ge(i.css, n, (e, n) => {
		let i = Ke(e, n), a = P(i), o = a ? a.original : i, s = Le(t, o), c = r.get(i);
		if (c !== void 0 && c !== s) throw w(n, `@font-face family "${i}" maps to more than one name.`);
		r.set(i, s), r.set(o, s);
	});
	return r;
}
function Je(e, t, n) {
	let r = H(e).filter((e) => e.name === "font-family");
	if (r.length !== 1) throw w(n, "@font-face must declare exactly one font-family descriptor.");
	let i = r[0], { body: a } = z(e.slice(i.valueStart, i.valueEnd));
	if (R(a).length !== 1) throw w(n, "@font-face font-family must be a single family name, not a list.");
	let o = L(a);
	if (!o) throw w(n, "@font-face has an unsupported font-family descriptor.");
	let s = t.get(o.key);
	if (s === void 0) throw w(n, `@font-face family "${o.key}" was not registered.`);
	return B(e, [{
		start: i.valueStart + o.start,
		end: i.valueStart + o.end,
		text: Ve(s)
	}]);
}
var Ye = /* @__PURE__ */ new Map();
function Xe(e) {
	return e.replace(/\/\*[\s\S]*?\*\//g, " ").trim().replace(/^@layer\b/i, "@layer").replace(/\s+/g, " ").replace(/\s*,\s*/g, ", ");
}
function U(e, t, n = Ye, r = !1) {
	let i = "", a = 0;
	for (; a < e.length;) {
		let o = e[a];
		if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2), n = t < 0 ? e.length : t + 2;
			i += e.slice(a, n), a = n;
			continue;
		}
		if (/\s/.test(o) || o === ";" || o === "}") {
			i += o, a += 1;
			continue;
		}
		let s = a, c = a;
		for (; c < e.length;) {
			let t = e[c];
			if (t === "\"" || t === "'") c = k(e, c);
			else if (t === "/" && e[c + 1] === "*") {
				let t = e.indexOf("*/", c + 2);
				c = t < 0 ? e.length : t + 2;
			} else if (t === "(") c = A(e, c, "(", ")");
			else if (t === "[") c = A(e, c, "[", "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				c += 1;
			}
		}
		if (c >= e.length) {
			i += e.slice(s);
			break;
		}
		let l = e.slice(s, c), u = e[c];
		if (u === ";" || u === "}") {
			let e = Xe(l);
			if (!r && (e === "@layer rmd.themes" || `${e};` === b)) {
				a = c + 1;
				continue;
			}
			i += l + u, a = c + 1;
			continue;
		}
		let d = M(e, c + 1), f = e.slice(c + 1, d), p = l.trim();
		if (p.startsWith("@")) {
			let e = (/^@([A-Za-z-]+)/.exec(p)?.[1] ?? "").toLowerCase();
			if (e === "import") throw w("theme.css", "must not use @import.");
			if (e === "keyframes" || e.endsWith("-keyframes")) throw w("theme.css", `@${e} declares a global name; phase one only supports document-scoped CSS.`);
			if (e === "font-face") i += `${p} {${Je(f, n, "theme.css")}}`;
			else if (e === "layer" && !r && Xe(p) === "@layer rmd.themes") i += U(f, t, n, !0).trim();
			else {
				let a = _e.has(e) ? U(f, t, n, r || e === "layer") : f;
				i += `${p} {${a}}`;
			}
		} else i += `${Pe(p, t)} {${We(f, n)}}`;
		a = Math.min(d + 1, e.length);
	}
	return i;
}
function W(e, t, n = Ye) {
	return `${b}\n@layer ${y} {\n${U(e, t, n).trim()}\n}`;
}
function G(e, t) {
	if (!Array.isArray(e)) throw w(t, "must be an array of { id, css } resources.");
	if (e.length > ue) throw w(t, `may contain at most ${ue} resources.`);
	let n = /* @__PURE__ */ new Set(), r = [], i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a], s = `${t}[${a}]`;
		if (!Ce(o)) throw w(s, "must be an object.");
		let c = o.id;
		if (typeof c != "string" || c.length === 0) throw w(`${s}.id`, "must be a non-empty string.");
		if (c.length > de) throw w(`${s}.id`, `must not exceed ${de} characters.`);
		if (!pe.test(c)) throw w(`${s}.id`, `"${c}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (n.has(c)) throw w(`${s}.id`, `"${c}" is declared more than once.`);
		n.add(c);
		let l = o.css;
		if (typeof l != "string") throw w(`${s}.css`, "must be a string.");
		if (l.length > x) throw w(`${s}.css`, `must not exceed ${x} characters.`);
		if (i += l.length, i > S) throw w(t, `must not exceed ${S} characters in total.`);
		Oe(l, `${s}.css`), r.push(Object.freeze({
			id: c,
			css: l
		}));
	}
	return {
		resources: Object.freeze(r),
		totalLength: i
	};
}
function Ze(e) {
	let t = 0;
	for (let [n, r] of e.entries()) {
		if (r.css.length > x) throw w(`theme.css[${n}].css`, `scoped CSS must not exceed ${x} characters.`);
		t += r.css.length;
	}
	if (t > S) throw w("theme.css", `scoped CSS must not exceed ${S} characters in total.`);
}
function K(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		protocol: e.protocol,
		colorSchemes: Object.freeze([...e.colorSchemes]),
		css: Object.freeze(e.css.map((e) => Object.freeze({
			id: e.id,
			css: e.css
		})))
	});
}
function Qe(e, t) {
	let n = T(e, t), i = E(n.id, `${t}.id`), a = D(n.name, `${t}.name`), o = O(n.version, `${t}.version`);
	if (n.protocol !== "reactive-md-theme-1") throw w(`${t}.protocol`, `must be "${r}".`);
	let s = we(n.colorSchemes, `${t}.colorSchemes`), { resources: c } = G(n.css, `${t}.css`);
	return K({
		id: i,
		name: a,
		version: o,
		protocol: r,
		colorSchemes: s,
		css: c
	});
}
function q(e) {
	let t = T(e, "input"), n = E(t.id, "theme.id"), i = D(t.name, "theme.name"), a = O(t.version, "theme.version");
	if ((t.protocol === void 0 ? "reactive-md-theme-1" : t.protocol) !== "reactive-md-theme-1") throw w("theme.protocol", `must be "${r}".`);
	let o = we(t.colorSchemes, "theme.colorSchemes"), { resources: s } = G(t.css, "theme.css"), c = qe(s, i, "theme.css"), l = s.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, i, c)
	}));
	return Ze(l), K({
		id: n,
		name: i,
		version: a,
		protocol: r,
		colorSchemes: o,
		css: l
	});
}
function $e(e) {
	let t = T(e, "input"), n = E(t.id, "theme.id"), r = D(t.name, "theme.name"), i = O(t.version, "theme.version"), a = Qe(t.base, "theme.base"), o = G(t.overrides, "theme.overrides"), s = qe([...a.css, ...o.resources], r, "theme.css"), c = new Set(a.css.map((e) => e.id));
	for (let e of o.resources) {
		if (c.has(e.id)) throw w("theme.overrides", `resource "${e.id}" is already declared by the base theme.`);
		c.add(e.id);
	}
	let l = [...a.css.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, r, s)
	})), ...o.resources.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, r, s)
	}))];
	return Ze(l), K({
		id: n,
		name: r,
		version: i,
		protocol: a.protocol,
		colorSchemes: a.colorSchemes,
		css: l
	});
}
function et(e) {
	return q(e).css.map((e) => e.css).join("\n");
}
// src/sdk/preset.ts
var J = /* @__PURE__ */ new WeakSet();
function tt(e, t) {
	let n = t instanceof Error ? t.message : String(t);
	throw Error(`Invalid local preset (themes[${e}]): ${n}`);
}
function Y(e) {
	if (typeof e == "object" && e && J.has(e)) return e;
	let t = oe(e);
	if (t.themes === void 0) return J.add(t), t;
	let n = t.themes.map((e, t) => {
		try {
			return q(e);
		} catch (e) {
			tt(t, e);
		}
	}), r = Object.freeze({
		...t,
		themes: Object.freeze(n)
	});
	return J.add(r), r;
}
function nt(e) {
	return Y(e);
}
function rt(e) {
	return ae(e);
}
// src/sdk/config.ts
var it = v.id, at = v.version, ot = Object.freeze({
	id: it,
	version: at
}), st = 16, ct = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"replacements",
	"themes"
]), X = /* @__PURE__ */ new WeakSet();
function lt(e) {
	o(e) || d("themes", "each theme must be an object."), m(e, /* @__PURE__ */ new Set([
		"id",
		"name",
		"version",
		"protocol",
		"colorSchemes",
		"css"
	]), "theme");
	try {
		return q(e);
	} catch (e) {
		d("theme", e instanceof Error ? e.message : String(e));
	}
}
function Z(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || d("themes", "must be an array."), e.length > 16 && d("themes", "accepts at most 16 themes.");
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = lt(i);
		t.has(e.id) && d("themes", `theme id "${e.id}" is declared more than once.`), n.has(e.name) && d("themes", `theme name "${e.name}" is declared more than once.`), t.add(e.id), n.add(e.name), r.push(e);
	}
	return Object.freeze(r.sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function ut(e, t) {
	if (typeof e == "string") return e !== "default" && e !== v.id && d(`presets[${t}]`, `unsupported preset "${e}"; phase one accepts only the built-in default package.`), v;
	if (o(e) || d(`presets[${t}]`, "must be a preset package, \"default\" or a preset reference."), e.protocol !== void 0 || e.components !== void 0) try {
		return Y(e);
	} catch (e) {
		d(`presets[${t}]`, e instanceof Error ? e.message : String(e));
	}
	let n = e.id, r = e.version;
	return typeof n != "string" && d(`presets[${t}].id`, "must be a string."), typeof r != "string" && d(`presets[${t}].version`, "must be a string."), (n === "default" ? v.id : n) !== v.id && d(`presets[${t}]`, `unsupported preset "${n}"; phase one accepts only "${v.id}".`), r !== v.version && d(`presets[${t}].version`, `must be "${v.version}".`), v;
}
function dt(e) {
	if (e === void 0) return Object.freeze([v]);
	Array.isArray(e) || d("presets", "must be an array.");
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r = 0; r < e.length; r += 1) {
		let i = ut(e[r], r);
		n.has(i.id) && d("presets", `preset "${i.id}" is selected more than once.`), n.add(i.id), t.push(i);
	}
	return Object.freeze([...t].sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function ft(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || d("components", "must be an array.");
	let t = e.map((e, t) => {
		try {
			return _(e);
		} catch (e) {
			d(`components[${t}]`, e instanceof Error ? e.message : String(e));
		}
	});
	return Object.freeze(t.sort((e, t) => {
		if (e.id !== t.id) return e.id < t.id ? -1 : 1;
		let n = e.replaces === void 0 ? 0 : 1, r = t.replaces === void 0 ? 0 : 1;
		return n === r ? e.version === t.version ? e.name < t.name ? -1 : +(e.name > t.name) : e.version < t.version ? -1 : 1 : n - r;
	}));
}
function pt(e) {
	return e === void 0 ? "allow" : (e !== "allow" && e !== "forbid" && d("replacements", "must be \"allow\" or \"forbid\"."), e);
}
function mt(e, t) {
	o(e) || d(t, "must be an object."), m(e, ct, t);
	let r = Object.freeze({
		protocol: n,
		presets: dt(e.presets),
		components: ft(e.components),
		replacementPolicy: pt(e.replacements),
		themes: Z(e.themes)
	});
	return re(r) > 16777216 && d(t, `serialized size exceeds the ${p}-byte budget.`), r;
}
function ht(e) {
	return Object.freeze({
		...e,
		presets: Object.freeze(e.presets.map((e) => Y(e))),
		themes: Z(e.themes)
	});
}
function gt(e) {
	let t = ht(e), n = u(t, { legacyProfiles: l }), r = c(t, n);
	return X.add(r), r;
}
function Q(e = {}) {
	return gt(mt(e, "config"));
}
var _t;
function vt(e) {
	return e === void 0 ? _t ??= Q().key : $(e).key;
}
function yt(e) {
	return new Set(e.legacyKeys.map((e) => e.key));
}
function bt(e, t) {
	let n = $(t ?? Q()), r = e.componentConfigKey;
	return r === void 0 || r === n.key || yt(n).has(r) ? [] : [{
		code: "local.extension.config-mismatch",
		severity: "error",
		message: "The document compiler configuration differs from the installed renderer. Recompile with the same host.config used by host.reactConfig (including Worker requests).",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}];
}
function xt(e) {
	return e.preset.id === v.id && e.preset.version === v.version ? v : Y({
		...v,
		id: e.preset.id,
		version: e.preset.version
	});
}
function St(e, t) {
	let r = ne(e.presets, ot, t)[0] ?? ot, i = a(r, t);
	i === void 0 && d("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${r.id}" ${r.version}.`);
	let o = i.legacyKeys[0];
	o === void 0 && d("presets", `local.config.migration-unsupported: profile "${i.name}" has no legacy key mapping.`), s(i, v.components);
	let l = xt(i), f = ee(e.components, v.components);
	f.some((e) => e.replaces !== void 0) && d("config", "replaces is not supported by reactive-md-config/v1.");
	let p = Z(e.themes), m = Object.freeze({
		protocol: n,
		presets: Object.freeze([l]),
		components: f,
		replacementPolicy: "forbid",
		themes: p
	}), h = u(m, { legacyProfiles: t }), g = te(i.preset, h.components), re = [...h.legacyKeys, ...h.legacyKeys.some((e) => e.key === g) ? [] : [Object.freeze({
		profile: o.profile,
		key: g
	})]], _ = c(m, h, re);
	return X.add(_), _;
}
function $(n, r = []) {
	return typeof n == "object" && n && X.has(n) ? n : (o(n) || d("config", "must be an object."), m(n, h, "config"), n.protocol === "reactive-md-config/v1" ? St(n, g(r)) : (n.protocol !== "reactive-md-config/v2" && d("config.protocol", `must be "${e}" (or legacy "${t}").`), gt(f(n.assembly))));
}
function Ct(e) {
	if (typeof e == "object" && e && X.has(e)) return e.key;
	try {
		return $(e).key;
	} catch {
		try {
			return `invalid:${ie(JSON.stringify(e))}`;
		} catch {
			return "invalid";
		}
	}
}
function wt(e) {
	try {
		return $(e);
	} catch {
		return e;
	}
}
export { se as _, vt as a, y as b, wt as c, rt as d, Y as f, ke as g, q as h, Q as i, bt as l, $e as m, at as n, Ct as o, et as p, st as r, $ as s, it as t, nt as u, ce as v, b as y };
