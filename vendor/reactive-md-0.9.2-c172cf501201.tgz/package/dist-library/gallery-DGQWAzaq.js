import { I as e } from "./sdk-core-BG-HbMwE.js";
import { useCallback as t, useEffect as n, useId as r, useRef as i, useState as a } from "react";
import { jsx as o, jsxs as s } from "react/jsx-runtime";
// src/components/gallery/gallery.tsx
var c = 280, l = 180, u = 480, d = 24, f = 28, p = 700;
function m(e) {
	return Math.round(Math.min(u, Math.max(l, typeof e == "number" && Number.isFinite(e) ? e : c)));
}
function h() {
	return typeof window < "u" && typeof window.matchMedia == "function" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function g(e) {
	return e.children.items().filter((e) => e.kind === "component" && e.name === "gallery-item");
}
function _(e) {
	let t = e.props.label;
	return typeof t == "string" ? t.trim() : "";
}
function v(c) {
	let l = e(c), u = g(c), v = u.length, y = m(c.props["item-width"]), b = typeof c.props.label == "string" ? c.props.label.trim() : "", x = r(), S = i(null), C = i(null), w = i(null), T = i(null), E = i(null), D = i(void 0), O = i(""), [k, A] = a(() => ({
		start: +(v > 0),
		end: v,
		prev: !1,
		next: !1
	})), j = t(() => {
		let e = C.current, t = S.current;
		if (!e || !t || e.clientWidth === 0) return;
		let n = Math.max(0, e.scrollWidth - e.clientWidth), r = Math.max(0, e.scrollLeft), i = r > .5, a = n - r > .5;
		t.setAttribute("data-rmd-gallery-ready", ""), t.setAttribute("data-rmd-gallery-overflow", n > .5 ? "true" : "false"), e.style.setProperty("--rmd-gallery-fade-left", `${i ? Math.min(d, r) : 0}px`), e.style.setProperty("--rmd-gallery-fade-right", `${a ? Math.min(d, n - r) : 0}px`);
		let o = e.getBoundingClientRect(), s = window.getComputedStyle(e), c = o.left + e.clientLeft + (parseFloat(s.paddingLeft) || 0), l = o.left + e.clientLeft + e.clientWidth - (parseFloat(s.paddingRight) || 0), u = 0, p = 0, m = 0;
		for (let t of Array.from(e.children)) {
			if (!t.classList.contains("rmd-gallery-item")) continue;
			m += 1;
			let e = t.getBoundingClientRect();
			e.right > c + .5 && e.left < l - .5 && (u === 0 && (u = m), p = m);
		}
		let h = u === 0 ? +(m > 0) : u, g = p === 0 ? m : p, _ = `${h}|${g}|${i}|${a}`;
		_ !== O.current && (O.current = _, A({
			start: h,
			end: g,
			prev: i,
			next: a
		}));
		let v = w.current, y = T.current;
		if (!v || !y) return;
		let b = n > .5;
		if (v.toggleAttribute("data-hidden", !b), !b) return;
		let x = v.clientWidth, E = Math.min(x, Math.max(f, x * e.clientWidth / Math.max(1, e.scrollWidth))), D = Math.max(0, Math.min(x - E, (x - E) * (r / n)));
		y.style.width = `${E}px`, y.style.transform = `translateX(${D}px)`;
	}, []), M = t(() => {
		let e = S.current;
		e && (e.setAttribute("data-rmd-gallery-scrolling", ""), D.current !== void 0 && window.clearTimeout(D.current), D.current = window.setTimeout(() => {
			D.current = void 0, e.removeAttribute("data-rmd-gallery-scrolling");
		}, p));
	}, []);
	n(() => {
		let e = C.current;
		if (!e) return;
		let t = 0, n = () => {
			t === 0 && (t = window.requestAnimationFrame(() => {
				t = 0, j();
			}));
		}, r = () => {
			n(), M();
		};
		e.addEventListener("scroll", r, { passive: !0 }), j();
		let i;
		if (typeof ResizeObserver < "u") {
			i = new ResizeObserver(n), i.observe(e);
			for (let t of Array.from(e.children)) i.observe(t);
		}
		let a = typeof MutationObserver > "u" ? void 0 : new MutationObserver(() => {
			if (i?.disconnect(), i) {
				i.observe(e);
				for (let t of Array.from(e.children)) i.observe(t);
			}
			n();
		});
		return a?.observe(e, { childList: !0 }), () => {
			e.removeEventListener("scroll", r), t !== 0 && window.cancelAnimationFrame(t), i?.disconnect(), a?.disconnect(), D.current !== void 0 && (window.clearTimeout(D.current), D.current = void 0);
		};
	}, [
		j,
		M,
		v
	]), n(() => {
		let e = C.current;
		if (!e) return;
		e.scrollLeft = 0;
		let t = window.requestAnimationFrame(() => j());
		return () => window.cancelAnimationFrame(t);
	}, [
		c.resetToken,
		c.visible,
		j
	]), n(() => {
		let e = C.current;
		if (!e) return;
		let t = (t) => {
			if (t.defaultPrevented || t.ctrlKey || t.metaKey || t.altKey) return;
			let n = e.scrollWidth - e.clientWidth;
			if (n <= .5) return;
			let r = t.deltaMode === 1 ? 16 : t.deltaMode === 2 ? e.clientWidth : 1, i = t.deltaX * r, a = t.deltaY * r;
			if (Math.abs(i) > Math.abs(a) || a === 0) return;
			let o = e.scrollLeft;
			a < 0 && o <= .5 || a > 0 && o >= n - .5 || (t.preventDefault(), e.scrollBy({
				left: a,
				behavior: h() ? "auto" : "smooth"
			}));
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, []);
	let N = (e) => {
		let t = C.current;
		t && !c.disabled && t.scrollBy({
			left: e * t.clientWidth * .9,
			behavior: h() ? "auto" : "smooth"
		});
	}, P = (e) => {
		if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
		let t = e.target instanceof Element ? e.target : null;
		if (t && t !== e.currentTarget && t.closest("input, textarea, select, button, a[href], [contenteditable=\"true\"], [role=\"textbox\"], [role=\"slider\"]")) return;
		let n = C.current;
		if (!n) return;
		let r = Math.max(0, n.scrollWidth - n.clientWidth), i = n.scrollLeft, a = h() ? "auto" : "smooth";
		if (e.key === "ArrowRight") {
			if (i >= r - .5) return;
			e.preventDefault(), n.scrollBy({
				left: n.clientWidth * .9,
				behavior: a
			});
		} else if (e.key === "ArrowLeft") {
			if (i <= .5) return;
			e.preventDefault(), n.scrollBy({
				left: -n.clientWidth * .9,
				behavior: a
			});
		} else if (e.key === "Home") {
			if (i <= .5) return;
			e.preventDefault(), n.scrollTo({
				left: 0,
				behavior: a
			});
		} else if (e.key === "End") {
			if (i >= r - .5) return;
			e.preventDefault(), n.scrollTo({
				left: r,
				behavior: a
			});
		}
	}, F = (e) => {
		let t = C.current, n = w.current, r = T.current;
		if (!t || !n || !r || e.button !== 0) return;
		e.preventDefault(), e.stopPropagation(), e.currentTarget.setPointerCapture(e.pointerId);
		let i = t.scrollWidth - t.clientWidth, a = Math.max(1, n.clientWidth - r.offsetWidth);
		E.current = {
			startX: e.clientX,
			scroll: t.scrollLeft,
			ratio: i / a
		}, S.current?.setAttribute("data-rmd-gallery-dragging", ""), t.style.scrollSnapType = "none";
	}, I = (e) => {
		let t = E.current, n = C.current;
		if (!t || !n) return;
		let r = Math.max(0, n.scrollWidth - n.clientWidth), i = t.scroll + (e.clientX - t.startX) * t.ratio;
		n.scrollLeft = Math.max(0, Math.min(r, i));
	}, L = (e) => {
		if (!E.current) return;
		E.current = null, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId), S.current?.removeAttribute("data-rmd-gallery-dragging");
		let t = C.current;
		t && (t.style.scrollSnapType = ""), M();
	}, R = (e) => {
		if (e.button !== 0 || e.target !== e.currentTarget) return;
		let t = C.current, n = T.current;
		if (!t) return;
		e.preventDefault();
		let r = n?.getBoundingClientRect(), i = r ? e.clientX > r.left + r.width / 2 : e.clientX > t.getBoundingClientRect().left + t.clientWidth / 2;
		t.scrollBy({
			left: (i ? 1 : -1) * t.clientWidth * .9,
			behavior: h() ? "auto" : "smooth"
		});
	}, z = v === 0 ? 0 : Math.min(v, Math.max(1, k.start || 1)), B = v === 0 ? 0 : Math.min(v, Math.max(z, k.end || v)), V = { "--rmd-gallery-item-width": `${y}px` }, H = b ? c.locale.t(`Browse ${b}`, `浏览${b}`) : c.locale.t("Gallery items", "画廊项目"), U = l(V);
	return /* @__PURE__ */ s("section", {
		className: "rmd-gallery",
		style: U.style,
		"aria-label": b || void 0,
		ref: (e) => {
			S.current = e, U.ref?.(e);
		},
		children: [
			/* @__PURE__ */ s("div", {
				className: "rmd-gallery-head",
				children: [/* @__PURE__ */ o("h3", {
					className: "rmd-gallery-title",
					title: b || void 0,
					children: b
				}), /* @__PURE__ */ s("div", {
					className: "rmd-gallery-controls",
					children: [
						v > 0 ? /* @__PURE__ */ s("span", {
							className: "rmd-gallery-count",
							"aria-live": "polite",
							"aria-atomic": "true",
							children: [
								z,
								"–",
								B,
								" / ",
								v
							]
						}) : null,
						/* @__PURE__ */ o("button", {
							type: "button",
							className: "rmd-gallery-button",
							"data-direction": "previous",
							"data-rmd-appearance": "custom",
							"aria-label": c.locale.t("Previous items", "上一组"),
							"aria-controls": x,
							disabled: c.disabled || !k.prev,
							onClick: () => N(-1),
							children: /* @__PURE__ */ o("svg", {
								width: "22",
								height: "22",
								viewBox: "0 0 24 24",
								fill: "none",
								"aria-hidden": "true",
								children: /* @__PURE__ */ o("path", {
									d: "m14.5 5.5-6.5 6.5 6.5 6.5",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round"
								})
							})
						}),
						/* @__PURE__ */ o("button", {
							type: "button",
							className: "rmd-gallery-button",
							"data-direction": "next",
							"data-rmd-appearance": "custom",
							"aria-label": c.locale.t("Next items", "下一组"),
							"aria-controls": x,
							disabled: c.disabled || !k.next,
							onClick: () => N(1),
							children: /* @__PURE__ */ o("svg", {
								width: "22",
								height: "22",
								viewBox: "0 0 24 24",
								fill: "none",
								"aria-hidden": "true",
								children: /* @__PURE__ */ o("path", {
									d: "m9.5 5.5 6.5 6.5-6.5 6.5",
									stroke: "currentColor",
									strokeWidth: "2",
									strokeLinecap: "round",
									strokeLinejoin: "round"
								})
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ o("ul", {
				id: x,
				ref: C,
				className: "rmd-gallery-viewport",
				role: "list",
				tabIndex: 0,
				"aria-label": H,
				onKeyDown: P,
				children: u.map((e) => {
					let t = _(e);
					return /* @__PURE__ */ o("li", {
						className: "rmd-gallery-item",
						children: /* @__PURE__ */ s("figure", {
							className: "rmd-gallery-figure",
							children: [t ? /* @__PURE__ */ o("figcaption", { children: /* @__PURE__ */ o("h3", {
								className: "rmd-gallery-caption",
								title: t,
								children: t
							}) }) : null, /* @__PURE__ */ o("div", {
								className: "rmd-gallery-body",
								children: c.children.renderItems(e.children, e.visible)
							})]
						})
					}, e.id);
				})
			}),
			/* @__PURE__ */ o("div", {
				className: "rmd-gallery-track",
				ref: w,
				"aria-hidden": "true",
				onPointerDown: R,
				children: /* @__PURE__ */ o("div", {
					className: "rmd-gallery-thumb",
					ref: T,
					onPointerDown: F,
					onPointerMove: I,
					onPointerUp: L,
					onPointerCancel: L
				})
			})
		]
	});
}
function y(t) {
	let n = e(t), r = g(t), i = m(t.props["item-width"]), a = typeof t.props.label == "string" ? t.props.label.trim() : "", c = { "--rmd-gallery-item-width": `${i}px` };
	return /* @__PURE__ */ s("section", {
		className: "rmd-gallery rmd-gallery-static",
		...n(c),
		"aria-label": a || void 0,
		children: [/* @__PURE__ */ o("div", {
			className: "rmd-gallery-head",
			children: /* @__PURE__ */ o("h3", {
				className: "rmd-gallery-title",
				title: a || void 0,
				children: a
			})
		}), /* @__PURE__ */ o("ul", {
			className: "rmd-gallery-static-grid",
			role: "list",
			children: r.map((e) => {
				let n = _(e);
				return /* @__PURE__ */ o("li", {
					className: "rmd-gallery-static-item",
					children: /* @__PURE__ */ s("figure", {
						className: "rmd-gallery-figure",
						children: [n ? /* @__PURE__ */ o("figcaption", { children: /* @__PURE__ */ o("h3", {
							className: "rmd-gallery-caption",
							title: n,
							children: n
						}) }) : null, /* @__PURE__ */ o("div", {
							className: "rmd-gallery-body",
							children: t.children.renderItems(e.children, e.visible)
						})]
					})
				}, e.id);
			})
		})]
	});
}
function b(t) {
	let n = e(t), r = typeof t.props.label == "string" ? t.props.label.trim() : "";
	return /* @__PURE__ */ s("section", {
		...n(),
		className: "rmd-gallery-item-standalone",
		"aria-label": r || void 0,
		children: [r ? /* @__PURE__ */ o("h3", {
			className: "rmd-gallery-caption",
			title: r,
			children: r
		}) : null, /* @__PURE__ */ o("div", {
			className: "rmd-gallery-body",
			children: t.children.render()
		})]
	});
}
function x(e) {
	return e.mode === "static" ? /* @__PURE__ */ o(y, { ...e }) : /* @__PURE__ */ o(v, { ...e });
}
export { x as n, b as t };
