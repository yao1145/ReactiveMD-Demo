import { y as e } from "./document-theme-Cvvc_EOe.js";
import { t, u as n } from "./component-state-CwKX_SN5.js";
import { c as r, i, t as a } from "./identity-BUx0Q_-d.js";
// src/export/component-state.ts
function o(e, t) {
	return {
		code: e,
		message: t,
		severity: "warning",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function s(t, n) {
	let r = i(t.source), o = /* @__PURE__ */ new Set();
	for (let i of e(t.nodes)) i.name !== void 0 && o.add(a({
		documentId: n,
		sourceDigest: r,
		nodeId: i.id,
		stateKey: i.attrs?.["state-key"]
	}));
	return o;
}
function c(e, a, c) {
	let l = n(a);
	if (!l.ok) return l;
	let u = i(e.source), d = r({
		documentId: c?.documentId,
		sourceDigest: u
	}), f = s(e, d), p = [...l.diagnostics], m = {}, h = c?.configKey, g = l.document.configKey, _ = c?.legacyConfigKeys ?? [];
	if (g !== void 0 && h !== void 0 && g !== h && !_.includes(g)) return p.push(o("local.runtime.state.config-mismatch", `Saved component state belongs to configuration "${g}", not "${h}".`)), {
		ok: !0,
		componentState: Object.freeze({
			format: t,
			configKey: h,
			records: Object.freeze({})
		}),
		diagnostics: p
	};
	for (let [e, t] of Object.entries(l.records)) t.documentId !== void 0 && t.documentId !== d ? p.push(o("local.runtime.state.document-mismatch", `Saved state key "${e}" belongs to a different document identity (${t.documentId}).`)) : f.has(e) ? m[e] = t : p.push(o("local.runtime.state.unknown-component", `Saved state key "${e}" does not match any component in this document.`));
	return {
		ok: !0,
		componentState: Object.freeze({
			format: t,
			...(h ?? g) === void 0 ? {} : { configKey: h ?? g },
			records: Object.freeze(m)
		}),
		diagnostics: p
	};
}
export { c as t };
