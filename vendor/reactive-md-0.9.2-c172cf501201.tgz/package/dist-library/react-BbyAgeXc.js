import { Component as e, Fragment as t, createContext as n, createElement as r, forwardRef as i, useCallback as a, useContext as o, useEffect as s, useId as c, useInsertionEffect as l, useLayoutEffect as u, useMemo as d, useRef as f, useState as p } from "react";
import { jsx as m, jsxs as h } from "react/jsx-runtime";
// node_modules/framer-motion/dist/es/context/LayoutGroupContext.mjs
var g = /* @__PURE__ */ n({});
// node_modules/framer-motion/dist/es/utils/use-constant.mjs
function _(e) {
	let t = f(null);
	return t.current === null && (t.current = e()), t.current;
}
// node_modules/framer-motion/dist/es/utils/use-isomorphic-effect.mjs
var v = typeof window < "u" ? u : s, y = /* @__PURE__ */ n(null);
// node_modules/motion-utils/dist/es/array.mjs
function b(e, t) {
	e.indexOf(t) === -1 && e.push(t);
}
function x(e, t) {
	let n = e.indexOf(t);
	n > -1 && e.splice(n, 1);
}
// node_modules/motion-utils/dist/es/clamp.mjs
var S = (e, t, n) => n > t ? t : n < e ? e : n;
// node_modules/motion-utils/dist/es/format-error-message.mjs
function C(e, t) {
	return t ? `${e}. For more information and steps for solving, visit https://motion.dev/troubleshooting/${t}` : e;
}
// node_modules/motion-utils/dist/es/errors.mjs
var w = () => {}, T = () => {};
typeof process < "u" && process.env.NODE_ENV !== "production" && (w = (e, t, n) => {
	!e && typeof console < "u" && console.warn(C(t, n));
}, T = (e, t, n) => {
	if (!e) throw Error(C(t, n));
});
// node_modules/motion-utils/dist/es/global-config.mjs
var E = {}, D = (e) => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e), O = (e) => typeof e == "object" && !!e, ee = (e) => /^0[^.\s]+$/u.test(e);
// node_modules/motion-utils/dist/es/memo.mjs
/*#__NO_SIDE_EFFECTS__*/
function te(e) {
	let t;
	return () => (t === void 0 && (t = e()), t);
}
// node_modules/motion-utils/dist/es/noop.mjs
var k = /* @__NO_SIDE_EFFECTS__ */ (e) => e, ne = (...e) => e.reduce((e, t) => (n) => t(e(n))), re = /* @__NO_SIDE_EFFECTS__ */ (e, t, n) => {
	let r = t - e;
	return r ? (n - e) / r : 1;
}, ie = class {
	constructor() {
		this.subscriptions = [];
	}
	add(e) {
		return b(this.subscriptions, e), () => this.remove(e);
	}
	remove(e) {
		x(this.subscriptions, e);
	}
	notify(e, t, n) {
		let r = this.subscriptions.length;
		if (r) {
			if (r === 1) this.subscriptions[0](e, t, n);
			else for (let i = 0; i < r; i++) {
				let r = this.subscriptions[i];
				r && r(e, t, n);
			}
		}
	}
	getSize() {
		return this.subscriptions.length;
	}
	clear() {
		this.subscriptions.length = 0;
	}
}, A = /* @__NO_SIDE_EFFECTS__ */ (e) => e * 1e3, j = /* @__NO_SIDE_EFFECTS__ */ (e) => e / 1e3, ae = /* @__NO_SIDE_EFFECTS__ */ (e, t) => t ? 1e3 / t * e : 0, oe = /* @__PURE__ */ new Set();
function se(e, t, n) {
	e || oe.has(t) || (console.warn(C(t, n)), oe.add(t));
}
// node_modules/motion-utils/dist/es/wrap.mjs
var ce = (e, t, n) => {
	let r = t - e;
	return ((n - e) % r + r) % r + e;
}, le = (e, t, n) => e * (3 * (1 - e) * ((1 - e) * t + e * n) + e * e);
/*#__NO_SIDE_EFFECTS__*/
function ue(e, t, n, r) {
	return e === t && n === r ? k : (i) => {
		let a = 0, o = 1, s = i;
		for (let t = 0;; t++) {
			s >= a && s <= o || (s = (a + o) / 2);
			let r = le(s, e, n) - i;
			if (r * r < 1e-28 || t === 40) break;
			r > 0 ? o = s : a = s, s -= r * 1e-7 / (le(s + 1e-7, e, n) - i - r);
		}
		return le(s, t, r);
	};
}
// node_modules/motion-utils/dist/es/easing/modifiers/mirror.mjs
var de = /* @__NO_SIDE_EFFECTS__ */ (e) => (t) => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2, fe = /* @__NO_SIDE_EFFECTS__ */ (e) => (t) => 1 - e(1 - t), pe = /*@__PURE__*/ ue(.33, 1.53, .69, .99), me = /*@__PURE__*/ fe(pe), he = /*@__PURE__*/ de(me), ge = (e) => e >= 1 ? 1 : (e *= 2) < 1 ? .5 * me(e) : .5 * (2 - 2 ** (-10 * (e - 1))), _e = (e) => 1 - Math.sin(Math.acos(e)), ve = /* @__PURE__ */ fe(_e), ye = /* @__PURE__ */ de(_e), be = /*@__PURE__*/ ue(.42, 0, 1, 1), xe = /*@__PURE__*/ ue(0, 0, .58, 1), Se = /*@__PURE__*/ ue(.42, 0, .58, 1), Ce = /* @__NO_SIDE_EFFECTS__ */ (e) => Array.isArray(e) && typeof e[0] != "number";
// node_modules/motion-utils/dist/es/easing/utils/get-easing-for-segment.mjs
/*#__NO_SIDE_EFFECTS__*/
function we(e, t) {
	return /* @__PURE__ */ Ce(e) ? e[ce(0, e.length, t)] : e;
}
// node_modules/motion-utils/dist/es/easing/utils/is-bezier-definition.mjs
var Te = /* @__NO_SIDE_EFFECTS__ */ (e) => Array.isArray(e) && typeof e[0] == "number", Ee = {
	linear: k,
	easeIn: be,
	easeInOut: Se,
	easeOut: xe,
	circIn: _e,
	circInOut: ye,
	circOut: ve,
	backIn: me,
	backInOut: he,
	backOut: pe,
	anticipate: ge
}, De = (e) => typeof e == "string", Oe = (e) => {
	if (/* @__PURE__ */ Te(e)) {
		typeof process < "u" && process.env.NODE_ENV !== "production" && T(e.length === 4, "Cubic bezier arrays must contain four numerical values.", "cubic-bezier-length");
		let [t, n, r, i] = e;
		return /* @__PURE__ */ ue(t, n, r, i);
	}
	return De(e) ? (typeof process < "u" && process.env.NODE_ENV !== "production" && T(Ee[e] !== void 0, `Invalid easing type '${e}'`, "invalid-easing-type"), Ee[e]) : e;
}, M = {
	delta: 0,
	timestamp: 0,
	isProcessing: !1
}, ke;
function Ae() {
	ke = void 0;
}
var N = {
	now: () => (ke === void 0 && N.set(M.isProcessing || E.useManualTiming ? M.timestamp : performance.now()), ke),
	set: (e) => {
		ke = e, queueMicrotask(Ae);
	}
}, je = (e) => Math.round(e * 1e5) / 1e5, Me = (e) => (t) => typeof t == "string" && t.startsWith(e), Ne = /*@__PURE__*/ Me("--"), Pe = /*@__PURE__*/ Me("var(--"), Fe = (e) => Pe(e) ? Ie.test(e.split("/*")[0].trim()) : !1, Ie = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
function Le(e) {
	return typeof e == "string" && e.split("/*")[0].includes("var(--");
}
// node_modules/motion-dom/dist/es/value/types/numbers/index.mjs
var Re = {
	test: (e) => typeof e == "number",
	parse: parseFloat,
	transform: (e) => e
}, ze = {
	...Re,
	transform: (e) => S(0, 1, e)
}, Be = {
	...Re,
	default: 1
}, Ve = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
// node_modules/motion-dom/dist/es/value/types/utils/is-nullish.mjs
function He(e) {
	return e == null;
}
// node_modules/motion-dom/dist/es/value/types/utils/single-color-regex.mjs
var Ue = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu, We = (e, t) => (n) => !!(typeof n == "string" && Ue.test(n) && n.startsWith(e) || t && !He(n) && Object.prototype.hasOwnProperty.call(n, t)), Ge = (e, t, n) => (r) => {
	if (typeof r != "string") return r;
	let [i, a, o, s] = r.match(Ve);
	return {
		[e]: parseFloat(i),
		[t]: parseFloat(a),
		[n]: parseFloat(o),
		alpha: s === void 0 ? 1 : parseFloat(s)
	};
}, Ke = (e) => S(0, 255, e), qe = {
	...Re,
	transform: (e) => Math.round(Ke(e))
}, Je = {
	test: /*@__PURE__*/ We("rgb", "red"),
	parse: /*@__PURE__*/ Ge("red", "green", "blue"),
	transform: ({ red: e, green: t, blue: n, alpha: r = 1 }) => "rgba(" + qe.transform(e) + ", " + qe.transform(t) + ", " + qe.transform(n) + ", " + je(ze.transform(r)) + ")"
}, Ye = (e, t, n) => {
	let r = e.substring(1 + t * n, 1 + (t + 1) * n);
	return n > 1 ? r : r + r;
};
function Xe(e) {
	let t = e.length > 5 ? 2 : 1, n = Ye(e, 3, t);
	return {
		red: parseInt(Ye(e, 0, t), 16),
		green: parseInt(Ye(e, 1, t), 16),
		blue: parseInt(Ye(e, 2, t), 16),
		alpha: n ? parseInt(n, 16) / 255 : 1
	};
}
var Ze = {
	test: /*@__PURE__*/ We("#"),
	parse: Xe,
	transform: Je.transform
}, Qe = /* @__NO_SIDE_EFFECTS__ */ (e) => ({
	test: (t) => typeof t == "string" && t.endsWith(e) && t.split(" ").length === 1,
	parse: parseFloat,
	transform: (t) => `${t}${e}`
}), $e = /*@__PURE__*/ Qe("deg"), P = /*@__PURE__*/ Qe("%"), F = /*@__PURE__*/ Qe("px"), et = /*@__PURE__*/ Qe("vh"), tt = /*@__PURE__*/ Qe("vw"), nt = {
	...P,
	parse: (e) => P.parse(e) / 100,
	transform: (e) => P.transform(e * 100)
}, rt = {
	test: /*@__PURE__*/ We("hsl", "hue"),
	parse: /*@__PURE__*/ Ge("hue", "saturation", "lightness"),
	transform: ({ hue: e, saturation: t, lightness: n, alpha: r = 1 }) => "hsla(" + Math.round(e) + ", " + P.transform(je(t)) + ", " + P.transform(je(n)) + ", " + je(ze.transform(r)) + ")"
}, I = {
	test: (e) => Je.test(e) || Ze.test(e) || rt.test(e),
	parse: (e) => Je.test(e) ? Je.parse(e) : rt.test(e) ? rt.parse(e) : Ze.parse(e),
	transform: (e) => typeof e == "string" ? e : e.hasOwnProperty("red") ? Je.transform(e) : rt.transform(e),
	getAnimatableNone: (e) => {
		let t = I.parse(e);
		return t.alpha = 0, I.transform(t);
	}
}, it = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu, at = /*@__PURE__*/ new RegExp(Ve.source), ot = /*@__PURE__*/ new RegExp(it.source, "i");
function st(e) {
	return isNaN(e) && typeof e == "string" && (at.test(e) || ot.test(e));
}
var ct = "number", lt = "color", ut = "var", dt = "var(", ft = "${}", pt = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)(?![a-z]*\()/giu;
function mt(e) {
	let t = e.toString();
	return at.test(t) || ot.test(t);
}
function ht(e) {
	let t = e.toString(), n = [], r = {
		color: [],
		number: [],
		var: []
	}, i = [], a = 0;
	return {
		values: n,
		split: t.replace(pt, (e) => (I.test(e) ? (r.color.push(a), i.push(lt), n.push(I.parse(e))) : e.startsWith(dt) ? (r.var.push(a), i.push(ut), n.push(e)) : (r.number.push(a), i.push(ct), n.push(parseFloat(e))), ++a, ft)).split(ft),
		indexes: r,
		types: i
	};
}
function gt(e) {
	return ht(e).values;
}
function _t({ split: e, types: t }) {
	let n = e.length;
	return (r) => {
		let i = "";
		for (let a = 0; a < n; a++) if (i += e[a], r[a] !== void 0) {
			let e = t[a];
			i += e === ct ? je(r[a]) : e === lt ? I.transform(r[a]) : r[a];
		}
		return i;
	};
}
function vt(e) {
	return _t(ht(e));
}
var yt = (e) => typeof e == "number" ? 0 : I.test(e) ? I.getAnimatableNone(e) : e, bt = (e, t) => typeof e == "number" ? t?.trim().endsWith("/") ? e : 0 : yt(e);
function xt(e) {
	let t = ht(e);
	return _t(t)(t.values.map((e, n) => bt(e, t.split[n])));
}
var L = {
	test: st,
	parse: gt,
	createTransformer: vt,
	getAnimatableNone: xt
};
// node_modules/motion-dom/dist/es/value/types/color/hsla-to-rgba.mjs
function St(e, t, n) {
	return n < 0 && (n += 1), n > 1 && --n, n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e;
}
function Ct({ hue: e, saturation: t, lightness: n, alpha: r }) {
	e /= 360, t /= 100, n /= 100;
	let i = 0, a = 0, o = 0;
	if (!t) i = a = o = n;
	else {
		let r = n < .5 ? n * (1 + t) : n + t - n * t, s = 2 * n - r;
		i = St(s, r, e + 1 / 3), a = St(s, r, e), o = St(s, r, e - 1 / 3);
	}
	return {
		red: Math.round(i * 255),
		green: Math.round(a * 255),
		blue: Math.round(o * 255),
		alpha: r
	};
}
// node_modules/motion-dom/dist/es/utils/mix/immediate.mjs
function wt(e, t) {
	return (n) => n > 0 ? t : e;
}
// node_modules/motion-dom/dist/es/utils/mix/number.mjs
var R = (e, t, n) => e + (t - e) * n, Tt = (e, t, n) => {
	let r = e * e, i = n * (t * t - r) + r;
	return i < 0 ? 0 : Math.sqrt(i);
}, Et = [
	Ze,
	Je,
	rt
], Dt = (e) => Et.find((t) => t.test(e));
function Ot(e) {
	let t = Dt(e);
	if (!t) return process.env.NODE_ENV !== "production" && w(!1, `'${e}' is not an animatable color. Use the equivalent color code instead.`, "color-not-animatable"), !1;
	let n = t.parse(e);
	return t === rt && (n = Ct(n)), n;
}
var kt = (e, t) => {
	let n = Ot(e), r = Ot(t);
	if (!n || !r) return wt(e, t);
	let i = { ...n };
	return (e) => (i.red = Tt(n.red, r.red, e), i.green = Tt(n.green, r.green, e), i.blue = Tt(n.blue, r.blue, e), i.alpha = R(n.alpha, r.alpha, e), Je.transform(i));
}, At = /* @__PURE__ */ new Set(["none", "hidden"]);
function jt(e, t) {
	return At.has(e) ? (n) => n <= 0 ? e : t : (n) => n >= 1 ? t : e;
}
// node_modules/motion-dom/dist/es/utils/mix/complex.mjs
function Mt(e, t) {
	return (n) => R(e, t, n);
}
function Nt(e) {
	return typeof e == "number" ? Mt : typeof e == "string" ? Fe(e) ? wt : I.test(e) ? kt : Lt : Array.isArray(e) ? Pt : typeof e == "object" ? I.test(e) ? kt : Ft : wt;
}
function Pt(e, t) {
	let n = [...e], r = n.length, i = e.map((e, n) => Nt(e)(e, t[n]));
	return (e) => {
		for (let t = 0; t < r; t++) n[t] = i[t](e);
		return n;
	};
}
function Ft(e, t) {
	let n = {
		...e,
		...t
	}, r = {};
	for (let i in n) e[i] !== void 0 && t[i] !== void 0 && (r[i] = Nt(e[i])(e[i], t[i]));
	return (e) => {
		for (let t in r) n[t] = r[t](e);
		return n;
	};
}
function It(e, t) {
	let n = [], r = {
		color: 0,
		var: 0,
		number: 0
	};
	for (let i = 0; i < t.values.length; i++) {
		let a = t.types[i], o = e.indexes[a][r[a]], s = e.values[o] ?? 0;
		n[i] = s, r[a]++;
	}
	return n;
}
var Lt = (e, t) => {
	let n = ht(e), r = ht(t);
	return n.indexes.var.length === r.indexes.var.length && n.indexes.color.length === r.indexes.color.length && n.indexes.number.length >= r.indexes.number.length ? At.has(e) && !r.values.length || At.has(t) && !n.values.length ? jt(e, t) : ne(Pt(It(n, r), r.values), _t(r)) : (process.env.NODE_ENV !== "production" && w(!0, `Complex values '${e}' and '${t}' too different to mix. Ensure all colors are of the same type, and that each contains the same quantity of number and color values. Falling back to instant transition.`, "complex-values-different"), wt(e, t));
}, Rt = /^(-?(?:\d+(?:\.\d*)?|\.\d+))([a-z%]*)$/iu;
function zt(e, t) {
	let n = Rt.exec(e);
	if (!n) return;
	let r = Rt.exec(t);
	if (!r || n[2] !== r[2]) return;
	let i = n[2], a = parseFloat(n[1]), o = parseFloat(r[1]);
	return (e) => je(R(a, o, e)) + i;
}
function Bt(e, t, n) {
	if (typeof e == "number" && typeof t == "number" && typeof n == "number") return R(e, t, n);
	if (typeof e == "string" && typeof t == "string") {
		let n = zt(e, t);
		if (n) return n;
	}
	return Nt(e)(e, t);
}
// node_modules/motion-dom/dist/es/frameloop/order.mjs
var Vt = [
	"setup",
	"read",
	"resolveKeyframes",
	"preUpdate",
	"update",
	"preRender",
	"render",
	"postRender"
];
// node_modules/motion-dom/dist/es/frameloop/render-step.mjs
function Ht(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = !1, i = !1, a, o = /* @__PURE__ */ new Set(), s = {
		delta: 0,
		timestamp: 0,
		isProcessing: !1
	};
	function c(t) {
		o.has(t) && (n.add(t), e()), (a = t)(s);
	}
	let l = {
		schedule: (e, i = !1, s = !1) => {
			let c = s && r, l = c ? t : n;
			return i && o.add(e), c && e !== a && l.delete(e), l.add(e), e;
		},
		cancel: (e) => {
			n.delete(e), o.delete(e);
		},
		process: (e) => {
			if (s = e, r) {
				i = !0;
				return;
			}
			r = !0;
			let o = t;
			t = n, n = o, t.forEach(c), t.clear(), a = void 0, r = !1, i && (i = !1, l.process(e));
		}
	};
	return l;
}
// node_modules/motion-dom/dist/es/frameloop/batcher.mjs
var Ut = 40;
function Wt(e, t, n = {
	delta: 0,
	timestamp: 0,
	isProcessing: !1
}) {
	let r = !1, i = !0, a = () => r = !0, o = Vt.reduce((e, t) => (e[t] = Ht(a), e), {}), { setup: s, read: c, resolveKeyframes: l, preUpdate: u, update: d, preRender: f, render: p, postRender: m } = o, h = () => {
		let a = E.useManualTiming, o = a ? n.timestamp : performance.now();
		r = !1, a || (n.delta = i ? 1e3 / 60 : Math.max(Math.min(o - n.timestamp, Ut), 1)), n.timestamp = o, n.isProcessing = !0, s.process(n), c.process(n), l.process(n), u.process(n), d.process(n), f.process(n), p.process(n), m.process(n), n.isProcessing = !1, r && t && (i = !1, e(h));
	}, g = () => {
		r = !0, i = !0, n.isProcessing || e(h);
	};
	return {
		schedule: Vt.reduce((e, t) => {
			let n = o[t];
			return e[t] = (e, t = !1, i = !1) => (r || g(), n.schedule(e, t, i)), e;
		}, {}),
		cancel: (e) => {
			for (let t = 0; t < Vt.length; t++) o[Vt[t]].cancel(e);
		},
		state: n,
		steps: o
	};
}
// node_modules/motion-dom/dist/es/frameloop/frame.mjs
var { schedule: z, cancel: B, steps: Gt } = /* @__PURE__ */ Wt(typeof requestAnimationFrame < "u" ? requestAnimationFrame : k, !0, M), Kt = (e) => {
	let t = ({ timestamp: t }) => e(t);
	return {
		start: (e = !0) => z.update(t, e),
		stop: () => B(t),
		now: () => M.isProcessing ? M.timestamp : N.now()
	};
}, qt = (e, t, n = 10) => {
	let r = "", i = Math.max(Math.round(t / n), 2);
	for (let t = 0; t < i; t++) r += Math.round(e(t / (i - 1)) * 1e4) / 1e4 + ", ";
	return `linear(${r.substring(0, r.length - 2)})`;
}, Jt = 2e4;
function Yt(e, t = 50, n = Jt, r) {
	let i = 0, a = e.next(i);
	for (r?.push(a.value); !a.done && i < n;) i += t, a = e.next(i), r?.push(a.value);
	return i >= n ? Infinity : i;
}
// node_modules/motion-dom/dist/es/animation/generators/utils/create-generator-easing.mjs
function Xt(e, t = 100, n) {
	let { keyframes: r, velocity: i } = e, a = r && r[r.length - 1] - r[0], o = n({
		...e,
		velocity: i && a ? i * t / a : i,
		keyframes: [0, t]
	}), s = Math.min(Yt(o), Jt);
	return {
		type: "keyframes",
		ease: (e) => o.next(s * e).value / t,
		duration: /* @__PURE__ */ j(s)
	};
}
// node_modules/motion-dom/dist/es/animation/generators/spring.mjs
var Zt = 100, Qt = 10, $t = 1, en = 800, tn = .3, nn = .3, rn = .01, an = 2, on = .005, sn = .5, cn = .01, ln = 10, un = .05, dn = (e) => e < 0 ? 1 / Math.max(1 + e, un) : Math.max(1 - e, un);
function fn(e, t) {
	if (!(e > 1)) return 1;
	let n = Math.sqrt(e * e - 1), r = e - n, i = e + n, a = 2 * n * Math.exp(-t) * (1 + t);
	return hn((e) => i * Math.exp(-r * e) - r * Math.exp(-i * e) - a, (e) => Math.exp(-i * e) - Math.exp(-r * e), t) / t;
}
function pn(e, t) {
	return e * Math.sqrt(1 - t * t);
}
var mn = 12;
function hn(e, t, n) {
	let r = n;
	for (let n = 1; n < mn; n++) r -= e(r) / t(r);
	return r;
}
var gn = .001;
function _n({ duration: e = en, bounce: t = tn }) {
	let n, r;
	process.env.NODE_ENV !== "production" && w(e <= /* @__PURE__ */ A(ln), "Spring duration must be 10 seconds or less", "spring-duration-limit");
	let i = dn(t);
	e = S(cn, ln, /* @__PURE__ */ j(e)), i < 1 ? (n = (t) => {
		let n = t * i, r = n * e, a = pn(t, i), o = Math.exp(-r);
		return gn - n / a * o;
	}, r = (t) => {
		let r = t * i * e, a = i * i * t * t * e, o = Math.exp(-r), s = pn(t * t, i);
		return (-n(t) + gn > 0 ? -1 : 1) * -a * o / s;
	}) : (n = (t) => -.001 + Math.exp(-t * e) * (t * e + 1), r = (t) => Math.exp(-t * e) * (-t * (e * e)));
	let a = 5 / e, o = hn(n, r, a), s = o * fn(i, o * e), c = s * s;
	return {
		stiffness: c,
		damping: i * 2 * Math.sqrt(c),
		duration: /* @__PURE__ */ A(e)
	};
}
var vn = (e, t) => (t ? e >= 0 : e > 0) && e < Infinity;
function yn(e, t) {
	if (vn(e, t)) return e;
	process.env.NODE_ENV !== "production" && w(e === void 0, "Spring stiffness and mass must be positive, damping 0 or greater", "spring-invalid-physics");
}
function bn(e) {
	let t = yn(e.stiffness), n = yn(e.damping, !0), r = yn(e.mass), i = {
		...e,
		stiffness: t ?? Zt,
		damping: n ?? Qt,
		mass: r ?? $t,
		isResolvedFromDuration: !1,
		isTimeDefined: (t ?? n ?? r) === void 0 && (e.duration !== void 0 || e.bounce !== void 0)
	};
	if (i.isTimeDefined) {
		if (e.visualDuration) {
			let t = dn(e.bounce || 0), n = 2 * Math.PI / (e.visualDuration * 1.2) * fn(t, 2 * Math.PI / 1.2);
			i.stiffness = n * n, i.damping = 2 * t * Math.sqrt(i.stiffness);
		} else Object.assign(i, _n(i)), i.isResolvedFromDuration = !0;
		vn(i.stiffness) && vn(i.damping, !0) || (i.stiffness = Zt, i.damping = Qt);
	}
	return i;
}
function xn(e = nn, t = tn) {
	let n = typeof e == "object" ? e : {
		visualDuration: e,
		keyframes: [0, 1],
		bounce: t
	}, r = n.keyframes[0], i = n.keyframes[n.keyframes.length - 1], a = {
		done: !1,
		value: r
	}, { stiffness: o, damping: s, mass: c, duration: l, isResolvedFromDuration: u, isTimeDefined: d } = bn({ ...n }), f = (e) => u ? 0 : -/* @__PURE__ */ j(e), p = s / (2 * Math.sqrt(o * c)), m = /* @__PURE__ */ j(Math.sqrt(o / c)), h = p * m, g = {
		target: i,
		delta: i - r,
		velocity: f(n.velocity) || 0,
		restSpeed: 0,
		restDelta: 0
	}, _ = () => {
		let e = Math.abs(g.delta) < 5;
		g.restSpeed = n.restSpeed || (e ? rn : an), g.restDelta = n.restDelta || (e ? on : sn);
	};
	_();
	let v, y, b;
	if (p < 1) {
		let e = pn(m, p), t = {
			A: 0,
			sinC: 0,
			cosC: 0,
			t: -1,
			env: 0,
			sin: 0,
			cos: 0
		};
		b = () => {
			t.A = (g.velocity + h * g.delta) / e, t.sinC = h * t.A + g.delta * e, t.cosC = h * g.delta - t.A * e;
		};
		let n = (n) => {
			n !== t.t && (t.t = n, t.env = Math.exp(-h * n), t.sin = Math.sin(e * n), t.cos = Math.cos(e * n));
		};
		v = (e) => (n(e), g.target - t.env * (t.A * t.sin + g.delta * t.cos)), y = (e) => (n(e), t.env * (t.sinC * t.sin + t.cosC * t.cos));
	} else if (p === 1) {
		v = (e) => g.target - Math.exp(-m * e) * (g.delta + (g.velocity + m * g.delta) * e);
		let e = { C: 0 };
		b = () => {
			e.C = g.velocity + m * g.delta;
		}, y = (t) => Math.exp(-m * t) * (m * e.C * t - g.velocity);
	} else {
		let e = m * Math.sqrt(p * p - 1), t = h - e, n = h + e, r = e < 1 || d ? Infinity : 300 / e, i = (e, t) => Math.exp(t > r ? (h - e) * r - h * t : -e * t), a = {
			S: 0,
			F: 0
		};
		b = () => {
			let t = (g.velocity + h * g.delta) / e;
			a.S = (g.delta + t) / 2, a.F = (g.delta - t) / 2;
		}, v = (e) => g.target - a.S * i(t, e) - a.F * i(n, e), y = (e) => t * a.S * i(t, e) + n * a.F * i(n, e);
	}
	b();
	let x = u && l || null, S = {
		calculatedDuration: x,
		retarget: (e, t) => {
			g.target = e[e.length - 1], g.delta = g.target - e[0], g.velocity = f(t), n.restSpeed && n.restDelta || _(), S.calculatedDuration = x, a.done = !1, b();
		},
		velocity: (e) => /* @__PURE__ */ A(y(e)),
		next: (e) => {
			let t = v(e);
			if (u) a.done = e >= l;
			else {
				let n = /* @__PURE__ */ A(y(e));
				a.done = Math.abs(n) <= g.restSpeed && Math.abs(g.target - t) <= g.restDelta;
			}
			return a.value = a.done ? g.target : t, a;
		},
		toString: () => {
			let e = Math.min(Yt(S), Jt), t = qt((t) => S.next(e * t).value, e, 30);
			return e + "ms " + t;
		}
	};
	return S;
}
var Sn = /* @__PURE__ */ Object.assign(xn, { applyToOptions: (e) => {
	let t = Xt(e, 100, xn);
	return e.ease = t.ease, e.duration = /* @__PURE__ */ A(t.duration), e.type = "keyframes", e;
} });
// node_modules/motion-dom/dist/es/animation/generators/inertia.mjs
function Cn({ keyframes: e, velocity: t = 0, power: n = .8, timeConstant: r = 325, bounceDamping: i = 10, bounceStiffness: a = 500, modifyTarget: o, min: s, max: c, restDelta: l = .5, restSpeed: u }) {
	let d = e[0], f = {
		done: !1,
		value: d
	}, p = (e) => e < s || e > c, m = (e) => s === void 0 ? c : c === void 0 || Math.abs(s - e) < Math.abs(c - e) ? s : c, h = n * t, g = d + h, _ = o ? o(g) : g;
	_ !== g && (h = _ - d);
	let v = (e) => -h * Math.exp(-e / r), y = (e) => {
		let t = v(e);
		f.done = Math.abs(t) <= l, f.value = f.done ? _ : e ? _ + t : d;
	}, b, x, S = (e) => {
		p(f.value) && (b = e, x = Sn({
			keyframes: [f.value, m(f.value)],
			velocity: -v(e) / r * 1e3,
			damping: i,
			stiffness: a,
			restDelta: l,
			restSpeed: u
		}));
	};
	return S(0), {
		calculatedDuration: null,
		next: (e) => {
			let t = !1;
			return !x && b === void 0 && (t = !0, y(e), S(e)), b !== void 0 && e >= b ? x.next(e - b) : (!t && y(e), f);
		}
	};
}
// node_modules/motion-dom/dist/es/utils/interpolate.mjs
function wn(e, t, n) {
	let r = [], i = E.mix || Bt, a = e.length - 1;
	for (let o = 0; o < a; o++) {
		let a = n?.(e[o], e[o + 1]) || i(e[o], e[o + 1]);
		t && (a = ne(Array.isArray(t) ? t[o] || k : t, a)), r.push(a);
	}
	return r;
}
function Tn(e, t, { clamp: n = !0, ease: r, mixer: i } = {}) {
	let a = e.length;
	if (process.env.NODE_ENV !== "production" && T(a === t.length, "Both input and output ranges must be the same length", "range-length"), a === 1) return () => t[0];
	if (a === 2 && t[0] === t[1]) return () => t[1];
	let o = e[0] === e[1];
	e[0] > e[a - 1] && (e = [...e].reverse(), t = [...t].reverse());
	let s = wn(t, r, i), c = s.length, l = (n) => {
		if (o && n < e[0]) return t[0];
		let r = 0;
		if (c > 1) for (; r < e.length - 2 && !(n < e[r + 1]); r++);
		let i = /* @__PURE__ */ re(e[r], e[r + 1], n);
		return s[r](i);
	};
	return n ? (t) => l(S(e[0], e[a - 1], t)) : l;
}
// node_modules/motion-dom/dist/es/animation/keyframes/offsets/fill.mjs
function En(e, t) {
	let n = e[e.length - 1];
	for (let r = 1; r <= t; r++) {
		let i = /* @__PURE__ */ re(0, t, r);
		e.push(R(n, 1, i));
	}
}
// node_modules/motion-dom/dist/es/animation/keyframes/offsets/default.mjs
function Dn(e) {
	let t = [0];
	return En(t, e.length - 1), t;
}
// node_modules/motion-dom/dist/es/animation/keyframes/offsets/time.mjs
function On(e, t) {
	return e.map((e) => e * t);
}
// node_modules/motion-dom/dist/es/animation/generators/keyframes.mjs
function kn(e, t) {
	return e.map(() => t || Se).splice(0, e.length - 1);
}
function V({ duration: e = 300, keyframes: t, times: n, ease: r = "easeInOut", mixer: i }) {
	let a = typeof t[0] == "number" ? void 0 : i, o = /* @__PURE__ */ Ce(r) ? r.map(Oe) : Oe(r) || Se, s = {
		done: !1,
		value: t[0]
	}, c = -1;
	if (!a) {
		for (let e = 1; e < t.length; e++) if (t[e] !== t[e - 1]) {
			if (c >= 0) {
				c = -2;
				break;
			}
			c = e - 1;
		}
	}
	if (c >= 0) {
		let r = n && n.length === t.length ? n : Dn(t), i = r[c] * e, a = r[c + 1] * e, l = t[c], u = t[c + 1], d = Array.isArray(o) ? o[c] : o, f = (E.mix || Bt)(l, u), p = t.length - 2;
		return {
			calculatedDuration: e,
			next: (t) => (s.value = c && t < i ? f(0) : c < p && (t >= a || !e) ? typeof u == "number" ? u : f(1) : f(d(t >= a || !e ? 1 : t <= i ? 0 : (t - i) / (a - i))), s.done = t >= e, s)
		};
	}
	let l = Tn(On(n && n.length === t.length ? n : Dn(t), e), t, {
		ease: Array.isArray(o) ? o : kn(t, o),
		mixer: a
	});
	return {
		calculatedDuration: e,
		next: (t) => (s.value = l(t), s.done = t >= e, s)
	};
}
// node_modules/motion-dom/dist/es/animation/generators/utils/velocity.mjs
var An = 5;
function jn(e, t, n) {
	let r = Math.max(t - An, 0);
	return /* @__PURE__ */ ae(n - e(r), t - r);
}
function Mn(e, t, n = 0) {
	return t <= 0 ? n : e.velocity ? e.velocity(t) : jn((t) => e.next(t).value, t, e.next(t).value);
}
// node_modules/motion-dom/dist/es/animation/keyframes/get-final.mjs
function Nn(e, { repeat: t, repeatType: n = "loop" }, r, i = 1) {
	let a, o, s = 0;
	for (let t = 0; t < e.length; t++) {
		let n = e[t];
		n !== null && (s++ || (a = n), o = n);
	}
	let c = i < 0 || t && n !== "loop" && t % 2 == 1 ? 0 : s - 1;
	return !c || r === void 0 ? c ? o : a : r;
}
// node_modules/motion-dom/dist/es/animation/utils/replace-transition-type.mjs
var Pn = {
	decay: Cn,
	inertia: Cn,
	tween: V,
	keyframes: V,
	spring: Sn
};
function Fn(e) {
	typeof e.type == "string" && (e.type = Pn[e.type]);
}
// node_modules/motion-dom/dist/es/animation/utils/resolve-start-time.mjs
var In = 40, Ln = (e, t) => t - e > In && !E.useManualTiming ? t : e;
// node_modules/motion-dom/dist/es/animation/utils/notify-inspector.mjs
function Rn(e, t) {
	return {
		kind: e,
		animation: t,
		timestamp: N.now(),
		frameTimestamp: M.timestamp,
		frameIsProcessing: M.isProcessing
	};
}
function zn(e, t, n) {
	let r = globalThis.__MOTION_INSPECT__;
	if (r) try {
		r({
			...Rn("animation-start", e),
			options: n ? {
				...t,
				...n
			} : t
		});
	} catch {}
}
function Bn(e, t) {
	let n = globalThis.__MOTION_INSPECT__;
	if (n) try {
		n({
			...Rn("layout-animation-start", e),
			node: t
		});
	} catch {}
}
// node_modules/motion-dom/dist/es/animation/utils/WithPromise.mjs
var Vn = class {
	constructor() {
		this.isResolved = !1;
	}
	get finished() {
		return this._finished ||= this.isResolved ? Promise.resolve() : new Promise((e) => {
			this._resolve = e;
		}), this._finished;
	}
	updateFinished() {
		this._finished = this._resolve = void 0, this.isResolved = !1;
	}
	notifyFinished() {
		this.isResolved = !0, this._resolve?.();
	}
	then(e, t) {
		return this.finished.then(e, t);
	}
}, Hn = (e) => e / 100, Un = (e) => Math.round(e * 1e4) / 1e4, Wn = class extends Vn {
	constructor(e) {
		super(), this.state = "idle", this.startTime = null, this.isStopped = !1, this.currentTime = 0, this.holdTime = null, this.playbackSpeed = 1, this.delayState = {
			done: !1,
			value: void 0
		}, this.stop = () => {
			let { motionValue: e } = this.options, t = N.now();
			e && e.updatedAt !== t && this.tick(e.updatedAt = t), this.isStopped = !0, this.state !== "idle" && (this.teardown(), this.options.onStop?.());
		}, this.options = e, this.initAnimation(), this.play(), e.autoplay === !1 && this.pause(), zn(this, this.options);
	}
	initAnimation() {
		let { options: e } = this;
		Fn(e);
		let { type: t = V, repeat: n = 0, repeatDelay: r = 0, repeatType: i, velocity: a = 0 } = e, { keyframes: o } = e, s = t || V;
		process.env.NODE_ENV !== "production" && s !== V && T(o.length <= 2, `Only two keyframes currently supported with spring and inertia animations. Trying to animate ${o}`, "spring-two-frames"), this.mixKeyframes = void 0, s !== V && typeof o[0] != "number" && (this.mixKeyframes = ne(Hn, e.mixer?.(o[0], o[1]) || Bt(o[0], o[1])), o = [0, 100]);
		let c = s(o === e.keyframes ? e : {
			...e,
			keyframes: o
		});
		i === "mirror" && (this.mirroredGenerator = s({
			...e,
			keyframes: [...o].reverse(),
			velocity: -a
		})), c.calculatedDuration === null && (c.calculatedDuration = Yt(c));
		let { calculatedDuration: l } = c;
		this.calculatedDuration = l, this.resolvedDuration = l + r, this.totalDuration = this.resolvedDuration * (n + 1) - r, this.generator = c;
	}
	updateTime(e) {
		this.currentTime = this.holdTime ?? Math.round(e - this.startTime) * this.playbackSpeed;
	}
	tick(e, t = !1) {
		let { generator: n, totalDuration: r, calculatedDuration: i } = this;
		if (this.startTime === null) return n.next(0);
		let { delay: a = 0, keyframes: o, type: s, onUpdate: c, finalKeyframe: l } = this.options;
		this.startTime === this.pendingStartTime && (this.startTime = Ln(this.startTime, e)), this.pendingStartTime = void 0, this.speed > 0 ? this.startTime = Math.min(this.startTime, e) : this.speed < 0 && (this.startTime = Math.min(e - r / this.speed, this.startTime)), t ? this.currentTime = e : this.updateTime(e);
		let u = this.currentTime - a * (this.playbackSpeed >= 0 ? 1 : -1), d = this.playbackSpeed >= 0 ? u < 0 : u > r;
		this.currentTime = Math.max(u, 0), this.state === "finished" && this.holdTime === null && (this.currentTime = r);
		let f = this.generate(this.currentTime, d), { done: p } = f;
		d || (p = this.playbackSpeed >= 0 ? i < Infinity ? this.currentTime >= r : p : this.currentTime <= 0);
		let m = this.holdTime === null && (this.state === "finished" || this.state === "running" && p);
		return m && s !== Cn && (f.value = Nn(o, this.options, l, this.speed)), c && c(f.value), m && this.finish(), f;
	}
	at(e) {
		return this.holdTime ?? Un((e - this.startTime) * this.playbackSpeed);
	}
	sampleAt(e, t) {
		let { options: n, totalDuration: r } = this, i = this.at(e) - (n.delay || 0);
		return i >= r && n.type !== Cn ? Nn(n.keyframes, n, t ? void 0 : n.finalKeyframe) : this.generate(Math.max(i, 0), i < 0).value;
	}
	generate(e, t) {
		let { generator: n, totalDuration: r, mixKeyframes: i, mirroredGenerator: a, resolvedDuration: o } = this, { keyframes: s, repeat: c, repeatType: l, repeatDelay: u } = this.options, d = e, f = n;
		if (c) {
			let t = Math.min(e, r) / o, n = Math.floor(t), i = t % 1;
			!i && t >= 1 && (i = 1), i === 1 && n--, n = Math.min(n, c + 1), n % 2 && (l === "reverse" ? (i = 1 - i, u && (i -= u / o)) : l === "mirror" && (f = a)), d = S(0, 1, i) * o;
		}
		let p;
		return t ? (this.delayState.value = s[0], p = this.delayState) : p = f.next(d), i && !t && (p.value = i(p.value)), p;
	}
	get duration() {
		return /* @__PURE__ */ j(this.calculatedDuration);
	}
	get iterationDuration() {
		return this.duration + /* @__PURE__ */ j(this.options.delay ?? 0);
	}
	get time() {
		return /* @__PURE__ */ j(this.currentTime);
	}
	set time(e) {
		this.state === "finished" && this.updateFinished(), e = /* @__PURE__ */ A(e), this.currentTime = e, this.startTime === null || this.holdTime !== null || this.playbackSpeed === 0 ? this.holdTime = e : this.driver && (this.startTime = this.driver.now() - e / this.playbackSpeed), this.driver ? this.driver.start(!1) : (this.startTime = 0, this.state = "paused", this.holdTime = e, this.tick(e));
	}
	getGeneratorVelocity() {
		return Mn(this.generator, this.currentTime, this.options.velocity);
	}
	get speed() {
		return this.playbackSpeed;
	}
	set speed(e) {
		let t = this.playbackSpeed !== e;
		t && this.driver && this.updateTime(N.now()), this.playbackSpeed = e, t && this.driver && (this.time = /* @__PURE__ */ j(this.currentTime));
	}
	play() {
		if (this.isStopped) return;
		let { driver: e = Kt, startTime: t } = this.options;
		this.driver ||= e((e) => this.tick(e)), this.options.onPlay?.();
		let n = this.driver.now();
		this.state === "finished" ? (this.updateFinished(), this.startTime = n) : this.holdTime === null ? this.startTime ||= t ?? (this.pendingStartTime = n) : this.startTime = n - this.holdTime / (this.playbackSpeed || 1), this.state === "finished" && this.speed < 0 && (this.startTime += this.calculatedDuration), this.holdTime = null, this.state = "running", this.driver.start();
	}
	pause() {
		this.state = "paused", this.updateTime(N.now()), this.holdTime = this.currentTime;
	}
	complete() {
		this.state !== "running" && this.play(), this.state = "finished", this.holdTime = null;
	}
	finish() {
		this.notifyFinished(), this.teardown(), this.state = "finished", this.options.onComplete?.();
	}
	cancel() {
		this.holdTime = null, this.startTime = 0, this.tick(0), this.teardown(), this.options.onCancel?.();
	}
	teardown() {
		this.state = "idle", this.driver?.stop(), this.driver = void 0, this.startTime = this.holdTime = null;
	}
	sample(e) {
		return this.startTime = 0, this.tick(e, !0);
	}
	attachTimeline(e) {
		return this.options.allowFlatten && (this.options.type = "keyframes", this.options.ease = "linear", this.initAnimation()), this.driver?.stop(), e.observe(this);
	}
}, Gn = /* @__PURE__ */ new Set([
	"brightness",
	"contrast",
	"saturate",
	"opacity"
]);
function Kn(e) {
	let [t, n] = e.slice(0, -1).split("(");
	if (t === "drop-shadow") return e;
	let [r] = n.match(Ve) || [];
	if (!r) return e;
	let i = n.replace(r, ""), a = +!!Gn.has(t);
	return r !== n && (a *= 100), t + "(" + a + i + ")";
}
var qn = /\b([a-z-]*)\(.*?\)/gu, Jn = {
	...L,
	getAnimatableNone: (e) => {
		let t = e.match(qn);
		return t ? t.map(Kn).join(" ") : e;
	}
}, Yn = {
	...L,
	getAnimatableNone: (e) => {
		let t = L.parse(e);
		return L.createTransformer(e)(t.map((e) => typeof e == "number" ? 0 : typeof e == "object" ? {
			...e,
			alpha: 1
		} : e));
	}
}, Xn = {
	...Re,
	transform: Math.round
}, Zn = {
	rotate: $e,
	pathRotation: $e,
	rotateX: $e,
	rotateY: $e,
	rotateZ: $e,
	scale: Be,
	scaleX: Be,
	scaleY: Be,
	scaleZ: Be,
	skew: $e,
	skewX: $e,
	skewY: $e,
	distance: F,
	translateX: F,
	translateY: F,
	translateZ: F,
	x: F,
	y: F,
	z: F,
	perspective: F,
	transformPerspective: F,
	opacity: ze,
	originX: nt,
	originY: nt,
	originZ: F
}, H = {
	borderWidth: F,
	borderTopWidth: F,
	borderRightWidth: F,
	borderBottomWidth: F,
	borderLeftWidth: F,
	borderRadius: F,
	borderTopLeftRadius: F,
	borderTopRightRadius: F,
	borderBottomRightRadius: F,
	borderBottomLeftRadius: F,
	width: F,
	maxWidth: F,
	height: F,
	maxHeight: F,
	top: F,
	right: F,
	bottom: F,
	left: F,
	inset: F,
	insetBlock: F,
	insetBlockStart: F,
	insetBlockEnd: F,
	insetInline: F,
	insetInlineStart: F,
	insetInlineEnd: F,
	padding: F,
	paddingTop: F,
	paddingRight: F,
	paddingBottom: F,
	paddingLeft: F,
	paddingBlock: F,
	paddingBlockStart: F,
	paddingBlockEnd: F,
	paddingInline: F,
	paddingInlineStart: F,
	paddingInlineEnd: F,
	margin: F,
	marginTop: F,
	marginRight: F,
	marginBottom: F,
	marginLeft: F,
	marginBlock: F,
	marginBlockStart: F,
	marginBlockEnd: F,
	marginInline: F,
	marginInlineStart: F,
	marginInlineEnd: F,
	fontSize: F,
	backgroundPositionX: F,
	backgroundPositionY: F,
	...Zn,
	zIndex: Xn,
	fillOpacity: ze,
	strokeOpacity: ze,
	numOctaves: Xn
}, Qn = {
	...H,
	color: I,
	backgroundColor: I,
	outlineColor: I,
	fill: I,
	stroke: I,
	borderColor: I,
	borderTopColor: I,
	borderRightColor: I,
	borderBottomColor: I,
	borderLeftColor: I,
	filter: Jn,
	WebkitFilter: Jn,
	mask: Yn,
	WebkitMask: Yn
}, $n = (e) => Qn[e], er = /*@__PURE__*/ new Set([Jn, Yn]), tr, nr, rr;
function ir(e, t) {
	if (e === tr && t === nr) return rr;
	let n = $n(e);
	return er.has(n) || (n = L), rr = n.getAnimatableNone ? n.getAnimatableNone(t) : void 0, tr = e, nr = t, rr;
}
// node_modules/motion-dom/dist/es/animation/keyframes/utils/fill-wildcards.mjs
function ar(e) {
	for (let t = 1; t < e.length; t++) e[t] ?? (e[t] = e[t - 1]);
}
// node_modules/motion-dom/dist/es/render/dom/parse-transform.mjs
var or = (e) => e * 180 / Math.PI, sr = (e) => lr(or(Math.atan2(e[1], e[0]))), cr = {
	x: 4,
	y: 5,
	translateX: 4,
	translateY: 5,
	scaleX: 0,
	scaleY: 3,
	scaleZ: () => 1,
	scale: (e) => (Math.abs(e[0]) + Math.abs(e[3])) / 2,
	rotate: sr,
	rotateZ: sr,
	skewX: (e) => or(Math.atan(e[1])),
	skewY: (e) => or(Math.atan(e[2])),
	skew: (e) => (Math.abs(e[1]) + Math.abs(e[2])) / 2
}, lr = (e) => (e %= 360, e < 0 && (e += 360), e), ur = sr, dr = (e) => Math.hypot(e[0], e[1]), fr = (e) => Math.hypot(e[4], e[5]), pr = {
	x: 12,
	y: 13,
	z: 14,
	translateX: 12,
	translateY: 13,
	translateZ: 14,
	scaleX: dr,
	scaleY: fr,
	scaleZ: (e) => Math.hypot(e[8], e[9], e[10]),
	scale: (e) => (dr(e) + fr(e)) / 2,
	rotateX: (e) => lr(or(Math.atan2(e[6], e[5]))),
	rotateY: (e) => lr(or(Math.atan2(-e[2], e[0]))),
	rotateZ: ur,
	rotate: ur,
	skewX: (e) => or(Math.atan(e[4])),
	skewY: (e) => or(Math.atan(e[1])),
	skew: (e) => (Math.abs(e[1]) + Math.abs(e[4])) / 2
};
function mr(e) {
	return +!!e.includes("scale");
}
function hr(e, t) {
	if (!e || e === "none") return mr(t);
	let n = e.match(/^matrix(3d)?\(([-\d.e\s,]+)\)$/u);
	if (!n) return mr(t);
	let r = (n[1] ? pr : cr)[t], i = n[2].split(",").map((e) => parseFloat(e));
	return typeof r == "function" ? r(i) : i[r];
}
var gr = (e, t) => {
	let { transform: n = "none" } = getComputedStyle(e);
	return hr(n, t);
}, U = [
	"transformPerspective",
	"x",
	"y",
	"z",
	"translateX",
	"translateY",
	"translateZ",
	"scale",
	"scaleX",
	"scaleY",
	"scaleZ",
	"rotate",
	"rotateX",
	"rotateY",
	"rotateZ",
	"skew",
	"skewX",
	"skewY"
], W = /* @__PURE__ */ new Set([...U, "pathRotation"]), _r = (e) => e === Re || e === F, vr = /* @__PURE__ */ new Set([
	"x",
	"y",
	"z"
]), yr = /* @__PURE__ */ U.filter((e) => !vr.has(e));
function br(e) {
	let t = [];
	return yr.forEach((n) => {
		let r = e.getValue(n);
		if (r !== void 0) {
			let e = r.get(), i = +!!n.startsWith("scale");
			if (e === i) return;
			t.push([n, e]), r.set(i);
		}
	}), t;
}
var xr = /* @__PURE__ */ new Set(["bottom", "right"]);
function Sr(e, t, n, r, i, a) {
	let o = parseFloat(e);
	if (!isNaN(o)) return o;
	let { min: s, max: c } = t()[n], l = c - s;
	return a === "border-box" ? l : l - parseFloat(r) - parseFloat(i);
}
var Cr = ({ transform: e }) => hr(e, "x"), wr = ({ transform: e }) => hr(e, "y"), Tr = {
	width: ({ width: e, paddingLeft: t = "0", paddingRight: n = "0", boxSizing: r }, i) => Sr(e, i, "x", t, n, r),
	height: ({ height: e, paddingTop: t = "0", paddingBottom: n = "0", boxSizing: r }, i) => Sr(e, i, "y", t, n, r),
	top: ({ top: e }) => parseFloat(e),
	left: ({ left: e }) => parseFloat(e),
	bottom: ({ top: e }, t) => {
		let { y: n } = t();
		return parseFloat(e) + (n.max - n.min);
	},
	right: ({ left: e }, t) => {
		let { x: n } = t();
		return parseFloat(e) + (n.max - n.min);
	},
	x: Cr,
	y: wr,
	translateX: Cr,
	translateY: wr
}, Er = /* @__PURE__ */ new Set(), Dr = !1, Or = !1, kr = !1;
function Ar() {
	if (Or) {
		let e = [], t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set();
		Er.forEach((r) => {
			r.needsMeasurement && (e.push(r), t.add(r.element), xr.has(r.name) && n.add(r.element));
		});
		let r = /* @__PURE__ */ new Map();
		n.forEach((e) => {
			let t = br(e);
			t.length && (r.set(e, t), e.render());
		}), e.forEach((e) => e.measureInitialState()), t.forEach((e) => {
			e.render();
			let t = r.get(e);
			t && t.forEach(([t, n]) => {
				e.getValue(t)?.set(n);
			});
		}), e.forEach((e) => e.measureEndState()), e.forEach((e) => {
			e.suspendedScrollY !== void 0 && window.scrollTo(0, e.suspendedScrollY);
		});
	}
	Or = !1, Dr = !1, Er.forEach((e) => e.complete(kr)), Er.clear();
}
function jr() {
	Er.forEach((e) => {
		e.readKeyframes(), e.needsMeasurement && (Or = !0);
	});
}
function Mr() {
	kr = !0, jr(), Ar(), kr = !1;
}
function Nr(e, t, n) {
	if (typeof e == "string") {
		if (D(e) || ee(e)) return parseFloat(e);
		if (!L.test(e) && L.test(n)) return ir(t, n);
	}
	return e ?? void 0;
}
var Pr = class {
	constructor(e, t, n, r, i, a = !1) {
		this.state = "pending", this.isAsync = !1, this.needsMeasurement = !1, this.unresolvedKeyframes = [...e], this.onComplete = t, this.name = n, this.motionValue = r, this.element = i, this.isAsync = a;
	}
	scheduleResolve() {
		this.state = "scheduled", this.isAsync ? (Er.add(this), Dr || (Dr = !0, z.read(jr), z.resolveKeyframes(Ar))) : (this.readKeyframes(), this.complete());
	}
	readKeyframes() {
		let { unresolvedKeyframes: e, name: t, element: n, motionValue: r } = this;
		if (e[0] === null) {
			let i = r?.get(), a = e[e.length - 1];
			if (i !== void 0) e[0] = i;
			else if (n && t) {
				let r = Nr(n.readValue(t, a), t, a);
				r !== void 0 && (e[0] = r);
			}
			e[0] === void 0 && (e[0] = a), r && i === void 0 && r.set(e[0]);
		}
		ar(e);
	}
	setFinalKeyframe() {}
	measureInitialState() {}
	renderEndStyles() {}
	measureEndState() {}
	complete(e = !1) {
		this.state = "complete", this.onComplete(this.unresolvedKeyframes, this.finalKeyframe, e), Er.delete(this);
	}
	cancel() {
		this.state === "scheduled" && (Er.delete(this), this.state = "pending");
	}
	resume() {
		this.state === "pending" && this.scheduleResolve();
	}
}, Fr = (e) => e.startsWith("--");
// node_modules/motion-dom/dist/es/render/dom/style-set.mjs
function Ir(e, t, n) {
	Fr(t) ? e.style.setProperty(t, n) : e.style[t] = n;
}
// node_modules/motion-dom/dist/es/utils/supports/flags.mjs
var Lr = {};
// node_modules/motion-dom/dist/es/utils/supports/memo.mjs
function Rr(e, t) {
	let n = /* @__PURE__ */ te(e);
	return () => Lr[t] ?? n();
}
// node_modules/motion-dom/dist/es/utils/supports/scroll-timeline.mjs
var zr = /* @__PURE__ */ Rr(() => window.ScrollTimeline !== void 0, "scrollTimeline"), Br = /*@__PURE__*/ Rr(() => {
	try {
		document.createElement("div").animate({ opacity: 0 }, { easing: "linear(0, 1)" });
	} catch {
		return !1;
	}
	return !0;
}, "linearEasing"), Vr = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`, Hr = {
	linear: "linear",
	ease: "ease",
	easeIn: "ease-in",
	easeOut: "ease-out",
	easeInOut: "ease-in-out",
	circIn: /*@__PURE__*/ Vr([
		0,
		.65,
		.55,
		1
	]),
	circOut: /*@__PURE__*/ Vr([
		.55,
		0,
		1,
		.45
	]),
	backIn: /*@__PURE__*/ Vr([
		.31,
		.01,
		.66,
		-.59
	]),
	backOut: /*@__PURE__*/ Vr([
		.33,
		1.53,
		.69,
		.99
	])
};
// node_modules/motion-dom/dist/es/animation/waapi/easing/map-easing.mjs
function Ur(e, t) {
	if (e) return typeof e == "function" ? Br() ? qt(e, t) : "ease-out" : /* @__PURE__ */ Te(e) ? Vr(e) : Array.isArray(e) ? e.map((e) => Ur(e, t) || Hr.easeOut) : Hr[e];
}
// node_modules/motion-dom/dist/es/animation/waapi/start-waapi-animation.mjs
function Wr(e, t, n, { delay: r = 0, duration: i = 300, repeat: a = 0, repeatType: o = "loop", ease: s = "easeOut", times: c } = {}, l = void 0) {
	let u = { [t]: n };
	c && (u.offset = c);
	let d = Ur(s, i);
	Array.isArray(d) && (u.easing = d);
	let f = {
		delay: r,
		duration: i,
		easing: Array.isArray(d) ? "linear" : d,
		fill: "both",
		iterations: a + 1,
		direction: o === "reverse" ? "alternate" : "normal"
	};
	return l && (f.pseudoElement = l), e.animate(u, f);
}
// node_modules/motion-dom/dist/es/animation/generators/utils/is-generator.mjs
function Gr(e) {
	return typeof e == "function" && "applyToOptions" in e;
}
// node_modules/motion-dom/dist/es/animation/waapi/utils/apply-generator.mjs
function Kr({ type: e, ...t }) {
	return Gr(e) && Br() ? e.applyToOptions(t) : (t.duration ??= 300, t.ease ??= "easeOut", t);
}
// node_modules/motion-dom/dist/es/animation/NativeAnimation.mjs
var qr = class extends Vn {
	constructor(e) {
		if (super(), this.finishedTime = null, this.isStopped = !1, this.manualStartTime = null, !e) return;
		let { element: t, name: n, keyframes: r, pseudoElement: i, allowFlatten: a = !1, finalKeyframe: o, onComplete: s } = e;
		this.isPseudoElement = !!i, this.allowFlatten = a, this.options = e, typeof process < "u" && process.env.NODE_ENV !== "production" && T(typeof e.type != "string", "Mini animate() doesn't support \"type\" as a string.", "mini-spring");
		let c = Kr(e);
		this.animation = Wr(t, n, r, c, i), c.autoplay === !1 && this.animation.pause(), this.animation.onfinish = this.onFinish = () => {
			if (this.animation.onfinish = null, this.finishedTime = this.time, !i) {
				let e = Nn(r, this.options, o, this.speed);
				this.updateMotionValue?.(e), Ir(t, n, e), this.animation.cancel();
			}
			s?.(), this.notifyFinished();
		}, zn(this, e, c);
	}
	play() {
		this.isStopped || (this.manualStartTime = null, this.animation.onfinish = this.onFinish, this.animation.play(), this.state === "finished" && this.updateFinished());
	}
	pause() {
		this.animation.pause();
	}
	complete() {
		this.isStopped || (this.animation.onfinish = this.onFinish), this.animation.finish?.();
	}
	cancel() {
		this.animation.onfinish = null;
		try {
			this.animation.cancel();
		} catch {}
	}
	stop() {
		this.isStopped || (this.isStopped = !0, this.state !== "idle" && this.finishedTime === null && (this.updateMotionValue ? this.updateMotionValue() : this.commitStyles(), this.isPseudoElement || this.cancel()));
	}
	commitStyles() {
		let e = this.options?.element;
		!this.isPseudoElement && e?.isConnected && this.animation.commitStyles?.();
	}
	get duration() {
		let e = this.animation.effect?.getComputedTiming?.().duration || 0;
		return /* @__PURE__ */ j(Number(e));
	}
	get iterationDuration() {
		let { delay: e = 0 } = this.options || {};
		return this.duration + /* @__PURE__ */ j(e);
	}
	get time() {
		return /* @__PURE__ */ j(Number(this.animation.currentTime) || 0);
	}
	set time(e) {
		let t = this.finishedTime !== null;
		this.manualStartTime = null, this.finishedTime = null, this.animation.currentTime = /* @__PURE__ */ A(e), t && (this.animation.pause(), this.updateFinished());
	}
	get speed() {
		return this.animation.playbackRate;
	}
	set speed(e) {
		e < 0 && (this.finishedTime = null), this.animation.playbackRate = e;
	}
	get state() {
		return this.finishedTime === null ? this.animation.playState : "finished";
	}
	get startTime() {
		return this.manualStartTime ?? Number(this.animation.startTime);
	}
	set startTime(e) {
		this.manualStartTime = this.animation.startTime = e;
	}
	attachTimeline({ timeline: e, onAttach: t, observe: n }) {
		return this.allowFlatten && this.animation.effect?.updateTiming({ easing: "linear" }), this.animation.onfinish = this.onFinish = null, e && zr() ? (this.animation.timeline = e, t?.(this.animation), k) : n(this);
	}
}, Jr = {
	anticipate: ge,
	backInOut: he,
	circInOut: ye
};
function Yr(e) {
	return e in Jr;
}
function Xr(e) {
	typeof e.ease == "string" && Yr(e.ease) && (e.ease = Jr[e.ease]);
}
var Zr = class extends qr {
	constructor(e) {
		Xr(e), Fn(e), super(e), e.startTime !== void 0 && e.autoplay !== !1 && (this.startTime = e.startTime), this.options = e;
	}
	elapsed() {
		return this.state === "running" ? (N.now() - this.startTime) * this.speed : this.time * 1e3;
	}
	sample(e) {
		if (!this.sampler) {
			let { motionValue: e, onUpdate: t, onComplete: n, onPlay: r, onStop: i, element: a, ...o } = this.options;
			this.sampler = new Wn({
				...o,
				autoplay: !1
			}), this.sampler.stop();
		}
		return this.sampler.sample(Math.max(0, e)).value;
	}
	liveValue() {
		let { state: e } = this;
		if (e === "running" || e === "paused") return this.sample(this.elapsed());
	}
	updateMotionValue(e) {
		let { motionValue: t, element: n, name: r } = this.options;
		if (!t) return;
		if (e !== void 0) {
			t.set(e);
			return;
		}
		let { speed: i } = this, a = this.elapsed(), o = this.state === "running" && i ? S(0, 10, a) : 0, s = this.sample(a);
		n && r && Ir(n, r, s), t.setWithVelocity(this.sample(a - o * Math.sign(i)), s, o / Math.abs(i || 1));
	}
}, Qr = (e, t) => t !== "zIndex" && !!(typeof e == "number" || Array.isArray(e) || typeof e == "string" && (L.test(e) || e === "0") && !e.startsWith("url("));
// node_modules/motion-dom/dist/es/animation/utils/can-animate.mjs
function $r(e) {
	let t = e[0];
	if (e.length === 1) return !0;
	for (let n = 0; n < e.length; n++) if (e[n] !== t) return !0;
}
function ei(e, t, n, r) {
	let i = e[0];
	if (i === null) return !1;
	if (t === "display" || t === "visibility") return !0;
	let a = e[e.length - 1], o = Qr(i, t), s = Qr(a, t);
	return !o || !s ? (o !== s && process.env.NODE_ENV !== "production" && w(!1, `You are trying to animate ${t} from "${i}" to "${a}". "${o ? a : i}" is not an animatable value.`, "value-not-animatable"), !1) : $r(e) || (n === "spring" || Gr(n)) && r;
}
// node_modules/motion-dom/dist/es/animation/utils/make-animation-instant.mjs
function ti(e) {
	e.duration = 0, e.type = "keyframes";
}
// node_modules/motion-dom/dist/es/animation/waapi/utils/accelerated-values.mjs
var ni = /* @__PURE__ */ new Set([
	"opacity",
	"clipPath",
	"filter",
	"transform"
]), ri = /^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;
function ii(e) {
	for (let t = 0; t < e.length; t++) if (typeof e[t] == "string" && ri.test(e[t])) return !0;
	return !1;
}
// node_modules/motion-dom/dist/es/animation/waapi/utils/needs-mixer.mjs
var ai = ({ mixer: e, keyframes: t }) => e && typeof t[0] != "number" && t.some((n, r) => r && e(t[r - 1], n)), oi = /* @__PURE__ */ new Set([
	"color",
	"backgroundColor",
	"outlineColor",
	"fill",
	"stroke",
	"borderColor",
	"borderTopColor",
	"borderRightColor",
	"borderBottomColor",
	"borderLeftColor"
]), si = () => !E.useManualTiming && Object.hasOwnProperty.call(Element.prototype, "animate");
function ci(e) {
	let { motionValue: t, name: n, repeatDelay: r, repeatType: i, damping: a, type: o, keyframes: s } = e;
	if (!n || !(ni.has(n) || oi.has(n))) return !1;
	let c = t?.owner?.current;
	if (!(c instanceof HTMLElement) && !(c instanceof SVGElement)) return !1;
	let { onUpdate: l, transformTemplate: u } = t.owner.getProps();
	return si() && (ni.has(n) || oi.has(n) && ii(s)) && (n !== "transform" || !u) && !l && !r && i !== "mirror" && a !== 0 && o !== "inertia" && !ai(e);
}
// node_modules/motion-dom/dist/es/value/types/utils/get-as-type.mjs
var li = (e, t) => t && typeof e == "number" ? t.transform(e) : e, ui = {
	x: "translateX",
	y: "translateY",
	z: "translateZ",
	transformPerspective: "perspective"
}, di = U.length, fi = {}, pi = (e, t, n = li(t, Zn[e])) => (fi[e] || (fi[e] = (ui[e] || e) + "(")) + n + ")", mi = (e, t) => (typeof t == "number" ? t : parseFloat(t)) === +!!e.startsWith("scale");
function hi(e, t, n) {
	let r = "";
	for (let i = 0; i < di; i++) {
		let a = U[i], o = e[a];
		if (o === void 0) continue;
		let s = n && (t[a] = li(o, H[a]));
		mi(a, o) || (r += pi(a, o, s || void 0) + " ");
	}
	let i = e.pathRotation;
	return i && (r += pi("rotate", i)), r = r.trim(), n ? n(t, r) : r || "none";
}
// node_modules/motion-dom/dist/es/animation/waapi/transforms/groups.mjs
var gi = /* @__PURE__ */ new WeakMap(), _i = 200, vi = .001, yi = .1, bi = .001, xi = 100, Si = 100, Ci = /* @__PURE__ */ new Set([
	"linear",
	"easeIn",
	"easeOut",
	"easeInOut"
]), wi = (e) => Ci.has(e), Ti = /* @__PURE__ */ new WeakMap(), Ei = (e, t) => {
	let n = Ti.get(e);
	return n?.[0] !== t && (n = [t, "linear(" + Dn(Array(t + 1)).map((t) => Un(e(t)) + " " + Un(t * 100) + "%") + ")"], Ti.set(e, n)), n[1];
}, Di = (e, t) => Math.min(_i, Math.max(2, Math.ceil((t - e) / 10))), Oi = (e, t) => Math.abs(e - t) <= vi, ki = (e, t) => e - t, Ai = (e, t, n) => Dn(Array(n + 1)).map((n) => R(e, t, n)), ji = (e) => e.motionValue.owner, Mi = (e) => gi.get(e), Ni = ({ state: e }) => e === "idle" || e === "finished", Pi = (e, t) => e.latestValues ? e.latestValues[t] : e.getValue(t)?.get(), Fi = ({ name: e, motionValue: t }) => e && U.includes(e) && t?.owner?.current instanceof HTMLElement && si() && Br();
function Ii(e) {
	let t = ji(e), { onUpdate: n, transformTemplate: r } = t.getProps();
	return !e.isHandoff && !n && !e.hasOnUpdate && !r && e.type !== "inertia" && (Pi(t, "transform") || "none") === "none" && !Pi(t, "pathRotation") && !t.projection?.isProjecting() && !ai(e);
}
var Li = class {
	constructor(e, t, n, r) {
		this.element = e, this.update = t, this.makeDriver = n, this.animation = r;
	}
	get js() {
		return this.driver ||= this.makeDriver(this.update);
	}
	now() {
		return this.driver || this.makeDriver !== Kt ? this.js.now() : M.isProcessing ? M.timestamp : N.now();
	}
	start(e = !0) {
		let t = Mi(this.element);
		!t || t.isJS ? this.js.start(e) : t.schedule(!1, !e);
	}
	stopJS() {
		this.driver?.stop();
	}
	stop() {
		this.stopJS();
		let e = Mi(this.element);
		e && !e.isFinishing && e.release(this.animation);
	}
}, Ri, zi = class extends Wn {
	constructor(e) {
		let t = ji(e).current, { driver: n = Kt } = e, r, i = Ii(e);
		e.driver = (e) => new Li(t, e, n, r), super(e), r = this;
		let a = this.driver;
		a && (a.animation = this), this.canAccelerate = i;
		let { stop: o } = this;
		this.stop = () => {
			this.isAccelerated() && this.sync(), o();
		};
	}
	offsets() {
		let { keyframes: e, times: t } = this.options;
		return t || (this.offsetsOf !== e && (this.offsetsOf = e, this.cachedOffsets = Dn(e)), this.cachedOffsets);
	}
	get group() {
		return Mi(ji(this.options).current);
	}
	get js() {
		return this.driver?.js;
	}
	stopJS() {
		this.driver?.stopJS();
	}
	get name() {
		return this.options.name;
	}
	timing() {
		let { startTime: e, speed: t, totalDuration: n } = this, { delay: r = 0, repeatType: i } = this.options;
		return this.holdTime === null ? n === Infinity ? [e + r / t, this.resolvedDuration * (i === "loop" ? 1 : 2) / t || 1] : [e + (r + n) / t, 0] : [Infinity, 0];
	}
	isAccelerated() {
		let { group: e, state: t } = this;
		return e?.tracks.has(this) && !e.isJS && this.canAccelerate && (t === "running" || t === "paused");
	}
	liveValue() {
		return this.isAccelerated() ? this.sampleAt(N.now()) : void 0;
	}
	tween() {
		let { keyframes: e, type: t, repeat: n, delay: r = 0 } = this.options, i = -1;
		if (n || t !== V || this.holdTime !== null) return;
		for (let t = 1; t < e.length; t++) if (e[t] !== e[t - 1]) {
			if (i >= 0) return;
			i = t - 1;
		}
		let { ease: a } = this.options;
		/* @__PURE__ */ Ce(a) && (a = a[i]);
		let o = this.offsets(), s = (e) => this.startTime + (r + o[e] * this.totalDuration) / this.speed;
		if (i >= 0) {
			let e = /* @__PURE__ */ Te(a) ? Vr(a) : wi(a) ? Hr[a] : Oe(a);
			return [
				s(i),
				s(i + 1),
				typeof e == "string" || Oi(e(0), 0) && Oi(e(1), 1) ? e : void 0
			];
		}
	}
	boundaries(e, t) {
		let { startTime: n, speed: r, resolvedDuration: i, options: a } = this, { delay: o = 0, repeat: s = 0, repeatDelay: c = 0, repeatType: l, type: u } = a, d = (u || V) === V ? this.offsets() : [0, 1], f = n + o / r, p = [];
		if (this.holdTime !== null || !(i > 0)) return p;
		for (let n = Math.max(0, Math.floor((e - f) * r / i)); n <= s; n++) {
			let a = f + n * i / r;
			if (a > t) break;
			for (let o of d) {
				let s = a + (n % 2 && l && l !== "loop" ? 1 - o : o) * (i - c) / r;
				s > e && s < t && p.push(s);
			}
		}
		return p;
	}
	numberAt(e) {
		return parseFloat(this.sampleAt(e, !0));
	}
	sync() {
		let e = N.now(), t = this.sampleAt(e, !0);
		this.options.motionValue.setWithVelocity(this.holdTime === null ? this.sampleAt(e - 10, !0) : t, t, 10);
	}
	play() {
		this.isStopped || ((this.group || Hi(ji(this.options))).tracks.add(this), super.play());
	}
	pause() {
		super.pause(), this.isAccelerated() && this.group.schedule(!1);
	}
	complete() {
		super.complete();
		let { group: e } = this;
		e && !e.isJS && this.tick(N.now());
	}
	get time() {
		return this.isAccelerated() ? /* @__PURE__ */ j(S(0, this.totalDuration, this.at(N.now()) - (this.options.delay || 0))) : super.time;
	}
	set time(e) {
		(Ri ??= Object.getOwnPropertyDescriptor(Wn.prototype, "time").set).call(this, e);
	}
	attachTimeline(e) {
		return this.canAccelerate = !1, this.group?.demote(!0), super.attachTimeline(e);
	}
}, Bi, Vi = (e) => {
	Bi || queueMicrotask(() => {
		let e = Bi;
		Bi = void 0, e.forEach((e) => e());
	}), (Bi ||= []).push(e);
};
function Hi(e) {
	let t = e.current, n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Map(), i = {}, a = [], o = /* @__PURE__ */ new Map(), s = [], c = !1, l = !1, u = !1, d = !1, f = -Infinity, p, m = Infinity, h, g = (e) => {
		for (let t of n) if (t.name === e) return !0;
	}, _ = (t, n) => {
		let o = {};
		for (let s of t === void 0 ? U : a) {
			let a = r.get(s), c = t === void 0 ? Pi(e, s) : a ? a.sampleAt(n > t && !a.timing()[1] ? n : t) : i[s];
			c !== void 0 && (o[s] = c);
		}
		return o;
	}, v = (e, t) => {
		let n = "";
		for (let r in e) {
			let i = e[r];
			t && mi(r, i) || (n += pi(r, i) + " ");
		}
		return (t ? n.trim() : n) || "none";
	}, y = (e, t) => v(_(e, t)), b = (e = _()) => {
		t.style.transform = v(e, !0);
	}, x = (e) => {
		e.onfinish = e.oncancel = null, e.cancel();
	}, S = (e = !0) => {
		clearTimeout(p), m = Infinity, h = void 0, e && b(), s.forEach(({ animation: e }) => x(e)), s = [];
	}, C = (e, n) => new Animation(new KeyframeEffect(t, e, n)), w = (e, t, n = Infinity) => {
		let r = {
			animation: e,
			offset: t,
			end: n
		};
		e.startTime = N.now() + t, n < Infinity && (e.onfinish = () => {
			r.isDone = !0, s.some((e) => e.end === Infinity) && (x(e), s = s.filter((e) => e !== r)), j.schedule(!1);
		}), e.oncancel = () => s.includes(r) && j.demote(), s.push(r);
	}, T = (e, t, n) => {
		let r = (t, n) => Math.abs(e(n) - e(t)), i = r(t, n);
		for (; n - t > .01;) {
			let e = (t + n) / 2;
			r(t, e) > r(e, n) ? n = e : t = e;
		}
		return r(t, n) > i / 2 ? [t, n] : [];
	}, E = (e, t, n, r) => {
		let i = Di(t, n);
		if (r.length * 4 > i) return;
		let a;
		for (let r of e) {
			let e = r.numberAt(t), i = (r.numberAt((t + n) / 2) - e) / (r.numberAt(n) - e);
			if (i === i) {
				if (a === void 0) a = i;
				else if (!Oi(i, a)) return;
			}
		}
		let o = Ai(t, n, i).concat(r).sort(ki), s = (e) => /* @__PURE__ */ re(t, n, e), c, l;
		for (let n of e) {
			let e = n.numberAt(t), r = o.map((t) => n.numberAt(t) - e), i = r[r.length - 1], a = r.some((e) => Math.abs(e) * vi > Math.abs(i)) ? 0 : i, s = r.map((e) => a ? e / a : e);
			if (a && !c) c = s, l = (t) => (n.numberAt(t) - e) / a;
			else if (s.some((e, t) => !Oi(e, a && c[t]))) return;
		}
		if (!c || c.every((e, t) => Oi(e, s(o[t])))) return "linear";
		let u = [], d = (e, t = l(e)) => u.push(Un(t) + " " + Un(s(e) * 100) + "%");
		return c.forEach((e, t) => {
			t && Math.abs(e - c[t - 1]) > .2 && T(l, o[t - 1], o[t]).forEach((e) => d(e)), d(o[t], e);
		}), "linear(" + u + ")";
	}, D = (e, t, n, r) => {
		let i = [t], a = [], o = n, s = t;
		for (let r of e) {
			let e = r.tween();
			if (e?.[2] !== "linear") {
				let [i, c] = r.timing(), [l, u] = e || [t, c ? n : i];
				o = Math.min(o, l), s = Math.max(s, u), a.push(r);
			}
		}
		o = Math.max(t, o), s = Math.min(n, s);
		let c = (e, t) => a.every((n) => !(Math.abs(n.numberAt((e + t) / 2) - (n.numberAt(e) + n.numberAt(t)) / 2) > (n.name.startsWith("scale") ? bi : yi))), l = (t, n, r) => {
			if (n - t < 1 || c(t, n)) i.push(n);
			else if (r < 4) l(t, (t + n) / 2, r + 1), l((t + n) / 2, n, r + 1);
			else {
				for (let r of e) i.push(...T((e) => r.numberAt(e), t, n));
				i.push(n);
			}
		}, u = s > o ? Ai(o, s, Math.ceil((s - o) / 100)) : [];
		u.push(n);
		for (let e of r) u.push(e, Math.min(e + .01, n));
		let d = t;
		for (let e of u.sort(ki)) e > d && l(d, e, 0), d = e;
		return i.sort(ki);
	}, O = (e) => {
		let t;
		for (let n of e) {
			let e = n.tween();
			if (!e || t && (Math.abs(e[0] - t[0]) > 1 || Math.abs(e[1] - t[1]) > 1)) return;
			t = [
				e[0],
				e[1],
				!t || e[2] === t[2] ? e[2] : void 0
			];
		}
		return t;
	}, ee = (e, t, n, r, i = { fill: "both" }, a) => {
		let o = r ? [] : e.flatMap((e) => e.boundaries(t, n)), s = r || E(e, t, n, o), c = s ? [t, n] : D(e, t, n, o), l = c.map((e) => y(e, a)), u = { transform: l };
		return s || (u.offset = c.map((e) => /* @__PURE__ */ re(t, n, e))), l.every((e) => e === l[0]) && (b(_(t, a)), u = null), C(u, {
			...i,
			duration: n - t,
			easing: s || "linear"
		});
	}, te = (e) => {
		let t = N.now() + e;
		t < m && (clearTimeout(p), m = t, p = setTimeout(() => {
			m = Infinity, j.schedule(!1);
		}, e));
	}, k = (t) => {
		let c = t, l = 0, u = 0, d = [], f = [], p = /* @__PURE__ */ new Set();
		r.clear(), o = /* @__PURE__ */ new Map();
		for (let e of n) {
			r.set(e.name, e);
			let [n, i] = e.timing(), a = n === Infinity;
			if (o.set(e, [
				e.at(t),
				e.speed,
				a
			]), !a) {
				if (e.speed < 0) return;
				if (i) {
					if (l) {
						let e = (n - u) / i;
						if (Math.abs(i - l) > 1 || Math.abs(e - Math.round(e)) * l > 1) return;
					} else l = i, u = n;
					f.push(e);
				} else p.add(n);
				d.push(e), c = Math.max(c, n);
			}
		}
		i = {}, a = U.filter((t) => {
			if (r.has(t)) return !0;
			let n = i[t] = Pi(e, t);
			return n !== void 0 && !mi(t, n);
		}), S(!1);
		let m = !l && O(d);
		try {
			if (c > t) {
				let e;
				if (m && m[1] > t) {
					let [n, r, i] = m;
					if (n - t > Si) return d.forEach((e) => e.sync()), te(h = n - t - Si), !0;
					e = typeof i == "string" ? i : i ? Ei(i, Di(n, r)) : E(d, n, r, []), e && w(ee(d, n, r, e, {
						fill: "both",
						endDelay: c - r
					}), n - t, c - n);
				}
				e || w(ee(d, t, c), 0, c - t), p.forEach((e) => e < c - 1 && w(C(null, { duration: e - t }), 0, e - t));
			}
			if (l) {
				let e = u + Math.floor((c - u) / l) * l;
				w(ee(f, e, e + l, void 0, {
					iterations: Infinity,
					iterationStart: (c - e) / l,
					fill: "forwards"
				}, c), c - t);
			}
		} catch {
			return;
		}
		return s.length || S(), !0;
	}, ne = (e, t) => {
		let r, i = 0;
		for (let t of n) {
			let n = o.get(t);
			if (!n) return !1;
			let [a, c, l] = n, u = t.at(e), d = t.timing()[0] === Infinity;
			if (l) {
				if (d && (u === a || !s.length)) continue;
				return !1;
			}
			let f = (u - a) / c, p = d ? 0 : t.speed / c;
			if (r === void 0) r = f, i = p;
			else if (Math.abs(f - r) > 1 || p !== i) return !1;
		}
		if (r === void 0) return !0;
		if (!s.length) {
			if (h === void 0 || t && i) return !1;
			if (i) {
				let e = (h - r) / i;
				if (e < 1) return !1;
				te(e);
			}
			return !0;
		}
		for (let { offset: e, end: n, isDone: i } of s) {
			let a = r - e;
			if (n < Infinity && (i ? a < n - 1 : a < 0 && (t || e <= 0) || a >= n)) return !1;
		}
		for (let { animation: t, offset: n, isDone: a } of s) {
			if (a) continue;
			let o = r - n;
			i && t.updatePlaybackRate && t.playState === "running" && Math.abs(Number(t.currentTime) - o) < 20 ? t.playbackRate !== i && t.updatePlaybackRate(i) : i ? (t.playbackRate !== i && (t.playbackRate = i), t.startTime = e - o / i) : (t.startTime = null, t.currentTime = o);
		}
		return !0;
	}, ie = () => !n.size && (u = !0, Mi(t) === j && gi.delete(t), j.isJS || S(), !0), A = () => {
		let t = N.now();
		if (j.isJS || (j.isFinishing = !0, n.forEach((n) => {
			let [r, a] = n.timing();
			n.state === "running" && n.speed > 0 && !a && r <= t + 1 && (n.complete(), i[n.name] = Pi(e, n.name), o.has(n) || (c = !0));
		}), j.isFinishing = !1), l = !1, u || (n.forEach((e) => Ni(e) && n.delete(e)), ie())) return;
		for (let e of n) if (!e.canAccelerate) return j.demote(!0);
		j.isJS && (j.isJS = !1, c = !0, n.forEach((e) => e.stopJS()));
		let r = c, a = d;
		if (c = d = !1, r || !ne(t, a)) {
			if (a) {
				if (t - f < xi) return j.demote();
				f = t;
			}
			if (!k(t)) return j.demote();
		} else if (h !== void 0 && !a) return;
		n.forEach((e) => e.timing()[0] === Infinity && e.sync());
	}, j = {
		tracks: n,
		isJS: !1,
		isFinishing: !1,
		schedule(e, t) {
			u || (c ||= e, d ||= !!t, l || (l = !0, M.isProcessing ? z.render(A, !1, !0) : Vi(A)));
		},
		release(e) {
			Ni(e) && n.delete(e), ie() || j.schedule(!0);
		},
		check() {
			if (!j.isJS) {
				for (let t in i) if (Pi(e, t) !== i[t] && !g(t)) return j.schedule(!0, !0);
			}
		},
		demote(e) {
			if (!(j.isJS || u)) return n.forEach((t) => {
				t.isAccelerated() && t.sync(), e || (t.canAccelerate = !1);
			}), j.isJS = !0, o = /* @__PURE__ */ new Map(), S(), n.forEach((e) => e.state === "running" && e.js?.start()), !0;
		}
	};
	return gi.set(t, j), j;
}
// node_modules/motion-dom/dist/es/animation/AsyncMotionValueAnimation.mjs
var Ui = class extends Vn {
	constructor(e) {
		super(), this.stop = () => {
			this._animation && (this._animation.stop(), this.stopTimeline?.()), this.keyframeResolver?.cancel();
		}, this.createdAt = N.now();
		let { keyframes: t, name: n, motionValue: r, element: i } = e, a = e;
		a.autoplay ??= !0, a.delay ??= 0, a.type ??= "keyframes", a.repeat ??= 0, a.repeatDelay ??= 0, a.repeatType ??= "loop";
		let o = i?.KeyframeResolver || Pr;
		this.keyframeResolver = new o(t, (e, t, n) => this.onKeyframesResolved(e, t, a, !n), n, r, i), this.keyframeResolver?.scheduleResolve();
	}
	onKeyframesResolved(e, t, n, r) {
		this.keyframeResolver = void 0;
		let { name: i, type: a, velocity: o, delay: s, isHandoff: c, onUpdate: l } = n;
		this.resolvedAt = N.now();
		let u = ei(e, i, a, o);
		u || ((E.instantAnimations || !s) && l?.(Nn(e, n, t)), e[0] = e[e.length - 1], ti(n), n.repeat = 0);
		let { onComplete: d } = n;
		n.finalKeyframe = t, n.keyframes = e, n.onComplete = () => {
			d?.(), this.notifyFinished();
		};
		let f = u && !c && ci(n), p = !f && Fi(n);
		r && (f || p || this.resolvedAt !== this.createdAt) && (n.startTime ??= Ln(this.createdAt, this.resolvedAt));
		let m;
		if (f) {
			n.element = n.motionValue?.owner?.current;
			try {
				m = new Zr(n);
			} catch {
				m = new Wn(n);
			}
		} else m = p ? new zi(n) : new Wn(n);
		this.pendingTimeline &&= (this.stopTimeline = m.attachTimeline(this.pendingTimeline), void 0), this._animation = m;
	}
	get finished() {
		return this._animation ? this._animation.finished : super.finished;
	}
	then(e, t) {
		return this.finished.finally(e).then(() => {});
	}
	liveValue() {
		return this._animation?.liveValue?.();
	}
	get animation() {
		return this._animation || (this.keyframeResolver?.resume(), Mr()), this._animation;
	}
	get duration() {
		return this.animation.duration;
	}
	get iterationDuration() {
		return this.animation.iterationDuration;
	}
	get time() {
		return this.animation.time;
	}
	set time(e) {
		this.animation.time = e;
	}
	get speed() {
		return this.animation.speed;
	}
	get state() {
		return this.animation.state;
	}
	set speed(e) {
		this.animation.speed = e;
	}
	get startTime() {
		return this.animation.startTime;
	}
	attachTimeline(e) {
		return this._animation ? this.stopTimeline = this.animation.attachTimeline(e) : this.pendingTimeline = e, () => this.stop();
	}
	play() {
		this.animation.play();
	}
	pause() {
		this.animation.pause();
	}
	complete() {
		this.animation.complete();
	}
	cancel() {
		this._animation?.cancel(), this.keyframeResolver?.cancel();
	}
}, Wi = class {
	constructor(e) {
		this.stop = () => {
			for (let e of this.animations) e.stop();
		}, this.animations = e.filter(Boolean);
	}
	get finished() {
		return Promise.all(this.animations.map((e) => e.finished));
	}
	getAll(e) {
		return this.animations[0][e];
	}
	attachTimeline(e) {
		let t = this.animations.map((t) => t.attachTimeline(e));
		return () => {
			t.forEach((e, t) => {
				e && e(), this.animations[t].stop();
			});
		};
	}
	get time() {
		return this.getAll("time");
	}
	set time(e) {
		for (let t of this.animations) t.time = e;
	}
	get speed() {
		return this.getAll("speed");
	}
	set speed(e) {
		for (let t of this.animations) t.speed = e;
	}
	get state() {
		return this.getAll("state");
	}
	get startTime() {
		return this.getAll("startTime");
	}
	get duration() {
		return Gi(this.animations, "duration");
	}
	get iterationDuration() {
		return Gi(this.animations, "iterationDuration");
	}
	play() {
		for (let e of this.animations) e.play();
	}
	pause() {
		for (let e of this.animations) e.pause();
	}
	cancel() {
		for (let e of this.animations) e.cancel();
	}
	complete() {
		for (let e of this.animations) e.complete();
	}
};
function Gi(e, t) {
	let n = 0;
	for (let r = 0; r < e.length; r++) {
		let i = e[r][t];
		i !== null && i > n && (n = i);
	}
	return n;
}
// node_modules/motion-dom/dist/es/animation/GroupAnimationWithThen.mjs
var Ki = class extends Wi {
	then(e, t) {
		return this.finished.finally(e).then(() => {});
	}
};
// node_modules/motion-dom/dist/es/animation/utils/calc-child-stagger.mjs
function qi(e, t, n, r = 0, i = 1) {
	let a = Array.from(e).sort((e, t) => e.sortNodePosition(t)).indexOf(t), o = e.size, s = (o - 1) * r;
	return typeof n == "function" ? n(a, o) : i === 1 ? a * r : s - a * r;
}
// node_modules/motion-dom/dist/es/value/index.mjs
var Ji = 30, Yi = (e) => !isNaN(parseFloat(e)), Xi = { current: void 0 }, Zi = class {
	constructor(e, t = {}) {
		this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (e) => {
			let t = N.now();
			if (this.updatedAt !== t && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(e), this.current !== this.prev && (this.dirty(), this.dependents)) for (let e of this.dependents) e.dirty();
		}, this.hasAnimated = !1, this.setCurrent(e), this.owner = t.owner;
	}
	setCurrent(e) {
		this.current = e, this.updatedAt = N.now(), this.canTrackVelocity === null && e !== void 0 && (this.canTrackVelocity = Yi(this.current));
	}
	setPrevFrameValue(e = this.current) {
		this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt;
	}
	onChange(e) {
		return process.env.NODE_ENV !== "production" && se(!1, "value.onChange(callback) is deprecated. Switch to value.on(\"change\", callback)."), this.on("change", e);
	}
	on(e, t) {
		var n;
		return e === "change" ? this.onChangeSubscribe(t) : ((n = this.events)[e] || (n[e] = new ie())).add(t);
	}
	onChangeSubscribe(e) {
		let { events: t } = this;
		return !t.change && !this.changeSubscriber ? this.changeSubscriber = e : (t.change || (t.change = new ie(), t.change.add(this.changeSubscriber), this.changeSubscriber = void 0), t.change.add(e)), () => {
			this.changeSubscriber === e ? this.changeSubscriber = void 0 : t.change?.remove(e), this.stopIfUnobserved();
		};
	}
	stopIfUnobserved() {
		z.read(() => {
			!this.changeSubscriber && !this.events.change?.getSize() && this.stop();
		});
	}
	clearListeners() {
		this.changeSubscriber = void 0;
		for (let e in this.events) this.events[e].clear();
	}
	attach(e, t) {
		this.passiveEffect = e, this.stopPassiveEffect = t;
	}
	set(e) {
		this.passiveEffect ? this.passiveEffect(e, this.updateAndNotify) : this.updateAndNotify(e);
	}
	setWithVelocity(e, t, n) {
		this.set(t), this.prev = void 0, this.prevFrameValue = e, this.prevUpdatedAt = this.updatedAt - n;
	}
	jump(e, t = !0) {
		t && (this.updatedAt = N.now(), this.stop()), this.updateAndNotify(e), this.prev = e, this.prevUpdatedAt = this.prevFrameValue = void 0, this.stopPassiveEffect?.();
	}
	dirty() {
		let { current: e, changeSubscriber: t } = this;
		t ? t(e) : this.events.change?.notify(e);
	}
	addDependent(e) {
		(this.dependents ||= /* @__PURE__ */ new Set()).add(e);
	}
	removeDependent(e) {
		this.dependents?.delete(e);
	}
	get() {
		Xi.current?.push(this);
		let e = this.animation?.liveValue?.();
		return e === void 0 ? this.current : e;
	}
	getCurrent() {
		return this.current;
	}
	getPrevious() {
		return this.prev;
	}
	getVelocity() {
		let e = N.now();
		if (!this.canTrackVelocity || this.prevFrameValue === void 0 || e - this.updatedAt > Ji) return 0;
		let t = Math.min(this.updatedAt - this.prevUpdatedAt, Ji);
		return /* @__PURE__ */ ae(parseFloat(this.current) - parseFloat(this.prevFrameValue), t);
	}
	start(e) {
		return new Promise((t) => this.run(e, t));
	}
	run(e, t) {
		this.stop(), this.hasAnimated = !0;
		let n = !1, r;
		r = e(() => {
			n = !0, this.events.animationComplete?.notify(), this.animation === r && (this.animation = void 0), t?.();
		}), n || (this.animation = r), this.events.animationStart?.notify();
	}
	stop() {
		this.animation && (this.animation.stop(), this.events.animationCancel?.notify()), this.animation = void 0;
	}
	isAnimating() {
		return !!this.animation;
	}
	destroy() {
		this.dependents?.clear(), this.events.destroy?.notify(), this.clearListeners(), this.stop(), this.stopPassiveEffect?.();
	}
};
function G(e, t) {
	return new Zi(e, t);
}
// node_modules/motion-dom/dist/es/animation/utils/resolve-transition.mjs
function Qi(e, t) {
	if (e?.inherit && t) {
		let { inherit: n, ...r } = e;
		return {
			...t,
			...r
		};
	}
	return e;
}
// node_modules/motion-dom/dist/es/animation/utils/get-value-transition.mjs
function $i(e, t) {
	let n = e?.[t] ?? e?.default ?? e;
	return n === e ? n : Qi(n, e);
}
// node_modules/motion-dom/dist/es/animation/utils/default-transitions.mjs
var ea = {
	type: "spring",
	stiffness: 500,
	damping: 25,
	restSpeed: 10
}, ta = (e) => ({
	type: "spring",
	stiffness: 550,
	damping: e === 0 ? 2 * Math.sqrt(550) : 30,
	restSpeed: 10
}), na = {
	type: "keyframes",
	duration: .8
}, ra = {
	type: "keyframes",
	ease: [
		.25,
		.1,
		.35,
		1
	],
	duration: .3
}, ia = (e, { keyframes: t }) => t.length > 2 ? na : W.has(e) ? e.startsWith("scale") ? ta(t[1]) : ea : ra, aa = /* @__PURE__ */ new Set([
	"when",
	"delay",
	"delayChildren",
	"staggerChildren",
	"staggerDirection",
	"repeat",
	"repeatType",
	"repeatDelay",
	"from",
	"elapsed",
	"out",
	"mixer"
]);
function oa(e) {
	for (let t in e) if (!aa.has(t)) return !0;
	return !1;
}
// node_modules/motion-dom/dist/es/animation/interfaces/motion-value.mjs
var sa = (e, t, n, r = {}, i, a) => (o) => {
	let s = $i(r, e) || {}, c = s.delay || r.delay || 0, { elapsed: l = 0 } = r;
	l -= /* @__PURE__ */ A(c);
	let u = {
		keyframes: Array.isArray(n) ? n : [null, n],
		ease: "easeOut",
		velocity: t.getVelocity(),
		...s,
		delay: -l,
		onUpdate: (e) => {
			t.set(e), s.onUpdate && s.onUpdate(e);
		},
		onComplete: () => {
			o(), s.onComplete && s.onComplete();
		},
		name: e,
		motionValue: t,
		element: a ? void 0 : i,
		hasOnUpdate: !!s.onUpdate
	};
	oa(s) || Object.assign(u, ia(e, u)), u.duration &&= /* @__PURE__ */ A(u.duration), u.repeatDelay &&= /* @__PURE__ */ A(u.repeatDelay), u.from !== void 0 && (u.keyframes[0] = u.from);
	let d = !1;
	if ((u.type === !1 || u.duration === 0 && !u.repeatDelay) && (ti(u), u.delay === 0 && (d = !0)), (E.instantAnimations || E.skipAnimations || i?.shouldSkipAnimations || s.skipAnimations) && (d = !0, ti(u), u.delay = 0), u.allowFlatten = !s.type && !s.ease, d && !a && t.get() !== void 0) {
		let e = Nn(u.keyframes, s);
		if (e !== void 0) {
			z.update(() => {
				u.onUpdate(e), u.onComplete();
			});
			return;
		}
	}
	return s.isSync ? new Wn(u) : new Ui(u);
}, ca = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function la(e) {
	let t = ca.exec(e);
	if (!t) return [,];
	let [, n, r, i] = t;
	return [`--${n ?? r}`, i];
}
var ua = 4;
function da(e, t, n = 1) {
	process.env.NODE_ENV !== "production" && T(n <= ua, `Max CSS variable fallback depth detected in property "${e}". This may indicate a circular fallback dependency.`, "max-css-var-depth");
	let [r, i] = la(e);
	if (!r) return;
	let a = window.getComputedStyle(t).getPropertyValue(r);
	if (a) {
		let e = a.trim();
		return D(e) ? parseFloat(e) : e;
	}
	return Fe(i) ? da(i, t, n + 1) : i;
}
// node_modules/motion-dom/dist/es/render/utils/resolve-variants.mjs
function fa(e) {
	let t = [{}, {}];
	return e?.values.forEach((e, n) => {
		t[0][n] = e.get(), t[1][n] = e.getVelocity();
	}), t;
}
function pa(e, t, n, r) {
	let i = (t) => typeof t == "function" ? t(n === void 0 ? e.custom : n, ...fa(r)) : t;
	return t = i(t), typeof t == "string" && (t = e.variants && e.variants[t]), i(t);
}
// node_modules/motion-dom/dist/es/render/utils/resolve-dynamic-variants.mjs
function ma(e, t, n) {
	return pa(e.getProps(), t, n, e);
}
var ha = (e, t) => t === "exit" ? e.presenceContext?.custom : void 0, ga = /* @__PURE__ */ new Set([
	"width",
	"height",
	"top",
	"left",
	"right",
	"bottom",
	...U
]), _a = (e) => Array.isArray(e);
// node_modules/motion-dom/dist/es/render/utils/setters.mjs
function va(e, t, n) {
	e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, G(n));
}
function ya(e) {
	return _a(e) ? e[e.length - 1] || 0 : e;
}
function ba(e, t) {
	let { transitionEnd: n = {}, transition: r = {}, ...i } = ma(e, t) || {};
	i = {
		...i,
		...n
	};
	for (let t in i) va(e, t, ya(i[t]));
}
// node_modules/motion-dom/dist/es/value/utils/is-motion-value.mjs
var K = (e) => !!(e && e.getVelocity);
// node_modules/motion-dom/dist/es/value/will-change/is.mjs
function xa(e) {
	return !!(K(e) && e.add);
}
// node_modules/motion-dom/dist/es/value/will-change/add-will-change.mjs
function Sa(e, t) {
	let n = e.getValue("willChange");
	if (xa(n)) return n.add(t);
	if (!n && E.WillChange) {
		let n = new E.WillChange("auto");
		e.addValue("willChange", n), n.add(t);
	}
}
// node_modules/motion-dom/dist/es/animation/optimized-appear/data-id.mjs
var Ca = "data-framer-appear-id";
// node_modules/motion-dom/dist/es/animation/optimized-appear/get-appear-id.mjs
function wa(e) {
	return e.props[Ca];
}
// node_modules/motion-dom/dist/es/animation/interfaces/visual-element-target.mjs
var Ta = typeof window < "u";
function Ea({ protectedKeys: e, needsAnimating: t }, n) {
	let r = n in e && !t[n];
	return t[n] = !1, r;
}
function Da(e, t, { delay: n = 0, transitionOverride: r, type: i } = {}) {
	let { transition: a, transitionEnd: o, ...s } = t, c = e.getDefaultTransition();
	a = a ? Qi(a, c) : c;
	let l = a?.reduceMotion, u = a?.skipAnimations;
	r && (a = r);
	let d = [], f = i && e.animationState?.getState()[i], p = a?.path;
	p && (p.animateValues ? p.animateValues((t) => e.getValue(t, e.latestValues[t] ?? 0), s, a, n, d) : p.animateVisualElement?.(e, s, a, n, d));
	for (let t in s) {
		let r = e.getValue(t, e.latestValues[t] ?? null), i = s[t];
		if (i === void 0 || f && Ea(f, t)) continue;
		let o = {
			delay: n,
			...$i(f?.out[t] || a || {}, t)
		};
		u && (o.skipAnimations = !0);
		let c = r.get();
		if (c !== void 0 && !r.isAnimating() && !Array.isArray(i) && i === c && !o.velocity) {
			z.update(() => r.set(i));
			continue;
		}
		let p = !1;
		if (Ta && window.MotionHandoffAnimation) {
			let n = wa(e);
			if (n) {
				let e = window.MotionHandoffAnimation(n, t, z);
				e !== null && (o.startTime = e, p = !0);
			}
		}
		Sa(e, t);
		let m = l ?? e.shouldReduceMotion;
		r.run(sa(t, r, i, m && ga.has(t) ? { type: !1 } : o, e, p));
		let h = r.animation;
		h && d.push(h);
	}
	if (o) {
		let t = () => z.update(() => {
			o && ba(e, o);
		});
		d.length ? Promise.all(d).then(t) : t();
	}
	return d;
}
// node_modules/motion-dom/dist/es/animation/interfaces/visual-element-variant.mjs
function Oa(e, t, n = {}) {
	let r = ma(e, t, ha(e, n.type)), i = n.transitionOverride || (r?.transition ?? (e.getDefaultTransition() || {})), a = () => Promise.all(r ? Da(e, r, n) : []), o = (r = 0) => {
		let { variantChildren: a } = e, { delayChildren: o = 0, staggerChildren: s, staggerDirection: c } = i, l = [];
		return a?.forEach((e) => {
			e.notify("AnimationStart", t), l.push(Oa(e, t, {
				...n,
				delay: r + (typeof o == "function" ? 0 : o) + qi(a, e, o, s, c)
			}).then(() => e.notify("AnimationComplete", t)));
		}), Promise.all(l);
	}, { when: s } = i;
	return s ? s === "beforeChildren" ? a().then(() => o()) : o().then(a) : Promise.all([a(), o(n.delay)]);
}
// node_modules/motion-dom/dist/es/animation/interfaces/visual-element.mjs
function ka(e, t, n = {}) {
	return e.notify("AnimationStart", t), (Array.isArray(t) ? Promise.all(t.map((t) => Oa(e, t, n))) : typeof t == "string" ? Oa(e, t, n) : Promise.all(Da(e, ma(e, t, n.custom), n))).then(() => {
		e.notify("AnimationComplete", t);
	});
}
// node_modules/motion-dom/dist/es/value/types/auto.mjs
var Aa = {
	test: (e) => e === "auto",
	parse: (e) => e
}, ja = (e) => (t) => t.test(e), Ma = [
	Re,
	F,
	P,
	$e,
	tt,
	et,
	Aa
], Na = (e) => Ma.find(ja(e));
// node_modules/motion-dom/dist/es/animation/keyframes/utils/is-none.mjs
function Pa(e) {
	return typeof e == "number" ? e === 0 : e === null || e === "none" || e === "0" || ee(e);
}
// node_modules/motion-dom/dist/es/animation/keyframes/utils/make-none-animatable.mjs
var Fa = /* @__PURE__ */ new Set([
	"auto",
	"none",
	"0"
]);
function Ia(e, t, n) {
	let r = 0, i;
	for (; r < e.length && !i;) {
		let t = e[r];
		typeof t == "string" && !Fa.has(t) && mt(t) && (i = e[r]), r++;
	}
	if (i && n) for (let r of t) e[r] !== i && (e[r] = ir(n, i));
}
// node_modules/motion-dom/dist/es/animation/keyframes/DOMKeyframesResolver.mjs
var La = class extends Pr {
	constructor(e, t, n, r, i) {
		super(e, t, n, r, i, !0);
	}
	scheduleResolve() {
		if (this.canReadNow() && (this.readKeyframes(), !this.needsMeasurement)) return this.complete();
		super.scheduleResolve();
	}
	canReadNow() {
		let { unresolvedKeyframes: e, element: t, motionValue: n } = this, r = e[0] ?? n?.get();
		if (!t?.current || r === void 0) return !1;
		for (let t = 0; t < e.length; t++) if (Le(t ? e[t] : r)) return !1;
		return !0;
	}
	readKeyframes() {
		let { unresolvedKeyframes: e, element: t, name: n } = this;
		if (!t?.current) return;
		super.readKeyframes();
		for (let n = 0; n < e.length; n++) {
			let r = e[n];
			if (typeof r == "string" && (r = r.trim(), Fe(r))) {
				let i = da(r, t.current);
				i !== void 0 && (e[n] = i), n === e.length - 1 && (this.finalKeyframe = r);
			}
		}
		if (this.resolveNoneKeyframes(), !ga.has(n) || e.length !== 2) return;
		let [r, i] = e;
		if (typeof r == "number" && typeof i == "number") return;
		let a = Na(r), o = Na(i);
		if (Le(r) !== Le(i) && Tr[n]) this.needsMeasurement = !0;
		else if (a !== o) {
			if (_r(a) && _r(o)) for (let t = 0; t < e.length; t++) {
				let n = e[t];
				typeof n == "string" && (e[t] = parseFloat(n));
			}
			else Tr[n] && (this.needsMeasurement = !0);
		}
	}
	resolveNoneKeyframes() {
		let { unresolvedKeyframes: e, name: t } = this, n = [];
		for (let t = 0; t < e.length; t++) (e[t] === null || Pa(e[t])) && n.push(t);
		n.length && Ia(e, n, t);
	}
	measure() {
		let { element: e, name: t } = this;
		return Tr[t](window.getComputedStyle(e.current), () => e.measureViewportBox());
	}
	measureInitialState() {
		let { element: e, unresolvedKeyframes: t, name: n } = this;
		if (!e?.current) return;
		n === "height" && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = this.measure(), t[0] = this.measuredOrigin;
		let r = t[t.length - 1];
		r !== void 0 && this.motionValue?.jump(r, !1);
	}
	measureEndState() {
		let { element: e, unresolvedKeyframes: t } = this;
		if (!e?.current) return;
		this.motionValue?.jump(this.measuredOrigin, !1);
		let n = t.length - 1, r = t[n];
		t[n] = this.measure(), r !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = r), this.resolveNoneKeyframes();
	}
}, Ra = [
	"borderTopLeftRadius",
	"borderTopRightRadius",
	"borderBottomRightRadius",
	"borderBottomLeftRadius"
], za = [];
function Ba(e) {
	process.env.NODE_ENV !== "production" && T(typeof e.test == "function" && typeof e.read == "function", "Effects passed to animate.addEffect() need test() and read().", "effect-missing-test"), Va(e), za.unshift(e);
}
function Va(e) {
	x(za, e);
}
function Ha(e) {
	return za.find((t) => t.test(e));
}
function Ua(e, t, n = {}, r) {
	let i = [], { velocity: a, path: o } = n, s = n.reduceMotion ?? r?.shouldReduceMotion;
	o?.animateValues && r && (t = { ...t }, o.animateValues(e, t, n, 0, i));
	for (let o in t) {
		if (o === "transition" || o === "transitionEnd") continue;
		let c = t[o];
		if (c === void 0) continue;
		let l = e(o), u = l.get();
		u !== void 0 && !l.isAnimating() && !Array.isArray(c) && c === u && !a ? z.update(() => l.set(c)) : (l.run(sa(o, l, c, s && ga.has(o) ? { type: !1 } : n, r)), l.animation && i.push(l.animation));
	}
	let { transitionEnd: c } = t;
	if (c) {
		let t = () => z.update(() => {
			for (let t in c) e(t).set(c[t]);
		});
		i.length ? Promise.all(i).then(t) : t();
	}
	return i;
}
function Wa(e, t, n, r, i) {
	let a, o = !1, s = Ua((r) => {
		let s = a?.[r] ?? e.get(t, r);
		if (!s) {
			let c;
			if (!i) {
				let i = n[r];
				c = Ga(i) ?? e.read(t, r, i), process.env.NODE_ENV !== "production" && T(c !== void 0, `"${r}" can't be read from the animated subject. Provide [from, to] keyframes.`, "effect-unreadable-value");
			}
			s = G(c, { owner: i }), o ? e(t, { [r]: s }) : (a ||= {})[r] = s;
		}
		return s;
	}, n, r, i);
	return o = !0, a && e(t, a), s;
}
function Ga(e) {
	let t = Array.isArray(e) ? e[0] : void 0;
	return t === null ? void 0 : t;
}
// node_modules/motion-dom/dist/es/utils/is-html-element.mjs
function Ka(e) {
	return O(e) && "offsetHeight" in e && !("ownerSVGElement" in e);
}
// node_modules/motion-dom/dist/es/utils/is-svg-element.mjs
function qa(e) {
	return O(e) && "ownerSVGElement" in e;
}
// node_modules/motion-dom/dist/es/scope/active.mjs
var q = {};
function Ja(e) {
	return q.current?.add(e), e;
}
var Ya = (e) => q.current ? q.current.bind(e) : e;
// node_modules/motion-dom/dist/es/utils/resolve-elements.mjs
function Xa(e, t, n) {
	if (e == null) return [];
	if (e instanceof EventTarget) return [e];
	if (typeof e == "string") {
		let r = t ? t.current : q.current?.root || document, i = n?.[e] ?? r.querySelectorAll(e);
		return i ? Array.from(i) : [];
	}
	return Array.from(e).filter((e) => e != null);
}
// node_modules/motion-dom/dist/es/effects/MotionValueState.mjs
var Za = class {
	constructor(e = z.render) {
		this.step = e, this.values = /* @__PURE__ */ new Map(), this.pending = [], this.numPending = 0, this.flush = () => {
			let { pending: e, numPending: t } = this;
			this.numPending = 0;
			for (let n = 0; n < t; n++) e[n]();
		};
	}
	set(e, t, n, r) {
		if (this.values.get(e)?.onRemove(), r) for (let e of this.values.values()) e.value === r && (n = e.render);
		let i = () => n && this.schedule(n);
		t.get() !== void 0 && i();
		let a = t.on("change", i), o = () => {
			a(), n && !r && this.cancel(n), this.values.get(e)?.onRemove === o && this.values.delete(e);
		};
		return this.values.set(e, {
			value: t,
			render: r ? void 0 : n,
			onRemove: o
		}), o;
	}
	get(e) {
		return this.values.get(e)?.value;
	}
	release() {
		let e = /* @__PURE__ */ new Map();
		return this.values.forEach((t, n) => {
			e.set(n, t.value), t.onRemove();
		}), this.transformKeys = this.transformValues = void 0, e;
	}
	schedule(e) {
		let { pending: t, numPending: n } = this;
		for (let r = 0; r < n; r++) if (t[r] === e) return;
		n || this.step(this.flush), t[this.numPending++] = e;
	}
	cancel(e) {
		let { pending: t } = this;
		for (let n = 0; n < this.numPending; n++) if (t[n] === e) {
			t[n] = t[--this.numPending];
			return;
		}
	}
};
// node_modules/motion-dom/dist/es/effects/utils/create-effect.mjs
function Qa(e, { step: t, ...n } = {}) {
	let r = /* @__PURE__ */ new WeakMap();
	return Object.assign((n, i) => {
		let a = r.get(n) ?? new Za(t);
		r.set(n, a);
		let o = [];
		for (let t in i) {
			let r = i[t], s = e(n, a, t, r);
			o.push(s);
		}
		return () => {
			for (let e of o) e();
		};
	}, n, {
		get: (e, t) => r.get(e)?.get(t),
		flush: (e) => r.get(e)?.flush(),
		state: (e) => r.get(e)
	});
}
// node_modules/motion-dom/dist/es/effects/style/transform.mjs
function $a(e) {
	let t = "", { transformKeys: n = [], transformValues: r = {} } = e;
	for (let e = 0; e < n.length; e++) {
		let i = n[e], a = r[i].getCurrent();
		a !== void 0 && (mi(i, a) || (t += (t && " ") + pi(i, a)));
	}
	let i = e.get("pathRotation")?.get();
	return i && (t += (t && " ") + pi("rotate", i)), t || "none";
}
// node_modules/motion-dom/dist/es/effects/style/index.mjs
var eo = /* @__PURE__ */ new Set([
	"originX",
	"originY",
	"originZ"
]), to = (e, t) => li(e.get(t)?.get(), H[t]), no = (e, t, n, r) => {
	let i, a;
	if (W.has(n)) {
		if (n !== "pathRotation") {
			let e = t.transformKeys ??= [];
			(t.transformValues ??= {})[n] = r, e.includes(n) || (e.push(n), e.sort((e, t) => U.indexOf(e) - U.indexOf(t)));
		}
		t.get("transform") || (!Ka(e) && !t.get("transformBox") && no(e, t, "transformBox", new Zi("fill-box")), t.set("transform", new Zi("none"), () => {
			gi.get(e)?.check(), e.style.transform = $a(t);
		})), a = t.get("transform");
	} else eo.has(n) ? (t.get("transformOrigin") || t.set("transformOrigin", new Zi(""), () => {
		let n = to(t, "originX") ?? "50%", r = to(t, "originY") ?? "50%", i = to(t, "originZ") ?? 0;
		e.style.transformOrigin = `${n} ${r} ${i}`;
	}), a = t.get("transformOrigin")) : i = Fr(n) ? () => {
		e.style.setProperty(n, r.getCurrent());
	} : () => {
		e.style[n] = li(r.getCurrent(), H[n]);
	};
	return t.set(n, r, i, a);
}, ro = (e) => Ka(e) || qa(e), io = (e, t) => {
	if (W.has(t)) return gr(e, t);
	let n = getComputedStyle(e), r = Fr(t) ? n.getPropertyValue(t) : n[t];
	return typeof r == "string" && r.trim() || 0;
}, ao = /*@__PURE__*/ Qa(no, {
	test: ro,
	read: io
});
// node_modules/motion-dom/dist/es/render/dom/utils/camel-to-dash.mjs
function oo(e) {
	return e.replace(/([A-Z])/g, (e) => `-${e.toLowerCase()}`);
}
// node_modules/motion-dom/dist/es/render/html/utils/build-styles.mjs
function so(e, t, n) {
	let { style: r, vars: i, transformOrigin: a } = e, o = !1, s = !1;
	for (let e in t) {
		let n = t[e];
		if (W.has(e)) o = !0;
		else if (Ne(e)) i[e] = n;
		else {
			let t = li(n, H[e]);
			e.startsWith("origin") ? (s = !0, a[e] = t) : r[e] = t;
		}
	}
	if (t.transform || (o || n ? r.transform = hi(t, e.transform, n) : r.transform &&= "none"), s) {
		let { originX: e = "50%", originY: t = "50%", originZ: n = 0 } = a;
		r.transformOrigin = `${e} ${t} ${n}`;
	}
}
// node_modules/motion-dom/dist/es/render/svg/utils/path.mjs
var co = {
	offset: "stroke-dashoffset",
	array: "stroke-dasharray"
}, lo = {
	offset: "strokeDashoffset",
	array: "strokeDasharray"
};
function uo(e, t, n = 1, r = 0, i = !0) {
	e.pathLength = 1;
	let a = i ? co : lo;
	e[a.offset] = `${-r}`, e[a.array] = `${t} ${n}`;
}
// node_modules/motion-dom/dist/es/render/svg/utils/build-attrs.mjs
var fo = [
	"transform",
	"opacity",
	"clipPath",
	"filter",
	"offsetDistance",
	"offsetPath",
	"offsetRotate",
	"offsetAnchor"
];
function po(e, { attrX: t, attrY: n, attrScale: r, pathLength: i, pathSpacing: a = 1, pathOffset: o = 0, ...s }, c, l, u) {
	if (so(e, s, l), c) {
		e.style.viewBox && (e.attrs.viewBox = e.style.viewBox);
		return;
	}
	e.attrs = e.style, e.style = {};
	let { attrs: d, style: f } = e;
	for (let e of fo) d[e] !== void 0 && (f[e] = d[e], delete d[e]);
	(f.transform || d.transformOrigin) && (f.transformOrigin = d.transformOrigin ?? "50% 50%", delete d.transformOrigin), f.transform && (f.transformBox = u?.transformBox ?? "fill-box", delete d.transformBox), t !== void 0 && (d.x = t), n !== void 0 && (d.y = n), r !== void 0 && (d.scale = r), i !== void 0 && uo(d, i, a, o, !1);
}
// node_modules/motion-dom/dist/es/effects/attr/index.mjs
function mo(e, t) {
	if (!(t in e)) return !1;
	let n = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(e), t) || Object.getOwnPropertyDescriptor(e, t);
	return n && typeof n.set == "function";
}
var ho = (e, t, n, r, i = n) => {
	let a = mo(e, i);
	!a && (i.startsWith("data") || i.startsWith("aria")) && (i = oo(i));
	let o = H[n] || H[i], s = a ? () => {
		e[i] = li(r.get(), H[n]);
	} : () => {
		let t = li(r.get(), o);
		t == null ? e.removeAttribute(i) : e.setAttribute(i, String(t));
	};
	return t.set(n, r, s);
};
// node_modules/motion-dom/dist/es/effects/svg/index.mjs
function go(e, t, n, r) {
	return z.render(() => e.setAttribute("pathLength", "1")), n === "pathOffset" ? t.set(n, r, () => {
		let t = r.get();
		e.setAttribute("stroke-dashoffset", `${-t}`);
	}) : (t.get("stroke-dasharray") || t.set("stroke-dasharray", new Zi("1 1"), () => {
		let n = t.get("pathLength")?.get() ?? 1, r = t.get("pathSpacing")?.get();
		e.setAttribute("stroke-dasharray", `${n} ${r ?? 1 - Number(n)}`);
	}), t.set(n, r, void 0, t.get("stroke-dasharray")));
}
var _o = /*@__PURE__*/ Qa((e, t, n, r) => n.startsWith("path") && !W.has(n) ? go(e, t, n, r) : n.startsWith("attr") ? ho(e, t, n, r, vo(n)) : n === "d" ? t.set(n, r, () => {
	let t = r.get()?.replace(/path\(|["')]/g, "");
	t === void 0 ? e.removeAttribute(n) : e.setAttribute(n, t);
}) : (W.has(n) || eo.has(n) || Fr(n) || n in e.style ? no : ho)(e, t, n, r), {
	test: qa,
	read: (e, t) => W.has(t) ? H[t]?.default || 0 : Fr(t) || fo.includes(t) ? io(e, t) || e.getAttribute(oo(t)) || 0 : (t = vo(t), e.getAttribute(oo(t)) ?? e.getAttribute(t) ?? void 0)
});
function vo(e) {
	return e.replace(/^attr([A-Z])/, (e, t) => t.toLowerCase());
}
// node_modules/motion-dom/dist/es/projection/geometry/conversion.mjs
function yo({ top: e, left: t, right: n, bottom: r }) {
	return {
		x: {
			min: t,
			max: n
		},
		y: {
			min: e,
			max: r
		}
	};
}
function bo({ x: e, y: t }) {
	return {
		top: t.min,
		right: e.max,
		bottom: t.max,
		left: e.min
	};
}
function xo(e, t) {
	if (!t) return e;
	let n = t({
		x: e.left,
		y: e.top
	}), r = t({
		x: e.right,
		y: e.bottom
	});
	return {
		top: n.y,
		left: n.x,
		bottom: r.y,
		right: r.x
	};
}
// node_modules/motion-dom/dist/es/projection/utils/has-transform.mjs
function So(e) {
	return e === void 0 || e === 1;
}
function Co({ scale: e, scaleX: t, scaleY: n }) {
	return !So(e) || !So(t) || !So(n);
}
var wo = [
	"rotate",
	"rotateX",
	"rotateY",
	"rotateZ",
	"skewX",
	"skewY"
];
function To(e) {
	return Co(e) || Do(e) || Eo(e);
}
function Eo(e) {
	return e.z || e.rotate || e.rotateX || e.rotateY || e.rotateZ || e.skewX || e.skewY;
}
function Do(e) {
	return Oo(e.x) || Oo(e.y);
}
function Oo(e) {
	return e && e !== "0%";
}
// node_modules/motion-dom/dist/es/projection/geometry/delta-apply.mjs
function ko(e, t, n) {
	return n + t * (e - n);
}
function Ao(e, t, n, r, i) {
	return i !== void 0 && (e = ko(e, i, r)), ko(e, n, r) + t;
}
function jo(e, t = 0, n = 1, r, i) {
	e.min = Ao(e.min, t, n, r, i), e.max = Ao(e.max, t, n, r, i);
}
function Mo(e, { x: t, y: n }) {
	jo(e.x, t.translate, t.scale, t.originPoint), jo(e.y, n.translate, n.scale, n.originPoint);
}
var No = .999999999999, Po = 1.0000000000001;
function Fo(e, t, n, r = !1) {
	let i = n.length;
	if (!i) return;
	t.x = t.y = 1;
	let a, o;
	for (let s = 0; s < i; s++) a = n[s], o = a.projectionDelta, a.options.visualElement?.props.style?.display !== "contents" && (r === !0 && a.options.layoutScroll && a.scroll && a !== a.root && (J(e.x, -a.scroll.offset.x), J(e.y, -a.scroll.offset.y)), o && (t.x *= o.x.scale, t.y *= o.y.scale, Mo(e, o)), r && (r.path?.[s] || r) !== a && To(a.latestValues) && Ro(e, a.latestValues, a.layout?.layoutBox));
	t.x < Po && t.x > No && (t.x = 1), t.y < Po && t.y > No && (t.y = 1);
}
function J(e, t) {
	e.min += t, e.max += t;
}
function Io(e, t, n, r, i = .5) {
	jo(e, t, n, R(e.min, e.max, i), r);
}
function Lo(e, t) {
	return typeof e == "string" ? parseFloat(e) / 100 * (t.max - t.min) : e;
}
function Ro(e, t, n) {
	let r = n ?? e;
	Io(e.x, Lo(t.x, r.x), t.scaleX, t.scale, t.originX), Io(e.y, Lo(t.y, r.y), t.scaleY, t.scale, t.originY);
}
// node_modules/motion-dom/dist/es/projection/utils/measure.mjs
function zo(e, t) {
	return yo(xo(e.getBoundingClientRect(), t));
}
function Bo(e, t, n) {
	let r = zo(e, n), { scroll: i } = t;
	return i && (J(r.x, i.offset.x), J(r.y, i.offset.y)), r;
}
var Vo = () => ({
	x: document.documentElement.scrollLeft || document.body?.scrollLeft || 0,
	y: document.documentElement.scrollTop || document.body?.scrollTop || 0
}), Ho = {}, Uo = (e) => qa(e) ? _o : ao, Wo = class {
	constructor(e, t) {
		this.effect = e, this.current = t, this.KeyframeResolver = La;
	}
	getValue(e) {
		return this.effect.get(this.current, e);
	}
	readValue(e, t) {
		return this.effect.read(this.current, e, t);
	}
	render() {
		this.effect.flush(this.current);
	}
	measureViewportBox() {
		return zo(this.current);
	}
	getProps() {
		return Ho;
	}
};
function Go(e, t, n, r) {
	if (q.current?.track(e), r) return Ua((e) => r.getValue(e, null), t, n, r);
	let i = Uo(e);
	return Wa(i, e, t, n, new Wo(i, e));
}
// node_modules/motion-dom/dist/es/effects/prop/index.mjs
var Ko = /*@__PURE__*/ Qa((e, t, n, r) => t.set(n, r, () => {
	e[n] = r.get();
}), {
	test: (e) => O(e),
	read: (e, t) => {
		let n = e[t];
		return typeof n == "string" || typeof n == "number" ? n : void 0;
	}
}), { schedule: qo, cancel: Jo } = /* @__PURE__ */ Wt(queueMicrotask, !1);
// node_modules/motion-dom/dist/es/animation/animate/single-value.mjs
function Yo(e, t, n) {
	let r = K(e) ? e : G(e);
	return r.run(sa("", r, t, n)), r.animation;
}
// node_modules/motion-dom/dist/es/projection/styles/scale-correction.mjs
var Xo = {}, Zo = {
	value: null,
	addProjectionMetrics: null,
	countProjection: void 0
};
// node_modules/motion-dom/dist/es/utils/delay.mjs
function Qo(e, t) {
	let n = N.now();
	e = Ya(e);
	let r = ({ timestamp: i }) => {
		let a = i - n;
		a >= t && (B(r), e(a - t));
	};
	return z.setup(r, !0), Ja(() => B(r));
}
// node_modules/motion-dom/dist/es/utils/is-ref-object.mjs
function $o(e) {
	return e && typeof e == "object" && Object.prototype.hasOwnProperty.call(e, "current");
}
// node_modules/motion-dom/dist/es/utils/is-svg-svg-element.mjs
function es(e) {
	return qa(e) && e.tagName === "svg";
}
// node_modules/motion-dom/dist/es/value/utils/resolve-motion-value.mjs
function ts(e) {
	return K(e) ? e.get() : e;
}
// node_modules/motion-dom/dist/es/value/utils/as-number.mjs
var ns = (e) => typeof e == "number" ? e : parseFloat(e), rs = Ra.length, is = (e) => typeof e == "number" || F.test(e);
function as(e, t, n, r, i, a) {
	i ? (e.opacity = R(0, n.opacity ?? 1, ss(r)), e.opacityExit = R(t.opacity ?? 1, 0, cs(r))) : a && (e.opacity = R(t.opacity ?? 1, n.opacity ?? 1, r));
	for (let i = 0; i < rs; i++) {
		let a = Ra[i], o = os(t, a), s = os(n, a);
		(o !== void 0 || s !== void 0) && (o ||= 0, s ||= 0, o === 0 || s === 0 || is(o) === is(s) ? (e[a] = Math.max(R(ns(o), ns(s), r), 0), (P.test(s) || P.test(o)) && (e[a] += "%")) : e[a] = s);
	}
	for (let i = 0; i < wo.length; i++) {
		let a = wo[i];
		(t[a] || n[a]) && (e[a] = R(t[a] || 0, n[a] || 0, r));
	}
}
function os(e, t) {
	return e[t] === void 0 ? e.borderRadius : e[t];
}
var ss = /*@__PURE__*/ ls(0, .5, ve), cs = /*@__PURE__*/ ls(.5, .95, k);
function ls(e, t, n) {
	return (r) => r < e ? 0 : r > t ? 1 : n(/* @__PURE__ */ re(e, t, r));
}
// node_modules/motion-dom/dist/es/projection/geometry/copy.mjs
function us(e, t) {
	e.min = t.min, e.max = t.max;
}
function Y(e, t) {
	us(e.x, t.x), us(e.y, t.y);
}
function ds(e, t) {
	e.translate = t.translate, e.scale = t.scale, e.originPoint = t.originPoint, e.origin = t.origin;
}
// node_modules/motion-dom/dist/es/projection/geometry/delta-calc.mjs
var fs = .9999, ps = 1.0001, ms = -.01, hs = .01;
function X(e) {
	return e.max - e.min;
}
function gs(e, t, n) {
	return Math.abs(e - t) <= n;
}
function _s(e, t, n, r = .5) {
	e.origin = r, e.originPoint = R(t.min, t.max, e.origin), e.scale = X(n) / X(t), e.translate = R(n.min, n.max, e.origin) - e.originPoint, (e.scale >= fs && e.scale <= ps || isNaN(e.scale)) && (e.scale = 1), (e.translate >= ms && e.translate <= hs || isNaN(e.translate)) && (e.translate = 0);
}
function vs(e, t, n, r) {
	_s(e.x, t.x, n.x, r?.originX), _s(e.y, t.y, n.y, r?.originY);
}
function ys(e, t, n, r = 0) {
	e.min = (r ? R(n.min, n.max, r) : n.min) + t.min, e.max = e.min + X(t);
}
function bs(e, t, n, r) {
	ys(e.x, t.x, n.x, r?.x), ys(e.y, t.y, n.y, r?.y);
}
function xs(e, t, n, r = 0) {
	let i = r ? R(n.min, n.max, r) : n.min;
	e.min = t.min - i, e.max = e.min + X(t);
}
function Ss(e, t, n, r) {
	xs(e.x, t.x, n.x, r?.x), xs(e.y, t.y, n.y, r?.y);
}
// node_modules/motion-dom/dist/es/projection/geometry/delta-remove.mjs
function Cs(e, t, n, r, i) {
	return e -= t, e = ko(e, 1 / n, r), i !== void 0 && (e = ko(e, 1 / i, r)), e;
}
function ws(e, t = 0, n = 1, r = .5, i, a = e, o = e) {
	if (P.test(t) && (t = parseFloat(t), t = R(o.min, o.max, t / 100) - o.min), typeof t != "number") return;
	let s = R(a.min, a.max, r);
	e === a && (s -= t), e.min = Cs(e.min, t, n, s, i), e.max = Cs(e.max, t, n, s, i);
}
function Ts(e, t, [n, r, i], a, o) {
	ws(e, t[n], t[r], t[i], t.scale, a, o);
}
var Es = [
	"x",
	"scaleX",
	"originX"
], Ds = [
	"y",
	"scaleY",
	"originY"
];
function Os(e, t, n, r) {
	Ts(e.x, t, Es, n?.x, r?.x), Ts(e.y, t, Ds, n?.y, r?.y);
}
// node_modules/motion-dom/dist/es/projection/geometry/round.mjs
var ks = (e) => typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(e), As = ks("applewebkit/") && !ks("chrome/") ? Math.round : k;
function js(e) {
	e.min = As(e.min), e.max = As(e.max);
}
function Ms(e) {
	js(e.x), js(e.y);
}
// node_modules/motion-dom/dist/es/projection/geometry/models.mjs
var Ns = () => ({
	translate: 0,
	scale: 1,
	origin: 0,
	originPoint: 0
}), Ps = () => ({
	x: Ns(),
	y: Ns()
}), Fs = () => ({
	min: 0,
	max: 0
}), Z = () => ({
	x: Fs(),
	y: Fs()
});
// node_modules/motion-dom/dist/es/projection/geometry/utils.mjs
function Is(e) {
	return e.translate === 0 && e.scale === 1;
}
function Ls(e) {
	return Is(e.x) && Is(e.y);
}
function Rs(e, t) {
	return e.min === t.min && e.max === t.max;
}
function zs(e, t) {
	return Rs(e.x, t.x) && Rs(e.y, t.y);
}
function Bs(e, t) {
	return Math.round(e.min) === Math.round(t.min) && Math.round(e.max) === Math.round(t.max);
}
function Vs(e, t) {
	return Bs(e.x, t.x) && Bs(e.y, t.y);
}
function Hs(e) {
	return X(e.x) / X(e.y);
}
function Us(e, t) {
	return e.translate === t.translate && e.scale === t.scale && e.originPoint === t.originPoint;
}
// node_modules/motion-dom/dist/es/projection/shared/stack.mjs
var Ws = class {
	constructor() {
		this.members = [];
	}
	add(e) {
		b(this.members, e);
		for (let t = this.members.length - 1; t >= 0; t--) {
			let n = this.members[t];
			if (n === e || n === this.lead || n === this.prevLead) continue;
			let r = n.instance;
			r && r.isConnected !== !1 || n.snapshot || (x(this.members, n), n.unmount());
		}
		e.scheduleRender();
	}
	remove(e) {
		if (x(this.members, e), e === this.prevLead && (this.prevLead = void 0), e === this.lead) {
			let e = this.members[this.members.length - 1];
			e && this.promote(e);
		}
	}
	relegate(e) {
		for (let t = this.members.indexOf(e) - 1; t >= 0; t--) {
			let e = this.members[t];
			if (e.isPresent !== !1 && e.instance?.isConnected !== !1) return this.promote(e), !0;
		}
		return !1;
	}
	promote(e, t) {
		let n = this.lead;
		if (e !== n && (this.prevLead = n, this.lead = e, e.show(), n)) {
			n.updateSnapshot(), e.scheduleRender();
			let { layoutDependency: r } = n.options, { layoutDependency: i } = e.options;
			(r === void 0 || r !== i) && (e.resumeFrom = n, t && (n.preserveOpacity = !0), n.snapshot && (e.snapshot = n.snapshot, e.snapshot.latestValues = n.animationValues || n.latestValues), e.root?.isUpdating && (e.isLayoutDirty = !0)), e.options.crossfade === !1 && n.hide();
		}
	}
	exitAnimationComplete() {
		this.members.forEach((e) => {
			e.options.onExitComplete?.(), e.resumingFrom?.options.onExitComplete?.();
		});
	}
	scheduleRender() {
		this.members.forEach((e) => e.instance && e.scheduleRender(!1));
	}
	removeLeadSnapshot() {
		this.lead?.snapshot && (this.lead.snapshot = void 0);
	}
};
// node_modules/motion-dom/dist/es/projection/styles/scale-border-radius.mjs
function Gs(e, t) {
	return t.max === t.min ? 0 : e / (t.max - t.min) * 100;
}
var Ks = { correct: (e, t) => {
	if (!t.target) return e;
	if (typeof e == "string") {
		if (F.test(e)) e = parseFloat(e);
		else return e;
	}
	return `${Gs(e, t.target.x)}% ${Gs(e, t.target.y)}%`;
} }, qs = {
	borderRadius: /* @__PURE__ */ Object.assign({}, Ks, { applyTo: /* @__PURE__ */ Ra.slice() }),
	borderTopLeftRadius: Ks,
	borderTopRightRadius: Ks,
	borderBottomLeftRadius: Ks,
	borderBottomRightRadius: Ks,
	boxShadow: { correct: (e, { treeScale: t, projectionDelta: n }) => {
		let r = e, i = L.parse(e);
		if (i.length > 5) return r;
		let a = L.createTransformer(e), o = typeof i[0] == "number" ? 0 : 1, s = n.x.scale * t.x, c = n.y.scale * t.y;
		i[0 + o] /= s, i[1 + o] /= c;
		let l = R(s, c, .5);
		return typeof i[2 + o] == "number" && (i[2 + o] /= l), typeof i[3 + o] == "number" && (i[3 + o] /= l), a(i);
	} }
};
// node_modules/motion-dom/dist/es/projection/styles/transform.mjs
function Js(e, t, n) {
	let r = "", i = e.x.translate / t.x, a = e.y.translate / t.y, o = n?.z || 0;
	(i || a || o) && (r = `translate3d(${i}px, ${a}px, ${o}px) `);
	let s = "";
	if (n) {
		let { transformPerspective: e } = n;
		e && (r = `perspective(${e}px) ${r}`);
		for (let e = 0; e < wo.length; e++) {
			let t = wo[e], r = n[t];
			r && (s += `${t}(${r}deg) `), !e && n.pathRotation && (s += `rotate(${n.pathRotation}deg) `);
		}
	}
	if (s) {
		(t.x !== 1 || t.y !== 1) && (r += `scale(${1 / t.x}, ${1 / t.y}) `), r += s;
		let n = e.x.scale * t.x, i = e.y.scale * t.y;
		(n !== 1 || i !== 1) && (r += `scale(${n}, ${i})`);
	} else e.x.scale !== 1 || e.y.scale !== 1 ? r += `scale(${e.x.scale}, ${e.y.scale})` : r || t.x === 1 && t.y === 1 || (r = "scale(1, 1)");
	return r || "none";
}
// node_modules/motion-dom/dist/es/projection/utils/each-axis.mjs
function Q(e) {
	return [e("x"), e("y")];
}
// node_modules/motion-dom/dist/es/projection/utils/compare-by-depth.mjs
var Ys = (e, t) => e.depth - t.depth, Xs = class {
	constructor() {
		this.children = [], this.isDirty = !1;
	}
	add(e) {
		b(this.children, e), this.isDirty = !0;
	}
	remove(e) {
		x(this.children, e), this.isDirty = !0;
	}
	forEach(e) {
		this.isDirty && this.children.sort(Ys), this.isDirty = !1, this.children.forEach(e);
	}
}, Zs = {
	hasAnimatedSinceResize: !0,
	hasEverUpdated: !1
}, Qs = [
	"z",
	"skew",
	"skewZ"
], $s = 1e3, ec = 0;
function tc(e, t, n, r) {
	let { latestValues: i } = t;
	i[e] && (n[e] = i[e], t.setStaticValue(e, 0), r && (r[e] = 0));
}
var nc = (e) => e.instance && gi.get(e.instance)?.demote() && e.resetSkewAndRotation();
function rc(e) {
	if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
	let { visualElement: t } = e.options;
	if (!t) return;
	let n = wa(t);
	if (window.MotionHasOptimisedAnimation(n, "transform")) {
		let { layout: t, layoutId: r } = e.options;
		window.MotionCancelOptimisedAnimation(n, "transform", z, !(t || r));
	}
	let { parent: r } = e;
	r && !r.hasCheckedOptimisedAppear && rc(r);
}
function ic(e) {
	if (e) return e.options.allowProjection === !1 ? ic(e.parent) : e.projection;
}
function ac({ attachResizeListener: e, defaultParent: t, measureScroll: n, checkIsScrollRoot: r, resetTransform: i }) {
	return Object.assign(Xo, {
		...qs,
		...Xo
	}), class {
		static create(e, t, n) {
			let { layoutId: r, layout: i, drag: a, dragConstraints: o, layoutScroll: s, layoutRoot: c, layoutAnchor: l, layoutCrossfade: u } = t, d = e.projection = new this(e.latestValues, t["data-framer-portal-id"] ? void 0 : ic(e.parent));
			d.setOptions({
				layoutId: r,
				layout: i,
				alwaysMeasureLayout: !!a || o && $o(o),
				visualElement: e,
				animationType: typeof i == "string" ? i : "both",
				initialPromotionConfig: n,
				crossfade: u,
				layoutScroll: s,
				layoutRoot: c,
				layoutAnchor: l
			});
			let f = d.getStack()?.lead;
			f && !d.root.isUpdateBlocked() && (f.willUpdate(), f.scheduleCheckAfterUnmount());
		}
		constructor(e = {}, n = t?.()) {
			this.id = ec++, this.animationId = 0, this.animationCommitId = 0, this.children = /* @__PURE__ */ new Set(), this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
				x: 1,
				y: 1
			}, this.eventHandlers = /* @__PURE__ */ new Map(), this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
				this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots());
			}, this.updateProjection = () => {
				this.projectionUpdateScheduled = !1, this.nodes.forEach(cc), this.nodes.forEach(yc), this.nodes.forEach(bc), this.nodes.forEach(lc), Zo.countProjection?.();
			}, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = /* @__PURE__ */ new Map(), this.latestValues = e, this.root = n ? n.root || n : this, this.path = n ? [...n.path, n] : [], this.parent = n, this.depth = n ? n.depth + 1 : 0;
			for (let e = 0; e < this.path.length; e++) this.path[e].shouldResetTransform = !0;
			this.root === this && (this.nodes = new Xs());
		}
		addEventListener(e, t) {
			return this.eventHandlers.has(e) || this.eventHandlers.set(e, new ie()), this.eventHandlers.get(e).add(t);
		}
		notifyListeners(e, ...t) {
			this.eventHandlers.get(e)?.notify(...t);
		}
		hasListeners(e) {
			return this.eventHandlers.has(e);
		}
		mount(t) {
			if (this.instance) return;
			this.isSVG = qa(t) && !es(t), this.instance = t;
			let { layoutId: n, layout: r, visualElement: i } = this.options;
			if (i && !i.current && i.mount(t), this.root.nodes.add(this), this.parent?.children.add(this), this.root.hasTreeAnimated && (r || n) && (this.isLayoutDirty = !0), e) {
				let n, r = 0, i = () => this.root.updateBlockedByResize = !1;
				z.read(() => {
					r = window.innerWidth;
				}), e(t, () => {
					let e = window.innerWidth;
					e !== r && (r = e, this.root.updateBlockedByResize = !0, n?.(), n = Qo(i, 250), Zs.hasAnimatedSinceResize && (Zs.hasAnimatedSinceResize = !1, this.nodes.forEach(vc)));
				});
			}
			n && this.root.registerSharedNode(n, this), this.addLayoutListener();
		}
		addLayoutListener() {
			let { layoutId: e, layout: t, visualElement: n, animate: r } = this.options;
			this.instance && !this.hasLayoutListener && r !== !1 && n && (e || t) && (this.hasLayoutListener = !0, this.addEventListener("didUpdate", ({ delta: e, hasLayoutChanged: t, hasRelativeLayoutChanged: r, layout: i }) => {
				if (this.isAnimationBlocked) {
					this.target = void 0, this.relativeTarget = void 0;
					return;
				}
				let a = this.options.transition || n.getDefaultTransition() || Ec, { onLayoutAnimationStart: o, onLayoutAnimationComplete: s } = n.getProps(), c = !this.targetLayout || !Vs(this.targetLayout, i), l = !t && r;
				if (this.options.layoutRoot || this.resumeFrom || l || t && (c || !this.currentAnimation)) {
					this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0);
					let t = {
						...$i(a, "layout"),
						onPlay: o,
						onComplete: s
					};
					(n.shouldReduceMotion || this.options.layoutRoot) && (t.delay = 0, t.type = !1), this.startAnimation(t), this.setAnimationOrigin(e, l, t.path);
				} else t || vc(this), this.isLead() && this.options.onExitComplete?.();
				this.targetLayout = i;
			}));
		}
		unmount() {
			this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this), this.getStack()?.remove(this), this.parent?.children.delete(this), this.instance = void 0, this.eventHandlers.clear(), this.hasLayoutListener = !1, B(this.updateProjection);
		}
		blockUpdate() {
			this.updateManuallyBlocked = !0;
		}
		unblockUpdate() {
			this.updateManuallyBlocked = !1;
		}
		isUpdateBlocked() {
			return this.updateManuallyBlocked || this.updateBlockedByResize;
		}
		startUpdate() {
			this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes?.forEach(xc), this.animationId++);
		}
		getTransformTemplate() {
			let { visualElement: e } = this.options;
			return e && e.getProps().transformTemplate;
		}
		willUpdate(e = !0) {
			if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
				this.options.onExitComplete?.();
				return;
			}
			if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && rc(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
			nc(this), this.isLayoutDirty = !0;
			for (let e = 0; e < this.path.length; e++) {
				let t = this.path[e];
				t.shouldResetTransform = !0, nc(t), (typeof t.latestValues.x == "string" || typeof t.latestValues.y == "string") && (t.isLayoutDirty = !0), t.updateScroll("snapshot"), t.options.layoutRoot && t.willUpdate(!1), t.isAnimationBlocked && (t.dragSnapshot ||= t.measure(), this.dragAncestor = t);
			}
			let { layoutId: t, layout: n } = this.options;
			if (t === void 0 && !n) return;
			let r = this.getTransformTemplate();
			this.prevTransformTemplateValue = r ? r(this.latestValues, "") : void 0, this.updateSnapshot(), e && this.notifyListeners("willUpdate");
		}
		update() {
			if (this.updateScheduled = !1, this.isUpdateBlocked()) {
				let e = this.updateBlockedByResize;
				this.unblockUpdate(), this.updateBlockedByResize = !1, this.clearAllSnapshots(), e && this.nodes.forEach(fc), this.nodes.forEach(dc);
				return;
			}
			if (this.animationId <= this.animationCommitId) {
				this.nodes.forEach(pc);
				return;
			}
			this.animationCommitId = this.animationId, this.isUpdating ? (this.isUpdating = !1, this.nodes.forEach(hc), this.nodes.forEach(gc), this.nodes.forEach(_c), this.nodes.forEach(oc), this.nodes.forEach(sc)) : this.nodes.forEach(pc), this.clearAllSnapshots();
			let e = N.now();
			M.delta = S(0, 1e3 / 60, e - M.timestamp), M.timestamp = e, M.isProcessing = !0, Gt.update.process(M), Gt.preRender.process(M), Gt.render.process(M), M.isProcessing = !1;
		}
		didUpdate() {
			this.updateScheduled || (this.updateScheduled = !0, qo.read(this.scheduleUpdate));
		}
		clearAllSnapshots() {
			this.nodes.forEach(uc), this.sharedNodes.forEach((e, t) => e.members.length ? e.removeLeadSnapshot() : this.sharedNodes.delete(t));
		}
		scheduleUpdateProjection() {
			this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, z.preRender(this.updateProjection, !1, !0));
		}
		scheduleCheckAfterUnmount() {
			z.postRender(() => {
				this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed();
			});
		}
		updateSnapshot() {
			!this.snapshot && this.instance && (this.snapshot = this.measure(), this.snapshot && !X(this.snapshot.measuredBox.x) && !X(this.snapshot.measuredBox.y) && (this.snapshot = void 0));
		}
		updateLayout() {
			if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
			if (this.resumeFrom && !this.resumeFrom.instance) for (let e = 0; e < this.path.length; e++) this.path[e].updateScroll();
			let e = this.layout;
			this.layout = this.measure(!1), this.layoutCorrected ||= Z(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
			let { visualElement: t } = this.options;
			t?.notify("LayoutMeasure", this.layout.layoutBox, e?.layoutBox);
		}
		updateScroll(e = "measure") {
			let { scroll: t, instance: i } = this, { animationId: a } = this.root;
			if (this.options.layoutScroll && i && !(t && t.animationId === a && t.phase === e)) {
				let o = r(i);
				this.scroll = {
					animationId: a,
					phase: e,
					isRoot: o,
					offset: n(i),
					wasRoot: t ? t.isRoot : o
				};
			}
		}
		resetTransform() {
			if (!i) return;
			let e = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout;
			e && nc(this);
			let t = this.projectionDelta && !Ls(this.projectionDelta), n = this.getTransformTemplate(), r = n ? n(this.latestValues, "") : void 0, a = r !== this.prevTransformTemplateValue;
			e && this.instance && (t || To(this.latestValues) || a) && (i(this.instance, r), this.shouldResetTransform = !1, this.scheduleRender());
		}
		measure(e = !0) {
			let t = this.measurePageBox(), n = this.removeElementScroll(t);
			return e && (n = this.removeTransform(n)), Ms(n), {
				animationId: this.root.animationId,
				measuredBox: t,
				layoutBox: n,
				latestValues: {},
				source: this.id
			};
		}
		measurePageBox() {
			let { visualElement: e } = this.options;
			if (!e) return Z();
			let t = e.measureViewportBox();
			if (!(this.scroll?.wasRoot || this.path.some(kc))) {
				let { scroll: e } = this.root;
				e && (J(t.x, e.offset.x), J(t.y, e.offset.y));
			}
			return t;
		}
		removeElementScroll(e) {
			let t = Z();
			if (Y(t, e), this.scroll?.wasRoot) return t;
			for (let n = 0; n < this.path.length; n++) {
				let r = this.path[n], { scroll: i, options: a } = r;
				r !== this.root && i && a.layoutScroll && (i.wasRoot && Y(t, e), J(t.x, i.offset.x), J(t.y, i.offset.y));
			}
			return t;
		}
		applyTransform(e, t = !1, n, r, i = 0) {
			let a = n || Z();
			Y(a, e);
			for (let e = i; e < this.path.length; e++) {
				let n = this.path[e];
				!t && n.options.layoutScroll && n.scroll && n !== n.root && (J(a.x, -n.scroll.offset.x), J(a.y, -n.scroll.offset.y)), To(n.latestValues) && Ro(a, n.latestValues, n.layout?.layoutBox);
			}
			return !r && To(this.latestValues) && Ro(a, this.latestValues, this.layout?.layoutBox), a;
		}
		removeTransform(e) {
			let t = Z();
			Y(t, e);
			for (let e = 0; e < this.path.length; e++) {
				let n = this.path[e];
				if (!To(n.latestValues)) continue;
				let r;
				n.instance && (Co(n.latestValues) && n.updateSnapshot(), r = Z(), Y(r, n.measurePageBox())), Os(t, n.latestValues, n.snapshot?.layoutBox, r);
			}
			return To(this.latestValues) && Os(t, this.latestValues), t;
		}
		setTargetDelta(e) {
			this.targetDelta = e, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0;
		}
		setOptions(e) {
			this.options = {
				...this.options,
				...e,
				crossfade: e.crossfade === void 0 || e.crossfade
			}, this.addLayoutListener();
		}
		clearMeasurements() {
			this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1;
		}
		forceRelativeParentToResolveTarget() {
			this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== M.timestamp && this.relativeParent.resolveTargetDelta(!0);
		}
		resolveTargetDelta(e = !1) {
			let t = this.getLead();
			this.isProjectionDirty ||= t.isProjectionDirty, this.isTransformDirty ||= t.isTransformDirty, this.isSharedProjectionDirty ||= t.isSharedProjectionDirty;
			let n = !!this.resumingFrom || this !== t;
			if (!(e || n && this.isSharedProjectionDirty || this.isProjectionDirty || this.parent?.isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
			let { layout: r, layoutId: i } = this.options;
			if (!this.layout || !(r || i)) return;
			this.resolvedRelativeTargetAt = M.timestamp;
			let a = this.getClosestProjectingParent();
			!this.targetDelta && !this.relativeTarget && (this.options.layoutAnchor !== !1 && a && a.layout ? this.createRelativeTarget(a, this.layout.layoutBox, a.layout.layoutBox) : this.removeRelativeTarget()), (this.relativeTarget || this.targetDelta) && (this.target || (this.target = Z(), this.targetWithTransforms = Z()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), bs(this.target, this.relativeTarget, this.relativeParent.target, this.options.layoutAnchor || void 0)) : this.targetDelta ? (this.resumingFrom ? this.applyTransform(this.layout.layoutBox, !1, this.target, !0) : Y(this.target, this.layout.layoutBox), Mo(this.target, this.targetDelta)) : Y(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget && (this.attemptToResolveRelativeTarget = !1, this.options.layoutAnchor !== !1 && a && (!a.resumingFrom == !this.resumingFrom || a.options.layoutRoot && !a.resumingFrom) && !a.options.layoutScroll && a.target && this.animationProgress !== 1 ? this.createRelativeTarget(a, this.target, a.target) : this.relativeParent = this.relativeTarget = void 0), Zo.countProjection?.(1));
		}
		getClosestProjectingParent() {
			if (!(!this.parent || Co(this.parent.latestValues) || Do(this.parent.latestValues))) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent();
		}
		isProjecting() {
			return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout);
		}
		createRelativeTarget(e, t, n) {
			this.relativeParent = e, this.forceRelativeParentToResolveTarget(), this.relativeTarget = Z(), this.relativeTargetOrigin = Z(), Ss(this.relativeTargetOrigin, t, n, this.options.layoutAnchor || void 0), Y(this.relativeTarget, this.relativeTargetOrigin);
		}
		removeRelativeTarget() {
			this.relativeParent = this.relativeTarget = void 0;
		}
		calcProjection() {
			let e = this.getLead(), t = !!this.resumingFrom || this !== e, n = !0;
			if ((this.isProjectionDirty || this.parent?.isProjectionDirty) && (n = !1), t && (this.isSharedProjectionDirty || this.isTransformDirty) && (n = !1), this.resolvedRelativeTargetAt === M.timestamp && (n = !1), n) return;
			let { layout: r, layoutId: i } = this.options;
			if (this.isTreeAnimating = !!(this.parent?.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(r || i)) return;
			Y(this.layoutCorrected, this.layout.layoutBox);
			let a = this.treeScale.x, o = this.treeScale.y;
			Fo(this.layoutCorrected, this.treeScale, this.path, t && (e.relativeTarget && !e.relativeParent.resumingFrom ? e.relativeParent : !0)), e.layout && !e.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1) && (e.target = e.layout.layoutBox, e.targetWithTransforms = Z());
			let { target: s } = e;
			s ? (!this.projectionDelta || !this.prevProjectionDelta ? this.createProjectionDeltas() : (ds(this.prevProjectionDelta.x, this.projectionDelta.x), ds(this.prevProjectionDelta.y, this.projectionDelta.y)), vs(this.projectionDelta, this.layoutCorrected, s, this.latestValues), this.treeScale.x === a && this.treeScale.y === o && Us(this.projectionDelta.x, this.prevProjectionDelta.x) && Us(this.projectionDelta.y, this.prevProjectionDelta.y) || (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", s)), Zo.countProjection?.(2)) : this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
		}
		hide() {
			this.isVisible = !1;
		}
		show() {
			this.isVisible = !0;
		}
		scheduleRender(e = !0) {
			this.options.visualElement?.scheduleRender(), e && this.getStack()?.scheduleRender(), this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0);
		}
		createProjectionDeltas() {
			this.prevProjectionDelta = Ps(), this.projectionDelta = Ps(), this.projectionDeltaWithTransform = Ps();
		}
		setAnimationOrigin(e, t = !1, n) {
			let r = this.snapshot, i = r ? r.latestValues : {}, a = { ...this.latestValues }, o = Ps();
			this.relativeParent && this.relativeParent.options.layoutRoot || (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !t;
			let s = Z(), c = r?.source !== this.layout?.source, l = this.getStack(), u = !l || l.members.length <= 1, d = !(!c || u || this.options.crossfade !== !0 || this.path.some(Tc));
			this.animationProgress = 0;
			let f, p = n?.interpolateProjection(e);
			this.mixTargetDelta = (t) => {
				let n = t / 1e3, r = p?.(n);
				Sc(o.x, e.x, n), Sc(o.y, e.y, n), r && (o.x.translate = r.x, o.y.translate = r.y), this.setTargetDelta(o), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (Ss(s, this.layout.layoutBox, this.relativeParent.layout.layoutBox, this.options.layoutAnchor || void 0), wc(this.relativeTarget, this.relativeTargetOrigin, s, n), f && zs(this.relativeTarget, f) && (this.isProjectionDirty = !1), f ||= Z(), Y(f, this.relativeTarget)), c && (this.animationValues = a, as(a, i, this.latestValues, n, d, u)), r?.rotate !== void 0 && (this.animationValues ||= a, this.animationValues.pathRotation = r.rotate), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = n;
			}, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0);
		}
		startAnimation(e) {
			this.notifyListeners("animationStart"), this.currentAnimation?.stop(), this.resumingFrom?.currentAnimation?.stop(), this.pendingAnimation &&= (B(this.pendingAnimation), void 0), this.pendingAnimation = z.update(() => {
				Zs.hasAnimatedSinceResize = !0, this.motionValue ||= G(0), this.motionValue.jump(0, !1), this.currentAnimation = Yo(this.motionValue, [0, 1e3], {
					...e,
					velocity: 0,
					isSync: !0,
					onUpdate: (t) => {
						this.mixTargetDelta(t), e.onUpdate && e.onUpdate(t);
					},
					onComplete: () => {
						e.onComplete && e.onComplete(), this.completeAnimation();
					}
				}), Bn(this.currentAnimation, this), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0;
			});
		}
		completeAnimation() {
			this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
			let e = this.getStack();
			e && e.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete");
		}
		finishAnimation() {
			this.currentAnimation && (this.mixTargetDelta?.($s), this.currentAnimation.stop()), this.completeAnimation();
		}
		applyTransformsToTarget() {
			let e = this.getLead(), { targetWithTransforms: t, layout: n, latestValues: r } = e, { target: i } = e;
			if (t && i && n) {
				if (this !== e && this.layout && n && Oc(this.options.animationType, this.layout.layoutBox, n.layoutBox)) {
					let { layoutBox: e } = this.layout, t = i;
					i = this.target || Z(), Dc(i.x, t.x, e.x), Dc(i.y, t.y, e.y);
				}
				Y(t, i), Ro(t, r), vs(this.projectionDeltaWithTransform, this.layoutCorrected, t, r);
			}
		}
		registerSharedNode(e, t) {
			this.sharedNodes.has(e) || this.sharedNodes.set(e, new Ws()), this.sharedNodes.get(e).add(t);
			let n = t.options.initialPromotionConfig;
			t.promote({
				transition: n?.transition,
				preserveFollowOpacity: n?.shouldPreserveFollowOpacity ? n.shouldPreserveFollowOpacity(t) : void 0
			});
		}
		isLead() {
			let e = this.getStack();
			return !e || e.lead === this;
		}
		getLead() {
			let { layoutId: e } = this.options;
			return e && this.getStack()?.lead || this;
		}
		getPrevLead() {
			let { layoutId: e } = this.options;
			return e ? this.getStack()?.prevLead : void 0;
		}
		getStack() {
			let { layoutId: e } = this.options;
			if (e) return this.root.sharedNodes.get(e);
		}
		promote({ needsReset: e, transition: t, preserveFollowOpacity: n } = {}) {
			this.getStack()?.promote(this, n), e && (this.projectionDelta = void 0, this.needsReset = !0), t && this.setOptions({ transition: t });
		}
		relegate() {
			return this.getStack()?.relegate(this) || !1;
		}
		resetSkewAndRotation() {
			let { visualElement: e } = this.options;
			if (!e) return;
			let { latestValues: t } = e;
			if (!Eo(t)) return;
			let n = {};
			for (let t = 0; t < Qs.length; t++) tc(Qs[t], e, n, this.animationValues);
			for (let t = 0; t < wo.length; t++) tc(wo[t], e, n, this.animationValues);
			e.render();
			for (let t in n) e.setStaticValue(t, n[t]), this.animationValues && (this.animationValues[t] = n[t]);
			e.scheduleRender();
		}
		applyProjectionStyles(e, t) {
			if (!this.instance || this.isSVG) return;
			let n = this.getLead();
			if (!this.isVisible && n !== this) {
				e.visibility = "hidden";
				return;
			}
			let r = this.getTransformTemplate();
			if (this.needsReset) {
				this.needsReset = !1, e.visibility = "", e.opacity = "", e.pointerEvents = ts(t?.pointerEvents) || "", e.transform = r ? r(this.latestValues, "") : "none";
				return;
			}
			if (!this.projectionDelta || !this.layout || !n.target) {
				(this.options.layoutId || this.needsShow) && (this.needsShow = !1, e.visibility = "", e.opacity = this.latestValues.opacity === void 0 ? 1 : this.latestValues.opacity, e.pointerEvents = ts(t?.pointerEvents) || ""), this.hasProjected && !To(this.latestValues) && (e.transform = r ? r({}, "") : "none", this.hasProjected = !1);
				return;
			}
			e.visibility = "";
			let i = n.animationValues || n.latestValues;
			this.applyTransformsToTarget();
			let a = Js(this.projectionDeltaWithTransform, this.treeScale, i);
			r && (a = r(i, a)), e.transform = a;
			let { x: o, y: s } = this.projectionDelta;
			e.transformOrigin = `${o.origin * 100}% ${s.origin * 100}% 0`, e.opacity = n.animationValues ? n === this ? i.opacity ?? this.latestValues.opacity ?? 1 : this.preserveOpacity ? this.latestValues.opacity : i.opacityExit : n === this ? i.opacity === void 0 ? "" : i.opacity : i.opacityExit === void 0 ? 0 : i.opacityExit;
			for (let t in Xo) {
				if (i[t] === void 0) continue;
				let { correct: r, applyTo: o, isCSSVariable: s } = Xo[t], c = a === "none" ? i[t] : r(i[t], n);
				if (o) {
					let t = o.length;
					for (let n = 0; n < t; n++) e[o[n]] = c;
				} else s ? this.options.visualElement.renderState.vars[t] = c : e[t] = c;
			}
			this.options.layoutId && (e.pointerEvents = n === this ? ts(t?.pointerEvents) || "" : "none");
		}
		clearSnapshot() {
			this.resumeFrom = this.snapshot = this.dragSnapshot = this.dragAncestor = void 0;
		}
		resetTree() {
			this.root.nodes.forEach((e) => e.currentAnimation?.stop()), this.root.nodes.forEach(dc), this.root.sharedNodes.clear();
		}
	};
}
function oc(e) {
	e.updateLayout(), mc(e);
}
function sc(e) {
	let t = e.resumeFrom?.snapshot || e.snapshot;
	if (e.isLead() && e.layout && t && e.hasListeners("didUpdate")) {
		let { layoutBox: n, measuredBox: r } = e.layout, { animationType: i } = e.options, a = t.source !== e.layout.source, o = (r, a) => {
			if (i === "size") Q((e) => {
				let t = X(r[e]);
				r[e].min = a[e].min, r[e].max = r[e].min + t;
			});
			else if (i === "x" || i === "y") {
				let e = i === "x" ? "y" : "x";
				us(r[e], a[e]);
			} else Oc(i, t.layoutBox, n) && Q((t) => {
				let n = X(a[t]);
				r[t].max = r[t].min + n, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[t].max = e.relativeTarget[t].min + n);
			});
		}, s = a ? t.measuredBox : t.layoutBox;
		o(s, n);
		let c = Ps();
		vs(c, n, t.layoutBox);
		let l = Ps();
		vs(l, a ? e.applyTransform(r, !0) : n, s);
		let u = !Ls(c), d = !1, f = e.getClosestProjectingParent();
		if ((!a || f?.options.layoutRoot && e.resumeFrom?.path.includes(f)) && f && !f.resumeFrom) {
			let { snapshot: r, layout: i } = f;
			if (r && i) {
				let s = e.options.layoutAnchor || void 0, c = Z();
				Ss(c, a ? e.resumeFrom.applyTransform(t.layoutBox, !0, void 0, !0, f.depth + 1) : t.layoutBox, r.layoutBox, s);
				let l = Z();
				Ss(l, n, i.layoutBox, s), a && o(c, l), Vs(c, l) || (d = !0), f.options.layoutRoot && (e.relativeTarget = l, e.relativeTargetOrigin = c, e.relativeParent = f);
			}
		}
		e.notifyListeners("didUpdate", {
			layout: n,
			snapshot: t,
			delta: l,
			layoutDelta: c,
			hasLayoutChanged: u,
			hasRelativeLayoutChanged: d
		});
	} else e.isLead() && e.options.onExitComplete?.();
	e.options.transition = void 0;
}
function cc(e) {
	Zo.countProjection?.(0), e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty ||= !!(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty), e.isTransformDirty ||= e.parent.isTransformDirty);
}
function lc(e) {
	e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1;
}
function uc(e) {
	e.clearSnapshot();
}
function dc(e) {
	e.clearMeasurements();
}
function fc(e) {
	e.isLayoutDirty = !0, e.updateLayout();
}
function pc(e) {
	e.isLayoutDirty = !1;
}
function mc(e) {
	let { snapshot: t, dragAncestor: n } = e, r = n?.isAnimationBlocked && n.layout;
	if (!t || !r || e.resumeFrom || e.isAnimationBlocked) return;
	let i = n.dragSnapshot;
	Q((e) => J(t.layoutBox[e], r.layoutBox[e].min - i.layoutBox[e].min));
}
function hc(e) {
	e.isAnimationBlocked && e.layout && !e.isLayoutDirty && (e.snapshot = e.dragSnapshot || e.layout, e.isLayoutDirty = !0);
}
function gc(e) {
	e.relativeTarget && e.relativeParent?.isLayoutDirty && (e.currentAnimation ? e.isLayoutDirty = !0 : (e.targetDelta = void 0, e.removeRelativeTarget()));
}
function _c(e) {
	let { visualElement: t } = e.options;
	t?.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform();
}
function vc(e) {
	e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0;
}
function yc(e) {
	e.resolveTargetDelta();
}
function bc(e) {
	e.calcProjection();
}
function xc(e) {
	e.resetSkewAndRotation();
}
function Sc(e, t, n) {
	e.translate = R(t.translate, 0, n), e.scale = R(t.scale, 1, n), e.origin = t.origin, e.originPoint = t.originPoint;
}
function Cc(e, t, n, r) {
	e.min = R(t.min, n.min, r), e.max = R(t.max, n.max, r);
}
function wc(e, t, n, r) {
	Cc(e.x, t.x, n.x, r), Cc(e.y, t.y, n.y, r);
}
function Tc(e) {
	return e.animationValues?.opacityExit !== void 0;
}
var Ec = {
	duration: .45,
	ease: [
		.4,
		0,
		.1,
		1
	]
};
function Dc(e, t, n) {
	e.max = X(n) + (e.min = t.min);
}
function Oc(e, t, n) {
	return e === "position" || e === "preserve-aspect" && !gs(Hs(t), Hs(n), .2);
}
function kc(e) {
	return e !== e.root && e.scroll?.wasRoot;
}
// node_modules/motion-dom/dist/es/events/add-dom-event.mjs
function Ac(e, t, n, r = { passive: !0 }) {
	return e.addEventListener(t, n, r), () => e.removeEventListener(t, n, r);
}
// node_modules/motion-dom/dist/es/projection/node/DocumentProjectionNode.mjs
var jc = /* @__PURE__ */ ac({
	attachResizeListener: (e, t) => Ac(e, "resize", t),
	measureScroll: Vo,
	checkIsScrollRoot: () => !0
}), Mc = { current: void 0 }, Nc = /* @__PURE__ */ ac({
	measureScroll: (e) => ({
		x: e.scrollLeft,
		y: e.scrollTop
	}),
	defaultParent: () => {
		if (!Mc.current) {
			let e = new jc({});
			e.mount(window), e.setOptions({ layoutScroll: !0 }), Mc.current = e;
		}
		return Mc.current;
	},
	resetTransform: (e, t) => {
		e.style.transform = t === void 0 ? "none" : t;
	},
	checkIsScrollRoot: (e) => window.getComputedStyle(e).position === "fixed"
}), Pc = /* @__PURE__ */ new WeakMap();
// node_modules/motion-dom/dist/es/render/utils/is-animation-controls.mjs
function Fc(e) {
	return typeof e == "object" && !!e && typeof e.start == "function";
}
// node_modules/motion-dom/dist/es/render/utils/is-variant-label.mjs
function Ic(e) {
	return typeof e == "string" || Array.isArray(e);
}
// node_modules/motion-dom/dist/es/render/utils/variant-props.mjs
var Lc = [
	"animate",
	"whileInView",
	"whileFocus",
	"whileHover",
	"whileTap",
	"whileDrag",
	"whilePinch",
	"exit"
], Rc = /* @__PURE__ */ ["initial"].concat(Lc);
// node_modules/motion-dom/dist/es/render/utils/is-controlling-variants.mjs
function zc(e) {
	if (Fc(e.animate)) return !0;
	for (let t = 0; t < Rc.length; t++) if (Ic(e[Rc[t]])) return !0;
	return !1;
}
function Bc(e) {
	return !!(zc(e) || e.variants);
}
// node_modules/motion-dom/dist/es/render/utils/motion-values.mjs
function Vc(e, t, n) {
	for (let r in t) {
		let i = t[r], a = n[r];
		if (K(i)) e.addValue(r, i);
		else if (K(a)) e.addValue(r, G(i, { owner: e }));
		else if (a !== i) {
			if (e.hasValue(r)) {
				let t = e.getValue(r);
				t.liveStyle === !0 ? t.jump(i) : t.hasAnimated || t.set(i);
			} else {
				let t = e.getStaticValue(r);
				e.addValue(r, G(t === void 0 ? i : t, { owner: e }));
			}
		}
	}
	for (let r in n) t[r] === void 0 && e.removeValue(r);
	return t;
}
// node_modules/motion-dom/dist/es/render/utils/reduced-motion/state.mjs
var Hc = { current: null }, Uc = { current: !1 }, Wc = typeof window < "u";
function Gc() {
	if (Uc.current = !0, Wc) {
		if (window.matchMedia) {
			let e = window.matchMedia("(prefers-reduced-motion)"), t = () => Hc.current = e.matches;
			e.addEventListener("change", t), t();
		} else Hc.current = !1;
	}
}
// node_modules/motion-dom/dist/es/render/VisualElement.mjs
var Kc = [
	"AnimationStart",
	"AnimationComplete",
	"Update",
	"BeforeLayoutMeasure",
	"LayoutMeasure",
	"LayoutAnimationStart",
	"LayoutAnimationComplete"
], qc = {};
function Jc(e) {
	qc = e;
}
function Yc() {
	return qc;
}
var Xc = class {
	scrapeMotionValuesFromProps(e, t, n) {
		return {};
	}
	constructor({ parent: e, props: t, presenceContext: n, reducedMotionConfig: r, skipAnimations: i, blockInitialAnimation: a, visualState: o }, s = {}) {
		this.current = null, this.children = /* @__PURE__ */ new Set(), this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.shouldSkipAnimations = !1, this.values = /* @__PURE__ */ new Map(), this.KeyframeResolver = Pr, this.features = {}, this.valueSubscriptions = /* @__PURE__ */ new Map(), this.prevMotionValues = {}, this.hasBeenMounted = !1, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
			this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection));
		}, this.renderScheduledAt = 0, this.scheduleRender = () => {
			let e = N.now();
			this.renderScheduledAt < e && (this.renderScheduledAt = e, z.render(this.render, !1, !0));
		};
		let { latestValues: c, renderState: l } = o;
		this.latestValues = c, this.baseTarget = { ...c }, this.initialValues = t.initial ? { ...c } : {}, this.renderState = l, this.parent = e, this.props = t, this.presenceContext = n, this.depth = e ? e.depth + 1 : 0, this.reducedMotionConfig = r, this.skipAnimationsConfig = i, this.options = s, this.blockInitialAnimation = !!a, this.isControllingVariants = zc(t), this.isVariantNode = Bc(t), this.isVariantNode && (this.variantChildren = /* @__PURE__ */ new Set()), this.manuallyAnimateOnMount = !!(e && e.current);
		let { willChange: u, ...d } = this.scrapeMotionValuesFromProps(t, {}, this);
		for (let e in d) {
			let t = d[e];
			c[e] !== void 0 && K(t) && t.set(c[e]);
		}
	}
	mount(e) {
		let t = this.presenceContext;
		if (this.hasBeenMounted && t?.isPresent !== !1 && !t?.keepValuesOnRemount) for (let e in this.initialValues) this.values.get(e)?.jump(this.initialValues[e]), this.latestValues[e] = this.initialValues[e];
		if (this.current = e, Pc.set(e, this), this.projection?.instance || this.projection?.mount(e), this.isVariantNode && !this.isControllingVariants) {
			let e = this;
			do
				e = e.props.inherit !== !1 && e.parent;
			while (e && !e.isVariantNode);
			if (e) {
				let { variantChildren: t } = e;
				t.add(this), this.removeFromVariantTree = () => t.delete(this);
			}
		}
		this.values.forEach((e, t) => this.bindToMotionValue(t, e)), this.reducedMotionConfig === "never" ? this.shouldReduceMotion = !1 : this.reducedMotionConfig === "always" ? this.shouldReduceMotion = !0 : (Uc.current || Gc(), this.shouldReduceMotion = Hc.current), process.env.NODE_ENV !== "production" && se(this.shouldReduceMotion !== !0, "You have Reduced Motion enabled on your device. Animations may not appear as expected.", "reduced-motion-disabled"), this.shouldSkipAnimations = this.skipAnimationsConfig ?? !1, this.parent?.addChild(this), this.update(this.props, this.presenceContext), this.hasBeenMounted = !0;
	}
	unmount() {
		this.projection?.unmount(), B(this.notifyUpdate), B(this.render), this.valueSubscriptions.forEach((e) => e()), this.valueSubscriptions.clear(), this.removeFromVariantTree?.(), this.parent?.removeChild(this);
		for (let e in this.events) this.events[e].clear();
		for (let e in this.features) {
			let t = this.features[e];
			t && (t.unmount(), t.isMounted = !1);
		}
		this.current = null;
	}
	addChild(e) {
		this.children.add(e), (this.enteringChildren ||= /* @__PURE__ */ new Set()).add(e);
	}
	removeChild(e) {
		this.children.delete(e), this.enteringChildren?.delete(e);
	}
	bindToMotionValue(e, t) {
		if (this.valueSubscriptions.get(e)?.(), t.accelerate && ni.has(e) && this.current instanceof HTMLElement) {
			let { factory: n, keyframes: r, times: i, ease: a, duration: o } = t.accelerate, s = new qr({
				element: this.current,
				name: e,
				keyframes: r,
				times: i,
				ease: a,
				duration: /* @__PURE__ */ A(o)
			}), c = n(s);
			this.valueSubscriptions.set(e, () => {
				c(), s.cancel();
			});
			return;
		}
		let n = W.has(e);
		n && this.onBindTransform && this.onBindTransform();
		let r = t.on("change", (t) => {
			this.latestValues[e] = t, this.props.onUpdate && z.preRender(this.notifyUpdate), n && (this.projection && (this.projection.isTransformDirty = !0), gi.get(this.current)?.check()), this.scheduleRender();
		}), i;
		typeof window < "u" && window.MotionCheckAppearSync && (i = window.MotionCheckAppearSync(this, e, t)), this.valueSubscriptions.set(e, () => {
			r(), i?.();
		});
	}
	sortNodePosition(e) {
		return !this.current || !e.current || !this.sortInstanceNodePosition || this.type !== e.type ? 0 : this.sortInstanceNodePosition(this.current, e.current);
	}
	updateFeatures() {
		let e = "animation";
		for (e in qc) {
			let t = qc[e];
			if (!t) continue;
			let { isEnabled: n, Feature: r } = t;
			if (!this.features[e] && r && n(this.props) && (this.features[e] = new r(this)), this.features[e]) {
				let t = this.features[e];
				t.isMounted ? t.update() : (t.mount(), t.isMounted = !0);
			}
		}
	}
	triggerBuild() {
		this.build(this.renderState, this.latestValues, this.props);
	}
	measureViewportBox() {
		return this.current ? this.measureInstanceViewportBox(this.current, this.props) : Z();
	}
	getStaticValue(e) {
		return this.latestValues[e];
	}
	setStaticValue(e, t) {
		this.latestValues[e] = t;
	}
	update(e, t) {
		let { transformTemplate: n, onUpdate: r } = this.props;
		(e.transformTemplate || n) && this.scheduleRender(), (e.transformTemplate && !n || e.onUpdate && !r) && gi.get(this.current)?.demote(), this.prevProps = this.props, this.props = e, this.prevPresenceContext = this.presenceContext, this.presenceContext = t;
		for (let t = 0; t < Kc.length; t++) {
			let n = Kc[t];
			this.propEventSubscriptions[n]?.(), delete this.propEventSubscriptions[n];
			let r = e["on" + n];
			r && (this.propEventSubscriptions[n] = this.on(n, r));
		}
		this.prevMotionValues = Vc(this, this.scrapeMotionValuesFromProps(e, this.prevProps || {}, this), this.prevMotionValues), this.handleChildMotionValue?.();
	}
	getProps() {
		return this.props;
	}
	getVariant(e) {
		return this.props.variants?.[e];
	}
	getDefaultTransition() {
		return this.props.transition;
	}
	getTransformPagePoint() {
		return this.props.transformPagePoint;
	}
	addValue(e, t) {
		let n = this.values.get(e);
		if (t !== n) {
			n && this.removeValue(e), this.bindToMotionValue(e, t), this.values.set(e, t);
			let r = t.get();
			r !== void 0 && (this.latestValues[e] = r);
		}
	}
	removeValue(e) {
		this.values.delete(e), this.valueSubscriptions.get(e)?.(), this.valueSubscriptions.delete(e), delete this.latestValues[e], this.removeValueFromRenderState(e, this.renderState);
	}
	hasValue(e) {
		return this.values.has(e);
	}
	getValue(e, t) {
		let n = this.props.values?.[e];
		return n || (n = this.values.get(e), n === void 0 && t !== void 0 && (n = G(t ?? this.getDefaultValue?.(e), { owner: this }), this.addValue(e, n)), n);
	}
	readValue(e, t) {
		let n = this.latestValues[e] !== void 0 || !this.current ? this.latestValues[e] : this.getBaseTargetFromProps(this.props, e) ?? this.readValueFromInstance(this.current, e, this.options);
		return n != null && (typeof n == "string" && (D(n) || ee(n)) ? n = parseFloat(n) : typeof n != "number" && !L.test(n) && L.test(t) && (n = ir(e, t)), this.setBaseTarget(e, K(n) ? n.get() : n)), K(n) ? n.get() : n;
	}
	setBaseTarget(e, t) {
		this.baseTarget[e] = t;
	}
	on(e, t) {
		return (this.events[e] || (this.events[e] = new ie())).add(t);
	}
	notify(e, ...t) {
		this.events[e]?.notify(...t);
	}
	scheduleRenderMicrotask() {
		qo.render(this.render);
	}
}, Zc = class extends Xc {
	constructor() {
		super(...arguments), this.KeyframeResolver = La;
	}
	sortInstanceNodePosition(e, t) {
		return e.compareDocumentPosition(t) & 2 ? 1 : -1;
	}
	getBaseTargetFromProps(e, t) {
		let n = e.style;
		return n ? n[t] : void 0;
	}
	removeValueFromRenderState(e, { vars: t, style: n }) {
		delete t[e], delete n[e];
	}
	handleChildMotionValue() {
		this.childSubscription && (this.childSubscription(), delete this.childSubscription);
		let { children: e } = this.props;
		K(e) && (this.childSubscription = e.on("change", (e) => {
			this.current && (this.current.textContent = `${e}`);
		}));
	}
};
// node_modules/motion-dom/dist/es/render/html/utils/render.mjs
function Qc(e, { style: t, vars: n }, r, i) {
	let a = e.style, o;
	for (o in t) a[o] = t[o];
	for (o in i?.applyProjectionStyles(a, r), n) a.setProperty(o, n[o]);
}
// node_modules/motion-dom/dist/es/render/utils/is-forced-motion-value.mjs
function $c(e, { layout: t, layoutId: n }) {
	return W.has(e) || e.startsWith("origin") || (t || n !== void 0) && (!!Xo[e] || e === "opacity");
}
// node_modules/motion-dom/dist/es/render/html/utils/scrape-motion-values.mjs
function el(e, t, n) {
	let r = e.style, i = t?.style, a = {};
	if (!r) return a;
	for (let t in r) (K(r[t]) || i && K(i[t]) || $c(t, e) || n?.getValue(t)?.liveStyle !== void 0) && (a[t] = r[t]);
	return a;
}
// node_modules/motion-dom/dist/es/render/html/HTMLVisualElement.mjs
function tl(e) {
	return window.getComputedStyle(e);
}
var nl = class extends Zc {
	constructor() {
		super(...arguments), this.type = "html", this.renderInstance = Qc;
	}
	mount(e) {
		process.env.NODE_ENV !== "production" && T(!!e.style, "motion.create() components must forward their ref to a HTML or SVG element", "custom-component-ref"), super.mount(e);
	}
	readValueFromInstance(e, t) {
		if (W.has(t)) return this.projection?.isProjecting ? mr(t) : gr(e, t);
		{
			let n = tl(e), r = (Ne(t) ? n.getPropertyValue(t) : n[t]) || 0;
			return typeof r == "string" ? r.trim() : r;
		}
	}
	measureInstanceViewportBox(e, { transformPagePoint: t }) {
		return zo(e, t);
	}
	build(e, t, n) {
		so(e, t, n.transformTemplate);
	}
	scrapeMotionValuesFromProps(e, t, n) {
		return el(e, t, n);
	}
}, rl = (e) => e.pointerType === "mouse" ? typeof e.button != "number" || e.button <= 0 : e.isPrimary !== !1;
// node_modules/motion-dom/dist/es/events/event-info.mjs
function il(e) {
	return { point: {
		x: e.pageX,
		y: e.pageY
	} };
}
var al = (e) => (t) => rl(t) && e(t, il(t));
// node_modules/motion-dom/dist/es/events/add-pointer-event.mjs
function ol(e, t, n, r) {
	return Ac(e, t, al(n), r);
}
// node_modules/motion-dom/dist/es/resize/handle-element.mjs
var sl = /* @__PURE__ */ new WeakMap(), cl, ll = (e, t, n) => (r, i) => i && i[0] ? i[0][e + "Size"] : qa(r) && "getBBox" in r ? r.getBBox()[t] : r[n], ul = /*@__PURE__*/ ll("inline", "width", "offsetWidth"), dl = /*@__PURE__*/ ll("block", "height", "offsetHeight");
function fl({ target: e, borderBoxSize: t }) {
	sl.get(e)?.forEach((n) => {
		n(e, {
			get width() {
				return ul(e, t);
			},
			get height() {
				return dl(e, t);
			}
		});
	});
}
function pl(e) {
	e.forEach(fl);
}
function ml() {
	typeof ResizeObserver < "u" && (cl = new ResizeObserver(pl));
}
function hl(e, t) {
	cl || ml();
	let n = Xa(e);
	return n.forEach((e) => {
		let n = sl.get(e);
		n || (n = /* @__PURE__ */ new Set(), sl.set(e, n)), n.add(t), cl?.observe(e);
	}), () => {
		n.forEach((e) => {
			let n = sl.get(e);
			n?.delete(t), n?.size || cl?.unobserve(e);
		});
	};
}
// node_modules/motion-dom/dist/es/resize/handle-window.mjs
var gl = /* @__PURE__ */ new Set(), _l;
function vl() {
	_l = () => {
		let e = {
			get width() {
				return window.innerWidth;
			},
			get height() {
				return window.innerHeight;
			}
		};
		gl.forEach((t) => t(e));
	}, window.addEventListener("resize", _l);
}
function yl(e) {
	return gl.add(e), _l || vl(), () => {
		gl.delete(e), !gl.size && typeof _l == "function" && (window.removeEventListener("resize", _l), _l = void 0);
	};
}
// node_modules/motion-dom/dist/es/resize/index.mjs
function bl(e, t) {
	return Ja(typeof e == "function" ? yl(e) : hl(e, t));
}
// node_modules/motion-dom/dist/es/utils/distance.mjs
var xl = (e, t) => Math.abs(e - t);
function Sl(e, t) {
	let n = xl(e.x, t.x), r = xl(e.y, t.y);
	return Math.sqrt(n ** 2 + r ** 2);
}
// node_modules/motion-dom/dist/es/gestures/pan/PanSession.mjs
var Cl = /*#__PURE__*/ new Set(["auto", "scroll"]), wl = class {
	constructor(e, t, { transformPagePoint: n, contextWindow: r = window, dragSnapToOrigin: i = !1, distanceThreshold: a = 3, element: o, immediate: s } = {}) {
		if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.lastRawMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.scrollPositions = /* @__PURE__ */ new Map(), this.onElementScroll = (e) => {
			this.handleScroll(e.target);
		}, this.onWindowScroll = () => {
			this.handleScroll(window);
		}, this.updatePoint = () => {
			if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
			this.hasPendingMove = !1, this.lastRawMoveEventInfo && (this.lastMoveEventInfo = El(this.lastRawMoveEventInfo, this.transformPagePoint));
			let e = Ol(this.lastMoveEventInfo, this.history), t = this.startEvent !== null, n = Sl(e.offset, {
				x: 0,
				y: 0
			}) >= this.distanceThreshold;
			if (!t && !n) return;
			let { point: r } = e;
			this.history.push({
				...r,
				timestamp: N.now()
			});
			let { onStart: i, onMove: a } = this.handlers;
			t || (i?.(this.lastMoveEvent, e), this.startEvent = this.lastMoveEvent), a?.(this.lastMoveEvent, e);
		}, this.handlePointerMove = (e, t) => {
			this.handleScroll(window), this.lastMoveEvent = e, this.lastRawMoveEventInfo = t, this.lastMoveEventInfo = El(t, this.transformPagePoint), this.hasPendingMove = !0, z.update(this.updatePoint, !0);
		}, this.handlePointerUp = (e, t) => {
			this.hasPendingMove && this.updatePoint(), this.end();
			let { onEnd: n, onSessionEnd: r, resumeAnimation: i } = this.handlers;
			if ((this.dragSnapToOrigin || !this.startEvent) && i?.(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
			let a = Ol(e.type === "pointercancel" ? this.lastMoveEventInfo : El(t, this.transformPagePoint), this.history);
			this.startEvent && n?.(e, a), r?.(e, a);
		}, !rl(e)) return;
		this.dragSnapToOrigin = i, this.handlers = t, this.transformPagePoint = n, this.distanceThreshold = s ? 0 : a, this.contextWindow = r || window;
		let c = il(e), l = El(c, this.transformPagePoint), { point: u } = l;
		this.history = [{
			...u,
			timestamp: N.now()
		}];
		let { onSessionStart: d } = t;
		d && d(e, Ol(l, this.history));
		let f = {
			passive: !0,
			capture: !0
		};
		this.removeListeners = ne(ol(this.contextWindow, "pointermove", this.handlePointerMove, f), ol(this.contextWindow, "pointerup", this.handlePointerUp, f), ol(this.contextWindow, "pointercancel", this.handlePointerUp, f)), o && this.startScrollTracking(o), s && (this.handlePointerMove(e, c), this.updatePoint());
	}
	startScrollTracking(e) {
		let t = e.parentElement;
		for (; t;) {
			let e = getComputedStyle(t);
			(Cl.has(e.overflowX) || Cl.has(e.overflowY)) && this.scrollPositions.set(t, Tl(t)), t = t.parentElement;
		}
		this.scrollPositions.set(window, Tl(window)), this.removeScrollListeners = ne(Ac(window, "scroll", this.onElementScroll, { capture: !0 }), Ac(window, "scroll", this.onWindowScroll, {}));
	}
	handleScroll(e) {
		let t = this.scrollPositions.get(e);
		if (!t) return;
		let n = e === window, r = Tl(e), i = {
			x: r.x - t.x,
			y: r.y - t.y
		};
		(i.x !== 0 || i.y !== 0) && (n ? this.lastMoveEventInfo && (this.lastMoveEventInfo.point.x += i.x, this.lastMoveEventInfo.point.y += i.y) : this.history.length > 0 && (this.history[0].x -= i.x, this.history[0].y -= i.y), this.scrollPositions.set(e, r), z.update(this.updatePoint, !0));
	}
	updateHandlers(e) {
		this.handlers = e;
	}
	end() {
		this.removeListeners?.(), this.removeScrollListeners?.(), this.scrollPositions.clear(), B(this.updatePoint);
	}
}, Tl = (e) => e === window ? {
	x: window.scrollX,
	y: window.scrollY
} : {
	x: e.scrollLeft,
	y: e.scrollTop
};
function El(e, t) {
	return t ? { point: t(e.point) } : e;
}
function Dl(e, t) {
	return {
		x: e.x - t.x,
		y: e.y - t.y
	};
}
function Ol({ point: e }, t) {
	return {
		point: e,
		delta: Dl(e, Al(t)),
		offset: Dl(e, kl(t)),
		velocity: jl(t, .1)
	};
}
function kl(e) {
	return e[0];
}
function Al(e) {
	return e[e.length - 1];
}
function jl(e, t) {
	if (e.length < 2) return {
		x: 0,
		y: 0
	};
	let n = e.length - 1, r = null, i = Al(e);
	for (; n >= 0 && (r = e[n], !(i.timestamp - r.timestamp > /* @__PURE__ */ A(t)));) n--;
	if (!r) return {
		x: 0,
		y: 0
	};
	r === e[0] && e.length > 2 && i.timestamp - r.timestamp > /* @__PURE__ */ A(t) * 2 && (r = e[1]);
	let a = /* @__PURE__ */ j(i.timestamp - r.timestamp);
	if (a === 0) return {
		x: 0,
		y: 0
	};
	let o = {
		x: (i.x - r.x) / a,
		y: (i.y - r.y) / a
	};
	return o.x === Infinity && (o.x = 0), o.y === Infinity && (o.y = 0), o;
}
// node_modules/motion-dom/dist/es/gestures/press/utils/is-keyboard-accessible.mjs
var Ml = /* @__PURE__ */ new Set([
	"BUTTON",
	"INPUT",
	"SELECT",
	"TEXTAREA",
	"A"
]);
function Nl(e) {
	return Ml.has(e.tagName) || e.isContentEditable === !0;
}
var Pl = /* @__PURE__ */ new Set([
	"INPUT",
	"SELECT",
	"TEXTAREA"
]);
function Fl(e) {
	return Pl.has(e.tagName) || e.isContentEditable === !0;
}
// node_modules/motion-dom/dist/es/gestures/drag/state/is-active.mjs
var $ = {
	x: !1,
	y: !1
};
function Il() {
	return $.x || $.y;
}
// node_modules/motion-dom/dist/es/gestures/drag/state/set-active.mjs
function Ll(e) {
	return e === "x" || e === "y" ? $[e] ? null : ($[e] = !0, () => {
		$[e] = !1;
	}) : $.x || $.y ? null : ($.x = $.y = !0, () => {
		$.x = $.y = !1;
	});
}
// node_modules/motion-dom/dist/es/gestures/drag/utils/constraints.mjs
function Rl(e, { min: t, max: n }, r) {
	return t !== void 0 && e < t ? e = r ? R(t, e, r.min) : Math.max(e, t) : n !== void 0 && e > n && (e = r ? R(n, e, r.max) : Math.min(e, n)), e;
}
function zl(e, t, n) {
	return {
		min: t === void 0 ? void 0 : e.min + t,
		max: n === void 0 ? void 0 : e.max + n - (e.max - e.min)
	};
}
function Bl(e, { top: t, left: n, bottom: r, right: i }) {
	return {
		x: zl(e.x, n, i),
		y: zl(e.y, t, r)
	};
}
function Vl(e, t) {
	let n = t.min - e.min, r = t.max - e.max;
	return t.max - t.min < e.max - e.min && ([n, r] = [r, n]), {
		min: n,
		max: r
	};
}
function Hl(e, t) {
	return {
		x: Vl(e.x, t.x),
		y: Vl(e.y, t.y)
	};
}
function Ul(e, t) {
	let n = .5, r = X(e), i = X(t);
	return i > r ? n = /* @__PURE__ */ re(t.min, t.max - r, e.min) : r > i && (n = /* @__PURE__ */ re(e.min, e.max - i, t.min)), S(0, 1, n);
}
function Wl(e, t) {
	let n = {};
	return t.min !== void 0 && (n.min = t.min - e.min), t.max !== void 0 && (n.max = t.max - e.min), n;
}
var Gl = .35;
function Kl(e = Gl) {
	return e === !1 ? e = 0 : e === !0 && (e = Gl), {
		x: ql(e, "left", "right"),
		y: ql(e, "top", "bottom")
	};
}
function ql(e, t, n) {
	return {
		min: Jl(e, t),
		max: Jl(e, n)
	};
}
function Jl(e, t) {
	return typeof e == "number" ? e : e[t] || 0;
}
// node_modules/motion-dom/dist/es/gestures/drag/VisualElementDragControls.mjs
function Yl(e) {
	let t = "";
	for (let n of e.path) {
		n.scroll = void 0, n.updateScroll();
		let { scroll: r } = n;
		n !== e.root && r && (t += r.offset.x + "," + r.offset.y + ",");
	}
	return t;
}
var Xl = /* @__PURE__ */ new WeakMap(), Zl = class {
	constructor(e, t = () => e.getProps()) {
		this.openDragLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
			x: 0,
			y: 0
		}, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = Z(), this.latestPointerEvent = null, this.latestPanInfo = null, this.visualElement = e, this.readProps = t;
	}
	start(e, t = {}) {
		if (this.visualElement.presenceContext?.isPresent === !1) return;
		let n = (e) => {
			t.snapToCursor && this.snapToCursor(e), this.stopAnimation();
		}, r = (e, t) => {
			let { drag: n, dragConstraints: r, dragPropagation: i, onDragStart: a } = this.getProps();
			if (n && !i && (this.openDragLock?.(), this.openDragLock = Ll(n), !this.openDragLock)) return;
			this.latestPointerEvent = e, this.latestPanInfo = t, this.isDragging = !0, this.currentDirection = null, this.resolveConstraints();
			let { projection: o } = this.visualElement;
			o && (o.isAnimationBlocked = !0, o.target = void 0), Q((e) => {
				let t = this.getAxisMotionValue(e).get() || 0;
				if (Fe(t) && (t = da(t, this.visualElement.current) || 0), F.test(t)) t = parseFloat(t);
				else if (P.test(t)) {
					let n = o?.layout?.layoutBox[e];
					n && (t = X(n) * (parseFloat(t) / 100));
				}
				this.originPoint[e] = t;
			}), this.point = typeof r == "function" && r(this), a && z.update(() => a(e, t), !1, !0), Sa(this.visualElement, "transform"), this.visualElement.animationState?.setActive("whileDrag", !0);
		}, i = (e, t) => {
			this.latestPointerEvent = e, this.latestPanInfo = t;
			let { dragPropagation: n, dragDirectionLock: r, onDirectionLock: i, onDrag: a } = this.getProps();
			if (!n && !this.openDragLock) return;
			let { offset: o } = t;
			if (r && this.currentDirection === null) {
				if (this.currentDirection = ru(o), this.currentDirection === null) return;
				i && i(this.currentDirection);
			}
			this.updateAxis("x", o), this.updateAxis("y", o), this.point && this.point.move(), this.visualElement.render(), a && z.update(() => a(e, t), !1, !0);
		}, a = (e, t) => {
			this.latestPointerEvent = e, this.latestPanInfo = t, this.stop(e, t), this.latestPointerEvent = null, this.latestPanInfo = null;
		}, o = () => {
			let { dragSnapToOrigin: e } = this.getProps();
			(e || this.constraints || this.point) && this.startAnimation({
				x: 0,
				y: 0
			});
		}, { dragSnapToOrigin: s } = this.getProps();
		this.panSession = new wl(e, {
			onSessionStart: n,
			onStart: r,
			onMove: i,
			onSessionEnd: a,
			resumeAnimation: o
		}, {
			...t,
			transformPagePoint: this.visualElement.getTransformPagePoint(),
			dragSnapToOrigin: s,
			contextWindow: this.visualElement.current?.ownerDocument.defaultView,
			element: this.visualElement.current
		});
	}
	stop(e, t, n) {
		let r = e || this.latestPointerEvent, i = t || this.latestPanInfo, a = this.isDragging;
		if (this.cancel(), !a || !i || !r) return;
		let { velocity: o } = i;
		this.startAnimation(o, n);
		let { onDragEnd: s } = this.getProps();
		s && z.postRender(() => s(r, i));
	}
	cancel() {
		this.isDragging = !1;
		let { projection: e, animationState: t } = this.visualElement;
		e && (e.isAnimationBlocked = !1), this.endPanSession(), !this.getProps().dragPropagation && this.openDragLock && (this.openDragLock(), this.openDragLock = null), t?.setActive("whileDrag", !1);
	}
	endPanSession() {
		this.panSession?.end(), this.panSession = void 0;
	}
	updateAxis(e, t) {
		let { drag: n } = this.readProps();
		if (!t || !nu(e, n, this.currentDirection)) return;
		let r = this.getAxisMotionValue(e), i = this.originPoint[e] + t[e], a = this.constraints && this.constraints[e];
		a && (i = Rl(i, a, this.elastic[e])), this.point ? this.point[e] = i : r.set(i);
	}
	resolveConstraints() {
		let { dragConstraints: e, dragElastic: t } = this.getProps(), { projection: n } = this.visualElement, r = n && (n.layout || n.measure(!1)), i = this.constraints;
		Ql(e) ? this.constraints && this.scroll === Yl(n) || (this.constraints = this.resolveRefConstraints()) : this.constraints = e && r && typeof e == "object" ? Bl(r.layoutBox, e) : !1, this.elastic = Kl(t), i !== this.constraints && !Ql(e) && r && this.constraints && !this.hasMutatedConstraints && Q((e) => {
			this.constraints !== !1 && this.getAxisMotionValue(e) && (this.constraints[e] = Wl(r.layoutBox[e], this.constraints[e]));
		});
	}
	resolveRefConstraints() {
		let { dragConstraints: e, onMeasureDragConstraints: t } = this.getProps();
		if (!Ql(e)) return !1;
		let n = $l(e);
		process.env.NODE_ENV !== "production" && T(!!n, "If `dragConstraints` is set as a React ref, that ref must be passed to another component's `ref` prop.", "drag-constraints-ref");
		let { projection: r } = this.visualElement;
		if (!r || !r.layout) return !1;
		this.scroll = Yl(r);
		let i = Bo(n, r.root, this.visualElement.getTransformPagePoint()), a = Hl(r.layout.layoutBox, r.removeElementScroll(i));
		if (t) {
			let e = t(bo(a));
			this.hasMutatedConstraints = !!e, e && (a = yo(e));
		}
		return a;
	}
	startAnimation(e, t) {
		let { drag: n, dragMomentum: r, dragElastic: i, dragTransition: a, dragSnapToOrigin: o, onDragTransitionEnd: s } = this.getProps(), c = {
			bounceStiffness: i ? 200 : 1e6,
			bounceDamping: i ? 40 : 1e7,
			timeConstant: 750,
			restDelta: 1,
			restSpeed: 10,
			...a
		}, l = (i) => r && !(this.point && o) && nu(i, t || n, this.currentDirection) ? e[i] : 0;
		if (this.point && !o) return this.point.release({
			x: l("x"),
			y: l("y")
		}, c).then(s);
		let u = this.constraints || {}, d = Q((e) => {
			if (!nu(e, t || n, this.currentDirection)) return;
			let r = u[e] || {};
			(o === !0 || o === e) && (r = {
				min: 0,
				max: 0
			});
			let i = {
				type: "inertia",
				velocity: l(e),
				...c,
				...r
			};
			return this.startAxisValueAnimation(e, i);
		});
		return Promise.all(d).then(s);
	}
	startAxisValueAnimation(e, t) {
		let n = this.getAxisMotionValue(e);
		return Sa(this.visualElement, e), n.start(sa(e, n, 0, t, this.visualElement, !1));
	}
	stopAnimation() {
		Q((e) => this.getAxisMotionValue(e).stop());
	}
	getAxisMotionValue(e) {
		let t = `_drag${e.toUpperCase()}`;
		return this.readProps()[t] || this.visualElement.getValue(e, this.visualElement.latestValues[e] ?? 0);
	}
	snapToCursor({ clientX: e, clientY: t }) {
		let { drag: n } = this.getProps(), r = {
			x: e,
			y: t
		}, i = this.visualElement.getTransformPagePoint()?.(r) || r, a = this.visualElement.measureViewportBox();
		Q((e) => {
			if (!nu(e, n, this.currentDirection)) return;
			let t = this.getAxisMotionValue(e), { min: r, max: o } = a[e];
			t.set((t.get() || 0) + i[e] - R(r, o, .5));
		});
	}
	scalePositionWithinConstraints() {
		if (!this.visualElement.current) return;
		let { drag: e, dragConstraints: t } = this.getProps(), { projection: n } = this.visualElement;
		if (!Ql(t) || !n || !this.constraints) return;
		this.stopAnimation();
		let r = this.constraints, i = {
			x: 0,
			y: 0
		};
		Q((e) => {
			let t = this.getAxisMotionValue(e).get();
			i[e] = Ul({
				min: t,
				max: t
			}, r[e]);
		});
		let { transformTemplate: a } = this.visualElement.getProps();
		this.visualElement.current.style.transform = a ? a({}, "") : "none", n.root?.updateScroll(), n.updateLayout(), this.constraints = !1, this.resolveConstraints(), Q((t) => {
			let n = this.getAxisMotionValue(t);
			if (!nu(t, e, null) || !n.get()) return;
			let { min: r, max: a } = this.constraints[t];
			n.set(R(r, a, i[t]));
		}), this.visualElement.render();
	}
	addListeners() {
		if (!this.visualElement.current) return;
		Xl.set(this.visualElement, this);
		let e = this.visualElement.current, t = ol(e, "pointerdown", (t) => {
			let { drag: n, dragListener: r = !0 } = this.getProps(), i = t.target, a = i !== e && Fl(i);
			n && r && !a && this.start(t);
		}), n, r = () => {
			let { dragConstraints: t } = this.getProps(), r = Ql(t) && $l(t);
			r && (this.constraints = this.resolveRefConstraints(), n ||= tu(e, r, () => this.scalePositionWithinConstraints()));
		}, { projection: i } = this.visualElement, a = i.addEventListener("measure", r);
		i.layout || (i.root?.updateScroll(), i.updateLayout()), z.read(r);
		let o = Ac(window, "resize", () => this.scalePositionWithinConstraints()), s = i.addEventListener("didUpdate", (({ delta: e, hasLayoutChanged: t }) => {
			this.isDragging && t && (Q((t) => {
				if (!nu(t, this.getProps().drag, this.currentDirection)) return;
				let n = this.getAxisMotionValue(t);
				this.originPoint[t] += e[t].translate, n.set(n.get() + e[t].translate);
			}), this.visualElement.render());
		}));
		return () => {
			o(), t(), a(), s(), n?.();
		};
	}
	getProps() {
		let e = this.readProps(), { dragElastic: t = Gl, dragMomentum: n = !0 } = e;
		return {
			...e,
			dragElastic: t,
			dragMomentum: n
		};
	}
};
function Ql(e) {
	return !!e && typeof e == "object" && ("current" in e || "nodeType" in e);
}
var $l = (e) => "current" in e ? e.current : e;
function eu(e) {
	let t = !0;
	return () => {
		t ? t = !1 : e();
	};
}
function tu(e, t, n) {
	let r = bl(e, eu(n)), i = bl(t, eu(n));
	return () => {
		r(), i();
	};
}
function nu(e, t, n) {
	return (t === !0 || t === e) && (n === null || n === e);
}
function ru(e, t = 10) {
	let n = null;
	return Math.abs(e.y) > t ? n = "y" : Math.abs(e.x) > t && (n = "x"), n;
}
// node_modules/motion-dom/dist/es/gestures/utils/setup.mjs
function iu(e, t) {
	let n = Xa(e), r = new AbortController();
	return [
		n,
		{
			passive: !0,
			...t,
			signal: r.signal
		},
		Ja(() => r.abort())
	];
}
// node_modules/motion-dom/dist/es/gestures/hover.mjs
function au(e) {
	return !(e.pointerType === "touch" || Il());
}
function ou(e, t, n = {}) {
	t = Ya(t);
	let [r, i, a] = iu(e, n);
	return r.forEach((e) => {
		let n = !1, r = !1, a, o = () => {
			e.removeEventListener("pointerleave", u);
		}, s = (e) => {
			a &&= (a(e), void 0), o();
		}, c = (e) => {
			n = !1, window.removeEventListener("pointerup", c), window.removeEventListener("pointercancel", c), r && (r = !1, s(e));
		}, l = () => {
			n = !0, window.addEventListener("pointerup", c, i), window.addEventListener("pointercancel", c, i);
		}, u = (e) => {
			e.pointerType !== "touch" && (n ? r = !0 : s(e));
		};
		e.addEventListener("pointerenter", (n) => {
			if (!au(n)) return;
			r = !1;
			let o = t(e, n);
			typeof o == "function" && (a = o, e.addEventListener("pointerleave", u, i));
		}, i), e.addEventListener("pointerdown", l, i);
	}), a;
}
// node_modules/motion-dom/dist/es/gestures/utils/is-node-or-child.mjs
var su = (e, t) => t ? e === t || su(e, t.parentElement) : !1, cu = /* @__PURE__ */ new WeakSet();
// node_modules/motion-dom/dist/es/gestures/press/utils/keyboard.mjs
function lu(e) {
	return (t) => {
		t.key === "Enter" && e(t);
	};
}
function uu(e, t) {
	e.dispatchEvent(new PointerEvent("pointer" + t, {
		isPrimary: !0,
		bubbles: !0
	}));
}
var du = (e, t) => {
	let n = !1, r = lu(() => {
		n || cu.has(e) || (n = !0, uu(e, "down"));
	}), i = lu(() => {
		n && (n = !1, uu(e, "up"));
	});
	e.addEventListener("keydown", r, t), e.addEventListener("keyup", i, t), e.addEventListener("blur", () => {
		e.removeEventListener("keydown", r), e.removeEventListener("keyup", i), n && uu(e, "cancel");
	}, {
		...t,
		once: !0
	});
};
// node_modules/motion-dom/dist/es/gestures/press/index.mjs
function fu(e) {
	return rl(e) && !Il();
}
var pu = /* @__PURE__ */ new WeakSet(), mu = 100, hu = 8, gu = (e, t, n) => Math.hypot(e.clientX - t.clientX, e.clientY - t.clientY) > n, _u = (e) => e.preventDefault();
function vu(e, t, n = {}) {
	t = Ya(t);
	let [r, i, a] = iu(e, n), o = /* @__PURE__ */ new WeakMap(), s = (e) => {
		let r = e.currentTarget;
		if (!fu(e) || pu.has(e)) return;
		n.stopPropagation && pu.add(e);
		let { count: a = 1, countTimeout: s = .3, hold: c = 0, repeat: l } = n, u = N.now(), d = /* @__PURE__ */ A(c), f = /* @__PURE__ */ A(s), p = o.get(r);
		p?.expire(gu(p.event, e, mu)) ? p = void 0 : p && (B(p.expire), o.delete(r));
		let m = p ? p.count + 1 : 1, h = m >= a, g = h && (c || l), _ = !c, v = 0, y;
		if (cu.add(r), p) y = p.handlers;
		else {
			let n = t(r, e);
			y = typeof n == "function" ? { onComplete: n } : n || {};
		}
		h && _ && y.onActive?.();
		let b = /* @__PURE__ */ A(l), x = d || b, S = u + x, C = !0, w = () => {
			if (i.signal.aborted) return B(w);
			let e = Math.min(1 - (S - N.now()) / x, 1);
			C && e < 1 && (e = 0), C = !1, y.onHold?.(e), !(e < 1) && (_ ? y.onRepeat?.(++v) : (_ = !0, y.onActive?.()), l ? (C = !0, S += x = b) : B(w));
		}, T = {
			...i,
			capture: !0
		}, E = (t, n) => {
			if (rl(t)) {
				if (window.removeEventListener("pointerup", D, T), window.removeEventListener("pointercancel", O, T), window.removeEventListener("pointermove", ee, T), r.removeEventListener("contextmenu", _u), B(w), cu.delete(r), Il() && (n = !1), n && !h) {
					let n = N.now(), a = (e) => {
						let s = i.signal.aborted;
						if (s || e === !0 || N.now() - n > f) return B(a), o.delete(r), s || y.onComplete?.(t, { success: !1 }), !0;
					};
					o.set(r, {
						count: m,
						event: e,
						handlers: y,
						expire: a
					}), z.update(a, !0);
				} else y.onComplete?.(t, { success: n && _ });
			}
		}, D = (e) => {
			E(e, r === window || r === document || n.useGlobalTarget || su(r, e.target));
		}, O = (e) => {
			E(e, !1);
		}, ee = (t) => {
			rl(t) && ((l || !_) && gu(e, t, hu) || a > 1 && Il()) && O(t);
		};
		window.addEventListener("pointerup", D, T), window.addEventListener("pointercancel", O, T), (g || a > 1) && window.addEventListener("pointermove", ee, T), g && (z.update(w, !0), r.addEventListener("contextmenu", _u, {
			...i,
			passive: !1
		}));
	};
	return r.forEach((e) => {
		(n.useGlobalTarget ? window : e).addEventListener("pointerdown", s, i), Ka(e) && (e.addEventListener("focus", () => du(e, i), i), !Nl(e) && !e.hasAttribute("tabindex") && (e.tabIndex = 0));
	}), a;
}
// node_modules/motion-dom/dist/es/utils/transform.mjs
function yu(...e) {
	let t = !Array.isArray(e[0]), n = t ? 0 : -1, r = e[0 + n], i = e[1 + n], a = e[2 + n], o = e[3 + n], s = Tn(i, a, o);
	return t ? s(r) : s;
}
// node_modules/motion-dom/dist/es/render/Feature.mjs
var bu = class {
	constructor(e) {
		this.isMounted = !1, this.node = e;
	}
	update() {}
}, xu = /* @__PURE__ */ new Set([
	"baseFrequency",
	"diffuseConstant",
	"kernelMatrix",
	"kernelUnitLength",
	"keySplines",
	"keyTimes",
	"limitingConeAngle",
	"markerHeight",
	"markerWidth",
	"numOctaves",
	"targetX",
	"targetY",
	"surfaceScale",
	"specularConstant",
	"specularExponent",
	"stdDeviation",
	"tableValues",
	"viewBox",
	"gradientTransform",
	"pathLength",
	"startOffset",
	"textLength",
	"lengthAdjust"
]), Su = (e) => typeof e == "string" && e.toLowerCase() === "svg";
// node_modules/motion-dom/dist/es/render/svg/utils/render.mjs
function Cu(e, t, n, r) {
	Qc(e, t, void 0, r);
	for (let n in t.attrs) e.setAttribute(xu.has(n) ? n : oo(n), t.attrs[n]);
}
// node_modules/motion-dom/dist/es/render/svg/utils/scrape-motion-values.mjs
function wu(e, t, n) {
	let r = el(e, t, n);
	for (let n in e) if (n !== "children" && (K(e[n]) || K(t[n]))) {
		let t = U.indexOf(n) === -1 ? n : "attr" + n.charAt(0).toUpperCase() + n.substring(1);
		r[t] = e[n];
	}
	return r;
}
// node_modules/motion-dom/dist/es/render/svg/SVGVisualElement.mjs
var Tu = class extends Zc {
	constructor() {
		super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = Z;
	}
	getBaseTargetFromProps(e, t) {
		return W.has(t) ? super.getBaseTargetFromProps(e, t) ?? mr(t) : e[t];
	}
	getDefaultValue(e) {
		return W.has(e) ? this.latestValues[e] ?? mr(e) : void 0;
	}
	readValueFromInstance(e, t) {
		if (W.has(t)) {
			let e = $n(t);
			return e && e.default || 0;
		}
		if (fo.includes(t)) {
			let n = getComputedStyle(e)[t];
			if (typeof n == "string" && n) return n.trim();
		}
		return t = xu.has(t) ? t : oo(t), e.getAttribute(t);
	}
	scrapeMotionValuesFromProps(e, t, n) {
		return wu(e, t, n);
	}
	build(e, t, n) {
		po(e, t, this.isSVGTag, n.transformTemplate, n.style);
	}
	renderInstance(e, t, n, r) {
		Cu(e, t, n, r);
	}
	mount(e) {
		this.isSVGTag = Su(e.tagName), super.mount(e);
	}
};
// node_modules/motion-dom/dist/es/render/utils/shallow-compare.mjs
function Eu(e, t) {
	if (!Array.isArray(t)) return !1;
	let n = t.length;
	if (n !== e.length) return !1;
	for (let r = 0; r < n; r++) if (t[r] !== e[r]) return !1;
	return !0;
}
// node_modules/motion-dom/dist/es/render/utils/animation-state.mjs
var Du = [...Lc].reverse(), Ou = (e) => e?.out === !0 ? e : e?.out;
function ku(e) {
	let t = (t) => Promise.all(t.map(({ animation: t, options: n }) => ka(e, t, n))), n = ju(), r = !0, i = !1;
	function a(a) {
		let { props: o, parent: s, manuallyAnimateOnMount: c } = e, { initial: l } = o, u = r || i, d = [], f = (t = l) => typeof t != "boolean" && ma(e, Array.isArray(t) ? t[0] : t, e.presenceContext?.custom) || void 0, p = /* @__PURE__ */ new Map(), m = {}, h = Infinity, g = e;
		do
			g = g.props.inherit !== !1 && g.parent;
		while (g && !g.isControllingVariants);
		let _ = u && Ou(f(l ?? (g && g.props.initial))?.transition);
		if (Du.forEach((t, r) => {
			let i = n[t], l = o[t], f = g && g.props[t], v = l === void 0 ? Ic(f) || f === !1 ? f : void 0 : l, y = Ic(v), b = t === a ? i.isActive : null, x = y && l === void 0 && !(u && c);
			if (i.protectedKeys = { ...m }, !i.isActive && b === null || !v && !i.prevProp || Fc(v) || typeof v == "boolean") return;
			if (b === !1 && (h = r), t === "exit" && i.isActive && b !== !0) {
				m = {
					...m,
					...i.prevResolvedValues
				};
				return;
			}
			let S = Au(i.prevProp, v), C = S || y && (b && !x || r > h), w = !1, T = Array.isArray(v) ? v : [v], E = {}, D;
			if (b !== !1) for (let n of T) {
				let { transition: r, transitionEnd: i, ...a } = ma(e, n, ha(e, t)) || {};
				E = {
					...E,
					...a,
					...i
				}, D = Ou(r) || D;
			}
			let { prevResolvedValues: O } = i;
			for (let t in {
				...O,
				...E
			}) {
				if (t in m) continue;
				let n = E[t], r = O[t], a = Array.isArray(n) && Array.isArray(r) ? !Eu(n, r) || S : n !== r, o;
				if (a && n == null) p.has(t) || p.set(t, i.prevOut);
				else if (a || n !== void 0 && p.has(t)) {
					C = !0, o = p.get(t) || _, p.delete(t) && (w = !0), i.needsAnimating[t] = !0;
					let n = e.getValue(t);
					n && (n.liveStyle = !1);
				} else i.protectedKeys[t] = !0;
				i.out[t] = o;
			}
			if (i.prevProp = v, i.prevResolvedValues = E, i.prevOut = D, i.isActive && (m = {
				...m,
				...E
			}), C && (!(x && S) || w)) for (let n of T) {
				let r = { type: t };
				if (typeof n == "string" && u && c && s?.enteringChildren) {
					let t = ma(s, n)?.transition?.delayChildren;
					r.delay = qi(s.enteringChildren, e, t);
				}
				d.push({
					animation: n,
					options: r
				});
			}
		}), p.size) {
			let t = {}, n = f(), r = n?.transition;
			p.forEach((i, a) => {
				i && (r = {
					...r || e.getDefaultTransition(),
					[a]: i
				});
				let s = e.getValue(a);
				s && (s.liveStyle = !0);
				let c = n && !Array.isArray(l) ? n[a] : void 0, u = e.getBaseTargetFromProps(o, a);
				t[a] = (c === void 0 ? u !== void 0 && !K(u) ? u : e.initialValues[a] === void 0 ? e.baseTarget[a] : void 0 : c) ?? null, process.env.NODE_ENV !== "production" && t[a] === null && e.initialValues[a] !== void 0 && (delete e.initialValues[a], s?.stop(), e.baseTarget[a] = s?.get());
			}), r && (t.transition = r), d.push({ animation: t });
		}
		let v = u && e.blockInitialAnimation || r && !c && (o.initial === !1 || o.initial === o.animate);
		return r = i = !1, !v && d.length ? t(d) : Promise.resolve();
	}
	function o(t, r) {
		if (n[t].isActive === r) return Promise.resolve();
		e.variantChildren?.forEach((e) => e.animationState?.setActive(t, r)), n[t].isActive = r;
		let i = a(t);
		for (let e in n) n[e].protectedKeys = {};
		return i;
	}
	return {
		animateChanges: a,
		setActive: o,
		setAnimateFunction: (n) => {
			t = n(e);
		},
		getState: () => n,
		reset: () => {
			n = ju(), i = !0;
		}
	};
}
function Au(e, t) {
	return typeof t == "string" ? t !== e : Array.isArray(t) ? !Eu(t, e) : !1;
}
function ju() {
	let e = {};
	for (let t of Lc) e[t] = {
		isActive: t === "animate",
		protectedKeys: {},
		needsAnimating: {},
		prevResolvedValues: {},
		out: {}
	};
	return e;
}
// node_modules/framer-motion/dist/es/context/MotionConfigContext.mjs
var Mu = /* @__PURE__ */ n({
	transformPagePoint: (e) => e,
	isStatic: !1,
	reducedMotion: "never"
});
// node_modules/framer-motion/dist/es/components/AnimatePresence/use-presence.mjs
function Nu(e = !0) {
	let t = o(y);
	if (t === null) return [!0, null];
	let { isPresent: n, onExitComplete: r, register: i } = t, l = c();
	s(() => {
		if (e) return i(l);
	}, [e]);
	let u = a(() => e && r && r(l), [
		l,
		r,
		e
	]);
	return !n && r ? [!1, u] : [!0];
}
// node_modules/framer-motion/dist/es/context/LazyContext.mjs
var Pu = /* @__PURE__ */ n({ strict: !1 }), Fu = {
	animation: ["variants", ...Lc],
	exit: ["exit"],
	drag: ["drag", "dragControls"],
	focus: ["whileFocus"],
	hover: [
		"whileHover",
		"onHoverStart",
		"onHoverEnd"
	],
	tap: [
		"whileTap",
		"onTap",
		"onTapStart",
		"onTapCancel"
	],
	pan: [
		"onPan",
		"onPanStart",
		"onPanSessionStart",
		"onPanEnd"
	],
	inView: [
		"whileInView",
		"onViewportEnter",
		"onViewportLeave"
	],
	layout: ["layout", "layoutId"]
}, Iu = !1;
function Lu() {
	if (Iu) return;
	let e = {};
	for (let t in Fu) e[t] = { isEnabled: (e) => Fu[t].some((t) => !!e[t]) };
	Jc(e), Iu = !0;
}
function Ru() {
	return Lu(), Yc();
}
// node_modules/framer-motion/dist/es/motion/features/load-features.mjs
function zu(e) {
	let t = Ru();
	for (let n in e) t[n] = {
		...t[n],
		...e[n]
	};
	Jc(t);
}
// node_modules/framer-motion/dist/es/context/MotionContext/index.mjs
var Bu = /* @__PURE__ */ n({});
// node_modules/framer-motion/dist/es/context/MotionContext/utils.mjs
function Vu(e, t) {
	if (zc(e)) {
		let { initial: t, animate: n } = e;
		return {
			initial: t === !1 || Ic(t) ? t : void 0,
			animate: Ic(n) ? n : void 0
		};
	}
	return e.inherit === !1 ? {} : t;
}
// node_modules/framer-motion/dist/es/context/MotionContext/create.mjs
function Hu(e) {
	let { initial: t, animate: n } = Vu(e, o(Bu));
	return d(() => ({
		initial: t,
		animate: n
	}), [Uu(t), Uu(n)]);
}
function Uu(e) {
	return Array.isArray(e) ? e.join(" ") : e;
}
// node_modules/framer-motion/dist/es/render/html/utils/create-render-state.mjs
var Wu = () => ({
	style: {},
	transform: {},
	transformOrigin: {},
	vars: {}
});
// node_modules/framer-motion/dist/es/render/html/use-props.mjs
function Gu(e, t, n) {
	for (let r in t) !K(t[r]) && !$c(r, n) && (e[r] = t[r]);
}
function Ku({ transformTemplate: e }, t) {
	return d(() => {
		let n = Wu();
		return so(n, t, e), Object.assign({}, n.vars, n.style);
	}, [t]);
}
function qu(e, t) {
	let n = e.style || {}, r = {};
	return Gu(r, n, e), Object.assign(r, Ku(e, t)), r;
}
function Ju(e, t) {
	let n = {}, r = qu(e, t);
	return e.drag && e.dragListener !== !1 && (n.draggable = !1, r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none", r.touchAction = e.drag === !0 ? "none" : `pan-${e.drag === "x" ? "y" : "x"}`), e.tabIndex === void 0 && (e.onTap || e.onTapStart || e.whileTap) && (n.tabIndex = 0), n.style = r, n;
}
// node_modules/framer-motion/dist/es/render/svg/utils/create-render-state.mjs
var Yu = () => ({
	...Wu(),
	attrs: {}
});
// node_modules/framer-motion/dist/es/render/svg/use-props.mjs
function Xu(e, t, n, r) {
	let i = d(() => {
		let n = Yu();
		return po(n, t, Su(r), e.transformTemplate, e.style), {
			...n.attrs,
			style: { ...n.style }
		};
	}, [t]);
	if (e.style) {
		let t = {};
		return Gu(t, e.style, e), {
			...i,
			style: {
				...t,
				...i.style
			}
		};
	}
	return i;
}
// node_modules/framer-motion/dist/es/motion/utils/valid-prop.mjs
var Zu = /* @__PURE__ */ new Set(/* @__PURE__ */ "animate.exit.variants.initial.style.values.transition.transformTemplate.custom.inherit.onBeforeLayoutMeasure.onAnimationStart.onAnimationComplete.onUpdate.onDragStart.onDrag.onDragEnd.onMeasureDragConstraints.onDirectionLock.onDragTransitionEnd._dragX._dragY.onHoverStart.onHoverEnd.onViewportEnter.onViewportLeave.globalTapTarget.tap.propagate.ignoreStrict.viewport.pinch".split("."));
function Qu(e) {
	return e.startsWith("while") || e.startsWith("drag") && e !== "draggable" || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || e.startsWith("onLayout") || Zu.has(e);
}
// node_modules/framer-motion/dist/es/render/dom/utils/filter-props.mjs
function $u(e, t) {
	return e.startsWith("on") ? !Qu(e) : t?.(e) ?? !Qu(e);
}
function ed(e, t, n, r) {
	let i = {};
	for (let a in e) a === "values" && typeof e.values == "object" || K(e[a]) || ($u(a, r) || n === !0 && Qu(a) || !t && !Qu(a) || e.draggable && a.startsWith("onDrag")) && (i[a] = e[a]);
	return i;
}
// node_modules/framer-motion/dist/es/render/svg/lowercase-elements.mjs
var td = [
	"animate",
	"circle",
	"defs",
	"desc",
	"ellipse",
	"g",
	"image",
	"line",
	"filter",
	"marker",
	"mask",
	"metadata",
	"path",
	"pattern",
	"polygon",
	"polyline",
	"rect",
	"stop",
	"switch",
	"symbol",
	"svg",
	"text",
	"tspan",
	"use",
	"view"
];
// node_modules/framer-motion/dist/es/render/dom/utils/is-svg-component.mjs
function nd(e) {
	return typeof e != "string" || e.includes("-") ? !1 : !!(td.indexOf(e) > -1 || /[A-Z]/u.test(e));
}
// node_modules/framer-motion/dist/es/render/dom/use-render.mjs
function rd(e, n, i, { latestValues: a }, o, s = !1, c, l) {
	let u = (c ?? nd(e) ? Xu : Ju)(n, a, o, e), f = ed(n, typeof e == "string", s, l), p = e === t ? {} : {
		...f,
		...u,
		ref: i
	}, { children: m } = n, h = d(() => K(m) ? m.get() : m, [m]);
	return r(e, {
		...p,
		children: h
	});
}
// node_modules/framer-motion/dist/es/motion/utils/use-visual-state.mjs
function id({ scrapeMotionValuesFromProps: e, createRenderState: t }, n, r, i) {
	return {
		latestValues: ad(n, r, i, e),
		renderState: t()
	};
}
function ad(e, t, n, r) {
	let i = {}, a = r(e, {});
	for (let e in a) i[e] = ts(a[e]);
	let { initial: o, animate: s } = e, c = zc(e), l = Bc(e);
	t && l && !c && e.inherit !== !1 && (o === void 0 && (o = t.initial), s === void 0 && (s = t.animate));
	let u = n ? n.initial === !1 : !1;
	u ||= o === !1;
	let d = u ? s : o;
	if (d && typeof d != "boolean" && !Fc(d)) {
		let t = Array.isArray(d) ? d : [d];
		for (let n = 0; n < t.length; n++) {
			let r = pa(e, t[n]);
			if (r) {
				let { transitionEnd: e, transition: t, ...n } = r;
				for (let e in n) {
					let t = n[e];
					if (Array.isArray(t)) {
						let e = u ? t.length - 1 : 0;
						t = t[e];
					}
					t !== null && (i[e] = t);
				}
				for (let t in e) i[t] = e[t];
			}
		}
	}
	return i;
}
var od = (e) => (t, n) => {
	let r = o(Bu), i = o(y), a = () => id(e, t, r, i);
	return n ? a() : _(a);
}, sd = /*@__PURE__*/ od({
	scrapeMotionValuesFromProps: el,
	createRenderState: Wu
}), cd = /*@__PURE__*/ od({
	scrapeMotionValuesFromProps: wu,
	createRenderState: Yu
}), ld = /* @__PURE__ */ Symbol.for("motionComponentSymbol");
// node_modules/framer-motion/dist/es/motion/utils/use-motion-ref.mjs
function ud(e, t, n) {
	let r = f(n);
	l(() => {
		r.current = n;
	});
	let i = f(null);
	return a((n) => {
		n && e.onMount?.(n), t && (n ? t.mount(n) : t.unmount());
		let a = r.current;
		if (typeof a == "function") {
			if (n) {
				let e = a(n);
				typeof e == "function" && (i.current = e);
			} else i.current ? (i.current(), i.current = null) : a(n);
		} else a && (a.current = n);
	}, [t]);
}
// node_modules/framer-motion/dist/es/context/SwitchLayoutGroupContext.mjs
var dd = /* @__PURE__ */ n({});
// node_modules/framer-motion/dist/es/motion/utils/use-visual-element.mjs
function fd(e, t, n, r, i, a) {
	let { visualElement: c } = o(Bu), u = o(Pu), d = o(y), p = o(Mu), m = p.reducedMotion, h = p.skipAnimations, g = f(null), _ = f(!1);
	r ||= u.renderer, !g.current && r && (g.current = r(e, {
		visualState: t,
		parent: c,
		props: n,
		presenceContext: d,
		blockInitialAnimation: d ? d.initial === !1 : !1,
		reducedMotionConfig: m,
		skipAnimations: h,
		isSVG: a
	}), _.current && g.current && (g.current.manuallyAnimateOnMount = !0));
	let b = g.current, x = o(dd);
	b && !b.projection && i && (b.type === "html" || b.type === "svg") && i.create(b, n, x), l(() => {
		b && b.props !== n && b.update(n, d);
	});
	let S = n[Ca], C = f(!!S && typeof window < "u" && !window.MotionHandoffIsComplete?.(S) && window.MotionHasOptimisedAnimation?.(S));
	return v(() => {
		_.current && b && (b.animationState?.animateChanges(), b.enteringChildren = void 0);
	}, []), v(() => {
		_.current = !0, b && (window.MotionIsMounted = !0, b.updateFeatures(), b.scheduleRenderMicrotask(), C.current && b.animationState && b.animationState.animateChanges());
	}), s(() => {
		b && (!C.current && b.animationState && b.animationState.animateChanges(), C.current &&= (queueMicrotask(() => {
			window.MotionHandoffMarkAsComplete?.(S);
		}), !1), b.enteringChildren = void 0);
	}), b;
}
// node_modules/framer-motion/dist/es/motion/index.mjs
function pd(e, { forwardMotionProps: t = !1, type: n } = {}, r, a) {
	r && zu(r);
	let s = n ? n === "svg" : nd(e), c = s ? cd : sd;
	function l(n, i) {
		let l, u = md(n);
		_(() => !!Mc.current?.sharedNodes.get(u)?.lead && n.initial) && (n = {
			...n,
			initial: !1
		});
		let d = {
			...o(Mu),
			...n,
			layoutId: u
		}, { isStatic: f, isValidProp: p } = d, g = Hu(n), v = c(n, f);
		if (!f && typeof window < "u") {
			hd(d, r);
			let t = gd(d);
			g.visualElement = fd(e, v, d, a, t.ProjectionNode, s), (t.isEnabled || g.visualElement?.projection?.options.layoutId) && (l = t.MeasureLayout);
		}
		return h(Bu.Provider, {
			value: g,
			children: [l && g.visualElement ? m(l, {
				visualElement: g.visualElement,
				...d
			}) : null, rd(e, n, ud(v, g.visualElement, i), v, f, t, s, p)]
		});
	}
	l.displayName = `motion.${typeof e == "string" ? e : `create(${e.displayName ?? e.name ?? ""})`}`;
	let u = i(l);
	return u[ld] = e, u;
}
function md({ layoutId: e }) {
	let t = o(g).id;
	return t && e !== void 0 ? t + "-" + e : e;
}
function hd(e, t) {
	let n = o(Pu).strict;
	if (process.env.NODE_ENV !== "production" && t && n) {
		let t = "You have rendered a `motion` component within a `LazyMotion` component. This will break tree shaking. Import and render a `m` component instead";
		e.ignoreStrict ? se(!1, t + ". For Reorder, import it from \"motion/react-m\"", "lazy-strict-mode") : T(!1, t, "lazy-strict-mode");
	}
}
function gd(e) {
	let { drag: t, layout: n } = Ru();
	if (!t && !n) return {};
	let r = {
		...t,
		...n
	};
	return {
		MeasureLayout: r.MeasureLayout,
		isEnabled: t?.isEnabled(e) || n?.isEnabled(e),
		ProjectionNode: r.ProjectionNode
	};
}
// node_modules/framer-motion/dist/es/render/components/create-proxy.mjs
function _d(e, t) {
	if (typeof Proxy > "u") return pd;
	let n = /* @__PURE__ */ new Map(), r = (n, r) => pd(n, r, e, t);
	return new Proxy((e, t) => (process.env.NODE_ENV !== "production" && se(!1, "motion() is deprecated. Use motion.create() instead."), r(e, t)), { get: (i, a) => a === "create" ? r : (n.has(a) || n.set(a, pd(a, void 0, e, t)), n.get(a)) });
}
// node_modules/framer-motion/dist/es/render/dom/create-visual-element.mjs
var vd = (e, n) => n.isSVG ?? nd(e) ? new Tu(n) : new nl(n, { allowProjection: e !== t }), yd = class extends bu {
	constructor(e) {
		super(e), e.animationState ||= ku(e);
	}
	updateAnimationControlsSubscription() {
		let { animate: e } = this.node.getProps();
		Fc(e) && (this.unmountControls = e.subscribe(this.node));
	}
	mount() {
		this.updateAnimationControlsSubscription();
	}
	update() {
		this.node.getProps().animate !== this.node.prevProps?.animate && this.updateAnimationControlsSubscription();
	}
	unmount() {
		this.node.animationState.reset(), this.unmountControls?.();
	}
}, bd = 0, xd = {
	animation: { Feature: yd },
	exit: { Feature: class extends bu {
		constructor() {
			super(...arguments), this.id = bd++;
		}
		update() {
			let { presenceContext: e, animationState: t } = this.node;
			if (!e || !t) return;
			let { isPresent: n, onExitComplete: r } = e;
			if (n === !this.exit) return;
			if (n) {
				if (this.exit === !0) {
					let { initial: e } = this.node.getProps();
					if (e && !Array.isArray(e)) {
						let { transition: t, transitionEnd: n, ...r } = ma(this.node, e) || {};
						for (let e in r) this.node.getValue(e)?.jump(r[e]);
					}
					this.node.blockInitialAnimation = !1, t.reset(), t.animateChanges();
				} else t.setActive("exit", !1);
				this.exit = void 0;
				return;
			}
			let i = this.exit = t.setActive("exit", !0);
			r && i.then(() => {
				this.exit === i && (this.exit = !0, r(this.id));
			});
		}
		mount() {
			let { register: e } = this.node.presenceContext || {};
			e && (this.unmount = e(this.id, this.node)), this.update();
		}
		unmount() {}
	} }
}, Sd = class extends bu {
	constructor(e) {
		super(e), this.removeGroupControls = k, this.removeListeners = k, this.controls = new Zl(e);
	}
	mount() {
		let { dragControls: e } = this.node.getProps();
		e && (this.removeGroupControls = e.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || k;
	}
	update() {
		let { dragControls: e, drag: t } = this.node.getProps(), { dragControls: n, drag: r } = this.node.prevProps || {};
		e !== n && (this.removeGroupControls(), e && (this.removeGroupControls = e.subscribe(this.controls))), r && !t && this.controls.stop(void 0, void 0, r);
	}
	unmount() {
		this.removeGroupControls(), this.removeListeners(), this.controls.isDragging || this.controls.endPanSession();
	}
}, Cd = (e) => (t, n) => {
	e && z.update(() => e(t, n), !1, !0);
}, wd = class extends bu {
	constructor() {
		super(...arguments), this.removePointerDownListener = k;
	}
	onPointerDown(e) {
		this.session = new wl(e, this.createPanHandlers(), {
			transformPagePoint: this.node.getTransformPagePoint(),
			contextWindow: this.node.current?.ownerDocument.defaultView
		});
	}
	createPanHandlers() {
		let { onPanSessionStart: e, onPanStart: t, onPan: n, onPanEnd: r } = this.node.getProps();
		return {
			onSessionStart: Cd(e),
			onStart: Cd(t),
			onMove: Cd(n),
			onEnd: (e, t) => {
				delete this.session, r && z.postRender(() => r(e, t));
			}
		};
	}
	mount() {
		this.removePointerDownListener = ol(this.node.current, "pointerdown", (e) => this.onPointerDown(e));
	}
	update() {
		this.session?.updateHandlers(this.createPanHandlers());
	}
	unmount() {
		this.removePointerDownListener(), this.session?.end();
	}
}, Td = !1, Ed = ({ layout: e, layoutDependency: t, layoutAnchor: n }) => ({
	layout: e,
	layoutDependency: t,
	layoutAnchor: n,
	animationType: typeof e == "string" ? e : "both"
}), Dd = (e, t) => {
	let { snapshot: n } = e, r = e.getStack();
	r?.remove(e);
	let i = r?.lead;
	if (r?.prevLead === e && i.resumeFrom === e && (i.resumeFrom = i.currentAnimation = e.resumingFrom = void 0), e.options.layoutId = t, !t) e.needsShow = !0;
	else return e.root.registerSharedNode(t, e), () => {
		let { resumeFrom: t } = e;
		t?.isPresent !== !1 && e.getStack().members.includes(t) && (t.hide(), e.resumeFrom = void 0, e.snapshot = n);
	};
}, Od = class extends e {
	componentDidMount() {
		let { visualElement: e, layoutGroup: t, switchLayoutGroup: n, layoutId: r } = this.props, { projection: i } = e;
		i && (t.group?.add(i), r && n?.register?.(i), Td && i.root.didUpdate(), i.options.layoutId !== r && Dd(i, r)?.(), i.addEventListener("animationComplete", () => this.safeToRemove()), i.setOptions({
			...i.options,
			...Ed(this.props),
			onExitComplete: () => this.safeToRemove()
		})), Zs.hasEverUpdated = !0;
	}
	getSnapshotBeforeUpdate(e) {
		let { layoutDependency: t, layoutId: n, visualElement: r, drag: i, isPresent: a } = this.props, { projection: o } = r;
		return o && (o.isPresent = a, this.takeOver = e.layoutId === n ? void 0 : (o.willUpdate(), Dd(o, n)), o.setOptions({
			...o.options,
			...Ed(this.props)
		}), Td = !0, i || e.layoutDependency !== t || t === void 0 || e.isPresent !== a ? o.willUpdate() : this.safeToRemove(), e.isPresent !== a && (a ? o.promote() : o.relegate() || z.postRender(() => {
			o.getStack()?.members.length || this.safeToRemove();
		}))), null;
	}
	componentDidUpdate() {
		let { projection: e } = this.props.visualElement;
		e && (this.takeOver?.(), e.root.didUpdate(), qo.postRender(() => {
			!e.currentAnimation && e.isLead() && this.safeToRemove();
		}));
	}
	componentWillUnmount() {
		let { visualElement: e, layoutGroup: t, switchLayoutGroup: n } = this.props, { projection: r } = e;
		Td = !0, r && (r.scheduleCheckAfterUnmount(), t.group?.remove(r), n?.deregister?.(r));
	}
	safeToRemove() {
		this.props.safeToRemove?.();
	}
	render() {
		return null;
	}
};
function kd(e) {
	let [t, n] = Nu(), r = o(g);
	return m(Od, {
		...e,
		layoutGroup: r,
		switchLayoutGroup: o(dd),
		isPresent: t,
		safeToRemove: n
	});
}
// node_modules/framer-motion/dist/es/motion/features/drag.mjs
var Ad = {
	pan: { Feature: wd },
	drag: {
		Feature: Sd,
		ProjectionNode: Nc,
		MeasureLayout: kd
	}
};
// node_modules/framer-motion/dist/es/gestures/hover.mjs
function jd(e, t, n, r, i) {
	let { props: a } = e, o = "while" + n;
	!i && e.animationState && a[o] && e.animationState.setActive(o, r === "Start");
	let s = a["on" + n + r];
	s && z.postRender(() => s(t, il(t)));
}
var Md = class extends bu {
	mount() {
		let { current: e } = this.node;
		e && (this.unmount = ou(e, (e, t) => (jd(this.node, t, "Hover", "Start"), (e) => jd(this.node, e, "Hover", "End"))));
	}
	unmount() {}
}, Nd = class extends bu {
	constructor() {
		super(...arguments), this.isActive = !1;
	}
	onFocus() {
		let e = !1;
		try {
			e = this.node.current.matches(":focus-visible");
		} catch {
			e = !0;
		}
		e && this.node.animationState && (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0);
	}
	onBlur() {
		this.isActive && this.node.animationState && (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1);
	}
	mount() {
		this.unmount = ne(Ac(this.node.current, "focus", () => this.onFocus()), Ac(this.node.current, "blur", () => this.onBlur()));
	}
	unmount() {}
};
// node_modules/framer-motion/dist/es/gestures/press.mjs
function Pd(e, t, n, r) {
	e.current instanceof HTMLButtonElement && e.current.disabled || jd(e, t, "Tap", n, r);
}
var Fd = class extends bu {
	constructor() {
		super(...arguments), this.options = {};
	}
	mount() {
		let { current: e } = this.node;
		e && (this.update(), this.unmount = vu(e, (e, t) => (Pd(this.node, t, "Start"), {
			onComplete: (e, { success: t }) => Pd(this.node, e, t ? "" : "Cancel"),
			onRepeat: () => Pd(this.node, t, "", !0)
		}), this.options));
	}
	update() {
		let { options: e, node: t } = this, { globalTapTarget: n, propagate: r, tap: i } = t.props;
		for (let t in e) delete e[t];
		Object.assign(e, i, {
			useGlobalTarget: n,
			stopPropagation: r?.tap === !1
		});
	}
	unmount() {}
}, Id = /* @__PURE__ */ new WeakMap(), Ld = /* @__PURE__ */ new WeakMap(), Rd = (e) => {
	let t = Id.get(e.target);
	t && t(e);
}, zd = (e) => {
	e.forEach(Rd);
};
function Bd({ root: e, ...t }) {
	let n = e || document;
	Ld.has(n) || Ld.set(n, {});
	let r = Ld.get(n), i = JSON.stringify(t);
	return r[i] || (r[i] = new IntersectionObserver(zd, {
		root: e,
		...t
	})), r[i];
}
function Vd(e, t, n) {
	let r = Bd(t);
	return Id.set(e, n), r.observe(e), () => {
		Id.delete(e), r.unobserve(e);
	};
}
// node_modules/framer-motion/dist/es/motion/features/viewport/index.mjs
var Hd = {
	some: 0,
	all: 1
}, Ud = class extends bu {
	constructor() {
		super(...arguments), this.hasEnteredView = !1, this.isInView = !1;
	}
	startObserver() {
		this.stopObserver?.();
		let { viewport: e = {} } = this.node.getProps(), { root: t, margin: n, amount: r = "some", once: i } = e, a = {
			root: t ? t.current : void 0,
			rootMargin: n,
			threshold: typeof r == "number" ? r : Hd[r]
		}, o = (e) => {
			let { isIntersecting: t } = e;
			if (this.isInView === t || (this.isInView = t, i && !t && this.hasEnteredView)) return;
			t && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", t);
			let { onViewportEnter: n, onViewportLeave: r } = this.node.getProps(), a = t ? n : r;
			a && a(e);
		};
		this.stopObserver = Vd(this.node.current, a, o);
	}
	mount() {
		this.startObserver();
	}
	update() {
		if (typeof IntersectionObserver > "u") return;
		let { props: e, prevProps: t } = this.node;
		[
			"amount",
			"margin",
			"root"
		].some(Wd(e, t)) && this.startObserver();
	}
	unmount() {
		this.stopObserver?.(), this.hasEnteredView = !1, this.isInView = !1;
	}
};
function Wd({ viewport: e = {} }, { viewport: t = {} } = {}) {
	return (n) => e[n] !== t[n];
}
// node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs
var Gd = /*@__PURE__*/ _d(/* @__PURE__ */ Object.assign({}, xd, {
	inView: { Feature: Ud },
	tap: { Feature: Fd },
	focus: { Feature: Nd },
	hover: { Feature: Md }
}, Ad, { layout: {
	ProjectionNode: Nc,
	MeasureLayout: kd
} }), vd);
// node_modules/framer-motion/dist/es/value/use-motion-value.mjs
function Kd(e) {
	let t = _(() => G(e)), { isStatic: n } = o(Mu);
	if (n) {
		let [, n] = p(e);
		s(() => t.on("change", n), []);
	}
	return t;
}
// node_modules/framer-motion/dist/es/value/use-combine-values.mjs
function qd(e, t) {
	let n = Kd(t()), r = () => n.set(t());
	return r(), v(() => {
		let t = () => z.preRender(r, !1, !0), n = e.map((e) => e.on("change", t));
		return r(), () => {
			n.forEach((e) => e()), B(r);
		};
	}), n;
}
// node_modules/framer-motion/dist/es/value/use-computed.mjs
function Jd(e) {
	Xi.current = [], e();
	let t = qd(Xi.current, e);
	return Xi.current = void 0, t;
}
// node_modules/framer-motion/dist/es/value/use-transform.mjs
function Yd(e, t, n, r) {
	if (typeof e == "function") return Jd(e);
	if (n !== void 0 && !Array.isArray(n) && typeof t != "function") return Zd(e, t, n, r);
	let i = typeof t == "function" ? t : yu(t, n, r), a = Array.isArray(e) ? Xd(e, i) : Xd([e], ([e]) => i(e)), o = Array.isArray(e) ? void 0 : e.accelerate;
	if (o && !o.isTransformed && typeof t != "function" && Array.isArray(n) && r?.clamp !== !1 && !r?.mixer) {
		let e = r?.ease;
		a.accelerate = {
			...o,
			times: [
				0,
				...t,
				1
			],
			keyframes: [
				n[0],
				...n,
				n[n.length - 1]
			],
			isTransformed: !0,
			...e ? { ease: Array.isArray(e) ? [e[0], ...e] : e } : {}
		};
	}
	return a;
}
function Xd(e, t) {
	let n = _(() => []);
	return qd(e, () => {
		n.length = 0;
		let r = e.length;
		for (let t = 0; t < r; t++) n[t] = e[t].get();
		return t(n);
	});
}
function Zd(e, t, n, r) {
	let i = _(() => Object.keys(n)), a = _(() => ({}));
	for (let o of i) a[o] = Yd(e, t, n[o], r);
	return a;
}
// node_modules/framer-motion/dist/es/utils/reduced-motion/use-reduced-motion.mjs
function Qd() {
	!Uc.current && Gc();
	let [e] = p(Hc.current);
	return process.env.NODE_ENV !== "production" && se(e !== !0, "You have Reduced Motion enabled on your device. Animations may not appear as expected.", "reduced-motion-disabled"), e;
}
// node_modules/framer-motion/dist/es/animation/utils/is-dom-keyframes.mjs
function $d(e) {
	return typeof e == "object" && !Array.isArray(e);
}
// node_modules/framer-motion/dist/es/animation/animate/resolve-subjects.mjs
function ef(e, t, n, r) {
	return e == null ? [] : typeof e == "string" && $d(t) ? Xa(e, n, r) : e instanceof NodeList ? Array.from(e) : Array.isArray(e) ? e.filter((e) => e != null) : [e];
}
// node_modules/framer-motion/dist/es/animation/sequence/utils/calc-repeat-duration.mjs
function tf(e, t, n) {
	return e * (t + 1) + n * t;
}
// node_modules/framer-motion/dist/es/animation/sequence/utils/calc-time.mjs
function nf(e, t) {
	if (t.has(e)) return t.get(e);
	let [, n, r] = e.match(/^(.+?)([+-][\d.]+)$/) || [];
	return t.has(n) ? Math.max(0, t.get(n) + parseFloat(r)) : void 0;
}
function rf(e, t, n, r) {
	return typeof t == "number" ? t : t.startsWith("-") || t.startsWith("+") ? Math.max(0, e + parseFloat(t)) : t === "<" ? n : t.startsWith("<") ? Math.max(0, n + parseFloat(t.slice(1))) : nf(t, r) ?? e;
}
// node_modules/framer-motion/dist/es/animation/sequence/utils/edit.mjs
function af(e, t, n) {
	for (let r = 0; r < e.length; r++) {
		let i = e[r];
		i.at > t && i.at < n && (x(e, i), r--);
	}
}
function of(e, t, n, r, i, a) {
	af(e, i, a);
	for (let o = 0; o < t.length; o++) e.push({
		value: t[o],
		at: R(i, a, r[o]),
		easing: /* @__PURE__ */ we(n, o)
	});
}
// node_modules/framer-motion/dist/es/animation/sequence/utils/normalize-times.mjs
function sf(e, t, n = 0) {
	let r = t + 1 + t * n;
	for (let t = 0; t < e.length; t++) e[t] = e[t] / r;
}
// node_modules/framer-motion/dist/es/animation/sequence/utils/sort.mjs
function cf(e, t) {
	return e.at === t.at ? e.value === null ? 1 : t.value === null ? -1 : 0 : e.at - t.at;
}
// node_modules/framer-motion/dist/es/animation/sequence/create.mjs
var lf = "easeInOut", uf = 20;
function df(e, { defaultTransition: t = {}, ...n } = {}, r, i, a) {
	let o = t.duration || .3, s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = {}, u = /* @__PURE__ */ new Map(), d = 0, f = 0, p = 0, m = (e, n) => {
		let a = n, s = (e) => typeof e == "number" ? n + e : rf(f, e, d, u);
		for (let n = 0; n < e.length; n++) {
			let h = e[n];
			if (typeof h == "string") {
				u.set(h, f);
				continue;
			}
			if (!Array.isArray(h)) {
				let e = h.at === void 0 ? f : s(h.at);
				"sequence" in h ? (d = f = e, f = m(h.sequence, e), d = e, a = Math.max(a, f)) : u.set(h.name, e);
				continue;
			}
			let [g, _, v = {}] = h;
			v.at !== void 0 && (f = s(v.at));
			let y = 0, b = (e, n, r, a = 0, s = 0) => {
				let c = mf(e), { delay: l = 0, times: u = Dn(c), type: d = t.type || "keyframes", repeat: m, repeatType: h, repeatDelay: g = 0, ..._ } = n, { ease: v = t.ease || "easeOut", duration: b } = n;
				r.mixer ||= n.mixer;
				let x = typeof l == "function" ? l(a, s) : l, S = c.length, C = Gr(d) ? d : i?.[d || "keyframes"];
				if (S <= 2 && C) {
					let e = 100;
					if (S === 2 && _f(c)) {
						let t = c[1] - c[0];
						e = Math.abs(t);
					}
					let n = {
						...t,
						..._
					};
					b !== void 0 && (n.duration = /* @__PURE__ */ A(b));
					let r = Xt(n, e, C);
					v = r.ease, b = r.duration;
				}
				b ??= o;
				let T = f + x;
				u.length === 1 && u[0] === 0 && (u[1] = 1);
				let E = u.length - c.length;
				if (E > 0 && En(u, E), c.length === 1 && c.unshift(null), m && typeof process < "u" && process.env.NODE_ENV !== "production" && w(m < uf, `Sequence segments can't repeat ${m} times — ignoring repeat option. Use a value below ${uf} or apply repeat at the sequence level instead.`), m && m < uf) {
					let e = b > 0 ? g / b : 0;
					b = tf(b, m, g);
					let t = [...c], n = [...u];
					v = Array.isArray(v) ? [...v] : [v];
					let r = [...v], i = h === "reverse" || h === "mirror", a = t, o = r;
					i && (a = [...t].reverse(), h === "reverse" && (o = [...r].reverse().map((e) => typeof e == "function" ? /* @__PURE__ */ fe(e) : e)));
					for (let s = 0; s < m; s++) {
						let l = i && s % 2 == 0, d = l ? a : t, f = l ? o : r, p = (s + 1) * (1 + e);
						e > 0 && (c.push(c[c.length - 1]), u.push(p), v.push("linear")), c.push(...d);
						for (let e = 0; e < d.length; e++) u.push(n[e] + p), v.push(e === 0 ? "linear" : /* @__PURE__ */ we(f, e - 1));
					}
					sf(u, m, e);
				}
				let D = T + b;
				of(r, c, v, u, T, D), y = Math.max(x + b, y), p = Math.max(D, p);
			};
			if (K(g)) {
				let e = ff(g, c);
				b(_, v, pf("default", e));
			} else {
				let e = ef(g, _, r, l), t = e.length;
				for (let n = 0; n < t; n++) {
					_ = _, v = v;
					let r = e[n], i = ff(r, c);
					for (let e in _) b(_[e], hf(v, e), pf(e, i), n, t);
				}
			}
			d = f, f += y, a = Math.max(a, f);
		}
		return a;
	};
	m(e, 0), a && (a.duration = p, a.labels = u);
	let { type: h, ...g } = t;
	return c.forEach((e, r) => {
		for (let i in e) {
			let a = e[i];
			a.sort(cf);
			let o = [], c = [], l = [];
			for (let e = 0; e < a.length; e++) {
				let { at: t, value: n, easing: r } = a[e];
				o.push(n), c.push(/* @__PURE__ */ re(0, p, t)), l.push(r || "easeOut");
			}
			c[0] !== 0 && (c.unshift(0), o.unshift(o[0]), l.unshift(lf)), c[c.length - 1] !== 1 && (c.push(1), o.push(null)), s.has(r) || s.set(r, {
				keyframes: {},
				transition: {}
			});
			let u = s.get(r);
			u.keyframes[i] = o, u.transition[i] = {
				...g,
				duration: p,
				ease: l,
				times: c,
				mixer: a.mixer || t.mixer,
				...n
			};
		}
	}), s;
}
function ff(e, t) {
	return !t.has(e) && t.set(e, {}), t.get(e);
}
function pf(e, t) {
	return t[e] || (t[e] = []), t[e];
}
function mf(e) {
	return Array.isArray(e) ? e : [e];
}
function hf(e, t) {
	return e && e[t] ? {
		...e,
		...e[t]
	} : { ...e };
}
var gf = (e) => typeof e == "number", _f = (e) => e.every(gf);
// node_modules/framer-motion/dist/es/animation/animate/subject.mjs
function vf(e, t) {
	return K(e) || typeof e == "number" || typeof e == "string" && !$d(t);
}
function yf(e, t, n, r) {
	let i = [];
	if (vf(e, t)) i.push(Yo(e, $d(t) && t.default || t, n && (n.default || n)));
	else {
		if (e == null) return i;
		let a = ef(e, t, r), o = a.length;
		process.env.NODE_ENV !== "production" && T(!!o, "No valid elements provided.", "no-valid-elements");
		for (let e = 0; e < o; e++) {
			let r = a[e], s = { ...n };
			"delay" in s && typeof s.delay == "function" && (s.delay = s.delay(e, o)), r instanceof Element ? i.push(...Go(r, t, s, Pc.get(r))) : i.push(...Wa(Ha(r) ?? Ko, r, t, s));
		}
	}
	return i;
}
// node_modules/framer-motion/dist/es/animation/animate/sequence.mjs
function bf(e, t, n, r) {
	let i = [], a = df(e.map((e) => {
		if (Array.isArray(e) && typeof e[0] == "function") {
			let t = e[0], n = G(0);
			return n.on("change", t), e.length === 1 ? [n, [0, 1]] : e.length === 2 ? [
				n,
				[0, 1],
				e[1]
			] : [
				n,
				e[1],
				e[2]
			];
		}
		return e;
	}), t, n, { spring: Sn }, r), o = t?.reduceMotion ?? t?.defaultTransition?.reduceMotion;
	return a.forEach(({ keyframes: e, transition: t }, n) => {
		i.push(...yf(n, e, {
			...t,
			reduceMotion: o
		}));
	}), i;
}
// node_modules/framer-motion/dist/es/animation/timeline/index.mjs
var xf = 0;
function Sf({ repeat: e = 0, repeatDelay: t = 0, repeatType: n = "loop", delay: r = 0 }, i, a, o) {
	let s = i + t, c = o === void 0;
	if (c) {
		let t = Math.max(0, a - r);
		o = s && t > 0 ? Math.min(e, Math.ceil(t / s - 1e-9) - 1) : 0, a = Math.min(t - o * s, i);
	}
	return n !== "loop" && o % 2 && (a = i - a), [o, c ? a : r + o * s + a];
}
function Cf(e, t) {
	let n = [...e], r = typeof n[0] == "function" ? Math.max(1, n.length - 1) : 2;
	return n[r] = {
		...n[r],
		at: t
	}, n;
}
var wf = (e, t) => t === void 0 ? e : {
	name: e,
	at: t
};
function Tf(e) {
	e.pause(), e.time = 0, e.stop();
}
var Ef = class e {
	constructor(e = [], t = {}, n) {
		this.options = t, this.entries = [], this.repeatIndex = 0, this.prevTime = 0, this.markers = [], this.labels = /* @__PURE__ */ new Map(), this.totalDuration = 0, this.isDirty = !1, this.isDone = !1, this.isRebuilding = !1, this.playbackSpeed = 1, this.motionScope = q.current, this.isKilled = !1, this.isWrapped = !1, this.stop = () => {
			this.flush(), this.group?.stop();
		}, this.isPaused = t.autoplay === !1, this.newFinished(), e.forEach((e) => this.add(e)), n ? (this.isDirty = !1, this.isWrapped = !0, this.group = new Ki(n), this.watch()) : (this.invalidate(), this.flush());
	}
	add(t, n) {
		return t instanceof e && t.adopt(this), this.push({
			item: t,
			at: n
		});
	}
	call(e, t) {
		return this.push({
			item: e,
			at: t,
			marker: {
				name: "_m" + xf++,
				time: 0,
				callback: e
			}
		});
	}
	addPause(e, t) {
		return this.push({
			item: t || {},
			at: e,
			marker: {
				name: "_m" + xf++,
				time: 0,
				callback: t,
				pause: !0
			}
		});
	}
	move(e, t) {
		return this.entries.forEach((n) => {
			n.item === e && (n.at = t);
		}), this.invalidate();
	}
	remove(t) {
		return t instanceof e && (t.parent = void 0), this.entries = this.entries.filter((e) => e.item !== t), this.invalidate();
	}
	clear() {
		return this.entries = [], this.invalidate();
	}
	getLabelTime(e) {
		return this.flush(), this.labels.get(e);
	}
	seek(e) {
		return this.time = this.resolve(e), this;
	}
	playTo(e) {
		let t = this.resolve(e), n = this.iterationDuration, r = this.time, [i] = Sf(this.options, n, r), a = Sf(this.options, n, t, i)[1], o = Math.abs(this.speed);
		return this.speed = a < r ? -o : o, this.stopAt = t, this.clock || this.invalidate(), this.play(), this;
	}
	reverse() {
		return this.speed = -this.speed, this.play(), this;
	}
	get progress() {
		return this.duration ? this.time / this.duration : 0;
	}
	set progress(e) {
		this.time = e * this.duration;
	}
	get time() {
		return this.active()?.time ?? 0;
	}
	set time(e) {
		this.flush(), this.prevTime = e, this.group && (this.group.time = e), this.repeatIndex = this.currentRepeat();
	}
	get speed() {
		return this.playbackSpeed;
	}
	set speed(e) {
		this.playbackSpeed = e, this.group && (this.group.speed = e);
	}
	get duration() {
		return this.flush(), this.isWrapped ? this.group.duration : this.totalDuration;
	}
	get iterationDuration() {
		return this.flush(), this.isWrapped ? this.group.iterationDuration : this.totalDuration;
	}
	get state() {
		return this.active()?.state ?? "idle";
	}
	get startTime() {
		return this.active()?.startTime ?? null;
	}
	play() {
		this.flush(), this.isPaused = !1, this.group?.play(), this.isDone && (this.newFinished(), this.watch());
	}
	pause() {
		this.flush(), this.isPaused = !0, this.group?.pause();
	}
	cancel() {
		this.flush(), this.group?.cancel();
	}
	complete() {
		this.flush(), this.group?.complete();
	}
	attachTimeline(e) {
		return this.flush(), this.scrollTimeline = e, this.detachScroll = this.group?.attachTimeline(e), () => {
			this.scrollTimeline = void 0, this.detachScroll?.();
		};
	}
	then(e, t) {
		return this.finished.then(e, t);
	}
	active() {
		return this.flush(), this.group?.animations.length ? this.group : void 0;
	}
	push(e) {
		return this.entries.push(e), this.invalidate();
	}
	invalidate() {
		return this.parent ? this.parent.invalidate() : this.isDirty || (this.isDirty = !0, queueMicrotask(() => this.flush())), this;
	}
	flush() {
		this.isDirty && !this.parent && !this.isKilled && this.build();
	}
	adopt(e) {
		this.group &&= (Tf(this.group), void 0), this.isDirty = !1, this.parent = e;
	}
	build() {
		let e = this.isWrapped ? this.group.iterationDuration : this.totalDuration;
		this.isDirty = !1, this.isWrapped = !1;
		let t = this.group, n = 0;
		t && (this.isRebuilding = !0, this.scrollTimeline ? (this.detachScroll?.(), t.cancel()) : (n = t.animations.length ? t.time : 0, Tf(t)), this.isRebuilding = !1);
		let { defaultTransition: r, onComplete: i, onUpdate: a, onRepeat: o, onReverseComplete: s, autoplay: c, scope: l, ...u } = this.options, d = {};
		l?.reduceMotion !== void 0 && (d.reduceMotion = l.reduceMotion), l?.skipAnimations !== void 0 && (d.skipAnimations = l.skipAnimations), Object.assign(d, u);
		let f = /* @__PURE__ */ new Map(), p = {}, m = q.current;
		q.current = this.motionScope;
		let h;
		try {
			h = bf(this.toSequence(f), {
				defaultTransition: r,
				...d
			}, l, p);
		} finally {
			q.current = m;
		}
		let g = p.labels, _ = d.duration ?? p.duration, v = p.duration ? _ / p.duration : 1;
		if (g.forEach((e, t) => g.set(t, e * v)), this.markers = [], f.forEach((e, t) => {
			e.time = g.get(t), g.delete(t), _ = Math.max(_, e.time), this.markers.push(e);
		}), this.markers.sort((e, t) => e.time - t.time), this.labels = g, this.totalDuration = _, this.clock = this.clockAnimation = void 0, this.markers.length || this.stopAt !== void 0 || a || o) {
			let e = this.clock = G(0);
			e.on("change", (t) => e === this.clock && this.onClock(t)), h.unshift(this.clockAnimation = Yo(e, [0, _], {
				...d,
				duration: _,
				ease: "linear"
			}));
		}
		let y = this.group = new Ki(h), { delay: b = 0, repeat: x = 0, repeatDelay: S = 0 } = this.options, [C, w] = Sf(this.options, e, n);
		n > b && (n = Sf(this.options, _, Math.min(w, _), C)[1]), this.isDone && n < b + (x + 1) * (_ + S) - S && this.newFinished(), this.scrollTimeline ? this.detachScroll = y.attachTimeline(this.scrollTimeline) : (y.speed = this.playbackSpeed, this.isPaused && y.pause(), n && (y.time = n)), this.repeatIndex = this.currentRepeat(), this.prevTime = n || -1, this.watch();
	}
	toSequence(t) {
		return this.entries.map(({ item: n, at: r, marker: i }) => i ? (t.set(i.name, i), wf(i.name, r)) : n instanceof e ? {
			sequence: n.toSequence(t),
			at: r
		} : typeof n == "string" ? wf(n, r) : r === void 0 ? n : Array.isArray(n) ? Cf(n, r) : {
			...n,
			at: r
		});
	}
	resolve(e) {
		return this.flush(), typeof e == "number" ? e : nf(e, this.labels) ?? this.time;
	}
	currentRepeat() {
		return Sf(this.options, this.totalDuration, this.clockAnimation?.time ?? 0)[0];
	}
	onClock(e) {
		let t = this.prevTime;
		if (this.prevTime = e, this.isRebuilding) return;
		let { onUpdate: n, onRepeat: r, repeatType: i = "loop" } = this.options;
		n?.(e);
		let a = this.currentRepeat(), o = a > this.repeatIndex ? 1 : -1;
		for (; a !== this.repeatIndex;) {
			let e = this.speed > 0 == (i === "loop" || !(this.repeatIndex % 2)), n = e ? this.totalDuration : 0;
			if (this.cross(t, n)) return;
			this.repeatIndex += o, r?.(), t = i === "loop" ? e ? -1 : Infinity : n;
		}
		this.cross(t, e);
	}
	cross(e, t) {
		if (e === t) return;
		let n = t > e, r = (r) => n ? r > e && r <= t : r < e && r >= t, i = n ? this.markers : [...this.markers].reverse();
		for (let e of i) if (r(e.time) && (e.callback?.(n ? 1 : -1), e.pause)) return this.pauseAt(e.time);
		if (this.stopAt !== void 0 && r(this.stopAt)) return this.pauseAt(this.stopAt), this.stopAt = void 0, !0;
	}
	pauseAt(e) {
		return this.pause(), this.time = Sf(this.options, this.totalDuration, e, this.repeatIndex)[1], !0;
	}
	watch() {
		let e = this.group;
		e.finished.then(() => {
			if (e !== this.group || this.isDone) return;
			this.isDone = !0;
			let { onComplete: t, onReverseComplete: n } = this.options, r = this.speed < 0 && n || t, i = this.resolveFinished;
			r?.(), i();
		});
	}
	newFinished() {
		this.isDone = !1, this.finished = new Promise((e) => {
			this.resolveFinished = e;
		});
		let { scope: e } = this.options, t = this.motionScope?.add(() => {
			this.isKilled = !0, this.stop();
		});
		e?.animations.push(this), this.finished.then(() => {
			t?.(), e && x(e.animations, this);
		});
	}
};
// node_modules/framer-motion/dist/es/animation/animate/index.mjs
function Df(e) {
	return Array.isArray(e) && e.some((e) => Array.isArray(e) || e?.sequence);
}
function Of(e = {}) {
	let { scope: t, reduceMotion: n, skipAnimations: r } = e;
	function i(e, i, a) {
		let o = q.current?.transition, s = {};
		n !== void 0 && (s.reduceMotion = n), r !== void 0 && (s.skipAnimations = r);
		let c;
		if (Df(e)) {
			let r = {
				...s,
				...i,
				scope: t
			};
			o && (r.defaultTransition = {
				...o,
				...r.defaultTransition
			}), r.reduceMotion = i?.reduceMotion ?? r.defaultTransition?.reduceMotion ?? n, c = new Ef(e, r);
		} else {
			let { onComplete: n, ...r } = a || {}, l = {
				...s,
				...o,
				...r
			}, { onUpdate: u } = r;
			c = new Ef([typeof e == "number" || typeof e == "string" && (typeof i == "string" || Array.isArray(i)) ? [
				u || (() => {}),
				Array.isArray(i) ? i : [e, i],
				{
					...l,
					onUpdate: void 0
				}
			] : [
				e,
				i,
				l
			]], {
				...s,
				onComplete: n,
				scope: t
			}, yf(e, i, l, t));
		}
		return c;
	}
	return i;
}
var kf = /* @__PURE__ */ Object.assign(/* @__PURE__ */ Of(), {
	addEffect: Ba,
	removeEffect: Va
}), Af = Gd;
export { Kd as a, qo as c, v as d, _ as f, Yd as i, Ka as l, kf as n, Nu as o, g as p, Qd as r, Mu as s, Af as t, y as u };
