// src/local/types.ts
var e = (e) => e.attrs?.bind ?? `@${e.id}`, t = "local-draft-3";
export { e as n, t };
