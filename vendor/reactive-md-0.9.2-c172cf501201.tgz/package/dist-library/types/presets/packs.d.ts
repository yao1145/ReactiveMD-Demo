export declare const controlsPack: import("../sdk/index.js").LocalPresetPackage;
export declare const layoutPack: import("../sdk/index.js").LocalPresetPackage;
export declare const dataPack: import("../sdk/index.js").LocalPresetPackage;
export declare const visualsPack: import("../sdk/index.js").LocalPresetPackage;
