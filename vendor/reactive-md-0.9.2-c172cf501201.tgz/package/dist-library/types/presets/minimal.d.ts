export declare const minimalPreset: import("../sdk/index.js").LocalPresetPackage;
export default minimalPreset;
