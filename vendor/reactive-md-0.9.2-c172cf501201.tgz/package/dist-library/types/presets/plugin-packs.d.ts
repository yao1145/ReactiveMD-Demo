export declare function selectOfficialPreset(id: string, names: readonly string[], dependencies?: readonly string[]): import("../sdk/index.js").LocalPresetPackage;
