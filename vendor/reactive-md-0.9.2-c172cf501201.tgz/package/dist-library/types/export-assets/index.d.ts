/**
 * Build-time manifest for the files hosts embed in exported HTML.
 * Node-only: this subpath reads the installed package and never enters a
 * browser, React or compiler graph.
 */
export declare const EXPORT_ASSETS_PROTOCOL = "reactive-md-export-assets/v1";
export type ExportAssetId = 'base-css' | 'print-css' | 'notices' | 'package-json' | 'runtime';
export interface ExportAssetEntry {
    /** Stable across releases; safe to persist in build configuration. */
    readonly id: ExportAssetId;
    /** Public package specifier that resolves to the emitted file. */
    readonly specifier: string;
    readonly description: string;
}
export interface ExportAssetsManifest {
    /** Protocol string; the trailing segment is the manifest version. */
    readonly protocol: typeof EXPORT_ASSETS_PROTOCOL;
    readonly assets: readonly ExportAssetEntry[];
}
/** The frozen manifest. Identical object on every call. */
export declare function listExportAssets(): ExportAssetsManifest;
/** File URL of an asset, resolved through the installed package exports. */
export declare function resolveExportAsset(id: ExportAssetId): URL;
/** UTF-8 contents of an asset. */
export declare function readExportAsset(id: ExportAssetId): string;
