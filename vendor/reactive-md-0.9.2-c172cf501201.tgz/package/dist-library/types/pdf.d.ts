/** A problem that only the print engine can observe, with no document position. */
export interface LocalPdfDiagnostic {
    readonly code: 'local.pdf.image-decode';
    readonly message: string;
}
export interface LocalPdfOptions {
    readonly format?: string;
    readonly landscape?: boolean;
    readonly margin?: {
        readonly top?: string;
        readonly right?: string;
        readonly bottom?: string;
        readonly left?: string;
    };
    readonly printBackground?: boolean;
    /** Treat reported problems as fatal, like the CLI's --strict. */
    readonly strict?: boolean;
    /** Called once per problem; a relaxed export still writes its PDF. */
    readonly onDiagnostic?: (diagnostic: LocalPdfDiagnostic) => void;
}
/** Print self-contained static HTML using a caller-installed Chromium. */
export declare function renderLocalPdf(html: string, options?: LocalPdfOptions): Promise<Uint8Array>;
