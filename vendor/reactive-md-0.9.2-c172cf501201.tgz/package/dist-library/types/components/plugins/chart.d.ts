declare const _default: import("../../react/index.js").LocalReactPresetPackage;
export default _default;
