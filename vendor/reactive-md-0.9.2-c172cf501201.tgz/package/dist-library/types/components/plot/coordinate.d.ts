import type { LocalComponentContext } from '../../react/component-api.js';
export declare function CoordinateView(context: LocalComponentContext): import("react").JSX.Element;
