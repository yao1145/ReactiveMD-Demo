export declare const minimalReactPresetPackage: import("../react/index.js").LocalReactPresetPackage;
export default minimalReactPresetPackage;
