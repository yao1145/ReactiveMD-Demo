import { type LocalComponentRender } from '../react/component-api.js';
import type { LocalPresetPackage } from '../sdk/types.js';
import type { LocalStyleResource } from '../sdk/theme.js';
export declare function mountOfficialPreset(preset: LocalPresetPackage, views: Readonly<Record<string, LocalComponentRender>>, resources?: readonly LocalStyleResource[]): import("../react/index.js").LocalReactPresetPackage;
