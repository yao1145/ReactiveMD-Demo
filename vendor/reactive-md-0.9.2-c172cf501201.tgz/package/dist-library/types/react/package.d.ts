import { type LocalReactHostInput, type LocalReactPresetPackage } from './package-core.js';
export * from './package-core.js';
/** Default semantic preset paired with the built-in React implementation table. */
export declare const defaultReactPresetPackage: LocalReactPresetPackage;
export declare function createReactHost(input?: LocalReactHostInput): import("./package-core.js").LocalReactHost;
