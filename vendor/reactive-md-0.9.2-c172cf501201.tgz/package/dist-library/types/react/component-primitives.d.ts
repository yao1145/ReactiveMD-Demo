/**
 * Stable public adapter primitives for component implementations.
 *
 * These are canonical kernel/rendering utilities re-exported behind a public
 * entry so builtin and external components can share the same limits, text
 * length, expression, math, table surface and diagram layout behaviour. The
 * implementations are not copied: they remain the kernel modules.
 */
export { DEFAULT_LOCAL_DATA_TABLE_ROWS, MAX_LOCAL_ARRAY_LENGTH, MAX_LOCAL_DATA_TABLE_COLUMNS, MAX_LOCAL_DATA_TABLE_ROWS, MAX_LOCAL_PLOT_CURVES, MAX_LOCAL_PLOT_POINTS, MAX_LOCAL_PLOT_STEPS, MAX_LOCAL_STRING_LENGTH, MAX_LOCAL_VALUE_CHARACTERS, isLocalEmail, } from '../local/configuration/limits.js';
export { countLocalCodePoints } from '../local/source/source-context.js';
export { formatLocalDiagnostic } from '../local/configuration/diagnostics.js';
export { compileExpression, type LocalExpression } from '../local/evaluation/expression/compile.js';
export { compileLatex, compilePlotFormula, implicitGridSize, LatexError, MAX_IMPLICIT_GRID, MIN_IMPLICIT_GRID, plotFormulaKind, type CompiledPlotFormula, type LatexEvaluationBudget, type PlotFormulaKind, type PlotPoint, type PlotSample, } from '../local/evaluation/math/latex.js';
export { sampleImplicit, sampleParametric, samplePlot, samplePolar } from '../local/evaluation/math/sample.js';
export { LatexView } from '../local/rendering/math-view.js';
export { TableSurface } from '../local/rendering/table/data-table.js';
export { createDiagramLayoutFallback, diagramEdgePath, diagramLayoutKey, layoutDiagram, type DiagramLayoutInput, type DiagramLayoutResult, } from '../components/diagram/layout.js';
export { isLocalColor } from '../local/configuration/color-values.js';
export type { Diagnostic, LocalValue } from '../local/types.js';
export type { LocalRenderMode } from '../local/rendering/render-types.js';
export type { LocalLocale, Localize } from './localization.js';
