import { LOCAL_REACT_PRESET_PROTOCOL, type LocalComponentDefinition, type LocalPresetPackage } from '../sdk/types.js';
import type { LocalStyleResource, LocalThemePackage } from '../sdk/theme.js';
import { type LocalReactConfig } from './sdk-core.js';
import { type LocalReactComponent, type LocalReactComponentImplementation } from './component-api.js';
export interface LocalPackageNotice {
    readonly id: string;
    readonly name?: string;
    readonly version?: string;
    readonly license?: string;
    readonly url?: string;
    readonly text?: string;
}
export type LocalReactComponentPackageInput = Omit<LocalComponentDefinition, 'protocol' | 'form' | 'props'> & Partial<Pick<LocalComponentDefinition, 'protocol' | 'form' | 'props'>> & LocalReactComponentImplementation & {
    readonly css?: string;
    readonly resources?: readonly LocalStyleResource[];
};
export interface LocalReactPackage {
    readonly components: readonly LocalReactComponent[];
    readonly resources?: readonly LocalStyleResource[];
    readonly themes?: readonly LocalThemePackage[];
    readonly notices?: readonly LocalPackageNotice[];
}
export interface LocalReactComponentPackage extends LocalReactPackage {
    readonly definition: LocalComponentDefinition;
    readonly resources: readonly LocalStyleResource[];
}
/**
 * Pairs one semantic preset with the React implementations and resources the
 * host installs for it. The pairing is validated by manifest identity, not by
 * array position or preset version alone.
 */
export interface LocalReactPresetPackage {
    readonly protocol: typeof LOCAL_REACT_PRESET_PROTOCOL;
    readonly preset: LocalPresetPackage;
    readonly components: readonly LocalReactComponent[];
    readonly resources?: readonly LocalStyleResource[];
    readonly notices?: readonly LocalPackageNotice[];
}
/** Validate a semantic preset and its React pairing. */
export declare function defineReactPreset(input: LocalReactPresetPackage): LocalReactPresetPackage;
/** One authoring declaration; its manifest stays plain data for Worker use. */
export declare function defineReactComponentPackage(input: LocalReactComponentPackageInput): LocalReactComponentPackage;
export interface LocalReactHostInput {
    /**
     * React preset packages. Omitted keeps the default preset; `[]` installs no
     * preset. Explicit packages/components never restore the default silently.
     */
    readonly presets?: readonly (LocalReactPresetPackage | 'default')[];
    readonly replacements?: 'allow' | 'forbid';
    readonly packages?: readonly LocalReactPackage[];
    readonly components?: readonly LocalReactComponent[];
    readonly themes?: readonly LocalThemePackage[];
    readonly resources?: readonly LocalStyleResource[];
    readonly notices?: readonly LocalPackageNotice[];
}
export interface LocalReactHost {
    readonly config: LocalReactConfig['config'];
    readonly reactConfig: LocalReactConfig;
    readonly compileOptions: Readonly<{
        config: LocalReactConfig['config'];
    }>;
    readonly resources: readonly LocalStyleResource[];
    readonly css: string;
    readonly notices: readonly LocalPackageNotice[];
}
/** Compose packages once for compiler, renderer, authoring and export. */
export declare function createReactHostWithBase(input: LocalReactHostInput, base: LocalReactPresetPackage): LocalReactHost;
