import { type Plugin } from 'vite';
import type { LocalReactHost } from '../react/package.js';
/** Directory mode: discover `theme/` and `plugin/` entries relative to the Vite root. */
export interface ReactiveMdDirectoryOptions {
    /** Theme root relative to the Vite root. Defaults to `theme`. */
    readonly themeDir?: string;
    /** Package entry root relative to the Vite root. Defaults to `plugin`. */
    readonly pluginDir?: string;
    /**
     * Select the base preset. `true` (default) keeps the complete compatibility
     * preset, `minimal` installs the core set, and `false` starts with no preset.
     */
    readonly defaultPreset?: boolean | 'minimal';
    /**
     * Also expose `virtual:reactive-md-minimal-host` and
     * `virtual:reactive-md-minimal-bundle` from the same discovery snapshot.
     * They install the minimal base preset but keep every discovered package,
     * preset identity, dependency and resource in the normal order.
     */
    readonly includeMinimal?: boolean;
}
/** Manual mode: one local module exporting `host = createReactHost(...)`. */
export interface ReactiveMdExtensionsOptions {
    /** Local module exporting `host = createReactHost(...)`. Relative to Vite root. */
    readonly extensions: string;
}
/**
 * Passing `extensions` selects manual registration. Omitting every option, or
 * passing only `themeDir`/`pluginDir`, enables directory registration.
 */
export type ReactiveMdViteOptions = ReactiveMdDirectoryOptions | ReactiveMdExtensionsOptions;
/** Load the same directory registration in a trusted Node project for CLI export. */
export declare function loadLocalDirectoryHost(projectRoot: string, options?: ReactiveMdDirectoryOptions & {
    readonly interactive?: boolean;
}): Promise<{
    host: LocalReactHost;
    bundle: import("../build/index.js").LocalStandaloneBuild | undefined;
}>;
/**
 * Optional Node-only adapter. Directory mode discovers `theme/` and `plugin/`
 * once per snapshot and generates one registration module; manual mode keeps
 * the explicit `extensions` entry. Registration and code execution stay
 * explicit on the consumer side.
 */
export declare function reactiveMd(options?: ReactiveMdViteOptions): Plugin;
export default reactiveMd;
