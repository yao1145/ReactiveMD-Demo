/**
 * Bidirectional (submit + subscribe) network adapters over WebSocket and
 * WebRTC data channels.
 *
 * The default wire protocol is JSON:
 *
 *   client -> server  {"type":"submit","requestId":"1","payload":{...},"idempotencyKey":"..."}
 *   server -> client  {"type":"ack","requestId":"1"}
 *                     {"type":"reject","requestId":"1","message":"..."}
 *                     {"type":"data","value":...}
 *
 * `data` messages are pushes and carry no request id. Hosts with a different
 * protocol pass a `codec`; the core still performs inbound validation and byte
 * budgeting before any component sees a value.
 *
 * Every runtime session (identified by the adapter's `sessionSignal`) owns one
 * connection. Subscriptions and pending submissions in that session share it;
 * a session that still waits for an ack keeps the connection open after its
 * last subscription leaves. Submits are never replayed, whether after a
 * timeout, a disconnect or a reconnect.
 *
 * The module only touches `WebSocket` (or host-injected factories) when a
 * connection is actually opened, so importing it on the server is safe.
 */
import type { ChannelValidator, Json, JsonPayload, NetworkChannel } from '../network.js';
/** A decoded inbound message. Unknown types are ignored by the adapter. */
export interface DuplexAck {
    readonly type: 'ack';
    readonly requestId: string;
}
export interface DuplexReject {
    readonly type: 'reject';
    readonly requestId: string;
    readonly message?: string;
}
export interface DuplexPush {
    readonly type: 'data';
    readonly value: unknown;
}
export type DuplexInbound = DuplexAck | DuplexReject | DuplexPush;
export interface DuplexSubmit {
    readonly type: 'submit';
    readonly requestId: string;
    readonly payload: JsonPayload;
    readonly idempotencyKey?: string;
}
/**
 * Wire mapping for a duplex channel. `encodeSubmit` returns whatever the
 * transport accepts (`string` or binary). `decode` receives the raw message
 * from the transport and returns a normalized message, or `undefined` to
 * ignore it. Throwing from `decode` is reported as invalid data.
 */
export interface DuplexCodec {
    encodeSubmit(message: DuplexSubmit): unknown;
    decode(raw: unknown): DuplexInbound | undefined;
}
export interface DuplexTimers {
    setTimeout(callback: () => void, delayMs: number): unknown;
    clearTimeout(handle: unknown): void;
}
export interface DuplexReconnectOptions {
    /** First retry delay in milliseconds. Defaults to 1000. */
    readonly delayMs?: number;
    /** Exponential backoff cap in milliseconds. Defaults to 30000. */
    readonly maxDelayMs?: number;
    /** Maximum consecutive attempts. Defaults to unbounded. */
    readonly attempts?: number;
}
export interface DuplexChannelOptions {
    /** Enables submission and authorizes outbound payloads. */
    readonly validateSubmit?: ChannelValidator<JsonPayload>;
    /** Enables subscription and authorizes inbound values. */
    readonly validateSubscribe?: ChannelValidator<Json>;
    /** Encoded JSON byte budget handed to the core. Omitted uses the core default. */
    readonly maxBytes?: number;
    /**
     * Raw inbound message budget in UTF-8 bytes for text and bytes for binary
     * messages. Defaults to 64 KiB and applies before decoding.
     */
    readonly maxMessageBytes?: number;
    /** Defaults to `jsonDuplexCodec`. */
    readonly codec?: DuplexCodec;
    /** How long a sent submit waits for an ack. Defaults to 15000 ms. */
    readonly ackTimeoutMs?: number;
    /**
     * How long one connection attempt may take before it counts as a transport
     * failure. Defaults to 15000 ms.
     */
    readonly connectTimeoutMs?: number;
    /**
     * Reconnect a session's subscription transport after an unexpected close.
     * Disabled by default; a session only reconnects while a subscription is
     * still attached. Submits are never replayed either way.
     */
    readonly reconnect?: boolean | DuplexReconnectOptions;
    /** Timer injection for tests. Defaults to the global timers. */
    readonly timers?: DuplexTimers;
}
/** Minimal structural WebSocket surface used by the adapter. */
export interface DuplexSocketLike {
    send(data: unknown): void;
    close(): void;
    addEventListener(type: string, listener: (event: unknown) => void): void;
    removeEventListener(type: string, listener: (event: unknown) => void): void;
}
export type DuplexSocketFactory = (url: string, protocols: readonly string[]) => DuplexSocketLike;
export interface WebSocketEndpoint {
    readonly url?: string;
    readonly protocols?: string | readonly string[];
}
export interface WebSocketChannelOptions extends DuplexChannelOptions {
    /** Absolute `ws:` or `wss:` URL. */
    readonly endpoint: string;
    /** Subprotocols sent during the upgrade; often used for authentication. */
    readonly protocols?: string | readonly string[];
    /**
     * Resolve the URL and subprotocols for each connection attempt, for example
     * to attach a short-lived token. Runs only on connect, never at import time.
     */
    readonly prepare?: (context: {
        readonly signal: AbortSignal;
    }) => WebSocketEndpoint | Promise<WebSocketEndpoint>;
    /** Injected socket factory for tests or non-browser hosts. */
    readonly webSocket?: DuplexSocketFactory;
}
/** Minimal structural RTCDataChannel surface used by the adapter. */
export interface DuplexDataChannelLike {
    readonly readyState?: string;
    send(data: unknown): void;
    addEventListener(type: string, listener: (event: unknown) => void): void;
    removeEventListener(type: string, listener: (event: unknown) => void): void;
}
/**
 * A data channel borrowed from the host. The adapter never closes it; on
 * teardown it removes its listeners and calls `release`, if provided.
 */
export interface WebRtcPeer {
    readonly channel: DuplexDataChannelLike;
    readonly release?: () => void;
}
export type WebRtcConnect = (endpoint: string, signal: AbortSignal) => WebRtcPeer | Promise<WebRtcPeer>;
export interface WebRtcChannelOptions extends DuplexChannelOptions {
    /** Signaling path or peer identifier handed to `connect`. */
    readonly endpoint: string;
    /**
     * Select a trusted peer and return its data channel. `signal` aborts when
     * the session no longer needs the connection. The host owns signaling,
     * authentication and peer selection.
     */
    readonly connect: WebRtcConnect;
}
export declare const DEFAULT_DUPLEX_ACK_TIMEOUT_MS = 15000;
export declare const DEFAULT_DUPLEX_MESSAGE_BYTES: number;
/** Default JSON wire protocol; see the module comment for the message shapes. */
export declare const jsonDuplexCodec: DuplexCodec;
/** WebSocket channel factory; supports protocols, prepared URLs and auth. */
export declare function webSocketChannel(options: WebSocketChannelOptions): NetworkChannel;
/**
 * WebRTC data-channel factory. The host selects the trusted peer in `connect`
 * and owns everything it hands over; the adapter only detaches listeners and
 * calls `release` on teardown.
 */
export declare function webRtcChannel(options: WebRtcChannelOptions): NetworkChannel;
