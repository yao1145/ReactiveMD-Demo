/**
 * HTTP submission and SSE subscription adapters.
 *
 * This module belongs to the browser layer. It reads `fetch` and `EventSource`
 * lazily when an operation starts, never at import time, and every default is
 * replaceable so tests and non-DOM hosts can inject their own transport.
 *
 * Creating an adapter only validates the host configuration. No request is
 * issued until the runtime calls `send` or `open`; this keeps a document with
 * registered channels free of I/O until a reader submits or a component
 * subscribes.
 */
import type { ChannelValidator, Json, JsonPayload, SubmitAdapter, SubmitAdapterContext, SubmitResult, SubscribeAdapter } from '../network.js';
/** Injected `fetch` replacement: receives the resolved endpoint and init. */
export type HttpFetch = (url: string, init: RequestInit) => Promise<Response>;
/** Request body produced by the default encoder or a host `encode` hook. */
export interface HttpEncodedBody {
    readonly body: string;
    /** Defaults to `application/json`; `null` omits the header. */
    readonly contentType?: string | null;
}
/** The response facts `interpret` receives after a request completes. */
export interface HttpSubmitResponse {
    readonly status: number;
    readonly ok: boolean;
    readonly headers: Headers;
    /** Decoded response text. Empty when there is no response body. */
    readonly text: string;
}
export interface HttpSubmitOptions {
    /** Absolute HTTP(S) URL or a same-origin relative path. */
    readonly endpoint: string;
    /** Applied to the payload before the runtime calls `send`. */
    readonly validate: ChannelValidator<JsonPayload>;
    /** Outbound budget in UTF-8 bytes of the encoded body. Defaults to 64 KiB. */
    readonly maxBytes?: number;
    /** Budget for response bytes delivered to the interpreter. Defaults to 64 KiB. */
    readonly maxResponseBytes?: number;
    /** Deadline for fetching and reading the response, in milliseconds. Defaults to 15000. */
    readonly timeoutMs?: number;
    /** Defaults to `POST`. */
    readonly method?: string;
    /**
     * Static headers, or a per-submission function that can read
     * `requestId` and `idempotencyKey` from the context.
     */
    readonly headers?: Readonly<Record<string, string>> | ((context: SubmitAdapterContext) => Readonly<Record<string, string>>);
    /** Passed to `fetch`; omitted leaves the platform default. */
    readonly credentials?: RequestCredentials;
    /** Defaults to `globalThis.fetch`, read when a submission starts. */
    readonly fetch?: HttpFetch;
    /**
     * Map the validated payload to a request body. The byte budget applies to
     * the returned text. Defaults to `JSON.stringify` with a JSON content type.
     */
    readonly encode?: (payload: JsonPayload, context: SubmitAdapterContext) => HttpEncodedBody;
    /**
     * Business confirmation. Return a result to use it; return `undefined` to
     * fall back to the status rules (2xx confirms, 4xx rejects, anything else is
     * unconfirmed). A success may include validated JSON receipt data selected
     * by the host from the response body.
     */
    readonly interpret?: (response: HttpSubmitResponse) => SubmitResult | undefined;
    /** Header used for `idempotencyKey`; `null` or `''` disables it. Defaults to `Idempotency-Key`. */
    readonly idempotencyHeader?: string | null;
}
/** The subset of an EventSource-compatible client this adapter needs. */
export interface SseEventSourceLike {
    addEventListener(type: string, listener: (event: Event) => void): void;
    removeEventListener(type: string, listener: (event: Event) => void): void;
    close(): void;
    /**
     * 0 / 1 / 2 as in the EventSource spec. Optional, but a client that omits
     * it cannot report a terminal close through an `error` event.
     */
    readonly readyState?: number;
}
export interface SseStreamOptions {
    /** Absolute HTTP(S) URL or a same-origin relative path. */
    readonly endpoint: string;
    /** Applied by the runtime to every decoded message before dispatch. */
    readonly validate: ChannelValidator<Json>;
    /** Early limit in UTF-8 bytes of the raw event text. Defaults to 64 KiB. */
    readonly maxBytes?: number;
    /** Event names to listen for; defaults to `['message']`. */
    readonly events?: readonly string[];
    /** Passed to the built-in `EventSource` constructor. */
    readonly withCredentials?: boolean;
    /**
     * Replace the built-in `EventSource`, for example with a client that sends
     * authorization headers. The adapter never reconnects; clients that own
     * reconnection keep doing so.
     */
    readonly createEventSource?: (url: string) => SseEventSourceLike;
    /** Decode raw event data; defaults to `JSON.parse` for string data. */
    readonly decode?: (data: unknown, event: Event) => unknown;
}
/**
 * Submit one payload with `fetch`.
 *
 * Status rules: a 2xx response confirms; a 4xx response is an explicit
 * rejection; any other received status leaves the outcome ambiguous. A fetch
 * that times out or fails after being called reports `unconfirmed`. When host
 * interpretation is configured, the response body must be readable within
 * the budget to confirm an outcome. Caller or session abort reports `cancelled`.
 */
export declare function httpSubmit(options: HttpSubmitOptions): SubmitAdapter;
/**
 * Subscribe to a server-sent event stream.
 *
 * The adapter decodes each event and hands the value to the runtime, which
 * runs the host validator. It never reconnects; reconnection stays with the
 * EventSource-compatible client. Cancelling the operation or the session
 * removes listeners and closes the client, and the returned disposer is
 * idempotent.
 */
export declare function sseStream(options: SseStreamOptions): SubscribeAdapter;
