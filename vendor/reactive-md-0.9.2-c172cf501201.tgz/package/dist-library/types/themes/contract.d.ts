/** Public styling contract, independent of the document theme-name protocol. */
export declare const LOCAL_STYLE_CONTRACT: 'reactive-md-styles-1';
/** Earlier layers supply the baseline; later layers apply deliberate overrides. */
export declare const LOCAL_STYLE_LAYERS: readonly ["rmd.reset", "rmd.defaults", "rmd.components", "rmd.themes", "rmd.overrides"];
export declare const LOCAL_THEME_STYLE_LAYER: 'rmd.themes';
/** Declare before any resource so module evaluation order cannot reorder layers. */
export declare const LOCAL_STYLE_LAYER_ORDER: string;
