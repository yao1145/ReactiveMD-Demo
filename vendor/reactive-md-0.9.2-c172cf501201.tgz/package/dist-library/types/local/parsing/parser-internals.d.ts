import type { LocalNode } from '../types.js';
import type { LocalDiagnosticDetails } from '../configuration/diagnostics.js';
import type { FastMarkdownContext } from './fast-markdown.js';
export declare const MARK_OPEN: string;
export declare const MARK_CLOSE: string;
export declare const MARK_BOUNDARY: string;
export declare const HTML_NAMES: ReadonlySet<string>;
export declare const BLOCK_HTML_RESULTS: Set<string>;
export declare const NATIVE_HTML_VOID: Set<string>;
export interface Token {
    start: number;
    end: number;
    block?: boolean;
    node: LocalNode;
}
export interface RegionResult {
    tokens: Token[];
    end: number;
    contentEnd: number;
    indent: number;
}
/** Source range of one `[^label]:` definition block. */
export interface DefinitionRange {
    start: number;
    end: number;
}
export interface RegionOptions {
    /** Footnote bodies keep controls, interpolations and math as literal text. */
    footnote?: boolean;
    /** Base indentation removed from continuation lines when converting. */
    indent?: number;
    /** Container bodies use container-aware code fence detection. */
    container?: boolean;
    /** Definition blocks visible to this region. */
    definitions?: readonly DefinitionRange[];
    stripBlockquote?: boolean;
}
export interface ConvertOptions {
    /** Show raw HTML as text instead of diagnosing it (footnote bodies). */
    literalHtml?: boolean;
    /** Strip the enclosing Markdown quote markers before dedenting a note. */
    stripBlockquote?: boolean;
}
export declare class LocalBudgetError extends Error {
    readonly code: string;
    readonly start: number;
    readonly end: number;
    readonly key: string;
    readonly params?: Record<string, string | number | boolean | null> | undefined;
    readonly actual?: number | undefined;
    constructor(code: string, message: string, start: number, end: number, key?: string, params?: Record<string, string | number | boolean | null> | undefined, actual?: number | undefined);
}
export type CreateNode = (type: string, start: number, end: number, extra?: Partial<LocalNode>) => LocalNode;
export type ParseDiagnostic = (code: string, message: string | LocalDiagnosticDetails, start: number, end?: number, details?: LocalDiagnosticDetails) => void;
export type ParseMarkdown = (text: string, tryFast?: boolean, fastContext?: FastMarkdownContext) => any;
