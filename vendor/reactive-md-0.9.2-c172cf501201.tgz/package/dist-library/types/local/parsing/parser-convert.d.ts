import { ParseWorkBudget } from './parse-budget.js';
import { SourceContext } from '../source/source-context.js';
import type { ParserWork } from './parser-core.js';
import { type ConvertOptions, type CreateNode, type ParseDiagnostic, type ParseMarkdown, type Token } from './parser-internals.js';
import type { FastMarkdownPlan } from './fast-markdown.js';
import type { LocalNode } from '../types.js';
interface MarkdownConverterOptions {
    source: string;
    maxSyntaxNodes: number;
    budget: ParseWorkBudget;
    markdownBreaks: boolean;
    isInlineName: (name: string) => boolean;
    sourceContext: SourceContext;
    work: ParserWork;
    parseMarkdown: ParseMarkdown;
    readNodeCount: () => number;
    fastPlans: Set<FastMarkdownPlan>;
    node: CreateNode;
    reservedMarkers: Set<string>;
    sourceBomOffset: number;
    rootMarkdown: any;
    maskedAuthorBody: boolean;
    error: ParseDiagnostic;
}
export declare function createMarkdownConverter({ source, maxSyntaxNodes, budget, markdownBreaks, isInlineName, sourceContext, work, parseMarkdown, readNodeCount, fastPlans, node, reservedMarkers, sourceBomOffset, rootMarkdown, maskedAuthorBody, error, }: MarkdownConverterOptions): (start: number, end: number, tokens: Token[], indent?: number, options?: ConvertOptions) => LocalNode[];
export {};
