import type { NormalizedComponent } from '../configuration/component-kernel.js';
import type { LocalParserHtmlCapability } from './parser-capabilities.js';
import { SourceContext } from '../source/source-context.js';
import { type ConvertOptions, type CreateNode, type ParseDiagnostic, type RegionOptions, type RegionResult, type Token } from './parser-internals.js';
import type { LocalNode } from '../types.js';
interface HtmlNodeContext {
    footnote: boolean;
    container: boolean;
    indent: number;
    stripBlockquote: boolean;
    depth: number;
}
interface TagScannerOptions {
    source: string;
    strict: boolean;
    known: ReadonlyMap<string, NormalizedComponent>;
    htmlSupport?: LocalParserHtmlCapability;
    decodeEntities: (value: string) => string;
    decodeAttribute: (value: string) => string;
    sourceContext: SourceContext;
    node: CreateNode;
    codeEndAt: (offset: number) => number | null;
    error: ParseDiagnostic;
    region: (start: number, end: number, parent?: string, openStart?: number, openEnd?: number, depth?: number, options?: RegionOptions) => RegionResult;
    convert: (start: number, end: number, tokens: Token[], indent?: number, options?: ConvertOptions) => LocalNode[];
}
export declare function createTagScanner({ source, strict, known, htmlSupport, decodeEntities, decodeAttribute, sourceContext, node, codeEndAt, error, region, convert, }: TagScannerOptions): {
    tagAt: (start: number, limit: number) => {
        name: string;
        closing: boolean;
        self: boolean;
        start: number;
        end: number;
        attrs: Record<string, string>;
        head: number;
        unclosed: boolean;
    } | null;
    scanTag: (start: number, limit: number) => {
        name: string;
        closing: boolean;
        self: boolean;
        end: number;
    } | null;
    htmlLiteralEnd: (start: number, limit: number, parent?: string, rawName?: string) => number;
    beginsLine: (offset: number) => boolean;
    footnoteLabelAt: (start: number, limit: number) => {
        label: string;
        identifier: string;
        openEnd: number;
        closeEnd: number;
    } | null;
    definitionLabelAt: (start: number) => {
        label: string;
        identifier: string;
        bodyStart: number;
    } | null;
    htmlTagAt: (start: number, limit: number, tableContext?: boolean) => {
        lower: string;
        closing: boolean;
        self: boolean;
        rest: string;
        attrs: any;
        entries: never[] | import("./html-attributes.js").HtmlAttributeValue[];
        invalid: never[] | import("./html-attributes.js").HtmlAttributeValue[];
        start: number;
        head: number;
        end: number;
    } | null;
    htmlCloseEnd: (start: number, name: string, limit: number, insideContainer: boolean) => {
        start: number;
        end: number;
    } | null;
    selectHtmlAttributes: (lower: string, tag: ReturnType<(start: number, limit: number, tableContext?: boolean) => {
        lower: string;
        closing: boolean;
        self: boolean;
        rest: string;
        attrs: any;
        entries: never[] | import("./html-attributes.js").HtmlAttributeValue[];
        invalid: never[] | import("./html-attributes.js").HtmlAttributeValue[];
        start: number;
        head: number;
        end: number;
    } | null> & {}) => {
        ok: true;
        attrs: Record<string, string>;
    } | {
        ok: false;
        attr: string;
    };
    buildHtmlNode: (tag: {
        lower: string;
        start: number;
        head: number;
        end: number;
    }, close: {
        start: number;
        end: number;
    }, attrs: Record<string, string>, context: HtmlNodeContext) => LocalNode;
    protectedEnd: (i: number, end: number, insideContainer: boolean) => number | null;
    unknownTagEnd: (start: number, name: string, limit: number, insideContainer: boolean, ignoreCase?: boolean) => {
        start: number;
        end: number;
    } | null;
    interpolationEnd: (start: number, end: number) => number;
    commonIndent: (start: number, end: number) => number;
};
export {};
