import type { Diagnostic, LocalNode, LocalRecovery, LocalVersionDeclaration, SourceRange } from '../types.js';
import { ParseWorkBudget } from './parse-budget.js';
import type { NormalizedComponent } from '../configuration/component-kernel.js';
import type { LocalParserHtmlCapability } from './parser-capabilities.js';
import { SourceContext } from '../source/source-context.js';
import type { ParserWork } from './parser-core.js';
import { type ConvertOptions, type CreateNode, type DefinitionRange, type ParseDiagnostic, type ParseMarkdown, type RegionOptions, type RegionResult, type Token } from './parser-internals.js';
import type { createTagScanner } from './parser-tags.js';
export interface DocumentHeaders {
    theme?: string;
    themeRange?: SourceRange;
    themeHeaders: number;
    headerCursor: number;
    versionDeclaration?: LocalVersionDeclaration;
    versionHeaders: number;
}
interface RegionScannerOptions {
    source: string;
    diagnostics: Diagnostic[];
    maxSyntaxNodes: number;
    strict: boolean;
    budget: ParseWorkBudget;
    known: ReadonlyMap<string, NormalizedComponent>;
    externalNames: ReadonlySet<string>;
    unmountedLeafNames: ReadonlySet<string>;
    suggestionNames: string[];
    htmlSupport?: LocalParserHtmlCapability;
    nativeHtmlNames: ReadonlySet<string>;
    sourceContext: SourceContext;
    work: ParserWork;
    ensureDepth: (text: string) => void;
    parseMarkdown: ParseMarkdown;
    node: CreateNode;
    codeRanges: SourceRange[];
    recoveryRanges: readonly SourceRange[];
    recoveries: LocalRecovery[];
    rootMathLiterals: SourceRange[];
    rootDefinitionRanges: DefinitionRange[];
    error: ParseDiagnostic;
    warning: ParseDiagnostic;
    headers: DocumentHeaders;
    scanner: ReturnType<typeof createTagScanner>;
    convert: (start: number, end: number, tokens: Token[], indent?: number, options?: ConvertOptions) => LocalNode[];
}
export declare function createRegionScanner({ source, diagnostics, maxSyntaxNodes, strict, budget, known, externalNames, unmountedLeafNames, suggestionNames, htmlSupport, nativeHtmlNames, sourceContext, work, ensureDepth, parseMarkdown, node, codeRanges, recoveryRanges, recoveries, rootMathLiterals, rootDefinitionRanges, error, warning, headers, scanner, convert, }: RegionScannerOptions): (start: number, end: number, parent?: string, openStart?: number, openEnd?: number, depth?: number, options?: RegionOptions) => RegionResult;
export {};
