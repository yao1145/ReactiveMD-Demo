import type { SourceRange } from '../types.js';
export declare const EXTENDED_HTML_NAMES: ReadonlySet<string>;
/** Native fragments use HTML lexical boundaries even when their text resembles Markdown. */
export declare function opaqueHtmlClose(source: string, from: number, name: string, limit: number): SourceRange | null;
/** Repair the first Markdown code range that crosses a raw author block's end. */
export declare function maskLeakingAuthorBody(source: string, code: readonly SourceRange[], definitions: readonly SourceRange[], registered: {
    has(name: string): boolean;
}, from: number): {
    source: string;
    end: number;
} | undefined;
