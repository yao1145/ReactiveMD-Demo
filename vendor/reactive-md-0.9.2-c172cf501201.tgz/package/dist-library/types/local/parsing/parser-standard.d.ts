import type { MarkdownStructure } from './markdown-blocks.js';
import type { LocalParserCapabilities } from './parser-capabilities.js';
/** Lezer is advisory only: its top-level nodes seed candidate ranges. */
export declare function scanMarkdownStructure(source: string): MarkdownStructure;
/**
 * Parser abilities of the full experience: GFM syntax, native HTML support,
 * isolated HTML repair and Lezer-assisted block planning. The minimal compiler
 * never imports this module.
 */
export declare const STANDARD_PARSER_CAPABILITIES: LocalParserCapabilities;
