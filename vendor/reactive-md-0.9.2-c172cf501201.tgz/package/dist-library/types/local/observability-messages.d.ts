export type LocalObservabilityMessageKey = 'local.worker.timeout' | 'local.worker.error' | 'local.worker.compile' | 'local.worker.compile.detail' | 'local.worker.stale-response' | 'local.export.failure' | 'local.resource.budget';
export declare const LOCAL_OBSERVABILITY_MESSAGES: Readonly<Record<LocalObservabilityMessageKey, Readonly<{
    en: string;
    zh: string;
}>>>;
export declare function formatObservabilityMessage(key: LocalObservabilityMessageKey, locale: 'en' | 'zh', params?: Readonly<Record<string, string | number | boolean>>): string;
