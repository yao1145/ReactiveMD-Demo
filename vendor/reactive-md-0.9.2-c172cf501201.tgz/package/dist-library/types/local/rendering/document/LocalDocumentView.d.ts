import { type LocalDocumentViewProps, type LocalReactiveDocumentProps } from './LocalDocumentViewCore.js';
export { textProblem } from './LocalDocumentViewCore.js';
export type { LocalDocumentViewProps, LocalReactiveDocumentProps, LocalUrlPolicy, LocalImageResolver } from './LocalDocumentViewCore.js';
export declare function LocalDocumentView(props: LocalDocumentViewProps): import("react").JSX.Element;
export declare function LocalReactiveDocument(props: LocalReactiveDocumentProps): import("react").JSX.Element;
