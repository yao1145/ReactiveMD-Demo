import type { Diagnostic, LocalHtmlPolicy } from '../../types.js';
export interface ExtendedHtmlFragmentProps {
    /** Raw fragment source as it appeared in the document, without its fence. */
    source: string;
    /** Effective policy for this mount (compile ceiling ∩ grants). */
    policy: LocalHtmlPolicy;
    /** Exact HTTPS origins this mount may frame; omission denies every remote frame. */
    allowedFrameOrigins?: readonly string[];
    inline?: boolean;
    sourceAttributes?: Record<string, string>;
    onDiagnostics?: (items: Diagnostic[]) => void;
}
/** Render sanitized inert HTML in the document and isolate active fragments. */
export declare function ExtendedHtmlFragment({ source, policy, allowedFrameOrigins, inline, sourceAttributes, onDiagnostics, }: ExtendedHtmlFragmentProps): import("react").JSX.Element;
