import type { LocalNode, SourceRange } from '../types.js';
export interface RawAttribute {
    name: string;
    nameRange: SourceRange;
    /** Content between the quotes, without the quotes themselves. */
    valueRange?: SourceRange;
    quoteStart?: number;
    quoteEnd?: number;
    unquoted?: boolean;
}
export interface RawTag {
    start: number;
    /** Offset just past `>`. */
    end: number;
    /** Offset of `>`. */
    contentEnd: number;
    name: string;
    nameRange: SourceRange;
    closing: boolean;
    selfClosing: boolean;
    attrs: RawAttribute[];
}
export declare function readTagAt(source: string, start: number): RawTag | null;
export declare function closingTagOf(source: string, node: LocalNode, openingEnd: number): RawTag | null;
export interface RawInterpolation {
    /** Start of `{{`. */
    start: number;
    /** Offset just past `}}`. */
    end: number;
    innerStart: number;
    innerEnd: number;
}
/** Mirrors the compiler's attribute-template scanner, including `\{{` escapes. */
export declare function rawInterpolations(source: string, start: number, end: number): RawInterpolation[];
/** Attribute decoding matches the parser while retaining original boundaries. */
export declare function decodedAttribute(source: string, range: SourceRange): {
    text: string;
    offsets: number[];
};
export interface IdentifierRange {
    name: string;
    range: SourceRange;
}
/** Identifiers that are real references: strings, literals, functions are skipped. */
export declare function expressionIdentifiers(source: string, start: number, end: number): IdentifierRange[];
export declare function isIdentifierStart(character: string | undefined): boolean;
export declare function isIdentifierPart(character: string | undefined): boolean;
export declare function isWhitespace(character: string | undefined): boolean;
