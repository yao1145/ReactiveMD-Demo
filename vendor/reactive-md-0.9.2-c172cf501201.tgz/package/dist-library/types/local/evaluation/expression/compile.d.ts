import type { LocalValue, LocalValueKind } from '../../types.js';
export interface LocalExpression {
    readonly source: string;
    readonly dependencies: string[];
    evaluate(env: Record<string, LocalValue>): LocalValue;
    inferType(env: Record<string, LocalValueKind>): LocalValueKind;
}
/**
 * Offset, relative to `expression.source`, of the first reference token that
 * reads `name`. Unlike a text search it never lands inside a string literal.
 * Returns `undefined` for names that are not dependencies or for expressions
 * not created by `compileExpression`. Internal; not part of the package API.
 */
export declare function expressionDependencyOffset(expression: LocalExpression, name: string): number | undefined;
export declare function compileExpression(source: string): LocalExpression;
/** Render a template to scalar text. Arrays are rejected rather than serialized. */
export declare function interpolate(template: string, env: Record<string, LocalValue>): string;
/**
 * Evaluate a template that is exactly one interpolation, preserving its type.
 * Mixed templates and plain text fall back to text rendering.
 */
export declare function expressionValue(template: string, env: Record<string, LocalValue>): LocalValue;
/**
 * Binding keys read by the `{{ }}` expressions of a template, deduplicated in
 * first-occurrence order. Malformed templates or expressions throw; callers
 * that only need a static scan treat a throw as undecidable.
 */
export declare function templateDependencies(template: string): string[];
export { LocalExpressionError, BUILTIN_SET, CONSTANTS, FORBIDDEN_NAMES, VALID_KINDS, RESERVED_NAMES, MAX_AST_NODES, MAX_PARSE_DEPTH, MAX_AST_DEPTH, MAX_EVAL_STEPS, MAX_EVAL_DEPTH, MAX_STRING_LENGTH, arrayValueProblem, localValueBudgetIssue, localValueBudgetError } from "./values.js";
export type { BuiltinName } from "./values.js";
