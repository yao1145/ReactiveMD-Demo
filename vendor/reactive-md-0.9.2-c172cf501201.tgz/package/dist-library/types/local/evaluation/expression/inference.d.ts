import type { LocalValue, LocalValueKind } from '../../types.js';
import type { Ast } from './syntax.js';
export declare function literalKind(value: LocalValue): LocalValueKind;
export declare function inferAst(ast: Ast, env: Record<string, LocalValueKind>): LocalValueKind;
