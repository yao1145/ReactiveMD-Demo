import type { LocalValue } from '../../types.js';
import type { Ast } from './syntax.js';
export declare function evalAst(ast: Ast, env: Record<string, LocalValue>): LocalValue;
