import type { LocalValue } from '../../types.js';
import type { Ast } from './latex.js';
export interface Evaluation {
    x: number;
    env: Record<string, LocalValue>;
    steps: number;
    limit: number;
    depth: number;
}
export declare function evaluateAst(node: Ast, state: Evaluation): number;
