import type { LocalValue, SourceRange } from '../../types.js';
export interface LatexExpression {
    readonly source: string;
    dependencies: string[];
    evaluate(x: number, env: Record<string, LocalValue>, budget?: LatexEvaluationBudget): number;
}
/** Shared step budget used by samplePlot so the whole curve has one bound. */
export interface LatexEvaluationBudget {
    steps: number;
    limit: number;
}
export interface PlotPoint {
    x: number;
    y: number | null;
    /** Parameter value for parametric curves; absent for explicit and implicit curves. */
    t?: number;
    /** Angle in radians for polar curves. */
    theta?: number;
}
export interface PlotSample {
    points: PlotPoint[];
    endpoint: number | null;
}
/** A point on an implicit contour; both coordinates are defined. */
export interface PlotSegmentPoint {
    x: number;
    y: number;
}
/** One formula block inside a plot, ready for sampling. */
export type PlotFormulaKind = 'explicit' | 'parametric' | 'polar' | 'implicit';
export interface CompiledPlotFormula {
    kind: PlotFormulaKind;
    source: string;
    /** Explicit y(x), parametric x(t), polar r(theta), or implicit F(x, y). */
    expression: LatexExpression;
    /** Parametric y(t); null for the other kinds. */
    yExpression: LatexExpression | null;
    /** Document parameters only; each curve's independent variables are removed. */
    dependencies: string[];
}
export type Relation = 'eq' | 'ne' | 'lt' | 'le' | 'gt' | 'ge';
export type CallName = 'sin' | 'cos' | 'tan' | 'arcsin' | 'arccos' | 'arctan' | 'exp' | 'ln' | 'log' | 'min' | 'max' | 'sqrt';
export interface When {
    op: Relation;
    left: Ast;
    right: Ast;
}
export interface CaseBranch {
    value: Ast;
    when: When | null;
}
export type Ast = {
    kind: 'number';
    value: number;
    offset: number;
} | {
    kind: 'constant';
    value: 'pi' | 'e';
    offset: number;
} | {
    kind: 'variable';
    name: string;
    offset: number;
} | {
    kind: 'unary';
    op: '-' | '+';
    operand: Ast;
    offset: number;
} | {
    kind: 'binary';
    op: '+' | '-' | '*' | '/' | '^';
    left: Ast;
    right: Ast;
    offset: number;
} | {
    kind: 'abs';
    value: Ast;
    offset: number;
} | {
    kind: 'call';
    name: CallName;
    args: Ast[];
    base: Ast | null;
    power: Ast | null;
    offset: number;
} | {
    kind: 'cases';
    branches: CaseBranch[];
    offset: number;
};
/** Internal authoring support: only AST variable nodes represent plot reads. */
export declare function localLatexReferences(source: string): {
    name: string;
    range: SourceRange;
}[];
export declare function compileLatex(source: string): LatexExpression;
/** Cheap classification used before compiling and sampling a plot block. */
export declare function plotFormulaKind(source: string): PlotFormulaKind | null;
/**
 * Classifies one plot formula block.
 *
 * - `y = f(x)` is an explicit curve.
 * - `\begin{cases} x = f(t) \\ y = g(t) \end{cases}` is a parametric curve.
 * - `r = f(\theta)` is a polar curve, with theta local to the curve.
 * - Any other equation in x and y is implicit and traced as `left - right = 0`.
 */
export declare function compilePlotFormula(source: string): CompiledPlotFormula;
/** Upper bound for the per-axis grid used to trace an implicit equation. */
export declare const MAX_IMPLICIT_GRID = 100;
/** Minimum grid resolution; smaller `samples` values are raised to this. */
export declare const MIN_IMPLICIT_GRID = 32;
/** Grid cells per axis for an implicit curve at a given plot sample count. */
export declare function implicitGridSize(samples: number): number;
export { LatexError } from './syntax.js';
