import type { CompileState } from './compiler-services.js';
import { type LocalExpression } from '../evaluation/expression/compile.js';
import type { LocalBinding, LocalValue, LocalValueKind } from '../types.js';
import { type KernelRule } from '../configuration/component-kernel.js';
import type { AttrMap, AttrState } from './compiler-structure.js';
export declare function validateExpressions(state: CompileState): void;
/**
 * Validate static navigation targets after bindings are known: heading slugs
 * can depend on initial interpolation values, and explicit anchors must be
 * unique with each other and with heading targets.
 */
export declare function validateNavigation(state: CompileState, bindings: Record<string, LocalBinding>, initialState: Record<string, LocalValue>): void;
interface ScopedExpression {
    compiled: LocalExpression;
    /** Null when dependencies were missing or inference was not requested. */
    kind: LocalValueKind | null;
}
/**
 * Compile one expression against a caller-provided type environment. Used by
 * the row scope of data tables and by validation rules; ordinary attributes
 * keep using the document environment in validateExpressions.
 */
export declare function validateScopedExpression(state: CompileState, expression: string, base: number, env: Record<string, LocalValueKind>, infer: boolean): ScopedExpression | null;
/** Require a whole-value `{{ expression }}` attribute; returns its expression. */
export declare function fullExpressionAttribute(info: AttrState | undefined, code: string, component: string, attribute: string, state: CompileState): {
    expression: string;
    base: number;
} | null;
export declare function dataTableMaxRows(attrs: AttrMap, rule: Extract<KernelRule, {
    kind: 'data-table';
}>): number;
export {};
