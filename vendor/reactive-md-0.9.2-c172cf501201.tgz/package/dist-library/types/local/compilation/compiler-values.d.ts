import type { LocalNode, LocalValue, LocalValueKind } from '../types.js';
import type { AttrMap, Entry } from './compiler-structure.js';
import type { CompileState } from './compiler-services.js';
import { type KernelBindingSchema, type KernelNumericConstraints } from '../configuration/component-kernel.js';
import type { Group, GroupMember } from './compiler-bindings.js';
export declare function parseNumberText(raw: string): number | null;
export declare function meaningful(nodes: LocalNode[] | undefined): LocalNode[];
export declare function hasComponent(node: LocalNode): boolean;
/** Static numeric attribute value, or the manifest prop default. */
export declare function numberValue(entry: Entry, attrs: AttrMap, name: string | undefined): number | undefined;
/** Static string attribute value, or the manifest prop default. */
export declare function staticAttributeString(entry: Entry, attrs: AttrMap, name: string | undefined): string | undefined;
export declare function plainText(node: LocalNode): string;
export declare function hasInterpolation(node: LocalNode): boolean;
export declare function typeName(kind: LocalValueKind): string;
export declare const IDENTIFIER: RegExp;
export declare function singleFullInterpolation(value: string): boolean;
interface ScanSegment {
    expression: string;
    start: number;
    end: number;
}
/** Locate `{{ ... }}` segments inside a decoded attribute value. */
export declare function scanInterpolations(value: string): {
    segments: ScanSegment[];
    unterminated: number[];
};
export declare function fullInterpolation(value: string): {
    expression: string;
    start: number;
} | null;
export declare function suggestName(name: string, candidates: string[]): string | undefined;
/** Environment used by ordinary expressions: writable parameters plus read-only computations and externals. */
export declare function expressionEnv(state: CompileState): Record<string, LocalValueKind>;
/** Longer names are rejected before suggestion/edit-distance work. */
export declare const MAX_LOCAL_NAME_LENGTH = 128;
export declare function cloneValue(value: LocalValue): LocalValue;
export type NumericConstraints = KernelNumericConstraints;
export declare function numericConstraints(entry: Entry, attrs: AttrMap): NumericConstraints;
/**
 * A shared string binding must satisfy every owner's runtime value rules.
 * Empty values stay allowed at compile time so an optional required input can
 * still start empty; writes are enforced by the runtime.
 */
export declare function validateStaticInitial(group: Group, initial: LocalValue, state: CompileState, initialOffset?: number): void;
export declare function validateInitialValue(group: Group, first: GroupMember, value: LocalValue, binding: KernelBindingSchema, options: string[], constraints: NumericConstraints | undefined, state: CompileState): void;
export {};
