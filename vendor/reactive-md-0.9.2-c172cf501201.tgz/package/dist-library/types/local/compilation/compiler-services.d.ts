import type { Diagnostic, LocalCompileOptions, LocalComputation, LocalDynamicConstraints, LocalExternal, LocalHtmlPolicy, LocalMathDisplayIssue, LocalNode, LocalValueKind } from '../types.js';
import { type SourceContext } from '../source/source-context.js';
import type { InlinePlanLookup } from '../parsing/fast-markdown.js';
import type { ParsedLocal } from '../parsing/parser-core.js';
import type { LocalExpression } from '../evaluation/expression/compile.js';
import type { CompiledPlotFormula, LatexExpression, PlotFormulaKind } from '../evaluation/math/latex.js';
import type { Entry, StructureState } from './compiler-structure.js';
import type { LocalComponentDefinition } from '../../sdk/types.js';
import type { TableShape } from './compiler-tables.js';
import { type LocalDiagnosticDetails } from '../configuration/diagnostics.js';
/** Parser entry used by tracked compiles; the session owns the cache. */
export interface LocalCompilerParserService {
    parse(source: string, options?: LocalCompileOptions, context?: SourceContext, rowPlans?: InlinePlanLookup): ParsedLocal;
}
/**
 * Successful semantic products from previous revisions. Every method must be
 * a pure lookup or store keyed by source text or validated attributes; errors
 * are still reported against the current source, never replayed.
 */
export interface LocalCompilerSemanticService {
    expression(source: string): LocalExpression;
    infer(expression: LocalExpression, environment: Record<string, LocalValueKind>): LocalValueKind;
    attributes<T>(key: string): {
        value: T;
        origin: number;
    } | undefined;
    rememberAttributes(key: string, origin: number, value: unknown): void;
    binding<T>(key: string): T | undefined;
    rememberBinding(key: string, value: unknown): void;
    latex(source: string): LatexExpression;
}
/** Optional KaTeX display precheck; compat and standard keep the full check. */
export type LocalMathDisplayInspector = (source: string, block: boolean) => readonly LocalMathDisplayIssue[];
export interface SemanticCacheStats {
    expressionsCompiled: number;
    expressionsReused: number;
    typesInferred: number;
    typesReused: number;
    attributesValidated: number;
    attributesReused: number;
    bindingsResolved: number;
    bindingsReused: number;
    formulasCompiled: number;
    formulasReused: number;
    displaysInspected: number;
    displaysReused: number;
    entries: number;
}
/** Session cache operations used by the tracked compile entry. */
export interface LocalTrackedSemanticService extends LocalCompilerSemanticService {
    begin(key: string): void;
    display: LocalMathDisplayInspector;
    readonly stats: SemanticCacheStats;
}
/** Optional whole-document HTML sanitizer for the native HTML branch. */
export type LocalHtmlDocumentSanitizer = (source: string, policy: LocalHtmlPolicy, maxSyntaxNodes: number) => {
    markup: string;
    diagnostics: Diagnostic[];
};
export type LocalHtmlFragmentSanitizer = (source: string, policy: LocalHtmlPolicy, maxSyntaxNodes: number) => {
    markup?: string;
    diagnostics: Diagnostic[];
};
/** Optional plot-formula compiler; omitted assemblies reject plot formulas. */
export interface LocalCompilerPlotMath {
    kind(source: string): PlotFormulaKind | null;
    gridSize(samples: number): number;
    compile(source: string): CompiledPlotFormula;
}
/** Optional execution goods for one compile; all fields are independent. */
export interface LocalCompilerCoreServices {
    parser?: LocalCompilerParserService;
    semantic?: LocalCompilerSemanticService;
    /**
     * Per-row inline plans from the previous revision. Checked before the
     * session LRU so large sequential row blocks cannot thrash it.
     */
    rowPlans?: InlinePlanLookup;
    display?: LocalMathDisplayInspector;
    /** Extended HTML fragment service; absent in the minimal assembly. */
    htmlFragment?: LocalHtmlFragmentSanitizer;
    /** Plot formula semantics; absent in the minimal assembly. */
    plotMath?: LocalCompilerPlotMath;
}
export interface CompileState extends StructureState {
    semantic?: LocalCompilerSemanticService;
    /** Optional KaTeX display precheck; absent in the minimal core entry. */
    display?: LocalMathDisplayInspector;
    /** Extended HTML fragment service; absent in the minimal assembly. */
    htmlFragment?: LocalHtmlFragmentSanitizer;
    /** Optional plot formula semantics; absent in the minimal core entry. */
    plotMath?: LocalCompilerPlotMath;
    source: string;
    lineStarts: number[];
    nodes: LocalNode[];
    diagnostics: Diagnostic[];
    definitionsByName: ReadonlyMap<string, LocalComponentDefinition>;
    entries: Entry[];
    tableShapes: Map<string, TableShape | null>;
    bindingSlots: Record<string, Record<string, string>>;
    bindingKinds: Record<string, LocalValueKind>;
    computationKinds: Record<string, LocalValueKind>;
    computations: Record<string, LocalComputation>;
    externals: Record<string, LocalExternal>;
    externalKinds: Record<string, LocalValueKind>;
    dynamicConstraints: Record<string, LocalDynamicConstraints>;
    expressionKinds: Map<string, LocalValueKind | null>;
}
/** Host schemas are validated before parsing; an unmatched node only warns. */
export declare function reportWarning(state: CompileState, code: string, message: string | LocalDiagnosticDetails, start: number, end?: number, details?: LocalDiagnosticDetails): void;
