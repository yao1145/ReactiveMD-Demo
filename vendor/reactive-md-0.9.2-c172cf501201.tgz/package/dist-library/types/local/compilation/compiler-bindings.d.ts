import { type AttrMap, type Entry } from './compiler-structure.js';
import { type KernelBindingSchema } from '../configuration/component-kernel.js';
import type { CompileState } from './compiler-services.js';
import type { LocalBinding, LocalValueKind } from '../types.js';
/** Bind names that cannot be used because they are literals or plot variables. */
export declare const EXTRA_RESERVED: Set<string>;
export interface GroupMember {
    entry: Entry;
    attrs: AttrMap;
}
export interface Group {
    key: string;
    binding: KernelBindingSchema;
    members: GroupMember[];
}
export declare function requireBindingAttribute(entry: Entry, binding: KernelBindingSchema, attrs: AttrMap, state: CompileState): void;
export declare function resolveBindings(state: CompileState): Record<string, LocalBinding>;
export declare function bindingKinds(bindings: Record<string, LocalBinding>): Record<string, LocalValueKind>;
export declare function lineAt(state: CompileState, offset: number): number;
