import type { CompileState } from './compiler-services.js';
import type { LocalValidation } from '../types.js';
/**
 * Validate every component declaring a `data-table` rule and sum document
 * budgets. Rows use the ordinary global environment; `key` and the child value
 * attribute additionally see the immutable row locals `item`/`index`.
 */
export declare function validateDataTables(state: CompileState): void;
/**
 * Validate `<validation>` rules and build their source-ordered metadata. The
 * tag itself stays in the tree so the renderer can place the hint; unlike
 * `<computed>`, it is not stripped.
 */
export declare function validateValidations(state: CompileState): LocalValidation[];
export declare function validatePlots(state: CompileState): void;
