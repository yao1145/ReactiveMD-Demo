import type { LocalBinding, LocalNode, LocalValue } from '../types.js';
import { type NormalizedComponent } from '../configuration/component-kernel.js';
import { type KernelValueRule } from '../configuration/kernel-value-rules.js';
import { type LocalComponentDefinition, type LocalExtensionRequirements } from '../../sdk/types.js';
import type { LocalDiagnosticDetails } from '../configuration/diagnostics.js';
import type { CompileState } from './compiler-services.js';
export interface AttrState {
    raw: string;
    value?: LocalValue;
    dynamic: boolean;
    expression?: string;
    offset: number;
    expressionOffset?: number;
}
export type AttrMap = Record<string, AttrState>;
export interface Entry {
    node: LocalNode;
    name: string;
    kernel: NormalizedComponent;
    definition?: LocalComponentDefinition;
    legacy: boolean;
    parent: Entry | null;
}
export interface ChecklistInfo {
    ids: string[];
    checked: string[];
}
export type ReportDiagnostic = (code: string, message: string | LocalDiagnosticDetails, start: number, end?: number, details?: LocalDiagnosticDetails) => void;
/**
 * Minimal state the structure pass reads and writes. `CompileState` extends
 * this view so the compiler and the pass share one state shape.
 */
export interface StructureState {
    /** Unified registry used for every component node in this compile. */
    readonly schemaByName: ReadonlyMap<string, NormalizedComponent>;
    readonly report: ReportDiagnostic;
    readonly attrs: Map<string, AttrMap>;
    readonly options: Map<string, string[]>;
    readonly tabs: Map<string, string[]>;
    readonly steps: Map<string, string[]>;
    readonly selections: Map<string, string[]>;
    readonly diagramNodes: Map<string, string[]>;
    readonly checklists: Map<string, ChecklistInfo>;
    readonly tables: Map<string, LocalNode>;
}
export declare function projectionMap(state: StructureState, kind: 'options' | 'tabs' | 'steps' | 'diagram-nodes'): Map<string, string[]>;
export declare function validateChildren(entry: Entry, state: StructureState): void;
export declare function validateChecklist(entry: Entry, state: StructureState, itemLimit?: number): ChecklistInfo;
export declare function collectLegacyFences(nodes: LocalNode[]): LocalNode[];
export declare function collectEntries(nodes: LocalNode[], parent: Entry | null, out: Entry[], state: CompileState): void;
/**
 * Requirements for external components actually used by the document. A
 * configured component that never appears in the source contributes nothing,
 * so restoring a document only needs the implementations it really references.
 */
export declare function extensionRequirements(nodes: LocalNode[], sdkByName: ReadonlyMap<string, LocalComponentDefinition>): LocalExtensionRequirements | undefined;
/** Lower manifest rules to the serializable metadata the runtime consumes. */
export declare function compileKernelMetadata(state: CompileState, bindings: Record<string, LocalBinding>): {
    valueRules: Record<string, readonly KernelValueRule[]>;
    slotRelations: readonly {
        nodeId: string;
        lower: string;
        upper: string;
    }[];
    retentionExclusions: readonly string[];
    bindingAttributes?: Record<string, {
        bind: string;
        initial: string;
    }>;
    dependencyRules?: Record<string, {
        selfBinding?: {
            mode: 'always' | 'attribute';
            attribute?: string;
        };
        inlineMathReads?: boolean;
    }>;
};
/** Distinct manifests referenced by the compiled document, in first-use order. */
export declare function componentDefinitionsFor(state: CompileState): LocalComponentDefinition[];
/** Host-shaped nodes with no registry entry warn instead of failing the document. */
export declare function reportUnmatchedHostComponents(nodes: LocalNode[], state: CompileState): void;
