import type { LocalDocumentCapabilities, LocalHtmlPolicy } from '../types.js';
import { type CompileState } from './compiler-services.js';
export declare function compileDocumentCapabilities(state: CompileState, policy: LocalHtmlPolicy, maxSyntaxNodes: number): LocalDocumentCapabilities | undefined;
