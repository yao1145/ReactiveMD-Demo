import type { CompileState } from './compiler-services.js';
import type { LocalBinding, LocalNode } from '../types.js';
/**
 * Resolve the independent, exclusive slot bindings of `<range-slider>` and
 * `<coordinate>`. Each slot registers its own binding key, so `setMany` can
 * update the slots atomically while `bindingSlots` tells the renderer which
 * slot maps to which public parameter.
 */
export declare function resolveSlotBindings(state: CompileState, bindings: Record<string, LocalBinding>): void;
export declare function slotMap(state: CompileState): Record<string, Record<string, string>> | undefined;
/**
 * Resolve top-level `<computed>` and `<const>` declarations into document
 * metadata. Namespace checks happen here because both controls and slot
 * bindings are already resolved; the graph walk and type inference live in
 * `computations.ts`.
 */
export declare function resolveComputations(state: CompileState): void;
/** Declaration tags never reach the published tree; they are metadata only. */
export declare function stripDeclarationNodes(nodes: LocalNode[]): LocalNode[];
/**
 * Resolve top-level `<external>` declarations into read-only document metadata.
 * Names share the expression namespace with controls and computations but are
 * never writable: they do not enter `bindings`, public parameters or state
 * files.
 */
export declare function resolveExternals(state: CompileState): void;
/**
 * Record dynamic `min`, `max` and `required` expressions for the runtime. Any
 * attribute named by a manifest `dynamic-constraints` rule or by a numeric
 * binding constraint prop is eligible; tag names play no part.
 */
export declare function collectDynamicConstraints(state: CompileState): void;
