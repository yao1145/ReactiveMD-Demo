import type { LocalDocument, LocalNode, LocalValueKind } from '../types.js';
import type { AttrMap, Entry, ReportDiagnostic } from './compiler-structure.js';
/** Only the state consumed by table validation and selection projection. */
interface TableCompileState {
    readonly entries: Entry[];
    readonly attrs: Map<string, AttrMap>;
    readonly tables: Map<string, LocalNode>;
    readonly tableShapes: Map<string, TableShape | null>;
    readonly selections: Map<string, string[]>;
    readonly expressionKinds: Map<string, LocalValueKind | null>;
    readonly report: ReportDiagnostic;
}
export interface TableShape {
    header: string[];
    rows: LocalNode[][];
}
export declare function validateTables(state: TableCompileState): void;
/**
 * Projects the compiler's table shapes onto the document as plain, frozen
 * data. Only header text and cell node ids are kept, so the persisted form is
 * serializable and never references nodes or forms cycles.
 */
export declare function attachTableShapes(document: LocalDocument, shapes: Map<string, TableShape | null>): void;
/**
 * Turn the `key` column of a table/chart into the stable selection options used
 * by its optional `bind`. Selection is only compiled when `key` is present, so
 * old documents keep the renderer's internal selection state.
 */
export declare function computeSelections(state: TableCompileState): void;
export {};
