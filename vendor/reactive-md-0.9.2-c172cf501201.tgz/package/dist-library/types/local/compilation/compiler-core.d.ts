import { type ParsedLocal } from '../parsing/parser-core.js';
import { type LocalCompileOptions, type LocalCompileResult, type SourceRange } from '../types.js';
import { type LocalOptionCheck } from '../configuration/options-core.js';
import { type LocalCompilerCoreServices, type LocalHtmlDocumentSanitizer } from './compiler-services.js';
/**
 * Whole-document native HTML branch. The Markdown parser, components,
 * expressions, computations and bindings are all bypassed; the source only
 * becomes grammar-aware sanitized HTML for an isolated `srcdoc` iframe.
 */
export declare function compileLegacyHtmlLocal(source: string, check: Extract<LocalOptionCheck, {
    ok: true;
}>, sanitize: LocalHtmlDocumentSanitizer): LocalCompileResult;
/**
 * The single reference compiler pass. Options must already be validated; the
 * validated `optionCheck` is the option snapshot this pass reads, so later
 * mutation of the caller's options object cannot change compilation semantics.
 *
 * `services` carries optional execution goods (session parser, semantic
 * products, row plans, KaTeX display inspector). Omitting them keeps the same
 * semantic flow, only without cross-revision reuse and optional checks.
 */
export declare function compileLocalCore(source: string, options: LocalCompileOptions | undefined, optionCheck: Extract<LocalOptionCheck, {
    ok: true;
}>, services?: LocalCompilerCoreServices, capture?: (tree: ParsedLocal) => void, mark?: (name: string) => void, literalRanges?: readonly SourceRange[]): LocalCompileResult;
