import type { CompileState } from './compiler-services.js';
import type { AttrMap, Entry } from './compiler-structure.js';
/** Slice only the opening tag so attribute lookup never rescans component content. */
export declare function openingTag(source: string, start: number, end: number): string;
export declare function validateAttributes(entry: Entry, state: CompileState): AttrMap;
/** A binding step referenced by a prop must be static and positive. */
export declare function validateBindingConstraintAttributes(entry: Entry, state: CompileState): void;
export declare function validateAttributeRelations(entry: Entry, state: CompileState): void;
