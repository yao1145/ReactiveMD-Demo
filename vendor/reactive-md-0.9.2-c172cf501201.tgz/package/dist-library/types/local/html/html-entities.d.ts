/**
 * Decode character references with the browser grammar, never activating
 * markup. This is the shared implementation for the strict HTML parser and
 * the isolated HTML repair pass; `replaceNul` keeps the result free of NUL
 * characters. NUL is replaced before parse5 sees it, which would otherwise drop
 * a raw NUL from text, so the result does not depend on whether `&` occurs.
 */
export declare function decodeLocalHtmlEntities(value: string, replaceNul?: boolean): string;
/**
 * Decode an attribute value with the attribute-value grammar: a legacy named
 * reference without `;` followed by `=` or an ASCII alphanumeric stays literal
 * (`?a=1&copy=2` keeps `&copy`). The raw value comes from a quoted or unquoted
 * attribute; `"` is re-encoded so the probe element always parses as one
 * double-quoted attribute and reference boundaries are unchanged.
 */
export declare function decodeLocalHtmlAttribute(raw: string): string;
