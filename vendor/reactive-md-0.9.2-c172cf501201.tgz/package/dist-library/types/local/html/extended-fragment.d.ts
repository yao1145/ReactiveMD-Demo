import type { Diagnostic, LocalHtmlPolicy } from '../types.js';
import { type LocalHtmlFragmentResult } from './html.js';
/**
 * Extended HTML fragments reuse the whole-document sanitizer rather than a
 * second policy: same element allow-list, attribute rules, URL schemes, script
 * and style gates, and node budget. The differences are structural — a
 * fragment is parsed in body context, keeps no document shell, and a remote
 * `iframe` is only honored for an exact HTTPS origin granted by the host.
 */
/** Result of sanitizing one fragment; `markup` is absent when nothing is renderable. */
export type ExtendedFragmentResult = LocalHtmlFragmentResult;
/**
 * Sanitize one extended HTML fragment for isolated rendering.
 *
 * `policy` is the effective mount policy (compile ceiling intersected with the
 * caller's grants). The host grant list is the permission table for remote
 * frames and defaults to empty: without an explicit origin, no remote frame is
 * kept (and `frame-src` admits only `about:`). Diagnostics keep fragment
 * offsets so the editor can navigate to the offending attribute or element.
 */
export declare function sanitizeExtendedFragment(source: string, policy: LocalHtmlPolicy, maxSyntaxNodes: number, allowedFrameOrigins?: readonly string[]): ExtendedFragmentResult;
/**
 * Complete sandbox `srcdoc` for one fragment: trusted head plus sanitized body.
 * A fragment may hold active markup, so it never reaches the host document
 * directly; the renderer assigns this string to an iframe whose sandbox tokens
 * come from `extendedFragmentSandbox`.
 */
export declare function extendedFragmentDocument(markup: string, policy: LocalHtmlPolicy, allowedFrameOrigins?: readonly string[]): string;
/** Sandbox tokens for the fragment container; never same-origin or top-level navigation. */
export declare function extendedFragmentSandbox(policy: LocalHtmlPolicy): string;
/**
 * Compiler-service adapter matching `LocalHtmlDocumentSanitizer`.
 *
 * The compiler decides whether a fragment is admissible and records its
 * structural diagnostics. Remote frame origins are a mount policy, so they are
 * not evaluated here: the mount-time sanitizer applies the host grant list.
 */
export declare function sanitizeExtendedHtmlFragmentService(source: string, policy: LocalHtmlPolicy, maxSyntaxNodes: number): {
    markup: string;
    diagnostics: Diagnostic[];
};
