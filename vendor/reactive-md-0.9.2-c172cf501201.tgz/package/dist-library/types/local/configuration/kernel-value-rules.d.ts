import { type KernelComponentSchema, type KernelDiagnosticIssue } from './component-kernel.js';
import type { LocalNode } from '../types.js';
export type KernelValueRule = {
    kind: 'date';
    min?: string;
    max?: string;
    required?: string;
} | {
    kind: 'length';
    min?: string;
    max?: string;
    email?: string;
    emailType?: string;
} | {
    kind: 'required';
    required: string;
} | {
    kind: 'email';
    type: string;
    value: string;
};
export interface KernelDocumentMetadata {
    readonly valueRules: Readonly<Record<string, readonly KernelValueRule[]>>;
    readonly slotRelations: readonly {
        nodeId: string;
        lower: string;
        upper: string;
    }[];
    readonly retentionExclusions: readonly string[];
    /** Authored bind/initial attribute names per public binding. */
    readonly bindingAttributes?: Readonly<Record<string, {
        readonly bind: string;
        readonly initial: string;
    }>>;
    /** Dependency-display capabilities per component node. */
    readonly dependencyRules?: Readonly<Record<string, {
        readonly selfBinding?: {
            readonly mode: 'always' | 'attribute';
            readonly attribute?: string;
        };
        readonly inlineMathReads?: boolean;
    }>>;
}
/** Lower a component's runtime value rules; compile-time rules are ignored. */
export declare function kernelValueRules(schema: KernelComponentSchema): readonly KernelValueRule[];
/** The serialized kernel metadata a compiled document carries. */
export declare function kernelDocumentMetadata(document: unknown): KernelDocumentMetadata | undefined;
export declare function isKernelAnchorId(value: string): boolean;
export interface KernelNavigationTarget {
    name: string;
    target: string;
    offset: number;
}
/**
 * Check navigation targets against known anchors and heading slugs. Rules pick
 * the target attribute; the algorithm is shared by every declaring component.
 */
export declare function kernelNavigationIssues(targets: readonly KernelNavigationTarget[], explicit: ReadonlySet<string>, headings: ReadonlySet<string>): KernelDiagnosticIssue[];
export declare const KERNEL_LIMITS: Readonly<{
    arrayLength: 10000;
    dataTableColumns: 20;
    plotCurves: 16;
    plotPoints: 20000;
}>;
export declare function kernelMeaningfulChildren(nodes: readonly LocalNode[] | undefined): LocalNode[];
export declare function kernelHasComponent(node: LocalNode): boolean;
