/** Binding, expression and runtime diagnostic templates. */
export declare const LOCAL_RUNTIME_DIAGNOSTIC_MESSAGES: {
    readonly 'budget.identifier': {
        readonly en: 'Parameter name exceeds the {limit}-character limit.';
        readonly zh: '参数名超过 {limit} 个字符的上限。';
    };
    readonly 'binding.nameInvalid': {
        readonly en: 'Parameter name "{name}" must match [A-Za-z_][A-Za-z0-9_]*.';
        readonly zh: '参数名“{name}”必须匹配 [A-Za-z_][A-Za-z0-9_]*。';
    };
    readonly 'binding.reserved': {
        readonly en: 'Parameter name "{name}" is reserved; choose another name.';
        readonly zh: '参数名“{name}”是保留名称；请换一个名称。';
    };
    readonly 'binding.typeConflict': {
        readonly en: 'Parameter "{key}" is already declared as {kind} by <{first}> and cannot also bind <{second}>.';
        readonly zh: '参数“{key}”已由 <{first}> 声明为 {kind}，不能再绑定 <{second}>。';
    };
    readonly 'binding.exclusive': {
        readonly en: 'Parameter "{key}" of <{first}> can only be owned by one component and cannot be shared with <{second}>.';
        readonly zh: '<{first}> 的参数“{key}”只能由一个组件拥有，不能与 <{second}> 共享。';
    };
    readonly 'binding.slotExclusive': {
        readonly en: 'Parameter "{key}" of the {slot} slot of <{name}> is exclusive and cannot be shared with another control.';
        readonly zh: '<{name}> 的 {slot} 槽参数“{key}”是独占的，不能与另一个控件共享。';
    };
    readonly 'binding.constraintConflict': {
        readonly en: 'Parameter "{key}" must use the same numeric range and step: <{first}> has {firstConstraints}, <{second}> has {secondConstraints}.';
        readonly zh: '参数“{key}”必须使用相同的数值范围和步长：<{first}> 为 {firstConstraints}，<{second}> 为 {secondConstraints}。';
    };
    readonly 'binding.optionConflict': {
        readonly en: 'Parameter "{key}" must use the same option set in the same order.';
        readonly zh: '参数“{key}”必须使用相同顺序的同一组选项。';
    };
    readonly 'initial.duplicate': {
        readonly en: 'Parameter "{key}" has multiple explicit initial values ({count} in total).';
        readonly zh: '参数“{key}”有多个显式初值（共 {count} 个）。';
    };
    readonly 'initial.duplicatePeers': {
        readonly en: 'Parameter "{key}" has multiple explicit initial values ({count} in total; see also line {lines}).';
        readonly zh: '参数“{key}”有多个显式初值（共 {count} 个；另见第 {lines} 行）。';
    };
    readonly 'initial.rangeNoStep': {
        readonly en: 'Parameter "{key}" has no valid step value within range [{min}, {max}].';
        readonly zh: '参数“{key}”在范围 [{min}, {max}] 内没有有效的步长值。';
    };
    readonly 'initial.cannotDerive': {
        readonly en: 'Cannot derive a default initial value for <{name}> parameter "{key}".';
        readonly zh: '无法为 <{name}> 的参数“{key}”推导默认初值。';
    };
    readonly 'initial.typeFiniteNumber': {
        readonly en: 'Initial value of parameter "{key}" must be a finite number.';
        readonly zh: '参数“{key}”的初值必须是有限数字。';
    };
    readonly 'initial.belowMin': {
        readonly en: 'Initial value {value} of parameter "{key}" is below the minimum {min}.';
        readonly zh: '参数“{key}”的初值 {value} 小于最小值 {min}。';
    };
    readonly 'initial.aboveMax': {
        readonly en: 'Initial value {value} of parameter "{key}" exceeds the maximum {max}.';
        readonly zh: '参数“{key}”的初值 {value} 超过最大值 {max}。';
    };
    readonly 'initial.offStep': {
        readonly en: 'Initial value {value} of parameter "{key}" is not on step {step} (based at {base}).';
        readonly zh: '参数“{key}”的初值 {value} 不在步长 {step} 上（基准 {base}）。';
    };
    readonly 'initial.typeBoolean': {
        readonly en: 'Initial value of parameter "{key}" must be a boolean.';
        readonly zh: '参数“{key}”的初值必须是布尔值。';
    };
    readonly 'initial.notAmongOptions': {
        readonly en: 'Initial value "{value}" of parameter "{key}" is not among the available values {options}.';
        readonly zh: '参数“{key}”的初值“{value}”不在可用值 {options} 中。';
    };
    readonly 'initial.typeWrong': {
        readonly en: 'Initial value of parameter "{name}" has the wrong type.';
        readonly zh: '参数“{name}”的初值类型不正确。';
    };
    readonly 'initial.typeCollection': {
        readonly en: 'Initial value of parameter "{key}" must be a JSON array.';
        readonly zh: '参数“{key}”的初值必须是 JSON 数组。';
    };
    readonly 'initial.typeStringArray': {
        readonly en: 'Initial value of parameter "{key}" must be an array of strings.';
        readonly zh: '参数“{key}”的初值必须是字符串数组。';
    };
    readonly 'initial.typeNumberArray': {
        readonly en: 'Initial value of parameter "{key}" must be an array of finite numbers.';
        readonly zh: '参数“{key}”的初值必须是有限数字组成的数组。';
    };
    readonly 'initial.maxItems': {
        readonly en: 'Initial value of parameter "{key}" exceeds the limit of {max} items.';
        readonly zh: '参数“{key}”的初值超过 {max} 项的上限。';
    };
    readonly 'initial.dateInvalid': {
        readonly en: 'Initial date "{value}" is not a valid YYYY-MM-DD.';
        readonly zh: '初值日期“{value}”不是有效的 YYYY-MM-DD。';
    };
    readonly 'initial.notAvailableOption': {
        readonly en: 'Initial value "{value}" is not an available option: {options}.';
        readonly zh: '初值“{value}”不是可用选项：{options}。';
    };
    readonly 'initial.multiSelectOption': {
        readonly en: 'Initial value "{value}" of parameter "{key}" is not an option of <multi-select>.';
        readonly zh: '参数“{key}”的初值“{value}”不是 <multi-select> 的选项。';
    };
    readonly 'initial.rangeSliderOrder': {
        readonly en: '<range-slider> start {start} cannot be greater than end {end}.';
        readonly zh: '<range-slider> 的 start {start} 不能大于 end {end}。';
    };
    readonly 'initial.slotBelowMin': {
        readonly en: 'Initial value {value} of <{name}> {slot} is below the minimum {min}.';
        readonly zh: '<{name}> 的 {slot} 初值 {value} 小于最小值 {min}。';
    };
    readonly 'initial.slotAboveMax': {
        readonly en: 'Initial value {value} of <{name}> {slot} exceeds the maximum {max}.';
        readonly zh: '<{name}> 的 {slot} 初值 {value} 超过最大值 {max}。';
    };
    readonly 'initial.slotOffStep': {
        readonly en: 'Initial value {value} of <{name}> {slot} is not on step {step} (based at {base}).';
        readonly zh: '<{name}> 的 {slot} 初值 {value} 不在步长 {step} 上（基准 {base}）。';
    };
    readonly 'initial.lengthBelow': {
        readonly en: 'Initial value of parameter "{key}" has length {length}, below the minimum length {min} required by <{name}>.';
        readonly zh: '参数“{key}”的初值长度为 {length}，小于 <{name}> 要求的最小长度 {min}。';
    };
    readonly 'initial.lengthAbove': {
        readonly en: 'Initial value of parameter "{key}" has length {length}, exceeding the maximum length {max} allowed by <{name}>.';
        readonly zh: '参数“{key}”的初值长度为 {length}，超过 <{name}> 允许的最大长度 {max}。';
    };
    readonly 'initial.email': {
        readonly en: 'Initial value of parameter "{key}" is not a valid email address.';
        readonly zh: '参数“{key}”的初值不是有效的电子邮件地址。';
    };
    readonly 'initial.dateBelow': {
        readonly en: 'Initial value {value} of parameter "{key}" is earlier than the minimum date {min} of <date>.';
        readonly zh: '参数“{key}”的初值 {value} 早于 <date> 的最小日期 {min}。';
    };
    readonly 'initial.dateAbove': {
        readonly en: 'Initial value {value} of parameter "{key}" is later than the maximum date {max} of <date>.';
        readonly zh: '参数“{key}”的初值 {value} 晚于 <date> 的最大日期 {max}。';
    };
    readonly 'initial.multiSelectExceeds': {
        readonly en: 'Initial values of <multi-select> exceed max-selected {max}.';
        readonly zh: '<multi-select> 的初值数量超过 max-selected {max}。';
    };
    readonly 'expression.error': {
        readonly en: 'Expression error: {detail}';
        readonly zh: '表达式错误：{detail}';
    };
    readonly 'binding.unknownSuggestion': {
        readonly en: 'Reference to undeclared parameter {name}. Did you mean {suggestion}?';
        readonly zh: '引用了未声明的参数 {name}。是否想使用 {suggestion}？';
    };
    readonly 'binding.unknownPlain': {
        readonly en: 'Reference to undeclared parameter {name}.';
        readonly zh: '引用了未声明的参数 {name}。';
    };
    readonly 'type.number': {
        readonly en: 'Expected a number here, but the expression evaluates to {kind}.';
        readonly zh: '此处需要数字，但表达式结果为 {kind}。';
    };
    readonly 'type.boolean': {
        readonly en: 'Expected a boolean here, but the expression evaluates to {kind}.';
        readonly zh: '此处需要布尔值，但表达式结果为 {kind}。';
    };
    readonly 'type.string': {
        readonly en: 'Expected a string here, but the expression evaluates to {kind}.';
        readonly zh: '此处需要字符串，但表达式结果为 {kind}。';
    };
    readonly 'type.arrayNoDisplay': {
        readonly en: 'Arrays cannot be displayed directly; convert them first with a function such as len.';
        readonly zh: '数组不能直接显示；请先用 len 等函数转换。';
    };
    readonly 'attribute.fullInterpolation': {
        readonly en: 'The {name} attribute of <{component}> must be a full interpolation.';
        readonly zh: '<{component}> 的 {name} 属性必须是完整插值。';
    };
    readonly 'anchor.idInvalid': {
        readonly en: 'Anchor id "{id}" must match [A-Za-z_][A-Za-z0-9_-]*.';
        readonly zh: '锚点 id“{id}”必须匹配 [A-Za-z_][A-Za-z0-9_-]*。';
    };
    readonly 'anchor.duplicate': {
        readonly en: 'Duplicate anchor id "{id}".';
        readonly zh: '重复的锚点 id“{id}”。';
    };
    readonly 'anchor.headingCollision': {
        readonly en: 'Anchor id "{id}" collides with an automatic heading target.';
        readonly zh: '锚点 id“{id}”与自动标题目标冲突。';
    };
    readonly 'jump.empty': {
        readonly en: '<jump> target cannot be empty.';
        readonly zh: '<jump> 的目标不能为空。';
    };
    readonly 'jump.badTarget': {
        readonly en: '<jump> target "{target}" must be a bare heading slug or anchor id without "#" or whitespace.';
        readonly zh: '<jump> 的目标“{target}”必须是不含“#”或空白的标题 slug 或锚点 id。';
    };
    readonly 'jump.unresolved': {
        readonly en: '<jump> target "{target}" does not resolve to a heading or explicit anchor in this document.';
        readonly zh: '<jump> 的目标“{target}”无法解析到本文档中的标题或显式锚点。';
    };
    readonly 'budget.plotCurves': {
        readonly en: '<plot> supports at most {limit} curves, but has {count}.';
        readonly zh: '<plot> 最多支持 {limit} 条曲线，当前有 {count} 条。';
    };
    readonly 'budget.plotPoints': {
        readonly en: "The document's total plot sample count exceeds the limit of {limit}.";
        readonly zh: '文档的绘图采样点总数超过上限 {limit}。';
    };
    readonly 'math.formulaShape': {
        readonly en: '<plot> formulas must be an equation: y = f(x), a parametric cases block, r = f(\\theta), or an implicit equation in x and y.';
        readonly zh: '<plot> 的公式必须是方程：y = f(x)、参数方程 cases 块、r = f(\\theta)，或关于 x 和 y 的隐式方程。';
    };
    readonly 'math.computeFailed': {
        readonly en: 'Cannot compute plot formula: {detail}';
        readonly zh: '无法计算绘图公式（错误代码 {code}）：{detail}';
    };
    readonly 'math.bindingUnknown': {
        readonly en: 'Plot formula references undeclared parameter "{name}".';
        readonly zh: '绘图公式引用了未声明的参数“{name}”。';
    };
    readonly 'math.bindingType': {
        readonly en: 'Plot parameter "{name}" must be a number, but is {kind}.';
        readonly zh: '绘图参数“{name}”必须是数字，但当前为 {kind}。';
    };
    readonly 'math.displayUnsupportedCommand': {
        readonly en: 'Formula command \\{name} is not supported; it is displayed as literal text.';
        readonly zh: '公式命令 \\{name} 不受支持；已按原文显示。';
    };
    readonly 'math.displayUnsupportedEnvironment': {
        readonly en: 'Formula environment {name} is not supported; it is displayed as literal text.';
        readonly zh: '公式环境 {name} 不受支持；已按原文显示。';
    };
    readonly 'math.displayBudget': {
        readonly en: 'Formula exceeds a display resource limit ({limit}); it is displayed as literal text.';
        readonly zh: '公式超过显示资源上限（{limit}）；已按原文显示。';
    };
    readonly 'math.displayStrayEnd': {
        readonly en: 'Formula has an unmatched \\end; it is displayed as literal text.';
        readonly zh: '公式中存在未匹配的 \\end；已按原文显示。';
    };
    readonly 'math.displayEnvironmentUnclosed': {
        readonly en: 'Formula environment {name} is missing its closing brace; it is displayed as literal text.';
        readonly zh: '公式环境 {name} 缺少结束花括号；已按原文显示。';
    };
    readonly 'math.displayEnvironmentMissingName': {
        readonly en: 'Formula environment is missing its name; \\begin is displayed as literal text.';
        readonly zh: '公式环境缺少名称；\\begin 已按原文显示。';
    };
    readonly 'math.displaySyntax': {
        readonly en: 'Formula structure cannot be displayed and is shown as literal text.';
        readonly zh: '公式结构无法显示，已按原文显示。';
    };
    readonly 'table.missingHeader': {
        readonly en: 'The table for <{name}> is missing a header.';
        readonly zh: '<{name}> 的表格缺少表头。';
    };
    readonly 'table.headerInterpolation': {
        readonly en: 'Table headers cannot contain interpolations.';
        readonly zh: '表格表头不能包含插值。';
    };
    readonly 'table.headerEmpty': {
        readonly en: 'Table headers cannot be empty.';
        readonly zh: '表格表头不能为空。';
    };
    readonly 'table.headerDuplicate': {
        readonly en: 'Duplicate table header "{name}".';
        readonly zh: '重复的表格表头“{name}”。';
    };
    readonly 'table.rowColumnMismatch': {
        readonly en: 'Table row has a different column count: header has {header} columns, this row has {row}.';
        readonly zh: '表格行的列数不一致：表头有 {header} 列，此行有 {row} 列。';
    };
    readonly 'chart.numericExpression': {
        readonly en: 'Chart column "{name}" requires a number in row {row}, but the expression evaluates to {kind}.';
        readonly zh: '图表列“{name}”第 {row} 行需要数字，但表达式结果为 {kind}。';
    };
    readonly 'timeline.numericExpression': {
        readonly en: 'Timeline column "{name}" requires a number in row {row}, but the expression evaluates to {kind}.';
        readonly zh: '时间线列“{name}”第 {row} 行需要数字，但表达式结果为 {kind}。';
    };
    readonly 'chart.numericPlain': {
        readonly en: 'Chart column "{name}" requires a plain number in row {row}, got "{value}".';
        readonly zh: '图表列“{name}”第 {row} 行需要普通数字，当前为“{value}”。';
    };
    readonly 'timeline.numericPlain': {
        readonly en: 'Timeline column "{name}" requires a plain number in row {row}, got "{value}".';
        readonly zh: '时间线列“{name}”第 {row} 行需要普通数字，当前为“{value}”。';
    };
    readonly 'selection.keyEmpty': {
        readonly en: '<{component}> key cannot be empty.';
        readonly zh: '<{component}> 的 key 不能为空。';
    };
    readonly 'selection.keyMissingColumn': {
        readonly en: '<{component}> key column "{name}" does not exist in its table.';
        readonly zh: '<{component}> 的 key 列“{name}”在表格中不存在。';
    };
    readonly 'selection.keyInterpolation': {
        readonly en: '<{component}> key column "{name}" must contain static text; row {row} contains an interpolation.';
        readonly zh: '<{component}> 的 key 列“{name}”必须包含静态文本；第 {row} 行包含插值。';
    };
    readonly 'selection.keyEmptyCell': {
        readonly en: '<{component}> key column "{name}" cannot be empty in row {row}.';
        readonly zh: '<{component}> 的 key 列“{name}”在第 {row} 行不能为空。';
    };
    readonly 'selection.keyDuplicate': {
        readonly en: '<{component}> key column "{name}" must be unique; duplicate value "{value}".';
        readonly zh: '<{component}> 的 key 列“{name}”必须唯一；重复值“{value}”。';
    };
    readonly 'initial.selectionNotValue': {
        readonly en: 'Initial selection "{value}" of <{component}> is not a value of key column "{name}".';
        readonly zh: '<{component}> 的初始选择“{value}”不是 key 列“{name}”中的值。';
    };
    readonly 'chart.columnComma': {
        readonly en: 'Chart column names cannot contain commas: "{name}".';
        readonly zh: '图表列名不能包含逗号：“{name}”。';
    };
    readonly 'chart.xMissing': {
        readonly en: 'Chart x column "{name}" does not exist.';
        readonly zh: '图表 x 列“{name}”不存在。';
    };
    readonly 'chart.yRequired': {
        readonly en: 'Chart y requires a column name.';
        readonly zh: '图表 y 需要列名。';
    };
    readonly 'chart.yMissing': {
        readonly en: 'Chart y column "{name}" does not exist.';
        readonly zh: '图表 y 列“{name}”不存在。';
    };
    readonly 'chart.needsNumeric': {
        readonly en: 'Chart requires at least one numeric column.';
        readonly zh: '图表至少需要一个数值列。';
    };
    readonly 'chart.scatterXMissing': {
        readonly en: 'Scatter chart x column "{name}" does not exist.';
        readonly zh: '散点图的 x 列“{name}”不存在。';
    };
    readonly 'chart.scatterNeedsNumeric': {
        readonly en: 'Scatter chart requires at least one numeric column.';
        readonly zh: '散点图至少需要一个数值列。';
    };
    readonly 'chart.donutNeedsColumns': {
        readonly en: 'Donut chart requires a label column and a value column.';
        readonly zh: '环形图需要一个标签列和一个数值列。';
    };
    readonly 'chart.donutYOne': {
        readonly en: 'Donut chart y can only specify one numeric column.';
        readonly zh: '环形图的 y 只能指定一个数值列。';
    };
    readonly 'chart.donutNeedY': {
        readonly en: 'A donut chart with more than two columns must use y to specify the single numeric column.';
        readonly zh: '超过两列的环形图必须用 y 指定唯一的数值列。';
    };
    readonly 'chart.negative': {
        readonly en: 'Donut chart values cannot be negative; row {row} is {value}.';
        readonly zh: '环形图的数值不能为负；第 {row} 行为 {value}。';
    };
    readonly 'timeline.headerMissing': {
        readonly en: 'Timeline requires either Task, Start and Duration columns or 事项, 开始 and 时长 columns, with optional Notes or 说明.';
        readonly zh: '时间线需要 Task、Start、Duration 列，或 事项、开始、时长 列，并可选 Notes 或 说明。';
    };
    readonly 'timeline.columnUnsupported': {
        readonly en: 'Timeline does not support column "{name}".';
        readonly zh: '时间线不支持列“{name}”。';
    };
    readonly 'timeline.negative': {
        readonly en: 'Timeline column "{name}" cannot be negative in row {row}.';
        readonly zh: '时间线列“{name}”在第 {row} 行不能为负。';
    };
    readonly 'runtime.bindingNoWritable': {
        readonly en: 'This component has no writable binding state.';
        readonly zh: '此组件没有可写的绑定状态。';
    };
    readonly 'runtime.bindingNeedsSlot': {
        readonly en: 'This multi-slot component requires a slot such as start/end or x/y.';
        readonly zh: '此多槽组件需要 start/end 或 x/y 之类的槽位。';
    };
    readonly 'runtime.bindingUnknownSlot': {
        readonly en: 'This component has no writable slot "{slot}".';
        readonly zh: '此组件没有可写的槽位“{slot}”。';
    };
    readonly 'runtime.bindingNoMultiSlot': {
        readonly en: 'This component does not support multiple slots.';
        readonly zh: '此组件不支持多个槽位。';
    };
    readonly 'runtime.dateInvalid': {
        readonly en: 'Date must be a valid YYYY-MM-DD or an empty string.';
        readonly zh: '日期必须是有效的 YYYY-MM-DD 或空字符串。';
    };
    readonly 'runtime.dateRequired': {
        readonly en: 'This date is required.';
        readonly zh: '此日期为必填项。';
    };
    readonly 'runtime.dateEarlier': {
        readonly en: 'Date cannot be earlier than {min}.';
        readonly zh: '日期不能早于 {min}。';
    };
    readonly 'runtime.dateLater': {
        readonly en: 'Date cannot be later than {max}.';
        readonly zh: '日期不能晚于 {max}。';
    };
    readonly 'runtime.fieldRequired': {
        readonly en: 'This field is required.';
        readonly zh: '此字段为必填项。';
    };
    readonly 'runtime.minLength': {
        readonly en: 'At least {min} characters.';
        readonly zh: '至少 {min} 个字符。';
    };
    readonly 'runtime.maxLength': {
        readonly en: 'At most {max} characters.';
        readonly zh: '至多 {max} 个字符。';
    };
    readonly 'runtime.emailLength': {
        readonly en: 'Email address cannot exceed {limit} characters.';
        readonly zh: '电子邮件地址不能超过 {limit} 个字符。';
    };
    readonly 'runtime.emailInvalid': {
        readonly en: 'Enter a valid email address.';
        readonly zh: '请输入有效的电子邮件地址。';
    };
    readonly 'runtime.finiteNumber': {
        readonly en: 'Parameter "{name}" requires a finite number.';
        readonly zh: '参数“{name}”需要有限数字。';
    };
    readonly 'runtime.min': {
        readonly en: 'Parameter "{name}" must be at least {min}.';
        readonly zh: '参数“{name}”必须至少为 {min}。';
    };
    readonly 'runtime.max': {
        readonly en: 'Parameter "{name}" must be at most {max}.';
        readonly zh: '参数“{name}”必须至多为 {max}。';
    };
    readonly 'runtime.step': {
        readonly en: 'Parameter "{name}" must be a multiple of step {step} (base {base}).';
        readonly zh: '参数“{name}”必须是步长 {step} 的倍数（基准 {base}）。';
    };
    readonly 'runtime.boolean': {
        readonly en: 'Parameter "{name}" requires a boolean.';
        readonly zh: '参数“{name}”需要布尔值。';
    };
    readonly 'runtime.string': {
        readonly en: 'Parameter "{name}" requires a string.';
        readonly zh: '参数“{name}”需要字符串。';
    };
    readonly 'runtime.array': {
        readonly en: 'Parameter "{name}" requires an array of strings.';
        readonly zh: '参数“{name}”需要字符串数组。';
    };
    readonly 'runtime.arrayMembers': {
        readonly en: 'Parameter "{name}" members must be strings.';
        readonly zh: '参数“{name}”的成员必须是字符串。';
    };
    readonly 'runtime.numberArray': {
        readonly en: 'Parameter "{name}" requires an array of finite numbers.';
        readonly zh: '参数“{name}”需要有限数字数组。';
    };
    readonly 'runtime.numberArrayMembers': {
        readonly en: 'Parameter "{name}" members must be finite numbers.';
        readonly zh: '参数“{name}”的成员必须是有限数字。';
    };
    readonly 'runtime.null': {
        readonly en: 'Parameter "{name}" requires null.';
        readonly zh: '参数“{name}”需要 null。';
    };
    readonly 'runtime.checklistOption': {
        readonly en: 'Checklist item "{value}" does not exist.';
        readonly zh: '清单项“{value}”不存在。';
    };
    readonly 'runtime.maxItems': {
        readonly en: 'Parameter "{name}" allows at most {max} selected values.';
        readonly zh: '参数“{name}”最多允许选择 {max} 个值。';
    };
    readonly 'runtime.unsupportedType': {
        readonly en: 'Parameter "{name}" has an unsupported value type.';
        readonly zh: '参数“{name}”的值类型不受支持。';
    };
    readonly 'runtime.option': {
        readonly en: 'Value "{value}" is not among the options: {options}.';
        readonly zh: '值“{value}”不在选项中：{options}。';
    };
    readonly 'runtime.budget': {
        readonly en: 'Parameter "{name}": {detail}';
        readonly zh: '参数“{name}”：{detail}';
    };
    readonly 'runtime.rangeOrder': {
        readonly en: 'The range start cannot be greater than its end.';
        readonly zh: '范围起点不能大于终点。';
    };
    readonly 'budget.string': {
        readonly en: 'String exceeds the {limit}-character limit.';
        readonly zh: '字符串超过 {limit} 个字符的上限。';
    };
    readonly 'budget.array': {
        readonly en: 'Array exceeds the {limit}-item limit.';
        readonly zh: '数组超过 {limit} 个项的上限。';
    };
    readonly 'budget.arrayMember': {
        readonly en: 'Array member exceeds the {limit}-character limit.';
        readonly zh: '数组成员超过 {limit} 个字符的上限。';
    };
    readonly 'budget.arrayContents': {
        readonly en: 'Array contents exceed the {limit}-character limit.';
        readonly zh: '数组内容超过 {limit} 个字符的上限。';
    };
    readonly 'theme.missing': {
        readonly en: 'Theme "{name}" is not registered by the host; using the default theme.';
        readonly zh: '宿主未注册主题“{name}”；将使用默认主题。';
    };
    readonly 'theme.registryUnreadable': {
        readonly en: 'The host theme registry could not be read; using the default theme.';
        readonly zh: '无法读取宿主主题注册表；将使用默认主题。';
    };
    readonly 'theme.invalidDefinition': {
        readonly en: 'The selected theme "{name}" is not a valid definition; using the default theme.';
        readonly zh: '所选主题“{name}”不是有效定义；将使用默认主题。';
    };
    readonly 'theme.duplicateRegistration': {
        readonly en: 'Theme "{name}" is registered more than once; using the default theme.';
        readonly zh: '主题“{name}”被多次注册；将使用默认主题。';
    };
    readonly 'theme.protocol': {
        readonly en: 'Theme "{name}" does not support the {protocol} protocol; using the default theme.';
        readonly zh: '主题“{name}”不支持 {protocol} 协议；将使用默认主题。';
    };
    readonly 'theme.modes': {
        readonly en: 'Theme "{name}" must supply both light and dark color schemes; using the default theme.';
        readonly zh: '主题“{name}”必须同时提供浅色和深色配色；将使用默认主题。';
    };
    readonly 'theme.selectedUnreadable': {
        readonly en: 'The selected theme "{name}" could not be read; using the default theme.';
        readonly zh: '所选主题“{name}”无法读取；将使用默认主题。';
    };
    readonly 'error.expression-syntax': {
        readonly en: 'Check expression operators, parentheses and arguments.';
        readonly zh: '表达式语法不正确，请检查运算符、括号或参数是否完整。';
    };
    readonly 'error.expression-index': {
        readonly en: 'An array index must be a finite safe integer.';
        readonly zh: '数组索引必须为有限的安全整数。';
    };
    readonly 'error.expression-cycle': {
        readonly en: 'Named calculations contain a dependency cycle.';
        readonly zh: '命名计算中存在循环依赖。';
    };
    readonly 'error.array.homogeneous': {
        readonly en: 'Array elements must all be strings or all be numbers.';
        readonly zh: '数组元素必须全部为字符串或全部为数字。';
    };
    readonly 'error.array.finite': {
        readonly en: 'Array members must be finite numbers.';
        readonly zh: '数字数组元素必须为有限数值。';
    };
    readonly 'error.array.members': {
        readonly en: 'Array members must be strings or finite numbers.';
        readonly zh: '数组元素必须为字符串或有限数值。';
    };
    readonly 'error.expression-number': {
        readonly en: 'A numeric literal must be finite and valid.';
        readonly zh: '数字字面量无效，必须是有限数值。';
    };
    readonly 'error.expression-string': {
        readonly en: 'Check the string quotes and escape sequences.';
        readonly zh: '字符串格式不正确，请检查引号和转义。';
    };
    readonly 'error.expression-budget': {
        readonly en: 'The expression exceeded a resource budget.';
        readonly zh: '表达式超过长度、节点、深度或求值步数预算，请简化表达式。';
    };
    readonly 'error.expression-assignment': {
        readonly en: 'Assignment is not allowed in expressions.';
        readonly zh: '表达式不能执行赋值，请使用比较运算符。';
    };
    readonly 'error.expression-property': {
        readonly en: 'Property access is not allowed.';
        readonly zh: '表达式不支持属性访问，请直接引用绑定名称。';
    };
    readonly 'error.expression-empty': {
        readonly en: 'An expression is required.';
        readonly zh: '此处需要非空表达式。';
    };
    readonly 'error.expression-unknown-function': {
        readonly en: 'Use a supported built-in function.';
        readonly zh: '函数不受支持，请使用语言内置函数。';
    };
    readonly 'error.expression-arity': {
        readonly en: 'Check the function argument count.';
        readonly zh: '函数参数数量不正确。';
    };
    readonly 'error.expression-forbidden-name': {
        readonly en: 'The name is forbidden.';
        readonly zh: '此名称属于禁止访问的名称，请使用已声明的绑定。';
    };
    readonly 'error.expression-type': {
        readonly en: 'Operand or argument types do not match.';
        readonly zh: '操作数或函数参数的类型不匹配，请检查绑定类型。';
    };
    readonly 'error.expression-unknown-name': {
        readonly en: 'The binding is not declared.';
        readonly zh: '引用了未声明的绑定。';
    };
    readonly 'error.expression-value': {
        readonly en: 'The binding value is not supported.';
        readonly zh: '绑定值不符合表达式支持的类型或数值范围。';
    };
    readonly 'error.expression-eval': {
        readonly en: 'The expression cannot be evaluated.';
        readonly zh: '表达式无法求值，请检查输入和运算条件。';
    };
    readonly 'error.expression-domain': {
        readonly en: 'A value lies outside the function domain.';
        readonly zh: '参数超出函数定义域。';
    };
    readonly 'error.expression-divide-by-zero': {
        readonly en: 'Division by zero is undefined.';
        readonly zh: '除数不能为零。';
    };
    readonly 'error.expression-interpolation': {
        readonly en: 'Check interpolation delimiters and content.';
        readonly zh: '插值格式不正确，请检查分隔符和表达式内容。';
    };
    readonly 'error.latex-budget': {
        readonly en: 'The formula exceeded a resource budget.';
        readonly zh: '公式超过长度、记号、节点、深度或计算步数预算，请简化公式。';
    };
    readonly 'error.latex-syntax': {
        readonly en: 'Check formula syntax and delimiters.';
        readonly zh: '公式语法不正确，请检查命令、括号和分隔符。';
    };
    readonly 'error.latex-empty': {
        readonly en: 'A formula is required.';
        readonly zh: '公式不能为空。';
    };
    readonly 'error.latex-relation': {
        readonly en: 'Check the formula relation.';
        readonly zh: '公式中的关系式不符合计算语法。';
    };
    readonly 'error.latex-number': {
        readonly en: 'A formula number must be finite.';
        readonly zh: '公式中的数字必须是有限数值。';
    };
    readonly 'error.latex-name': {
        readonly en: 'Use a valid formula parameter name.';
        readonly zh: '公式参数名称无效，请使用合法绑定名。';
    };
    readonly 'error.latex-unsupported': {
        readonly en: 'The LaTeX structure is not computable.';
        readonly zh: '此 LaTeX 结构不支持计算，请改用支持的函数和运算。';
    };
    readonly 'error.latex-variable': {
        readonly en: 'A numeric formula parameter is missing or invalid.';
        readonly zh: '公式引用的参数缺失或不是有限数字。';
    };
    readonly 'error.latex-type': {
        readonly en: 'A formula parameter has the wrong type.';
        readonly zh: '公式参数类型不正确，计算参数必须为数字。';
    };
    readonly 'error.latex-divide-by-zero': {
        readonly en: 'Division by zero is undefined.';
        readonly zh: '公式中的除数不能为零。';
    };
    readonly 'error.latex-domain': {
        readonly en: 'A formula value lies outside the function domain.';
        readonly zh: '公式参数超出函数定义域。';
    };
    readonly 'error.latex-undefined': {
        readonly en: 'The formula is undefined at this point.';
        readonly zh: '公式在此点没有有限定义值。';
    };
    readonly 'error.latex-plot-range': {
        readonly en: 'Plot bounds must be finite and increasing.';
        readonly zh: '绘图区间必须由有限数值构成，且最小值小于最大值。';
    };
    readonly 'error.latex-plot-samples': {
        readonly en: 'The sample count must be an integer from 2 to 2000.';
        readonly zh: '采样点数必须为 2 至 2000 的整数。';
    };
    readonly 'local.external.placement': {
        readonly en: '<external> declarations must be standalone tags at the document top level.';
        readonly zh: '<external> 声明必须独占一行，位于文档顶层。';
    };
    readonly 'local.external.name': {
        readonly en: 'External name "{name}" must match [A-Za-z_][A-Za-z0-9_]*.';
        readonly zh: '外部名称“{name}”必须匹配 [A-Za-z_][A-Za-z0-9_]*。';
    };
    readonly 'local.external.reserved': {
        readonly en: 'External name "{name}" is reserved; choose another name.';
        readonly zh: '外部名称“{name}”为保留名称，请更换。';
    };
    readonly 'local.external.duplicate': {
        readonly en: 'External name "{name}" is declared more than once.';
        readonly zh: '外部名称“{name}”被重复声明。';
    };
    readonly 'local.external.conflict': {
        readonly en: 'External name "{name}" conflicts with a control parameter of the same name.';
        readonly zh: '外部名称“{name}”与同名控件参数冲突。';
    };
    readonly 'local.external.type': {
        readonly en: 'External "{name}" must declare type string, number, boolean, string-array or number-array.';
        readonly zh: '外部声明“{name}”必须声明 string、number、boolean、string-array 或 number-array 类型。';
    };
    readonly 'local.host.structure.leaf': {
        readonly en: 'Host component <{component}> is a leaf and cannot have body content.';
        readonly zh: '宿主组件 <{component}> 是叶子组件，不能包含正文内容。';
    };
    readonly 'local.runtime.external': {
        readonly en: 'External value {name} cannot be written.';
        readonly zh: '无法写入外部数据 {name}。';
    };
    readonly 'local.runtime.external-value': {
        readonly en: 'External value {name} must be {kind}.';
        readonly zh: '外部数据 {name} 必须是 {kind} 类型。';
    };
    readonly 'local.runtime.external-budget': {
        readonly en: 'External value {name} exceeds a resource limit.';
        readonly zh: '外部数据 {name} 超过资源限制。';
    };
    readonly 'local.runtime.value.constraint': {
        readonly en: 'Dynamic {attribute} constraint failed for parameter {name}.';
        readonly zh: '参数 {name} 的动态 {attribute} 约束无法计算。';
    };
    readonly 'local.runtime.value.constraint-range': {
        readonly en: 'Dynamic constraints for parameter {name} produce an invalid range.';
        readonly zh: '参数 {name} 的动态约束产生无效范围。';
    };
    readonly 'local.runtime.value.constraint-date': {
        readonly en: 'Dynamic {attribute} date bound for parameter {name} is not a valid YYYY-MM-DD value.';
        readonly zh: '参数 {name} 的动态 {attribute} 日期边界不是合法的 YYYY-MM-DD。';
    };
};
