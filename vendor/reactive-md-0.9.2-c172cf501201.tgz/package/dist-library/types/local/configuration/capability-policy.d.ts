import type { LocalHtmlOptions, LocalHtmlPolicy } from '../types.js';
export declare const DEFAULT_CAPABILITY_POLICY: LocalHtmlPolicy;
export declare function intersectCapabilityPolicy(compiled: LocalHtmlPolicy | undefined, grants: LocalHtmlOptions | undefined): LocalHtmlPolicy;
