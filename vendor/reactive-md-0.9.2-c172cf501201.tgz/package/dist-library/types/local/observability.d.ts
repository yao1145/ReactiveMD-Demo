import { type Diagnostic } from './types.js';
import { type LocalObservabilityMessageKey } from './observability-messages.js';
import type { LocalTraceEvent } from './observability-core.js';
export { createLocalTraceId, emitLocalDiagnostic, emitLocalTrace } from './observability-core.js';
export type { LocalObserver, LocalTraceEvent } from './observability-core.js';
export interface LocalDiagnosticReport {
    schema: 'reactive-md-diagnostic/v1';
    generatedAt: string;
    traceId?: string;
    package: {
        engine: string;
        sdk: string;
        syntax: string;
        component: string;
        theme: string;
        editor?: string;
        react?: string;
        vite?: string;
    };
    environment: {
        runtime: 'browser' | 'node' | 'worker';
        userAgent?: string;
        node?: string;
        platform?: string;
    };
    document: {
        sourceBytes: number;
        sourceDigest: string;
        sourceRevision?: string;
    };
    diagnostics: readonly (Pick<Diagnostic, 'code' | 'severity' | 'range'> & Partial<Pick<Diagnostic, 'phase' | 'recoverable' | 'line' | 'column' | 'messageKey' | 'details'>>)[];
    events?: readonly LocalTraceEvent[];
}
export interface DiagnosticReportOptions {
    traceId?: string;
    sourceRevision?: string;
    package?: Partial<LocalDiagnosticReport['package']>;
    diagnostics?: readonly Diagnostic[];
    events?: readonly LocalTraceEvent[];
}
export declare function createLocalObservabilityDiagnostic(code: LocalObservabilityMessageKey, details?: NonNullable<Diagnostic['details']>): Diagnostic;
/** Copy an explicitly allowlisted, bounded field set. Free text can contain source. */
export declare function createDiagnosticReport(source: string, options?: DiagnosticReportOptions): LocalDiagnosticReport;
