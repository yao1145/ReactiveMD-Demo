/**
 * Move a static native document out of its preview frame so Chromium can
 * paginate the body. Keep the author's HTML and body attributes, along with
 * the export's print styles and restrictions on resource loading.
 */
export declare function prepareLocalPrintHtml(html: string): string;
/**
 * Wait for fonts and every image before printing, and return readable labels
 * for images Chromium could not decode. Labels use alt text, or the 1-based
 * document index when alt is empty; they never contain the image source, so a
 * data URI never reaches a diagnostic.
 *
 * The function only reads the global `document` and declares every constant
 * inline, which lets `page.evaluate(waitForLocalPrintImages)` serialize it into
 * the page. A host printing a document that lives in an iframe can pass that
 * frame's document.
 */
export declare function waitForLocalPrintImages(target?: Document | void): Promise<readonly string[]>;
