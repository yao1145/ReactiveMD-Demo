import type { LocalReactConfig } from '../react/sdk-core.js';
/** Mount with the bundle's own implementations. */
export declare function mountAll(root: ParentNode | undefined, host: {
    readonly reactConfig: LocalReactConfig;
}): import("./session-core.js").ReactiveMDHandle[];
