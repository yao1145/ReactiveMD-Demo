import { m as e, p as t, s as n } from "./document-theme-Cvvc_EOe.js";
import { n as r, r as i, t as a } from "./observability-core-Bcu7vpnl.js";
import { n as o, t as s } from "./observability-DC9q9t2z.js";
export { t as LOCAL_OBSERVABILITY_MESSAGES, s as createDiagnosticReport, o as createLocalObservabilityDiagnostic, a as createLocalTraceId, r as emitLocalDiagnostic, i as emitLocalTrace, n as formatLocalDiagnostic, e as formatObservabilityMessage };
