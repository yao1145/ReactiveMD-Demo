import { useEffect as e, useLayoutEffect as t } from "react";
// src/react/tooltip-layer.tsx
var n = typeof window > "u" ? e : t, r = n;
function i(e) {
	try {
		return e.matches(":popover-open");
	} catch {
		return !1;
	}
}
function a(e, t) {
	n(() => {
		let n = e.current;
		if (!n?.showPopover) return;
		let r;
		try {
			t ? i(n) || n.showPopover() : i(n) && (r = setTimeout(() => {
				try {
					n.hidePopover?.();
				} catch {}
			}, 200));
		} catch {}
		return () => {
			r !== void 0 && clearTimeout(r);
		};
	}, [e, t]);
}
export { a as n, r as t };
