import { c as e, n as t, o as n } from "./version-DAxuGOG2.js";
import { T as r, a as i, t as a } from "./preset-core-DeZPA8IE.js";
import { I as o, L as s, N as c, P as l, z as u } from "./sdk-core-BG-HbMwE.js";
import { t as d } from "./mount-preset-CfNUCUeV.js";
import { useCallback as f, useId as p, useLayoutEffect as m, useRef as h, useState as g } from "react";
import { jsx as _, jsxs as v } from "react/jsx-runtime";
// src/components/network/submit-button.tsx
var y = r({
	id: "reactive-md/submit-button",
	name: "submit-button",
	version: e,
	protocol: t,
	form: "leaf",
	props: {
		channel: {
			kind: "string",
			static: !0,
			required: !0
		},
		fields: {
			kind: "string",
			static: !0,
			required: !0
		},
		label: {
			kind: "string",
			coerce: "text"
		},
		disabled: {
			kind: "boolean",
			dynamic: !0,
			default: !1
		}
	},
	structure: {
		rule: "none",
		label: "none"
	},
	rules: [
		{
			kind: "nonempty",
			attribute: "channel"
		},
		{
			kind: "nonempty",
			attribute: "fields"
		},
		{
			kind: "dynamic-constraints",
			attributes: ["disabled"]
		}
	],
	capabilities: {
		interactive: !0,
		static: !0,
		ssr: !0,
		offline: !0
	},
	styles: ["reactive-md/network.css"],
	authoring: {
		title: {
			en: "Submit button",
			zh: "提交按钮"
		},
		description: {
			en: "Send the selected fields to a channel the host enabled.",
			zh: "把所选字段提交到宿主开放的通道。"
		},
		category: "action",
		insertText: "<submit-button channel=\"answers\" fields=\"choice comment\">"
	}
});
function b(e) {
	if (e === void 0) return null;
	let t = e.trim().split(/\s+/).filter((e) => e !== "");
	return t.length === 0 || new Set(t).size !== t.length || t.some((e) => !/^[A-Za-z_][A-Za-z0-9_]*$/.test(e)) ? null : t;
}
function x(e, t) {
	if (!e || t === "") return !1;
	try {
		return e.supports(t, "submit");
	} catch {
		return !1;
	}
}
function S() {
	let e = globalThis.crypto;
	if (e?.randomUUID) return e.randomUUID();
	if (e?.getRandomValues) {
		let t = e.getRandomValues(/* @__PURE__ */ new Uint8Array(16));
		return Array.from(t, (e) => e.toString(16).padStart(2, "0")).join("");
	}
	return `submit-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
}
function C(e) {
	let t = o(e), n = s(e), r = p(), { mode: i, visible: a, t: d } = n, y = e.services.network, C = e.props.channel, w = typeof C == "string" ? C.trim() : "", T = e.props.fields, E = typeof T == "string" ? b(T) : null, D = l(e, "label", d("Submit", "提交")), [O, k] = g(null), A = O?.tone === "pending", j = h(null), M = h(null), N = f(() => {
		let e = j.current;
		j.current = null, e?.abort();
	}, []);
	if (m(() => (M.current = null, k(null), N), [
		w,
		T,
		y,
		i,
		N
	]), u(e, () => {
		N(), M.current = null, k(null);
	}), i === "static") return /* @__PURE__ */ _("span", {
		...t(),
		className: "local-submit-button local-submit-button-static",
		"data-rmd-static-submit": "",
		"aria-disabled": "true",
		hidden: !a || void 0,
		children: c(D)
	});
	let P = w === "" ? d("This button has no submit channel.", "此按钮未配置提交通道。") : E === null ? d("List valid field names without duplicates.", "请填写有效且不重复的字段名。") : x(y, w) ? void 0 : d("Submitting is not enabled for this channel.", "此通道未开放提交。"), F = () => {
		if (!a || e.disabled || j.current || !E || !x(y, w)) return;
		let t;
		try {
			t = e.runtime.readSubmissionFields?.(E) ?? {
				ok: !1,
				field: E[0],
				reason: "unavailable"
			};
		} catch {
			t = {
				ok: !1,
				field: E[0],
				reason: "unavailable"
			};
		}
		if (!t.ok) {
			let e = t.field, n = t.reason === "required" ? d(`Field "${e}" is required.`, `字段“${e}”为必填项。`) : t.reason === "invalid" ? d(`Field "${e}" has an invalid value.`, `字段“${e}”的值无效。`) : d(`Field "${e}" is unavailable.`, `无法读取字段“${e}”。`);
			k({
				tone: "error",
				text: n,
				field: e
			});
			return;
		}
		let n = t.payload, r = JSON.stringify(n);
		M.current?.signature !== r && (M.current = null);
		let i = M.current?.key ?? S(), o = new AbortController();
		j.current = o, k({
			tone: "pending",
			text: d("Submitting…", "正在提交…")
		}), (async () => {
			let e;
			try {
				e = await y.submit(w, n, {
					signal: o.signal,
					idempotencyKey: i
				});
			} catch {
				e = {
					ok: !1,
					error: {
						code: "transport",
						message: ""
					}
				};
			}
			if (j.current !== o) return;
			if (j.current = null, e.ok) {
				M.current = null, k({
					tone: "success",
					text: d("Submitted.", "已提交。")
				});
				return;
			}
			let t = e.error, a = t.message.trim();
			t.code === "cancelled" ? k(null) : t.code === "unconfirmed" ? (M.current = {
				key: i,
				signature: r
			}, k({
				tone: "warning",
				text: d("Submission result is unconfirmed. Retry to send the same fields again.", "提交结果未确认。可手动重试同一组字段。")
			})) : t.code === "transport" ? k({
				tone: "error",
				text: a || d("The submission could not be sent.", "发送提交失败。")
			}) : t.code === "rejected" || t.code === "invalid-data" ? (M.current = null, k({
				tone: "error",
				text: a ? d(`Submission was rejected: ${a}`, `提交被拒绝：${a}`) : d("Submission was rejected.", "提交被拒绝。")
			})) : (M.current = null, k({
				tone: "error",
				text: d("Submitting is not enabled for this channel.", "此通道未开放提交。")
			}));
		})();
	};
	return /* @__PURE__ */ v("div", {
		...t(),
		className: "local-submit-button-control",
		"data-rmd-component": "submit-button",
		"data-field": O?.field,
		hidden: !a || void 0,
		children: [/* @__PURE__ */ _("button", {
			type: "button",
			className: "md-button md-button-primary local-submit-button",
			disabled: e.disabled || A || P !== void 0,
			"aria-busy": A || void 0,
			"aria-describedby": `${r}-submit-status`,
			onClick: F,
			children: D
		}), /* @__PURE__ */ _("span", {
			id: `${r}-submit-status`,
			className: "local-submit-button-status",
			role: "status",
			"data-tone": P ? "error" : O?.tone ?? "idle",
			children: P ?? O?.text ?? ""
		})]
	});
}
// src/components/network/network.css?inline
var w = "@layer rmd.components{.local-submit-button-control:where(.md-document,.md-document *){align-items:center;gap:var(--space-2);flex-wrap:wrap;margin:.7em 0;display:flex}.local-document .md-button.local-submit-button{min-height:var(--control-height);padding:0 var(--control-inset-x);font-size:var(--text-sm);margin:0}:is(.local-submit-button-control,.local-submit-button-static)[hidden]:where(.md-document,.md-document *){display:none}.local-submit-button-status:where(.md-document,.md-document *){min-height:1.2em;color:var(--ink-muted);font-size:var(--text-xs);font-weight:var(--weight-semibold)}.local-submit-button-status[data-tone=success]:where(.md-document,.md-document *){color:var(--success)}.local-submit-button-status[data-tone=warning]:where(.md-document,.md-document *){color:var(--warning,var(--ink-soft))}.local-submit-button-status[data-tone=error]:where(.md-document,.md-document *){color:var(--danger)}.local-submit-button-static:where(.md-document,.md-document *){padding:0 var(--space-2);border:1px solid var(--line-strong);border-radius:var(--radius-pill);color:var(--ink);font-size:var(--text-sm);font-weight:var(--weight-semibold);display:inline-block}}", T = a({
	id: "reactive-md/network",
	version: i,
	protocol: n,
	components: [y]
}), E = d(T, { "submit-button": C }, [{
	id: "reactive-md/network.css",
	css: w
}]);
export { E as default };
