import { s as e } from "./document-theme-Cvvc_EOe.js";
import { O as t } from "./preset-core-DeZPA8IE.js";
import { i as n, o as r } from "./props-sJ8vk0cr.js";
import { s as i } from "./config-DA_bEhiK.js";
import { S as a } from "./component-state-CwKX_SN5.js";
import { i as o, n as s, o as c, s as l } from "./identity-BUx0Q_-d.js";
import { t as u } from "./runtime-BDnnimPA.js";
import { i as d } from "./resources-BNTgAbpz.js";
import { Component as f, createElement as p, useCallback as m, useEffect as h, useRef as g, useState as _ } from "react";
import { jsx as v, jsxs as y } from "react/jsx-runtime";
// src/react/component-api.tsx
var b = Symbol("reactive-md.content-node");
function x(e) {
	return e[b];
}
function S(e, t) {
	return Object.defineProperty(e, b, {
		value: t,
		enumerable: !1,
		configurable: !1,
		writable: !1
	}), Object.freeze(e);
}
var C = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;
function w(e) {
	return e === null ? "" : typeof e == "string" ? e : typeof e == "number" ? Number.isFinite(e) ? String(e) : null : typeof e == "boolean" ? e ? "true" : "false" : null;
}
function T(e) {
	if (!Number.isFinite(e)) return "—";
	if (Object.is(e, -0)) return "0";
	let t = Math.abs(e);
	return t >= 0xe8d4a51000 || t > 0 && t < 1e-4 ? e.toExponential(3).replace(/(\.\d*?)0+e/, "$1e").replace(/\.e/, "e") : Number(e.toFixed(6)).toString();
}
function E(e) {
	return Array.isArray(e) ? Object.freeze(e.slice()) : e === void 0 ? null : e;
}
function D(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function O(e, t, r, i) {
	try {
		return {
			ok: !0,
			value: n(e, t, r, i)
		};
	} catch (e) {
		return {
			ok: !1,
			error: e
		};
	}
}
var ee = /* @__PURE__ */ new WeakMap(), k = /* @__PURE__ */ new WeakMap();
function te(e) {
	k.delete(j(e));
}
var A = /* @__PURE__ */ new WeakMap(), ne = 4096, re = 512;
function j(e) {
	let t = N.get(e);
	return t || (t = Object.freeze({}), N.set(e, t)), t;
}
function ie(e, t, n) {
	let { environment: r, node: i } = e, a = r.positionOf?.(i.range.start) ?? {
		line: 1,
		column: 1
	}, o = n instanceof Error ? n.message : String(n);
	return {
		code: "local.component.prop",
		message: `Component <${i.name ?? i.id}> prop "${t}" is invalid: ${o}`,
		severity: "error",
		range: {
			start: i.range.start,
			end: i.range.end
		},
		line: a.line,
		column: a.column
	};
}
function ae(e, t, n) {
	if (n.length === 0) return;
	if (typeof window > "u") {
		e.report(n);
		return;
	}
	let r = A.get(t);
	r || (r = {
		diagnostics: [],
		scheduled: !1,
		report: e.report
	}, A.set(t, r));
	let i = r;
	i.report = e.report;
	for (let e of n) {
		if (i.diagnostics.length >= re) break;
		i.diagnostics.push(e);
	}
	if (i.scheduled) return;
	i.scheduled = !0;
	let a = () => {
		i.scheduled = !1;
		let e = i.diagnostics.splice(0);
		e.length > 0 && i.report(e);
	};
	typeof queueMicrotask == "function" ? queueMicrotask(a) : setTimeout(a, 0);
}
function oe(e, t, n, r) {
	if (!e) return {};
	let i = t ?? {}, a = {}, o = r?.environment.mode === "static" && typeof window > "u", s = r !== void 0, c = r ? j(n) : null, l = null;
	if (r && c && s) {
		let e = o ? k : ee;
		l = e.get(c) ?? null, l ? l.size > ne && l.clear() : (l = /* @__PURE__ */ new Map(), e.set(c, l));
	}
	let u = [];
	for (let t of Object.keys(e.props)) {
		let o = Object.hasOwn(i, t) && typeof i[t] == "string" ? i[t] : void 0, s = O(e, t, o, n);
		if (s.ok) a[t] = s.value, r && l && l.delete(`${r.node.id}\u0000${t}`);
		else if (a[t] = null, r) {
			if (l) {
				let e = `${r.node.id}\u0000${t}`, n = `${o ?? ""}\u0000${s.error instanceof Error ? s.error.message : String(s.error)}`;
				if (l.get(e) === n) continue;
				l.set(e, n);
			}
			u.push(ie(r, t, s.error));
		}
	}
	return r && c && ae(r.environment, c, u), a;
}
function se(e) {
	return e?.bindings ?? {};
}
function M(e, t, n, r) {
	let i = r.get(e);
	if (i) return i;
	let a = e.type === "component" || e.type === "hostComponent", o = a ? t.definitionFor(e.name ?? "") : void 0, s = Object.freeze(a ? oe(o, e.attrs, t.runtime, {
		environment: t,
		node: e
	}) : {}), c = (e.children ?? []).map((e) => M(e, t, n, r)), l = null;
	if (a) try {
		l = E(t.runtime.get(e));
	} catch {
		l = null;
	}
	else if (e.type === "interpolation") try {
		l = E(t.runtime.evaluate(e.value ?? ""));
	} catch {
		l = null;
	}
	let u = S({
		id: e.id,
		kind: a ? "component" : e.type,
		name: a ? e.name ?? "" : "",
		...a && o ? { form: o.form } : {},
		props: s,
		attrs: Object.freeze({ ...e.attrs ?? {} }),
		value: l,
		text: typeof e.value == "string" ? e.value : "",
		...e.lang === void 0 ? e.type === "math" || e.type === "inlineMath" ? { format: e.type } : {} : { format: e.lang },
		visible: n,
		children: Object.freeze(c),
		range: Object.freeze({
			start: e.range.start,
			end: e.range.end
		})
	}, e);
	return r.set(e, u), u;
}
var N = /* @__PURE__ */ new WeakMap();
function ce(e, t, n) {
	let r = t === "static", i = N.get(e);
	i || (i = Object.freeze({}), N.set(e, i));
	let a = x, o = (e) => (e.length > 0 && n(e), e), s = (e, t) => {
		let n = {
			start: e.range.start,
			end: e.range.end
		};
		return [{
			code: "local.extension.write",
			message: `Component <${e.name || e.id}> write failed: ${t instanceof Error ? t.message : String(t)}`,
			severity: "error",
			range: n,
			line: 1,
			column: 1
		}];
	};
	return Object.freeze({
		identity: i,
		get(t, n) {
			return E(e.get(a(t), n === "value" ? void 0 : n));
		},
		set(t, n, i) {
			if (r) return s(t, /* @__PURE__ */ Error("Runtime is read-only in static mode."));
			try {
				return o(e.set(a(t), D(n), i === "value" ? void 0 : i));
			} catch (e) {
				return s(t, e);
			}
		},
		setMany(t, n) {
			if (r) return s(t, /* @__PURE__ */ Error("Runtime is read-only in static mode."));
			try {
				let r = {};
				for (let [e, t] of Object.entries(n)) r[e] = D(t);
				return o(e.setMany(a(t), r));
			} catch (e) {
				return s(t, e);
			}
		},
		reset(t) {
			if (!r) try {
				e.reset(a(t));
			} catch {}
		},
		resetToken(t) {
			try {
				return e.resetToken(a(t));
			} catch {
				return 0;
			}
		},
		evaluate(t) {
			return E(e.evaluate(t));
		},
		snapshot() {
			try {
				let t = e.snapshot(), n = {};
				for (let [e, r] of Object.entries(t.state)) n[e] = E(r);
				return {
					revision: t.revision,
					state: Object.freeze(n)
				};
			} catch {
				return {
					revision: 0,
					state: {}
				};
			}
		},
		readSubmissionFields(t) {
			let n = {
				ok: !1,
				field: t[0] ?? "",
				reason: "unavailable"
			};
			if (r) return n;
			try {
				return e.readSubmissionFields?.(t) ?? n;
			} catch {
				return n;
			}
		},
		registerSubmissionField(t, n) {
			return r ? () => {} : e.registerSubmissionField?.(a(t), n) ?? (() => {});
		},
		validate() {
			try {
				return e.validate();
			} catch {
				return [];
			}
		},
		text(t) {
			try {
				return e.text(t);
			} catch {
				return "";
			}
		}
	});
}
function le(e, t, n, r) {
	return Object.freeze({
		get: () => {
			try {
				return e.get(t, n);
			} catch {
				return null;
			}
		},
		set: (i) => {
			if (r) return {
				ok: !1,
				diagnostics: []
			};
			let a = e.set(t, i, n);
			return {
				ok: a.length === 0,
				diagnostics: a
			};
		}
	});
}
function ue(e, t) {
	let n = [], r = e.children, i = t.definitionFor(e.name), a = i?.rules?.find((e) => e.kind === "options-body"), o = a?.kind === "options-body" ? a.child : i?.structure?.child ?? "option", s = a?.kind === "options-body" ? a.valueAttribute : i?.structure?.valueAttribute ?? "value", c = 0;
	for (let i of r) {
		if (i.kind !== "component" || i.name !== o) continue;
		let r = x(i), a = i.attrs[s] ?? `option-${c + 1}`;
		c += 1;
		let l = t.renderToText(r.children) || i.attrs[s] || "";
		n.push(Object.freeze({
			value: a,
			content: i,
			label: l,
			render: () => t.renderInline(r.children, e.visible)
		}));
	}
	return n;
}
function P(e, t) {
	let n = e.children ?? [], r = n.filter((e) => !(e.type === "text" && !(e.value ?? "").trim())), i, a = "empty", o = "", s = null, c = null;
	if (r.length === 1 && r[0].type === "interpolation") try {
		i = t.runtime.evaluate(r[0].value ?? "");
		let e = w(i);
		i === null ? (a = "null", o = "") : typeof i == "string" ? (a = "string", o = i) : typeof i == "number" ? Number.isFinite(i) ? (a = "number", o = T(i), s = i) : (a = "error", o = t.locale === "zh" ? "无法计算" : "Cannot compute", c = t.locale === "zh" ? "结果不是有限数字" : "Result is not a finite number") : typeof i == "boolean" ? (a = "boolean", o = i ? "true" : "false") : (a = "array", o = e ?? "", c = t.locale === "zh" ? "数组需要先用 len 等函数转换" : "Arrays must first be converted with a function such as len");
	} catch (e) {
		a = "error", o = t.locale === "zh" ? "无法计算" : "Cannot compute", c = e instanceof Error ? e.message : String(e);
	}
	else {
		let e = "", l = null, u = (n) => {
			for (let r of n ?? []) if (r.type === "text" || r.type === "inlineCode" || r.type === "code") e += r.value ?? "";
			else if (r.type === "interpolation") try {
				let n = w(t.runtime.evaluate(r.value ?? ""));
				n === null ? l ??= t.locale === "zh" ? "数组需要先用 len 等函数转换" : "Arrays must first be converted with a function such as len" : e += n;
			} catch (n) {
				l ??= n instanceof Error ? n.message : String(n), e += t.locale === "zh" ? "无法计算" : "Cannot compute";
			}
			else r.type === "inlineMath" || r.type === "math" ? e += r.value ?? "" : r.type === "image" ? e += r.alt ?? "" : r.children && r.children.length > 0 ? u(r.children) : r.value && (e += r.value);
		};
		u(n);
		let d = r.length > 0 && r.every((e) => e.type === "text"), f = e.trim();
		if (d && C.test(f)) {
			let t = Number(f);
			Number.isFinite(t) && (a = "number", o = e, s = t, i = t);
		}
		a === "empty" && (l ? (a = "error", o = t.locale === "zh" ? "无法计算" : "Cannot compute", c = l) : (a = f === "" ? "empty" : "string", o = e, i = e));
	}
	return Object.freeze({
		text: o,
		value: i,
		kind: a,
		numeric: s,
		error: c,
		render: () => t.renderInline(n, !0)
	});
}
function de(e, t) {
	let n = e.children.find((e) => e.kind === "table");
	if (!n) return null;
	let r = (x(n).children ?? []).filter((e) => e.type === "tableRow");
	if (r.length === 0) return null;
	let i = (r[0].children ?? []).map((e) => P(e, t));
	return Object.freeze({
		header: Object.freeze(i),
		headerText: Object.freeze(i.map((e) => e.error ? t.locale === "zh" ? "无法计算" : "Cannot compute" : e.text)),
		rows: Object.freeze(r.slice(1).map((e, n) => Object.freeze({
			index: n,
			cells: Object.freeze((e.children ?? []).map((e) => P(e, t)))
		})))
	});
}
function fe(e, t) {
	let n = e["state-key"];
	return c(typeof n == "string" ? n : t["state-key"]);
}
function pe(e) {
	try {
		return e.document.source;
	} catch {
		return "";
	}
}
var F = /* @__PURE__ */ new WeakMap();
function I(e) {
	if (e.services !== void 0) return e.services;
	let t = F.get(e);
	return t === void 0 && (t = u({ sourceDigest: o(pe(e)) }), F.set(e, t)), t;
}
function L(e, t) {
	let n = t.definitionFor(e.name ?? ""), r = /* @__PURE__ */ new Map(), i = M(e, t, t.visible, r), o = ce(t.runtime, t.mode, t.report), c = t.services ?? I(t.runtime), u = n?.id ?? e.name ?? e.type, d = fe(i.props, i.attrs), f = null, p = () => (f === null && (f = c.state.handle({
		nodeId: e.id,
		component: u,
		componentVersion: n?.version ?? "0.0.0",
		stateKey: d,
		stateVersion: 0
	})), f), m = typeof i.props.seed == "number" && Number.isFinite(i.props.seed) ? i.props.seed : void 0, h = l({
		explicitSeed: m,
		documentSeed: c.randomSeed,
		componentId: u,
		nodeId: e.id,
		stateKey: d
	}), g = Object.freeze({
		network: t.mode === "static" ? a : t.network ?? t.runtime.network ?? a,
		random: Object.freeze({
			seed: h,
			derive: (e) => s(h, e)
		}),
		clock: c.clock,
		scheduler: c.scheduler,
		get state() {
			return p();
		}
	}), _ = t.mode === "static", v = se(n), y = {};
	for (let e of Object.keys(v)) y[e] = le(o, i, e, _);
	let b = y.value ?? Object.freeze({
		get: () => null,
		set: () => ({
			ok: !1,
			diagnostics: []
		})
	}), S = Object.freeze({
		render: () => t.renderChildren(e.children, t.visible),
		inline: () => t.renderInline(e.children, t.visible),
		text: () => t.renderToText(e.children),
		items: () => i.children,
		renderItems: (e, n) => t.renderChildren(e.map((e) => x(e)), n ?? t.visible),
		renderInlineItems: (e, n) => t.renderInline(e.map((e) => x(e)), n ?? t.visible),
		textOf: (e) => t.renderToText(e.map((e) => x(e))),
		options: () => ue(i, t),
		table: () => de(i, t),
		math: () => i.children.filter((e) => e.kind === "math" || e.kind === "inlineMath")
	}), C = Object.freeze({
		value: b,
		slots: Object.freeze(y),
		isReadOnly: _,
		get(e = "value") {
			let t = y[e];
			return t ? t.get() : null;
		},
		set(e, t) {
			let n = y[e];
			return n ? n.set(t) : {
				ok: !1,
				diagnostics: [{
					code: "local.extension.binding",
					message: `Component <${i.name || i.id}> has no binding slot "${e}".`,
					severity: "error",
					range: i.range,
					line: 1,
					column: 1
				}]
			};
		},
		setMany(e) {
			if (_) return {
				ok: !1,
				diagnostics: []
			};
			let t = o.setMany(i, e);
			return {
				ok: t.length === 0,
				diagnostics: t
			};
		}
	}), w = Object.freeze({
		fieldFor: (e) => t.validationFieldFor(x(e)),
		hintFor: (e) => t.validationHintFor(x(e))
	}), E = Object.freeze({
		targetId: (e) => t.targetId(e),
		anchorId: () => t.anchorId(e),
		allowed: (e) => t.jumpAllowed(e),
		jump: (e) => {
			let n = t.targetId(e);
			return n === void 0 ? "missing" : t.jumpTo(n);
		}
	}), D = Object.freeze({
		resolve(e, n) {
			if (!e) return null;
			let r = e.trim();
			if (!r) return null;
			let i = r.replace(/[\u0000- ]+/g, ""), a = /^([a-z][a-z0-9+.-]*):/i.exec(i);
			if (a) {
				let e = a[1].toLowerCase();
				if (!(n === "image" ? e === "http" || e === "https" : e === "http" || e === "https" || e === "mailto" || e === "tel")) return null;
			}
			if (!t.urlPolicy) return n === "image" ? null : r;
			try {
				return t.urlPolicy(r, n) ? r : null;
			} catch {
				return null;
			}
		},
		image(e) {
			let n = D.resolve(e, "image");
			if (!n) return null;
			if (!t.imageResolver) return n;
			try {
				let e = t.imageResolver(n);
				return typeof e == "string" && e.trim() !== "" ? e : null;
			} catch {
				return null;
			}
		}
	}), O = Object.freeze({
		locale: t.locale,
		t: (e, n) => t.locale === "zh" ? n : e,
		formatNumber: T
	});
	return Object.freeze({
		props: i.props,
		authorStyle: t.authorStyle,
		authorStyleText: t.authorStyleText,
		dispatchAuthorAction: t.dispatchAuthorAction,
		content: i,
		services: g,
		bindings: C,
		children: S,
		runtime: o,
		instance: Object.freeze({
			id: e.id,
			componentId: n?.id ?? e.name ?? "",
			range: Object.freeze({
				start: e.range.start,
				end: e.range.end
			})
		}),
		mode: t.mode,
		visible: t.visible,
		disabled: t.disabled,
		disabledInvalid: t.disabledInvalid,
		resetToken: t.resetToken,
		validation: w,
		source: Object.freeze({ attributes: (n) => t.sourceAttributes(n ? x(n) : e, e.name) }),
		navigation: E,
		url: D,
		locale: O,
		report: t.report
	});
}
var R = [
	"interactive",
	"static",
	"ssr",
	"offline"
];
function z(e) {
	let t = e.capabilities;
	if (t === void 0) return;
	if (typeof t != "object" || !t || Array.isArray(t)) throw TypeError("Component capabilities must be an object.");
	let n = {};
	for (let e of R) {
		let r = t[e];
		if (r !== void 0) {
			if (typeof r != "boolean") throw TypeError(`Component capability "${e}" must be a boolean.`);
			n[e] = r;
		}
	}
	return n;
}
function B(e, t, n) {
	if (t) {
		if (typeof n.render != "function") throw TypeError("defineReactComponent requires a render function.");
		if (n.renderStatic !== void 0 && typeof n.renderStatic != "function") throw TypeError("defineReactComponent renderStatic must be a function.");
		if (t.static === !1 && t.ssr === !0) throw TypeError(`Component "${e.id ?? ""}" declares SSR without static rendering.`);
		if (t.static === !1 && t.offline === !0) throw TypeError(`Component "${e.id ?? ""}" declares offline output without a static implementation.`);
		if (t.interactive === !1 && t.offline === !0 && t.static !== !0) throw TypeError(`Component "${e.id ?? ""}" declares offline output without any renderable implementation.`);
	}
}
function me(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("defineReactComponent requires a component definition object.");
	return e;
}
function he(e, n) {
	let r = me(e);
	if (!n || typeof n != "object") throw TypeError("defineReactComponent requires an implementation object.");
	B(r, z(r), n);
	let i;
	try {
		i = t(r);
	} catch (e) {
		throw TypeError(`Cannot bind a React implementation to component "${r.id}": ${e instanceof Error ? e.message : String(e)}`);
	}
	return Object.freeze({
		definition: r,
		digest: i,
		render: n.render,
		...n.renderStatic === void 0 ? {} : { renderStatic: n.renderStatic }
	});
}
// src/react/component-utils.tsx
function ge(e) {
	return {
		context: e,
		content: e.content,
		props: e.props,
		runtime: e.runtime,
		bindings: e.bindings,
		children: e.children,
		mode: e.mode,
		visible: e.visible,
		disabled: e.disabled,
		disabledInvalid: e.disabledInvalid,
		resetToken: e.resetToken,
		t: e.locale.t,
		locale: e.locale.locale,
		validation: e.validation,
		source: e.source,
		navigation: e.navigation,
		url: e.url,
		report: e.report,
		render: (t, n) => e.children.renderItems(t ?? e.children.items(), n),
		renderInline: (t, n) => e.children.renderInlineItems(t ?? e.children.items(), n)
	};
}
function _e(t) {
	let [n, r] = _(null), { locale: i, report: a, bindings: o } = t, s = m((t) => t.map((t) => e(t, i.locale)).join("; "), [i.locale]);
	return {
		write: m((e, t = "value") => {
			let n = o.set(t, e);
			return n.ok ? (r(null), !0) : (n.diagnostics.length > 0 ? (r(s(n.diagnostics)), a(n.diagnostics)) : r(i.t("Cannot write this value", "无法写入此值")), !1);
		}, [
			o,
			i,
			s,
			a
		]),
		writeMany: m((e) => {
			let t = o.setMany(e);
			return t.ok ? (r(null), !0) : (t.diagnostics.length > 0 ? (r(s(t.diagnostics)), a(t.diagnostics)) : r(i.t("Cannot write this value", "无法写入此值")), !1);
		}, [
			o,
			i,
			s,
			a
		]),
		error: n,
		setError: r
	};
}
function ve(e) {
	return {
		disabled: e.disabled,
		invalid: e.disabledInvalid
	};
}
function ye(e, t) {
	return e.validation.fieldFor(t ?? e.content);
}
function be(e, t) {
	return e.validation.hintFor(t ?? e.content);
}
function xe(e, t) {
	return e.source.attributes(t);
}
function Se(e, t) {
	let n = e.resetToken, r = g(n), i = g(t);
	i.current = t, h(() => {
		r.current !== n && (r.current = n, i.current());
	}, [n]);
}
function Ce(e, t) {
	return e.attrs[t];
}
function we(e, t, n = "") {
	let r = e.props[t];
	return typeof r == "string" ? r : typeof r == "number" ? Number.isFinite(r) ? String(r) : n : typeof r == "boolean" ? r ? "true" : "false" : e.content.attrs[t] === void 0 ? n : e.locale.t("Cannot compute", "无法计算");
}
function V(e, t, n) {
	let r = e.props[t];
	return typeof r == "number" && Number.isFinite(r) ? r : n;
}
function Te(e, t, n, r = "") {
	let i = t.props[n];
	return typeof i == "string" ? i : typeof i == "number" ? Number.isFinite(i) ? String(i) : r : typeof i == "boolean" ? i ? "true" : "false" : t.attrs[n] === void 0 ? r : e.locale.t("Cannot compute", "无法计算");
}
function Ee(e, t, n, r = !1) {
	let i = t.props[n];
	return typeof i == "boolean" ? i : r;
}
function De(e, t) {
	if (e.content.attrs[t] === void 0) return {
		present: !1,
		error: !1
	};
	let n = e.props[t];
	return typeof n == "number" && Number.isFinite(n) ? {
		present: !0,
		error: !1,
		value: n
	} : {
		present: !0,
		error: !0
	};
}
function Oe(e, t) {
	if (e.content.attrs[t] === void 0) return {
		present: !1,
		error: !1
	};
	let n = e.props[t];
	return typeof n == "string" ? {
		present: !0,
		error: !1,
		value: n
	} : {
		present: !0,
		error: !0
	};
}
function H(e, t, n) {
	if (e.content.attrs[t] === void 0) return {
		ok: !0,
		value: n
	};
	let r = e.props[t];
	return typeof r == "boolean" ? {
		ok: !0,
		value: r
	} : { ok: !1 };
}
function ke(e, t, n = !1) {
	let r = H(e, t, n);
	return r.ok ? r.value : n;
}
function Ae(e, t, n, r) {
	if (e.content.attrs[t] === void 0) return {
		tone: r,
		error: !1
	};
	let i = e.props[t];
	return typeof i == "string" && n.includes(i) ? {
		tone: i,
		error: !1
	} : {
		tone: r,
		error: /\{\{/.test(e.content.attrs[t] ?? "")
	};
}
function je(e) {
	let t = e.attrs.color;
	if (t === void 0) return;
	let n = t.trim();
	return n !== "" && r(n) ? n : void 0;
}
function Me(e) {
	if (e) return {
		"--local-accent": e,
		"--local-accent-soft": `color-mix(in srgb, ${e} 14%, var(--surface))`,
		"--local-accent-strong": e
	};
}
function U(e) {
	return e === null ? "" : typeof e == "string" ? e : typeof e == "number" ? Number.isFinite(e) ? String(e) : null : typeof e == "boolean" ? e ? "true" : "false" : null;
}
function Ne(e) {
	return U(e) ?? "";
}
function Pe(e) {
	try {
		return e.runtime.get(e.content);
	} catch {
		return null;
	}
}
function Fe(e, t, n) {
	try {
		let r = e.runtime.get(e.content, t);
		return typeof r == "number" && Number.isFinite(r) ? r : n;
	} catch {
		return n;
	}
}
function Ie(e, t, n) {
	return Math.min(n, Math.max(t, e));
}
function Le(e, t, n, r) {
	let i = Number.isFinite(r) && r > 0 ? r : 1, a = Math.max(0, Math.floor((n - t) / i + 1e-9)), o = t + Math.max(0, Math.min(a, Math.round((e - t) / i))) * i;
	return Number(o.toPrecision(15));
}
function Re(e, t, n, r, i, a = 1) {
	let o = V(e, t, r), s = V(e, n, i);
	o > s && ([o, s] = [s, o]);
	let c = V(e, "step", a);
	return {
		min: o,
		max: s,
		step: Number.isFinite(c) && c > 0 ? c : 1
	};
}
function ze(e) {
	return e.trim() === "" ? "—" : e;
}
var W = (e) => e.startsWith("--") ? e : e.replace(/^ms-?/, "-ms").replace(/[A-Z]/g, (e) => `-${e.toLowerCase()}`);
function Be(e, t, n) {
	let r = e.ownerDocument.createElement("span").style;
	for (let [e, n] of Object.entries(t ?? {})) {
		if (n == null) continue;
		let t = W(e);
		r.setProperty(t, String(n)), typeof n == "number" && !t.startsWith("--") && !r.getPropertyValue(t) && r.setProperty(t, `${n}px`);
	}
	let i = r.cssText;
	return e.style.cssText = i + n, () => {
		e.style.cssText = i;
	};
}
function Ve(e) {
	let t = e.authorStyle, n = e.authorStyleText, r = m((e) => {
		if (!e || !t) return;
		let n = Object.entries(t).map(([e, t]) => `${W(e)}:${t};`).join("");
		e.style.cssText += n;
	}, [t]);
	return (e) => {
		if (n) return {
			style: {
				...e,
				"--rmd-author-inline": `initial;${n}`
			},
			ref: (t) => t ? Be(t, e, n) : void 0
		};
		if (!t) return {
			style: e,
			ref: void 0
		};
		let i = { ...e };
		for (let [e, n] of Object.entries(t)) delete i[e], i[e] = n;
		return {
			style: i,
			ref: r
		};
	};
}
function He({ label: e, value: t, hint: n, className: r = "", multiline: i = !1, authorRoot: a }) {
	return /* @__PURE__ */ y("div", {
		className: `md-control local-static-control ${r}`.trim(),
		...a,
		children: [
			/* @__PURE__ */ v("span", {
				className: "md-label",
				children: e
			}),
			/* @__PURE__ */ v("span", {
				className: `local-static-value${i ? " local-static-multiline" : ""}`,
				"data-local-static-value": "",
				children: t
			}),
			n ? /* @__PURE__ */ v("span", {
				className: "md-hint",
				children: n
			}) : null
		]
	});
}
function Ue({ value: e, block: t = !1 }) {
	return t ? /* @__PURE__ */ v("div", {
		className: "local-print-value local-print-block",
		"aria-hidden": "true",
		"data-local-print-value": "",
		children: e
	}) : /* @__PURE__ */ v("span", {
		className: "local-print-value",
		"aria-hidden": "true",
		"data-local-print-value": "",
		children: e
	});
}
function We({ message: e, id: t }) {
	return e ? /* @__PURE__ */ v("span", {
		id: t,
		className: "field-error",
		role: "alert",
		children: e
	}) : null;
}
function Ge({ message: e }) {
	return /* @__PURE__ */ v("span", {
		className: "local-error",
		role: "alert",
		children: e ?? "Cannot compute"
	});
}
function Ke({ message: e }) {
	return /* @__PURE__ */ v("span", {
		className: "local-error local-tone-error",
		role: "status",
		children: e
	});
}
function qe(e, t) {
	let n = Math.max(0, Math.floor(e)), r = Math.floor(n / 60), i = n % 60;
	return r === 0 ? t(`${i} seconds`, `${i} 秒`) : `${r}:${String(i).padStart(2, "0")}`;
}
function Je(e) {
	return T(e);
}
function G(e, t, n = 0) {
	if (!t || n > 64) return "";
	let r = "";
	for (let i of t) switch (i.kind) {
		case "text":
		case "inlineCode":
		case "fallback":
			r += i.text;
			break;
		case "interpolation":
			try {
				let t = U(e.runtime.evaluate(i.text));
				r += t ?? e.locale.t("Cannot compute", "无法计算");
			} catch {
				r += e.locale.t("Cannot compute", "无法计算");
			}
			break;
		case "break":
			r += " ";
			break;
		default: r += G(e, i.children, n + 1);
	}
	return r;
}
function Ye(e, t) {
	return G(e, t.content.children) || t.content.attrs.value || "";
}
// src/react/sdk-core.tsx
function Xe(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("defineReactComponent requires a component definition object.");
	return e;
}
var K = /* @__PURE__ */ new WeakMap();
function q(e) {
	let t = K.get(e);
	if (t) return t;
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
	for (let t of e.components) n.set(t.definition.name, t), r.set(t.definition.id, t);
	let i = Object.freeze({
		byName: n,
		byId: r
	});
	return K.set(e, i), i;
}
function Ze(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("createReactConfig components must be LocalReactComponent values.");
	let t = e;
	if (!t.definition || typeof t.definition != "object") throw TypeError("A React component is missing its manifest definition.");
	if (typeof t.render != "function") throw TypeError("A React component is missing its render implementation.");
	if (t.renderStatic !== void 0 && typeof t.renderStatic != "function") throw TypeError("A React component renderStatic must be a function.");
	return t;
}
function Qe(e, n, r) {
	let a = i(e), o = n?.components;
	if (!Array.isArray(o)) throw TypeError("createReactConfig requires a components array.");
	let s = n?.presets ?? [];
	if (!Array.isArray(s)) throw TypeError("createReactConfig presets must be an array.");
	let c = [], l = [], u = /* @__PURE__ */ new Set(), d = (e, n) => {
		let r = Ze(e), i = Xe(r.definition), a = t(i);
		if (r.digest !== a) throw TypeError(`React component "${i.id}" from ${n} has a stale digest; create it with defineReactComponent.`);
		return c.push(r), r;
	};
	for (let e of r) {
		let t = d(e, "the default React preset");
		u.add(t);
	}
	for (let e of s) {
		if (!e || typeof e != "object" || !Array.isArray(e.components)) throw TypeError("createReactConfig preset must expose a components array.");
		for (let t of e.components) l.push(d(t, `preset "${e.id ?? ""}"`));
	}
	for (let e of o) l.push(d(e, "components"));
	let f = [], p = [];
	for (let e of a.registry) {
		let n = t(e), r = c.filter((t) => t.definition.id === e.id && t.definition.name === e.name && t.definition.version === e.version && t.digest === n);
		if (r.length === 0) {
			if (c.some((t) => t.definition.id === e.id)) throw TypeError(`React component "${e.id}@${e.version}" does not match the installed manifest contract.`);
			p.push(`${e.id}@${e.version}`);
		} else {
			if (r.length > 1) throw TypeError(`Component id "${e.id}" has more than one matching React implementation.`);
			f.push(r[0]);
		}
	}
	if (p.length > 0) {
		let e = new Set(a.registry.map((e) => e.id)), t = [...new Set(l.filter((t) => !e.has(t.definition.id)).map((e) => `${e.definition.id}@${e.definition.version}`))];
		throw TypeError(`createReactConfig is missing implementations for: ${p.join(", ")}.` + (t.length === 0 ? "" : ` Supplied implementation(s) ${t.join(", ")} are not declared by this local config.`));
	}
	let m = new Map(f.map((e) => [e.definition.id, e])), h = new Map(f.map((e) => [e.definition.name, e])), g = f.filter((e) => !u.has(e)), _ = Object.freeze(a.themes.slice()), v = Object.freeze({
		byName: new Map(h),
		byId: new Map(m)
	}), y = Object.freeze({
		config: a,
		components: Object.freeze(g),
		implementations: Object.freeze(f),
		themes: _,
		hostRenderer: rt(v)
	});
	return K.set(y, v), y;
}
var J = class extends Error {
	componentName;
	constructor(e) {
		super(`No React implementation is registered for <${e}>.`), this.name = "LocalReactExtensionMissingError", this.componentName = e;
	}
};
function $e(e) {
	try {
		return e.snapshot().revision;
	} catch {
		return 0;
	}
}
function et(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.max(0, Math.min(t, e.length)), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: n - i + 1
	};
}
function Y(e, t, n, r, i) {
	let { line: a, column: o } = et(r, n.start);
	return {
		code: e,
		message: `Component <${t}> failed: ${i instanceof Error ? i.message : String(i)}`,
		severity: "error",
		range: {
			start: n.start,
			end: n.end
		},
		line: a,
		column: o
	};
}
var X = class extends f {
	state = { failed: !1 };
	static getDerivedStateFromError() {
		return { failed: !0 };
	}
	componentDidCatch(e) {
		try {
			this.props.report([Y("local.extension.render", this.props.name, this.props.range, this.props.source, e)]);
		} catch {}
	}
	componentDidUpdate(e) {
		this.state.failed && e.revision !== this.props.revision && this.setState({ failed: !1 });
	}
	render() {
		return this.state.failed ? p("span", {
			className: "local-host-component local-host-unavailable local-sdk-unavailable",
			"data-local-host-component": this.props.name,
			"data-local-host-reason": "error",
			"data-rmd-source-start": String(this.props.range.start),
			"data-rmd-source-end": String(this.props.range.end),
			"data-rmd-source-node": this.props.nodeId,
			"data-rmd-source-type": "hostComponent",
			"data-rmd-source-component": this.props.name,
			role: "note"
		}, `Component <${this.props.name}> is unavailable here.`) : this.props.children;
	}
};
function tt({ implementation: e, node: t, environment: n }) {
	let r = e.definition.id.startsWith("reactive-md/"), i = n.mode === "static" ? "static" : "interactive";
	if (!r && !e.definition.capabilities[i]) throw Error(`Component ${e.definition.id} does not support ${i} rendering.`);
	let a = L(t, {
		runtime: n.runtime,
		authorStyle: n.authorStyle,
		authorStyleText: n.authorStyleText,
		dispatchAuthorAction: n.dispatchAuthorAction,
		network: n.network,
		services: n.services ?? n.runtime.services,
		mode: n.mode,
		locale: n.locale,
		visible: n.visible,
		disabled: n.disabled,
		disabledInvalid: n.disabledInvalid,
		resetToken: n.resetToken,
		definitionFor: n.definitionFor,
		validationFieldFor: n.validationField,
		validationHintFor: n.validationHint,
		sourceAttributes: n.sourceAttributes,
		renderChildren: (e, t) => n.renderChildren(e, t),
		renderInline: (e, t) => n.renderInline(e, t),
		renderToText: (e) => n.renderToText(e),
		report: n.report,
		targetId: n.targetId,
		anchorId: n.anchorId,
		jumpAllowed: n.jumpAllowed,
		jumpTo: n.jumpTo,
		urlPolicy: n.urlPolicy,
		imageResolver: n.imageResolver
	}), o = n.mode === "static" && e.renderStatic ? e.renderStatic : e.render;
	return p(o, a);
}
function Z(e, t, n) {
	let r = t.name ?? "", i = e.byName.get(r);
	if (!i) throw new J(r);
	let a;
	try {
		a = n.runtime.document.source;
	} catch {
		a = void 0;
	}
	let o = p(tt, {
		implementation: i,
		node: t,
		environment: n
	});
	return i.definition.id.startsWith("reactive-md/") ? o : p(X, {
		name: r,
		nodeId: t.id,
		revision: $e(n.runtime),
		range: t.range,
		source: a,
		report: n.report
	}, o);
}
function nt(e) {
	return (t, n) => Z(q(e), t, n);
}
function Q(e) {
	let t = "";
	for (let n of e ?? []) n.type === "text" || n.type === "inlineCode" || n.type === "code" ? t += n.value ?? "" : n.type === "math" || n.type === "inlineMath" || n.type === "image" ? t += n.value ?? n.alt ?? "" : t += Q(n.children);
	return t;
}
function rt(e) {
	return (t, n, r) => Z(e, t, {
		runtime: r.runtime,
		mode: r.mode,
		visible: r.visible,
		disabled: r.disabled,
		disabledInvalid: !1,
		resetToken: r.resetToken,
		locale: "en",
		renderChildren: (e, t) => r.render(e, t),
		renderInline: (e, t) => r.render(e, t),
		renderToText: (e) => Q(e),
		report: (e) => r.report(e),
		definitionFor: (t) => e.byName.get(t)?.definition,
		validationField: () => ({ invalid: !1 }),
		validationHint: () => null,
		sourceAttributes: () => ({}),
		targetId: () => void 0,
		anchorId: () => void 0,
		jumpAllowed: () => !1,
		jumpTo: () => "missing"
	});
}
function it(e, t) {
	let n = d(t, e.config);
	if (n.length || !t || typeof t != "object") return n;
	let r = t.components;
	if (!Array.isArray(r)) return n;
	let i = q(e);
	for (let e of r) i.byId.has(e.id) || n.push({
		code: "local.extension.renderer-missing",
		severity: "error",
		message: new J(e.name).message,
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	});
	return n;
}
function $(e, t, n) {
	try {
		e.report([Y("local.extension.event", e.instance.componentId, e.instance.range, n, t)]);
	} catch {}
}
function at(e, t, n) {
	return (...r) => {
		try {
			t(...r);
		} catch (t) {
			$(e, t, n);
		}
	};
}
export { U as A, xe as B, je as C, Ye as D, Re as E, Ae as F, he as G, be as H, Ve as I, ge as L, Le as M, ze as N, Ce as O, we as P, ve as R, Te as S, De as T, _e as U, ye as V, te as W, Ne as _, at as a, G as b, Ge as c, Ke as d, Me as f, Oe as g, Pe as h, $ as i, Fe as j, H as k, Ue as l, Ie as m, Qe as n, it as o, ke as p, nt as r, We as s, J as t, He as u, Je as v, V as w, Ee as x, qe as y, Se as z };
