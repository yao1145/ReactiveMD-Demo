import { o as e } from "./version-DAxuGOG2.js";
import { a as t, i as n, t as r } from "./preset-core-DeZPA8IE.js";
import { t as i } from "./default-components-s21NevON.js";
// src/presets/default.ts
var a = r({
	protocol: e,
	id: n,
	version: t,
	components: i
});
export { a as default, a as defaultPreset };
