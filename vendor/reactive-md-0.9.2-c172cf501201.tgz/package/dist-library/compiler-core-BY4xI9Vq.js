import { f as e, l as t, r as n, u as r } from "./latex-1w7aQgD5.js";
import { C as i, D as a, T as o, a as s, b as c, j as l, k as u, w as d, x as f, y as p } from "./version-DAxuGOG2.js";
import { _ as m, f as h, g, h as _, l as v, o as y, r as b, v as x, y as S } from "./document-theme-Cvvc_EOe.js";
import { a as C, c as w, i as T, o as E, t as D } from "./compile-BsTbvddN.js";
import { $ as O, B as k, C as A, D as j, E as M, F as N, G as P, H as ee, I as F, K as I, L, N as R, O as te, P as ne, Q as z, R as B, S as re, T as V, U as ie, V as ae, W as oe, X as H, Z as se, _ as ce, d as U, et as le, f as ue, h as W, j as de, k as G, l as K, m as q, p as fe, q as J, s as pe, u as me, w as he, z as Y } from "./validation-Dyy4pGO1.js";
import { C as ge, b as _e, x as ve } from "./config-validation-D3D7Dy2J.js";
import { n as ye, t as be } from "./types-daDo2c_w.js";
import { k as xe } from "./preset-core-DeZPA8IE.js";
import { o as Se } from "./props-sJ8vk0cr.js";
import { _ as Ce, a as we, b as X, c as Te, d as Ee, f as Z, g as De, h as Oe, i as ke, l as Ae, m as je, o as Me, p as Ne, s as Pe, u as Fe, v as Ie, y as Le } from "./registry-core-C9xOunaw.js";
// node_modules/bail/index.js
function Re(e) {
	if (e) throw e;
}
// node_modules/is-plain-obj/index.js
var ze = /* @__PURE__ */ e((/* @__PURE__ */ t(((e, t) => {
	var n = Object.prototype.hasOwnProperty, r = Object.prototype.toString, i = Object.defineProperty, a = Object.getOwnPropertyDescriptor, o = function(e) {
		return typeof Array.isArray == "function" ? Array.isArray(e) : r.call(e) === "[object Array]";
	}, s = function(e) {
		if (!e || r.call(e) !== "[object Object]") return !1;
		var t = n.call(e, "constructor"), i = e.constructor && e.constructor.prototype && n.call(e.constructor.prototype, "isPrototypeOf");
		if (e.constructor && !t && !i) return !1;
		for (var a in e);
		return a === void 0 || n.call(e, a);
	}, c = function(e, t) {
		i && t.name === "__proto__" ? i(e, t.name, {
			enumerable: !0,
			configurable: !0,
			value: t.newValue,
			writable: !0
		}) : e[t.name] = t.newValue;
	}, l = function(e, t) {
		if (t === "__proto__") {
			if (!n.call(e, t)) return;
			if (a) return a(e, t).value;
		}
		return e[t];
	};
	t.exports = function e() {
		var t, n, r, i, a, u, d = arguments[0], f = 1, p = arguments.length, m = !1;
		for (typeof d == "boolean" && (m = d, d = arguments[1] || {}, f = 2), (d == null || typeof d != "object" && typeof d != "function") && (d = {}); f < p; ++f) if (t = arguments[f], t != null) for (n in t) r = l(d, n), i = l(t, n), d !== i && (m && i && (s(i) || (a = o(i))) ? (a ? (a = !1, u = r && o(r) ? r : []) : u = r && s(r) ? r : {}, c(d, {
			name: n,
			newValue: e(m, u, i)
		})) : i !== void 0 && c(d, {
			name: n,
			newValue: i
		}));
		return d;
	};
})))(), 1);
function Be(e) {
	if (typeof e != "object" || !e) return !1;
	let t = Object.getPrototypeOf(e);
	return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e);
}
// node_modules/trough/lib/index.js
function Ve() {
	let e = [], t = {
		run: n,
		use: r
	};
	return t;
	function n(...t) {
		let n = -1, r = t.pop();
		if (typeof r != "function") throw TypeError("Expected function as last argument, not " + r);
		i(null, ...t);
		function i(a, ...o) {
			let s = e[++n], c = -1;
			if (a) r(a);
			else {
				for (; ++c < t.length;) (o[c] === null || o[c] === void 0) && (o[c] = t[c]);
				t = o, s ? He(s, i)(...o) : r(null, ...o);
			}
		}
	}
	function r(n) {
		if (typeof n != "function") throw TypeError("Expected `middelware` to be a function, not " + n);
		return e.push(n), t;
	}
}
function He(e, t) {
	let n;
	return r;
	function r(...t) {
		let r = e.length > t.length, o;
		r && t.push(i);
		try {
			o = e.apply(this, t);
		} catch (e) {
			let t = e;
			if (r && n) throw t;
			return i(t);
		}
		r || (o && o.then && typeof o.then == "function" ? o.then(a, i) : o instanceof Error ? i(o) : a(o));
	}
	function i(e, ...r) {
		n || (n = !0, t(e, ...r));
	}
	function a(e) {
		i(null, e);
	}
}
// node_modules/unist-util-stringify-position/lib/index.js
function Ue(e) {
	return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? Ge(e.position) : "start" in e || "end" in e ? Ge(e) : "line" in e || "column" in e ? We(e) : "";
}
function We(e) {
	return Ke(e && e.line) + ":" + Ke(e && e.column);
}
function Ge(e) {
	return We(e && e.start) + "-" + We(e && e.end);
}
function Ke(e) {
	return e && typeof e == "number" ? e : 1;
}
// node_modules/vfile-message/lib/index.js
var Q = class extends Error {
	constructor(e, t, n) {
		super(), typeof t == "string" && (n = t, t = void 0);
		let r = "", i = {}, a = !1;
		if (t && (i = "line" in t && "column" in t || "start" in t && "end" in t ? { place: t } : "type" in t ? {
			ancestors: [t],
			place: t.position
		} : { ...t }), typeof e == "string" ? r = e : !i.cause && e && (a = !0, r = e.message, i.cause = e), !i.ruleId && !i.source && typeof n == "string") {
			let e = n.indexOf(":");
			e === -1 ? i.ruleId = n : (i.source = n.slice(0, e), i.ruleId = n.slice(e + 1));
		}
		if (!i.place && i.ancestors && i.ancestors) {
			let e = i.ancestors[i.ancestors.length - 1];
			e && (i.place = e.position);
		}
		let o = i.place && "start" in i.place ? i.place.start : i.place;
		this.ancestors = i.ancestors || void 0, this.cause = i.cause || void 0, this.column = o ? o.column : void 0, this.fatal = void 0, this.file = "", this.message = r, this.line = o ? o.line : void 0, this.name = Ue(i.place) || "1:1", this.place = i.place || void 0, this.reason = this.message, this.ruleId = i.ruleId || void 0, this.source = i.source || void 0, this.stack = a && i.cause && typeof i.cause.stack == "string" ? i.cause.stack : "", this.actual = void 0, this.expected = void 0, this.note = void 0, this.url = void 0;
	}
};
Q.prototype.file = "", Q.prototype.name = "", Q.prototype.reason = "", Q.prototype.message = "", Q.prototype.stack = "", Q.prototype.column = void 0, Q.prototype.line = void 0, Q.prototype.ancestors = void 0, Q.prototype.cause = void 0, Q.prototype.fatal = void 0, Q.prototype.place = void 0, Q.prototype.ruleId = void 0, Q.prototype.source = void 0;
// node_modules/vfile/lib/minpath.browser.js
var qe = {
	basename: Je,
	dirname: Ye,
	extname: Xe,
	join: Ze,
	sep: "/"
};
function Je(e, t) {
	if (t !== void 0 && typeof t != "string") throw TypeError("\"ext\" argument must be a string");
	et(e);
	let n = 0, r = -1, i = e.length, a;
	if (t === void 0 || t.length === 0 || t.length > e.length) {
		for (; i--;) if (e.codePointAt(i) === 47) {
			if (a) {
				n = i + 1;
				break;
			}
		} else r < 0 && (a = !0, r = i + 1);
		return r < 0 ? "" : e.slice(n, r);
	}
	if (t === e) return "";
	let o = -1, s = t.length - 1;
	for (; i--;) if (e.codePointAt(i) === 47) {
		if (a) {
			n = i + 1;
			break;
		}
	} else o < 0 && (a = !0, o = i + 1), s > -1 && (e.codePointAt(i) === t.codePointAt(s--) ? s < 0 && (r = i) : (s = -1, r = o));
	return n === r ? r = o : r < 0 && (r = e.length), e.slice(n, r);
}
function Ye(e) {
	if (et(e), e.length === 0) return ".";
	let t = -1, n = e.length, r;
	for (; --n;) if (e.codePointAt(n) === 47) {
		if (r) {
			t = n;
			break;
		}
	} else r ||= !0;
	return t < 0 ? e.codePointAt(0) === 47 ? "/" : "." : t === 1 && e.codePointAt(0) === 47 ? "//" : e.slice(0, t);
}
function Xe(e) {
	et(e);
	let t = e.length, n = -1, r = 0, i = -1, a = 0, o;
	for (; t--;) {
		let s = e.codePointAt(t);
		if (s === 47) {
			if (o) {
				r = t + 1;
				break;
			}
		} else n < 0 && (o = !0, n = t + 1), s === 46 ? i < 0 ? i = t : a !== 1 && (a = 1) : i > -1 && (a = -1);
	}
	return i < 0 || n < 0 || a === 0 || a === 1 && i === n - 1 && i === r + 1 ? "" : e.slice(i, n);
}
function Ze(...e) {
	let t = -1, n;
	for (; ++t < e.length;) et(e[t]), e[t] && (n = n === void 0 ? e[t] : n + "/" + e[t]);
	return n === void 0 ? "." : Qe(n);
}
function Qe(e) {
	et(e);
	let t = e.codePointAt(0) === 47, n = $e(e, !t);
	return n.length === 0 && !t && (n = "."), n.length > 0 && e.codePointAt(e.length - 1) === 47 && (n += "/"), t ? "/" + n : n;
}
function $e(e, t) {
	let n = "", r = 0, i = -1, a = 0, o = -1, s, c;
	for (; ++o <= e.length;) {
		if (o < e.length) s = e.codePointAt(o);
		else if (s === 47) break;
		else s = 47;
		if (s === 47) {
			if (i !== o - 1 && a !== 1) {
				if (i !== o - 1 && a === 2) {
					if (n.length < 2 || r !== 2 || n.codePointAt(n.length - 1) !== 46 || n.codePointAt(n.length - 2) !== 46) {
						if (n.length > 2) {
							if (c = n.lastIndexOf("/"), c !== n.length - 1) {
								c < 0 ? (n = "", r = 0) : (n = n.slice(0, c), r = n.length - 1 - n.lastIndexOf("/")), i = o, a = 0;
								continue;
							}
						} else if (n.length > 0) {
							n = "", r = 0, i = o, a = 0;
							continue;
						}
					}
					t && (n = n.length > 0 ? n + "/.." : "..", r = 2);
				} else n.length > 0 ? n += "/" + e.slice(i + 1, o) : n = e.slice(i + 1, o), r = o - i - 1;
			}
			i = o, a = 0;
		} else s === 46 && a > -1 ? a++ : a = -1;
	}
	return n;
}
function et(e) {
	if (typeof e != "string") throw TypeError("Path must be a string. Received " + JSON.stringify(e));
}
// node_modules/vfile/lib/minproc.browser.js
var tt = { cwd: nt };
function nt() {
	return "/";
}
// node_modules/vfile/lib/minurl.shared.js
function rt(e) {
	return !!(typeof e == "object" && e && "href" in e && e.href && "protocol" in e && e.protocol && e.auth === void 0);
}
// node_modules/vfile/lib/minurl.browser.js
function it(e) {
	if (typeof e == "string") e = new URL(e);
	else if (!rt(e)) {
		let t = /* @__PURE__ */ TypeError("The \"path\" argument must be of type string or an instance of URL. Received `" + e + "`");
		throw t.code = "ERR_INVALID_ARG_TYPE", t;
	}
	if (e.protocol !== "file:") {
		let e = /* @__PURE__ */ TypeError("The URL must be of scheme file");
		throw e.code = "ERR_INVALID_URL_SCHEME", e;
	}
	return at(e);
}
function at(e) {
	if (e.hostname !== "") {
		let e = /* @__PURE__ */ TypeError("File URL host must be \"localhost\" or empty on darwin");
		throw e.code = "ERR_INVALID_FILE_URL_HOST", e;
	}
	let t = e.pathname, n = -1;
	for (; ++n < t.length;) if (t.codePointAt(n) === 37 && t.codePointAt(n + 1) === 50) {
		let e = t.codePointAt(n + 2);
		if (e === 70 || e === 102) {
			let e = /* @__PURE__ */ TypeError("File URL path must not include encoded / characters");
			throw e.code = "ERR_INVALID_FILE_URL_PATH", e;
		}
	}
	return decodeURIComponent(t);
}
// node_modules/vfile/lib/index.js
var ot = [
	"history",
	"path",
	"basename",
	"stem",
	"extname",
	"dirname"
], st = class {
	constructor(e) {
		let t;
		t = e ? rt(e) ? { path: e } : typeof e == "string" || dt(e) ? { value: e } : e : {}, this.cwd = "cwd" in t ? "" : tt.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
		let n = -1;
		for (; ++n < ot.length;) {
			let e = ot[n];
			e in t && t[e] !== void 0 && t[e] !== null && (this[e] = e === "history" ? [...t[e]] : t[e]);
		}
		let r;
		for (r in t) ot.includes(r) || (this[r] = t[r]);
	}
	get basename() {
		return typeof this.path == "string" ? qe.basename(this.path) : void 0;
	}
	set basename(e) {
		lt(e, "basename"), ct(e, "basename"), this.path = qe.join(this.dirname || "", e);
	}
	get dirname() {
		return typeof this.path == "string" ? qe.dirname(this.path) : void 0;
	}
	set dirname(e) {
		ut(this.basename, "dirname"), this.path = qe.join(e || "", this.basename);
	}
	get extname() {
		return typeof this.path == "string" ? qe.extname(this.path) : void 0;
	}
	set extname(e) {
		if (ct(e, "extname"), ut(this.dirname, "extname"), e) {
			if (e.codePointAt(0) !== 46) throw Error("`extname` must start with `.`");
			if (e.includes(".", 1)) throw Error("`extname` cannot contain multiple dots");
		}
		this.path = qe.join(this.dirname, this.stem + (e || ""));
	}
	get path() {
		return this.history[this.history.length - 1];
	}
	set path(e) {
		rt(e) && (e = it(e)), lt(e, "path"), this.path !== e && this.history.push(e);
	}
	get stem() {
		return typeof this.path == "string" ? qe.basename(this.path, this.extname) : void 0;
	}
	set stem(e) {
		lt(e, "stem"), ct(e, "stem"), this.path = qe.join(this.dirname || "", e + (this.extname || ""));
	}
	fail(e, t, n) {
		let r = this.message(e, t, n);
		throw r.fatal = !0, r;
	}
	info(e, t, n) {
		let r = this.message(e, t, n);
		return r.fatal = void 0, r;
	}
	message(e, t, n) {
		let r = new Q(e, t, n);
		return this.path && (r.name = this.path + ":" + r.name, r.file = this.path), r.fatal = !1, this.messages.push(r), r;
	}
	toString(e) {
		return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(e || void 0).decode(this.value);
	}
};
function ct(e, t) {
	if (e && e.includes(qe.sep)) throw Error("`" + t + "` cannot be a path: did not expect `" + qe.sep + "`");
}
function lt(e, t) {
	if (!e) throw Error("`" + t + "` cannot be empty");
}
function ut(e, t) {
	if (!e) throw Error("Setting `" + t + "` requires `path` to be set too");
}
function dt(e) {
	return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
// node_modules/unified/lib/callable-instance.js
var ft = (function(e) {
	let t = this.constructor.prototype, n = t[e], r = function() {
		return n.apply(r, arguments);
	};
	return Object.setPrototypeOf(r, t), r;
}), pt = {}.hasOwnProperty, mt = new class e extends ft {
	constructor() {
		super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = Ve();
	}
	copy() {
		let t = new e(), n = -1;
		for (; ++n < this.attachers.length;) {
			let e = this.attachers[n];
			t.use(...e);
		}
		return t.data((0, ze.default)(!0, {}, this.namespace)), t;
	}
	data(e, t) {
		return typeof e == "string" ? arguments.length === 2 ? (_t("data", this.frozen), this.namespace[e] = t, this) : pt.call(this.namespace, e) && this.namespace[e] || void 0 : e ? (_t("data", this.frozen), this.namespace = e, this) : this.namespace;
	}
	freeze() {
		if (this.frozen) return this;
		let e = this;
		for (; ++this.freezeIndex < this.attachers.length;) {
			let [t, ...n] = this.attachers[this.freezeIndex];
			if (n[0] === !1) continue;
			n[0] === !0 && (n[0] = void 0);
			let r = t.call(e, ...n);
			typeof r == "function" && this.transformers.use(r);
		}
		return this.frozen = !0, this.freezeIndex = Infinity, this;
	}
	parse(e) {
		this.freeze();
		let t = bt(e), n = this.parser || this.Parser;
		return ht("parse", n), n(String(t), t);
	}
	process(e, t) {
		let n = this;
		return this.freeze(), ht("process", this.parser || this.Parser), gt("process", this.compiler || this.Compiler), t ? r(void 0, t) : new Promise(r);
		function r(r, i) {
			let a = bt(e), o = n.parse(a);
			n.run(o, a, function(e, t, r) {
				if (e || !t || !r) return s(e);
				let i = t, a = n.stringify(i, r);
				St(a) ? r.value = a : r.result = a, s(e, r);
			});
			function s(e, n) {
				e || !n ? i(e) : r ? r(n) : t(void 0, n);
			}
		}
	}
	processSync(e) {
		let t = !1, n;
		return this.freeze(), ht("processSync", this.parser || this.Parser), gt("processSync", this.compiler || this.Compiler), this.process(e, r), yt("processSync", "process", t), n;
		function r(e, r) {
			t = !0, Re(e), n = r;
		}
	}
	run(e, t, n) {
		vt(e), this.freeze();
		let r = this.transformers;
		return !n && typeof t == "function" && (n = t, t = void 0), n ? i(void 0, n) : new Promise(i);
		function i(i, a) {
			let o = bt(t);
			r.run(e, o, s);
			function s(t, r, o) {
				let s = r || e;
				t ? a(t) : i ? i(s) : n(void 0, s, o);
			}
		}
	}
	runSync(e, t) {
		let n = !1, r;
		return this.run(e, t, i), yt("runSync", "run", n), r;
		function i(e, t) {
			Re(e), r = t, n = !0;
		}
	}
	stringify(e, t) {
		this.freeze();
		let n = bt(t), r = this.compiler || this.Compiler;
		return gt("stringify", r), vt(e), r(e, n);
	}
	use(e, ...t) {
		let n = this.attachers, r = this.namespace;
		if (_t("use", this.frozen), e != null) {
			if (typeof e == "function") s(e, t);
			else if (typeof e == "object") Array.isArray(e) ? o(e) : a(e);
			else throw TypeError("Expected usable value, not `" + e + "`");
		}
		return this;
		function i(e) {
			if (typeof e == "function") s(e, []);
			else if (typeof e == "object") {
				if (Array.isArray(e)) {
					let [t, ...n] = e;
					s(t, n);
				} else a(e);
			} else throw TypeError("Expected usable value, not `" + e + "`");
		}
		function a(e) {
			if (!("plugins" in e) && !("settings" in e)) throw Error("Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither");
			o(e.plugins), e.settings && (r.settings = (0, ze.default)(!0, r.settings, e.settings));
		}
		function o(e) {
			let t = -1;
			if (e != null) {
				if (Array.isArray(e)) for (; ++t < e.length;) {
					let n = e[t];
					i(n);
				}
				else throw TypeError("Expected a list of plugins, not `" + e + "`");
			}
		}
		function s(e, t) {
			let r = -1, i = -1;
			for (; ++r < n.length;) if (n[r][0] === e) {
				i = r;
				break;
			}
			if (i === -1) n.push([e, ...t]);
			else if (t.length > 0) {
				let [r, ...a] = t, o = n[i][1];
				Be(o) && Be(r) && (r = (0, ze.default)(!0, o, r)), n[i] = [
					e,
					r,
					...a
				];
			}
		}
	}
}().freeze();
function ht(e, t) {
	if (typeof t != "function") throw TypeError("Cannot `" + e + "` without `parser`");
}
function gt(e, t) {
	if (typeof t != "function") throw TypeError("Cannot `" + e + "` without `compiler`");
}
function _t(e, t) {
	if (t) throw Error("Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.");
}
function vt(e) {
	if (!Be(e) || typeof e.type != "string") throw TypeError("Expected node, got `" + e + "`");
}
function yt(e, t, n) {
	if (!n) throw Error("`" + e + "` finished async. Use `" + t + "` instead");
}
function bt(e) {
	return xt(e) ? e : new st(e);
}
function xt(e) {
	return !!(e && typeof e == "object" && "message" in e && "messages" in e);
}
function St(e) {
	return typeof e == "string" || Ct(e);
}
function Ct(e) {
	return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
// node_modules/character-entities/index.js
var wt = {
	AElig: "Æ",
	AMP: "&",
	Aacute: "Á",
	Abreve: "Ă",
	Acirc: "Â",
	Acy: "А",
	Afr: "𝔄",
	Agrave: "À",
	Alpha: "Α",
	Amacr: "Ā",
	And: "⩓",
	Aogon: "Ą",
	Aopf: "𝔸",
	ApplyFunction: "⁡",
	Aring: "Å",
	Ascr: "𝒜",
	Assign: "≔",
	Atilde: "Ã",
	Auml: "Ä",
	Backslash: "∖",
	Barv: "⫧",
	Barwed: "⌆",
	Bcy: "Б",
	Because: "∵",
	Bernoullis: "ℬ",
	Beta: "Β",
	Bfr: "𝔅",
	Bopf: "𝔹",
	Breve: "˘",
	Bscr: "ℬ",
	Bumpeq: "≎",
	CHcy: "Ч",
	COPY: "©",
	Cacute: "Ć",
	Cap: "⋒",
	CapitalDifferentialD: "ⅅ",
	Cayleys: "ℭ",
	Ccaron: "Č",
	Ccedil: "Ç",
	Ccirc: "Ĉ",
	Cconint: "∰",
	Cdot: "Ċ",
	Cedilla: "¸",
	CenterDot: "·",
	Cfr: "ℭ",
	Chi: "Χ",
	CircleDot: "⊙",
	CircleMinus: "⊖",
	CirclePlus: "⊕",
	CircleTimes: "⊗",
	ClockwiseContourIntegral: "∲",
	CloseCurlyDoubleQuote: "”",
	CloseCurlyQuote: "’",
	Colon: "∷",
	Colone: "⩴",
	Congruent: "≡",
	Conint: "∯",
	ContourIntegral: "∮",
	Copf: "ℂ",
	Coproduct: "∐",
	CounterClockwiseContourIntegral: "∳",
	Cross: "⨯",
	Cscr: "𝒞",
	Cup: "⋓",
	CupCap: "≍",
	DD: "ⅅ",
	DDotrahd: "⤑",
	DJcy: "Ђ",
	DScy: "Ѕ",
	DZcy: "Џ",
	Dagger: "‡",
	Darr: "↡",
	Dashv: "⫤",
	Dcaron: "Ď",
	Dcy: "Д",
	Del: "∇",
	Delta: "Δ",
	Dfr: "𝔇",
	DiacriticalAcute: "´",
	DiacriticalDot: "˙",
	DiacriticalDoubleAcute: "˝",
	DiacriticalGrave: "`",
	DiacriticalTilde: "˜",
	Diamond: "⋄",
	DifferentialD: "ⅆ",
	Dopf: "𝔻",
	Dot: "¨",
	DotDot: "⃜",
	DotEqual: "≐",
	DoubleContourIntegral: "∯",
	DoubleDot: "¨",
	DoubleDownArrow: "⇓",
	DoubleLeftArrow: "⇐",
	DoubleLeftRightArrow: "⇔",
	DoubleLeftTee: "⫤",
	DoubleLongLeftArrow: "⟸",
	DoubleLongLeftRightArrow: "⟺",
	DoubleLongRightArrow: "⟹",
	DoubleRightArrow: "⇒",
	DoubleRightTee: "⊨",
	DoubleUpArrow: "⇑",
	DoubleUpDownArrow: "⇕",
	DoubleVerticalBar: "∥",
	DownArrow: "↓",
	DownArrowBar: "⤓",
	DownArrowUpArrow: "⇵",
	DownBreve: "̑",
	DownLeftRightVector: "⥐",
	DownLeftTeeVector: "⥞",
	DownLeftVector: "↽",
	DownLeftVectorBar: "⥖",
	DownRightTeeVector: "⥟",
	DownRightVector: "⇁",
	DownRightVectorBar: "⥗",
	DownTee: "⊤",
	DownTeeArrow: "↧",
	Downarrow: "⇓",
	Dscr: "𝒟",
	Dstrok: "Đ",
	ENG: "Ŋ",
	ETH: "Ð",
	Eacute: "É",
	Ecaron: "Ě",
	Ecirc: "Ê",
	Ecy: "Э",
	Edot: "Ė",
	Efr: "𝔈",
	Egrave: "È",
	Element: "∈",
	Emacr: "Ē",
	EmptySmallSquare: "◻",
	EmptyVerySmallSquare: "▫",
	Eogon: "Ę",
	Eopf: "𝔼",
	Epsilon: "Ε",
	Equal: "⩵",
	EqualTilde: "≂",
	Equilibrium: "⇌",
	Escr: "ℰ",
	Esim: "⩳",
	Eta: "Η",
	Euml: "Ë",
	Exists: "∃",
	ExponentialE: "ⅇ",
	Fcy: "Ф",
	Ffr: "𝔉",
	FilledSmallSquare: "◼",
	FilledVerySmallSquare: "▪",
	Fopf: "𝔽",
	ForAll: "∀",
	Fouriertrf: "ℱ",
	Fscr: "ℱ",
	GJcy: "Ѓ",
	GT: ">",
	Gamma: "Γ",
	Gammad: "Ϝ",
	Gbreve: "Ğ",
	Gcedil: "Ģ",
	Gcirc: "Ĝ",
	Gcy: "Г",
	Gdot: "Ġ",
	Gfr: "𝔊",
	Gg: "⋙",
	Gopf: "𝔾",
	GreaterEqual: "≥",
	GreaterEqualLess: "⋛",
	GreaterFullEqual: "≧",
	GreaterGreater: "⪢",
	GreaterLess: "≷",
	GreaterSlantEqual: "⩾",
	GreaterTilde: "≳",
	Gscr: "𝒢",
	Gt: "≫",
	HARDcy: "Ъ",
	Hacek: "ˇ",
	Hat: "^",
	Hcirc: "Ĥ",
	Hfr: "ℌ",
	HilbertSpace: "ℋ",
	Hopf: "ℍ",
	HorizontalLine: "─",
	Hscr: "ℋ",
	Hstrok: "Ħ",
	HumpDownHump: "≎",
	HumpEqual: "≏",
	IEcy: "Е",
	IJlig: "Ĳ",
	IOcy: "Ё",
	Iacute: "Í",
	Icirc: "Î",
	Icy: "И",
	Idot: "İ",
	Ifr: "ℑ",
	Igrave: "Ì",
	Im: "ℑ",
	Imacr: "Ī",
	ImaginaryI: "ⅈ",
	Implies: "⇒",
	Int: "∬",
	Integral: "∫",
	Intersection: "⋂",
	InvisibleComma: "⁣",
	InvisibleTimes: "⁢",
	Iogon: "Į",
	Iopf: "𝕀",
	Iota: "Ι",
	Iscr: "ℐ",
	Itilde: "Ĩ",
	Iukcy: "І",
	Iuml: "Ï",
	Jcirc: "Ĵ",
	Jcy: "Й",
	Jfr: "𝔍",
	Jopf: "𝕁",
	Jscr: "𝒥",
	Jsercy: "Ј",
	Jukcy: "Є",
	KHcy: "Х",
	KJcy: "Ќ",
	Kappa: "Κ",
	Kcedil: "Ķ",
	Kcy: "К",
	Kfr: "𝔎",
	Kopf: "𝕂",
	Kscr: "𝒦",
	LJcy: "Љ",
	LT: "<",
	Lacute: "Ĺ",
	Lambda: "Λ",
	Lang: "⟪",
	Laplacetrf: "ℒ",
	Larr: "↞",
	Lcaron: "Ľ",
	Lcedil: "Ļ",
	Lcy: "Л",
	LeftAngleBracket: "⟨",
	LeftArrow: "←",
	LeftArrowBar: "⇤",
	LeftArrowRightArrow: "⇆",
	LeftCeiling: "⌈",
	LeftDoubleBracket: "⟦",
	LeftDownTeeVector: "⥡",
	LeftDownVector: "⇃",
	LeftDownVectorBar: "⥙",
	LeftFloor: "⌊",
	LeftRightArrow: "↔",
	LeftRightVector: "⥎",
	LeftTee: "⊣",
	LeftTeeArrow: "↤",
	LeftTeeVector: "⥚",
	LeftTriangle: "⊲",
	LeftTriangleBar: "⧏",
	LeftTriangleEqual: "⊴",
	LeftUpDownVector: "⥑",
	LeftUpTeeVector: "⥠",
	LeftUpVector: "↿",
	LeftUpVectorBar: "⥘",
	LeftVector: "↼",
	LeftVectorBar: "⥒",
	Leftarrow: "⇐",
	Leftrightarrow: "⇔",
	LessEqualGreater: "⋚",
	LessFullEqual: "≦",
	LessGreater: "≶",
	LessLess: "⪡",
	LessSlantEqual: "⩽",
	LessTilde: "≲",
	Lfr: "𝔏",
	Ll: "⋘",
	Lleftarrow: "⇚",
	Lmidot: "Ŀ",
	LongLeftArrow: "⟵",
	LongLeftRightArrow: "⟷",
	LongRightArrow: "⟶",
	Longleftarrow: "⟸",
	Longleftrightarrow: "⟺",
	Longrightarrow: "⟹",
	Lopf: "𝕃",
	LowerLeftArrow: "↙",
	LowerRightArrow: "↘",
	Lscr: "ℒ",
	Lsh: "↰",
	Lstrok: "Ł",
	Lt: "≪",
	Map: "⤅",
	Mcy: "М",
	MediumSpace: " ",
	Mellintrf: "ℳ",
	Mfr: "𝔐",
	MinusPlus: "∓",
	Mopf: "𝕄",
	Mscr: "ℳ",
	Mu: "Μ",
	NJcy: "Њ",
	Nacute: "Ń",
	Ncaron: "Ň",
	Ncedil: "Ņ",
	Ncy: "Н",
	NegativeMediumSpace: "​",
	NegativeThickSpace: "​",
	NegativeThinSpace: "​",
	NegativeVeryThinSpace: "​",
	NestedGreaterGreater: "≫",
	NestedLessLess: "≪",
	NewLine: "\n",
	Nfr: "𝔑",
	NoBreak: "⁠",
	NonBreakingSpace: "\xA0",
	Nopf: "ℕ",
	Not: "⫬",
	NotCongruent: "≢",
	NotCupCap: "≭",
	NotDoubleVerticalBar: "∦",
	NotElement: "∉",
	NotEqual: "≠",
	NotEqualTilde: "≂̸",
	NotExists: "∄",
	NotGreater: "≯",
	NotGreaterEqual: "≱",
	NotGreaterFullEqual: "≧̸",
	NotGreaterGreater: "≫̸",
	NotGreaterLess: "≹",
	NotGreaterSlantEqual: "⩾̸",
	NotGreaterTilde: "≵",
	NotHumpDownHump: "≎̸",
	NotHumpEqual: "≏̸",
	NotLeftTriangle: "⋪",
	NotLeftTriangleBar: "⧏̸",
	NotLeftTriangleEqual: "⋬",
	NotLess: "≮",
	NotLessEqual: "≰",
	NotLessGreater: "≸",
	NotLessLess: "≪̸",
	NotLessSlantEqual: "⩽̸",
	NotLessTilde: "≴",
	NotNestedGreaterGreater: "⪢̸",
	NotNestedLessLess: "⪡̸",
	NotPrecedes: "⊀",
	NotPrecedesEqual: "⪯̸",
	NotPrecedesSlantEqual: "⋠",
	NotReverseElement: "∌",
	NotRightTriangle: "⋫",
	NotRightTriangleBar: "⧐̸",
	NotRightTriangleEqual: "⋭",
	NotSquareSubset: "⊏̸",
	NotSquareSubsetEqual: "⋢",
	NotSquareSuperset: "⊐̸",
	NotSquareSupersetEqual: "⋣",
	NotSubset: "⊂⃒",
	NotSubsetEqual: "⊈",
	NotSucceeds: "⊁",
	NotSucceedsEqual: "⪰̸",
	NotSucceedsSlantEqual: "⋡",
	NotSucceedsTilde: "≿̸",
	NotSuperset: "⊃⃒",
	NotSupersetEqual: "⊉",
	NotTilde: "≁",
	NotTildeEqual: "≄",
	NotTildeFullEqual: "≇",
	NotTildeTilde: "≉",
	NotVerticalBar: "∤",
	Nscr: "𝒩",
	Ntilde: "Ñ",
	Nu: "Ν",
	OElig: "Œ",
	Oacute: "Ó",
	Ocirc: "Ô",
	Ocy: "О",
	Odblac: "Ő",
	Ofr: "𝔒",
	Ograve: "Ò",
	Omacr: "Ō",
	Omega: "Ω",
	Omicron: "Ο",
	Oopf: "𝕆",
	OpenCurlyDoubleQuote: "“",
	OpenCurlyQuote: "‘",
	Or: "⩔",
	Oscr: "𝒪",
	Oslash: "Ø",
	Otilde: "Õ",
	Otimes: "⨷",
	Ouml: "Ö",
	OverBar: "‾",
	OverBrace: "⏞",
	OverBracket: "⎴",
	OverParenthesis: "⏜",
	PartialD: "∂",
	Pcy: "П",
	Pfr: "𝔓",
	Phi: "Φ",
	Pi: "Π",
	PlusMinus: "±",
	Poincareplane: "ℌ",
	Popf: "ℙ",
	Pr: "⪻",
	Precedes: "≺",
	PrecedesEqual: "⪯",
	PrecedesSlantEqual: "≼",
	PrecedesTilde: "≾",
	Prime: "″",
	Product: "∏",
	Proportion: "∷",
	Proportional: "∝",
	Pscr: "𝒫",
	Psi: "Ψ",
	QUOT: "\"",
	Qfr: "𝔔",
	Qopf: "ℚ",
	Qscr: "𝒬",
	RBarr: "⤐",
	REG: "®",
	Racute: "Ŕ",
	Rang: "⟫",
	Rarr: "↠",
	Rarrtl: "⤖",
	Rcaron: "Ř",
	Rcedil: "Ŗ",
	Rcy: "Р",
	Re: "ℜ",
	ReverseElement: "∋",
	ReverseEquilibrium: "⇋",
	ReverseUpEquilibrium: "⥯",
	Rfr: "ℜ",
	Rho: "Ρ",
	RightAngleBracket: "⟩",
	RightArrow: "→",
	RightArrowBar: "⇥",
	RightArrowLeftArrow: "⇄",
	RightCeiling: "⌉",
	RightDoubleBracket: "⟧",
	RightDownTeeVector: "⥝",
	RightDownVector: "⇂",
	RightDownVectorBar: "⥕",
	RightFloor: "⌋",
	RightTee: "⊢",
	RightTeeArrow: "↦",
	RightTeeVector: "⥛",
	RightTriangle: "⊳",
	RightTriangleBar: "⧐",
	RightTriangleEqual: "⊵",
	RightUpDownVector: "⥏",
	RightUpTeeVector: "⥜",
	RightUpVector: "↾",
	RightUpVectorBar: "⥔",
	RightVector: "⇀",
	RightVectorBar: "⥓",
	Rightarrow: "⇒",
	Ropf: "ℝ",
	RoundImplies: "⥰",
	Rrightarrow: "⇛",
	Rscr: "ℛ",
	Rsh: "↱",
	RuleDelayed: "⧴",
	SHCHcy: "Щ",
	SHcy: "Ш",
	SOFTcy: "Ь",
	Sacute: "Ś",
	Sc: "⪼",
	Scaron: "Š",
	Scedil: "Ş",
	Scirc: "Ŝ",
	Scy: "С",
	Sfr: "𝔖",
	ShortDownArrow: "↓",
	ShortLeftArrow: "←",
	ShortRightArrow: "→",
	ShortUpArrow: "↑",
	Sigma: "Σ",
	SmallCircle: "∘",
	Sopf: "𝕊",
	Sqrt: "√",
	Square: "□",
	SquareIntersection: "⊓",
	SquareSubset: "⊏",
	SquareSubsetEqual: "⊑",
	SquareSuperset: "⊐",
	SquareSupersetEqual: "⊒",
	SquareUnion: "⊔",
	Sscr: "𝒮",
	Star: "⋆",
	Sub: "⋐",
	Subset: "⋐",
	SubsetEqual: "⊆",
	Succeeds: "≻",
	SucceedsEqual: "⪰",
	SucceedsSlantEqual: "≽",
	SucceedsTilde: "≿",
	SuchThat: "∋",
	Sum: "∑",
	Sup: "⋑",
	Superset: "⊃",
	SupersetEqual: "⊇",
	Supset: "⋑",
	THORN: "Þ",
	TRADE: "™",
	TSHcy: "Ћ",
	TScy: "Ц",
	Tab: "	",
	Tau: "Τ",
	Tcaron: "Ť",
	Tcedil: "Ţ",
	Tcy: "Т",
	Tfr: "𝔗",
	Therefore: "∴",
	Theta: "Θ",
	ThickSpace: "  ",
	ThinSpace: " ",
	Tilde: "∼",
	TildeEqual: "≃",
	TildeFullEqual: "≅",
	TildeTilde: "≈",
	Topf: "𝕋",
	TripleDot: "⃛",
	Tscr: "𝒯",
	Tstrok: "Ŧ",
	Uacute: "Ú",
	Uarr: "↟",
	Uarrocir: "⥉",
	Ubrcy: "Ў",
	Ubreve: "Ŭ",
	Ucirc: "Û",
	Ucy: "У",
	Udblac: "Ű",
	Ufr: "𝔘",
	Ugrave: "Ù",
	Umacr: "Ū",
	UnderBar: "_",
	UnderBrace: "⏟",
	UnderBracket: "⎵",
	UnderParenthesis: "⏝",
	Union: "⋃",
	UnionPlus: "⊎",
	Uogon: "Ų",
	Uopf: "𝕌",
	UpArrow: "↑",
	UpArrowBar: "⤒",
	UpArrowDownArrow: "⇅",
	UpDownArrow: "↕",
	UpEquilibrium: "⥮",
	UpTee: "⊥",
	UpTeeArrow: "↥",
	Uparrow: "⇑",
	Updownarrow: "⇕",
	UpperLeftArrow: "↖",
	UpperRightArrow: "↗",
	Upsi: "ϒ",
	Upsilon: "Υ",
	Uring: "Ů",
	Uscr: "𝒰",
	Utilde: "Ũ",
	Uuml: "Ü",
	VDash: "⊫",
	Vbar: "⫫",
	Vcy: "В",
	Vdash: "⊩",
	Vdashl: "⫦",
	Vee: "⋁",
	Verbar: "‖",
	Vert: "‖",
	VerticalBar: "∣",
	VerticalLine: "|",
	VerticalSeparator: "❘",
	VerticalTilde: "≀",
	VeryThinSpace: " ",
	Vfr: "𝔙",
	Vopf: "𝕍",
	Vscr: "𝒱",
	Vvdash: "⊪",
	Wcirc: "Ŵ",
	Wedge: "⋀",
	Wfr: "𝔚",
	Wopf: "𝕎",
	Wscr: "𝒲",
	Xfr: "𝔛",
	Xi: "Ξ",
	Xopf: "𝕏",
	Xscr: "𝒳",
	YAcy: "Я",
	YIcy: "Ї",
	YUcy: "Ю",
	Yacute: "Ý",
	Ycirc: "Ŷ",
	Ycy: "Ы",
	Yfr: "𝔜",
	Yopf: "𝕐",
	Yscr: "𝒴",
	Yuml: "Ÿ",
	ZHcy: "Ж",
	Zacute: "Ź",
	Zcaron: "Ž",
	Zcy: "З",
	Zdot: "Ż",
	ZeroWidthSpace: "​",
	Zeta: "Ζ",
	Zfr: "ℨ",
	Zopf: "ℤ",
	Zscr: "𝒵",
	aacute: "á",
	abreve: "ă",
	ac: "∾",
	acE: "∾̳",
	acd: "∿",
	acirc: "â",
	acute: "´",
	acy: "а",
	aelig: "æ",
	af: "⁡",
	afr: "𝔞",
	agrave: "à",
	alefsym: "ℵ",
	aleph: "ℵ",
	alpha: "α",
	amacr: "ā",
	amalg: "⨿",
	amp: "&",
	and: "∧",
	andand: "⩕",
	andd: "⩜",
	andslope: "⩘",
	andv: "⩚",
	ang: "∠",
	ange: "⦤",
	angle: "∠",
	angmsd: "∡",
	angmsdaa: "⦨",
	angmsdab: "⦩",
	angmsdac: "⦪",
	angmsdad: "⦫",
	angmsdae: "⦬",
	angmsdaf: "⦭",
	angmsdag: "⦮",
	angmsdah: "⦯",
	angrt: "∟",
	angrtvb: "⊾",
	angrtvbd: "⦝",
	angsph: "∢",
	angst: "Å",
	angzarr: "⍼",
	aogon: "ą",
	aopf: "𝕒",
	ap: "≈",
	apE: "⩰",
	apacir: "⩯",
	ape: "≊",
	apid: "≋",
	apos: "'",
	approx: "≈",
	approxeq: "≊",
	aring: "å",
	ascr: "𝒶",
	ast: "*",
	asymp: "≈",
	asympeq: "≍",
	atilde: "ã",
	auml: "ä",
	awconint: "∳",
	awint: "⨑",
	bNot: "⫭",
	backcong: "≌",
	backepsilon: "϶",
	backprime: "‵",
	backsim: "∽",
	backsimeq: "⋍",
	barvee: "⊽",
	barwed: "⌅",
	barwedge: "⌅",
	bbrk: "⎵",
	bbrktbrk: "⎶",
	bcong: "≌",
	bcy: "б",
	bdquo: "„",
	becaus: "∵",
	because: "∵",
	bemptyv: "⦰",
	bepsi: "϶",
	bernou: "ℬ",
	beta: "β",
	beth: "ℶ",
	between: "≬",
	bfr: "𝔟",
	bigcap: "⋂",
	bigcirc: "◯",
	bigcup: "⋃",
	bigodot: "⨀",
	bigoplus: "⨁",
	bigotimes: "⨂",
	bigsqcup: "⨆",
	bigstar: "★",
	bigtriangledown: "▽",
	bigtriangleup: "△",
	biguplus: "⨄",
	bigvee: "⋁",
	bigwedge: "⋀",
	bkarow: "⤍",
	blacklozenge: "⧫",
	blacksquare: "▪",
	blacktriangle: "▴",
	blacktriangledown: "▾",
	blacktriangleleft: "◂",
	blacktriangleright: "▸",
	blank: "␣",
	blk12: "▒",
	blk14: "░",
	blk34: "▓",
	block: "█",
	bne: "=⃥",
	bnequiv: "≡⃥",
	bnot: "⌐",
	bopf: "𝕓",
	bot: "⊥",
	bottom: "⊥",
	bowtie: "⋈",
	boxDL: "╗",
	boxDR: "╔",
	boxDl: "╖",
	boxDr: "╓",
	boxH: "═",
	boxHD: "╦",
	boxHU: "╩",
	boxHd: "╤",
	boxHu: "╧",
	boxUL: "╝",
	boxUR: "╚",
	boxUl: "╜",
	boxUr: "╙",
	boxV: "║",
	boxVH: "╬",
	boxVL: "╣",
	boxVR: "╠",
	boxVh: "╫",
	boxVl: "╢",
	boxVr: "╟",
	boxbox: "⧉",
	boxdL: "╕",
	boxdR: "╒",
	boxdl: "┐",
	boxdr: "┌",
	boxh: "─",
	boxhD: "╥",
	boxhU: "╨",
	boxhd: "┬",
	boxhu: "┴",
	boxminus: "⊟",
	boxplus: "⊞",
	boxtimes: "⊠",
	boxuL: "╛",
	boxuR: "╘",
	boxul: "┘",
	boxur: "└",
	boxv: "│",
	boxvH: "╪",
	boxvL: "╡",
	boxvR: "╞",
	boxvh: "┼",
	boxvl: "┤",
	boxvr: "├",
	bprime: "‵",
	breve: "˘",
	brvbar: "¦",
	bscr: "𝒷",
	bsemi: "⁏",
	bsim: "∽",
	bsime: "⋍",
	bsol: "\\",
	bsolb: "⧅",
	bsolhsub: "⟈",
	bull: "•",
	bullet: "•",
	bump: "≎",
	bumpE: "⪮",
	bumpe: "≏",
	bumpeq: "≏",
	cacute: "ć",
	cap: "∩",
	capand: "⩄",
	capbrcup: "⩉",
	capcap: "⩋",
	capcup: "⩇",
	capdot: "⩀",
	caps: "∩︀",
	caret: "⁁",
	caron: "ˇ",
	ccaps: "⩍",
	ccaron: "č",
	ccedil: "ç",
	ccirc: "ĉ",
	ccups: "⩌",
	ccupssm: "⩐",
	cdot: "ċ",
	cedil: "¸",
	cemptyv: "⦲",
	cent: "¢",
	centerdot: "·",
	cfr: "𝔠",
	chcy: "ч",
	check: "✓",
	checkmark: "✓",
	chi: "χ",
	cir: "○",
	cirE: "⧃",
	circ: "ˆ",
	circeq: "≗",
	circlearrowleft: "↺",
	circlearrowright: "↻",
	circledR: "®",
	circledS: "Ⓢ",
	circledast: "⊛",
	circledcirc: "⊚",
	circleddash: "⊝",
	cire: "≗",
	cirfnint: "⨐",
	cirmid: "⫯",
	cirscir: "⧂",
	clubs: "♣",
	clubsuit: "♣",
	colon: ":",
	colone: "≔",
	coloneq: "≔",
	comma: ",",
	commat: "@",
	comp: "∁",
	compfn: "∘",
	complement: "∁",
	complexes: "ℂ",
	cong: "≅",
	congdot: "⩭",
	conint: "∮",
	copf: "𝕔",
	coprod: "∐",
	copy: "©",
	copysr: "℗",
	crarr: "↵",
	cross: "✗",
	cscr: "𝒸",
	csub: "⫏",
	csube: "⫑",
	csup: "⫐",
	csupe: "⫒",
	ctdot: "⋯",
	cudarrl: "⤸",
	cudarrr: "⤵",
	cuepr: "⋞",
	cuesc: "⋟",
	cularr: "↶",
	cularrp: "⤽",
	cup: "∪",
	cupbrcap: "⩈",
	cupcap: "⩆",
	cupcup: "⩊",
	cupdot: "⊍",
	cupor: "⩅",
	cups: "∪︀",
	curarr: "↷",
	curarrm: "⤼",
	curlyeqprec: "⋞",
	curlyeqsucc: "⋟",
	curlyvee: "⋎",
	curlywedge: "⋏",
	curren: "¤",
	curvearrowleft: "↶",
	curvearrowright: "↷",
	cuvee: "⋎",
	cuwed: "⋏",
	cwconint: "∲",
	cwint: "∱",
	cylcty: "⌭",
	dArr: "⇓",
	dHar: "⥥",
	dagger: "†",
	daleth: "ℸ",
	darr: "↓",
	dash: "‐",
	dashv: "⊣",
	dbkarow: "⤏",
	dblac: "˝",
	dcaron: "ď",
	dcy: "д",
	dd: "ⅆ",
	ddagger: "‡",
	ddarr: "⇊",
	ddotseq: "⩷",
	deg: "°",
	delta: "δ",
	demptyv: "⦱",
	dfisht: "⥿",
	dfr: "𝔡",
	dharl: "⇃",
	dharr: "⇂",
	diam: "⋄",
	diamond: "⋄",
	diamondsuit: "♦",
	diams: "♦",
	die: "¨",
	digamma: "ϝ",
	disin: "⋲",
	div: "÷",
	divide: "÷",
	divideontimes: "⋇",
	divonx: "⋇",
	djcy: "ђ",
	dlcorn: "⌞",
	dlcrop: "⌍",
	dollar: "$",
	dopf: "𝕕",
	dot: "˙",
	doteq: "≐",
	doteqdot: "≑",
	dotminus: "∸",
	dotplus: "∔",
	dotsquare: "⊡",
	doublebarwedge: "⌆",
	downarrow: "↓",
	downdownarrows: "⇊",
	downharpoonleft: "⇃",
	downharpoonright: "⇂",
	drbkarow: "⤐",
	drcorn: "⌟",
	drcrop: "⌌",
	dscr: "𝒹",
	dscy: "ѕ",
	dsol: "⧶",
	dstrok: "đ",
	dtdot: "⋱",
	dtri: "▿",
	dtrif: "▾",
	duarr: "⇵",
	duhar: "⥯",
	dwangle: "⦦",
	dzcy: "џ",
	dzigrarr: "⟿",
	eDDot: "⩷",
	eDot: "≑",
	eacute: "é",
	easter: "⩮",
	ecaron: "ě",
	ecir: "≖",
	ecirc: "ê",
	ecolon: "≕",
	ecy: "э",
	edot: "ė",
	ee: "ⅇ",
	efDot: "≒",
	efr: "𝔢",
	eg: "⪚",
	egrave: "è",
	egs: "⪖",
	egsdot: "⪘",
	el: "⪙",
	elinters: "⏧",
	ell: "ℓ",
	els: "⪕",
	elsdot: "⪗",
	emacr: "ē",
	empty: "∅",
	emptyset: "∅",
	emptyv: "∅",
	emsp13: " ",
	emsp14: " ",
	emsp: " ",
	eng: "ŋ",
	ensp: " ",
	eogon: "ę",
	eopf: "𝕖",
	epar: "⋕",
	eparsl: "⧣",
	eplus: "⩱",
	epsi: "ε",
	epsilon: "ε",
	epsiv: "ϵ",
	eqcirc: "≖",
	eqcolon: "≕",
	eqsim: "≂",
	eqslantgtr: "⪖",
	eqslantless: "⪕",
	equals: "=",
	equest: "≟",
	equiv: "≡",
	equivDD: "⩸",
	eqvparsl: "⧥",
	erDot: "≓",
	erarr: "⥱",
	escr: "ℯ",
	esdot: "≐",
	esim: "≂",
	eta: "η",
	eth: "ð",
	euml: "ë",
	euro: "€",
	excl: "!",
	exist: "∃",
	expectation: "ℰ",
	exponentiale: "ⅇ",
	fallingdotseq: "≒",
	fcy: "ф",
	female: "♀",
	ffilig: "ﬃ",
	fflig: "ﬀ",
	ffllig: "ﬄ",
	ffr: "𝔣",
	filig: "ﬁ",
	fjlig: "fj",
	flat: "♭",
	fllig: "ﬂ",
	fltns: "▱",
	fnof: "ƒ",
	fopf: "𝕗",
	forall: "∀",
	fork: "⋔",
	forkv: "⫙",
	fpartint: "⨍",
	frac12: "½",
	frac13: "⅓",
	frac14: "¼",
	frac15: "⅕",
	frac16: "⅙",
	frac18: "⅛",
	frac23: "⅔",
	frac25: "⅖",
	frac34: "¾",
	frac35: "⅗",
	frac38: "⅜",
	frac45: "⅘",
	frac56: "⅚",
	frac58: "⅝",
	frac78: "⅞",
	frasl: "⁄",
	frown: "⌢",
	fscr: "𝒻",
	gE: "≧",
	gEl: "⪌",
	gacute: "ǵ",
	gamma: "γ",
	gammad: "ϝ",
	gap: "⪆",
	gbreve: "ğ",
	gcirc: "ĝ",
	gcy: "г",
	gdot: "ġ",
	ge: "≥",
	gel: "⋛",
	geq: "≥",
	geqq: "≧",
	geqslant: "⩾",
	ges: "⩾",
	gescc: "⪩",
	gesdot: "⪀",
	gesdoto: "⪂",
	gesdotol: "⪄",
	gesl: "⋛︀",
	gesles: "⪔",
	gfr: "𝔤",
	gg: "≫",
	ggg: "⋙",
	gimel: "ℷ",
	gjcy: "ѓ",
	gl: "≷",
	glE: "⪒",
	gla: "⪥",
	glj: "⪤",
	gnE: "≩",
	gnap: "⪊",
	gnapprox: "⪊",
	gne: "⪈",
	gneq: "⪈",
	gneqq: "≩",
	gnsim: "⋧",
	gopf: "𝕘",
	grave: "`",
	gscr: "ℊ",
	gsim: "≳",
	gsime: "⪎",
	gsiml: "⪐",
	gt: ">",
	gtcc: "⪧",
	gtcir: "⩺",
	gtdot: "⋗",
	gtlPar: "⦕",
	gtquest: "⩼",
	gtrapprox: "⪆",
	gtrarr: "⥸",
	gtrdot: "⋗",
	gtreqless: "⋛",
	gtreqqless: "⪌",
	gtrless: "≷",
	gtrsim: "≳",
	gvertneqq: "≩︀",
	gvnE: "≩︀",
	hArr: "⇔",
	hairsp: " ",
	half: "½",
	hamilt: "ℋ",
	hardcy: "ъ",
	harr: "↔",
	harrcir: "⥈",
	harrw: "↭",
	hbar: "ℏ",
	hcirc: "ĥ",
	hearts: "♥",
	heartsuit: "♥",
	hellip: "…",
	hercon: "⊹",
	hfr: "𝔥",
	hksearow: "⤥",
	hkswarow: "⤦",
	hoarr: "⇿",
	homtht: "∻",
	hookleftarrow: "↩",
	hookrightarrow: "↪",
	hopf: "𝕙",
	horbar: "―",
	hscr: "𝒽",
	hslash: "ℏ",
	hstrok: "ħ",
	hybull: "⁃",
	hyphen: "‐",
	iacute: "í",
	ic: "⁣",
	icirc: "î",
	icy: "и",
	iecy: "е",
	iexcl: "¡",
	iff: "⇔",
	ifr: "𝔦",
	igrave: "ì",
	ii: "ⅈ",
	iiiint: "⨌",
	iiint: "∭",
	iinfin: "⧜",
	iiota: "℩",
	ijlig: "ĳ",
	imacr: "ī",
	image: "ℑ",
	imagline: "ℐ",
	imagpart: "ℑ",
	imath: "ı",
	imof: "⊷",
	imped: "Ƶ",
	in: "∈",
	incare: "℅",
	infin: "∞",
	infintie: "⧝",
	inodot: "ı",
	int: "∫",
	intcal: "⊺",
	integers: "ℤ",
	intercal: "⊺",
	intlarhk: "⨗",
	intprod: "⨼",
	iocy: "ё",
	iogon: "į",
	iopf: "𝕚",
	iota: "ι",
	iprod: "⨼",
	iquest: "¿",
	iscr: "𝒾",
	isin: "∈",
	isinE: "⋹",
	isindot: "⋵",
	isins: "⋴",
	isinsv: "⋳",
	isinv: "∈",
	it: "⁢",
	itilde: "ĩ",
	iukcy: "і",
	iuml: "ï",
	jcirc: "ĵ",
	jcy: "й",
	jfr: "𝔧",
	jmath: "ȷ",
	jopf: "𝕛",
	jscr: "𝒿",
	jsercy: "ј",
	jukcy: "є",
	kappa: "κ",
	kappav: "ϰ",
	kcedil: "ķ",
	kcy: "к",
	kfr: "𝔨",
	kgreen: "ĸ",
	khcy: "х",
	kjcy: "ќ",
	kopf: "𝕜",
	kscr: "𝓀",
	lAarr: "⇚",
	lArr: "⇐",
	lAtail: "⤛",
	lBarr: "⤎",
	lE: "≦",
	lEg: "⪋",
	lHar: "⥢",
	lacute: "ĺ",
	laemptyv: "⦴",
	lagran: "ℒ",
	lambda: "λ",
	lang: "⟨",
	langd: "⦑",
	langle: "⟨",
	lap: "⪅",
	laquo: "«",
	larr: "←",
	larrb: "⇤",
	larrbfs: "⤟",
	larrfs: "⤝",
	larrhk: "↩",
	larrlp: "↫",
	larrpl: "⤹",
	larrsim: "⥳",
	larrtl: "↢",
	lat: "⪫",
	latail: "⤙",
	late: "⪭",
	lates: "⪭︀",
	lbarr: "⤌",
	lbbrk: "❲",
	lbrace: "{",
	lbrack: "[",
	lbrke: "⦋",
	lbrksld: "⦏",
	lbrkslu: "⦍",
	lcaron: "ľ",
	lcedil: "ļ",
	lceil: "⌈",
	lcub: "{",
	lcy: "л",
	ldca: "⤶",
	ldquo: "“",
	ldquor: "„",
	ldrdhar: "⥧",
	ldrushar: "⥋",
	ldsh: "↲",
	le: "≤",
	leftarrow: "←",
	leftarrowtail: "↢",
	leftharpoondown: "↽",
	leftharpoonup: "↼",
	leftleftarrows: "⇇",
	leftrightarrow: "↔",
	leftrightarrows: "⇆",
	leftrightharpoons: "⇋",
	leftrightsquigarrow: "↭",
	leftthreetimes: "⋋",
	leg: "⋚",
	leq: "≤",
	leqq: "≦",
	leqslant: "⩽",
	les: "⩽",
	lescc: "⪨",
	lesdot: "⩿",
	lesdoto: "⪁",
	lesdotor: "⪃",
	lesg: "⋚︀",
	lesges: "⪓",
	lessapprox: "⪅",
	lessdot: "⋖",
	lesseqgtr: "⋚",
	lesseqqgtr: "⪋",
	lessgtr: "≶",
	lesssim: "≲",
	lfisht: "⥼",
	lfloor: "⌊",
	lfr: "𝔩",
	lg: "≶",
	lgE: "⪑",
	lhard: "↽",
	lharu: "↼",
	lharul: "⥪",
	lhblk: "▄",
	ljcy: "љ",
	ll: "≪",
	llarr: "⇇",
	llcorner: "⌞",
	llhard: "⥫",
	lltri: "◺",
	lmidot: "ŀ",
	lmoust: "⎰",
	lmoustache: "⎰",
	lnE: "≨",
	lnap: "⪉",
	lnapprox: "⪉",
	lne: "⪇",
	lneq: "⪇",
	lneqq: "≨",
	lnsim: "⋦",
	loang: "⟬",
	loarr: "⇽",
	lobrk: "⟦",
	longleftarrow: "⟵",
	longleftrightarrow: "⟷",
	longmapsto: "⟼",
	longrightarrow: "⟶",
	looparrowleft: "↫",
	looparrowright: "↬",
	lopar: "⦅",
	lopf: "𝕝",
	loplus: "⨭",
	lotimes: "⨴",
	lowast: "∗",
	lowbar: "_",
	loz: "◊",
	lozenge: "◊",
	lozf: "⧫",
	lpar: "(",
	lparlt: "⦓",
	lrarr: "⇆",
	lrcorner: "⌟",
	lrhar: "⇋",
	lrhard: "⥭",
	lrm: "‎",
	lrtri: "⊿",
	lsaquo: "‹",
	lscr: "𝓁",
	lsh: "↰",
	lsim: "≲",
	lsime: "⪍",
	lsimg: "⪏",
	lsqb: "[",
	lsquo: "‘",
	lsquor: "‚",
	lstrok: "ł",
	lt: "<",
	ltcc: "⪦",
	ltcir: "⩹",
	ltdot: "⋖",
	lthree: "⋋",
	ltimes: "⋉",
	ltlarr: "⥶",
	ltquest: "⩻",
	ltrPar: "⦖",
	ltri: "◃",
	ltrie: "⊴",
	ltrif: "◂",
	lurdshar: "⥊",
	luruhar: "⥦",
	lvertneqq: "≨︀",
	lvnE: "≨︀",
	mDDot: "∺",
	macr: "¯",
	male: "♂",
	malt: "✠",
	maltese: "✠",
	map: "↦",
	mapsto: "↦",
	mapstodown: "↧",
	mapstoleft: "↤",
	mapstoup: "↥",
	marker: "▮",
	mcomma: "⨩",
	mcy: "м",
	mdash: "—",
	measuredangle: "∡",
	mfr: "𝔪",
	mho: "℧",
	micro: "µ",
	mid: "∣",
	midast: "*",
	midcir: "⫰",
	middot: "·",
	minus: "−",
	minusb: "⊟",
	minusd: "∸",
	minusdu: "⨪",
	mlcp: "⫛",
	mldr: "…",
	mnplus: "∓",
	models: "⊧",
	mopf: "𝕞",
	mp: "∓",
	mscr: "𝓂",
	mstpos: "∾",
	mu: "μ",
	multimap: "⊸",
	mumap: "⊸",
	nGg: "⋙̸",
	nGt: "≫⃒",
	nGtv: "≫̸",
	nLeftarrow: "⇍",
	nLeftrightarrow: "⇎",
	nLl: "⋘̸",
	nLt: "≪⃒",
	nLtv: "≪̸",
	nRightarrow: "⇏",
	nVDash: "⊯",
	nVdash: "⊮",
	nabla: "∇",
	nacute: "ń",
	nang: "∠⃒",
	nap: "≉",
	napE: "⩰̸",
	napid: "≋̸",
	napos: "ŉ",
	napprox: "≉",
	natur: "♮",
	natural: "♮",
	naturals: "ℕ",
	nbsp: "\xA0",
	nbump: "≎̸",
	nbumpe: "≏̸",
	ncap: "⩃",
	ncaron: "ň",
	ncedil: "ņ",
	ncong: "≇",
	ncongdot: "⩭̸",
	ncup: "⩂",
	ncy: "н",
	ndash: "–",
	ne: "≠",
	neArr: "⇗",
	nearhk: "⤤",
	nearr: "↗",
	nearrow: "↗",
	nedot: "≐̸",
	nequiv: "≢",
	nesear: "⤨",
	nesim: "≂̸",
	nexist: "∄",
	nexists: "∄",
	nfr: "𝔫",
	ngE: "≧̸",
	nge: "≱",
	ngeq: "≱",
	ngeqq: "≧̸",
	ngeqslant: "⩾̸",
	nges: "⩾̸",
	ngsim: "≵",
	ngt: "≯",
	ngtr: "≯",
	nhArr: "⇎",
	nharr: "↮",
	nhpar: "⫲",
	ni: "∋",
	nis: "⋼",
	nisd: "⋺",
	niv: "∋",
	njcy: "њ",
	nlArr: "⇍",
	nlE: "≦̸",
	nlarr: "↚",
	nldr: "‥",
	nle: "≰",
	nleftarrow: "↚",
	nleftrightarrow: "↮",
	nleq: "≰",
	nleqq: "≦̸",
	nleqslant: "⩽̸",
	nles: "⩽̸",
	nless: "≮",
	nlsim: "≴",
	nlt: "≮",
	nltri: "⋪",
	nltrie: "⋬",
	nmid: "∤",
	nopf: "𝕟",
	not: "¬",
	notin: "∉",
	notinE: "⋹̸",
	notindot: "⋵̸",
	notinva: "∉",
	notinvb: "⋷",
	notinvc: "⋶",
	notni: "∌",
	notniva: "∌",
	notnivb: "⋾",
	notnivc: "⋽",
	npar: "∦",
	nparallel: "∦",
	nparsl: "⫽⃥",
	npart: "∂̸",
	npolint: "⨔",
	npr: "⊀",
	nprcue: "⋠",
	npre: "⪯̸",
	nprec: "⊀",
	npreceq: "⪯̸",
	nrArr: "⇏",
	nrarr: "↛",
	nrarrc: "⤳̸",
	nrarrw: "↝̸",
	nrightarrow: "↛",
	nrtri: "⋫",
	nrtrie: "⋭",
	nsc: "⊁",
	nsccue: "⋡",
	nsce: "⪰̸",
	nscr: "𝓃",
	nshortmid: "∤",
	nshortparallel: "∦",
	nsim: "≁",
	nsime: "≄",
	nsimeq: "≄",
	nsmid: "∤",
	nspar: "∦",
	nsqsube: "⋢",
	nsqsupe: "⋣",
	nsub: "⊄",
	nsubE: "⫅̸",
	nsube: "⊈",
	nsubset: "⊂⃒",
	nsubseteq: "⊈",
	nsubseteqq: "⫅̸",
	nsucc: "⊁",
	nsucceq: "⪰̸",
	nsup: "⊅",
	nsupE: "⫆̸",
	nsupe: "⊉",
	nsupset: "⊃⃒",
	nsupseteq: "⊉",
	nsupseteqq: "⫆̸",
	ntgl: "≹",
	ntilde: "ñ",
	ntlg: "≸",
	ntriangleleft: "⋪",
	ntrianglelefteq: "⋬",
	ntriangleright: "⋫",
	ntrianglerighteq: "⋭",
	nu: "ν",
	num: "#",
	numero: "№",
	numsp: " ",
	nvDash: "⊭",
	nvHarr: "⤄",
	nvap: "≍⃒",
	nvdash: "⊬",
	nvge: "≥⃒",
	nvgt: ">⃒",
	nvinfin: "⧞",
	nvlArr: "⤂",
	nvle: "≤⃒",
	nvlt: "<⃒",
	nvltrie: "⊴⃒",
	nvrArr: "⤃",
	nvrtrie: "⊵⃒",
	nvsim: "∼⃒",
	nwArr: "⇖",
	nwarhk: "⤣",
	nwarr: "↖",
	nwarrow: "↖",
	nwnear: "⤧",
	oS: "Ⓢ",
	oacute: "ó",
	oast: "⊛",
	ocir: "⊚",
	ocirc: "ô",
	ocy: "о",
	odash: "⊝",
	odblac: "ő",
	odiv: "⨸",
	odot: "⊙",
	odsold: "⦼",
	oelig: "œ",
	ofcir: "⦿",
	ofr: "𝔬",
	ogon: "˛",
	ograve: "ò",
	ogt: "⧁",
	ohbar: "⦵",
	ohm: "Ω",
	oint: "∮",
	olarr: "↺",
	olcir: "⦾",
	olcross: "⦻",
	oline: "‾",
	olt: "⧀",
	omacr: "ō",
	omega: "ω",
	omicron: "ο",
	omid: "⦶",
	ominus: "⊖",
	oopf: "𝕠",
	opar: "⦷",
	operp: "⦹",
	oplus: "⊕",
	or: "∨",
	orarr: "↻",
	ord: "⩝",
	order: "ℴ",
	orderof: "ℴ",
	ordf: "ª",
	ordm: "º",
	origof: "⊶",
	oror: "⩖",
	orslope: "⩗",
	orv: "⩛",
	oscr: "ℴ",
	oslash: "ø",
	osol: "⊘",
	otilde: "õ",
	otimes: "⊗",
	otimesas: "⨶",
	ouml: "ö",
	ovbar: "⌽",
	par: "∥",
	para: "¶",
	parallel: "∥",
	parsim: "⫳",
	parsl: "⫽",
	part: "∂",
	pcy: "п",
	percnt: "%",
	period: ".",
	permil: "‰",
	perp: "⊥",
	pertenk: "‱",
	pfr: "𝔭",
	phi: "φ",
	phiv: "ϕ",
	phmmat: "ℳ",
	phone: "☎",
	pi: "π",
	pitchfork: "⋔",
	piv: "ϖ",
	planck: "ℏ",
	planckh: "ℎ",
	plankv: "ℏ",
	plus: "+",
	plusacir: "⨣",
	plusb: "⊞",
	pluscir: "⨢",
	plusdo: "∔",
	plusdu: "⨥",
	pluse: "⩲",
	plusmn: "±",
	plussim: "⨦",
	plustwo: "⨧",
	pm: "±",
	pointint: "⨕",
	popf: "𝕡",
	pound: "£",
	pr: "≺",
	prE: "⪳",
	prap: "⪷",
	prcue: "≼",
	pre: "⪯",
	prec: "≺",
	precapprox: "⪷",
	preccurlyeq: "≼",
	preceq: "⪯",
	precnapprox: "⪹",
	precneqq: "⪵",
	precnsim: "⋨",
	precsim: "≾",
	prime: "′",
	primes: "ℙ",
	prnE: "⪵",
	prnap: "⪹",
	prnsim: "⋨",
	prod: "∏",
	profalar: "⌮",
	profline: "⌒",
	profsurf: "⌓",
	prop: "∝",
	propto: "∝",
	prsim: "≾",
	prurel: "⊰",
	pscr: "𝓅",
	psi: "ψ",
	puncsp: " ",
	qfr: "𝔮",
	qint: "⨌",
	qopf: "𝕢",
	qprime: "⁗",
	qscr: "𝓆",
	quaternions: "ℍ",
	quatint: "⨖",
	quest: "?",
	questeq: "≟",
	quot: "\"",
	rAarr: "⇛",
	rArr: "⇒",
	rAtail: "⤜",
	rBarr: "⤏",
	rHar: "⥤",
	race: "∽̱",
	racute: "ŕ",
	radic: "√",
	raemptyv: "⦳",
	rang: "⟩",
	rangd: "⦒",
	range: "⦥",
	rangle: "⟩",
	raquo: "»",
	rarr: "→",
	rarrap: "⥵",
	rarrb: "⇥",
	rarrbfs: "⤠",
	rarrc: "⤳",
	rarrfs: "⤞",
	rarrhk: "↪",
	rarrlp: "↬",
	rarrpl: "⥅",
	rarrsim: "⥴",
	rarrtl: "↣",
	rarrw: "↝",
	ratail: "⤚",
	ratio: "∶",
	rationals: "ℚ",
	rbarr: "⤍",
	rbbrk: "❳",
	rbrace: "}",
	rbrack: "]",
	rbrke: "⦌",
	rbrksld: "⦎",
	rbrkslu: "⦐",
	rcaron: "ř",
	rcedil: "ŗ",
	rceil: "⌉",
	rcub: "}",
	rcy: "р",
	rdca: "⤷",
	rdldhar: "⥩",
	rdquo: "”",
	rdquor: "”",
	rdsh: "↳",
	real: "ℜ",
	realine: "ℛ",
	realpart: "ℜ",
	reals: "ℝ",
	rect: "▭",
	reg: "®",
	rfisht: "⥽",
	rfloor: "⌋",
	rfr: "𝔯",
	rhard: "⇁",
	rharu: "⇀",
	rharul: "⥬",
	rho: "ρ",
	rhov: "ϱ",
	rightarrow: "→",
	rightarrowtail: "↣",
	rightharpoondown: "⇁",
	rightharpoonup: "⇀",
	rightleftarrows: "⇄",
	rightleftharpoons: "⇌",
	rightrightarrows: "⇉",
	rightsquigarrow: "↝",
	rightthreetimes: "⋌",
	ring: "˚",
	risingdotseq: "≓",
	rlarr: "⇄",
	rlhar: "⇌",
	rlm: "‏",
	rmoust: "⎱",
	rmoustache: "⎱",
	rnmid: "⫮",
	roang: "⟭",
	roarr: "⇾",
	robrk: "⟧",
	ropar: "⦆",
	ropf: "𝕣",
	roplus: "⨮",
	rotimes: "⨵",
	rpar: ")",
	rpargt: "⦔",
	rppolint: "⨒",
	rrarr: "⇉",
	rsaquo: "›",
	rscr: "𝓇",
	rsh: "↱",
	rsqb: "]",
	rsquo: "’",
	rsquor: "’",
	rthree: "⋌",
	rtimes: "⋊",
	rtri: "▹",
	rtrie: "⊵",
	rtrif: "▸",
	rtriltri: "⧎",
	ruluhar: "⥨",
	rx: "℞",
	sacute: "ś",
	sbquo: "‚",
	sc: "≻",
	scE: "⪴",
	scap: "⪸",
	scaron: "š",
	sccue: "≽",
	sce: "⪰",
	scedil: "ş",
	scirc: "ŝ",
	scnE: "⪶",
	scnap: "⪺",
	scnsim: "⋩",
	scpolint: "⨓",
	scsim: "≿",
	scy: "с",
	sdot: "⋅",
	sdotb: "⊡",
	sdote: "⩦",
	seArr: "⇘",
	searhk: "⤥",
	searr: "↘",
	searrow: "↘",
	sect: "§",
	semi: ";",
	seswar: "⤩",
	setminus: "∖",
	setmn: "∖",
	sext: "✶",
	sfr: "𝔰",
	sfrown: "⌢",
	sharp: "♯",
	shchcy: "щ",
	shcy: "ш",
	shortmid: "∣",
	shortparallel: "∥",
	shy: "­",
	sigma: "σ",
	sigmaf: "ς",
	sigmav: "ς",
	sim: "∼",
	simdot: "⩪",
	sime: "≃",
	simeq: "≃",
	simg: "⪞",
	simgE: "⪠",
	siml: "⪝",
	simlE: "⪟",
	simne: "≆",
	simplus: "⨤",
	simrarr: "⥲",
	slarr: "←",
	smallsetminus: "∖",
	smashp: "⨳",
	smeparsl: "⧤",
	smid: "∣",
	smile: "⌣",
	smt: "⪪",
	smte: "⪬",
	smtes: "⪬︀",
	softcy: "ь",
	sol: "/",
	solb: "⧄",
	solbar: "⌿",
	sopf: "𝕤",
	spades: "♠",
	spadesuit: "♠",
	spar: "∥",
	sqcap: "⊓",
	sqcaps: "⊓︀",
	sqcup: "⊔",
	sqcups: "⊔︀",
	sqsub: "⊏",
	sqsube: "⊑",
	sqsubset: "⊏",
	sqsubseteq: "⊑",
	sqsup: "⊐",
	sqsupe: "⊒",
	sqsupset: "⊐",
	sqsupseteq: "⊒",
	squ: "□",
	square: "□",
	squarf: "▪",
	squf: "▪",
	srarr: "→",
	sscr: "𝓈",
	ssetmn: "∖",
	ssmile: "⌣",
	sstarf: "⋆",
	star: "☆",
	starf: "★",
	straightepsilon: "ϵ",
	straightphi: "ϕ",
	strns: "¯",
	sub: "⊂",
	subE: "⫅",
	subdot: "⪽",
	sube: "⊆",
	subedot: "⫃",
	submult: "⫁",
	subnE: "⫋",
	subne: "⊊",
	subplus: "⪿",
	subrarr: "⥹",
	subset: "⊂",
	subseteq: "⊆",
	subseteqq: "⫅",
	subsetneq: "⊊",
	subsetneqq: "⫋",
	subsim: "⫇",
	subsub: "⫕",
	subsup: "⫓",
	succ: "≻",
	succapprox: "⪸",
	succcurlyeq: "≽",
	succeq: "⪰",
	succnapprox: "⪺",
	succneqq: "⪶",
	succnsim: "⋩",
	succsim: "≿",
	sum: "∑",
	sung: "♪",
	sup1: "¹",
	sup2: "²",
	sup3: "³",
	sup: "⊃",
	supE: "⫆",
	supdot: "⪾",
	supdsub: "⫘",
	supe: "⊇",
	supedot: "⫄",
	suphsol: "⟉",
	suphsub: "⫗",
	suplarr: "⥻",
	supmult: "⫂",
	supnE: "⫌",
	supne: "⊋",
	supplus: "⫀",
	supset: "⊃",
	supseteq: "⊇",
	supseteqq: "⫆",
	supsetneq: "⊋",
	supsetneqq: "⫌",
	supsim: "⫈",
	supsub: "⫔",
	supsup: "⫖",
	swArr: "⇙",
	swarhk: "⤦",
	swarr: "↙",
	swarrow: "↙",
	swnwar: "⤪",
	szlig: "ß",
	target: "⌖",
	tau: "τ",
	tbrk: "⎴",
	tcaron: "ť",
	tcedil: "ţ",
	tcy: "т",
	tdot: "⃛",
	telrec: "⌕",
	tfr: "𝔱",
	there4: "∴",
	therefore: "∴",
	theta: "θ",
	thetasym: "ϑ",
	thetav: "ϑ",
	thickapprox: "≈",
	thicksim: "∼",
	thinsp: " ",
	thkap: "≈",
	thksim: "∼",
	thorn: "þ",
	tilde: "˜",
	times: "×",
	timesb: "⊠",
	timesbar: "⨱",
	timesd: "⨰",
	tint: "∭",
	toea: "⤨",
	top: "⊤",
	topbot: "⌶",
	topcir: "⫱",
	topf: "𝕥",
	topfork: "⫚",
	tosa: "⤩",
	tprime: "‴",
	trade: "™",
	triangle: "▵",
	triangledown: "▿",
	triangleleft: "◃",
	trianglelefteq: "⊴",
	triangleq: "≜",
	triangleright: "▹",
	trianglerighteq: "⊵",
	tridot: "◬",
	trie: "≜",
	triminus: "⨺",
	triplus: "⨹",
	trisb: "⧍",
	tritime: "⨻",
	trpezium: "⏢",
	tscr: "𝓉",
	tscy: "ц",
	tshcy: "ћ",
	tstrok: "ŧ",
	twixt: "≬",
	twoheadleftarrow: "↞",
	twoheadrightarrow: "↠",
	uArr: "⇑",
	uHar: "⥣",
	uacute: "ú",
	uarr: "↑",
	ubrcy: "ў",
	ubreve: "ŭ",
	ucirc: "û",
	ucy: "у",
	udarr: "⇅",
	udblac: "ű",
	udhar: "⥮",
	ufisht: "⥾",
	ufr: "𝔲",
	ugrave: "ù",
	uharl: "↿",
	uharr: "↾",
	uhblk: "▀",
	ulcorn: "⌜",
	ulcorner: "⌜",
	ulcrop: "⌏",
	ultri: "◸",
	umacr: "ū",
	uml: "¨",
	uogon: "ų",
	uopf: "𝕦",
	uparrow: "↑",
	updownarrow: "↕",
	upharpoonleft: "↿",
	upharpoonright: "↾",
	uplus: "⊎",
	upsi: "υ",
	upsih: "ϒ",
	upsilon: "υ",
	upuparrows: "⇈",
	urcorn: "⌝",
	urcorner: "⌝",
	urcrop: "⌎",
	uring: "ů",
	urtri: "◹",
	uscr: "𝓊",
	utdot: "⋰",
	utilde: "ũ",
	utri: "▵",
	utrif: "▴",
	uuarr: "⇈",
	uuml: "ü",
	uwangle: "⦧",
	vArr: "⇕",
	vBar: "⫨",
	vBarv: "⫩",
	vDash: "⊨",
	vangrt: "⦜",
	varepsilon: "ϵ",
	varkappa: "ϰ",
	varnothing: "∅",
	varphi: "ϕ",
	varpi: "ϖ",
	varpropto: "∝",
	varr: "↕",
	varrho: "ϱ",
	varsigma: "ς",
	varsubsetneq: "⊊︀",
	varsubsetneqq: "⫋︀",
	varsupsetneq: "⊋︀",
	varsupsetneqq: "⫌︀",
	vartheta: "ϑ",
	vartriangleleft: "⊲",
	vartriangleright: "⊳",
	vcy: "в",
	vdash: "⊢",
	vee: "∨",
	veebar: "⊻",
	veeeq: "≚",
	vellip: "⋮",
	verbar: "|",
	vert: "|",
	vfr: "𝔳",
	vltri: "⊲",
	vnsub: "⊂⃒",
	vnsup: "⊃⃒",
	vopf: "𝕧",
	vprop: "∝",
	vrtri: "⊳",
	vscr: "𝓋",
	vsubnE: "⫋︀",
	vsubne: "⊊︀",
	vsupnE: "⫌︀",
	vsupne: "⊋︀",
	vzigzag: "⦚",
	wcirc: "ŵ",
	wedbar: "⩟",
	wedge: "∧",
	wedgeq: "≙",
	weierp: "℘",
	wfr: "𝔴",
	wopf: "𝕨",
	wp: "℘",
	wr: "≀",
	wreath: "≀",
	wscr: "𝓌",
	xcap: "⋂",
	xcirc: "◯",
	xcup: "⋃",
	xdtri: "▽",
	xfr: "𝔵",
	xhArr: "⟺",
	xharr: "⟷",
	xi: "ξ",
	xlArr: "⟸",
	xlarr: "⟵",
	xmap: "⟼",
	xnis: "⋻",
	xodot: "⨀",
	xopf: "𝕩",
	xoplus: "⨁",
	xotime: "⨂",
	xrArr: "⟹",
	xrarr: "⟶",
	xscr: "𝓍",
	xsqcup: "⨆",
	xuplus: "⨄",
	xutri: "△",
	xvee: "⋁",
	xwedge: "⋀",
	yacute: "ý",
	yacy: "я",
	ycirc: "ŷ",
	ycy: "ы",
	yen: "¥",
	yfr: "𝔶",
	yicy: "ї",
	yopf: "𝕪",
	yscr: "𝓎",
	yucy: "ю",
	yuml: "ÿ",
	zacute: "ź",
	zcaron: "ž",
	zcy: "з",
	zdot: "ż",
	zeetrf: "ℨ",
	zeta: "ζ",
	zfr: "𝔷",
	zhcy: "ж",
	zigrarr: "⇝",
	zopf: "𝕫",
	zscr: "𝓏",
	zwj: "‍",
	zwnj: "‌"
}, Tt = {}.hasOwnProperty;
function Et(e) {
	return Tt.call(wt, e) ? wt[e] : !1;
}
// node_modules/micromark-util-decode-numeric-character-reference/index.js
function Dt(e, t) {
	let n = Number.parseInt(e, t);
	return n < 9 || n === 11 || n > 13 && n < 32 || n > 126 && n < 160 || n > 55295 && n < 57344 || n > 64975 && n < 65008 || (n & 65535) == 65535 || (n & 65535) == 65534 || n > 1114111 ? "�" : String.fromCodePoint(n);
}
// node_modules/micromark/lib/initialize/content.js
var Ot = { tokenize: kt };
function kt(e) {
	let t = e.attempt(this.parser.constructs.contentInitial, r, i), n;
	return t;
	function r(n) {
		if (n === null) e.consume(n);
		else return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), F(e, t, "linePrefix");
	}
	function i(t) {
		return e.enter("paragraph"), a(t);
	}
	function a(t) {
		let r = e.enter("chunkText", {
			contentType: "text",
			previous: n
		});
		return n && (n.next = r), n = r, o(t);
	}
	function o(t) {
		if (t === null) e.exit("chunkText"), e.exit("paragraph"), e.consume(t);
		else return P(t) ? (e.consume(t), e.exit("chunkText"), a) : (e.consume(t), o);
	}
}
// node_modules/micromark-util-edit-map/index.js
var At = class {
	constructor() {
		this.index = /* @__PURE__ */ new Map(), this.map = [];
	}
	add(e, t, n) {
		jt(this, e, t, n, !1);
	}
	addBefore(e, t, n) {
		jt(this, e, t, n, !0);
	}
	consume(e) {
		if (this.map.sort(function(e, t) {
			return e[0] - t[0];
		}), this.map.length === 0) return;
		let t = this.map.length, n = [];
		for (; t > 0;) --t, n.push(e.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), e.length = this.map[t][0];
		n.push(e.slice()), e.length = 0;
		let r = n.pop();
		for (; r;) {
			for (let t of r) e.push(t);
			r = n.pop();
		}
		this.map.length = 0, this.index.clear();
	}
};
function jt(e, t, n, r, i) {
	if (n === 0 && r.length === 0) return;
	let a = e.index.get(t);
	if (a) {
		a[1] += n, i ? (r.push(...a[2]), a[2] = r) : a[2].push(...r);
		return;
	}
	let o = [
		t,
		n,
		r
	];
	e.map.push(o), e.index.set(t, o);
}
// node_modules/micromark/lib/initialize/document.js
var Mt = { tokenize: Pt }, Nt = { tokenize: Ft };
function Pt(e) {
	let t = this, n = [], r = 0, i, a, o;
	return s;
	function s(i) {
		if (r < n.length) {
			let a = n[r];
			return t.containerState = a[1], e.attempt(a[0].continuation, c, l)(i);
		}
		return l(i);
	}
	function c(e) {
		if (r++, t.containerState._closeFlow) {
			t.containerState._closeFlow = void 0, i && v();
			let n = t.events.length, a = n, o;
			for (; a--;) if (t.events[a][0] === "exit" && t.events[a][1].type === "chunkFlow") {
				o = t.events[a][1].end;
				break;
			}
			_(r);
			let s = n;
			for (; s < t.events.length;) t.events[s][1].end = { ...o }, s++;
			let c = new At();
			return c.add(a + 1, 0, t.events.slice(n)), c.add(n, s - n, []), c.consume(t.events), l(e);
		}
		return s(e);
	}
	function l(a) {
		if (r === n.length) {
			if (!i) return f(a);
			if (i.currentConstruct && i.currentConstruct.concrete) return m(a);
			t.interrupt = !(!i.currentConstruct || i._gfmTableDynamicInterruptHack);
		}
		return t.containerState = {}, e.check(Nt, u, d)(a);
	}
	function u(e) {
		return i && v(), _(r), f(e);
	}
	function d(e) {
		return t.parser.lazy[t.now().line] = r !== n.length, o = t.now().offset, m(e);
	}
	function f(n) {
		return t.containerState = {}, e.attempt(Nt, p, m)(n);
	}
	function p(e) {
		return r++, n.push([t.currentConstruct, t.containerState]), f(e);
	}
	function m(n) {
		if (n === null) i && v(), _(0), e.consume(n);
		else return i ||= t.parser.flow(t.now()), e.enter("chunkFlow", {
			_tokenizer: i,
			contentType: "flow",
			previous: a
		}), h(n);
	}
	function h(n) {
		if (n === null) g(e.exit("chunkFlow"), !0), _(0), e.consume(n);
		else return P(n) ? (e.consume(n), g(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, s) : (e.consume(n), h);
	}
	function g(e, n) {
		let s = t.sliceStream(e);
		if (n && s.push(null), e.previous = a, a && (a.next = e), a = e, i.defineSkip(e.start), i.write(s), t.parser.lazy[e.start.line]) {
			let e = i.events.length;
			for (; e--;) if (i.events[e][1].start.offset < o && (!i.events[e][1].end || i.events[e][1].end.offset > o)) return;
			let n = t.events.length, a = n, s, c;
			for (; a--;) if (t.events[a][0] === "exit" && t.events[a][1].type === "chunkFlow") {
				if (s) {
					c = t.events[a][1].end;
					break;
				}
				s = !0;
			}
			for (_(r), e = n; e < t.events.length;) t.events[e][1].end = { ...c }, e++;
			let l = new At();
			l.add(a + 1, 0, t.events.slice(n)), l.add(n, e - n, []), l.consume(t.events);
		}
	}
	function _(r) {
		let i = n.length;
		for (; i-- > r;) {
			let r = n[i];
			t.containerState = r[1], r[0].exit.call(t, e);
		}
		n.length = r;
	}
	function v() {
		i.write([null]), a = void 0, i = void 0, t.containerState._closeFlow = void 0;
	}
}
function Ft(e, t, n) {
	return F(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
// node_modules/micromark-core-commonmark/lib/attention.js
var It = {
	name: "attention",
	resolveAll: Lt,
	tokenize: Rt
};
function Lt(e, t) {
	let n = -1, r;
	for (; ++n < e.length;) if (e[n][0] === "enter" && e[n][1].type === "attentionSequence" && e[n][1]._close) {
		let i = n;
		for (; i--;) if (e[i][0] === "exit" && e[i][1].type === "attentionSequence" && e[i][1]._open && t.sliceSerialize(e[i][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
			if ((e[i][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[i][1].end.offset - e[i][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3)) continue;
			let a = e[i][1].end.offset - e[i][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1, o = { ...e[i][1].end }, s = { ...e[n][1].start };
			zt(o, -a), zt(s, a);
			let c = {
				type: a > 1 ? "strongSequence" : "emphasisSequence",
				start: o,
				end: { ...e[i][1].end }
			}, l = {
				type: a > 1 ? "strongSequence" : "emphasisSequence",
				start: { ...e[n][1].start },
				end: s
			}, u = {
				type: a > 1 ? "strongText" : "emphasisText",
				start: { ...e[i][1].end },
				end: { ...e[n][1].start }
			}, d = {
				type: a > 1 ? "strong" : "emphasis",
				start: { ...c.start },
				end: { ...l.end }
			};
			e[i][1].end = { ...c.start }, e[n][1].start = { ...l.end }, r = [], e[i][1].end.offset - e[i][1].start.offset && (r = z(r, [[
				"enter",
				e[i][1],
				t
			], [
				"exit",
				e[i][1],
				t
			]])), r = z(r, [
				[
					"enter",
					d,
					t
				],
				[
					"enter",
					c,
					t
				],
				[
					"exit",
					c,
					t
				],
				[
					"enter",
					u,
					t
				]
			]), r = z(r, ne(t.parser.constructs.insideSpan.null, e.slice(i + 1, n), t)), r = z(r, [
				[
					"exit",
					u,
					t
				],
				[
					"enter",
					l,
					t
				],
				[
					"exit",
					l,
					t
				],
				[
					"exit",
					d,
					t
				]
			]);
			let f = 0;
			e[n][1].end.offset - e[n][1].start.offset && (f = 2, r = z(r, [[
				"enter",
				e[n][1],
				t
			], [
				"exit",
				e[n][1],
				t
			]])), O(e, i - 1, n - i + 3, r), n = i + r.length - f - 2;
			break;
		}
	}
	for (n = -1; ++n < e.length;) e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
	return e;
}
function Rt(e, t) {
	let n = this.parser.constructs.attentionMarkers.null, r = this.previous, i = N(r), a;
	return o;
	function o(t) {
		return a = t, e.enter("attentionSequence"), s(t);
	}
	function s(o) {
		if (o === a) return e.consume(o), s;
		let c = e.exit("attentionSequence"), l = N(o), u = !l || l === 2 && i || n.includes(o) && o !== 42 && o !== 95, d = !i || i === 2 && l || n.includes(r) && r !== 42 && r !== 95;
		return c._open = !!(a === 42 ? u : u && (i || !d)), c._close = !!(a === 42 ? d : d && (l || !u)), t(o);
	}
}
function zt(e, t) {
	e.column += t, e.offset += t, e._bufferIndex += t;
}
// node_modules/micromark-core-commonmark/lib/autolink.js
var Bt = {
	name: "autolink",
	tokenize: Vt
};
function Vt(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(t), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), a;
	}
	function a(t) {
		return B(t) ? (e.consume(t), o) : t === 64 ? n(t) : l(t);
	}
	function o(e) {
		return e === 43 || e === 45 || e === 46 || Y(e) ? (r = 1, s(e)) : l(e);
	}
	function s(t) {
		return t === 58 ? (e.consume(t), r = 0, c) : (t === 43 || t === 45 || t === 46 || Y(t)) && r++ < 32 ? (e.consume(t), s) : (r = 0, l(t));
	}
	function c(r) {
		return r === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(r), e.exit("autolinkMarker"), e.exit("autolink"), t) : r === null || r === 32 || r === 60 || ae(r) ? n(r) : (e.consume(r), c);
	}
	function l(t) {
		return t === 64 ? (e.consume(t), u) : k(t) ? (e.consume(t), l) : n(t);
	}
	function u(e) {
		return Y(e) ? d(e) : n(e);
	}
	function d(n) {
		return n === 46 ? (e.consume(n), r = 0, u) : n === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(n), e.exit("autolinkMarker"), e.exit("autolink"), t) : f(n);
	}
	function f(t) {
		if ((t === 45 || Y(t)) && r++ < 63) {
			let n = t === 45 ? f : d;
			return e.consume(t), n;
		}
		return n(t);
	}
}
// node_modules/micromark-core-commonmark/lib/block-quote.js
var Ht = {
	continuation: { tokenize: Wt },
	exit: Gt,
	name: "blockQuote",
	tokenize: Ut
};
function Ut(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		if (t === 62) {
			let n = r.containerState;
			return n.open ||= (e.enter("blockQuote", { _container: !0 }), !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(t), e.exit("blockQuoteMarker"), a;
		}
		return n(t);
	}
	function a(n) {
		return J(n) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(n), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(n));
	}
}
function Wt(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return J(t) ? F(e, a, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : a(t);
	}
	function a(r) {
		return e.attempt(Ht, t, n)(r);
	}
}
function Gt(e) {
	e.exit("blockQuote");
}
// node_modules/micromark-core-commonmark/lib/character-escape.js
var Kt = {
	name: "characterEscape",
	tokenize: qt
};
function qt(e, t, n) {
	return r;
	function r(t) {
		return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(t), e.exit("escapeMarker"), i;
	}
	function i(r) {
		return oe(r) ? (e.enter("characterEscapeValue"), e.consume(r), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/character-reference.js
var Jt = {
	name: "characterReference",
	tokenize: Yt
};
function Yt(e, t, n) {
	let r = this, i = 0, a, o;
	return s;
	function s(t) {
		return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(t), e.exit("characterReferenceMarker"), c;
	}
	function c(t) {
		return t === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(t), e.exit("characterReferenceMarkerNumeric"), l) : (e.enter("characterReferenceValue"), a = 31, o = Y, u(t));
	}
	function l(t) {
		return t === 88 || t === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(t), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), a = 6, o = ie, u) : (e.enter("characterReferenceValue"), a = 7, o = ee, u(t));
	}
	function u(s) {
		if (s === 59 && i) {
			let i = e.exit("characterReferenceValue");
			return o === Y && !Et(r.sliceSerialize(i)) ? n(s) : (e.enter("characterReferenceMarker"), e.consume(s), e.exit("characterReferenceMarker"), e.exit("characterReference"), t);
		}
		return o(s) && i++ < a ? (e.consume(s), u) : n(s);
	}
}
// node_modules/micromark-core-commonmark/lib/partial-non-lazy-continuation.js
var Xt = {
	partial: !0,
	tokenize: Zt
};
function Zt(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return t === null ? n(t) : (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), a);
	}
	function a(e) {
		return r.parser.lazy[r.now().line] ? n(e) : t(e);
	}
}
// node_modules/micromark-core-commonmark/lib/code-fenced.js
var Qt = {
	concrete: !0,
	name: "codeFenced",
	tokenize: $t
};
function $t(e, t, n) {
	let r = this, i = {
		partial: !0,
		tokenize: x
	}, a = 0, o = 0, s;
	return c;
	function c(e) {
		return l(e);
	}
	function l(t) {
		let n = r.events[r.events.length - 1];
		return a = n && n[1].type === "linePrefix" ? n[2].sliceSerialize(n[1], !0).length : 0, s = t, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), u(t);
	}
	function u(t) {
		return t === s ? (o++, e.consume(t), u) : o < 3 ? n(t) : (e.exit("codeFencedFenceSequence"), J(t) ? F(e, d, "whitespace")(t) : d(t));
	}
	function d(n) {
		return n === null || P(n) ? (e.exit("codeFencedFence"), r.interrupt ? t(n) : e.check(Xt, h, b)(n)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", { contentType: "string" }), f(n));
	}
	function f(t) {
		return t === null || P(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), d(t)) : J(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), F(e, p, "whitespace")(t)) : t === 96 && t === s ? n(t) : (e.consume(t), f);
	}
	function p(t) {
		return t === null || P(t) ? d(t) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", { contentType: "string" }), m(t));
	}
	function m(t) {
		return t === null || P(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), d(t)) : t === 96 && t === s ? n(t) : (e.consume(t), m);
	}
	function h(t) {
		return e.attempt(i, b, g)(t);
	}
	function g(t) {
		return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), _;
	}
	function _(t) {
		return a > 0 && J(t) ? F(e, v, "linePrefix", a + 1)(t) : v(t);
	}
	function v(t) {
		return t === null || P(t) ? e.check(Xt, h, b)(t) : (e.enter("codeFlowValue"), y(t));
	}
	function y(t) {
		return t === null || P(t) ? (e.exit("codeFlowValue"), v(t)) : (e.consume(t), y);
	}
	function b(n) {
		return e.exit("codeFenced"), t(n);
	}
	function x(e, t, n) {
		let i = 0;
		return a;
		function a(t) {
			return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), c;
		}
		function c(t) {
			return e.enter("codeFencedFence"), J(t) ? F(e, l, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : l(t);
		}
		function l(t) {
			return t === s ? (e.enter("codeFencedFenceSequence"), u(t)) : n(t);
		}
		function u(t) {
			return t === s ? (i++, e.consume(t), u) : i >= o ? (e.exit("codeFencedFenceSequence"), J(t) ? F(e, d, "whitespace")(t) : d(t)) : n(t);
		}
		function d(r) {
			return r === null || P(r) ? (e.exit("codeFencedFence"), t(r)) : n(r);
		}
	}
}
// node_modules/micromark-core-commonmark/lib/code-indented.js
var en = {
	name: "codeIndented",
	tokenize: nn
}, tn = {
	partial: !0,
	tokenize: rn
};
function nn(e, t, n) {
	return r;
	function r(t) {
		return e.enter("codeIndented"), L(e, i, n, "linePrefix", 4, 4)(t);
	}
	function i(t) {
		return t === null ? o(t) : P(t) ? e.attempt(tn, i, o)(t) : (e.enter("codeFlowValue"), a(t));
	}
	function a(t) {
		return t === null || P(t) ? (e.exit("codeFlowValue"), i(t)) : (e.consume(t), a);
	}
	function o(n) {
		return e.exit("codeIndented"), t(n);
	}
}
function rn(e, t, n) {
	let r = this;
	return i;
	function i(o) {
		return r.parser.lazy[r.now().line] ? n(o) : P(o) ? (e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), i) : L(e, t, a, "linePrefix", 4, 4)(o);
	}
	function a(e) {
		return P(e) ? i(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/code-text.js
var an = {
	name: "codeText",
	previous: sn,
	resolve: on,
	tokenize: cn
};
function on(e) {
	let t = e.length - 4, n = 3, r, i;
	if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
		for (r = n; ++r < t;) if (e[r][1].type === "codeTextData") {
			e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
			break;
		}
	}
	for (r = n - 1, t++; ++r <= t;) i === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (i = r) : (r === t || e[r][1].type === "lineEnding") && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
	return e;
}
function sn(e) {
	return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function cn(e, t, n) {
	let r = 0, i, a;
	return o;
	function o(t) {
		return e.enter("codeText"), e.enter("codeTextSequence"), s(t);
	}
	function s(t) {
		return t === 96 ? (e.consume(t), r++, s) : (e.exit("codeTextSequence"), c(t));
	}
	function c(t) {
		return t === null ? n(t) : t === 32 ? (e.enter("space"), e.consume(t), e.exit("space"), c) : t === 96 ? (a = e.enter("codeTextSequence"), i = 0, u(t)) : P(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), c) : (e.enter("codeTextData"), l(t));
	}
	function l(t) {
		return t === null || t === 32 || t === 96 || P(t) ? (e.exit("codeTextData"), c(t)) : (e.consume(t), l);
	}
	function u(n) {
		return n === 96 ? (e.consume(n), i++, u) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(n)) : (a.type = "codeTextData", l(n));
	}
}
// node_modules/micromark-util-subtokenize/lib/splice-buffer.js
var ln = class {
	constructor(e) {
		this.left = e ? [...e] : [], this.right = [];
	}
	get(e) {
		if (e < 0 || e >= this.left.length + this.right.length) throw RangeError("Cannot access index `" + e + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
		return e < this.left.length ? this.left[e] : this.right[this.right.length - e + this.left.length - 1];
	}
	get length() {
		return this.left.length + this.right.length;
	}
	shift() {
		return this.setCursor(0), this.right.pop();
	}
	slice(e, t) {
		let n = t ?? Infinity;
		return n < this.left.length ? this.left.slice(e, n) : e > this.left.length ? this.right.slice(this.right.length - n + this.left.length, this.right.length - e + this.left.length).reverse() : this.left.slice(e).concat(this.right.slice(this.right.length - n + this.left.length).reverse());
	}
	splice(e, t, n) {
		let r = t || 0;
		this.setCursor(Math.trunc(e));
		let i = this.right.splice(this.right.length - r, Infinity);
		return n && un(this.left, n), i.reverse();
	}
	pop() {
		return this.setCursor(Infinity), this.left.pop();
	}
	push(e) {
		this.setCursor(Infinity), this.left.push(e);
	}
	pushMany(e) {
		this.setCursor(Infinity), un(this.left, e);
	}
	unshift(e) {
		this.setCursor(0), this.right.push(e);
	}
	unshiftMany(e) {
		this.setCursor(0), un(this.right, e.reverse());
	}
	setCursor(e) {
		if (!(e === this.left.length || e > this.left.length && this.right.length === 0 || e < 0 && this.left.length === 0)) {
			if (e < this.left.length) {
				let t = this.left.splice(e, Infinity);
				un(this.right, t.reverse());
			} else {
				let t = this.right.splice(this.left.length + this.right.length - e, Infinity);
				un(this.left, t.reverse());
			}
		}
	}
};
function un(e, t) {
	let n = 0;
	if (t.length < 1e4) e.push(...t);
	else for (; n < t.length;) e.push(...t.slice(n, n + 1e4)), n += 1e4;
}
// node_modules/micromark-util-subtokenize/index.js
function dn(e) {
	let t = {}, n = -1, r, i, a, o, s, c, l, u = new ln(e);
	for (; ++n < u.length;) {
		for (; n in t;) n = t[n];
		if (r = u.get(n), n && r[1].type === "chunkFlow" && u.get(n - 1)[1].type === "listItemPrefix" && (c = r[1]._tokenizer.events, a = 0, a < c.length && c[a][1].type === "lineEndingBlank" && (a += 2), a < c.length && c[a][1].type === "content")) for (; ++a < c.length && c[a][1].type !== "content";) c[a][1].type === "chunkText" && (c[a][1]._isInFirstContentOfListItem = !0, a++);
		if (r[0] === "enter") r[1].contentType && (Object.assign(t, fn(u, n)), n = t[n], l = !0);
		else if (r[1]._container) {
			for (a = n, i = void 0; a--;) if (o = u.get(a), o[1].type === "lineEnding" || o[1].type === "lineEndingBlank") o[0] === "enter" && (i && (u.get(i)[1].type = "lineEndingBlank"), o[1].type = "lineEnding", i = a);
			else if (o[1].type !== "linePrefix" && o[1].type !== "listItemIndent") break;
			i && (r[1].end = { ...u.get(i)[1].start }, s = u.slice(i, n), s.unshift(r), u.splice(i, n - i + 1, s));
		}
	}
	return O(e, 0, Infinity, u.slice(0)), !l;
}
function fn(e, t) {
	let n = e.get(t)[1], r = e.get(t)[2], i = t - 1, a = [], o = n._tokenizer;
	o || (o = r.parser[n.contentType](n.start), n._contentTypeTextTrailing && (o._contentTypeTextTrailing = !0));
	let s = o.events, c = [], l = {}, u, d, f = -1, p = n, m = 0, h = 0, g = [h];
	for (; p;) {
		for (; e.get(++i)[1] !== p;);
		a.push(i), p._tokenizer || (u = r.sliceStream(p), p.next || u.push(null), d && o.defineSkip(p.start), p._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = !0), o.write(u), p._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = void 0)), d = p, p = p.next;
	}
	for (p = n; ++f < s.length;) s[f][0] === "exit" && s[f - 1][0] === "enter" && s[f][1].type === s[f - 1][1].type && s[f][1].start.line !== s[f][1].end.line && (h = f + 1, g.push(h), p._tokenizer = void 0, p.previous = void 0, p = p.next);
	for (o.events = [], p ? (p._tokenizer = void 0, p.previous = void 0) : g.pop(), f = g.length; f--;) {
		let t = s.slice(g[f], g[f + 1]), n = a.pop();
		c.push([n, n + t.length - 1]), e.splice(n, 2, t);
	}
	for (c.reverse(), f = -1; ++f < c.length;) l[m + c[f][0]] = m + c[f][1], m += c[f][1] - c[f][0] - 1;
	return l;
}
// node_modules/micromark-core-commonmark/lib/content.js
var pn = {
	resolve: hn,
	tokenize: gn
}, mn = {
	partial: !0,
	tokenize: _n
};
function hn(e) {
	return dn(e), e;
}
function gn(e, t) {
	let n;
	return r;
	function r(t) {
		return e.enter("content"), n = e.enter("chunkContent", { contentType: "content" }), i(t);
	}
	function i(t) {
		return t === null ? a(t) : P(t) ? e.check(mn, o, a)(t) : (e.consume(t), i);
	}
	function a(n) {
		return e.exit("chunkContent"), e.exit("content"), t(n);
	}
	function o(t) {
		return e.consume(t), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
			contentType: "content",
			previous: n
		}), n = n.next, i;
	}
}
function _n(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), F(e, a, "linePrefix");
	}
	function a(i) {
		if (i === null || P(i)) return n(i);
		let a = r.events[r.events.length - 1];
		return !r.parser.constructs.disable.null.includes("codeIndented") && a && a[1].type === "linePrefix" && a[2].sliceSerialize(a[1], !0).length >= 4 ? t(i) : e.interrupt(r.parser.constructs.flow, n, t)(i);
	}
}
// node_modules/micromark-factory-destination/index.js
function vn(e, t, n, r, i, a, o, s, c) {
	let l = c || Infinity, u = 0;
	return d;
	function d(t) {
		return t === 60 ? (e.enter(r), e.enter(i), e.enter(a), e.consume(t), e.exit(a), f) : t === null || t === 32 || t === 41 || ae(t) ? n(t) : (e.enter(r), e.enter(o), e.enter(s), e.enter("chunkString", { contentType: "string" }), h(t));
	}
	function f(n) {
		return n === 62 ? (e.enter(a), e.consume(n), e.exit(a), e.exit(i), e.exit(r), t) : (e.enter(s), e.enter("chunkString", { contentType: "string" }), p(n));
	}
	function p(t) {
		return t === 62 ? (e.exit("chunkString"), e.exit(s), f(t)) : t === null || t === 60 || P(t) ? n(t) : (e.consume(t), t === 92 ? m : p);
	}
	function m(t) {
		return t === 60 || t === 62 || t === 92 ? (e.consume(t), p) : p(t);
	}
	function h(i) {
		return !u && (i === null || i === 41 || I(i)) ? (e.exit("chunkString"), e.exit(s), e.exit(o), e.exit(r), t(i)) : u < l && i === 40 ? (e.consume(i), u++, h) : i === 41 ? (e.consume(i), u--, h) : i === null || i === 32 || i === 40 || ae(i) ? n(i) : (e.consume(i), i === 92 ? g : h);
	}
	function g(t) {
		return t === 40 || t === 41 || t === 92 ? (e.consume(t), h) : h(t);
	}
}
// node_modules/micromark-factory-label/index.js
function yn(e, t, n, r, i, a) {
	let o = this, s = 0, c;
	return l;
	function l(t) {
		return e.enter(r), e.enter(i), e.consume(t), e.exit(i), e.enter(a), u;
	}
	function u(l) {
		return s > 999 || l === null || l === 91 || l === 93 && !c || 
		/* c8 ignore next 3 */
		l === 94 && !s && "_hiddenFootnoteSupport" in o.parser.constructs ? n(l) : l === 93 ? (e.exit(a), e.enter(i), e.consume(l), e.exit(i), e.exit(r), t) : P(l) ? (e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), u) : (e.enter("chunkString", { contentType: "string" }), d(l));
	}
	function d(t) {
		return t === null || t === 91 || t === 93 || P(t) || s++ > 999 ? (e.exit("chunkString"), u(t)) : (e.consume(t), c ||= !J(t), t === 92 ? f : d);
	}
	function f(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), s++, d) : d(t);
	}
}
// node_modules/micromark-factory-title/index.js
function bn(e, t, n, r, i, a) {
	let o;
	return s;
	function s(t) {
		return t === 34 || t === 39 || t === 40 ? (e.enter(r), e.enter(i), e.consume(t), e.exit(i), o = t === 40 ? 41 : t, c) : n(t);
	}
	function c(n) {
		return n === o ? (e.enter(i), e.consume(n), e.exit(i), e.exit(r), t) : (e.enter(a), l(n));
	}
	function l(t) {
		return t === o ? (e.exit(a), c(o)) : t === null ? n(t) : P(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), F(e, l, "linePrefix")) : (e.enter("chunkString", { contentType: "string" }), u(t));
	}
	function u(t) {
		return t === o || t === null || P(t) ? (e.exit("chunkString"), l(t)) : (e.consume(t), t === 92 ? d : u);
	}
	function d(t) {
		return t === o || t === 92 ? (e.consume(t), u) : u(t);
	}
}
// node_modules/micromark-factory-whitespace/index.js
function xn(e, t) {
	let n;
	return r;
	function r(i) {
		return P(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), n = !0, r) : J(i) ? F(e, r, n ? "linePrefix" : "lineSuffix")(i) : t(i);
	}
}
// node_modules/micromark-core-commonmark/lib/definition.js
var Sn = {
	name: "definition",
	tokenize: wn
}, Cn = {
	partial: !0,
	tokenize: Tn
};
function wn(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("definition"), o(t);
	}
	function o(t) {
		return yn.call(r, e, s, n, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(t);
	}
	function s(t) {
		return i = H(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), t === 58 ? (e.enter("definitionMarker"), e.consume(t), e.exit("definitionMarker"), c) : n(t);
	}
	function c(t) {
		return I(t) ? xn(e, l)(t) : l(t);
	}
	function l(t) {
		return vn(e, u, n, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString")(t);
	}
	function u(t) {
		return e.attempt(Cn, d, d)(t);
	}
	function d(t) {
		return J(t) ? F(e, f, "whitespace")(t) : f(t);
	}
	function f(a) {
		return a === null || P(a) ? (e.exit("definition"), r.parser.defined.push(i), t(a)) : n(a);
	}
}
function Tn(e, t, n) {
	return r;
	function r(t) {
		return I(t) ? xn(e, i)(t) : n(t);
	}
	function i(t) {
		return bn(e, a, n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(t);
	}
	function a(t) {
		return J(t) ? F(e, o, "whitespace")(t) : o(t);
	}
	function o(e) {
		return e === null || P(e) ? t(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/hard-break-escape.js
var En = {
	name: "hardBreakEscape",
	tokenize: Dn
};
function Dn(e, t, n) {
	return r;
	function r(t) {
		return e.enter("hardBreakEscape"), e.consume(t), i;
	}
	function i(r) {
		return P(r) ? (e.exit("hardBreakEscape"), t(r)) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/heading-atx.js
var On = {
	name: "headingAtx",
	resolve: kn,
	tokenize: An
};
function kn(e, t) {
	let n = e.length - 2, r = 3;
	if (e[r][1].type === "whitespace" && (r += 2), n - 2 > r && e[n][1].type === "whitespace" && (n -= 2), e[n][1].type === "atxHeadingSequence" && (r === n - 1 || n - 4 > r && e[n - 2][1].type === "whitespace") && (n -= r + 1 === n ? 2 : 4), n > r) {
		let i = {
			type: "atxHeadingText",
			start: e[r][1].start,
			end: e[n][1].end
		}, a = {
			type: "chunkText",
			start: e[r][1].start,
			end: e[n][1].end,
			contentType: "text"
		};
		O(e, r, n - r + 1, [
			[
				"enter",
				i,
				t
			],
			[
				"enter",
				a,
				t
			],
			[
				"exit",
				a,
				t
			],
			[
				"exit",
				i,
				t
			]
		]);
	}
	return e;
}
function An(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return e.enter("atxHeading"), a(t);
	}
	function a(t) {
		return e.enter("atxHeadingSequence"), o(t);
	}
	function o(t) {
		return t === 35 && r++ < 6 ? (e.consume(t), o) : t === null || I(t) ? (e.exit("atxHeadingSequence"), s(t)) : n(t);
	}
	function s(n) {
		return n === 35 ? (e.enter("atxHeadingSequence"), c(n)) : n === null || P(n) ? (e.exit("atxHeading"), t(n)) : J(n) ? F(e, s, "whitespace")(n) : (e.enter("atxHeadingText"), l(n));
	}
	function c(t) {
		return t === 35 ? (e.consume(t), c) : (e.exit("atxHeadingSequence"), s(t));
	}
	function l(t) {
		return t === null || t === 35 || I(t) ? (e.exit("atxHeadingText"), s(t)) : (e.consume(t), l);
	}
}
// node_modules/micromark-util-html-tag-name/index.js
var jn = /* @__PURE__ */ "address.article.aside.base.basefont.blockquote.body.caption.center.col.colgroup.dd.details.dialog.dir.div.dl.dt.fieldset.figcaption.figure.footer.form.frame.frameset.h1.h2.h3.h4.h5.h6.head.header.hr.html.iframe.legend.li.link.main.menu.menuitem.nav.noframes.ol.optgroup.option.p.param.search.section.summary.table.tbody.td.tfoot.th.thead.title.tr.track.ul".split("."), Mn = [
	"pre",
	"script",
	"style",
	"textarea"
], Nn = {
	concrete: !0,
	name: "htmlFlow",
	resolveTo: Fn,
	tokenize: In
}, Pn = {
	partial: !0,
	tokenize: Ln
};
function Fn(e) {
	let t = e.length;
	for (; t-- && (e[t][0] !== "enter" || e[t][1].type !== "htmlFlow"););
	return t > 1 && e[t - 2][1].type === "linePrefix" && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e;
}
function In(e, t, n) {
	let r = this, i, a, o, s, c;
	return l;
	function l(e) {
		return u(e);
	}
	function u(t) {
		return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(t), d;
	}
	function d(s) {
		return s === 33 ? (e.consume(s), f) : s === 47 ? (e.consume(s), a = !0, h) : s === 63 ? (e.consume(s), i = 3, r.interrupt ? t : L) : B(s) ? (e.consume(s), o = String.fromCharCode(s), g) : n(s);
	}
	function f(a) {
		return a === 45 ? (e.consume(a), i = 2, p) : a === 91 ? (e.consume(a), i = 5, s = 0, m) : B(a) ? (e.consume(a), i = 4, r.interrupt ? t : L) : n(a);
	}
	function p(i) {
		return i === 45 ? (e.consume(i), r.interrupt ? t : L) : n(i);
	}
	function m(i) {
		return i === "CDATA[".charCodeAt(s++) ? (e.consume(i), s === 6 ? r.interrupt ? t : O : m) : n(i);
	}
	function h(t) {
		return B(t) ? (e.consume(t), o = String.fromCharCode(t), g) : n(t);
	}
	function g(s) {
		if (s === null || s === 47 || s === 62 || I(s)) {
			let c = s === 47, l = o.toLowerCase();
			return !c && !a && Mn.includes(l) ? (i = 1, r.interrupt ? t(s) : O(s)) : jn.includes(o.toLowerCase()) ? (i = 6, c ? (e.consume(s), _) : r.interrupt ? t(s) : O(s)) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(s) : a ? v(s) : y(s));
		}
		return s === 45 || Y(s) ? (e.consume(s), o += String.fromCharCode(s), g) : n(s);
	}
	function _(i) {
		return i === 62 ? (e.consume(i), r.interrupt ? t : O) : n(i);
	}
	function v(t) {
		return J(t) ? (e.consume(t), v) : E(t);
	}
	function y(t) {
		return t === 47 ? (e.consume(t), E) : t === 58 || t === 95 || B(t) ? (e.consume(t), b) : J(t) ? (e.consume(t), y) : E(t);
	}
	function b(t) {
		return t === 45 || t === 46 || t === 58 || t === 95 || Y(t) ? (e.consume(t), b) : x(t);
	}
	function x(t) {
		return t === 61 ? (e.consume(t), S) : J(t) ? (e.consume(t), x) : y(t);
	}
	function S(t) {
		return t === null || t === 60 || t === 61 || t === 62 || t === 96 ? n(t) : t === 34 || t === 39 ? (e.consume(t), c = t, C) : J(t) ? (e.consume(t), S) : w(t);
	}
	function C(t) {
		return t === c ? (e.consume(t), c = null, T) : t === null || P(t) ? n(t) : (e.consume(t), C);
	}
	function w(t) {
		return t === null || t === 34 || t === 39 || t === 47 || t === 60 || t === 61 || t === 62 || t === 96 || I(t) ? x(t) : (e.consume(t), w);
	}
	function T(e) {
		return e === 47 || e === 62 || J(e) ? y(e) : n(e);
	}
	function E(t) {
		return t === 62 ? (e.consume(t), D) : n(t);
	}
	function D(t) {
		return t === null || P(t) ? O(t) : J(t) ? (e.consume(t), D) : n(t);
	}
	function O(t) {
		return t === 45 && i === 2 ? (e.consume(t), M) : t === 60 && i === 1 ? (e.consume(t), N) : t === 62 && i === 4 ? (e.consume(t), R) : t === 63 && i === 3 ? (e.consume(t), L) : t === 93 && i === 5 ? (e.consume(t), F) : P(t) && (i === 6 || i === 7) ? (e.exit("htmlFlowData"), e.check(Pn, te, k)(t)) : t === null || P(t) ? (e.exit("htmlFlowData"), k(t)) : (e.consume(t), O);
	}
	function k(t) {
		return e.check(Xt, A, te)(t);
	}
	function A(t) {
		return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), j;
	}
	function j(t) {
		return t === null || P(t) ? k(t) : (e.enter("htmlFlowData"), O(t));
	}
	function M(t) {
		return t === 45 ? (e.consume(t), L) : O(t);
	}
	function N(t) {
		return t === 47 ? (e.consume(t), o = "", ee) : O(t);
	}
	function ee(t) {
		if (t === 62) {
			let n = o.toLowerCase();
			return Mn.includes(n) ? (e.consume(t), R) : O(t);
		}
		return B(t) && o.length < 8 ? (e.consume(t), o += String.fromCharCode(t), ee) : O(t);
	}
	function F(t) {
		return t === 93 ? (e.consume(t), L) : O(t);
	}
	function L(t) {
		return t === 62 ? (e.consume(t), R) : t === 45 && i === 2 ? (e.consume(t), L) : O(t);
	}
	function R(t) {
		return t === null || P(t) ? (e.exit("htmlFlowData"), te(t)) : (e.consume(t), R);
	}
	function te(n) {
		return e.exit("htmlFlow"), t(n);
	}
}
function Ln(e, t, n) {
	return r;
	function r(r) {
		return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), e.attempt(R, t, n);
	}
}
// node_modules/micromark-core-commonmark/lib/html-text.js
var Rn = {
	name: "htmlText",
	tokenize: zn
};
function zn(e, t, n) {
	let r = this, i, a, o;
	return s;
	function s(t) {
		return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(t), c;
	}
	function c(t) {
		return t === 33 ? (e.consume(t), l) : t === 47 ? (e.consume(t), x) : t === 63 ? (e.consume(t), y) : B(t) ? (e.consume(t), w) : n(t);
	}
	function l(t) {
		return t === 45 ? (e.consume(t), u) : t === 91 ? (e.consume(t), a = 0, m) : B(t) ? (e.consume(t), v) : n(t);
	}
	function u(t) {
		return t === 45 ? (e.consume(t), p) : n(t);
	}
	function d(t) {
		return t === null ? n(t) : t === 45 ? (e.consume(t), f) : P(t) ? (o = d, N(t)) : (e.consume(t), d);
	}
	function f(t) {
		return t === 45 ? (e.consume(t), p) : d(t);
	}
	function p(e) {
		return e === 62 ? M(e) : e === 45 ? f(e) : d(e);
	}
	function m(t) {
		return t === "CDATA[".charCodeAt(a++) ? (e.consume(t), a === 6 ? h : m) : n(t);
	}
	function h(t) {
		return t === null ? n(t) : t === 93 ? (e.consume(t), g) : P(t) ? (o = h, N(t)) : (e.consume(t), h);
	}
	function g(t) {
		return t === 93 ? (e.consume(t), _) : h(t);
	}
	function _(t) {
		return t === 62 ? M(t) : t === 93 ? (e.consume(t), _) : h(t);
	}
	function v(t) {
		return t === null || t === 62 ? M(t) : P(t) ? (o = v, N(t)) : (e.consume(t), v);
	}
	function y(t) {
		return t === null ? n(t) : t === 63 ? (e.consume(t), b) : P(t) ? (o = y, N(t)) : (e.consume(t), y);
	}
	function b(e) {
		return e === 62 ? M(e) : y(e);
	}
	function x(t) {
		return B(t) ? (e.consume(t), S) : n(t);
	}
	function S(t) {
		return t === 45 || Y(t) ? (e.consume(t), S) : C(t);
	}
	function C(t) {
		return P(t) ? (o = C, N(t)) : J(t) ? (e.consume(t), C) : M(t);
	}
	function w(t) {
		return t === 45 || Y(t) ? (e.consume(t), w) : t === 47 || t === 62 || I(t) ? T(t) : n(t);
	}
	function T(t) {
		return t === 47 ? (e.consume(t), M) : t === 58 || t === 95 || B(t) ? (e.consume(t), E) : P(t) ? (o = T, N(t)) : J(t) ? (e.consume(t), T) : M(t);
	}
	function E(t) {
		return t === 45 || t === 46 || t === 58 || t === 95 || Y(t) ? (e.consume(t), E) : D(t);
	}
	function D(t) {
		return t === 61 ? (e.consume(t), O) : P(t) ? (o = D, N(t)) : J(t) ? (e.consume(t), D) : T(t);
	}
	function O(t) {
		return t === null || t === 60 || t === 61 || t === 62 || t === 96 ? n(t) : t === 34 || t === 39 ? (e.consume(t), i = t, k) : P(t) ? (o = O, N(t)) : J(t) ? (e.consume(t), O) : (e.consume(t), A);
	}
	function k(t) {
		return t === i ? (e.consume(t), i = void 0, j) : t === null ? n(t) : P(t) ? (o = k, N(t)) : (e.consume(t), k);
	}
	function A(t) {
		return t === null || t === 34 || t === 39 || t === 60 || t === 61 || t === 96 ? n(t) : t === 47 || t === 62 || I(t) ? T(t) : (e.consume(t), A);
	}
	function j(e) {
		return e === 47 || e === 62 || I(e) ? T(e) : n(e);
	}
	function M(r) {
		return r === 62 ? (e.consume(r), e.exit("htmlTextData"), e.exit("htmlText"), t) : n(r);
	}
	function N(t) {
		return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), ee;
	}
	function ee(t) {
		return J(t) ? F(e, L, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : L(t);
	}
	function L(t) {
		return e.enter("htmlTextData"), o(t);
	}
}
// node_modules/micromark-core-commonmark/lib/label-end.js
var Bn = {
	name: "labelEnd",
	resolveAll: Wn,
	resolveTo: Gn,
	tokenize: Kn
}, Vn = { tokenize: qn }, Hn = { tokenize: Jn }, Un = { tokenize: Yn };
function Wn(e) {
	let t = -1, n = [];
	for (; ++t < e.length;) {
		let r = e[t][1];
		if (n.push(e[t]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
			let e = r.type === "labelImage" ? 4 : 2;
			r.type = "data", t += e;
		}
	}
	return e.length !== n.length && O(e, 0, e.length, n), e;
}
function Gn(e, t) {
	let n = e.length, r = 0, i, a, o;
	for (; n--;) {
		let t = e[n][1];
		if (i) {
			if (t.type === "link" || t.type === "labelLink" && t._inactive) break;
			e[n][0] === "enter" && t.type === "labelLink" && (t._inactive = !0);
		} else if (a) {
			if (e[n][0] === "enter" && (t.type === "labelImage" || t.type === "labelLink") && !t._balanced && (i = n, t.type !== "labelLink")) {
				r = 2;
				break;
			}
		} else t.type === "labelEnd" && (a = n);
	}
	let s = {
		type: e[i][1].type === "labelLink" ? "link" : "image",
		start: { ...e[i][1].start },
		end: { ...e[e.length - 1][1].end }
	}, c = {
		type: "label",
		start: { ...e[i][1].start },
		end: { ...e[a][1].end }
	}, l = {
		type: "labelText",
		start: { ...e[i + r + 2][1].end },
		end: { ...e[a - 2][1].start }
	};
	return o = [[
		"enter",
		s,
		t
	], [
		"enter",
		c,
		t
	]], o = z(o, e.slice(i + 1, i + r + 3)), o = z(o, [[
		"enter",
		l,
		t
	]]), o = z(o, ne(t.parser.constructs.insideSpan.null, e.slice(i + r + 4, a - 3), t)), o = z(o, [
		[
			"exit",
			l,
			t
		],
		e[a - 2],
		e[a - 1],
		[
			"exit",
			c,
			t
		]
	]), o = z(o, e.slice(a + 1)), o = z(o, [[
		"exit",
		s,
		t
	]]), O(e, i, e.length, o), e;
}
function Kn(e, t, n) {
	let r = this, i = r._labelStarts, a, o;
	if (i) {
		for (; i.length > 0 && i[i.length - 1]._balanced;) i.pop();
		a = i[i.length - 1];
	}
	return s;
	function s(t) {
		return a ? a._inactive ? d(t) : (o = r.parser.defined.includes(H(r.sliceSerialize({
			start: a.end,
			end: r.now()
		}))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), e.exit("labelEnd"), c) : n(t);
	}
	function c(t) {
		return t === 40 ? e.attempt(Vn, u, o ? u : d)(t) : t === 91 ? e.attempt(Hn, u, o ? l : d)(t) : o ? u(t) : d(t);
	}
	function l(t) {
		return e.attempt(Un, u, d)(t);
	}
	function u(e) {
		return i.pop(), t(e);
	}
	function d(e) {
		return a._balanced = !0, n(e);
	}
}
function qn(e, t, n) {
	return r;
	function r(t) {
		return e.enter("resource"), e.enter("resourceMarker"), e.consume(t), e.exit("resourceMarker"), i;
	}
	function i(t) {
		return I(t) ? xn(e, a)(t) : a(t);
	}
	function a(t) {
		return t === 41 ? u(t) : vn(e, o, s, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(t);
	}
	function o(t) {
		return I(t) ? xn(e, c)(t) : u(t);
	}
	function s(e) {
		return n(e);
	}
	function c(t) {
		return t === 34 || t === 39 || t === 40 ? bn(e, l, n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(t) : u(t);
	}
	function l(t) {
		return I(t) ? xn(e, u)(t) : u(t);
	}
	function u(r) {
		return r === 41 ? (e.enter("resourceMarker"), e.consume(r), e.exit("resourceMarker"), e.exit("resource"), t) : n(r);
	}
}
function Jn(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return yn.call(r, e, a, o, "reference", "referenceMarker", "referenceString")(t);
	}
	function a(e) {
		return r.parser.defined.includes(H(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(e) : n(e);
	}
	function o(e) {
		return n(e);
	}
}
function Yn(e, t, n) {
	return r;
	function r(t) {
		return e.enter("reference"), e.enter("referenceMarker"), e.consume(t), e.exit("referenceMarker"), i;
	}
	function i(r) {
		return r === 93 ? (e.enter("referenceMarker"), e.consume(r), e.exit("referenceMarker"), e.exit("reference"), t) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/label-start-image.js
var Xn = {
	name: "labelStartImage",
	resolveAll: Bn.resolveAll,
	tokenize: Zn
};
function Zn(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(t), e.exit("labelImageMarker"), o;
	}
	function o(t) {
		return t === 91 ? (e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), i = e.exit("labelImage"), s) : n(t);
	}
	function s(e) {
		return e === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(e));
	}
}
// node_modules/micromark-core-commonmark/lib/label-start-link.js
var Qn = {
	name: "labelStartLink",
	resolveAll: Bn.resolveAll,
	tokenize: $n
};
function $n(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("labelLink"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), i = e.exit("labelLink"), o;
	}
	function o(e) {
		return e === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(e));
	}
}
// node_modules/micromark-core-commonmark/lib/line-ending.js
var er = {
	name: "lineEnding",
	tokenize: tr
};
function tr(e, t) {
	return n;
	function n(n) {
		return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), F(e, t, "linePrefix");
	}
}
// node_modules/micromark-core-commonmark/lib/thematic-break.js
var nr = {
	name: "thematicBreak",
	tokenize: rr
};
function rr(e, t, n) {
	let r = 0, i;
	return a;
	function a(t) {
		return e.enter("thematicBreak"), o(t);
	}
	function o(e) {
		return i = e, s(e);
	}
	function s(a) {
		return a === i ? (e.enter("thematicBreakSequence"), c(a)) : r >= 3 && (a === null || P(a)) ? (e.exit("thematicBreak"), t(a)) : n(a);
	}
	function c(t) {
		return t === i ? (e.consume(t), r++, c) : (e.exit("thematicBreakSequence"), J(t) ? F(e, s, "whitespace")(t) : s(t));
	}
}
// node_modules/micromark-core-commonmark/lib/list.js
var $ = {
	continuation: { tokenize: sr },
	exit: lr,
	name: "list",
	tokenize: or
}, ir = {
	partial: !0,
	tokenize: ur
}, ar = {
	partial: !0,
	tokenize: cr
};
function or(e, t, n) {
	let r = this, i = r.events[r.events.length - 1], a = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], !0).length : 0, o = 0;
	return s;
	function s(t) {
		let i = r.containerState.type || (t === 42 || t === 43 || t === 45 ? "listUnordered" : "listOrdered");
		if (i === "listUnordered" ? !r.containerState.marker || t === r.containerState.marker : ee(t)) {
			if (r.containerState.type || (r.containerState.type = i, e.enter(i, { _container: !0 })), i === "listUnordered") return e.enter("listItemPrefix"), t === 42 || t === 45 ? e.check(nr, n, l)(t) : l(t);
			if (!r.interrupt || t === 49) return e.enter("listItemPrefix"), e.enter("listItemValue"), c(t);
		}
		return n(t);
	}
	function c(t) {
		return ee(t) && ++o < 10 ? (e.consume(t), c) : (!r.interrupt || o < 2) && (r.containerState.marker ? t === r.containerState.marker : t === 41 || t === 46) ? (e.exit("listItemValue"), l(t)) : n(t);
	}
	function l(t) {
		return e.enter("listItemMarker"), e.consume(t), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || t, e.check(R, r.interrupt ? n : u, e.attempt(ir, f, d));
	}
	function u(e) {
		return r.containerState.initialBlankLine = !0, a++, f(e);
	}
	function d(t) {
		return J(t) ? (e.enter("listItemPrefixWhitespace"), e.consume(t), e.exit("listItemPrefixWhitespace"), f) : n(t);
	}
	function f(n) {
		return r.containerState.size = a + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, t(n);
	}
}
function sr(e, t, n) {
	let r = this;
	return r.containerState._closeFlow = void 0, e.check(R, i, a);
	function i(n) {
		return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, F(e, t, "listItemIndent", r.containerState.size + 1)(n);
	}
	function a(n) {
		return r.containerState.furtherBlankLines || !J(n) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, o(n)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(ar, t, o)(n));
	}
	function o(i) {
		return r.containerState._closeFlow = !0, r.interrupt = void 0, F(e, e.attempt($, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(i);
	}
}
function cr(e, t, n) {
	let r = this;
	return F(e, i, "listItemIndent", r.containerState.size + 1);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return i && i[1].type === "listItemIndent" && i[2].sliceSerialize(i[1], !0).length === r.containerState.size ? t(e) : n(e);
	}
}
function lr(e) {
	e.exit(this.containerState.type);
}
function ur(e, t, n) {
	let r = this;
	return F(e, i, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return !J(e) && i && i[1].type === "listItemPrefixWhitespace" ? t(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/setext-underline.js
var dr = {
	name: "setextUnderline",
	resolveTo: fr,
	tokenize: pr
};
function fr(e, t) {
	let n = new At(), r = e.length, i, a, o;
	for (; r--;) if (e[r][0] === "enter") {
		if (e[r][1].type === "content") {
			i = r;
			break;
		}
		e[r][1].type === "paragraph" && (a = r);
	} else e[r][1].type === "content" && n.add(r, 1, []), !o && e[r][1].type === "definition" && (o = r);
	let s = {
		type: "setextHeading",
		start: { ...e[i][1].start },
		end: { ...e[e.length - 1][1].end }
	};
	return e[a][1].type = "setextHeadingText", o ? (n.add(a, 0, [[
		"enter",
		s,
		t
	]]), n.add(o + 1, 0, [[
		"exit",
		e[i][1],
		t
	]]), e[i][1].end = { ...e[o][1].end }) : e[i][1] = s, n.add(e.length, 0, [[
		"exit",
		s,
		t
	]]), n.consume(e), e;
}
function pr(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		let a = r.events.length, s;
		for (; a--;) if (r.events[a][1].type !== "lineEnding" && r.events[a][1].type !== "linePrefix" && r.events[a][1].type !== "content") {
			s = r.events[a][1].type === "paragraph";
			break;
		}
		return !r.parser.lazy[r.now().line] && (r.interrupt || s) ? (e.enter("setextHeadingLine"), i = t, o(t)) : n(t);
	}
	function o(t) {
		return e.enter("setextHeadingLineSequence"), s(t);
	}
	function s(t) {
		return t === i ? (e.consume(t), s) : (e.exit("setextHeadingLineSequence"), J(t) ? F(e, c, "lineSuffix")(t) : c(t));
	}
	function c(r) {
		return r === null || P(r) ? (e.exit("setextHeadingLine"), t(r)) : n(r);
	}
}
// node_modules/micromark/lib/initialize/flow.js
var mr = { tokenize: hr };
function hr(e) {
	let t = this, n = e.attempt(R, r, e.attempt(this.parser.constructs.flowInitial, i, F(e, e.attempt(this.parser.constructs.flow, i, e.attempt(pn, i)), "linePrefix")));
	return n;
	function r(r) {
		if (r === null) e.consume(r);
		else return e.enter("lineEndingBlank"), e.consume(r), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n;
	}
	function i(r) {
		if (r === null) e.consume(r);
		else return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), t.currentConstruct = void 0, n;
	}
}
// node_modules/micromark/lib/initialize/text.js
var gr = { resolveAll: br() }, _r = yr("string"), vr = yr("text");
function yr(e) {
	return {
		resolveAll: br(e === "text" ? xr : void 0),
		tokenize: t
	};
	function t(t) {
		let n = this, r = this.parser.constructs[e], i = t.attempt(r, a, o);
		return a;
		function a(e) {
			return c(e) ? i(e) : o(e);
		}
		function o(e) {
			if (e === null) t.consume(e);
			else return t.enter("data"), t.consume(e), s;
		}
		function s(e) {
			return c(e) ? (t.exit("data"), i(e)) : (t.consume(e), s);
		}
		function c(e) {
			if (e === null) return !0;
			let t = r[e], i = -1;
			if (t) for (; ++i < t.length;) {
				let e = t[i];
				if (!e.previous || e.previous.call(n, n.previous)) return !0;
			}
			return !1;
		}
	}
}
function br(e) {
	return t;
	function t(t, n) {
		let r = -1, i;
		for (; ++r <= t.length;) i === void 0 ? t[r] && t[r][1].type === "data" && (i = r, r++) : t[r] && t[r][1].type === "data" || (r !== i + 2 && (t[i][1].end = t[r - 1][1].end, t.splice(i + 2, r - i - 2), r = i + 2), i = void 0);
		return e ? e(t, n) : t;
	}
}
function xr(e, t) {
	let n = new At(), r = 0;
	for (; ++r <= e.length;) if ((r === e.length || e[r][1].type === "lineEnding") && e[r - 1][1].type === "data") {
		let i = e[r - 1][1], a = t.sliceStream(i), o = a.length, s = -1, c = 0, l;
		for (; o--;) {
			let e = a[o];
			if (typeof e == "string") {
				for (s = e.length; e.charCodeAt(s - 1) === 32;) c++, s--;
				if (s) break;
				s = -1;
			} else if (e === -2) l = !0, c++;
			else if (e !== -1) {
				o++;
				break;
			}
		}
		if (t._contentTypeTextTrailing && r === e.length && (c = 0), c) {
			let a = {
				type: r === e.length || l || c < 2 ? "lineSuffix" : "hardBreakTrailing",
				start: {
					_bufferIndex: o ? s : i.start._bufferIndex + s,
					_index: i.start._index + o,
					line: i.end.line,
					column: i.end.column - c,
					offset: i.end.offset - c
				},
				end: { ...i.end }
			};
			i.end = { ...a.start }, i.start.offset === i.end.offset ? Object.assign(i, a) : n.add(r, 0, [[
				"enter",
				a,
				t
			], [
				"exit",
				a,
				t
			]]);
		}
		r++;
	}
	return n.consume(e), e;
}
// node_modules/micromark/lib/constructs.js
var Sr = /* @__PURE__ */ r({
	attentionMarkers: () => Ar,
	contentInitial: () => wr,
	disable: () => jr,
	document: () => Cr,
	flow: () => Er,
	flowInitial: () => Tr,
	insideSpan: () => kr,
	string: () => Dr,
	text: () => Or
}), Cr = {
	42: $,
	43: $,
	45: $,
	48: $,
	49: $,
	50: $,
	51: $,
	52: $,
	53: $,
	54: $,
	55: $,
	56: $,
	57: $,
	62: Ht
}, wr = { 91: Sn }, Tr = {
	[-2]: en,
	[-1]: en,
	32: en
}, Er = {
	35: On,
	42: nr,
	45: [dr, nr],
	60: Nn,
	61: dr,
	95: nr,
	96: Qt,
	126: Qt
}, Dr = {
	38: Jt,
	92: Kt
}, Or = {
	[-5]: er,
	[-4]: er,
	[-3]: er,
	33: Xn,
	38: Jt,
	42: It,
	60: [Bt, Rn],
	91: Qn,
	92: [En, Kt],
	93: Bn,
	95: It,
	96: an
}, kr = { null: [It, gr] }, Ar = { null: [42, 95] }, jr = { null: [] };
// node_modules/micromark/lib/create-tokenizer.js
function Mr(e, t, n) {
	let r = {
		_bufferIndex: -1,
		_index: 0,
		line: n && n.line || 1,
		column: n && n.column || 1,
		offset: n && n.offset || 0
	}, i = {}, a = [], o = [], s = [], c = {
		attempt: C(x),
		check: C(S),
		consume: v,
		enter: y,
		exit: b,
		interrupt: C(S, { interrupt: !0 })
	}, l = {
		code: null,
		containerState: {},
		defineSkip: h,
		events: [],
		now: m,
		parser: e,
		previous: null,
		sliceSerialize: f,
		sliceStream: p,
		write: d
	}, u = t.tokenize.call(l, c);
	return t.resolveAll && a.push(t), l;
	function d(e) {
		return o = z(o, e), g(), o[o.length - 1] === null ? (w(t, 0), l.events = ne(a, l.events, l), l.events) : [];
	}
	function f(e, t) {
		return Pr(p(e), t);
	}
	function p(e) {
		return Nr(o, e);
	}
	function m() {
		let { _bufferIndex: e, _index: t, line: n, column: i, offset: a } = r;
		return {
			_bufferIndex: e,
			_index: t,
			line: n,
			column: i,
			offset: a
		};
	}
	function h(e) {
		i[e.line] = e.column, E();
	}
	function g() {
		for (; r._index < o.length;) {
			let e = o[r._index];
			if (typeof e == "string") {
				let t = r._index;
				for (r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === t && r._bufferIndex < e.length;) _(e.charCodeAt(r._bufferIndex));
			} else _(e);
		}
	}
	function _(e) {
		u = u(e);
	}
	function v(e) {
		P(e) ? (r.line++, r.column = 1, r.offset += e === -3 ? 2 : 1, E()) : e !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === o[r._index].length && (r._bufferIndex = -1, r._index++)), l.previous = e;
	}
	function y(e, t) {
		let n = t || {};
		return n.type = e, n.start = m(), l.events.push([
			"enter",
			n,
			l
		]), s.push(n), n;
	}
	function b(e) {
		let t = s.pop();
		return t.end = m(), l.events.push([
			"exit",
			t,
			l
		]), t;
	}
	function x(e, t) {
		w(e, t.from);
	}
	function S(e, t) {
		t.restore();
	}
	function C(e, t) {
		return n;
		function n(n, r, i) {
			let a, o, s, u;
			return Array.isArray(n) ? f(n) : "tokenize" in n ? f([n]) : d(n);
			function d(e) {
				return t;
				function t(t) {
					let n = t !== null && e[t], r = t !== null && e.null;
					return f([...Array.isArray(n) ? n : n ? [n] : [], ...Array.isArray(r) ? r : r ? [r] : []])(t);
				}
			}
			function f(e) {
				return a = e, o = 0, e.length === 0 ? i : p(e[o]);
			}
			function p(e) {
				return n;
				function n(n) {
					return u = T(), s = e, e.partial || (l.currentConstruct = e), e.name && l.parser.constructs.disable.null.includes(e.name) ? h(n) : e.tokenize.call(t ? Object.assign(Object.create(l), t) : l, c, m, h)(n);
				}
			}
			function m(t) {
				return e(s, u), r;
			}
			function h(e) {
				return u.restore(), ++o < a.length ? p(a[o]) : i;
			}
		}
	}
	function w(e, t) {
		e.resolveAll && !a.includes(e) && a.push(e), e.resolve && O(l.events, t, l.events.length - t, e.resolve(l.events.slice(t), l)), e.resolveTo && (l.events = e.resolveTo(l.events, l));
	}
	function T() {
		let e = m(), t = l.previous, n = l.currentConstruct, i = l.events.length, a = Array.from(s);
		return {
			from: i,
			restore: o
		};
		function o() {
			r = e, l.previous = t, l.currentConstruct = n, l.events.length = i, s = a, E();
		}
	}
	function E() {
		r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1);
	}
}
function Nr(e, t) {
	let n = t.start._index, r = t.start._bufferIndex, i = t.end._index, a = t.end._bufferIndex, o;
	if (n === i) o = [e[n].slice(r, a)];
	else {
		if (o = e.slice(n, i), r > -1) {
			let e = o[0];
			typeof e == "string" ? o[0] = e.slice(r) : o.shift();
		}
		a > 0 && o.push(e[i].slice(0, a));
	}
	return o;
}
function Pr(e, t) {
	let n = -1, r = [], i;
	for (; ++n < e.length;) {
		let a = e[n], o;
		if (typeof a == "string") o = a;
		else switch (a) {
			case -5:
				o = "\r";
				break;
			case -4:
				o = "\n";
				break;
			case -3:
				o = "\r\n";
				break;
			case -2:
				o = t ? " " : "	";
				break;
			case -1:
				if (!t && i) continue;
				o = " ";
				break;
			default: o = String.fromCharCode(a);
		}
		i = a === -2, r.push(o);
	}
	return r.join("");
}
// node_modules/micromark/lib/parse.js
function Fr(e) {
	let t = {
		constructs: se([Sr, ...(e || {}).extensions || []]),
		content: n(Ot),
		defined: [],
		document: n(Mt),
		flow: n(mr),
		lazy: {},
		string: n(_r),
		text: n(vr)
	};
	return t;
	function n(e) {
		return n;
		function n(n) {
			return Mr(t, e, n);
		}
	}
}
// node_modules/micromark/lib/postprocess.js
function Ir(e) {
	for (; !dn(e););
	return e;
}
// node_modules/micromark/lib/preprocess.js
var Lr = /[\0\t\n\r]/g;
function Rr() {
	let e = 1, t = "", n = !0, r;
	return i;
	function i(i, a, o) {
		i = t + (typeof i == "string" ? i.toString() : new TextDecoder(a || void 0).decode(i));
		let s = [], c = 0;
		for (t = "", n &&= (i.charCodeAt(0) === 65279 && c++, void 0); c < i.length;) {
			Lr.lastIndex = c;
			let n = Lr.exec(i), a = n && n.index !== void 0 ? n.index : i.length, o = i.charCodeAt(a);
			if (!n) {
				t = i.slice(c);
				break;
			}
			if (o === 10 && c === a && r) s.push(-3), r = void 0;
			else switch (r &&= (s.push(-5), void 0), c < a && (s.push(i.slice(c, a)), e += a - c), o) {
				case 0:
					s.push(65533), e++;
					break;
				case 9: {
					let t = Math.ceil(e / 4) * 4;
					for (s.push(-2); e++ < t;) s.push(-1);
					break;
				}
				case 10:
					s.push(-4), e = 1;
					break;
				default: r = !0, e = 1;
			}
			c = a + 1;
		}
		return o && (r && s.push(-5), t && s.push(t), s.push(null)), s;
	}
}
// node_modules/micromark-util-decode-string/index.js
var zr = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function Br(e) {
	return e.replace(zr, Vr);
}
function Vr(e, t, n) {
	if (t) return t;
	if (n.charCodeAt(0) === 35) {
		let e = n.charCodeAt(1), t = e === 120 || e === 88;
		return Dt(n.slice(t ? 2 : 1), t ? 16 : 10);
	}
	return Et(n) || e;
}
// node_modules/mdast-util-from-markdown/lib/index.js
var Hr = {}.hasOwnProperty;
function Ur(e, t, n) {
	return t && typeof t == "object" && (n = t, t = void 0), Wr(n)(Ir(Fr(n).document().write(Rr()(e, t, !0))));
}
function Wr(e) {
	let t = {
		afterExit: [],
		beforeEnter: [],
		transforms: [],
		canContainEols: [
			"emphasis",
			"fragment",
			"heading",
			"paragraph",
			"strong"
		],
		enter: {
			autolink: o(K),
			autolinkProtocol: E,
			autolinkEmail: E,
			atxHeading: o(ue),
			blockQuote: o(ae),
			characterEscape: E,
			characterReference: E,
			codeFenced: o(oe),
			codeFencedFenceInfo: s,
			codeFencedFenceMeta: s,
			codeIndented: o(oe, s),
			codeText: o(se, s),
			codeTextData: E,
			data: E,
			codeFlowValue: E,
			definition: o(ce),
			definitionDestinationString: s,
			definitionLabelString: s,
			definitionTitleString: s,
			emphasis: o(U),
			hardBreakEscape: o(W),
			hardBreakTrailing: o(W),
			htmlFlow: o(de, s),
			htmlFlowData: E,
			htmlText: o(de, s),
			htmlTextData: E,
			image: o(G),
			label: s,
			link: o(K),
			listItem: o(fe),
			listItemValue: p,
			listOrdered: o(q, f),
			listUnordered: o(q),
			paragraph: o(J),
			reference: te,
			referenceString: s,
			resourceDestinationString: s,
			resourceTitleString: s,
			setextHeading: o(ue),
			strong: o(pe),
			thematicBreak: o(he)
		},
		exit: {
			atxHeading: l(),
			atxHeadingSequence: S,
			autolink: l(),
			autolinkEmail: ie,
			autolinkProtocol: V,
			blockQuote: l(),
			characterEscapeValue: D,
			characterReferenceMarkerHexadecimal: z,
			characterReferenceMarkerNumeric: z,
			characterReferenceValue: B,
			characterReference: re,
			codeFenced: l(_),
			codeFencedFence: g,
			codeFencedFenceInfo: m,
			codeFencedFenceMeta: h,
			codeFlowValue: D,
			codeIndented: l(v),
			codeText: l(M),
			codeTextData: D,
			data: D,
			definition: l(),
			definitionDestinationString: x,
			definitionLabelString: y,
			definitionTitleString: b,
			emphasis: l(),
			hardBreakEscape: l(k),
			hardBreakTrailing: l(k),
			htmlFlow: l(A),
			htmlFlowData: D,
			htmlText: l(j),
			htmlTextData: D,
			image: l(P),
			label: F,
			labelText: ee,
			lineEnding: O,
			link: l(N),
			listItem: l(),
			listOrdered: l(),
			listUnordered: l(),
			paragraph: l(),
			referenceString: ne,
			resourceDestinationString: I,
			resourceTitleString: L,
			resource: R,
			setextHeading: l(T),
			setextHeadingLineSequence: w,
			setextHeadingText: C,
			strong: l(),
			thematicBreak: l()
		}
	};
	Kr(t, (e || {}).mdastExtensions || []);
	let n = {};
	return r;
	function r(e) {
		let r = {
			type: "root",
			children: [],
			position: void 0
		}, o = {
			stack: [r],
			tokenStack: [],
			config: t,
			enter: c,
			exit: u,
			buffer: s,
			resume: d,
			data: n
		}, l = [], f = [], p = -1;
		for (; ++p < e.length;) f.push(e[p]), (e[p][1].type === "listOrdered" || e[p][1].type === "listUnordered") && (e[p][0] === "enter" ? l.push(f.length - 1) : a(f, l.pop()));
		for (e = f, p = -1; ++p < e.length;) {
			let n = t[e[p][0]];
			e[p][0] === "enter" && t.beforeEnter.length > 0 && i(t.beforeEnter, {
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]), Hr.call(n, e[p][1].type) && n[e[p][1].type].call({
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]), e[p][0] === "exit" && t.afterExit.length > 0 && i(t.afterExit, {
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]);
		}
		if (o.tokenStack.length > 0) {
			let e = o.tokenStack[o.tokenStack.length - 1];
			(e[1] || Jr).call(o, void 0, e[0]);
		}
		for (r.position = {
			start: Gr(e.length > 0 ? e[0][1].start : {
				line: 1,
				column: 1,
				offset: 0
			}),
			end: Gr(e.length > 0 ? e[e.length - 2][1].end : {
				line: 1,
				column: 1,
				offset: 0
			})
		}, p = -1; ++p < t.transforms.length;) r = t.transforms[p](r) || r;
		return r;
	}
	function i(e, t, n) {
		let r = -1;
		for (; ++r < e.length;) e[r].call(t, n);
	}
	function a(e, t) {
		let n = e.length - 1, r = t - 1, i = -1, a = !1, o, s, c, l, u = [];
		for (; ++r <= n;) {
			let t = e[r];
			switch (t[1].type) {
				case "listUnordered":
				case "listOrdered":
				case "blockQuote":
					t[0] === "enter" ? i++ : i--, l = void 0;
					break;
				case "lineEndingBlank":
					t[0] === "enter" && (o && !l && !i && !c && (c = r), l = void 0);
					break;
				case "linePrefix":
				case "listItemValue":
				case "listItemMarker":
				case "listItemPrefix":
				case "listItemPrefixWhitespace": break;
				default: l = void 0;
			}
			if (!i && t[0] === "enter" && t[1].type === "listItemPrefix" || i === -1 && t[0] === "exit" && (t[1].type === "listUnordered" || t[1].type === "listOrdered")) {
				if (o) {
					let n = r;
					for (s = void 0; n--;) {
						let t = e[n];
						if (t[1].type === "lineEnding" || t[1].type === "lineEndingBlank") {
							if (t[0] === "exit") continue;
							s && (e[s][1].type = "lineEndingBlank", a = !0), t[1].type = "lineEnding", s = n;
						} else if (t[1].type !== "linePrefix" && t[1].type !== "blockQuotePrefix" && t[1].type !== "blockQuotePrefixWhitespace" && t[1].type !== "blockQuoteMarker" && t[1].type !== "listItemIndent") break;
					}
					c && (!s || c < s) && (o._spread = !0), o.end = Object.assign({}, s ? e[s][1].start : t[1].end), u.push({
						at: s || r,
						event: [
							"exit",
							o,
							t[2]
						]
					});
				}
				if (t[1].type === "listItemPrefix") {
					let e = {
						type: "listItem",
						_spread: !1,
						start: Object.assign({}, t[1].start),
						end: void 0
					};
					o = e, u.push({
						at: r,
						event: [
							"enter",
							e,
							t[2]
						]
					}), c = void 0, l = !0;
				}
			}
		}
		let d = e.splice(t), f = 0;
		for (r = -1; ++r < d.length;) {
			for (; f < u.length && u[f].at === t + r;) e.push(u[f++].event);
			e.push(d[r]);
		}
		e[t][1]._spread = a;
	}
	function o(e, t) {
		return n;
		function n(n) {
			c.call(this, e(n), n), t && t.call(this, n);
		}
	}
	function s() {
		this.stack.push({
			type: "fragment",
			children: []
		});
	}
	function c(e, t, n) {
		this.stack[this.stack.length - 1].children.push(e), this.stack.push(e), this.tokenStack.push([t, n || void 0]), e.position = {
			start: Gr(t.start),
			end: void 0
		};
	}
	function l(e) {
		return t;
		function t(t) {
			e && e.call(this, t), u.call(this, t);
		}
	}
	function u(e, t) {
		let n = this.stack.pop(), r = this.tokenStack.pop();
		if (!r) throw Error("Cannot close `" + e.type + "` (" + Ue({
			start: e.start,
			end: e.end
		}) + "): it’s not open");
		r[0].type !== e.type && (t ? t.call(this, e, r[0]) : (r[1] || Jr).call(this, e, r[0])), n.position.end = Gr(e.end);
	}
	function d() {
		return le(this.stack.pop());
	}
	function f() {
		this.data.expectingFirstListItemValue = !0;
	}
	function p(e) {
		if (this.data.expectingFirstListItemValue) {
			let t = this.stack[this.stack.length - 2];
			t.start = Number.parseInt(this.sliceSerialize(e), 10), this.data.expectingFirstListItemValue = void 0;
		}
	}
	function m() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.lang = e;
	}
	function h() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.meta = e;
	}
	function g() {
		this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
	}
	function _() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
	}
	function v() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e.replace(/(\r?\n|\r)$/g, "");
	}
	function y(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.label = t, n.identifier = H(this.sliceSerialize(e)).toLowerCase();
	}
	function b() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.title = e;
	}
	function x() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.url = e;
	}
	function S(e) {
		let t = this.stack[this.stack.length - 1];
		t.depth ||= this.sliceSerialize(e).length;
	}
	function C() {
		this.data.setextHeadingSlurpLineEnding = !0;
	}
	function w(e) {
		let t = this.stack[this.stack.length - 1];
		t.depth = this.sliceSerialize(e).codePointAt(0) === 61 ? 1 : 2;
	}
	function T() {
		this.data.setextHeadingSlurpLineEnding = void 0;
	}
	function E(e) {
		let t = this.stack[this.stack.length - 1].children, n = t[t.length - 1];
		n && n.type === "text" || (n = me(), n.position = {
			start: Gr(e.start),
			end: void 0
		}, t.push(n)), this.stack.push(n);
	}
	function D(e) {
		let t = this.stack.pop();
		t.value += this.sliceSerialize(e), t.position.end = Gr(e.end);
	}
	function O(e) {
		let n = this.stack[this.stack.length - 1];
		if (this.data.atHardBreak) {
			let t = n.children[n.children.length - 1];
			t.position.end = Gr(e.end), this.data.atHardBreak = void 0;
		} else !this.data.setextHeadingSlurpLineEnding && t.canContainEols.includes(n.type) && (E.call(this, e), D.call(this, e));
	}
	function k() {
		this.data.atHardBreak = !0;
	}
	function A() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function j() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function M() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function N() {
		let e = this.stack[this.stack.length - 1];
		if (this.data.inReference) {
			let t = this.data.referenceType || "shortcut";
			e.type += "Reference", e.referenceType = t, delete e.url, delete e.title;
		} else delete e.identifier, delete e.label;
		this.data.referenceType = void 0;
	}
	function P() {
		let e = this.stack[this.stack.length - 1];
		if (this.data.inReference) {
			let t = this.data.referenceType || "shortcut";
			e.type += "Reference", e.referenceType = t, delete e.url, delete e.title;
		} else delete e.identifier, delete e.label;
		this.data.referenceType = void 0;
	}
	function ee(e) {
		let t = this.sliceSerialize(e), n = this.stack[this.stack.length - 2];
		n.label = Br(t), n.identifier = H(t).toLowerCase();
	}
	function F() {
		let e = this.stack[this.stack.length - 1], t = this.resume(), n = this.stack[this.stack.length - 1];
		this.data.inReference = !0, n.type === "link" ? n.children = e.children : n.alt = t;
	}
	function I() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.url = e;
	}
	function L() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.title = e;
	}
	function R() {
		this.data.inReference = void 0;
	}
	function te() {
		this.data.referenceType = "collapsed";
	}
	function ne(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.label = t, n.identifier = H(this.sliceSerialize(e)).toLowerCase(), this.data.referenceType = "full";
	}
	function z(e) {
		this.data.characterReferenceType = e.type;
	}
	function B(e) {
		let t = this.sliceSerialize(e), n = this.data.characterReferenceType, r;
		n ? (r = Dt(t, n === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : r = Et(t);
		let i = this.stack[this.stack.length - 1];
		i.value += r;
	}
	function re(e) {
		let t = this.stack.pop();
		t.position.end = Gr(e.end);
	}
	function V(e) {
		D.call(this, e);
		let t = this.stack[this.stack.length - 1];
		t.url = this.sliceSerialize(e);
	}
	function ie(e) {
		D.call(this, e);
		let t = this.stack[this.stack.length - 1];
		t.url = "mailto:" + this.sliceSerialize(e);
	}
	function ae() {
		return {
			type: "blockquote",
			children: [],
			position: void 0
		};
	}
	function oe() {
		return {
			type: "code",
			lang: null,
			meta: null,
			value: "",
			position: void 0
		};
	}
	function se() {
		return {
			type: "inlineCode",
			value: "",
			position: void 0
		};
	}
	function ce() {
		return {
			type: "definition",
			identifier: "",
			label: null,
			title: null,
			url: "",
			position: void 0
		};
	}
	function U() {
		return {
			type: "emphasis",
			children: [],
			position: void 0
		};
	}
	function ue() {
		return {
			type: "heading",
			depth: 0,
			children: [],
			position: void 0
		};
	}
	function W() {
		return {
			type: "break",
			position: void 0
		};
	}
	function de() {
		return {
			type: "html",
			value: "",
			position: void 0
		};
	}
	function G() {
		return {
			type: "image",
			title: null,
			url: "",
			alt: null,
			position: void 0
		};
	}
	function K() {
		return {
			type: "link",
			title: null,
			url: "",
			children: [],
			position: void 0
		};
	}
	function q(e) {
		return {
			type: "list",
			ordered: e.type === "listOrdered",
			start: null,
			spread: e._spread,
			children: [],
			position: void 0
		};
	}
	function fe(e) {
		return {
			type: "listItem",
			spread: e._spread,
			checked: null,
			children: [],
			position: void 0
		};
	}
	function J() {
		return {
			type: "paragraph",
			children: [],
			position: void 0
		};
	}
	function pe() {
		return {
			type: "strong",
			children: [],
			position: void 0
		};
	}
	function me() {
		return {
			type: "text",
			value: "",
			position: void 0
		};
	}
	function he() {
		return {
			type: "thematicBreak",
			position: void 0
		};
	}
}
function Gr(e) {
	return {
		line: e.line,
		column: e.column,
		offset: e.offset
	};
}
function Kr(e, t) {
	let n = -1;
	for (; ++n < t.length;) {
		let r = t[n];
		Array.isArray(r) ? Kr(e, r) : qr(e, r);
	}
}
function qr(e, t) {
	let n;
	for (n in t) if (Hr.call(t, n)) switch (n) {
		case "canContainEols": {
			let r = t[n];
			r && e[n].push(...r);
			break;
		}
		case "transforms": {
			let r = t[n];
			r && e[n].push(...r);
			break;
		}
		case "afterExit":
		case "beforeEnter": {
			let r = t[n];
			r && e[n].push(r);
			break;
		}
		case "enter":
		case "exit": {
			let r = t[n];
			r && Object.assign(e[n], r);
			break;
		}
	}
}
function Jr(e, t) {
	throw Error(e ? "Cannot close `" + e.type + "` (" + Ue({
		start: e.start,
		end: e.end
	}) + "): a different token (`" + t.type + "`, " + Ue({
		start: t.start,
		end: t.end
	}) + ") is open" : "Cannot close document, a token (`" + t.type + "`, " + Ue({
		start: t.start,
		end: t.end
	}) + ") is still open");
}
// node_modules/remark-parse/lib/index.js
function Yr(e) {
	let t = this;
	t.parser = n;
	function n(n) {
		return Ur(n, {
			...t.data("settings"),
			...e,
			extensions: t.data("micromarkExtensions") || [],
			mdastExtensions: t.data("fromMarkdownExtensions") || []
		});
	}
}
// src/local/parsing/parse-budget.ts
var Xr = class extends Error {
	kind;
	limit;
	start;
	end;
	constructor(e, t, n, r) {
		super(e === "parse-work" ? `Parsing work exceeds the limit of ${t}.` : `Markdown nesting exceeds the ${t}-level limit.`), this.kind = e, this.limit = t, this.start = n, this.end = r, this.name = "ParseBudgetError";
	}
}, Zr = class {
	limits;
	usedWork = 0;
	observedDepth = 0;
	constructor(e) {
		this.limits = e;
	}
	get parseWork() {
		return this.usedWork;
	}
	get maxDepth() {
		return this.observedDepth;
	}
	charge(e, t, n) {
		if (!(!Number.isFinite(e) || e <= 0) && (this.usedWork += Math.floor(e), this.usedWork > this.limits.maxParseWork)) throw new Xr("parse-work", this.limits.maxParseWork, t, Math.max(t + 1, n));
	}
	observeDepth(e, t, n) {
		if (!Number.isFinite(e) || e <= 0) e > this.observedDepth && (this.observedDepth = e);
		else if (e > this.observedDepth && (this.observedDepth = e), e > this.limits.maxMarkdownDepth) throw new Xr("markdown-depth", this.limits.maxMarkdownDepth, t, Math.max(t + 1, n));
	}
}, Qr = /^([-+*]|\d{1,9}[.)]) /, $r = /!\[(\ue000[0-9]+\ue001)\]\(rmd-internal:placeholder\)/g;
function ei(e, t) {
	let n = t?.placeholders ? e.replace($r, (e, n, r) => {
		let i = t.placeholders.get(r + (t.offset ?? 0));
		return i && i.marker === n && i.end === r + (t.offset ?? 0) + e.length ? "x".repeat(e.length) : e;
	}) : e;
	if (e.includes("﻿") || /[\u0000-\u0009\u000b\u000c\u000e-\u001f\u007f\\`_\[\]<>!~&$@#]/.test(n) || !t?.allowBraces && /[{}]/.test(e) || e.includes("://") || /www\./i.test(e)) return;
	let r = [];
	for (let t = 0; t < e.length;) {
		let n = t;
		for (; n < e.length && e[n] !== "\r" && e[n] !== "\n";) n++;
		let i = e.slice(t, n);
		if (i.startsWith(" ") || i.endsWith(" ")) return;
		r.push({
			from: t,
			to: n,
			text: i
		}), t = e[n] === "\r" && e[n + 1] === "\n" ? n + 2 : n + 1;
	}
	return r;
}
function ti(e, t = !1) {
	let n = [], r = 0;
	for (; r < e.length;) {
		let i = r;
		for (; i < e.length && e[i] !== "*" && !(t && e[i] === "!");) i++;
		if (i === e.length) {
			n.push({
				type: "text",
				from: r,
				to: e.length,
				value: e.slice(r)
			});
			break;
		}
		if (t && e[i] === "!") {
			$r.lastIndex = i;
			let t = $r.exec(e);
			if (!t || t.index !== i) return;
			i > r && n.push({
				type: "text",
				from: r,
				to: i,
				value: e.slice(r, i)
			}), n.push({
				type: "opaque",
				from: i,
				to: i + t[0].length,
				value: t[1]
			}), r = i + t[0].length;
			continue;
		}
		if (e.slice(i, i + 2) !== "**" || i > 0 && e[i - 1] !== " ") return;
		let a = i + 2;
		for (; a < e.length && e[a] !== "*";) a++;
		if (a + 2 > e.length || e.slice(a, a + 2) !== "**" || a + 2 < e.length && !/[ .,;:?)\-]/.test(e[a + 2])) return;
		let o = e.slice(i + 2, a);
		if (!/^[\p{L}\p{N}](?:[\p{L}\p{N} .,:;()/-]*[\p{L}\p{N}])?$/u.test(o)) return;
		i > r && n.push({
			type: "text",
			from: r,
			to: i,
			value: e.slice(r, i)
		}), n.push({
			type: "strong",
			from: i,
			to: a + 2,
			value: o
		}), r = a + 2;
	}
	return n;
}
function ni(e, t, n, r, i) {
	let a = i(e, t, n);
	if (a === void 0) return;
	let o = [];
	for (let t of a) if (t.type === "text") o.push(r("text", e + t.from, e + t.to, { value: t.value }));
	else if (t.type === "opaque") o.push(r("rmdOpaque", e + t.from, e + t.to, { value: t.value }));
	else {
		let n = r("text", e + t.from + 2, e + t.to - 2, { value: t.value });
		o.push(r("strong", e + t.from, e + t.to, { children: [n] }));
	}
	return o;
}
function ri(e, t, n, r) {
	function i(e, t, i) {
		return ni(e, t, i, n, r);
	}
	function a(t, r, a) {
		let o = e.slice(t, r);
		if (!o || /^[ >+=-]/.test(o) || Qr.test(o) || /^\d{1,9}[.)]$/.test(o) || o.includes("|") || !a && o.startsWith("![")) return;
		let s = i(t, r, a);
		if (s !== void 0) return n("paragraph", t, r, { children: s });
	}
	function o(t) {
		if (!t.text.startsWith("|") || !t.text.endsWith("|") || t.text.length < 2) return;
		let n = [], r = t.from;
		for (let i = r + 1; i < t.to; i++) {
			if (e[i] !== "|") continue;
			let t = r + 1, a = i;
			for (; e[t] === " " && t < a;) t++;
			for (; e[a - 1] === " " && a > t;) a--;
			n.push({
				from: t,
				to: a,
				left: r,
				right: i
			}), r = i;
		}
		return n;
	}
	function s(e, t) {
		let r = [];
		for (let a = 0; a < t.length; a++) {
			let o = t[a], s = i(o.from, o.to, "row");
			if (s === void 0) return;
			r.push(n("tableCell", o.left, a === t.length - 1 ? e.to : o.right, { children: s }));
		}
		return n("tableRow", e.from, e.to, { children: r });
	}
	let c = [];
	for (let r = 0; r < t.length;) {
		let i = t[r];
		if (!i.text) {
			r++;
			continue;
		}
		let l = Qr.exec(i.text);
		if (l) {
			let e = [], o = l[1].length > 1, s = o ? l[1].at(-1) : l[1];
			for (; r < t.length;) {
				let i = t[r], c = Qr.exec(i.text);
				if (!c || (o ? c[1].length === 1 || c[1].at(-1) !== s : c[1] !== s)) break;
				let l = a(i.from + c[0].length, i.to, "item");
				if (l === void 0) return;
				e.push(n("listItem", i.from, i.to, {
					checked: null,
					children: [l]
				})), r++;
			}
			let u = r;
			for (; u < t.length && !t[u].text;) u++;
			if (u < t.length && Qr.test(t[u].text)) return;
			c.push(n("list", i.from, t[r - 1].to, {
				ordered: o,
				start: o ? parseInt(l[1], 10) : null,
				children: e
			}));
		} else if (i.text.startsWith("|")) {
			let a = o(i), l = t[r + 1] && o(t[r + 1]);
			if (!a?.length || !l || a.length !== l.length) return;
			let u = [];
			for (let t of l) {
				let n = e.slice(t.from, t.to);
				if (!/^:?-+:?$/.test(n)) return;
				u.push(n.startsWith(":") ? n.endsWith(":") ? "center" : "left" : n.endsWith(":") ? "right" : null);
			}
			let d = s(i, a);
			if (d === void 0) return;
			let f = [d];
			for (r += 2; r < t.length && t[r].text.startsWith("|");) {
				let e = o(t[r]);
				if (!e || e.length !== a.length) return;
				let n = s(t[r], e);
				if (n === void 0) return;
				f.push(n), r++;
			}
			c.push(n("table", i.from, t[r - 1].to, {
				align: u,
				children: f
			}));
		} else {
			let e = a(i.from, i.to);
			if (e === void 0) return;
			c.push(e), r++;
		}
		if (r < t.length && t[r].text) return;
	}
	return c;
}
function ii(e, t, n, r, i) {
	let a = i ?? ei(e, r);
	if (a === void 0) return;
	let o = /* @__PURE__ */ new Map(), s = (i, a, s) => {
		let c = e.slice(i, a);
		if (o.has(c)) return o.get(c);
		if (n?.has(c)) {
			let e = n.get(c);
			return o.set(c, e), s && e !== void 0 && t?.noteInlineReuse?.(s), e;
		}
		if (t) {
			let e = t.readInline(r?.placeholders ? "\0opaque\0" + c : c);
			if (e.hit) return s && e.value !== void 0 && t.noteInlineReuse?.(s), o.set(c, e.value), e.value;
		}
		let l = ti(c, !!r?.placeholders);
		return o.set(c, l), t?.writeInline(r?.placeholders ? "\0opaque\0" + c : c, l), l;
	}, c = 0, l = ri(e, a, (e) => (e !== "rmdOpaque" && (c += 1), null), s);
	if (l === void 0) return;
	let u = l.length;
	return {
		nodeCount: c,
		blockCount: u,
		source: e,
		rows: o,
		overflowAt(t) {
			let n = t + 1;
			if (!Number.isSafeInteger(n) || n < 1 || n > c) return;
			let r = 0, i, o = {};
			try {
				ri(e, a, (e, t, a) => {
					if (e === "rmdOpaque") return null;
					if (r += 1, r === n) throw i = {
						start: t,
						end: a
					}, o;
					return null;
				}, s);
			} catch (e) {
				if (e !== o) throw e;
			}
			return i;
		},
		emit(t) {
			let n = ri(e, a, (e, n, r, i) => t(e, n, r, i), s);
			if (n === void 0) throw Error("Fast Markdown plan became invalid during emission.");
			return n;
		}
	};
}
function ai(e, t, n, r) {
	let i = r?.placeholders ? ei(e, r) : void 0;
	if (r?.placeholders && !i) return;
	let a = r ? "\0" + (r.allowBraces ? "braces" : "") + (r.placeholders ? "opaque" : "") + "\0" + e : e;
	if (t) {
		let e = t.readPlan(a);
		if (e.hit) return e.value !== void 0 && t.notePlanReuse?.(), e.value;
	}
	let o = ii(e, t, n, r, i);
	return t?.writePlan(a, o), o;
}
// src/local/parsing/markdown-blocks.ts
var oi = "rmdFastBlock", si = "[^", ci = /* @__PURE__ */ new Set([
	"BulletList",
	"OrderedList",
	"Blockquote"
]), li = /^([-+*]|\d{1,9}[.)]) /, ui = /[ \t]*(?:\r\n?|\n)(?:[ \t]*(?:\r\n?|\n))*[ \t]{0,3}(?:[-+*]|\d{1,9}[.)])(?:[ \t]|\r|\n|$)/y, di = /^ {0,3}(`|~)/, fi = /* @__PURE__ */ new Set([
	"ATXHeading1",
	"ATXHeading2",
	"ATXHeading3",
	"ATXHeading4",
	"ATXHeading5",
	"ATXHeading6",
	"HorizontalRule"
]);
function pi(e, t, n, r, i, a, o) {
	let s = n?.source === e ? n.logicalLineCount : Ni(e), c = mi(e, r, a, o);
	if (c) return {
		tree: ji(e, [Ai(0, e.length, c)]),
		stats: {
			fastBlocks: c.blockCount,
			generalBlocks: 0,
			fastCharacters: e.length,
			generalCharacters: 0,
			lines: s
		}
	};
	let l = i?.candidates ?? [], u = [], d = 0;
	for (let t = 0; t < l.length; t++) {
		let n = l[t];
		if (n.from < d || !vi(e, n) || !yi(e, n, l[t - 1], u.at(-1))) continue;
		let i = mi(e.slice(n.from, n.to), r, a, o ? {
			...o,
			offset: n.from
		} : void 0);
		i && (u.push({
			from: n.from,
			to: n.to,
			plan: i
		}), d = n.to);
	}
	let f = Si(e, u);
	if (!f.length) return hi(e, t, s);
	let p = t(wi(e, f));
	if (!p || !Array.isArray(p.children) || Ti(p.children, f) || Ei(e, p.children, f) || Di(e, p.children, f)) return hi(e, t, s);
	let m = 0, h = 0;
	for (let e of f) m += e.to - e.from, h += e.plan.blockCount;
	return {
		tree: ji(e, ki(p.children, f)),
		stats: {
			fastBlocks: h,
			generalBlocks: p.children.length,
			fastCharacters: m,
			generalCharacters: e.length - m,
			lines: s
		}
	};
}
function mi(e, t, n, r) {
	if (!e.length || typeof ai != "function") return;
	let i;
	try {
		let a = r?.shield?.(e, r.offset ?? 0);
		if (a !== void 0) {
			let e = ai(a, t, void 0, { allowBraces: !0 });
			if (e) return {
				...e,
				shieldOnly: !0,
				emit() {
					throw Error("Cannot emit an advisory shielding plan");
				}
			};
		}
		i = ai(e, t, n, r);
	} catch {
		return;
	}
	return i && Number.isInteger(i.blockCount) && i.blockCount > 0 && typeof i.emit == "function" && typeof i.overflowAt == "function" ? i : void 0;
}
function hi(e, t, n) {
	let r = t(e);
	return {
		tree: r,
		stats: {
			fastBlocks: 0,
			generalBlocks: r && Array.isArray(r.children) ? r.children.length : 0,
			fastCharacters: 0,
			generalCharacters: e.length,
			lines: n
		}
	};
}
var gi = /* @__PURE__ */ new WeakMap();
function _i(e, t = !0) {
	let n = gi.get(e) ?? {}, r = t ? "all" : "outer";
	if (n[r]) return n[r];
	let i = {
		codeRanges: [],
		definitions: [],
		mathLiterals: []
	}, a = [e];
	for (; a.length;) {
		let e = a.pop(), n = e.position?.start?.offset, r = e.position?.end?.offset;
		e.type === "code" && Number.isInteger(n) && Number.isInteger(r) && i.codeRanges.push({
			start: n,
			end: r
		}), e.type === "footnoteDefinition" && Number.isInteger(n) && Number.isInteger(r) && i.definitions.push({
			start: n,
			end: r
		});
		let o = [
			"image",
			"imageReference",
			"definition"
		].includes(e.type);
		if (o || e.type === "link" || e.type === "linkReference") {
			let t = o ? n : e.children?.at(-1)?.position?.end?.offset ?? n;
			Number.isInteger(t) && Number.isInteger(r) && i.mathLiterals.push({
				start: t,
				end: r
			});
		}
		if (!t && e.type === "footnoteDefinition") continue;
		let s = e.children ?? [];
		for (let e = s.length - 1; e >= 0; e--) a.push(s[e]);
	}
	return n[r] = i, gi.set(e, n), i;
}
function vi(e, t) {
	return Number.isInteger(t.from) && Number.isInteger(t.to) && t.from >= 0 && t.to <= e.length && t.from < t.to && (t.from === 0 || Mi(e.charCodeAt(t.from - 1))) && (t.to === e.length || Mi(e.charCodeAt(t.to)));
}
function yi(e, t, n, r) {
	if (t.from === 0) return !0;
	let i = bi(e, t.from);
	return xi(e, i) ? !0 : !n || n.to !== i || ci.has(n.type) ? !1 : n.type === "LinkReference" ? !(t.type === "Paragraph" && e.startsWith(si, n.from)) : fi.has(n.type) || r?.to === n.to;
}
function bi(e, t) {
	let n = t;
	return e.charCodeAt(n - 1) === 10 && n--, n > 0 && e.charCodeAt(n - 1) === 13 && n--, n;
}
function xi(e, t) {
	for (let n = t; n > 0;) {
		let t = e.charCodeAt(n - 1);
		if (Mi(t)) return !0;
		if (t !== 32 && t !== 9) return !1;
		n--;
	}
	return !0;
}
function Si(e, t) {
	let n = [], r;
	for (let i = t.length - 1; i >= 0; i--) {
		let a = t[i], o = Oi(e, a.to);
		(o === void 0 || Ci(e, o) || r === o) && (n.push(a), r = a.from);
	}
	return n.reverse();
}
function Ci(e, t) {
	for (let n = t; n < e.length; n++) {
		let t = e.charCodeAt(n);
		if (Mi(t)) return !0;
		if (t !== 32 && t !== 9) return !1;
	}
	return !0;
}
function wi(e, t) {
	let n = [], r = 0;
	for (let i of t) n.push(e.slice(r, i.from)), n.push(e.slice(i.from, i.to).replace(/[^\r\n]/g, " ")), r = i.to;
	return n.push(e.slice(r)), n.join("");
}
function Ti(e, t) {
	let n = 0, r = -1;
	for (let i of e) {
		let e = i?.position?.start?.offset, a = i?.position?.end?.offset;
		if (!Number.isInteger(e) || !Number.isInteger(a) || a < e || e < r) return !0;
		for (r = e; n < t.length && t[n].to <= e;) n++;
		let o = t[n];
		if (o && o.from < a && e < o.to) return !0;
	}
	return !1;
}
function Ei(e, t, n) {
	let r = new Set(n.map((e) => e.from)), i = [...t];
	for (; i.length;) {
		let t = i.pop();
		if (t?.type === "footnoteDefinition") {
			let n = t.position?.end?.offset, i = Number.isInteger(n) ? Oi(e, n) : void 0;
			if (i !== void 0 && r.has(i)) return !0;
		}
		let n = t?.children;
		if (Array.isArray(n)) for (let e of n) i.push(e);
	}
	return !1;
}
function Di(e, t, n) {
	let r = [];
	for (let n of t) {
		let t = n.position.start.offset, i = n.position.end.offset, a = n.type === "code" && !di.test(e.slice(t, t + 4));
		if (a && (ui.lastIndex = i, ui.test(e))) return !0;
		let o = a || n.type === "list" && !n.children?.at(-1)?.children?.length;
		r.push({
			from: t,
			to: i,
			list: n.type === "list",
			indentedCode: a,
			open: o,
			fast: !1
		});
	}
	for (let t of n) r.push({
		from: t.from,
		to: t.to,
		list: li.test(e.slice(t.from, t.to)),
		indentedCode: !1,
		open: !1,
		fast: !0
	});
	r.sort((e, t) => e.from - t.from);
	let i = !1;
	for (let t = 1; t < r.length; t++) {
		let n = r[t - 1], a = r[t], o = /^[ \t\r\n]*$/.test(e.slice(n.to, a.from));
		if (o && a.indentedCode && n.fast && i || (i = o && a.fast && (n.fast ? i : n.list), o && ((n.fast || a.fast) && n.list && a.list || n.open && a.fast))) return !0;
	}
	return !1;
}
function Oi(e, t) {
	let n = t;
	for (; n < e.length && (e.charCodeAt(n) === 32 || e.charCodeAt(n) === 9);) n++;
	if (n >= e.length) return;
	let r = e.charCodeAt(n);
	if (r === 10) return n + 1;
	if (r === 13) return n + (e.charCodeAt(n + 1) === 10 ? 2 : 1);
}
function ki(e, t) {
	let n = [], r = 0;
	for (let i of e) {
		let e = i.position.start.offset;
		for (; r < t.length && t[r].to <= e;) n.push(Ai(t[r].from, t[r].to, t[r].plan)), r++;
		n.push(i);
	}
	for (; r < t.length;) n.push(Ai(t[r].from, t[r].to, t[r].plan)), r++;
	return n;
}
function Ai(e, t, n) {
	return {
		type: oi,
		position: {
			start: { offset: e },
			end: { offset: t }
		},
		plan: n
	};
}
function ji(e, t) {
	return {
		type: "root",
		position: {
			start: { offset: 0 },
			end: { offset: e.length }
		},
		children: t
	};
}
function Mi(e) {
	return e === 10 || e === 13;
}
function Ni(e) {
	if (!e.length) return 0;
	let t = 1;
	for (let n = 0; n < e.length; n++) {
		let r = e.charCodeAt(n);
		r === 10 ? t++ : r === 13 && (t++, e.charCodeAt(n + 1) === 10 && n++);
	}
	return t;
}
// src/local/parsing/parser-internals.ts
var Pi = ge, Fi = /* @__PURE__ */ new Set([
	"paragraph",
	"heading",
	"div",
	"details",
	"blockquote",
	"code",
	"list",
	"listItem",
	"thematicBreak",
	"htmlTable"
]), Ii = /* @__PURE__ */ new Set([
	"area",
	"base",
	"br",
	"col",
	"embed",
	"hr",
	"img",
	"input",
	"link",
	"meta",
	"param",
	"source",
	"track",
	"wbr"
]), Li = class extends Error {
	code;
	start;
	end;
	key;
	params;
	actual;
	constructor(e, t, n, r, i = e, a, o) {
		super(t), this.code = e, this.start = n, this.end = r, this.key = i, this.params = a, this.actual = o, this.name = "LocalBudgetError";
	}
};
// src/local/parsing/plain-paragraphs.ts
function Ri(e, t, n) {
	if (/[\u0000-\u0009\u000b\u000c\u000e-\u001f\u007f\ufeff\\`*_{}\[\]<>!~&|$@]/.test(e) || /(?:^|[\r\n])(?:[ #>+=-]|\d{1,9}[.)](?: |[\r\n]|$))/.test(e) || / [\r\n]/.test(e) || e.includes("://") || /www\./i.test(e)) return;
	let r = [], i = -1, a = 0;
	function o() {
		if (i < 0) return;
		let o = a;
		for (; e[o - 1] === " ";) o--;
		let s = [];
		if (t) {
			let t = i;
			for (let r = t; r < o; r++) {
				if (e[r] !== "\r" && e[r] !== "\n") continue;
				r > t && s.push(n("text", t, r, { value: e.slice(t, r) }));
				let i = e[r] === "\r" && e[r + 1] === "\n" ? r + 2 : r + 1;
				s.push(n("break", r, i)), t = i, r = i - 1;
			}
			t < o && s.push(n("text", t, o, { value: e.slice(t, o) }));
		} else s.push(n("text", i, o, { value: e.slice(i, o) }));
		r.push(n("paragraph", i, a, { children: s })), i = -1;
	}
	for (let t = 0; t < e.length;) {
		let n = t;
		for (; n < e.length && e[n] !== "\r" && e[n] !== "\n";) n++;
		n === t ? o() : (i < 0 && (i = t), a = n), t = e[n] === "\r" && e[n + 1] === "\n" ? n + 2 : n + 1;
	}
	return o(), r;
}
// src/local/parsing/author-markdown.ts
var zi = /* @__PURE__ */ new Set([
	"iframe",
	"dl",
	"section",
	"figure",
	"figcaption"
]);
function Bi(e, t, n, r) {
	if (n === "css" || n === "javascript" || A.has(n)) {
		let i = RegExp(`</${n}\\s*>`, "ig");
		i.lastIndex = t;
		let a = i.exec(e);
		return a && i.lastIndex <= r ? {
			start: a.index,
			end: i.lastIndex
		} : null;
	}
	let i = /<(\/?)([a-z][a-z0-9_-]*)(?=[\s/>])/iy, a = 1, o = t;
	for (;;) {
		let t = e.indexOf("<", o);
		if (t < 0 || t >= r) return null;
		if (e.startsWith("<!--", t)) {
			o = M(e, t, r);
			continue;
		}
		i.lastIndex = t;
		let s = i.exec(e);
		if (!s) {
			o = t + 1;
			continue;
		}
		let c = j(e, i.lastIndex, r);
		if (c < 0) return null;
		o = c;
		let l = s[2].toLowerCase();
		if (l === n && s[1] && --a === 0) return {
			start: t,
			end: c
		};
		if (!(s[1] || /\/\s*>$/.test(e.slice(i.lastIndex, c)))) {
			if (l === n) a++;
			else if (A.has(l)) {
				let t = Bi(e, c, l, r);
				if (!t) return null;
				o = t.end;
			}
		}
	}
}
function Vi(e, t, n, r, i) {
	if (!t.length) return;
	let a = /^[\t ]*<(css|javascript|dl|section|figure|figcaption)(?=[\s/>])|<(iframe)(?=[\s/>])/gim;
	a.lastIndex = i;
	let o = 0, s = 0;
	for (let i of e.matchAll(a)) {
		let a = i[1] ?? i[2], c = a.toLowerCase();
		if ((c === "css" || c === "javascript") && a !== c || r.has(c)) continue;
		let l = i.index + i[0].indexOf("<");
		for (; t[o]?.end <= l;) o++;
		for (; n[s]?.end <= l;) s++;
		if (t[o]?.start <= l || n[s]?.start <= l) continue;
		let u = i.index + i[0].length, d = j(e, u, e.length);
		if (d < 0 || /\/\s*>$/.test(e.slice(u, d))) continue;
		let f = Bi(e, d, c, e.length);
		if (f) for (let n = o; t[n]?.start < f.start; n++) {
			let r = t[n];
			if (!(r.start < d || r.end <= f.end)) return {
				source: e.slice(0, d) + e.slice(d, f.start).replace(/[^\r\n]/g, " ") + e.slice(f.start),
				end: f.end
			};
		}
	}
}
// src/local/parsing/lexical.ts
function Hi(e, t, n) {
	let r = "";
	for (let i = t + 2; i < n - 1; i += 1) {
		let t = e[i];
		if (r) t === "\\" ? i += 1 : t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === "}" && e[i + 1] === "}") return i + 2;
	}
	return -1;
}
function Ui(e, t, n, r) {
	for (let i = t; i + 1 < n; i += 1) if (e[i] === "\\") {
		if (e[i + 1] === r) return i + 2;
		i += 1;
	}
	return null;
}
function Wi(e, t, n) {
	for (let r = t; r + 2 < n; r += 1) if (e[r] === "\\") {
		if (e[r + 1] === "\\" && e[r + 2] === "]" && /\s/.test(e[r - 1] ?? "")) return r + 3;
		r += 1;
	}
	return null;
}
function Gi(e, t, n) {
	if (e.startsWith("\\\\[", t)) return Wi(e, t + 3, n) ?? t + 3;
	if (e[t] === "\\" && e[t + 1] === "(") return Ui(e, t + 2, n, ")") ?? t + 2;
	if (e[t] === "\\" && e[t + 1] === "[") return Ui(e, t + 2, n, "]") ?? t + 2;
	if (e[t] !== "$") return null;
	if (e[t + 1] === "$") {
		for (let r = t + 2; r + 1 < n; r += 1) if (e[r] === "\\") r += 1;
		else if (e[r] === "$" && e[r + 1] === "$") return r + 2;
		return t + 2;
	}
	for (let r = t + 1; r < n; r += 1) {
		let n = e[r];
		if (n === "\\") {
			r += 1;
			continue;
		}
		if (n === "\n" || n === "\r") break;
		if (n !== "$") continue;
		let i = e.slice(t + 1, r), a = e[r + 1];
		if (!i.trim() || a !== void 0 && a >= "0" && a <= "9") break;
		return r + 1;
	}
	return t + 1;
}
// src/local/parsing/theme-declaration.ts
function Ki(e, t) {
	let n = e.startsWith("</theme", t), r = !n && e.startsWith("<theme", t);
	if (!n && !r) return !1;
	let i = e[t + (n ? 7 : 6)];
	return i !== void 0 && (i === ">" || i === "/" || /\s/.test(i));
}
function qi(e, t, n) {
	let r = /^<(\/?)theme(?=[\s/>])/.exec(e.slice(t, n));
	if (!r) return null;
	let i = t + r[0].length, a = e.indexOf("\n", i), o = a < 0 ? n : Math.min(n, a), s = "", c = i;
	for (; c < o; c += 1) {
		let t = e[c];
		if (s) t === s && (s = "");
		else if (t === "\"" || t === "'") s = t;
		else if (t === ">") break;
	}
	let l = !!r[1];
	if (c >= o) {
		let n = o;
		return {
			start: t,
			end: n,
			rest: e.slice(i, n),
			closing: l,
			selfClosing: !1,
			unclosed: !0
		};
	}
	let u = e.slice(i, c);
	return {
		start: t,
		end: c + 1,
		rest: u,
		closing: l,
		selfClosing: /\/\s*$/.test(u),
		unclosed: !1
	};
}
function Ji(e, t, n) {
	let r = t;
	for (; r < n;) {
		let t = e[r];
		if (t.charCodeAt(0) === 65279 || t === " " || t === "	" || t === "\r" || t === "\n") r += 1;
		else if (e.startsWith("<!--", r)) {
			let t = e.indexOf("-->", r + 4);
			if (t < 0 || t + 3 > n) return -1;
			r = t + 3;
		} else break;
	}
	return r;
}
function Yi(e, t) {
	if (t.unclosed) return !1;
	let n = t.end;
	for (; n < e.length && (e[n] === " " || e[n] === "	" || e[n] === "\r");) n += 1;
	return n >= e.length || e[n] === "\n";
}
function Xi(e) {
	if (/\{\{|\}\}/.test(e)) return {
		code: "local.theme.expression",
		key: "local.theme.expression",
		message: "Theme names must be static text, not expressions."
	};
	let t = e.replace(/\/\s*$/, ""), n = /^\s*name\s*=\s*(?:"([^"]*)"|'([^']*)')\s*$/.exec(t);
	if (!n) return /\bname\s*=/.test(t) ? {
		code: "local.theme.attribute",
		key: "local.theme.attribute",
		message: "Theme declarations only accept a quoted name attribute."
	} : {
		code: "local.theme.name",
		key: "local.theme.name.missing",
		message: "A theme declaration requires a quoted name attribute."
	};
	let r = n[1] ?? n[2] ?? "";
	return b(r) ? { name: r } : {
		code: "local.theme.name",
		key: "local.theme.name.invalid",
		params: {
			name: r,
			limit: 64
		},
		message: `Theme name "${r}" must use lowercase letters, digits and single hyphens (maximum 64 characters).`
	};
}
// src/local/parsing/parser-region.ts
var Zi = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, Qi = /* @__PURE__ */ new Set([
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"div",
	"details",
	"blockquote",
	"pre",
	"ul",
	"ol",
	"li"
]), $i = 128, ea = /* @__PURE__ */ new Set(["css", "javascript"]), ta = Math.min(5e4, u), na = 100;
function ra(e, t) {
	let n = 0, r = e.length - 1;
	for (; n <= r;) {
		let i = n + r >>> 1, a = e[i];
		if (t < a.start) r = i - 1;
		else if (t >= a.end) n = i + 1;
		else return !0;
	}
	return !1;
}
function ia({ source: e, diagnostics: t, maxSyntaxNodes: n, strict: r, budget: i, known: a, externalNames: o, unmountedLeafNames: s, suggestionNames: c, htmlSupport: l, nativeHtmlNames: u, sourceContext: d, work: f, ensureDepth: p, parseMarkdown: m, node: h, codeRanges: g, recoveryRanges: v, recoveries: y, rootMathLiterals: b, rootDefinitionRanges: x, error: S, warning: C, headers: w, scanner: T, convert: E }) {
	let { tagAt: D, scanTag: O, htmlLiteralEnd: k, beginsLine: j, footnoteLabelAt: N, definitionLabelAt: P, htmlTagAt: ee, htmlCloseEnd: F, selectHtmlAttributes: I, buildHtmlNode: L, protectedEnd: R, unknownTagEnd: te, interpolationEnd: ne, commonIndent: z } = T, B = 0, re = !1, V = !1;
	function ie(e) {
		return V ? !1 : H(w.headerCursor, e) === e || (V = !0, !1);
	}
	function ae(t) {
		let n = d.lineStartAt(t);
		for (let r = n; r < t; r += 1) {
			let t = e.charCodeAt(r);
			if (t !== 65279 && t !== 32 && t !== 9) return !1;
		}
		return !0;
	}
	function oe(t, n, r) {
		let i = RegExp(`</${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\s*>`, "i").exec(e.slice(t, r));
		return i ? {
			start: t + i.index,
			end: t + i.index + i[0].length
		} : null;
	}
	function H(t, n, r = !0) {
		let i = t;
		for (; i < n;) {
			let t = e[i];
			if (t.charCodeAt(0) === 65279 || t === " " || t === "	" || t === "\r" || t === "\n") {
				i += 1;
				continue;
			}
			if (e.startsWith("<!--", i)) {
				let t = e.indexOf("-->", i + 4);
				if (t < 0 || t + 3 > n) return -1;
				i = t + 3;
				continue;
			}
			if (r && Ki(e, i)) {
				let t = qi(e, i, n);
				if (t && !t.closing && !t.unclosed && Yi(e, t)) {
					i = t.end;
					continue;
				}
				return i;
			}
			let o = se(i, n);
			if (o && o.name === "css" && o.close && !a.has("css")) i = o.close.end;
			else break;
		}
		return i;
	}
	function se(t, n) {
		let r = /^<(css|javascript)(?=[\s/>])/.exec(e.slice(t, Math.min(n, t + 16)));
		if (!r) return null;
		let i = r[1], a = O(t, n);
		return !a || a.closing ? null : {
			name: i,
			open: {
				end: a.end,
				self: a.self
			},
			close: a.self ? null : oe(a.end, i, n)
		};
	}
	function ce(T, V, H, U = T, le = T, ue = 0, W = {}) {
		let G = [];
		if (V > T && i.charge(V - T, T, V), f.maxComponentDepth = Math.max(f.maxComponentDepth, ue), ue > na) throw new Li("local.budget", "Component nesting exceeds the 100-level limit.", U, le, "local.budget.nesting", { limit: na }, 101);
		let K = W.footnote === !0, q = W.container ?? H !== void 0, fe = W.indent ?? 0, J = W.definitions ?? x, pe = b, me = [];
		if (H) {
			let e = te(T, H, V, !0)?.start ?? V, t = z(T, e);
			fe = t;
			let n = new _(d);
			n.original(T, e, t), n.finish(e), f.mappingSegments += n.segmentCount;
			let r = n.text(), a;
			!/[\[:@]|www\./i.test(r) && !/^[ \t>*+\-0-9.)]*(?: {4}|\t|`{3}|~{3})/m.test(r) ? (i.charge(r.length + 1, 0, Math.max(1, r.length)), p(r), a = {
				definitions: [],
				mathLiterals: [],
				codeRanges: []
			}) : a = _i(m(r), !1);
			let o = (t) => ({
				start: n.at(t.start, e),
				end: n.at(t.end, e)
			}), s = a.definitions.map(o).filter((e) => e.end > e.start);
			pe = a.mathLiterals.map(o).sort((e, t) => e.start - t.start), me = a.codeRanges.map(o).filter((t) => t.end > t.start && t.start >= T && t.end <= e).sort((e, t) => e.start - t.start), J = s.filter((t) => t.start >= T && t.end <= e).sort((e, t) => e.start - t.start || t.end - e.end);
		} else T > 0 && W.definitions !== void 0 && !K && (pe = _i(m(e.slice(T, V))).mathLiterals.map((e) => ({
			start: e.start + T,
			end: e.end + T
		})).sort((e, t) => e.start - t.start));
		let Y = 0, ge = 0, ve = 0;
		for (; ve < v.length && v[ve].end <= T;) ve += 1;
		for (let f = T; f < V;) {
			for (; ve < v.length && v[ve].end <= f;) ve += 1;
			let p = v[ve];
			if (p && p.start <= f && f < p.end) {
				let t = Math.min(V, p.end);
				G.push({
					start: f,
					end: t,
					block: j(f),
					node: h("fallback", f, t, { value: e.slice(f, t) })
				}), f = t;
				continue;
			}
			if (!q) {
				for (; g[B]?.end <= f;) B++;
				let e = g[B];
				if (e && e.start <= f) {
					f = e.end;
					continue;
				}
			} else if (me.length) {
				for (; me[ge]?.end <= f;) ge++;
				let e = me[ge];
				if (e && e.start <= f) {
					f = e.end;
					continue;
				}
			}
			for (; J[Y]?.end <= f;) Y++;
			let m = J[Y];
			if (m && m.start === f) {
				let t = f, n = P(t);
				for (; !n && t - f < 4 && t < m.end && (e[t] === " " || e[t] === "	");) t += 1, n = P(t);
				if (n && n.bodyStart <= m.end) {
					let r = d.lineStartAt(t), i = e.slice(r, t), a = /^(?:[ \t]{0,3}>[ \t]?)+/.exec(i)?.[0] ?? "", o = /^[ \t]*/.exec(i.slice(a.length))[0].length, s = o + 4, c = ce(n.bodyStart, m.end, void 0, n.bodyStart, n.bodyStart, ue + 1, {
						footnote: !0,
						indent: s,
						container: q || o > 0,
						definitions: [],
						stripBlockquote: a.length > 0
					}), l = E(n.bodyStart, m.end, c.tokens, s, {
						literalHtml: !0,
						stripBlockquote: a.length > 0
					});
					G.push({
						start: m.start,
						end: m.end,
						block: !0,
						node: h("footnoteDefinition", m.start, m.end, {
							identifier: n.identifier,
							label: n.label,
							children: l
						})
					}), f = m.end, Y += 1;
					continue;
				}
				Y += 1;
			}
			let _ = e.startsWith("\\\\[", f) && /\s/.test(e[f + 3] ?? "");
			if (!K && H !== "plot" && e[f] === "\\" && (e[f + 1] === "(" || e[f + 1] === "[" || _) && !ra(pe, f)) {
				let t = _ || e[f + 1] === "[", n = _ ? 3 : 2, r = t ? "]" : ")", i = f + n;
				for (; i < V;) if (e[i] === "\\") {
					if (_ ? e.startsWith("\\\\]", i) && i + 2 < V && /\s/.test(e[i - 1] ?? "") : e[i + 1] === r && i + 1 < V) break;
					i += 2;
				} else i++;
				if (i >= V) {
					S("local.math.unclosed", { key: "local.math.unclosed" }, f, V), f = V;
					continue;
				}
				let a = i + n, o = e.slice(f + n, i);
				o.length > ta && (S("local.budget.math", {
					key: "local.budget.math",
					params: { limit: ta }
				}, f, a), o = o.slice(0, ta)), G.push({
					start: f,
					end: a,
					node: h(t ? "math" : "inlineMath", f, a, { value: o })
				}), f = a;
				continue;
			}
			let b = R(f, V, q);
			if (b !== null) f = b;
			else if (e.startsWith("<!--", f)) {
				let t = M(e, f, V), n = e.slice(f, t);
				if (!K && /^<!--\s*reactive-md(?=[\s:]|-->|$)/i.test(n)) {
					w.versionHeaders += 1;
					let r = d.lineStartAt(f), i = e.indexOf("\n", t), a = /^\s*$/.test(e.slice(r, f)) && /^\s*$/.test(e.slice(t, i < 0 ? e.length : i)), o = /^<!--[ \t]*reactive-md:[ \t]*(local-draft-[1-9][0-9]*)[ \t]*-->$/.exec(n);
					w.versionHeaders > 1 ? S("local.version.duplicate", "Only one source syntax declaration is allowed.", f, t) : !o || /[\r\n]/.test(n) ? S("local.version.malformed", `Use <!-- reactive-md: ${be} --> on one line.`, f, t) : (w.versionDeclaration = {
						version: o[1],
						range: {
							start: f,
							end: t
						}
					}, H !== void 0 || !a || Ji(e, 0, f) !== f ? S("local.version.placement", "The syntax declaration must be on its own line before the theme and document body.", f, t) : o[1] !== "local-draft-3" && S("local.version.unsupported", {
						key: "local.version.unsupported",
						params: {
							declared: o[1],
							supported: be
						}
					}, f, t));
				}
				G.push({
					start: f,
					end: t,
					node: h("comment", f, t)
				}), f = t;
			} else if (!K && e.startsWith("{{", f)) {
				let t = ne(f, V);
				if (t < 0) {
					S("local.interpolation", { key: "local.interpolation.unclosed" }, f, V), f += 2;
					continue;
				}
				G.push({
					start: f,
					end: t,
					node: h("interpolation", f, t, { value: e.slice(f + 2, t - 2).trim() })
				}), f = t;
			} else if (!K && e[f] === "$") {
				let t = e[f + 1] === "$", n = t ? "$$" : "$";
				if (t) {
					let t = f + n.length;
					for (; t < V; t++) if (e[t] === "\\") t++;
					else if (e.startsWith(n, t)) break;
					if (t >= V || !e.startsWith(n, t)) {
						S("local.math.unclosed", { key: "local.math.unclosed" }, f, void 0), f += n.length;
						continue;
					}
					let r = e.slice(f + n.length, t);
					r.length > ta && (S("local.budget.math", {
						key: "local.budget.math",
						params: { limit: ta }
					}, f, t + n.length), r = r.slice(0, ta));
					let i = t + n.length;
					G.push({
						start: f,
						end: i,
						node: h("math", f, i, { value: r })
					}), f = i;
					continue;
				}
				let r = f + 1, i = -1;
				for (; r < V; r++) {
					let t = e[r];
					if (t === "\\") {
						r++;
						continue;
					}
					if (t === "\n" || t === "\r") break;
					if (t !== "$") continue;
					let n = e.slice(f + 1, r), a = e[r + 1];
					if (!n.trim() || /\s$/.test(n) && /^\d[\d.,]*(?:[，、；：。！？]|[.,;:!?]\s|\s+(?:and|or|to|each|per|for)\b)/i.test(n) || a !== void 0 && a >= "0" && a <= "9") break;
					i = r;
					break;
				}
				if (i < 0) {
					f += 1;
					continue;
				}
				let a = e.slice(f + 1, i);
				a.length > ta && (S("local.budget.math", {
					key: "local.budget.math",
					params: { limit: ta }
				}, f, i + 1), a = a.slice(0, ta));
				let o = i + 1;
				G.push({
					start: f,
					end: o,
					node: h("inlineMath", f, o, { value: a })
				}), f = o;
			} else {
				if (e[f] === "[") {
					let t = N(f, V);
					if (t && (e[t.closeEnd] !== ":" || !j(f))) {
						G.push({
							start: f,
							end: t.closeEnd,
							node: h("footnoteReference", f, t.closeEnd, {
								identifier: t.identifier,
								label: t.label
							})
						}), f = t.closeEnd;
						continue;
					}
				}
				if (e[f] === "<") {
					let d = K ? null : se(f, V), p = d !== null && ae(f), m = null;
					if (d) {
						let e = d.close, t = H === void 0 ? null : oe(f, H, V);
						m = e && (!t || e.end <= t.start) ? e : null;
					}
					if (d && !p && !a.has(d.name)) {
						let t = m !== null && !/\r?\n[\t ]*\r?\n/.test(e.slice(d.open.end, m.start)) ? m.end : d.open.end;
						C("local.author.placement", { key: "local.author.placement" }, f, t), G.push({
							start: f,
							end: t,
							block: !1,
							node: h("fallback", f, t, { value: e.slice(f, t) })
						}), f = t;
						continue;
					}
					if (d && p && !a.has(d.name)) {
						let t = H === void 0 && ue === 0, n = t && !re && ie(f), r = m ? m.end : d.open.self ? d.open.end : V, i = d.name === "javascript" ? t : n, a = () => {
							G.push({
								start: f,
								end: r,
								block: !0,
								node: h("fallback", f, r, { value: e.slice(f, r) })
							}), f = r;
						};
						if (d.open.self) {
							C("local.author.placement", { key: "local.author.placement" }, f, d.open.end), a();
							continue;
						}
						if (!m) {
							let t = k(d.open.end, V, H);
							C("local.author.unclosed", {
								key: "local.author.unclosed",
								params: { name: d.name }
							}, f, t), G.push({
								start: f,
								end: t,
								block: !0,
								node: h("fallback", f, t, { value: e.slice(f, t) })
							}), f = t;
							continue;
						}
						if (!i) {
							C(d.name === "css" ? "local.author.css-placement" : "local.author.script-placement", { key: d.name === "css" ? "local.author.css-placement" : "local.author.script-placement" }, f, m.end), a();
							continue;
						}
						d.name === "javascript" && t && (re = !0);
						let o = d.name === "css" ? "authorCss" : "authorJavaScript";
						G.push({
							start: f,
							end: m.end,
							block: !0,
							node: h(o, f, m.end, { value: e.slice(d.open.end, m.start) })
						}), n && (w.headerCursor = m.end), f = m.end;
						continue;
					}
					if (l) {
						let r = t.length, i = !1, o;
						try {
							o = l.readTable(e, f, V, {
								shield: (t, n) => {
									if (e.startsWith("{{", t)) {
										let e = ne(t, n);
										if (e >= 0) return e;
									}
									if (e[t] === "<") {
										let e = O(t, n);
										if (e && !e.closing && !de.has(e.name.toLowerCase()) && !Pi.has(e.name.toLowerCase()) && !a.has(e.name.toLowerCase())) {
											let t = te(e.end, e.name, n, q);
											if (t) return t.end;
										}
									}
									return R(t, n, q);
								},
								budget: (e, t) => {
									if (t > n * 2) throw new Li("local.budget", `Syntax nodes exceed the limit of ${n}.`, e, e + 1, "local.budget.nodes", { limit: n }, t);
								},
								node: h,
								problem: (e, t, n, r, a) => {
									i = !0, C("local.html.fallback", {
										key: `html.table.${e}`,
										params: {
											tag: r ?? "table",
											name: a ?? ""
										}
									}, t, n);
								},
								attributes: (e, t, n) => {
									let r = ee(t, n, !0), a = r && I(e, r);
									if (!a || !a.ok) {
										i = !0;
										let r = a && !a.ok ? a.attr : "";
										return C("local.html.fallback", {
											key: `html.table.${[
												"colspan",
												"rowspan",
												"span",
												"scope",
												"align"
											].includes(r) ? "value" : "attribute"}`,
											params: {
												tag: e,
												name: r
											}
										}, t, n), {};
									}
									return a.attrs;
								},
								content: (e, t) => E(e, t, ce(e, t, void 0, e, e, ue + 1, {
									...W,
									definitions: []
								}).tokens, z(e, t), {
									literalHtml: K,
									stripBlockquote: W.stripBlockquote === !0
								})
							});
						} catch (n) {
							if (n instanceof Li) throw n;
							let a = O(f, V);
							if (!a || a.closing || a.name.toLowerCase() !== "table") throw n;
							let s = te(a.end, a.name, V, q, !0)?.end ?? k(a.end, V, H), c = t.slice(r).filter((e) => e.code.startsWith("local.budget"));
							t.splice(r, t.length - r, ...c), C("local.html.fallback", { key: "local.html.fallback" }, f, s), o = {
								node: h("fallback", f, s, { value: e.slice(f, s) }),
								end: s
							}, i = !1;
						}
						if (o) {
							if (i) {
								let e = t.slice(r).filter((e) => e.code === "local.html.fallback" || e.code.startsWith("local.budget"));
								t.splice(r, t.length - r, ...e);
							}
							G.push({
								start: f,
								end: o.end,
								block: !0,
								node: i ? h("fallback", f, o.end, { value: e.slice(f, o.end) }) : o.node
							}), f = o.end;
							continue;
						}
					}
					let g = ee(f, V);
					if (g) {
						if (g.closing) {
							C("local.html.fallback", { key: "local.html.fallback" }, f, g.end), G.push({
								start: f,
								end: g.end,
								block: !1,
								node: h("fallback", f, g.end, { value: e.slice(f, g.end) })
							}), f = g.end;
							continue;
						}
						let t = I(g.lower, g);
						if (!t.ok) {
							let n = g.self || he.has(g.lower) ? g.end : F(g.end, g.lower, V, q)?.end ?? k(g.end, V, H, g.lower);
							C("local.html.fallback", {
								key: "local.html.fallback.attribute",
								params: { name: t.attr }
							}, f, n), G.push({
								start: f,
								end: n,
								block: !1,
								node: h("fallback", f, n, { value: e.slice(f, n) })
							}), f = n;
							continue;
						}
						let n = t.attrs;
						if (he.has(g.lower)) {
							if (g.lower === "br") G.push({
								start: f,
								end: g.end,
								node: h("break", f, g.end, { attrs: n })
							});
							else if (g.lower === "hr") G.push({
								start: f,
								end: g.end,
								block: !0,
								node: h("thematicBreak", f, g.end, { attrs: n })
							});
							else {
								let e = n.width === void 0 ? void 0 : Number(n.width), t = n.height === void 0 ? void 0 : Number(n.height);
								G.push({
									start: f,
									end: g.end,
									node: h("image", f, g.end, {
										url: n.src,
										alt: n.alt ?? "",
										title: n.title ?? null,
										...e === void 0 ? {} : { width: e },
										...t === void 0 ? {} : { height: t },
										attrs: n
									})
								});
							}
							f = g.end;
							continue;
						}
						let o = F(g.end, g.lower, V, q);
						if (!o) {
							let t = k(g.end, V, H, g.lower);
							if (!r && l) {
								i.charge(t - f, f, t);
								let n = l.recoverFragment(e, f, t, h, new Set(a.keys()));
								if (n) {
									y.push(n.recovery);
									for (let e of n.nodes) G.push({
										start: e.range.start,
										end: e.range.end,
										block: Qi.has(g.lower) || Fi.has(e.type),
										node: e
									});
								} else y.push({
									code: "local.html.literal",
									causeRange: {
										start: f,
										end: g.end
									},
									affectedRange: {
										start: f,
										end: t
									},
									action: "literal-fallback",
									boundary: "fragment"
								}), G.push({
									start: f,
									end: t,
									block: j(f),
									node: h("fallback", f, t, { value: e.slice(f, t) })
								});
								f = t;
								continue;
							}
							C("local.html.fallback", { key: "local.html.fallback" }, f, t), G.push({
								start: f,
								end: t,
								block: j(f),
								node: h("fallback", f, t, { value: e.slice(f, t) })
							}), f = t;
							continue;
						}
						let s = Qi.has(g.lower), c = L(g, o, n, {
							footnote: K,
							container: q,
							indent: fe,
							stripBlockquote: W.stripBlockquote === !0,
							depth: ue
						});
						G.push({
							start: f,
							end: o.end,
							...s ? { block: !0 } : {},
							node: c
						}), f = o.end;
						continue;
					}
					if (K) {
						f += 1;
						continue;
					}
					let _ = Ki(e, f) ? qi(e, f, V) : null;
					if (_) {
						if (H === void 0 && !re && ie(f)) {
							if (w.themeHeaders += 1, w.themeHeaders === 1 && (w.themeRange = {
								start: _.start,
								end: _.end
							}), _.unclosed) C("local.theme.malformed", { key: "local.theme.malformed.unclosed" }, f, _.end);
							else if (_.closing) C("local.theme.malformed", { key: "local.theme.malformed.closing" }, f, _.end);
							else if (!Yi(e, _)) C("local.theme.malformed", { key: "local.theme.malformed.placement" }, f, _.end);
							else if (w.themeHeaders > 1) C("local.theme.duplicate", { key: "local.theme.duplicate.declaration" }, f, _.end);
							else {
								let e = Xi(_.rest);
								e.code ? C(e.code, e.message ?? "Invalid theme declaration.", f, _.end, {
									key: e.key ?? e.code,
									...e.params ? { params: e.params } : {}
								}) : w.theme = e.name;
							}
							w.headerCursor = _.end, G.push({
								start: f,
								end: _.end,
								block: !0,
								node: h("comment", f, _.end)
							}), f = _.end;
							continue;
						}
						let t = H === void 0 ? "local.theme.late" : "local.theme.nested";
						C(t, H === void 0 ? "Theme declarations after document content are ignored." : "Theme declarations inside document content are ignored.", f, _.end, { key: t }), G.push({
							start: f,
							end: _.end,
							block: !1,
							node: h("fallback", f, _.end, { value: e.slice(f, _.end) })
						}), f = _.end;
						continue;
					}
					let v = O(f, V);
					if (v && !K && v.closing && !a.has(v.name.toLowerCase()) && ea.has(v.name.toLowerCase())) {
						C("local.author.placement", { key: "local.author.placement" }, f, v.end), G.push({
							start: f,
							end: v.end,
							block: !1,
							node: h("fallback", f, v.end, { value: e.slice(f, v.end) })
						}), f = v.end;
						continue;
					}
					v && !K && a.has(v.name.toLowerCase()) && ea.has(v.name.toLowerCase()) && !v.closing && C("local.author.component-conflict", {
						key: "local.author.component-conflict",
						params: { name: v.name }
					}, f, v.end);
					let b = v?.name.toLowerCase() ?? "";
					if (!K && v && !v.closing && b && zi.has(b) && !Pi.has(b) && !a.has(b) && !Ii.has(b) && (b === "iframe" || j(f))) {
						let t = v.self ? {
							start: v.end,
							end: v.end
						} : Bi(e, v.end, b, V), n = H === void 0 ? null : oe(f, H, V);
						if (t && (!n || t.end <= n.start)) {
							G.push({
								start: f,
								end: t.end,
								block: j(f),
								node: h("extendedHtmlRaw", f, t.end, { value: e.slice(f, t.end) })
							}), f = t.end;
							continue;
						}
					}
					if (v && !a.has(v.name.toLowerCase()) && u.has(v.name.toLowerCase())) {
						let t = !v.closing && !v.self && !Ii.has(v.name.toLowerCase()) ? te(v.end, v.name, V, q, !0) : null, n = !r && !v.closing && !v.self && A.has(v.name.toLowerCase()) && (!t || v.name.toLowerCase() === "plaintext"), i = v.closing || v.self || Ii.has(v.name.toLowerCase()) ? v.end : n ? V : t?.end ?? k(v.end, V, H, v.name);
						n ? y.push({
							code: "local.html.literal",
							causeRange: {
								start: f,
								end: v.end
							},
							affectedRange: {
								start: f,
								end: i
							},
							action: "literal-fallback",
							boundary: i === e.length ? "eof" : "fragment"
						}) : C("local.html.fallback", { key: "local.html.fallback" }, f, i), G.push({
							start: f,
							end: i,
							block: j(f),
							node: h("fallback", f, i, { value: e.slice(f, i) })
						}), f = i;
						continue;
					}
					if (v && !v.closing && Zi.test(v.name) && v.name.length <= $i && !a.has(v.name)) {
						let t = v.self || s.has(v.name) ? v.end : te(v.end, v.name, V, q)?.end ?? null;
						if (t === null) {
							if (!j(f)) {
								G.push({
									start: f,
									end: v.end,
									block: !1,
									node: h("text", f, v.end, { value: e.slice(f, v.end) })
								}), f = v.end;
								continue;
							}
							S("local.tag.unclosed", {
								key: "local.tag.unclosed.pair",
								params: { name: v.name }
							}, f, v.end), f = v.end;
							continue;
						}
						let n = _e(v.name, c);
						C("local.component.unknown", {
							key: n ? "local.component.unknown.suggestion" : "local.component.unknown",
							params: n ? {
								name: v.name,
								suggestion: n
							} : { name: v.name }
						}, f, t), G.push({
							start: f,
							end: t,
							block: j(f),
							node: h("fallback", f, t, { value: e.slice(f, t) })
						}), f = t;
						continue;
					}
					let x = D(f, V);
					if (x) {
						if (x.unclosed) {
							if (!a.has(x.name.toLowerCase()) && u.has(x.name.toLowerCase())) {
								let t = k(x.head, V, H, x.name);
								!r && A.has(x.name.toLowerCase()) ? y.push({
									code: "local.html.literal",
									causeRange: {
										start: f,
										end: x.head
									},
									affectedRange: {
										start: f,
										end: t
									},
									action: "literal-fallback",
									boundary: t === e.length ? "eof" : "fragment"
								}) : C("local.html.fallback", { key: "local.html.fallback" }, f, t), G.push({
									start: f,
									end: t,
									block: j(f),
									node: h("fallback", f, t, { value: e.slice(f, t) })
								}), f = t;
								continue;
							}
							if (!a.has(x.name.toLowerCase()) && !j(f)) {
								G.push({
									start: f,
									end: x.head,
									block: !1,
									node: h("text", f, x.head, { value: e.slice(f, x.head) })
								}), f = x.head;
								continue;
							}
							S("local.tag.unclosed", {
								key: "local.tag.unclosed.open",
								params: { name: x.name }
							}, f, V), f = V;
							continue;
						}
						if (!Zi.test(x.name) && !a.has(x.name.toLowerCase())) {
							G.push({
								start: f,
								end: x.end,
								block: !1,
								node: h("text", f, x.end, { value: e.slice(f, x.end) })
							}), f = x.end;
							continue;
						}
						if (Zi.test(x.name) || S("local.tag.name", {
							key: "local.tag.name",
							params: { name: x.name }
						}, f, f + 1 + x.name.length), x.closing) {
							if (x.name === H) return {
								tokens: G,
								end: x.end,
								contentEnd: f,
								indent: z(T, f)
							};
							if (o.has(x.name) && a.get(x.name)?.form === "leaf") {
								S("local.host.structure", {
									key: "local.host.structure.leaf",
									params: { component: x.name }
								}, f, x.end), f = x.end;
								continue;
							}
							S("local.tag.mismatch", {
								key: H ? "local.tag.mismatch.parent" : "local.tag.mismatch.root",
								params: H ? {
									name: x.name,
									parent: H
								} : { name: x.name }
							}, f, x.end), f = x.end;
							continue;
						}
						let t = a.get(x.name), n = o.has(x.name), i = n ? t?.form : void 0, s = t === void 0 || t.form !== "leaf", c = t?.form === "inline", l = !s || x.self;
						if (x.self && s && S("local.tag.shape", {
							key: "local.tag.shape",
							params: { name: x.name }
						}, f, x.end), l) {
							G.push({
								start: f,
								end: x.end,
								...n ? { block: j(f) } : {},
								node: h(n ? "hostComponent" : "component", f, x.end, {
									name: x.name,
									attrs: x.attrs,
									children: [],
									...n ? { hostForm: i } : {}
								})
							}), f = x.end;
							continue;
						}
						let d = ce(x.end, V, x.name, f, x.end, ue + 1), p = E(x.end, d.contentEnd, d.tokens, c ? 0 : d.indent), m = h(n ? "hostComponent" : "component", f, d.end, {
							name: x.name,
							attrs: x.attrs,
							children: c && p.length === 1 && p[0].type === "paragraph" ? p[0].children ?? [] : p,
							...n ? { hostForm: i } : {}
						});
						G.push({
							start: f,
							end: d.end,
							...n ? { block: j(f) } : {},
							node: m
						}), f = d.end;
						continue;
					}
				}
				f++;
			}
		}
		return H && S("local.tag.unclosed", {
			key: "local.tag.unclosed.pair",
			params: { name: H }
		}, U, Math.min(e.length, Math.max(le, U + 1))), {
			tokens: G,
			end: V,
			contentEnd: V,
			indent: H ? z(T, V) : 0
		};
	}
	return ce;
}
// src/local/parsing/footnotes.ts
function aa(e) {
	return typeof e == "string" && e.trim() !== "" ? e : void 0;
}
function oa(e) {
	let t = /^\[\^([\s\S]*)\]$/.exec(e.trim());
	return t ? t[1] : e;
}
function sa(e) {
	return e;
}
function ca(e, t) {
	return aa(e.attrs?.[t]);
}
function la(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase().toLowerCase();
}
function ua(e) {
	let t = sa(e), n = aa(e.value);
	return aa(t.identifier) ?? aa(t.label) ?? ca(e, "identifier") ?? ca(e, "label") ?? (n ? oa(n) : "");
}
function da(e) {
	return la(ua(e));
}
function fa(e) {
	let t = sa(e), n = aa(e.value);
	return (aa(t.label) ?? aa(t.identifier) ?? ca(e, "label") ?? ca(e, "identifier") ?? (n ? oa(n) : "")).trim().replace(/\s+/g, " ");
}
function pa(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [], i = /* @__PURE__ */ new Map(), a = [{
		nodes: e.nodes,
		index: 0
	}];
	for (; a.length;) {
		let e = a[a.length - 1];
		if (e.index === e.nodes.length) {
			a.pop();
			continue;
		}
		let t = e.nodes[e.index++];
		if (t.type === "footnoteDefinition") {
			let e = da(t);
			e && !n.has(e) && n.set(e, t), t.children && a.push({
				nodes: t.children,
				index: 0,
				owner: t
			});
		} else if (t.type === "footnoteReference") {
			let n = e.owner;
			if (n) {
				let e = i.get(n);
				e ? e.push(t) : i.set(n, [t]);
			} else r.push(t);
		} else t.children && a.push({
			nodes: t.children,
			index: 0,
			owner: e.owner
		});
	}
	let o = [], s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = (e) => {
		let r = n.get(e);
		if (!r) return null;
		let i = s.get(e);
		if (i) return i;
		let a = {
			identifier: e,
			number: o.length + 1,
			definition: r,
			id: `${t}-fn-${o.length + 1}`,
			references: []
		};
		return o.push(a), s.set(e, a), a;
	}, d = (e) => {
		let n = da(e), r = n ? u(n) : null;
		if (!r) {
			c.set(e, {
				id: "",
				entry: null,
				label: fa(e)
			});
			return;
		}
		let i = (l.get(n) ?? 0) + 1;
		l.set(n, i);
		let a = `${t}-fnref-${r.number}-${i}`;
		r.references.push({
			node: e,
			id: a
		}), c.set(e, {
			id: a,
			entry: r,
			label: fa(e)
		});
	};
	for (let e of r) d(e);
	for (let e = 0; e < o.length; e += 1) {
		let t = o[e];
		for (let e of i.get(t.definition) ?? []) d(e);
	}
	return {
		entries: o,
		siteFor(e) {
			return c.get(e);
		}
	};
}
// src/local/parsing/parser-convert.ts
function ma({ source: e, maxSyntaxNodes: t, budget: n, markdownBreaks: r, isInlineName: i, sourceContext: a, work: o, parseMarkdown: s, readNodeCount: c, fastPlans: l, node: u, reservedMarkers: d, sourceBomOffset: f, rootMarkdown: p, maskedAuthorBody: m, error: h }) {
	let g = 0;
	function v(v, y, b, x = 0, S = {}) {
		y > v && n.charge(y - v, v, y);
		let C = "", w = v, T = !1, E = v === 0 && y === e.length && b.length === 0 && x === 0 && !S.stripBlockquote && !S.literalHtml && !m && !p?.children.some((e) => e.plan?.shieldOnly), D = new _(a), O = (e, t) => E ? e + f : D.at(e, t), k = /* @__PURE__ */ new Map(), A = /* @__PURE__ */ new Set();
		function j(e) {
			A.add(D.length), M("", e, !1);
		}
		function M(e, t, n) {
			n ? (e.trim().length && (T = !0), D.original(t, t + e.length, x, S.stripBlockquote, !0)) : D.generated(e, t);
		}
		let N;
		if (E) C = e.slice(f), N = p, p = void 0;
		else {
			v === 0 && y === e.length && (p = void 0);
			for (let t of b) {
				M(e.slice(w, t.start), w, !0);
				let n;
				do
					n = "" + g++ + "";
				while (d.has(n));
				let r = t.block ?? (t.node.type === "math" || (t.node.type === "component" || t.node.type === "hostComponent") && !i(t.node.name));
				r && M("\n\n", t.start, !1);
				let a = t.node.type === "interpolation";
				a && /[*_]/.test(e[t.start - 1] ?? "") && j(t.start);
				let o = D.length;
				M(`![${n}](rmd-internal:placeholder)`, t.start, !1), k.set(o, {
					marker: n,
					end: D.length,
					node: t.node
				}), a && /[*_]/.test(e[t.end] ?? "") && j(t.end), r && M("\n\n", t.end, !1), w = t.end;
			}
			M(e.slice(w, y), w, !0), D.finish(y), C = D.text(), o.mappingSegments += D.segmentCount;
			let t = new Map([...k].filter(([, e]) => e.node.type === "interpolation"));
			N = s(C, T, {
				allowBraces: !0,
				...t.size ? { placeholders: t } : {}
			});
		}
		function P(e) {
			for (let t of e) t.type === "interpolation" && t.value !== void 0 && (t.value = t.value.replace(/\\\|/g, "|")), t.children && P(t.children);
		}
		function ee(t, n, i) {
			let a = t.value;
			if (typeof a != "string" || !a) return [];
			if (!r || !/[\r\n]/.test(a)) return [u("text", n, i, { value: a })];
			let o = t.position?.start?.offset, s = t.position?.end?.offset;
			if (!Number.isInteger(o) || !Number.isInteger(s) || o < 0 || s <= o || s > C.length) return [u("text", n, i, { value: a })];
			let c = (t, n) => {
				if (n === void 0) return t;
				let r = t;
				for (let t = 0; r < e.length && t < 32; t += 1) {
					let t = e[r];
					if (t !== " " && t !== "	" && t !== ">") break;
					r += 1;
				}
				return r < e.length && e[r] === n ? r : t;
			}, l = [];
			for (let e = o; e < s; e += 1) if (C[e] === "\\" && /[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(C[e + 1] ?? "")) e += 1;
			else {
				if (C[e] === "&") {
					let t = /^&(?:#(?:[xX][\da-fA-F]{1,6}|\d{1,7})|NewLine);/.exec(C.slice(e, Math.min(s, e + 34)))?.[0];
					if (t) {
						let n = t === "&NewLine;" ? 10 : t[2].toLowerCase() === "x" ? Number.parseInt(t.slice(3, -1), 16) : Number.parseInt(t.slice(2, -1), 10);
						(n === 10 || n === 13) && l.push({
							start: e,
							end: e + t.length,
							literal: !0
						}), e += t.length - 1;
						continue;
					}
				}
				if (C[e] === "\r") {
					let t = e + 1 < s && C[e + 1] === "\n" ? e + 2 : e + 1;
					l.push({
						start: e,
						end: t
					}), e = t - 1;
				} else C[e] === "\n" && l.push({
					start: e,
					end: e + 1
				});
			}
			if (!l.length) return [u("text", n, i, { value: a })];
			let d = [], f = 0, p = n, m = 0;
			for (let e = 0; e < a.length; e += 1) {
				let t = a[e];
				if (t !== "\n" && t !== "\r") continue;
				let n = l[m];
				if (n === void 0) break;
				m += 1;
				let r = !n.literal && t === "\r" && a[e + 1] === "\n" ? e + 2 : e + 1;
				if (n.literal) continue;
				let i = O(n.start, p), o = i + (n.end - n.start);
				e > f && d.push(u("text", p, i, { value: a.slice(f, e) })), d.push(u("break", i, o)), f = r, p = c(O(n.end, o), a[r]), e = r - 1;
			}
			return f < a.length && d.push(u("text", p, i, { value: a.slice(f) })), d;
		}
		let F;
		function I(t) {
			return t.indexOf("") < 0 ? t : (F ??= new Map([...k.values()].map((e) => [e.marker, e])), t.replace(/* @__PURE__ */ RegExp("?([0-9]+)?", "g"), (t, n) => {
				let r = F.get(n);
				return r ? e.slice(r.node.range.start, r.node.range.end) : t;
			}));
		}
		function L(e, n) {
			let r = O(e.position?.start?.offset ?? 0, v), a = O(e.position?.end?.offset ?? C.length, y);
			if (e.type === "rmdFastBlock") {
				let n = e.plan, i = e.position.start.offset;
				l.add(n);
				let o = n.overflowAt(t - c());
				if (o) throw new Li("local.budget", `Syntax nodes exceed the limit of ${t}.`, O(i + o.start, r), O(i + o.end, a), "local.budget.nodes", { limit: t }, t + 1);
				let s = n.emit((e, t, n, o) => {
					if (e === "rmdOpaque") {
						let e = k.get(i + t);
						if (!e || e.node.type !== "interpolation" || e.end !== i + n || e.marker !== o?.value) throw Error("Invalid interpolation placeholder");
						return k.delete(i + t), e.node;
					}
					return u(e, O(i + t, r), O(i + n, a), o);
				});
				for (let e of s) e.type === "table" && e.children && P(e.children);
				return s;
			}
			if (e.type === "image") {
				let t = k.get(e.position?.start?.offset);
				if (t && e.position.end.offset === t.end && e.url === "rmd-internal:placeholder" && e.alt === t.marker) return k.delete(e.position.start.offset), t.node.type === "comment" ? [] : [t.node];
			}
			if (e.type === "text") {
				let t = e.position.start.offset, n = e.position.end.offset, i = e.value;
				for (; t < n && A.has(t);) t++, i = i.slice(1);
				for (; n > t && A.has(n - 1);) n--, i = i.slice(0, -1);
				return t !== e.position.start.offset || n !== e.position.end.offset ? (e = {
					...e,
					value: i,
					position: {
						start: { offset: t },
						end: { offset: n }
					}
				}, ee(e, O(t, r), O(n, a))) : ee(e, r, a);
			}
			if (e.type === "footnoteReference" || e.type === "footnoteDefinition") {
				let t = typeof e.label == "string" && e.label ? e.label : String(e.identifier ?? ""), i = la(String(e.identifier ?? t));
				return e.type === "footnoteDefinition" ? [u("footnoteDefinition", r, a, {
					identifier: i,
					label: t,
					children: n ?? []
				})] : [u("footnoteReference", r, a, {
					identifier: i,
					label: t
				})];
			}
			if (e.type === "paragraph" && n?.length === 1 && (n[0].type === "math" || n[0].type === "fallback" || n[0].type === "footnoteDefinition" || n[0].type === "authorCss" || n[0].type === "authorJavaScript" || n[0].type === "extendedHtmlRaw" || Fi.has(n[0].type) || (n[0].type === "component" || n[0].type === "hostComponent") && !i(n[0].name))) return n;
			if (e.type === "paragraph" && !n?.length) return [];
			if (e.type === "html") return S.literalHtml ? typeof e.value == "string" && e.value ? [u("text", r, a, { value: e.value })] : [] : (h("local.html", { key: "local.html" }, r, a), []);
			let o = u(e.type, r, a);
			for (let t of [
				"value",
				"depth",
				"ordered",
				"start",
				"checked",
				"url",
				"title",
				"alt",
				"lang",
				"align"
			]) e[t] !== void 0 && (o[t] = e[t]);
			return typeof o.alt == "string" && (o.alt = I(o.alt)), n && (o.children = n), e.type === "table" && o.children && P(o.children), [o];
		}
		let R = [{
			raw: N,
			index: 0,
			children: []
		}];
		for (; R.length;) {
			let e = R[R.length - 1];
			if (e.raw.children && e.index < e.raw.children.length) {
				let t = e.raw.children[e.index++];
				R.push({
					raw: t,
					index: 0,
					children: t.children ? [] : void 0
				});
				continue;
			}
			if (R.pop(), !R.length) return e.children ?? [];
			let t = L(e.raw, e.children);
			for (let e of t) R[R.length - 1].children.push(e);
		}
		return [];
	}
	return v;
}
// src/local/parsing/html-attributes.ts
function ha(e, t, n) {
	let r = Object.create(null), i = [], a = [], o = 0;
	for (; o < e.length;) {
		for (; o < e.length && /\s/.test(e[o]);) o += 1;
		if (o >= e.length || e[o] === "/") break;
		let s = o, c = /^[A-Za-z_:][A-Za-z0-9_.:-]*/.exec(e.slice(o));
		if (!c) {
			o += 1;
			continue;
		}
		let l = c[0].toLowerCase();
		for (o += c[0].length; o < e.length && /\s/.test(e[o]);) o += 1;
		let u = "true";
		if (e[o] === "=") {
			for (o += 1; o < e.length && /\s/.test(e[o]);) o += 1;
			let r = e[o];
			if (r === "\"" || r === "'") {
				o += 1;
				let i = e.indexOf(r, o);
				if (i < 0) {
					a.push({
						name: l,
						value: "",
						start: t + s,
						end: t + e.length
					});
					break;
				}
				u = n(e.slice(o, i)), o = i + 1;
			} else {
				let t = o;
				for (; o < e.length && !/[\s>]/.test(e[o]);) o += 1;
				u = n(e.slice(t, o));
			}
		}
		let d = {
			name: l,
			value: u,
			start: t + s,
			end: t + o
		};
		Object.hasOwn(r, l) || (r[l] = u), i.push(d);
	}
	return {
		attrs: r,
		entries: i,
		invalid: a
	};
}
// src/local/html/html-details.ts
var ga = /^\s*$/;
function _a(e) {
	return e.type !== "text" || !ga.test(e.value ?? "");
}
function va(e, t) {
	let n = t[0]?.range, r = t[t.length - 1]?.range;
	return n !== void 0 && r !== void 0 && Number.isInteger(n.start) && Number.isInteger(r.end) && n.start >= e.range.start && r.end <= e.range.end && n.start <= r.end ? {
		...e,
		children: t,
		range: {
			start: n.start,
			end: r.end
		}
	} : {
		...e,
		children: t
	};
}
function ya(e) {
	let t = e.children;
	if (!t || t.length === 0) return null;
	let n = t.findIndex((e) => e.type === "summary");
	if (n < 0) return null;
	let r = t.filter((e, t) => t !== n);
	return r.some(_a) ? {
		summary: t[n],
		body: va(e, r)
	} : { summary: t[n] };
}
function ba(e) {
	let t = e.findIndex((e) => e.type === "summary");
	if (t >= 0) return {
		summary: e[t],
		body: e.filter((e, n) => n !== t)
	};
	let n = [], r;
	for (let t of e) {
		if (r === void 0 && t.type === "paragraph") {
			let e = ya(t);
			if (e) {
				r = e.summary, e.body && n.push(e.body);
				continue;
			}
		}
		n.push(t);
	}
	return r === void 0 ? { body: n } : {
		summary: r,
		body: n
	};
}
function xa(e) {
	let { summary: t, body: n } = ba(e);
	return t === void 0 ? n : [t, ...n];
}
// src/local/parsing/parser-tags.ts
function Sa({ source: e, strict: t, known: n, htmlSupport: r, decodeEntities: i, decodeAttribute: a, sourceContext: o, node: s, codeEndAt: c, error: l, region: u, convert: d }) {
	function f(e) {
		return e.replace(/&(quot|apos|amp|lt|gt);/g, (e, t) => ({
			quot: "\"",
			apos: "'",
			amp: "&",
			lt: "<",
			gt: ">"
		})[t]);
	}
	function p(e, t) {
		let n = Object.create(null), r = 0;
		for (; r < e.length;) {
			for (; r < e.length && /\s/.test(e[r]);) r++;
			if (r >= e.length || e[r] === "/") break;
			let i = r, a = /^[A-Za-z][A-Za-z0-9_-]*/.exec(e.slice(r));
			if (!a) {
				for (l("local.attribute", { key: "local.attribute.format" }, t + r, void 0); r < e.length && !/\s/.test(e[r]);) r++;
				continue;
			}
			let o = a[0];
			for (r += o.length, o.length > wa ? l("local.budget.name", {
				key: "local.budget.name.attribute",
				params: { limit: wa }
			}, t + i, t + r) : Ca.test(o) || l("local.attribute.name", {
				key: "local.attribute.name",
				params: { name: o }
			}, t + i, t + r); r < e.length && /\s/.test(e[r]);) r++;
			let s = "true";
			if (e[r] === "=") {
				for (r++; r < e.length && /\s/.test(e[r]);) r++;
				let n = e[r++];
				if (n !== "\"" && n !== "'") {
					l("local.attribute", {
						key: "local.attribute.value-quoted",
						params: { name: o }
					}, t + Math.max(0, r - 1), void 0);
					break;
				}
				let i = e.indexOf(n, r);
				if (i < 0) {
					l("local.attribute", {
						key: "local.attribute.closing-quote",
						params: { name: o }
					}, t + Math.max(0, r - 1), void 0);
					break;
				}
				s = f(e.slice(r, i)), r = i + 1;
			}
			if (Object.hasOwn(n, o) ? l("local.attribute.duplicate", {
				key: "local.attribute.duplicate",
				params: { name: o }
			}, t + i, t + r) : n[o] = s, r < e.length && !/\s|\//.test(e[r])) {
				l("local.attribute", { key: "local.attribute.separator" }, t + r, void 0);
				break;
			}
		}
		return n;
	}
	function m(t, r) {
		let i = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, r));
		if (!i) return null;
		let a = t + i[0].length, o = r, s = e[a];
		if ((s === " " || s === "	" || s === "\n" || s === "\r") && !n.has(i[2].toLowerCase()) && !_(t)) {
			let t = e.indexOf("\n", a);
			t >= 0 && (o = Math.min(r, t));
		}
		let c = j(e, a, o), u = i[2];
		if (c < 0) return {
			name: u,
			closing: !!i[1],
			self: !1,
			start: t,
			end: o,
			attrs: {},
			head: a,
			unclosed: !0
		};
		let d = c - 1;
		u.length > wa && l("local.budget.name", {
			key: "local.budget.name.tag",
			params: { limit: wa }
		}, t, t + 1 + u.length);
		let f = e.slice(a, d);
		return i[1] ? (f.trim() && l("local.tag.closing", {
			key: "local.tag.closing",
			params: { name: u }
		}, t, c), {
			name: u,
			closing: !0,
			self: !1,
			start: t,
			end: c,
			attrs: {},
			head: a,
			unclosed: !1
		}) : {
			name: u,
			closing: !1,
			self: /\/\s*$/.test(f),
			start: t,
			end: c,
			attrs: n.has(u.toLowerCase()) ? p(f, a) : {},
			head: a,
			unclosed: !1
		};
	}
	function h(t, r) {
		let i = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, r));
		if (!i) return null;
		let a = t + i[0].length, o = r, s = e[a];
		if ((s === " " || s === "	" || s === "\n" || s === "\r") && !n.has(i[2].toLowerCase()) && !_(t)) {
			let t = e.indexOf("\n", a);
			t >= 0 && (o = Math.min(r, t));
		}
		let c = j(e, a, o);
		if (c < 0) return null;
		let l = e.slice(a, c - 1);
		return {
			name: i[2],
			closing: !!i[1],
			self: !i[1] && /\/\s*$/.test(l),
			end: c
		};
	}
	function g(n, r, i, a) {
		if (!t && a && A.has(a.toLowerCase())) return r;
		let o = /\r?\n[\t ]*\r?\n/.exec(e.slice(n, r)), s = o ? n + o.index : r;
		if (i) {
			let t = RegExp(`</${i}\\s*>`, "g");
			t.lastIndex = n;
			let r = t.exec(e);
			r && r.index < s && (s = r.index);
		}
		return s;
	}
	function _(t) {
		let n = o.lineStartAt(t);
		return /^[ \t]*$/.test(e.slice(n, t));
	}
	function v(t, n) {
		if (e[t] !== "[" || e[t + 1] !== "^") return null;
		let r = t + 2, i = Math.min(n, t + 2 + Ta);
		for (; r < i; r++) {
			let t = e[r];
			if (t === "\\" && /[!-/:-@\[\]\\^_`{|}~]/.test(e[r + 1] ?? "")) r += 1;
			else {
				if (t === "]") break;
				if (t === "[" || t === "\n" || t === "\r") return null;
			}
		}
		if (r >= i || e[r] !== "]") return null;
		let a = e.slice(t + 2, r);
		if (!a.trim()) return null;
		let o = la(a);
		return o ? {
			label: a,
			identifier: o,
			openEnd: t + 2,
			closeEnd: r + 1
		} : null;
	}
	function y(t) {
		let n = v(t, e.length);
		return !n || e[n.closeEnd] !== ":" ? null : {
			label: n.label,
			identifier: n.identifier,
			bodyStart: n.closeEnd + 1
		};
	}
	function b(t, n, i = !1) {
		if (r === void 0) return null;
		let o = /^<(\/?)([A-Za-z][A-Za-z0-9]*)(?=[\s/>])/.exec(e.slice(t, Math.min(n, t + 64)));
		if (!o) return null;
		let s = o[2].toLowerCase();
		if (!Pi.has(s) && !(i && de.has(s))) return null;
		let c = t + o[0].length, l = j(e, c, n);
		if (l < 0) return null;
		let u = l - 1, d = e.slice(c, u), f = !!o[1], p = f ? {
			attrs: Object.create(null),
			entries: [],
			invalid: []
		} : ha(d, c, a);
		return {
			lower: s,
			closing: f,
			self: !f && /\/\s*$/.test(d),
			rest: d,
			attrs: p.attrs,
			entries: p.entries,
			invalid: p.invalid,
			start: t,
			head: c,
			end: u + 1
		};
	}
	function x(t, n, r, i) {
		let a = 1;
		for (let o = t; o < r;) {
			if (!i) {
				let e = c(o);
				if (e !== null && e > o) {
					o = Math.min(e, r);
					continue;
				}
			}
			let t = O(o, r, i);
			if (t !== null) o = t;
			else if (e.startsWith("<!--", o)) o = M(e, o, r);
			else {
				if (e[o] === "<") {
					let e = b(o, r);
					if (e) {
						if (e.lower === n) {
							if (e.closing) {
								if (--a, a === 0) return {
									start: o,
									end: e.end
								};
							} else !e.self && !he.has(n) && (a += 1);
						} else if (!e.closing && (e.lower === "pre" || e.lower === "code") && !he.has(e.lower)) {
							let t = x(e.end, e.lower, r, i);
							if (t) {
								o = t.end;
								continue;
							}
						}
						o = e.end;
						continue;
					}
				}
				o++;
			}
		}
		return null;
	}
	function S(e, t) {
		if (!t) return {
			ok: !1,
			attr: ""
		};
		let n = Object.create(null);
		if (t.invalid.length) return {
			ok: !1,
			attr: t.invalid[0].name
		};
		for (let r of t.entries) {
			let t = r.name;
			if (!te(e, t)) return {
				ok: !1,
				attr: t
			};
			let i = !Object.hasOwn(n, t);
			if (t === "align" && ve.has(e)) {
				let a = V(e, r.value);
				if (!a) return {
					ok: !1,
					attr: t
				};
				i && (n.align = a);
			} else {
				if (!G(t, r.value)) return {
					ok: !1,
					attr: t
				};
				i && (n[t] = r.value);
			}
		}
		return e === "details" && Object.hasOwn(n, "open") && (n.open = "true"), {
			ok: !0,
			attrs: n
		};
	}
	function C(e) {
		return e.length === 1 && e[0].type === "paragraph" ? e[0].children ?? [] : e;
	}
	function w(e) {
		return e.flatMap((e) => e.type === "paragraph" ? e.children ?? [] : [e]);
	}
	function T(t, n, r, a) {
		let o = t.start, c = n.end, l = () => {
			let e = u(t.end, n.start, void 0, o, t.end, a.depth + 1, {
				footnote: a.footnote,
				indent: a.indent,
				container: a.container,
				definitions: [],
				stripBlockquote: a.stripBlockquote
			});
			return d(t.end, n.start, e.tokens, a.indent, {
				literalHtml: a.footnote,
				stripBlockquote: a.stripBlockquote
			});
		}, f = () => C(l()), p = (e) => {
			let t = [];
			for (let n of e) if (n.type === "list") for (let e of n.children ?? []) e.type === "listItem" && t.push(e);
			else n.type === "listItem" ? t.push(n) : n.type === "comment" || n.type === "text" && !(n.value ?? "").trim() || t.push(s("listItem", n.range.start, n.range.end, { children: n.type === "paragraph" ? n.children ?? [] : [n] }));
			return t;
		};
		switch (t.lower) {
			case "code": return s("inlineCode", o, c, { value: i(e.slice(t.end, n.start)) });
			case "pre": {
				let a = e.slice(t.end, n.start), l = /^<code(?:\s[^>]*)?>([\s\S]*)<\/code>$/.exec(a);
				return s("code", o, c, {
					value: i(l ? l[1] : a),
					attrs: r
				});
			}
			case "summary": return s("summary", o, c, {
				attrs: r,
				children: f()
			});
			case "details": return s("details", o, c, {
				attrs: r,
				children: xa(l())
			});
			case "p": return s("paragraph", o, c, {
				attrs: r,
				children: w(l())
			});
			case "h1":
			case "h2":
			case "h3":
			case "h4":
			case "h5":
			case "h6": return s("heading", o, c, {
				depth: Number(t.lower.slice(1)),
				attrs: r,
				children: w(l())
			});
			case "div": return s("div", o, c, {
				attrs: r,
				children: l()
			});
			case "blockquote": return s("blockquote", o, c, {
				attrs: r,
				children: l()
			});
			case "ul":
			case "ol": {
				let e = t.lower === "ol", n = r.start, i = e && n !== void 0 ? Number(n) : void 0;
				return s("list", o, c, {
					ordered: e,
					...e && i !== void 0 && Number.isFinite(i) ? { start: i } : {},
					attrs: r,
					children: p(l())
				});
			}
			case "li": {
				let e = l();
				return s("listItem", o, c, {
					attrs: r,
					children: e.length === 1 && e[0].type === "paragraph" ? e[0].children ?? [] : e
				});
			}
			case "a": return r.href === void 0 ? s("span", o, c, {
				attrs: r,
				children: f()
			}) : s("link", o, c, {
				url: r.href,
				title: r.title ?? null,
				attrs: r,
				children: f()
			});
			case "span": return s("span", o, c, {
				attrs: r,
				children: f()
			});
			default: return s(re[t.lower] ?? t.lower, o, c, {
				attrs: r,
				children: f()
			});
		}
	}
	let E = /^ {0,3}$/, D = /^[ \t]*$/;
	function O(t, n, r) {
		let i = e[t];
		if (i === "\\") return Math.min(n, t + 2);
		if (i !== "`" && i !== "~") return null;
		let a = o.lineStartAt(t);
		if ((r ? D : E).test(e.slice(a, t))) {
			let i = /^(?:(`{3,})[^`\n]*|(~{3,})[^\n]*)(?:\n|$)/.exec(e.slice(t, n));
			if (i) {
				let a = i[1] ?? i[2], o = RegExp(`^${r ? "[ \\t]*" : " {0,3}"}${a[0]}{${a.length},}[ \\t]*\\r?$`, "gm");
				o.lastIndex = t + i[0].length;
				let s = o.exec(e);
				return s && s.index < n ? Math.min(n, s.index + s[0].length) : n;
			}
		}
		if (i === "`") {
			let r = /^`+/.exec(e.slice(t, n))[0], i = e.indexOf(r, t + r.length);
			for (; i >= 0 && i < n;) {
				if (e[i - 1] !== "`" && e[i + r.length] !== "`") return i + r.length;
				i = e.indexOf(r, i + r.length);
			}
			return t + r.length;
		}
		return null;
	}
	function k(t, n, r, i, a = !1) {
		let o = 1;
		for (let s = t; s < r;) {
			if (!i) {
				let e = c(s);
				if (e !== null && e > s) {
					s = Math.min(e, r);
					continue;
				}
			}
			let t = O(s, r, i);
			if (t !== null) s = t;
			else if (e.startsWith("<!--", s)) s = M(e, s, r);
			else {
				if (e[s] === "<") {
					let e = h(s, r);
					if (e) {
						if (e.name === n || a && e.name.toLowerCase() === n.toLowerCase()) {
							if (e.closing) {
								if (--o, o === 0) return {
									start: s,
									end: e.end
								};
							} else e.self || (o += 1);
						}
						s = e.end;
						continue;
					}
				}
				s++;
			}
		}
		return null;
	}
	function N(t, n) {
		return Hi(e, t, n);
	}
	function P(t, n) {
		let r = Infinity, i = "", a = 0, s = t;
		for (; s < n;) {
			let t = e.indexOf("\n", s), c = t < 0 || t > n ? n : t, l = e.slice(s, c);
			if (o.lineStartAt(s) === s) {
				if (i) RegExp(`^[ \\t]*${i}{${a},}[ \\t]*\\r?$`).test(l) && (i = "");
				else {
					let e = /^([ \t]*)(`{3,}(?=[^`]*$)|~{3,})/.exec(l);
					e ? (r = Math.min(r, e[1].length), i = e[2][0], a = e[2].length) : l.trim() !== "" && (r = Math.min(r, /^[ \t]*/.exec(l)[0].length));
				}
			}
			if (c >= n) break;
			s = c + 1;
		}
		return Number.isFinite(r) ? r : 0;
	}
	return {
		tagAt: m,
		scanTag: h,
		htmlLiteralEnd: g,
		beginsLine: _,
		footnoteLabelAt: v,
		definitionLabelAt: y,
		htmlTagAt: b,
		htmlCloseEnd: x,
		selectHtmlAttributes: S,
		buildHtmlNode: T,
		protectedEnd: O,
		unknownTagEnd: k,
		interpolationEnd: N,
		commonIndent: P
	};
}
var Ca = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, wa = 128, Ta = 1e3, Ea = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, Da = 128, Oa = "local.recovery.unclosed", ka = "local.recovery.mismatch", Aa = "local.recovery.stray-close";
function ja(e, t) {
	let n = e.lines, r = 0, i = n.length - 1;
	for (; r < i;) {
		let e = r + i + 1 >>> 1;
		n[e].from <= t ? r = e : i = e - 1;
	}
	return r;
}
function Ma(e, t) {
	let n = Hi(e, t, e.length);
	return n < 0 ? t + 2 : n;
}
function Na(e, t) {
	let n = e.slice(t.from, t.to), r = 0;
	for (;;) {
		let e = r;
		for (let t = 0; t < 3 && n[e] === " "; t += 1) e += 1;
		if (n[e] !== ">") break;
		e += 1, n[e] === " " && (e += 1), r = e;
	}
	let i = r;
	for (; n[i] === " " || n[i] === "	";) i += 1;
	if (i - r > 3 && t.depth === 0) return !1;
	let a = /^(?:[-+*]|\d{1,9}[.)])[ \t]+/.exec(n.slice(i));
	return a && (i += a[0].length), /^#{1,6}(?:[ \t]+|$)/.test(n.slice(i));
}
function Pa(e) {
	return e !== void 0 && (e.blank || /^[ \t]*(?:>[ \t]*)*$/.test(e.text));
}
function Fa(e, t, n) {
	for (let r = e.length - 1; r >= 0; --r) if (n(), t(e[r])) return r;
	return -1;
}
function Ia(e, t) {
	let n = [], r = [];
	t.charge(e.length, 0, Math.max(1, e.length));
	let i = (e, t, r, i) => {
		r.end <= r.start || n.push({
			code: e,
			causeRange: {
				start: t.start,
				end: t.end
			},
			affectedRange: {
				start: r.start,
				end: r.end
			},
			action: "literal-fallback",
			boundary: i
		});
	}, a = (e, n) => n === "theme" ? "theme" : t.isKnown(e) ? "rmd" : t.isHtmlName(n) ? "html" : Ea.test(e) ? "rmd" : "ignore", o = (e, t) => {
		let n = r[e + 1];
		if (!n) return;
		let a = r.slice(e + 1).filter((e) => e.kind === "rmd" && e.structural);
		if (!a.length) return;
		let o = n.start;
		for (let e of a) i(ka, {
			start: e.start,
			end: e.end
		}, {
			start: o,
			end: t
		}, "container-end");
	}, s = 0, c = 0;
	for (; c < e.length;) {
		for (; s < t.definitions.length && t.definitions[s].end <= c;) s += 1;
		let l = t.definitions[s];
		if (l && l.start <= c) {
			c = l.end;
			continue;
		}
		let u = r.length > 0;
		if (!u) {
			let n = t.codeEndAt(c);
			if (n !== null && n > c) {
				c = Math.min(n, e.length);
				continue;
			}
		}
		let d = Gi(e, c, e.length);
		if (d !== null) {
			c = d;
			continue;
		}
		let f = t.protectedEnd(c, u);
		if (f !== null && f > c) {
			c = Math.min(f, e.length);
			continue;
		}
		if (e.startsWith("<!--", c)) {
			c = M(e, c, e.length);
			continue;
		}
		if (e.startsWith("{{", c)) {
			c = Ma(e, c);
			continue;
		}
		if (e[c] !== "<") {
			c += 1;
			continue;
		}
		let p = t.readTag(c);
		if (!p) {
			c += 1;
			continue;
		}
		let m = p.name.toLowerCase(), h = a(p.name, m), g = Math.max(p.end, c + 1);
		if (h === "rmd" && !t.isKnown(p.name) && (m === "css" || m === "javascript")) {
			if (p.closing || !p.complete) {
				c = g;
				continue;
			}
			let n = t.rawHtmlEnd(m, p.end, u);
			if (!t.beginsLine(c)) {
				c = n !== null && !/\r?\n[\t ]*\r?\n/.test(e.slice(p.end, n)) && n !== null ? Math.max(n, g) : g;
				continue;
			}
			if (n !== null) {
				c = Math.max(n, g);
				continue;
			}
			let i = /\r?\n[\t ]*\r?\n/.exec(e.slice(p.end)), a = i ? p.end + i.index : e.length, o = r[r.length - 1]?.name;
			if (o) {
				let t = RegExp(`</${o}\\s*>`, "gi");
				t.lastIndex = p.end;
				let n = t.exec(e);
				n && n.index < a && (a = n.index);
			}
			c = Math.max(a, p.end);
			continue;
		}
		if (h === "theme" || h === "ignore" || p.name.length > Da) {
			c = g;
			continue;
		}
		if (!p.complete) {
			if (h === "html" || p.closing && !t.isKnown(p.name) && !t.beginsLine(c) || !p.closing && !t.isKnown(p.name) && !t.beginsLine(c)) {
				c = g;
				continue;
			}
			let n = null;
			for (let i = e.indexOf("<", g); i >= 0; i = e.indexOf("<", i + 1)) {
				if (t.facts.lines[ja(t.facts, i)]?.fenced || t.codeEndAt(i) !== null) continue;
				if (e.startsWith("<!--", i)) {
					let t = e.indexOf("-->", i + 4);
					if (t < 0) break;
					i = t + 2;
					continue;
				}
				let a = /^<\/([a-z][a-z0-9-]*)\s*>/.exec(e.slice(i, i + 256));
				if (a && Fa(r, (e) => e.name === a[1], () => t.charge(1, i, i + a[0].length)) >= 0) {
					n = i;
					break;
				}
			}
			let a = n ?? La(e, c, c, t);
			if (i(Oa, {
				start: c,
				end: g
			}, {
				start: c,
				end: a ?? e.length
			}, n === null ? a === null ? "eof" : "fragment" : "container-end"), n !== null) {
				c = n;
				continue;
			}
			break;
		}
		if (h === "html") {
			if (p.closing) {
				let e = Fa(r, (e) => e.kind === "html" && e.lower === m, () => t.charge(1, c, g));
				e >= 0 && (o(e, c), r.length = e), c = g;
				continue;
			}
			if (p.self || t.isVoidHtml(m)) {
				c = g;
				continue;
			}
			if (A.has(m)) {
				let n = t.rawHtmlEnd(m, p.end, u);
				c = n === null ? e.length : Math.max(n, g);
				continue;
			}
			r.push({
				name: p.name,
				lower: m,
				start: c,
				end: p.end,
				kind: "html",
				known: !1,
				structural: !1,
				complete: !0,
				pendingMark: n.length
			}), c = g;
			continue;
		}
		if (p.closing) {
			let e = Fa(r, (e) => e.kind === "rmd" && e.name === p.name, () => t.charge(1, c, g));
			if (e < 0) {
				if (!t.isPaired(p.name)) {
					c = g;
					continue;
				}
				i(Aa, {
					start: c,
					end: p.end
				}, {
					start: c,
					end: p.end
				}, "token");
			} else {
				let t = r[e];
				t.known ? o(e, c) : n.length = t.pendingMark, r.length = e;
			}
			c = g;
			continue;
		}
		if (p.self || !t.isPaired(p.name)) {
			c = g;
			continue;
		}
		let _ = t.isKnown(p.name);
		r.push({
			name: p.name,
			lower: m,
			start: c,
			end: p.end,
			kind: "rmd",
			known: _,
			structural: _ || t.beginsLine(c),
			complete: !0,
			pendingMark: n.length
		}), c = g;
	}
	let l = -1;
	for (let n of r) {
		if (n.kind !== "rmd" || !n.structural || n.start < l) continue;
		let r = e.length, a = "eof";
		if (n.complete) {
			let i = Ra(e, n.end, n.start, t);
			i !== null && (r = i, a = "heading");
		}
		if (a === "eof") {
			let i = La(e, n.end, n.start, t);
			i !== null && (r = i, a = "fragment");
		}
		i(Oa, {
			start: n.start,
			end: n.end
		}, {
			start: n.start,
			end: r
		}, a), l = r;
	}
	return za(n);
}
function La(e, t, n, r) {
	let { facts: i } = r, a = i.lines[ja(i, n)];
	if (!a || a.quoteDepth === 0 && a.depth === 0) return null;
	let o = ja(i, Math.min(t, e.length)) + 1;
	for (; o < i.lines.length; o += 1) {
		let e = i.lines[o];
		if (!(!e || e.blank || e.fenced) && (e.quoteDepth < a.quoteDepth || e.depth < a.depth)) return e.from;
	}
	return null;
}
function Ra(e, t, n, r) {
	let { facts: i } = r, a = i.lines;
	if (!a.length) return null;
	let o = a[ja(i, n)], s = ja(i, Math.min(t, e.length)) + 1;
	if (s >= a.length) return null;
	r.charge(Math.max(1, e.length - t), Math.max(0, t), e.length);
	let c = 0, l = a[s].from;
	for (; l < e.length;) {
		for (; c < r.definitions.length && r.definitions[c].end <= l;) c += 1;
		let t = r.definitions[c];
		if (t && t.start <= l) {
			l = t.end;
			continue;
		}
		s = ja(i, l);
		let n = a[s];
		if (n && l === n.from) {
			let t = s > 0 ? a[s - 1] : void 0;
			if (n.quoteDepth === o.quoteDepth && n.depth === o.depth && !n.fenced && Pa(t) && Na(e, n)) return n.from;
		}
		let u = n !== void 0 && n.depth > 0, d = r.codeEndAt(l);
		if (d !== null && d > l) {
			l = Math.min(d, e.length);
			continue;
		}
		let f = Gi(e, l, e.length);
		if (f !== null) {
			l = f;
			continue;
		}
		let p = r.protectedEnd(l, u);
		if (p !== null && p > l) l = Math.min(p, e.length);
		else if (e.startsWith("<!--", l)) l = M(e, l, e.length);
		else if (e.startsWith("{{", l)) l = Ma(e, l);
		else if (e[l] === "<") {
			let e = r.readTag(l);
			if (!e) {
				l += 1;
				continue;
			}
			if (!e.complete) return null;
			let t = e.name.toLowerCase();
			if (!e.closing && A.has(t) && r.isHtmlName(t) && !e.self) {
				let n = r.rawHtmlEnd(t, e.end, u);
				if (n === null) return null;
				l = Math.max(n, l + 1);
				continue;
			}
			l = Math.max(e.end, l + 1);
		} else l += 1;
	}
	return null;
}
function za(e) {
	let t = e.map((e, t) => ({
		record: e,
		index: t
	})).sort((e, t) => e.record.affectedRange.start - t.record.affectedRange.start || e.record.affectedRange.end - t.record.affectedRange.end || e.record.causeRange.start - t.record.causeRange.start || e.index - t.index), n = [];
	for (let { record: e } of t) {
		let t = n[n.length - 1];
		t && e.affectedRange.start < t.affectedRange.end ? e.affectedRange.end > t.affectedRange.end && (t.affectedRange = {
			start: t.affectedRange.start,
			end: e.affectedRange.end
		}) : n.push({
			code: e.code,
			causeRange: {
				start: e.causeRange.start,
				end: e.causeRange.end
			},
			affectedRange: {
				start: e.affectedRange.start,
				end: e.affectedRange.end
			},
			action: e.action,
			boundary: e.boundary
		});
	}
	let r = n.map(({ affectedRange: e }) => e), i = /* @__PURE__ */ new Map();
	for (let e of r) i.set(e.start, e.end);
	return {
		recoveries: n,
		ranges: r,
		byStart: i
	};
}
// src/local/parsing/parser-core.ts
var Ba = /* @__PURE__ */ new Set([
	"local.recovery.unclosed",
	"local.recovery.mismatch",
	"local.recovery.stray-close",
	"local.html.repair",
	"local.html.literal"
]);
function Va() {
	let e = globalThis.performance;
	return e && typeof e.now == "function" ? e.now() : Date.now();
}
function Ha(e) {
	return Math.round(e * 1e3) / 1e3;
}
var Ua = /(?:^|[\r\n])(?:[ \t]{0,3}>|[ \t]*(?:[-+*]|\d{1,9}[.)])(?=[ \t]|[\r\n]|$))/;
function Wa(e) {
	return Ua.test(e) || e.charCodeAt(0) === 65279 && Ua.test(e.slice(1));
}
var Ga = mt().use(Yr), Ka = /* @__PURE__ */ new WeakMap();
function qa(e) {
	let t = e?.markdownPlugins;
	if (!t?.length) return Ga;
	let n = Ka.get(e);
	if (n === void 0) {
		n = mt().use(Yr);
		for (let e of t) n.use(e);
		Ka.set(e, n);
	}
	return n;
}
function Ja(e, t) {
	if (!e || e.length === 0) return [];
	let n = [];
	for (let r of e) {
		if (!Number.isFinite(r.start) || !Number.isFinite(r.end)) continue;
		let e = Math.max(0, Math.min(t, r.start)), i = Math.max(0, Math.min(t, r.end));
		i > e && n.push({
			start: e,
			end: i
		});
	}
	n.sort((e, t) => e.start - t.start || e.end - t.end);
	let r = [];
	for (let e of n) {
		let t = r[r.length - 1];
		t && e.start <= t.end ? e.end > t.end && (t.end = e.end) : r.push({ ...e });
	}
	return r;
}
function Ya(e, t, n, r, i, a) {
	let s = [];
	if (typeof e != "string" || e.length > 1e6) {
		let t = typeof e == "string" ? v("local.budget.document", { limit: o }) : v("local.parse.source");
		return {
			nodes: [],
			diagnostics: [{
				code: typeof e == "string" ? "local.budget" : "local.parse",
				message: typeof e == "string" ? `Document exceeds the ${o}-character limit.` : "Document source must be a string.",
				severity: "error",
				range: {
					start: 0,
					end: typeof e == "string" && e.length ? 1 : 0
				},
				line: 1,
				column: 1,
				messageKey: t.key,
				...t.params ? { params: t.params } : {},
				phase: typeof e == "string" ? "resource" : "source",
				recoverable: !1,
				...typeof e == "string" ? { details: {
					budget: "maxDocumentLength",
					limit: o,
					actual: e.length,
					unit: "codeUnits"
				} } : {}
			}]
		};
	}
	if (!t.ok) return {
		nodes: [],
		diagnostics: [{
			code: "local.options.invalid",
			message: t.message,
			severity: "error",
			phase: "host",
			recoverable: !1,
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: t.key,
			...t.detail === void 0 ? {} : { params: { detail: t.detail } }
		}]
	};
	let c = t.maxSyntaxNodes, l = t.strict !== !1, u = new Zr({
		maxParseWork: t.maxParseWork,
		maxMarkdownDepth: t.maxMarkdownDepth
	}), f = t.markdownBreaks, p = t.schemaByName, m = t.externalComponentNames, _ = (e) => p.get(e)?.form === "inline", b = p, S = t.unmountedLeafNames, C = [...p.keys()], w = t.capabilities, T = w?.html, E = w?.markdownStructure, D = T?.nativeTagNames ?? /* @__PURE__ */ new Set(), O = T?.decodeEntities ?? ((e) => e), k = T?.decodeAttribute ?? O, A = qa(w), j = n?.source === e ? n : new g(e), { lineStarts: M } = j, N = {
		markdownCalls: 0,
		fastBlocks: 0,
		generalBlocks: 0,
		fastCharacters: 0,
		generalCharacters: 0,
		mappingSegments: 0,
		sourceLines: M.length,
		maxComponentDepth: 0
	}, P = r?.counters(), ee = Va(), F = 0, I = 0, L = 0, R = /* @__PURE__ */ new Map(), te = /* @__PURE__ */ new Set(), ne = (n) => {
		if (te.has(n) || !Wa(n)) return;
		te.add(n);
		let r = (n === e ? j : new g(n)).facts, i = r.maxMarkdownDepth;
		if (r.potentialDepth > t.maxMarkdownDepth || i > t.maxMarkdownDepth) {
			if (E) {
				let e = E(n);
				R.set(n, e), i = e.maxDepth;
			} else {
				i = 0;
				let e = [{
					node: B(n),
					depth: 0
				}];
				for (; e.length;) {
					let n = e.pop(), r = n.depth + +(n.node.type === "blockquote" || n.node.type === "list");
					if (i = Math.max(i, r), i > t.maxMarkdownDepth) break;
					for (let t of n.node.children ?? []) e.push({
						node: t,
						depth: r
					});
				}
			}
		}
		u.observeDepth(i, 0, Math.max(1, n.length));
	}, z = () => {
		if (N.parseWork = u.parseWork, N.maxMarkdownDepth = u.maxDepth, r) {
			let e = r.counters();
			N.cacheHits = e.hits - (P?.hits ?? e.hits), N.cacheMisses = e.misses - (P?.misses ?? e.misses), N.reusedBlocks = e.reusedBlocks - (P?.reusedBlocks ?? e.reusedBlocks), N.reusedRows = e.reusedRows - (P?.reusedRows ?? e.reusedRows), N.reusedItems = e.reusedItems - (P?.reusedItems ?? e.reusedItems), N.reusedAst = e.reusedAst - (P?.reusedAst ?? e.reusedAst);
		}
		N.timings = {
			shieldMs: Ha(F),
			regionMs: Ha(I),
			convertMs: Ha(L),
			totalMs: Ha(Va() - ee)
		};
	}, B = (e) => {
		let t = r?.readTree(e);
		if (t?.hit) return t.value;
		let n = A.parse(e);
		return r?.writeTree(e, n), n;
	}, re = (e, t = !0, n = { allowBraces: !0 }) => {
		if (u.charge(e.length + 1, 0, Math.max(1, e.length)), ne(e), !t) {
			let t = B(e);
			return N.markdownCalls++, N.generalBlocks += t.children.length, N.generalCharacters += e.length, t;
		}
		let a = R.get(e);
		a === void 0 && E && (a = E(e), R.set(e, a));
		let { tree: o, stats: s } = pi(e, B, j, r, a, i, n);
		return N.markdownCalls++, N.fastBlocks += s.fastBlocks, N.generalBlocks += s.generalBlocks, N.fastCharacters += s.fastCharacters, N.generalCharacters += s.generalCharacters, o;
	}, V = 0, ie = 0, ae = /* @__PURE__ */ new Set(), oe = (e, t, n, r = {}) => {
		if (ie >= c) throw new Li("local.budget", `Syntax nodes exceed the limit of ${c}.`, t, n, "local.budget.nodes", { limit: c }, ie + 1);
		return ie += 1, {
			type: e,
			id: `local-${V++}`,
			range: {
				start: t,
				end: n
			},
			...r
		};
	};
	try {
		u.charge(e.length, 0, Math.max(1, e.length)), ne(e);
		let t = a && a.length > 0 ? void 0 : Ri(e, f, oe);
		if (t !== void 0) return N.fastBlocks = t.length, N.fastCharacters = e.length, z(), {
			nodes: t,
			diagnostics: s,
			syntaxNodes: ie,
			work: N
		};
	} catch (e) {
		if (e instanceof Xr) return ge(e), z(), {
			nodes: [],
			diagnostics: s,
			work: N
		};
		if (!(e instanceof Li)) throw e;
		return Y(e), {
			nodes: [],
			diagnostics: s
		};
	}
	let H = new Set(e.match(/* @__PURE__ */ RegExp("[0-9]+", "g")) ?? []), se = [], ce = [], U = [], le = [], ue = [], W = +(e.charCodeAt(0) === 65279), de, G = !1;
	try {
		let t = e.slice(W);
		if (de = re(t, !0, {
			allowBraces: !0,
			shield(t, n) {
				if (!t.includes("{{")) return;
				let r = [], i = 0, a = 0;
				for (; a < t.length;) {
					let o = t.indexOf("{{", a);
					if (o < 0) break;
					let s = Hi(e, o + n + W, n + W + t.length) - n - W;
					if (s <= o || /[\r\n]/.test(t.slice(o, s))) return;
					r.push(t.slice(i, o), "v".repeat(s - o)), i = a = s;
				}
				if (r.length) return r.push(t.slice(i)), r.join("");
			}
		}), !e.includes("{{") && de.children.length === 1 && de.children[0].type === "rmdFastBlock") {
			let e = de.children[0].plan.overflowAt(c);
			if (e) throw new Li("local.budget", `Syntax nodes exceed the limit of ${c}.`, e.start + W, e.end + W, "local.budget.nodes", { limit: c }, c + 1);
		}
		let n = _i(de);
		if (/<(?:css|javascript|iframe|dl|section|figure|figcaption)(?=[\s/>])/i.test(t)) {
			let e = t, r = 0;
			for (;;) {
				let t = Vi(e, n.codeRanges, n.definitions, b, r);
				if (!t) break;
				G = !0, e = t.source, r = t.end, de = re(e, !1), n = _i(de);
			}
		}
		let r = (e) => ({
			start: e.start + W,
			end: e.end + W
		});
		for (let e of n.codeRanges) se.push(r(e));
		for (let e of n.definitions) e.end > e.start && ue.push(r(e));
		for (let e of n.mathLiterals) le.push(r(e));
		F = Va() - ee;
	} catch (e) {
		return e instanceof Xr ? (ge(e), z(), {
			nodes: [],
			diagnostics: s,
			work: N
		}) : e instanceof Li ? (Y(e), {
			nodes: [],
			diagnostics: s,
			work: N
		}) : (pe("local.parse", { key: "local.parse.markdown" }, 0, void 0), {
			nodes: [],
			diagnostics: s
		});
	}
	ue.sort((e, t) => e.start - t.start || t.end - e.end), le.sort((e, t) => e.start - t.start);
	let K = [];
	for (let e of ue) {
		let t = K[K.length - 1];
		t && e.start < t.end ? e.end > t.end && (t.end = e.end) : K.push({ ...e });
	}
	let q = (e) => {
		let t = 0, n = se.length - 1;
		for (; t <= n;) {
			let r = t + n >> 1, i = se[r];
			if (e < i.start) n = r - 1;
			else if (e >= i.end) t = r + 1;
			else return i.end;
		}
		return null;
	};
	function fe(t, n, r, i, a = i + 1, o, c) {
		if (s.length >= 100) {
			if (r === "warning") return;
			let e = s.length - 1;
			for (; e >= 0 && s[e].severity !== "warning";) --e;
			if (e < 0) return;
			s.splice(e, 1);
		}
		let l = Math.max(0, Math.min(e.length, i)), u = Math.max(l, Math.min(e.length, Math.max(l, a))), f = 0, p = M.length - 1;
		for (; f < p;) {
			let e = Math.ceil((f + p) / 2);
			M[e] <= l ? f = e : p = e - 1;
		}
		let m = f + 1, h = n.length > 2e3 ? `${x(n, d - 1)}…` : n, g = o?.key ?? t, _ = g === "local.budget.nodes" ? {
			budget: "maxSyntaxNodes",
			unit: "nodes"
		} : g === "local.budget.nesting" ? {
			budget: "maxComponentDepth",
			unit: "depth"
		} : g === "local.budget.parse-work" ? {
			budget: "maxParseWork",
			unit: "work"
		} : g === "local.budget.markdown-depth" ? {
			budget: "maxMarkdownDepth",
			unit: "depth"
		} : void 0, y = v(g, o?.params), b = y.params?.limit;
		s.push({
			code: t,
			message: h,
			severity: r,
			range: {
				start: l,
				end: u
			},
			line: m,
			column: l - M[f] + 1,
			messageKey: y.key,
			phase: t.startsWith("local.budget") ? "resource" : "parse",
			recoverable: r === "warning",
			..._ && typeof b == "number" && typeof c?.actual == "number" ? { details: {
				..._,
				limit: b,
				actual: c.actual,
				...c
			} } : {},
			...y.params ? { params: y.params } : {}
		});
	}
	function J(e) {
		return typeof e == "string" ? { text: e } : {
			text: y(e),
			details: e
		};
	}
	function pe(e, t, n, r = n + 1, i, a) {
		let o = J(t);
		fe(e, o.text, "error", n, r, o.details ?? i, a);
	}
	function me(e, t, n, r = n + 1, i) {
		let a = J(t);
		fe(e, a.text, "warning", n, r, a.details ?? i);
	}
	function Y(e) {
		let t = e.key === "local.budget.nodes" ? {
			budget: "maxSyntaxNodes",
			unit: "nodes"
		} : e.key === "local.budget.nesting" ? {
			budget: "maxComponentDepth",
			unit: "depth"
		} : void 0, n = e.params?.limit;
		pe(e.code, e.message, e.start, e.end, {
			key: e.key,
			...e.params ? { params: e.params } : {}
		}, t && typeof n == "number" && e.actual !== void 0 ? {
			...t,
			limit: n,
			actual: e.actual
		} : void 0);
	}
	function ge(e) {
		let t = e.kind === "parse-work" ? "local.budget.parse-work" : "local.budget.markdown-depth", n = e.kind === "parse-work" ? u.parseWork : u.maxDepth, r = e.kind === "parse-work" ? {
			budget: "maxParseWork",
			unit: "work"
		} : {
			budget: "maxMarkdownDepth",
			unit: "depth"
		};
		pe("local.budget", {
			key: t,
			params: { limit: e.limit }
		}, e.start, e.end, void 0, {
			...r,
			limit: e.limit,
			actual: n
		});
	}
	let _e = {
		themeHeaders: 0,
		headerCursor: 0,
		versionHeaders: 0
	}, ve = ma({
		source: e,
		maxSyntaxNodes: c,
		budget: u,
		markdownBreaks: f,
		isInlineName: _,
		sourceContext: j,
		work: N,
		parseMarkdown: re,
		readNodeCount: () => ie,
		fastPlans: ae,
		node: oe,
		reservedMarkers: H,
		sourceBomOffset: W,
		rootMarkdown: de,
		maskedAuthorBody: G,
		error: pe
	}), ye, be = Sa({
		source: e,
		strict: l,
		known: b,
		htmlSupport: T,
		decodeEntities: O,
		decodeAttribute: k,
		sourceContext: j,
		node: oe,
		codeEndAt: q,
		error: pe,
		region: (...e) => ye(...e),
		convert: ve
	}), { htmlCloseEnd: xe, protectedEnd: Se, scanTag: Ce, beginsLine: we } = be;
	function X(t) {
		let n = /* @__PURE__ */ new Set(), r = [...t];
		for (; r.length;) {
			let e = r.pop();
			if (e.type === "footnoteDefinition" && e.identifier && n.add(e.identifier), e.children) for (let t of e.children) r.push(t);
		}
		for (r.push(...t); r.length;) {
			let t = r.pop();
			if (t.type !== "footnoteReference" || t.identifier && n.has(t.identifier) || (t.type = "text", t.value = e.slice(t.range.start, t.range.end), delete t.identifier, delete t.label), t.children) for (let e of t.children) r.push(e);
		}
	}
	function Te() {
		if (l || U.length === 0) return;
		let e = /* @__PURE__ */ new Set(), t = !1;
		for (let n of U) {
			if (!Ba.has(n.code)) continue;
			let { causeRange: r, affectedRange: i } = n, a = `${n.code}:${r.start}:${r.end}:${i.start}:${i.end}:${n.boundary}`;
			e.has(a) || (e.add(a), me(n.code, h(n.code, "en"), r.start, r.end, { key: n.code }), t = !0);
		}
		t && s.sort((e, t) => e.range.start - t.range.start || e.range.end - t.range.end);
	}
	try {
		if (!l && e.includes("<")) {
			let t = Ia(e, {
				facts: j.facts,
				definitions: K,
				isKnown: (e) => b.has(e),
				isPaired: (e) => {
					let t = b.get(e);
					return t === void 0 ? !S.has(e) : t.form !== "leaf";
				},
				isHtmlName: (e) => T !== void 0 && (Pi.has(e) || D.has(e)),
				isVoidHtml: (e) => Ii.has(e) || he.has(e),
				rawHtmlEnd: (t, n, r) => {
					if (t === "plaintext") return e.length;
					if (t === "pre" || t === "code") return xe(n, t, e.length, r)?.end ?? null;
					let i = RegExp(`</${t}\\s*>`, "i").exec(e.slice(n));
					return i ? n + i.index + i[0].length : null;
				},
				protectedEnd: (t, n) => Se(t, e.length, n),
				codeEndAt: (e) => q(e),
				readTag: (t) => {
					let n = Ce(t, e.length);
					if (n) return {
						name: n.name,
						closing: n.closing,
						self: n.self,
						end: n.end,
						complete: !0
					};
					let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, Math.min(e.length, t + 256)));
					return r ? {
						name: r[2],
						closing: !!r[1],
						self: !1,
						end: t + r[0].length,
						complete: !1
					} : null;
				},
				beginsLine: we,
				charge: (e, t, n) => u.charge(e, t, n)
			});
			ce = t.ranges, U = [...t.recoveries];
		}
		a && a.length > 0 && (ce = Ja([...ce, ...a], e.length)), ye = ia({
			source: e,
			diagnostics: s,
			maxSyntaxNodes: c,
			strict: l,
			budget: u,
			known: b,
			externalNames: m,
			unmountedLeafNames: S,
			suggestionNames: C,
			htmlSupport: T,
			nativeHtmlNames: D,
			sourceContext: j,
			work: N,
			ensureDepth: ne,
			parseMarkdown: re,
			node: oe,
			codeRanges: se,
			recoveryRanges: ce,
			recoveries: U,
			rootMathLiterals: le,
			rootDefinitionRanges: K,
			error: pe,
			warning: me,
			headers: _e,
			scanner: be,
			convert: ve
		});
		let t = Va(), n = ye(0, e.length);
		I = Va() - t;
		let r = Va(), i = ve(0, e.length, n.tokens);
		L = Va() - r, X(i), U.sort((e, t) => e.causeRange.start - t.causeRange.start || e.causeRange.end - t.causeRange.end || e.affectedRange.start - t.affectedRange.start || e.affectedRange.end - t.affectedRange.end || e.code.localeCompare(t.code)), Te(), z();
		let { theme: o, themeRange: d, versionDeclaration: f } = _e;
		return {
			nodes: i,
			diagnostics: s,
			syntaxNodes: ie,
			work: N,
			...ae.size ? { plans: [...ae] } : {},
			...f ? { versionDeclaration: f } : {},
			...o === void 0 ? {} : { theme: o },
			...d ? { themeRange: d } : {},
			...U.length ? { recoveries: U } : {}
		};
	} catch (e) {
		return e instanceof Xr ? (ge(e), z(), {
			nodes: [],
			diagnostics: s,
			work: N,
			...U.length ? { recoveries: U } : {}
		}) : e instanceof Li ? (Y(e), z(), {
			nodes: [],
			diagnostics: s,
			work: N,
			...U.length ? { recoveries: U } : {}
		}) : (pe("local.parse", {
			key: "local.parse.document",
			params: { detail: e instanceof Error ? e.message : String(e) }
		}, 0, void 0), {
			nodes: [],
			diagnostics: s,
			...U.length ? { recoveries: U } : {}
		});
	}
}
// src/local/compilation/compiler-services.ts
function Xa(e, t, n, r, i = r + 1, a) {
	let o = typeof n == "string" ? a : n, s = typeof n == "string" ? n : y(n);
	if (e.diagnostics.length >= 100) return;
	let c = Math.max(0, Math.min(e.source.length, r)), l = Math.max(c, Math.min(e.source.length, Math.max(c, i))), u = 0, f = e.lineStarts.length - 1;
	for (; u < f;) {
		let t = Math.ceil((u + f) / 2);
		e.lineStarts[t] <= c ? u = t : f = t - 1;
	}
	let p = v(o?.key ?? t, o?.params);
	e.diagnostics.push({
		code: t,
		message: s.length > 2e3 ? `${x(s, d - 1)}…` : s,
		severity: "warning",
		range: {
			start: c,
			end: l
		},
		line: u + 1,
		column: c - e.lineStarts[u] + 1,
		messageKey: p.key,
		phase: t.includes("budget") ? "resource" : "semantic",
		recoverable: !0,
		...p.params ? { params: p.params } : {}
	});
}
// src/local/compilation/compiler-values.ts
var Za = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;
function Qa(e) {
	let t = e.trim();
	if (!Za.test(t)) return null;
	let n = Number(t);
	return Number.isFinite(n) ? n : null;
}
function $a(e) {
	return e.type === "comment" || e.type === "text" && !(e.value ?? "").trim() || e.type === "paragraph" && !e.children?.length && !(e.value ?? "").trim();
}
function eo(e) {
	return (e ?? []).filter((e) => !$a(e));
}
function to(e) {
	return e.type === "component" || (e.children ?? []).some(to);
}
function no(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.kernel.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function ro(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "string" ? r.value : void 0;
	let i = e.kernel.props[n]?.default;
	return typeof i == "string" ? i : void 0;
}
function io(e) {
	return e.type === "text" || e.type === "inlineCode" || e.type === "fallback" ? e.value ?? "" : e.type === "interpolation" ? "\0" : e.type === "break" ? " " : (e.children ?? []).map(io).join("");
}
function ao(e) {
	return e.type === "interpolation" || (e.children ?? []).some(ao);
}
function oo(e) {
	switch (e) {
		case "string": return "string";
		case "number": return "number";
		case "boolean": return "boolean";
		case "null": return "null";
		case "array": return "array";
		case "number-array": return "number-array";
	}
}
var so = /^[A-Za-z_][A-Za-z0-9_]*$/;
function co(e) {
	if (!uo(e)) return !1;
	let t = lo(e);
	return t.segments.length === 1 && t.unterminated.length === 0;
}
function lo(e) {
	let t = [], n = [];
	for (let r = 0; r < e.length;) {
		if (e[r] === "\\" && e.startsWith("{{", r + 1)) {
			r += 3;
			continue;
		}
		if (!e.startsWith("{{", r)) {
			r++;
			continue;
		}
		let i = "", a = r + 2;
		for (; a < e.length - 1; a++) {
			let t = e[a];
			if (i) t === "\\" ? a++ : t === i && (i = "");
			else if (t === "\"" || t === "'") i = t;
			else if (t === "}" && e[a + 1] === "}") break;
		}
		if (a >= e.length - 1) {
			n.push(r);
			break;
		}
		let o = e.slice(r + 2, a), s = o.length - o.trimStart().length;
		t.push({
			expression: o.trim(),
			start: r + 2 + s,
			end: a
		}), r = a + 2;
	}
	return {
		segments: t,
		unterminated: n
	};
}
function uo(e) {
	let t = /^\s*\{\{([\s\S]*)\}\}\s*$/.exec(e);
	if (!t) return null;
	let n = t[1], r = n.length - n.trimStart().length, i = e.indexOf("{{");
	return {
		expression: n.trim(),
		start: i + 2 + r
	};
}
function fo(e, t) {
	if (e.length > 128) return;
	let n, r = Infinity;
	for (let i of t) {
		let t = po(e, i);
		t < r && (n = i, r = t);
	}
	return r <= 2 ? n : void 0;
}
function po(e, t) {
	let n = Array.from({ length: t.length + 1 }, (e, t) => t);
	for (let r = 1; r <= e.length; r++) {
		let i = n[0];
		n[0] = r;
		for (let a = 1; a <= t.length; a++) {
			let o = n[a];
			n[a] = Math.min(n[a] + 1, n[a - 1] + 1, i + (e[r - 1] === t[a - 1] ? 0 : 1)), i = o;
		}
	}
	return n[t.length];
}
function mo(e) {
	return {
		...e.bindingKinds,
		...e.externalKinds,
		...e.computationKinds
	};
}
function ho(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function go(e, t) {
	let n = X(e.kernel);
	return n ? Ae(e.kernel, n, t) : { step: 1 };
}
function _o(e, t, n, r) {
	if (typeof t != "string" || t === "") return;
	let i = e.members[0], a = X(i.entry.kernel)?.initial ?? "initial", o = r ?? i.attrs[a]?.offset ?? i.entry.node.range.start, s = m(t);
	for (let r of e.members) {
		let { entry: i, attrs: a } = r;
		for (let r of W(i.kernel)) if (r.kind === "length") {
			let t = no(i, a, r.min) ?? 0, c = no(i, a, r.max);
			t > 0 && s < t && n.report("local.initial.length", {
				key: "local.initial.length.min",
				params: {
					key: e.key,
					length: s,
					min: t,
					name: i.name
				}
			}, o, void 0), c !== void 0 && s > c && n.report("local.initial.length", {
				key: "local.initial.length.max",
				params: {
					key: e.key,
					length: s,
					max: c,
					name: i.name
				}
			}, o, void 0);
		} else if (r.kind === "email") (ro(i, a, r.type) ?? "text") === r.value && (t.length > 254 || !l(t)) && n.report("local.initial.email", {
			key: "local.initial.email",
			params: { key: e.key }
		}, o, void 0);
		else if (r.kind === "date" && ke(t)) {
			let s = ro(i, a, r.min), c = ro(i, a, r.max);
			s && ke(s) && t < s && n.report("local.initial.range", {
				key: "local.initial.date.min",
				params: {
					key: e.key,
					value: t,
					min: s
				}
			}, o, void 0), c && ke(c) && t > c && n.report("local.initial.range", {
				key: "local.initial.date.max",
				params: {
					key: e.key,
					value: t,
					max: c
				}
			}, o, void 0);
		}
	}
}
function vo(e, t, n, r, i, a, o) {
	let s = e.key, c = t.attrs[r.initial]?.offset ?? t.entry.node.range.start;
	if (r.kind === "array" || r.kind === "number-array") {
		if (!Array.isArray(n)) {
			o.report("local.initial.type", {
				key: "local.initial.type.array",
				params: { key: s }
			}, c, void 0);
			return;
		}
		let e = w(n);
		if (e) {
			o.report("local.budget.array", {
				key: e.key,
				params: {
					...e.params,
					key: s
				}
			}, c, void 0);
			return;
		}
		if (r.kind === "number-array") {
			if (!n.every((e) => typeof e == "number" && Number.isFinite(e))) {
				o.report("local.initial.type", {
					key: "local.initial.type.number-array",
					params: { key: s }
				}, c, void 0);
				return;
			}
		} else {
			if (!n.every((e) => typeof e == "string")) {
				o.report("local.initial.type", {
					key: "local.initial.type.array",
					params: { key: s }
				}, c, void 0);
				return;
			}
			if (i.length) for (let e of n) i.includes(e) || o.report("local.initial.option", {
				key: "local.initial.value.option",
				params: {
					value: e,
					options: i.join(", ")
				}
			}, c, void 0);
		}
		let a = Te(t.entry.kernel, r, t.attrs);
		a !== void 0 && n.length > a && o.report("local.initial.range", {
			key: "local.initial.value.max-items",
			params: {
				key: s,
				max: a
			}
		}, c, void 0);
	} else if (r.kind === "number") {
		if (typeof n != "number" || !Number.isFinite(n)) {
			o.report("local.initial.type", {
				key: "local.initial.type.number",
				params: { key: s }
			}, t.entry.node.range.start, void 0);
			return;
		}
		let e = a ?? go(t.entry, t.attrs);
		e.min !== void 0 && n < e.min && o.report("local.initial.range", {
			key: "local.initial.range.min",
			params: {
				value: n,
				key: s,
				min: e.min
			}
		}, c, void 0), e.max !== void 0 && n > e.max && o.report("local.initial.range", {
			key: "local.initial.range.max",
			params: {
				value: n,
				key: s,
				max: e.max
			}
		}, c, void 0);
		let r = e.min ?? 0;
		e.dynamicMin === void 0 && n >= (e.min ?? -Infinity) && n <= (e.max ?? Infinity) && !Fe(n, r, e.step) && o.report("local.initial.step", {
			key: "local.initial.range.step",
			params: {
				value: n,
				key: s,
				step: e.step,
				base: e.min ?? 0
			}
		}, c, void 0);
	} else r.kind === "boolean" && typeof n != "boolean" && o.report("local.initial.type", {
		key: "local.initial.type.boolean",
		params: { key: s }
	}, t.entry.node.range.start, void 0), (r.family === "choice" || r.family === "tabs" || r.family === "steps" || r.family === "diagram" || r.family === "selection") && i.length && !i.includes(String(n)) && o.report("local.initial.option", {
		key: "local.initial.value.options",
		params: {
			value: String(n),
			key: s,
			options: i.join(", ")
		}
	}, c, void 0);
}
// src/local/compilation/compiler-structure.ts
function yo(e, t) {
	let n = [];
	for (let r of e.node.children ?? []) (r.type === "component" || r.type === "hostComponent") && r.name && t.schemaByName.has(r.name) && n.push({
		node: r,
		name: r.name
	});
	return n;
}
function bo(e, t) {
	switch (t) {
		case "options": return e.options;
		case "tabs": return e.tabs;
		case "steps": return e.steps;
		case "diagram-nodes": return e.diagramNodes;
	}
}
function xo(e, t, n, r) {
	n === "selection" ? e.selections.set(t.node.id, r) : n !== "checklist" && bo(e, n).set(t.node.id, r);
}
function So(e) {
	return e.children ?? e.items ?? (e.child ? [e.child] : []);
}
function Co(e) {
	return e.min ?? e.minItems ?? 0;
}
function wo(e, t) {
	if (So(Ie(e.kernel)).includes(t)) return !0;
	for (let n of Ne(e.kernel)) switch (n.kind) {
		case "options-body":
		case "value-sequence":
			if (n.child === t) return !0;
			break;
		case "only-children":
			if (n.children.includes(t)) return !0;
			break;
		case "data-table":
			if (n.child === t) return !0;
			break;
		case "quiz-body":
			if (n.child === t) return !0;
			break;
		case "diagram-body": if (n.node === t || n.edge === t) return !0;
	}
	return !1;
}
function To(e) {
	return e.max ?? e.maxItems ?? e.maxItemsCount;
}
var Eo = /* @__PURE__ */ new Set([
	"text",
	"emphasis",
	"strong",
	"delete",
	"underline",
	"mark",
	"link",
	"image",
	"inlineCode",
	"inlineMath",
	"interpolation",
	"break",
	"comment",
	"fallback",
	"footnoteReference"
]);
function Do(e) {
	return Eo.has(e.type) && (e.children ?? []).every(Do);
}
function Oo(e, t, n, r) {
	r && ((t.length === 1 && t[0].type === "paragraph" ? t[0].children ?? [] : t).every(Do) || n.report("local.structure.children", {
		key: "local.structure.inline-only",
		params: { name: e.name }
	}, e.node.range.start, e.node.range.end));
	for (let r of t) to(r) && n.report("local.structure.children", {
		key: "local.structure.no-nested-components",
		params: { name: e.name }
	}, r.range.start, r.range.end);
}
function ko(e, t) {
	let n = (r) => {
		for (let i of r) i.type === "component" || i.type === "hostComponent" ? t.report("local.structure.children", {
			key: "local.structure.no-components",
			params: { name: e.name }
		}, i.range.start, i.range.end) : i.children && n(i.children);
	};
	n(e.node.children ?? []);
}
function Ao(e, t, n, r, i, a, o, s) {
	let c = yo(e, t), l = c.filter((e) => e.name === r);
	l.length || t.report("local.structure.children", {
		key: "local.structure.options.needed",
		params: { name: e.name }
	}, e.node.range.start, e.node.range.end);
	for (let n of c) n.name !== r && t.report("local.structure.children", {
		key: "local.structure.options.only",
		params: { name: e.name }
	}, n.node.range.start, n.node.range.end);
	eo(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || e.name !== r) && t.report("local.structure.children", {
		key: "local.structure.options.only",
		params: { name: e.name }
	}, e.node.range.start, e.node.range.end), l.length > o && t.report("local.budget.array", {
		key: "local.budget.array.options",
		params: {
			name: e.name,
			limit: o
		}
	}, e.node.range.start, e.node.range.end);
	let u = [];
	for (let n of l) {
		let r = t.attrs.get(n.node.id) ?? {}, o = typeof r[i]?.value == "string" ? r[i].value : "";
		o ? s !== void 0 && o.includes(s) ? t.report("local.option.value", {
			key: "local.option.value.comma",
			params: { value: o }
		}, n.node.range.start, n.node.range.end) : a && u.includes(o) ? t.report("local.option.value", {
			key: "local.option.value.duplicate",
			params: {
				name: e.name,
				value: o
			}
		}, n.node.range.start, n.node.range.end) : ((n.node.children ?? []).some(to) && t.report("local.structure.children", { key: "local.structure.option.no-components" }, n.node.range.start, n.node.range.end), u.push(o)) : t.report("local.option.value", { key: "local.option.value.required" }, n.node.range.start, n.node.range.end);
	}
	xo(t, e, "options", u);
}
function jo(e, t, n, r, i, a) {
	let o = yo(e, t), s = o.filter((e) => e.name === n);
	s.length || t.report("local.structure.children", {
		key: "local.structure.sequence.minimum",
		params: {
			name: e.name,
			child: n
		}
	}, e.node.range.start, e.node.range.end);
	for (let r of o) r.name !== n && t.report("local.structure.children", {
		key: "local.structure.sequence.only",
		params: {
			name: e.name,
			child: n
		}
	}, r.node.range.start, r.node.range.end);
	eo(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || e.name !== n) && t.report("local.structure.children", {
		key: "local.structure.sequence.only",
		params: {
			name: e.name,
			child: n
		}
	}, e.node.range.start, e.node.range.end);
	let c = [];
	s.forEach((n, o) => {
		let s = t.attrs.get(n.node.id) ?? {}, l = (typeof s[r]?.value == "string" ? s[r].value.trim() : "") || `${i}${o + 1}`;
		c.includes(l) ? t.report(a, `Values in <${e.name}> must be unique; duplicate value "${l}".`, n.node.range.start, n.node.range.end, {
			key: `${a}.duplicate`,
			params: { value: l }
		}) : c.push(l);
	});
	let l = X(e.kernel)?.family;
	xo(t, e, Ee(l ?? "") === "tabs" ? "tabs" : "steps", c);
}
function Mo(e, t, n, r, i, a, o) {
	let s = yo(e, t), c = s.filter((e) => n.includes(e.name)), l = n.map((e) => `<${e}>`).join(" or "), u = i !== void 0 && o === "local.budget.data-table.columns" ? Math.min(i, 20) : i;
	c.length < r && t.report("local.structure.children", {
		key: "local.structure.children.minimum",
		params: {
			name: e.name,
			min: r,
			children: l
		}
	}, e.node.range.start, e.node.range.end), u !== void 0 && c.length > u && t.report(o ?? "local.budget.array", `<${e.name}> supports at most ${u} ${l}, but has ${c.length}.`, e.node.range.start, e.node.range.end);
	for (let r of s) n.includes(r.name) || t.report("local.structure.children", {
		key: a ?? "local.structure.children.only",
		params: {
			name: e.name,
			children: l
		}
	}, r.node.range.start, r.node.range.end);
	eo(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || !e.name || !t.schemaByName.has(e.name)) && t.report("local.structure.children", {
		key: a ?? "local.structure.children.only",
		params: {
			name: e.name,
			children: l
		}
	}, e.node.range.start, e.node.range.end);
}
function No(e, t, n) {
	let r = yo(e, t), i = r.filter((e) => e.name === n.node), a = r.filter((e) => e.name === n.edge);
	i.length || t.report("local.diagram.node", { key: "local.diagram.node.required" }, e.node.range.start, e.node.range.end);
	for (let e of r) e.name !== n.node && e.name !== n.edge && t.report("local.structure.children", { key: "local.structure.diagram.only" }, e.node.range.start, e.node.range.end);
	eo(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || !e.name || e.name !== n.node && e.name !== n.edge) && t.report("local.structure.children", { key: "local.structure.diagram.only" }, e.node.range.start, e.node.range.end);
	let o = [];
	for (let e of i) {
		let r = (t.attrs.get(e.node.id) ?? {})[n.id]?.value, i = typeof r == "string" ? r : "";
		i && (/^[A-Za-z_][A-Za-z0-9_-]*$/.test(i) || t.report("local.diagram.node", {
			key: "local.diagram.node.invalid",
			params: { id: i }
		}, e.node.range.start, e.node.range.end), o.includes(i) ? t.report("local.diagram.node", {
			key: "local.diagram.node.duplicate",
			params: { id: i }
		}, e.node.range.start, e.node.range.end) : o.push(i));
	}
	xo(t, e, "diagram-nodes", o);
	let s = /* @__PURE__ */ new Set();
	for (let e of a) {
		let r = t.attrs.get(e.node.id) ?? {}, i = r[n.from]?.value, a = r[n.to]?.value, c = n.label ? r[n.label]?.value : void 0, l = typeof i == "string" ? i : "", u = typeof a == "string" ? a : "", d = typeof c == "string" ? c : "";
		l && !o.includes(l) && t.report("local.diagram.edge", {
			key: "local.diagram.edge.from",
			params: { id: l }
		}, e.node.range.start, e.node.range.end), u && !o.includes(u) && t.report("local.diagram.edge", {
			key: "local.diagram.edge.to",
			params: { id: u }
		}, e.node.range.start, e.node.range.end);
		let f = `${l}\u0000${u}\u0000${d}`;
		s.has(f) && t.report("local.diagram.edge", {
			key: "local.diagram.edge.duplicate",
			params: {
				from: l,
				to: u,
				label: d ? ` (${d})` : ""
			}
		}, e.node.range.start, e.node.range.end), s.add(f);
	}
}
function Po(e, t, n, r) {
	let i = typeof n[r.type]?.value == "string" ? String(n[r.type].value) : "choice", a = ro(e, n, r.answer) ?? "";
	if (a.trim() || t.report("local.quiz.answer", { key: "local.quiz.answer.required" }, n[r.answer]?.offset ?? e.node.range.start, void 0), i === "number") {
		eo(e.node.children).length && t.report("local.structure.children", { key: "local.structure.quiz.numeric-no-body" }, e.node.range.start, e.node.range.end), a.trim() && Qa(a) === null && t.report("local.quiz.answer", { key: "local.quiz.answer.numeric" }, n[r.answer]?.offset ?? e.node.range.start, void 0);
		let i = no(e, n, r.tolerance);
		i !== void 0 && (!Number.isFinite(i) || i < 0) && t.report("local.constraint", { key: "local.constraint.quiz-tolerance" }, n[r.tolerance]?.offset ?? e.node.range.start, void 0);
		return;
	}
	Ao(e, t, n, r.child, r.valueAttribute, !0, Math.min(r.max ?? 1e4, p), void 0);
	let o = t.options.get(e.node.id) ?? [];
	a.trim() && o.length && !o.includes(a) && t.report("local.quiz.answer", {
		key: "local.quiz.answer.not-option",
		params: {
			answer: a,
			options: o.join(", ")
		}
	}, n[r.answer]?.offset ?? e.node.range.start, void 0);
}
function Fo(e, t) {
	let n = t.attrs.get(e.node.id) ?? {}, r = eo(e.node.children), i = t.report, a = Ie(e.kernel), o = Ne(e.kernel);
	a.parents && (e.parent === null || !a.parents.includes(e.parent.name) && !wo(e.parent, e.name)) && i("local.structure.parent", `<${e.name}> can only appear directly inside ${a.parents.map((e) => `<${e}>`).join(" or ")}.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.parent",
		params: {
			name: e.name,
			parents: a.parents.map((e) => `<${e}>`).join(" / ")
		}
	});
	let s = !1, c = !1;
	for (let l of o) switch (l.kind) {
		case "inline-body":
			s = !0, Oo(e, r, t, l.strict === !0 || a.inlineOnly === !0);
			break;
		case "no-components":
			s = !0, ko(e, t);
			break;
		case "single-table": {
			s = !0, c = !0;
			let n = r.filter((e) => e.type === "table");
			(n.length !== 1 || r.length !== 1) && i("local.structure.children", `The body of <${e.name}> must be exactly one Markdown table.`, e.node.range.start, e.node.range.end, {
				key: "local.structure.table.single",
				params: { name: e.name }
			}), n.length ? t.tables.set(e.node.id, n[0]) : l.fallbackSingle === !0 && r.length === 1 && t.tables.set(e.node.id, r[0]);
			break;
		}
		case "math-body":
			s = !0, c = !0, r.filter((e) => e.type === "math").length || i("local.structure.children", `<${e.name}> requires at least one $$...$$ formula block.`, e.node.range.start, e.node.range.end, { key: "local.structure.plot.needs-formula" });
			for (let t of r) t.type !== "math" && i("local.structure.children", `The body of <${e.name}> can only contain blank lines and $$...$$ formula blocks.`, t.range.start, t.range.end, { key: "local.structure.plot.only-formulas" });
			break;
		case "options-body":
			s = !0, c = !0, Ao(e, t, n, l.child, l.valueAttribute, l.unique, Math.min(l.max ?? 1e4, p), l.forbidSeparator);
			break;
		case "value-sequence":
			s = !0, c = !0, jo(e, t, l.child, l.valueAttribute, l.generatedPrefix, l.duplicateCode ?? `local.${l.child}.value`);
			break;
		case "only-children":
			s = !0, c = !0, Mo(e, t, l.children, l.min, l.max, l.onlyCode, l.maxCode);
			break;
		case "diagram-body":
			s = !0, c = !0, No(e, t, l);
			break;
		case "quiz-body":
			s = !0, c = !0, Po(e, t, n, l);
			break;
		case "checklist-body": s = !0, c = !0, Io(e, t, Math.min(l.itemLimit, p));
	}
	if (!s) switch (a.rule) {
		case "none":
			r.length && (e.legacy ? i("local.host.structure", `Host component <${e.name}> is a leaf and cannot have body content.`, r[0].range.start, r[0].range.end, {
				key: "local.host.structure.leaf",
				params: { component: e.name }
			}) : i("local.structure.children", `<${e.name}> does not accept body content.`, r[0].range.start, r[0].range.end, {
				key: "local.structure.no-body",
				params: { name: e.name }
			}));
			break;
		case "inline":
			Oo(e, r, t, a.inlineOnly === !0 || a.markdown === "inline");
			break;
		case "content":
			(a.noComponents === !0 || a.allowComponents === !1) && ko(e, t);
			break;
		case "components": {
			(a.noComponents === !0 || a.allowComponents === !1) && ko(e, t);
			let n = So(a);
			if (n.length) {
				c = !0;
				let r = Z(e.kernel, "data-table");
				Mo(e, t, n, Co(a), To(a), void 0, r ? "local.budget.data-table.columns" : void 0);
			}
			break;
		}
		case "options":
			c = !0, Ao(e, t, n, So(a)[0] ?? "option", a.valueAttribute ?? "value", !0, Math.min(a.maxItems ?? 1e4, p), a.forbidSeparator);
			break;
		case "tabs":
		case "steps": c = !0, jo(e, t, So(a)[0] ?? (a.rule === "tabs" ? "tab" : "step"), a.valueAttribute ?? "value", a.generatedPrefix ?? a.valuePrefix ?? `${a.rule === "tabs" ? "tab" : "step"}-`, `local.${a.rule === "tabs" ? "tab" : "step"}.value`);
	}
	let l = Co(a);
	!c && l > 0 && r.length < l && i(e.legacy ? "local.host.structure" : "local.structure.children", `Component <${e.name}> requires body content.`, e.node.range.start, e.node.range.end, {
		key: e.legacy ? "local.host.structure.leaf" : "local.structure.content-required",
		params: { component: e.name }
	});
	let u = To(a);
	!c && u !== void 0 && r.length > u && i("local.structure.children", `<${e.name}> accepts at most ${u} body blocks.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.body-max",
		params: {
			name: e.name,
			max: u
		}
	});
}
function Io(e, t, n = p) {
	let r = t.checklists.get(e.node.id);
	if (r) return r;
	let i = eo(e.node.children), a = i.filter((e) => e.type === "list");
	(i.length !== 1 || a.length !== 1) && t.report("local.checklist.body", { key: "local.checklist.body.single" }, e.node.range.start, e.node.range.end);
	let o = a[0], s = [], c = [];
	if (!o) return t.checklists.set(e.node.id, {
		ids: s,
		checked: c
	}), {
		ids: s,
		checked: c
	};
	let l = o.children ?? [];
	l.length || t.report("local.checklist.body", { key: "local.checklist.body.item-required" }, o.range.start, o.range.end), l.length > n && t.report("local.budget.array", {
		key: "local.checklist.body.items-limit",
		params: { limit: n }
	}, o.range.start, o.range.end), l.slice(0, n).forEach((e, n) => {
		if (e.type !== "listItem" || e.checked === null || e.checked === void 0) {
			t.report("local.checklist.body", { key: "local.checklist.body.task-only" }, e.range.start, e.range.end);
			return;
		}
		(e.children ?? []).some((e) => e.type === "list") && t.report("local.checklist.body", { key: "local.checklist.body.no-nested" }, e.range.start, e.range.end), to(e) && t.report("local.checklist.body", { key: "local.checklist.body.no-components" }, e.range.start, e.range.end);
		let r = `item-${n + 1}`;
		s.push(r), e.checked && c.push(r);
	});
	let u = {
		ids: s,
		checked: c
	};
	return t.checklists.set(e.node.id, u), u;
}
function Lo(e, t) {
	if (!(e.length > 128)) return _e(e, [...t]);
}
function Ro(e) {
	let t = [];
	for (let n of S(e)) n.type === "code" && (n.lang ?? "").trim().toLowerCase() === "reactive-md" && t.push(n);
	return t;
}
function zo(e, t, n, r) {
	let i = [{
		nodes: e,
		parent: t,
		index: 0
	}];
	for (; i.length;) {
		let e = i[i.length - 1];
		if (e.index === e.nodes.length) {
			i.pop();
			continue;
		}
		let t = e.nodes[e.index++], a = e.parent, o = a;
		if ((t.type === "component" || t.type === "hostComponent") && t.name) {
			let e = r.schemaByName.get(t.name);
			if (e) {
				let i = r.definitionsByName.get(t.name), s = Le(e) || i !== void 0 && !i.rules?.length && t.type === "hostComponent", c = {
					node: t,
					name: t.name,
					kernel: e,
					...i ? { definition: i } : {},
					legacy: s,
					parent: a
				};
				n.push(c), o = c;
			} else if (t.type === "component") {
				let e = Lo(t.name, r.schemaByName.keys());
				r.report("local.component.unknown", {
					key: e ? "local.component.unknown.suggestion" : "local.component.unknown",
					params: e ? {
						name: t.name,
						suggestion: e
					} : { name: t.name }
				}, t.range.start, t.range.end);
			}
		}
		t.children && i.push({
			nodes: t.children,
			parent: o,
			index: 0
		});
	}
}
function Bo(e, t) {
	if (t.size === 0) return;
	let n = /* @__PURE__ */ new Map();
	for (let r of S(e)) {
		if (r.type !== "hostComponent" || !r.name) continue;
		let e = t.get(r.name);
		e !== void 0 && n.set(e.id, xe(e));
	}
	if (n.size === 0) return;
	let r = Object.freeze([...n.values()].sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
	return Object.freeze({
		protocol: s,
		components: r
	});
}
function Vo(e, t) {
	let n = {}, r = {}, i = {}, a = [], o = new Map(e.entries.map((e) => [e.node.id, e])), s = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots)) {
		let e = o.get(t);
		if (e) for (let [t, r] of Object.entries(n)) s.set(r, {
			entry: e,
			slot: t
		});
	}
	for (let [e, n] of Object.entries(t)) {
		let t = s.get(e);
		if (t) {
			let n = De(t.entry.kernel).find((e) => e.slot === t.slot);
			n && (i[e] = {
				bind: n.bind,
				initial: n.initial
			});
			continue;
		}
		let r = o.get(n.owner ?? n.nodeIds[0] ?? ""), a = r ? X(r.kernel) : void 0;
		a && (i[e] = {
			bind: a.bind,
			initial: a.initial
		});
	}
	for (let t of e.entries) {
		let i = W(t.kernel);
		i.length && (n[t.node.id] = Object.freeze([...i]));
		let o = Z(t.kernel, "self-binding-read"), s = Z(t.kernel, "inline-math-reads");
		(o || s) && (r[t.node.id] = {
			...o ? { selfBinding: {
				mode: o.mode,
				...o.attribute ? { attribute: o.attribute } : {}
			} } : {},
			...s ? { inlineMathReads: !0 } : {}
		});
		for (let n of Ce(t.kernel)) e.bindingSlots[t.node.id]?.[n.lower] && e.bindingSlots[t.node.id]?.[n.upper] && a.push({
			nodeId: t.node.id,
			lower: n.lower,
			upper: n.upper
		});
	}
	let c = [];
	for (let [e, n] of Object.entries(t)) n.nodeIds.some((e) => {
		let t = o.get(e);
		return (t ? X(t.kernel) : void 0)?.retain === !1;
	}) && c.push(e);
	return Object.keys(n).length === 0 && Object.keys(r).length === 0 && Object.keys(i).length === 0 && a.length === 0 && c.length === 0 ? {
		valueRules: Object.freeze({}),
		slotRelations: Object.freeze([]),
		retentionExclusions: Object.freeze([])
	} : {
		valueRules: Object.freeze(n),
		slotRelations: Object.freeze(a.map((e) => Object.freeze(e))),
		retentionExclusions: Object.freeze(c.sort()),
		...Object.keys(i).length ? { bindingAttributes: Object.freeze(i) } : {},
		...Object.keys(r).length ? { dependencyRules: Object.freeze(r) } : {}
	};
}
function Ho(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r of e.entries) {
		let e = r.definition;
		e && !t.has(e.id) && (t.add(e.id), n.push(e));
	}
	return n;
}
function Uo(e, t) {
	for (let n of S(e)) n.type !== "hostComponent" || n.name && t.schemaByName.has(n.name) || Xa(t, "local.component.unknown", {
		key: "local.component.unknown",
		params: { name: n.name ?? "" }
	}, n.range.start, n.range.end);
}
// src/local/compilation/compiler-attributes.ts
function Wo(e, t, n) {
	let r = "", i = t;
	for (; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") {
			i += 1;
			break;
		}
	}
	return e.slice(t, i);
}
function Go(e, t, n) {
	if (n.length > 128) return t.range.start;
	let r = Wo(e.source, t.range.start, t.range.end), i = RegExp(`(?:^|[\\s"'/])${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?=\\s|=|/|>)`).exec(r);
	return i ? t.range.start + i.index + (i[0].length - n.length) : t.range.start;
}
function Ko(e, t) {
	if (!t.semantic) return qo(e, t);
	let n = e.name + "\0" + Wo(t.source, e.node.range.start, e.node.range.end), r = t.semantic.attributes(n), i = (e, t) => Object.fromEntries(Object.entries(e).map(([e, n]) => [e, {
		...n,
		offset: n.offset + t,
		...n.expressionOffset === void 0 ? {} : { expressionOffset: n.expressionOffset + t },
		...Array.isArray(n.value) ? { value: ho(n.value) } : {}
	}]));
	if (r) return i(r.value, e.node.range.start - r.origin);
	let a = t.diagnostics.length, o = qo(e, t);
	return a < 100 && t.diagnostics.length === a && t.semantic.rememberAttributes(n, e.node.range.start, i(o, 0)), o;
}
function qo(e, t) {
	let n = {}, r = e.node.attrs ?? {}, i = e.kernel.props, a = e.legacy, o = a ? Jo(e) : void 0;
	for (let [s, c] of Object.entries(r)) {
		let r = Go(t, e.node, s);
		if (a && c.length > 1e5) {
			t.report("local.budget.attribute", {
				key: "local.budget.attribute",
				params: {
					name: s,
					component: e.name,
					limit: u
				}
			}, r, r + s.length);
			continue;
		}
		if (o?.bind.has(s) || o?.initial.has(s)) {
			n[s] = Yo(e, s, c, r);
			continue;
		}
		let l = i[s];
		if (!l) {
			let n = _e(s, Object.keys(i));
			a ? t.report("local.host.attribute", {
				key: "local.host.attribute.unknown",
				params: {
					component: e.name,
					name: s
				}
			}, r, r + s.length) : t.report("local.attribute.unknown", {
				key: n ? "local.attribute.unknown.suggestion" : "local.attribute.unknown",
				params: n ? {
					component: e.name,
					name: s,
					suggestion: n
				} : {
					component: e.name,
					name: s
				}
			}, r, r + s.length);
			continue;
		}
		let d = {
			raw: c,
			offset: r,
			dynamic: !1
		};
		if (l.kind === "string" && c.length > 1e5 && (t.report("local.budget.attribute", {
			key: "local.budget.attribute",
			params: {
				name: s,
				component: e.name,
				limit: u
			}
		}, r, r + s.length), d.raw = c.slice(0, u)), Zo(s, l, d, t, a), l.color) {
			let n = lo(d.raw);
			n.segments.length || n.unterminated.length || Se(d.raw) || t.report("local.attribute.color", {
				key: "local.attribute.color",
				params: {
					name: s,
					component: e.name,
					value: d.raw
				}
			}, r, r + s.length);
		}
		n[s] = d;
	}
	for (let [r, s] of Object.entries(i)) o?.bind.has(r) || o?.initial.has(r) || s.required && s.default === void 0 && !Object.hasOwn(n, r) && (a ? t.report("local.host.attribute", {
		key: "local.host.attribute.required",
		params: {
			component: e.name,
			name: r
		}
	}, e.node.range.start, e.node.range.end) : t.report("local.attribute.required", {
		key: "local.attribute.required",
		params: {
			component: e.name,
			name: r
		}
	}, e.node.range.start, e.node.range.end));
	return Ie(e.kernel).label === "required" && (Object.hasOwn(n, "label") ? String(n.label.raw).trim() || t.report("local.label.required", {
		key: "local.label.required.empty",
		params: { name: e.name }
	}, n.label.offset, void 0) : t.report("local.label.required", {
		key: "local.label.required.missing",
		params: { name: e.name }
	}, e.node.range.start, e.node.range.end)), n;
}
function Jo(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = X(e.kernel);
	r && (t.add(r.bind), n.add(r.initial));
	for (let r of De(e.kernel)) t.add(r.bind), n.add(r.initial);
	return t.size || n.size ? {
		bind: t,
		initial: n
	} : void 0;
}
function Yo(e, t, n, r) {
	let i = X(e.kernel), a = i && i.bind === t ? i : De(e.kernel).find((e) => e.bind === t || e.initial === t) ?? (i && i.initial === t ? i : void 0), o = {
		raw: n,
		offset: r,
		dynamic: !1
	};
	if (!a || a.bind === t) return o.value = n, o;
	if (a.kind === "number") {
		let e = Qa(n);
		e !== null && (o.value = e);
	} else a.kind === "boolean" ? (n === "true" || n === "false") && (o.value = n === "true") : o.value = n;
	return o;
}
function Xo(e) {
	return e.values ?? e.enum ?? [];
}
function Zo(e, t, n, r, i) {
	let a = i ? "local.host.attribute.static" : "local.attribute.static", o = i ? "local.host.attribute" : "local.attribute.static";
	if (t.kind === "string") {
		if (t.dynamic) {
			let t = uo(n.raw);
			if (t) {
				n.dynamic = !0, n.expression = t.expression, n.expressionOffset = n.offset + t.start, t.expression || r.report("local.expression.empty", {
					key: "local.expression.empty.attribute",
					params: { name: e }
				}, n.expressionOffset, void 0);
				return;
			}
		}
		if (t.static) {
			let t = lo(n.raw);
			(t.segments.length || t.unterminated.length) && r.report(o, `Attribute ${e} is static and cannot contain interpolations.`, n.offset, n.offset + n.raw.length, {
				key: a,
				params: { name: e }
			}), n.value = n.raw;
			return;
		}
		if (t.dynamic === !1) {
			let t = lo(n.raw);
			if (t.segments.length || t.unterminated.length) {
				r.report(i ? "local.host.attribute" : "local.attribute.interpolation", `Attribute ${e} does not accept interpolations.`, n.offset, n.offset + n.raw.length, {
					key: "local.attribute.interpolation.dynamic",
					params: { name: e }
				});
				return;
			}
		}
		if (t.pattern !== void 0) {
			let a = lo(n.raw);
			if (a.segments.length > 0 || a.unterminated.length > 0) {
				co(n.raw) || r.report(i ? "local.host.attribute" : "local.attribute.interpolation", `Attribute ${e} must be a literal matching ${t.pattern} or one full interpolation.`, n.offset, n.offset + n.raw.length, {
					key: i ? "local.host.attribute.interpolation" : "local.attribute.interpolation.pattern",
					params: {
						name: e,
						pattern: t.pattern
					}
				}), n.value = n.raw;
				return;
			}
			let o = !0;
			try {
				o = new RegExp(t.pattern).test(n.raw);
			} catch {}
			o || (i ? r.report("local.host.attribute", {
				key: "local.host.attribute.pattern",
				params: {
					name: e,
					pattern: t.pattern
				}
			}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
				key: "local.attribute.type.pattern",
				params: {
					name: e,
					pattern: t.pattern
				}
			}, n.offset, n.offset + n.raw.length)), n.value = n.raw;
			return;
		}
		n.value = n.raw;
		return;
	}
	let s = t.static !== !0 && t.dynamic !== !1 && (t.dynamic === !0 || i);
	if (t.kind === "number") {
		let a = s ? uo(n.raw) : null;
		if (a) {
			n.dynamic = !0, n.expression = a.expression, n.expressionOffset = n.offset + a.start, a.expression || r.report("local.expression.empty", {
				key: "local.expression.empty.attribute",
				params: { name: e }
			}, n.expressionOffset, void 0);
			return;
		}
		let o = Qa(n.raw);
		if (o === null) {
			i ? r.report("local.host.attribute", {
				key: "local.host.attribute.type",
				params: {
					name: e,
					value: n.raw,
					kind: "number"
				}
			}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
				key: t.dynamic ? "local.attribute.type.number-interpolation" : "local.attribute.type.number",
				params: {
					name: e,
					value: n.raw
				}
			}, n.offset, n.offset + n.raw.length);
			return;
		}
		t.integer && !Number.isInteger(o) && (i ? r.report("local.host.attribute", {
			key: "local.attribute.type.integer",
			params: { name: e }
		}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
			key: "local.attribute.type.integer",
			params: { name: e }
		}, n.offset, void 0)), t.positive && !(o > 0) && r.report("local.attribute.type", {
			key: "local.attribute.type.positive",
			params: { name: e }
		}, n.offset, void 0), t.min !== void 0 && o < t.min && (i ? r.report("local.host.attribute", {
			key: "local.attribute.range.min",
			params: {
				name: e,
				min: t.min
			}
		}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.range", {
			key: "local.attribute.range.min",
			params: {
				name: e,
				min: t.min
			}
		}, n.offset, void 0)), t.max !== void 0 && o > t.max && (i ? r.report("local.host.attribute", {
			key: "local.attribute.range.max",
			params: {
				name: e,
				max: t.max
			}
		}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.range", {
			key: "local.attribute.range.max",
			params: {
				name: e,
				max: t.max
			}
		}, n.offset, void 0)), n.value = o;
		return;
	}
	if (t.kind === "boolean") {
		let a = s ? uo(n.raw) : null;
		if (a) {
			n.dynamic = !0, n.expression = a.expression, n.expressionOffset = n.offset + a.start, a.expression || r.report("local.expression.empty", {
				key: "local.expression.empty.attribute",
				params: { name: e }
			}, n.expressionOffset, void 0);
			return;
		}
		if (n.raw === "true" || n.raw === "false") {
			n.value = n.raw === "true";
			return;
		}
		i ? r.report("local.host.attribute", {
			key: "local.host.attribute.type",
			params: {
				name: e,
				value: n.raw,
				kind: "boolean"
			}
		}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
			key: t.dynamic ? "local.attribute.type.boolean-interpolation" : "local.attribute.type.boolean",
			params: { name: e }
		}, n.offset, n.offset + n.raw.length);
		return;
	}
	let c = s ? uo(n.raw) : null;
	if (c) {
		n.dynamic = !0, n.expression = c.expression, n.expressionOffset = n.offset + c.start, c.expression || r.report("local.expression.empty", {
			key: "local.expression.empty.attribute",
			params: { name: e }
		}, n.expressionOffset, void 0);
		return;
	}
	let l = Xo(t);
	l.includes(n.raw) ? n.value = n.raw : i ? r.report("local.host.attribute", {
		key: "local.host.attribute.enum",
		params: {
			name: e,
			values: l.join(" / "),
			value: n.raw
		}
	}, n.offset, n.offset + n.raw.length) : r.report("local.attribute.type", {
		key: "local.attribute.type.enum",
		params: {
			name: e,
			values: l.join(" / "),
			value: n.raw
		}
	}, n.offset, n.offset + n.raw.length);
}
function Qo(e, t) {
	if (!e.legacy) return;
	let n = X(e.kernel), r = n?.kind === "number" ? n.constraints?.step : void 0;
	if (!r || !("prop" in r)) return;
	let i = t.attrs.get(e.node.id) ?? {}, a = r.prop, o = e.kernel.props[a], s = i[a], c = s?.offset ?? Go(t, e.node, a);
	if (s) s.dynamic ? t.report("local.host.attribute", {
		key: "local.host.attribute.static",
		params: { name: a }
	}, c, c + s.raw.length) : typeof s.value == "number" && !(s.value > 0) && t.report("local.host.attribute", {
		key: "local.attribute.type.positive",
		params: { name: a }
	}, c, c + s.raw.length);
	else {
		let n = o?.default;
		typeof n == "number" ? n > 0 || t.report("local.host.attribute", {
			key: "local.attribute.type.positive",
			params: { name: a }
		}, e.node.range.start, e.node.range.end) : t.report("local.host.attribute", {
			key: "local.host.attribute.type",
			params: {
				name: a,
				value: "missing",
				kind: "number"
			}
		}, e.node.range.start, e.node.range.end);
	}
}
function $o(e, t) {
	let n = t.attrs.get(e.node.id) ?? {};
	for (let r of we(e.kernel, n, e.node.range)) t.report(r.code, r.message, r.start, r.end, {
		key: r.key,
		...r.params ? { params: r.params } : {}
	});
}
// src/local/compilation/compiler-tables.ts
function es(e, t, n) {
	let r = (e.children ?? []).filter((e) => e.type === "tableRow");
	if (!r.length) return t.report("local.table.header", {
		key: "local.table.header.missing",
		params: { name: n.name }
	}, e.range.start, e.range.end), null;
	let i = r[0].children ?? [], a = [];
	for (let e of i) {
		if (ao(e)) return t.report("local.table.header", { key: "local.table.header.interpolation" }, e.range.start, e.range.end), null;
		let n = io(e).trim();
		if (!n) return t.report("local.table.header", { key: "local.table.header.empty" }, e.range.start, e.range.end), null;
		if (a.includes(n)) return t.report("local.table.header", {
			key: "local.table.header.duplicate",
			params: { name: n }
		}, e.range.start, e.range.end), null;
		a.push(n);
	}
	if (!a.length) return t.report("local.table.header", { key: "local.table.header.empty" }, e.range.start, e.range.end), null;
	let o = [];
	for (let e of r.slice(1)) {
		let n = e.children ?? [];
		n.length === a.length ? o.push(n) : t.report("local.table.row", {
			key: "local.table.row.mismatch",
			params: {
				header: a.length,
				row: n.length
			}
		}, e.range.start, e.range.end);
	}
	return {
		header: a,
		rows: o
	};
}
function ts(e, t) {
	let n = eo(e.children);
	if (n.length === 1 && n[0].type === "interpolation") {
		let e = t.expressionKinds.get(n[0].id);
		if (e === "number" || e === null) return !0;
		if (e !== void 0) return !1;
	}
	let r = io(e).trim();
	return r ? Qa(r) !== null : !1;
}
function ns(e, t, n, r, i) {
	let a = e.header[t], o = Z(r.kernel, "timeline-table") !== void 0;
	e.rows.forEach((e, r) => {
		let i = e[t];
		if (!i) return;
		let s = eo(i.children);
		if (s.length === 1 && s[0].type === "interpolation") {
			let e = n.expressionKinds.get(s[0].id);
			e != null && e !== "number" && n.report("local.chart.numeric", {
				key: o ? "local.timeline.numeric.expression" : "local.chart.numeric.expression",
				params: {
					name: a,
					row: r + 1,
					kind: oo(e)
				}
			}, i.range.start, i.range.end);
		} else ts(i, n) || n.report("local.chart.numeric", {
			key: o ? "local.timeline.numeric.plain" : "local.chart.numeric.plain",
			params: {
				name: a,
				row: r + 1,
				value: io(i).trim() || "empty"
			}
		}, i.range.start, i.range.end);
	});
}
function rs(e, t) {
	return e.indexOf(t);
}
function is(e) {
	for (let t of e.entries) {
		if (!Z(t.kernel, "single-table")) continue;
		let n = Z(t.kernel, "chart-table"), r = Z(t.kernel, "timeline-table");
		if (!n && !r) {
			as(t, e);
			continue;
		}
		let i = as(t, e);
		i && (n ? cs(t, i, e, n) : r && ls(t, i, e, r));
	}
}
function as(e, t) {
	if (t.tableShapes.has(e.node.id)) return t.tableShapes.get(e.node.id) ?? null;
	let n = t.tables.get(e.node.id), r = n ? es(n, t, e) : null;
	return t.tableShapes.set(e.node.id, r), r;
}
function os(e, t) {
	if (t.size === 0) return;
	let n = Object.create(null), r = 0;
	for (let [e, i] of t) i && (n[e] = Object.freeze({
		header: Object.freeze([...i.header]),
		rowIds: Object.freeze(i.rows.map((e) => Object.freeze(e.map((e) => e.id))))
	}), r += 1);
	r !== 0 && (e.tableShapes = Object.freeze(n));
}
function ss(e) {
	for (let t of e.entries) {
		let n = Z(t.kernel, "table-selection");
		if (!n) continue;
		let r = e.attrs.get(t.node.id) ?? {}, i = r[n.key];
		if (!i) continue;
		let a = typeof i.value == "string" ? i.value.trim() : "";
		if (!a) {
			e.report("local.selection.key", {
				key: "local.selection.key.empty",
				params: { component: t.name }
			}, i.offset, void 0), e.selections.set(t.node.id, [""]);
			continue;
		}
		let o = as(t, e);
		if (!o) {
			e.selections.set(t.node.id, [""]);
			continue;
		}
		let s = rs(o.header, a);
		if (s < 0) {
			e.report("local.selection.key", {
				key: "local.selection.key.missing-column",
				params: {
					component: t.name,
					name: a
				}
			}, i.offset, void 0), e.selections.set(t.node.id, [""]);
			continue;
		}
		let c = [], l = /* @__PURE__ */ new Set();
		o.rows.forEach((n, r) => {
			let i = n[s];
			if (!i) return;
			if (ao(i)) {
				e.report("local.selection.key", {
					key: "local.selection.key.interpolation",
					params: {
						component: t.name,
						name: a,
						row: r + 1
					}
				}, i.range.start, i.range.end);
				return;
			}
			let o = io(i).trim();
			o ? l.has(o) ? e.report("local.selection.key", {
				key: "local.selection.key.duplicate",
				params: {
					component: t.name,
					name: a,
					value: o
				}
			}, i.range.start, i.range.end) : (l.add(o), c.push(o)) : e.report("local.selection.key", {
				key: "local.selection.key.empty-cell",
				params: {
					component: t.name,
					name: a,
					row: r + 1
				}
			}, i.range.start, i.range.end);
		}), e.selections.set(t.node.id, ["", ...c]);
		let u = r.initial;
		u && typeof u.value == "string" && u.value !== "" && !c.includes(u.value) && e.report("local.initial.option", {
			key: "local.selection.key.initial",
			params: {
				value: u.value,
				component: t.name,
				name: a
			}
		}, u.offset, void 0);
	}
}
function cs(e, t, n, r) {
	let i = n.attrs.get(e.node.id) ?? {}, a = typeof i[r.chartKind]?.value == "string" ? String(i[r.chartKind].value) : "bar", o = t.header;
	for (let t of o) t.includes(",") && n.report("local.chart.column", {
		key: "local.chart.column.comma",
		params: { name: t }
	}, e.node.range.start, e.node.range.end);
	let s = typeof i[r.x]?.value == "string" ? String(i[r.x].value).trim() : "", c = typeof i[r.y]?.value == "string" ? String(i[r.y].value).trim() : "";
	s && rs(o, s) < 0 && n.report("local.chart.column", {
		key: "local.chart.column.x-missing",
		params: { name: s }
	}, i[r.x]?.offset ?? e.node.range.start, void 0);
	let l = [];
	if (c) {
		l = c.split(",").map((e) => e.trim()).filter(Boolean), l.length || n.report("local.chart.column", { key: "local.chart.column.y-required" }, i[r.y]?.offset ?? e.node.range.start, void 0);
		for (let t of l) rs(o, t) < 0 && n.report("local.chart.column", {
			key: "local.chart.column.y-missing",
			params: { name: t }
		}, i[r.y]?.offset ?? e.node.range.start, void 0);
	}
	let u = [];
	if (a === "bar" || a === "line" || a === "area") {
		let t = s ? Math.max(0, rs(o, s)) : 0;
		u = l.length ? l.map((e) => rs(o, e)).filter((e) => e >= 0) : o.map((e, t) => t).filter((e) => e !== t), u.length || n.report("local.chart.column", { key: "local.chart.column.needs-numeric" }, e.node.range.start, e.node.range.end);
	} else if (a === "scatter") {
		let r = s ? rs(o, s) : 0;
		r < 0 ? n.report("local.chart.column", {
			key: "local.chart.column.scatter-x-missing",
			params: { name: s }
		}, e.node.range.start, void 0) : ns(t, r, n, e, "x"), u = l.length ? l.map((e) => rs(o, e)).filter((e) => e >= 0) : o.map((e, t) => t).filter((e) => e !== r), u.length || n.report("local.chart.column", { key: "local.chart.column.scatter-needs-numeric" }, e.node.range.start, e.node.range.end);
	} else if (a === "donut" || a === "pie") {
		if (o.length < 2) {
			n.report("local.chart.column", { key: "local.chart.column.donut-columns" }, e.node.range.start, e.node.range.end);
			return;
		}
		if (l.length === 1) {
			let e = rs(o, l[0]);
			e >= 0 && (u = [e]);
		} else l.length > 1 ? n.report("local.chart.column", { key: "local.chart.column.donut-y" }, i[r.y]?.offset ?? e.node.range.start, void 0) : o.length > 2 ? n.report("local.chart.column", { key: "local.chart.column.donut-need-y" }, e.node.range.start, e.node.range.end) : u = [1];
	}
	u = [...new Set(u)];
	for (let r of u) ns(t, r, n, e, "y");
	if (a === "donut" || a === "pie") for (let e of u) t.rows.forEach((t, r) => {
		let i = t[e];
		if (!i || eo(i.children).length) return;
		let a = Qa(io(i).trim());
		a !== null && a < 0 && n.report("local.chart.negative", {
			key: "local.chart.negative",
			params: {
				row: r + 1,
				value: a
			}
		}, i.range.start, i.range.end);
	});
}
function ls(e, t, n, r) {
	let i = r.headerSets.map((e) => ({
		title: e[0] ?? "",
		start: e[1] ?? "",
		duration: e[2] ?? "",
		notes: e[3] ?? ""
	})).find((e) => t.header.includes(e.title) && t.header.includes(e.start) && t.header.includes(e.duration));
	if (!i) {
		n.report("local.timeline.header", { key: "local.timeline.header.missing" }, e.node.range.start, e.node.range.end);
		return;
	}
	let a = new Set(Object.values(i));
	for (let r of t.header) a.has(r) || n.report("local.timeline.header", {
		key: "local.timeline.header.column",
		params: { name: r }
	}, e.node.range.start, e.node.range.end);
	for (let r of [i.start, i.duration]) {
		let i = rs(t.header, r);
		i >= 0 && ns(t, i, n, e, r);
	}
	let o = rs(t.header, i.start), s = rs(t.header, i.duration);
	t.rows.forEach((e, r) => {
		for (let i of [o, s]) {
			if (i < 0) continue;
			let a = e[i];
			if (!a || eo(a.children).length) continue;
			let o = Qa(io(a).trim());
			o !== null && o < 0 && n.report("local.timeline.value", {
				key: "local.timeline.value.negative",
				params: {
					name: t.header[i],
					row: r + 1
				}
			}, a.range.start, a.range.end);
		}
	});
}
// src/local/transport/compiled-data.ts
function us(e, t = !0) {
	let n = /* @__PURE__ */ new WeakMap(), r = [], i = (e) => {
		if (typeof e != "object" || !e) return e;
		let t = n.get(e);
		if (t) return t;
		let i = Array.isArray(e) ? Array(e.length) : {};
		return n.set(e, i), r.push({
			input: e,
			output: i
		}), i;
	}, a = i(e);
	for (; r.length;) {
		let { input: e, output: n } = r.pop();
		for (let [t, r] of Object.entries(e)) Object.defineProperty(n, t, {
			value: i(r),
			enumerable: !0,
			configurable: !0,
			writable: !0
		});
		t && Object.isFrozen(e) && Object.freeze(n);
	}
	return a;
}
// src/local/compilation/compiler-bindings.ts
var ds = 4, fs = 3, ps = /* @__PURE__ */ new Set([
	"x",
	"y",
	"true",
	"false",
	"null",
	"pi",
	"e"
]);
function ms(e, t, n, r) {
	t.required && !Object.hasOwn(n, t.bind) && r.report("local.attribute.required", {
		key: "local.attribute.required",
		params: {
			component: e.name,
			name: t.bind
		}
	}, e.node.range.start, e.node.range.end);
}
function hs(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.entries) {
		let r = X(n.kernel);
		if (!r) continue;
		let i = e.attrs.get(n.node.id) ?? {};
		if (r.requiresAttributes?.some((e) => !Object.hasOwn(i, e))) continue;
		ms(n, r, i, e);
		let a = typeof i[r.bind]?.value == "string" ? String(i[r.bind].value) : "", o = a || `@${n.node.id}`;
		if (Object.hasOwn(i, r.bind)) {
			let t = i[r.bind].offset ?? n.node.range.start;
			a.length > 128 ? (e.report("local.budget.identifier", {
				key: "local.budget.identifier",
				params: { limit: 128 }
			}, t, void 0), o = `@${n.node.id}`) : so.test(a) ? (E.has(a) || ps.has(a)) && (e.report("local.binding.reserved", {
				key: "local.binding.reserved",
				params: { name: a }
			}, t, void 0), o = `@${n.node.id}`) : (e.report("local.binding.name", {
				key: "local.binding.name",
				params: { name: a }
			}, t, void 0), o = `@${n.node.id}`);
		}
		let s = t.get(o);
		s ? s.members.push({
			entry: n,
			attrs: i
		}) : t.set(o, {
			key: o,
			binding: r,
			members: [{
				entry: n,
				attrs: i
			}]
		});
	}
	let n = {};
	for (let r of t.values()) {
		let t = r.binding.family, i = e.semantic && t !== "checklist" ? JSON.stringify([r.key, r.members.map(({ entry: n }) => [
			n.name,
			n.node.id,
			n.node.attrs,
			Ss(n, e, n.kernel, t)
		])]) : void 0, a = i ? e.semantic.binding(i) : void 0, o = e.diagnostics.length, s = a ? us(a) : bs(r, e);
		!a && s && i && o < 100 && e.diagnostics.length === o && e.semantic.rememberBinding(i, us(s)), s && (n[r.key] = s);
	}
	return n;
}
function gs(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) n.startsWith("@") || (t[n] = r.type);
	return t;
}
var _s = Oe, vs = Pe;
function ys(e, t) {
	let n = e.attrs[t];
	if (n) return n.dynamic ? `{{ ${(n.expression ?? "").trim()} }}` : typeof n.value == "string" ? n.value : String(n.value ?? "");
}
function bs(e, t) {
	let n = e.members[0], r = e.binding, i = r.family;
	for (let a of e.members.slice(1)) {
		let o = X(a.entry.kernel);
		o && o.family === i && o.kind === r.kind || t.report("local.binding.type", {
			key: "local.binding.type",
			params: {
				key: e.key,
				kind: oo(r.kind),
				first: n.entry.name,
				second: a.entry.name
			}
		}, a.entry.node.range.start, a.entry.node.range.end);
	}
	let a = e.members.find((e) => X(e.entry.kernel)?.exclusive === !0);
	if (a && e.members.length > 1) for (let n of e.members) n !== a && t.report("local.binding.exclusive", {
		key: "local.binding.exclusive",
		params: {
			key: e.key,
			first: a.entry.name,
			second: n.entry.name
		}
	}, n.entry.node.range.start, n.entry.node.range.end);
	let o = Ss(n.entry, t, n.entry.kernel, i), s;
	if (r.kind === "number") {
		s = go(n.entry, n.attrs);
		for (let r of e.members.slice(1)) {
			let i = go(r.entry, r.attrs);
			_s(i, s, "min") && _s(i, s, "max") && i.step === s.step || t.report("local.binding.constraint", {
				key: "local.binding.constraint",
				params: {
					key: e.key,
					first: n.entry.name,
					second: r.entry.name,
					firstConstraints: vs(s),
					secondConstraints: vs(i)
				}
			}, r.entry.node.range.start, r.entry.node.range.end);
		}
	}
	if (i === "choice" || i === "selection") for (let n of e.members.slice(1)) Ss(n.entry, t, n.entry.kernel, i).join("\0") !== o.join("\0") && t.report("local.binding.option", {
		key: "local.binding.option",
		params: { key: e.key }
	}, n.entry.node.range.start, n.entry.node.range.end);
	let c = new Set(r.compare ?? []);
	for (let e of Ne(n.entry.kernel)) e.kind === "date-bounds" && (e.min && c.add(e.min), e.max && c.add(e.max));
	for (let r of c) {
		let i = ys(n, r);
		for (let a of e.members.slice(1)) ys(a, r) !== i && t.report("local.binding.constraint", {
			key: "local.binding.constraint",
			params: {
				key: e.key,
				first: n.entry.name,
				second: a.entry.name,
				firstConstraints: `${r} bounds`,
				secondConstraints: `${r} bounds`
			}
		}, a.entry.node.range.start, a.entry.node.range.end);
	}
	let l = r.maxItems ? Te(n.entry.kernel, r, n.attrs) : void 0, u = e.members.filter((e) => Object.hasOwn(e.attrs, r.initial)), d;
	if (u.length > 1) {
		let n = u.map((e) => xs(t, e.attrs[r.initial].offset)), i = Math.min(u.length, ds);
		for (let a = 0; a < i; a += 1) {
			let i = [];
			for (let e = 1; e < n.length && i.length < fs; e += 1) i.push(n[(a + e) % n.length]);
			t.report("local.initial.duplicate", i.length ? {
				key: "local.initial.duplicate-peers",
				params: {
					key: e.key,
					count: u.length,
					lines: i.join(", ")
				}
			} : {
				key: "local.initial.duplicate",
				params: {
					key: e.key,
					count: u.length
				}
			}, u[a].attrs[r.initial].offset, void 0);
		}
	}
	d = i === "multi-select" ? u.length ? ws(u[0], o, l, t, r) : [] : i === "collection" ? u.length ? Cs(u[0], t, r) : [] : u.length > 0 ? Ts(u[0], t, r, o) : Es(n, t, r, o, s), i === "checklist" && !Array.isArray(d) && (d = []), vo(e, n, d, r, o, s, t), _o(e, d, t);
	let f = {
		family: r.family,
		name: e.key,
		nodeIds: e.members.map((e) => e.entry.node.id),
		type: r.kind,
		initial: ho(d),
		owner: n.entry.node.id
	};
	return s && (s.min !== void 0 && (f.min = s.min), s.max !== void 0 && (f.max = s.max), f.step = s.step), o.length && (f.options = [...o]), i === "multi-select" ? f.maxItems = l ?? o.length : l !== void 0 && (f.maxItems = l), f;
}
function xs(e, t) {
	let n = Math.max(0, Math.min(e.source.length, t)), r = 0, i = e.lineStarts.length - 1;
	for (; r < i;) {
		let t = Math.ceil((r + i) / 2);
		e.lineStarts[t] <= n ? r = t : i = t - 1;
	}
	return r + 1;
}
function Ss(e, t, n, r) {
	let i = Ee(r);
	if (!i) return [];
	if (i === "checklist") {
		let r = Z(n, "checklist-body")?.itemLimit;
		return Io(e, t, r).ids;
	}
	if (i === "selection") return t.selections.get(e.node.id) ?? [""];
	let a = bo(t, i).get(e.node.id);
	return a === void 0 ? [...X(n)?.options ?? []] : a;
}
function Cs(e, t, n) {
	let r = e.attrs[n.initial];
	if (!r) return [];
	let i = typeof r.value == "string" ? r.value : String(r.value ?? ""), a;
	try {
		a = JSON.parse(i);
	} catch {
		return t.report("local.initial.type", {
			key: "local.initial.type.collection",
			params: { key: e.entry.node.id }
		}, r.offset, void 0), [];
	}
	return Array.isArray(a) ? n.kind === "number-array" ? a.every((e) => typeof e == "number" && Number.isFinite(e)) ? a : (t.report("local.initial.type", {
		key: "local.initial.type.number-array",
		params: { key: e.entry.node.id }
	}, r.offset, void 0), []) : a.every((e) => typeof e == "string") ? a : (t.report("local.initial.type", {
		key: "local.initial.type.array",
		params: { key: e.entry.node.id }
	}, r.offset, void 0), []) : (t.report("local.initial.type", {
		key: "local.initial.type.collection",
		params: { key: e.entry.node.id }
	}, r.offset, void 0), []);
}
function ws(e, t, n, r, i) {
	let a = e.attrs[i.initial];
	if (!a) return [];
	let o = typeof a.value == "string" ? a.value : String(a.value ?? ""), s = [];
	for (let n of o.split(",").map((e) => e.trim()).filter(Boolean)) t.includes(n) ? s.includes(n) || s.push(n) : r.report("local.initial.option", {
		key: "local.initial.option.multi-select",
		params: {
			key: e.entry.node.id,
			value: n
		}
	}, a.offset, void 0);
	return n !== void 0 && s.length > n && r.report("local.initial.range", {
		key: "local.initial.multi-select",
		params: { max: n }
	}, a.offset, void 0), t.filter((e) => s.includes(e));
}
function Ts(e, t, n, r) {
	let i = e.attrs[n.initial], a = e.entry, o = go(a, e.attrs);
	if (!i) return Es(e, t, n, r, void 0);
	if (n.kind === "null") return i.raw.trim() !== "null" && t.report("local.initial.type", {
		key: "local.initial.type",
		params: { name: a.node.id }
	}, i.offset, void 0), null;
	if (a.legacy) {
		let e = lo(i.raw);
		if (e.segments.length || e.unterminated.length) {
			t.report("local.host.attribute", {
				key: "local.host.attribute.static",
				params: { name: n.initial }
			}, i.offset, i.offset + i.raw.length);
			let e = Me(n.initialRule, o, r);
			return "value" in e ? e.value : "";
		}
	}
	if (n.kind === "number") return typeof i.value == "number" ? i.value : (t.report("local.initial.type", {
		key: "local.initial.type",
		params: { name: a.node.id }
	}, i.offset, void 0), 0);
	if (n.kind === "boolean") return typeof i.value == "boolean" ? i.value : (t.report("local.initial.type", {
		key: "local.initial.type",
		params: { name: a.node.id }
	}, i.offset, void 0), !1);
	let s = typeof i.value == "string" ? i.value : String(i.value ?? "");
	return W(a.kernel).some((e) => e.kind === "date") && !ke(s) && t.report("local.initial.date", {
		key: "local.initial.date",
		params: { value: s }
	}, i.offset, void 0), r.length && !r.includes(s) && n.family !== "text" && n.family !== "date" && t.report("local.initial.option", {
		key: "local.initial.value.option",
		params: {
			value: s,
			options: r.join(", ")
		}
	}, i.offset, void 0), s;
}
function Es(e, t, n, r, i) {
	let a = e.entry;
	if (n.kind === "null") return null;
	if (n.family === "checklist") return [...Io(a, t, Z(a.kernel, "checklist-body")?.itemLimit).checked];
	let o = i ?? go(a, e.attrs), s = Me(n.initialRule, o, r);
	return "value" in s && s.value !== void 0 ? s.value : "error" in s && s.error === "no-step" ? (t.report("local.initial.range", {
		key: "local.initial.no-step",
		params: {
			key: a.node.id,
			min: o.min ?? "-∞",
			max: o.max ?? "∞"
		}
	}, a.node.range.start, a.node.range.end), 0) : (t.report("local.initial", {
		key: "local.initial.cannot-derive",
		params: {
			name: a.name,
			key: a.node.id
		}
	}, a.node.range.start, a.node.range.end), "");
}
// src/local/compilation/compiler-declarations.ts
function Ds(e, t) {
	let n = new Set(Object.keys(t)), r = /* @__PURE__ */ new Map();
	for (let [e, n] of Object.entries(t)) for (let t of n.nodeIds) r.set(t, e);
	for (let i of e.entries) {
		let a = De(i.kernel);
		if (!a.length) continue;
		let o = e.attrs.get(i.node.id) ?? {}, s = Object.create(null), c = /* @__PURE__ */ new Map(), l = X(i.kernel);
		if (l && !l.requiresAttributes?.some((e) => !Object.hasOwn(o, e))) {
			let e = r.get(i.node.id);
			e && (s.value = e, c.set("value", e));
		}
		for (let r of a) {
			if (r.requiresAttributes?.some((e) => !Object.hasOwn(o, e))) continue;
			ms(i, r, o, e);
			let a = o[r.bind], l;
			if (a) {
				let t = typeof a.value == "string" ? a.value : "";
				t.length > 128 ? e.report("local.budget.identifier", {
					key: "local.budget.identifier",
					params: { limit: 128 }
				}, a.offset ?? i.node.range.start, void 0) : so.test(t) ? E.has(t) || ps.has(t) ? e.report("local.binding.reserved", {
					key: "local.binding.reserved",
					params: { name: t }
				}, a.offset ?? i.node.range.start, void 0) : l = t : e.report("local.binding.name", {
					key: "local.binding.name",
					params: { name: t }
				}, a.offset ?? i.node.range.start, void 0);
			}
			let u = l ?? `@${i.node.id}:${r.slot}`;
			l && n.has(l) && (e.report("local.binding.exclusive", {
				key: "local.binding.exclusive.slot",
				params: {
					key: l,
					slot: r.slot,
					name: i.name
				}
			}, a?.offset ?? i.node.range.start, void 0), u = `@${i.node.id}:${r.slot}`), n.add(u);
			let d = Ae(i.kernel, r, o), f = Os(i, o, r, d, e), p = {
				name: u,
				nodeIds: [i.node.id],
				type: r.kind,
				initial: f,
				owner: i.node.id
			};
			d.min !== void 0 && (p.min = d.min), d.max !== void 0 && (p.max = d.max), p.step = d.step, t[u] = p, s[r.slot] = u, c.set(r.slot, u);
		}
		for (let n of Ce(i.kernel)) {
			let r = c.get(n.lower), a = c.get(n.upper);
			if (!r || !a) continue;
			let o = t[r].initial, s = t[a].initial;
			typeof o == "number" && typeof s == "number" && o > s && e.report("local.initial.range", {
				key: "local.initial.range-slider",
				params: {
					start: o,
					end: s
				}
			}, i.node.range.start, i.node.range.end);
		}
		Object.keys(s).length && (e.bindingSlots[i.node.id] = s);
	}
}
function Os(e, t, n, r, i) {
	let a = r.min ?? 0, o = t[n.initial];
	if (o && typeof o.value == "number") {
		let t = o.value;
		return r.min !== void 0 && t < r.min && i.report("local.initial.range", {
			key: "local.initial.slot.min",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				min: r.min
			}
		}, o.offset, void 0), r.max !== void 0 && t > r.max && i.report("local.initial.range", {
			key: "local.initial.slot.max",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				max: r.max
			}
		}, o.offset, void 0), Fe(t, a, r.step) || i.report("local.initial.step", {
			key: "local.initial.slot.step",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				step: r.step,
				base: a
			}
		}, o.offset, void 0), t;
	}
	let s = Me(n.initialRule, r, []);
	return "value" in s && s.value !== void 0 ? s.value : 0;
}
function ks(e) {
	return Object.keys(e.bindingSlots).length ? e.bindingSlots : void 0;
}
function As(e, t) {
	let n = e.lineStarts[xs(e, t.range.start) - 1], r = e.lineStarts[xs(e, t.range.end)], i = r === void 0 ? e.source.length : r - 1;
	return e.source.slice(n, t.range.start).trim() === "" && e.source.slice(t.range.end, i).trim() === "";
}
function js(e, t, n) {
	let r = Wo(e.source, t.node.range.start, t.node.range.end), i = /(?:^|[\s"'/])value\s*=\s*(["'])/.exec(r);
	if (!i) return t.node.range.start;
	let a = t.node.range.start + i.index + i[0].length;
	return Math.min(t.node.range.end, a + n);
}
function Ms(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = new Set(e.nodes);
	for (let i of e.entries) {
		if (i.name !== "computed" && i.name !== "const") continue;
		let a = i.name, o = i.node;
		if (!r.has(o) || !As(e, o)) {
			e.report("local.computation.placement", `<${a}> declarations must be standalone tags at the document top level.`, o.range.start, o.range.end);
			continue;
		}
		let s = e.attrs.get(o.id) ?? {}, c = s.name, l = typeof c?.value == "string" ? c.value : "";
		if (!c || !l) continue;
		if (l.length > 128) {
			e.report("local.budget.identifier", "Computation name exceeds the 128-character limit.", c.offset);
			continue;
		}
		if (!so.test(l)) {
			e.report("local.computation.name", `Computation name "${l}" must match [A-Za-z_][A-Za-z0-9_]*.`, c.offset);
			continue;
		}
		if (E.has(l) || ps.has(l)) {
			e.report("local.computation.reserved", `Computation name "${l}" is reserved; choose another name.`, c.offset);
			continue;
		}
		if (Object.hasOwn(e.bindingKinds, l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" conflicts with a control parameter of the same name.`, c.offset);
			continue;
		}
		if (Object.hasOwn(e.externalKinds, l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" conflicts with an external declaration of the same name.`, c.offset);
			continue;
		}
		if (n.has(l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" is declared more than once.`, c.offset);
			continue;
		}
		n.set(l, a);
		let u = s.value;
		if (!u) continue;
		let d = uo(u.raw);
		d ? d.expression ? t.push({
			name: l,
			kind: a,
			source: d.expression,
			expressionOffset: js(e, i, d.start),
			nodeId: o.id,
			range: { ...o.range }
		}) : e.report("local.expression.empty", "Interpolation expression cannot be empty.", u.offset) : e.report("local.computation.value", `The value of <${a}> must be exactly one {{ expression }} interpolation.`, u.offset, u.offset + u.raw.length);
	}
	let i = U(t, {
		...e.bindingKinds,
		...e.externalKinds
	}, e.report, new Set(Object.keys(e.externalKinds)), e.semantic);
	e.computations = i.computations, e.computationKinds = i.kinds;
}
function Ns(e) {
	let t = [], n = [{
		nodes: e,
		kept: t,
		index: 0
	}];
	for (; n.length;) {
		let e = n[n.length - 1];
		if (e.index === e.nodes.length) {
			n.pop();
			continue;
		}
		let t = e.nodes[e.index++];
		if ((t.type !== "component" || t.name !== "computed" && t.name !== "const" && t.name !== "external") && (e.kept.push(t), t.children)) {
			let e = t.children;
			t.children = [], n.push({
				nodes: e,
				kept: t.children,
				index: 0
			});
		}
	}
	return t;
}
var Ps = {
	string: "string",
	number: "number",
	boolean: "boolean",
	"string-array": "array",
	"number-array": "number-array"
};
function Fs(e) {
	let t = new Set(e.nodes);
	for (let n of e.entries) {
		if (n.name !== "external") continue;
		let r = n.node;
		if (!t.has(r) || !As(e, r)) {
			e.report("local.external.placement", { key: "local.external.placement" }, r.range.start, r.range.end);
			continue;
		}
		let i = e.attrs.get(r.id) ?? {}, a = i.name, o = typeof a?.value == "string" ? a.value : "";
		if (!a || !o) continue;
		if (o.length > 128) {
			e.report("local.budget.identifier", {
				key: "local.budget.identifier",
				params: { limit: 128 }
			}, a.offset, void 0);
			continue;
		}
		if (!so.test(o)) {
			e.report("local.external.name", {
				key: "local.external.name",
				params: { name: o }
			}, a.offset, void 0);
			continue;
		}
		if (E.has(o) || ps.has(o)) {
			e.report("local.external.reserved", {
				key: "local.external.reserved",
				params: { name: o }
			}, a.offset, void 0);
			continue;
		}
		if (Object.hasOwn(e.bindingKinds, o)) {
			e.report("local.external.duplicate", {
				key: "local.external.conflict",
				params: { name: o }
			}, a.offset, void 0);
			continue;
		}
		if (Object.hasOwn(e.externals, o)) {
			e.report("local.external.duplicate", {
				key: "local.external.duplicate",
				params: { name: o }
			}, a.offset, void 0);
			continue;
		}
		let s = i.type, c = Ps[typeof s?.value == "string" ? s.value : ""];
		c ? (e.externals[o] = {
			name: o,
			type: c,
			nodeId: r.id,
			range: { ...r.range }
		}, e.externalKinds[o] = c) : e.report("local.external.type", {
			key: "local.external.type",
			params: { name: o }
		}, s?.offset ?? r.range.start, void 0);
	}
}
function Is(e) {
	for (let t of e.entries) {
		let n = e.attrs.get(t.node.id) ?? {}, r, i = (e, t, n) => {
			t.dynamic && t.expression !== void 0 && (r ??= {}, r[e] = {
				source: t.expression,
				offset: t.expressionOffset ?? t.offset,
				...n ? { numeric: n } : {}
			});
		};
		for (let e of je(t.kernel, "dynamic-constraints")) for (let t of e.attributes) if (t === "min" || t === "max" || t === "required") {
			let e = n[t];
			e && i(t, e);
		}
		let a = X(t.kernel);
		if (a?.kind === "number" && a.constraints) for (let e of ["min", "max"]) {
			let r = a.constraints[e];
			if (!r || !("prop" in r)) continue;
			let o = n[r.prop];
			if (!o) continue;
			let s = t.kernel.props[r.prop];
			i(e, o, s ? {
				...s.min === void 0 ? {} : { min: s.min },
				...s.max === void 0 ? {} : { max: s.max },
				...s.integer === !0 ? { integer: !0 } : {}
			} : void 0);
		}
		r && (e.dynamicConstraints[t.node.id] = r);
	}
}
// src/local/parsing/heading-anchors.ts
function Ls(e, t) {
	return (e ?? []).map((e) => {
		switch (e.type) {
			case "text":
			case "inlineCode":
			case "inlineMath":
			case "fallback": return e.value ?? "";
			case "image": return e.alt ?? "";
			case "break": return " ";
			case "interpolation": try {
				let n = D(e.value ?? "").evaluate(t);
				return Array.isArray(n) ? "Cannot compute" : n === null ? "" : String(n);
			} catch {
				return "Cannot compute";
			}
			default: return Ls(e.children, t);
		}
	}).join("");
}
function Rs(e) {
	return e.trim().toLowerCase().replace(/[^\p{L}\p{N}\p{M}\s_-]/gu, "").replace(/\s+/g, "-") || "section";
}
function zs(e, t) {
	let n = /* @__PURE__ */ new Map(), r = t ?? (Array.isArray(e.componentDefinitions) ? e.componentDefinitions : []);
	for (let e of r.slice(0, 192)) {
		if (!e || typeof e.name != "string" || !Array.isArray(e.rules)) continue;
		let t = e.rules.find((e) => e?.kind === "anchor");
		t?.kind === "anchor" && n.set(e.name, t.id);
	}
	return n;
}
function Bs(e, t) {
	if (e.type !== "component" && e.type !== "hostComponent") return;
	let n = t.get(e.name ?? "");
	if (n === void 0) return;
	let r = e.attrs?.[n];
	if (typeof r == "string" && r.length !== 0) return /^[A-Za-z_][A-Za-z0-9_-]*$/.test(r) ? r : void 0;
}
function Vs(e) {
	if (e.type === "component" || e.type === "hostComponent") return;
	let t = e.attrs?.id;
	if (typeof t != "string") return;
	let n = t.trim().replace(/[\u0000- \u007f-\u009f]+/g, "-").replace(/^-+|-+$/g, "");
	return n === "" ? void 0 : n;
}
function Hs(e, t, n = !0, r) {
	let i = zs(e, r), a = e.initialState;
	if (e.computations) {
		let t = {}, n = /* @__PURE__ */ new Map();
		for (let [r, i] of Object.entries(e.computations)) {
			i.kind === "const" && Object.hasOwn(i, "value") && (t[r] = i.value);
			try {
				n.set(r, D(i.source));
			} catch {}
		}
		let { order: r } = me(e.computations), i = K(e.computations, r, n, a, t);
		a = {
			...a,
			...i.values
		};
	}
	let o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map();
	function d(e) {
		let n = e, r = u.get(e) ?? 0;
		for (; l.has(n);) r += 1, n = `${e}-${r}`;
		u.set(e, r);
		let i = `${t}-${n}`;
		return l.set(n, i), {
			slug: n,
			id: i
		};
	}
	for (let t of S(e.nodes)) if (t.type === "heading") {
		let e = Vs(t) ?? Rs(Ls(t.children, a));
		o.set(t, d(e).id);
	} else {
		if (n) {
			let e = Bs(t, i);
			e && s.set(t, d(e).id);
		}
		let e = Vs(t);
		e && c.set(t, d(e).id);
	}
	function f(e) {
		if (e.length === 0) return;
		let t = l.get(e);
		if (t) return t;
		try {
			return l.get(decodeURIComponent(e));
		} catch {
			return;
		}
	}
	return {
		ids: o,
		anchorIds: s,
		htmlIds: c,
		targetId(e) {
			return f(e);
		},
		referenceId(e) {
			return f(e) ?? `${t}-${e}`;
		},
		resolve(e) {
			if (!e.startsWith("#")) return e;
			let t = f(e.slice(1));
			return t ? `#${t}` : e;
		}
	};
}
// src/local/compilation/compiler-expressions.ts
function Us(e) {
	let t = mo(e), n = Object.keys(t), r = (t, n) => {
		t instanceof C ? e.report(`local.expression.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0), void 0, {
			key: "local.expression.error",
			params: {
				detail: t.message,
				code: t.code || "invalid",
				near: e.source.slice(Math.max(n, n + t.offset - 16), n + t.offset + 24)
			}
		}) : e.report("local.expression.invalid", {
			key: "local.expression.error",
			params: {
				detail: t instanceof Error ? t.message : String(t),
				code: "invalid"
			}
		}, n, void 0);
	}, i = (i, a, o) => {
		if (!i.trim()) return e.report("local.expression.empty", { key: "local.expression.empty" }, a, void 0), null;
		let s = null;
		try {
			s = e.semantic?.expression(i) ?? D(i);
		} catch (e) {
			return r(e, a), null;
		}
		if (!s) return null;
		let c = !1;
		for (let r of s.dependencies) if (!Object.hasOwn(t, r)) {
			let t = fo(r, n);
			e.report("local.binding.unknown", t ? {
				key: "local.binding.unknown.suggestion",
				params: {
					name: r,
					suggestion: t
				}
			} : {
				key: "local.binding.unknown",
				params: { name: r }
			}, a + Math.max(0, i.indexOf(r)), void 0), c = !0;
		}
		if (c) return null;
		let l;
		try {
			l = e.semantic ? e.semantic.infer(s, t) : s.inferType(t);
		} catch (e) {
			return r(e, a), null;
		}
		return o === "number" && l !== "number" ? e.report("local.type", {
			key: "local.type.number",
			params: { kind: oo(l) }
		}, a, void 0) : o === "boolean" && l !== "boolean" ? e.report("local.type", {
			key: "local.type.boolean",
			params: { kind: oo(l) }
		}, a, void 0) : o === "string" && l !== "string" ? e.report("local.type", {
			key: "local.type.string",
			params: { kind: oo(l) }
		}, a, void 0) : o === "text" && (l === "array" || l === "number-array") && e.report("local.type", { key: "local.type.array" }, a, void 0), l;
	};
	for (let t of S(e.nodes)) if (t.type === "interpolation") {
		let n = e.source.slice(t.range.start + 2, Math.max(t.range.start + 2, t.range.end - 2)), r = t.value ?? "", a = Math.max(0, n.indexOf(r)), o = t.range.start + 2 + a;
		e.expressionKinds.set(t.id, i(r, o, "text"));
	}
	for (let t of e.entries) {
		if (t.name === "computed" || t.name === "const") continue;
		let n = e.attrs.get(t.node.id) ?? {}, r = /* @__PURE__ */ new Set(), a = /* @__PURE__ */ new Set();
		for (let e of Ne(t.kernel)) if (e.kind === "scoped-expressions") for (let t of e.attributes) r.add(t);
		else if (e.kind === "row-values") r.add(e.rows), r.add(e.key);
		else if (e.kind === "validation-rule") r.add(e.when);
		else if (e.kind === "require-full-interpolation") for (let t of e.attributes) a.add(t);
		for (let [a, o] of Object.entries(n)) {
			let n = t.kernel.props[a];
			if (n && !n.static && !r.has(a)) {
				if (n.kind === "string") {
					if (n.dynamic) {
						o.dynamic && i(o.expression ?? "", o.expressionOffset ?? o.offset, "string");
						continue;
					}
					let t = lo(o.raw);
					for (let n of t.unterminated) e.report("local.interpolation", { key: "local.interpolation.unclosed" }, o.offset + n, void 0);
					for (let e of t.segments) i(e.expression, o.offset + e.start, "text");
				} else o.dynamic && (n.kind === "number" ? i(o.expression ?? "", o.expressionOffset ?? o.offset, "number") : n.kind === "boolean" ? i(o.expression ?? "", o.expressionOffset ?? o.offset, "boolean") : n.kind === "enum" && i(o.expression ?? "", o.expressionOffset ?? o.offset, "string"));
			}
		}
		for (let r of a) {
			let i = n[r];
			i && !co(i.raw) && e.report("local.attribute.interpolation", {
				key: "local.attribute.interpolation",
				params: {
					name: r,
					component: t.name
				}
			}, i.offset, void 0);
		}
	}
}
function Ws(e, t, n) {
	let r = {
		syntax: "local",
		source: e.source,
		nodes: e.nodes,
		initialState: n,
		bindings: t,
		...Object.keys(e.computations).length ? { computations: e.computations } : {}
	}, i = "__local_core_check__", a = Hs(r, i, !1), o = /* @__PURE__ */ new Set();
	for (let t of S(e.nodes)) if (t.type === "heading") {
		let e = a.ids.get(t);
		e && e.startsWith(`${i}-`) && o.add(e.slice(21));
	}
	let s = /* @__PURE__ */ new Set();
	for (let t of e.entries) {
		let n = Z(t.kernel, "anchor");
		if (!n) continue;
		let r = (e.attrs.get(t.node.id) ?? {})[n.id];
		if (!r) continue;
		let i = typeof r.value == "string" ? r.value : "";
		!i || !ue(i) ? e.report("local.anchor.id", {
			key: "local.anchor.id",
			params: { id: i }
		}, r.offset, void 0) : (s.has(i) ? e.report("local.anchor.duplicate", {
			key: "local.anchor.duplicate",
			params: { id: i }
		}, r.offset, void 0) : s.add(i), o.has(i) && e.report("local.anchor.duplicate", {
			key: "local.anchor.heading-collision",
			params: { id: i }
		}, r.offset, void 0));
	}
	let c = [];
	for (let t of e.entries) {
		let n = Z(t.kernel, "navigation");
		if (!n) continue;
		let r = (e.attrs.get(t.node.id) ?? {})[n.target];
		r && c.push({
			name: t.name,
			target: typeof r.value == "string" ? r.value : "",
			offset: r.offset
		});
	}
	for (let t of q(c, s, o)) e.report(t.code, t.message, t.start, t.end, {
		key: t.key,
		...t.params ? { params: t.params } : {}
	});
}
function Gs(e, t, n) {
	t instanceof C ? e.report(`local.expression.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0)) : e.report("local.expression.invalid", `Expression error: ${t instanceof Error ? t.message : String(t)}`, n);
}
function Ks(e, t, n, r, i) {
	if (!t.trim()) return e.report("local.expression.empty", "Interpolation expression cannot be empty.", n), null;
	let a;
	try {
		a = e.semantic?.expression(t) ?? D(t);
	} catch (t) {
		return Gs(e, t, n), null;
	}
	let o = Object.keys(r), s = !1;
	for (let i of a.dependencies) if (!Object.hasOwn(r, i)) {
		let r = fo(i, o);
		e.report("local.binding.unknown", `Reference to undeclared parameter ${i}.${r ? ` Did you mean ${r}?` : ""}`, n + Math.max(0, t.indexOf(i))), s = !0;
	}
	if (s || !i) return {
		compiled: a,
		kind: null
	};
	let c;
	try {
		c = e.semantic ? e.semantic.infer(a, r) : a.inferType(r);
	} catch (t) {
		return Gs(e, t, n), null;
	}
	return {
		compiled: a,
		kind: c
	};
}
function qs(e, t, n, r, i) {
	if (!e) return null;
	let a = uo(e.raw);
	return a ? a.expression ? {
		expression: a.expression,
		base: e.offset + a.start
	} : (i.report("local.expression.empty", "Interpolation expression cannot be empty.", e.offset + a.start), null) : (i.report(t, `<${n}> ${r} must be exactly one {{ expression }} interpolation.`, e.offset, e.offset + e.raw.length), null);
}
function Js(e, t) {
	let n = e[t.maxRows], r = Math.min(t.defaultMaxRows, i);
	return n && !n.dynamic && typeof n.value == "number" && Number.isInteger(n.value) && n.value > 0 && n.value <= 1e3 ? n.value : r;
}
// src/local/compilation/compiler-validation.ts
function Ys(e) {
	let t = [];
	for (let n of e.entries) {
		let e = Z(n.kernel, "data-table");
		e && t.push([n, e]);
	}
	if (!t.length) return;
	let n = mo(e), r = 0, i = 0, a = !1, o = !1;
	for (let [s, l] of t) {
		let t = e.attrs.get(s.node.id) ?? {}, u = eo(s.node.children).filter((e) => (e.type === "component" || e.type === "hostComponent") && e.name === l.child), d = Js(t, l), p = Math.min(l.maxColumns, 20), m = Math.min(l.documentRows, f), h = Math.min(l.documentCells, c), g = Math.min(u.length, p);
		r += d, i += d * g, !a && r > m && (a = !0, e.report("local.budget.data-table.rows", `The document's generated row budget exceeds ${m}; ${l.maxRows} summed over every <${s.name}> must stay within it.`, s.node.range.start, s.node.range.end)), !o && i > h && (o = !0, e.report("local.budget.data-table.cells", `The document's generated cell budget exceeds ${h}; ${l.maxRows} multiplied by columns, summed over every <${s.name}>, must stay within it.`, s.node.range.start, s.node.range.end));
		let _ = qs(t[l.rows], "local.data-table.rows", s.name, l.rows, e), v = "string", y = !1;
		if (_) {
			let t = Ks(e, _.expression, _.base, n, !0);
			t?.kind === "array" ? (v = "string", y = !0) : t?.kind === "number-array" ? (v = "number", y = !0) : t && t.kind !== null && e.report("local.data-table.rows", `<${s.name}> ${l.rows} must evaluate to an array, but the expression evaluates to ${oo(t.kind)}.`, _.base);
		}
		let b = {
			...n,
			item: v,
			index: "number"
		}, x = qs(t[l.key], "local.data-table.key", s.name, l.key, e);
		if (x) {
			let t = Ks(e, x.expression, x.base, b, y);
			if (t) {
				let r = t.compiled.dependencies;
				r.includes("item") || e.report("local.data-table.key", `<${s.name}> key must depend on item.`, x.base);
				for (let t of r) t !== "item" && (t === "index" ? e.report("local.data-table.key", `<${s.name}> key cannot depend on index; use a stable item identifier.`, x.base) : Object.hasOwn(n, t) && e.report("local.data-table.key", `<${s.name}> key cannot depend on global parameter "${t}"; it must be derived from item only.`, x.base));
				t.kind !== null && t.kind !== "string" && t.kind !== "number" && e.report("local.data-table.key", `<${s.name}> key must evaluate to a string or number, got ${oo(t.kind)}.`, x.base);
			}
		}
		for (let t of u) {
			let n = e.attrs.get(t.id) ?? {}, r = n[l.label];
			r && !String(r.value ?? "").trim() && e.report("local.data-table.column", `<${l.child}> ${l.label} cannot be empty.`, r.offset);
			let i = qs(n[l.childValue], "local.data-table.value", l.child, l.childValue, e);
			if (!i) continue;
			let a = Ks(e, i.expression, i.base, b, y);
			a && (a.kind === "array" || a.kind === "number-array") && e.report("local.data-table.value", `<${l.child}> ${l.childValue} must be a scalar string, number, boolean or null, got ${oo(a.kind)}.`, i.base);
		}
	}
}
function Xs(e) {
	let t = [], n = 0, r = !1, i = Object.keys(e.bindingKinds), a = mo(e);
	for (let o of e.entries) {
		let s = Z(o.kernel, "validation-rule");
		if (!s) continue;
		n += 1;
		let c = o.node, l = Math.min(s.max, 100);
		if (n > l) {
			r || (r = !0, e.report("local.validation.budget", `The document declares more than ${l} validation rules; rules in hidden regions count too.`, c.range.start, c.range.end));
			continue;
		}
		o.parent && (o.parent.kernel.form !== "container" || Z(o.parent.kernel, "data-table") !== void 0) && e.report("local.validation.placement", `<${o.name}> can appear in normal prose or a container, but not inside inline content or a data table.`, c.range.start, c.range.end);
		let u = e.attrs.get(c.id) ?? {}, d = "", f = [], p = u[s.when];
		if (p) {
			let t = uo(p.raw);
			if (!t) e.report("local.validation.when", `<${o.name}> ${s.when} must be exactly one {{ boolean }} interpolation.`, p.offset, p.offset + p.raw.length);
			else if (t.expression) {
				d = t.expression;
				let n = Ks(e, d, p.offset + t.start, a, !0);
				n && (f = [...n.compiled.dependencies], n.kind !== null && n.kind !== "boolean" && e.report("local.type", `Expected a boolean here, but the expression evaluates to ${oo(n.kind)}.`, p.offset + t.start));
			}
		}
		let m = u[s.fields], h = m ? pe(m.raw) : [];
		m && !h.length && e.report("local.validation.fields", `<${o.name}> requires at least one field name.`, m.offset, m.offset + m.raw.length);
		let g = /* @__PURE__ */ new Set();
		for (let t of h) if (g.has(t)) e.report("local.validation.fields", `Duplicate field "${t}" in <${o.name}> fields.`, m?.offset ?? c.range.start);
		else if (g.add(t), !Object.hasOwn(e.bindingKinds, t)) {
			let n = fo(t, i);
			e.report("local.validation.fields", `Field "${t}" is not a public writable parameter.${n ? ` Did you mean ${n}?` : ""}`, m?.offset ?? c.range.start);
		}
		d && t.push({
			nodeId: c.id,
			expression: d,
			dependencies: f,
			message: typeof u[s.message]?.value == "string" ? String(u[s.message].value) : "",
			fields: [...g],
			range: { ...c.range }
		});
	}
	return t;
}
function Zs(e, t, n) {
	let r = e.kernel.props[n.samples]?.default, i = typeof r == "number" ? r : 200;
	return no(e, t, n.samplesAlias) ?? no(e, t, n.samples) ?? i;
}
function Qs(e) {
	let t = mo(e), n = 0, r = !1;
	for (let i of e.entries) {
		let o = Z(i.kernel, "plot-math");
		if (!o) continue;
		let s = e.plotMath;
		if (!s) {
			e.report("local.capability.plot", { key: "local.capability.plot" }, i.node.range.start, i.node.range.end);
			continue;
		}
		let c = e.attrs.get(i.node.id) ?? {}, l = eo(i.node.children).filter((e) => e.type === "math"), u = Zs(i, c, o), d = Math.min(o.curves, 16), f = Math.min(o.points, a);
		l.length > d && e.report("local.budget.plot.curves", {
			key: "local.budget.plot.curves",
			params: {
				limit: d,
				count: l.length
			}
		}, i.node.range.start, i.node.range.end);
		let p = l.map((e) => s.kind(e.value ?? "")), m = p.reduce((e, t) => e + (t === "implicit" ? s.gridSize(u) ** 2 : u), 0), h = n + m;
		if (!r && h > f && (e.report("local.budget.plot.points", {
			key: "local.budget.plot.points",
			params: { limit: f }
		}, i.node.range.start, i.node.range.end), r = !0), n = Math.min(f + 1, h), !(l.length > d || r)) for (let n = 0; n < l.length; n += 1) {
			let r = l[n], i = (r.value ?? "").trim();
			if (p[n] === null) {
				e.report("local.math.formula", { key: "local.math.formula.shape" }, r.range.start, r.range.end);
				continue;
			}
			let a = null;
			try {
				a = s.compile(i);
			} catch (t) {
				e.report("local.math", {
					key: "local.math.compute",
					params: {
						detail: t instanceof Error ? t.message : String(t),
						code: t && typeof t == "object" && "code" in t && typeof t.code == "string" ? t.code : "latex-syntax",
						near: i.slice(0, 120)
					}
				}, r.range.start, r.range.end);
			}
			if (a) for (let n of a.dependencies) n === "x" || n === "y" || n === "t" && a.kind !== "polar" || (Object.hasOwn(t, n) ? t[n] !== "number" && e.report("local.math.binding", {
				key: "local.math.binding.type",
				params: {
					name: n,
					kind: oo(t[n])
				}
			}, r.range.start, r.range.end) : e.report("local.math.binding", {
				key: "local.math.binding.unknown",
				params: { name: n }
			}, r.range.start, r.range.end));
		}
	}
}
// src/local/compilation/dependencies.ts
var $s = /* @__PURE__ */ new Map(), ec = /* @__PURE__ */ new WeakMap(), tc = /* @__PURE__ */ new WeakMap();
function nc(e) {
	let t = e.snapshot().revision, n = tc.get(e);
	if (n?.revision === t) return n.tokens;
	let r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new WeakMap();
	for (let t of S(e.document.nodes, !0)) {
		let n = e.resetToken(t);
		for (let e of t.children ?? []) n += i.get(e);
		r.set(t.id, n), i.set(t, n);
	}
	return tc.set(e, {
		revision: t,
		tokens: r
	}), r;
}
function rc(e, t) {
	for (let n of t) e.add(n);
}
function ic(e, t) {
	let r = ec.get(e);
	if (r !== void 0 && r.definitions === t) return r.index;
	let i = e.dependencies;
	if (i !== void 0) {
		let n = new Map(Object.entries(i));
		return ec.set(e, {
			definitions: t,
			index: n
		}), n;
	}
	let a = t ?? (Array.isArray(e.componentDefinitions) ? e.componentDefinitions : []), o = /* @__PURE__ */ new Map(), s = fe(e), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Set();
	for (let [t, n] of Object.entries(e.bindings)) {
		for (let e of n.nodeIds) l.add(e);
		if (!t.startsWith("@")) for (let e of n.nodeIds) {
			let n = c.get(e) ?? [];
			n.push(t), c.set(e, n);
		}
	}
	let u = (e) => c.get(e.id) ?? [ye(e)], d = (t, n) => {
		let r = e.bindingSlots?.[n.id];
		if (r !== void 0) {
			t.add(ye(n));
			for (let e of Object.values(r)) t.add(e);
		}
	}, f = /* @__PURE__ */ new WeakMap();
	for (let t of S(e.nodes, !0)) {
		let r = /* @__PURE__ */ new Set(), i = !1;
		if (t.attrs !== void 0) for (let e of Object.values(t.attrs)) try {
			rc(r, T(e));
		} catch {
			i = !0;
			break;
		}
		if (!i) {
			if (t.type === "interpolation") try {
				rc(r, D(t.value ?? "").dependencies);
			} catch {
				i = !0;
			}
			else if (t.type === "math") try {
				rc(r, n(t.value ?? "").dependencies);
			} catch {
				i = !0;
			}
			else if (t.name !== void 0) {
				if (s) {
					let i = s.dependencyRules?.[t.id];
					if (i?.selfBinding) {
						let e = i.selfBinding.attribute;
						(i.selfBinding.mode === "always" || e !== void 0 && (t.attrs?.[e] ?? "").trim() !== "") && rc(r, u(t));
					}
					if (i?.inlineMathReads) for (let e of t.children ?? []) {
						if (e.type !== "inlineMath") continue;
						let t = (e.value ?? "").trim();
						if (/^y\s*=/u.test(t)) try {
							rc(r, n(t).dependencies);
						} catch {}
					}
					i || (e.bindingSlots?.[t.id] !== void 0 && r.add(ye(t)), l.has(t.id) && rc(r, u(t)), d(r, t));
				} else {
					let e = t.name ? a.find((e) => e.name === t.name) : void 0, i = e ? Ne(e) : [], o = i.find((e) => e.kind === "self-binding-read"), s = i.some((e) => e.kind === "inline-math-reads");
					if (o ? (o.mode === "always" || o.attribute !== void 0 && (t.attrs?.[o.attribute] ?? "").trim() !== "") && rc(r, u(t)) : !s && l.has(t.id) && rc(r, u(t)), s) for (let e of t.children ?? []) {
						if (e.type !== "inlineMath") continue;
						let t = (e.value ?? "").trim();
						if (/^y\s*=/u.test(t)) try {
							rc(r, n(t).dependencies);
						} catch {}
					}
					d(r, t);
				}
			}
		}
		let c = !1;
		for (let e of t.children ?? []) {
			let t = f.get(e);
			t === null ? c = !0 : rc(r, t);
		}
		let p = i || c ? null : [...r];
		o.set(t.id, p), f.set(t, p);
	}
	return ec.set(e, {
		definitions: t,
		index: o
	}), o;
}
function ac(e, t) {
	if (e.dependencies !== void 0) return;
	let n = ic(e, t), r = Object.create(null);
	for (let [e, t] of n) r[e] = t === null ? null : Object.freeze([...t]);
	e.dependencies = Object.freeze(r);
}
// src/local/css/author-css.ts
var oc = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/i, sc = "[data-rmd-document]", cc = [
	"@import",
	"expression(",
	"javascript:",
	"vbscript:",
	"-moz-binding",
	"behavior:",
	"image-set(",
	"-webkit-image-set("
], lc = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"container",
	"starting-style"
]), uc = /* @__PURE__ */ new Set([
	"import",
	"charset",
	"namespace",
	"font-face",
	"font-feature-values",
	"font-palette-values",
	"keyframes",
	"-webkit-keyframes",
	"page",
	"property",
	"counter-style",
	"viewport",
	"custom-media",
	"custom-selector",
	"position-try",
	"layer",
	"scope"
]), dc = 4, fc = /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/;
function pc(e) {
	let t = {}, n = {};
	for (let r of Pc(Nc(e), ";")) {
		let e = bc(r);
		if (!e) continue;
		let i = xc(e.property);
		i && vc.test(i) && (!n[i] || e.important) && (n[i] = e.important, delete t[i], t[i] = e.important ? `${e.value} !important` : e.value);
	}
	return Object.freeze(t);
}
function mc(e) {
	let t = [], n = /* @__PURE__ */ new Set(), r = !1;
	for (let i of Pc(Nc(e), ";")) {
		let e = bc(i);
		e && (n.has(e.property) && (r = !0), n.add(e.property), t.push(`${e.property}:${e.value}${e.important ? " !important" : ""};`));
	}
	return r ? t.join("") : void 0;
}
function hc(e) {
	let t = /^([\s\S]*?)\s*!\s*important\s*$/i.exec(e.trim());
	return t ? {
		value: t[1].trimEnd(),
		important: !0
	} : {
		value: e.trim(),
		important: !1
	};
}
function gc(e, t) {
	let n = t === void 0 ? ":scope" : Ac(t);
	if (!n) return "";
	let r = Ec(e, 0);
	if (r.length === 0) return "";
	let i = `${n} ${sc}`;
	return jc(`@scope${t === void 0 ? "" : ` (${n})`} to (${i}) {\n${Mc(r.join("\n"))}\n}`);
}
function _c(e, t) {
	let n = [];
	function r(e, i, a) {
		if (!(a > dc)) for (let o of Lc(e)) {
			if (n.length >= t) return;
			let e = /^@([A-Za-z-]+)/.exec(o.prelude)?.[1];
			if (!e) continue;
			let s = e.toLowerCase();
			if (uc.has(s)) {
				let t = i + o.start;
				n.push({
					name: e,
					start: t,
					end: t + e.length + 1
				});
			} else lc.has(s) && o.block !== null && r(o.block, i + o.blockStart, a + 1);
		}
	}
	return r(e, 0, 0), n;
}
var vc = /^(?:--[\w-]+|[A-Za-z][\w$]*)$/, yc = /^(?:--[A-Za-z0-9_-]+|-{0,2}[A-Za-z][A-Za-z0-9-]*)$/;
function bc(e) {
	let t = Fc(e);
	if (t < 1) return null;
	let n = e.slice(0, t).trim(), r = e.slice(t + 1).trim();
	if (!yc.test(n) || r === "") return null;
	n.startsWith("--") || (n = n.toLowerCase());
	let i = hc(r);
	return !Sc(i.value) || !i.important && /!\s*important\b/i.test(i.value) ? null : {
		property: n,
		value: i.value,
		important: i.important
	};
}
function xc(e) {
	if (e.startsWith("--")) return e;
	let t = e.startsWith("-"), n = e.replace(/^-+/, "");
	if (!n) return null;
	let r = n.replace(/-+([a-z0-9])/g, (e, t) => t.toUpperCase());
	return t ? r.charAt(0).toUpperCase() + r.slice(1) : r;
}
function Sc(e) {
	if (e === "" || fc.test(e)) return !1;
	let t = Cc(e);
	if (t.separator || t.unbalanced) return !1;
	let n = Tc(e), r = n.toLowerCase();
	if (cc.some((e) => r.includes(e))) return !1;
	for (let e of wc(n)) if (!oc.test(e.replace(/\s+/g, ""))) return !1;
	return !0;
}
function Cc(e) {
	let t = "", n = 0;
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r];
		if (t) i === "\\" ? r += 1 : i === t && (t = "");
		else if (i === "\"" || i === "'") t = i;
		else if (i === "(" || i === "[") n += 1;
		else if (i === ")" || i === "]") {
			if (--n, n < 0) return {
				separator: !0,
				unbalanced: !0
			};
		} else if (n === 0 && (i === ";" || i === "{" || i === "}")) return {
			separator: !0,
			unbalanced: !1
		};
	}
	return {
		separator: !1,
		unbalanced: t !== "" || n !== 0
	};
}
function wc(e) {
	let t = [], n = /url\s*\(/gi, r;
	for (; (r = n.exec(e)) !== null;) {
		let n = r.index + r[0].length, i = "", a = "";
		for (; n < e.length;) {
			let t = e[n];
			if (i) {
				if (t === "\\" && n + 1 < e.length) {
					a += e[n + 1], n += 2;
					continue;
				}
				if (t === i) {
					i = "", n += 1;
					continue;
				}
				a += t;
			} else if (t === "\"" || t === "'") i = t;
			else if (t === ")") break;
			else a += t;
			n += 1;
		}
		t.push(a.trim());
	}
	return t;
}
function Tc(e) {
	return e.replace(/\\(?:([0-9a-fA-F]{1,6})[ \t\n\r\f]?|([\s\S]))/g, (e, t, n) => {
		if (t) {
			let e = Number.parseInt(t, 16);
			return e === 0 || e > 1114111 ? "�" : String.fromCodePoint(e);
		}
		return n ?? "";
	});
}
function Ec(e, t) {
	if (t > dc) return [];
	let n = [];
	for (let r of Lc(Nc(e))) {
		if (r.prelude.startsWith("@")) {
			let e = /^@([A-Za-z-]+)/.exec(r.prelude)?.[1]?.toLowerCase();
			if (!e || uc.has(e) || !lc.has(e) || r.block === null) continue;
			let i = kc(r.prelude.slice(e.length + 1));
			if (i === null) continue;
			let a = Ec(r.block, t + 1);
			if (a.length === 0) continue;
			let o = i ? `@${e} ${i}` : `@${e}`;
			n.push(`${o} {\n${Mc(a.join("\n"))}\n}`);
			continue;
		}
		if (r.block === null) continue;
		let e = Pc(r.prelude, ",").map((e) => e.trim()).filter(Oc);
		if (e.length === 0) continue;
		let i = Dc(r.block);
		i.length !== 0 && n.push(`${e.join(", ")} {\n${Mc(i.join("\n"))}\n}`);
	}
	return n;
}
function Dc(e) {
	let t = [];
	for (let n of Pc(e, ";")) {
		let e = bc(n);
		e && t.push(`${e.property}: ${e.value}${e.important ? " !important" : ""};`);
	}
	return t;
}
function Oc(e) {
	return !(e === "" || e.length > 512 || /[{}@;]/.test(e) || /[\u0000-\u0008\u000b\u000e-\u001f\u007f]/.test(e) || /:root\b/i.test(e) || /(^|[\s>+~,])(?:html|body)(?:$|[\s.#:[>+~,])/i.test(e));
}
function kc(e) {
	let t = e.trim();
	if (!t) return "";
	if (/[{}]/.test(t) || fc.test(t)) return null;
	let n = Tc(t).toLowerCase();
	if (cc.some((e) => n.includes(e))) return null;
	for (let e of wc(n)) if (!oc.test(e.replace(/\s+/g, ""))) return null;
	return t;
}
function Ac(e) {
	let t = e.trim();
	if (t === "" || t.length > 512 || /[{}<>@;]|\/\*|[\u0000-\u001f\u007f]/.test(t)) return "";
	let n = {
		"]": "[",
		")": "("
	}, r = [];
	for (let e of t) if (e === "[" || e === "(") r.push(e);
	else if (n[e] && r.pop() !== n[e]) return "";
	return r.length > 0 || /[\s>+~,]$/.test(t) ? "" : t;
}
function jc(e) {
	return e.replace(/\u0000/g, "�").replace(/<(?=\/style[\t\n\f\r />])/gi, "\\3c ");
}
function Mc(e) {
	return e.split("\n").map((e) => e && `  ${e}`).join("\n");
}
function Nc(e) {
	let t = "", n = "", r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (n) {
			if (t += i, i === "\\" && r + 1 < e.length) {
				t += e[r + 1], r += 2;
				continue;
			}
			i === n && (n = ""), r += 1;
		} else if (i === "\"" || i === "'") n = i, t += i, r += 1;
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else t += i, r += 1;
	}
	return t;
}
function Pc(e, t) {
	let n = [], r = "", i = "", a = 0;
	for (let o = 0; o < e.length; o += 1) {
		let s = e[o];
		i ? (r += s, s === "\\" && o + 1 < e.length ? (r += e[o + 1], o += 1) : s === i && (i = "")) : s === "\"" || s === "'" ? (i = s, r += s) : (s === "(" || s === "[" ? a += 1 : (s === ")" || s === "]") && (a = Math.max(0, a - 1)), a === 0 && s === t ? (n.push(r), r = "") : r += s);
	}
	return n.push(r), n;
}
function Fc(e) {
	let t = "", n = 0;
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r];
		if (t) i === "\\" ? r += 1 : i === t && (t = "");
		else if (i === "\"" || i === "'") t = i;
		else if (i === "(" || i === "[") n += 1;
		else if (i === ")" || i === "]") n = Math.max(0, n - 1);
		else if (i === ":" && n === 0) return r;
	}
	return -1;
}
function Ic(e, t) {
	let n = 0, r = "";
	for (let i = t; i < e.length; i += 1) {
		let t = e[i];
		if (r) t === "\\" ? i += 1 : t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === "/" && e[i + 1] === "*") {
			let t = e.indexOf("*/", i + 2);
			if (t < 0) return -1;
			i = t + 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return i;
	}
	return -1;
}
function Lc(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
		else if (e.startsWith("/*", n)) {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else break;
		if (n >= e.length) break;
		let r = n, i = "", a = "";
		for (; n < e.length;) {
			let t = e[n];
			if (i) t === "\\" ? n += 2 : (t === i && (i = ""), n += 1);
			else if (t === "\"" || t === "'") i = t, n += 1;
			else if (t === "/" && e[n + 1] === "*") {
				let t = e.indexOf("*/", n + 2);
				n = t < 0 ? e.length : t + 2;
			} else {
				if (t === "{" || t === ";" || t === "}") {
					a = t;
					break;
				}
				n += 1;
			}
		}
		let o = e.slice(r, n).trim();
		if (a === "{") {
			let i = Ic(e, n);
			if (i < 0) {
				o && t.push({
					prelude: o,
					block: null,
					start: r,
					blockStart: n + 1
				});
				break;
			}
			o && t.push({
				prelude: o,
				block: e.slice(n + 1, i),
				start: r,
				blockStart: n + 1
			}), n = i + 1;
		} else {
			if (o && t.push({
				prelude: o,
				block: null,
				start: r,
				blockStart: n
			}), a === "") break;
			n += 1;
		}
	}
	return t;
}
// src/local/compilation/compiler-capabilities.ts
var Rc = /* @__PURE__ */ new Set([
	"computed",
	"const",
	"external",
	"validation",
	"option",
	"column",
	"edge",
	"step"
]), zc = /* @__PURE__ */ new Set([
	"html",
	"head",
	"body",
	"base",
	"title",
	"link",
	"meta",
	"style",
	"script"
]);
function Bc(e, t, n) {
	let r = [], i = [], a = Object.create(null), o = Object.create(null), s = /* @__PURE__ */ new Set(), c = !1, l = 100, u = (t, n, r, i) => {
		Xa(e, t, {
			key: t,
			params: i
		}, n, r);
	}, d = (f) => f.flatMap((f) => {
		let { type: p, name: m, attrs: h, range: g } = f;
		if (p === "authorCss" || p === "authorJavaScript") {
			let n = p === "authorCss", a = f.value ?? "", o = g.start + Wo(e.source, g.start, g.end).length;
			if (n ? t.enableCss : t.enableJavaScript) {
				if ((n ? r : i).push({
					text: a,
					range: {
						start: o,
						end: o + a.length
					}
				}), n && l > 0) {
					let e = _c(a, l);
					l -= e.length;
					for (let t of e) u("local.author.css-global-rule", o + t.start, o + t.end, { name: t.name });
				}
				c = !0;
			} else u("local.author.disabled", g.start, o, { feature: n ? "CSS" : "JavaScript" });
			return [];
		}
		if (p === "extendedHtmlRaw") {
			let r = f.value ?? e.source.slice(g.start, g.end), i = /^<([\w-]+)/.exec(r)?.[1].toLowerCase() ?? "html";
			if (zc.has(i)) return u("local.author.fragment-tag", g.start, g.end, { name: i }), [{
				...f,
				type: "fallback",
				value: r
			}];
			if (!t.enableExtendedHtml || !e.htmlFragment) return Xa(e, "local.html.fallback", {
				key: "local.html.extended",
				params: { name: i }
			}, g.start, g.end), [{
				...f,
				type: "fallback",
				value: r
			}];
			let a = e.htmlFragment(r, t, n);
			for (let t of a.diagnostics) Xa(e, t.code, t.message, g.start + t.range.start, g.start + t.range.end, {
				key: t.messageKey ?? t.code,
				params: t.params
			});
			return a.markup ? (c = !0, [{
				...f,
				type: "extendedHtml",
				value: r
			}]) : [{
				...f,
				type: "fallback",
				value: r
			}];
		}
		let _ = f.children ? d(f.children) : void 0;
		if (p !== "component" && p !== "hostComponent" || !m || !h || !Object.hasOwn(h, "css") && !Object.hasOwn(h, "action-id")) return [_ ? {
			...f,
			children: _
		} : f];
		let v = { ...h }, y = e.schemaByName.get(m), b = Wo(e.source, g.start, g.end), x = /^<[^\s/>]+/.exec(b)?.[0].length ?? 0, S = ha(b.slice(x), g.start + x, (e) => e), C = (e) => S.entries.find((t) => t.name === e) ?? g;
		if (Object.hasOwn(h, "css")) {
			let e = C("css");
			y && Object.hasOwn(y.props, "css") ? u("local.author.css-owned", e.start, e.end, { name: m }) : y && (delete v.css, Rc.has(m) ? u("local.author.css-hidden", e.start, e.end, { name: m }) : t.enableCss ? (a[f.id] = h.css, c = !0) : u("local.author.disabled", e.start, e.end, { feature: "CSS" }));
		}
		if (Object.hasOwn(h, "action-id") && y && !Object.hasOwn(y.props, "action-id")) {
			delete v["action-id"];
			let e = h["action-id"], t = C("action-id");
			m !== "counter" || !/^[A-Za-z][\w-]{0,63}$/.test(e) ? u("local.author.action-invalid", t.start, t.end, { id: e }) : Object.hasOwn(o, e) || s.has(e) ? (s.add(e), delete o[e], u("local.author.action-duplicate", t.start, t.end, { id: e })) : (o[e] = f.id, c = !0);
		}
		return [{
			...f,
			attrs: v,
			..._ ? { children: _ } : {}
		}];
	});
	return e.nodes = d(e.nodes), c ? {
		policy: t,
		styles: r,
		scripts: i,
		componentStyles: a,
		actionTargets: o
	} : void 0;
}
// src/local/compilation/compiler-core.ts
function Vc(e, t) {
	return !t || t.length === 0 ? e : {
		...e,
		recoveries: [...t]
	};
}
function Hc(e) {
	return e.schemaByName ?? /* @__PURE__ */ new Map();
}
function Uc(e) {
	return e.componentByName ?? /* @__PURE__ */ new Map();
}
function Wc(e, t, n) {
	if (typeof e != "string" || e.length > 1e6) return {
		ok: !1,
		diagnostics: [{
			code: typeof e == "string" ? "local.budget" : "local.parse",
			message: typeof e == "string" ? `Document exceeds the ${o}-character limit.` : "Document source must be a string.",
			severity: "error",
			range: {
				start: 0,
				end: typeof e == "string" && e.length ? 1 : 0
			},
			line: 1,
			column: 1,
			messageKey: typeof e == "string" ? "local.budget.document" : "local.parse.source",
			phase: typeof e == "string" ? "resource" : "source",
			recoverable: !1,
			...typeof e == "string" ? { details: {
				budget: "maxDocumentLength",
				limit: o,
				actual: e.length,
				unit: "codeUnits"
			} } : {},
			...typeof e == "string" ? { params: { limit: o } } : {}
		}]
	};
	let r = n(e, t.html, t.maxSyntaxNodes);
	return r.diagnostics.some((e) => e.severity === "error") ? {
		ok: !1,
		diagnostics: r.diagnostics
	} : {
		ok: !0,
		document: {
			syntax: "local",
			source: e,
			syntaxVersion: be,
			html: t.html,
			nodes: [{
				type: "htmlDocument",
				id: "local-0",
				range: {
					start: 0,
					end: e.length
				},
				value: r.markup
			}],
			initialState: {},
			bindings: {}
		},
		diagnostics: r.diagnostics
	};
}
function Gc(e, t, n, r, i, a, o) {
	if (typeof e != "string" || e.length > 1e6) {
		let t = Ya(e, n);
		return Vc({
			ok: !1,
			diagnostics: t.diagnostics
		}, t.recoveries);
	}
	let s = [], c = new g(e), { lineStarts: l } = c, u = (t, n, r, i = r + 1, a) => {
		let o = typeof n == "string" ? a : n, c = typeof n == "string" ? n : y(n);
		if (s.length >= 100) {
			let e = s.length - 1;
			for (; e >= 0 && s[e].severity !== "warning";) --e;
			if (e < 0) return;
			s.splice(e, 1);
		}
		let u = Math.max(0, Math.min(e.length, r)), f = Math.max(u, Math.min(e.length, Math.max(u, i))), p = 0, m = l.length - 1;
		for (; p < m;) {
			let e = Math.ceil((p + m) / 2);
			l[e] <= u ? p = e : m = e - 1;
		}
		let h = v(o?.key ?? t, o?.params);
		s.push({
			code: t,
			message: c.length > 2e3 ? `${x(c, d - 1)}…` : c,
			severity: "error",
			range: {
				start: u,
				end: f
			},
			line: p + 1,
			column: u - l[p] + 1,
			messageKey: h.key,
			phase: t.includes("budget") ? "resource" : t === "local.parse" ? "parse" : "semantic",
			recoverable: !1,
			...h.params ? { params: h.params } : {}
		});
	}, f;
	try {
		f = r?.parser ? r.parser.parse(e, t, c, r.rowPlans, o) : Ya(e, n, c, void 0, void 0, o), i?.(f), a?.("parseMs");
	} catch (e) {
		return u("local.parse", `Cannot parse document: ${e instanceof Error ? e.message : String(e)}`, 0, void 0, {
			key: "local.parse.document",
			params: { detail: e instanceof Error ? e.message : String(e) }
		}), {
			ok: !1,
			diagnostics: s
		};
	}
	s.push(...f.diagnostics);
	let p = f.recoveries;
	if (s.some((e) => e.severity === "error" && e.code.startsWith("local.version."))) {
		let e = new Set((p ?? []).map((e) => `${e.code}:${e.causeRange.start}:${e.causeRange.end}`));
		return Vc({
			ok: !1,
			diagnostics: s.filter((t) => t.code.startsWith("local.version.") || t.severity === "warning" && e.has(`${t.code}:${t.range.start}:${t.range.end}`))
		}, p);
	}
	for (let e of Ro(f.nodes)) u("local.legacy", "Legacy reactive-md configuration fences (state/data/computed/actions, etc.) are not part of the local interaction syntax; select legacy mode explicitly in the host.", e.range.start, e.range.end, { key: "local.legacy" });
	let m = {
		semantic: r?.semantic,
		display: r?.display,
		htmlFragment: r?.htmlFragment,
		plotMath: r?.plotMath,
		source: e,
		lineStarts: l,
		nodes: f.nodes,
		diagnostics: s,
		schemaByName: Hc(n),
		definitionsByName: Uc(n),
		report: u,
		entries: [],
		attrs: /* @__PURE__ */ new Map(),
		options: /* @__PURE__ */ new Map(),
		tabs: /* @__PURE__ */ new Map(),
		steps: /* @__PURE__ */ new Map(),
		selections: /* @__PURE__ */ new Map(),
		diagramNodes: /* @__PURE__ */ new Map(),
		checklists: /* @__PURE__ */ new Map(),
		tables: /* @__PURE__ */ new Map(),
		tableShapes: /* @__PURE__ */ new Map(),
		bindingSlots: Object.create(null),
		bindingKinds: {},
		computationKinds: {},
		computations: {},
		externals: {},
		externalKinds: {},
		dynamicConstraints: {},
		expressionKinds: /* @__PURE__ */ new Map()
	}, h = Bc(m, n.html, n.maxSyntaxNodes);
	zo(m.nodes, null, m.entries, m);
	for (let e of m.entries) m.attrs.set(e.node.id, Ko(e, m)), $o(e, m), Qo(e, m);
	a?.("attributesMs");
	for (let e of m.entries) Fo(e, m);
	ss(m), a?.("structureMs");
	let _ = hs(m);
	Ds(m, _), m.bindingKinds = gs(_), a?.("bindingsMs"), Fs(m), Ms(m), a?.("computationsMs"), Is(m), Us(m), a?.("expressionsMs"), Ys(m), a?.("dataTablesMs");
	let b = Xs(m);
	a?.("validationsMs"), Qs(m), a?.("plotsMs"), is(m), a?.("tablesMs");
	let S = {};
	for (let [e, t] of Object.entries(_)) S[e] = ho(t.initial);
	Ws(m, _, S), Uo(m.nodes, m), a?.("hostAndNavigationMs");
	let C = [...m.nodes];
	for (; C.length && s.length < 100;) {
		let t = C.pop();
		if (t.type === "math" || t.type === "inlineMath") {
			let n = e.startsWith("\\\\[", t.range.start) ? 3 : t.type === "math" || e.startsWith("\\(", t.range.start) ? 2 : 1, r = t.range.start + n;
			if (m.display) for (let e of m.display(t.value ?? "", t.type === "math")) Xa(m, e.code, e.message, r + e.start, r + e.end, {
				key: e.messageKey,
				params: e.params
			});
		} else t.children && C.push(...t.children);
	}
	if (a?.("mathDisplayMs"), s.sort((e, t) => e.range.start - t.range.start || e.range.end - t.range.end), s.some((e) => e.severity === "error")) return Vc({
		ok: !1,
		diagnostics: s
	}, p);
	let w = ks(m), T = Object.keys(m.computations), E = Object.keys(m.externals), D = Object.keys(m.dynamicConstraints).length ? m.dynamicConstraints : void 0, O = Bo(m.nodes, n.sdkByName), k = Vo(m, _), A = Ho(m), j = {
		syntax: "local",
		source: e,
		...n.config || !t?.hostComponents ? { componentConfigKey: ce(n) } : {},
		syntaxVersion: be,
		...f.versionDeclaration ? { versionDeclaration: f.versionDeclaration } : {},
		nodes: Ns(m.nodes),
		...h ? { capabilities: h } : {},
		initialState: S,
		bindings: _,
		theme: f.theme ?? "default",
		...f.themeRange ? { themeRange: f.themeRange } : {},
		...w ? { bindingSlots: w } : {},
		...T.length ? { computations: m.computations } : {},
		...E.length ? { externals: m.externals } : {},
		...D ? { dynamicConstraints: D } : {},
		...b.length ? { validations: b } : {},
		...O ? { extensions: O } : {},
		kernel: k,
		...A.length ? { componentDefinitions: Object.freeze(A) } : {}
	};
	return ac(j, n.registry), os(j, m.tableShapes), a?.("publicationMs"), Vc({
		ok: !0,
		document: j,
		diagnostics: s
	}, p);
}
export { mc as a, nc as c, us as d, Ja as f, fa as g, pa as h, gc as i, zs as l, ba as m, Gc as n, $s as o, Ya as p, pc as r, ic as s, Wc as t, Hs as u };
