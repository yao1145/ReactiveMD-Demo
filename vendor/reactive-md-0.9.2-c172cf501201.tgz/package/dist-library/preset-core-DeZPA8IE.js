import { C as e, D as t, b as n, c as r, d as i, m as a, n as o, o as s, x as c, y as l } from "./version-DAxuGOG2.js";
// src/sdk/hash.ts
function u(e) {
	let t = 2166136261, n = 16777619;
	for (let r = 0; r < e.length; r += 1) {
		let i = e.charCodeAt(r);
		t ^= i, t = Math.imul(t, 16777619) >>> 0, n ^= i + r, n = Math.imul(n, 2246822507) >>> 0;
	}
	let r = e.length;
	return t ^= r, t = Math.imul(t, 16777619) >>> 0, n ^= r, n = Math.imul(n, 3266489909) >>> 0, `rmd-${t.toString(16).padStart(8, "0")}${n.toString(16).padStart(8, "0")}`;
}
// src/sdk/pattern.ts
function d(e, t) {
	let n = e[t];
	if (n === "*" || n === "+" || n === "?") return { length: e[t + 1] === "?" ? 2 : 1 };
	if (n !== "{") return null;
	let r = /^\{(\d+)(?:,(\d*))?\}/.exec(e.slice(t));
	return r ? { length: r[0].length + +(e[t + r[0].length] === "?") } : null;
}
function f(e) {
	let t = [], n = !1, r = !1;
	for (let i = 0; i < e.length; i += 1) {
		let a = e[i];
		if (n) {
			n = !1;
			continue;
		}
		if (a === "\\") {
			let t = e[i + 1];
			if (t !== void 0 && t >= "1" && t <= "9" || t === "k" && e[i + 2] === "<") return !1;
			n = !0;
			continue;
		}
		if (r) {
			a === "]" && (r = !1);
			continue;
		}
		if (a === "[") {
			r = !0;
			continue;
		}
		if (a === "(") {
			if (e[i + 1] === "?") {
				if (e[i + 2] !== ":") return !1;
				t.push({
					quantified: !1,
					alternation: !1
				}), i += 2;
				continue;
			}
			t.push({
				quantified: !1,
				alternation: !1
			});
			continue;
		}
		if (a === "|") {
			let e = t[t.length - 1];
			e && (e.alternation = !0);
			continue;
		}
		if (a === ")") {
			let n = t.pop();
			if (!n) return !1;
			let r = d(e, i + 1);
			if (r && (n.quantified || n.alternation)) return !1;
			let a = t[t.length - 1];
			a && (a.quantified = a.quantified || n.quantified || r !== null, a.alternation = a.alternation || n.alternation), r && (i += r.length);
			continue;
		}
		let o = d(e, i);
		if (o) {
			let e = t[t.length - 1];
			e && (e.quantified = !0), i += o.length - 1;
		}
	}
	return t.length === 0 && !n && !r;
}
// src/sdk/manifest.ts
var p = 64, m = 64, h = 128, g = 160, _ = 64, v = 64, y = 512, b = 4096, x = 16, ee = 32, te = 256, S = 65536, C = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, w = /^[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*$/, ne = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/, re = /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/, T = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), E = /* @__PURE__ */ new WeakSet(), ie = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), ae = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), oe = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), se = /* @__PURE__ */ new Set([
	"text",
	"number",
	"boolean",
	"choice",
	"date",
	"timer",
	"checklist",
	"tabs",
	"diagram",
	"multi-select",
	"selection",
	"steps",
	"collection"
]), ce = /* @__PURE__ */ new Set([
	"empty",
	"false",
	"max-step",
	"nearest-zero",
	"min",
	"first-option",
	"first-tab",
	"first-step",
	"first-node",
	"checked",
	"duration",
	"empty-array",
	"none"
]), le = /* @__PURE__ */ new Set([
	"none",
	"inline",
	"markdown"
]), ue = /* @__PURE__ */ new Set([
	"none",
	"any",
	"inline",
	"content",
	"table",
	"plot",
	"diagram",
	"quiz",
	"options",
	"tabs",
	"steps",
	"components"
]), de = /* @__PURE__ */ new Set(/* @__PURE__ */ "numeric-range.text-length.date-bounds.nonempty.progress-bounds.timer-duration.option-count.selection-requires.inline-body.no-components.single-table.math-body.options-body.value-sequence.only-children.diagram-body.quiz-body.checklist-body.dynamic-constraints.require-full-interpolation.scoped-expressions.row-values.validation-rule.anchor.navigation.data-table.plot-math.chart-table.timeline-table.table-selection.retain.self-binding-read.inline-math-reads.value-date.value-length.value-required.value-email".split(".")), fe = /* @__PURE__ */ new Set([
	"none",
	"required",
	"optional"
]), pe = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"form",
	"props",
	"bindings",
	"children",
	"structure",
	"rules",
	"slotRelations",
	"legacyHost",
	"capabilities",
	"authoring",
	"dependencies",
	"styles",
	"requires",
	"replaces"
]), me = /* @__PURE__ */ new Set([
	"kind",
	"required",
	"static",
	"dynamic",
	"default",
	"nullable",
	"enum",
	"values",
	"pattern",
	"min",
	"max",
	"integer",
	"positive",
	"color",
	"coerce",
	"description"
]), he = /* @__PURE__ */ new Set([
	"kind",
	"family",
	"bind",
	"initial",
	"initialRule",
	"required",
	"exclusive",
	"constraints",
	"options",
	"maxItems",
	"requiresAttributes",
	"compare",
	"retain"
]), ge = /* @__PURE__ */ new Set([
	"min",
	"max",
	"step"
]), _e = /* @__PURE__ */ new Set([
	"interactive",
	"static",
	"ssr",
	"offline"
]), ve = /* @__PURE__ */ new Set([
	"title",
	"description",
	"category",
	"insertText"
]), ye = /* @__PURE__ */ new Set(["kind", "required"]), be = /* @__PURE__ */ new Set([
	"rule",
	"label",
	"parents",
	"child",
	"children",
	"min",
	"max",
	"inlineOnly",
	"noComponents",
	"valueAttribute",
	"generatedPrefix",
	"forbidSeparator",
	"maxItems"
]), xe = /* @__PURE__ */ new Set(["id", "version"]), Se = /* @__PURE__ */ new Set(["kernel"]), Ce = /* @__PURE__ */ new Set(["id", "version"]), we = /^[A-Za-z0-9][A-Za-z0-9._/-]*$/, Te = /^[A-Za-z][A-Za-z0-9]*$/, D = /* @__PURE__ */ new Set(["setMany"]), Ee = 16, De = 32, Oe = 16, ke = 32, Ae = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]);
function O(e, t) {
	throw Error(`Invalid local component manifest (${e}): ${t}`);
}
function k(e) {
	try {
		let t = JSON.stringify(e);
		return typeof t == "string" ? typeof TextEncoder == "function" ? new TextEncoder().encode(t).length : t.length * 2 : Infinity;
	} catch {
		return Infinity;
	}
}
function A(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function j(e, t, n) {
	for (let r of Object.keys(e)) T.has(r) && O(n, `field "${r}" is not allowed.`), t.has(r) || O(n, `unknown field "${r}".`);
}
function M(e, t) {
	return typeof e != "boolean" && O(t, "must be a boolean."), e;
}
function N(e, t, n = b) {
	return typeof e != "string" && O(t, "must be a string."), e.length > n && O(t, `exceeds the ${n}-character limit.`), e;
}
function P(e, t) {
	return typeof e == "number" && Number.isFinite(e) || O(t, "must be a finite number."), e;
}
function F(e, t) {
	return typeof e != "string" && O(t, "must be a string."), e.length > 128 && O(t, "exceeds the 128-character limit."), C.test(e) || O(t, "must use lowercase kebab-case."), e;
}
function I(e, t) {
	A(e) || O(t, "must be an object.");
	let n = {}, r = Object.keys(e).sort();
	for (let i of r) T.has(i) && O(t, `locale "${i}" is not allowed.`), re.test(i) || O(t, `locale "${i}" must look like "en" or "zh-CN".`), n[i] = N(e[i], `${t}.${i}`, 256);
	return n;
}
function je(e, t) {
	A(e) || O(t, "must be an object."), j(e, ve, t);
	let n = {};
	return e.title !== void 0 && (n.title = I(e.title, `${t}.title`)), e.description !== void 0 && (n.description = I(e.description, `${t}.description`)), e.category !== void 0 && (n.category = N(e.category, `${t}.category`, 64)), e.insertText !== void 0 && (n.insertText = N(e.insertText, `${t}.insertText`, b)), n;
}
function Me(e, t, n) {
	A(e) || O(n, "must be an object."), j(e, ye, n);
	let r = e.kind;
	typeof r == "string" && le.has(r) || O(`${n}.kind`, "must be \"none\", \"inline\" or \"markdown\".");
	let i = r;
	e.required !== void 0 && M(e.required, `${n}.required`);
	let a = e.required === !0;
	return t === "leaf" && i !== "none" && O(n, "a leaf component cannot declare body content."), t === "inline" && i === "markdown" && O(n, "an inline component cannot declare Markdown block content."), a && i === "none" && O(n, "cannot require body content of kind \"none\"."), {
		kind: i,
		...a ? { required: !0 } : {}
	};
}
function L(e) {
	if (e !== void 0) return e.kind === "none" ? Object.freeze({
		rule: "none",
		label: "none"
	}) : e.kind === "inline" ? Object.freeze({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0,
		...e.required ? { min: 1 } : {}
	}) : Object.freeze({
		rule: "any",
		label: "none",
		...e.required ? { min: 1 } : {}
	});
}
function R(e, t) {
	Array.isArray(e) || O(t, "must be an array of component names."), e.length > 32 && O(t, "accepts at most 32 names.");
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = F(i, t);
		n.has(e) && O(t, `name "${e}" is declared more than once.`), n.add(e), r.push(e);
	}
	return r;
}
function z(e, t) {
	let n = P(e, t);
	return (!Number.isInteger(n) || n < 0) && O(t, "must be a nonnegative integer."), n;
}
function Ne(e, t, n) {
	A(e) || O(n, "must be an object."), j(e, be, n);
	let r = e.rule;
	typeof r == "string" && ue.has(r) || O(`${n}.rule`, "is not a supported child rule.");
	let i = r;
	t === "leaf" && i !== "none" && O(n, "a leaf component cannot declare body content."), t === "inline" && i !== "none" && i !== "inline" && i !== "any" && O(n, "an inline component only supports \"none\", \"inline\" or \"any\".");
	let a = { rule: i };
	if (e.label !== void 0 && (typeof e.label == "string" && fe.has(e.label) || O(`${n}.label`, "must be \"none\", \"required\" or \"optional\"."), a.label = e.label), e.parents !== void 0 && (a.parents = R(e.parents, `${n}.parents`)), e.child !== void 0 && (a.child = F(e.child, `${n}.child`)), e.children !== void 0 && (a.children = R(e.children, `${n}.children`)), e.min !== void 0 && (a.min = H(e.min, `${n}.min`, l)), e.max !== void 0 && (a.max = H(e.max, `${n}.max`, l)), a.min !== void 0 && a.max !== void 0 && a.min > a.max && O(n, "\"min\" cannot exceed \"max\"."), e.inlineOnly !== void 0 && (a.inlineOnly = M(e.inlineOnly, `${n}.inlineOnly`)), e.noComponents !== void 0 && (a.noComponents = M(e.noComponents, `${n}.noComponents`)), e.valueAttribute !== void 0 && (a.valueAttribute = F(e.valueAttribute, `${n}.valueAttribute`)), e.generatedPrefix !== void 0) {
		let t = N(e.generatedPrefix, `${n}.generatedPrefix`, 128);
		t.length === 0 && O(`${n}.generatedPrefix`, "must not be empty."), a.generatedPrefix = t;
	}
	if (e.forbidSeparator !== void 0) {
		let t = N(e.forbidSeparator, `${n}.forbidSeparator`, 4);
		t.length === 0 && O(`${n}.forbidSeparator`, "must not be empty."), a.forbidSeparator = t;
	}
	return e.maxItems !== void 0 && (a.maxItems = H(e.maxItems, `${n}.maxItems`, l)), a;
}
function B(e, t) {
	return F(e, t);
}
function V(e, t) {
	return z(e, t);
}
function H(e, t, n) {
	let r = z(e, t);
	return r > n && O(t, `cannot exceed the kernel limit ${n}.`), r;
}
function U(e, t) {
	return R(e, t);
}
function Pe(e, t) {
	return Array.isArray(e) || O(t, "must be an array of strings."), e.length > 32 && O(t, "accepts at most 32 values."), e.map((e) => N(e, t, 128));
}
function Fe(r, i) {
	A(r) || O(i, "must be an object.");
	let a = r.kind;
	typeof a == "string" && de.has(a) || O(`${i}.kind`, "is not a supported rule.");
	let o = (e) => j(r, /* @__PURE__ */ new Set(["kind", ...e]), i), s = (e) => {
		let t = {};
		for (let n of e) r[n] !== void 0 && (t[n] = B(r[n], `${i}.${n}`));
		return t;
	};
	switch (a) {
		case "numeric-range": {
			o([
				"min",
				"max",
				"step",
				"order",
				"integer",
				"positiveInteger"
			]);
			let e;
			return r.order !== void 0 && (r.order !== "nondecreasing" && r.order !== "increasing" && O(`${i}.order`, "must be \"nondecreasing\" or \"increasing\"."), e = r.order), {
				kind: a,
				...s([
					"min",
					"max",
					"step",
					"integer",
					"positiveInteger"
				]),
				...e ? { order: e } : {}
			};
		}
		case "text-length": return o(["min", "max"]), {
			kind: a,
			...s(["min", "max"])
		};
		case "date-bounds": return o([
			"min",
			"max",
			"required"
		]), {
			kind: a,
			...s([
				"min",
				"max",
				"required"
			])
		};
		case "nonempty": return o(["attribute"]), {
			kind: a,
			attribute: B(r.attribute, `${i}.attribute`)
		};
		case "progress-bounds": return o([
			"value",
			"max",
			"defaultMax"
		]), {
			kind: a,
			value: B(r.value, `${i}.value`),
			max: B(r.max, `${i}.max`),
			defaultMax: P(r.defaultMax, `${i}.defaultMax`)
		};
		case "timer-duration": return o(["attribute", "default"]), {
			kind: a,
			attribute: B(r.attribute, `${i}.attribute`),
			default: P(r.default, `${i}.default`)
		};
		case "option-count": return o(["max"]), {
			kind: a,
			...r.max === void 0 ? {} : { max: B(r.max, `${i}.max`) }
		};
		case "selection-requires": return o(["key", "attributes"]), {
			kind: a,
			key: B(r.key, `${i}.key`),
			attributes: U(r.attributes, `${i}.attributes`)
		};
		case "inline-body": return o(["strict"]), {
			kind: a,
			...r.strict === void 0 ? {} : { strict: M(r.strict, `${i}.strict`) }
		};
		case "no-components":
		case "math-body":
		case "inline-math-reads": return o([]), { kind: a };
		case "single-table": return o(["fallbackSingle"]), {
			kind: a,
			...r.fallbackSingle === void 0 ? {} : { fallbackSingle: M(r.fallbackSingle, `${i}.fallbackSingle`) }
		};
		case "options-body": return o([
			"child",
			"valueAttribute",
			"unique",
			"max",
			"forbidSeparator"
		]), {
			kind: a,
			child: B(r.child, `${i}.child`),
			valueAttribute: B(r.valueAttribute, `${i}.valueAttribute`),
			unique: r.unique === void 0 || M(r.unique, `${i}.unique`),
			...r.max === void 0 ? {} : { max: H(r.max, `${i}.max`, l) },
			...r.forbidSeparator === void 0 ? {} : { forbidSeparator: N(r.forbidSeparator, `${i}.forbidSeparator`, 4) }
		};
		case "value-sequence": return o([
			"child",
			"valueAttribute",
			"min",
			"generatedPrefix",
			"unique",
			"duplicateCode"
		]), {
			kind: a,
			child: B(r.child, `${i}.child`),
			valueAttribute: B(r.valueAttribute, `${i}.valueAttribute`),
			min: V(r.min, `${i}.min`),
			generatedPrefix: N(r.generatedPrefix, `${i}.generatedPrefix`, 128),
			unique: r.unique === void 0 || M(r.unique, `${i}.unique`),
			...r.duplicateCode === void 0 ? {} : { duplicateCode: N(r.duplicateCode, `${i}.duplicateCode`, 128) }
		};
		case "only-children": return o([
			"children",
			"min",
			"max",
			"maxCode",
			"onlyCode"
		]), {
			kind: a,
			children: U(r.children, `${i}.children`),
			min: V(r.min, `${i}.min`),
			...r.max === void 0 ? {} : { max: H(r.max, `${i}.max`, l) },
			...r.maxCode === void 0 ? {} : { maxCode: N(r.maxCode, `${i}.maxCode`, 128) },
			...r.onlyCode === void 0 ? {} : { onlyCode: N(r.onlyCode, `${i}.onlyCode`, 128) }
		};
		case "diagram-body": return o([
			"node",
			"edge",
			"id",
			"from",
			"to",
			"label"
		]), {
			kind: a,
			node: B(r.node, `${i}.node`),
			edge: B(r.edge, `${i}.edge`),
			id: B(r.id, `${i}.id`),
			from: B(r.from, `${i}.from`),
			to: B(r.to, `${i}.to`),
			...r.label === void 0 ? {} : { label: B(r.label, `${i}.label`) }
		};
		case "quiz-body": return o([
			"type",
			"answer",
			"tolerance",
			"child",
			"valueAttribute",
			"max"
		]), {
			kind: a,
			type: B(r.type, `${i}.type`),
			answer: B(r.answer, `${i}.answer`),
			tolerance: B(r.tolerance, `${i}.tolerance`),
			child: B(r.child, `${i}.child`),
			valueAttribute: B(r.valueAttribute, `${i}.valueAttribute`),
			...r.max === void 0 ? {} : { max: H(r.max, `${i}.max`, l) }
		};
		case "checklist-body": return o(["itemLimit"]), {
			kind: a,
			itemLimit: H(r.itemLimit, `${i}.itemLimit`, l)
		};
		case "dynamic-constraints":
		case "require-full-interpolation": return o(["attributes"]), {
			kind: a,
			attributes: U(r.attributes, `${i}.attributes`)
		};
		case "scoped-expressions": return o(["attributes", "scope"]), r.scope !== "row" && r.scope !== "validation" && O(`${i}.scope`, "must be \"row\" or \"validation\"."), {
			kind: a,
			attributes: U(r.attributes, `${i}.attributes`),
			scope: r.scope
		};
		case "row-values": return o([
			"rows",
			"key",
			"child",
			"childValue"
		]), {
			kind: a,
			rows: B(r.rows, `${i}.rows`),
			key: B(r.key, `${i}.key`),
			child: B(r.child, `${i}.child`),
			childValue: B(r.childValue, `${i}.childValue`)
		};
		case "validation-rule": return o([
			"when",
			"fields",
			"message",
			"placement",
			"max"
		]), r.placement !== "container" && r.placement !== "prose" && O(`${i}.placement`, "must be \"container\" or \"prose\"."), {
			kind: a,
			when: B(r.when, `${i}.when`),
			fields: B(r.fields, `${i}.fields`),
			message: B(r.message, `${i}.message`),
			placement: r.placement,
			max: H(r.max, `${i}.max`, 100)
		};
		case "anchor": return o(["id"]), {
			kind: a,
			id: B(r.id, `${i}.id`)
		};
		case "navigation": return o(["target"]), {
			kind: a,
			target: B(r.target, `${i}.target`)
		};
		case "data-table": return o([
			"rows",
			"key",
			"child",
			"childValue",
			"label",
			"maxRows",
			"defaultMaxRows",
			"documentRows",
			"documentCells",
			"maxColumns"
		]), {
			kind: a,
			rows: B(r.rows, `${i}.rows`),
			key: B(r.key, `${i}.key`),
			child: B(r.child, `${i}.child`),
			childValue: B(r.childValue, `${i}.childValue`),
			label: B(r.label, `${i}.label`),
			maxRows: B(r.maxRows, `${i}.maxRows`),
			defaultMaxRows: H(r.defaultMaxRows, `${i}.defaultMaxRows`, e),
			documentRows: H(r.documentRows, `${i}.documentRows`, c),
			documentCells: H(r.documentCells, `${i}.documentCells`, n),
			maxColumns: H(r.maxColumns, `${i}.maxColumns`, 20)
		};
		case "plot-math": return o([
			"min",
			"max",
			"samples",
			"samplesAlias",
			"curves",
			"points"
		]), {
			kind: a,
			min: B(r.min, `${i}.min`),
			max: B(r.max, `${i}.max`),
			samples: B(r.samples, `${i}.samples`),
			...r.samplesAlias === void 0 ? {} : { samplesAlias: B(r.samplesAlias, `${i}.samplesAlias`) },
			curves: H(r.curves, `${i}.curves`, 16),
			points: H(r.points, `${i}.points`, t)
		};
		case "chart-table": return o([
			"chartKind",
			"x",
			"y"
		]), {
			kind: a,
			chartKind: B(r.chartKind, `${i}.chartKind`),
			x: B(r.x, `${i}.x`),
			y: B(r.y, `${i}.y`)
		};
		case "timeline-table": return o(["headerSets"]), Array.isArray(r.headerSets) || O(`${i}.headerSets`, "must be an array."), {
			kind: a,
			headerSets: r.headerSets.map((e, t) => Pe(e, `${i}.headerSets[${t}]`))
		};
		case "table-selection": return o(["key", "bindings"]), {
			kind: a,
			key: B(r.key, `${i}.key`),
			bindings: U(r.bindings, `${i}.bindings`)
		};
		case "retain": return o(["value"]), {
			kind: a,
			value: M(r.value, `${i}.value`)
		};
		case "self-binding-read": return o(["mode", "attribute"]), r.mode !== "always" && r.mode !== "attribute" && O(`${i}.mode`, "must be \"always\" or \"attribute\"."), {
			kind: a,
			mode: r.mode,
			...r.attribute === void 0 ? {} : { attribute: B(r.attribute, `${i}.attribute`) }
		};
		case "value-date": return o([
			"min",
			"max",
			"required"
		]), {
			kind: a,
			...s([
				"min",
				"max",
				"required"
			])
		};
		case "value-length": return o([
			"min",
			"max",
			"email",
			"emailType"
		]), {
			kind: a,
			...s([
				"min",
				"max",
				"email"
			]),
			...r.emailType === void 0 ? {} : { emailType: N(r.emailType, `${i}.emailType`, 128) }
		};
		case "value-required": return o(["required"]), {
			kind: a,
			required: B(r.required, `${i}.required`)
		};
		case "value-email": return o(["type", "value"]), {
			kind: a,
			...s(["type"]),
			...r.value === void 0 ? {} : { value: N(r.value, `${i}.value`, 128) }
		};
		default: O(`${i}.kind`, "is not a supported rule.");
	}
}
function Ie(e) {
	Array.isArray(e) || O("rules", "must be an array."), e.length > 32 && O("rules", "accepts at most 32 rules.");
	let t = [];
	for (let n = 0; n < e.length; n += 1) t.push(Fe(e[n], `rules[${n}]`));
	return t;
}
function Le(e) {
	Array.isArray(e) || O("slotRelations", "must be an array."), e.length > 16 && O("slotRelations", "accepts at most 16 relations.");
	let t = [];
	for (let n = 0; n < e.length; n += 1) {
		let r = e[n], i = `slotRelations[${n}]`;
		A(r) || O(i, "must be an object."), j(r, /* @__PURE__ */ new Set(["lower", "upper"]), i), t.push({
			lower: F(r.lower, `${i}.lower`),
			upper: F(r.upper, `${i}.upper`)
		});
	}
	return t;
}
function Re(e, t) {
	A(e) || O(t, "must be an object."), j(e, _e, t);
	let n = (n) => e[n] !== void 0 && M(e[n], `${t}.${n}`);
	return {
		interactive: n("interactive"),
		static: n("static"),
		ssr: n("ssr"),
		offline: n("offline")
	};
}
function ze(e, t) {
	A(e) || O(t, "must be an object."), j(e, me, t);
	let n = e.kind;
	typeof n == "string" && ie.has(n) || O(`${t}.kind`, "must be \"string\", \"number\", \"boolean\" or \"enum\".");
	let r = n, i = { kind: r };
	for (let n of [
		"required",
		"static",
		"dynamic",
		"integer",
		"positive",
		"color",
		"nullable"
	]) e[n] !== void 0 && (i[n] = M(e[n], `${t}.${n}`));
	i.static === !0 && i.dynamic === !0 && O(t, "cannot be both static and dynamic."), e.coerce !== void 0 && (e.coerce !== "text" && O(`${t}.coerce`, "must be \"text\"."), r !== "string" && O(`${t}.coerce`, "is only valid for kind \"string\"."), i.coerce = "text");
	let a = e.enum === void 0 ? e.values : e.enum, o = a !== void 0;
	if (r !== "enum") o && O(t, `"enum" is only valid for kind "enum", not "${r}".`);
	else {
		e.enum !== void 0 && e.values !== void 0 && O(t, "use \"enum\" or \"values\", not both."), Array.isArray(a) && a.length !== 0 || O(`${t}.enum`, "must be a non-empty string array."), a.length > 64 && O(`${t}.enum`, "accepts at most 64 values.");
		let n = /* @__PURE__ */ new Set(), r = [];
		for (let e of a) {
			let i = N(e, `${t}.enum`, 128);
			n.has(i) && O(`${t}.enum`, `value "${i}" is declared more than once.`), n.add(i), r.push(i);
		}
		i.enum = r;
	}
	let s = e.pattern !== void 0;
	if (r !== "string") s && O(t, `"pattern" is only valid for kind "string", not "${r}".`);
	else if (s) {
		typeof e.pattern != "string" && O(`${t}.pattern`, "must be a string."), e.pattern.length > 512 && O(`${t}.pattern`, "exceeds the 512-character limit.");
		try {
			new RegExp(e.pattern);
		} catch {
			O(`${t}.pattern`, "is not a valid regular expression.");
		}
		f(e.pattern) || O(`${t}.pattern`, "uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected."), i.pattern = e.pattern;
	}
	let c = e.min !== void 0, l = e.max !== void 0;
	if (r === "number" ? (c && (i.min = P(e.min, `${t}.min`)), l && (i.max = P(e.max, `${t}.max`)), i.min !== void 0 && i.max !== void 0 && i.min > i.max && O(t, "\"min\" cannot exceed \"max\".")) : ((c || l) && O(t, "\"min\" and \"max\" are only valid for kind \"number\"."), i.integer === !0 && O(t, "\"integer\" is only valid for kind \"number\"."), i.positive === !0 && O(t, "\"positive\" is only valid for kind \"number\".")), i.color === !0 && r !== "string" && O(t, "\"color\" is only valid for kind \"string\"."), e.description !== void 0 && (i.description = I(e.description, `${t}.description`)), e.default !== void 0) {
		let n = e.default;
		if (n === null) i.nullable !== !0 && O(`${t}.default`, "is null but the prop is not nullable."), i.default = null;
		else if (r === "string") i.default = N(n, `${t}.default`);
		else if (r === "number") {
			let e = P(n, `${t}.default`);
			i.integer === !0 && !Number.isInteger(e) && O(`${t}.default`, "must be an integer."), i.positive === !0 && !(e > 0) && O(`${t}.default`, "must be greater than zero."), i.min !== void 0 && e < i.min && O(`${t}.default`, `is below the minimum ${i.min}.`), i.max !== void 0 && e > i.max && O(`${t}.default`, `exceeds the maximum ${i.max}.`), i.default = e;
		} else if (r === "boolean") i.default = M(n, `${t}.default`);
		else {
			let e = N(n, `${t}.default`, 128);
			i.enum?.includes(e) || O(`${t}.default`, `"${e}" is not an allowed enum value.`), i.default = e;
		}
		if (i.pattern !== void 0 && r === "string" && typeof i.default == "string") {
			let e = !0;
			try {
				e = new RegExp(i.pattern).test(i.default);
			} catch {
				e = !1;
			}
			e || O(`${t}.default`, `does not match pattern ${i.pattern}.`);
		}
	}
	return i;
}
function Be(e, t) {
	A(e) || O(t, "must be an object with \"literal\" or \"prop\".");
	let n = Object.keys(e);
	n.length !== 1 && O(t, "must contain exactly one of \"literal\" or \"prop\".");
	let r = n[0];
	if (T.has(r) && O(t, `field "${r}" is not allowed.`), r === "literal") return { literal: P(e.literal, `${t}.literal`) };
	if (r === "prop") return { prop: F(e.prop, `${t}.prop`) };
	O(t, `unknown field "${r}"; use "literal" or "prop".`);
}
function Ve(e, t, n, r) {
	A(e) || O(r, "must be an object."), j(e, ge, r);
	let i = {};
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (e[n] === void 0) continue;
		let a = Be(e[n], `${r}.${n}`);
		if ("prop" in a) {
			let e = t[a.prop];
			e === void 0 && O(`${r}.${n}`, `references undeclared prop "${a.prop}".`), e.kind !== "number" && O(`${r}.${n}`, `references prop "${a.prop}", which is not a number.`);
		}
		n === "step" && "literal" in a && !(a.literal > 0) && O(`${r}.step`, "must be greater than 0."), i[n] = a;
	}
	return n !== "number" && (i.min || i.max || i.step) && O(r, "\"min\", \"max\" and \"step\" are only valid for number bindings."), i.min && "literal" in i.min && i.max && "literal" in i.max && i.min.literal > i.max.literal && O(r, "\"min\" cannot exceed \"max\"."), i;
}
function He(e, t) {
	if (e === "number") return t === "timer" ? /* @__PURE__ */ new Set([
		"duration",
		"min",
		"nearest-zero"
	]) : /* @__PURE__ */ new Set([
		"min",
		"nearest-zero",
		"max-step"
	]);
	if (e === "boolean") return /* @__PURE__ */ new Set(["false"]);
	if (e === "null") return /* @__PURE__ */ new Set(["empty"]);
	if (e === "array") return t === "checklist" ? /* @__PURE__ */ new Set(["checked", "empty-array"]) : /* @__PURE__ */ new Set(["empty-array"]);
	if (e === "number-array") return /* @__PURE__ */ new Set(["empty-array"]);
	switch (t) {
		case "choice":
		case "selection": return /* @__PURE__ */ new Set(["first-option", "none"]);
		case "tabs": return /* @__PURE__ */ new Set(["first-tab"]);
		case "steps": return /* @__PURE__ */ new Set(["first-step"]);
		case "diagram": return /* @__PURE__ */ new Set(["first-node"]);
		case "date": return /* @__PURE__ */ new Set(["empty"]);
		default: return /* @__PURE__ */ new Set(["empty"]);
	}
}
function Ue(e, t, n, r = !1) {
	A(e) || O(n, "must be an object."), j(e, he, n);
	let i = e.kind;
	typeof i == "string" && oe.has(i) || O(`${n}.kind`, "must be \"string\", \"number\", \"boolean\", \"array\", \"number-array\" or \"null\".");
	let a = i, o = e.family;
	typeof o == "string" && se.has(o) || O(`${n}.family`, "must be a supported binding family.");
	let s = o;
	({
		number: /* @__PURE__ */ new Set(["number", "timer"]),
		boolean: /* @__PURE__ */ new Set(["boolean"]),
		string: /* @__PURE__ */ new Set([
			"text",
			"choice",
			"date",
			"tabs",
			"diagram",
			"steps",
			"selection"
		]),
		array: /* @__PURE__ */ new Set([
			"multi-select",
			"checklist",
			"collection"
		]),
		"number-array": /* @__PURE__ */ new Set(["collection"]),
		null: /* @__PURE__ */ new Set(["text"])
	})[a]?.has(s) || O(`${n}.family`, `"${s}" is not supported for a ${a} binding.`);
	let c;
	if (e.options !== void 0) {
		a !== "string" && O(`${n}.options`, "is only valid for a string binding."), s !== "choice" && O(`${n}.options`, "requires family \"choice\".");
		let t = e.options;
		Array.isArray(t) && t.length !== 0 || O(`${n}.options`, "must be a non-empty string array."), t.length > 64 && O(`${n}.options`, "accepts at most 64 values.");
		let r = /* @__PURE__ */ new Set(), i = [];
		for (let e of t) {
			let t = N(e, `${n}.options`, 128);
			t.length === 0 && O(`${n}.options`, "values must be non-empty."), r.has(t) && O(`${n}.options`, `value "${t}" is declared more than once.`), r.add(t), i.push(t);
		}
		c = i;
	}
	a === "string" && s === "choice" && c === void 0 && !r && O(`${n}.options`, "is required for a choice binding."), s !== "choice" && c !== void 0 && O(`${n}.options`, "is only valid for family \"choice\".");
	let l = F(e.bind, `${n}.bind`), u = F(e.initial, `${n}.initial`);
	l === u && O(n, "\"bind\" and \"initial\" must name different attributes."), (D.has(l) || D.has(u)) && O(n, "binding attributes cannot use a reserved slot name."), (Object.hasOwn(t, l) || Object.hasOwn(t, u)) && O(n, "binding attributes are reserved and cannot be declared as props.");
	let d = He(a, s), f;
	if (e.initialRule === void 0) switch (a) {
		case "number":
			f = s === "timer" ? "duration" : "nearest-zero";
			break;
		case "boolean":
			f = "false";
			break;
		case "array":
			f = s === "checklist" ? "checked" : "empty-array";
			break;
		case "number-array":
			f = "empty-array";
			break;
		case "null":
			f = "empty";
			break;
		default: f = s === "choice" ? "first-option" : s === "tabs" ? "first-tab" : s === "steps" ? "first-step" : s === "diagram" ? "first-node" : s === "selection" ? "none" : "empty";
	}
	else typeof e.initialRule == "string" && ce.has(e.initialRule) || O(`${n}.initialRule`, "is not a supported initial rule."), f = e.initialRule;
	d.has(f) || O(`${n}.initialRule`, `is not supported for a ${a} ${s} binding.`), e.required !== void 0 && M(e.required, `${n}.required`), e.exclusive !== void 0 && M(e.exclusive, `${n}.exclusive`), e.retain !== void 0 && M(e.retain, `${n}.retain`);
	let p;
	e.constraints !== void 0 && (p = Ve(e.constraints, t, a, `${n}.constraints`));
	let m;
	if (e.maxItems !== void 0) {
		if (a !== "array" && a !== "number-array" && O(`${n}.maxItems`, "is only valid for array or number-array bindings."), m = Be(e.maxItems, `${n}.maxItems`), "prop" in m) {
			let e = t[m.prop];
			e === void 0 && O(`${n}.maxItems`, `references undeclared prop "${m.prop}".`), e.kind !== "number" && O(`${n}.maxItems`, `references prop "${m.prop}", which is not a number.`), e.dynamic === !0 && O(`${n}.maxItems`, "requires a static numeric property.");
		} else (!Number.isInteger(m.literal) || m.literal < 0) && O(`${n}.maxItems`, "must be a nonnegative integer.");
	}
	let h;
	if (e.requiresAttributes !== void 0) {
		h = R(e.requiresAttributes, `${n}.requiresAttributes`);
		for (let e of h) Object.hasOwn(t, e) || O(`${n}.requiresAttributes`, `references undeclared prop "${e}".`);
	}
	let g;
	if (e.compare !== void 0) {
		g = R(e.compare, `${n}.compare`);
		for (let e of g) Object.hasOwn(t, e) || O(`${n}.compare`, `references undeclared prop "${e}".`);
	}
	return {
		kind: a,
		family: s,
		bind: l,
		initial: u,
		initialRule: f,
		...e.required === !0 ? { required: !0 } : {},
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...c ? { options: c } : {},
		...p ? { constraints: p } : {},
		...m ? { maxItems: m } : {},
		...h ? { requiresAttributes: h } : {},
		...g ? { compare: g } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function We(e, t) {
	A(e) || O(t, "must be an object."), j(e, xe, t);
	let n = e.id;
	(typeof n != "string" || !w.test(n) || n.length > 160) && O(`${t}.id`, "must be a lowercase namespaced id.");
	let r;
	if (e.version !== void 0) {
		let n = e.version, i = a(n);
		i === null && O(`${t}.version`, "must be an exact version or a supported range (exact, ^, ~, >=, <=, >, <)."), r = i.source;
	}
	return {
		id: n,
		...r ? { version: r } : {}
	};
}
function Ge(e) {
	A(e) || O("requires", "must be an object."), j(e, Se, "requires");
	let t;
	if (e.kernel !== void 0) {
		let n = a(e.kernel);
		n === null && O("requires.kernel", "must be a supported kernel version range (exact, ^, ~, >=, <=, >, <)."), t = n.source;
	}
	return { ...t ? { kernel: t } : {} };
}
function Ke(e, t) {
	A(e) || O("replaces", "must be an object."), j(e, Ce, "replaces");
	let n = e.id;
	(typeof n != "string" || !w.test(n) || n.length > 160) && O("replaces.id", "must be a lowercase namespaced id."), n !== t && O("replaces.id", "must equal the declaring manifest id.");
	let r;
	if (e.version !== void 0) {
		let t = a(e.version);
		t === null && O("replaces.version", "must be an exact version or a supported range (exact, ^, ~, >=, <=, >, <)."), r = t.source;
	}
	return {
		id: n,
		...r ? { version: r } : {}
	};
}
function qe(e) {
	Array.isArray(e) || O("styles", "must be an array of style-resource ids."), e.length > 32 && O("styles", "accepts at most 32 resources.");
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r];
		(typeof i != "string" || i.length === 0 || i.length > 256) && O(`styles[${r}]`, "must be a non-empty string of at most 256 characters."), we.test(i) || O(`styles[${r}]`, "must be a bounded resource id."), t.has(i) && O("styles", `resource "${i}" is declared more than once.`), t.add(i), n.push(i);
	}
	return n;
}
function W(e) {
	if (typeof e == "object" && e && E.has(e)) return e;
	A(e) || O("manifest", "must be an object."), j(e, pe, "manifest");
	let t = e.id;
	(typeof t != "string" || t.length > 160 || !w.test(t)) && O("id", "must be a lowercase namespaced id such as \"example/rating\".");
	let n = F(e.name, "name"), r = e.version;
	(typeof r != "string" || r.length > 64 || !ne.test(r)) && O("version", "must be a semantic version such as 1.0.0."), e.protocol !== "reactive-md-component/v1" && O("protocol", `must be "${o}".`);
	let i = e.form;
	typeof i == "string" && ae.has(i) || O("form", "must be \"leaf\", \"inline\" or \"container\".");
	let a = i;
	A(e.props) || O("props", "must be an object.");
	let s = Object.keys(e.props).sort();
	s.length > 64 && O("props", "accepts at most 64 properties.");
	let c = {};
	for (let t of s) T.has(t) && O("props", `property "${t}" is not allowed.`), (!C.test(t) || t.length > 128) && O("props", `property "${t}" must use lowercase kebab-case.`), c[t] = ze(e.props[t], `props.${t}`);
	let l;
	if (e.bindings !== void 0) {
		A(e.bindings) || O("bindings", "must be an object.");
		let t = Object.keys(e.bindings);
		t.length === 0 && O("bindings", "must declare at least one binding slot."), t.length > 16 && O("bindings", "accepts at most 16 slots.");
		let n = {}, r = /* @__PURE__ */ new Set();
		for (let i of t) {
			T.has(i) && O("bindings", `field "${i}" is not allowed.`), Te.test(i) || O("bindings", `slot "${i}" must be a letter followed by letters or digits.`), D.has(i) && O("bindings", `slot "${i}" is reserved by the runtime.`);
			let t = Ue(e.bindings[i], c, `bindings.${i}`, a === "container" && Array.isArray(e.rules) && e.rules.some((e) => A(e) && e.kind === "options-body"));
			i !== "value" && (t.kind !== "number" || t.family !== "number") && O(`bindings.${i}`, "numeric named slots support kind \"number\" with family \"number\" in this contract."), i !== "value" && A(e.bindings[i]) && e.bindings[i].exclusive === !1 && O(`bindings.${i}.exclusive`, "named slots require exclusive ownership in this contract.");
			for (let e of [t.bind, t.initial]) r.has(e) && O("bindings", `attribute "${e}" is claimed by more than one binding.`), r.add(e);
			n[i] = i === "value" ? t : {
				...t,
				exclusive: !0
			};
		}
		l = n;
	}
	let u = e.children === void 0 ? void 0 : Me(e.children, a, "children");
	e.children !== void 0 && e.structure !== void 0 && O("manifest", "cannot declare both \"children\" and \"structure\"; use \"structure\".");
	let d = e.structure === void 0 ? L(u) : Ne(e.structure, a, "structure"), f = e.rules === void 0 ? void 0 : Ie(e.rules), p = e.slotRelations === void 0 ? void 0 : Le(e.slotRelations);
	e.legacyHost !== void 0 && M(e.legacyHost, "legacyHost");
	let m = Re(e.capabilities, "capabilities"), h = e.authoring === void 0 ? void 0 : je(e.authoring, "authoring"), g = e.styles === void 0 ? void 0 : qe(e.styles), _ = e.requires === void 0 ? void 0 : Ge(e.requires), v = e.replaces === void 0 ? void 0 : Ke(e.replaces, t), y;
	if (e.dependencies !== void 0) {
		Array.isArray(e.dependencies) || O("dependencies", "must be an array."), e.dependencies.length > 16 && O("dependencies", "accepts at most 16 entries.");
		let t = /* @__PURE__ */ new Set(), n = [];
		for (let r = 0; r < e.dependencies.length; r += 1) {
			let i = We(e.dependencies[r], `dependencies[${r}]`);
			t.has(i.id) && O("dependencies", `"${i.id}" is declared more than once.`), t.add(i.id), n.push(i);
		}
		y = n;
	}
	let b = {
		id: t,
		name: n,
		version: r,
		protocol: o,
		form: a,
		props: c,
		...l ? { bindings: l } : {},
		...u ? { children: u } : {},
		...d && !u ? { structure: d } : {},
		...f ? { rules: f } : {},
		...p ? { slotRelations: p } : {},
		...e.legacyHost === !0 ? { legacyHost: !0 } : {},
		capabilities: m,
		...h ? { authoring: h } : {},
		...g ? { styles: g } : {},
		..._ ? { requires: _ } : {},
		...y ? { dependencies: y } : {},
		...v ? { replaces: v } : {}
	};
	k(b) > 65536 && O("manifest", `serialized size exceeds the ${S}-byte budget.`);
	let x = Ye(b);
	return E.add(x), x;
}
function Je(e) {
	return W(e);
}
function Ye(e) {
	if (typeof e != "object" || !e) return e;
	for (let t of Object.keys(e)) Ye(e[t]);
	return Object.freeze(e);
}
function Xe(e) {
	return {
		kind: e.kind,
		...e.required === !0 ? { required: !0 } : {},
		...e.static === !0 ? { static: !0 } : {},
		...e.dynamic === void 0 ? {} : { dynamic: e.dynamic },
		...e.default === void 0 ? {} : { default: e.default },
		...e.nullable === !0 ? { nullable: !0 } : {},
		...e.enum ? { enum: [...e.enum] } : {},
		...e.pattern === void 0 ? {} : { pattern: e.pattern },
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.integer === !0 ? { integer: !0 } : {},
		...e.positive === !0 ? { positive: !0 } : {},
		...e.color === !0 ? { color: !0 } : {},
		...e.coerce === void 0 ? {} : { coerce: e.coerce }
	};
}
function G(e) {
	return "literal" in e ? { literal: e.literal } : { prop: e.prop };
}
function Ze(e) {
	return {
		...e.min ? { min: G(e.min) } : {},
		...e.max ? { max: G(e.max) } : {},
		...e.step ? { step: G(e.step) } : {}
	};
}
function Qe(e) {
	let t = e.constraints;
	return {
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule,
		...e.required === !0 ? { required: !0 } : {},
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...e.options ? { options: [...e.options] } : {},
		...t ? { constraints: Ze(t) } : {},
		...e.maxItems ? { maxItems: G(e.maxItems) } : {},
		...e.requiresAttributes ? { requiresAttributes: [...e.requiresAttributes] } : {},
		...e.compare ? { compare: [...e.compare] } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function $e(e) {
	return {
		rule: e.rule,
		...e.label === void 0 ? {} : { label: e.label },
		...e.parents ? { parents: [...e.parents] } : {},
		...e.child === void 0 ? {} : { child: e.child },
		...e.children ? { children: [...e.children] } : {},
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.inlineOnly === void 0 ? {} : { inlineOnly: e.inlineOnly },
		...e.noComponents === void 0 ? {} : { noComponents: e.noComponents },
		...e.valueAttribute === void 0 ? {} : { valueAttribute: e.valueAttribute },
		...e.generatedPrefix === void 0 ? {} : { generatedPrefix: e.generatedPrefix },
		...e.forbidSeparator === void 0 ? {} : { forbidSeparator: e.forbidSeparator },
		...e.maxItems === void 0 ? {} : { maxItems: e.maxItems }
	};
}
function et(e) {
	let t = e, n = Object.keys(t).sort(), r = {};
	for (let e of n) {
		let n = t[e];
		r[e] = Array.isArray(n) ? n.map((e) => Array.isArray(e) ? [...e] : e) : n;
	}
	return r;
}
function tt(e) {
	let t = {};
	for (let n of Object.keys(e.props).sort()) t[n] = Xe(e.props[n]);
	let n = {};
	if (e.bindings) for (let t of Object.keys(e.bindings).sort()) n[t] = Qe(e.bindings[t]);
	return {
		protocol: e.protocol,
		id: e.id,
		name: e.name,
		version: e.version,
		form: e.form,
		props: t,
		...e.bindings ? { bindings: n } : {},
		...e.children ? { children: {
			kind: e.children.kind,
			...e.children.required ? { required: !0 } : {}
		} } : {},
		...e.structure ? { structure: $e(e.structure) } : {},
		...e.rules ? { rules: e.rules.map(et) } : {},
		...e.slotRelations ? { slotRelations: e.slotRelations.map((e) => ({ ...e })) } : {},
		capabilities: {
			interactive: e.capabilities.interactive,
			static: e.capabilities.static,
			ssr: e.capabilities.ssr,
			offline: e.capabilities.offline
		},
		...e.styles ? { styles: [...e.styles] } : {},
		...e.requires?.kernel ? { requires: { kernel: e.requires.kernel } } : {},
		...e.dependencies ? { dependencies: [...e.dependencies].map((e) => ({ ...e })).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)) } : {},
		...e.replaces ? { replaces: {
			id: e.replaces.id,
			...e.replaces.version ? { version: e.replaces.version } : {}
		} } : {}
	};
}
var nt = /* @__PURE__ */ new WeakMap();
function K(e) {
	let t = E.has(e) ? e : W(e), n = nt.get(t);
	if (n !== void 0) return n;
	let r = u(JSON.stringify(tt(t)));
	return nt.set(t, r), r;
}
function rt(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: K(e)
	});
}
function it(e) {
	return typeof e == "string" && e.length <= 128 && C.test(e);
}
function q(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 160 && w.test(e);
}
// src/presets/identity.ts
var at = "reactive-md/default", ot = "reactive-md/minimal", st = r, ct = 160, lt = 256, ut = 32, dt = 256, ft = 4096, pt = /^[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*$/, mt = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), ht = /* @__PURE__ */ new Set([
	"protocol",
	"id",
	"version",
	"components",
	"authoring",
	"themes",
	"dependencies",
	"metadata"
]), gt = /* @__PURE__ */ new Set([
	"title",
	"description",
	"category",
	"insertText"
]), _t = /* @__PURE__ */ new Set(["title", "description"]), vt = /* @__PURE__ */ new Set(["id", "version"]), J = /* @__PURE__ */ new WeakSet();
function Y(e, t) {
	throw Error(`Invalid local preset (${e}): ${t}`);
}
function X(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function Z(e, t, n) {
	for (let r of Object.keys(e)) mt.has(r) && Y(n, `field "${r}" is not allowed.`), t.has(r) || Y(n, `unknown field "${r}".`);
}
function Q(e, t) {
	X(e) || Y(t, "must be a locale-keyed string map.");
	let n = {};
	for (let r of Object.keys(e).sort()) {
		mt.has(r) && Y(t, `locale "${r}" is not allowed.`), /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(r) || Y(t, `locale "${r}" must look like "en" or "zh-CN".`);
		let i = e[r];
		(typeof i != "string" || i.length > ft) && Y(t, `locale "${r}" must be a bounded string.`), n[r] = i;
	}
	return Object.freeze(n);
}
function yt(e) {
	X(e) || Y("authoring", "must be an object."), Z(e, gt, "authoring");
	let t = {};
	return e.title !== void 0 && (t.title = Q(e.title, "authoring.title")), e.description !== void 0 && (t.description = Q(e.description, "authoring.description")), e.category !== void 0 && ((typeof e.category != "string" || e.category.length > 64) && Y("authoring.category", "must be a bounded string."), t.category = e.category), e.insertText !== void 0 && ((typeof e.insertText != "string" || e.insertText.length > ft) && Y("authoring.insertText", "must be a bounded string."), t.insertText = e.insertText), Object.freeze(t);
}
function bt(e, t) {
	Array.isArray(e) || Y("authoring", "must be an array."), e.length > dt && Y("authoring", `accepts at most ${dt} entries.`);
	let n = new Set(t.map((e) => e.id)), r = /* @__PURE__ */ new Set(), i = [];
	for (let t = 0; t < e.length; t += 1) {
		let a = e[t];
		X(a) || Y(`authoring[${t}]`, "must be an object."), Z(a, /* @__PURE__ */ new Set(["componentId", "authoring"]), `authoring[${t}]`);
		let o = a.componentId;
		typeof o == "string" && q(o) || Y(`authoring[${t}].componentId`, "must be a lowercase namespaced id."), n.has(o) || Y(`authoring[${t}].componentId`, `"${o}" is not declared by this preset.`), r.has(o) && Y("authoring", `component "${o}" is declared more than once.`), r.add(o), i.push(Object.freeze({
			componentId: o,
			authoring: yt(a.authoring)
		}));
	}
	return Object.freeze(i.sort((e, t) => e.componentId < t.componentId ? -1 : +(e.componentId > t.componentId)));
}
function xt(e) {
	Array.isArray(e) || Y("dependencies", "must be an array."), e.length > ut && Y("dependencies", `accepts at most ${ut} entries.`);
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let a = e[r];
		X(a) || Y(`dependencies[${r}]`, "must be an object."), Z(a, vt, `dependencies[${r}]`);
		let o = a.id;
		typeof o == "string" && q(o) || Y(`dependencies[${r}].id`, "must be a lowercase namespaced id."), t.has(o) && Y("dependencies", `"${o}" is declared more than once.`), t.add(o);
		let s = a.version;
		typeof s == "string" && i(s) || Y(`dependencies[${r}].version`, "must be an exact semantic version."), n.push(Object.freeze({
			id: o,
			version: s
		}));
	}
	return Object.freeze(n.sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function St(e) {
	Array.isArray(e) || Y("themes", "must be an array.");
	let t = [], n = /* @__PURE__ */ new Set(), r = /* @__PURE__ */ new Set();
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		X(o) || Y(`themes[${a}]`, "must be an object.");
		let s = o.id, c = o.name, l = o.version;
		(typeof s != "string" || s.length === 0) && Y(`themes[${a}].id`, "must be a non-empty string."), (typeof c != "string" || c.length === 0) && Y(`themes[${a}].name`, "must be a non-empty string."), typeof l == "string" && i(l) || Y(`themes[${a}].version`, "must be a semantic version."), n.has(s) && Y("themes", `theme id "${s}" is declared more than once.`), r.has(c) && Y("themes", `theme name "${c}" is declared more than once.`), n.add(s), r.add(c), t.push(Object.freeze({ ...o }));
	}
	return Object.freeze(t.sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function Ct(e) {
	return X(e) || Y("metadata", "must be an object."), Z(e, _t, "metadata"), Object.freeze({
		...e.title === void 0 ? {} : { title: Q(e.title, "metadata.title") },
		...e.description === void 0 ? {} : { description: Q(e.description, "metadata.description") }
	});
}
function $(e) {
	if (X(e) && J.has(e)) return e;
	X(e) || Y("preset", "must be an object."), Z(e, ht, "preset"), e.protocol !== "reactive-md-preset/v1" && Y("protocol", `must be "${s}".`);
	let t = e.id;
	(typeof t != "string" || t.length > ct || !pt.test(t)) && Y("id", "must be a lowercase namespaced id.");
	let n = e.version;
	typeof n == "string" && i(n) || Y("version", "must be a semantic version such as \"1.0.0\"."), Array.isArray(e.components) || Y("components", "must be an array."), e.components.length > lt && Y("components", `accepts at most ${lt} components.`);
	let r = [], a = /* @__PURE__ */ new Set(), o = /* @__PURE__ */ new Set();
	for (let t = 0; t < e.components.length; t += 1) {
		let n;
		try {
			n = Je(e.components[t]);
		} catch (e) {
			Y(`components[${t}]`, e instanceof Error ? e.message : String(e));
		}
		a.has(n.id) && Y("components", `component id "${n.id}" is declared more than once.`), o.has(n.name) && Y("components", `component name "${n.name}" is declared more than once.`), a.add(n.id), o.add(n.name), r.push(n);
	}
	let c = e.authoring === void 0 ? void 0 : bt(e.authoring, r), l = e.themes === void 0 ? void 0 : St(e.themes), u = e.dependencies === void 0 ? void 0 : xt(e.dependencies), d = e.metadata === void 0 ? void 0 : Ct(e.metadata), f = e.components, p = Object.isFrozen(f) && f.length === r.length && f.every((e, t) => e === r[t]) ? f : Object.freeze(r), m = Object.freeze({
		protocol: s,
		id: t,
		version: n,
		components: p,
		...c ? { authoring: c } : {},
		...l ? { themes: l } : {},
		...u ? { dependencies: u } : {},
		...d ? { metadata: d } : {}
	});
	return J.add(m), m;
}
function wt(e) {
	return $(e);
}
function Tt(e) {
	let t = $(e);
	return u(JSON.stringify({
		protocol: s,
		id: t.id,
		version: t.version,
		components: [...t.components].map((e) => ({
			id: e.id,
			version: e.version,
			digest: K(e)
		})).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)),
		dependencies: [...t.dependencies ?? []].map((e) => ({
			id: e.id,
			version: e.version
		})).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id))
	}));
}
export { k as A, _ as C, it as D, q as E, W as M, f as N, K as O, u as P, te as S, Je as T, De as _, st as a, ke as b, Ee as c, v as d, g as f, m as g, y as h, at as i, L as j, rt as k, p as l, h as m, Tt as n, ot as o, S as p, $ as r, Ae as s, wt as t, x as u, Oe as v, tt as w, ee as x, b as y };
