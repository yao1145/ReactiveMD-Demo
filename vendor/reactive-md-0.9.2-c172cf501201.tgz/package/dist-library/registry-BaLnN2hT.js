import { t as e } from "./registry-core-C9xOunaw.js";
import { t } from "./default-components-s21NevON.js";
import { s as n } from "./config-DA_bEhiK.js";
// src/sdk/registry.ts
function r() {
	return t;
}
function i(e) {
	return e ? n(e).registry : r();
}
function a(e, t) {
	let n = i(t);
	for (let t of n) if (t.name === e) return t;
}
function o(t) {
	let n = /* @__PURE__ */ new Map();
	for (let r of i(t)) n.set(r.name, e(r));
	return n;
}
export { i as n, o as r, a as t };
