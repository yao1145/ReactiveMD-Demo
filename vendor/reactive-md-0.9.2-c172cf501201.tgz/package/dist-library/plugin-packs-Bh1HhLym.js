import { o as e } from "./version-DAxuGOG2.js";
import { a as t, t as n } from "./preset-core-DeZPA8IE.js";
import { t as r } from "./default-components-s21NevON.js";
// src/presets/plugin-packs.ts
function i(i, a, o = []) {
	let s = r.filter((e) => a.includes(e.name));
	if (s.length !== a.length) throw Error(`Invalid official component list for ${i}.`);
	return n({
		id: i,
		version: t,
		protocol: e,
		components: s,
		dependencies: o.map((e) => ({
			id: e,
			version: t
		}))
	});
}
export { i as t };
