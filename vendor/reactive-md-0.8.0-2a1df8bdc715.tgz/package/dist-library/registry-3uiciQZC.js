import { F as e, M as t, P as n, a as r, i, j as a, k as o, q as s } from "./identity-D1cB_NI3.js";
import { $ as c, S as l, _ as u, a as d, c as f, d as p, g as m, h as ee, i as h, m as te, n as g, nt as _, o as ne, p as re, r as v, s as ie, t as ae, v as oe, y as se } from "./config-validation-Dcg9tIe2.js";
import { t as ce } from "./default-components-BdI438Uo.js";
import y from "./reactive-md-default-preset.js";
// src/local/theme/theme.ts
var b = "reactive-md-theme-1", x = Object.freeze({
	name: "default",
	protocol: b,
	colorSchemes: Object.freeze(["light", "dark"])
});
function le(e, t) {
	let n = typeof t == "string" ? t.length : Infinity;
	if (!e || typeof e.start != "number" || typeof e.end != "number" || !Number.isFinite(e.start) || !Number.isFinite(e.end)) return {
		start: 0,
		end: 0
	};
	let r = Math.max(0, Math.min(n, Math.floor(e.start)));
	return {
		start: r,
		end: Math.max(r, Math.min(n, Math.floor(e.end)))
	};
}
function ue(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.min(t, e.length), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: t - i + 1
	};
}
function de(e, t, n, r) {
	let i = le(n, r), { line: a, column: o } = ue(r, i.start);
	return {
		code: e,
		message: c(t),
		severity: "warning",
		range: i,
		line: a,
		column: o,
		messageKey: t.key,
		...t.params ? { params: t.params } : {}
	};
}
function fe(e, t, n, r) {
	let i = (e, t) => ({
		name: x.name,
		diagnostics: [de(e, t, n, r)]
	}), a = e;
	if (a == null || a === "") return {
		name: x.name,
		diagnostics: []
	};
	if (!l(a)) return i("local.theme.name", _("local.theme.name", {
		name: String(a),
		limit: 64
	}));
	let o = a;
	if (o === x.name) return {
		name: x.name,
		diagnostics: []
	};
	if (!Array.isArray(t)) return i("local.theme.missing", _("local.theme.missing", { name: o }));
	let s = 0, c = null;
	try {
		for (let e of t) typeof e == "object" && e && !Array.isArray(e) && e.name === o && (s += 1, c = e);
	} catch {
		return i("local.theme.manifest", _("local.theme.manifest.unreadable"));
	}
	if (s === 0) return i("local.theme.missing", _("local.theme.missing", { name: o }));
	if (s > 1) return i("local.theme.duplicate", _("local.theme.duplicate", { name: o }));
	try {
		let e = c;
		if (!e || typeof e != "object") return i("local.theme.manifest", _("local.theme.manifest.definition", { name: o }));
		if (e.protocol !== "reactive-md-theme-1") return i("local.theme.protocol", _("local.theme.protocol", {
			name: o,
			protocol: b
		}));
		let t = e.colorSchemes;
		if (!Array.isArray(t) || !t.includes("light") || !t.includes("dark")) return i("local.theme.modes", _("local.theme.modes", { name: o }));
	} catch {
		return i("local.theme.manifest", _("local.theme.manifest.selected", { name: o }));
	}
	return {
		name: o,
		diagnostics: []
	};
}
// src/themes/contract.ts
var pe = "reactive-md-styles-1", me = Object.freeze([
	"rmd.reset",
	"rmd.defaults",
	"rmd.components",
	"rmd.themes",
	"rmd.overrides"
]), he = "rmd.themes", S = `@layer ${me.join(", ")};`, ge = 128, _e = 32, ve = 128, C = 262144, w = 524288, ye = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/, be = /^[a-z][a-z0-9._/-]*$/, xe = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/, Se = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/, Ce = /^(?::root|html|body)(?![A-Za-z0-9_-])/i, we = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]), Te = 256, Ee = /* @__PURE__ */ new Set([
	"serif",
	"sans-serif",
	"monospace",
	"cursive",
	"fantasy",
	"system-ui",
	"ui-serif",
	"ui-sans-serif",
	"ui-monospace",
	"ui-rounded",
	"math",
	"emoji",
	"fangsong",
	"-apple-system",
	"blinkmacsystemfont"
]), T = /* @__PURE__ */ new Set([
	"inherit",
	"initial",
	"unset",
	"revert",
	"revert-layer"
]), De = /* @__PURE__ */ new Set([
	"caption",
	"icon",
	"menu",
	"message-box",
	"small-caption",
	"status-bar"
]), Oe = /* @__PURE__ */ new Set([
	"xx-small",
	"x-small",
	"small",
	"medium",
	"large",
	"x-large",
	"xx-large",
	"xxx-large",
	"smaller",
	"larger"
]), ke = /^rmd-theme-([a-z][a-z0-9-]*)-font-([0-9a-f]+)$/;
function E(e, t) {
	return /* @__PURE__ */ Error(`Invalid local theme ${e}: ${t}`);
}
function Ae(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function D(e, t) {
	if (!Ae(e)) throw E(t, "must be an object.");
	return e;
}
function O(e, t) {
	if (typeof e != "string" || e.length === 0) throw E(t, "must be a non-empty string.");
	if (e.length > ge) throw E(t, `must not exceed ${ge} characters.`);
	if (!ye.test(e)) throw E(t, `"${e}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return e;
}
function k(e, t) {
	if (!l(e)) throw E(t, "must be a lowercase kebab-case name that starts with a letter.");
	if (e === "default") throw E(t, "must not replace the reserved built-in \"default\" theme.");
	return e;
}
function A(e, t) {
	if (typeof e != "string" || !xe.test(e)) throw E(t, "must be a semantic version such as \"1.0.0\".");
	return e;
}
function je(e, t) {
	if (e === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(e)) throw E(t, "must be an array of \"light\" and \"dark\".");
	let n = [];
	for (let r of e) {
		if (r !== "light" && r !== "dark") throw E(t, "may only contain \"light\" and \"dark\".");
		if (n.includes(r)) throw E(t, `must not repeat "${r}".`);
		n.push(r);
	}
	if (!n.includes("light") || !n.includes("dark")) throw E(t, "must declare both \"light\" and \"dark\".");
	return Object.freeze(n);
}
function j(e, t) {
	let n = e[t], r = t + 1;
	for (; r < e.length;) if (e[r] === "\\") r += 2;
	else {
		if (e[r] === n) return r + 1;
		r += 1;
	}
	return e.length;
}
function M(e, t, n, r) {
	let i = 0;
	for (let a = t; a < e.length; a += 1) {
		let t = e[a];
		if (t === "\"" || t === "'") a = j(e, a) - 1;
		else if (t === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === n) i += 1;
		else if (t === r && (--i, i === 0)) return a + 1;
	}
	return e.length;
}
function Me(e, t, n) {
	let r = t + 3;
	for (; r < e.length && /\s/.test(e[r]);) r += 1;
	if (e[r] !== "(") throw E(n, "has a malformed url() value.");
	for (r += 1; r < e.length && /\s/.test(e[r]);) r += 1;
	let i = e[r];
	if (i === "\"" || i === "'") {
		let t = e.indexOf(i, r + 1);
		if (t < 0) throw E(n, "has an unterminated url() string.");
		let a = e.slice(r + 1, t);
		for (r = t + 1; r < e.length && /\s/.test(e[r]);) r += 1;
		if (e[r] !== ")") throw E(n, "has a malformed url() value.");
		return {
			value: a.trim(),
			end: r + 1
		};
	}
	let a = e.indexOf(")", r);
	if (a < 0) throw E(n, "has an unterminated url() value.");
	return {
		value: e.slice(r, a).trim(),
		end: a + 1
	};
}
function Ne(e, t, n, r) {
	let i = t;
	for (; i < e.length && e[i] !== "(";) i += 1;
	if (i >= e.length) throw E(r, `has a malformed ${n}() value.`);
	let a = M(e, i, "(", ")");
	if (a <= i + 1 || e[a - 1] !== ")") throw E(r, `has an unterminated ${n}() value.`);
	return {
		body: e.slice(i + 1, a - 1),
		end: a
	};
}
function Pe(e, t) {
	let n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (r === "\"" || r === "'") {
			let i = j(e, n);
			if (i > e.length || e[i - 1] !== r) throw E(t, "has an unterminated image-set() string.");
			let a = e.slice(n + 1, i - 1).trim();
			if (!/^data:/i.test(a)) throw E(t, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			n = i;
		} else if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else n += 1;
	}
}
function Fe(e, t, n = !1) {
	if (e.toLowerCase().includes("</style")) throw E(t, "must not contain a closing style tag.");
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = j(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else {
			if (i === "\\") throw E(t, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
			if (i === "@" && /^@import\b/i.test(e.slice(r, r + 8))) throw E(t, "must not use @import; inline every resource.");
			if ((i === "i" || i === "I" || i === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(e.slice(r, r + 24))) {
				let { body: n } = Ne(e, r, "image-set", t);
				Pe(n, t), r += 1;
			} else if ((i === "u" || i === "U") && /^url\s*\(/i.test(e.slice(r, r + 12))) {
				let i = Me(e, r, t);
				if (!/^data:/i.test(i.value) && !(n && i.value.startsWith("#"))) throw E(t, "may only reference data: URLs; network and file URLs are not allowed.");
				r = i.end;
			} else {
				if ((i === "e" || i === "E") && /^expression\s*\(/i.test(e.slice(r, r + 16))) throw E(t, "must not use CSS expression().");
				r += 1;
			}
		}
	}
}
function Ie(e) {
	if (typeof e != "string" || e.length > 4194304) return !1;
	try {
		return Fe(e, "css", !0), !0;
	} catch {
		return !1;
	}
}
function Le(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		if (o === "\"" || o === "'") a = j(e, a) - 1;
		else if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else o === "\\" ? a += 1 : o === "(" ? r += 1 : o === ")" ? r = Math.max(0, r - 1) : o === "[" ? i += 1 : o === "]" ? i = Math.max(0, i - 1) : o === "," && r === 0 && i === 0 && (t.push(e.slice(n, a)), n = a + 1);
	}
	return t.push(e.slice(n)), t;
}
function Re(e, t) {
	let n = e.trim(), r = `[data-rmd-theme="${t}"]`, i = Se.exec(n);
	return i ? `${r}${n.slice(i[0].length)}` : `${r} ${n}`;
}
function N(e, t) {
	let n = t;
	for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
	else if (e[n] === "/" && e[n + 1] === "*") {
		let t = e.indexOf("*/", n + 2);
		n = t < 0 ? e.length : t + 2;
	} else break;
	return n;
}
function ze(e, t) {
	let n = e.toLowerCase(), r = /:has\s*\(/g;
	for (let i = r.exec(n); i; i = r.exec(n)) {
		if (r.lastIndex = i.index + 1, i.index >= t) continue;
		let n = i.index + i[0].length - 1, a = M(e, n, "(", ")"), o = e.slice(n + 1, Math.max(n + 1, a - 1));
		for (let t of Le(o)) if (/^\s*[+~]/.test(t)) throw E("theme.css", `selector "${e.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
function Be(e) {
	let t = e.trim();
	if (t === "") return;
	if (t[0] === "+" || t[0] === "~") throw E("theme.css", `selector "${t}" begins with a sibling combinator and cannot be scoped.`);
	let n = Se.exec(t);
	if (n) {
		let e = n[0].length;
		for (; e < t.length;) {
			let n = t[e];
			if (/\s/.test(n) || n === "+" || n === "~" || n === ">" || n === ",") break;
			n === "[" ? e = M(t, e, "[", "]") : n === "(" ? e = M(t, e, "(", ")") : e += 1;
		}
		let r = N(t, e);
		if (t[r] === "+" || t[r] === "~") throw E("theme.css", `selector "${t}" uses a sibling combinator that can escape the theme root.`);
		ze(t, e);
	}
}
function Ve(e, t) {
	let n = Le(e).map((e) => e.trim()).filter(Boolean);
	if (n.length === 0) return e.trim();
	for (let e of n) {
		if (Ce.test(e)) throw E("theme.css", `selector "${e}" targets the host document; scope it under the theme root instead.`);
		Be(e);
	}
	return n.map((e) => Re(e, t)).join(", ");
}
function P(e, t) {
	let n = 1;
	for (let r = t; r < e.length; r += 1) {
		let t = e[r];
		if (t === "\"" || t === "'") r = j(e, r) - 1;
		else if (t === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return r;
	}
	return e.length;
}
function F(e) {
	return e.trim().replace(/\s+/g, " ").toLowerCase();
}
function He(e) {
	let t = [];
	for (let n of e) {
		let e = n.codePointAt(0);
		e <= 127 ? t.push(e) : e <= 2047 ? t.push(192 | e >> 6, 128 | e & 63) : e <= 65535 ? t.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : t.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63);
	}
	return t;
}
function Ue(e) {
	let t = "", n = 0;
	for (; n < e.length;) {
		let r = e[n], i, a;
		if (r <= 127) i = r, a = 1;
		else if (r >= 194 && r <= 223) i = r & 31, a = 2;
		else if (r >= 224 && r <= 239) i = r & 15, a = 3;
		else if (r >= 240 && r <= 244) i = r & 7, a = 4;
		else return null;
		if (n + a > e.length) return null;
		for (let t = 1; t < a; t += 1) {
			let r = e[n + t];
			if ((r & 192) != 128) return null;
			i = i << 6 | r & 63;
		}
		if (a === 3 && (i < 2048 || i >= 55296 && i <= 57343) || a === 4 && (i < 65536 || i > 1114111)) return null;
		t += String.fromCodePoint(i), n += a;
	}
	return t;
}
function We(e, t) {
	return `rmd-theme-${e}-font-${He(t).map((e) => e.toString(16).padStart(2, "0")).join("")}`;
}
function Ge(e) {
	let t = ke.exec(e);
	if (!t || t[2].length % 2 != 0) return null;
	let n = [];
	for (let e = 0; e < t[2].length; e += 2) n.push(Number.parseInt(t[2].slice(e, e + 2), 16));
	let r = Ue(n);
	return r === null || r.length === 0 || F(r) !== r ? null : {
		themeName: t[1],
		original: r
	};
}
function Ke(e) {
	return e === void 0 ? !1 : /[A-Za-z0-9_-]/.test(e) || e.codePointAt(0) >= 128;
}
function qe(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (/[A-Za-z_]/.test(n) || n.codePointAt(0) >= 128) return !0;
	if (n === "-") {
		let n = e[t + 1];
		return n !== void 0 && (Ke(n) || n === "-");
	}
	return !1;
}
function Je(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (n >= "0" && n <= "9") return !0;
	let r = e[t + 1];
	return n === "+" || n === "-" ? r !== void 0 && (r >= "0" && r <= "9" || r === ".") : n === "." && r !== void 0 && r >= "0" && r <= "9";
}
function I(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
			continue;
		}
		let i = n;
		if (r === "\"" || r === "'") {
			let r = j(e, n);
			t.push({
				type: "string",
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: e.slice(i + 1, Math.max(i + 1, r - 1))
			}), n = r;
		} else if (r === ",") t.push({
			type: "comma",
			text: ",",
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
		else if (Je(e, n)) {
			let r = n;
			for ((e[r] === "+" || e[r] === "-") && (r += 1); e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === ".") for (r += 1; e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === "e" || e[r] === "E") {
				let t = r;
				r += 1, (e[r] === "+" || e[r] === "-") && (r += 1);
				let n = r;
				for (; e[r] >= "0" && e[r] <= "9";) r += 1;
				r === n && (r = t);
			}
			let a = "number";
			if (e[r] === "%") r += 1, a = "percentage";
			else if (qe(e, r)) {
				for (r += 1; Ke(e[r]);) r += 1;
				a = "dimension";
			}
			t.push({
				type: a,
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: ""
			}), n = r;
		} else if (qe(e, n)) {
			let r = n + 1;
			for (; Ke(e[r]);) r += 1;
			let a = e.slice(n, r).toLowerCase();
			if (e[r] === "(") {
				let o = M(e, r, "(", ")"), s = Math.min(o, e.length);
				t.push({
					type: "function",
					text: e.slice(n, s),
					start: i,
					end: s,
					name: a,
					stringValue: ""
				}), n = s;
				continue;
			}
			t.push({
				type: "ident",
				text: e.slice(n, r),
				start: i,
				end: r,
				name: a,
				stringValue: ""
			}), n = r;
		} else if (r === "(") {
			let r = M(e, n, "(", ")"), a = Math.min(r, e.length);
			t.push({
				type: "function",
				text: e.slice(n, a),
				start: i,
				end: a,
				name: "",
				stringValue: ""
			}), n = a;
		} else t.push({
			type: "delimiter",
			text: r,
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
	}
	return t;
}
function Ye(e) {
	return N(e, 0) === e.length;
}
function L(e) {
	let t = I(e);
	if (t.length === 0) return null;
	if (t.length === 1 && t[0].type === "string") {
		let e = F(t[0].stringValue);
		return e === "" ? null : {
			key: e,
			start: t[0].start,
			end: t[0].end
		};
	}
	if (t[0].type === "string") return null;
	for (let n = 0; n < t.length; n += 1) if (t[n].type !== "ident" || n > 0 && !Ye(e.slice(t[n - 1].end, t[n].start))) return null;
	if (t.length === 1 && (T.has(t[0].name) || Ee.has(t[0].name))) return null;
	let n = F(t.map((e) => e.text).join(" "));
	return n === "" ? null : {
		key: n,
		start: t[0].start,
		end: t[t.length - 1].end
	};
}
function R(e) {
	let t = [], n = 0, r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = j(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else i === "(" || i === "[" ? r = M(e, r, i, i === "(" ? ")" : "]") : (i === "," && (t.push({
			start: n,
			end: r
		}), n = r + 1), r += 1);
	}
	return t.push({
		start: n,
		end: e.length
	}), t;
}
function z(e) {
	let t = I(e);
	if (t.length < 2) return {
		body: e,
		important: ""
	};
	let n = t[t.length - 1], r = t[t.length - 2];
	return n.type !== "ident" || n.name !== "important" || r.type !== "delimiter" || r.text !== "!" || !Ye(e.slice(r.end, n.start)) ? {
		body: e,
		important: ""
	} : {
		body: e.slice(0, r.start),
		important: e.slice(r.start)
	};
}
function B(e, t) {
	if (t.length === 0) return e;
	let n = [...t].sort((e, t) => e.start - t.start), r = "", i = 0;
	for (let t of n) t.start < i || (r += e.slice(i, t.start) + t.text, i = t.end);
	return r + e.slice(i);
}
function Xe(e) {
	return `"${e}"`;
}
function V(e, t, n = 0) {
	if (t.size === 0) return e;
	if (n > 64) throw E("theme.css", "font-family fallback nesting exceeds 64 levels.");
	let { body: r, important: i } = z(e), a = [];
	for (let e of R(r)) {
		let i = r.slice(e.start, e.end), o = L(i);
		if (o) {
			let n = t.get(o.key);
			n && a.push({
				start: e.start + o.start,
				end: e.start + o.end,
				text: Xe(n)
			});
			continue;
		}
		let s = I(i);
		if (s.length !== 0 && (s.length !== 1 || s[0].type !== "ident" || !Ee.has(s[0].name) && !T.has(s[0].name))) {
			if (s.length === 1 && s[0].type === "function" && s[0].name === "var") {
				let r = s[0], i = r.text.indexOf("("), o = r.text.slice(i + 1, -1), c = R(o), l = I(o.slice(0, c[0].end));
				if (!r.text.endsWith(")") || l.length !== 1 || l[0].type !== "ident" || !l[0].text.startsWith("--")) throw E("theme.css", "font-family var() must start with a custom property name.");
				if (c.length > 1) {
					let s = c[0].end + 1, l = o.slice(s);
					a.push({
						start: e.start + r.start + i + 1 + s,
						end: e.start + r.end - 1,
						text: V(l, t, n + 1)
					});
				}
			} else throw E("theme.css", "unsupported font-family syntax; use literal families or var() with a family-list fallback.");
		}
	}
	return B(r, a) + i;
}
function Ze(e) {
	let t = I(e);
	if (t.length === 0 || t.length === 1 && t[0].type === "ident" && (De.has(t[0].name) || T.has(t[0].name))) return null;
	let n = -1;
	for (let e = 0; e < t.length; e += 1) {
		let r = t[e];
		if (r.type === "dimension" && !/(?:deg|grad|rad|turn)$/i.test(r.text) || r.type === "percentage" || r.type === "ident" && Oe.has(r.name) || r.type === "number" && Number(r.text) === 0) {
			n = e;
			break;
		}
		if (r.type === "function") {
			let i = t[e + 1];
			if ([
				"calc",
				"min",
				"max",
				"clamp"
			].includes(r.name) || r.name === "var" && i?.type === "delimiter" && i.text === "/") {
				n = e;
				break;
			}
		}
	}
	if (n < 0) return null;
	let r = n + 1, i = t[r];
	return i?.type === "delimiter" && i.text === "/" && (r += 2), r >= t.length ? null : t[r].start;
}
function Qe(e, t) {
	if (t.size === 0) return e;
	let { body: n, important: r } = z(e), i = Ze(n);
	if (i === null) {
		let t = I(n);
		if (t.length === 1 && t[0].type === "ident" && (De.has(t[0].name) || T.has(t[0].name)) || t.length === 1 && t[0].type === "function" && t[0].name === "var" && R(t[0].text.slice(t[0].text.indexOf("(") + 1, -1)).length === 1) return e;
		throw E("theme.css", "unsupported font shorthand; use an explicit font size (including calc/min/max/clamp) and a family list.");
	}
	let a = V(n.slice(i), t);
	return n.slice(0, i) + a + r;
}
function H(e, t = !1, n = 0) {
	if (n > 64) throw E("theme.css", "nested font declarations exceed 64 levels.");
	let r = [], i = (i) => {
		let a = P(e, i + 1);
		if (t) for (let t of H(e.slice(i + 1, a), !0, n + 1)) r.push({
			name: t.name,
			valueStart: i + 1 + t.valueStart,
			valueEnd: i + 1 + t.valueEnd
		});
		return Math.min(a + 1, e.length);
	}, a = 0;
	for (; a < e.length && (a = N(e, a), !(a >= e.length));) {
		if (e[a] === ";" || e[a] === "}") {
			a += 1;
			continue;
		}
		if (e[a] === "{") {
			a = i(a);
			continue;
		}
		let t = a, n = a;
		for (; n < e.length;) {
			let t = e[n];
			if (t === "\"" || t === "'") n = j(e, n);
			else if (t === "/" && e[n + 1] === "*") n = N(e, n);
			else if (t === "(" || t === "[") n = M(e, n, t, t === "(" ? ")" : "]");
			else {
				if (t === ":" || t === ";" || t === "{" || t === "}") break;
				n += 1;
			}
		}
		if (n >= e.length) break;
		if (e[n] !== ":") {
			a = e[n] === "{" ? i(n) : n + 1;
			continue;
		}
		let o = I(e.slice(t, n)), s = o.length === 1 && o[0].type === "ident" ? o[0] : void 0, c = s?.text ?? "", l = c.startsWith("--") ? c : c.toLowerCase(), u = n + 1, d = u;
		for (; d < e.length;) {
			let t = e[d];
			if (t === "\"" || t === "'") d = j(e, d);
			else if (t === "/" && e[d + 1] === "*") d = N(e, d);
			else if (t === "(" || t === "[") d = M(e, d, t, t === "(" ? ")" : "]");
			else if (t === "{" && c.startsWith("--")) d = P(e, d + 1) + 1;
			else {
				if (t === ";" || t === "{" || t === "}") break;
				d += 1;
			}
		}
		e[d] === "{" ? a = i(d) : (s && r.push({
			name: l,
			valueStart: u,
			valueEnd: d
		}), a = d, e[d] === ";" && (a += 1));
	}
	return r;
}
function $e(e, t) {
	if (t.size === 0) return e;
	let n = [];
	for (let r of H(e, !0)) {
		let i = r.name === "font-family" || r.name === "--font-sans" || r.name === "--font-mono";
		if (!i && r.name !== "font") continue;
		let a = e.slice(r.valueStart, r.valueEnd), o = i ? V(a, t) : Qe(a, t);
		o !== a && n.push({
			start: r.valueStart,
			end: r.valueEnd,
			text: o
		});
	}
	return B(e, n);
}
function et(e, t, n) {
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (/\s/.test(i) || i === ";" || i === "}") {
			r += 1;
			continue;
		}
		if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
			continue;
		}
		if (i === "{") {
			r = P(e, r + 1) + 1;
			continue;
		}
		let a = r, o = r;
		for (; o < e.length;) {
			let t = e[o];
			if (t === "\"" || t === "'") o = j(e, o);
			else if (t === "/" && e[o + 1] === "*") {
				let t = e.indexOf("*/", o + 2);
				o = t < 0 ? e.length : t + 2;
			} else if (t === "(" || t === "[") o = M(e, o, t, t === "(" ? ")" : "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				o += 1;
			}
		}
		if (o >= e.length) break;
		if (e[o] !== "{") {
			r = o + 1;
			continue;
		}
		let s = P(e, o + 1), c = e.slice(a, o).trim();
		if (c.startsWith("@")) {
			let r = (/^@([A-Za-z-]+)/.exec(c)?.[1] ?? "").toLowerCase();
			r === "font-face" ? n(e.slice(o + 1, s), t) : we.has(r) && et(e.slice(o + 1, s), t, n);
		}
		r = Math.min(s + 1, e.length);
	}
}
function tt(e, t) {
	let n = H(e).filter((e) => e.name === "font-family");
	if (n.length === 0) throw E(t, "@font-face must declare a font-family descriptor.");
	if (n.length > 1) throw E(t, "@font-face may declare font-family only once.");
	let { body: r, important: i } = z(e.slice(n[0].valueStart, n[0].valueEnd));
	if (i !== "") throw E(t, "@font-face descriptors must not use !important.");
	if (R(r).length !== 1) throw E(t, "@font-face font-family must be a single family name, not a list.");
	let a = L(r);
	if (!a) throw E(t, "@font-face font-family must be one quoted or unquoted family name; generic families, keywords, var() and other functions are not allowed.");
	if (He(Ge(a.key)?.original ?? a.key).length > Te) throw E(t, `@font-face font-family must not exceed ${Te} UTF-8 bytes.`);
	return a.key;
}
function nt(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i of e) et(i.css, n, (e, n) => {
		let i = tt(e, n), a = Ge(i), o = a ? a.original : i, s = We(t, o), c = r.get(i);
		if (c !== void 0 && c !== s) throw E(n, `@font-face family "${i}" maps to more than one name.`);
		r.set(i, s), r.set(o, s);
	});
	return r;
}
function rt(e, t, n) {
	let r = H(e).filter((e) => e.name === "font-family");
	if (r.length !== 1) throw E(n, "@font-face must declare exactly one font-family descriptor.");
	let i = r[0], { body: a } = z(e.slice(i.valueStart, i.valueEnd));
	if (R(a).length !== 1) throw E(n, "@font-face font-family must be a single family name, not a list.");
	let o = L(a);
	if (!o) throw E(n, "@font-face has an unsupported font-family descriptor.");
	let s = t.get(o.key);
	if (s === void 0) throw E(n, `@font-face family "${o.key}" was not registered.`);
	return B(e, [{
		start: i.valueStart + o.start,
		end: i.valueStart + o.end,
		text: Xe(s)
	}]);
}
var it = /* @__PURE__ */ new Map();
function at(e) {
	return e.replace(/\/\*[\s\S]*?\*\//g, " ").trim().replace(/^@layer\b/i, "@layer").replace(/\s+/g, " ").replace(/\s*,\s*/g, ", ");
}
function U(e, t, n = it, r = !1) {
	let i = "", a = 0;
	for (; a < e.length;) {
		let o = e[a];
		if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2), n = t < 0 ? e.length : t + 2;
			i += e.slice(a, n), a = n;
			continue;
		}
		if (/\s/.test(o) || o === ";" || o === "}") {
			i += o, a += 1;
			continue;
		}
		let s = a, c = a;
		for (; c < e.length;) {
			let t = e[c];
			if (t === "\"" || t === "'") c = j(e, c);
			else if (t === "/" && e[c + 1] === "*") {
				let t = e.indexOf("*/", c + 2);
				c = t < 0 ? e.length : t + 2;
			} else if (t === "(") c = M(e, c, "(", ")");
			else if (t === "[") c = M(e, c, "[", "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				c += 1;
			}
		}
		if (c >= e.length) {
			i += e.slice(s);
			break;
		}
		let l = e.slice(s, c), u = e[c];
		if (u === ";" || u === "}") {
			let e = at(l);
			if (!r && (e === "@layer rmd.themes" || `${e};` === S)) {
				a = c + 1;
				continue;
			}
			i += l + u, a = c + 1;
			continue;
		}
		let d = P(e, c + 1), f = e.slice(c + 1, d), p = l.trim();
		if (p.startsWith("@")) {
			let e = (/^@([A-Za-z-]+)/.exec(p)?.[1] ?? "").toLowerCase();
			if (e === "import") throw E("theme.css", "must not use @import.");
			if (e === "keyframes" || e.endsWith("-keyframes")) throw E("theme.css", `@${e} declares a global name; phase one only supports document-scoped CSS.`);
			if (e === "font-face") i += `${p} {${rt(f, n, "theme.css")}}`;
			else if (e === "layer" && !r && at(p) === "@layer rmd.themes") i += U(f, t, n, !0).trim();
			else {
				let a = we.has(e) ? U(f, t, n, r || e === "layer") : f;
				i += `${p} {${a}}`;
			}
		} else i += `${Ve(p, t)} {${$e(f, n)}}`;
		a = Math.min(d + 1, e.length);
	}
	return i;
}
function W(e, t, n = it) {
	return `${S}\n@layer ${he} {\n${U(e, t, n).trim()}\n}`;
}
function G(e, t) {
	if (!Array.isArray(e)) throw E(t, "must be an array of { id, css } resources.");
	if (e.length > _e) throw E(t, `may contain at most ${_e} resources.`);
	let n = /* @__PURE__ */ new Set(), r = [], i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a], s = `${t}[${a}]`;
		if (!Ae(o)) throw E(s, "must be an object.");
		let c = o.id;
		if (typeof c != "string" || c.length === 0) throw E(`${s}.id`, "must be a non-empty string.");
		if (c.length > ve) throw E(`${s}.id`, `must not exceed ${ve} characters.`);
		if (!be.test(c)) throw E(`${s}.id`, `"${c}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (n.has(c)) throw E(`${s}.id`, `"${c}" is declared more than once.`);
		n.add(c);
		let l = o.css;
		if (typeof l != "string") throw E(`${s}.css`, "must be a string.");
		if (l.length > C) throw E(`${s}.css`, `must not exceed ${C} characters.`);
		if (i += l.length, i > w) throw E(t, `must not exceed ${w} characters in total.`);
		Fe(l, `${s}.css`), r.push(Object.freeze({
			id: c,
			css: l
		}));
	}
	return {
		resources: Object.freeze(r),
		totalLength: i
	};
}
function ot(e) {
	let t = 0;
	for (let [n, r] of e.entries()) {
		if (r.css.length > C) throw E(`theme.css[${n}].css`, `scoped CSS must not exceed ${C} characters.`);
		t += r.css.length;
	}
	if (t > w) throw E("theme.css", `scoped CSS must not exceed ${w} characters in total.`);
}
function K(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		protocol: e.protocol,
		colorSchemes: Object.freeze([...e.colorSchemes]),
		css: Object.freeze(e.css.map((e) => Object.freeze({
			id: e.id,
			css: e.css
		})))
	});
}
function st(e, t) {
	let n = D(e, t), r = O(n.id, `${t}.id`), i = k(n.name, `${t}.name`), a = A(n.version, `${t}.version`);
	if (n.protocol !== "reactive-md-theme-1") throw E(`${t}.protocol`, `must be "${b}".`);
	let o = je(n.colorSchemes, `${t}.colorSchemes`), { resources: s } = G(n.css, `${t}.css`);
	return K({
		id: r,
		name: i,
		version: a,
		protocol: b,
		colorSchemes: o,
		css: s
	});
}
function q(e) {
	let t = D(e, "input"), n = O(t.id, "theme.id"), r = k(t.name, "theme.name"), i = A(t.version, "theme.version");
	if ((t.protocol === void 0 ? "reactive-md-theme-1" : t.protocol) !== "reactive-md-theme-1") throw E("theme.protocol", `must be "${b}".`);
	let a = je(t.colorSchemes, "theme.colorSchemes"), { resources: o } = G(t.css, "theme.css"), s = nt(o, r, "theme.css"), c = o.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, r, s)
	}));
	return ot(c), K({
		id: n,
		name: r,
		version: i,
		protocol: b,
		colorSchemes: a,
		css: c
	});
}
function ct(e) {
	let t = D(e, "input"), n = O(t.id, "theme.id"), r = k(t.name, "theme.name"), i = A(t.version, "theme.version"), a = st(t.base, "theme.base"), o = G(t.overrides, "theme.overrides"), s = nt([...a.css, ...o.resources], r, "theme.css"), c = new Set(a.css.map((e) => e.id));
	for (let e of o.resources) {
		if (c.has(e.id)) throw E("theme.overrides", `resource "${e.id}" is already declared by the base theme.`);
		c.add(e.id);
	}
	let l = [...a.css.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, r, s)
	})), ...o.resources.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, r, s)
	}))];
	return ot(l), K({
		id: n,
		name: r,
		version: i,
		protocol: a.protocol,
		colorSchemes: a.colorSchemes,
		css: l
	});
}
function lt(e) {
	return q(e).css.map((e) => e.css).join("\n");
}
// src/sdk/preset.ts
var J = /* @__PURE__ */ new WeakSet();
function ut(e, t) {
	let n = t instanceof Error ? t.message : String(t);
	throw Error(`Invalid local preset (themes[${e}]): ${n}`);
}
function Y(e) {
	if (typeof e == "object" && e && J.has(e)) return e;
	let t = r(e);
	if (t.themes === void 0) return J.add(t), t;
	let n = t.themes.map((e, t) => {
		try {
			return q(e);
		} catch (e) {
			ut(t, e);
		}
	}), i = Object.freeze({
		...t,
		themes: Object.freeze(n)
	});
	return J.add(i), i;
}
function dt(e) {
	return Y(e);
}
function ft(e) {
	return i(e);
}
// src/sdk/config.ts
var pt = y.id, mt = y.version, ht = Object.freeze({
	id: pt,
	version: mt
}), gt = 16, _t = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"replacements",
	"themes"
]), X = /* @__PURE__ */ new WeakSet();
function vt(e) {
	d(e) || h("themes", "each theme must be an object."), v(e, /* @__PURE__ */ new Set([
		"id",
		"name",
		"version",
		"protocol",
		"colorSchemes",
		"css"
	]), "theme");
	try {
		return q(e);
	} catch (e) {
		h("theme", e instanceof Error ? e.message : String(e));
	}
}
function Z(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || h("themes", "must be an array."), e.length > 16 && h("themes", "accepts at most 16 themes.");
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = vt(i);
		t.has(e.id) && h("themes", `theme id "${e.id}" is declared more than once.`), n.has(e.name) && h("themes", `theme name "${e.name}" is declared more than once.`), t.add(e.id), n.add(e.name), r.push(e);
	}
	return Object.freeze(r.sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function yt(e, t) {
	if (typeof e == "string") return e !== "default" && e !== y.id && h(`presets[${t}]`, `unsupported preset "${e}"; phase one accepts only the built-in default package.`), y;
	if (d(e) || h(`presets[${t}]`, "must be a preset package, \"default\" or a preset reference."), e.protocol !== void 0 || e.components !== void 0) try {
		return Y(e);
	} catch (e) {
		h(`presets[${t}]`, e instanceof Error ? e.message : String(e));
	}
	let n = e.id, r = e.version;
	return typeof n != "string" && h(`presets[${t}].id`, "must be a string."), typeof r != "string" && h(`presets[${t}].version`, "must be a string."), (n === "default" ? y.id : n) !== y.id && h(`presets[${t}]`, `unsupported preset "${n}"; phase one accepts only "${y.id}".`), r !== y.version && h(`presets[${t}].version`, `must be "${y.version}".`), y;
}
function bt(e) {
	if (e === void 0) return Object.freeze([y]);
	Array.isArray(e) || h("presets", "must be an array.");
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r = 0; r < e.length; r += 1) {
		let i = yt(e[r], r);
		n.has(i.id) && h("presets", `preset "${i.id}" is selected more than once.`), n.add(i.id), t.push(i);
	}
	return Object.freeze([...t].sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function xt(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || h("components", "must be an array.");
	let t = e.map((e, t) => {
		try {
			return a(e);
		} catch (e) {
			h(`components[${t}]`, e instanceof Error ? e.message : String(e));
		}
	});
	return Object.freeze(t.sort((e, t) => {
		if (e.id !== t.id) return e.id < t.id ? -1 : 1;
		let n = e.replaces === void 0 ? 0 : 1, r = t.replaces === void 0 ? 0 : 1;
		return n === r ? e.version === t.version ? e.name < t.name ? -1 : +(e.name > t.name) : e.version < t.version ? -1 : 1 : n - r;
	}));
}
function St(e) {
	return e === void 0 ? "allow" : (e !== "allow" && e !== "forbid" && h("replacements", "must be \"allow\" or \"forbid\"."), e);
}
function Ct(e, n) {
	d(e) || h(n, "must be an object."), v(e, _t, n);
	let r = Object.freeze({
		protocol: t,
		presets: bt(e.presets),
		components: xt(e.components),
		replacementPolicy: St(e.replacements),
		themes: Z(e.themes)
	});
	return o(r) > 16777216 && h(n, `serialized size exceeds the ${g}-byte budget.`), r;
}
function wt(e) {
	return Object.freeze({
		...e,
		presets: Object.freeze(e.presets.map((e) => Y(e))),
		themes: Z(e.themes)
	});
}
function Tt(e) {
	let t = wt(e), n = ee(t, { legacyProfiles: m }), r = p(t, n);
	return X.add(r), r;
}
function Q(e = {}) {
	return Tt(Ct(e, "config"));
}
var Et;
function Dt(e) {
	return e === void 0 ? Et ??= Q().key : $(e).key;
}
function Ot(e) {
	return new Set(e.legacyKeys.map((e) => e.key));
}
function kt(e, t) {
	let n = $(t ?? Q()), r = e.componentConfigKey;
	return r === void 0 || r === n.key || Ot(n).has(r) ? [] : [{
		code: "local.extension.config-mismatch",
		severity: "error",
		message: "The document compiler configuration differs from the installed renderer. Recompile with the same host.config used by host.reactConfig (including Worker requests).",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}];
}
function At(e) {
	return e.preset.id === y.id && e.preset.version === y.version ? y : Y({
		...y,
		id: e.preset.id,
		version: e.preset.version
	});
}
function jt(e, n) {
	let r = ie(e.presets, ht, n)[0] ?? ht, i = u(r, n);
	i === void 0 && h("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${r.id}" ${r.version}.`);
	let a = i.legacyKeys[0];
	a === void 0 && h("presets", `local.config.migration-unsupported: profile "${i.name}" has no legacy key mapping.`), f(i, y.components);
	let o = At(i), s = ne(e.components, y.components);
	s.some((e) => e.replaces !== void 0) && h("config", "replaces is not supported by reactive-md-config/v1.");
	let c = Z(e.themes), l = Object.freeze({
		protocol: t,
		presets: Object.freeze([o]),
		components: s,
		replacementPolicy: "forbid",
		themes: c
	}), d = ee(l, { legacyProfiles: n }), m = re(i.preset, d.components), te = [...d.legacyKeys, ...d.legacyKeys.some((e) => e.key === m) ? [] : [Object.freeze({
		profile: a.profile,
		key: m
	})]], g = p(l, d, te);
	return X.add(g), g;
}
function $(t, r = []) {
	return typeof t == "object" && t && X.has(t) ? t : (d(t) || h("config", "must be an object."), v(t, ae, "config"), t.protocol === "reactive-md-config/v1" ? jt(t, oe(r)) : (t.protocol !== "reactive-md-config/v2" && h("config.protocol", `must be "${e}" (or legacy "${n}").`), Tt(te(t.assembly))));
}
function Mt(e) {
	if (typeof e == "object" && e && X.has(e)) return e.key;
	try {
		return $(e).key;
	} catch {
		try {
			return `invalid:${s(JSON.stringify(e))}`;
		} catch {
			return "invalid";
		}
	}
}
function Nt(e) {
	try {
		return $(e);
	} catch {
		return e;
	}
}
// src/sdk/registry.ts
function Pt() {
	return ce;
}
function Ft(e) {
	return e ? $(e).registry : Pt();
}
function It(e, t) {
	let n = Ft(t);
	for (let t of n) if (t.name === e) return t;
}
function Lt(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of Ft(e)) t.set(n.name, se(n));
	return t;
}
export { he as C, fe as E, S, b as T, ct as _, mt as a, pe as b, Dt as c, Nt as d, kt as f, lt as g, Y as h, pt as i, Mt as l, ft as m, Ft as n, gt as o, dt as p, Lt as r, Q as s, It as t, $ as u, q as v, x as w, me as x, Ie as y };
