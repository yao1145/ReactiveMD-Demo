import { ut as e } from "./identity-D1cB_NI3.js";
import { $ as t, F as n, X as r, j as i, nt as a, ot as o } from "./config-validation-Dcg9tIe2.js";
import { J as s, Q as c, Y as l, Z as u, a as d, at as f, c as p, et as m, i as h, n as g, nt as _, o as v, r as ee, rt as y, t as b, tt as x, w as S } from "./validation-1iORHbyb.js";
import { t as C } from "./registry-3uiciQZC.js";
import { C as w, b as T } from "./component-state-Cq2K5gkS.js";
import { n as E } from "./runtime-Dkq7ldyg.js";
// src/local/runtime/retention.ts
function D(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of u(e.nodes)) t.set(n.id, n);
	return t;
}
function O(e, t, n) {
	let r = e.bindingSlots?.[t.id];
	return r !== void 0 && Object.values(r).includes(n);
}
function k(e, t, n) {
	let r = t.name ? C(t.name) : void 0;
	if (r?.bindings) {
		let i = e.bindingSlots?.[t.id];
		for (let [e, a] of Object.entries(r.bindings)) if (t.attrs?.[a.bind] === n || e !== "value" && i?.[e] === n) return a.retain === !1 ? void 0 : a.initial;
	} else if (t.attrs?.bind === n || O(e, t, n)) return "initial";
}
function A(e) {
	let t = D(e), r = n(e), i = new Set(r?.retentionExclusions ?? []), a = /* @__PURE__ */ new Map();
	for (let [n, o] of Object.entries(e.bindings)) {
		let s = o.nodeIds.flatMap((e) => {
			let n = t.get(e);
			return n ? [n] : [];
		});
		if (!s.length || n.startsWith("@") || i.has(n)) continue;
		let c;
		if (r === void 0) {
			let t = s.map((t) => k(e, t, n));
			if (t.some((e) => e === void 0)) continue;
			c = t;
		} else {
			let e = r.bindingAttributes?.[n]?.initial ?? "initial";
			c = s.map(() => e);
		}
		let l = s.flatMap((e, t) => Object.hasOwn(e.attrs ?? {}, c[t]) ? [e.attrs[c[t]]] : []).sort();
		a.set(n, {
			type: o.type,
			initialDefinition: JSON.stringify([o.initial, l])
		});
	}
	return a;
}
function j(e, t) {
	return Object.freeze({
		name: e,
		reason: t
	});
}
function te(e) {
	let t = A(e.previous), n = A(e.next), r = {}, i = [], a = [];
	for (let o of Object.keys(e.state).sort()) {
		if (o.startsWith("@")) {
			a.push(j(o, "internal"));
			continue;
		}
		if (!Object.hasOwn(e.previous.bindings, o) || !Object.hasOwn(e.next.bindings, o)) {
			a.push(j(o, "unknown"));
			continue;
		}
		let s = t.get(o), c = n.get(o);
		if (!s || !c) {
			a.push(j(o, "unretainable"));
			continue;
		}
		if (s.type !== c.type) {
			a.push(j(o, "type"));
			continue;
		}
		if (s.initialDefinition !== c.initialDefinition) {
			a.push(j(o, "initial"));
			continue;
		}
		let l = e.state[o];
		r[o] = Array.isArray(l) ? Object.freeze([...l]) : l, i.push(o);
	}
	return Object.freeze({
		values: Object.freeze(r),
		retained: Object.freeze(i),
		dropped: Object.freeze(a)
	});
}
function M(e, t, n) {
	return Object.freeze({
		retained: Object.freeze([...e]),
		dropped: Object.freeze(t.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...n])
	});
}
function N(e, t) {
	let n = Object.keys(t.values).sort();
	if (!e.setParameters(t.values).length) return M(n, t.dropped, []);
	let r = [], i = n, a = [];
	for (; i.length;) {
		let n = [];
		a = [];
		for (let o of i) {
			let i = e.setParameter(o, t.values[o]);
			i.length ? (n.push(o), a.push(...i)) : r.push(o);
		}
		if (n.length === i.length) break;
		i = n;
	}
	r.sort();
	let o = [...t.dropped, ...i.map((e) => j(e, "invalid"))];
	return o.sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name)), M(r, o, a);
}
// src/local/runtime/runtime.ts
var ne = 1e-9, re = 200;
function P(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function ie(e) {
	return {
		...e,
		range: { ...e.range }
	};
}
function F(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => e === t[n]) : e === t;
}
function I(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= ne * Math.max(1, Math.abs(r));
}
function ae(e) {
	for (let [t, n] of Object.entries(e)) Array.isArray(n) && !Object.isFrozen(n) && (e[t] = Object.freeze([...n]));
	return Object.freeze(e);
}
function L(e, n, r, i) {
	let a = Math.max(0, Math.min(e.source.length, n.range.start)), o = e.source.slice(0, a).split("\n");
	return {
		code: r,
		message: t(i),
		severity: "error",
		range: {
			start: a,
			end: Math.max(a + 1, Math.min(e.source.length, n.range.end))
		},
		line: o.length,
		column: (o.at(-1) ?? "").length + 1,
		messageKey: i.key,
		...i.params ? { params: i.params } : {}
	};
}
function R(e, t, n) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1,
		...n ? {
			messageKey: n.key,
			...n.params ? { params: n.params } : {}
		} : {}
	};
}
function z(e, t) {
	return e.attrs?.[t];
}
function B(e, t) {
	let n = z(e, t);
	if (n === "true") return !0;
	if (n === "false") return !1;
}
function V(e, t) {
	let n = z(e, t);
	if (n === void 0) return;
	let r = Number(n);
	return Number.isFinite(r) ? r : void 0;
}
function H(e) {
	return o(e);
}
function U(e, t) {
	return {
		ok: !1,
		detail: a(e, t)
	};
}
function W(e, t) {
	if (t !== void 0) return z(e, t);
}
function G(e, t) {
	if (t !== void 0) return V(e, t);
}
function K(t, n, r, a = {}) {
	for (let o of r) if (o.kind === "date") {
		if (!i(n)) return U("local.runtime.value.date-invalid");
		let e = a.required ?? (o.required !== void 0 && B(t, o.required) === !0);
		if (n === "" && e) return U("local.runtime.value.date-required");
		let r = a.min ?? W(t, o.min), s = a.max ?? W(t, o.max);
		if (n !== "" && r && n < r) return U("local.runtime.value.date-earlier", { min: r });
		if (n !== "" && s && n > s) return U("local.runtime.value.date-later", { max: s });
	} else if (o.kind === "required") {
		let e = a.required ?? B(t, o.required) === !0;
		if (n === "" && e) return U("local.runtime.value.field-required");
	} else if (o.kind === "length") {
		let e = H(n), r = G(t, o.min), i = G(t, o.max);
		if (r !== void 0 && r > 0 && n !== "" && e < r) return U("local.runtime.value.min-length", { min: r });
		if (i !== void 0 && e > i) return U("local.runtime.value.max-length", { max: i });
	} else if (o.kind === "email" && (W(t, o.type) ?? "text") === o.value && n !== "") {
		if (n.length > 254) return U("local.runtime.value.email-length", { limit: 254 });
		if (!e(n)) return U("local.runtime.value.email-invalid");
	}
	return {
		ok: !0,
		value: n
	};
}
var q = /* @__PURE__ */ new Map();
function J(e) {
	if (!e.name) return Y;
	let t = q.get(e.name);
	if (t !== void 0) return t ?? Y;
	let n = C(e.name), i = n ? r(n) : Y;
	return q.set(e.name, n ? i : null), i;
}
var Y = Object.freeze([]);
function X(e, n, r, a, o, s = !1) {
	switch (e.type) {
		case "number": {
			if (typeof r != "number" || !Number.isFinite(r)) return U("local.runtime.value.finite-number", { name: e.name });
			let t = e.step ?? 1, i = e.min ?? 0;
			for (let t of n) {
				let n = a(t, "min");
				if (n.present && !n.ok) return U("local.runtime.value.constraint", {
					name: e.name,
					attribute: "min"
				});
				if (n.present && n.ok) {
					if (typeof n.value != "number" || !Number.isFinite(n.value)) return U("local.runtime.value.constraint", {
						name: e.name,
						attribute: "min"
					});
					if (i = n.value, r < n.value) return U("local.runtime.value.min", {
						name: e.name,
						min: n.value
					});
				}
				let o = a(t, "max");
				if (o.present && !o.ok) return U("local.runtime.value.constraint", {
					name: e.name,
					attribute: "max"
				});
				if (o.present && o.ok) {
					if (typeof o.value != "number" || !Number.isFinite(o.value)) return U("local.runtime.value.constraint", {
						name: e.name,
						attribute: "max"
					});
					if (r > o.value) return U("local.runtime.value.max", {
						name: e.name,
						max: o.value
					});
				}
				if (n.present && n.ok && o.present && o.ok && typeof n.value == "number" && typeof o.value == "number" && n.value > o.value) return U("local.runtime.value.constraint-range", { name: e.name });
			}
			return e.min !== void 0 && r < e.min ? U("local.runtime.value.min", {
				name: e.name,
				min: e.min
			}) : e.max !== void 0 && r > e.max ? U("local.runtime.value.max", {
				name: e.name,
				max: e.max
			}) : t > 0 && !I(r, i, t) ? U("local.runtime.value.step", {
				name: e.name,
				step: t,
				base: i
			}) : {
				ok: !0,
				value: r
			};
		}
		case "boolean": return typeof r == "boolean" ? {
			ok: !0,
			value: r
		} : U("local.runtime.value.boolean", { name: e.name });
		case "string": {
			if (typeof r != "string") return U("local.runtime.value.string", { name: e.name });
			let c = y(r);
			if (c) return U("local.runtime.value.budget", {
				name: e.name,
				detail: t(c),
				detailKey: c.key,
				...c.params
			});
			for (let t of n) {
				let n = o?.get(t.id) ?? (s ? J(t) : Y);
				if (!n.length) continue;
				let c = {};
				for (let r of n) {
					if (r.kind === "date") {
						for (let n of ["min", "max"]) {
							if (r[n] === void 0) continue;
							let o = a(t, n);
							if (o.present) {
								if (!o.ok || typeof o.value != "string" || !i(o.value)) return U("local.runtime.value.constraint-date", {
									name: e.name,
									attribute: n
								});
								c[n] = o.value;
							}
						}
						let n = c.min ?? W(t, r.min), o = c.max ?? W(t, r.max);
						if (n && o && i(n) && i(o) && n > o) return U("local.runtime.value.constraint-range", { name: e.name });
					}
					if ((r.kind === "date" || r.kind === "required" ? r.required : void 0) !== void 0) {
						let n = a(t, "required");
						if (n.present) {
							if (!n.ok || typeof n.value != "boolean") return U("local.runtime.value.constraint", {
								name: e.name,
								attribute: "required"
							});
							c.required = n.value;
						}
					}
				}
				let l = K(t, r, n, c);
				if (!l.ok) return l;
			}
			return e.options?.length && !e.options.includes(r) ? U("local.runtime.value.option", {
				value: r,
				options: e.options.join(", ")
			}) : {
				ok: !0,
				value: r
			};
		}
		case "array": {
			if (!Array.isArray(r)) return U("local.runtime.value.array", { name: e.name });
			let n = y(r);
			if (n) return U("local.runtime.value.budget", {
				name: e.name,
				detail: t(n),
				detailKey: n.key,
				...n.params
			});
			for (let t of r) if (typeof t != "string") return U("local.runtime.value.array-members", { name: e.name });
			if (e.family === "collection") return e.maxItems !== void 0 && r.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: r.slice()
			};
			let i = /* @__PURE__ */ new Set();
			for (let t of r) {
				if (e.options && !e.options.includes(t)) return U("local.runtime.value.checklist-option", { value: t });
				i.add(t);
			}
			let a = e.options ? e.options.filter((e) => i.has(e)) : [...i];
			return e.maxItems !== void 0 && a.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: a
			};
		}
		case "number-array": {
			if (!Array.isArray(r)) return U("local.runtime.value.number-array", { name: e.name });
			let n = y(r);
			if (n) return U("local.runtime.value.budget", {
				name: e.name,
				detail: t(n),
				detailKey: n.key,
				...n.params
			});
			for (let t of r) if (typeof t != "number" || !Number.isFinite(t)) return U("local.runtime.value.number-array-members", { name: e.name });
			return e.maxItems !== void 0 && r.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: r.slice()
			};
		}
		case "null": return r === null ? {
			ok: !0,
			value: r
		} : U("local.runtime.value.null", { name: e.name });
	}
	return U("local.runtime.value.unsupported-type", { name: e.name });
}
function Z(e) {
	return e instanceof c ? e : new c("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function oe(e, t) {
	switch (e) {
		case "string": {
			if (typeof t != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string" }
			};
			let e = y(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t
			};
		}
		case "number": return typeof t == "number" && Number.isFinite(t) ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "number" }
		};
		case "boolean": return typeof t == "boolean" ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "boolean" }
		};
		case "array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			for (let e of t) if (typeof e != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			let e = y(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		case "number-array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			for (let e of t) if (typeof e != "number" || !Number.isFinite(e)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			let e = y(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		default: return {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: String(e) }
		};
	}
}
function se(e, t) {
	let n = e.document.bindings[t];
	if (!n) return;
	let { nodeIds: r, owner: i, ...a } = n, o = (e.controls.get(t) ?? []).map((t) => {
		let n = e.document.dynamicConstraints?.[t.id] ?? {};
		return {
			name: t.name ?? null,
			attrs: t.attrs ?? {},
			dynamic: Object.fromEntries(Object.entries(n).map(([e, t]) => [e, t ? {
				source: t.source,
				numeric: t.numeric ?? null
			} : null])),
			rules: e.valueRules.get(t.id) ?? null
		};
	});
	return JSON.stringify({
		facts: a,
		legacy: e.legacyValueRules,
		controls: o
	});
}
function ce(e, t) {
	let n = t.get(e);
	if (n) return {
		expression: n,
		error: null
	};
	try {
		let n = m(e);
		if (t.size >= re) {
			let e = t.keys().next().value;
			e !== void 0 && t.delete(e);
		}
		return t.set(e, n), {
			expression: n,
			error: null
		};
	} catch (e) {
		return {
			expression: null,
			error: Z(e)
		};
	}
}
function le(e, r) {
	let i = /* @__PURE__ */ new Map();
	for (let t of u(e.nodes)) i.set(t.id, t);
	let a = {}, o = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e.bindings)) {
		let e = y(r.initial);
		if (e) throw new c("expression-budget", `Parameter "${n}": ${t(e)}`, 0);
		a[n] = P(r.initial);
		let s = [];
		for (let e of r.nodeIds) {
			let t = i.get(e);
			t && s.push(t);
		}
		o.set(n, s);
	}
	let s = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots ?? {})) s.set(t, { ...n });
	let f = n(e), p = new Map(Object.entries(f?.valueRules ?? {})), m = f === void 0, h = /* @__PURE__ */ new Map();
	if (f) for (let e of f.slotRelations) {
		let t = s.get(e.nodeId), n = t?.[e.lower], r = t?.[e.upper];
		if (!n || !r) continue;
		let i = h.get(e.nodeId) ?? [];
		i.push({
			lower: n,
			upper: r
		}), h.set(e.nodeId, i);
	}
	else for (let [e, t] of s) t.start && t.end && h.set(e, [{
		lower: t.start,
		upper: t.end
	}]);
	let g = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) for (let e of n.nodeIds) {
		if (s.has(e)) continue;
		let n = g.get(e);
		(n === void 0 || n.startsWith("@") && !t.startsWith("@")) && g.set(e, t);
	}
	let ee = Object.freeze(Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort()), b = /* @__PURE__ */ new Map();
	for (let [e, t] of s) for (let n of Object.values(t)) {
		if (n.startsWith("@")) continue;
		let t = b.get(n) ?? /* @__PURE__ */ new Set();
		t.add(e), b.set(n, t);
	}
	let x = e.computations ?? {}, S = Object.keys(x), C = /* @__PURE__ */ new Map();
	for (let [e, t] of Object.entries(x)) {
		let n = ce(t.source, r);
		n.expression && C.set(e, n.expression);
	}
	let { order: w, cyclic: T } = l(x), E = {}, D = /* @__PURE__ */ new Map();
	for (let e of w) {
		let t = x[e];
		if (!t || t.kind !== "const") continue;
		if (Object.hasOwn(t, "value")) {
			let n = t.value, r = _(n);
			if (r) {
				D.set(e, new c("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			E[e] = P(n);
			continue;
		}
		let n = C.get(e);
		if (!n) D.set(e, new c("expression-eval", `Constant "${e}" cannot be evaluated.`, 0));
		else try {
			let t = n.evaluate({ ...E }), r = _(t);
			if (r) {
				D.set(e, new c("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			E[e] = P(t);
		} catch (t) {
			D.set(e, Z(t));
		}
	}
	let O = /* @__PURE__ */ new Map();
	for (let e of T) O.set(e, new c("expression-cycle", `Computation "${e}" is part of a dependency cycle.`, 0));
	let k = [];
	if (Array.isArray(e.validations)) for (let t of e.validations) {
		if (!d(t)) continue;
		let e = ce(t.expression, r);
		k.push({
			rule: t,
			expression: e.expression,
			error: e.error
		});
	}
	return {
		document: e,
		nodeIndex: i,
		controls: o,
		slotKeys: s,
		publicNames: ee,
		publicSlotOwners: b,
		initial: a,
		valueRules: p,
		legacyValueRules: m,
		slotRelations: h,
		bindingByNode: g,
		computationMetadata: x,
		computationNames: S,
		computationOrder: w,
		cyclicComputations: T,
		computationExpressions: C,
		constValues: E,
		constErrors: D,
		cycleErrors: O,
		validationRules: k,
		validationLineStarts: v(typeof e.source == "string" ? e.source : "")
	};
}
function ue(e) {
	return !e || e.syntax !== "local" ? "createLocalRuntime requires a local interaction document." : e.syntaxVersion !== void 0 && e.syntaxVersion !== "local-draft-3" || e.versionDeclaration && e.versionDeclaration.version !== "local-draft-3" ? `createLocalRuntime requires ${S}; migrate the source before constructing a runtime.` : null;
}
function de(e, t) {
	return (e.controls.get(t.name) ?? [])[0] ?? (t.owner ? e.nodeIndex.get(t.owner) : void 0) ?? (t.nodeIds[0] ? e.nodeIndex.get(t.nodeIds[0]) : void 0);
}
function fe(e, n, r) {
	let i = de(e, n);
	return i ? L(e.document, i, "local.runtime.value", r) : R("local.runtime.value", t(r));
}
function Q(e, t, n) {
	let r = e.slotRelations.get(t);
	return r?.length ? r.some(({ lower: e, upper: t }) => {
		let r = n[e], i = n[t];
		return typeof r == "number" && typeof i == "number" && r > i;
	}) : !1;
}
function pe(e, n) {
	let r = e.nodeIndex.get(n);
	return r ? L(e.document, r, "local.runtime.value", a("local.runtime.value.range-order")) : R("local.runtime.value", t(a("local.runtime.value.range-order")));
}
var me = /* @__PURE__ */ new WeakMap();
function $(e) {
	return Object.freeze({
		ok: e.ok,
		changed: e.changed,
		revision: e.revision,
		retained: Object.freeze([...e.retained]),
		dropped: Object.freeze(e.dropped.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...e.diagnostics])
	});
}
function he(e, t, n) {
	let r = me.get(e);
	if (!r) throw TypeError("updateLocalRuntime requires a runtime created by createLocalRuntime.");
	return r.update(t, n?.notify !== !1);
}
function ge(e) {
	me.get(e)?.notify();
}
function _e(e, n) {
	let r = ue(e);
	if (r) throw Error(r);
	let i = n?.services === void 0, o = w(e.source), l = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map(), _ = le(e, d), v = () => _, S = () => {
		let e = /* @__PURE__ */ new Set();
		for (let t of u(_.document.nodes)) t.name !== void 0 && e.add(T({
			documentId: n?.documentId,
			sourceDigest: o,
			nodeId: t.id,
			stateKey: t.attrs?.["state-key"]
		}));
		return e;
	}, C = n?.services ?? E({
		documentId: n?.documentId,
		sourceDigest: o,
		randomSeed: n?.randomSeed,
		componentState: n?.componentState,
		...n?.componentStateStorage === void 0 ? {} : { componentStateStorage: n.componentStateStorage },
		...n?.componentStateWriteDelayMs === void 0 ? {} : { componentStateWriteDelayMs: n.componentStateWriteDelayMs },
		...n?.configKey === void 0 ? {} : { configKey: n.configKey },
		...n?.legacyConfigKeys === void 0 ? {} : { legacyConfigKeys: n.legacyConfigKeys },
		...i ? { knownStateKeys: S } : {}
	}), D = {};
	for (let [t, r] of Object.entries(e.externals ?? {})) {
		let e = n?.externalValues?.[t];
		if (e === void 0) continue;
		let i = oe(r.type, e);
		i.ok && (D[t] = i.value);
	}
	let O = (e) => {
		let t = {};
		for (let [n, r] of Object.entries(e.document.externals ?? {})) {
			if (!Object.hasOwn(D, n)) continue;
			let e = oe(r.type, D[n]);
			e.ok && (t[n] = e.value);
		}
		return t;
	}, k = (e, t, n, r = v()) => {
		let i = r.document.dynamicConstraints?.[e.id]?.[t];
		if (!i) return { present: !1 };
		let a = ce(i.source, d);
		if (!a.expression) return {
			present: !0,
			ok: !1
		};
		try {
			let e = a.expression.evaluate(n), t = i.numeric;
			return t && (typeof e != "number" || !Number.isFinite(e) || t.integer === !0 && !Number.isInteger(e) || t.min !== void 0 && e < t.min || t.max !== void 0 && e > t.max) ? {
				present: !0,
				ok: !1
			} : {
				present: !0,
				ok: !0,
				value: e
			};
		} catch {
			return {
				present: !0,
				ok: !1
			};
		}
	}, A = _.initial, j = 0, M = {}, N = {}, ne = {
		revision: 0,
		state: ae({})
	}, I = !1, z = null, B = /* @__PURE__ */ new Set(), V = /* @__PURE__ */ new Map(), H = () => {
		if (I) throw Error("The local interaction runtime has been disposed.");
	}, U = (e, t) => {
		let n = O(e), r = /* @__PURE__ */ new Map();
		for (let t of Object.keys(e.document.externals ?? {})) Object.hasOwn(n, t) || r.set(t, new c("external-missing", "External data \"" + t + "\" is not available.", 0));
		let i = {}, a = /* @__PURE__ */ new Map();
		if (e.computationNames.length > 0) {
			let o = s(e.computationMetadata, e.computationOrder, e.computationExpressions, {
				...t,
				...n
			}, e.constValues, r);
			i = o.values, a = o.errors;
			for (let [t, n] of e.constErrors) Object.hasOwn(i, t) || a.set(t, n);
			for (let [t, n] of e.cycleErrors) Object.hasOwn(i, t) || a.set(t, n);
		}
		let o = {};
		for (let [e, n] of Object.entries(t)) o[e] = n;
		for (let [e, t] of Object.entries(n)) o[e] = t;
		for (let [e, t] of Object.entries(i)) o[e] = t;
		for (let [e, t] of [...r, ...a]) Object.hasOwn(i, e) || Object.defineProperty(o, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw t;
			}
		});
		let l = {};
		for (let [e, n] of Object.entries(t)) l[e] = n;
		for (let [e, t] of Object.entries(n)) l[e] = t;
		for (let [e, t] of Object.entries(i)) l[e] = t;
		return {
			environment: o,
			snapshotState: l
		};
	}, W = () => {
		let e = U(v(), A);
		M = e.environment, N = e.snapshotState;
	}, G = (e, t = v(), n = A) => {
		let r;
		return (i, a) => t.document.dynamicConstraints?.[i.id]?.[a] ? (r ??= U(t, {
			...n,
			...e
		}).environment, k(i, a, r, t)) : { present: !1 };
	}, K = () => {
		ne = {
			revision: j,
			state: ae(N)
		};
	}, q = () => {
		for (let e of B) e();
	}, J = (e) => {
		A = e, j += 1, W(), K(), q();
	}, Y = (e) => {
		if (H(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setExternalValues requires an object of external values.");
		let n = [], r = {}, i = Object.keys(e).sort();
		for (let o of i) {
			if (o === "__proto__") {
				n.push(R("local.runtime.external", "External names cannot be \"__proto__\"."));
				continue;
			}
			let i = v().document.externals ?? {}, s = Object.hasOwn(i, o) ? i[o] : void 0;
			if (!s) {
				let e = a("local.runtime.external", { name: o });
				n.push(R("local.runtime.external", t(e), e));
				continue;
			}
			let c = oe(s.type, e[o]);
			if (c.ok) r[o] = c.value;
			else {
				let e = a(c.key, {
					name: o,
					...c.params ?? {}
				});
				n.push(R("local.runtime.external", t(e), e));
			}
		}
		if (n.length) return n;
		if (!i.some((e) => !F(D[e], r[e]))) return [];
		for (let [e, t] of Object.entries(r)) D[e] = t;
		return j += 1, W(), K(), q(), [];
	}, Z = (e) => {
		H();
		let t = v(), n = [], r = {}, i = Object.keys(e).sort(), a = G(e);
		for (let o of i) {
			if (o === "__proto__") {
				n.push(R("local.runtime.parameter", "Parameter names cannot be \"__proto__\"."));
				continue;
			}
			if (o.startsWith("@")) {
				n.push(R("local.runtime.parameter", `Internal parameter "${o}" cannot be written by name.`));
				continue;
			}
			if (!Object.hasOwn(t.document.bindings, o)) {
				n.push(R("local.runtime.parameter", `Unknown parameter "${o}".`));
				continue;
			}
			let i = t.document.bindings[o], s = X(i, t.controls.get(o) ?? [], e[o], a, t.valueRules, t.legacyValueRules);
			s.ok ? r[o] = P(s.value) : n.push(fe(t, i, s.detail));
		}
		if (n.length) return n;
		if (!i.some((e) => !F(A[e], r[e]))) return [];
		let o = {
			...A,
			...r
		}, s = /* @__PURE__ */ new Set();
		for (let e of i) for (let n of t.publicSlotOwners.get(e) ?? []) s.add(n);
		for (let e of [...s].sort()) Q(t, e, o) && n.push(pe(t, e));
		return n.length ? n : (J(o), []);
	}, de = (e) => {
		let t = l.get(e);
		if (!t) {
			if (t = m(e), l.size >= re) {
				let e = l.keys().next().value;
				e !== void 0 && l.delete(e);
			}
			l.set(e, t);
		}
		return t;
	}, he = () => {
		let e = v(), t = [], n = typeof e.document.source == "string" ? e.document.source : "";
		for (let r of e.validationRules) {
			if (r.error) {
				t.push(p(n, e.validationLineStarts, r.rule.range, b, h(`Validation expression is invalid: ${r.error.message}`)));
				continue;
			}
			if (!r.expression) continue;
			let i;
			try {
				i = r.expression.evaluate(M);
			} catch (i) {
				t.push(p(n, e.validationLineStarts, r.rule.range, b, h(`Validation expression failed: ${i instanceof Error ? i.message : String(i)}`)));
				continue;
			}
			typeof i == "boolean" ? i || t.push(p(n, e.validationLineStarts, r.rule.range, g, ge(r.rule.message))) : t.push(p(n, e.validationLineStarts, r.rule.range, b, "Validation expression must evaluate to a boolean."));
		}
		return t;
	}, ge = (e) => {
		let t;
		try {
			t = x(e, M);
		} catch {
			t = ee;
		}
		return h(t);
	}, _e = (e, t) => {
		let n = te({
			previous: _.document,
			state: A,
			next: e
		}), r = {};
		for (let [t, n] of Object.entries(e.bindings)) r[t] = P(n.initial);
		let i = /* @__PURE__ */ new Map();
		for (let e of n.dropped) i.set(e.name, Object.freeze({ ...e }));
		let a = [], o = {}, s = [], c = /* @__PURE__ */ new Set(), l, u = (e) => {
			let r = _.document.bindings[e], i = _.controls.get(e) ?? [];
			return !r || !i.some((e) => _.document.dynamicConstraints?.[e.id]) || (l ??= G({}, _, A), X(r, i, n.values[e], l, _.valueRules, _.legacyValueRules).ok) ? !1 : se(_, e) === se(t, e);
		};
		for (let l of n.retained) {
			let d = e.bindings[l];
			if (!d) continue;
			if (u(l)) {
				c.add(l), o[l] = P(n.values[l]), s.push(l);
				continue;
			}
			let f = X(d, t.controls.get(l) ?? [], n.values[l], G(n.values, t, r), t.valueRules, t.legacyValueRules);
			f.ok ? (o[l] = P(f.value), s.push(l)) : (a.push(fe(t, d, f.detail)), i.set(l, Object.freeze({
				name: l,
				reason: "invalid"
			})));
		}
		let d = {
			...r,
			...o
		}, f = /* @__PURE__ */ new Set();
		for (let e of s) for (let n of t.publicSlotOwners.get(e) ?? []) f.add(n);
		let p = !1;
		for (let e of [...f].sort()) if (Q(t, e, d)) {
			p = !0;
			break;
		}
		let m;
		if (!p) Object.assign(r, o), m = s;
		else {
			m = [];
			for (let e of s) {
				let n = r[e];
				r[e] = o[e];
				let s = !1;
				for (let n of [...t.publicSlotOwners.get(e) ?? []].sort()) Q(t, n, r) && (a.push(pe(t, n)), s = !0);
				s ? (r[e] = n, i.set(e, Object.freeze({
					name: e,
					reason: "invalid"
				}))) : m.push(e);
			}
		}
		for (let [n, o] of t.slotRelations) if (Q(t, n, r)) {
			for (let t of o) for (let n of [t.lower, t.upper]) {
				let t = e.bindings[n];
				if (!t) continue;
				r[n] = P(t.initial);
				let a = m.indexOf(n);
				a >= 0 && m.splice(a, 1), i.set(n, Object.freeze({
					name: n,
					reason: "invalid"
				}));
			}
			if (a.push(pe(t, n)), Q(t, n, r)) return {
				values: {},
				retained: [],
				dropped: [],
				diagnostics: []
			};
		}
		let h = !0;
		for (; h;) {
			let n = G({}, t, r), o = [];
			for (let i of m) {
				if (c.has(i)) continue;
				let s = e.bindings[i], l = X(s, t.controls.get(i) ?? [], r[i], n, t.valueRules, t.legacyValueRules);
				l.ok || (a.push(fe(t, s, l.detail)), o.push(i));
			}
			for (let t of o) r[t] = P(e.bindings[t].initial), m.splice(m.indexOf(t), 1), i.set(t, Object.freeze({
				name: t,
				reason: "invalid"
			}));
			h = o.length > 0;
		}
		let g = [...i.values()].sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name));
		return m.sort(), {
			values: r,
			retained: m,
			dropped: g,
			diagnostics: a
		};
	}, ve = (e, t) => {
		if (H(), e === _.document) return $({
			ok: !0,
			changed: !1,
			revision: j,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		if (ue(e)) return $({
			ok: !1,
			changed: !1,
			revision: j,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let n;
		try {
			n = le(e, d);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: j,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let r = _e(e, n);
		if (Object.keys(r.values).length === 0 && Object.keys(e.bindings).length > 0) return $({
			ok: !1,
			changed: !1,
			revision: j,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let i;
		try {
			i = U(n, r.values);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: j,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let a = O(n);
		for (let e of Object.keys(D)) delete D[e];
		if (Object.assign(D, a), _ = n, A = r.values, M = i.environment, N = i.snapshotState, z = null, j += 1, K(), t) for (let e of B) e();
		return $({
			ok: !0,
			changed: !0,
			revision: j,
			retained: r.retained,
			dropped: r.dropped,
			diagnostics: r.diagnostics
		});
	}, ye = (e) => {
		let t = /* @__PURE__ */ new Set();
		for (let n of u([e])) t.add(n.id);
		return t;
	}, be = {
		get document() {
			return _.document;
		},
		services: C,
		snapshot() {
			return H(), ne;
		},
		get(e, t) {
			H();
			let n = v(), r = n.nodeIndex.get(e.id);
			if (!r) return null;
			let i = t === void 0 ? n.slotKeys.get(r.id)?.value ?? n.bindingByNode.get(r.id) ?? f(r) : n.slotKeys.get(r.id)?.[t];
			return i && Object.hasOwn(A, i) ? P(A[i]) : null;
		},
		set(e, t, n) {
			H();
			let r = v(), i = r.nodeIndex.get(e.id);
			if (!i) return [L(r.document, e, "local.runtime.binding", a("local.runtime.binding.no-writable"))];
			let o = r.slotKeys.get(i.id), s;
			if (n === void 0) {
				if (o && !o.value) return [L(r.document, i, "local.runtime.binding", a("local.runtime.binding.needs-slot"))];
				s = o?.value ?? r.bindingByNode.get(i.id) ?? f(i);
			} else if (s = o?.[n], !s) return [L(r.document, i, "local.runtime.binding", a("local.runtime.binding.unknown-slot", { slot: n }))];
			let c = Object.hasOwn(r.document.bindings, s) ? r.document.bindings[s] : void 0;
			if (!c) return [L(r.document, i, "local.runtime.binding", a("local.runtime.binding.no-writable"))];
			let l = X(c, r.controls.get(s) ?? [], t, G({ [s]: t }), r.valueRules, r.legacyValueRules);
			if (!l.ok) return [L(r.document, i, "local.runtime.value", l.detail)];
			let u = P(l.value);
			if (F(A[s], u)) return [];
			let d = {
				...A,
				[s]: u
			};
			return Q(r, i.id, d) ? [L(r.document, i, "local.runtime.value", a("local.runtime.value.range-order"))] : (J(d), []);
		},
		setMany(e, t) {
			H();
			let n = v(), r = n.nodeIndex.get(e.id);
			if (!r) return [L(n.document, e, "local.runtime.binding", a("local.runtime.binding.no-writable"))];
			let i = n.slotKeys.get(r.id);
			if (!i) return [L(n.document, r, "local.runtime.binding", a("local.runtime.binding.no-multi-slot"))];
			let o = Object.entries(t);
			if (!o.length) return [];
			let s = { ...A }, c = U(n, {
				...A,
				...Object.fromEntries(o.map(([e, t]) => [i[e], t]))
			}).environment;
			for (let [e, t] of o) {
				let o = i[e];
				if (!o || !Object.hasOwn(n.document.bindings, o)) return [L(n.document, r, "local.runtime.binding", a("local.runtime.binding.unknown-slot", { slot: e }))];
				let l = X(n.document.bindings[o], n.controls.get(o) ?? [], t, (e, t) => k(e, t, c), n.valueRules, n.legacyValueRules);
				if (!l.ok) return [L(n.document, r, "local.runtime.value", l.detail)];
				s[o] = P(l.value);
			}
			return Q(n, r.id, s) ? [L(n.document, r, "local.runtime.value", a("local.runtime.value.range-order"))] : (o.every(([e, t]) => F(A[i[e]], t)) || J(s), []);
		},
		parameterNames() {
			return H(), v().publicNames;
		},
		getParameter(e) {
			H();
			let t = v();
			if (!e.startsWith("@") && Object.hasOwn(t.document.bindings, e)) return Object.hasOwn(A, e) ? P(A[e]) : void 0;
		},
		getParameters() {
			H();
			let e = v(), t = {};
			for (let n of e.publicNames) {
				let e = A[n];
				t[n] = Array.isArray(e) ? Object.freeze([...e]) : e;
			}
			return Object.freeze(t);
		},
		setParameter(e, t) {
			H();
			let n = Object.create(null);
			return n[e] = t, Z(n);
		},
		setParameters(e) {
			if (H(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setParameters requires an object of parameter values.");
			return Z(e);
		},
		getExternal(e) {
			if (H(), Object.hasOwn(v().document.externals ?? {}, e) && Object.hasOwn(D, e)) return P(D[e]);
		},
		getExternalValues() {
			H();
			let e = {};
			for (let [t, n] of Object.entries(D)) e[t] = Array.isArray(n) ? Object.freeze([...n]) : n;
			return Object.freeze(e);
		},
		setExternalValues(e) {
			return Y(e);
		},
		evaluate(e) {
			H();
			let t = de(e).evaluate(M);
			return Array.isArray(t) ? t.slice() : t;
		},
		validate() {
			if (H(), z && z.revision === j) return z.diagnostics.map(ie);
			let e = he();
			return z = {
				revision: j,
				diagnostics: e
			}, e.map(ie);
		},
		text(e) {
			return H(), x(e, M);
		},
		reset(e) {
			H();
			let n = v(), r = n.nodeIndex.get(e.id);
			if (!r) return;
			let i = ye(r), a = { ...A };
			for (let [e, r] of Object.entries(n.document.bindings)) {
				if (!(n.controls.get(e) ?? []).some((e) => i.has(e.id))) continue;
				let o = y(r.initial);
				if (o) throw new c("expression-budget", `Parameter "${e}": ${t(o)}`, 0);
				a[e] = P(r.initial);
			}
			for (let e of i) V.set(e, (V.get(e) ?? 0) + 1);
			J(a);
		},
		resetToken(e) {
			H();
			let t = v().nodeIndex.get(e.id);
			return t ? V.get(t.id) ?? 0 : 0;
		},
		subscribe(e) {
			return H(), B.add(e), () => {
				B.delete(e);
			};
		},
		dispose() {
			I || (I = !0, C.state.flush(), i && C.scheduler.dispose(), B.clear(), l.clear(), d.clear(), _.computationExpressions.clear(), _.constErrors.clear(), _.cycleErrors.clear(), _.validationRules.length = 0, V.clear());
		}
	};
	return me.set(be, {
		update: ve,
		notify() {
			if (!I) for (let e of B) e();
		}
	}), W(), K(), be;
}
export { te as a, N as i, ge as n, he as r, _e as t };
