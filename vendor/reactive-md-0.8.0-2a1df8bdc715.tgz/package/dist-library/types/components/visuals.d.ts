import { type ReactNode } from 'react';
import type { LocalComponentContext } from '../react/component-api.js';
export declare function VisualFrame({ className, label, children, component, }: {
    className: string;
    label: ReactNode;
    children: ReactNode;
    /** Stable component hook consumed by theme CSS; omitted for plain frames. */
    component?: string;
}): import("react").JSX.Element;
export declare function TableView(context: LocalComponentContext): import("react").JSX.Element;
export declare function ChartView(context: LocalComponentContext): import("react").JSX.Element;
export declare function PlotView(context: LocalComponentContext): import("react").JSX.Element;
export declare function TimelineView(context: LocalComponentContext): import("react").JSX.Element;
export declare function DiagramView(context: LocalComponentContext): import("react").JSX.Element;
export declare function NodeView(context: LocalComponentContext): import("react").JSX.Element;
