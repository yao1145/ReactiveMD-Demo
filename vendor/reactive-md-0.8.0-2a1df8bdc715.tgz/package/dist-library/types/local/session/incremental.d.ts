import { type SemanticCacheStats } from './compiler-cache.js';
import { LocalParseSession } from './parse-session.js';
import type { LocalCompileOptions, LocalCompileResult } from '../contracts/types.js';
export interface LocalIncrementalStats {
    mode: 'full' | 'incremental' | 'cached';
    totalBlocks: number;
    compiledBlocks: number;
    reusedBlocks: number;
    compiledCharacters: number;
    fallbackReason?: string;
    /** Block-index construction attempts during this call (including deferred recovery). */
    cacheBuilds?: number;
    sharedNodes?: number;
    semantic?: SemanticCacheStats;
    parse?: Readonly<LocalParseSession['stats']>;
    stages?: Readonly<Record<string, number>>;
}
export declare class LocalCompileSession {
    private disposed;
    private snapshot;
    private deferred;
    private readonly parseSession;
    private readonly semantic;
    private readonly services;
    private shared;
    private sharedKey;
    private sharedMode;
    private epoch;
    private cacheBuilds;
    private serial;
    private lastStats;
    get stats(): Readonly<LocalIncrementalStats>;
    compile(source: string, options?: LocalCompileOptions): LocalCompileResult;
    /** Compiler-owned persistent result for the Worker and preview. Treat as read-only. */
    compileShared(source: string, options?: LocalCompileOptions): LocalCompileResult;
    private compileCore;
    private seed;
    private update;
    /**
     * Lezer only proposes block boundaries. The local parser can keep one node
     * across them (a lazy continuation line after an empty nested list item) or
     * read a block differently after its predecessor (`+` after indented code is
     * a paragraph, not a list). Every boundary next to a recompiled block or in
     * the edited gap is therefore re-parsed by the local parser in one window:
     * from the last top-level node before the boundary to the first one after
     * it. The window must reproduce exactly the nodes of the assembled blocks.
     * Matching edge nodes leave the parser in the same state as the complete
     * document, so untouched boundaries keep the result of earlier revisions.
     */
    private sameBoundaries;
    private publish;
    get hasPendingPreparation(): boolean;
    prepare(): boolean;
    prepareAsync(signal?: {
        readonly aborted: boolean;
    }, yieldTask?: () => Promise<void>): Promise<boolean>;
    clear(): void;
    dispose(): void;
}
export declare function createLocalCompileSession(): LocalCompileSession;
