/**
 * Structural execution services for the single compiler pass.
 *
 * These interfaces describe what the compiler *uses*, never a concrete
 * implementation. Sessions, workers and tests can supply their own parser or
 * semantic store without the core importing a cache class, a session module or
 * a theme registry. Omitting every service keeps the same semantic flow; it
 * only drops cross-revision reuse and the optional KaTeX display precheck.
 */
import type { LocalExpression } from '../evaluation/expression.js';
import type { CompiledPlotFormula, LatexExpression, PlotFormulaKind } from '../evaluation/math.js';
import type { InlinePlanLookup } from '../markdown/fast-markdown.js';
import type { ParsedLocal } from '../parsing/parser-core.js';
import type { SourceContext } from '../source/source-context.js';
import type { Diagnostic, LocalCompileOptions, LocalHtmlPolicy, LocalMathDisplayIssue, LocalValueKind } from '../contracts/types.js';
/** Parser entry used by tracked compiles; the session owns the cache. */
export interface LocalCompilerParserService {
    parse(source: string, options?: LocalCompileOptions, context?: SourceContext, rowPlans?: InlinePlanLookup): ParsedLocal;
}
/**
 * Successful semantic products from previous revisions. Every method must be
 * a pure lookup or store keyed by source text or validated attributes; errors
 * are still reported against the current source, never replayed.
 */
export interface LocalCompilerSemanticService {
    expression(source: string): LocalExpression;
    infer(expression: LocalExpression, environment: Record<string, LocalValueKind>): LocalValueKind;
    attributes<T>(key: string): {
        value: T;
        origin: number;
    } | undefined;
    rememberAttributes(key: string, origin: number, value: unknown): void;
    binding<T>(key: string): T | undefined;
    rememberBinding(key: string, value: unknown): void;
    latex(source: string): LatexExpression;
}
/** Optional KaTeX display precheck; compat and standard keep the full check. */
export type LocalMathDisplayInspector = (source: string, block: boolean) => readonly LocalMathDisplayIssue[];
/** Optional whole-document HTML sanitizer for the native HTML branch. */
export type LocalHtmlDocumentSanitizer = (source: string, policy: LocalHtmlPolicy, maxSyntaxNodes: number) => {
    markup: string;
    diagnostics: Diagnostic[];
};
/** Optional plot-formula compiler; omitted assemblies reject plot formulas. */
export interface LocalCompilerPlotMath {
    kind(source: string): PlotFormulaKind | null;
    gridSize(samples: number): number;
    compile(source: string): CompiledPlotFormula;
}
/** Optional execution goods for one compile; all fields are independent. */
export interface LocalCompilerCoreServices {
    parser?: LocalCompilerParserService;
    semantic?: LocalCompilerSemanticService;
    /**
     * Per-row inline plans from the previous revision. Checked before the
     * session LRU so large sequential row blocks cannot thrash it.
     */
    rowPlans?: InlinePlanLookup;
    display?: LocalMathDisplayInspector;
    /** Whole-document HTML branch; absent in the minimal assembly. */
    htmlDocument?: LocalHtmlDocumentSanitizer;
    /** Plot formula semantics; absent in the minimal assembly. */
    plotMath?: LocalCompilerPlotMath;
}
