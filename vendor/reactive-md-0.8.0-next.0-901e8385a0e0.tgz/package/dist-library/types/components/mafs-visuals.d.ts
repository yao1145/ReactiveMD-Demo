import { type KeyboardEvent as ReactKeyboardEvent } from 'react';
export interface MafsRange {
    min: number;
    max: number;
}
export interface PlotSurfacePoint {
    x: number;
    y: number;
}
export interface PlotSurfaceSegment {
    curve: number;
    points: PlotSurfacePoint[];
}
export interface MafsCoordinatePlaneProps {
    x: number;
    y: number;
    xRange: MafsRange;
    yRange: MafsRange;
    step: number;
    disabled: boolean;
    accent: string;
    onMove: (x: number, y: number) => void;
}
export declare function MafsCoordinatePlane({ x, y, xRange, yRange, step, disabled, accent, onMove, }: MafsCoordinatePlaneProps): import("react").JSX.Element;
export interface MafsPlotSurfaceProps {
    label: string;
    readoutId?: string;
    xDomain: MafsRange;
    yDomain: MafsRange;
    xTicks: number[];
    yTicks: number[];
    xLabel: string;
    yLabel: string;
    segments: PlotSurfaceSegment[];
    colors: readonly string[];
    focused: number | null;
    onFocusedChange: (curve: number | null) => void;
    onActiveXChange: (x: number | null) => void;
    curvePointAt: (curve: number, x: number) => PlotSurfacePoint | null;
    onKeyDown?: (event: ReactKeyboardEvent<Element>) => void;
    onFocus?: () => void;
    onBlur?: () => void;
}
export declare function MafsPlotSurface({ label, readoutId, xDomain, yDomain, xTicks, yTicks, xLabel, yLabel, segments, colors, focused, onFocusedChange, onActiveXChange, curvePointAt, onKeyDown, onFocus, onBlur, }: MafsPlotSurfaceProps): import("react").JSX.Element;
