import { f as e, n as t } from "./registry-B9Jc3FVe.js";
import { i as n, n as r, r as i } from "./resources-BGt8mpDA.js";
import { c as a, t as o } from "./LocalDocumentView-CAjEPw4h.js";
import { createLocalExportPlan as s } from "./reactive-md-export.js";
import { createElement as c } from "react";
import { renderToString as l } from "react-dom/server";
// src/react/server.tsx
function u(u) {
	let d = e(u.document, u.reactConfig?.config);
	if (d.push(...u.reactConfig ? a(u.reactConfig, u.document.extensions) : n(u.document.extensions, void 0)), d.push(...i({
		document: u.document,
		installed: t(u.reactConfig?.config),
		externalNames: new Set(u.reactConfig?.config.components.map((e) => e.name) ?? [])
	})), d.length) return {
		ok: !1,
		diagnostics: d
	};
	if (u.reactConfig) {
		let e = s({
			document: u.document,
			config: u.reactConfig.config,
			target: "ssr",
			resources: u.resources
		});
		if (d.push(...e.diagnostics), !e.ok) return {
			ok: !1,
			diagnostics: d
		};
	}
	try {
		let e = l(c(o, {
			...u,
			mode: "static",
			staticFirst: !1,
			onDiagnostics(e) {
				d.push(...e), u.onDiagnostics?.(e);
			}
		}));
		return /data-rmd-extension-error\s*=|local-sdk-unavailable/.test(e) && d.push(r("local.extension.ssr-render", "Server output contains an unavailable extension component.")), d.some((e) => e.severity === "error") ? {
			ok: !1,
			diagnostics: d
		} : {
			ok: !0,
			markup: e,
			diagnostics: d
		};
	} catch (e) {
		let t = u.document.extensions?.components.map((e) => e.id).join(", ");
		return d.push(r("local.extension.ssr-render", `Server rendering failed${t ? ` (document extensions: ${t})` : ""}: ${e instanceof Error ? e.message : String(e)}`)), {
			ok: !1,
			diagnostics: d
		};
	}
}
export { u as renderLocalStaticDocument };
