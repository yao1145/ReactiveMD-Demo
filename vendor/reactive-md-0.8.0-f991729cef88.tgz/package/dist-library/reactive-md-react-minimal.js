import { c as e, n as t } from "./sdk-core-CIxdxzII.js";
import { n, r, t as i } from "./package-core-BcNQeexR.js";
import { n as a, t as o } from "./LocalDocumentViewCore-CtD9xOcs.js";
import s from "./reactive-md-minimal-react-preset.js";
import { jsx as c } from "react/jsx-runtime";
// src/react/minimal.tsx
function l(e = {}) {
	return i(e, s);
}
function u(e, n) {
	return t(e, n, s.components);
}
var d, f = () => d ??= l().reactConfig;
function p(e) {
	return /* @__PURE__ */ c(o, {
		...e,
		getBaseConfig: f
	});
}
function m(e) {
	return /* @__PURE__ */ c(a, {
		...e,
		useBaseCompileConfig: !0,
		getBaseConfig: f
	});
}
export { p as LocalDocumentView, m as LocalReactiveDocument, u as createReactConfig, l as createReactHost, e as defineReactComponent, n as defineReactComponentPackage, r as defineReactPreset };
