// \0rolldown/runtime.js
var e = Object.create, t = Object.defineProperty, n = Object.getOwnPropertyDescriptor, r = Object.getOwnPropertyNames, i = Object.getPrototypeOf, a = Object.prototype.hasOwnProperty, o = (e, t) => () => (t || (e((t = { exports: {} }).exports, t, t.exports), e = null), t.exports), s = (e, n) => {
	let r = {};
	for (var i in e) t(r, i, {
		get: e[i],
		enumerable: !0
	});
	return n || t(r, Symbol.toStringTag, { value: "Module" }), r;
}, c = (e, i, o, s) => {
	if (i && typeof i == "object" || typeof i == "function") for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
		get: ((e) => i[e]).bind(null, d),
		enumerable: !(s = n(i, d)) || s.enumerable
	});
	return e;
}, l = (n, r, o) => (o = n == null ? {} : e(i(n)), c(r || !n || !n.__esModule || !a.call(n, "default") ? t(o, "default", {
	value: n,
	enumerable: !0
}) : o, n)), u = /* @__PURE__ */ ((e) => typeof require < "u" ? require : typeof Proxy < "u" ? new Proxy(e, { get: (e, t) => (typeof require < "u" ? require : e)[t] }) : e)(function(e) {
	if (typeof require < "u") return require.apply(this, arguments);
	throw Error("Calling `require` for \"" + e + "\" in an environment that doesn't expose the `require` function. See https://rolldown.rs/in-depth/bundling-cjs#require-external-modules for more details.");
}), d = class extends Error {
	code;
	offset;
	constructor(e, t, n = 0) {
		super(t), this.name = "LatexError", this.code = e, this.offset = n;
	}
}, f = 5e4, p = 2e4, m = 5e3, h = 120, g = 2e4, _ = 1e3, v = /* @__PURE__ */ new Set([
	"quad",
	"qquad",
	"enspace",
	"thinspace",
	"medspace",
	"thickspace",
	"negthinspace",
	"displaystyle",
	"textstyle",
	"scriptstyle",
	"scriptscriptstyle",
	"limits",
	"nolimits"
]), y = {
	alpha: "alpha",
	beta: "beta",
	gamma: "gamma",
	theta: "theta",
	omega: "omega",
	lambda: "lambda",
	mu: "mu",
	sigma: "sigma"
}, b = /* @__PURE__ */ new Set([
	"sin",
	"cos",
	"tan",
	"arcsin",
	"arccos",
	"arctan",
	"exp",
	"ln",
	"log",
	"min",
	"max"
]), x = {
	"{": "lbrace",
	"}": "rbrace",
	"|": "vert",
	"%": "percent",
	"&": "amp",
	"#": "hash",
	_: "underscore",
	$: "dollar"
};
function S(e) {
	let t = [], n = 0, r = (e, n, r) => {
		if (t.length >= p) throw new d("latex-budget", "Math input contains too many tokens.", r);
		t.push({
			kind: e,
			value: n,
			offset: r
		});
	};
	for (; n < e.length;) {
		let t = e[n];
		if (t === " " || t === "	" || t === "\r" || t === "\n") n += 1;
		else if (t === "%") for (; n < e.length && e[n] !== "\n";) n += 1;
		else if (t === "\\") {
			if (n + 1 >= e.length) throw new d("latex-syntax", "Formula ends with a lone backslash.", n);
			let t = e[n + 1];
			if (t === "\\") {
				r("command", "newline", n), n += 2;
				continue;
			}
			if (/[A-Za-z]/.test(t)) {
				let t = n + 1;
				for (; t < e.length && /[A-Za-z]/.test(e[t]);) t += 1;
				let i = e.slice(n + 1, t);
				v.has(i) || r("command", i, n), n = t;
				continue;
			}
			if (t === " " || t === "," || t === ";" || t === ":" || t === "!") {
				n += 2;
				continue;
			}
			let i = x[t];
			if (i) {
				r("command", i, n), n += 2;
				continue;
			}
			r("command", t, n), n += 2;
		} else if (t === "θ") r("command", "theta", n), n += 1;
		else if (t >= "0" && t <= "9") {
			let t = /^(?:\d+(?:\.\d*)?|\.\d+)/.exec(e.slice(n));
			r("number", t[0], n), n += t[0].length;
		} else if (t === "." && e[n + 1] >= "0" && e[n + 1] <= "9") {
			let t = /^(?:\d+(?:\.\d*)?|\.\d+)/.exec(e.slice(n));
			r("number", t[0], n), n += t[0].length;
		} else /[A-Za-z]/.test(t) ? (r("letter", t, n), n += 1) : (r("punct", t, n), n += 1);
	}
	return r("eof", "", e.length), t;
}
function C(e) {
	return Object.prototype.hasOwnProperty.call(y, e);
}
function w(e) {
	switch (e.kind) {
		case "number":
		case "letter": return !0;
		case "punct": return e.value === "(" || e.value === "{" || e.value === "[" || e.value === "|";
		case "command": {
			let t = e.value;
			return b.has(t) || C(t) ? !0 : t === "frac" || t === "dfrac" || t === "tfrac" || t === "sqrt" || t === "left" || t === "pi" || t === "mathrm" || t === "begin" || t === "lvert" || t === "vert" || t === "lbrace";
		}
		default: return !1;
	}
}
function T(e) {
	if (e.kind === "punct") return e.value === "=" ? "eq" : e.value === "<" ? "lt" : e.value === ">" ? "gt" : null;
	if (e.kind === "command") {
		if (e.value === "ne" || e.value === "neq") return "ne";
		if (e.value === "le" || e.value === "leq") return "le";
		if (e.value === "ge" || e.value === "geq") return "ge";
	}
	return null;
}
var E = class {
	tokens;
	source;
	pos = 0;
	nodes = 0;
	allowY;
	constructor(e, t, n = {}) {
		this.source = e, this.tokens = t, this.allowY = n.allowY === !0;
	}
	parseDocument() {
		if (this.peek().kind === "eof") throw new d("latex-empty", "Formula is empty.", 0);
		if (this.atLetter("y") && this.atPunctAt(1, "=") && (this.pos += 2), this.peek().kind === "eof") throw new d("latex-empty", "Missing expression after y.", this.peek().offset);
		let e = this.parseAdditive(0), t = this.peek();
		if (t.kind !== "eof") throw T(t) || t.kind === "punct" && t.value === "=" ? new d("latex-relation", "Plots support only explicit y = f(x) equations.", t.offset) : new d("latex-syntax", `Unexpected token "${this.raw(t)}".`, t.offset);
		return e;
	}
	parseEquation() {
		if (this.peek().kind === "eof") throw new d("latex-empty", "Formula is empty.", 0);
		let e = this.parseAdditive(0), t = this.peek();
		if (t.kind !== "punct" || t.value !== "=") throw new d("latex-relation", "Plot formulas must be written as an equation.", t.offset);
		this.take();
		let n = this.parseAdditive(0), r = this.peek();
		if (r.kind !== "eof") throw new d("latex-syntax", `Unexpected token "${this.raw(r)}".`, r.offset);
		return {
			left: e,
			right: n
		};
	}
	peek(e = 0) {
		return this.tokens[Math.min(this.pos + e, this.tokens.length - 1)];
	}
	take() {
		return this.tokens[this.pos++];
	}
	atPunct(e) {
		let t = this.peek();
		return t.kind === "punct" && t.value === e;
	}
	atPunctAt(e, t) {
		let n = this.peek(e);
		return n.kind === "punct" && n.value === t;
	}
	atCommand(e) {
		let t = this.peek();
		return t.kind === "command" && t.value === e;
	}
	atLetter(e) {
		let t = this.peek();
		return t.kind === "letter" && t.value === e;
	}
	expectPunct(e) {
		let t = this.peek();
		if (t.kind !== "punct" || t.value !== e) throw new d("latex-syntax", `Missing "${e}".`, t.offset);
		return this.take();
	}
	raw(e) {
		return e.kind === "eof" ? "end of input" : e.kind === "command" ? `\\${e.value}` : this.source.slice(e.offset, e.offset + Math.max(1, e.value.length));
	}
	make(e, t, n) {
		if (this.nodes += 1, this.nodes > m) throw new d("latex-budget", "Formula is too complex.", t);
		if (n > h) throw new d("latex-budget", "Formula is nested too deeply.", t);
		return e;
	}
	parseAdditive(e) {
		let t = this.parseMultiplicative(e + 1, !1);
		for (;;) {
			let n = this.peek();
			if (n.kind !== "punct" || n.value !== "+" && n.value !== "-") break;
			let r = this.take().value, i = this.parseMultiplicative(e + 1, !1);
			t = this.make({
				kind: "binary",
				op: r,
				left: t,
				right: i,
				offset: n.offset
			}, n.offset, e);
		}
		return t;
	}
	parseMultiplicative(e, t) {
		let n = this.parseUnary(e + 1, t);
		for (;;) {
			let r = this.peek();
			if (r.kind === "punct" && r.value === "/") {
				this.take();
				let i = this.parseUnary(e + 1, t);
				n = this.make({
					kind: "binary",
					op: "/",
					left: n,
					right: i,
					offset: r.offset
				}, r.offset, e);
				continue;
			}
			if (r.kind === "punct" && r.value === "*" || r.kind === "command" && (r.value === "cdot" || r.value === "times")) {
				this.take();
				let i = this.parseUnary(e + 1, t);
				n = this.make({
					kind: "binary",
					op: "*",
					left: n,
					right: i,
					offset: r.offset
				}, r.offset, e);
				continue;
			}
			if (t && r.kind === "command" && b.has(r.value) || !w(r)) break;
			let i = this.parseUnary(e + 1, t);
			n = this.make({
				kind: "binary",
				op: "*",
				left: n,
				right: i,
				offset: r.offset
			}, r.offset, e);
		}
		return n;
	}
	parseUnary(e, t) {
		let n = this.peek();
		if (n.kind === "punct" && (n.value === "+" || n.value === "-")) {
			this.take();
			let r = this.parseUnary(e + 1, t);
			return n.value === "+" ? r : this.make({
				kind: "unary",
				op: "-",
				operand: r,
				offset: n.offset
			}, n.offset, e);
		}
		return this.parsePower(e, t);
	}
	parsePower(e, t) {
		let n = this.parseAtom(e + 1, t), r = this.peek();
		if (r.kind === "punct" && r.value === "^") {
			this.take();
			let t = this.parseScriptArgument(e + 1);
			return this.make({
				kind: "binary",
				op: "^",
				left: n,
				right: t,
				offset: r.offset
			}, r.offset, e);
		}
		return n;
	}
	parseScriptArgument(e) {
		if (this.atPunct("{")) return this.parseBraceGroup(e + 1);
		if (this.atPunct("+") || this.atPunct("-")) {
			let t = this.take(), n = this.parseUnary(e + 1, !1);
			return t.value === "+" ? n : this.make({
				kind: "unary",
				op: "-",
				operand: n,
				offset: t.offset
			}, t.offset, e);
		}
		return this.parseUnary(e + 1, !1);
	}
	parseAtom(e, t) {
		let n = this.peek();
		if (n.kind === "number") {
			this.take();
			let t = Number(n.value);
			if (!Number.isFinite(t)) throw new d("latex-number", `Number "${n.value}" is not finite.`, n.offset);
			return this.make({
				kind: "number",
				value: t,
				offset: n.offset
			}, n.offset, e);
		}
		if (n.kind === "letter") return this.take(), this.variable(n.value, n.offset, e);
		if (n.kind === "punct") {
			if (n.value === "(") return this.parseParenthesized(e);
			if (n.value === "{") return this.parseBraceGroup(e);
			if (n.value === "[") return this.parseBracketGroup(e);
			if (n.value === "|") return this.parsePlainAbs(e, n.offset);
			throw new d("latex-syntax", `Cannot start an expression with "${n.value}".`, n.offset);
		}
		if (n.kind === "command") {
			let t = n.value;
			if (t === "frac" || t === "dfrac" || t === "tfrac") {
				this.take();
				let t = this.parseArgument(e + 1), r = this.parseArgument(e + 1);
				return this.make({
					kind: "binary",
					op: "/",
					left: t,
					right: r,
					offset: n.offset
				}, n.offset, e);
			}
			if (t === "sqrt") {
				this.take();
				let t = null;
				this.atPunct("[") && (this.take(), t = this.parseAdditive(e + 1), this.expectPunct("]"));
				let r = this.parseArgument(e + 1);
				return this.make({
					kind: "call",
					name: "sqrt",
					args: [r],
					base: t,
					power: null,
					offset: n.offset
				}, n.offset, e);
			}
			if (t === "left") return this.parseLeft(e);
			if (b.has(t)) return this.parseFunction(t, e);
			if (t === "pi") return this.take(), this.make({
				kind: "constant",
				value: "pi",
				offset: n.offset
			}, n.offset, e);
			if (C(t)) return this.take(), this.variable(y[t], n.offset, e);
			if (t === "mathrm") {
				this.take();
				let t = this.readRawGroup();
				if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(t.raw)) throw new d("latex-name", "\\mathrm requires a valid parameter name.", t.offset);
				return this.variable(t.raw, n.offset, e);
			}
			if (t === "begin") return this.parseCases(e);
			if (t === "lvert" || t === "vert") return this.parseCommandAbs(e, n.offset);
			throw t === "right" ? new d("latex-syntax", "\\right has no matching \\left.", n.offset) : t === "text" ? new d("latex-unsupported", "\\text is only allowed as the otherwise condition of a piecewise function.", n.offset) : new d("latex-unsupported", `Command \\${t} is not supported for computation.`, n.offset);
		}
		throw new d("latex-syntax", "Expression is incomplete.", n.offset);
	}
	parseArgument(e) {
		if (this.atPunct("{")) return this.parseBraceGroup(e + 1);
		if (this.peek().kind === "eof") throw new d("latex-syntax", "Command is missing an argument.", this.peek().offset);
		return this.parseUnary(e + 1, !1);
	}
	parseParenthesized(e) {
		let t = this.expectPunct("(");
		if (this.atPunct(")")) throw new d("latex-syntax", "Missing expression inside parentheses.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct(")"), n;
	}
	parseBraceGroup(e) {
		let t = this.expectPunct("{");
		if (this.atPunct("}")) throw new d("latex-syntax", "Missing expression inside braces.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct("}"), n;
	}
	parseBracketGroup(e) {
		let t = this.expectPunct("[");
		if (this.atPunct("]")) throw new d("latex-syntax", "Missing expression inside brackets.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct("]"), n;
	}
	parsePlainAbs(e, t) {
		if (this.take(), this.atPunct("|")) throw new d("latex-syntax", "Absolute value is missing its contents.", t);
		let n = this.parseAdditive(e + 1);
		if (this.atPunct("|")) this.take();
		else if (this.atCommand("rvert")) this.take();
		else throw new d("latex-syntax", "Unpaired absolute value bar.", t);
		return this.make({
			kind: "abs",
			value: n,
			offset: t
		}, t, e);
	}
	parseCommandAbs(e, t) {
		if (this.take(), this.atCommand("rvert") || this.atCommand("vert") || this.atPunct("|")) throw new d("latex-syntax", "Absolute value is missing its contents.", t);
		let n = this.parseAdditive(e + 1);
		if (this.atCommand("rvert") || this.atCommand("vert") || this.atPunct("|")) this.take();
		else throw new d("latex-syntax", "Unpaired absolute value bar.", t);
		return this.make({
			kind: "abs",
			value: n,
			offset: t
		}, t, e);
	}
	parseLeft(e) {
		let t = this.take(), n = this.readDelimiter(), r = this.parseAdditive(e + 1);
		if (!this.atCommand("right")) throw new d("latex-syntax", "\\left has no matching \\right.", t.offset);
		this.take();
		let i = this.readDelimiter();
		if (n === "|" && i !== "|") throw new d("latex-syntax", "Unpaired absolute value bar.", t.offset);
		return n === "|" ? this.make({
			kind: "abs",
			value: r,
			offset: t.offset
		}, t.offset, e) : r;
	}
	readDelimiter() {
		let e = this.peek();
		if (e.kind === "punct" && (e.value === "(" || e.value === ")" || e.value === "[" || e.value === "]" || e.value === "|" || e.value === ".")) return this.take(), e.value;
		if (e.kind === "command" && (e.value === "lbrace" || e.value === "rbrace" || e.value === "lvert" || e.value === "rvert" || e.value === "vert" || e.value === "Vert")) return this.take(), e.value === "lbrace" || e.value === "rbrace" ? "{" : e.value === "lvert" || e.value === "rvert" || e.value === "vert" ? "|" : "Vert";
		throw new d("latex-syntax", "Missing delimiter after \\left/\\right.", e.offset);
	}
	variable(e, t, n) {
		if (e === "y" && !this.allowY) throw new d("latex-name", "y is the plot output marker and cannot appear in the expression.", t);
		return e === "e" || e === "pi" ? this.make({
			kind: "constant",
			value: e,
			offset: t
		}, t, n) : this.make({
			kind: "variable",
			name: e,
			offset: t
		}, t, n);
	}
	parseFunction(e, t) {
		let n = this.take().offset, r = null, i = null;
		e === "log" && this.atPunct("_") && (this.take(), r = this.parseScriptArgument(t + 1)), this.atPunct("^") && (this.take(), i = this.parseScriptArgument(t + 1));
		let a = [];
		if ((e === "min" || e === "max") && this.atPunct("(")) {
			if (this.take(), this.atPunct(")")) throw new d("latex-syntax", `\\${e} requires at least one argument.`, n);
			for (a.push(this.parseAdditive(t + 1)); this.atPunct(",");) this.take(), a.push(this.parseAdditive(t + 1));
			this.expectPunct(")");
		} else a.push(this.parseFunctionArgument(t + 1));
		return this.make({
			kind: "call",
			name: e,
			args: a,
			base: r,
			power: i,
			offset: n
		}, n, t);
	}
	parseFunctionArgument(e) {
		if (this.atPunct("(")) {
			this.take();
			let t = this.parseAdditive(e + 1);
			return this.expectPunct(")"), t;
		}
		return this.parseMultiplicative(e + 1, !0);
	}
	parseCases(e) {
		let t = this.take(), n = this.readRawGroup();
		if (n.raw.trim() !== "cases") throw new d("latex-unsupported", `Environment "${n.raw.trim()}" is not supported.`, n.offset);
		let r = [];
		for (; !this.atCommand("end");) {
			if (this.peek().kind === "eof") throw new d("latex-syntax", "cases environment is missing \\end{cases}.", t.offset);
			if (this.atCommand("newline")) {
				this.take();
				continue;
			}
			let n = this.parseAdditive(e + 1);
			this.atPunct(",") && this.take();
			let i = null;
			if (this.atPunct("&") && (this.take(), i = this.parseCaseCondition(e + 1), this.atPunct(",") && this.take()), r.push({
				value: n,
				when: i
			}), this.atCommand("newline")) {
				this.take();
				continue;
			}
			if (this.atCommand("end")) break;
			let a = this.peek();
			throw new d("latex-syntax", `Unexpected "${this.raw(a)}" after a cases branch.`, a.offset);
		}
		let i = this.take();
		if (this.readRawGroup().raw.trim() !== "cases") throw new d("latex-syntax", "\\begin{cases} must be closed with \\end{cases}.", i.offset);
		if (r.length === 0) throw new d("latex-syntax", "cases environment has no branches.", t.offset);
		return this.make({
			kind: "cases",
			branches: r,
			offset: t.offset
		}, t.offset, e);
	}
	parseCaseCondition(e) {
		if (this.atCommand("text")) {
			let e = this.take(), t = this.readRawGroup();
			if (t.raw.trim() !== "otherwise") throw new d("latex-unsupported", `Unsupported piecewise condition text "${t.raw.trim()}".`, e.offset);
			return null;
		}
		let t = this.parseAdditive(e + 1), n = this.peek(), r = T(n);
		if (!r) throw new d("latex-syntax", "Piecewise condition requires one comparison.", n.offset);
		return this.take(), {
			op: r,
			left: t,
			right: this.parseAdditive(e + 1)
		};
	}
	readRawGroup() {
		let e = this.expectPunct("{"), t = 1, n = this.pos;
		for (; n < this.tokens.length; n += 1) {
			let e = this.tokens[n];
			if (e.kind === "eof") break;
			if (e.kind === "punct") {
				if (e.value === "{") t += 1;
				else if (e.value === "}" && (--t, t === 0)) break;
			}
		}
		if (n >= this.tokens.length || this.tokens[n].kind === "eof") throw new d("latex-syntax", "Unclosed brace.", e.offset);
		let r = this.tokens[n];
		return this.pos = n + 1, {
			raw: this.source.slice(e.offset + 1, r.offset),
			offset: e.offset + 1
		};
	}
};
function D(e, t) {
	switch (e.kind) {
		case "variable":
			e.name !== "x" && t.add(e.name);
			return;
		case "number":
		case "constant": return;
		case "unary":
			D(e.operand, t);
			return;
		case "binary":
			D(e.left, t), D(e.right, t);
			return;
		case "abs":
			D(e.value, t);
			return;
		case "call":
			e.base && D(e.base, t), e.power && D(e.power, t);
			for (let n of e.args) D(n, t);
			return;
		case "cases":
			for (let n of e.branches) D(n.value, t), n.when && (D(n.when.left, t), D(n.when.right, t));
			return;
	}
}
function O(e, t, n, r) {
	let i = [], a = (t) => {
		switch (t.kind) {
			case "variable": {
				if (r.has(t.name)) return;
				let a = n + t.offset, o = a + 1;
				e.startsWith("\\mathrm", t.offset) ? o = n + e.indexOf("}", t.offset) + 1 : e[t.offset] === "\\" && (o = a + 1 + t.name.length), i.push({
					name: t.name,
					range: {
						start: a,
						end: o
					}
				});
				return;
			}
			case "unary":
				a(t.operand);
				return;
			case "binary":
				a(t.left), a(t.right);
				return;
			case "abs":
				a(t.value);
				return;
			case "call":
				t.base && a(t.base), t.power && a(t.power), t.args.forEach(a);
				return;
			case "cases":
				for (let e of t.branches) a(e.value), e.when && (a(e.when.left), a(e.when.right));
				return;
			case "number":
			case "constant": return;
		}
	};
	return a(t), i;
}
function k(e) {
	let t = e.trim(), n = e.length - e.trimStart().length;
	if (K(t) === "polar") {
		q(t);
		let { right: e } = new E(t, S(t), { allowY: !0 }).parseEquation();
		return O(t, e, n, /* @__PURE__ */ new Set(["theta"])).sort((e, t) => e.range.start - t.range.start);
	}
	let r = G(t);
	if (r) {
		let e = /* @__PURE__ */ new Set([
			"x",
			"y",
			"t"
		]), t = [];
		for (let i of [{
			text: r.x,
			offset: r.xOffset
		}, {
			text: r.y,
			offset: r.yOffset
		}]) {
			B(i.text);
			let r = new E(i.text, S(i.text)).parseDocument();
			t.push(...O(i.text, r, n + i.offset, e));
		}
		return t.sort((e, t) => e.range.start - t.range.start);
	}
	try {
		return O(e, new E(e, S(e)).parseDocument(), 0, /* @__PURE__ */ new Set(["x", "y"])).sort((e, t) => e.range.start - t.range.start);
	} catch (t) {
		try {
			let t = new E(e, S(e), { allowY: !0 }).parseEquation(), n = /* @__PURE__ */ new Set(["x", "y"]);
			return [...O(e, t.left, 0, n), ...O(e, t.right, 0, n)].sort((e, t) => e.range.start - t.range.start);
		} catch {
			throw t;
		}
	}
}
function A(e, t, n) {
	throw new d(e, t, n);
}
function j(e, t) {
	return Number.isFinite(e) || A("latex-number", "Result is not finite.", t), e;
}
function M(e, t, n) {
	if (e === "x") return t.x;
	let r = t.env[e];
	return r === void 0 && !Object.prototype.hasOwnProperty.call(t.env, e) && A("latex-variable", `Parameter "${e}" is not declared.`, n), typeof r == "number" && Number.isFinite(r) || A("latex-type", `Parameter "${e}" must be a finite number.`, n), r;
}
function N(e, t, n) {
	return e === 0 && t < 0 && A("latex-divide-by-zero", "Negative powers of zero are undefined.", n), e < 0 && !Number.isInteger(t) && A("latex-domain", "A negative base with a non-integer exponent is not real.", n), j(e ** +t, n);
}
function P(e, t, n) {
	let r = t ?? 2;
	return (!Number.isFinite(r) || r <= 0) && A("latex-domain", "Root index must be positive.", n), e < 0 ? (Number.isInteger(r) && r % 2 != 0 || A("latex-domain", "A negative number has no real even root.", n), j(r === 3 ? -Math.cbrt(-e) : -((-e) ** (1 / r)), n)) : j(e ** (1 / r), n);
}
function F(e, t) {
	let n = L(e.left, t), r = L(e.right, t);
	switch (e.op) {
		case "eq": return n === r;
		case "ne": return n !== r;
		case "lt": return n < r;
		case "le": return n <= r;
		case "gt": return n > r;
		case "ge": return n >= r;
		default: return !1;
	}
}
function I(e, t) {
	let n = e.args.map((e) => L(e, t)), r = 0;
	switch (e.name) {
		case "sin":
			r = Math.sin(n[0]);
			break;
		case "cos":
			r = Math.cos(n[0]);
			break;
		case "tan":
			Math.abs(Math.cos(n[0])) < 1e-15 && A("latex-domain", "tan is undefined at this point.", e.offset), r = Math.tan(n[0]);
			break;
		case "arcsin":
			(n[0] < -1 || n[0] > 1) && A("latex-domain", "arcsin argument must be in [-1, 1].", e.offset), r = Math.asin(n[0]);
			break;
		case "arccos":
			(n[0] < -1 || n[0] > 1) && A("latex-domain", "arccos argument must be in [-1, 1].", e.offset), r = Math.acos(n[0]);
			break;
		case "arctan":
			r = Math.atan(n[0]);
			break;
		case "exp":
			r = Math.exp(n[0]);
			break;
		case "ln":
			n[0] <= 0 && A("latex-domain", "ln argument must be positive.", e.offset), r = Math.log(n[0]);
			break;
		case "log": {
			let i = e.base ? L(e.base, t) : 10;
			(i <= 0 || i === 1) && A("latex-domain", "Logarithm base must be positive and not equal to 1.", e.offset), n[0] <= 0 && A("latex-domain", "Logarithm argument must be positive.", e.offset), r = Math.log(n[0]) / Math.log(i);
			break;
		}
		case "min":
			r = Math.min(...n);
			break;
		case "max":
			r = Math.max(...n);
			break;
		case "sqrt":
			r = P(n[0], e.base ? L(e.base, t) : null, e.offset);
			break;
		default: A("latex-unsupported", "Unsupported function.", e.offset);
	}
	return e.power && (r = N(r, L(e.power, t), e.offset)), j(r, e.offset);
}
function L(e, t) {
	let n = e.offset;
	t.steps += 1, t.depth += 1;
	try {
		switch (t.steps > t.limit && A("latex-budget", "Math evaluation exceeded its budget.", n), t.depth > _ && A("latex-budget", "Math evaluation is nested too deeply.", n), e.kind) {
			case "number": return e.value;
			case "constant": return e.value === "pi" ? Math.PI : Math.E;
			case "variable": return M(e.name, t, e.offset);
			case "unary": {
				let n = L(e.operand, t);
				return e.op === "-" ? -n : n;
			}
			case "binary": {
				let n = L(e.left, t), r = L(e.right, t);
				switch (e.op) {
					case "+": return j(n + r, e.offset);
					case "-": return j(n - r, e.offset);
					case "*": return j(n * r, e.offset);
					case "/": return r === 0 && A("latex-divide-by-zero", "Division by zero.", e.offset), j(n / r, e.offset);
					case "^": return N(n, r, e.offset);
				}
				break;
			}
			case "abs": return j(Math.abs(L(e.value, t)), e.offset);
			case "call": return I(e, t);
			case "cases":
				for (let n of e.branches) if (n.when === null || F(n.when, t)) return L(n.value, t);
				A("latex-undefined", "No piecewise branch matched.", e.offset);
		}
		A("latex-unsupported", "Cannot compute this math structure.", n);
	} finally {
		--t.depth;
	}
}
var R = /* @__PURE__ */ new Map();
function z(e, t, n) {
	return {
		source: e,
		dependencies: n,
		evaluate(e, n, r) {
			if (typeof e != "number" || !Number.isFinite(e)) throw new d("latex-variable", "Plot input x must be a finite number.", 0);
			let i = {
				x: e,
				env: n ?? {},
				steps: r?.steps ?? 0,
				limit: r?.limit ?? g,
				depth: 0
			};
			try {
				return L(t, i);
			} finally {
				r && (r.steps = i.steps);
			}
		}
	};
}
function B(e) {
	if (typeof e != "string") throw new d("latex-syntax", "Math source must be a string.", 0);
	if (e.length > f) throw new d("latex-budget", "Formula exceeds the length limit.", f);
	let t = R.get(e);
	if (t) return t;
	let n = new E(e, S(e)).parseDocument(), r = /* @__PURE__ */ new Set();
	D(n, r);
	let i = z(e, n, [...r]);
	return R.size >= 512 && R.clear(), R.set(e, i), i;
}
function V(e, t) {
	switch (e.kind) {
		case "variable": return e.name === t;
		case "number":
		case "constant": return !1;
		case "unary": return V(e.operand, t);
		case "binary": return V(e.left, t) || V(e.right, t);
		case "abs": return V(e.value, t);
		case "call": return e.base !== null && V(e.base, t) || e.power !== null && V(e.power, t) || e.args.some((e) => V(e, t));
		case "cases": return e.branches.some((e) => V(e.value, t) || e.when !== null && (V(e.when.left, t) || V(e.when.right, t)));
	}
}
function H(e, t) {
	return e.kind === "variable" && e.name === t;
}
function U(e) {
	let t = 0;
	for (let n = 0; n < e.length; n += 1) {
		let r = e[n];
		if (r === "{") t += 1;
		else if (r === "}") t = Math.max(0, t - 1);
		else if (r === "=" && t === 0) return n;
	}
	return -1;
}
function W(e, t) {
	let n = [], r = 0, i = 0, a = (r) => {
		let a = e.slice(i, r), o = a.length - a.trimStart().length, s = a.trim();
		s && n.push({
			text: s,
			offset: t + i + o
		});
	};
	for (let t = 0; t < e.length; t += 1) {
		let n = e[t];
		n === "{" ? r += 1 : n === "}" ? r = Math.max(0, r - 1) : n === "\\" && e[t + 1] === "\\" && r === 0 && (a(t), i = t + 2, t += 1);
	}
	return a(e.length), n;
}
function G(e) {
	let t = /^\\begin\{cases\}([\s\S]*)\\end\{cases\}$/u.exec(e);
	if (!t) return null;
	let n = t.index + 13, r = W(t[1], n);
	if (r.length !== 2) return null;
	let i = null, a = null;
	for (let e of r) {
		let t = U(e.text);
		if (t < 0) return null;
		let n = e.text.slice(0, t).trim(), r = e.text.slice(t + 1), o = r.length - r.trimStart().length, s = r.trim();
		if (!s) return null;
		let c = e.offset + t + 1 + o;
		if (n === "x" && i === null) i = {
			text: s,
			offset: c
		};
		else if (n === "y" && a === null) a = {
			text: s,
			offset: c
		};
		else return null;
	}
	return i !== null && a !== null ? {
		x: i.text,
		y: a.text,
		xOffset: i.offset,
		yOffset: a.offset
	} : null;
}
function K(e) {
	let t = e.trim();
	if (!t) return null;
	if (/^\\begin\{cases\}/u.test(t)) return "parametric";
	let n = U(t);
	if (n < 0) return null;
	if (t.slice(0, n).trim() === "r") return "polar";
	if (t.slice(0, n).trim() !== "y") return "implicit";
	try {
		let { right: e } = new E(t, S(t), { allowY: !0 }).parseEquation();
		return V(e, "y") ? "implicit" : "explicit";
	} catch {
		return "explicit";
	}
}
function q(e) {
	if (typeof e != "string") throw new d("latex-syntax", "Math source must be a string.", 0);
	if (e.length > f) throw new d("latex-budget", "Formula exceeds the length limit.", f);
	let t = e.trim();
	if (!t) throw new d("latex-empty", "Formula is empty.", 0);
	let n = G(t);
	if (n) {
		let e = (e) => S(e).some((e) => e.kind === "letter" && e.value === "x");
		if (e(n.x) || e(n.y)) throw new d("latex-variable", "Parametric formulas use t and cannot read x.", 0);
		let r = B(n.x), i = B(n.y), a = /* @__PURE__ */ new Set();
		for (let e of [...r.dependencies, ...i.dependencies]) e !== "t" && e !== "x" && e !== "y" && a.add(e);
		return {
			kind: "parametric",
			source: t,
			expression: r,
			yExpression: i,
			dependencies: [...a]
		};
	}
	let { left: r, right: i } = new E(t, S(t), { allowY: !0 }).parseEquation();
	if (H(r, "r") && K(t) === "polar") {
		for (let e of [
			"x",
			"y",
			"r"
		]) if (V(i, e)) throw new d("latex-variable", `Polar formulas use theta and cannot read ${e}.`, i.offset);
		let e = /* @__PURE__ */ new Set();
		return D(i, e), e.delete("theta"), {
			kind: "polar",
			source: t,
			expression: z(t, i, [...e]),
			yExpression: null,
			dependencies: [...e]
		};
	}
	if (H(r, "y") && !V(i, "y")) {
		let e = B(t);
		return {
			kind: "explicit",
			source: t,
			expression: e,
			yExpression: null,
			dependencies: e.dependencies
		};
	}
	let a = {
		kind: "binary",
		op: "-",
		left: r,
		right: i,
		offset: r.offset
	}, o = /* @__PURE__ */ new Set();
	return D(a, o), o.delete("x"), o.delete("y"), {
		kind: "implicit",
		source: t,
		expression: z(t, a, [...o]),
		yExpression: null,
		dependencies: [...o]
	};
}
var J = 100, Y = 32;
function X(e) {
	return Math.max(32, Math.min(100, Math.floor(e)));
}
export { q as a, K as c, u as d, l as f, B as i, o as l, J as n, X as o, Y as r, k as s, d as t, s as u };
