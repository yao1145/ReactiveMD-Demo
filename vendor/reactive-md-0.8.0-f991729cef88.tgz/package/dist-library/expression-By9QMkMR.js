import { $ as e, lt as t, ut as n } from "./preset-core-CKc5YXSM.js";
import { F as r, O as i, j as a } from "./config-validation-BLmgvFIS.js";
// src/local/evaluation/formatting.ts
var o = class extends Error {
	code;
	constructor(e, t) {
		super(t), this.name = "LocalFunctionError", this.code = e;
	}
}, s = [
	"en-US",
	"zh-CN",
	"de-DE",
	"fr-FR",
	"ja-JP"
], c = new Set(s), ee = /^[A-Z]{3}$/, l = 20, te = { signDisplay: "negative" };
function u(e) {
	throw new o("expression-domain", e);
}
function d(e, n) {
	if (e.length > 1e5) throw new o("expression-budget", `${n} exceeds the ${t}-character limit.`);
	return e;
}
function f(e) {
	return c.has(e) || u(`Unsupported locale "${e}"; expected one of ${s.join(", ")}.`), e;
}
function p(e, t) {
	return (!Number.isInteger(e) || e < 0 || e > l) && u(`${t} digits must be an integer from 0 to ${l}.`), e;
}
function m(e) {
	if (!Number.isFinite(e)) throw new o("expression-number", "Value must be a finite number.");
	return e;
}
function h(e, t, n, r, i) {
	let a;
	try {
		a = new Intl.NumberFormat(e, {
			...t,
			...te
		});
	} catch {
		a = void 0;
	}
	return a === void 0 && u(i), d(a.format(n), r);
}
function ne(e, t = 2, n = "en-US", r = !0) {
	let i = f(n), a = p(t, "formatNumber");
	return typeof r != "boolean" && u("formatNumber grouping must be a boolean."), e === null ? "" : h(i, {
		useGrouping: r,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, m(e), "Formatted number", `Cannot format a number for locale "${i}".`);
}
function re(e, t = 0, n = "en-US") {
	let r = f(n), i = p(t, "formatPercent");
	return e === null ? "" : h(r, {
		style: "percent",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, m(e), "Formatted percentage", `Cannot format a percentage for locale "${r}".`);
}
function ie(e, t = 2, n = "en-US") {
	let r = f(n), i = p(t, "formatScientific");
	return e === null ? "" : h(r, {
		notation: "scientific",
		minimumFractionDigits: i,
		maximumFractionDigits: i,
		roundingMode: "halfExpand"
	}, m(e), "Formatted number", `Cannot format a number for locale "${r}".`);
}
function ae(e, t = "USD", n = 2, r = "en-US") {
	let i = f(r);
	ee.test(t) || u(`Currency "${t}" must be a three-letter uppercase code such as "USD".`);
	let a = p(n, "formatCurrency");
	return e === null ? "" : h(i, {
		style: "currency",
		currency: t,
		minimumFractionDigits: a,
		maximumFractionDigits: a,
		roundingMode: "halfExpand"
	}, m(e), "Formatted currency", `Currency code "${t}" is not accepted by Intl.`);
}
// src/local/evaluation/collection-functions.ts
function g() {
	throw new o("expression-number", "The result is not a finite number.");
}
function _(e) {
	if (!Number.isFinite(e)) throw new o("expression-value", "Numeric array members must be finite numbers.");
	return e;
}
function v(e) {
	let t = 0;
	for (let n of e) t += _(n);
	return Number.isFinite(t) || g(), t;
}
function oe(e) {
	if (e.length === 0) return null;
	let t = v(e) / e.length;
	return Number.isFinite(t) || g(), t;
}
function se(e) {
	if (e.length === 0) return null;
	let t = _(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = _(e[n]);
		r < t && (t = r);
	}
	return t;
}
function ce(e) {
	if (e.length === 0) return null;
	let t = _(e[0]);
	for (let n = 1; n < e.length; n += 1) {
		let r = _(e[n]);
		r > t && (t = r);
	}
	return t;
}
// src/local/evaluation/dates.ts
function le(e) {
	let t = /^(\d{4})-(\d{2})-(\d{2})$/.exec(e);
	if (!t) return null;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	if (n < 1 || r < 1 || r > 12 || i < 1 || i > 31) return null;
	let a = /* @__PURE__ */ new Date(0);
	return a.setUTCFullYear(n, r - 1, i), a.getUTCFullYear() === n && a.getUTCMonth() === r - 1 && a.getUTCDate() === i ? a.getTime() : null;
}
// src/local/evaluation/data-functions.ts
function y(e) {
	throw new o("expression-domain", e);
}
function ue(e) {
	return d(e.trim(), "trim result");
}
function de(e) {
	return d(e.toLowerCase(), "lower result");
}
function fe(e) {
	return d(e.toUpperCase(), "upper result");
}
function pe(e, t) {
	return e.startsWith(t);
}
function me(e, t) {
	return e.endsWith(t);
}
function he(e, n, r) {
	n.length === 0 && y("replace search text must not be empty.");
	let i = r.length - n.length;
	if (i > 0) {
		let r = 0, a = 0;
		for (;;) {
			let t = e.indexOf(n, a);
			if (t < 0) break;
			r += 1, a = t + n.length;
		}
		if (e.length + r * i > 1e5) throw new o("expression-budget", `replace result would exceed the ${t}-character limit.`);
	}
	let a = "", s = 0;
	for (;;) {
		let t = e.indexOf(n, s);
		if (t < 0) break;
		a += e.slice(s, t), a += r, s = t + n.length;
	}
	return a += e.slice(s), d(a, "replace result");
}
function b(e, t) {
	return e < 0 ? Math.max(t + e, 0) : Math.min(e, t);
}
function ge(e, t, n) {
	Number.isInteger(t) || y("slice start must be an integer."), n !== void 0 && !Number.isInteger(n) && y("slice end must be an integer.");
	let r = Array.from(e), i = r.length, a = b(t, i), o = n === void 0 ? i : b(n, i);
	return o <= a ? "" : d(r.slice(a, o).join(""), "slice result");
}
var _e = /* @__PURE__ */ new Map([
	["days", 864e5],
	["hours", 36e5],
	["minutes", 6e4],
	["seconds", 1e3],
	["milliseconds", 1]
]), ve = "days, hours, minutes, seconds or milliseconds";
function x(e) {
	let t = le(e);
	if (t === null) throw new o("expression-domain", `Date "${e}" must be a valid YYYY-MM-DD calendar date in years 0001-9999.`);
	return t;
}
function ye(e, t) {
	let n = x(e), r = x(t);
	return n === r ? 0 : n < r ? -1 : 1;
}
function be(e, t, n = "days") {
	let r = _e.get(n);
	return r === void 0 && y(`dateDiff unit must be ${ve}.`), (x(e) - x(t)) / r;
}
// src/local/evaluation/expression.ts
var S = class extends Error {
	offset;
	code;
	constructor(e, t, n = 0) {
		super(t), this.name = "LocalExpressionError", this.code = e, this.offset = n;
	}
}, C = /* @__PURE__ */ "abs.sqrt.floor.ceil.round.min.max.pow.sin.cos.tan.asin.acos.atan.exp.log.len.contains.clamp.sum.average.minOf.maxOf.formatNumber.formatPercent.formatScientific.formatCurrency.trim.lower.upper.startsWith.endsWith.replace.slice.dateCompare.dateDiff".split("."), w = new Set(C), xe = /* @__PURE__ */ new Map([["pi", Math.PI], ["e", Math.E]]), T = /* @__PURE__ */ new Set([
	"__proto__",
	"prototype",
	"constructor"
]), Se = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), Ce = /* @__PURE__ */ new Set([
	...C,
	"x",
	"y",
	"pi",
	"e",
	"true",
	"false",
	"null",
	...T
]), E = 4e3, we = 2e3, D = 100, O = 200, k = 1e4, Te = 250, A = t, j = t, Ee = 500;
function M(r) {
	if (r.length > 1e4) return {
		code: "expression-budget",
		...a("local.budget.value.array", { limit: e }),
		message: `Array exceeds the ${e}-item limit.`
	};
	let i = null, o = 0;
	for (let e of r) if (typeof e == "string") {
		if (i === "number") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (i = "string", e.length > 1e5) return {
			code: "expression-budget",
			...a("local.budget.value.array-member", { limit: t }),
			message: `Array member exceeds the ${t}-character limit.`
		};
		if (o += e.length, o > 1e5) return {
			code: "expression-budget",
			...a("local.budget.value.array-contents", { limit: n }),
			message: `Array contents exceed the ${n}-character limit.`
		};
	} else if (typeof e == "number") {
		if (i === "string") return {
			code: "expression-value",
			key: "error.array.homogeneous",
			message: "Array elements must all be strings or all be numbers."
		};
		if (i = "number", !Number.isFinite(e)) return {
			code: "expression-value",
			key: "error.array.finite",
			message: "Array members must be finite numbers."
		};
	} else return {
		code: "expression-value",
		key: "error.array.members",
		message: "Array members must be strings or finite numbers."
	};
	return null;
}
function N(e) {
	if (typeof e == "string") return e.length > 1e5 ? a("local.budget.value.string", { limit: t }) : null;
	if (Array.isArray(e)) {
		let t = M(e);
		return t ? a(t.key, t.params) : null;
	}
	return null;
}
function P(e) {
	let t = N(e);
	return t ? i(t) : null;
}
var De = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/, Oe = /[A-Za-z_]/, ke = /[A-Za-z0-9_]/;
function Ae(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r >= "0" && r <= "9" || r === "." && /[0-9]/.test(e[n + 1] ?? "")) {
			let r = De.exec(e.slice(n));
			if (!r) throw new S("expression-syntax", "Invalid number.", n);
			let i = r[0], a = Number(i);
			if (!Number.isFinite(a)) throw new S("expression-number", `Number must be finite: ${i}.`, n);
			t.push({
				kind: "number",
				value: i,
				start: n,
				number: a
			}), n += i.length;
			continue;
		}
		if (r === "\"" || r === "'") {
			let i = n, a = r, o = "", s = n + 1, c = !1;
			for (; s < e.length;) {
				let t = e[s];
				if (t === a) {
					c = !0, s += 1;
					break;
				}
				if (t === "\n" || t === "\r") throw new S("expression-string", "String literals cannot span lines.", i);
				if (t === "\\") {
					let t = e[s + 1];
					if (t === void 0) break;
					switch (t) {
						case "\\":
							o += "\\";
							break;
						case "'":
							o += "'";
							break;
						case "\"":
							o += "\"";
							break;
						case "n":
							o += "\n";
							break;
						case "t":
							o += "	";
							break;
						default: throw new S("expression-string", `Unsupported escape \\${t}.`, s);
					}
					s += 2;
				} else o += t, s += 1;
			}
			if (!c) throw new S("expression-string", "Unterminated string literal.", i);
			if (o.length > A) throw new S("expression-budget", "String literal exceeds the length limit.", i);
			t.push({
				kind: "string",
				value: o,
				start: i
			}), n = s;
			continue;
		}
		if (Oe.test(r)) {
			let r = n + 1;
			for (; r < e.length && ke.test(e[r]);) r += 1;
			t.push({
				kind: "ident",
				value: e.slice(n, r),
				start: n
			}), n = r;
			continue;
		}
		let i = e.slice(n, n + 2);
		if (e.startsWith("!==", n) || e.startsWith("===", n)) throw new S("expression-syntax", `Unsupported operator ${e.slice(n, n + 3)}.`, n);
		if (i === "==" || i === "!=" || i === "<=" || i === ">=" || i === "&&" || i === "||") t.push({
			kind: "punct",
			value: i,
			start: n
		}), n += 2;
		else if ("+-*/%()!<>?:,[]".includes(r)) t.push({
			kind: "punct",
			value: r,
			start: n
		}), n += 1;
		else throw r === "=" ? new S("expression-assignment", "Assignments are not supported.", n) : r === "." ? new S("expression-property", "Property access is not supported.", n) : r === "&" || r === "|" ? new S("expression-syntax", `Use ${r}${r} for logical operations.`, n) : new S("expression-syntax", `Unrecognized character "${r}".`, n);
	}
	return t.push({
		kind: "eof",
		value: "",
		start: e.length
	}), t;
}
var je = {
	abs: [1, 1],
	sqrt: [1, 1],
	floor: [1, 1],
	ceil: [1, 1],
	round: [1, 1],
	min: [1, 2 ** 53 - 1],
	max: [1, 2 ** 53 - 1],
	pow: [2, 2],
	sin: [1, 1],
	cos: [1, 1],
	tan: [1, 1],
	asin: [1, 1],
	acos: [1, 1],
	atan: [1, 1],
	exp: [1, 1],
	log: [1, 1],
	len: [1, 1],
	contains: [2, 2],
	clamp: [3, 3],
	sum: [1, 1],
	average: [1, 1],
	minOf: [1, 1],
	maxOf: [1, 1],
	formatNumber: [1, 4],
	formatPercent: [1, 3],
	formatScientific: [1, 3],
	formatCurrency: [1, 4],
	trim: [1, 1],
	lower: [1, 1],
	upper: [1, 1],
	startsWith: [2, 2],
	endsWith: [2, 2],
	replace: [3, 3],
	slice: [2, 3],
	dateCompare: [2, 2],
	dateDiff: [2, 3]
};
function Me(e) {
	let t = 0, n = [{
		node: e,
		depth: 1
	}];
	for (; n.length > 0;) {
		let { node: e, depth: r } = n.pop();
		switch (r > t && (t = r), e.kind) {
			case "unary":
				n.push({
					node: e.operand,
					depth: r + 1
				});
				break;
			case "binary":
				n.push({
					node: e.left,
					depth: r + 1
				}), n.push({
					node: e.right,
					depth: r + 1
				});
				break;
			case "conditional":
				n.push({
					node: e.test,
					depth: r + 1
				}), n.push({
					node: e.consequent,
					depth: r + 1
				}), n.push({
					node: e.alternate,
					depth: r + 1
				});
				break;
			case "call":
				for (let t of e.args) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "array":
				for (let t of e.elements) n.push({
					node: t,
					depth: r + 1
				});
				break;
			case "index": n.push({
				node: e.target,
				depth: r + 1
			}), n.push({
				node: e.index,
				depth: r + 1
			});
		}
	}
	return t;
}
var Ne = class {
	tokens;
	position = 0;
	nodeCount = 0;
	dependencyNames = [];
	dependencySet = /* @__PURE__ */ new Set();
	dependencyStarts = /* @__PURE__ */ new Map();
	constructor(e) {
		this.tokens = Ae(e);
	}
	get dependencies() {
		return this.dependencyNames;
	}
	get dependencyOffsets() {
		return this.dependencyStarts;
	}
	parse() {
		if (this.peek().kind === "eof") throw new S("expression-empty", "Expression is empty.", 0);
		let e = this.parseConditional(0), t = this.peek();
		if (t.kind !== "eof") throw new S("expression-syntax", `Unexpected content "${t.value}".`, t.start);
		if (Me(e) > O) throw new S("expression-budget", "Expression is nested too deeply.", e.start);
		return e;
	}
	peek() {
		return this.tokens[this.position];
	}
	next() {
		let e = this.tokens[this.position];
		return this.position += 1, e;
	}
	isPunct(e) {
		let t = this.peek();
		return t.kind === "punct" && t.value === e;
	}
	expect(e) {
		let t = this.peek();
		if (t.kind !== "punct" || t.value !== e) throw new S("expression-syntax", `Missing "${e}".`, t.start);
		return this.next();
	}
	node(e, t, n) {
		if (this.nodeCount += 1, this.nodeCount > we) throw new S("expression-budget", "Expression is too complex.", n);
		if (t > D) throw new S("expression-budget", "Expression is nested too deeply.", n);
		return e;
	}
	parseConditional(e) {
		let t = this.parseOr(e);
		if (!this.isPunct("?")) return t;
		let n = t.start;
		this.next();
		let r = this.parseConditional(e + 1);
		this.expect(":");
		let i = this.parseConditional(e + 1);
		return this.node({
			kind: "conditional",
			test: t,
			consequent: r,
			alternate: i,
			start: n
		}, e, n);
	}
	parseOr(e) {
		let t = this.parseAnd(e);
		for (; this.isPunct("||");) {
			let n = t.start;
			this.next();
			let r = this.parseAnd(e);
			t = this.node({
				kind: "binary",
				operator: "||",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAnd(e) {
		let t = this.parseEquality(e);
		for (; this.isPunct("&&");) {
			let n = t.start;
			this.next();
			let r = this.parseEquality(e);
			t = this.node({
				kind: "binary",
				operator: "&&",
				left: t,
				right: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseEquality(e) {
		let t = this.parseRelational(e);
		for (; this.isPunct("==") || this.isPunct("!=");) {
			let n = t.start, r = this.next().value, i = this.parseRelational(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseRelational(e) {
		let t = this.parseAdditive(e);
		for (; this.isPunct("<") || this.isPunct("<=") || this.isPunct(">") || this.isPunct(">=");) {
			let n = t.start, r = this.next().value, i = this.parseAdditive(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAdditive(e) {
		let t = this.parseMultiplicative(e);
		for (; this.isPunct("+") || this.isPunct("-");) {
			let n = t.start, r = this.next().value, i = this.parseMultiplicative(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseMultiplicative(e) {
		let t = this.parseUnary(e);
		for (; this.isPunct("*") || this.isPunct("/") || this.isPunct("%");) {
			let n = t.start, r = this.next().value, i = this.parseUnary(e);
			t = this.node({
				kind: "binary",
				operator: r,
				left: t,
				right: i,
				start: n
			}, e, n);
		}
		return t;
	}
	parseUnary(e) {
		let t = this.peek();
		if (t.kind === "punct" && (t.value === "-" || t.value === "+" || t.value === "!")) {
			this.next();
			let n = this.parseUnary(e + 1);
			return this.node({
				kind: "unary",
				operator: t.value,
				operand: n,
				start: t.start
			}, e, t.start);
		}
		return this.parsePrimary(e);
	}
	parsePrimary(e) {
		let t = this.parseAtom(e);
		for (; this.isPunct("[");) {
			let n = t.start;
			this.next();
			let r = this.parseConditional(e + 1);
			this.expect("]"), t = this.node({
				kind: "index",
				target: t,
				index: r,
				start: n
			}, e, n);
		}
		return t;
	}
	parseAtom(e) {
		let t = this.peek();
		if (t.kind === "number") return this.next(), this.node({
			kind: "literal",
			value: t.number,
			start: t.start
		}, e, t.start);
		if (t.kind === "string") return this.next(), this.node({
			kind: "literal",
			value: t.value,
			start: t.start
		}, e, t.start);
		if (t.kind === "ident") {
			this.next();
			let n = t.value;
			if (this.isPunct("(")) {
				if (!w.has(n)) throw new S("expression-unknown-function", `Unknown function "${n}".`, t.start);
				this.next();
				let r = [];
				if (!this.isPunct(")")) for (r.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), r.push(this.parseConditional(e + 1));
				this.expect(")");
				let [i, a] = je[n];
				if (r.length < i || r.length > a) throw new S("expression-arity", `Function ${n} expects ${i === a ? `${i} ${i === 1 ? "argument" : "arguments"}` : i === 1 ? "at least one argument" : `${i}–${a} arguments`}.`, t.start);
				return this.node({
					kind: "call",
					name: n,
					args: r,
					start: t.start
				}, e, t.start);
			}
			if (n === "true" || n === "false") return this.node({
				kind: "literal",
				value: n === "true",
				start: t.start
			}, e, t.start);
			if (n === "null") return this.node({
				kind: "literal",
				value: null,
				start: t.start
			}, e, t.start);
			let r = xe.get(n);
			if (r !== void 0) return this.node({
				kind: "literal",
				value: r,
				start: t.start
			}, e, t.start);
			if (T.has(n)) throw new S("expression-forbidden-name", `Name "${n}" is not allowed.`, t.start);
			if (w.has(n)) throw new S("expression-syntax", `Function ${n} must be called with parentheses.`, t.start);
			return this.dependencySet.has(n) || (this.dependencySet.add(n), this.dependencyNames.push(n), this.dependencyStarts.set(n, t.start)), this.node({
				kind: "reference",
				name: n,
				start: t.start
			}, e, t.start);
		}
		if (t.kind === "punct" && t.value === "(") {
			this.next();
			let t = this.parseConditional(e + 1);
			return this.expect(")"), t;
		}
		if (t.kind === "punct" && t.value === "[") {
			this.next();
			let n = [];
			if (!this.isPunct("]")) for (n.push(this.parseConditional(e + 1)); this.isPunct(",");) this.next(), n.push(this.parseConditional(e + 1));
			return this.expect("]"), this.node({
				kind: "array",
				elements: n,
				start: t.start
			}, e, t.start);
		}
		throw new S("expression-syntax", "Expected an expression.", t.start);
	}
};
function F(e) {
	switch (e) {
		case "string": return "string";
		case "number": return "number";
		case "boolean": return "boolean";
		case "null": return "null";
		case "array": return "array";
		case "number-array": return "number array";
	}
}
function I(e) {
	return e === null ? "null" : Array.isArray(e) ? "array" : typeof e == "boolean" ? "boolean" : typeof e == "number" ? "number" : "string";
}
function L(e, t) {
	throw new S("expression-type", e, t);
}
function R(e, t, n, r) {
	e !== t && L(`${r}, got ${F(e)}.`, n);
}
function Pe(e, t) {
	return e === t ? e : e === "null" ? t : t === "null" ? e : null;
}
function z(e, t) {
	switch (e.kind) {
		case "literal": return I(e.value);
		case "reference": {
			if (typeof t != "object" || !t || !Object.prototype.hasOwnProperty.call(t, e.name)) throw new S("expression-unknown-name", `Variable "${e.name}" is not declared.`, e.start);
			let n = t[e.name];
			if (typeof n != "string" || !Se.has(n)) throw new S("expression-value", `Variable "${e.name}" has an invalid type.`, e.start);
			return n;
		}
		case "unary": {
			let n = z(e.operand, t);
			return e.operator === "!" ? (R(n, "boolean", e.start, "Logical not requires a boolean"), "boolean") : (R(n, "number", e.start, `Unary ${e.operator} requires a number`), "number");
		}
		case "binary": {
			let n = z(e.left, t), r = z(e.right, t);
			switch (e.operator) {
				case "+": return n === "number" && r === "number" ? "number" : n === "string" && r === "string" ? "string" : L(`Operator "+" requires two numbers or two strings, got ${F(n)} and ${F(r)}.`, e.start);
				case "-":
				case "*":
				case "/":
				case "%": return R(n, "number", e.start, `Operator "${e.operator}" requires a number`), R(r, "number", e.start, `Operator "${e.operator}" requires a number`), "number";
				case "<":
				case "<=":
				case ">":
				case ">=": return n === "number" && r === "number" || n === "string" && r === "string" ? "boolean" : L(`Comparison operator "${e.operator}" requires two numbers or two strings, got ${F(n)} and ${F(r)}.`, e.start);
				case "==":
				case "!=": return n !== r && n !== "null" && r !== "null" ? L(`Equality comparison requires matching types, got ${F(n)} and ${F(r)}.`, e.start) : "boolean";
				case "&&":
				case "||": return R(n, "boolean", e.start, "Logical operators require booleans"), R(r, "boolean", e.start, "Logical operators require booleans"), "boolean";
			}
			break;
		}
		case "array": {
			if (e.elements.length === 0) return "number-array";
			let n = null;
			for (let r of e.elements) {
				let e = z(r, t);
				if (e !== "string" && e !== "number") return L(`Array literals require string or number elements, got ${F(e)}.`, r.start);
				if (n === null) n = e;
				else if (n !== e) return L(`Array literals require elements of one type, got ${F(n)} and ${F(e)}.`, r.start);
			}
			return n === "string" ? "array" : "number-array";
		}
		case "index": {
			let n = z(e.target, t);
			return R(z(e.index, t), "number", e.start, "Array index must be a number"), n === "array" ? "string" : n === "number-array" ? "number" : L(`Index access requires an array, got ${F(n)}.`, e.start);
		}
		case "conditional": {
			R(z(e.test, t), "boolean", e.start, "Conditional test must be a boolean");
			let n = z(e.consequent, t), r = z(e.alternate, t);
			if (n === "array" && e.alternate.kind === "array" && e.alternate.elements.length === 0 || r === "array" && e.consequent.kind === "array" && e.consequent.elements.length === 0) return "array";
			let i = Pe(n, r);
			return i === null ? L(`Conditional branches must have matching types or one null, got ${F(n)} and ${F(r)}.`, e.start) : i;
		}
		case "call": {
			let n = e.args.map((e) => z(e, t));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": return R(n[0], "number", e.start, `Function ${e.name} requires a number`), "number";
				case "min":
				case "max":
				case "pow":
				case "clamp":
					for (let t of n) R(t, "number", e.start, `Function ${e.name} requires a number`);
					return "number";
				case "len": return n[0] !== "string" && n[0] !== "array" && n[0] !== "number-array" && L(`Function len requires a string or array, got ${F(n[0])}.`, e.start), "number";
				case "contains":
					if (n[0] === "number-array") return R(n[1], "number", e.start, "Function contains requires a numeric member"), "boolean";
					if (n[0] === "string" || n[0] === "array") return R(n[1], "string", e.start, "Function contains requires a string member"), "boolean";
					L(`Function contains requires a string or array, got ${F(n[0])}.`, e.start);
					break;
				case "sum":
				case "average":
				case "minOf":
				case "maxOf": return R(n[0], "number-array", e.start, `Function ${e.name} requires a numeric array`), "number";
				case "formatNumber":
				case "formatPercent":
				case "formatScientific": return n[0] !== "number" && n[0] !== "null" && L(`Function ${e.name} requires a number or null, got ${F(n[0])}.`, e.start), n[1] !== void 0 && R(n[1], "number", e.start, `Function ${e.name} requires numeric fraction digits`), n[2] !== void 0 && R(n[2], "string", e.start, `Function ${e.name} requires a string locale`), e.name === "formatNumber" && n[3] !== void 0 && R(n[3], "boolean", e.start, "Function formatNumber requires a boolean grouping flag"), "string";
				case "formatCurrency": return n[0] !== "number" && n[0] !== "null" && L(`Function formatCurrency requires a number or null, got ${F(n[0])}.`, e.start), n[1] !== void 0 && R(n[1], "string", e.start, "Function formatCurrency requires a string currency code"), n[2] !== void 0 && R(n[2], "number", e.start, "Function formatCurrency requires numeric fraction digits"), n[3] !== void 0 && R(n[3], "string", e.start, "Function formatCurrency requires a string locale"), "string";
				case "trim":
				case "lower":
				case "upper": return R(n[0], "string", e.start, `Function ${e.name} requires a string`), "string";
				case "startsWith":
				case "endsWith": return R(n[0], "string", e.start, `Function ${e.name} requires a string`), R(n[1], "string", e.start, `Function ${e.name} requires a string search value`), "boolean";
				case "replace": return R(n[0], "string", e.start, "Function replace requires a string"), R(n[1], "string", e.start, "Function replace requires a string search value"), R(n[2], "string", e.start, "Function replace requires a string replacement"), "string";
				case "slice": return R(n[0], "string", e.start, "Function slice requires a string"), R(n[1], "number", e.start, "Function slice requires a numeric start index"), n[2] !== void 0 && R(n[2], "number", e.start, "Function slice requires a numeric end index"), "string";
				case "dateCompare": return R(n[0], "string", e.start, "Function dateCompare requires a date string"), R(n[1], "string", e.start, "Function dateCompare requires a date string"), "number";
				case "dateDiff": return R(n[0], "string", e.start, "Function dateDiff requires a date string"), R(n[1], "string", e.start, "Function dateDiff requires a date string"), n[2] !== void 0 && R(n[2], "string", e.start, "Function dateDiff requires a string unit"), "number";
			}
			break;
		}
	}
	throw new S("expression-type", "Unsupported expression.", 0);
}
function B(e, t, n = "expression-eval") {
	throw new S(n, e, t);
}
function V(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) throw new S("expression-value", "Expression environment must be an object.", 0);
}
function Fe(e, t, n) {
	if (e === null) return null;
	if (typeof e == "string") {
		let r = P(e);
		if (r) throw new S("expression-budget", `Variable "${t}": ${r}`, n);
		return e;
	}
	if (typeof e == "boolean") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new S("expression-value", `Variable "${t}" must be a finite number.`, n);
		return e;
	}
	if (Array.isArray(e)) {
		let r = M(e);
		if (r) throw new S(r.code, `Variable "${t}": ${r.message}`, n);
		return e;
	}
	throw new S("expression-value", `Variable "${t}" has an invalid value type.`, n);
}
function Ie(e, t, n) {
	return V(e), Object.prototype.hasOwnProperty.call(e, t) || B(`Variable "${t}" is not declared.`, n, "expression-unknown-name"), Fe(e[t], t, n);
}
function H(e, t, n = "Expected a number") {
	return typeof e == "number" && Number.isFinite(e) || B(`${n}.`, t, "expression-type"), e;
}
function U(e, t, n = "Expected a boolean") {
	return typeof e != "boolean" && B(`${n}.`, t, "expression-type"), e;
}
function W(e, t, n = "Expected a string") {
	return typeof e != "string" && B(`${n}.`, t, "expression-type"), e;
}
function G(e, t, n) {
	Array.isArray(e) || B(`${n}.`, t, "expression-type");
	for (let r of e) typeof r == "number" && Number.isFinite(r) || B(`${n}.`, t, "expression-type");
	return e;
}
function Le(e, t) {
	let n = M(e);
	return n && B(n.message, t, n.code), e;
}
function K(e, t) {
	try {
		return t();
	} catch (t) {
		throw t instanceof o ? new S(t.code, t.message, e) : t;
	}
}
function q(e, t) {
	return Number.isNaN(e) && B("The result is undefined.", t, "expression-domain"), Number.isFinite(e) || B("The result is not a finite number.", t, "expression-number"), e;
}
function Re(e, t) {
	let n = Array.from(e), r = Array.from(t), i = Math.min(n.length, r.length);
	for (let e = 0; e < i; e += 1) {
		let t = n[e].codePointAt(0), i = r[e].codePointAt(0);
		if (t !== i) return t < i ? -1 : 1;
	}
	return n.length === r.length ? 0 : n.length < r.length ? -1 : 1;
}
function ze(e, t) {
	if (e === t) return !0;
	if (Array.isArray(e) && Array.isArray(t)) {
		if (e.length !== t.length) return !1;
		for (let n = 0; n < e.length; n += 1) if (e[n] !== t[n]) return !1;
		return !0;
	}
	return !1;
}
function Be(e, t) {
	return J(e, t, { steps: 0 }, 1);
}
function J(e, t, n, i) {
	switch (n.steps += 1, n.steps > k && B("Expression evaluation exceeded the step limit.", e.start, "expression-budget"), i > Te && B("Expression evaluation is nested too deeply.", e.start, "expression-budget"), e.kind) {
		case "literal": return e.value;
		case "reference": return Ie(t, e.name, e.start);
		case "unary": {
			let r = J(e.operand, t, n, i + 1);
			if (e.operator === "!") return !U(r, e.start, "Logical not requires a boolean");
			let a = H(r, e.start, `Unary ${e.operator} requires a number`);
			return q(e.operator === "-" ? -a : a, e.start);
		}
		case "binary": {
			if (e.operator === "&&" || e.operator === "||") {
				let r = U(J(e.left, t, n, i + 1), e.start, "Logical operators require booleans");
				return e.operator === "&&" && !r ? !1 : e.operator === "||" && r ? !0 : U(J(e.right, t, n, i + 1), e.start, "Logical operators require booleans");
			}
			let r = J(e.left, t, n, i + 1), a = J(e.right, t, n, i + 1);
			switch (e.operator) {
				case "+":
					if (typeof r == "number" && typeof a == "number") return q(r + a, e.start);
					if (typeof r == "string" && typeof a == "string") {
						let t = r + a;
						return t.length > A && B("String result exceeds the length limit.", e.start, "expression-budget"), t;
					}
					B("Operator \"+\" requires two numbers or two strings.", e.start, "expression-type");
				case "-":
				case "*":
				case "/":
				case "%": {
					let t = H(r, e.start, `Operator "${e.operator}" requires a number`), n = H(a, e.start, `Operator "${e.operator}" requires a number`);
					return (e.operator === "/" || e.operator === "%") && n === 0 && B("Division by zero.", e.start, "expression-divide-by-zero"), q(e.operator === "-" ? t - n : e.operator === "*" ? t * n : e.operator === "/" ? t / n : t % n, e.start);
				}
				case "==":
				case "!=": {
					let t = I(r), n = I(a);
					t !== n && t !== "null" && n !== "null" && B("Equality comparison requires matching types.", e.start, "expression-type");
					let i = ze(r, a);
					return e.operator === "==" ? i : !i;
				}
				case "<":
				case "<=":
				case ">":
				case ">=": {
					let t;
					return typeof r == "number" && typeof a == "number" ? t = r === a ? 0 : r < a ? -1 : 1 : typeof r == "string" && typeof a == "string" ? t = Re(r, a) : B(`Comparison operator "${e.operator}" requires two numbers or two strings.`, e.start, "expression-type"), e.operator === "<" ? t < 0 : e.operator === "<=" ? t <= 0 : e.operator === ">" ? t > 0 : t >= 0;
				}
			}
			break;
		}
		case "conditional": return J(U(J(e.test, t, n, i + 1), e.start, "Conditional test must be a boolean") ? e.consequent : e.alternate, t, n, i + 1);
		case "array": {
			let r = [];
			for (let a of e.elements) r.push(J(a, t, n, i + 1));
			return Le(r, e.start);
		}
		case "index": {
			let r = J(e.target, t, n, i + 1), a = H(J(e.index, t, n, i + 1), e.start, "Array index must be a number");
			return Number.isSafeInteger(a) || B("Array index must be a finite integer.", e.start, "expression-index"), Array.isArray(r) || B("Index access requires an array.", e.start, "expression-type"), a < 0 || a >= r.length ? null : r[a];
		}
		case "call": {
			let a = e.args.map((e) => J(e, t, n, i + 1));
			switch (e.name) {
				case "abs":
				case "sqrt":
				case "floor":
				case "ceil":
				case "round":
				case "sin":
				case "cos":
				case "tan":
				case "asin":
				case "acos":
				case "atan":
				case "exp":
				case "log": {
					let t = H(a[0], e.start, `Function ${e.name} requires a number`);
					e.name === "sqrt" && t < 0 && B("sqrt requires a non-negative argument.", e.start, "expression-domain"), e.name === "log" && t <= 0 && B("log requires a positive argument.", e.start, "expression-domain"), (e.name === "asin" || e.name === "acos") && (t < -1 || t > 1) && B(`${e.name} requires an argument between -1 and 1.`, e.start, "expression-domain");
					let n;
					switch (e.name) {
						case "abs":
							n = Math.abs(t);
							break;
						case "sqrt":
							n = Math.sqrt(t);
							break;
						case "floor":
							n = Math.floor(t);
							break;
						case "ceil":
							n = Math.ceil(t);
							break;
						case "round":
							n = Math.round(t);
							break;
						case "sin":
							n = Math.sin(t);
							break;
						case "cos":
							n = Math.cos(t);
							break;
						case "tan":
							n = Math.tan(t);
							break;
						case "asin":
							n = Math.asin(t);
							break;
						case "acos":
							n = Math.acos(t);
							break;
						case "atan":
							n = Math.atan(t);
							break;
						case "exp":
							n = Math.exp(t);
							break;
						default: n = Math.log(t);
					}
					return q(n, e.start);
				}
				case "min":
				case "max": {
					let t = H(a[0], e.start, `Function ${e.name} requires a number`);
					for (let n = 1; n < a.length; n += 1) {
						let r = H(a[n], e.start, `Function ${e.name} requires a number`);
						t = e.name === "min" ? Math.min(t, r) : Math.max(t, r);
					}
					return q(t, e.start);
				}
				case "pow": return q(H(a[0], e.start, "Function pow requires a number") ** +H(a[1], e.start, "Function pow requires a number"), e.start);
				case "clamp": {
					let t = H(a[0], e.start, "Function clamp requires a number"), n = H(a[1], e.start, "Function clamp requires a number"), r = H(a[2], e.start, "Function clamp requires a number");
					return n > r && B("clamp lower bound cannot exceed upper bound.", e.start, "expression-domain"), q(Math.min(r, Math.max(n, t)), e.start);
				}
				case "len": {
					let t = a[0];
					if (typeof t == "string") return r(t);
					if (Array.isArray(t)) return t.length;
					B("Function len requires a string or array.", e.start, "expression-type");
				}
				case "contains": {
					let t = a[0], n = a[1];
					if (typeof t == "string") return t.includes(W(n, e.start, "Function contains requires a string member"));
					if (Array.isArray(t)) {
						if (typeof n == "string") {
							for (let n of t) typeof n != "string" && B("Function contains requires a string member for a string array.", e.start, "expression-type");
							return t.includes(n);
						}
						if (typeof n == "number" && Number.isFinite(n)) {
							for (let n of t) typeof n != "number" && B("Function contains requires a numeric member for a numeric array.", e.start, "expression-type");
							return t.includes(n);
						}
						B("Function contains requires a string or numeric member.", e.start, "expression-type");
					}
					B("Function contains requires a string or array.", e.start, "expression-type");
				}
				case "sum": {
					let t = G(a[0], e.start, "Function sum requires a numeric array");
					return K(e.start, () => v(t));
				}
				case "average": {
					let t = G(a[0], e.start, "Function average requires a numeric array");
					return K(e.start, () => oe(t));
				}
				case "minOf": {
					let t = G(a[0], e.start, "Function minOf requires a numeric array");
					return K(e.start, () => se(t));
				}
				case "maxOf": {
					let t = G(a[0], e.start, "Function maxOf requires a numeric array");
					return K(e.start, () => ce(t));
				}
				case "formatNumber": {
					let t = a[0] === null ? null : H(a[0], e.start, "Function formatNumber requires a number or null"), n = a[1] === void 0 ? 2 : H(a[1], e.start, "Function formatNumber requires numeric fraction digits"), r = a[2] === void 0 ? "en-US" : W(a[2], e.start, "Function formatNumber requires a string locale"), i = a[3] === void 0 || U(a[3], e.start, "Function formatNumber requires a boolean grouping flag");
					return K(e.start, () => ne(t, n, r, i));
				}
				case "formatPercent": {
					let t = a[0] === null ? null : H(a[0], e.start, "Function formatPercent requires a number or null"), n = a[1] === void 0 ? 0 : H(a[1], e.start, "Function formatPercent requires numeric fraction digits"), r = a[2] === void 0 ? "en-US" : W(a[2], e.start, "Function formatPercent requires a string locale");
					return K(e.start, () => re(t, n, r));
				}
				case "formatScientific": {
					let t = a[0] === null ? null : H(a[0], e.start, "Function formatScientific requires a number or null"), n = a[1] === void 0 ? 2 : H(a[1], e.start, "Function formatScientific requires numeric fraction digits"), r = a[2] === void 0 ? "en-US" : W(a[2], e.start, "Function formatScientific requires a string locale");
					return K(e.start, () => ie(t, n, r));
				}
				case "formatCurrency": {
					let t = a[0] === null ? null : H(a[0], e.start, "Function formatCurrency requires a number or null"), n = a[1] === void 0 ? "USD" : W(a[1], e.start, "Function formatCurrency requires a string currency code"), r = a[2] === void 0 ? 2 : H(a[2], e.start, "Function formatCurrency requires numeric fraction digits"), i = a[3] === void 0 ? "en-US" : W(a[3], e.start, "Function formatCurrency requires a string locale");
					return K(e.start, () => ae(t, n, r, i));
				}
				case "trim": return K(e.start, () => ue(W(a[0], e.start, "Function trim requires a string")));
				case "lower": return K(e.start, () => de(W(a[0], e.start, "Function lower requires a string")));
				case "upper": return K(e.start, () => fe(W(a[0], e.start, "Function upper requires a string")));
				case "startsWith": return K(e.start, () => pe(W(a[0], e.start, "Function startsWith requires a string"), W(a[1], e.start, "Function startsWith requires a string search value")));
				case "endsWith": return K(e.start, () => me(W(a[0], e.start, "Function endsWith requires a string"), W(a[1], e.start, "Function endsWith requires a string search value")));
				case "replace": {
					let t = W(a[0], e.start, "Function replace requires a string"), n = W(a[1], e.start, "Function replace requires a string search value"), r = W(a[2], e.start, "Function replace requires a string replacement");
					return K(e.start, () => he(t, n, r));
				}
				case "slice": {
					let t = W(a[0], e.start, "Function slice requires a string"), n = H(a[1], e.start, "Function slice requires a numeric start index"), r = a[2] === void 0 ? void 0 : H(a[2], e.start, "Function slice requires a numeric end index");
					return K(e.start, () => ge(t, n, r));
				}
				case "dateCompare": {
					let t = W(a[0], e.start, "Function dateCompare requires a date string"), n = W(a[1], e.start, "Function dateCompare requires a date string");
					return K(e.start, () => ye(t, n));
				}
				case "dateDiff": {
					let t = W(a[0], e.start, "Function dateDiff requires a date string"), n = W(a[1], e.start, "Function dateDiff requires a date string"), r = a[2] === void 0 ? "days" : W(a[2], e.start, "Function dateDiff requires a string unit");
					return K(e.start, () => be(t, n, r));
				}
			}
			break;
		}
	}
	throw new S("expression-eval", "Unsupported expression.", 0);
}
var Y = /* @__PURE__ */ new Map(), X = /* @__PURE__ */ new WeakMap();
function Ve(e, t) {
	return X.get(e)?.get(t);
}
function Z(e) {
	if (typeof e != "string") throw new S("expression-syntax", "Expression must be a string.", 0);
	if (e.length > E) throw new S("expression-budget", `Expression exceeds the ${E}-character limit.`, 0);
	let t = Y.get(e);
	if (t) return t;
	let n = new Ne(e), r = n.parse(), i = [...n.dependencies], a = Object.freeze({
		source: e,
		dependencies: i,
		evaluate(e) {
			return Be(r, e);
		},
		inferType(e) {
			return z(r, e);
		}
	});
	if (Y.size >= Ee) {
		let e = Y.keys().next().value;
		e !== void 0 && Y.delete(e);
	}
	return X.set(a, n.dependencyOffsets), Y.set(e, a), a;
}
function Q(e) {
	if (e.length > j) throw new S("expression-budget", "Interpolation template exceeds the length limit.", 0);
	let t = [], n = 0;
	for (;;) {
		let r = e.indexOf("{{", n);
		if (r < 0) {
			n < e.length && t.push({
				kind: "text",
				value: e.slice(n)
			});
			break;
		}
		r > n && t.push({
			kind: "text",
			value: e.slice(n, r)
		});
		let i = r + 2, a = "", o = !1;
		for (; i < e.length;) {
			let t = e[i];
			if (a !== "") {
				if (t === "\\") {
					i += 2;
					continue;
				}
				t === a && (a = ""), i += 1;
			} else if (t === "\"" || t === "'") a = t, i += 1;
			else {
				if (t === "{" && e[i + 1] === "{") throw new S("expression-interpolation", "Interpolations cannot be nested.", i);
				if (t === "}" && e[i + 1] === "}") {
					o = !0;
					break;
				}
				i += 1;
			}
		}
		if (!o) throw new S("expression-interpolation", "Interpolation is missing }}.", r);
		let s = e.slice(r + 2, i);
		if (s.trim() === "") throw new S("expression-empty", "Interpolation expression is empty.", r + 2);
		t.push({
			kind: "expression",
			source: s,
			start: r + 2
		}), n = i + 2;
	}
	return t;
}
function $(e) {
	try {
		return Z(e.source);
	} catch (t) {
		throw t instanceof S ? new S(t.code, t.message, e.start + t.offset) : t;
	}
}
function He(e, t, n) {
	try {
		return e.evaluate(t);
	} catch (e) {
		throw e instanceof S ? new S(e.code, e.message, n + e.offset) : e;
	}
}
function Ue(e, t) {
	if (e === null) return "";
	if (typeof e == "string") return e;
	if (typeof e == "number") {
		if (!Number.isFinite(e)) throw new S("expression-value", "Cannot display a non-finite number.", t);
		return String(e);
	}
	if (typeof e == "boolean") return e ? "true" : "false";
	throw Array.isArray(e) ? new S("expression-type", "Cannot insert an array as text; convert it with a function such as len first.", t) : new S("expression-type", "Cannot display this value as text.", t);
}
function We(e, t) {
	let n = [], r = 0;
	for (let i of e) {
		let e;
		if (e = i.kind === "text" ? i.value : Ue(He($(i), t, i.start), i.start), r += e.length, r > A) throw new S("expression-budget", "Interpolation result exceeds the length limit.", 0);
		n.push(e);
	}
	return n.join("");
}
function Ge(e, t) {
	if (typeof e != "string") throw new S("expression-interpolation", "Interpolation template must be a string.", 0);
	if (e.length > j) throw new S("expression-budget", `Interpolation template exceeds the ${j}-character limit.`, 0);
	return e.includes("{{") ? We(Q(e), t) : e;
}
function Ke(e) {
	if (typeof e != "string") throw new S("expression-interpolation", "Interpolation template must be a string.", 0);
	let t = /* @__PURE__ */ new Set();
	for (let n of Q(e)) if (n.kind === "expression") for (let e of $(n).dependencies) t.add(e);
	return [...t];
}
export { Ge as a, Ke as c, Ve as i, Ce as n, P as o, Z as r, N as s, S as t };
