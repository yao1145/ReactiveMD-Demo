import { a as e, o as t } from "./visuals-D7mhVGdN.js";
import { o as n } from "./layout-CUsXVZmO.js";
import { t as r } from "./data-table-CKuFAjaW.js";
import { t as i } from "./plugin-packs-Capd7aq4.js";
import { t as a } from "./mount-preset-BsXjU5zi.js";
import { t as o } from "./visuals-DT0qsc1V.js";
// src/components/plugins/data.ts
var s = {
	column: n,
	"data-table": r,
	table: e,
	timeline: t
}, c = i("reactive-md/data", Object.keys(s)), l = a(c, s, [{
	id: "reactive-md/visuals.css",
	css: o
}]);
export { l as default };
