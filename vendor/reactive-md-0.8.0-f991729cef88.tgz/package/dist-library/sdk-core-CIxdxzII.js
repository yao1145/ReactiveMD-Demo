import { O as e } from "./preset-core-CKc5YXSM.js";
import { i as t } from "./props-DGlBk0e5.js";
import { s as n } from "./config-C7nMEidX.js";
import { C as r, E as i, T as a, x as o } from "./component-state-Cq2K5gkS.js";
import { t as s } from "./runtime-Dkq7ldyg.js";
import { i as c } from "./resources-85Qoj6wA.js";
import { Component as l, createElement as u } from "react";
// src/react/component-api.tsx
var d = Symbol("reactive-md.content-node");
function f(e) {
	return e[d];
}
function p(e, t) {
	return Object.defineProperty(e, d, {
		value: t,
		enumerable: !1,
		configurable: !1,
		writable: !1
	}), Object.freeze(e);
}
var m = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;
function h(e) {
	return e === null ? "" : typeof e == "string" ? e : typeof e == "number" ? Number.isFinite(e) ? String(e) : null : typeof e == "boolean" ? e ? "true" : "false" : null;
}
function g(e) {
	if (!Number.isFinite(e)) return "—";
	if (Object.is(e, -0)) return "0";
	let t = Math.abs(e);
	return t >= 0xe8d4a51000 || t > 0 && t < 1e-4 ? e.toExponential(3).replace(/(\.\d*?)0+e/, "$1e").replace(/\.e/, "e") : Number(e.toFixed(6)).toString();
}
function _(e) {
	return Array.isArray(e) ? Object.freeze(e.slice()) : e === void 0 ? null : e;
}
function v(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function y(e, n, r, i) {
	try {
		return {
			ok: !0,
			value: t(e, n, r, i)
		};
	} catch (e) {
		return {
			ok: !1,
			error: e
		};
	}
}
var b = /* @__PURE__ */ new WeakMap(), x = /* @__PURE__ */ new WeakMap();
function S(e) {
	x.delete(E(e));
}
var C = /* @__PURE__ */ new WeakMap(), w = 4096, T = 512;
function E(e) {
	let t = M.get(e);
	return t || (t = Object.freeze({}), M.set(e, t)), t;
}
function D(e, t, n) {
	let { environment: r, node: i } = e, a = r.positionOf?.(i.range.start) ?? {
		line: 1,
		column: 1
	}, o = n instanceof Error ? n.message : String(n);
	return {
		code: "local.component.prop",
		message: `Component <${i.name ?? i.id}> prop "${t}" is invalid: ${o}`,
		severity: "error",
		range: {
			start: i.range.start,
			end: i.range.end
		},
		line: a.line,
		column: a.column
	};
}
function O(e, t, n) {
	if (n.length === 0) return;
	if (typeof window > "u") {
		e.report(n);
		return;
	}
	let r = C.get(t);
	r || (r = {
		diagnostics: [],
		scheduled: !1,
		report: e.report
	}, C.set(t, r));
	let i = r;
	i.report = e.report;
	for (let e of n) {
		if (i.diagnostics.length >= T) break;
		i.diagnostics.push(e);
	}
	if (i.scheduled) return;
	i.scheduled = !0;
	let a = () => {
		i.scheduled = !1;
		let e = i.diagnostics.splice(0);
		e.length > 0 && i.report(e);
	};
	typeof queueMicrotask == "function" ? queueMicrotask(a) : setTimeout(a, 0);
}
function k(e, t, n, r) {
	if (!e) return {};
	let i = t ?? {}, a = {}, o = r?.environment.mode === "static" && typeof window > "u", s = r !== void 0, c = r ? E(n) : null, l = null;
	if (r && c && s) {
		let e = o ? x : b;
		l = e.get(c) ?? null, l ? l.size > w && l.clear() : (l = /* @__PURE__ */ new Map(), e.set(c, l));
	}
	let u = [];
	for (let t of Object.keys(e.props)) {
		let o = Object.hasOwn(i, t) && typeof i[t] == "string" ? i[t] : void 0, s = y(e, t, o, n);
		if (s.ok) a[t] = s.value, r && l && l.delete(`${r.node.id}\u0000${t}`);
		else if (a[t] = null, r) {
			if (l) {
				let e = `${r.node.id}\u0000${t}`, n = `${o ?? ""}\u0000${s.error instanceof Error ? s.error.message : String(s.error)}`;
				if (l.get(e) === n) continue;
				l.set(e, n);
			}
			u.push(D(r, t, s.error));
		}
	}
	return r && c && O(r.environment, c, u), a;
}
function A(e) {
	return e?.bindings ?? {};
}
function j(e, t, n, r) {
	let i = r.get(e);
	if (i) return i;
	let a = e.type === "component" || e.type === "hostComponent", o = a ? t.definitionFor(e.name ?? "") : void 0, s = Object.freeze(a ? k(o, e.attrs, t.runtime, {
		environment: t,
		node: e
	}) : {}), c = (e.children ?? []).map((e) => j(e, t, n, r)), l = null;
	if (a) try {
		l = _(t.runtime.get(e));
	} catch {
		l = null;
	}
	else if (e.type === "interpolation") try {
		l = _(t.runtime.evaluate(e.value ?? ""));
	} catch {
		l = null;
	}
	let u = p({
		id: e.id,
		kind: a ? "component" : e.type,
		name: a ? e.name ?? "" : "",
		...a && o ? { form: o.form } : {},
		props: s,
		attrs: Object.freeze({ ...e.attrs ?? {} }),
		value: l,
		text: typeof e.value == "string" ? e.value : "",
		...e.lang === void 0 ? e.type === "math" || e.type === "inlineMath" ? { format: e.type } : {} : { format: e.lang },
		visible: n,
		children: Object.freeze(c),
		range: Object.freeze({
			start: e.range.start,
			end: e.range.end
		})
	}, e);
	return r.set(e, u), u;
}
var M = /* @__PURE__ */ new WeakMap();
function ee(e, t, n) {
	let r = t === "static", i = M.get(e);
	i || (i = Object.freeze({}), M.set(e, i));
	let a = f, o = (e) => (e.length > 0 && n(e), e), s = (e, t) => {
		let n = {
			start: e.range.start,
			end: e.range.end
		};
		return [{
			code: "local.extension.write",
			message: `Component <${e.name || e.id}> write failed: ${t instanceof Error ? t.message : String(t)}`,
			severity: "error",
			range: n,
			line: 1,
			column: 1
		}];
	};
	return Object.freeze({
		identity: i,
		get(t, n) {
			return _(e.get(a(t), n === "value" ? void 0 : n));
		},
		set(t, n, i) {
			if (r) return s(t, /* @__PURE__ */ Error("Runtime is read-only in static mode."));
			try {
				return o(e.set(a(t), v(n), i === "value" ? void 0 : i));
			} catch (e) {
				return s(t, e);
			}
		},
		setMany(t, n) {
			if (r) return s(t, /* @__PURE__ */ Error("Runtime is read-only in static mode."));
			try {
				let r = {};
				for (let [e, t] of Object.entries(n)) r[e] = v(t);
				return o(e.setMany(a(t), r));
			} catch (e) {
				return s(t, e);
			}
		},
		reset(t) {
			if (!r) try {
				e.reset(a(t));
			} catch {}
		},
		resetToken(t) {
			try {
				return e.resetToken(a(t));
			} catch {
				return 0;
			}
		},
		evaluate(t) {
			return _(e.evaluate(t));
		},
		snapshot() {
			try {
				let t = e.snapshot(), n = {};
				for (let [e, r] of Object.entries(t.state)) n[e] = _(r);
				return {
					revision: t.revision,
					state: Object.freeze(n)
				};
			} catch {
				return {
					revision: 0,
					state: {}
				};
			}
		},
		validate() {
			try {
				return e.validate();
			} catch {
				return [];
			}
		},
		text(t) {
			try {
				return e.text(t);
			} catch {
				return "";
			}
		}
	});
}
function N(e, t, n, r) {
	return Object.freeze({
		get: () => {
			try {
				return e.get(t, n);
			} catch {
				return null;
			}
		},
		set: (i) => {
			if (r) return {
				ok: !1,
				diagnostics: []
			};
			let a = e.set(t, i, n);
			return {
				ok: a.length === 0,
				diagnostics: a
			};
		}
	});
}
function P(e, t) {
	let n = [], r = e.children, i = t.definitionFor(e.name), a = i?.rules?.find((e) => e.kind === "options-body"), o = a?.kind === "options-body" ? a.child : i?.structure?.child ?? "option", s = a?.kind === "options-body" ? a.valueAttribute : i?.structure?.valueAttribute ?? "value", c = 0;
	for (let i of r) {
		if (i.kind !== "component" || i.name !== o) continue;
		let r = f(i), a = i.attrs[s] ?? `option-${c + 1}`;
		c += 1;
		let l = t.renderToText(r.children) || i.attrs[s] || "";
		n.push(Object.freeze({
			value: a,
			content: i,
			label: l,
			render: () => t.renderInline(r.children, e.visible)
		}));
	}
	return n;
}
function F(e, t) {
	let n = e.children ?? [], r = n.filter((e) => !(e.type === "text" && !(e.value ?? "").trim())), i, a = "empty", o = "", s = null, c = null;
	if (r.length === 1 && r[0].type === "interpolation") try {
		i = t.runtime.evaluate(r[0].value ?? "");
		let e = h(i);
		i === null ? (a = "null", o = "") : typeof i == "string" ? (a = "string", o = i) : typeof i == "number" ? Number.isFinite(i) ? (a = "number", o = g(i), s = i) : (a = "error", o = t.locale === "zh" ? "无法计算" : "Cannot compute", c = t.locale === "zh" ? "结果不是有限数字" : "Result is not a finite number") : typeof i == "boolean" ? (a = "boolean", o = i ? "true" : "false") : (a = "array", o = e ?? "", c = t.locale === "zh" ? "数组需要先用 len 等函数转换" : "Arrays must first be converted with a function such as len");
	} catch (e) {
		a = "error", o = t.locale === "zh" ? "无法计算" : "Cannot compute", c = e instanceof Error ? e.message : String(e);
	}
	else {
		let e = "", l = null, u = (n) => {
			for (let r of n ?? []) if (r.type === "text" || r.type === "inlineCode" || r.type === "code") e += r.value ?? "";
			else if (r.type === "interpolation") try {
				let n = h(t.runtime.evaluate(r.value ?? ""));
				n === null ? l ??= t.locale === "zh" ? "数组需要先用 len 等函数转换" : "Arrays must first be converted with a function such as len" : e += n;
			} catch (n) {
				l ??= n instanceof Error ? n.message : String(n), e += t.locale === "zh" ? "无法计算" : "Cannot compute";
			}
			else r.type === "inlineMath" || r.type === "math" ? e += r.value ?? "" : r.type === "image" ? e += r.alt ?? "" : r.children && r.children.length > 0 ? u(r.children) : r.value && (e += r.value);
		};
		u(n);
		let d = r.length > 0 && r.every((e) => e.type === "text"), f = e.trim();
		if (d && m.test(f)) {
			let t = Number(f);
			Number.isFinite(t) && (a = "number", o = e, s = t, i = t);
		}
		a === "empty" && (l ? (a = "error", o = t.locale === "zh" ? "无法计算" : "Cannot compute", c = l) : (a = f === "" ? "empty" : "string", o = e, i = e));
	}
	return Object.freeze({
		text: o,
		value: i,
		kind: a,
		numeric: s,
		error: c,
		render: () => t.renderInline(n, !0)
	});
}
function te(e, t) {
	let n = e.children.find((e) => e.kind === "table");
	if (!n) return null;
	let r = (f(n).children ?? []).filter((e) => e.type === "tableRow");
	if (r.length === 0) return null;
	let i = (r[0].children ?? []).map((e) => F(e, t));
	return Object.freeze({
		header: Object.freeze(i),
		headerText: Object.freeze(i.map((e) => e.error ? t.locale === "zh" ? "无法计算" : "Cannot compute" : e.text)),
		rows: Object.freeze(r.slice(1).map((e, n) => Object.freeze({
			index: n,
			cells: Object.freeze((e.children ?? []).map((e) => F(e, t)))
		})))
	});
}
function ne(e, t) {
	let n = e["state-key"];
	return a(typeof n == "string" ? n : t["state-key"]);
}
function re(e) {
	try {
		return e.document.source;
	} catch {
		return "";
	}
}
var I = /* @__PURE__ */ new WeakMap();
function L(e) {
	if (e.services !== void 0) return e.services;
	let t = I.get(e);
	return t === void 0 && (t = s({ sourceDigest: r(re(e)) }), I.set(e, t)), t;
}
function R(e, t) {
	let n = t.definitionFor(e.name ?? ""), r = /* @__PURE__ */ new Map(), a = j(e, t, t.visible, r), s = ee(t.runtime, t.mode, t.report), c = t.services ?? L(t.runtime), l = n?.id ?? e.name ?? e.type, u = ne(a.props, a.attrs), d = null, p = () => (d === null && (d = c.state.handle({
		nodeId: e.id,
		component: l,
		componentVersion: n?.version ?? "0.0.0",
		stateKey: u,
		stateVersion: 0
	})), d), m = typeof a.props.seed == "number" && Number.isFinite(a.props.seed) ? a.props.seed : void 0, h = i({
		explicitSeed: m,
		documentSeed: c.randomSeed,
		componentId: l,
		nodeId: e.id,
		stateKey: u
	}), _ = Object.freeze({
		random: Object.freeze({
			seed: h,
			derive: (e) => o(h, e)
		}),
		clock: c.clock,
		scheduler: c.scheduler,
		get state() {
			return p();
		}
	}), v = t.mode === "static", y = A(n), b = {};
	for (let e of Object.keys(y)) b[e] = N(s, a, e, v);
	let x = b.value ?? Object.freeze({
		get: () => null,
		set: () => ({
			ok: !1,
			diagnostics: []
		})
	}), S = Object.freeze({
		render: () => t.renderChildren(e.children, t.visible),
		inline: () => t.renderInline(e.children, t.visible),
		text: () => t.renderToText(e.children),
		items: () => a.children,
		renderItems: (e, n) => t.renderChildren(e.map((e) => f(e)), n ?? t.visible),
		renderInlineItems: (e, n) => t.renderInline(e.map((e) => f(e)), n ?? t.visible),
		textOf: (e) => t.renderToText(e.map((e) => f(e))),
		options: () => P(a, t),
		table: () => te(a, t),
		math: () => a.children.filter((e) => e.kind === "math" || e.kind === "inlineMath")
	}), C = Object.freeze({
		value: x,
		slots: Object.freeze(b),
		isReadOnly: v,
		get(e = "value") {
			let t = b[e];
			return t ? t.get() : null;
		},
		set(e, t) {
			let n = b[e];
			return n ? n.set(t) : {
				ok: !1,
				diagnostics: [{
					code: "local.extension.binding",
					message: `Component <${a.name || a.id}> has no binding slot "${e}".`,
					severity: "error",
					range: a.range,
					line: 1,
					column: 1
				}]
			};
		},
		setMany(e) {
			if (v) return {
				ok: !1,
				diagnostics: []
			};
			let t = s.setMany(a, e);
			return {
				ok: t.length === 0,
				diagnostics: t
			};
		}
	}), w = Object.freeze({
		fieldFor: (e) => t.validationFieldFor(f(e)),
		hintFor: (e) => t.validationHintFor(f(e))
	}), T = Object.freeze({
		targetId: (e) => t.targetId(e),
		anchorId: () => t.anchorId(e),
		allowed: (e) => t.jumpAllowed(e),
		jump: (e) => {
			let n = t.targetId(e);
			return n === void 0 ? "missing" : t.jumpTo(n);
		}
	}), E = Object.freeze({
		resolve(e, n) {
			if (!e) return null;
			let r = e.trim();
			if (!r) return null;
			let i = r.replace(/[\u0000- ]+/g, ""), a = /^([a-z][a-z0-9+.-]*):/i.exec(i);
			if (a) {
				let e = a[1].toLowerCase();
				if (!(n === "image" ? e === "http" || e === "https" : e === "http" || e === "https" || e === "mailto" || e === "tel")) return null;
			}
			if (!t.urlPolicy) return n === "image" ? null : r;
			try {
				return t.urlPolicy(r, n) ? r : null;
			} catch {
				return null;
			}
		},
		image(e) {
			let n = E.resolve(e, "image");
			if (!n) return null;
			if (!t.imageResolver) return n;
			try {
				let e = t.imageResolver(n);
				return typeof e == "string" && e.trim() !== "" ? e : null;
			} catch {
				return null;
			}
		}
	}), D = Object.freeze({
		locale: t.locale,
		t: (e, n) => t.locale === "zh" ? n : e,
		formatNumber: g
	});
	return Object.freeze({
		props: a.props,
		content: a,
		services: _,
		bindings: C,
		children: S,
		runtime: s,
		instance: Object.freeze({
			id: e.id,
			componentId: n?.id ?? e.name ?? "",
			range: Object.freeze({
				start: e.range.start,
				end: e.range.end
			})
		}),
		mode: t.mode,
		visible: t.visible,
		disabled: t.disabled,
		disabledInvalid: t.disabledInvalid,
		resetToken: t.resetToken,
		validation: w,
		source: Object.freeze({ attributes: (n) => t.sourceAttributes(n ? f(n) : e, e.name) }),
		navigation: T,
		url: E,
		locale: D,
		report: t.report
	});
}
var z = [
	"interactive",
	"static",
	"ssr",
	"offline"
];
function B(e) {
	let t = e.capabilities;
	if (t === void 0) return;
	if (typeof t != "object" || !t || Array.isArray(t)) throw TypeError("Component capabilities must be an object.");
	let n = {};
	for (let e of z) {
		let r = t[e];
		if (r !== void 0) {
			if (typeof r != "boolean") throw TypeError(`Component capability "${e}" must be a boolean.`);
			n[e] = r;
		}
	}
	return n;
}
function V(e, t, n) {
	if (t) {
		if (typeof n.render != "function") throw TypeError("defineReactComponent requires a render function.");
		if (n.renderStatic !== void 0 && typeof n.renderStatic != "function") throw TypeError("defineReactComponent renderStatic must be a function.");
		if (t.static === !1 && t.ssr === !0) throw TypeError(`Component "${e.id ?? ""}" declares SSR without static rendering.`);
		if (t.static === !1 && t.offline === !0) throw TypeError(`Component "${e.id ?? ""}" declares offline output without a static implementation.`);
		if (t.interactive === !1 && t.offline === !0 && t.static !== !0) throw TypeError(`Component "${e.id ?? ""}" declares offline output without any renderable implementation.`);
	}
}
function H(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("defineReactComponent requires a component definition object.");
	return e;
}
function U(t, n) {
	let r = H(t);
	if (!n || typeof n != "object") throw TypeError("defineReactComponent requires an implementation object.");
	V(r, B(r), n);
	let i;
	try {
		i = e(r);
	} catch (e) {
		throw TypeError(`Cannot bind a React implementation to component "${r.id}": ${e instanceof Error ? e.message : String(e)}`);
	}
	return Object.freeze({
		definition: r,
		digest: i,
		render: n.render,
		...n.renderStatic === void 0 ? {} : { renderStatic: n.renderStatic }
	});
}
// src/react/sdk-core.tsx
function W(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("defineReactComponent requires a component definition object.");
	return e;
}
var G = /* @__PURE__ */ new WeakMap();
function K(e) {
	let t = G.get(e);
	if (t) return t;
	let n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
	for (let t of e.components) n.set(t.definition.name, t), r.set(t.definition.id, t);
	let i = Object.freeze({
		byName: n,
		byId: r
	});
	return G.set(e, i), i;
}
function q(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("createReactConfig components must be LocalReactComponent values.");
	let t = e;
	if (!t.definition || typeof t.definition != "object") throw TypeError("A React component is missing its manifest definition.");
	if (typeof t.render != "function") throw TypeError("A React component is missing its render implementation.");
	if (t.renderStatic !== void 0 && typeof t.renderStatic != "function") throw TypeError("A React component renderStatic must be a function.");
	return t;
}
function J(t, r, i) {
	let a = n(t), o = r?.components;
	if (!Array.isArray(o)) throw TypeError("createReactConfig requires a components array.");
	let s = r?.presets ?? [];
	if (!Array.isArray(s)) throw TypeError("createReactConfig presets must be an array.");
	let c = [], l = [], u = /* @__PURE__ */ new Set(), d = (t, n) => {
		let r = q(t), i = W(r.definition), a = e(i);
		if (r.digest !== a) throw TypeError(`React component "${i.id}" from ${n} has a stale digest; create it with defineReactComponent.`);
		return c.push(r), r;
	};
	for (let e of i) {
		let t = d(e, "the default React preset");
		u.add(t);
	}
	for (let e of s) {
		if (!e || typeof e != "object" || !Array.isArray(e.components)) throw TypeError("createReactConfig preset must expose a components array.");
		for (let t of e.components) l.push(d(t, `preset "${e.id ?? ""}"`));
	}
	for (let e of o) l.push(d(e, "components"));
	let f = [], p = [];
	for (let t of a.registry) {
		let n = e(t), r = c.filter((e) => e.definition.id === t.id && e.definition.name === t.name && e.definition.version === t.version && e.digest === n);
		if (r.length === 0) {
			if (c.some((e) => e.definition.id === t.id)) throw TypeError(`React component "${t.id}@${t.version}" does not match the installed manifest contract.`);
			p.push(`${t.id}@${t.version}`);
		} else {
			if (r.length > 1) throw TypeError(`Component id "${t.id}" has more than one matching React implementation.`);
			f.push(r[0]);
		}
	}
	if (p.length > 0) {
		let e = new Set(a.registry.map((e) => e.id)), t = [...new Set(l.filter((t) => !e.has(t.definition.id)).map((e) => `${e.definition.id}@${e.definition.version}`))];
		throw TypeError(`createReactConfig is missing implementations for: ${p.join(", ")}.` + (t.length === 0 ? "" : ` Supplied implementation(s) ${t.join(", ")} are not declared by this local config.`));
	}
	let m = new Map(f.map((e) => [e.definition.id, e])), h = new Map(f.map((e) => [e.definition.name, e])), g = f.filter((e) => !u.has(e)), _ = Object.freeze(a.themes.slice()), v = Object.freeze({
		byName: new Map(h),
		byId: new Map(m)
	}), y = Object.freeze({
		config: a,
		components: Object.freeze(g),
		implementations: Object.freeze(f),
		themes: _,
		hostRenderer: le(v)
	});
	return G.set(y, v), y;
}
var Y = class extends Error {
	componentName;
	constructor(e) {
		super(`No React implementation is registered for <${e}>.`), this.name = "LocalReactExtensionMissingError", this.componentName = e;
	}
};
function ie(e) {
	try {
		return e.snapshot().revision;
	} catch {
		return 0;
	}
}
function ae(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.max(0, Math.min(t, e.length)), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: n - i + 1
	};
}
function X(e, t, n, r, i) {
	let { line: a, column: o } = ae(r, n.start);
	return {
		code: e,
		message: `Component <${t}> failed: ${i instanceof Error ? i.message : String(i)}`,
		severity: "error",
		range: {
			start: n.start,
			end: n.end
		},
		line: a,
		column: o
	};
}
var oe = class extends l {
	state = { failed: !1 };
	static getDerivedStateFromError() {
		return { failed: !0 };
	}
	componentDidCatch(e) {
		try {
			this.props.report([X("local.extension.render", this.props.name, this.props.range, this.props.source, e)]);
		} catch {}
	}
	componentDidUpdate(e) {
		this.state.failed && e.revision !== this.props.revision && this.setState({ failed: !1 });
	}
	render() {
		return this.state.failed ? u("span", {
			className: "local-host-component local-host-unavailable local-sdk-unavailable",
			"data-local-host-component": this.props.name,
			"data-local-host-reason": "error",
			"data-rmd-source-start": String(this.props.range.start),
			"data-rmd-source-end": String(this.props.range.end),
			"data-rmd-source-node": this.props.nodeId,
			"data-rmd-source-type": "hostComponent",
			"data-rmd-source-component": this.props.name,
			role: "note"
		}, `Component <${this.props.name}> is unavailable here.`) : this.props.children;
	}
};
function se({ implementation: e, node: t, environment: n }) {
	let r = e.definition.id.startsWith("reactive-md/"), i = n.mode === "static" ? "static" : "interactive";
	if (!r && !e.definition.capabilities[i]) throw Error(`Component ${e.definition.id} does not support ${i} rendering.`);
	let a = R(t, {
		runtime: n.runtime,
		services: n.services ?? n.runtime.services,
		mode: n.mode,
		locale: n.locale,
		visible: n.visible,
		disabled: n.disabled,
		disabledInvalid: n.disabledInvalid,
		resetToken: n.resetToken,
		definitionFor: n.definitionFor,
		validationFieldFor: n.validationField,
		validationHintFor: n.validationHint,
		sourceAttributes: n.sourceAttributes,
		renderChildren: (e, t) => n.renderChildren(e, t),
		renderInline: (e, t) => n.renderInline(e, t),
		renderToText: (e) => n.renderToText(e),
		report: n.report,
		targetId: n.targetId,
		anchorId: n.anchorId,
		jumpAllowed: n.jumpAllowed,
		jumpTo: n.jumpTo,
		urlPolicy: n.urlPolicy,
		imageResolver: n.imageResolver
	}), o = n.mode === "static" && e.renderStatic ? e.renderStatic : e.render;
	return u(o, a);
}
function Z(e, t, n) {
	let r = t.name ?? "", i = e.byName.get(r);
	if (!i) throw new Y(r);
	let a;
	try {
		a = n.runtime.document.source;
	} catch {
		a = void 0;
	}
	let o = u(se, {
		implementation: i,
		node: t,
		environment: n
	});
	return i.definition.id.startsWith("reactive-md/") ? o : u(oe, {
		name: r,
		nodeId: t.id,
		revision: ie(n.runtime),
		range: t.range,
		source: a,
		report: n.report
	}, o);
}
function ce(e) {
	return (t, n) => Z(K(e), t, n);
}
function Q(e) {
	let t = "";
	for (let n of e ?? []) n.type === "text" || n.type === "inlineCode" || n.type === "code" ? t += n.value ?? "" : n.type === "math" || n.type === "inlineMath" || n.type === "image" ? t += n.value ?? n.alt ?? "" : t += Q(n.children);
	return t;
}
function le(e) {
	return (t, n, r) => Z(e, t, {
		runtime: r.runtime,
		mode: r.mode,
		visible: r.visible,
		disabled: r.disabled,
		disabledInvalid: !1,
		resetToken: r.resetToken,
		locale: "en",
		renderChildren: (e, t) => r.render(e, t),
		renderInline: (e, t) => r.render(e, t),
		renderToText: (e) => Q(e),
		report: (e) => r.report(e),
		definitionFor: (t) => e.byName.get(t)?.definition,
		validationField: () => ({ invalid: !1 }),
		validationHint: () => null,
		sourceAttributes: () => ({}),
		targetId: () => void 0,
		anchorId: () => void 0,
		jumpAllowed: () => !1,
		jumpTo: () => "missing"
	});
}
function ue(e, t) {
	let n = c(t, e.config);
	if (n.length || !t || typeof t != "object") return n;
	let r = t.components;
	if (!Array.isArray(r)) return n;
	let i = K(e);
	for (let e of r) i.byId.has(e.id) || n.push({
		code: "local.extension.renderer-missing",
		severity: "error",
		message: new Y(e.name).message,
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	});
	return n;
}
function $(e, t, n) {
	try {
		e.report([X("local.extension.event", e.instance.componentId, e.instance.range, n, t)]);
	} catch {}
}
function de(e, t, n) {
	return (...r) => {
		try {
			t(...r);
		} catch (t) {
			$(e, t, n);
		}
	};
}
export { de as a, U as c, $ as i, g as l, J as n, ue as o, ce as r, S as s, Y as t };
