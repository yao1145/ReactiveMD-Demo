import { A as e, F as t, I as n, J as r, M as i, N as a, n as o, r as s } from "./preset-core-CKc5YXSM.js";
import { O as c, _ as l, a as u, c as d, d as f, g as p, h as ee, i as m, j as h, m as te, n as g, o as ne, p as re, r as _, s as ie, t as ae, v as oe, y as se } from "./config-validation-BLmgvFIS.js";
import v from "./reactive-md-default-preset.js";
// src/local/theme/theme.ts
var y = "reactive-md-theme-1", b = Object.freeze({
	name: "default",
	protocol: y,
	colorSchemes: Object.freeze(["light", "dark"])
});
function ce(e, t) {
	let n = typeof t == "string" ? t.length : Infinity;
	if (!e || typeof e.start != "number" || typeof e.end != "number" || !Number.isFinite(e.start) || !Number.isFinite(e.end)) return {
		start: 0,
		end: 0
	};
	let r = Math.max(0, Math.min(n, Math.floor(e.start)));
	return {
		start: r,
		end: Math.max(r, Math.min(n, Math.floor(e.end)))
	};
}
function le(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.min(t, e.length), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: t - i + 1
	};
}
function ue(e, t, n, r) {
	let i = ce(n, r), { line: a, column: o } = le(r, i.start);
	return {
		code: e,
		message: c(t),
		severity: "warning",
		range: i,
		line: a,
		column: o,
		messageKey: t.key,
		...t.params ? { params: t.params } : {}
	};
}
function de(e, t, n, r) {
	let i = (e, t) => ({
		name: b.name,
		diagnostics: [ue(e, t, n, r)]
	}), a = e;
	if (a == null || a === "") return {
		name: b.name,
		diagnostics: []
	};
	if (!se(a)) return i("local.theme.name", h("local.theme.name", {
		name: String(a),
		limit: 64
	}));
	let o = a;
	if (o === b.name) return {
		name: b.name,
		diagnostics: []
	};
	if (!Array.isArray(t)) return i("local.theme.missing", h("local.theme.missing", { name: o }));
	let s = 0, c = null;
	try {
		for (let e of t) typeof e == "object" && e && !Array.isArray(e) && e.name === o && (s += 1, c = e);
	} catch {
		return i("local.theme.manifest", h("local.theme.manifest.unreadable"));
	}
	if (s === 0) return i("local.theme.missing", h("local.theme.missing", { name: o }));
	if (s > 1) return i("local.theme.duplicate", h("local.theme.duplicate", { name: o }));
	try {
		let e = c;
		if (!e || typeof e != "object") return i("local.theme.manifest", h("local.theme.manifest.definition", { name: o }));
		if (e.protocol !== "reactive-md-theme-1") return i("local.theme.protocol", h("local.theme.protocol", {
			name: o,
			protocol: y
		}));
		let t = e.colorSchemes;
		if (!Array.isArray(t) || !t.includes("light") || !t.includes("dark")) return i("local.theme.modes", h("local.theme.modes", { name: o }));
	} catch {
		return i("local.theme.manifest", h("local.theme.manifest.selected", { name: o }));
	}
	return {
		name: o,
		diagnostics: []
	};
}
// src/themes/contract.ts
var fe = "reactive-md-styles-1", pe = Object.freeze([
	"rmd.reset",
	"rmd.defaults",
	"rmd.components",
	"rmd.themes",
	"rmd.overrides"
]), me = "rmd.themes", x = `@layer ${pe.join(", ")};`, he = 128, ge = 32, _e = 128, S = 262144, C = 524288, ve = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/, ye = /^[a-z][a-z0-9._/-]*$/, be = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/, xe = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/, Se = /^(?::root|html|body)(?![A-Za-z0-9_-])/i, Ce = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]), we = 256, Te = /* @__PURE__ */ new Set([
	"serif",
	"sans-serif",
	"monospace",
	"cursive",
	"fantasy",
	"system-ui",
	"ui-serif",
	"ui-sans-serif",
	"ui-monospace",
	"ui-rounded",
	"math",
	"emoji",
	"fangsong",
	"-apple-system",
	"blinkmacsystemfont"
]), w = /* @__PURE__ */ new Set([
	"inherit",
	"initial",
	"unset",
	"revert",
	"revert-layer"
]), Ee = /* @__PURE__ */ new Set([
	"caption",
	"icon",
	"menu",
	"message-box",
	"small-caption",
	"status-bar"
]), De = /* @__PURE__ */ new Set([
	"xx-small",
	"x-small",
	"small",
	"medium",
	"large",
	"x-large",
	"xx-large",
	"xxx-large",
	"smaller",
	"larger"
]), Oe = /^rmd-theme-([a-z][a-z0-9-]*)-font-([0-9a-f]+)$/;
function T(e, t) {
	return /* @__PURE__ */ Error(`Invalid local theme ${e}: ${t}`);
}
function ke(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function E(e, t) {
	if (!ke(e)) throw T(t, "must be an object.");
	return e;
}
function D(e, t) {
	if (typeof e != "string" || e.length === 0) throw T(t, "must be a non-empty string.");
	if (e.length > he) throw T(t, `must not exceed ${he} characters.`);
	if (!ve.test(e)) throw T(t, `"${e}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return e;
}
function O(e, t) {
	if (!se(e)) throw T(t, "must be a lowercase kebab-case name that starts with a letter.");
	if (e === "default") throw T(t, "must not replace the reserved built-in \"default\" theme.");
	return e;
}
function k(e, t) {
	if (typeof e != "string" || !be.test(e)) throw T(t, "must be a semantic version such as \"1.0.0\".");
	return e;
}
function Ae(e, t) {
	if (e === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(e)) throw T(t, "must be an array of \"light\" and \"dark\".");
	let n = [];
	for (let r of e) {
		if (r !== "light" && r !== "dark") throw T(t, "may only contain \"light\" and \"dark\".");
		if (n.includes(r)) throw T(t, `must not repeat "${r}".`);
		n.push(r);
	}
	if (!n.includes("light") || !n.includes("dark")) throw T(t, "must declare both \"light\" and \"dark\".");
	return Object.freeze(n);
}
function A(e, t) {
	let n = e[t], r = t + 1;
	for (; r < e.length;) if (e[r] === "\\") r += 2;
	else {
		if (e[r] === n) return r + 1;
		r += 1;
	}
	return e.length;
}
function j(e, t, n, r) {
	let i = 0;
	for (let a = t; a < e.length; a += 1) {
		let t = e[a];
		if (t === "\"" || t === "'") a = A(e, a) - 1;
		else if (t === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === n) i += 1;
		else if (t === r && (--i, i === 0)) return a + 1;
	}
	return e.length;
}
function je(e, t, n) {
	let r = t + 3;
	for (; r < e.length && /\s/.test(e[r]);) r += 1;
	if (e[r] !== "(") throw T(n, "has a malformed url() value.");
	for (r += 1; r < e.length && /\s/.test(e[r]);) r += 1;
	let i = e[r];
	if (i === "\"" || i === "'") {
		let t = e.indexOf(i, r + 1);
		if (t < 0) throw T(n, "has an unterminated url() string.");
		let a = e.slice(r + 1, t);
		for (r = t + 1; r < e.length && /\s/.test(e[r]);) r += 1;
		if (e[r] !== ")") throw T(n, "has a malformed url() value.");
		return {
			value: a.trim(),
			end: r + 1
		};
	}
	let a = e.indexOf(")", r);
	if (a < 0) throw T(n, "has an unterminated url() value.");
	return {
		value: e.slice(r, a).trim(),
		end: a + 1
	};
}
function Me(e, t, n, r) {
	let i = t;
	for (; i < e.length && e[i] !== "(";) i += 1;
	if (i >= e.length) throw T(r, `has a malformed ${n}() value.`);
	let a = j(e, i, "(", ")");
	if (a <= i + 1 || e[a - 1] !== ")") throw T(r, `has an unterminated ${n}() value.`);
	return {
		body: e.slice(i + 1, a - 1),
		end: a
	};
}
function Ne(e, t) {
	let n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (r === "\"" || r === "'") {
			let i = A(e, n);
			if (i > e.length || e[i - 1] !== r) throw T(t, "has an unterminated image-set() string.");
			let a = e.slice(n + 1, i - 1).trim();
			if (!/^data:/i.test(a)) throw T(t, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			n = i;
		} else if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else n += 1;
	}
}
function Pe(e, t, n = !1) {
	if (e.toLowerCase().includes("</style")) throw T(t, "must not contain a closing style tag.");
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = A(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else {
			if (i === "\\") throw T(t, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
			if (i === "@" && /^@import\b/i.test(e.slice(r, r + 8))) throw T(t, "must not use @import; inline every resource.");
			if ((i === "i" || i === "I" || i === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(e.slice(r, r + 24))) {
				let { body: n } = Me(e, r, "image-set", t);
				Ne(n, t), r += 1;
			} else if ((i === "u" || i === "U") && /^url\s*\(/i.test(e.slice(r, r + 12))) {
				let i = je(e, r, t);
				if (!/^data:/i.test(i.value) && !(n && i.value.startsWith("#"))) throw T(t, "may only reference data: URLs; network and file URLs are not allowed.");
				r = i.end;
			} else {
				if ((i === "e" || i === "E") && /^expression\s*\(/i.test(e.slice(r, r + 16))) throw T(t, "must not use CSS expression().");
				r += 1;
			}
		}
	}
}
function Fe(e) {
	if (typeof e != "string" || e.length > 4194304) return !1;
	try {
		return Pe(e, "css", !0), !0;
	} catch {
		return !1;
	}
}
function Ie(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		if (o === "\"" || o === "'") a = A(e, a) - 1;
		else if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else o === "\\" ? a += 1 : o === "(" ? r += 1 : o === ")" ? r = Math.max(0, r - 1) : o === "[" ? i += 1 : o === "]" ? i = Math.max(0, i - 1) : o === "," && r === 0 && i === 0 && (t.push(e.slice(n, a)), n = a + 1);
	}
	return t.push(e.slice(n)), t;
}
function Le(e, t) {
	let n = e.trim(), r = `[data-rmd-theme="${t}"]`, i = xe.exec(n);
	return i ? `${r}${n.slice(i[0].length)}` : `${r} ${n}`;
}
function M(e, t) {
	let n = t;
	for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
	else if (e[n] === "/" && e[n + 1] === "*") {
		let t = e.indexOf("*/", n + 2);
		n = t < 0 ? e.length : t + 2;
	} else break;
	return n;
}
function Re(e, t) {
	let n = e.toLowerCase(), r = /:has\s*\(/g;
	for (let i = r.exec(n); i; i = r.exec(n)) {
		if (r.lastIndex = i.index + 1, i.index >= t) continue;
		let n = i.index + i[0].length - 1, a = j(e, n, "(", ")"), o = e.slice(n + 1, Math.max(n + 1, a - 1));
		for (let t of Ie(o)) if (/^\s*[+~]/.test(t)) throw T("theme.css", `selector "${e.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
function ze(e) {
	let t = e.trim();
	if (t === "") return;
	if (t[0] === "+" || t[0] === "~") throw T("theme.css", `selector "${t}" begins with a sibling combinator and cannot be scoped.`);
	let n = xe.exec(t);
	if (n) {
		let e = n[0].length;
		for (; e < t.length;) {
			let n = t[e];
			if (/\s/.test(n) || n === "+" || n === "~" || n === ">" || n === ",") break;
			n === "[" ? e = j(t, e, "[", "]") : n === "(" ? e = j(t, e, "(", ")") : e += 1;
		}
		let r = M(t, e);
		if (t[r] === "+" || t[r] === "~") throw T("theme.css", `selector "${t}" uses a sibling combinator that can escape the theme root.`);
		Re(t, e);
	}
}
function Be(e, t) {
	let n = Ie(e).map((e) => e.trim()).filter(Boolean);
	if (n.length === 0) return e.trim();
	for (let e of n) {
		if (Se.test(e)) throw T("theme.css", `selector "${e}" targets the host document; scope it under the theme root instead.`);
		ze(e);
	}
	return n.map((e) => Le(e, t)).join(", ");
}
function N(e, t) {
	let n = 1;
	for (let r = t; r < e.length; r += 1) {
		let t = e[r];
		if (t === "\"" || t === "'") r = A(e, r) - 1;
		else if (t === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return r;
	}
	return e.length;
}
function P(e) {
	return e.trim().replace(/\s+/g, " ").toLowerCase();
}
function Ve(e) {
	let t = [];
	for (let n of e) {
		let e = n.codePointAt(0);
		e <= 127 ? t.push(e) : e <= 2047 ? t.push(192 | e >> 6, 128 | e & 63) : e <= 65535 ? t.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : t.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63);
	}
	return t;
}
function He(e) {
	let t = "", n = 0;
	for (; n < e.length;) {
		let r = e[n], i, a;
		if (r <= 127) i = r, a = 1;
		else if (r >= 194 && r <= 223) i = r & 31, a = 2;
		else if (r >= 224 && r <= 239) i = r & 15, a = 3;
		else if (r >= 240 && r <= 244) i = r & 7, a = 4;
		else return null;
		if (n + a > e.length) return null;
		for (let t = 1; t < a; t += 1) {
			let r = e[n + t];
			if ((r & 192) != 128) return null;
			i = i << 6 | r & 63;
		}
		if (a === 3 && (i < 2048 || i >= 55296 && i <= 57343) || a === 4 && (i < 65536 || i > 1114111)) return null;
		t += String.fromCodePoint(i), n += a;
	}
	return t;
}
function Ue(e, t) {
	return `rmd-theme-${e}-font-${Ve(t).map((e) => e.toString(16).padStart(2, "0")).join("")}`;
}
function We(e) {
	let t = Oe.exec(e);
	if (!t || t[2].length % 2 != 0) return null;
	let n = [];
	for (let e = 0; e < t[2].length; e += 2) n.push(Number.parseInt(t[2].slice(e, e + 2), 16));
	let r = He(n);
	return r === null || r.length === 0 || P(r) !== r ? null : {
		themeName: t[1],
		original: r
	};
}
function F(e) {
	return e === void 0 ? !1 : /[A-Za-z0-9_-]/.test(e) || e.codePointAt(0) >= 128;
}
function Ge(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (/[A-Za-z_]/.test(n) || n.codePointAt(0) >= 128) return !0;
	if (n === "-") {
		let n = e[t + 1];
		return n !== void 0 && (F(n) || n === "-");
	}
	return !1;
}
function Ke(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (n >= "0" && n <= "9") return !0;
	let r = e[t + 1];
	return n === "+" || n === "-" ? r !== void 0 && (r >= "0" && r <= "9" || r === ".") : n === "." && r !== void 0 && r >= "0" && r <= "9";
}
function I(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
			continue;
		}
		let i = n;
		if (r === "\"" || r === "'") {
			let r = A(e, n);
			t.push({
				type: "string",
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: e.slice(i + 1, Math.max(i + 1, r - 1))
			}), n = r;
		} else if (r === ",") t.push({
			type: "comma",
			text: ",",
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
		else if (Ke(e, n)) {
			let r = n;
			for ((e[r] === "+" || e[r] === "-") && (r += 1); e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === ".") for (r += 1; e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === "e" || e[r] === "E") {
				let t = r;
				r += 1, (e[r] === "+" || e[r] === "-") && (r += 1);
				let n = r;
				for (; e[r] >= "0" && e[r] <= "9";) r += 1;
				r === n && (r = t);
			}
			let a = "number";
			if (e[r] === "%") r += 1, a = "percentage";
			else if (Ge(e, r)) {
				for (r += 1; F(e[r]);) r += 1;
				a = "dimension";
			}
			t.push({
				type: a,
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: ""
			}), n = r;
		} else if (Ge(e, n)) {
			let r = n + 1;
			for (; F(e[r]);) r += 1;
			let a = e.slice(n, r).toLowerCase();
			if (e[r] === "(") {
				let o = j(e, r, "(", ")"), s = Math.min(o, e.length);
				t.push({
					type: "function",
					text: e.slice(n, s),
					start: i,
					end: s,
					name: a,
					stringValue: ""
				}), n = s;
				continue;
			}
			t.push({
				type: "ident",
				text: e.slice(n, r),
				start: i,
				end: r,
				name: a,
				stringValue: ""
			}), n = r;
		} else if (r === "(") {
			let r = j(e, n, "(", ")"), a = Math.min(r, e.length);
			t.push({
				type: "function",
				text: e.slice(n, a),
				start: i,
				end: a,
				name: "",
				stringValue: ""
			}), n = a;
		} else t.push({
			type: "delimiter",
			text: r,
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
	}
	return t;
}
function qe(e) {
	return M(e, 0) === e.length;
}
function L(e) {
	let t = I(e);
	if (t.length === 0) return null;
	if (t.length === 1 && t[0].type === "string") {
		let e = P(t[0].stringValue);
		return e === "" ? null : {
			key: e,
			start: t[0].start,
			end: t[0].end
		};
	}
	if (t[0].type === "string") return null;
	for (let n = 0; n < t.length; n += 1) if (t[n].type !== "ident" || n > 0 && !qe(e.slice(t[n - 1].end, t[n].start))) return null;
	if (t.length === 1 && (w.has(t[0].name) || Te.has(t[0].name))) return null;
	let n = P(t.map((e) => e.text).join(" "));
	return n === "" ? null : {
		key: n,
		start: t[0].start,
		end: t[t.length - 1].end
	};
}
function R(e) {
	let t = [], n = 0, r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = A(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else i === "(" || i === "[" ? r = j(e, r, i, i === "(" ? ")" : "]") : (i === "," && (t.push({
			start: n,
			end: r
		}), n = r + 1), r += 1);
	}
	return t.push({
		start: n,
		end: e.length
	}), t;
}
function z(e) {
	let t = I(e);
	if (t.length < 2) return {
		body: e,
		important: ""
	};
	let n = t[t.length - 1], r = t[t.length - 2];
	return n.type !== "ident" || n.name !== "important" || r.type !== "delimiter" || r.text !== "!" || !qe(e.slice(r.end, n.start)) ? {
		body: e,
		important: ""
	} : {
		body: e.slice(0, r.start),
		important: e.slice(r.start)
	};
}
function B(e, t) {
	if (t.length === 0) return e;
	let n = [...t].sort((e, t) => e.start - t.start), r = "", i = 0;
	for (let t of n) t.start < i || (r += e.slice(i, t.start) + t.text, i = t.end);
	return r + e.slice(i);
}
function Je(e) {
	return `"${e}"`;
}
function V(e, t, n = 0) {
	if (t.size === 0) return e;
	if (n > 64) throw T("theme.css", "font-family fallback nesting exceeds 64 levels.");
	let { body: r, important: i } = z(e), a = [];
	for (let e of R(r)) {
		let i = r.slice(e.start, e.end), o = L(i);
		if (o) {
			let n = t.get(o.key);
			n && a.push({
				start: e.start + o.start,
				end: e.start + o.end,
				text: Je(n)
			});
			continue;
		}
		let s = I(i);
		if (s.length !== 0 && (s.length !== 1 || s[0].type !== "ident" || !Te.has(s[0].name) && !w.has(s[0].name))) {
			if (s.length === 1 && s[0].type === "function" && s[0].name === "var") {
				let r = s[0], i = r.text.indexOf("("), o = r.text.slice(i + 1, -1), c = R(o), l = I(o.slice(0, c[0].end));
				if (!r.text.endsWith(")") || l.length !== 1 || l[0].type !== "ident" || !l[0].text.startsWith("--")) throw T("theme.css", "font-family var() must start with a custom property name.");
				if (c.length > 1) {
					let s = c[0].end + 1, l = o.slice(s);
					a.push({
						start: e.start + r.start + i + 1 + s,
						end: e.start + r.end - 1,
						text: V(l, t, n + 1)
					});
				}
			} else throw T("theme.css", "unsupported font-family syntax; use literal families or var() with a family-list fallback.");
		}
	}
	return B(r, a) + i;
}
function Ye(e) {
	let t = I(e);
	if (t.length === 0 || t.length === 1 && t[0].type === "ident" && (Ee.has(t[0].name) || w.has(t[0].name))) return null;
	let n = -1;
	for (let e = 0; e < t.length; e += 1) {
		let r = t[e];
		if (r.type === "dimension" && !/(?:deg|grad|rad|turn)$/i.test(r.text) || r.type === "percentage" || r.type === "ident" && De.has(r.name) || r.type === "number" && Number(r.text) === 0) {
			n = e;
			break;
		}
		if (r.type === "function") {
			let i = t[e + 1];
			if ([
				"calc",
				"min",
				"max",
				"clamp"
			].includes(r.name) || r.name === "var" && i?.type === "delimiter" && i.text === "/") {
				n = e;
				break;
			}
		}
	}
	if (n < 0) return null;
	let r = n + 1, i = t[r];
	return i?.type === "delimiter" && i.text === "/" && (r += 2), r >= t.length ? null : t[r].start;
}
function Xe(e, t) {
	if (t.size === 0) return e;
	let { body: n, important: r } = z(e), i = Ye(n);
	if (i === null) {
		let t = I(n);
		if (t.length === 1 && t[0].type === "ident" && (Ee.has(t[0].name) || w.has(t[0].name)) || t.length === 1 && t[0].type === "function" && t[0].name === "var" && R(t[0].text.slice(t[0].text.indexOf("(") + 1, -1)).length === 1) return e;
		throw T("theme.css", "unsupported font shorthand; use an explicit font size (including calc/min/max/clamp) and a family list.");
	}
	let a = V(n.slice(i), t);
	return n.slice(0, i) + a + r;
}
function H(e, t = !1, n = 0) {
	if (n > 64) throw T("theme.css", "nested font declarations exceed 64 levels.");
	let r = [], i = (i) => {
		let a = N(e, i + 1);
		if (t) for (let t of H(e.slice(i + 1, a), !0, n + 1)) r.push({
			name: t.name,
			valueStart: i + 1 + t.valueStart,
			valueEnd: i + 1 + t.valueEnd
		});
		return Math.min(a + 1, e.length);
	}, a = 0;
	for (; a < e.length && (a = M(e, a), !(a >= e.length));) {
		if (e[a] === ";" || e[a] === "}") {
			a += 1;
			continue;
		}
		if (e[a] === "{") {
			a = i(a);
			continue;
		}
		let t = a, n = a;
		for (; n < e.length;) {
			let t = e[n];
			if (t === "\"" || t === "'") n = A(e, n);
			else if (t === "/" && e[n + 1] === "*") n = M(e, n);
			else if (t === "(" || t === "[") n = j(e, n, t, t === "(" ? ")" : "]");
			else {
				if (t === ":" || t === ";" || t === "{" || t === "}") break;
				n += 1;
			}
		}
		if (n >= e.length) break;
		if (e[n] !== ":") {
			a = e[n] === "{" ? i(n) : n + 1;
			continue;
		}
		let o = I(e.slice(t, n)), s = o.length === 1 && o[0].type === "ident" ? o[0] : void 0, c = s?.text ?? "", l = c.startsWith("--") ? c : c.toLowerCase(), u = n + 1, d = u;
		for (; d < e.length;) {
			let t = e[d];
			if (t === "\"" || t === "'") d = A(e, d);
			else if (t === "/" && e[d + 1] === "*") d = M(e, d);
			else if (t === "(" || t === "[") d = j(e, d, t, t === "(" ? ")" : "]");
			else if (t === "{" && c.startsWith("--")) d = N(e, d + 1) + 1;
			else {
				if (t === ";" || t === "{" || t === "}") break;
				d += 1;
			}
		}
		e[d] === "{" ? a = i(d) : (s && r.push({
			name: l,
			valueStart: u,
			valueEnd: d
		}), a = d, e[d] === ";" && (a += 1));
	}
	return r;
}
function Ze(e, t) {
	if (t.size === 0) return e;
	let n = [];
	for (let r of H(e, !0)) {
		let i = r.name === "font-family" || r.name === "--font-sans" || r.name === "--font-mono";
		if (!i && r.name !== "font") continue;
		let a = e.slice(r.valueStart, r.valueEnd), o = i ? V(a, t) : Xe(a, t);
		o !== a && n.push({
			start: r.valueStart,
			end: r.valueEnd,
			text: o
		});
	}
	return B(e, n);
}
function Qe(e, t, n) {
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (/\s/.test(i) || i === ";" || i === "}") {
			r += 1;
			continue;
		}
		if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
			continue;
		}
		if (i === "{") {
			r = N(e, r + 1) + 1;
			continue;
		}
		let a = r, o = r;
		for (; o < e.length;) {
			let t = e[o];
			if (t === "\"" || t === "'") o = A(e, o);
			else if (t === "/" && e[o + 1] === "*") {
				let t = e.indexOf("*/", o + 2);
				o = t < 0 ? e.length : t + 2;
			} else if (t === "(" || t === "[") o = j(e, o, t, t === "(" ? ")" : "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				o += 1;
			}
		}
		if (o >= e.length) break;
		if (e[o] !== "{") {
			r = o + 1;
			continue;
		}
		let s = N(e, o + 1), c = e.slice(a, o).trim();
		if (c.startsWith("@")) {
			let r = (/^@([A-Za-z-]+)/.exec(c)?.[1] ?? "").toLowerCase();
			r === "font-face" ? n(e.slice(o + 1, s), t) : Ce.has(r) && Qe(e.slice(o + 1, s), t, n);
		}
		r = Math.min(s + 1, e.length);
	}
}
function $e(e, t) {
	let n = H(e).filter((e) => e.name === "font-family");
	if (n.length === 0) throw T(t, "@font-face must declare a font-family descriptor.");
	if (n.length > 1) throw T(t, "@font-face may declare font-family only once.");
	let { body: r, important: i } = z(e.slice(n[0].valueStart, n[0].valueEnd));
	if (i !== "") throw T(t, "@font-face descriptors must not use !important.");
	if (R(r).length !== 1) throw T(t, "@font-face font-family must be a single family name, not a list.");
	let a = L(r);
	if (!a) throw T(t, "@font-face font-family must be one quoted or unquoted family name; generic families, keywords, var() and other functions are not allowed.");
	if (Ve(We(a.key)?.original ?? a.key).length > we) throw T(t, `@font-face font-family must not exceed ${we} UTF-8 bytes.`);
	return a.key;
}
function et(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i of e) Qe(i.css, n, (e, n) => {
		let i = $e(e, n), a = We(i), o = a ? a.original : i, s = Ue(t, o), c = r.get(i);
		if (c !== void 0 && c !== s) throw T(n, `@font-face family "${i}" maps to more than one name.`);
		r.set(i, s), r.set(o, s);
	});
	return r;
}
function tt(e, t, n) {
	let r = H(e).filter((e) => e.name === "font-family");
	if (r.length !== 1) throw T(n, "@font-face must declare exactly one font-family descriptor.");
	let i = r[0], { body: a } = z(e.slice(i.valueStart, i.valueEnd));
	if (R(a).length !== 1) throw T(n, "@font-face font-family must be a single family name, not a list.");
	let o = L(a);
	if (!o) throw T(n, "@font-face has an unsupported font-family descriptor.");
	let s = t.get(o.key);
	if (s === void 0) throw T(n, `@font-face family "${o.key}" was not registered.`);
	return B(e, [{
		start: i.valueStart + o.start,
		end: i.valueStart + o.end,
		text: Je(s)
	}]);
}
var nt = /* @__PURE__ */ new Map();
function rt(e) {
	return e.replace(/\/\*[\s\S]*?\*\//g, " ").trim().replace(/^@layer\b/i, "@layer").replace(/\s+/g, " ").replace(/\s*,\s*/g, ", ");
}
function U(e, t, n = nt, r = !1) {
	let i = "", a = 0;
	for (; a < e.length;) {
		let o = e[a];
		if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2), n = t < 0 ? e.length : t + 2;
			i += e.slice(a, n), a = n;
			continue;
		}
		if (/\s/.test(o) || o === ";" || o === "}") {
			i += o, a += 1;
			continue;
		}
		let s = a, c = a;
		for (; c < e.length;) {
			let t = e[c];
			if (t === "\"" || t === "'") c = A(e, c);
			else if (t === "/" && e[c + 1] === "*") {
				let t = e.indexOf("*/", c + 2);
				c = t < 0 ? e.length : t + 2;
			} else if (t === "(") c = j(e, c, "(", ")");
			else if (t === "[") c = j(e, c, "[", "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				c += 1;
			}
		}
		if (c >= e.length) {
			i += e.slice(s);
			break;
		}
		let l = e.slice(s, c), u = e[c];
		if (u === ";" || u === "}") {
			let e = rt(l);
			if (!r && (e === "@layer rmd.themes" || `${e};` === x)) {
				a = c + 1;
				continue;
			}
			i += l + u, a = c + 1;
			continue;
		}
		let d = N(e, c + 1), f = e.slice(c + 1, d), p = l.trim();
		if (p.startsWith("@")) {
			let e = (/^@([A-Za-z-]+)/.exec(p)?.[1] ?? "").toLowerCase();
			if (e === "import") throw T("theme.css", "must not use @import.");
			if (e === "keyframes" || e.endsWith("-keyframes")) throw T("theme.css", `@${e} declares a global name; phase one only supports document-scoped CSS.`);
			if (e === "font-face") i += `${p} {${tt(f, n, "theme.css")}}`;
			else if (e === "layer" && !r && rt(p) === "@layer rmd.themes") i += U(f, t, n, !0).trim();
			else {
				let a = Ce.has(e) ? U(f, t, n, r || e === "layer") : f;
				i += `${p} {${a}}`;
			}
		} else i += `${Be(p, t)} {${Ze(f, n)}}`;
		a = Math.min(d + 1, e.length);
	}
	return i;
}
function W(e, t, n = nt) {
	return `${x}\n@layer ${me} {\n${U(e, t, n).trim()}\n}`;
}
function G(e, t) {
	if (!Array.isArray(e)) throw T(t, "must be an array of { id, css } resources.");
	if (e.length > ge) throw T(t, `may contain at most ${ge} resources.`);
	let n = /* @__PURE__ */ new Set(), r = [], i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a], s = `${t}[${a}]`;
		if (!ke(o)) throw T(s, "must be an object.");
		let c = o.id;
		if (typeof c != "string" || c.length === 0) throw T(`${s}.id`, "must be a non-empty string.");
		if (c.length > _e) throw T(`${s}.id`, `must not exceed ${_e} characters.`);
		if (!ye.test(c)) throw T(`${s}.id`, `"${c}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (n.has(c)) throw T(`${s}.id`, `"${c}" is declared more than once.`);
		n.add(c);
		let l = o.css;
		if (typeof l != "string") throw T(`${s}.css`, "must be a string.");
		if (l.length > S) throw T(`${s}.css`, `must not exceed ${S} characters.`);
		if (i += l.length, i > C) throw T(t, `must not exceed ${C} characters in total.`);
		Pe(l, `${s}.css`), r.push(Object.freeze({
			id: c,
			css: l
		}));
	}
	return {
		resources: Object.freeze(r),
		totalLength: i
	};
}
function it(e) {
	let t = 0;
	for (let [n, r] of e.entries()) {
		if (r.css.length > S) throw T(`theme.css[${n}].css`, `scoped CSS must not exceed ${S} characters.`);
		t += r.css.length;
	}
	if (t > C) throw T("theme.css", `scoped CSS must not exceed ${C} characters in total.`);
}
function K(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		protocol: e.protocol,
		colorSchemes: Object.freeze([...e.colorSchemes]),
		css: Object.freeze(e.css.map((e) => Object.freeze({
			id: e.id,
			css: e.css
		})))
	});
}
function at(e, t) {
	let n = E(e, t), r = D(n.id, `${t}.id`), i = O(n.name, `${t}.name`), a = k(n.version, `${t}.version`);
	if (n.protocol !== "reactive-md-theme-1") throw T(`${t}.protocol`, `must be "${y}".`);
	let o = Ae(n.colorSchemes, `${t}.colorSchemes`), { resources: s } = G(n.css, `${t}.css`);
	return K({
		id: r,
		name: i,
		version: a,
		protocol: y,
		colorSchemes: o,
		css: s
	});
}
function q(e) {
	let t = E(e, "input"), n = D(t.id, "theme.id"), r = O(t.name, "theme.name"), i = k(t.version, "theme.version");
	if ((t.protocol === void 0 ? "reactive-md-theme-1" : t.protocol) !== "reactive-md-theme-1") throw T("theme.protocol", `must be "${y}".`);
	let a = Ae(t.colorSchemes, "theme.colorSchemes"), { resources: o } = G(t.css, "theme.css"), s = et(o, r, "theme.css"), c = o.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, r, s)
	}));
	return it(c), K({
		id: n,
		name: r,
		version: i,
		protocol: y,
		colorSchemes: a,
		css: c
	});
}
function ot(e) {
	let t = E(e, "input"), n = D(t.id, "theme.id"), r = O(t.name, "theme.name"), i = k(t.version, "theme.version"), a = at(t.base, "theme.base"), o = G(t.overrides, "theme.overrides"), s = et([...a.css, ...o.resources], r, "theme.css"), c = new Set(a.css.map((e) => e.id));
	for (let e of o.resources) {
		if (c.has(e.id)) throw T("theme.overrides", `resource "${e.id}" is already declared by the base theme.`);
		c.add(e.id);
	}
	let l = [...a.css.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, r, s)
	})), ...o.resources.map((e) => Object.freeze({
		id: e.id,
		css: W(e.css, r, s)
	}))];
	return it(l), K({
		id: n,
		name: r,
		version: i,
		protocol: a.protocol,
		colorSchemes: a.colorSchemes,
		css: l
	});
}
function st(e) {
	return q(e).css.map((e) => e.css).join("\n");
}
// src/sdk/preset.ts
var J = /* @__PURE__ */ new WeakSet();
function ct(e, t) {
	let n = t instanceof Error ? t.message : String(t);
	throw Error(`Invalid local preset (themes[${e}]): ${n}`);
}
function Y(e) {
	if (typeof e == "object" && e && J.has(e)) return e;
	let t = s(e);
	if (t.themes === void 0) return J.add(t), t;
	let n = t.themes.map((e, t) => {
		try {
			return q(e);
		} catch (e) {
			ct(t, e);
		}
	}), r = Object.freeze({
		...t,
		themes: Object.freeze(n)
	});
	return J.add(r), r;
}
function lt(e) {
	return Y(e);
}
function ut(e) {
	return o(e);
}
// src/sdk/config.ts
var dt = v.id, ft = v.version, pt = Object.freeze({
	id: dt,
	version: ft
}), mt = 16, ht = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"replacements",
	"themes"
]), X = /* @__PURE__ */ new WeakSet();
function gt(e) {
	u(e) || m("themes", "each theme must be an object."), _(e, /* @__PURE__ */ new Set([
		"id",
		"name",
		"version",
		"protocol",
		"colorSchemes",
		"css"
	]), "theme");
	try {
		return q(e);
	} catch (e) {
		m("theme", e instanceof Error ? e.message : String(e));
	}
}
function Z(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || m("themes", "must be an array."), e.length > 16 && m("themes", "accepts at most 16 themes.");
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = gt(i);
		t.has(e.id) && m("themes", `theme id "${e.id}" is declared more than once.`), n.has(e.name) && m("themes", `theme name "${e.name}" is declared more than once.`), t.add(e.id), n.add(e.name), r.push(e);
	}
	return Object.freeze(r.sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function _t(e, t) {
	if (typeof e == "string") return e !== "default" && e !== v.id && m(`presets[${t}]`, `unsupported preset "${e}"; phase one accepts only the built-in default package.`), v;
	if (u(e) || m(`presets[${t}]`, "must be a preset package, \"default\" or a preset reference."), e.protocol !== void 0 || e.components !== void 0) try {
		return Y(e);
	} catch (e) {
		m(`presets[${t}]`, e instanceof Error ? e.message : String(e));
	}
	let n = e.id, r = e.version;
	return typeof n != "string" && m(`presets[${t}].id`, "must be a string."), typeof r != "string" && m(`presets[${t}].version`, "must be a string."), (n === "default" ? v.id : n) !== v.id && m(`presets[${t}]`, `unsupported preset "${n}"; phase one accepts only "${v.id}".`), r !== v.version && m(`presets[${t}].version`, `must be "${v.version}".`), v;
}
function vt(e) {
	if (e === void 0) return Object.freeze([v]);
	Array.isArray(e) || m("presets", "must be an array.");
	let t = [], n = /* @__PURE__ */ new Set();
	for (let r = 0; r < e.length; r += 1) {
		let i = _t(e[r], r);
		n.has(i.id) && m("presets", `preset "${i.id}" is selected more than once.`), n.add(i.id), t.push(i);
	}
	return Object.freeze([...t].sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
}
function yt(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || m("components", "must be an array.");
	let t = e.map((e, t) => {
		try {
			return i(e);
		} catch (e) {
			m(`components[${t}]`, e instanceof Error ? e.message : String(e));
		}
	});
	return Object.freeze(t.sort((e, t) => {
		if (e.id !== t.id) return e.id < t.id ? -1 : 1;
		let n = e.replaces === void 0 ? 0 : 1, r = t.replaces === void 0 ? 0 : 1;
		return n === r ? e.version === t.version ? e.name < t.name ? -1 : +(e.name > t.name) : e.version < t.version ? -1 : 1 : n - r;
	}));
}
function bt(e) {
	return e === void 0 ? "allow" : (e !== "allow" && e !== "forbid" && m("replacements", "must be \"allow\" or \"forbid\"."), e);
}
function xt(t, n) {
	u(t) || m(n, "must be an object."), _(t, ht, n);
	let r = Object.freeze({
		protocol: a,
		presets: vt(t.presets),
		components: yt(t.components),
		replacementPolicy: bt(t.replacements),
		themes: Z(t.themes)
	});
	return e(r) > 16777216 && m(n, `serialized size exceeds the ${g}-byte budget.`), r;
}
function St(e) {
	return Object.freeze({
		...e,
		presets: Object.freeze(e.presets.map((e) => Y(e))),
		themes: Z(e.themes)
	});
}
function Ct(e) {
	let t = St(e), n = ee(t, { legacyProfiles: p }), r = f(t, n);
	return X.add(r), r;
}
function Q(e = {}) {
	return Ct(xt(e, "config"));
}
var wt;
function Tt(e) {
	return e === void 0 ? wt ??= Q().key : $(e).key;
}
function Et(e) {
	return new Set(e.legacyKeys.map((e) => e.key));
}
function Dt(e, t) {
	let n = $(t ?? Q()), r = e.componentConfigKey;
	return r === void 0 || r === n.key || Et(n).has(r) ? [] : [{
		code: "local.extension.config-mismatch",
		severity: "error",
		message: "The document compiler configuration differs from the installed renderer. Recompile with the same host.config used by host.reactConfig (including Worker requests).",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}];
}
function Ot(e) {
	return e.preset.id === v.id && e.preset.version === v.version ? v : Y({
		...v,
		id: e.preset.id,
		version: e.preset.version
	});
}
function kt(e, t) {
	let n = ie(e.presets, pt, t)[0] ?? pt, r = l(n, t);
	r === void 0 && m("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${n.id}" ${n.version}.`);
	let i = r.legacyKeys[0];
	i === void 0 && m("presets", `local.config.migration-unsupported: profile "${r.name}" has no legacy key mapping.`), d(r, v.components);
	let o = Ot(r), s = ne(e.components, v.components);
	s.some((e) => e.replaces !== void 0) && m("config", "replaces is not supported by reactive-md-config/v1.");
	let c = Z(e.themes), u = Object.freeze({
		protocol: a,
		presets: Object.freeze([o]),
		components: s,
		replacementPolicy: "forbid",
		themes: c
	}), p = ee(u, { legacyProfiles: t }), h = re(r.preset, p.components), te = [...p.legacyKeys, ...p.legacyKeys.some((e) => e.key === h) ? [] : [Object.freeze({
		profile: i.profile,
		key: h
	})]], g = f(u, p, te);
	return X.add(g), g;
}
function $(e, r = []) {
	return typeof e == "object" && e && X.has(e) ? e : (u(e) || m("config", "must be an object."), _(e, ae, "config"), e.protocol === "reactive-md-config/v1" ? kt(e, oe(r)) : (e.protocol !== "reactive-md-config/v2" && m("config.protocol", `must be "${n}" (or legacy "${t}").`), Ct(te(e.assembly))));
}
function At(e) {
	if (typeof e == "object" && e && X.has(e)) return e.key;
	try {
		return $(e).key;
	} catch {
		try {
			return `invalid:${r(JSON.stringify(e))}`;
		} catch {
			return "invalid";
		}
	}
}
function jt(e) {
	try {
		return $(e);
	} catch {
		return e;
	}
}
export { de as C, y as S, fe as _, Tt as a, me as b, jt as c, ut as d, Y as f, Fe as g, q as h, Q as i, Dt as l, ot as m, ft as n, At as o, st as p, mt as r, $ as s, dt as t, lt as u, pe as v, b as x, x as y };
