import { a as e, c as t, o as n } from "./math-6b-qdjqP.js";
import { t as r } from "./compiler-core-C83OmA9k.js";
import { d as i } from "./validation-BPmsZ5G9.js";
import { n as a } from "./math-display-DlaL4Zrf.js";
import { o, t as s } from "./parser-standard-BPdDQopN.js";
import c from "./reactive-md-default-preset.js";
import { i as l, r as u, t as d } from "./types-APg2YEYh.js";
// src/compiler/standard.ts
function f(e) {
	let t = i(e, c.components, s);
	if (t.ok) return t;
	throw new d(t.message, {
		code: t.key,
		...t.detail === void 0 ? {} : { detail: t.detail }
	});
}
function p(e) {
	return e === void 0 ? void 0 : Object.freeze({ ...e });
}
function m(i) {
	let s = f(i), c = p(i), d = {
		display: a,
		htmlDocument: o,
		plotMath: {
			kind: t,
			gridSize: n,
			compile: e
		}
	};
	return { compile(e) {
		return l(r(e, c, s, d), u);
	} };
}
export { d as CompilerConfigurationError, m as createStandardCompiler };
