import { $ as e, j as t, st as n } from "./preset-core-CKc5YXSM.js";
// src/local/compilation/component-kernel.ts
function r(e, t, n) {
	if (!e) return;
	let r = e, i = e.options ?? [], a = e.constraints ?? (r.min !== void 0 || r.max !== void 0 || r.step !== void 0 ? {
		...r.min === void 0 ? {} : { min: { literal: r.min } },
		...r.max === void 0 ? {} : { max: { literal: r.max } },
		...r.step === void 0 ? {} : { step: { literal: r.step } }
	} : void 0), o = e.family ?? (e.kind === "number" ? "number" : e.kind === "boolean" ? "boolean" : e.kind === "array" ? "multi-select" : i.length ? "choice" : "text");
	return {
		...e,
		family: o,
		bind: e.bind ?? "bind",
		initial: e.initial ?? "initial",
		initialRule: e.initialRule ?? n ?? (t === "value" ? e.kind === "boolean" ? "false" : e.kind === "number" ? "nearest-zero" : "empty" : "nearest-zero"),
		...a ? { constraints: a } : {}
	};
}
function i(e) {
	return e.bindings.value;
}
function a(e) {
	let t = [];
	for (let [n, r] of Object.entries(e.bindings)) n !== "value" && t.push({
		...r,
		slot: n
	});
	return t;
}
function o(e) {
	return e.slotRelations;
}
function s(e) {
	return e.structure ? e.structure : {
		rule: e.childRule ?? (e.form === "leaf" ? "none" : e.form === "inline" ? "inline" : "any"),
		label: e.label ?? "none",
		...e.parent ? { parents: e.parent } : {}
	};
}
function c(e) {
	return e.structure;
}
function l(e) {
	return e.rules ?? [];
}
function u(e, t) {
	for (let n of l(e)) if (n.kind === t) return n;
}
function d(e, t) {
	return l(e).filter((e) => e.kind === t);
}
function f(e) {
	return e.legacyHost === !0;
}
function p(e, t) {
	if (t === e.bind) return e.options, {
		kind: "string",
		static: !0
	};
	switch (e.kind) {
		case "number": return {
			kind: "number",
			static: !0
		};
		case "boolean": return {
			kind: "boolean",
			static: !0
		};
		default: return {
			kind: "string",
			static: !0
		};
	}
}
function m(e, t) {
	let n = { ...e.props }, r = t?.bindings ?? e.bindings, i = r?.value ?? e.binding, a = r ? Object.entries(r).filter(([e]) => e !== "value").map(([, e]) => e) : (e.slots ?? []).map((e) => ({
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule ?? "nearest-zero"
	}));
	for (let e of i ? [i] : []) Object.hasOwn(n, e.bind) || (n[e.bind] = p(e, e.bind)), Object.hasOwn(n, e.initial) || (n[e.initial] = p(e, e.initial)), Object.hasOwn(n, "disabled") || (n.disabled = {
		kind: "boolean",
		dynamic: !0,
		default: !1
	});
	for (let e of a) Object.hasOwn(n, e.bind) || (n[e.bind] = p(e, e.bind)), Object.hasOwn(n, e.initial) || (n[e.initial] = p(e, e.initial));
	return {
		...e,
		props: n,
		...t?.structure ?? e.structure ? { structure: t?.structure ?? e.structure } : {},
		...t?.rules ?? e.rules ? { rules: t?.rules ?? e.rules } : {},
		...r ? { bindings: r } : {},
		...t?.slotRelations ?? e.slotRelations ? { slotRelations: t?.slotRelations ?? e.slotRelations } : {},
		...t?.legacyHost === !0 || e.legacyHost === !0 ? { legacyHost: !0 } : {}
	};
}
function h(e, t) {
	let n = m(e, t), i = {}, a = t?.bindings ?? e.bindings;
	if (a) for (let [t, n] of Object.entries(a)) {
		let a = r(n, t, t === "value" ? e.initialRule : void 0);
		a && (i[t] = a);
	}
	else if (e.binding) {
		let t = r(e.binding, "value", e.initialRule);
		t && (i.value = t);
	}
	for (let t of e.slots ?? []) {
		if (i[t.name] !== void 0) continue;
		let e = r({
			kind: t.kind,
			family: t.family,
			bind: t.bind,
			initial: t.initial,
			...t.exclusive === void 0 ? {} : { exclusive: t.exclusive },
			...t.initialRule === void 0 ? {} : { initialRule: t.initialRule }
		}, t.name);
		e && (i[t.name] = e);
	}
	let o = {};
	for (let [e, t] of Object.entries(n.props)) {
		let n = t.values ?? t.enum;
		if (n === void 0) {
			o[e] = t;
			continue;
		}
		let { enum: r, ...i } = t;
		o[e] = {
			...i,
			values: n
		};
	}
	return Object.freeze({
		name: n.name,
		form: n.form,
		props: Object.freeze(o),
		bindings: Object.freeze(i),
		structure: s(n),
		rules: n.rules ?? [],
		slotRelations: n.slotRelations ?? [],
		legacyHost: n.legacyHost === !0
	});
}
function g(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function _(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "string" ? r.value : void 0;
	let i = e.props[n]?.default;
	return typeof i == "string" ? i : void 0;
}
function v(e, t, n) {
	return n === void 0 ? t : e[n]?.offset ?? t;
}
function y(e, t, n) {
	let r = [], i = e.name, a = i, o = (e, t, n, i, a) => {
		r.push({
			code: e,
			message: t,
			start: n,
			key: i,
			...a ? { params: a } : {}
		});
	};
	for (let r of l(e)) switch (r.kind) {
		case "numeric-range": {
			let s = g(e, t, r.min), c = g(e, t, r.max);
			s !== void 0 && c !== void 0 && (r.order === "increasing" ? !(s < c) : s > c) && o("local.constraint", r.order === "increasing" ? `${i} ${r.min ?? "min"} must be less than ${r.max ?? "max"}.` : `Component <${i}> min cannot exceed max.`, v(t, n.start, r.min), r.order === "increasing" ? "local.constraint.plot-range" : "local.constraint.number-min-max", r.order === "increasing" ? void 0 : { component: a });
			let l = g(e, t, r.step);
			l === void 0 || l > 0 && Number.isFinite(l) || o("local.constraint", `Component <${i}> step must be greater than 0.`, v(t, n.start, r.step), "local.constraint.number-step", { component: a });
			let u = r.integer;
			if (u !== void 0) {
				let r = g(e, t, u);
				r !== void 0 && !Number.isInteger(r) && o("local.constraint", `Attribute ${u} must be a whole number.`, v(t, n.start, u), "local.constraint.integer", {
					name: u,
					component: a
				});
			}
			if (r.positiveInteger !== void 0) {
				let i = g(e, t, r.positiveInteger);
				i !== void 0 && (!Number.isInteger(i) || i <= 0) && o("local.constraint", `Attribute ${r.positiveInteger} must be a positive whole number.`, v(t, n.start, r.positiveInteger), "local.constraint.positive-integer", {
					name: r.positiveInteger,
					component: a
				});
			}
			break;
		}
		case "text-length": {
			let i = g(e, t, r.min) ?? 0, a = g(e, t, r.max);
			a !== void 0 && a < i && o("local.constraint", "max-length cannot be less than min-length.", v(t, n.start, r.max), "local.constraint.length-order");
			break;
		}
		case "date-bounds": {
			let i = _(e, t, r.min), a = _(e, t, r.max);
			i !== void 0 && !x(i) && o("local.attribute.type", `Date lower bound ${i} is not a valid YYYY-MM-DD.`, v(t, n.start, r.min), "local.attribute.type.date-lower", { value: i }), a !== void 0 && !x(a) && o("local.attribute.type", `Date upper bound ${a} is not a valid YYYY-MM-DD.`, v(t, n.start, r.max), "local.attribute.type.date-upper", { value: a }), i && a && i > a && o("local.constraint", "Date min cannot be later than max.", v(t, n.start, r.min), "local.constraint.date-order");
			break;
		}
		case "nonempty": {
			let e = t[r.attribute];
			if (!e || e.dynamic) break;
			(typeof e.value == "string" ? e.value : String(e.raw ?? "")).trim() || o("local.constraint", `Attribute ${r.attribute} of <${i}> cannot be empty.`, e.offset, `local.constraint.${i}-${r.attribute}`, {
				name: r.attribute,
				component: a
			});
			break;
		}
		case "progress-bounds": {
			let n = g(e, t, r.max) ?? r.defaultMax, i = t[r.value];
			i && !i.dynamic && typeof i.value == "number" && (i.value < 0 || i.value > n) && o("local.constraint", `progress value must be between 0 and ${n}, got ${i.value}.`, i.offset, "local.constraint.progress-range", {
				max: n,
				value: i.value
			});
			break;
		}
		case "timer-duration": {
			let i = g(e, t, r.attribute) ?? r.default;
			(!Number.isInteger(i) || i <= 0) && o("local.constraint", "timer duration must be a positive whole number of seconds.", v(t, n.start, r.attribute), "local.constraint.timer-duration");
			break;
		}
		case "option-count": {
			let a = g(e, t, r.max);
			a !== void 0 && (!Number.isInteger(a) || a < 0) && o("local.constraint", `${i} ${r.max} must be a nonnegative whole number.`, v(t, n.start, r.max), `local.constraint.${i}`);
			break;
		}
		case "selection-requires":
			if (Object.hasOwn(t, r.key)) break;
			for (let e of r.attributes) {
				let n = t[e];
				n && o("local.selection.key", `<${i}> ${e} requires a key attribute naming the selection column.`, n.offset, "local.selection.key.required", {
					component: a,
					name: e
				});
			}
	}
	return r;
}
var b = /^(\d{4})-(\d{2})-(\d{2})$/;
function x(e) {
	if (e === "") return !0;
	let t = b.exec(e);
	if (!t) return !1;
	let n = Number(t[1]), r = Number(t[2]), i = Number(t[3]);
	return n < 1 || r < 1 || r > 12 || i < 1 ? !1 : i <= [
		31,
		n % 4 == 0 && n % 100 != 0 || n % 400 == 0 ? 29 : 28,
		31,
		30,
		31,
		30,
		31,
		31,
		30,
		31,
		30,
		31
	][r - 1];
}
function S(e, t, n) {
	if (n === void 0) return;
	if ("literal" in n) return n.literal;
	let r = t[n.prop];
	if (r) return r.dynamic ? void 0 : typeof r.value == "number" ? r.value : void 0;
	let i = e.props[n.prop]?.default;
	return typeof i == "number" ? i : void 0;
}
function C(e, t, n) {
	let r = t.constraints;
	if (!r) return { step: 1 };
	let i = S(e, n, r.min), a = S(e, n, r.max), o = S(e, n, r.step) ?? 1, s = (e) => {
		if (e === void 0 || !("prop" in e)) return;
		let t = n[e.prop];
		return t?.dynamic ? (t.expression ?? "").trim() : void 0;
	}, c = s(r.min), l = s(r.max);
	return {
		...i === void 0 ? {} : { min: i },
		...a === void 0 ? {} : { max: a },
		step: o > 0 ? o : 1,
		...c === void 0 ? {} : { dynamicMin: c },
		...l === void 0 ? {} : { dynamicMax: l }
	};
}
function w(e, t, n) {
	return S(e, n, t.maxItems);
}
function T(e, t, n) {
	let r = n === "min" ? e.dynamicMin : e.dynamicMax, i = n === "min" ? t.dynamicMin : t.dynamicMax;
	return r !== void 0 || i !== void 0 ? r === i : e[n] === t[n];
}
function E(e) {
	return `[${e.dynamicMin === void 0 ? e.min === void 0 ? "-∞" : String(e.min) : `{{ ${e.dynamicMin} }}`}, ${e.dynamicMax === void 0 ? e.max === void 0 ? "∞" : String(e.max) : `{{ ${e.dynamicMax} }}`}] / ${e.step}`;
}
function D(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= 1e-9 * Math.max(1, Math.abs(r));
}
function O(e, t, n) {
	let r = e ?? 0, i = e === void 0 ? -Infinity : Math.ceil((e - r) / n), a = t === void 0 ? Infinity : Math.floor((t - r) / n);
	if (i > a) return null;
	let o = -r / n, s = null;
	for (let e of [Math.floor(o), Math.ceil(o)]) {
		let t = Math.min(a, Math.max(i, e));
		if (!Number.isFinite(t)) continue;
		if (s === null) {
			s = t;
			continue;
		}
		let o = r + t * n, c = r + s * n;
		(Math.abs(o) < Math.abs(c) || Math.abs(o) === Math.abs(c) && o < c) && (s = t);
	}
	if (s === null) return null;
	let c = r + s * n;
	return e !== void 0 && c < e || t !== void 0 && c > t ? null : c;
}
function k(e, t, n) {
	switch (e) {
		case "empty": return { value: "" };
		case "false": return { value: !1 };
		case "min": return { value: t?.min ?? 0 };
		case "nearest-zero": {
			let e = t ?? { step: 1 }, n = O(e.min, e.max, e.step);
			return n === null ? { error: "no-step" } : { value: n };
		}
		case "duration": return { value: t?.max ?? 60 };
		case "first-option":
		case "first-tab":
		case "first-step":
		case "first-node": return { value: n[0] ?? "" };
		case "checked": return { value: [] };
		case "empty-array": return { value: [] };
		case "max-step": {
			let e = t ?? { step: 1 }, n = e.min ?? 0, r = (e.max ?? n) - n, i = n + Math.max(0, Math.floor(r / e.step + 1e-9)) * e.step;
			return { value: Math.min(e.max ?? i, Math.max(e.min ?? i, i)) };
		}
		case "none": return { value: "" };
		default: return { error: "cannot-derive" };
	}
}
function A(e) {
	switch (e) {
		case "choice":
		case "multi-select": return "options";
		case "tabs": return "tabs";
		case "steps": return "steps";
		case "selection": return "selection";
		case "diagram": return "diagram-nodes";
		case "checklist": return "checklist";
		default: return;
	}
}
function j(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) r !== void 0 && (t[n] = r);
	return t;
}
function M(e) {
	let t = [];
	for (let n of l(e)) switch (n.kind) {
		case "value-date":
			t.push(j({
				kind: "date",
				min: n.min,
				max: n.max,
				required: n.required
			}));
			break;
		case "value-length":
			t.push(j({
				kind: "length",
				min: n.min,
				max: n.max
			})), (n.email !== void 0 || n.emailType !== void 0) && t.push(j({
				kind: "email",
				type: n.email ?? "type",
				value: n.emailType ?? "email"
			}));
			break;
		case "value-email":
			t.push(j({
				kind: "email",
				type: n.type ?? "type",
				value: n.value ?? "email"
			}));
			break;
		case "value-required": t.push({
			kind: "required",
			required: n.required
		});
	}
	return t;
}
function N(e) {
	if (!e || typeof e != "object") return;
	let t = e.kernel;
	if (t && typeof t == "object") return t;
}
var P = /^[A-Za-z_][A-Za-z0-9_-]*$/;
function F(e) {
	return P.test(e);
}
function I(e, t, n) {
	let r = [];
	for (let i of e) {
		let e = i.target;
		e ? e.startsWith("#") || /\s/.test(e) ? r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" must be a bare heading slug or anchor id without "#" or whitespace.`,
			start: i.offset,
			key: "local.jump.bad-target",
			params: { target: e }
		}) : !t.has(e) && !n.has(e) && r.push({
			code: "local.jump.target",
			message: `<${i.name}> target "${e}" does not resolve to a heading or explicit anchor in this document.`,
			start: i.offset,
			key: "local.jump.unresolved",
			params: { target: e }
		}) : r.push({
			code: "local.jump.target",
			message: "<jump> target cannot be empty.",
			start: i.offset,
			key: "local.jump.empty"
		});
	}
	return r;
}
Object.freeze({
	arrayLength: e,
	dataTableColumns: 20,
	plotCurves: 16,
	plotPoints: n
});
// src/sdk/registry-core.ts
var L = /* @__PURE__ */ new WeakMap();
function R(e) {
	return {
		kind: e.kind,
		...e.required === !0 ? { required: !0 } : {},
		...e.static === !0 ? { static: !0 } : {},
		...e.dynamic === void 0 ? {} : { dynamic: e.dynamic },
		...e.default === void 0 ? {} : { default: e.default },
		...e.nullable === !0 ? { nullable: !0 } : {},
		...e.enum ? { values: [...e.enum] } : {},
		...e.pattern === void 0 ? {} : { pattern: e.pattern },
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.integer === !0 ? { integer: !0 } : {},
		...e.positive === !0 ? { positive: !0 } : {},
		...e.color === !0 ? { color: !0 } : {},
		...e.coerce === void 0 ? {} : { coerce: e.coerce }
	};
}
function z(e) {
	return {
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule,
		required: e.required === !0,
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...e.options ? { options: e.options } : {},
		...e.constraints ? { constraints: e.constraints } : {},
		...e.maxItems ? { maxItems: e.maxItems } : {},
		...e.requiresAttributes ? { requiresAttributes: e.requiresAttributes } : {},
		...e.compare ? { compare: e.compare } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function B(e, t) {
	if (t === e.bind) return {
		kind: "string",
		static: !0
	};
	switch (e.kind) {
		case "number": return {
			kind: "number",
			static: !0
		};
		case "boolean": return {
			kind: "boolean",
			static: !0
		};
		default: return {
			kind: "string",
			static: !0
		};
	}
}
function V(e, t) {
	if (e === void 0) return t === "leaf" ? "none" : "any";
	switch (e.rule) {
		case "components": return e.child === "card" ? "cards" : e.child === "disclosure" ? "disclosures" : e.child === "column" ? "columns" : "any";
		default: return e.rule;
	}
}
function H(e) {
	let n = L.get(e);
	if (n !== void 0) return n;
	let r = e.bindings ?? {}, i = e.structure ?? t(e.children), a = r.value, o = [];
	for (let [e, t] of Object.entries(r)) e !== "value" && o.push(Object.freeze({
		name: e,
		bind: t.bind,
		initial: t.initial,
		kind: t.kind,
		family: t.family,
		exclusive: t.exclusive === !0,
		initialRule: t.initialRule
	}));
	let s = {};
	for (let [t, n] of Object.entries(e.props)) s[t] = R(n);
	for (let e of Object.values(r)) {
		let t = [e.bind, e.initial];
		for (let n of t) Object.hasOwn(s, n) || (n !== e.initial || e.initialRule !== "checked" && e.initialRule !== "duration") && (s[n] = B(e, n));
	}
	let c = Object.freeze({
		name: e.name,
		form: e.form,
		props: Object.freeze(s),
		...a ? { binding: Object.freeze(z(a)) } : {},
		...Object.keys(r).length ? { bindings: Object.freeze({ ...r }) } : {},
		...o.length ? { slots: Object.freeze(o) } : {},
		...i ? { structure: i } : {},
		...e.rules ? { rules: e.rules } : {},
		...e.slotRelations ? { slotRelations: e.slotRelations } : {},
		...e.legacyHost === !0 ? { legacyHost: !0 } : {},
		childRule: V(i, e.form),
		label: i?.label ?? "none",
		...i?.parents ? { parent: i.parents } : {},
		...a ? { initialRule: a.initialRule } : {}
	});
	return L.set(e, c), c;
}
function U(e) {
	return H(e);
}
var W = /* @__PURE__ */ new WeakMap();
function G(e) {
	let n = W.get(e);
	if (n !== void 0) return n;
	let r = e.structure ?? t(e.children), i = h({
		name: e.name,
		form: e.form,
		props: e.props,
		childRule: V(r, e.form)
	}, {
		...r ? { structure: r } : {},
		...e.rules ? { rules: e.rules } : {},
		...e.bindings ? { bindings: e.bindings } : {},
		...e.slotRelations ? { slotRelations: e.slotRelations } : {},
		...e.legacyHost ? { legacyHost: !0 } : {}
	});
	return W.set(e, i), i;
}
export { i as C, f as S, h as T, d as _, x as a, o as b, E as c, I as d, C as f, l as g, u as h, F as i, N as l, A as m, U as n, y as o, D as p, G as r, k as s, H as t, w as u, T as v, M as w, c as x, a as y };
