import { o as e } from "./props-DGlBk0e5.js";
import { k as t } from "./config-validation-BLmgvFIS.js";
import { l as n } from "./sdk-core-CIxdxzII.js";
import { useCallback as r, useEffect as i, useRef as a, useState as o } from "react";
import { jsx as s, jsxs as c } from "react/jsx-runtime";
// src/react/component-utils.tsx
function l(e) {
	return {
		context: e,
		content: e.content,
		props: e.props,
		runtime: e.runtime,
		bindings: e.bindings,
		children: e.children,
		mode: e.mode,
		visible: e.visible,
		disabled: e.disabled,
		disabledInvalid: e.disabledInvalid,
		resetToken: e.resetToken,
		t: e.locale.t,
		locale: e.locale.locale,
		validation: e.validation,
		source: e.source,
		navigation: e.navigation,
		url: e.url,
		report: e.report,
		render: (t, n) => e.children.renderItems(t ?? e.children.items(), n),
		renderInline: (t, n) => e.children.renderInlineItems(t ?? e.children.items(), n)
	};
}
function u(e) {
	let [n, i] = o(null), { locale: a, report: s, bindings: c } = e, l = r((e) => e.map((e) => t(e, a.locale)).join("; "), [a.locale]);
	return {
		write: r((e, t = "value") => {
			let n = c.set(t, e);
			return n.ok ? (i(null), !0) : (n.diagnostics.length > 0 ? (i(l(n.diagnostics)), s(n.diagnostics)) : i(a.t("Cannot write this value", "无法写入此值")), !1);
		}, [
			c,
			a,
			l,
			s
		]),
		writeMany: r((e) => {
			let t = c.setMany(e);
			return t.ok ? (i(null), !0) : (t.diagnostics.length > 0 ? (i(l(t.diagnostics)), s(t.diagnostics)) : i(a.t("Cannot write this value", "无法写入此值")), !1);
		}, [
			c,
			a,
			l,
			s
		]),
		error: n,
		setError: i
	};
}
function d(e) {
	return {
		disabled: e.disabled,
		invalid: e.disabledInvalid
	};
}
function f(e, t) {
	return e.validation.fieldFor(t ?? e.content);
}
function p(e, t) {
	return e.validation.hintFor(t ?? e.content);
}
function m(e, t) {
	return e.source.attributes(t);
}
function h(e, t) {
	let n = e.resetToken, r = a(n), o = a(t);
	o.current = t, i(() => {
		r.current !== n && (r.current = n, o.current());
	}, [n]);
}
function g(e, t) {
	return e.attrs[t];
}
function _(e, t, n = "") {
	let r = e.props[t];
	return typeof r == "string" ? r : typeof r == "number" ? Number.isFinite(r) ? String(r) : n : typeof r == "boolean" ? r ? "true" : "false" : e.content.attrs[t] === void 0 ? n : e.locale.t("Cannot compute", "无法计算");
}
function v(e, t, n) {
	let r = e.props[t];
	return typeof r == "number" && Number.isFinite(r) ? r : n;
}
function y(e, t, n, r = "") {
	let i = t.props[n];
	return typeof i == "string" ? i : typeof i == "number" ? Number.isFinite(i) ? String(i) : r : typeof i == "boolean" ? i ? "true" : "false" : t.attrs[n] === void 0 ? r : e.locale.t("Cannot compute", "无法计算");
}
function b(e, t, n, r = !1) {
	let i = t.props[n];
	return typeof i == "boolean" ? i : r;
}
function x(e, t) {
	if (e.content.attrs[t] === void 0) return {
		present: !1,
		error: !1
	};
	let n = e.props[t];
	return typeof n == "number" && Number.isFinite(n) ? {
		present: !0,
		error: !1,
		value: n
	} : {
		present: !0,
		error: !0
	};
}
function S(e, t) {
	if (e.content.attrs[t] === void 0) return {
		present: !1,
		error: !1
	};
	let n = e.props[t];
	return typeof n == "string" ? {
		present: !0,
		error: !1,
		value: n
	} : {
		present: !0,
		error: !0
	};
}
function C(e, t, n) {
	if (e.content.attrs[t] === void 0) return {
		ok: !0,
		value: n
	};
	let r = e.props[t];
	return typeof r == "boolean" ? {
		ok: !0,
		value: r
	} : { ok: !1 };
}
function w(e, t, n = !1) {
	let r = C(e, t, n);
	return r.ok ? r.value : n;
}
function T(e, t, n, r) {
	if (e.content.attrs[t] === void 0) return {
		tone: r,
		error: !1
	};
	let i = e.props[t];
	return typeof i == "string" && n.includes(i) ? {
		tone: i,
		error: !1
	} : {
		tone: r,
		error: /\{\{/.test(e.content.attrs[t] ?? "")
	};
}
function E(t) {
	let n = t.attrs.color;
	if (n === void 0) return;
	let r = n.trim();
	return r !== "" && e(r) ? r : void 0;
}
function D(e) {
	if (e) return {
		"--local-accent": e,
		"--local-accent-soft": `color-mix(in srgb, ${e} 14%, var(--surface))`,
		"--local-accent-strong": e
	};
}
function O(e) {
	return e === null ? "" : typeof e == "string" ? e : typeof e == "number" ? Number.isFinite(e) ? String(e) : null : typeof e == "boolean" ? e ? "true" : "false" : null;
}
function k(e) {
	return O(e) ?? "";
}
function A(e) {
	try {
		return e.runtime.get(e.content);
	} catch {
		return null;
	}
}
function j(e, t, n) {
	try {
		let r = e.runtime.get(e.content, t);
		return typeof r == "number" && Number.isFinite(r) ? r : n;
	} catch {
		return n;
	}
}
function M(e, t, n) {
	return Math.min(n, Math.max(t, e));
}
function N(e, t, n, r) {
	let i = Number.isFinite(r) && r > 0 ? r : 1, a = Math.max(0, Math.floor((n - t) / i + 1e-9)), o = t + Math.max(0, Math.min(a, Math.round((e - t) / i))) * i;
	return Number(o.toPrecision(15));
}
function P(e, t, n, r, i, a = 1) {
	let o = v(e, t, r), s = v(e, n, i);
	o > s && ([o, s] = [s, o]);
	let c = v(e, "step", a);
	return {
		min: o,
		max: s,
		step: Number.isFinite(c) && c > 0 ? c : 1
	};
}
function F(e) {
	return e.trim() === "" ? "—" : e;
}
function I({ label: e, value: t, hint: n, className: r = "", multiline: i = !1 }) {
	return /* @__PURE__ */ c("div", {
		className: `md-control local-static-control ${r}`.trim(),
		children: [
			/* @__PURE__ */ s("span", {
				className: "md-label",
				children: e
			}),
			/* @__PURE__ */ s("span", {
				className: `local-static-value${i ? " local-static-multiline" : ""}`,
				"data-local-static-value": "",
				children: t
			}),
			n ? /* @__PURE__ */ s("span", {
				className: "md-hint",
				children: n
			}) : null
		]
	});
}
function L({ value: e, block: t = !1 }) {
	return t ? /* @__PURE__ */ s("div", {
		className: "local-print-value local-print-block",
		"aria-hidden": "true",
		"data-local-print-value": "",
		children: e
	}) : /* @__PURE__ */ s("span", {
		className: "local-print-value",
		"aria-hidden": "true",
		"data-local-print-value": "",
		children: e
	});
}
function R({ message: e, id: t }) {
	return e ? /* @__PURE__ */ s("span", {
		id: t,
		className: "field-error",
		role: "alert",
		children: e
	}) : null;
}
function z({ message: e }) {
	return /* @__PURE__ */ s("span", {
		className: "local-error",
		role: "alert",
		children: e ?? "Cannot compute"
	});
}
function B({ message: e }) {
	return /* @__PURE__ */ s("span", {
		className: "local-error local-tone-error",
		role: "status",
		children: e
	});
}
function V(e, t) {
	let n = Math.max(0, Math.floor(e)), r = Math.floor(n / 60), i = n % 60;
	return r === 0 ? t(`${i} seconds`, `${i} 秒`) : `${r}:${String(i).padStart(2, "0")}`;
}
function H(e) {
	return n(e);
}
function U(e, t, n = 0) {
	if (!t || n > 64) return "";
	let r = "";
	for (let i of t) switch (i.kind) {
		case "text":
		case "inlineCode":
		case "fallback":
			r += i.text;
			break;
		case "interpolation":
			try {
				let t = O(e.runtime.evaluate(i.text));
				r += t ?? e.locale.t("Cannot compute", "无法计算");
			} catch {
				r += e.locale.t("Cannot compute", "无法计算");
			}
			break;
		case "break":
			r += " ";
			break;
		default: r += U(e, i.children, n + 1);
	}
	return r;
}
function W(e, t) {
	return U(e, t.content.children) || t.content.attrs.value || "";
}
export { l as A, C, F as D, N as E, p as F, u as I, h as M, m as N, _ as O, f as P, g as S, j as T, E as _, B as a, P as b, M as c, k as d, H as f, y as g, b as h, I as i, d as j, T as k, A as l, U as m, z as n, D as o, V as p, L as r, w as s, R as t, S as u, v, O as w, W as x, x as y };
