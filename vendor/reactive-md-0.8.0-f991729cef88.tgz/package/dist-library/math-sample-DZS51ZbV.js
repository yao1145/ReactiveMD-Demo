import { t as e } from "./math-6b-qdjqP.js";
// src/local/evaluation/math-sample.ts
var t = 2e3, n = 5, r = 1e6;
function i(t, n, r, i) {
	try {
		return t.evaluate(n, r, i);
	} catch (t) {
		if (t instanceof e) {
			if (t.code === "latex-budget") throw t;
			return null;
		}
		throw t;
	}
}
function a(e) {
	if (e.length === 0) return 0;
	let t = [...e].sort((e, t) => e - t);
	return t[Math.floor(t.length / 2)];
}
function o(e, t, r, i, a, o) {
	let s = r - e;
	if (!(s > 0)) return !1;
	let c = 0, l = 0;
	for (let a = 1; a <= n; a += 1) {
		let n = 1 << a, u = s / n, d = t, f = 0;
		for (let t = 1; t <= n; t += 1) {
			let a = t === n ? r : e + t * u, s = t === n ? i : o(a);
			if (s === null) return !0;
			let c = Math.abs(s - d) / u;
			c > f && (f = c), d = s;
		}
		a === 2 && (c = f), l = f;
	}
	return l > Math.max(c * 6, a * 12, 1e-9);
}
function s(n, s, c, l, u = 200, d) {
	if (!Number.isFinite(c) || !Number.isFinite(l)) throw new e("latex-plot-range", "Plot min/max must be finite numbers.", 0);
	if (!(c < l)) throw new e("latex-plot-range", "Plot min must be less than max.", 0);
	if (!Number.isInteger(u) || u < 2 || u > t) throw new e("latex-plot-samples", `Sample count must be an integer between 2 and ${t}.`, 0);
	let f = {
		steps: 0,
		limit: Math.max(r, u * 1024)
	}, p = (e) => {
		let t = f.limit - f.steps, r = d ? Number.isFinite(d.limit) && Number.isFinite(d.steps) ? d.limit - d.steps : 0 : Infinity, a = {
			steps: 0,
			limit: Math.max(0, Math.min(t, r))
		};
		try {
			return i(n, e, s, a);
		} finally {
			f.steps += a.steps, d && (d.steps = Number.isFinite(d.steps) ? d.steps + a.steps : a.steps);
		}
	}, m = (l - c) / (u - 1), h = [];
	for (let e = 0; e < u; e += 1) {
		let t = e === u - 1 ? l : c + e * m;
		h.push({
			x: t,
			y: p(t)
		});
	}
	let g = h.map((e) => e.y).filter((e) => e !== null).map((e) => Math.abs(e)), _ = Math.max(1e-9, a(g) * 8);
	for (let e = 1; e < h.length - 1; e += 1) {
		let t = h[e - 1].y, n = h[e].y, r = h[e + 1].y;
		t !== null && n !== null && r !== null && Math.abs(n) > Math.max(1, Math.abs(t), Math.abs(r)) * 100 && Math.abs(n) > _ && (h[e] = {
			x: h[e].x,
			y: null
		});
	}
	let v = h.length - 1, y = h[v].y, b = v > 0 ? h[v - 1].y : null;
	y !== null && b !== null && Math.abs(y) > Math.max(1, Math.abs(b)) * 100 && Math.abs(y) > _ && (y = null, h[v] = {
		x: h[v].x,
		y: null
	});
	let x = [], S = [];
	for (let e = 0; e < h.length - 1; e += 1) {
		let t = h[e], n = h[e + 1];
		if (t.y === null || n.y === null) continue;
		let r = Math.abs(n.y - t.y);
		x.push(r);
		let i = n.x - t.x;
		i > 0 && S.push(r / i);
	}
	let C = a(x), w = a(S);
	for (let e = 0; e < h.length - 1; e += 1) {
		let t = h[e], n = h[e + 1], r = t.y, i = n.y;
		if (r === null || i === null) continue;
		let a = () => {
			h[e + 1] = {
				x: n.x,
				y: null
			};
		}, s = p(t.x + (n.x - t.x) / 2);
		if (s === null) {
			a();
			continue;
		}
		let c = Math.abs(i - r);
		(Math.abs(s - (r + i) / 2) > Math.max(c * .25, C * .4, 1e-9) || c > Math.max(C * 16, 1e-9)) && o(t.x, r, n.x, i, w, (e) => p(e)) && a();
	}
	return {
		points: h,
		endpoint: y
	};
}
function c(t, n, r, i) {
	if (!Number.isFinite(t) || !Number.isFinite(n)) throw new e("latex-plot-range", "Plot min/max must be finite numbers.", 0);
	if (!(t < n)) throw new e("latex-plot-range", "Plot min must be less than max.", 0);
	if (!Number.isInteger(r) || r < 2 || r > i) throw new e("latex-plot-samples", `Sample count must be an integer between 2 and ${i}.`, 0);
}
function l(e, t) {
	let n = e.limit - e.steps, r = t ? Number.isFinite(t.limit) && Number.isFinite(t.steps) ? t.limit - t.steps : 0 : Infinity;
	return {
		steps: 0,
		limit: Math.max(0, Math.min(n, r))
	};
}
function u(e, t, n) {
	e.steps += n.steps, t && (t.steps = Number.isFinite(t.steps) ? t.steps + n.steps : n.steps);
}
function d(e, n, a, o, s, d = 200, f) {
	c(o, s, d, t);
	let p = {
		steps: 0,
		limit: Math.max(r, d * 2048)
	}, m = (s - o) / (d - 1), h = [];
	for (let t = 0; t < d; t += 1) {
		let r = t === d - 1 ? s : o + t * m, c = {
			...a,
			t: r
		}, g = l(p, f), _ = null;
		try {
			_ = i(e, r, c, g);
		} finally {
			u(p, f, g);
		}
		let v = l(p, f), y = null;
		try {
			y = _ === null ? null : i(n, r, c, v);
		} finally {
			u(p, f, v);
		}
		h.push({
			x: _ === null || !Number.isFinite(_) ? NaN : _,
			y: _ === null || y === null || !Number.isFinite(y) ? null : y,
			t: r
		});
	}
	let g = h[h.length - 1];
	return {
		points: h,
		endpoint: g && g.y !== null ? g.y : null
	};
}
function f(e, n, a, o, s = 200, d) {
	c(a, o, s, t);
	let f = {
		steps: 0,
		limit: Math.max(r, s * 1024)
	}, p = (o - a) / (s - 1), m = [];
	for (let t = 0; t < s; t += 1) {
		let r = t === s - 1 ? o : a + t * p, c = l(f, d), h;
		try {
			h = i(e, r, {
				...n,
				theta: r
			}, c);
		} finally {
			u(f, d, c);
		}
		h === null || !Number.isFinite(h) || !Number.isFinite(r) ? m.push({
			x: NaN,
			y: null,
			theta: r
		}) : m.push({
			x: h * Math.cos(r),
			y: h * Math.sin(r),
			theta: r
		});
	}
	return {
		points: m,
		endpoint: m.at(-1)?.y ?? null
	};
}
function p(e, t, n, r, i, a) {
	let o = n - a, s = o === 0 ? .5 : Math.max(0, Math.min(1, n / o));
	return {
		x: e + (r - e) * s,
		y: t + (i - t) * s
	};
}
function m(e, t) {
	switch (e) {
		case 1: return [[3, 0]];
		case 2: return [[0, 1]];
		case 3: return [[3, 1]];
		case 4: return [[1, 2]];
		case 5: return t ? [[0, 1], [2, 3]] : [[3, 0], [1, 2]];
		case 6: return [[0, 2]];
		case 7: return [[3, 2]];
		case 8: return [[2, 3]];
		case 9: return [[0, 2]];
		case 10: return t ? [[3, 0], [1, 2]] : [[0, 1], [2, 3]];
		case 11: return [[1, 2]];
		case 12: return [[3, 1]];
		case 13: return [[0, 1]];
		case 14: return [[3, 0]];
		default: return [];
	}
}
function h(e, t, n, r, i) {
	if (e.length === 0) return [];
	let a = n - t || 1, o = i - r || 1, s = (e) => `${Math.round((e.x - t) / a * 1e7)},${Math.round((e.y - r) / o * 1e7)}`, c = /* @__PURE__ */ new Map(), l = (e, t) => {
		let n = c.get(e);
		n ? n.push(t) : c.set(e, [t]);
	};
	e.forEach((e, t) => {
		l(s(e.a), t), l(s(e.b), t);
	});
	let u = new Uint8Array(e.length), d = [], f = (t, n) => {
		let r = c.get(s(n));
		if (!r) return !1;
		for (let i of r) {
			if (u[i]) continue;
			let r = e[i], a = s(r.a) === s(n) ? r.b : r.a;
			if (s(a) === s(n)) u[i] = 1;
			else return u[i] = 1, t.push(a), !0;
		}
		return !1;
	};
	for (let t = 0; t < e.length; t += 1) {
		if (u[t]) continue;
		let n = e[t];
		if (s(n.a) === s(n.b)) {
			u[t] = 1;
			continue;
		}
		u[t] = 1;
		let r = [n.a, n.b], i = 0;
		for (; i < e.length && f(r, r[r.length - 1]);) i += 1;
		for (r.reverse(), i = 0; i < e.length && f(r, r[r.length - 1]);) i += 1;
		r.reverse(), d.push(r);
	}
	return d;
}
function g(t, n, a, o, s, d, f = 100, g) {
	if (c(a, o, f, 100), !Number.isFinite(s) || !Number.isFinite(d) || !(s < d)) throw new e("latex-plot-range", "The vertical plot range must be finite and increasing.", 0);
	let _ = {
		steps: 0,
		limit: Math.max(r, f * f * 2048)
	}, v = f + 1, y = Array(v * v).fill(null), b = (o - a) / f, x = (d - s) / f;
	for (let e = 0; e <= f; e += 1) {
		let r = e === f ? d : s + e * x, c = {
			...n,
			y: r
		};
		for (let n = 0; n <= f; n += 1) {
			let r = n === f ? o : a + n * b, s = l(_, g), d = null;
			try {
				d = i(t, r, c, s);
			} finally {
				u(_, g, s);
			}
			y[e * v + n] = d !== null && Number.isFinite(d) ? d : null;
		}
	}
	let S = [], C = (e, t) => y[t * v + e];
	for (let e = 0; e < f; e += 1) {
		let t = e + 1 === f, n = t ? d - x : s + e * x, r = t ? d : s + (e + 1) * x;
		for (let t = 0; t < f; t += 1) {
			let i = t + 1 === f, s = i ? o - b : a + t * b, c = i ? o : a + (t + 1) * b, l = C(t, e), u = C(t + 1, e), d = C(t + 1, e + 1), h = C(t, e + 1);
			if (l === null || u === null || d === null || h === null) continue;
			let g = l >= 0 | (u >= 0 ? 2 : 0) | (d >= 0 ? 4 : 0) | (h >= 0 ? 8 : 0);
			if (g === 0 || g === 15) continue;
			let _ = [
				p(s, n, l, c, n, u),
				p(c, n, u, c, r, d),
				p(s, r, h, c, r, d),
				p(s, n, l, s, r, h)
			], v = (l + u + d + h) / 4;
			for (let [e, t] of m(g, v >= 0)) S.push({
				a: _[e],
				b: _[t]
			});
		}
	}
	return h(S, a, o, s, d);
}
export { f as i, d as n, s as r, g as t };
