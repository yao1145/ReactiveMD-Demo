import { type ReactiveMDMountOptions, type StandaloneHostHooks } from './session-core.js';
export { isReactiveMDMounted, REACTIVE_MD_MOUNTED_ATTRIBUTE } from './session-core.js';
export type { ReactiveMDMountOptions, ReactiveMDHandle, StandaloneHostHooks } from './session-core.js';
export declare function createStandaloneMount(element: HTMLElement, options: ReactiveMDMountOptions, hooks?: StandaloneHostHooks): import("./session-core.js").ReactiveMDHandle;
export declare function mount(element: HTMLElement, options: ReactiveMDMountOptions): import("./session-core.js").ReactiveMDHandle;
export declare function mountAll(root?: ParentNode, host?: Pick<ReactiveMDMountOptions, 'reactConfig'>): import("./session-core.js").ReactiveMDHandle[];
