import type { LocalConfig } from '../sdk/types.js';
import { type CreateLocalReactConfigOptions } from './sdk-core.js';
export * from './sdk-core.js';
export declare function createReactConfig(input: LocalConfig, options: CreateLocalReactConfigOptions): import("./sdk-core.js").LocalReactConfig;
