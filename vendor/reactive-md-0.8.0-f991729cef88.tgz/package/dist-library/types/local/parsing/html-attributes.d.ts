interface HtmlAttributeValue {
    name: string;
    value: string;
    start: number;
    end: number;
}
interface HtmlAttributeScan {
    attrs: Record<string, string>;
    entries: HtmlAttributeValue[];
    invalid: HtmlAttributeValue[];
}
/** Attribute values are raw decoded strings; the source is never executed. */
export declare function scanHtmlAttributes(raw: string, offset: number, decode: (value: string) => string): HtmlAttributeScan;
export {};
