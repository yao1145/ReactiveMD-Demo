import { n as e } from "./sdk-core-CIxdxzII.js";
import { a as t } from "./LocalDocumentView-D6m6ImeU.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
