import { a as e, c as t, o as n } from "./math-6b-qdjqP.js";
import { n as r, t as i } from "./compiler-core-C83OmA9k.js";
import { n as a } from "./math-display-DlaL4Zrf.js";
import { o } from "./parser-standard-BPdDQopN.js";
import { n as s, t as c } from "./options-DiCwIp4Z.js";
// src/local/compilation/compiler.ts
function l(e, t) {
	return r(p(e, t));
}
function u(e, t, n) {
	let r, i = () => globalThis.performance?.now?.() ?? Date.now(), a = i(), o = {}, s = a, l = (e) => {
		let t = i();
		o[e] = t - s, s = t;
	};
	n?.semantic?.begin(c(t));
	let u = p(e, t, (e) => {
		r = e;
	}, n, l);
	return o.totalMs = i() - a, {
		result: u,
		parsed: r,
		...n?.semantic ? { semantic: n.semantic.stats } : {},
		timings: o
	};
}
function d(e) {
	return {
		ok: !1,
		diagnostics: [{
			code: "local.options.invalid",
			message: e.message,
			severity: "error",
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: e.key,
			...e.detail === void 0 ? {} : { params: { detail: e.detail } }
		}]
	};
}
function f(r) {
	return {
		...r?.parser ? { parser: r.parser } : {},
		...r?.semantic ? { semantic: r.semantic } : {},
		...r?.rowPlans ? { rowPlans: r.rowPlans } : {},
		display: r?.semantic ? (e, t) => r.semantic.display(e, t) : a,
		htmlDocument: o,
		plotMath: {
			kind: t,
			gridSize: n,
			compile: e
		}
	};
}
function p(e, t, n, r, a) {
	let o = s(t);
	return o.ok ? i(e, t, o, f(r), n, a) : d(o);
}
export { u as n, l as t };
