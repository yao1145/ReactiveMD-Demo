import { f as e, l as t } from "./math-6b-qdjqP.js";
import { Q as n } from "./preset-core-CKc5YXSM.js";
import { a as r, c as i, d as a, i as o, l as s, o as c, s as l, u } from "./compiler-core-C83OmA9k.js";
import { E as d, I as f, T as p, k as m } from "./config-validation-BLmgvFIS.js";
import { S as h, Z as g, n as _ } from "./validation-BPmsZ5G9.js";
import { a as v, o as y } from "./parser-standard-BPdDQopN.js";
import { C as b, l as x, s as S, x as C } from "./config-C7nMEidX.js";
import { n as w } from "./registry-B-xSD10y.js";
import { n as T, t as E } from "./options-DiCwIp4Z.js";
import { n as D } from "./incremental-DTyqwPeo.js";
import { n as O, r as k, t as A } from "./runtime-1Dz-JXJE.js";
import { r as ee } from "./resources-85Qoj6wA.js";
import { o as j, r as M, s as N, t as P } from "./sdk-core-CIxdxzII.js";
import { n as F, r as I, t as L } from "./visual-frame-CR6J1ymw.js";
import { r as te } from "./component-utils-BM3NsGM6.js";
import { n as ne, t as re } from "./tooltip-layer-HDLrSWs0.js";
import { Component as ie, Fragment as ae, createContext as oe, createElement as R, memo as se, useCallback as z, useContext as ce, useEffect as B, useId as le, useMemo as V, useRef as H, useState as U, useSyncExternalStore as ue } from "react";
import { Fragment as de, jsx as W, jsxs as G } from "react/jsx-runtime";
import { createPortal as fe } from "react-dom";
// src/local/rendering/use-color-scheme.ts
var pe = "(prefers-color-scheme: dark)";
function K(e) {
	return e === "light" || e === "dark" ? e : null;
}
function me(e) {
	let t = K(e.getAttribute("data-theme"));
	if (t) return t;
	let n = e.parentElement;
	for (; n;) {
		let e = K(n.getAttribute("data-color-scheme")) ?? K(n.getAttribute("data-theme"));
		if (e) return e;
		n = n.parentElement;
	}
	return null;
}
function q() {
	if (typeof window > "u" || typeof window.matchMedia != "function") return null;
	try {
		return window.matchMedia(pe).matches ? "dark" : "light";
	} catch {
		return null;
	}
}
function he(e, t) {
	let n = K(t), [r, i] = U("light");
	return B(() => {
		if (n) {
			i(n);
			return;
		}
		let t = e.current;
		if (!t || typeof window > "u") {
			i("light");
			return;
		}
		let r = () => i(me(t) ?? q() ?? "light");
		r();
		let a = [];
		if (typeof MutationObserver == "function") try {
			let e = (e, t) => {
				let n = new MutationObserver(r);
				n.observe(e, {
					attributes: !0,
					attributeFilter: t
				}), a.push(n);
			};
			e(t, ["data-theme"]);
			let n = t.parentElement;
			for (; n;) e(n, ["data-color-scheme", "data-theme"]), n = n.parentElement;
		} catch {
			for (let e of a) e.disconnect();
			a = [];
		}
		let o = () => r(), s = null;
		if (typeof window.matchMedia == "function") try {
			s = window.matchMedia(pe), typeof s.addEventListener == "function" ? s.addEventListener("change", o) : typeof s.addListener == "function" && s.addListener(o);
		} catch {
			s = null;
		}
		return () => {
			for (let e of a) e.disconnect();
			s && (typeof s.removeEventListener == "function" ? s.removeEventListener("change", o) : typeof s.removeListener == "function" && s.removeListener(o));
		};
	}, [n, e]), n ?? r;
}
// src/react/overflow-text-tooltip.tsx
function J(e) {
	let t = e.getAttribute("data-rmd-overflow-text");
	return t === null ? typeof HTMLElement < "u" && e instanceof HTMLElement ? e.innerText.trim() : (e.textContent ?? "").trim() : t.trim();
}
function ge(e) {
	return e.hasAttribute("data-rmd-overflow-text") ? !0 : getComputedStyle(e).textOverflow === "ellipsis" && e.clientWidth > 0 && e.scrollWidth > e.clientWidth + 1;
}
function _e(e, t) {
	if (!(t instanceof Element) || !e.contains(t) || t.closest(".local-tooltip")) return null;
	if (t instanceof HTMLInputElement || t instanceof HTMLTextAreaElement || t instanceof HTMLSelectElement) {
		for (let e of t.labels ?? []) for (let t of [e, ...e.querySelectorAll("*")]) if (ge(t) && J(t)) return {
			anchor: t,
			text: J(t)
		};
	}
	for (let n = t; n && n !== e; n = n.parentElement) {
		if (ge(n) && J(n)) return {
			anchor: n,
			text: J(n)
		};
		if (n.matches("button, label, [role=\"option\"], [role=\"radio\"], [tabindex]")) {
			for (let e of n.querySelectorAll("*")) if (ge(e) && J(e)) return {
				anchor: e,
				text: J(e)
			};
		}
	}
	return null;
}
function Y({ rootRef: e, enabled: t }) {
	let n = `${le()}-overflow-text`, r = H(null), [i, a] = U(null), [o, s] = U({
		left: 8,
		top: 8,
		ready: !1
	});
	return ne(r, t && i !== null), B(() => {
		let i = e.current;
		if (!i || !t) return;
		let o = null, c = null, l = null, u = null, d, f, p = !1, m = /* @__PURE__ */ new Map(), h = () => {
			if (clearTimeout(d), clearTimeout(f), l) {
				let e = (l.getAttribute("aria-describedby") ?? "").split(/\s+/).filter((e) => e && e !== n);
				e.length ? l.setAttribute("aria-describedby", e.join(" ")) : l.removeAttribute("aria-describedby");
			}
			l = null;
			for (let [e, t] of m) e.hasAttribute("title") || e.setAttribute("title", t);
			m.clear(), o = null, c = null, p || a(null);
		}, g = () => {
			clearTimeout(f), f = setTimeout(h, 100);
		}, _ = (e) => {
			if (e instanceof Node && r.current?.contains(e)) {
				clearTimeout(f);
				return;
			}
			let t = _e(i, e);
			t ? (clearTimeout(f), o?.anchor !== t.anchor && c !== t.anchor && (h(), c = t.anchor, d = setTimeout(() => {
				if (!i.contains(t.anchor) || !ge(t.anchor)) return;
				o = {
					anchor: t.anchor,
					text: J(t.anchor)
				}, c = null;
				let e = t.anchor.closest("label");
				l = t.anchor.closest("button, input, [role=\"option\"], [role=\"radio\"], [tabindex]") ?? e?.control ?? t.anchor;
				let r = (l.getAttribute("aria-describedby") ?? "").split(/\s+/).filter(Boolean);
				l.setAttribute("aria-describedby", [.../* @__PURE__ */ new Set([...r, n])].join(" "));
				for (let e = t.anchor; e && e !== i; e = e.parentElement) {
					let t = e.getAttribute("title");
					t !== null && (m.set(e, t), e.removeAttribute("title"));
				}
				s({
					left: 8,
					top: 8,
					ready: !1
				}), a(o);
			}, 180))) : g();
		}, v = (e) => {
			u !== document.activeElement && _(e.target);
		}, y = (e) => {
			u = e.target instanceof Element ? e.target : null, _(e.target);
		}, b = (e) => {
			u && (e.movementX || e.movementY) && (u = null, _(e.target));
		}, x = (e) => {
			let t = e.relatedTarget;
			t instanceof Node && (o?.anchor.contains(t) || r.current?.contains(t)) || g();
		}, S = (e) => {
			u !== document.activeElement && x(e);
		}, C = (e) => {
			u = null, x(e);
		}, w = (e) => {
			e.key === "Escape" && h();
		}, T = (e) => {
			if (!(e.target instanceof Node && r.current?.contains(e.target))) {
				if (c) {
					let e = c.getBoundingClientRect();
					if (e.bottom > 0 && e.top < window.innerHeight && e.right > 0 && e.left < window.innerWidth) return;
				}
				h();
			}
		}, E = new MutationObserver(() => {
			o && (!i.contains(o.anchor) || o.anchor.getClientRects().length === 0 || J(o.anchor) !== o.text) && h();
		});
		return E.observe(i, {
			childList: !0,
			characterData: !0,
			subtree: !0,
			attributes: !0,
			attributeFilter: ["hidden", "aria-hidden"]
		}), i.addEventListener("mouseover", v), i.addEventListener("mousemove", b), i.addEventListener("mouseout", S), i.addEventListener("focusin", y), i.addEventListener("focusout", C), window.addEventListener("keydown", w, !0), i.addEventListener("scroll", T, !0), window.addEventListener("resize", h), window.addEventListener("scroll", T, !0), () => {
			p = !0, h(), E.disconnect(), i.removeEventListener("mouseover", v), i.removeEventListener("mousemove", b), i.removeEventListener("mouseout", S), i.removeEventListener("focusin", y), i.removeEventListener("focusout", C), window.removeEventListener("keydown", w, !0), i.removeEventListener("scroll", T, !0), window.removeEventListener("resize", h), window.removeEventListener("scroll", T, !0);
		};
	}, [
		t,
		n,
		e
	]), re(() => {
		if (!i || !r.current) return;
		let e = i.anchor.getBoundingClientRect(), t = r.current.getBoundingClientRect(), n = Math.max(8, Math.min(e.left, window.innerWidth - t.width - 8)), a = e.bottom + 8, o = a + t.height <= window.innerHeight - 8 ? a : Math.max(8, e.top - t.height - 8);
		s({
			left: n,
			top: o,
			ready: !0
		});
	}, [i]), !t || !i ? null : /* @__PURE__ */ W("div", {
		ref: r,
		id: n,
		role: "tooltip",
		popover: "manual",
		className: "rmd-overflow-tooltip",
		"data-rmd-overflow-tooltip": "",
		style: {
			left: o.left,
			top: o.top,
			visibility: o.ready ? "visible" : "hidden"
		},
		children: i.text
	});
}
// src/local/rendering/view-revision.ts
function ve(e) {
	return Array.isArray(e) ? `a[${e.map((e) => JSON.stringify(e)).join(",")}]` : `${typeof e}:${JSON.stringify(e)}`;
}
function ye(e, t) {
	let n = "", r = e.initialState ?? {};
	for (let e of Object.keys(r).sort()) n += `${e}=${ve(r[e])}\u0001`;
	let i = "", a = e.computations ?? {};
	for (let e of Object.keys(a).sort()) {
		let t = a[e];
		t && (i += `${e}\u0000${t.kind}\u0000${t.source}\u0000${ve(t.value)}\u0002`);
	}
	let o = JSON.stringify([...l(e, t)].sort(([e], [t]) => e.localeCompare(t)));
	return `${n}\u0003${i}\u0003${o}`;
}
function be(e, t) {
	let n = [], r = l(e, t);
	for (let t of g(e.nodes)) {
		let e = t.type === "component" || t.type === "hostComponent", i = !e && typeof t.attrs?.id == "string", a = e ? r.get(t.name ?? "") : void 0, o = a !== void 0 && typeof t.attrs?.[a] == "string";
		(t.type === "heading" || i || o) && n.push(t);
	}
	return {
		nodes: n,
		metadata: ye(e, t)
	};
}
function xe(e, t) {
	if (e.metadata !== t.metadata || e.nodes.length !== t.nodes.length) return !1;
	for (let n = 0; n < e.nodes.length; n += 1) if (e.nodes[n] !== t.nodes[n]) return !1;
	return !0;
}
function Se(e) {
	let t = [];
	for (let n of g(e.nodes)) (n.type === "footnoteDefinition" || n.type === "footnoteReference") && t.push(n);
	return { nodes: t };
}
function Ce(e, t) {
	if (e.nodes.length !== t.nodes.length) return !1;
	for (let n = 0; n < e.nodes.length; n += 1) if (e.nodes[n] !== t.nodes[n]) return !1;
	return !0;
}
function we(e) {
	let t = Array.isArray(e.validations) ? e.validations : [], n = "";
	for (let e of t) n += `${e.nodeId}\u0000${e.expression}\u0000${e.message}\u0000${(e.fields ?? []).join(",")}\u0001`;
	n += "";
	for (let t of Object.keys(e.bindings).sort()) {
		let r = e.bindings[t];
		n += `${t}\u0000${r.type}\u0000${(r.nodeIds ?? []).join(",")}\u0000${(r.options ?? []).join(",")}\u0003`;
	}
	return n;
}
function Te(e, t) {
	let n = /* @__PURE__ */ new Map(), r = Array.isArray(e.validations) ? e.validations : [];
	for (let e = 0; e < r.length; e += 1) {
		let t = r[e].range;
		n.set(`${t.start}:${t.end}`, e);
	}
	return t.map((e) => `${n.get(`${e.range.start}:${e.range.end}`) ?? e.range.start}:${e.code}\u0000${e.message}`).join("");
}
function Ee(e, t) {
	if (e.node !== t.node || e.visible !== t.visible || e.resetToken !== t.resetToken || e.env !== t.env || e.depValues === null || t.depValues === null || e.depValues.length !== t.depValues.length) return !1;
	for (let n = 0; n < e.depValues.length; n += 1) if (!Object.is(e.depValues[n], t.depValues[n])) return !1;
	return !0;
}
// src/local/theme/i18n.tsx
var De = (e) => e, Oe = oe("en");
function ke({ locale: e = "en", children: t }) {
	return /* @__PURE__ */ W(Oe.Provider, {
		value: e,
		children: t
	});
}
function Ae() {
	return ce(Oe);
}
function je(e, t, n) {
	return e === "zh" ? n : t;
}
function Me() {
	let e = Ae();
	return V(() => (t, n) => je(e, t, n), [e]);
}
// src/local/widgets/table-numeric-columns.ts
var Ne = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/;
function Pe(e) {
	return e === null ? "" : typeof e == "string" ? e : typeof e == "number" ? Number.isFinite(e) ? String(e) : null : typeof e == "boolean" ? e ? "true" : "false" : null;
}
function Fe(e, t, n) {
	let r = "";
	for (let i of e ?? []) if (i.type === "text" || i.type === "inlineCode" || i.type === "code") r += i.value ?? "";
	else if (i.type === "interpolation") try {
		let e = Pe(t.evaluate((i.value ?? "").trim()));
		e === null ? n.error = !0 : r += e;
	} catch {
		n.error = !0;
	}
	else i.type === "inlineMath" || i.type === "math" ? r += i.value ?? "" : i.type === "image" ? r += i.alt ?? "" : i.children && i.children.length > 0 ? r += Fe(i.children, t, n) : i.value && (r += i.value);
	return r;
}
function Ie(e, t) {
	let n = e.children ?? [], r = n.filter((e) => !(e.type === "text" && !(e.value ?? "").trim()));
	if (r.length === 1 && r[0].type === "interpolation") try {
		let e = t.evaluate((r[0].value ?? "").trim());
		return {
			empty: !1,
			numeric: typeof e == "number" && Number.isFinite(e) ? e : null
		};
	} catch {
		return {
			empty: !1,
			numeric: null
		};
	}
	let i = { error: !1 }, a = Fe(n, t, i);
	if (r.length > 0 && r.every((e) => e.type === "text") && Ne.test(a.trim())) {
		let e = Number(a.trim());
		if (Number.isFinite(e)) return {
			empty: !1,
			numeric: e
		};
	}
	return !i.error && a.trim() === "" ? {
		empty: !0,
		numeric: null
	} : {
		empty: !1,
		numeric: null
	};
}
function Le(e, t, n = De) {
	let r = e[0]?.length ?? 0;
	if (!e.every((e) => e.length === r)) return Array(r).fill(!1);
	let i = e.map((e) => e.map((e) => {
		let n = e.children ?? [], r = n.length === 1 && n[0].type === "paragraph" ? n[0].children ?? [] : n;
		return Ie({
			...e,
			children: r
		}, t);
	}));
	return Array.from({ length: r }, (e, t) => {
		let n = !1;
		for (let e of i) {
			let r = e[t];
			if (r && !r.empty) {
				if (r.numeric === null) return !1;
				n = !0;
			}
		}
		return n;
	});
}
// node_modules/highlight.js/es/languages/django.js
function Re(e) {
	let t = {
		begin: /\|[A-Za-z]+:?/,
		keywords: { name: "truncatewords removetags linebreaksbr yesno get_digit timesince random striptags filesizeformat escape linebreaks length_is ljust rjust cut urlize fix_ampersands title floatformat capfirst pprint divisibleby add make_list unordered_list urlencode timeuntil urlizetrunc wordcount stringformat linenumbers slice date dictsort dictsortreversed default_if_none pluralize lower join center default truncatewords_html upper length phone2numeric wordwrap time addslashes slugify first escapejs force_escape iriencode last safe safeseq truncatechars localize unlocalize localtime utc timezone" },
		contains: [e.QUOTE_STRING_MODE, e.APOS_STRING_MODE]
	};
	return {
		name: "Django",
		aliases: ["jinja"],
		case_insensitive: !0,
		subLanguage: "xml",
		contains: [
			e.COMMENT(/\{%\s*comment\s*%\}/, /\{%\s*endcomment\s*%\}/),
			e.COMMENT(/\{#/, /#\}/),
			{
				className: "template-tag",
				begin: /\{%/,
				end: /%\}/,
				contains: [{
					className: "name",
					begin: /\w+/,
					keywords: { name: "comment endcomment load templatetag ifchanged endifchanged if endif firstof for endfor ifnotequal endifnotequal widthratio extends include spaceless endspaceless regroup ifequal endifequal ssi now with cycle url filter endfilter debug block endblock else autoescape endautoescape csrf_token empty elif endwith static trans blocktrans endblocktrans get_static_prefix get_media_prefix plural get_current_language language get_available_languages get_current_language_bidi get_language_info get_language_info_list localize endlocalize localtime endlocaltime timezone endtimezone get_current_timezone verbatim" },
					starts: {
						endsWithParent: !0,
						keywords: "in by as",
						contains: [t],
						relevance: 0
					}
				}]
			},
			{
				className: "template-variable",
				begin: /\{\{/,
				end: /\}\}/,
				contains: [t]
			}
		]
	};
}
// node_modules/highlight.js/es/languages/dockerfile.js
function ze(e) {
	return {
		name: "Dockerfile",
		aliases: ["docker"],
		case_insensitive: !0,
		keywords: [
			"from",
			"maintainer",
			"expose",
			"env",
			"arg",
			"user",
			"onbuild",
			"stopsignal"
		],
		contains: [
			e.HASH_COMMENT_MODE,
			e.APOS_STRING_MODE,
			e.QUOTE_STRING_MODE,
			e.NUMBER_MODE,
			{
				beginKeywords: "run cmd entrypoint volume add copy workdir label healthcheck shell",
				starts: {
					end: /[^\\]$/,
					subLanguage: "bash"
				}
			}
		],
		illegal: "</"
	};
}
// node_modules/highlight.js/es/languages/latex.js
function Be(e) {
	let t = e.regex.either(...[
		"(?:NeedsTeXFormat|RequirePackage|GetIdInfo)",
		"Provides(?:Expl)?(?:Package|Class|File)",
		"(?:DeclareOption|ProcessOptions)",
		"(?:documentclass|usepackage|input|include)",
		"makeat(?:letter|other)",
		"ExplSyntax(?:On|Off)",
		"(?:new|renew|provide)?command",
		"(?:re)newenvironment",
		"(?:New|Renew|Provide|Declare)(?:Expandable)?DocumentCommand",
		"(?:New|Renew|Provide|Declare)DocumentEnvironment",
		"(?:(?:e|g|x)?def|let)",
		"(?:begin|end)",
		"(?:part|chapter|(?:sub){0,2}section|(?:sub)?paragraph)",
		"caption",
		"(?:label|(?:eq|page|name)?ref|(?:paren|foot|super)?cite)",
		"(?:alpha|beta|[Gg]amma|[Dd]elta|(?:var)?epsilon|zeta|eta|[Tt]heta|vartheta)",
		"(?:iota|(?:var)?kappa|[Ll]ambda|mu|nu|[Xx]i|[Pp]i|varpi|(?:var)rho)",
		"(?:[Ss]igma|varsigma|tau|[Uu]psilon|[Pp]hi|varphi|chi|[Pp]si|[Oo]mega)",
		"(?:frac|sum|prod|lim|infty|times|sqrt|leq|geq|left|right|middle|[bB]igg?)",
		"(?:[lr]angle|q?quad|[lcvdi]?dots|d?dot|hat|tilde|bar)"
	].map((e) => e + "(?![a-zA-Z@:_])")), n = new RegExp([
		"(?:__)?[a-zA-Z]{2,}_[a-zA-Z](?:_?[a-zA-Z])+:[a-zA-Z]*",
		"[lgc]__?[a-zA-Z](?:_?[a-zA-Z])*_[a-zA-Z]{2,}",
		"[qs]__?[a-zA-Z](?:_?[a-zA-Z])+",
		"use(?:_i)?:[a-zA-Z]*",
		"(?:else|fi|or):",
		"(?:if|cs|exp):w",
		"(?:hbox|vbox):n",
		"::[a-zA-Z]_unbraced",
		"::[a-zA-Z:]"
	].map((e) => e + "(?![a-zA-Z:_])").join("|")), r = [{ begin: /[a-zA-Z@]+/ }, { begin: /[^a-zA-Z@]?/ }], i = [
		{ begin: /\^{6}[0-9a-f]{6}/ },
		{ begin: /\^{5}[0-9a-f]{5}/ },
		{ begin: /\^{4}[0-9a-f]{4}/ },
		{ begin: /\^{3}[0-9a-f]{3}/ },
		{ begin: /\^{2}[0-9a-f]{2}/ },
		{ begin: /\^{2}[\u0000-\u007f]/ }
	], a = [
		{
			className: "keyword",
			begin: /\\/,
			relevance: 0,
			contains: [
				{
					endsParent: !0,
					begin: t
				},
				{
					endsParent: !0,
					begin: n
				},
				{
					endsParent: !0,
					variants: i
				},
				{
					endsParent: !0,
					relevance: 0,
					variants: r
				}
			]
		},
		{
			className: "params",
			relevance: 0,
			begin: /#+\d?/
		},
		{ variants: i },
		{
			className: "built_in",
			relevance: 0,
			begin: /[$&^_]/
		},
		{
			className: "meta",
			begin: /% ?!(T[eE]X|tex|BIB|bib)/,
			end: "$",
			relevance: 10
		},
		e.COMMENT("%", "$", { relevance: 0 })
	], o = {
		begin: /\{/,
		end: /\}/,
		relevance: 0,
		contains: ["self", ...a]
	}, s = e.inherit(o, {
		relevance: 0,
		endsParent: !0,
		contains: [o, ...a]
	}), c = {
		begin: /\[/,
		end: /\]/,
		endsParent: !0,
		relevance: 0,
		contains: [o, ...a]
	}, l = {
		begin: /\s+/,
		relevance: 0
	}, u = [s], d = [c], f = function(e, t) {
		return {
			contains: [l],
			starts: {
				relevance: 0,
				contains: e,
				starts: t
			}
		};
	}, p = function(e, t) {
		return {
			begin: "\\\\" + e + "(?![a-zA-Z@:_])",
			keywords: {
				$pattern: /\\[a-zA-Z]+/,
				keyword: "\\" + e
			},
			relevance: 0,
			contains: [l],
			starts: t
		};
	}, m = function(t, n) {
		return e.inherit({
			begin: "\\\\begin(?=[ 	]*(\\r?\\n[ 	]*)?\\{" + t + "\\})",
			keywords: {
				$pattern: /\\[a-zA-Z]+/,
				keyword: "\\begin"
			},
			relevance: 0
		}, f(u, n));
	}, h = (t = "string") => e.END_SAME_AS_BEGIN({
		className: t,
		begin: /(.|\r?\n)/,
		end: /(.|\r?\n)/,
		excludeBegin: !0,
		excludeEnd: !0,
		endsParent: !0
	}), g = function(e) {
		return {
			className: "string",
			end: "(?=\\\\end\\{" + e + "\\})"
		};
	}, _ = (e = "string") => ({
		relevance: 0,
		begin: /\{/,
		starts: {
			endsParent: !0,
			contains: [{
				className: e,
				end: /(?=\})/,
				endsParent: !0,
				contains: [{
					begin: /\{/,
					end: /\}/,
					relevance: 0,
					contains: ["self"]
				}]
			}]
		}
	});
	return {
		name: "LaTeX",
		aliases: ["tex"],
		contains: [
			...["verb", "lstinline"].map((e) => p(e, { contains: [h()] })),
			p("mint", f(u, { contains: [h()] })),
			p("mintinline", f(u, { contains: [_(), h()] })),
			p("url", { contains: [_("link"), _("link")] }),
			p("hyperref", { contains: [_("link")] }),
			p("href", f(d, { contains: [_("link")] })),
			...[].concat(...["", "\\*"].map((e) => [
				m("verbatim" + e, g("verbatim" + e)),
				m("filecontents" + e, f(u, g("filecontents" + e))),
				...[
					"",
					"B",
					"L"
				].map((t) => m(t + "Verbatim" + e, f(d, g(t + "Verbatim" + e))))
			])),
			m("minted", f(d, f(u, g("minted")))),
			...a
		]
	};
}
// node_modules/highlight.js/es/languages/arduino.js
function Ve(e) {
	let t = e.regex, n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }), r = "[a-zA-Z_]\\w*::", i = "(?!struct)(decltype\\(auto\\)|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")", a = {
		className: "type",
		begin: "\\b[a-z\\d_]*_t\\b"
	}, o = {
		className: "string",
		variants: [
			{
				begin: "(u8?|U|L)?\"",
				end: "\"",
				illegal: "\\n",
				contains: [e.BACKSLASH_ESCAPE]
			},
			{
				begin: "(u8?|U|L)?'(\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)|.)",
				end: "'",
				illegal: "."
			},
			e.END_SAME_AS_BEGIN({
				begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
				end: /\)([^()\\ ]{0,16})"/
			})
		]
	}, s = {
		className: "number",
		variants: [{ begin: "[+-]?(?:(?:[0-9](?:'?[0-9])*\\.(?:[0-9](?:'?[0-9])*)?|\\.[0-9](?:'?[0-9])*)(?:[Ee][+-]?[0-9](?:'?[0-9])*)?|[0-9](?:'?[0-9])*[Ee][+-]?[0-9](?:'?[0-9])*|0[Xx](?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*(?:\\.(?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)?)?|\\.[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)[Pp][+-]?[0-9](?:'?[0-9])*)(?:[Ff](?:16|32|64|128)?|(BF|bf)16|[Ll]|)" }, { begin: "[+-]?\\b(?:0[Bb][01](?:'?[01])*|0[Xx][0-9A-Fa-f](?:'?[0-9A-Fa-f])*|0(?:'?[0-7])*|[1-9](?:'?[0-9])*)(?:[Uu](?:LL?|ll?)|[Uu][Zz]?|(?:LL?|ll?)[Uu]?|[Zz][Uu]|)" }],
		relevance: 0
	}, c = {
		className: "meta",
		begin: /#\s*[a-z]+\b/,
		end: /$/,
		keywords: { keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include" },
		contains: [
			{
				begin: /\\\n/,
				relevance: 0
			},
			e.inherit(o, { className: "string" }),
			{
				className: "string",
				begin: /<.*?>/
			},
			n,
			e.C_BLOCK_COMMENT_MODE
		]
	}, l = {
		className: "title",
		begin: t.optional(r) + e.IDENT_RE,
		relevance: 0
	}, u = t.optional(r) + e.IDENT_RE + "\\s*\\(", d = /* @__PURE__ */ "alignas.alignof.and.and_eq.asm.atomic_cancel.atomic_commit.atomic_noexcept.auto.bitand.bitor.break.case.catch.class.co_await.co_return.co_yield.compl.concept.const_cast|10.consteval.constexpr.constinit.continue.decltype.default.delete.do.dynamic_cast|10.else.enum.explicit.export.extern.false.final.for.friend.goto.if.import.inline.module.mutable.namespace.new.noexcept.not.not_eq.nullptr.operator.or.or_eq.override.private.protected.public.reflexpr.register.reinterpret_cast|10.requires.return.sizeof.static_assert.static_cast|10.struct.switch.synchronized.template.this.thread_local.throw.transaction_safe.transaction_safe_dynamic.true.try.typedef.typeid.typename.union.using.virtual.volatile.while.xor.xor_eq".split("."), f = [
		"bool",
		"char",
		"char16_t",
		"char32_t",
		"char8_t",
		"double",
		"float",
		"int",
		"long",
		"short",
		"void",
		"wchar_t",
		"unsigned",
		"signed",
		"const",
		"static"
	], p = /* @__PURE__ */ "any.auto_ptr.barrier.binary_semaphore.bitset.complex.condition_variable.condition_variable_any.counting_semaphore.deque.false_type.flat_map.flat_set.future.imaginary.initializer_list.istringstream.jthread.latch.lock_guard.multimap.multiset.mutex.optional.ostringstream.packaged_task.pair.promise.priority_queue.queue.recursive_mutex.recursive_timed_mutex.scoped_lock.set.shared_future.shared_lock.shared_mutex.shared_timed_mutex.shared_ptr.stack.string_view.stringstream.timed_mutex.thread.true_type.tuple.unique_lock.unique_ptr.unordered_map.unordered_multimap.unordered_multiset.unordered_set.variant.vector.weak_ptr.wstring.wstring_view".split("."), m = /* @__PURE__ */ "abort.abs.acos.apply.as_const.asin.atan.atan2.calloc.ceil.cerr.cin.clog.cos.cosh.cout.declval.endl.exchange.exit.exp.fabs.floor.fmod.forward.fprintf.fputs.free.frexp.fscanf.future.invoke.isalnum.isalpha.iscntrl.isdigit.isgraph.islower.isprint.ispunct.isspace.isupper.isxdigit.labs.launder.ldexp.log.log10.make_pair.make_shared.make_shared_for_overwrite.make_tuple.make_unique.malloc.memchr.memcmp.memcpy.memset.modf.move.pow.printf.putchar.puts.realloc.scanf.sin.sinh.snprintf.sprintf.sqrt.sscanf.std.stderr.stdin.stdout.strcat.strchr.strcmp.strcpy.strcspn.strlen.strncat.strncmp.strncpy.strpbrk.strrchr.strspn.strstr.swap.tan.tanh.terminate.to_underlying.tolower.toupper.vfprintf.visit.vprintf.vsprintf".split("."), h = {
		type: f,
		keyword: d,
		literal: [
			"NULL",
			"false",
			"nullopt",
			"nullptr",
			"true"
		],
		built_in: ["_Pragma"],
		_type_hints: p
	}, g = {
		className: "function.dispatch",
		relevance: 0,
		keywords: { _hint: m },
		begin: t.concat(/\b/, `(?!${d.join("|")})`, e.IDENT_RE, t.lookahead(/(<[^<>]+>|)\s*\(/))
	}, _ = [
		g,
		c,
		a,
		n,
		e.C_BLOCK_COMMENT_MODE,
		s,
		o
	], v = {
		variants: [
			{
				begin: /=/,
				end: /;/
			},
			{
				begin: /\(/,
				end: /\)/
			},
			{
				beginKeywords: "new throw return else",
				end: /;/
			}
		],
		keywords: h,
		contains: _.concat([{
			begin: /\(/,
			end: /\)/,
			keywords: h,
			contains: _.concat(["self"]),
			relevance: 0
		}]),
		relevance: 0
	}, y = {
		className: "function",
		begin: "(" + i + "[\\*&\\s]+)+" + u,
		returnBegin: !0,
		end: /[{;=]/,
		excludeEnd: !0,
		keywords: h,
		illegal: /[^\w\s\*&:<>.]/,
		contains: [
			{
				begin: "decltype\\(auto\\)",
				keywords: h,
				relevance: 0
			},
			{
				begin: u,
				returnBegin: !0,
				contains: [l],
				relevance: 0
			},
			{
				begin: /::/,
				relevance: 0
			},
			{
				begin: /:/,
				endsWithParent: !0,
				contains: [o, s]
			},
			{
				relevance: 0,
				match: /,/
			},
			{
				className: "params",
				begin: /\(/,
				end: /\)/,
				keywords: h,
				relevance: 0,
				contains: [
					n,
					e.C_BLOCK_COMMENT_MODE,
					o,
					s,
					a,
					{
						begin: /\(/,
						end: /\)/,
						keywords: h,
						relevance: 0,
						contains: [
							"self",
							n,
							e.C_BLOCK_COMMENT_MODE,
							o,
							s,
							a
						]
					}
				]
			},
			a,
			n,
			e.C_BLOCK_COMMENT_MODE,
			c
		]
	};
	return {
		name: "C++",
		aliases: [
			"cc",
			"c++",
			"h++",
			"hpp",
			"hh",
			"hxx",
			"cxx"
		],
		keywords: h,
		illegal: "</",
		classNameAliases: { "function.dispatch": "built_in" },
		contains: [].concat(v, y, g, _, [
			c,
			{
				begin: "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function|flat_map|flat_set)\\s*<(?!<)",
				end: ">",
				keywords: h,
				contains: ["self", a]
			},
			{
				begin: e.IDENT_RE + "::",
				keywords: h
			},
			{
				match: [
					/\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/,
					/\s+/,
					/\w+/
				],
				className: {
					1: "keyword",
					3: "title.class"
				}
			}
		])
	};
}
function He(e) {
	let t = {
		type: [
			"boolean",
			"byte",
			"word",
			"String"
		],
		built_in: /* @__PURE__ */ "KeyboardController.MouseController.SoftwareSerial.EthernetServer.EthernetClient.LiquidCrystal.RobotControl.GSMVoiceCall.EthernetUDP.EsploraTFT.HttpClient.RobotMotor.WiFiClient.GSMScanner.FileSystem.Scheduler.GSMServer.YunClient.YunServer.IPAddress.GSMClient.GSMModem.Keyboard.Ethernet.Console.GSMBand.Esplora.Stepper.Process.WiFiUDP.GSM_SMS.Mailbox.USBHost.Firmata.PImage.Client.Server.GSMPIN.FileIO.Bridge.Serial.EEPROM.Stream.Mouse.Audio.Servo.File.Task.GPRS.WiFi.Wire.TFT.GSM.SPI.SD".split("."),
		_hints: /* @__PURE__ */ "setup.loop.runShellCommandAsynchronously.analogWriteResolution.retrieveCallingNumber.printFirmwareVersion.analogReadResolution.sendDigitalPortPair.noListenOnLocalhost.readJoystickButton.setFirmwareVersion.readJoystickSwitch.scrollDisplayRight.getVoiceCallStatus.scrollDisplayLeft.writeMicroseconds.delayMicroseconds.beginTransmission.getSignalStrength.runAsynchronously.getAsynchronously.listenOnLocalhost.getCurrentCarrier.readAccelerometer.messageAvailable.sendDigitalPorts.lineFollowConfig.countryNameWrite.runShellCommand.readStringUntil.rewindDirectory.readTemperature.setClockDivider.readLightSensor.endTransmission.analogReference.detachInterrupt.countryNameRead.attachInterrupt.encryptionType.readBytesUntil.robotNameWrite.readMicrophone.robotNameRead.cityNameWrite.userNameWrite.readJoystickY.readJoystickX.mouseReleased.openNextFile.scanNetworks.noInterrupts.digitalWrite.beginSpeaker.mousePressed.isActionDone.mouseDragged.displayLogos.noAutoscroll.addParameter.remoteNumber.getModifiers.keyboardRead.userNameRead.waitContinue.processInput.parseCommand.printVersion.readNetworks.writeMessage.blinkVersion.cityNameRead.readMessage.setDataMode.parsePacket.isListening.setBitOrder.beginPacket.isDirectory.motorsWrite.drawCompass.digitalRead.clearScreen.serialEvent.rightToLeft.setTextSize.leftToRight.requestFrom.keyReleased.compassRead.analogWrite.interrupts.WiFiServer.disconnect.playMelody.parseFloat.autoscroll.getPINUsed.setPINUsed.setTimeout.sendAnalog.readSlider.analogRead.beginWrite.createChar.motorsStop.keyPressed.tempoWrite.readButton.subnetMask.debugPrint.macAddress.writeGreen.randomSeed.attachGPRS.readString.sendString.remotePort.releaseAll.mouseMoved.background.getXChange.getYChange.answerCall.getResult.voiceCall.endPacket.constrain.getSocket.writeJSON.getButton.available.connected.findUntil.readBytes.exitValue.readGreen.writeBlue.startLoop.IPAddress.isPressed.sendSysex.pauseMode.gatewayIP.setCursor.getOemKey.tuneWrite.noDisplay.loadImage.switchPIN.onRequest.onReceive.changePIN.playFile.noBuffer.parseInt.overflow.checkPIN.knobRead.beginTFT.bitClear.updateIR.bitWrite.position.writeRGB.highByte.writeRed.setSpeed.readBlue.noStroke.remoteIP.transfer.shutdown.hangCall.beginSMS.endWrite.attached.maintain.noCursor.checkReg.checkPUK.shiftOut.isValid.shiftIn.pulseIn.connect.println.localIP.pinMode.getIMEI.display.noBlink.process.getBand.running.beginSD.drawBMP.lowByte.setBand.release.bitRead.prepare.pointTo.readRed.setMode.noFill.remove.listen.stroke.detach.attach.noTone.exists.buffer.height.bitSet.circle.config.cursor.random.IRread.setDNS.endSMS.getKey.micros.millis.begin.print.write.ready.flush.width.isPIN.blink.clear.press.mkdir.rmdir.close.point.yield.image.BSSID.click.delay.read.text.move.peek.beep.rect.line.open.seek.fill.size.turn.stop.home.find.step.tone.sqrt.RSSI.SSID.end.bit.tan.cos.sin.pow.map.abs.max.min.get.run.put".split("."),
		literal: [
			"DIGITAL_MESSAGE",
			"FIRMATA_STRING",
			"ANALOG_MESSAGE",
			"REPORT_DIGITAL",
			"REPORT_ANALOG",
			"INPUT_PULLUP",
			"SET_PIN_MODE",
			"INTERNAL2V56",
			"SYSTEM_RESET",
			"LED_BUILTIN",
			"INTERNAL1V1",
			"SYSEX_START",
			"INTERNAL",
			"EXTERNAL",
			"DEFAULT",
			"OUTPUT",
			"INPUT",
			"HIGH",
			"LOW"
		]
	}, n = Ve(e), r = n.keywords;
	return r.type = [...r.type, ...t.type], r.literal = [...r.literal, ...t.literal], r.built_in = [...r.built_in, ...t.built_in], r._hints = t._hints, n.name = "Arduino", n.aliases = ["ino"], n.supersetOf = "cpp", n;
}
// node_modules/highlight.js/es/languages/bash.js
function Ue(e) {
	let t = e.regex, n = {}, r = {
		begin: /\$\{/,
		end: /\}/,
		contains: ["self", {
			begin: /:-/,
			contains: [n]
		}]
	};
	Object.assign(n, {
		className: "variable",
		variants: [{ begin: t.concat(/\$[\w\d#@][\w\d_]*/, "(?![\\w\\d])(?![$])") }, r]
	});
	let i = {
		className: "subst",
		begin: /\$\(/,
		end: /\)/,
		contains: [e.BACKSLASH_ESCAPE]
	}, a = e.inherit(e.COMMENT(), {
		match: [/(^|\s)/, /#.*$/],
		scope: { 2: "comment" }
	}), o = {
		begin: /<<-?\s*(?=\w+)/,
		starts: { contains: [e.END_SAME_AS_BEGIN({
			begin: /(\w+)/,
			end: /(\w+)/,
			className: "string"
		})] }
	}, s = {
		className: "string",
		begin: /"/,
		end: /"/,
		contains: [
			e.BACKSLASH_ESCAPE,
			n,
			i
		]
	};
	i.contains.push(s);
	let c = { match: /\\"/ }, l = {
		className: "string",
		begin: /'/,
		end: /'/
	}, u = { match: /\\'/ }, d = {
		begin: /\$?\(\(/,
		end: /\)\)/,
		contains: [
			{
				begin: /\d+#[0-9a-f]+/,
				className: "number"
			},
			e.NUMBER_MODE,
			n
		]
	}, f = e.SHEBANG({
		binary: "(fish|bash|zsh|sh|csh|ksh|tcsh|dash|scsh)",
		relevance: 10
	}), p = {
		className: "function",
		begin: /\w[\w\d_]*\s*\(\s*\)\s*\{/,
		returnBegin: !0,
		contains: [e.inherit(e.TITLE_MODE, { begin: /\w[\w\d_]*/ })],
		relevance: 0
	}, m = [
		"if",
		"then",
		"else",
		"elif",
		"fi",
		"time",
		"for",
		"while",
		"until",
		"in",
		"do",
		"done",
		"case",
		"esac",
		"coproc",
		"function",
		"select"
	], h = ["true", "false"], g = { match: /(\/[a-z._-]+)+/ }, _ = [
		"break",
		"cd",
		"continue",
		"eval",
		"exec",
		"exit",
		"export",
		"getopts",
		"hash",
		"pwd",
		"readonly",
		"return",
		"shift",
		"test",
		"times",
		"trap",
		"umask",
		"unset"
	], v = [
		"alias",
		"bind",
		"builtin",
		"caller",
		"command",
		"declare",
		"echo",
		"enable",
		"help",
		"let",
		"local",
		"logout",
		"mapfile",
		"printf",
		"read",
		"readarray",
		"source",
		"sudo",
		"type",
		"typeset",
		"ulimit",
		"unalias"
	], y = /* @__PURE__ */ "autoload.bg.bindkey.bye.cap.chdir.clone.comparguments.compcall.compctl.compdescribe.compfiles.compgroups.compquote.comptags.comptry.compvalues.dirs.disable.disown.echotc.echoti.emulate.fc.fg.float.functions.getcap.getln.history.integer.jobs.kill.limit.log.noglob.popd.print.pushd.pushln.rehash.sched.setcap.setopt.stat.suspend.ttyctl.unfunction.unhash.unlimit.unsetopt.vared.wait.whence.where.which.zcompile.zformat.zftp.zle.zmodload.zparseopts.zprof.zpty.zregexparse.zsocket.zstyle.ztcp".split("."), b = /* @__PURE__ */ "chcon.chgrp.chown.chmod.cp.dd.df.dir.dircolors.ln.ls.mkdir.mkfifo.mknod.mktemp.mv.realpath.rm.rmdir.shred.sync.touch.truncate.vdir.b2sum.base32.base64.cat.cksum.comm.csplit.cut.expand.fmt.fold.head.join.md5sum.nl.numfmt.od.paste.ptx.pr.sha1sum.sha224sum.sha256sum.sha384sum.sha512sum.shuf.sort.split.sum.tac.tail.tr.tsort.unexpand.uniq.wc.arch.basename.chroot.date.dirname.du.echo.env.expr.factor.groups.hostid.id.link.logname.nice.nohup.nproc.pathchk.pinky.printenv.printf.pwd.readlink.runcon.seq.sleep.stat.stdbuf.stty.tee.test.timeout.tty.uname.unlink.uptime.users.who.whoami.yes".split(".");
	return {
		name: "Bash",
		aliases: ["sh", "zsh"],
		keywords: {
			$pattern: /\b[a-z][a-z0-9._-]+\b/,
			keyword: m,
			literal: h,
			built_in: [
				..._,
				...v,
				"set",
				"shopt",
				...y,
				...b
			]
		},
		contains: [
			f,
			e.SHEBANG(),
			p,
			d,
			a,
			o,
			g,
			s,
			c,
			l,
			u,
			n
		]
	};
}
// node_modules/highlight.js/es/languages/c.js
function We(e) {
	let t = e.regex, n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }), r = "[a-zA-Z_]\\w*::", i = "(decltype\\(auto\\)|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")", a = {
		className: "type",
		variants: [{ begin: "\\b[a-z\\d_]*_t\\b" }, { match: /\batomic_[a-z]{3,6}\b/ }]
	}, o = {
		className: "string",
		variants: [
			{
				begin: "(u8?|U|L)?\"",
				end: "\"",
				illegal: "\\n",
				contains: [e.BACKSLASH_ESCAPE]
			},
			{
				begin: "(u8?|U|L)?'(\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)|.)",
				end: "'",
				illegal: "."
			},
			e.END_SAME_AS_BEGIN({
				begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
				end: /\)([^()\\ ]{0,16})"/
			})
		]
	}, s = {
		className: "number",
		variants: [
			{ match: /\b(0b[01']+)/ },
			{ match: /(-?)\b([\d']+(\.[\d']*)?|\.[\d']+)((ll|LL|l|L)(u|U)?|(u|U)(ll|LL|l|L)?|f|F|b|B)/ },
			{ match: /(-?)\b(0[xX][a-fA-F0-9]+(?:'[a-fA-F0-9]+)*(?:\.[a-fA-F0-9]*(?:'[a-fA-F0-9]*)*)?(?:[pP][-+]?[0-9]+)?(l|L)?(u|U)?)/ },
			{ match: /(-?)\b\d+(?:'\d+)*(?:\.\d*(?:'\d*)*)?(?:[eE][-+]?\d+)?/ }
		],
		relevance: 0
	}, c = {
		className: "meta",
		begin: /#\s*[a-z]+\b/,
		end: /$/,
		keywords: { keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef elifdef elifndef include" },
		contains: [
			{
				begin: /\\\n/,
				relevance: 0
			},
			e.inherit(o, { className: "string" }),
			{
				className: "string",
				begin: /<.*?>/
			},
			n,
			e.C_BLOCK_COMMENT_MODE
		]
	}, l = {
		className: "title",
		begin: t.optional(r) + e.IDENT_RE,
		relevance: 0
	}, u = t.optional(r) + e.IDENT_RE + "\\s*\\(", d = {
		keyword: /* @__PURE__ */ "asm.auto.break.case.continue.default.do.else.enum.extern.for.fortran.goto.if.inline.register.restrict.return.sizeof.typeof.typeof_unqual.struct.switch.typedef.union.volatile.while._Alignas._Alignof._Atomic._Generic._Noreturn._Static_assert._Thread_local.alignas.alignof.noreturn.static_assert.thread_local._Pragma".split("."),
		type: /* @__PURE__ */ "float.double.signed.unsigned.int.short.long.char.void._Bool._BitInt._Complex._Imaginary._Decimal32._Decimal64._Decimal96._Decimal128._Decimal64x._Decimal128x._Float16._Float32._Float64._Float128._Float32x._Float64x._Float128x.const.static.constexpr.complex.bool.imaginary".split("."),
		literal: "true false NULL",
		built_in: "std string wstring cin cout cerr clog stdin stdout stderr stringstream istringstream ostringstream auto_ptr deque list queue stack vector map set pair bitset multiset multimap unordered_set unordered_map unordered_multiset unordered_multimap priority_queue make_pair array shared_ptr abort terminate abs acos asin atan2 atan calloc ceil cosh cos exit exp fabs floor fmod fprintf fputs free frexp fscanf future isalnum isalpha iscntrl isdigit isgraph islower isprint ispunct isspace isupper isxdigit tolower toupper labs ldexp log10 log malloc realloc memchr memcmp memcpy memset modf pow printf putchar puts scanf sinh sin snprintf sprintf sqrt sscanf strcat strchr strcmp strcpy strcspn strlen strncat strncmp strncpy strpbrk strrchr strspn strstr tanh tan vfprintf vprintf vsprintf endl initializer_list unique_ptr"
	}, f = [
		c,
		a,
		n,
		e.C_BLOCK_COMMENT_MODE,
		s,
		o
	], p = {
		variants: [
			{
				begin: /=/,
				end: /;/
			},
			{
				begin: /\(/,
				end: /\)/
			},
			{
				beginKeywords: "new throw return else",
				end: /;/
			}
		],
		keywords: d,
		contains: f.concat([{
			begin: /\(/,
			end: /\)/,
			keywords: d,
			contains: f.concat(["self"]),
			relevance: 0
		}]),
		relevance: 0
	}, m = {
		begin: "(" + i + "[\\*&\\s]+)+" + u,
		returnBegin: !0,
		end: /[{;=]/,
		excludeEnd: !0,
		keywords: d,
		illegal: /[^\w\s\*&:<>.]/,
		contains: [
			{
				begin: "decltype\\(auto\\)",
				keywords: d,
				relevance: 0
			},
			{
				begin: u,
				returnBegin: !0,
				contains: [e.inherit(l, { className: "title.function" })],
				relevance: 0
			},
			{
				relevance: 0,
				match: /,/
			},
			{
				className: "params",
				begin: /\(/,
				end: /\)/,
				keywords: d,
				relevance: 0,
				contains: [
					n,
					e.C_BLOCK_COMMENT_MODE,
					o,
					s,
					a,
					{
						begin: /\(/,
						end: /\)/,
						keywords: d,
						relevance: 0,
						contains: [
							"self",
							n,
							e.C_BLOCK_COMMENT_MODE,
							o,
							s,
							a
						]
					}
				]
			},
			a,
			n,
			e.C_BLOCK_COMMENT_MODE,
			c
		]
	};
	return {
		name: "C",
		aliases: ["h"],
		keywords: d,
		disableAutodetect: !0,
		illegal: "</",
		contains: [].concat(p, m, f, [
			c,
			{
				begin: e.IDENT_RE + "::",
				keywords: d
			},
			{
				className: "class",
				beginKeywords: "enum class struct union",
				end: /[{;:<>=]/,
				contains: [{ beginKeywords: "final class struct" }, e.TITLE_MODE]
			}
		]),
		exports: {
			preprocessor: c,
			strings: o,
			keywords: d
		}
	};
}
// node_modules/highlight.js/es/languages/cpp.js
function Ge(e) {
	let t = e.regex, n = e.COMMENT("//", "$", { contains: [{ begin: /\\\n/ }] }), r = "[a-zA-Z_]\\w*::", i = "(?!struct)(decltype\\(auto\\)|" + t.optional(r) + "[a-zA-Z_]\\w*" + t.optional("<[^<>]+>") + ")", a = {
		className: "type",
		begin: "\\b[a-z\\d_]*_t\\b"
	}, o = {
		className: "string",
		variants: [
			{
				begin: "(u8?|U|L)?\"",
				end: "\"",
				illegal: "\\n",
				contains: [e.BACKSLASH_ESCAPE]
			},
			{
				begin: "(u8?|U|L)?'(\\\\(x[0-9A-Fa-f]{2}|u[0-9A-Fa-f]{4,8}|[0-7]{3}|\\S)|.)",
				end: "'",
				illegal: "."
			},
			e.END_SAME_AS_BEGIN({
				begin: /(?:u8?|U|L)?R"([^()\\ ]{0,16})\(/,
				end: /\)([^()\\ ]{0,16})"/
			})
		]
	}, s = {
		className: "number",
		variants: [{ begin: "[+-]?(?:(?:[0-9](?:'?[0-9])*\\.(?:[0-9](?:'?[0-9])*)?|\\.[0-9](?:'?[0-9])*)(?:[Ee][+-]?[0-9](?:'?[0-9])*)?|[0-9](?:'?[0-9])*[Ee][+-]?[0-9](?:'?[0-9])*|0[Xx](?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*(?:\\.(?:[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)?)?|\\.[0-9A-Fa-f](?:'?[0-9A-Fa-f])*)[Pp][+-]?[0-9](?:'?[0-9])*)(?:[Ff](?:16|32|64|128)?|(BF|bf)16|[Ll]|)" }, { begin: "[+-]?\\b(?:0[Bb][01](?:'?[01])*|0[Xx][0-9A-Fa-f](?:'?[0-9A-Fa-f])*|0(?:'?[0-7])*|[1-9](?:'?[0-9])*)(?:[Uu](?:LL?|ll?)|[Uu][Zz]?|(?:LL?|ll?)[Uu]?|[Zz][Uu]|)" }],
		relevance: 0
	}, c = {
		className: "meta",
		begin: /#\s*[a-z]+\b/,
		end: /$/,
		keywords: { keyword: "if else elif endif define undef warning error line pragma _Pragma ifdef ifndef include" },
		contains: [
			{
				begin: /\\\n/,
				relevance: 0
			},
			e.inherit(o, { className: "string" }),
			{
				className: "string",
				begin: /<.*?>/
			},
			n,
			e.C_BLOCK_COMMENT_MODE
		]
	}, l = {
		className: "title",
		begin: t.optional(r) + e.IDENT_RE,
		relevance: 0
	}, u = t.optional(r) + e.IDENT_RE + "\\s*\\(", d = /* @__PURE__ */ "alignas.alignof.and.and_eq.asm.atomic_cancel.atomic_commit.atomic_noexcept.auto.bitand.bitor.break.case.catch.class.co_await.co_return.co_yield.compl.concept.const_cast|10.consteval.constexpr.constinit.continue.decltype.default.delete.do.dynamic_cast|10.else.enum.explicit.export.extern.false.final.for.friend.goto.if.import.inline.module.mutable.namespace.new.noexcept.not.not_eq.nullptr.operator.or.or_eq.override.private.protected.public.reflexpr.register.reinterpret_cast|10.requires.return.sizeof.static_assert.static_cast|10.struct.switch.synchronized.template.this.thread_local.throw.transaction_safe.transaction_safe_dynamic.true.try.typedef.typeid.typename.union.using.virtual.volatile.while.xor.xor_eq".split("."), f = [
		"bool",
		"char",
		"char16_t",
		"char32_t",
		"char8_t",
		"double",
		"float",
		"int",
		"long",
		"short",
		"void",
		"wchar_t",
		"unsigned",
		"signed",
		"const",
		"static"
	], p = /* @__PURE__ */ "any.auto_ptr.barrier.binary_semaphore.bitset.complex.condition_variable.condition_variable_any.counting_semaphore.deque.false_type.flat_map.flat_set.future.imaginary.initializer_list.istringstream.jthread.latch.lock_guard.multimap.multiset.mutex.optional.ostringstream.packaged_task.pair.promise.priority_queue.queue.recursive_mutex.recursive_timed_mutex.scoped_lock.set.shared_future.shared_lock.shared_mutex.shared_timed_mutex.shared_ptr.stack.string_view.stringstream.timed_mutex.thread.true_type.tuple.unique_lock.unique_ptr.unordered_map.unordered_multimap.unordered_multiset.unordered_set.variant.vector.weak_ptr.wstring.wstring_view".split("."), m = /* @__PURE__ */ "abort.abs.acos.apply.as_const.asin.atan.atan2.calloc.ceil.cerr.cin.clog.cos.cosh.cout.declval.endl.exchange.exit.exp.fabs.floor.fmod.forward.fprintf.fputs.free.frexp.fscanf.future.invoke.isalnum.isalpha.iscntrl.isdigit.isgraph.islower.isprint.ispunct.isspace.isupper.isxdigit.labs.launder.ldexp.log.log10.make_pair.make_shared.make_shared_for_overwrite.make_tuple.make_unique.malloc.memchr.memcmp.memcpy.memset.modf.move.pow.printf.putchar.puts.realloc.scanf.sin.sinh.snprintf.sprintf.sqrt.sscanf.std.stderr.stdin.stdout.strcat.strchr.strcmp.strcpy.strcspn.strlen.strncat.strncmp.strncpy.strpbrk.strrchr.strspn.strstr.swap.tan.tanh.terminate.to_underlying.tolower.toupper.vfprintf.visit.vprintf.vsprintf".split("."), h = {
		type: f,
		keyword: d,
		literal: [
			"NULL",
			"false",
			"nullopt",
			"nullptr",
			"true"
		],
		built_in: ["_Pragma"],
		_type_hints: p
	}, g = {
		className: "function.dispatch",
		relevance: 0,
		keywords: { _hint: m },
		begin: t.concat(/\b/, `(?!${d.join("|")})`, e.IDENT_RE, t.lookahead(/(<[^<>]+>|)\s*\(/))
	}, _ = [
		g,
		c,
		a,
		n,
		e.C_BLOCK_COMMENT_MODE,
		s,
		o
	], v = {
		variants: [
			{
				begin: /=/,
				end: /;/
			},
			{
				begin: /\(/,
				end: /\)/
			},
			{
				beginKeywords: "new throw return else",
				end: /;/
			}
		],
		keywords: h,
		contains: _.concat([{
			begin: /\(/,
			end: /\)/,
			keywords: h,
			contains: _.concat(["self"]),
			relevance: 0
		}]),
		relevance: 0
	}, y = {
		className: "function",
		begin: "(" + i + "[\\*&\\s]+)+" + u,
		returnBegin: !0,
		end: /[{;=]/,
		excludeEnd: !0,
		keywords: h,
		illegal: /[^\w\s\*&:<>.]/,
		contains: [
			{
				begin: "decltype\\(auto\\)",
				keywords: h,
				relevance: 0
			},
			{
				begin: u,
				returnBegin: !0,
				contains: [l],
				relevance: 0
			},
			{
				begin: /::/,
				relevance: 0
			},
			{
				begin: /:/,
				endsWithParent: !0,
				contains: [o, s]
			},
			{
				relevance: 0,
				match: /,/
			},
			{
				className: "params",
				begin: /\(/,
				end: /\)/,
				keywords: h,
				relevance: 0,
				contains: [
					n,
					e.C_BLOCK_COMMENT_MODE,
					o,
					s,
					a,
					{
						begin: /\(/,
						end: /\)/,
						keywords: h,
						relevance: 0,
						contains: [
							"self",
							n,
							e.C_BLOCK_COMMENT_MODE,
							o,
							s,
							a
						]
					}
				]
			},
			a,
			n,
			e.C_BLOCK_COMMENT_MODE,
			c
		]
	};
	return {
		name: "C++",
		aliases: [
			"cc",
			"c++",
			"h++",
			"hpp",
			"hh",
			"hxx",
			"cxx"
		],
		keywords: h,
		illegal: "</",
		classNameAliases: { "function.dispatch": "built_in" },
		contains: [].concat(v, y, g, _, [
			c,
			{
				begin: "\\b(deque|list|queue|priority_queue|pair|stack|vector|map|set|bitset|multiset|multimap|unordered_map|unordered_set|unordered_multiset|unordered_multimap|array|tuple|optional|variant|function|flat_map|flat_set)\\s*<(?!<)",
				end: ">",
				keywords: h,
				contains: ["self", a]
			},
			{
				begin: e.IDENT_RE + "::",
				keywords: h
			},
			{
				match: [
					/\b(?:enum(?:\s+(?:class|struct))?|class|struct|union)/,
					/\s+/,
					/\w+/
				],
				className: {
					1: "keyword",
					3: "title.class"
				}
			}
		])
	};
}
// node_modules/highlight.js/es/languages/csharp.js
function Ke(e) {
	let t = [
		"bool",
		"byte",
		"char",
		"decimal",
		"delegate",
		"double",
		"dynamic",
		"enum",
		"float",
		"int",
		"long",
		"nint",
		"nuint",
		"object",
		"sbyte",
		"short",
		"string",
		"ulong",
		"uint",
		"ushort"
	], n = [
		"public",
		"private",
		"protected",
		"static",
		"internal",
		"protected",
		"abstract",
		"async",
		"extern",
		"override",
		"unsafe",
		"virtual",
		"new",
		"sealed",
		"partial"
	], r = {
		keyword: (/* @__PURE__ */ "abstract.as.base.break.case.catch.class.const.continue.do.else.event.explicit.extern.finally.fixed.for.foreach.goto.if.implicit.in.interface.internal.is.lock.namespace.new.operator.out.override.params.private.protected.public.readonly.record.ref.return.scoped.sealed.sizeof.stackalloc.static.struct.switch.this.throw.try.typeof.unchecked.unsafe.using.virtual.void.volatile.while".split(".")).concat(/* @__PURE__ */ "add.alias.and.ascending.args.async.await.by.descending.dynamic.equals.file.from.get.global.group.init.into.join.let.nameof.not.notnull.on.or.orderby.partial.record.remove.required.scoped.select.set.unmanaged.value|0.var.when.where.with.yield".split(".")),
		built_in: t,
		literal: [
			"default",
			"false",
			"null",
			"true"
		]
	}, i = e.inherit(e.TITLE_MODE, { begin: "[a-zA-Z](\\.?\\w)*" }), a = {
		className: "number",
		variants: [
			{ begin: "\\b(0b[01']+)" },
			{ begin: "(-?)\\b([\\d']+(\\.[\\d']*)?|\\.[\\d']+)(u|U|l|L|ul|UL|f|F|b|B)" },
			{ begin: "(-?)(\\b0[xX][a-fA-F0-9'_]+|(\\b[\\d'_]+(\\.[\\d'_]*)?|\\.[\\d'_]+)([eE][-+]?[\\d'_]+)?)" }
		],
		relevance: 0
	}, o = {
		className: "string",
		begin: /"""("*)(?!")(.|\n)*?"""\1/,
		relevance: 1
	}, s = {
		className: "string",
		begin: "@\"",
		end: "\"",
		contains: [{ begin: "\"\"" }]
	}, c = e.inherit(s, { illegal: /\n/ }), l = {
		className: "subst",
		begin: /\{/,
		end: /\}/,
		keywords: r
	}, u = e.inherit(l, { illegal: /\n/ }), d = {
		className: "string",
		begin: /\$"/,
		end: "\"",
		illegal: /\n/,
		contains: [
			{ begin: /\{\{/ },
			{ begin: /\}\}/ },
			e.BACKSLASH_ESCAPE,
			u
		]
	}, f = {
		className: "string",
		begin: /\$@"/,
		end: "\"",
		contains: [
			{ begin: /\{\{/ },
			{ begin: /\}\}/ },
			{ begin: "\"\"" },
			l
		]
	}, p = e.inherit(f, {
		illegal: /\n/,
		contains: [
			{ begin: /\{\{/ },
			{ begin: /\}\}/ },
			{ begin: "\"\"" },
			u
		]
	});
	l.contains = [
		f,
		d,
		s,
		e.APOS_STRING_MODE,
		e.QUOTE_STRING_MODE,
		a,
		e.C_BLOCK_COMMENT_MODE
	], u.contains = [
		p,
		d,
		c,
		e.APOS_STRING_MODE,
		e.QUOTE_STRING_MODE,
		a,
		e.inherit(e.C_BLOCK_COMMENT_MODE, { illegal: /\n/ })
	];
	let m = { variants: [
		o,
		f,
		d,
		s,
		e.APOS_STRING_MODE,
		e.QUOTE_STRING_MODE
	] }, h = {
		begin: "<",
		end: ">",
		contains: [{ beginKeywords: "in out" }, i]
	}, g = e.IDENT_RE + "(<" + e.IDENT_RE + "(\\s*,\\s*" + e.IDENT_RE + ")*>)?(\\[\\])?", _ = {
		begin: "@" + e.IDENT_RE,
		relevance: 0
	};
	return {
		name: "C#",
		aliases: ["cs", "c#"],
		keywords: r,
		illegal: /::/,
		contains: [
			e.COMMENT("///", "$", {
				returnBegin: !0,
				contains: [{
					className: "doctag",
					variants: [
						{
							begin: "///",
							relevance: 0
						},
						{ begin: "<!--|-->" },
						{
							begin: "</?",
							end: ">"
						}
					]
				}]
			}),
			e.C_LINE_COMMENT_MODE,
			e.C_BLOCK_COMMENT_MODE,
			{
				className: "meta",
				begin: "#",
				end: "$",
				keywords: { keyword: "if else elif endif define undef warning error line region endregion pragma checksum" }
			},
			m,
			a,
			{
				beginKeywords: "class interface",
				relevance: 0,
				end: /[{;=]/,
				illegal: /[^\s:,]/,
				contains: [
					{ beginKeywords: "where class" },
					i,
					h,
					e.C_LINE_COMMENT_MODE,
					e.C_BLOCK_COMMENT_MODE
				]
			},
			{
				beginKeywords: "namespace",
				relevance: 0,
				end: /[{;=]/,
				illegal: /[^\s:]/,
				contains: [
					i,
					e.C_LINE_COMMENT_MODE,
					e.C_BLOCK_COMMENT_MODE
				]
			},
			{
				beginKeywords: "record",
				relevance: 0,
				end: /[{;=]/,
				illegal: /[^\s:]/,
				contains: [
					i,
					h,
					e.C_LINE_COMMENT_MODE,
					e.C_BLOCK_COMMENT_MODE
				]
			},
			{
				className: "meta",
				begin: "^\\s*\\[(?=[\\w])",
				excludeBegin: !0,
				end: "\\]",
				excludeEnd: !0,
				contains: [{
					className: "string",
					begin: /"/,
					end: /"/
				}]
			},
			{
				beginKeywords: "new return throw await else",
				relevance: 0
			},
			{
				className: "function",
				begin: "(" + g + "\\s+)+" + e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
				returnBegin: !0,
				end: /\s*[{;=]/,
				excludeEnd: !0,
				keywords: r,
				contains: [
					{
						beginKeywords: n.join(" "),
						relevance: 0
					},
					{
						begin: e.IDENT_RE + "\\s*(<[^=]+>\\s*)?\\(",
						returnBegin: !0,
						contains: [e.TITLE_MODE, h],
						relevance: 0
					},
					{ match: /\(\)/ },
					{
						className: "params",
						begin: /\(/,
						end: /\)/,
						excludeBegin: !0,
						excludeEnd: !0,
						keywords: r,
						relevance: 0,
						contains: [
							m,
							a,
							e.C_BLOCK_COMMENT_MODE
						]
					},
					e.C_LINE_COMMENT_MODE,
					e.C_BLOCK_COMMENT_MODE
				]
			},
			_
		]
	};
}
// node_modules/highlight.js/es/languages/css.js
var qe = (e) => ({
	IMPORTANT: {
		scope: "meta",
		begin: "!important"
	},
	BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
	HEXCOLOR: {
		scope: "number",
		begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
	},
	UNICODE_RANGE: {
		scope: "number",
		begin: /\b[Uu]\+[0-9A-Fa-f][0-9A-Fa-f?]{0,4}(-[0-9A-Fa-f][0-9A-Fa-f]{0,4})?/
	},
	FUNCTION_DISPATCH: {
		className: "built_in",
		begin: /[\w-]+(?=\()/
	},
	ATTRIBUTE_SELECTOR_MODE: {
		scope: "selector-attr",
		begin: /\[/,
		end: /\]/,
		illegal: "$",
		contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
	},
	CSS_NUMBER_MODE: {
		scope: "number",
		begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
		relevance: 0
	},
	CSS_VARIABLE: {
		className: "attr",
		begin: /--[A-Za-z_][A-Za-z0-9_-]*/
	}
}), Je = /* @__PURE__ */ "a.abbr.address.article.aside.audio.b.blockquote.body.button.canvas.caption.cite.code.dd.del.details.dfn.div.dl.dt.em.fieldset.figcaption.figure.footer.form.h1.h2.h3.h4.h5.h6.header.hgroup.html.i.iframe.img.input.ins.kbd.label.legend.li.main.mark.menu.nav.object.ol.optgroup.option.p.picture.q.quote.samp.section.select.source.span.strong.summary.sup.table.tbody.td.textarea.tfoot.th.thead.time.tr.ul.var.video".split("."), Ye = /* @__PURE__ */ "defs.g.marker.mask.pattern.svg.switch.symbol.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feFlood.feGaussianBlur.feImage.feMerge.feMorphology.feOffset.feSpecularLighting.feTile.feTurbulence.linearGradient.radialGradient.stop.circle.ellipse.image.line.path.polygon.polyline.rect.text.use.textPath.tspan.foreignObject.clipPath".split("."), Xe = [...Je, ...Ye], Ze = (/* @__PURE__ */ "any-hover.any-pointer.aspect-ratio.color.color-gamut.color-index.device-aspect-ratio.device-height.device-width.display-mode.forced-colors.grid.height.hover.inverted-colors.monochrome.orientation.overflow-block.overflow-inline.pointer.prefers-color-scheme.prefers-contrast.prefers-reduced-motion.prefers-reduced-transparency.resolution.scan.scripting.update.width.min-width.max-width.min-height.max-height".split(".")).sort().reverse(), Qe = (/* @__PURE__ */ "active.any-link.blank.checked.current.default.defined.dir.disabled.drop.empty.enabled.first.first-child.first-of-type.fullscreen.future.focus.focus-visible.focus-within.has.host.host-context.hover.indeterminate.in-range.invalid.is.lang.last-child.last-of-type.left.link.local-link.not.nth-child.nth-col.nth-last-child.nth-last-col.nth-last-of-type.nth-of-type.only-child.only-of-type.optional.out-of-range.past.placeholder-shown.read-only.read-write.required.right.root.scope.target.target-within.user-invalid.valid.visited.where".split(".")).sort().reverse(), $e = [
	"after",
	"backdrop",
	"before",
	"cue",
	"cue-region",
	"first-letter",
	"first-line",
	"grammar-error",
	"marker",
	"part",
	"placeholder",
	"selection",
	"slotted",
	"spelling-error"
].sort().reverse(), et = (/* @__PURE__ */ "accent-color.align-content.align-items.align-self.alignment-baseline.all.anchor-name.animation.animation-composition.animation-delay.animation-direction.animation-duration.animation-fill-mode.animation-iteration-count.animation-name.animation-play-state.animation-range.animation-range-end.animation-range-start.animation-timeline.animation-timing-function.appearance.aspect-ratio.backdrop-filter.backface-visibility.background.background-attachment.background-blend-mode.background-clip.background-color.background-image.background-origin.background-position.background-position-x.background-position-y.background-repeat.background-size.baseline-shift.block-size.border.border-block.border-block-color.border-block-end.border-block-end-color.border-block-end-style.border-block-end-width.border-block-start.border-block-start-color.border-block-start-style.border-block-start-width.border-block-style.border-block-width.border-bottom.border-bottom-color.border-bottom-left-radius.border-bottom-right-radius.border-bottom-style.border-bottom-width.border-collapse.border-color.border-end-end-radius.border-end-start-radius.border-image.border-image-outset.border-image-repeat.border-image-slice.border-image-source.border-image-width.border-inline.border-inline-color.border-inline-end.border-inline-end-color.border-inline-end-style.border-inline-end-width.border-inline-start.border-inline-start-color.border-inline-start-style.border-inline-start-width.border-inline-style.border-inline-width.border-left.border-left-color.border-left-style.border-left-width.border-radius.border-right.border-right-color.border-right-style.border-right-width.border-spacing.border-start-end-radius.border-start-start-radius.border-style.border-top.border-top-color.border-top-left-radius.border-top-right-radius.border-top-style.border-top-width.border-width.bottom.box-align.box-decoration-break.box-direction.box-flex.box-flex-group.box-lines.box-ordinal-group.box-orient.box-pack.box-shadow.box-sizing.break-after.break-before.break-inside.caption-side.caret-color.clear.clip.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-profile.color-rendering.color-scheme.column-count.column-fill.column-gap.column-rule.column-rule-color.column-rule-style.column-rule-width.column-span.column-width.columns.contain.contain-intrinsic-block-size.contain-intrinsic-height.contain-intrinsic-inline-size.contain-intrinsic-size.contain-intrinsic-width.container.container-name.container-type.content.content-visibility.counter-increment.counter-reset.counter-set.cue.cue-after.cue-before.cursor.cx.cy.direction.display.dominant-baseline.empty-cells.enable-background.field-sizing.fill.fill-opacity.fill-rule.filter.flex.flex-basis.flex-direction.flex-flow.flex-grow.flex-shrink.flex-wrap.float.flood-color.flood-opacity.flow.font.font-display.font-family.font-feature-settings.font-kerning.font-language-override.font-optical-sizing.font-palette.font-size.font-size-adjust.font-smooth.font-smoothing.font-stretch.font-style.font-synthesis.font-synthesis-position.font-synthesis-small-caps.font-synthesis-style.font-synthesis-weight.font-variant.font-variant-alternates.font-variant-caps.font-variant-east-asian.font-variant-emoji.font-variant-ligatures.font-variant-numeric.font-variant-position.font-variation-settings.font-weight.forced-color-adjust.gap.glyph-orientation-horizontal.glyph-orientation-vertical.grid.grid-area.grid-auto-columns.grid-auto-flow.grid-auto-rows.grid-column.grid-column-end.grid-column-start.grid-gap.grid-row.grid-row-end.grid-row-start.grid-template.grid-template-areas.grid-template-columns.grid-template-rows.hanging-punctuation.height.hyphenate-character.hyphenate-limit-chars.hyphens.icon.image-orientation.image-rendering.image-resolution.ime-mode.initial-letter.initial-letter-align.inline-size.inset.inset-area.inset-block.inset-block-end.inset-block-start.inset-inline.inset-inline-end.inset-inline-start.isolation.justify-content.justify-items.justify-self.kerning.left.letter-spacing.lighting-color.line-break.line-height.line-height-step.list-style.list-style-image.list-style-position.list-style-type.margin.margin-block.margin-block-end.margin-block-start.margin-bottom.margin-inline.margin-inline-end.margin-inline-start.margin-left.margin-right.margin-top.margin-trim.marker.marker-end.marker-mid.marker-start.marks.mask.mask-border.mask-border-mode.mask-border-outset.mask-border-repeat.mask-border-slice.mask-border-source.mask-border-width.mask-clip.mask-composite.mask-image.mask-mode.mask-origin.mask-position.mask-repeat.mask-size.mask-type.masonry-auto-flow.math-depth.math-shift.math-style.max-block-size.max-height.max-inline-size.max-width.min-block-size.min-height.min-inline-size.min-width.mix-blend-mode.nav-down.nav-index.nav-left.nav-right.nav-up.none.normal.object-fit.object-position.offset.offset-anchor.offset-distance.offset-path.offset-position.offset-rotate.opacity.order.orphans.outline.outline-color.outline-offset.outline-style.outline-width.overflow.overflow-anchor.overflow-block.overflow-clip-margin.overflow-inline.overflow-wrap.overflow-x.overflow-y.overlay.overscroll-behavior.overscroll-behavior-block.overscroll-behavior-inline.overscroll-behavior-x.overscroll-behavior-y.padding.padding-block.padding-block-end.padding-block-start.padding-bottom.padding-inline.padding-inline-end.padding-inline-start.padding-left.padding-right.padding-top.page.page-break-after.page-break-before.page-break-inside.paint-order.pause.pause-after.pause-before.perspective.perspective-origin.place-content.place-items.place-self.pointer-events.position.position-anchor.position-visibility.print-color-adjust.quotes.r.resize.rest.rest-after.rest-before.right.rotate.row-gap.ruby-align.ruby-position.scale.scroll-behavior.scroll-margin.scroll-margin-block.scroll-margin-block-end.scroll-margin-block-start.scroll-margin-bottom.scroll-margin-inline.scroll-margin-inline-end.scroll-margin-inline-start.scroll-margin-left.scroll-margin-right.scroll-margin-top.scroll-padding.scroll-padding-block.scroll-padding-block-end.scroll-padding-block-start.scroll-padding-bottom.scroll-padding-inline.scroll-padding-inline-end.scroll-padding-inline-start.scroll-padding-left.scroll-padding-right.scroll-padding-top.scroll-snap-align.scroll-snap-stop.scroll-snap-type.scroll-timeline.scroll-timeline-axis.scroll-timeline-name.scrollbar-color.scrollbar-gutter.scrollbar-width.shape-image-threshold.shape-margin.shape-outside.shape-rendering.speak.speak-as.src.stop-color.stop-opacity.stroke.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke-width.tab-size.table-layout.text-align.text-align-all.text-align-last.text-anchor.text-combine-upright.text-decoration.text-decoration-color.text-decoration-line.text-decoration-skip.text-decoration-skip-ink.text-decoration-style.text-decoration-thickness.text-emphasis.text-emphasis-color.text-emphasis-position.text-emphasis-style.text-indent.text-justify.text-orientation.text-overflow.text-rendering.text-shadow.text-size-adjust.text-transform.text-underline-offset.text-underline-position.text-wrap.text-wrap-mode.text-wrap-style.timeline-scope.top.touch-action.transform.transform-box.transform-origin.transform-style.transition.transition-behavior.transition-delay.transition-duration.transition-property.transition-timing-function.translate.unicode-bidi.unicode-range.user-modify.user-select.vector-effect.vertical-align.view-timeline.view-timeline-axis.view-timeline-inset.view-timeline-name.view-transition-name.visibility.voice-balance.voice-duration.voice-family.voice-pitch.voice-range.voice-rate.voice-stress.voice-volume.white-space.white-space-collapse.widows.width.will-change.word-break.word-spacing.word-wrap.writing-mode.x.y.z-index.zoom".split(".")).sort().reverse();
function tt(e) {
	let t = e.regex, n = qe(e), r = { begin: /-(webkit|moz|ms|o)-(?=[a-z])/ }, i = /@-?\w[\w]*(-\w+)*/, a = [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE];
	return {
		name: "CSS",
		case_insensitive: !0,
		illegal: /[=|'\$]/,
		keywords: { keyframePosition: "from to" },
		classNameAliases: { keyframePosition: "selector-tag" },
		contains: [
			n.BLOCK_COMMENT,
			r,
			n.CSS_NUMBER_MODE,
			{
				className: "selector-id",
				begin: /#[A-Za-z0-9_-]+/,
				relevance: 0
			},
			{
				className: "selector-class",
				begin: "\\.[a-zA-Z-][a-zA-Z0-9_-]*",
				relevance: 0
			},
			n.ATTRIBUTE_SELECTOR_MODE,
			{
				className: "selector-pseudo",
				variants: [{ begin: ":(" + Qe.join("|") + ")" }, { begin: ":(:)?(" + $e.join("|") + ")" }]
			},
			n.CSS_VARIABLE,
			{
				className: "attribute",
				begin: "\\b(" + et.join("|") + ")\\b"
			},
			{
				begin: /:/,
				end: /[;}{]/,
				contains: [
					n.BLOCK_COMMENT,
					n.HEXCOLOR,
					n.IMPORTANT,
					n.CSS_NUMBER_MODE,
					n.UNICODE_RANGE,
					...a,
					{
						begin: /(url|data-uri)\(/,
						end: /\)/,
						relevance: 0,
						keywords: { built_in: "url data-uri" },
						contains: [...a, {
							className: "string",
							begin: /[^)]/,
							endsWithParent: !0,
							excludeEnd: !0
						}]
					},
					n.FUNCTION_DISPATCH
				]
			},
			{
				begin: t.lookahead(/@/),
				end: "[{;]",
				relevance: 0,
				illegal: /:/,
				contains: [{
					className: "keyword",
					begin: i
				}, {
					begin: /\s/,
					endsWithParent: !0,
					excludeEnd: !0,
					relevance: 0,
					keywords: {
						$pattern: /[a-z-]+/,
						keyword: "and or not only",
						attribute: Ze.join(" ")
					},
					contains: [
						{
							begin: /[a-z-]+(?=:)/,
							className: "attribute"
						},
						...a,
						n.CSS_NUMBER_MODE
					]
				}]
			},
			{
				className: "selector-tag",
				begin: "\\b(" + Xe.join("|") + ")\\b"
			}
		]
	};
}
// node_modules/highlight.js/es/languages/diff.js
function nt(e) {
	let t = e.regex;
	return {
		name: "Diff",
		aliases: ["patch"],
		contains: [
			{
				className: "meta",
				relevance: 10,
				match: t.either(/^@@ +-\d+,\d+ +\+\d+,\d+ +@@/, /^@@ +-\d+ +\+\d+,\d+ +@@/, /^@@ +-\d+,\d+ +\+\d+ +@@/, /^@@ +-\d+ +\+\d+ +@@/, /^\*\*\* +\d+,\d+ +\*\*\*\*$/, /^--- +\d+,\d+ +----$/)
			},
			{
				className: "comment",
				variants: [{
					begin: t.either(/Index: /, /^index/, /={3,}/, /^-{3}/, /^\*{3} /, /^\+{3}/, /^diff --git/),
					end: /$/
				}, { match: /^\*{15}$/ }]
			},
			{
				className: "addition",
				begin: /^\+/,
				end: /$/
			},
			{
				className: "deletion",
				begin: /^-/,
				end: /$/
			},
			{
				className: "addition",
				begin: /^!/,
				end: /$/
			}
		]
	};
}
// node_modules/highlight.js/es/languages/go.js
function rt(e) {
	let t = {
		keyword: [
			"break",
			"case",
			"chan",
			"const",
			"continue",
			"default",
			"defer",
			"else",
			"fallthrough",
			"for",
			"func",
			"go",
			"goto",
			"if",
			"import",
			"interface",
			"map",
			"package",
			"range",
			"return",
			"select",
			"struct",
			"switch",
			"type",
			"var"
		],
		type: [
			"bool",
			"byte",
			"complex64",
			"complex128",
			"error",
			"float32",
			"float64",
			"int8",
			"int16",
			"int32",
			"int64",
			"string",
			"uint8",
			"uint16",
			"uint32",
			"uint64",
			"int",
			"uint",
			"uintptr",
			"rune"
		],
		literal: [
			"true",
			"false",
			"iota",
			"nil"
		],
		built_in: [
			"append",
			"cap",
			"close",
			"complex",
			"copy",
			"imag",
			"len",
			"make",
			"new",
			"panic",
			"print",
			"println",
			"real",
			"recover",
			"delete"
		]
	};
	return {
		name: "Go",
		aliases: ["golang"],
		keywords: t,
		illegal: "</",
		contains: [
			e.C_LINE_COMMENT_MODE,
			e.C_BLOCK_COMMENT_MODE,
			{
				className: "string",
				variants: [
					e.QUOTE_STRING_MODE,
					e.APOS_STRING_MODE,
					{
						begin: "`",
						end: "`"
					}
				]
			},
			{
				className: "number",
				variants: [
					{
						match: /-?\b0[xX]\.[a-fA-F0-9](_?[a-fA-F0-9])*[pP][+-]?\d(_?\d)*i?/,
						relevance: 0
					},
					{
						match: /-?\b0[xX](_?[a-fA-F0-9])+((\.([a-fA-F0-9](_?[a-fA-F0-9])*)?)?[pP][+-]?\d(_?\d)*)?i?/,
						relevance: 0
					},
					{
						match: /-?\b0[oO](_?[0-7])*i?/,
						relevance: 0
					},
					{
						match: /-?\.\d(_?\d)*([eE][+-]?\d(_?\d)*)?i?/,
						relevance: 0
					},
					{
						match: /-?\b\d(_?\d)*(\.(\d(_?\d)*)?)?([eE][+-]?\d(_?\d)*)?i?/,
						relevance: 0
					}
				]
			},
			{ begin: /:=/ },
			{
				className: "function",
				beginKeywords: "func",
				end: "\\s*(\\{|$)",
				excludeEnd: !0,
				contains: [e.TITLE_MODE, {
					className: "params",
					begin: /\(/,
					end: /\)/,
					endsParent: !0,
					keywords: t,
					illegal: /["']/
				}]
			}
		]
	};
}
// node_modules/highlight.js/es/languages/graphql.js
function it(e) {
	let t = e.regex;
	return {
		name: "GraphQL",
		aliases: ["gql"],
		case_insensitive: !0,
		disableAutodetect: !1,
		keywords: {
			keyword: [
				"query",
				"mutation",
				"subscription",
				"type",
				"input",
				"schema",
				"directive",
				"interface",
				"union",
				"scalar",
				"fragment",
				"enum",
				"on"
			],
			literal: [
				"true",
				"false",
				"null"
			]
		},
		contains: [
			e.HASH_COMMENT_MODE,
			e.QUOTE_STRING_MODE,
			e.NUMBER_MODE,
			{
				scope: "punctuation",
				match: /[.]{3}/,
				relevance: 0
			},
			{
				scope: "punctuation",
				begin: /[\!\(\)\:\=\[\]\{\|\}]{1}/,
				relevance: 0
			},
			{
				scope: "variable",
				begin: /\$/,
				end: /\W/,
				excludeEnd: !0,
				relevance: 0
			},
			{
				scope: "meta",
				match: /@\w+/,
				excludeEnd: !0
			},
			{
				scope: "symbol",
				begin: t.concat(/[_A-Za-z][_0-9A-Za-z]*/, t.lookahead(/\s*:/)),
				relevance: 0
			}
		],
		illegal: [/[;<']/, /BEGIN/]
	};
}
// node_modules/highlight.js/es/languages/ini.js
function at(e) {
	let t = e.regex, n = {
		className: "number",
		relevance: 0,
		variants: [{ begin: /([+-]+)?[\d]+_[\d_]+/ }, { begin: e.NUMBER_RE }]
	}, r = e.COMMENT();
	r.variants = [{
		begin: /;/,
		end: /$/
	}, {
		begin: /#/,
		end: /$/
	}];
	let i = {
		className: "variable",
		variants: [{ begin: /\$[\w\d"][\w\d_]*/ }, { begin: /\$\{(.*?)\}/ }]
	}, a = {
		className: "literal",
		begin: /\bon|off|true|false|yes|no\b/
	}, o = {
		className: "string",
		contains: [e.BACKSLASH_ESCAPE],
		variants: [
			{
				begin: "'''",
				end: "'''",
				relevance: 10
			},
			{
				begin: "\"\"\"",
				end: "\"\"\"",
				relevance: 10
			},
			{
				begin: "\"",
				end: "\""
			},
			{
				begin: "'",
				end: "'"
			}
		]
	}, s = {
		begin: /\[/,
		end: /\]/,
		contains: [
			r,
			a,
			i,
			o,
			n,
			"self"
		],
		relevance: 0
	}, c = t.either(/[A-Za-z0-9_-]+/, /"(\\"|[^"])*"/, /'[^']*'/);
	return {
		name: "TOML, also INI",
		aliases: ["toml"],
		case_insensitive: !0,
		illegal: /\S/,
		contains: [
			r,
			{
				className: "section",
				begin: /\[+/,
				end: /\]+/
			},
			{
				begin: t.concat(c, "(\\s*\\.\\s*", c, ")*", t.lookahead(/\s*=\s*[^#\s]/)),
				className: "attr",
				starts: {
					end: /$/,
					contains: [
						r,
						s,
						a,
						i,
						o,
						n
					]
				}
			}
		]
	};
}
// node_modules/highlight.js/es/languages/java.js
var ot = "[0-9](_*[0-9])*", st = `\\.(${ot})`, ct = "[0-9a-fA-F](_*[0-9a-fA-F])*", lt = {
	className: "number",
	variants: [
		{ begin: `(\\b(${ot})((${st})|\\.)?|(${st}))[eE][+-]?(${ot})[fFdD]?\\b` },
		{ begin: `\\b(${ot})((${st})[fFdD]?\\b|\\.([fFdD]\\b)?)` },
		{ begin: `(${st})[fFdD]?\\b` },
		{ begin: `\\b(${ot})[fFdD]\\b` },
		{ begin: `\\b0[xX]((${ct})\\.?|(${ct})?\\.(${ct}))[pP][+-]?(${ot})[fFdD]?\\b` },
		{ begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b" },
		{ begin: `\\b0[xX](${ct})[lL]?\\b` },
		{ begin: "\\b0(_*[0-7])*[lL]?\\b" },
		{ begin: "\\b0[bB][01](_*[01])*[lL]?\\b" }
	],
	relevance: 0
};
function ut(e, t, n) {
	return n === -1 ? "" : e.replace(t, (r) => ut(e, t, n - 1));
}
function dt(e) {
	let t = e.regex, n = "[À-ʸa-zA-Z_$][À-ʸa-zA-Z_$0-9]*", r = n + ut("(?:<" + n + "~~~(?:\\s*,\\s*" + n + "~~~)*>)?", /~~~/g, 2), i = {
		keyword: /* @__PURE__ */ "synchronized.abstract.private.var.static.if.const .for.while.strictfp.finally.protected.import.native.final.void.enum.else.break.transient.catch.instanceof.volatile.case.assert.package.default.public.try.switch.continue.throws.protected.public.private.module.requires.exports.do.sealed.yield.permits.goto.when".split("."),
		literal: [
			"false",
			"true",
			"null"
		],
		type: [
			"char",
			"boolean",
			"long",
			"float",
			"int",
			"byte",
			"short",
			"double"
		],
		built_in: ["super", "this"]
	}, a = {
		className: "meta",
		begin: "@" + n,
		contains: [{
			begin: /\(/,
			end: /\)/,
			contains: ["self"]
		}]
	}, o = {
		className: "params",
		begin: /\(/,
		end: /\)/,
		keywords: i,
		relevance: 0,
		contains: [e.C_BLOCK_COMMENT_MODE],
		endsParent: !0
	};
	return {
		name: "Java",
		aliases: ["jsp"],
		keywords: i,
		illegal: /<\/|#/,
		contains: [
			e.COMMENT("/\\*\\*", "\\*/", {
				relevance: 0,
				contains: [{
					begin: /\w+@/,
					relevance: 0
				}, {
					className: "doctag",
					begin: "@[A-Za-z]+"
				}]
			}),
			{
				begin: /import java\.[a-z]+\./,
				keywords: "import",
				relevance: 2
			},
			e.C_LINE_COMMENT_MODE,
			e.C_BLOCK_COMMENT_MODE,
			{
				begin: /"""/,
				end: /"""/,
				className: "string",
				contains: [e.BACKSLASH_ESCAPE]
			},
			e.APOS_STRING_MODE,
			e.QUOTE_STRING_MODE,
			{
				match: [
					/\b(?:class|interface|enum|extends|implements|new)/,
					/\s+/,
					n
				],
				className: {
					1: "keyword",
					3: "title.class"
				}
			},
			{
				match: /non-sealed/,
				scope: "keyword"
			},
			{
				begin: [
					t.concat(/(?!else)/, n),
					/\s+/,
					n,
					/\s+/,
					/=(?!=)/
				],
				className: {
					1: "type",
					3: "variable",
					5: "operator"
				}
			},
			{
				begin: [
					/record/,
					/\s+/,
					n
				],
				className: {
					1: "keyword",
					3: "title.class"
				},
				contains: [
					o,
					e.C_LINE_COMMENT_MODE,
					e.C_BLOCK_COMMENT_MODE
				]
			},
			{
				beginKeywords: "new throw return else",
				relevance: 0
			},
			{
				begin: [
					"(?:" + r + "\\s+)",
					e.UNDERSCORE_IDENT_RE,
					/\s*(?=\()/
				],
				className: { 2: "title.function" },
				keywords: i,
				contains: [
					{
						className: "params",
						begin: /\(/,
						end: /\)/,
						keywords: i,
						relevance: 0,
						contains: [
							a,
							e.APOS_STRING_MODE,
							e.QUOTE_STRING_MODE,
							lt,
							e.C_BLOCK_COMMENT_MODE
						]
					},
					e.C_LINE_COMMENT_MODE,
					e.C_BLOCK_COMMENT_MODE
				]
			},
			lt,
			a
		]
	};
}
// node_modules/highlight.js/es/languages/javascript.js
var ft = "[A-Za-z$_][0-9A-Za-z$_]*", pt = /* @__PURE__ */ "as.in.of.if.for.while.finally.var.new.function.do.return.void.else.break.catch.instanceof.with.throw.case.default.try.switch.continue.typeof.delete.let.yield.const.class.debugger.async.await.static.import.from.export.extends.using".split("."), mt = [
	"true",
	"false",
	"null",
	"undefined",
	"NaN",
	"Infinity"
], ht = /* @__PURE__ */ "Object.Function.Boolean.Symbol.Math.Date.Number.BigInt.String.RegExp.Array.Float32Array.Float64Array.Int8Array.Uint8Array.Uint8ClampedArray.Int16Array.Int32Array.Uint16Array.Uint32Array.BigInt64Array.BigUint64Array.Set.Map.WeakSet.WeakMap.ArrayBuffer.SharedArrayBuffer.Atomics.DataView.JSON.Promise.Generator.GeneratorFunction.AsyncFunction.Reflect.Proxy.Intl.WebAssembly".split("."), gt = [
	"Error",
	"EvalError",
	"InternalError",
	"RangeError",
	"ReferenceError",
	"SyntaxError",
	"TypeError",
	"URIError"
], _t = [
	"setInterval",
	"setTimeout",
	"clearInterval",
	"clearTimeout",
	"require",
	"exports",
	"eval",
	"isFinite",
	"isNaN",
	"parseFloat",
	"parseInt",
	"decodeURI",
	"decodeURIComponent",
	"encodeURI",
	"encodeURIComponent",
	"escape",
	"unescape"
], vt = [
	"arguments",
	"this",
	"super",
	"console",
	"window",
	"document",
	"localStorage",
	"sessionStorage",
	"module",
	"global"
], yt = [].concat(_t, ht, gt);
function bt(e) {
	let t = e.regex, n = (e, { after: t }) => {
		let n = "</" + e[0].slice(1);
		return e.input.indexOf(n, t) !== -1;
	}, r = ft, i = {
		begin: "<>",
		end: "</>"
	}, a = /<[A-Za-z0-9\\._:-]+\s*\/>/, o = {
		begin: /<[A-Za-z0-9\\._:-]+/,
		end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
		isTrulyOpeningTag: (e, t) => {
			let r = e[0].length + e.index, i = e.input[r];
			if (i === "<" || i === ",") {
				t.ignoreMatch();
				return;
			}
			i === ">" && (n(e, { after: r }) || t.ignoreMatch());
			let a, o = e.input.substring(r);
			((a = o.match(/^\s*=/)) || (a = o.match(/^\s+extends\s+/)) && a.index === 0) && t.ignoreMatch();
		}
	}, s = {
		$pattern: ft,
		keyword: pt,
		literal: mt,
		built_in: yt,
		"variable.language": vt
	}, c = "[0-9](_?[0-9])*", l = `\\.(${c})`, u = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*", d = {
		className: "number",
		variants: [
			{ begin: `(\\b(${u})((${l})|\\.)?|(${l}))[eE][+-]?(${c})\\b` },
			{ begin: `\\b(${u})\\b((${l})\\b|\\.)?|(${l})\\b` },
			{ begin: "\\b(0|[1-9](_?[0-9])*)n\\b" },
			{ begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b" },
			{ begin: "\\b0[bB][0-1](_?[0-1])*n?\\b" },
			{ begin: "\\b0[oO][0-7](_?[0-7])*n?\\b" },
			{ begin: "\\b0[0-7]+n?\\b" }
		],
		relevance: 0
	}, f = {
		className: "subst",
		begin: "\\$\\{",
		end: "\\}",
		keywords: s,
		contains: []
	}, p = {
		begin: ".?html`",
		end: "",
		starts: {
			end: "`",
			returnEnd: !1,
			contains: [e.BACKSLASH_ESCAPE, f],
			subLanguage: "xml"
		}
	}, m = {
		begin: ".?css`",
		end: "",
		starts: {
			end: "`",
			returnEnd: !1,
			contains: [e.BACKSLASH_ESCAPE, f],
			subLanguage: "css"
		}
	}, h = {
		begin: ".?gql`",
		end: "",
		starts: {
			end: "`",
			returnEnd: !1,
			contains: [e.BACKSLASH_ESCAPE, f],
			subLanguage: "graphql"
		}
	}, g = {
		className: "string",
		begin: "`",
		end: "`",
		contains: [e.BACKSLASH_ESCAPE, f]
	}, _ = {
		className: "comment",
		variants: [
			e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
				relevance: 0,
				contains: [{
					begin: "(?=@[A-Za-z]+)",
					relevance: 0,
					contains: [
						{
							className: "doctag",
							begin: "@[A-Za-z]+"
						},
						{
							className: "type",
							begin: "\\{",
							end: "\\}",
							excludeEnd: !0,
							excludeBegin: !0,
							relevance: 0
						},
						{
							className: "variable",
							begin: r + "(?=\\s*(-)|$)",
							endsParent: !0,
							relevance: 0
						},
						{
							begin: /(?=[^\n])\s/,
							relevance: 0
						}
					]
				}]
			}),
			e.C_BLOCK_COMMENT_MODE,
			e.C_LINE_COMMENT_MODE
		]
	}, v = [
		e.APOS_STRING_MODE,
		e.QUOTE_STRING_MODE,
		p,
		m,
		h,
		g,
		{ match: /\$\d+/ },
		d
	];
	f.contains = v.concat({
		begin: /\{/,
		end: /\}/,
		keywords: s,
		contains: ["self"].concat(v)
	});
	let y = [].concat(_, f.contains), b = y.concat([{
		begin: /(\s*)\(/,
		end: /\)/,
		keywords: s,
		contains: ["self"].concat(y)
	}]), x = {
		className: "params",
		begin: /(\s*)\(/,
		end: /\)/,
		excludeBegin: !0,
		excludeEnd: !0,
		keywords: s,
		contains: b
	}, S = { variants: [{
		match: [
			/class/,
			/\s+/,
			r,
			/\s+/,
			/extends/,
			/\s+/,
			t.concat(r, "(", t.concat(/\./, r), ")*")
		],
		scope: {
			1: "keyword",
			3: "title.class",
			5: "keyword",
			7: "title.class.inherited"
		}
	}, {
		match: [
			/class/,
			/\s+/,
			r
		],
		scope: {
			1: "keyword",
			3: "title.class"
		}
	}] }, C = {
		relevance: 0,
		match: t.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
		className: "title.class",
		keywords: { _: [...ht, ...gt] }
	}, w = {
		label: "use_strict",
		className: "meta",
		relevance: 10,
		begin: /^\s*['"]use (strict|asm)['"]/
	}, T = {
		variants: [{ match: [
			/function/,
			/\s+/,
			r,
			/(?=\s*\()/
		] }, { match: [/function/, /\s*(?=\()/] }],
		className: {
			1: "keyword",
			3: "title.function"
		},
		label: "func.def",
		contains: [x],
		illegal: /%/
	}, E = {
		relevance: 0,
		match: /\b[A-Z][A-Z_0-9]+\b/,
		className: "variable.constant"
	};
	function D(e) {
		return t.concat("(?!", e.join("|"), ")");
	}
	let O = {
		match: t.concat(/\b/, D([
			..._t,
			"super",
			"import",
			"await"
		].map((e) => `${e}\\s*\\(`)), r, t.lookahead(/\s*\(/)),
		className: "title.function",
		relevance: 0
	}, k = {
		begin: t.concat(/\./, t.lookahead(t.concat(r, /(?![0-9A-Za-z$_(])/))),
		end: r,
		excludeBegin: !0,
		keywords: "prototype",
		className: "property",
		relevance: 0
	}, A = {
		match: [
			/get|set/,
			/\s+/,
			r,
			/(?=\()/
		],
		className: {
			1: "keyword",
			3: "title.function"
		},
		contains: [{ begin: /\(\)/ }, x]
	}, ee = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>", j = {
		match: [
			/const|var|let/,
			/\s+/,
			r,
			/\s*/,
			/=\s*/,
			/(async\s*)?/,
			t.lookahead(ee)
		],
		keywords: "async",
		className: {
			1: "keyword",
			3: "title.function"
		},
		contains: [x]
	};
	return {
		name: "JavaScript",
		aliases: [
			"js",
			"jsx",
			"mjs",
			"cjs"
		],
		keywords: s,
		exports: {
			PARAMS_CONTAINS: b,
			CLASS_REFERENCE: C
		},
		illegal: /#(?![$_A-Za-z])/,
		contains: [
			e.SHEBANG({
				label: "shebang",
				binary: "node",
				relevance: 5
			}),
			w,
			e.APOS_STRING_MODE,
			e.QUOTE_STRING_MODE,
			p,
			m,
			h,
			g,
			_,
			{ match: /\$\d+/ },
			d,
			C,
			{
				scope: "attr",
				match: r + t.lookahead(":"),
				relevance: 0
			},
			j,
			{
				begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
				keywords: "return throw case",
				relevance: 0,
				contains: [
					_,
					e.REGEXP_MODE,
					{
						className: "function",
						begin: ee,
						returnBegin: !0,
						end: "\\s*=>",
						contains: [{
							className: "params",
							variants: [
								{
									begin: e.UNDERSCORE_IDENT_RE,
									relevance: 0
								},
								{
									className: null,
									begin: /\(\s*\)/,
									skip: !0
								},
								{
									begin: /(\s*)\(/,
									end: /\)/,
									excludeBegin: !0,
									excludeEnd: !0,
									keywords: s,
									contains: b
								}
							]
						}]
					},
					{
						begin: /,/,
						relevance: 0
					},
					{
						match: /\s+/,
						relevance: 0
					},
					{
						variants: [
							{
								begin: i.begin,
								end: i.end
							},
							{ match: a },
							{
								begin: o.begin,
								"on:begin": o.isTrulyOpeningTag,
								end: o.end
							}
						],
						subLanguage: "xml",
						contains: [{
							begin: o.begin,
							end: o.end,
							skip: !0,
							contains: ["self"]
						}]
					}
				]
			},
			T,
			{ beginKeywords: "while if switch catch for" },
			{
				begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
				returnBegin: !0,
				label: "func.def",
				contains: [x, e.inherit(e.TITLE_MODE, {
					begin: r,
					className: "title.function"
				})]
			},
			{
				match: /\.\.\./,
				relevance: 0
			},
			k,
			{
				match: "\\$" + r,
				relevance: 0
			},
			{
				match: [/\bconstructor(?=\s*\()/],
				className: { 1: "title.function" },
				contains: [x]
			},
			O,
			E,
			S,
			A,
			{ match: /\$[(.]/ }
		]
	};
}
// node_modules/highlight.js/es/languages/json.js
var xt = {
	scope: "number",
	match: "([-+]?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)|NaN|[-+]?Infinity",
	relevance: 0
};
function St(e) {
	let t = {
		className: "attr",
		begin: /(("(\\.|[^\\"\r\n])*")|('(\\.|[^\\'\r\n])*'))(?=\s*:)/,
		relevance: 1.01
	}, n = {
		match: /[{}[\],:]/,
		className: "punctuation",
		relevance: 0
	}, r = [
		"true",
		"false",
		"null"
	], i = {
		scope: "literal",
		beginKeywords: r.join(" ")
	};
	return {
		name: "JSON",
		aliases: ["jsonc", "json5"],
		keywords: { literal: r },
		contains: [
			t,
			n,
			e.APOS_STRING_MODE,
			e.QUOTE_STRING_MODE,
			i,
			xt,
			e.C_LINE_COMMENT_MODE,
			e.C_BLOCK_COMMENT_MODE
		],
		illegal: "\\S"
	};
}
// node_modules/highlight.js/es/languages/kotlin.js
var Ct = "[0-9](_*[0-9])*", wt = `\\.(${Ct})`, Tt = "[0-9a-fA-F](_*[0-9a-fA-F])*", Et = {
	className: "number",
	variants: [
		{ begin: `(\\b(${Ct})((${wt})|\\.)?|(${wt}))[eE][+-]?(${Ct})[fFdD]?\\b` },
		{ begin: `\\b(${Ct})((${wt})[fFdD]?\\b|\\.([fFdD]\\b)?)` },
		{ begin: `(${wt})[fFdD]?\\b` },
		{ begin: `\\b(${Ct})[fFdD]\\b` },
		{ begin: `\\b0[xX]((${Tt})\\.?|(${Tt})?\\.(${Tt}))[pP][+-]?(${Ct})[fFdD]?\\b` },
		{ begin: "\\b(0|[1-9](_*[0-9])*)[lL]?\\b" },
		{ begin: `\\b0[xX](${Tt})[lL]?\\b` },
		{ begin: "\\b0(_*[0-7])*[lL]?\\b" },
		{ begin: "\\b0[bB][01](_*[01])*[lL]?\\b" }
	],
	relevance: 0
};
function Dt(e) {
	let t = {
		keyword: "abstract as val var vararg get set class object open private protected public noinline crossinline dynamic final enum if else do while for when throw try catch finally import package is in fun override companion reified inline lateinit init interface annotation data sealed internal infix operator out by constructor super tailrec where const inner suspend typealias external expect actual",
		built_in: "Byte Short Char Int Long Boolean Float Double Void Unit Nothing",
		literal: "true false null"
	}, n = {
		className: "keyword",
		begin: /\b(break|continue|return|this)\b/,
		starts: { contains: [{
			className: "symbol",
			begin: /@\w+/
		}] }
	}, r = {
		className: "symbol",
		begin: e.UNDERSCORE_IDENT_RE + "@"
	}, i = {
		className: "subst",
		begin: /\$\{/,
		end: /\}/,
		contains: [e.C_NUMBER_MODE]
	}, a = {
		className: "variable",
		begin: "\\$" + e.UNDERSCORE_IDENT_RE
	}, o = {
		className: "string",
		variants: [
			{
				begin: "\"\"\"",
				end: "\"\"\"(?=[^\"])",
				contains: [a, i]
			},
			{
				begin: "'",
				end: "'",
				illegal: /\n/,
				contains: [e.BACKSLASH_ESCAPE]
			},
			{
				begin: "\"",
				end: "\"",
				illegal: /\n/,
				contains: [
					e.BACKSLASH_ESCAPE,
					a,
					i
				]
			}
		]
	};
	i.contains.push(o);
	let s = {
		className: "meta",
		begin: "@(?:file|property|field|get|set|receiver|param|setparam|delegate)\\s*:(?:\\s*" + e.UNDERSCORE_IDENT_RE + ")?"
	}, c = {
		className: "meta",
		begin: "@" + e.UNDERSCORE_IDENT_RE,
		contains: [{
			begin: /\(/,
			end: /\)/,
			contains: [e.inherit(o, { className: "string" }), "self"]
		}]
	}, l = Et, u = e.COMMENT("/\\*", "\\*/", { contains: [e.C_BLOCK_COMMENT_MODE] }), d = { variants: [{
		className: "type",
		begin: e.UNDERSCORE_IDENT_RE
	}, {
		begin: /\(/,
		end: /\)/,
		contains: []
	}] }, f = d;
	return f.variants[1].contains = [d], d.variants[1].contains = [f], {
		name: "Kotlin",
		aliases: ["kt", "kts"],
		keywords: t,
		contains: [
			e.COMMENT("/\\*\\*", "\\*/", {
				relevance: 0,
				contains: [{
					className: "doctag",
					begin: "@[A-Za-z]+"
				}]
			}),
			e.C_LINE_COMMENT_MODE,
			u,
			n,
			r,
			s,
			c,
			{
				className: "function",
				beginKeywords: "fun",
				end: "[(]|$",
				returnBegin: !0,
				excludeEnd: !0,
				keywords: t,
				relevance: 5,
				contains: [
					{
						begin: e.UNDERSCORE_IDENT_RE + "\\s*\\(",
						returnBegin: !0,
						relevance: 0,
						contains: [e.UNDERSCORE_TITLE_MODE]
					},
					{
						className: "type",
						begin: /</,
						end: />/,
						keywords: "reified",
						relevance: 0
					},
					{
						className: "params",
						begin: /\(/,
						end: /\)/,
						endsParent: !0,
						keywords: t,
						relevance: 0,
						contains: [
							{
								begin: /:/,
								end: /[=,\/]/,
								endsWithParent: !0,
								contains: [
									d,
									e.C_LINE_COMMENT_MODE,
									u
								],
								relevance: 0
							},
							e.C_LINE_COMMENT_MODE,
							u,
							s,
							c,
							o,
							e.C_NUMBER_MODE
						]
					},
					u
				]
			},
			{
				begin: [
					/class|interface|trait/,
					/\s+/,
					e.UNDERSCORE_IDENT_RE
				],
				beginScope: { 3: "title.class" },
				keywords: "class interface trait",
				end: /[:\{(]|$/,
				excludeEnd: !0,
				illegal: "extends implements",
				contains: [
					{ beginKeywords: "public protected internal private constructor" },
					e.UNDERSCORE_TITLE_MODE,
					{
						className: "type",
						begin: /</,
						end: />/,
						excludeBegin: !0,
						excludeEnd: !0,
						relevance: 0
					},
					{
						className: "type",
						begin: /[,:]\s*/,
						end: /[<\(,){\s]|$/,
						excludeBegin: !0,
						returnEnd: !0
					},
					s,
					c
				]
			},
			o,
			{
				className: "meta",
				begin: "^#!/usr/bin/env",
				end: "$",
				illegal: "\n"
			},
			l
		]
	};
}
// node_modules/highlight.js/es/languages/less.js
var Ot = (e) => ({
	IMPORTANT: {
		scope: "meta",
		begin: "!important"
	},
	BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
	HEXCOLOR: {
		scope: "number",
		begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
	},
	UNICODE_RANGE: {
		scope: "number",
		begin: /\b[Uu]\+[0-9A-Fa-f][0-9A-Fa-f?]{0,4}(-[0-9A-Fa-f][0-9A-Fa-f]{0,4})?/
	},
	FUNCTION_DISPATCH: {
		className: "built_in",
		begin: /[\w-]+(?=\()/
	},
	ATTRIBUTE_SELECTOR_MODE: {
		scope: "selector-attr",
		begin: /\[/,
		end: /\]/,
		illegal: "$",
		contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
	},
	CSS_NUMBER_MODE: {
		scope: "number",
		begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
		relevance: 0
	},
	CSS_VARIABLE: {
		className: "attr",
		begin: /--[A-Za-z_][A-Za-z0-9_-]*/
	}
}), kt = /* @__PURE__ */ "a.abbr.address.article.aside.audio.b.blockquote.body.button.canvas.caption.cite.code.dd.del.details.dfn.div.dl.dt.em.fieldset.figcaption.figure.footer.form.h1.h2.h3.h4.h5.h6.header.hgroup.html.i.iframe.img.input.ins.kbd.label.legend.li.main.mark.menu.nav.object.ol.optgroup.option.p.picture.q.quote.samp.section.select.source.span.strong.summary.sup.table.tbody.td.textarea.tfoot.th.thead.time.tr.ul.var.video".split("."), At = /* @__PURE__ */ "defs.g.marker.mask.pattern.svg.switch.symbol.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feFlood.feGaussianBlur.feImage.feMerge.feMorphology.feOffset.feSpecularLighting.feTile.feTurbulence.linearGradient.radialGradient.stop.circle.ellipse.image.line.path.polygon.polyline.rect.text.use.textPath.tspan.foreignObject.clipPath".split("."), jt = [...kt, ...At], Mt = (/* @__PURE__ */ "any-hover.any-pointer.aspect-ratio.color.color-gamut.color-index.device-aspect-ratio.device-height.device-width.display-mode.forced-colors.grid.height.hover.inverted-colors.monochrome.orientation.overflow-block.overflow-inline.pointer.prefers-color-scheme.prefers-contrast.prefers-reduced-motion.prefers-reduced-transparency.resolution.scan.scripting.update.width.min-width.max-width.min-height.max-height".split(".")).sort().reverse(), Nt = (/* @__PURE__ */ "active.any-link.blank.checked.current.default.defined.dir.disabled.drop.empty.enabled.first.first-child.first-of-type.fullscreen.future.focus.focus-visible.focus-within.has.host.host-context.hover.indeterminate.in-range.invalid.is.lang.last-child.last-of-type.left.link.local-link.not.nth-child.nth-col.nth-last-child.nth-last-col.nth-last-of-type.nth-of-type.only-child.only-of-type.optional.out-of-range.past.placeholder-shown.read-only.read-write.required.right.root.scope.target.target-within.user-invalid.valid.visited.where".split(".")).sort().reverse(), Pt = [
	"after",
	"backdrop",
	"before",
	"cue",
	"cue-region",
	"first-letter",
	"first-line",
	"grammar-error",
	"marker",
	"part",
	"placeholder",
	"selection",
	"slotted",
	"spelling-error"
].sort().reverse(), Ft = (/* @__PURE__ */ "accent-color.align-content.align-items.align-self.alignment-baseline.all.anchor-name.animation.animation-composition.animation-delay.animation-direction.animation-duration.animation-fill-mode.animation-iteration-count.animation-name.animation-play-state.animation-range.animation-range-end.animation-range-start.animation-timeline.animation-timing-function.appearance.aspect-ratio.backdrop-filter.backface-visibility.background.background-attachment.background-blend-mode.background-clip.background-color.background-image.background-origin.background-position.background-position-x.background-position-y.background-repeat.background-size.baseline-shift.block-size.border.border-block.border-block-color.border-block-end.border-block-end-color.border-block-end-style.border-block-end-width.border-block-start.border-block-start-color.border-block-start-style.border-block-start-width.border-block-style.border-block-width.border-bottom.border-bottom-color.border-bottom-left-radius.border-bottom-right-radius.border-bottom-style.border-bottom-width.border-collapse.border-color.border-end-end-radius.border-end-start-radius.border-image.border-image-outset.border-image-repeat.border-image-slice.border-image-source.border-image-width.border-inline.border-inline-color.border-inline-end.border-inline-end-color.border-inline-end-style.border-inline-end-width.border-inline-start.border-inline-start-color.border-inline-start-style.border-inline-start-width.border-inline-style.border-inline-width.border-left.border-left-color.border-left-style.border-left-width.border-radius.border-right.border-right-color.border-right-style.border-right-width.border-spacing.border-start-end-radius.border-start-start-radius.border-style.border-top.border-top-color.border-top-left-radius.border-top-right-radius.border-top-style.border-top-width.border-width.bottom.box-align.box-decoration-break.box-direction.box-flex.box-flex-group.box-lines.box-ordinal-group.box-orient.box-pack.box-shadow.box-sizing.break-after.break-before.break-inside.caption-side.caret-color.clear.clip.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-profile.color-rendering.color-scheme.column-count.column-fill.column-gap.column-rule.column-rule-color.column-rule-style.column-rule-width.column-span.column-width.columns.contain.contain-intrinsic-block-size.contain-intrinsic-height.contain-intrinsic-inline-size.contain-intrinsic-size.contain-intrinsic-width.container.container-name.container-type.content.content-visibility.counter-increment.counter-reset.counter-set.cue.cue-after.cue-before.cursor.cx.cy.direction.display.dominant-baseline.empty-cells.enable-background.field-sizing.fill.fill-opacity.fill-rule.filter.flex.flex-basis.flex-direction.flex-flow.flex-grow.flex-shrink.flex-wrap.float.flood-color.flood-opacity.flow.font.font-display.font-family.font-feature-settings.font-kerning.font-language-override.font-optical-sizing.font-palette.font-size.font-size-adjust.font-smooth.font-smoothing.font-stretch.font-style.font-synthesis.font-synthesis-position.font-synthesis-small-caps.font-synthesis-style.font-synthesis-weight.font-variant.font-variant-alternates.font-variant-caps.font-variant-east-asian.font-variant-emoji.font-variant-ligatures.font-variant-numeric.font-variant-position.font-variation-settings.font-weight.forced-color-adjust.gap.glyph-orientation-horizontal.glyph-orientation-vertical.grid.grid-area.grid-auto-columns.grid-auto-flow.grid-auto-rows.grid-column.grid-column-end.grid-column-start.grid-gap.grid-row.grid-row-end.grid-row-start.grid-template.grid-template-areas.grid-template-columns.grid-template-rows.hanging-punctuation.height.hyphenate-character.hyphenate-limit-chars.hyphens.icon.image-orientation.image-rendering.image-resolution.ime-mode.initial-letter.initial-letter-align.inline-size.inset.inset-area.inset-block.inset-block-end.inset-block-start.inset-inline.inset-inline-end.inset-inline-start.isolation.justify-content.justify-items.justify-self.kerning.left.letter-spacing.lighting-color.line-break.line-height.line-height-step.list-style.list-style-image.list-style-position.list-style-type.margin.margin-block.margin-block-end.margin-block-start.margin-bottom.margin-inline.margin-inline-end.margin-inline-start.margin-left.margin-right.margin-top.margin-trim.marker.marker-end.marker-mid.marker-start.marks.mask.mask-border.mask-border-mode.mask-border-outset.mask-border-repeat.mask-border-slice.mask-border-source.mask-border-width.mask-clip.mask-composite.mask-image.mask-mode.mask-origin.mask-position.mask-repeat.mask-size.mask-type.masonry-auto-flow.math-depth.math-shift.math-style.max-block-size.max-height.max-inline-size.max-width.min-block-size.min-height.min-inline-size.min-width.mix-blend-mode.nav-down.nav-index.nav-left.nav-right.nav-up.none.normal.object-fit.object-position.offset.offset-anchor.offset-distance.offset-path.offset-position.offset-rotate.opacity.order.orphans.outline.outline-color.outline-offset.outline-style.outline-width.overflow.overflow-anchor.overflow-block.overflow-clip-margin.overflow-inline.overflow-wrap.overflow-x.overflow-y.overlay.overscroll-behavior.overscroll-behavior-block.overscroll-behavior-inline.overscroll-behavior-x.overscroll-behavior-y.padding.padding-block.padding-block-end.padding-block-start.padding-bottom.padding-inline.padding-inline-end.padding-inline-start.padding-left.padding-right.padding-top.page.page-break-after.page-break-before.page-break-inside.paint-order.pause.pause-after.pause-before.perspective.perspective-origin.place-content.place-items.place-self.pointer-events.position.position-anchor.position-visibility.print-color-adjust.quotes.r.resize.rest.rest-after.rest-before.right.rotate.row-gap.ruby-align.ruby-position.scale.scroll-behavior.scroll-margin.scroll-margin-block.scroll-margin-block-end.scroll-margin-block-start.scroll-margin-bottom.scroll-margin-inline.scroll-margin-inline-end.scroll-margin-inline-start.scroll-margin-left.scroll-margin-right.scroll-margin-top.scroll-padding.scroll-padding-block.scroll-padding-block-end.scroll-padding-block-start.scroll-padding-bottom.scroll-padding-inline.scroll-padding-inline-end.scroll-padding-inline-start.scroll-padding-left.scroll-padding-right.scroll-padding-top.scroll-snap-align.scroll-snap-stop.scroll-snap-type.scroll-timeline.scroll-timeline-axis.scroll-timeline-name.scrollbar-color.scrollbar-gutter.scrollbar-width.shape-image-threshold.shape-margin.shape-outside.shape-rendering.speak.speak-as.src.stop-color.stop-opacity.stroke.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke-width.tab-size.table-layout.text-align.text-align-all.text-align-last.text-anchor.text-combine-upright.text-decoration.text-decoration-color.text-decoration-line.text-decoration-skip.text-decoration-skip-ink.text-decoration-style.text-decoration-thickness.text-emphasis.text-emphasis-color.text-emphasis-position.text-emphasis-style.text-indent.text-justify.text-orientation.text-overflow.text-rendering.text-shadow.text-size-adjust.text-transform.text-underline-offset.text-underline-position.text-wrap.text-wrap-mode.text-wrap-style.timeline-scope.top.touch-action.transform.transform-box.transform-origin.transform-style.transition.transition-behavior.transition-delay.transition-duration.transition-property.transition-timing-function.translate.unicode-bidi.unicode-range.user-modify.user-select.vector-effect.vertical-align.view-timeline.view-timeline-axis.view-timeline-inset.view-timeline-name.view-transition-name.visibility.voice-balance.voice-duration.voice-family.voice-pitch.voice-range.voice-rate.voice-stress.voice-volume.white-space.white-space-collapse.widows.width.will-change.word-break.word-spacing.word-wrap.writing-mode.x.y.z-index.zoom".split(".")).sort().reverse(), It = Nt.concat(Pt).sort().reverse();
function Lt(e) {
	let t = Ot(e), n = It, r = "([\\w-]+|@\\{[\\w-]+\\})", i = [], a = [], o = function(e) {
		return {
			className: "string",
			begin: "~?" + e + ".*?" + e
		};
	}, s = function(e, t, n) {
		return {
			className: e,
			begin: t,
			relevance: n
		};
	}, c = {
		$pattern: /[a-z-]+/,
		keyword: "and or not only",
		attribute: Mt.join(" ")
	}, l = {
		begin: "\\(",
		end: "\\)",
		contains: a,
		keywords: c,
		relevance: 0
	};
	a.push(e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, o("'"), o("\""), t.CSS_NUMBER_MODE, {
		begin: "(url|data-uri)\\(",
		starts: {
			className: "string",
			end: "[\\)\\n]",
			excludeEnd: !0
		}
	}, t.UNICODE_RANGE, t.HEXCOLOR, l, s("variable", "@@?[\\w-]+", 10), s("variable", "@\\{[\\w-]+\\}"), s("built_in", "~?`[^`]*?`"), {
		className: "attribute",
		begin: "[\\w-]+\\s*:",
		end: ":",
		returnBegin: !0,
		excludeEnd: !0
	}, t.IMPORTANT, { beginKeywords: "and not" }, t.FUNCTION_DISPATCH);
	let u = a.concat({
		begin: /\{/,
		end: /\}/,
		contains: i
	}), d = {
		beginKeywords: "when",
		endsWithParent: !0,
		contains: [{ beginKeywords: "and not" }].concat(a)
	}, f = {
		begin: r + "\\s*:",
		returnBegin: !0,
		end: /[;}]/,
		relevance: 0,
		contains: [
			{ begin: /-(webkit|moz|ms|o)-/ },
			t.CSS_VARIABLE,
			{
				className: "attribute",
				begin: "\\b(" + Ft.join("|") + ")\\b",
				end: /(?=:)/,
				starts: {
					endsWithParent: !0,
					illegal: "[<=$]",
					relevance: 0,
					contains: a
				}
			}
		]
	}, p = {
		className: "keyword",
		begin: "@(import|media|charset|font-face|(-[a-z]+-)?keyframes|supports|document|namespace|page|viewport|host)\\b",
		starts: {
			end: "[;{}]",
			keywords: c,
			returnEnd: !0,
			contains: a,
			relevance: 0
		}
	}, m = {
		className: "variable",
		variants: [{
			begin: "@[\\w-]+\\s*:",
			relevance: 15
		}, { begin: "@[\\w-]+" }],
		starts: {
			end: "[;}]",
			returnEnd: !0,
			contains: u
		}
	}, h = {
		variants: [{
			begin: "[\\.#:&\\[>]",
			end: "[;{}]"
		}, {
			begin: r,
			end: /\{/
		}],
		returnBegin: !0,
		returnEnd: !0,
		illegal: "[<='$\"]",
		relevance: 0,
		contains: [
			e.C_LINE_COMMENT_MODE,
			e.C_BLOCK_COMMENT_MODE,
			d,
			s("keyword", "all\\b"),
			s("variable", "@\\{[\\w-]+\\}"),
			{
				begin: "\\b(" + jt.join("|") + ")\\b",
				className: "selector-tag"
			},
			t.CSS_NUMBER_MODE,
			s("selector-tag", r, 0),
			s("selector-id", "#" + r),
			s("selector-class", "\\." + r, 0),
			s("selector-tag", "&", 0),
			t.ATTRIBUTE_SELECTOR_MODE,
			{
				className: "selector-pseudo",
				begin: ":(" + Nt.join("|") + ")"
			},
			{
				className: "selector-pseudo",
				begin: ":(:)?(" + Pt.join("|") + ")"
			},
			{
				begin: /\(/,
				end: /\)/,
				relevance: 0,
				contains: u
			},
			{ begin: "!important" },
			t.FUNCTION_DISPATCH
		]
	}, g = {
		begin: `[\\w-]+:(:)?(${n.join("|")})`,
		returnBegin: !0,
		contains: [h]
	};
	return i.push(e.C_LINE_COMMENT_MODE, e.C_BLOCK_COMMENT_MODE, p, m, g, f, h, d, t.FUNCTION_DISPATCH), {
		name: "Less",
		case_insensitive: !0,
		illegal: "[=>'/<($\"]",
		contains: i
	};
}
// node_modules/highlight.js/es/languages/lua.js
function Rt(e) {
	let t = "\\[=*\\[", n = "\\]=*\\]", r = {
		begin: t,
		end: n,
		contains: ["self"]
	}, i = [e.COMMENT("--(?!\\[=*\\[)", "$"), e.COMMENT("--\\[=*\\[", n, {
		contains: [r],
		relevance: 10
	})];
	return {
		name: "Lua",
		aliases: ["pluto"],
		keywords: {
			$pattern: e.UNDERSCORE_IDENT_RE,
			literal: "true false nil",
			keyword: "and break do else elseif end for goto if in local not or repeat return then until while",
			built_in: "_G _ENV _VERSION __index __newindex __mode __call __metatable __tostring __len __gc __add __sub __mul __div __mod __pow __concat __unm __eq __lt __le assert collectgarbage dofile error getfenv getmetatable ipairs load loadfile loadstring module next pairs pcall print rawequal rawget rawset require select setfenv setmetatable tonumber tostring type unpack xpcall arg self coroutine resume yield status wrap create running debug getupvalue debug sethook getmetatable gethook setmetatable setlocal traceback setfenv getinfo setupvalue getlocal getregistry getfenv io lines write close flush open output type read stderr stdin input stdout popen tmpfile math log max acos huge ldexp pi cos tanh pow deg tan cosh sinh random randomseed frexp ceil floor rad abs sqrt modf asin min mod fmod log10 atan2 exp sin atan os exit setlocale date getenv difftime remove time clock tmpname rename execute package preload loadlib loaded loaders cpath config path seeall string sub upper len gfind rep find match char dump gmatch reverse byte format gsub lower table setn insert getn foreachi maxn foreach concat sort remove"
		},
		contains: i.concat([
			{
				className: "function",
				beginKeywords: "function",
				end: "\\)",
				contains: [e.inherit(e.TITLE_MODE, { begin: "([_a-zA-Z]\\w*\\.)*([_a-zA-Z]\\w*:)?[_a-zA-Z]\\w*" }), {
					className: "params",
					begin: "\\(",
					endsWithParent: !0,
					contains: i
				}].concat(i)
			},
			e.C_NUMBER_MODE,
			e.APOS_STRING_MODE,
			e.QUOTE_STRING_MODE,
			{
				className: "string",
				begin: t,
				end: n,
				contains: [r],
				relevance: 5
			}
		])
	};
}
// node_modules/highlight.js/es/languages/makefile.js
function zt(e) {
	let t = {
		className: "variable",
		variants: [{
			begin: "\\$\\(" + e.UNDERSCORE_IDENT_RE + "\\)",
			contains: [e.BACKSLASH_ESCAPE]
		}, { begin: /\$[@%<?\^\+\*]/ }]
	}, n = {
		className: "string",
		begin: /"/,
		end: /"/,
		contains: [e.BACKSLASH_ESCAPE, t]
	}, r = {
		className: "variable",
		begin: /\$\([\w-]+\s/,
		end: /\)/,
		keywords: { built_in: "subst patsubst strip findstring filter filter-out sort word wordlist firstword lastword dir notdir suffix basename addsuffix addprefix join wildcard realpath abspath error warning shell origin flavor foreach if or and call eval file value" },
		contains: [t, n]
	}, i = { begin: "^" + e.UNDERSCORE_IDENT_RE + "\\s*(?=[:+?]?=)" }, a = {
		className: "meta",
		begin: /^\.PHONY:/,
		end: /$/,
		keywords: {
			$pattern: /[\.\w]+/,
			keyword: ".PHONY"
		}
	}, o = {
		className: "section",
		begin: /^[^\s]+:/,
		end: /$/,
		contains: [t]
	};
	return {
		name: "Makefile",
		aliases: [
			"mk",
			"mak",
			"make"
		],
		keywords: {
			$pattern: /[\w-]+/,
			keyword: "define endef undefine ifdef ifndef ifeq ifneq else endif include -include sinclude override export unexport private vpath"
		},
		contains: [
			e.HASH_COMMENT_MODE,
			t,
			n,
			r,
			i,
			a,
			o
		]
	};
}
// node_modules/highlight.js/es/languages/markdown.js
function Bt(e) {
	let t = e.regex, n = {
		begin: /<\/?[A-Za-z_]/,
		end: ">",
		subLanguage: "xml",
		relevance: 0
	}, r = {
		begin: "^[-\\*]{3,}",
		end: "$"
	}, i = {
		className: "code",
		variants: [
			{ begin: "(`{3,})[^`](.|\\n)*?\\1`*[ ]*" },
			{ begin: "(~{3,})[^~](.|\\n)*?\\1~*[ ]*" },
			{
				begin: "```",
				end: "```+[ ]*$"
			},
			{
				begin: "~~~",
				end: "~~~+[ ]*$"
			},
			{ begin: "`.+?`" },
			{
				begin: "(?=^( {4}|\\t))",
				contains: [{
					begin: "^( {4}|\\t)",
					end: "(\\n)$"
				}],
				relevance: 0
			}
		]
	}, a = {
		className: "bullet",
		begin: "^[ 	]*([*+-]|(\\d+\\.))(?=\\s+)",
		end: "\\s+",
		excludeEnd: !0
	}, o = {
		begin: /^\[[^\n]+\]:/,
		returnBegin: !0,
		contains: [{
			className: "symbol",
			begin: /\[/,
			end: /\]/,
			excludeBegin: !0,
			excludeEnd: !0
		}, {
			className: "link",
			begin: /:\s*/,
			end: /$/,
			excludeBegin: !0
		}]
	}, s = {
		variants: [
			{
				begin: /\[.+?\]\[.*?\]/,
				relevance: 0
			},
			{
				begin: /\[.+?\]\(((data|javascript|mailto):|(?:http|ftp)s?:\/\/).*?\)/,
				relevance: 2
			},
			{
				begin: t.concat(/\[.+?\]\(/, /[A-Za-z][A-Za-z0-9+.-]*/, /:\/\/.*?\)/),
				relevance: 2
			},
			{
				begin: /\[.+?\]\([./?&#].*?\)/,
				relevance: 1
			},
			{
				begin: /\[.*?\]\(.*?\)/,
				relevance: 0
			}
		],
		returnBegin: !0,
		contains: [
			{ match: /\[(?=\])/ },
			{
				className: "string",
				relevance: 0,
				begin: "\\[",
				end: "\\]",
				excludeBegin: !0,
				returnEnd: !0
			},
			{
				className: "link",
				relevance: 0,
				begin: "\\]\\(",
				end: "\\)",
				excludeBegin: !0,
				excludeEnd: !0
			},
			{
				className: "symbol",
				relevance: 0,
				begin: "\\]\\[",
				end: "\\]",
				excludeBegin: !0,
				excludeEnd: !0
			}
		]
	}, c = {
		className: "strong",
		contains: [],
		variants: [{
			begin: /_{2}(?!\s)/,
			end: /_{2}/
		}, {
			begin: /\*{2}(?!\s)/,
			end: /\*{2}/
		}]
	}, l = {
		className: "emphasis",
		contains: [],
		variants: [{
			begin: /\*(?![*\s])/,
			end: /\*/
		}, {
			begin: /_(?![_\s])/,
			end: /_/,
			relevance: 0
		}]
	}, u = e.inherit(c, { contains: [] }), d = e.inherit(l, { contains: [] });
	c.contains.push(d), l.contains.push(u);
	let f = [n, s];
	return [
		c,
		l,
		u,
		d
	].forEach((e) => {
		e.contains = e.contains.concat(f);
	}), f = f.concat(c, l), {
		name: "Markdown",
		aliases: [
			"md",
			"mkdown",
			"mkd"
		],
		contains: [
			{
				className: "section",
				variants: [{
					begin: "^#{1,6}",
					end: "$",
					contains: f
				}, {
					begin: "(?=^.+?\\n[=-]{2,}$)",
					contains: [{ begin: "^[=-]*$" }, {
						begin: "^",
						end: "\\n",
						contains: f
					}]
				}]
			},
			n,
			a,
			c,
			l,
			{
				className: "quote",
				begin: "^>\\s+",
				contains: f,
				end: "$"
			},
			i,
			r,
			s,
			o,
			{
				scope: "literal",
				match: /&([a-zA-Z0-9]+|#[0-9]{1,7}|#[Xx][0-9a-fA-F]{1,6});/
			}
		]
	};
}
// node_modules/highlight.js/es/languages/objectivec.js
function Vt(e) {
	let t = {
		className: "built_in",
		begin: "\\b(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)\\w+"
	}, n = /[a-zA-Z@][a-zA-Z0-9_]*/, r = {
		"variable.language": ["this", "super"],
		$pattern: n,
		keyword: /* @__PURE__ */ "while.export.sizeof.typedef.const.struct.for.union.volatile.static.mutable.if.do.return.goto.enum.else.break.extern.asm.case.default.register.explicit.typename.switch.continue.inline.readonly.assign.readwrite.self.@synchronized.id.typeof.nonatomic.IBOutlet.IBAction.strong.weak.copy.in.out.inout.bycopy.byref.oneway.__strong.__weak.__block.__autoreleasing.@private.@protected.@public.@try.@property.@end.@throw.@catch.@finally.@autoreleasepool.@synthesize.@dynamic.@selector.@optional.@required.@encode.@package.@import.@defs.@compatibility_alias.__bridge.__bridge_transfer.__bridge_retained.__bridge_retain.__covariant.__contravariant.__kindof._Nonnull._Nullable._Null_unspecified.__FUNCTION__.__PRETTY_FUNCTION__.__attribute__.getter.setter.retain.unsafe_unretained.nonnull.nullable.null_unspecified.null_resettable.class.instancetype.NS_DESIGNATED_INITIALIZER.NS_UNAVAILABLE.NS_REQUIRES_SUPER.NS_RETURNS_INNER_POINTER.NS_INLINE.NS_AVAILABLE.NS_DEPRECATED.NS_ENUM.NS_OPTIONS.NS_SWIFT_UNAVAILABLE.NS_ASSUME_NONNULL_BEGIN.NS_ASSUME_NONNULL_END.NS_REFINED_FOR_SWIFT.NS_SWIFT_NAME.NS_SWIFT_NOTHROW.NS_DURING.NS_HANDLER.NS_ENDHANDLER.NS_VALUERETURN.NS_VOIDRETURN".split("."),
		literal: [
			"false",
			"true",
			"FALSE",
			"TRUE",
			"nil",
			"YES",
			"NO",
			"NULL"
		],
		built_in: [
			"dispatch_once_t",
			"dispatch_queue_t",
			"dispatch_sync",
			"dispatch_async",
			"dispatch_once"
		],
		type: [
			"int",
			"float",
			"char",
			"unsigned",
			"signed",
			"short",
			"long",
			"double",
			"wchar_t",
			"unichar",
			"void",
			"bool",
			"BOOL",
			"id|0",
			"_Bool"
		]
	}, i = {
		$pattern: n,
		keyword: [
			"@interface",
			"@class",
			"@protocol",
			"@implementation"
		]
	};
	return {
		name: "Objective-C",
		aliases: [
			"mm",
			"objc",
			"obj-c",
			"obj-c++",
			"objective-c++"
		],
		keywords: r,
		illegal: "</",
		contains: [
			t,
			e.C_LINE_COMMENT_MODE,
			e.C_BLOCK_COMMENT_MODE,
			e.C_NUMBER_MODE,
			e.QUOTE_STRING_MODE,
			e.APOS_STRING_MODE,
			{
				className: "string",
				variants: [{
					begin: "@\"",
					end: "\"",
					illegal: "\\n",
					contains: [e.BACKSLASH_ESCAPE]
				}]
			},
			{
				className: "meta",
				begin: /#\s*[a-z]+\b/,
				end: /$/,
				keywords: { keyword: "if else elif endif define undef warning error line pragma ifdef ifndef include" },
				contains: [
					{
						begin: /\\\n/,
						relevance: 0
					},
					e.inherit(e.QUOTE_STRING_MODE, { className: "string" }),
					{
						className: "string",
						begin: /<.*?>/,
						end: /$/,
						illegal: "\\n"
					},
					e.C_LINE_COMMENT_MODE,
					e.C_BLOCK_COMMENT_MODE
				]
			},
			{
				className: "class",
				begin: "(" + i.keyword.join("|") + ")\\b",
				end: /(\{|$)/,
				excludeEnd: !0,
				keywords: i,
				contains: [e.UNDERSCORE_TITLE_MODE]
			},
			{
				begin: "\\." + e.UNDERSCORE_IDENT_RE,
				relevance: 0
			}
		]
	};
}
// node_modules/highlight.js/es/languages/perl.js
function Ht(e) {
	let t = e.regex, n = /* @__PURE__ */ "abs.accept.alarm.and.atan2.bind.binmode.bless.break.caller.chdir.chmod.chomp.chop.chown.chr.chroot.class.close.closedir.connect.continue.cos.crypt.dbmclose.dbmopen.defined.delete.die.do.dump.each.else.elsif.endgrent.endhostent.endnetent.endprotoent.endpwent.endservent.eof.eval.exec.exists.exit.exp.fcntl.field.fileno.flock.for.foreach.fork.format.formline.getc.getgrent.getgrgid.getgrnam.gethostbyaddr.gethostbyname.gethostent.getlogin.getnetbyaddr.getnetbyname.getnetent.getpeername.getpgrp.getpriority.getprotobyname.getprotobynumber.getprotoent.getpwent.getpwnam.getpwuid.getservbyname.getservbyport.getservent.getsockname.getsockopt.given.glob.gmtime.goto.grep.gt.hex.if.index.int.ioctl.join.keys.kill.last.lc.lcfirst.length.link.listen.local.localtime.log.lstat.lt.ma.map.method.mkdir.msgctl.msgget.msgrcv.msgsnd.my.ne.next.no.not.oct.open.opendir.or.ord.our.pack.package.pipe.pop.pos.print.printf.prototype.push.q|0.qq.quotemeta.qw.qx.rand.read.readdir.readline.readlink.readpipe.recv.redo.ref.rename.require.reset.return.reverse.rewinddir.rindex.rmdir.say.scalar.seek.seekdir.select.semctl.semget.semop.send.setgrent.sethostent.setnetent.setpgrp.setpriority.setprotoent.setpwent.setservent.setsockopt.shift.shmctl.shmget.shmread.shmwrite.shutdown.sin.sleep.socket.socketpair.sort.splice.split.sprintf.sqrt.srand.stat.state.study.sub.substr.symlink.syscall.sysopen.sysread.sysseek.system.syswrite.tell.telldir.tie.tied.time.times.tr.truncate.uc.ucfirst.umask.undef.unless.unlink.unpack.unshift.untie.until.use.utime.values.vec.wait.waitpid.wantarray.warn.when.while.write.x|0.xor.y|0".split("."), r = /[dualxmsipngr]{0,12}/, i = {
		$pattern: /[\w.]+/,
		keyword: n.join(" ")
	}, a = {
		className: "subst",
		begin: "[$@]\\{",
		end: "\\}",
		keywords: i
	}, o = {
		begin: /->\{/,
		end: /\}/
	}, s = {
		scope: "attr",
		match: /\s+:\s*\w+(\s*\(.*?\))?/
	}, c = {
		scope: "variable",
		variants: [
			{ begin: /\$\d/ },
			{ begin: t.concat(/[$%@](?!")(\^\w\b|#\w+(::\w+)*|\{\w+\}|\w+(::\w*)*)/, "(?![A-Za-z])(?![@$%])") },
			{
				begin: /[$%@](?!")[^\s\w{=]|\$=/,
				relevance: 0
			}
		],
		contains: [s]
	}, l = {
		className: "number",
		variants: [
			{ match: /0?\.[0-9][0-9_]+\b/ },
			{ match: /\bv?(0|[1-9][0-9_]*(\.[0-9_]+)?|[1-9][0-9_]*)\b/ },
			{ match: /\b0[0-7][0-7_]*\b/ },
			{ match: /\b0x[0-9a-fA-F][0-9a-fA-F_]*\b/ },
			{ match: /\b0b[0-1][0-1_]*\b/ }
		],
		relevance: 0
	}, u = [
		e.BACKSLASH_ESCAPE,
		a,
		c
	], d = [
		/!/,
		/\//,
		/\|/,
		/\?/,
		/'/,
		/"/,
		/#/
	], f = (e, n, i = "\\1") => {
		let a = i === "\\1" ? i : t.concat(i, n);
		return t.concat(t.concat("(?:", e, ")"), n, /(?:\\.|[^\\\/])*?/, a, /(?:\\.|[^\\\/])*?/, i, r);
	}, p = (e, n, i) => t.concat(t.concat("(?:", e, ")"), n, /(?:\\.|[^\\\/])*?/, i, r), m = [
		c,
		e.HASH_COMMENT_MODE,
		e.COMMENT(/^=\w/, /=cut/, { endsWithParent: !0 }),
		o,
		{
			className: "string",
			contains: u,
			variants: [
				{
					begin: "q[qwxr]?\\s*\\(",
					end: "\\)",
					relevance: 5
				},
				{
					begin: "q[qwxr]?\\s*\\[",
					end: "\\]",
					relevance: 5
				},
				{
					begin: "q[qwxr]?\\s*\\{",
					end: "\\}",
					relevance: 5
				},
				{
					begin: "q[qwxr]?\\s*\\|",
					end: "\\|",
					relevance: 5
				},
				{
					begin: "q[qwxr]?\\s*<",
					end: ">",
					relevance: 5
				},
				{
					begin: "qw\\s+q",
					end: "q",
					relevance: 5
				},
				{
					begin: "'",
					end: "'",
					contains: [e.BACKSLASH_ESCAPE]
				},
				{
					begin: "\"",
					end: "\""
				},
				{
					begin: "`",
					end: "`",
					contains: [e.BACKSLASH_ESCAPE]
				},
				{
					begin: /\{\w+\}/,
					relevance: 0
				},
				{
					begin: "-?\\w+\\s*=>",
					relevance: 0
				}
			]
		},
		l,
		{
			begin: "(\\/\\/|" + e.RE_STARTERS_RE + "|\\b(split|return|print|reverse|grep)\\b)\\s*",
			keywords: "split return print reverse grep",
			relevance: 0,
			contains: [
				e.HASH_COMMENT_MODE,
				{
					className: "regexp",
					variants: [
						{ begin: f("s|tr|y", t.either(...d, { capture: !0 })) },
						{ begin: f("s|tr|y", "\\(", "\\)") },
						{ begin: f("s|tr|y", "\\[", "\\]") },
						{ begin: f("s|tr|y", "\\{", "\\}") }
					],
					relevance: 2
				},
				{
					className: "regexp",
					variants: [
						{
							begin: /(m|qr)\/\//,
							relevance: 0
						},
						{ begin: p("(?:m|qr)?", /\//, /\//) },
						{ begin: p("m|qr", t.either(...d, { capture: !0 }), /\1/) },
						{ begin: p("m|qr", /\(/, /\)/) },
						{ begin: p("m|qr", /\[/, /\]/) },
						{ begin: p("m|qr", /\{/, /\}/) }
					]
				}
			]
		},
		{
			className: "function",
			beginKeywords: "sub method",
			end: "(\\s*\\(.*?\\))?[;{]",
			excludeEnd: !0,
			relevance: 5,
			contains: [e.TITLE_MODE, s]
		},
		{
			className: "class",
			beginKeywords: "class",
			end: "[;{]",
			excludeEnd: !0,
			relevance: 5,
			contains: [
				e.TITLE_MODE,
				s,
				l
			]
		},
		{
			begin: "-\\w\\b",
			relevance: 0
		},
		{
			begin: "^__DATA__$",
			end: "^__END__$",
			subLanguage: "mojolicious",
			contains: [{
				begin: "^@@.*",
				end: "$",
				className: "comment"
			}]
		}
	];
	return a.contains = m, o.contains = m, {
		name: "Perl",
		aliases: ["pl", "pm"],
		keywords: i,
		contains: m
	};
}
// node_modules/highlight.js/es/languages/php.js
function Ut(e) {
	let t = e.regex, n = /(?![A-Za-z0-9])(?![$])/, r = t.concat(/[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*/, n), i = t.concat(/(\\?[A-Z][a-z0-9_\x7f-\xff]+|\\?[A-Z]+(?=[A-Z][a-z0-9_\x7f-\xff])){1,}/, n), a = t.concat(/[A-Z]+/, n), o = {
		scope: "variable",
		match: "\\$+" + r
	}, s = {
		scope: "meta",
		variants: [
			{
				begin: /<\?php/,
				relevance: 10
			},
			{ begin: /<\?=/ },
			{
				begin: /<\?/,
				relevance: .1
			},
			{ begin: /\?>/ }
		]
	}, c = {
		scope: "subst",
		variants: [{ begin: /\$\w+/ }, {
			begin: /\{\$/,
			end: /\}/
		}]
	}, l = e.inherit(e.APOS_STRING_MODE, { illegal: null }), u = e.inherit(e.QUOTE_STRING_MODE, {
		illegal: null,
		contains: e.QUOTE_STRING_MODE.contains.concat(c)
	}), d = {
		begin: /<<<[ \t]*(?:(\w+)|"(\w+)")\n/,
		end: /[ \t]*(\w+)\b/,
		contains: e.QUOTE_STRING_MODE.contains.concat(c),
		"on:begin": (e, t) => {
			t.data._beginMatch = e[1] || e[2];
		},
		"on:end": (e, t) => {
			t.data._beginMatch !== e[1] && t.ignoreMatch();
		}
	}, f = e.END_SAME_AS_BEGIN({
		begin: /<<<[ \t]*'(\w+)'\n/,
		end: /[ \t]*(\w+)\b/
	}), p = "[ 	\n]", m = {
		scope: "string",
		variants: [
			u,
			l,
			d,
			f
		]
	}, h = {
		scope: "number",
		variants: [
			{ begin: "\\b0[bB][01]+(?:_[01]+)*\\b" },
			{ begin: "\\b0[oO][0-7]+(?:_[0-7]+)*\\b" },
			{ begin: "\\b0[xX][\\da-fA-F]+(?:_[\\da-fA-F]+)*\\b" },
			{ begin: "(?:\\b\\d+(?:_\\d+)*(\\.(?:\\d+(?:_\\d+)*))?|\\B\\.\\d+)(?:[eE][+-]?\\d+)?" }
		],
		relevance: 0
	}, g = [
		"false",
		"null",
		"true"
	], _ = /* @__PURE__ */ "__CLASS__.__DIR__.__FILE__.__FUNCTION__.__COMPILER_HALT_OFFSET__.__LINE__.__METHOD__.__NAMESPACE__.__TRAIT__.die.echo.exit.include.include_once.print.require.require_once.array.abstract.and.as.binary.bool.boolean.break.callable.case.catch.class.clone.const.continue.declare.default.do.double.else.elseif.empty.enddeclare.endfor.endforeach.endif.endswitch.endwhile.enum.eval.extends.final.finally.float.for.foreach.from.global.goto.if.implements.instanceof.insteadof.int.integer.interface.isset.iterable.list.match|0.mixed.new.never.object.or.private.protected.public.readonly.real.return.string.switch.throw.trait.try.unset.use.var.void.while.xor.yield".split("."), v = /* @__PURE__ */ "Error|0.AppendIterator.ArgumentCountError.ArithmeticError.ArrayIterator.ArrayObject.AssertionError.BadFunctionCallException.BadMethodCallException.CachingIterator.CallbackFilterIterator.CompileError.Countable.DirectoryIterator.DivisionByZeroError.DomainException.EmptyIterator.ErrorException.Exception.FilesystemIterator.FilterIterator.GlobIterator.InfiniteIterator.InvalidArgumentException.IteratorIterator.LengthException.LimitIterator.LogicException.MultipleIterator.NoRewindIterator.OutOfBoundsException.OutOfRangeException.OuterIterator.OverflowException.ParentIterator.ParseError.RangeException.RecursiveArrayIterator.RecursiveCachingIterator.RecursiveCallbackFilterIterator.RecursiveDirectoryIterator.RecursiveFilterIterator.RecursiveIterator.RecursiveIteratorIterator.RecursiveRegexIterator.RecursiveTreeIterator.RegexIterator.RuntimeException.SeekableIterator.SplDoublyLinkedList.SplFileInfo.SplFileObject.SplFixedArray.SplHeap.SplMaxHeap.SplMinHeap.SplObjectStorage.SplObserver.SplPriorityQueue.SplQueue.SplStack.SplSubject.SplTempFileObject.TypeError.UnderflowException.UnexpectedValueException.UnhandledMatchError.ArrayAccess.BackedEnum.Closure.Fiber.Generator.Iterator.IteratorAggregate.Serializable.Stringable.Throwable.Traversable.UnitEnum.WeakReference.WeakMap.Directory.__PHP_Incomplete_Class.parent.php_user_filter.self.static.stdClass".split("."), y = {
		keyword: _,
		literal: ((e) => {
			let t = [];
			return e.forEach((e) => {
				t.push(e), e.toLowerCase() === e ? t.push(e.toUpperCase()) : t.push(e.toLowerCase());
			}), t;
		})(g),
		built_in: v
	}, b = (e) => e.map((e) => e.replace(/\|\d+$/, "")), x = { variants: [{
		match: [
			/new/,
			t.concat(p, "+"),
			t.concat("(?!", b(v).join("\\b|"), "\\b)"),
			i
		],
		scope: {
			1: "keyword",
			4: "title.class"
		}
	}] }, S = t.concat(r, "\\b(?!\\()"), C = { variants: [
		{
			match: [t.concat(/::/, t.lookahead(/(?!class\b)/)), S],
			scope: { 2: "variable.constant" }
		},
		{
			match: [/::/, /class/],
			scope: { 2: "variable.language" }
		},
		{
			match: [
				i,
				t.concat(/::/, t.lookahead(/(?!class\b)/)),
				S
			],
			scope: {
				1: "title.class",
				3: "variable.constant"
			}
		},
		{
			match: [i, t.concat("::", t.lookahead(/(?!class\b)/))],
			scope: { 1: "title.class" }
		},
		{
			match: [
				i,
				/::/,
				/class/
			],
			scope: {
				1: "title.class",
				3: "variable.language"
			}
		}
	] }, w = {
		scope: "attr",
		match: t.concat(r, t.lookahead(":"), t.lookahead(/(?!::)/))
	}, T = {
		relevance: 0,
		begin: /\(/,
		end: /\)/,
		keywords: y,
		contains: [
			w,
			o,
			C,
			e.C_BLOCK_COMMENT_MODE,
			e.C_LINE_COMMENT_MODE,
			e.HASH_COMMENT_MODE,
			m,
			h,
			x
		]
	}, E = {
		relevance: 0,
		match: [
			/\b/,
			t.concat("(?!fn\\b|function\\b|", b(_).join("\\b|"), "|", b(v).join("\\b|"), "\\b)"),
			r,
			t.concat(p, "*"),
			t.lookahead(/(?=\()/)
		],
		scope: { 3: "title.function.invoke" },
		contains: [T]
	};
	T.contains.push(E);
	let D = [
		w,
		C,
		e.C_BLOCK_COMMENT_MODE,
		e.C_LINE_COMMENT_MODE,
		e.HASH_COMMENT_MODE,
		m,
		h,
		x
	], O = {
		begin: t.concat(/#\[\s*\\?/, t.either(i, a)),
		beginScope: "meta",
		end: /]/,
		endScope: "meta",
		keywords: {
			literal: g,
			keyword: ["new", "array"]
		},
		contains: [
			{
				begin: /\[/,
				end: /]/,
				keywords: {
					literal: g,
					keyword: ["new", "array"]
				},
				contains: ["self", ...D]
			},
			...D,
			{
				scope: "meta",
				variants: [{ match: i }, { match: a }]
			}
		]
	};
	return {
		case_insensitive: !1,
		keywords: y,
		contains: [
			O,
			e.HASH_COMMENT_MODE,
			e.COMMENT("//", "$"),
			e.COMMENT("/\\*", "\\*/", { contains: [{
				scope: "doctag",
				match: "@[A-Za-z]+"
			}] }),
			{
				match: /__halt_compiler\(\);/,
				keywords: "__halt_compiler",
				starts: {
					scope: "comment",
					end: e.MATCH_NOTHING_RE,
					contains: [{
						match: /\?>/,
						scope: "meta",
						endsParent: !0
					}]
				}
			},
			s,
			{
				scope: "variable.language",
				match: /\$this\b/
			},
			o,
			E,
			C,
			{
				match: [
					/const/,
					/\s/,
					r
				],
				scope: {
					1: "keyword",
					3: "variable.constant"
				}
			},
			x,
			{
				scope: "function",
				relevance: 0,
				beginKeywords: "fn function",
				end: /[;{]/,
				excludeEnd: !0,
				illegal: "[$%\\[]",
				contains: [
					{ beginKeywords: "use" },
					e.UNDERSCORE_TITLE_MODE,
					{
						begin: "=>",
						endsParent: !0
					},
					{
						scope: "params",
						begin: "\\(",
						end: "\\)",
						excludeBegin: !0,
						excludeEnd: !0,
						keywords: y,
						contains: [
							"self",
							O,
							o,
							C,
							e.C_BLOCK_COMMENT_MODE,
							e.C_LINE_COMMENT_MODE,
							e.HASH_COMMENT_MODE,
							m,
							h
						]
					}
				]
			},
			{
				scope: "class",
				variants: [{
					beginKeywords: "enum",
					illegal: /[($"]/
				}, {
					beginKeywords: "class interface trait",
					illegal: /[:($"]/
				}],
				relevance: 0,
				end: /\{/,
				excludeEnd: !0,
				contains: [{ beginKeywords: "extends implements" }, e.UNDERSCORE_TITLE_MODE]
			},
			{
				beginKeywords: "namespace",
				relevance: 0,
				end: ";",
				illegal: /[.']/,
				contains: [e.inherit(e.UNDERSCORE_TITLE_MODE, { scope: "title.class" })]
			},
			{
				beginKeywords: "use",
				relevance: 0,
				end: ";",
				contains: [{
					match: /\b(as|const|function)\b/,
					scope: "keyword"
				}, e.UNDERSCORE_TITLE_MODE]
			},
			m,
			h
		]
	};
}
// node_modules/highlight.js/es/languages/php-template.js
function Wt(e) {
	return {
		name: "PHP template",
		subLanguage: "xml",
		contains: [{
			begin: /<\?(php|=)?/,
			end: /\?>/,
			subLanguage: "php",
			contains: [
				{
					begin: "/\\*",
					end: "\\*/",
					skip: !0
				},
				{
					begin: "b\"",
					end: "\"",
					skip: !0
				},
				{
					begin: "b'",
					end: "'",
					skip: !0
				},
				e.inherit(e.APOS_STRING_MODE, {
					illegal: null,
					className: null,
					contains: null,
					skip: !0
				}),
				e.inherit(e.QUOTE_STRING_MODE, {
					illegal: null,
					className: null,
					contains: null,
					skip: !0
				})
			]
		}]
	};
}
// node_modules/highlight.js/es/languages/plaintext.js
function Gt(e) {
	return {
		name: "Plain text",
		aliases: ["text", "txt"],
		disableAutodetect: !0
	};
}
// node_modules/highlight.js/es/languages/python.js
function Kt(e) {
	let t = e.regex, n = /[\p{XID_Start}_]\p{XID_Continue}*/u, r = /* @__PURE__ */ "and.as.assert.async.await.break.case.class.continue.def.del.elif.else.except.finally.for.from.global.if.import.in.is.lambda.match.nonlocal|10.not.or.pass.raise.return.try.while.with.yield".split("."), i = {
		$pattern: /[A-Za-z]\w+|__\w+__/,
		keyword: r,
		built_in: /* @__PURE__ */ "__import__.abs.all.any.ascii.bin.bool.breakpoint.bytearray.bytes.callable.chr.classmethod.compile.complex.delattr.dict.dir.divmod.enumerate.eval.exec.filter.float.format.frozenset.getattr.globals.hasattr.hash.help.hex.id.input.int.isinstance.issubclass.iter.len.list.locals.map.max.memoryview.min.next.object.oct.open.ord.pow.print.property.range.repr.reversed.round.set.setattr.slice.sorted.staticmethod.str.sum.super.tuple.type.vars.zip".split("."),
		literal: [
			"__debug__",
			"Ellipsis",
			"False",
			"None",
			"NotImplemented",
			"True"
		],
		type: [
			"Any",
			"Callable",
			"Coroutine",
			"Dict",
			"List",
			"Literal",
			"Generic",
			"Optional",
			"Sequence",
			"Set",
			"Tuple",
			"Type",
			"Union"
		]
	}, a = {
		className: "meta",
		begin: /^(>>>|\.\.\.) /
	}, o = {
		className: "subst",
		begin: /\{/,
		end: /\}/,
		keywords: i,
		illegal: /#/
	}, s = {
		begin: /\{\{/,
		relevance: 0
	}, c = {
		className: "string",
		contains: [e.BACKSLASH_ESCAPE],
		variants: [
			{
				begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?'''/,
				end: /'''/,
				contains: [e.BACKSLASH_ESCAPE, a],
				relevance: 10
			},
			{
				begin: /([uU]|[bB]|[rR]|[bB][rR]|[rR][bB])?"""/,
				end: /"""/,
				contains: [e.BACKSLASH_ESCAPE, a],
				relevance: 10
			},
			{
				begin: /([fF][rR]|[rR][fF]|[fF])'''/,
				end: /'''/,
				contains: [
					e.BACKSLASH_ESCAPE,
					a,
					s,
					o
				]
			},
			{
				begin: /([fF][rR]|[rR][fF]|[fF])"""/,
				end: /"""/,
				contains: [
					e.BACKSLASH_ESCAPE,
					a,
					s,
					o
				]
			},
			{
				begin: /([uU]|[rR])'/,
				end: /'/,
				relevance: 10
			},
			{
				begin: /([uU]|[rR])"/,
				end: /"/,
				relevance: 10
			},
			{
				begin: /([bB]|[bB][rR]|[rR][bB])'/,
				end: /'/
			},
			{
				begin: /([bB]|[bB][rR]|[rR][bB])"/,
				end: /"/
			},
			{
				begin: /([fF][rR]|[rR][fF]|[fF])'/,
				end: /'/,
				contains: [
					e.BACKSLASH_ESCAPE,
					s,
					o
				]
			},
			{
				begin: /([fF][rR]|[rR][fF]|[fF])"/,
				end: /"/,
				contains: [
					e.BACKSLASH_ESCAPE,
					s,
					o
				]
			},
			e.APOS_STRING_MODE,
			e.QUOTE_STRING_MODE
		]
	}, l = "[0-9](_?[0-9])*", u = `(\\b(${l}))?\\.(${l})|\\b(${l})\\.`, d = `\\b|${r.join("|")}`, f = {
		className: "number",
		relevance: 0,
		variants: [
			{ begin: `(\\b(${l})|(${u}))[eE][+-]?(${l})[jJ]?(?=${d})` },
			{ begin: `(${u})[jJ]?` },
			{ begin: `\\b([1-9](_?[0-9])*|0+(_?0)*)[lLjJ]?(?=${d})` },
			{ begin: `\\b0[bB](_?[01])+[lL]?(?=${d})` },
			{ begin: `\\b0[oO](_?[0-7])+[lL]?(?=${d})` },
			{ begin: `\\b0[xX](_?[0-9a-fA-F])+[lL]?(?=${d})` },
			{ begin: `\\b(${l})[jJ](?=${d})` }
		]
	}, p = {
		className: "comment",
		begin: t.lookahead(/# type:/),
		end: /$/,
		keywords: i,
		contains: [{ begin: /# type:/ }, {
			begin: /#/,
			end: /\b\B/,
			endsWithParent: !0
		}]
	}, m = {
		className: "params",
		variants: [{
			className: "",
			begin: /\(\s*\)/,
			skip: !0
		}, {
			begin: /\(/,
			end: /\)/,
			excludeBegin: !0,
			excludeEnd: !0,
			keywords: i,
			contains: [
				"self",
				a,
				f,
				c,
				e.HASH_COMMENT_MODE
			]
		}]
	};
	return o.contains = [
		c,
		f,
		a
	], {
		name: "Python",
		aliases: [
			"py",
			"gyp",
			"ipython"
		],
		unicodeRegex: !0,
		keywords: i,
		illegal: /(<\/|\?)|=>/,
		contains: [
			a,
			f,
			{
				scope: "variable.language",
				match: /\bself\b/
			},
			{
				beginKeywords: "if",
				relevance: 0
			},
			{
				match: /\bor\b/,
				scope: "keyword"
			},
			c,
			p,
			e.HASH_COMMENT_MODE,
			{
				match: [
					/\bdef/,
					/\s+/,
					n
				],
				scope: {
					1: "keyword",
					3: "title.function"
				},
				contains: [m]
			},
			{
				variants: [{ match: [
					/\bclass/,
					/\s+/,
					n,
					/\s*/,
					/\(\s*/,
					n,
					/\s*\)/
				] }, { match: [
					/\bclass/,
					/\s+/,
					n
				] }],
				scope: {
					1: "keyword",
					3: "title.class",
					6: "title.class.inherited"
				}
			},
			{
				className: "meta",
				begin: /^[\t ]*@/,
				end: /(?=#)|$/,
				contains: [
					f,
					m,
					c
				]
			}
		]
	};
}
// node_modules/highlight.js/es/languages/python-repl.js
function qt(e) {
	return {
		aliases: ["pycon"],
		contains: [{
			className: "meta.prompt",
			starts: {
				end: / |$/,
				starts: {
					end: "$",
					subLanguage: "python"
				}
			},
			variants: [{ begin: /^>>>(?=[ ]|$)/ }, { begin: /^\.\.\.(?=[ ]|$)/ }]
		}]
	};
}
// node_modules/highlight.js/es/languages/r.js
function Jt(e) {
	let t = e.regex, n = /(?:(?:[a-zA-Z]|\.[._a-zA-Z])[._a-zA-Z0-9]*)|\.(?!\d)/, r = t.either(/0[xX][0-9a-fA-F]+\.[0-9a-fA-F]*[pP][+-]?\d+i?/, /0[xX][0-9a-fA-F]+(?:[pP][+-]?\d+)?[Li]?/, /(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?[Li]?/), i = /[=!<>:]=|\|\||&&|:::?|<-|<<-|->>|->|\|>|[-+*\/?!$&|:<=>@^~]|\*\*/, a = t.either(/[()]/, /[{}]/, /\[\[/, /[[\]]/, /\\/, /,/);
	return {
		name: "R",
		keywords: {
			$pattern: n,
			keyword: "function if in break next repeat else for while",
			literal: "NULL NA TRUE FALSE Inf NaN NA_integer_|10 NA_real_|10 NA_character_|10 NA_complex_|10",
			built_in: "LETTERS letters month.abb month.name pi T F abs acos acosh all any anyNA Arg as.call as.character as.complex as.double as.environment as.integer as.logical as.null.default as.numeric as.raw asin asinh atan atanh attr attributes baseenv browser c call ceiling class Conj cos cosh cospi cummax cummin cumprod cumsum digamma dim dimnames emptyenv exp expression floor forceAndCall gamma gc.time globalenv Im interactive invisible is.array is.atomic is.call is.character is.complex is.double is.environment is.expression is.finite is.function is.infinite is.integer is.language is.list is.logical is.matrix is.na is.name is.nan is.null is.numeric is.object is.pairlist is.raw is.recursive is.single is.symbol lazyLoadDBfetch length lgamma list log max min missing Mod names nargs nzchar oldClass on.exit pos.to.env proc.time prod quote range Re rep retracemem return round seq_along seq_len seq.int sign signif sin sinh sinpi sqrt standardGeneric substitute sum switch tan tanh tanpi tracemem trigamma trunc unclass untracemem UseMethod xtfrm"
		},
		contains: [
			e.COMMENT(/#'/, /$/, { contains: [
				{
					scope: "doctag",
					match: /@examples/,
					starts: {
						end: t.lookahead(t.either(/\n^#'\s*(?=@[a-zA-Z]+)/, /\n^(?!#')/)),
						endsParent: !0
					}
				},
				{
					scope: "doctag",
					begin: "@param",
					end: /$/,
					contains: [{
						scope: "variable",
						variants: [{ match: n }, { match: /`(?:\\.|[^`\\])+`/ }],
						endsParent: !0
					}]
				},
				{
					scope: "doctag",
					match: /@[a-zA-Z]+/
				},
				{
					scope: "keyword",
					match: /\\[a-zA-Z]+/
				}
			] }),
			e.HASH_COMMENT_MODE,
			{
				scope: "string",
				contains: [e.BACKSLASH_ESCAPE],
				variants: [
					e.END_SAME_AS_BEGIN({
						begin: /[rR]"(-*)\(/,
						end: /\)(-*)"/
					}),
					e.END_SAME_AS_BEGIN({
						begin: /[rR]"(-*)\{/,
						end: /\}(-*)"/
					}),
					e.END_SAME_AS_BEGIN({
						begin: /[rR]"(-*)\[/,
						end: /\](-*)"/
					}),
					e.END_SAME_AS_BEGIN({
						begin: /[rR]'(-*)\(/,
						end: /\)(-*)'/
					}),
					e.END_SAME_AS_BEGIN({
						begin: /[rR]'(-*)\{/,
						end: /\}(-*)'/
					}),
					e.END_SAME_AS_BEGIN({
						begin: /[rR]'(-*)\[/,
						end: /\](-*)'/
					}),
					{
						begin: "\"",
						end: "\"",
						relevance: 0
					},
					{
						begin: "'",
						end: "'",
						relevance: 0
					}
				]
			},
			{
				relevance: 0,
				variants: [
					{
						scope: {
							1: "operator",
							2: "number"
						},
						match: [i, r]
					},
					{
						scope: {
							1: "operator",
							2: "number"
						},
						match: [/%[^%]*%/, r]
					},
					{
						scope: {
							1: "punctuation",
							2: "number"
						},
						match: [a, r]
					},
					{
						scope: { 2: "number" },
						match: [/[^a-zA-Z0-9._]|^/, r]
					}
				]
			},
			{
				scope: { 3: "operator" },
				match: [
					n,
					/\s+/,
					/<-/,
					/\s+/
				]
			},
			{
				scope: "operator",
				relevance: 0,
				variants: [{ match: i }, { match: /%[^%]*%/ }]
			},
			{
				scope: "punctuation",
				relevance: 0,
				match: a
			},
			{
				begin: "`",
				end: "`",
				contains: [{ begin: /\\./ }]
			}
		]
	};
}
// node_modules/highlight.js/es/languages/ruby.js
function Yt(e) {
	let t = e.regex, n = "([a-zA-Z_]\\w*[!?=]?|[-+~]@|<<|>>|=~|===?|<=>|[<>]=?|\\*\\*|[-/+%^&*~`|]|\\[\\]=?)", r = t.either(/\b([A-Z]+[a-z0-9]+)+/, /\b([A-Z]+[a-z0-9]+)+[A-Z]+/), i = t.concat(r, /(::\w+)*/), a = {
		"variable.constant": [
			"__FILE__",
			"__LINE__",
			"__ENCODING__"
		],
		"variable.language": ["self", "super"],
		keyword: /* @__PURE__ */ "alias.and.begin.BEGIN.break.case.class.defined.do.else.elsif.end.END.ensure.for.if.in.module.next.not.or.redo.require.rescue.retry.return.then.undef.unless.until.when.while.yield.include.extend.prepend.public.private.protected.raise.throw".split("."),
		built_in: [
			"proc",
			"lambda",
			"attr_accessor",
			"attr_reader",
			"attr_writer",
			"define_method",
			"private_constant",
			"module_function"
		],
		literal: [
			"true",
			"false",
			"nil"
		]
	}, o = {
		className: "doctag",
		begin: "@[A-Za-z]+"
	}, s = {
		begin: "#<",
		end: ">"
	}, c = [
		e.COMMENT("#", "$", { contains: [o] }),
		e.COMMENT("^=begin", "^=end", {
			contains: [o],
			relevance: 10
		}),
		e.COMMENT("^__END__", e.MATCH_NOTHING_RE)
	], l = {
		className: "subst",
		begin: /#\{/,
		end: /\}/,
		keywords: a
	}, u = {
		className: "string",
		contains: [e.BACKSLASH_ESCAPE, l],
		variants: [
			{
				begin: /'/,
				end: /'/
			},
			{
				begin: /"/,
				end: /"/
			},
			{
				begin: /`/,
				end: /`/
			},
			{
				begin: /%[qQwWx]?\(/,
				end: /\)/
			},
			{
				begin: /%[qQwWx]?\[/,
				end: /\]/
			},
			{
				begin: /%[qQwWx]?\{/,
				end: /\}/
			},
			{
				begin: /%[qQwWx]?</,
				end: />/
			},
			{
				begin: /%[qQwWx]?\//,
				end: /\//
			},
			{
				begin: /%[qQwWx]?%/,
				end: /%/
			},
			{
				begin: /%[qQwWx]?-/,
				end: /-/
			},
			{
				begin: /%[qQwWx]?\|/,
				end: /\|/
			},
			{ begin: /\B\?(\\\d{1,3})/ },
			{ begin: /\B\?(\\x[A-Fa-f0-9]{1,2})/ },
			{ begin: /\B\?(\\u\{?[A-Fa-f0-9]{1,6}\}?)/ },
			{ begin: /\B\?(\\M-\\C-|\\M-\\c|\\c\\M-|\\M-|\\C-\\M-)[\x20-\x7e]/ },
			{ begin: /\B\?\\(c|C-)[\x20-\x7e]/ },
			{ begin: /\B\?\\?\S/ },
			{
				begin: t.concat(/<<[-~]?'?/, t.lookahead(/(\w+)(?=\W)[^\n]*\n(?:[^\n]*\n)*?\s*\1\b/)),
				contains: [e.END_SAME_AS_BEGIN({
					begin: /(\w+)/,
					end: /(\w+)/,
					contains: [e.BACKSLASH_ESCAPE, l]
				})]
			}
		]
	}, d = "[0-9](_?[0-9])*", f = {
		className: "number",
		relevance: 0,
		variants: [
			{ begin: `\\b([1-9](_?[0-9])*|0)(\\.(${d}))?([eE][+-]?(${d})|r)?i?\\b` },
			{ begin: "\\b0[dD][0-9](_?[0-9])*r?i?\\b" },
			{ begin: "\\b0[bB][0-1](_?[0-1])*r?i?\\b" },
			{ begin: "\\b0[oO][0-7](_?[0-7])*r?i?\\b" },
			{ begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*r?i?\\b" },
			{ begin: "\\b0(_?[0-7])+r?i?\\b" }
		]
	}, p = { variants: [{ match: /\(\)/ }, {
		className: "params",
		begin: /\(/,
		end: /(?=\))/,
		excludeBegin: !0,
		endsParent: !0,
		keywords: a
	}] }, m = [
		u,
		{
			variants: [{ match: [
				/class\s+/,
				i,
				/\s+<\s+/,
				i
			] }, { match: [/\b(class|module)\s+/, i] }],
			scope: {
				2: "title.class",
				4: "title.class.inherited"
			},
			keywords: a
		},
		{
			match: [/(include|extend)\s+/, i],
			scope: { 2: "title.class" },
			keywords: a
		},
		{
			relevance: 0,
			match: [i, /\.new[. (]/],
			scope: { 1: "title.class" }
		},
		{
			relevance: 0,
			match: /\b[A-Z][A-Z_0-9]+\b/,
			className: "variable.constant"
		},
		{
			relevance: 0,
			match: r,
			scope: "title.class"
		},
		{
			match: [
				/def/,
				/\s+/,
				n
			],
			scope: {
				1: "keyword",
				3: "title.function"
			},
			contains: [p]
		},
		{ begin: e.IDENT_RE + "::" },
		{
			className: "symbol",
			begin: e.UNDERSCORE_IDENT_RE + "(!|\\?)?:",
			relevance: 0
		},
		{
			className: "symbol",
			begin: ":(?!\\s)",
			contains: [u, { begin: n }],
			relevance: 0
		},
		f,
		{
			className: "variable",
			begin: "(\\$\\W)|((\\$|@@?)(\\w+))(?=[^@$?])(?![A-Za-z])(?![@$?'])"
		},
		{
			className: "params",
			begin: /\|(?!=)/,
			end: /\|/,
			excludeBegin: !0,
			excludeEnd: !0,
			relevance: 0,
			keywords: a
		},
		{
			begin: "(" + e.RE_STARTERS_RE + "|unless)\\s*",
			keywords: "unless",
			contains: [{
				className: "regexp",
				contains: [e.BACKSLASH_ESCAPE, l],
				illegal: /\n/,
				variants: [
					{
						begin: "/",
						end: "/[a-z]*"
					},
					{
						begin: /%r\{/,
						end: /\}[a-z]*/
					},
					{
						begin: "%r\\(",
						end: "\\)[a-z]*"
					},
					{
						begin: "%r!",
						end: "![a-z]*"
					},
					{
						begin: "%r\\[",
						end: "\\][a-z]*"
					}
				]
			}].concat(s, c),
			relevance: 0
		}
	].concat(s, c);
	l.contains = m, p.contains = m;
	let h = [{
		begin: /^\s*=>/,
		starts: {
			end: "$",
			contains: m
		}
	}, {
		className: "meta.prompt",
		begin: "^([>?]>|[\\w#]+\\(\\w+\\):\\d+:\\d+[>*]|(\\w+-)?\\d+\\.\\d+\\.\\d+(p\\d+)?[^\\d][^>]+>)(?=[ ])",
		starts: {
			end: "$",
			keywords: a,
			contains: m
		}
	}];
	return c.unshift(s), {
		name: "Ruby",
		aliases: [
			"rb",
			"gemspec",
			"podspec",
			"thor",
			"irb"
		],
		keywords: a,
		illegal: /\/\*/,
		contains: [e.SHEBANG({ binary: "ruby" })].concat(h, c, m)
	};
}
// node_modules/highlight.js/es/languages/rust.js
function Xt(e) {
	let t = e.regex, n = /(r#)?/, r = t.concat(n, e.UNDERSCORE_IDENT_RE), i = t.concat(n, e.IDENT_RE), a = {
		className: "title.function.invoke",
		relevance: 0,
		begin: t.concat(/\b/, /(?!let|for|while|if|else|match\b)/, i, t.lookahead(/\s*\(/))
	}, o = "([ui](8|16|32|64|128|size)|f(32|64))?", s = /* @__PURE__ */ "abstract.as.async.await.become.box.break.const.continue.crate.do.dyn.else.enum.extern.false.final.fn.for.if.impl.in.let.loop.macro.match.mod.move.mut.override.priv.pub.ref.return.self.Self.static.struct.super.trait.true.try.type.typeof.union.unsafe.unsized.use.virtual.where.while.yield".split("."), c = [
		"true",
		"false",
		"Some",
		"None",
		"Ok",
		"Err"
	], l = /* @__PURE__ */ "drop .Copy.Send.Sized.Sync.Drop.Fn.FnMut.FnOnce.ToOwned.Clone.Debug.PartialEq.PartialOrd.Eq.Ord.AsRef.AsMut.Into.From.Default.Iterator.Extend.IntoIterator.DoubleEndedIterator.ExactSizeIterator.SliceConcatExt.ToString.assert!.assert_eq!.bitflags!.bytes!.cfg!.col!.concat!.concat_idents!.debug_assert!.debug_assert_eq!.env!.eprintln!.panic!.file!.format!.format_args!.include_bytes!.include_str!.line!.local_data_key!.module_path!.option_env!.print!.println!.select!.stringify!.try!.unimplemented!.unreachable!.vec!.write!.writeln!.macro_rules!.assert_ne!.debug_assert_ne!".split("."), u = [
		"i8",
		"i16",
		"i32",
		"i64",
		"i128",
		"isize",
		"u8",
		"u16",
		"u32",
		"u64",
		"u128",
		"usize",
		"f32",
		"f64",
		"str",
		"char",
		"bool",
		"Box",
		"Option",
		"Result",
		"String",
		"Vec"
	];
	return {
		name: "Rust",
		aliases: ["rs"],
		keywords: {
			$pattern: e.IDENT_RE + "!?",
			type: u,
			keyword: s,
			literal: c,
			built_in: l
		},
		illegal: "</",
		contains: [
			e.C_LINE_COMMENT_MODE,
			e.COMMENT("/\\*", "\\*/", { contains: ["self"] }),
			e.inherit(e.QUOTE_STRING_MODE, {
				begin: /b?"/,
				illegal: null
			}),
			{
				className: "symbol",
				begin: /'[a-zA-Z_][a-zA-Z0-9_]*(?!')/
			},
			{
				scope: "string",
				variants: [{ begin: /b?r(#*)"(.|\n)*?"\1(?!#)/ }, {
					begin: /b?'/,
					end: /'/,
					contains: [{
						scope: "char.escape",
						match: /\\('|\w|x\w{2}|u\w{4}|U\w{8})/
					}]
				}]
			},
			{
				className: "number",
				variants: [
					{ begin: "\\b0b([01_]+)" + o },
					{ begin: "\\b0o([0-7_]+)" + o },
					{ begin: "\\b0x([A-Fa-f0-9_]+)" + o },
					{ begin: "\\b(\\d[\\d_]*(\\.[0-9_]+)?([eE][+-]?[0-9_]+)?)" + o }
				],
				relevance: 0
			},
			{
				begin: [
					/fn/,
					/\s+/,
					r
				],
				className: {
					1: "keyword",
					3: "title.function"
				}
			},
			{
				className: "meta",
				begin: "#!?\\[",
				end: "\\]",
				contains: [{
					className: "string",
					begin: /"/,
					end: /"/,
					contains: [e.BACKSLASH_ESCAPE]
				}]
			},
			{
				begin: [
					/let/,
					/\s+/,
					/(?:mut\s+)?/,
					r
				],
				className: {
					1: "keyword",
					3: "keyword",
					4: "variable"
				}
			},
			{
				begin: [
					/for/,
					/\s+/,
					r,
					/\s+/,
					/in/
				],
				className: {
					1: "keyword",
					3: "variable",
					5: "keyword"
				}
			},
			{
				begin: [
					/type/,
					/\s+/,
					r
				],
				className: {
					1: "keyword",
					3: "title.class"
				}
			},
			{
				begin: [
					/(?:trait|enum|struct|union|impl|for)/,
					/\s+/,
					r
				],
				className: {
					1: "keyword",
					3: "title.class"
				}
			},
			{
				begin: e.IDENT_RE + "::",
				keywords: {
					keyword: "Self",
					built_in: l,
					type: u
				}
			},
			{
				className: "punctuation",
				begin: "->"
			},
			a
		]
	};
}
// node_modules/highlight.js/es/languages/scss.js
var Zt = (e) => ({
	IMPORTANT: {
		scope: "meta",
		begin: "!important"
	},
	BLOCK_COMMENT: e.C_BLOCK_COMMENT_MODE,
	HEXCOLOR: {
		scope: "number",
		begin: /#(([0-9a-fA-F]{3,4})|(([0-9a-fA-F]{2}){3,4}))\b/
	},
	UNICODE_RANGE: {
		scope: "number",
		begin: /\b[Uu]\+[0-9A-Fa-f][0-9A-Fa-f?]{0,4}(-[0-9A-Fa-f][0-9A-Fa-f]{0,4})?/
	},
	FUNCTION_DISPATCH: {
		className: "built_in",
		begin: /[\w-]+(?=\()/
	},
	ATTRIBUTE_SELECTOR_MODE: {
		scope: "selector-attr",
		begin: /\[/,
		end: /\]/,
		illegal: "$",
		contains: [e.APOS_STRING_MODE, e.QUOTE_STRING_MODE]
	},
	CSS_NUMBER_MODE: {
		scope: "number",
		begin: e.NUMBER_RE + "(%|em|ex|ch|rem|vw|vh|vmin|vmax|cm|mm|in|pt|pc|px|deg|grad|rad|turn|s|ms|Hz|kHz|dpi|dpcm|dppx)?",
		relevance: 0
	},
	CSS_VARIABLE: {
		className: "attr",
		begin: /--[A-Za-z_][A-Za-z0-9_-]*/
	}
}), Qt = /* @__PURE__ */ "a.abbr.address.article.aside.audio.b.blockquote.body.button.canvas.caption.cite.code.dd.del.details.dfn.div.dl.dt.em.fieldset.figcaption.figure.footer.form.h1.h2.h3.h4.h5.h6.header.hgroup.html.i.iframe.img.input.ins.kbd.label.legend.li.main.mark.menu.nav.object.ol.optgroup.option.p.picture.q.quote.samp.section.select.source.span.strong.summary.sup.table.tbody.td.textarea.tfoot.th.thead.time.tr.ul.var.video".split("."), $t = /* @__PURE__ */ "defs.g.marker.mask.pattern.svg.switch.symbol.feBlend.feColorMatrix.feComponentTransfer.feComposite.feConvolveMatrix.feDiffuseLighting.feDisplacementMap.feFlood.feGaussianBlur.feImage.feMerge.feMorphology.feOffset.feSpecularLighting.feTile.feTurbulence.linearGradient.radialGradient.stop.circle.ellipse.image.line.path.polygon.polyline.rect.text.use.textPath.tspan.foreignObject.clipPath".split("."), en = [...Qt, ...$t], tn = (/* @__PURE__ */ "any-hover.any-pointer.aspect-ratio.color.color-gamut.color-index.device-aspect-ratio.device-height.device-width.display-mode.forced-colors.grid.height.hover.inverted-colors.monochrome.orientation.overflow-block.overflow-inline.pointer.prefers-color-scheme.prefers-contrast.prefers-reduced-motion.prefers-reduced-transparency.resolution.scan.scripting.update.width.min-width.max-width.min-height.max-height".split(".")).sort().reverse(), nn = (/* @__PURE__ */ "active.any-link.blank.checked.current.default.defined.dir.disabled.drop.empty.enabled.first.first-child.first-of-type.fullscreen.future.focus.focus-visible.focus-within.has.host.host-context.hover.indeterminate.in-range.invalid.is.lang.last-child.last-of-type.left.link.local-link.not.nth-child.nth-col.nth-last-child.nth-last-col.nth-last-of-type.nth-of-type.only-child.only-of-type.optional.out-of-range.past.placeholder-shown.read-only.read-write.required.right.root.scope.target.target-within.user-invalid.valid.visited.where".split(".")).sort().reverse(), rn = [
	"after",
	"backdrop",
	"before",
	"cue",
	"cue-region",
	"first-letter",
	"first-line",
	"grammar-error",
	"marker",
	"part",
	"placeholder",
	"selection",
	"slotted",
	"spelling-error"
].sort().reverse(), an = (/* @__PURE__ */ "accent-color.align-content.align-items.align-self.alignment-baseline.all.anchor-name.animation.animation-composition.animation-delay.animation-direction.animation-duration.animation-fill-mode.animation-iteration-count.animation-name.animation-play-state.animation-range.animation-range-end.animation-range-start.animation-timeline.animation-timing-function.appearance.aspect-ratio.backdrop-filter.backface-visibility.background.background-attachment.background-blend-mode.background-clip.background-color.background-image.background-origin.background-position.background-position-x.background-position-y.background-repeat.background-size.baseline-shift.block-size.border.border-block.border-block-color.border-block-end.border-block-end-color.border-block-end-style.border-block-end-width.border-block-start.border-block-start-color.border-block-start-style.border-block-start-width.border-block-style.border-block-width.border-bottom.border-bottom-color.border-bottom-left-radius.border-bottom-right-radius.border-bottom-style.border-bottom-width.border-collapse.border-color.border-end-end-radius.border-end-start-radius.border-image.border-image-outset.border-image-repeat.border-image-slice.border-image-source.border-image-width.border-inline.border-inline-color.border-inline-end.border-inline-end-color.border-inline-end-style.border-inline-end-width.border-inline-start.border-inline-start-color.border-inline-start-style.border-inline-start-width.border-inline-style.border-inline-width.border-left.border-left-color.border-left-style.border-left-width.border-radius.border-right.border-right-color.border-right-style.border-right-width.border-spacing.border-start-end-radius.border-start-start-radius.border-style.border-top.border-top-color.border-top-left-radius.border-top-right-radius.border-top-style.border-top-width.border-width.bottom.box-align.box-decoration-break.box-direction.box-flex.box-flex-group.box-lines.box-ordinal-group.box-orient.box-pack.box-shadow.box-sizing.break-after.break-before.break-inside.caption-side.caret-color.clear.clip.clip-path.clip-rule.color.color-interpolation.color-interpolation-filters.color-profile.color-rendering.color-scheme.column-count.column-fill.column-gap.column-rule.column-rule-color.column-rule-style.column-rule-width.column-span.column-width.columns.contain.contain-intrinsic-block-size.contain-intrinsic-height.contain-intrinsic-inline-size.contain-intrinsic-size.contain-intrinsic-width.container.container-name.container-type.content.content-visibility.counter-increment.counter-reset.counter-set.cue.cue-after.cue-before.cursor.cx.cy.direction.display.dominant-baseline.empty-cells.enable-background.field-sizing.fill.fill-opacity.fill-rule.filter.flex.flex-basis.flex-direction.flex-flow.flex-grow.flex-shrink.flex-wrap.float.flood-color.flood-opacity.flow.font.font-display.font-family.font-feature-settings.font-kerning.font-language-override.font-optical-sizing.font-palette.font-size.font-size-adjust.font-smooth.font-smoothing.font-stretch.font-style.font-synthesis.font-synthesis-position.font-synthesis-small-caps.font-synthesis-style.font-synthesis-weight.font-variant.font-variant-alternates.font-variant-caps.font-variant-east-asian.font-variant-emoji.font-variant-ligatures.font-variant-numeric.font-variant-position.font-variation-settings.font-weight.forced-color-adjust.gap.glyph-orientation-horizontal.glyph-orientation-vertical.grid.grid-area.grid-auto-columns.grid-auto-flow.grid-auto-rows.grid-column.grid-column-end.grid-column-start.grid-gap.grid-row.grid-row-end.grid-row-start.grid-template.grid-template-areas.grid-template-columns.grid-template-rows.hanging-punctuation.height.hyphenate-character.hyphenate-limit-chars.hyphens.icon.image-orientation.image-rendering.image-resolution.ime-mode.initial-letter.initial-letter-align.inline-size.inset.inset-area.inset-block.inset-block-end.inset-block-start.inset-inline.inset-inline-end.inset-inline-start.isolation.justify-content.justify-items.justify-self.kerning.left.letter-spacing.lighting-color.line-break.line-height.line-height-step.list-style.list-style-image.list-style-position.list-style-type.margin.margin-block.margin-block-end.margin-block-start.margin-bottom.margin-inline.margin-inline-end.margin-inline-start.margin-left.margin-right.margin-top.margin-trim.marker.marker-end.marker-mid.marker-start.marks.mask.mask-border.mask-border-mode.mask-border-outset.mask-border-repeat.mask-border-slice.mask-border-source.mask-border-width.mask-clip.mask-composite.mask-image.mask-mode.mask-origin.mask-position.mask-repeat.mask-size.mask-type.masonry-auto-flow.math-depth.math-shift.math-style.max-block-size.max-height.max-inline-size.max-width.min-block-size.min-height.min-inline-size.min-width.mix-blend-mode.nav-down.nav-index.nav-left.nav-right.nav-up.none.normal.object-fit.object-position.offset.offset-anchor.offset-distance.offset-path.offset-position.offset-rotate.opacity.order.orphans.outline.outline-color.outline-offset.outline-style.outline-width.overflow.overflow-anchor.overflow-block.overflow-clip-margin.overflow-inline.overflow-wrap.overflow-x.overflow-y.overlay.overscroll-behavior.overscroll-behavior-block.overscroll-behavior-inline.overscroll-behavior-x.overscroll-behavior-y.padding.padding-block.padding-block-end.padding-block-start.padding-bottom.padding-inline.padding-inline-end.padding-inline-start.padding-left.padding-right.padding-top.page.page-break-after.page-break-before.page-break-inside.paint-order.pause.pause-after.pause-before.perspective.perspective-origin.place-content.place-items.place-self.pointer-events.position.position-anchor.position-visibility.print-color-adjust.quotes.r.resize.rest.rest-after.rest-before.right.rotate.row-gap.ruby-align.ruby-position.scale.scroll-behavior.scroll-margin.scroll-margin-block.scroll-margin-block-end.scroll-margin-block-start.scroll-margin-bottom.scroll-margin-inline.scroll-margin-inline-end.scroll-margin-inline-start.scroll-margin-left.scroll-margin-right.scroll-margin-top.scroll-padding.scroll-padding-block.scroll-padding-block-end.scroll-padding-block-start.scroll-padding-bottom.scroll-padding-inline.scroll-padding-inline-end.scroll-padding-inline-start.scroll-padding-left.scroll-padding-right.scroll-padding-top.scroll-snap-align.scroll-snap-stop.scroll-snap-type.scroll-timeline.scroll-timeline-axis.scroll-timeline-name.scrollbar-color.scrollbar-gutter.scrollbar-width.shape-image-threshold.shape-margin.shape-outside.shape-rendering.speak.speak-as.src.stop-color.stop-opacity.stroke.stroke-dasharray.stroke-dashoffset.stroke-linecap.stroke-linejoin.stroke-miterlimit.stroke-opacity.stroke-width.tab-size.table-layout.text-align.text-align-all.text-align-last.text-anchor.text-combine-upright.text-decoration.text-decoration-color.text-decoration-line.text-decoration-skip.text-decoration-skip-ink.text-decoration-style.text-decoration-thickness.text-emphasis.text-emphasis-color.text-emphasis-position.text-emphasis-style.text-indent.text-justify.text-orientation.text-overflow.text-rendering.text-shadow.text-size-adjust.text-transform.text-underline-offset.text-underline-position.text-wrap.text-wrap-mode.text-wrap-style.timeline-scope.top.touch-action.transform.transform-box.transform-origin.transform-style.transition.transition-behavior.transition-delay.transition-duration.transition-property.transition-timing-function.translate.unicode-bidi.unicode-range.user-modify.user-select.vector-effect.vertical-align.view-timeline.view-timeline-axis.view-timeline-inset.view-timeline-name.view-transition-name.visibility.voice-balance.voice-duration.voice-family.voice-pitch.voice-range.voice-rate.voice-stress.voice-volume.white-space.white-space-collapse.widows.width.will-change.word-break.word-spacing.word-wrap.writing-mode.x.y.z-index.zoom".split(".")).sort().reverse();
function on(e) {
	let t = Zt(e), n = rn, r = nn, i = "@[a-z-]+", a = {
		className: "variable",
		begin: "(\\$[a-zA-Z-][a-zA-Z0-9_-]*)\\b",
		relevance: 0
	};
	return {
		name: "SCSS",
		case_insensitive: !0,
		illegal: "[=/|']",
		contains: [
			e.C_LINE_COMMENT_MODE,
			e.C_BLOCK_COMMENT_MODE,
			t.CSS_NUMBER_MODE,
			{
				className: "selector-id",
				begin: "#[A-Za-z0-9_-]+",
				relevance: 0
			},
			{
				className: "selector-class",
				begin: "\\.[A-Za-z0-9_-]+",
				relevance: 0
			},
			t.ATTRIBUTE_SELECTOR_MODE,
			{
				className: "selector-tag",
				begin: "\\b(" + en.join("|") + ")\\b",
				relevance: 0
			},
			{
				className: "selector-pseudo",
				begin: ":(" + r.join("|") + ")"
			},
			{
				className: "selector-pseudo",
				begin: ":(:)?(" + n.join("|") + ")"
			},
			a,
			{
				begin: /\(/,
				end: /\)/,
				contains: [t.CSS_NUMBER_MODE]
			},
			t.CSS_VARIABLE,
			{
				className: "attribute",
				begin: "\\b(" + an.join("|") + ")\\b"
			},
			{ begin: "\\b(whitespace|wait|w-resize|visible|vertical-text|vertical-ideographic|uppercase|upper-roman|upper-alpha|underline|transparent|top|thin|thick|text|text-top|text-bottom|tb-rl|table-header-group|table-footer-group|sw-resize|super|strict|static|square|solid|small-caps|separate|se-resize|scroll|s-resize|rtl|row-resize|ridge|right|repeat|repeat-y|repeat-x|relative|progress|pointer|overline|outside|outset|oblique|nowrap|not-allowed|normal|none|nw-resize|no-repeat|no-drop|newspaper|ne-resize|n-resize|move|middle|medium|ltr|lr-tb|lowercase|lower-roman|lower-alpha|loose|list-item|line|line-through|line-edge|lighter|left|keep-all|justify|italic|inter-word|inter-ideograph|inside|inset|inline|inline-block|inherit|inactive|ideograph-space|ideograph-parenthesis|ideograph-numeric|ideograph-alpha|horizontal|hidden|help|hand|groove|fixed|ellipsis|e-resize|double|dotted|distribute|distribute-space|distribute-letter|distribute-all-lines|disc|disabled|default|decimal|dashed|crosshair|collapse|col-resize|circle|char|center|capitalize|break-word|break-all|bottom|both|bolder|bold|block|bidi-override|below|baseline|auto|always|all-scroll|absolute|table|table-cell)\\b" },
			{
				begin: /:/,
				end: /[;}{]/,
				relevance: 0,
				contains: [
					t.BLOCK_COMMENT,
					a,
					t.HEXCOLOR,
					t.CSS_NUMBER_MODE,
					t.UNICODE_RANGE,
					e.QUOTE_STRING_MODE,
					e.APOS_STRING_MODE,
					t.IMPORTANT,
					t.FUNCTION_DISPATCH
				]
			},
			{
				begin: "@(page|font-face)",
				keywords: {
					$pattern: i,
					keyword: "@page @font-face"
				}
			},
			{
				begin: "@",
				end: "[{;]",
				returnBegin: !0,
				keywords: {
					$pattern: /[a-z-]+/,
					keyword: "and or not only",
					attribute: tn.join(" ")
				},
				contains: [
					{
						begin: i,
						className: "keyword"
					},
					{
						begin: /[a-z-]+(?=:)/,
						className: "attribute"
					},
					a,
					e.QUOTE_STRING_MODE,
					e.APOS_STRING_MODE,
					t.HEXCOLOR,
					t.CSS_NUMBER_MODE
				]
			},
			t.FUNCTION_DISPATCH
		]
	};
}
// node_modules/highlight.js/es/languages/shell.js
function sn(e) {
	return {
		name: "Shell Session",
		aliases: ["console", "shellsession"],
		contains: [{
			className: "meta.prompt",
			begin: /^\s{0,3}[/~\w\d[\]()@-]*[>%$#][ ]?/,
			starts: {
				end: /[^\\](?=\s*$)/,
				subLanguage: "bash"
			}
		}]
	};
}
// node_modules/highlight.js/es/languages/sql.js
function cn(e) {
	let t = e.regex, n = e.COMMENT("--", "$"), r = {
		scope: "string",
		variants: [{
			begin: /'/,
			end: /'/,
			contains: [{ match: /''/ }]
		}]
	}, i = {
		begin: /"/,
		end: /"/,
		contains: [{ match: /""/ }]
	}, a = [
		"true",
		"false",
		"unknown"
	], o = [
		"double precision",
		"large object",
		"with timezone",
		"without timezone"
	], s = /* @__PURE__ */ "bigint.binary.blob.boolean.char.character.clob.date.dec.decfloat.decimal.float.int.integer.interval.nchar.nclob.national.numeric.real.row.smallint.time.timestamp.varchar.varying.varbinary".split("."), c = [
		"add",
		"asc",
		"collation",
		"desc",
		"final",
		"first",
		"last",
		"view"
	], l = /* @__PURE__ */ "abs.acos.all.allocate.alter.and.any.are.array.array_agg.array_max_cardinality.as.asensitive.asin.asymmetric.at.atan.atomic.authorization.avg.begin.begin_frame.begin_partition.between.bigint.binary.blob.boolean.both.by.call.called.cardinality.cascaded.case.cast.ceil.ceiling.char.char_length.character.character_length.check.classifier.clob.close.coalesce.collate.collect.column.commit.condition.connect.constraint.contains.convert.copy.corr.corresponding.cos.cosh.count.covar_pop.covar_samp.create.cross.cube.cume_dist.current.current_catalog.current_date.current_default_transform_group.current_path.current_role.current_row.current_schema.current_time.current_timestamp.current_path.current_role.current_transform_group_for_type.current_user.cursor.cycle.date.day.deallocate.dec.decimal.decfloat.declare.default.define.delete.dense_rank.deref.describe.deterministic.disconnect.distinct.double.drop.dynamic.each.element.else.empty.end.end_frame.end_partition.end-exec.equals.escape.every.except.exec.execute.exists.exp.external.extract.false.fetch.filter.first_value.float.floor.for.foreign.frame_row.free.from.full.function.fusion.get.global.grant.group.grouping.groups.having.hold.hour.identity.in.indicator.initial.inner.inout.insensitive.insert.int.integer.intersect.intersection.interval.into.is.join.json_array.json_arrayagg.json_exists.json_object.json_objectagg.json_query.json_table.json_table_primitive.json_value.lag.language.large.last_value.lateral.lead.leading.left.like.like_regex.listagg.ln.local.localtime.localtimestamp.log.log10.lower.match.match_number.match_recognize.matches.max.member.merge.method.min.minute.mod.modifies.module.month.multiset.national.natural.nchar.nclob.new.no.none.normalize.not.nth_value.ntile.null.nullif.numeric.octet_length.occurrences_regex.of.offset.old.omit.on.one.only.open.or.order.out.outer.over.overlaps.overlay.parameter.partition.pattern.per.percent.percent_rank.percentile_cont.percentile_disc.period.portion.position.position_regex.power.precedes.precision.prepare.primary.procedure.ptf.range.rank.reads.real.recursive.ref.references.referencing.regr_avgx.regr_avgy.regr_count.regr_intercept.regr_r2.regr_slope.regr_sxx.regr_sxy.regr_syy.release.result.return.returns.revoke.right.rollback.rollup.row.row_number.rows.running.savepoint.scope.scroll.search.second.seek.select.sensitive.session_user.set.show.similar.sin.sinh.skip.smallint.some.specific.specifictype.sql.sqlexception.sqlstate.sqlwarning.sqrt.start.static.stddev_pop.stddev_samp.submultiset.subset.substring.substring_regex.succeeds.sum.symmetric.system.system_time.system_user.table.tablesample.tan.tanh.then.time.timestamp.timezone_hour.timezone_minute.to.trailing.translate.translate_regex.translation.treat.trigger.trim.trim_array.true.truncate.uescape.union.unique.unknown.unnest.update.upper.user.using.value.values.value_of.var_pop.var_samp.varbinary.varchar.varying.versioning.when.whenever.where.width_bucket.window.with.within.without.year".split("."), u = /* @__PURE__ */ "abs.acos.array_agg.asin.atan.avg.cast.ceil.ceiling.coalesce.corr.cos.cosh.count.covar_pop.covar_samp.cume_dist.dense_rank.deref.element.exp.extract.first_value.floor.json_array.json_arrayagg.json_exists.json_object.json_objectagg.json_query.json_table.json_table_primitive.json_value.lag.last_value.lead.listagg.ln.log.log10.lower.max.min.mod.nth_value.ntile.nullif.percent_rank.percentile_cont.percentile_disc.position.position_regex.power.rank.regr_avgx.regr_avgy.regr_count.regr_intercept.regr_r2.regr_slope.regr_sxx.regr_sxy.regr_syy.row_number.sin.sinh.sqrt.stddev_pop.stddev_samp.substring.substring_regex.sum.tan.tanh.translate.translate_regex.treat.trim.trim_array.unnest.upper.value_of.var_pop.var_samp.width_bucket".split("."), d = [
		"current_catalog",
		"current_date",
		"current_default_transform_group",
		"current_path",
		"current_role",
		"current_schema",
		"current_transform_group_for_type",
		"current_user",
		"session_user",
		"system_time",
		"system_user",
		"current_time",
		"localtime",
		"current_timestamp",
		"localtimestamp"
	], f = [
		"create table",
		"insert into",
		"primary key",
		"foreign key",
		"not null",
		"alter table",
		"add constraint",
		"grouping sets",
		"on overflow",
		"character set",
		"respect nulls",
		"ignore nulls",
		"nulls first",
		"nulls last",
		"depth first",
		"breadth first"
	], p = u, m = [...l, ...c].filter((e) => !u.includes(e)), h = {
		scope: "variable",
		match: /@[a-z0-9][a-z0-9_]*/
	}, g = {
		scope: "operator",
		match: /[-+*/=%^~]|&&?|\|\|?|!=?|<(?:=>?|<|>)?|>[>=]?/,
		relevance: 0
	}, _ = {
		match: t.concat(/\b/, t.either(...p), /\s*\(/),
		relevance: 0,
		keywords: { built_in: p }
	};
	function v(e) {
		return t.concat(/\b/, t.either(...e.map((e) => e.replace(/\s+/, "\\s+"))), /\b/);
	}
	let y = {
		scope: "keyword",
		match: v(f),
		relevance: 0
	};
	function b(e, { exceptions: t, when: n } = {}) {
		let r = n;
		return t ||= [], e.map((e) => e.match(/\|\d+$/) || t.includes(e) ? e : r(e) ? `${e}|0` : e);
	}
	return {
		name: "SQL",
		case_insensitive: !0,
		illegal: /[{}]|<\//,
		keywords: {
			$pattern: /\b[\w\.]+/,
			keyword: b(m, { when: (e) => e.length < 3 }),
			literal: a,
			type: s,
			built_in: d
		},
		contains: [
			{
				scope: "type",
				match: v(o)
			},
			y,
			_,
			h,
			r,
			i,
			e.C_NUMBER_MODE,
			e.C_BLOCK_COMMENT_MODE,
			n,
			g
		]
	};
}
// node_modules/highlight.js/es/languages/swift.js
function ln(e) {
	return e ? typeof e == "string" ? e : e.source : null;
}
function un(e) {
	return X("(?=", e, ")");
}
function X(...e) {
	return e.map((e) => ln(e)).join("");
}
function dn(e) {
	let t = e[e.length - 1];
	return typeof t == "object" && t.constructor === Object ? (e.splice(e.length - 1, 1), t) : {};
}
function Z(...e) {
	return "(" + (dn(e).capture ? "" : "?:") + e.map((e) => ln(e)).join("|") + ")";
}
var fn = (e) => X(/\b/, e, /\w$/.test(e) ? /\b/ : /\B/), pn = ["Protocol", "Type"].map(fn), mn = ["init", "self"].map(fn), hn = ["Any", "Self"], gn = [
	"actor",
	"any",
	"associatedtype",
	"async",
	"await",
	/as\?/,
	/as!/,
	"as",
	"borrowing",
	"break",
	"case",
	"catch",
	"class",
	"consume",
	"consuming",
	"continue",
	"convenience",
	"copy",
	"default",
	"defer",
	"deinit",
	"didSet",
	"distributed",
	"do",
	"dynamic",
	"each",
	"else",
	"enum",
	"extension",
	"fallthrough",
	/fileprivate\(set\)/,
	"fileprivate",
	"final",
	"for",
	"func",
	"get",
	"guard",
	"if",
	"import",
	"indirect",
	"infix",
	/init\?/,
	/init!/,
	"inout",
	/internal\(set\)/,
	"internal",
	"in",
	"is",
	"isolated",
	"nonisolated",
	"lazy",
	"let",
	"macro",
	"mutating",
	"nonmutating",
	/open\(set\)/,
	"open",
	"operator",
	"optional",
	"override",
	"package",
	"postfix",
	"precedencegroup",
	"prefix",
	/private\(set\)/,
	"private",
	"protocol",
	/public\(set\)/,
	"public",
	"repeat",
	"required",
	"rethrows",
	"return",
	"set",
	"some",
	"static",
	"struct",
	"subscript",
	"super",
	"switch",
	"throws",
	"throw",
	/try\?/,
	/try!/,
	"try",
	"typealias",
	/unowned\(safe\)/,
	/unowned\(unsafe\)/,
	"unowned",
	"var",
	"weak",
	"where",
	"while",
	"willSet"
], _n = [
	"false",
	"nil",
	"true"
], vn = [
	"assignment",
	"associativity",
	"higherThan",
	"left",
	"lowerThan",
	"none",
	"right"
], yn = [
	"#colorLiteral",
	"#column",
	"#dsohandle",
	"#else",
	"#elseif",
	"#endif",
	"#error",
	"#file",
	"#fileID",
	"#fileLiteral",
	"#filePath",
	"#function",
	"#if",
	"#imageLiteral",
	"#keyPath",
	"#line",
	"#selector",
	"#sourceLocation",
	"#warning"
], bn = /* @__PURE__ */ "abs.all.any.assert.assertionFailure.debugPrint.dump.fatalError.getVaList.isKnownUniquelyReferenced.max.min.numericCast.pointwiseMax.pointwiseMin.precondition.preconditionFailure.print.readLine.repeatElement.sequence.stride.swap.swift_unboxFromSwiftValueWithType.transcode.type.unsafeBitCast.unsafeDowncast.withExtendedLifetime.withUnsafeMutablePointer.withUnsafePointer.withVaList.withoutActuallyEscaping.zip".split("."), xn = Z(/[/=\-+!*%<>&|^~?]/, /[\u00A1-\u00A7]/, /[\u00A9\u00AB]/, /[\u00AC\u00AE]/, /[\u00B0\u00B1]/, /[\u00B6\u00BB\u00BF\u00D7\u00F7]/, /[\u2016-\u2017]/, /[\u2020-\u2027]/, /[\u2030-\u203E]/, /[\u2041-\u2053]/, /[\u2055-\u205E]/, /[\u2190-\u23FF]/, /[\u2500-\u2775]/, /[\u2794-\u2BFF]/, /[\u2E00-\u2E7F]/, /[\u3001-\u3003]/, /[\u3008-\u3020]/, /[\u3030]/), Sn = Z(xn, /[\u0300-\u036F]/, /[\u1DC0-\u1DFF]/, /[\u20D0-\u20FF]/, /[\uFE00-\uFE0F]/, /[\uFE20-\uFE2F]/), Cn = X(xn, Sn, "*"), wn = Z(/[a-zA-Z_]/, /[\u00A8\u00AA\u00AD\u00AF\u00B2-\u00B5\u00B7-\u00BA]/, /[\u00BC-\u00BE\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u00FF]/, /[\u0100-\u02FF\u0370-\u167F\u1681-\u180D\u180F-\u1DBF]/, /[\u1E00-\u1FFF]/, /[\u200B-\u200D\u202A-\u202E\u203F-\u2040\u2054\u2060-\u206F]/, /[\u2070-\u20CF\u2100-\u218F\u2460-\u24FF\u2776-\u2793]/, /[\u2C00-\u2DFF\u2E80-\u2FFF]/, /[\u3004-\u3007\u3021-\u302F\u3031-\u303F\u3040-\uD7FF]/, /[\uF900-\uFD3D\uFD40-\uFDCF\uFDF0-\uFE1F\uFE30-\uFE44]/, /[\uFE47-\uFEFE\uFF00-\uFFFD]/), Tn = Z(wn, /\d/, /[\u0300-\u036F\u1DC0-\u1DFF\u20D0-\u20FF\uFE20-\uFE2F]/), En = X(wn, Tn, "*"), Dn = X(/[A-Z]/, Tn, "*"), On = [
	"attached",
	"autoclosure",
	X(/convention\(/, Z("swift", "block", "c"), /\)/),
	"discardableResult",
	"dynamicCallable",
	"dynamicMemberLookup",
	"escaping",
	"freestanding",
	"frozen",
	"GKInspectable",
	"IBAction",
	"IBDesignable",
	"IBInspectable",
	"IBOutlet",
	"IBSegueAction",
	"inlinable",
	"main",
	"nonobjc",
	"NSApplicationMain",
	"NSCopying",
	"NSManaged",
	X(/objc\(/, En, /\)/),
	"objc",
	"objcMembers",
	"propertyWrapper",
	"requires_stored_property_inits",
	"resultBuilder",
	"Sendable",
	"testable",
	"UIApplicationMain",
	"unchecked",
	"unknown",
	"usableFromInline",
	"warn_unqualified_access"
], kn = [
	"iOS",
	"iOSApplicationExtension",
	"macOS",
	"macOSApplicationExtension",
	"macCatalyst",
	"macCatalystApplicationExtension",
	"watchOS",
	"watchOSApplicationExtension",
	"tvOS",
	"tvOSApplicationExtension",
	"swift"
];
function An(e) {
	let t = {
		match: /\s+/,
		relevance: 0
	}, n = e.COMMENT("/\\*", "\\*/", { contains: ["self"] }), r = [e.C_LINE_COMMENT_MODE, n], i = {
		match: [/\./, Z(...pn, ...mn)],
		className: { 2: "keyword" }
	}, a = {
		match: X(/\./, Z(...gn)),
		relevance: 0
	}, o = gn.filter((e) => typeof e == "string").concat(["_|0"]), s = { variants: [{
		className: "keyword",
		match: Z(...gn.filter((e) => typeof e != "string").concat(hn).map(fn), ...mn)
	}] }, c = {
		$pattern: Z(/\b\w+/, /#\w+/),
		keyword: o.concat(yn),
		literal: _n
	}, l = [
		i,
		a,
		s
	], u = [{
		match: X(/\./, Z(...bn)),
		relevance: 0
	}, {
		className: "built_in",
		match: X(/\b/, Z(...bn), /(?=\()/)
	}], d = {
		match: /->/,
		relevance: 0
	}, f = [d, {
		className: "operator",
		relevance: 0,
		variants: [{ match: Cn }, { match: `\\.(\\.|${Sn})+` }]
	}], p = "([0-9]_*)+", m = "([0-9a-fA-F]_*)+", h = {
		className: "number",
		relevance: 0,
		variants: [
			{ match: `\\b(${p})(\\.(${p}))?([eE][+-]?(${p}))?\\b` },
			{ match: `\\b0x(${m})(\\.(${m}))?([pP][+-]?(${p}))?\\b` },
			{ match: /\b0o([0-7]_*)+\b/ },
			{ match: /\b0b([01]_*)+\b/ }
		]
	}, g = (e = "") => ({
		className: "subst",
		variants: [{ match: X(/\\/, e, /[0\\tnr"']/) }, { match: X(/\\/, e, /u\{[0-9a-fA-F]{1,8}\}/) }]
	}), _ = (e = "") => ({
		className: "subst",
		match: X(/\\/, e, /[\t ]*(?:[\r\n]|\r\n)/)
	}), v = (e = "") => ({
		className: "subst",
		label: "interpol",
		begin: X(/\\/, e, /\(/),
		end: /\)/
	}), y = (e = "") => ({
		begin: X(e, /"""/),
		end: X(/"""/, e),
		contains: [
			g(e),
			_(e),
			v(e)
		]
	}), b = (e = "") => ({
		begin: X(e, /"/),
		end: X(/"/, e),
		contains: [g(e), v(e)]
	}), x = {
		className: "string",
		variants: [
			y(),
			y("#"),
			y("##"),
			y("###"),
			b(),
			b("#"),
			b("##"),
			b("###")
		]
	}, S = [e.BACKSLASH_ESCAPE, {
		begin: /\[/,
		end: /\]/,
		relevance: 0,
		contains: [e.BACKSLASH_ESCAPE]
	}], C = {
		begin: /\/[^\s](?=[^/\n]*\/)/,
		end: /\//,
		contains: S
	}, w = (e) => {
		let t = X(e, /\//), n = X(/\//, e);
		return {
			begin: t,
			end: n,
			contains: [...S, {
				scope: "comment",
				begin: `#(?!.*${n})`,
				end: /$/
			}]
		};
	}, T = {
		scope: "regexp",
		variants: [
			w("###"),
			w("##"),
			w("#"),
			C
		]
	}, E = { match: X(/`/, En, /`/) }, D = [
		E,
		{
			className: "variable",
			match: /\$\d+/
		},
		{
			className: "variable",
			match: `\\$${Tn}+`
		}
	], O = [
		{
			match: /(@|#(un)?)available/,
			scope: "keyword",
			starts: { contains: [{
				begin: /\(/,
				end: /\)/,
				keywords: kn,
				contains: [
					...f,
					h,
					x
				]
			}] }
		},
		{
			scope: "keyword",
			match: X(/@/, Z(...On), un(Z(/\(/, /\s+/)))
		},
		{
			scope: "meta",
			match: X(/@/, En)
		}
	], k = {
		match: un(/\b[A-Z]/),
		relevance: 0,
		contains: [
			{
				className: "type",
				match: X(/(AV|CA|CF|CG|CI|CL|CM|CN|CT|MK|MP|MTK|MTL|NS|SCN|SK|UI|WK|XC)/, Tn, "+")
			},
			{
				className: "type",
				match: Dn,
				relevance: 0
			},
			{
				match: /[?!]+/,
				relevance: 0
			},
			{
				match: /\.\.\./,
				relevance: 0
			},
			{
				match: X(/\s+&\s+/, un(Dn)),
				relevance: 0
			}
		]
	}, A = {
		begin: /</,
		end: />/,
		keywords: c,
		contains: [
			...r,
			...l,
			...O,
			d,
			k
		]
	};
	k.contains.push(A);
	let ee = {
		begin: /\(/,
		end: /\)/,
		relevance: 0,
		keywords: c,
		contains: [
			"self",
			{
				match: X(En, /\s*:/),
				keywords: "_|0",
				relevance: 0
			},
			...r,
			T,
			...l,
			...u,
			...f,
			h,
			x,
			...D,
			...O,
			k
		]
	}, j = {
		begin: /</,
		end: />/,
		keywords: "repeat each",
		contains: [...r, k]
	}, M = {
		begin: /\(/,
		end: /\)/,
		keywords: c,
		contains: [
			{
				begin: Z(un(X(En, /\s*:/)), un(X(En, /\s+/, En, /\s*:/))),
				end: /:/,
				relevance: 0,
				contains: [{
					className: "keyword",
					match: /\b_\b/
				}, {
					className: "params",
					match: En
				}]
			},
			...r,
			...l,
			...f,
			h,
			x,
			...O,
			k,
			ee
		],
		endsParent: !0,
		illegal: /["']/
	}, N = {
		match: [
			/(func|macro)/,
			/\s+/,
			Z(E.match, En, Cn)
		],
		className: {
			1: "keyword",
			3: "title.function"
		},
		contains: [
			j,
			M,
			t
		],
		illegal: [/\[/, /%/]
	}, P = {
		match: [/\b(?:subscript|init[?!]?)/, /\s*(?=[<(])/],
		className: { 1: "keyword" },
		contains: [
			j,
			M,
			t
		],
		illegal: /\[|%/
	}, F = {
		match: [
			/operator/,
			/\s+/,
			Cn
		],
		className: {
			1: "keyword",
			3: "title"
		}
	}, I = {
		begin: [
			/precedencegroup/,
			/\s+/,
			Dn
		],
		className: {
			1: "keyword",
			3: "title"
		},
		contains: [k],
		keywords: [...vn, ..._n],
		end: /}/
	}, L = {
		match: [
			/class\b/,
			/\s+/,
			/func\b/,
			/\s+/,
			/\b[A-Za-z_][A-Za-z0-9_]*\b/
		],
		scope: {
			1: "keyword",
			3: "keyword",
			5: "title.function"
		}
	}, te = {
		match: [
			/class\b/,
			/\s+/,
			/var\b/
		],
		scope: {
			1: "keyword",
			3: "keyword"
		}
	}, ne = {
		begin: [
			/(struct|protocol|class|extension|enum|actor)/,
			/\s+/,
			En,
			/\s*/
		],
		beginScope: {
			1: "keyword",
			3: "title.class"
		},
		keywords: c,
		contains: [
			j,
			...l,
			{
				begin: /:/,
				end: /\{/,
				keywords: c,
				contains: [{
					scope: "title.class.inherited",
					match: Dn
				}, ...l],
				relevance: 0
			}
		]
	};
	for (let e of x.variants) {
		let t = e.contains.find((e) => e.label === "interpol");
		t.keywords = c;
		let n = [
			...l,
			...u,
			...f,
			h,
			x,
			...D
		];
		t.contains = [...n, {
			begin: /\(/,
			end: /\)/,
			contains: ["self", ...n]
		}];
	}
	return {
		name: "Swift",
		keywords: c,
		contains: [
			...r,
			N,
			P,
			L,
			te,
			ne,
			F,
			I,
			{
				beginKeywords: "import",
				end: /$/,
				contains: [...r],
				relevance: 0
			},
			T,
			...l,
			...u,
			...f,
			h,
			x,
			...D,
			...O,
			k,
			ee
		]
	};
}
// node_modules/highlight.js/es/languages/typescript.js
var jn = "[A-Za-z$_][0-9A-Za-z$_]*", Mn = /* @__PURE__ */ "as.in.of.if.for.while.finally.var.new.function.do.return.void.else.break.catch.instanceof.with.throw.case.default.try.switch.continue.typeof.delete.let.yield.const.class.debugger.async.await.static.import.from.export.extends.using".split("."), Nn = [
	"true",
	"false",
	"null",
	"undefined",
	"NaN",
	"Infinity"
], Pn = /* @__PURE__ */ "Object.Function.Boolean.Symbol.Math.Date.Number.BigInt.String.RegExp.Array.Float32Array.Float64Array.Int8Array.Uint8Array.Uint8ClampedArray.Int16Array.Int32Array.Uint16Array.Uint32Array.BigInt64Array.BigUint64Array.Set.Map.WeakSet.WeakMap.ArrayBuffer.SharedArrayBuffer.Atomics.DataView.JSON.Promise.Generator.GeneratorFunction.AsyncFunction.Reflect.Proxy.Intl.WebAssembly".split("."), Fn = [
	"Error",
	"EvalError",
	"InternalError",
	"RangeError",
	"ReferenceError",
	"SyntaxError",
	"TypeError",
	"URIError"
], In = [
	"setInterval",
	"setTimeout",
	"clearInterval",
	"clearTimeout",
	"require",
	"exports",
	"eval",
	"isFinite",
	"isNaN",
	"parseFloat",
	"parseInt",
	"decodeURI",
	"decodeURIComponent",
	"encodeURI",
	"encodeURIComponent",
	"escape",
	"unescape"
], Ln = [
	"arguments",
	"this",
	"super",
	"console",
	"window",
	"document",
	"localStorage",
	"sessionStorage",
	"module",
	"global"
], Rn = [].concat(In, Pn, Fn);
function zn(e) {
	let t = e.regex, n = (e, { after: t }) => {
		let n = "</" + e[0].slice(1);
		return e.input.indexOf(n, t) !== -1;
	}, r = jn, i = {
		begin: "<>",
		end: "</>"
	}, a = /<[A-Za-z0-9\\._:-]+\s*\/>/, o = {
		begin: /<[A-Za-z0-9\\._:-]+/,
		end: /\/[A-Za-z0-9\\._:-]+>|\/>/,
		isTrulyOpeningTag: (e, t) => {
			let r = e[0].length + e.index, i = e.input[r];
			if (i === "<" || i === ",") {
				t.ignoreMatch();
				return;
			}
			i === ">" && (n(e, { after: r }) || t.ignoreMatch());
			let a, o = e.input.substring(r);
			((a = o.match(/^\s*=/)) || (a = o.match(/^\s+extends\s+/)) && a.index === 0) && t.ignoreMatch();
		}
	}, s = {
		$pattern: jn,
		keyword: Mn,
		literal: Nn,
		built_in: Rn,
		"variable.language": Ln
	}, c = "[0-9](_?[0-9])*", l = `\\.(${c})`, u = "0|[1-9](_?[0-9])*|0[0-7]*[89][0-9]*", d = {
		className: "number",
		variants: [
			{ begin: `(\\b(${u})((${l})|\\.)?|(${l}))[eE][+-]?(${c})\\b` },
			{ begin: `\\b(${u})\\b((${l})\\b|\\.)?|(${l})\\b` },
			{ begin: "\\b(0|[1-9](_?[0-9])*)n\\b" },
			{ begin: "\\b0[xX][0-9a-fA-F](_?[0-9a-fA-F])*n?\\b" },
			{ begin: "\\b0[bB][0-1](_?[0-1])*n?\\b" },
			{ begin: "\\b0[oO][0-7](_?[0-7])*n?\\b" },
			{ begin: "\\b0[0-7]+n?\\b" }
		],
		relevance: 0
	}, f = {
		className: "subst",
		begin: "\\$\\{",
		end: "\\}",
		keywords: s,
		contains: []
	}, p = {
		begin: ".?html`",
		end: "",
		starts: {
			end: "`",
			returnEnd: !1,
			contains: [e.BACKSLASH_ESCAPE, f],
			subLanguage: "xml"
		}
	}, m = {
		begin: ".?css`",
		end: "",
		starts: {
			end: "`",
			returnEnd: !1,
			contains: [e.BACKSLASH_ESCAPE, f],
			subLanguage: "css"
		}
	}, h = {
		begin: ".?gql`",
		end: "",
		starts: {
			end: "`",
			returnEnd: !1,
			contains: [e.BACKSLASH_ESCAPE, f],
			subLanguage: "graphql"
		}
	}, g = {
		className: "string",
		begin: "`",
		end: "`",
		contains: [e.BACKSLASH_ESCAPE, f]
	}, _ = {
		className: "comment",
		variants: [
			e.COMMENT(/\/\*\*(?!\/)/, "\\*/", {
				relevance: 0,
				contains: [{
					begin: "(?=@[A-Za-z]+)",
					relevance: 0,
					contains: [
						{
							className: "doctag",
							begin: "@[A-Za-z]+"
						},
						{
							className: "type",
							begin: "\\{",
							end: "\\}",
							excludeEnd: !0,
							excludeBegin: !0,
							relevance: 0
						},
						{
							className: "variable",
							begin: r + "(?=\\s*(-)|$)",
							endsParent: !0,
							relevance: 0
						},
						{
							begin: /(?=[^\n])\s/,
							relevance: 0
						}
					]
				}]
			}),
			e.C_BLOCK_COMMENT_MODE,
			e.C_LINE_COMMENT_MODE
		]
	}, v = [
		e.APOS_STRING_MODE,
		e.QUOTE_STRING_MODE,
		p,
		m,
		h,
		g,
		{ match: /\$\d+/ },
		d
	];
	f.contains = v.concat({
		begin: /\{/,
		end: /\}/,
		keywords: s,
		contains: ["self"].concat(v)
	});
	let y = [].concat(_, f.contains), b = y.concat([{
		begin: /(\s*)\(/,
		end: /\)/,
		keywords: s,
		contains: ["self"].concat(y)
	}]), x = {
		className: "params",
		begin: /(\s*)\(/,
		end: /\)/,
		excludeBegin: !0,
		excludeEnd: !0,
		keywords: s,
		contains: b
	}, S = { variants: [{
		match: [
			/class/,
			/\s+/,
			r,
			/\s+/,
			/extends/,
			/\s+/,
			t.concat(r, "(", t.concat(/\./, r), ")*")
		],
		scope: {
			1: "keyword",
			3: "title.class",
			5: "keyword",
			7: "title.class.inherited"
		}
	}, {
		match: [
			/class/,
			/\s+/,
			r
		],
		scope: {
			1: "keyword",
			3: "title.class"
		}
	}] }, C = {
		relevance: 0,
		match: t.either(/\bJSON/, /\b[A-Z][a-z]+([A-Z][a-z]*|\d)*/, /\b[A-Z]{2,}([A-Z][a-z]+|\d)+([A-Z][a-z]*)*/, /\b[A-Z]{2,}[a-z]+([A-Z][a-z]+|\d)*([A-Z][a-z]*)*/),
		className: "title.class",
		keywords: { _: [...Pn, ...Fn] }
	}, w = {
		label: "use_strict",
		className: "meta",
		relevance: 10,
		begin: /^\s*['"]use (strict|asm)['"]/
	}, T = {
		variants: [{ match: [
			/function/,
			/\s+/,
			r,
			/(?=\s*\()/
		] }, { match: [/function/, /\s*(?=\()/] }],
		className: {
			1: "keyword",
			3: "title.function"
		},
		label: "func.def",
		contains: [x],
		illegal: /%/
	}, E = {
		relevance: 0,
		match: /\b[A-Z][A-Z_0-9]+\b/,
		className: "variable.constant"
	};
	function D(e) {
		return t.concat("(?!", e.join("|"), ")");
	}
	let O = {
		match: t.concat(/\b/, D([
			...In,
			"super",
			"import",
			"await"
		].map((e) => `${e}\\s*\\(`)), r, t.lookahead(/\s*\(/)),
		className: "title.function",
		relevance: 0
	}, k = {
		begin: t.concat(/\./, t.lookahead(t.concat(r, /(?![0-9A-Za-z$_(])/))),
		end: r,
		excludeBegin: !0,
		keywords: "prototype",
		className: "property",
		relevance: 0
	}, A = {
		match: [
			/get|set/,
			/\s+/,
			r,
			/(?=\()/
		],
		className: {
			1: "keyword",
			3: "title.function"
		},
		contains: [{ begin: /\(\)/ }, x]
	}, ee = "(\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)|" + e.UNDERSCORE_IDENT_RE + ")\\s*=>", j = {
		match: [
			/const|var|let/,
			/\s+/,
			r,
			/\s*/,
			/=\s*/,
			/(async\s*)?/,
			t.lookahead(ee)
		],
		keywords: "async",
		className: {
			1: "keyword",
			3: "title.function"
		},
		contains: [x]
	};
	return {
		name: "JavaScript",
		aliases: [
			"js",
			"jsx",
			"mjs",
			"cjs"
		],
		keywords: s,
		exports: {
			PARAMS_CONTAINS: b,
			CLASS_REFERENCE: C
		},
		illegal: /#(?![$_A-Za-z])/,
		contains: [
			e.SHEBANG({
				label: "shebang",
				binary: "node",
				relevance: 5
			}),
			w,
			e.APOS_STRING_MODE,
			e.QUOTE_STRING_MODE,
			p,
			m,
			h,
			g,
			_,
			{ match: /\$\d+/ },
			d,
			C,
			{
				scope: "attr",
				match: r + t.lookahead(":"),
				relevance: 0
			},
			j,
			{
				begin: "(" + e.RE_STARTERS_RE + "|\\b(case|return|throw)\\b)\\s*",
				keywords: "return throw case",
				relevance: 0,
				contains: [
					_,
					e.REGEXP_MODE,
					{
						className: "function",
						begin: ee,
						returnBegin: !0,
						end: "\\s*=>",
						contains: [{
							className: "params",
							variants: [
								{
									begin: e.UNDERSCORE_IDENT_RE,
									relevance: 0
								},
								{
									className: null,
									begin: /\(\s*\)/,
									skip: !0
								},
								{
									begin: /(\s*)\(/,
									end: /\)/,
									excludeBegin: !0,
									excludeEnd: !0,
									keywords: s,
									contains: b
								}
							]
						}]
					},
					{
						begin: /,/,
						relevance: 0
					},
					{
						match: /\s+/,
						relevance: 0
					},
					{
						variants: [
							{
								begin: i.begin,
								end: i.end
							},
							{ match: a },
							{
								begin: o.begin,
								"on:begin": o.isTrulyOpeningTag,
								end: o.end
							}
						],
						subLanguage: "xml",
						contains: [{
							begin: o.begin,
							end: o.end,
							skip: !0,
							contains: ["self"]
						}]
					}
				]
			},
			T,
			{ beginKeywords: "while if switch catch for" },
			{
				begin: "\\b(?!function)" + e.UNDERSCORE_IDENT_RE + "\\([^()]*(\\([^()]*(\\([^()]*\\)[^()]*)*\\)[^()]*)*\\)\\s*\\{",
				returnBegin: !0,
				label: "func.def",
				contains: [x, e.inherit(e.TITLE_MODE, {
					begin: r,
					className: "title.function"
				})]
			},
			{
				match: /\.\.\./,
				relevance: 0
			},
			k,
			{
				match: "\\$" + r,
				relevance: 0
			},
			{
				match: [/\bconstructor(?=\s*\()/],
				className: { 1: "title.function" },
				contains: [x]
			},
			O,
			E,
			S,
			A,
			{ match: /\$[(.]/ }
		]
	};
}
function Bn(e) {
	let t = e.regex, n = zn(e), r = jn, i = [
		"any",
		"void",
		"number",
		"boolean",
		"string",
		"object",
		"never",
		"symbol",
		"bigint",
		"unknown"
	], a = {
		begin: [
			/namespace/,
			/\s+/,
			e.IDENT_RE
		],
		beginScope: {
			1: "keyword",
			3: "title.class"
		}
	}, o = {
		beginKeywords: "interface",
		end: /\{/,
		excludeEnd: !0,
		keywords: {
			keyword: "interface extends",
			built_in: i
		},
		contains: [n.exports.CLASS_REFERENCE]
	}, s = {
		className: "meta",
		relevance: 10,
		begin: /^\s*['"]use strict['"]/
	}, c = {
		$pattern: jn,
		keyword: Mn.concat([
			"type",
			"interface",
			"public",
			"private",
			"protected",
			"implements",
			"declare",
			"abstract",
			"readonly",
			"enum",
			"override",
			"satisfies"
		]),
		literal: Nn,
		built_in: Rn.concat(i),
		"variable.language": Ln
	}, l = {
		className: "meta",
		begin: "@" + r
	}, u = (e, t, n) => {
		let r = e.contains.findIndex((e) => e.label === t);
		if (r === -1) throw Error("can not find mode to replace");
		e.contains.splice(r, 1, n);
	};
	Object.assign(n.keywords, c), n.exports.PARAMS_CONTAINS.push(l);
	let d = n.contains.find((e) => e.scope === "attr"), f = Object.assign({}, d, { match: t.concat(r, t.lookahead(/\s*\?:/)) });
	n.exports.PARAMS_CONTAINS.push([
		n.exports.CLASS_REFERENCE,
		d,
		f
	]), n.contains = n.contains.concat([
		l,
		a,
		o,
		f
	]), u(n, "shebang", e.SHEBANG()), u(n, "use_strict", s);
	let p = n.contains.find((e) => e.label === "func.def");
	return p.relevance = 0, Object.assign(n, {
		name: "TypeScript",
		aliases: [
			"ts",
			"tsx",
			"mts",
			"cts"
		]
	}), n;
}
// node_modules/highlight.js/es/languages/vbnet.js
function Vn(e) {
	let t = e.regex, n = {
		className: "string",
		begin: /"(""|[^/n])"C\b/
	}, r = {
		className: "string",
		begin: /"/,
		end: /"/,
		illegal: /\n/,
		contains: [{ begin: /""/ }]
	}, i = /\d{1,2}\/\d{1,2}\/\d{4}/, a = /\d{4}-\d{1,2}-\d{1,2}/, o = /(\d|1[012])(:\d+){0,2} *(AM|PM)/, s = /\d{1,2}(:\d{1,2}){1,2}/, c = {
		className: "literal",
		variants: [
			{ begin: t.concat(/# */, t.either(a, i), / *#/) },
			{ begin: t.concat(/# */, s, / *#/) },
			{ begin: t.concat(/# */, o, / *#/) },
			{ begin: t.concat(/# */, t.either(a, i), / +/, t.either(o, s), / *#/) }
		]
	}, l = {
		className: "number",
		relevance: 0,
		variants: [
			{ begin: /\b\d[\d_]*((\.[\d_]+(E[+-]?[\d_]+)?)|(E[+-]?[\d_]+))[RFD@!#]?/ },
			{ begin: /\b\d[\d_]*((U?[SIL])|[%&])?/ },
			{ begin: /&H[\dA-F_]+((U?[SIL])|[%&])?/ },
			{ begin: /&O[0-7_]+((U?[SIL])|[%&])?/ },
			{ begin: /&B[01_]+((U?[SIL])|[%&])?/ }
		]
	}, u = {
		className: "label",
		begin: /^\w+:/
	}, d = e.COMMENT(/'''/, /$/, { contains: [{
		className: "doctag",
		begin: /<\/?/,
		end: />/
	}] }), f = e.COMMENT(null, /$/, { variants: [{ begin: /'/ }, { begin: /([\t ]|^)REM(?=\s)/ }] });
	return {
		name: "Visual Basic .NET",
		aliases: ["vb"],
		case_insensitive: !0,
		classNameAliases: { label: "symbol" },
		keywords: {
			keyword: "addhandler alias aggregate ansi as async assembly auto binary by byref byval call case catch class compare const continue custom declare default delegate dim distinct do each equals else elseif end enum erase error event exit explicit finally for friend from function get global goto group handles if implements imports in inherits interface into iterator join key let lib loop me mid module mustinherit mustoverride mybase myclass namespace narrowing new next notinheritable notoverridable of off on operator option optional order overloads overridable overrides paramarray partial preserve private property protected public raiseevent readonly redim removehandler resume return select set shadows shared skip static step stop structure strict sub synclock take text then throw to try unicode until using when where while widening with withevents writeonly yield",
			built_in: "addressof and andalso await directcast gettype getxmlnamespace is isfalse isnot istrue like mod nameof new not or orelse trycast typeof xor cbool cbyte cchar cdate cdbl cdec cint clng cobj csbyte cshort csng cstr cuint culng cushort",
			type: "boolean byte char date decimal double integer long object sbyte short single string uinteger ulong ushort",
			literal: "true false nothing"
		},
		illegal: "//|\\{|\\}|endif|gosub|variant|wend|^\\$ ",
		contains: [
			n,
			r,
			c,
			l,
			u,
			d,
			f,
			{
				className: "meta",
				begin: /[\t ]*#(const|disable|else|elseif|enable|end|externalsource|if|region)\b/,
				end: /$/,
				keywords: { keyword: "const disable else elseif enable end externalsource if region then" },
				contains: [f]
			}
		]
	};
}
// node_modules/highlight.js/es/languages/wasm.js
function Hn(e) {
	e.regex;
	let t = e.COMMENT(/\(;/, /;\)/);
	return t.contains.push("self"), {
		name: "WebAssembly",
		keywords: {
			$pattern: /[\w.]+/,
			keyword: /* @__PURE__ */ "anyfunc,block,br,br_if,br_table,call,call_indirect,data,drop,elem,else,end,export,func,global.get,global.set,local.get,local.set,local.tee,get_global,get_local,global,if,import,local,loop,memory,memory.grow,memory.size,module,mut,nop,offset,param,result,return,select,set_global,set_local,start,table,tee_local,then,type,unreachable".split(",")
		},
		contains: [
			e.COMMENT(/;;/, /$/),
			t,
			{
				match: [
					/(?:offset|align)/,
					/\s*/,
					/=/
				],
				className: {
					1: "keyword",
					3: "operator"
				}
			},
			{
				className: "variable",
				begin: /\$[\w_]+/
			},
			{
				match: /(\((?!;)|\))+/,
				className: "punctuation",
				relevance: 0
			},
			{
				begin: [
					/(?:func|call|call_indirect)/,
					/\s+/,
					/\$[^\s)]+/
				],
				className: {
					1: "keyword",
					3: "title.function"
				}
			},
			e.QUOTE_STRING_MODE,
			{
				match: /(i32|i64|f32|f64)(?!\.)/,
				className: "type"
			},
			{
				className: "keyword",
				match: /\b(f32|f64|i32|i64)(?:\.(?:abs|add|and|ceil|clz|const|convert_[su]\/i(?:32|64)|copysign|ctz|demote\/f64|div(?:_[su])?|eqz?|extend_[su]\/i32|floor|ge(?:_[su])?|gt(?:_[su])?|le(?:_[su])?|load(?:(?:8|16|32)_[su])?|lt(?:_[su])?|max|min|mul|nearest|neg?|or|popcnt|promote\/f32|reinterpret\/[fi](?:32|64)|rem_[su]|rot[lr]|shl|shr_[su]|store(?:8|16|32)?|sqrt|sub|trunc(?:_[su]\/f(?:32|64))?|wrap\/i64|xor))\b/
			},
			{
				className: "number",
				relevance: 0,
				match: /[+-]?\b(?:\d(?:_?\d)*(?:\.\d(?:_?\d)*)?(?:[eE][+-]?\d(?:_?\d)*)?|0x[\da-fA-F](?:_?[\da-fA-F])*(?:\.[\da-fA-F](?:_?[\da-fA-D])*)?(?:[pP][+-]?\d(?:_?\d)*)?)\b|\binf\b|\bnan(?::0x[\da-fA-F](?:_?[\da-fA-D])*)?\b/
			}
		]
	};
}
// node_modules/highlight.js/es/languages/xml.js
function Un(e) {
	let t = e.regex, n = t.concat(/[\p{L}_]/u, t.optional(/[\p{L}0-9_.-]*:/u), /[\p{L}0-9_.-]*/u), r = /[\p{L}0-9._:-]+/u, i = {
		className: "symbol",
		begin: /&[a-z]+;|&#[0-9]+;|&#x[a-f0-9]+;/
	}, a = {
		begin: /\s/,
		contains: [{
			className: "keyword",
			begin: /#?[a-z_][a-z1-9_-]+/,
			illegal: /\n/
		}]
	}, o = e.inherit(a, {
		begin: /\(/,
		end: /\)/
	}), s = e.inherit(e.APOS_STRING_MODE, { className: "string" }), c = e.inherit(e.QUOTE_STRING_MODE, { className: "string" }), l = {
		endsWithParent: !0,
		illegal: /</,
		relevance: 0,
		contains: [{
			className: "attr",
			begin: r,
			relevance: 0
		}, {
			begin: /=\s*/,
			relevance: 0,
			contains: [{
				className: "string",
				endsParent: !0,
				variants: [
					{
						begin: /"/,
						end: /"/,
						contains: [i]
					},
					{
						begin: /'/,
						end: /'/,
						contains: [i]
					},
					{ begin: /[^\s"'=<>`]+/ }
				]
			}]
		}]
	};
	return {
		name: "HTML, XML",
		aliases: [
			"html",
			"xhtml",
			"rss",
			"atom",
			"xjb",
			"xsd",
			"xsl",
			"plist",
			"wsf",
			"svg"
		],
		case_insensitive: !0,
		unicodeRegex: !0,
		contains: [
			{
				className: "meta",
				begin: /<![a-z]/,
				end: />/,
				relevance: 10,
				contains: [
					a,
					c,
					s,
					o,
					{
						begin: /\[/,
						end: /\]/,
						contains: [{
							className: "meta",
							begin: /<![a-z]/,
							end: />/,
							contains: [
								a,
								o,
								c,
								s
							]
						}]
					}
				]
			},
			e.COMMENT(/<!--/, /-->/, { relevance: 10 }),
			{
				begin: /<!\[CDATA\[/,
				end: /\]\]>/,
				relevance: 10
			},
			i,
			{
				className: "meta",
				end: /\?>/,
				variants: [{
					begin: /<\?xml/,
					relevance: 10,
					contains: [c]
				}, { begin: /<\?[a-z][a-z0-9]+/ }]
			},
			{
				className: "tag",
				begin: /<style(?=\s|>)/,
				end: />/,
				keywords: { name: "style" },
				contains: [l],
				starts: {
					end: /<\/style>/,
					returnEnd: !0,
					subLanguage: ["css", "xml"]
				}
			},
			{
				className: "tag",
				begin: /<script(?=\s|>)/,
				end: />/,
				keywords: { name: "script" },
				contains: [l],
				starts: {
					end: /<\/script>/,
					returnEnd: !0,
					subLanguage: [
						"javascript",
						"handlebars",
						"xml"
					]
				}
			},
			{
				className: "tag",
				begin: /<>|<\/>/
			},
			{
				className: "tag",
				begin: t.concat(/</, t.lookahead(t.concat(n, t.either(/\/>/, />/, /\s/)))),
				end: /\/?>/,
				contains: [{
					className: "name",
					begin: n,
					relevance: 0,
					starts: l
				}]
			},
			{
				className: "tag",
				begin: t.concat(/<\//, t.lookahead(t.concat(n, />/))),
				contains: [{
					className: "name",
					begin: n,
					relevance: 0
				}, {
					begin: />/,
					relevance: 0,
					endsParent: !0
				}]
			}
		]
	};
}
// node_modules/highlight.js/es/languages/yaml.js
function Wn(e) {
	let t = "true false yes no null", n = "[\\w#;/?:@&=+$,.~*'()[\\]]+", r = {
		className: "attr",
		variants: [
			{ begin: /[\w*@][\w*@ :()\./-]*:(?=[ \t]|$)/ },
			{ begin: /"[\w*@][\w*@ :()\./-]*":(?=[ \t]|$)/ },
			{ begin: /'[\w*@][\w*@ :()\./-]*':(?=[ \t]|$)/ }
		]
	}, i = {
		className: "template-variable",
		variants: [{
			begin: /\{\{/,
			end: /\}\}/
		}, {
			begin: /%\{/,
			end: /\}/
		}]
	}, a = {
		className: "string",
		relevance: 0,
		begin: /'/,
		end: /'/,
		contains: [{
			match: /''/,
			scope: "char.escape",
			relevance: 0
		}]
	}, o = {
		className: "string",
		relevance: 0,
		variants: [{
			begin: /"/,
			end: /"/
		}, { begin: /\S+/ }],
		contains: [e.BACKSLASH_ESCAPE, i]
	}, s = e.inherit(o, { variants: [
		{
			begin: /'/,
			end: /'/,
			contains: [{
				begin: /''/,
				relevance: 0
			}]
		},
		{
			begin: /"/,
			end: /"/
		},
		{ begin: /[^\s,{}[\]]+/ }
	] }), c = {
		className: "number",
		begin: "\\b[0-9]{4}(-[0-9][0-9]){0,2}([Tt \\t][0-9][0-9]?(:[0-9][0-9]){2})?(\\.[0-9]*)?([ \\t])*(Z|[-+][0-9][0-9]?(:[0-9][0-9])?)?\\b"
	}, l = {
		end: ",",
		endsWithParent: !0,
		excludeEnd: !0,
		keywords: t,
		relevance: 0
	}, u = {
		begin: /\{/,
		end: /\}/,
		contains: [l],
		illegal: "\\n",
		relevance: 0
	}, d = {
		begin: "\\[",
		end: "\\]",
		contains: [l],
		illegal: "\\n",
		relevance: 0
	}, f = [
		r,
		{
			className: "meta",
			begin: "^---\\s*$",
			relevance: 10
		},
		{
			className: "string",
			begin: "[\\|>]([1-9]?[+-])?[ ]*\\n( +)[^ ][^\\n]*\\n(\\2[^\\n]+\\n?)*"
		},
		{
			begin: "<%[%=-]?",
			end: "[%-]?%>",
			subLanguage: "ruby",
			excludeBegin: !0,
			excludeEnd: !0,
			relevance: 0
		},
		{
			className: "type",
			begin: "!\\w+!" + n
		},
		{
			className: "type",
			begin: "!<" + n + ">"
		},
		{
			className: "type",
			begin: "!" + n
		},
		{
			className: "type",
			begin: "!!" + n
		},
		{
			className: "meta",
			begin: "&" + e.UNDERSCORE_IDENT_RE + "$"
		},
		{
			className: "meta",
			begin: "\\*" + e.UNDERSCORE_IDENT_RE + "$"
		},
		{
			className: "bullet",
			begin: "-(?=[ ]|$)",
			relevance: 0
		},
		e.HASH_COMMENT_MODE,
		{
			beginKeywords: t,
			keywords: { literal: t }
		},
		c,
		{
			className: "number",
			begin: e.C_NUMBER_RE + "\\b",
			relevance: 0
		},
		u,
		d,
		a,
		o
	], p = [...f];
	return p.pop(), p.push(s), l.contains = p, {
		name: "YAML",
		case_insensitive: !0,
		aliases: ["yml"],
		contains: f
	};
}
// node_modules/lowlight/lib/common.js
var Gn = {
	arduino: He,
	bash: Ue,
	c: We,
	cpp: Ge,
	csharp: Ke,
	css: tt,
	diff: nt,
	go: rt,
	graphql: it,
	ini: at,
	java: dt,
	javascript: bt,
	json: St,
	kotlin: Dt,
	less: Lt,
	lua: Rt,
	makefile: zt,
	markdown: Bt,
	objectivec: Vt,
	perl: Ht,
	php: Ut,
	"php-template": Wt,
	plaintext: Gt,
	python: Kt,
	"python-repl": qt,
	r: Jt,
	ruby: Yt,
	rust: Xt,
	scss: on,
	shell: sn,
	sql: cn,
	swift: An,
	typescript: Bn,
	vbnet: Vn,
	wasm: Hn,
	xml: Un,
	yaml: Wn
}, Kn = (/* @__PURE__ */ e((/* @__PURE__ */ t(((e, t) => {
	function n(e) {
		return e instanceof Map ? e.clear = e.delete = e.set = function() {
			throw Error("map is read-only");
		} : e instanceof Set && (e.add = e.clear = e.delete = function() {
			throw Error("set is read-only");
		}), Object.freeze(e), Object.getOwnPropertyNames(e).forEach((t) => {
			let r = e[t], i = typeof r;
			i !== "object" && i !== "function" || Object.isFrozen(r) || n(r);
		}), e;
	}
	var r = class {
		constructor(e) {
			e.data === void 0 && (e.data = {}), this.data = e.data, this.isMatchIgnored = !1;
		}
		ignoreMatch() {
			this.isMatchIgnored = !0;
		}
	};
	function i(e) {
		return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;");
	}
	function a(e, ...t) {
		let n = Object.create(null);
		for (let t in e) n[t] = e[t];
		return t.forEach(function(e) {
			for (let t in e) n[t] = e[t];
		}), n;
	}
	var o = "</span>", s = (e) => !!e.scope, c = (e, { prefix: t }) => {
		if (e.startsWith("language:")) return e.replace("language:", "language-");
		if (e.includes(".")) {
			let n = e.split(".");
			return [`${t}${n.shift()}`, ...n.map((e, t) => `${e}${"_".repeat(t + 1)}`)].join(" ");
		}
		return `${t}${e}`;
	}, l = class {
		constructor(e, t) {
			this.buffer = "", this.classPrefix = t.classPrefix, e.walk(this);
		}
		addText(e) {
			this.buffer += i(e);
		}
		openNode(e) {
			if (!s(e)) return;
			let t = c(e.scope, { prefix: this.classPrefix });
			this.span(t);
		}
		closeNode(e) {
			s(e) && (this.buffer += o);
		}
		value() {
			return this.buffer;
		}
		span(e) {
			this.buffer += `<span class="${e}">`;
		}
	}, u = (e = {}) => {
		let t = { children: [] };
		return Object.assign(t, e), t;
	}, d = class e {
		constructor() {
			this.rootNode = u(), this.stack = [this.rootNode];
		}
		get top() {
			return this.stack[this.stack.length - 1];
		}
		get root() {
			return this.rootNode;
		}
		add(e) {
			this.top.children.push(e);
		}
		openNode(e) {
			let t = u({ scope: e });
			this.add(t), this.stack.push(t);
		}
		closeNode() {
			if (this.stack.length > 1) return this.stack.pop();
		}
		closeAllNodes() {
			for (; this.closeNode(););
		}
		toJSON() {
			return JSON.stringify(this.rootNode, null, 4);
		}
		walk(e) {
			return this.constructor._walk(e, this.rootNode);
		}
		static _walk(e, t) {
			return typeof t == "string" ? e.addText(t) : t.children && (e.openNode(t), t.children.forEach((t) => this._walk(e, t)), e.closeNode(t)), e;
		}
		static _collapse(t) {
			typeof t != "string" && t.children && (t.children.every((e) => typeof e == "string") ? t.children = [t.children.join("")] : t.children.forEach((t) => {
				e._collapse(t);
			}));
		}
	}, f = class extends d {
		constructor(e) {
			super(), this.options = e;
		}
		addText(e) {
			e !== "" && this.add(e);
		}
		startScope(e) {
			this.openNode(e);
		}
		endScope() {
			this.closeNode();
		}
		__addSublanguage(e, t) {
			let n = e.root;
			t && (n.scope = `language:${t}`), this.add(n);
		}
		toHTML() {
			return new l(this, this.options).value();
		}
		finalize() {
			return this.closeAllNodes(), !0;
		}
	};
	function p(e) {
		return e ? typeof e == "string" ? e : e.source : null;
	}
	function m(e) {
		return _("(?=", e, ")");
	}
	function h(e) {
		return _("(?:", e, ")*");
	}
	function g(e) {
		return _("(?:", e, ")?");
	}
	function _(...e) {
		return e.map((e) => p(e)).join("");
	}
	function v(e) {
		let t = e[e.length - 1];
		return typeof t == "object" && t.constructor === Object ? (e.splice(e.length - 1, 1), t) : {};
	}
	function y(...e) {
		return "(" + (v(e).capture ? "" : "?:") + e.map((e) => p(e)).join("|") + ")";
	}
	function b(e) {
		return RegExp(e.toString() + "|").exec("").length - 1;
	}
	function x(e, t) {
		let n = e && e.exec(t);
		return n && n.index === 0;
	}
	var S = /\[(?:[^\\\]]|\\.)*\]|\(\??|\\([1-9][0-9]*)|\\./;
	function C(e, { joinWith: t }) {
		let n = 0;
		return e.map((e) => {
			n += 1;
			let t = n, r = p(e), i = "";
			for (; r.length > 0;) {
				let e = S.exec(r);
				if (!e) {
					i += r;
					break;
				}
				i += r.substring(0, e.index), r = r.substring(e.index + e[0].length), e[0][0] === "\\" && e[1] ? i += "\\" + String(Number(e[1]) + t) : (i += e[0], e[0] === "(" && n++);
			}
			return i;
		}).map((e) => `(${e})`).join(t);
	}
	var w = /\b\B/, T = "[a-zA-Z]\\w*", E = "[a-zA-Z_]\\w*", D = "\\b\\d+(\\.\\d+)?", O = "(-?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)", k = "\\b(0b[01]+)", A = "!|!=|!==|%|%=|&|&&|&=|\\*|\\*=|\\+|\\+=|,|-|-=|/=|/|:|;|<<|<<=|<=|<|===|==|=|>>>=|>>=|>=|>>>|>>|>|\\?|\\[|\\{|\\(|\\^|\\^=|\\||\\|=|\\|\\||~", ee = (e = {}) => {
		let t = /^#![ ]*\//;
		return e.binary && (e.begin = _(t, /.*\b/, e.binary, /\b.*/)), a({
			scope: "meta",
			begin: t,
			end: /$/,
			relevance: 0,
			"on:begin": (e, t) => {
				e.index !== 0 && t.ignoreMatch();
			}
		}, e);
	}, j = {
		begin: "\\\\[\\s\\S]",
		relevance: 0
	}, M = {
		scope: "string",
		begin: "'",
		end: "'",
		illegal: "\\n",
		contains: [j]
	}, N = {
		scope: "string",
		begin: "\"",
		end: "\"",
		illegal: "\\n",
		contains: [j]
	}, P = { begin: /\b(a|an|the|are|I'm|isn't|don't|doesn't|won't|but|just|should|pretty|simply|enough|gonna|going|wtf|so|such|will|you|your|they|like|more)\b/ }, F = function(e, t, n = {}) {
		let r = a({
			scope: "comment",
			begin: e,
			end: t,
			contains: []
		}, n);
		r.contains.push({
			scope: "doctag",
			begin: "[ ]*(?=(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):)",
			end: /(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):/,
			excludeBegin: !0,
			relevance: 0
		});
		let i = y("I", "a", "is", "so", "us", "to", "at", "if", "in", "it", "on", /[A-Za-z]+['](d|ve|re|ll|t|s|n)/, /[A-Za-z]+[-][a-z]+/, /[A-Za-z][a-z]{2,}/);
		return r.contains.push({ begin: _(/[ ]+/, "(", i, /[.]?[:]?([.][ ]|[ ])/, "){3}") }), r;
	}, I = F("//", "$"), L = F("/\\*", "\\*/"), te = F("#", "$"), ne = /*#__PURE__*/ Object.freeze({
		__proto__: null,
		APOS_STRING_MODE: M,
		BACKSLASH_ESCAPE: j,
		BINARY_NUMBER_MODE: {
			scope: "number",
			begin: k,
			relevance: 0
		},
		BINARY_NUMBER_RE: k,
		COMMENT: F,
		C_BLOCK_COMMENT_MODE: L,
		C_LINE_COMMENT_MODE: I,
		C_NUMBER_MODE: {
			scope: "number",
			begin: O,
			relevance: 0
		},
		C_NUMBER_RE: O,
		END_SAME_AS_BEGIN: function(e) {
			return Object.assign(e, {
				"on:begin": (e, t) => {
					t.data._beginMatch = e[1];
				},
				"on:end": (e, t) => {
					t.data._beginMatch !== e[1] && t.ignoreMatch();
				}
			});
		},
		HASH_COMMENT_MODE: te,
		IDENT_RE: T,
		MATCH_NOTHING_RE: w,
		METHOD_GUARD: {
			begin: "\\.\\s*[a-zA-Z_]\\w*",
			relevance: 0
		},
		NUMBER_MODE: {
			scope: "number",
			begin: D,
			relevance: 0
		},
		NUMBER_RE: D,
		PHRASAL_WORDS_MODE: P,
		QUOTE_STRING_MODE: N,
		REGEXP_MODE: {
			scope: "regexp",
			begin: /\/(?=[^/\n]*\/)/,
			end: /\/[gimuy]*/,
			contains: [j, {
				begin: /\[/,
				end: /\]/,
				relevance: 0,
				contains: [j]
			}]
		},
		RE_STARTERS_RE: A,
		SHEBANG: ee,
		TITLE_MODE: {
			scope: "title",
			begin: T,
			relevance: 0
		},
		UNDERSCORE_IDENT_RE: E,
		UNDERSCORE_TITLE_MODE: {
			scope: "title",
			begin: E,
			relevance: 0
		}
	});
	function re(e, t) {
		e.input[e.index - 1] === "." && t.ignoreMatch();
	}
	function ie(e, t) {
		e.className !== void 0 && (e.scope = e.className, delete e.className);
	}
	function ae(e, t) {
		t && e.beginKeywords && (e.begin = "\\b(" + e.beginKeywords.split(" ").join("|") + ")(?!\\.)(?=\\b|\\s)", e.__beforeBegin = re, e.keywords = e.keywords || e.beginKeywords, delete e.beginKeywords, e.relevance === void 0 && (e.relevance = 0));
	}
	function oe(e, t) {
		Array.isArray(e.illegal) && (e.illegal = y(...e.illegal));
	}
	function R(e, t) {
		if (e.match) {
			if (e.begin || e.end) throw Error("begin & end are not supported with match");
			e.begin = e.match, delete e.match;
		}
	}
	function se(e, t) {
		e.relevance === void 0 && (e.relevance = 1);
	}
	var z = (e, t) => {
		if (!e.beforeMatch) return;
		if (e.starts) throw Error("beforeMatch cannot be used with starts");
		let n = Object.assign({}, e);
		Object.keys(e).forEach((t) => {
			delete e[t];
		}), e.keywords = n.keywords, e.begin = _(n.beforeMatch, m(n.begin)), e.starts = {
			relevance: 0,
			contains: [Object.assign(n, { endsParent: !0 })]
		}, e.relevance = 0, delete n.beforeMatch;
	}, ce = [
		"of",
		"and",
		"for",
		"in",
		"not",
		"or",
		"if",
		"then",
		"parent",
		"list",
		"value"
	], B = "keyword";
	function le(e, t, n = B) {
		let r = Object.create(null);
		return typeof e == "string" ? i(n, e.split(" ")) : Array.isArray(e) ? i(n, e) : Object.keys(e).forEach(function(n) {
			Object.assign(r, le(e[n], t, n));
		}), r;
		function i(e, n) {
			t && (n = n.map((e) => e.toLowerCase())), n.forEach(function(t) {
				let n = t.split("|");
				r[n[0]] = [e, V(n[0], n[1])];
			});
		}
	}
	function V(e, t) {
		return t ? Number(t) : +!H(e);
	}
	function H(e) {
		return ce.includes(e.toLowerCase());
	}
	var U = {}, ue = (e) => {
		console.error(e);
	}, de = (e, ...t) => {
		console.log(`WARN: ${e}`, ...t);
	}, W = (e, t) => {
		U[`${e}/${t}`] || (console.log(`Deprecated as of ${e}. ${t}`), U[`${e}/${t}`] = !0);
	}, G = /* @__PURE__ */ Error();
	function fe(e, t, { key: n }) {
		let r = 0, i = e[n], a = {}, o = {};
		for (let e = 1; e <= t.length; e++) o[e + r] = i[e], a[e + r] = !0, r += b(t[e - 1]);
		e[n] = o, e[n]._emit = a, e[n]._multi = !0;
	}
	function pe(e) {
		if (Array.isArray(e.begin)) {
			if (e.skip || e.excludeBegin || e.returnBegin) throw ue("skip, excludeBegin, returnBegin not compatible with beginScope: {}"), G;
			if (typeof e.beginScope != "object" || e.beginScope === null) throw ue("beginScope must be object"), G;
			fe(e, e.begin, { key: "beginScope" }), e.begin = C(e.begin, { joinWith: "" });
		}
	}
	function K(e) {
		if (Array.isArray(e.end)) {
			if (e.skip || e.excludeEnd || e.returnEnd) throw ue("skip, excludeEnd, returnEnd not compatible with endScope: {}"), G;
			if (typeof e.endScope != "object" || e.endScope === null) throw ue("endScope must be object"), G;
			fe(e, e.end, { key: "endScope" }), e.end = C(e.end, { joinWith: "" });
		}
	}
	function me(e) {
		e.scope && typeof e.scope == "object" && e.scope !== null && (e.beginScope = e.scope, delete e.scope);
	}
	function q(e) {
		me(e), typeof e.beginScope == "string" && (e.beginScope = { _wrap: e.beginScope }), typeof e.endScope == "string" && (e.endScope = { _wrap: e.endScope }), pe(e), K(e);
	}
	function he(e) {
		function t(t, n) {
			return new RegExp(p(t), "m" + (e.case_insensitive ? "i" : "") + (e.unicodeRegex ? "u" : "") + (n ? "g" : ""));
		}
		class n {
			constructor() {
				this.matchIndexes = {}, this.regexes = [], this.matchAt = 1, this.position = 0;
			}
			addRule(e, t) {
				t.position = this.position++, this.matchIndexes[this.matchAt] = t, this.regexes.push([t, e]), this.matchAt += b(e) + 1;
			}
			compile() {
				this.regexes.length === 0 && (this.exec = () => null);
				let e = this.regexes.map((e) => e[1]);
				this.matcherRe = t(C(e, { joinWith: "|" }), !0), this.lastIndex = 0;
			}
			exec(e) {
				this.matcherRe.lastIndex = this.lastIndex;
				let t = this.matcherRe.exec(e);
				if (!t) return null;
				let n = t.findIndex((e, t) => t > 0 && e !== void 0), r = this.matchIndexes[n];
				return t.splice(0, n), Object.assign(t, r);
			}
		}
		class r {
			constructor() {
				this.rules = [], this.multiRegexes = [], this.count = 0, this.lastIndex = 0, this.regexIndex = 0;
			}
			getMatcher(e) {
				if (this.multiRegexes[e]) return this.multiRegexes[e];
				let t = new n();
				return this.rules.slice(e).forEach(([e, n]) => t.addRule(e, n)), t.compile(), this.multiRegexes[e] = t, t;
			}
			resumingScanAtSamePosition() {
				return this.regexIndex !== 0;
			}
			considerAll() {
				this.regexIndex = 0;
			}
			addRule(e, t) {
				this.rules.push([e, t]), t.type === "begin" && this.count++;
			}
			exec(e) {
				let t = this.getMatcher(this.regexIndex);
				t.lastIndex = this.lastIndex;
				let n = t.exec(e);
				if (this.resumingScanAtSamePosition() && !(n && n.index === this.lastIndex)) {
					let t = this.getMatcher(0);
					t.lastIndex = this.lastIndex + 1, n = t.exec(e);
				}
				return n && (this.regexIndex += n.position + 1, this.regexIndex === this.count && this.considerAll()), n;
			}
		}
		function i(e) {
			let t = new r();
			return e.contains.forEach((e) => t.addRule(e.begin, {
				rule: e,
				type: "begin"
			})), e.terminatorEnd && t.addRule(e.terminatorEnd, { type: "end" }), e.illegal && t.addRule(e.illegal, { type: "illegal" }), t;
		}
		function o(n, r) {
			let a = n;
			if (n.isCompiled) return a;
			[
				ie,
				R,
				q,
				z
			].forEach((e) => e(n, r)), e.compilerExtensions.forEach((e) => e(n, r)), n.__beforeBegin = null, [
				ae,
				oe,
				se
			].forEach((e) => e(n, r)), n.isCompiled = !0;
			let s = null;
			return typeof n.keywords == "object" && n.keywords.$pattern && (n.keywords = Object.assign({}, n.keywords), s = n.keywords.$pattern, delete n.keywords.$pattern), s ||= /\w+/, n.keywords &&= le(n.keywords, e.case_insensitive), a.keywordPatternRe = t(s, !0), r && (n.begin ||= /\B|\b/, a.beginRe = t(a.begin), !n.end && !n.endsWithParent && (n.end = /\B|\b/), n.end && (a.endRe = t(a.end)), a.terminatorEnd = p(a.end) || "", n.endsWithParent && r.terminatorEnd && (a.terminatorEnd += (n.end ? "|" : "") + r.terminatorEnd)), n.illegal && (a.illegalRe = t(n.illegal)), n.contains ||= [], n.contains = [].concat(...n.contains.map(function(e) {
				return ge(e === "self" ? n : e);
			})), n.contains.forEach(function(e) {
				o(e, a);
			}), n.starts && o(n.starts, r), a.matcher = i(a), a;
		}
		if (e.compilerExtensions ||= [], e.contains && e.contains.includes("self")) throw Error("ERR: contains `self` is not supported at the top-level of a language.  See documentation.");
		return e.classNameAliases = a(e.classNameAliases || {}), o(e);
	}
	function J(e) {
		return e ? e.endsWithParent || J(e.starts) : !1;
	}
	function ge(e) {
		return e.variants && !e.cachedVariants && (e.cachedVariants = e.variants.map(function(t) {
			return a(e, { variants: null }, t);
		})), e.cachedVariants ? e.cachedVariants : J(e) ? a(e, { starts: e.starts ? a(e.starts) : null }) : Object.isFrozen(e) ? a(e) : e;
	}
	var _e = "11.11.2", Y = class extends Error {
		constructor(e, t) {
			super(e), this.name = "HTMLInjectionError", this.html = t;
		}
	}, ve = i, ye = a, be = Symbol("nomatch"), xe = 7, Se = function(e) {
		let t = Object.create(null), i = Object.create(null), a = [], o = !0, s = "Could not find the language '{}', did you forget to load/include a language module?", c = {
			disableAutodetect: !0,
			name: "Plain text",
			contains: []
		}, l = {
			ignoreUnescapedHTML: !1,
			throwUnescapedHTML: !1,
			noHighlightRe: /^(no-?highlight)$/i,
			languageDetectRe: /\blang(?:uage)?-([\w-]+)\b/i,
			classPrefix: "hljs-",
			cssSelector: "pre code",
			languages: null,
			__emitter: f
		};
		function u(e) {
			return l.noHighlightRe.test(e);
		}
		function d(e) {
			let t = e.className + " ";
			t += e.parentNode ? e.parentNode.className : "";
			let n = l.languageDetectRe.exec(t);
			if (n) {
				let t = M(n[1]);
				return t || (de(s.replace("{}", n[1])), de("Falling back to no-highlight mode for this block.", e)), t ? n[1] : "no-highlight";
			}
			return t.split(/\s+/).find((e) => u(e) || M(e));
		}
		function p(e, t, n) {
			let r = "", i = "";
			typeof t == "object" ? (r = e, n = t.ignoreIllegals, i = t.language) : (W("10.7.0", "highlight(lang, code, ...args) has been deprecated."), W("10.7.0", "Please use highlight(code, options) instead.\nhttps://github.com/highlightjs/highlight.js/issues/2277"), i = e, r = t), n === void 0 && (n = !0);
			let a = {
				code: r,
				language: i
			};
			te("before:highlight", a);
			let o = a.result ? a.result : v(a.language, a.code, n);
			return o.code = a.code, te("after:highlight", o), o;
		}
		function v(e, n, i, a) {
			let c = Object.create(null);
			function u(e, t) {
				return e.keywords[t];
			}
			function d() {
				if (!A.keywords) {
					j.addText(N);
					return;
				}
				let e = 0;
				A.keywordPatternRe.lastIndex = 0;
				let t = A.keywordPatternRe.exec(N), n = "";
				for (; t;) {
					n += N.substring(e, t.index);
					let r = D.case_insensitive ? t[0].toLowerCase() : t[0], i = u(A, r);
					if (i) {
						let [e, a] = i;
						if (j.addText(n), n = "", c[r] = (c[r] || 0) + 1, c[r] <= xe && (P += a), e.startsWith("_")) n += t[0];
						else {
							let n = D.classNameAliases[e] || e;
							m(t[0], n);
						}
					} else n += t[0];
					e = A.keywordPatternRe.lastIndex, t = A.keywordPatternRe.exec(N);
				}
				n += N.substring(e), j.addText(n);
			}
			function f() {
				if (N === "") return;
				let e = null;
				if (typeof A.subLanguage == "string") {
					if (!t[A.subLanguage]) {
						j.addText(N);
						return;
					}
					e = v(A.subLanguage, N, !0, ee[A.subLanguage]), ee[A.subLanguage] = e._top;
				} else e = S(N, A.subLanguage.length ? A.subLanguage : null);
				A.relevance > 0 && (P += e.relevance), j.__addSublanguage(e._emitter, e.language);
			}
			function p() {
				A.subLanguage == null ? d() : f(), N = "";
			}
			function m(e, t) {
				e !== "" && (j.startScope(t), j.addText(e), j.endScope());
			}
			function h(e, t) {
				let n = 1, r = t.length - 1;
				for (; n <= r;) {
					if (!e._emit[n]) {
						n++;
						continue;
					}
					let r = D.classNameAliases[e[n]] || e[n], i = t[n];
					r ? m(i, r) : (N = i, d(), N = ""), n++;
				}
			}
			function g(e, t) {
				return e.scope && typeof e.scope == "string" && j.openNode(D.classNameAliases[e.scope] || e.scope), e.beginScope && (e.beginScope._wrap ? (m(N, D.classNameAliases[e.beginScope._wrap] || e.beginScope._wrap), N = "") : e.beginScope._multi && (h(e.beginScope, t), N = "")), A = Object.create(e, { parent: { value: A } }), A;
			}
			function _(e, t, n) {
				let i = x(e.endRe, n);
				if (i) {
					if (e["on:end"]) {
						let n = new r(e);
						e["on:end"](t, n), n.isMatchIgnored && (i = !1);
					}
					if (i) {
						for (; e.endsParent && e.parent;) e = e.parent;
						return e;
					}
				}
				if (e.endsWithParent) return _(e.parent, t, n);
			}
			function y(e) {
				return A.matcher.regexIndex === 0 ? (N += e[0], 1) : (L = !0, 0);
			}
			function b(e) {
				let t = e[0], n = e.rule, i = new r(n), a = [n.__beforeBegin, n["on:begin"]];
				for (let n of a) if (n && (n(e, i), i.isMatchIgnored)) return y(t);
				return n.skip ? N += t : (n.excludeBegin && (N += t), p(), !n.returnBegin && !n.excludeBegin && (N = t)), g(n, e), n.returnBegin ? 0 : t.length;
			}
			function C(e) {
				let t = e[0], r = n.substring(e.index), i = _(A, e, r);
				if (!i) return be;
				let a = A;
				A.endScope && A.endScope._wrap ? (p(), m(t, A.endScope._wrap)) : A.endScope && A.endScope._multi ? (p(), h(A.endScope, e)) : a.skip ? N += t : (a.returnEnd || a.excludeEnd || (N += t), p(), a.excludeEnd && (N = t));
				do
					A.scope && j.closeNode(), !A.skip && !A.subLanguage && (P += A.relevance), A = A.parent;
				while (A !== i.parent);
				return i.starts && g(i.starts, e), a.returnEnd ? 0 : t.length;
			}
			function w() {
				let e = [];
				for (let t = A; t !== D; t = t.parent) t.scope && e.unshift(t.scope);
				e.forEach((e) => j.openNode(e));
			}
			let T = {};
			function E(t, r) {
				let a = r && r[0];
				if (N += t, a == null) return p(), 0;
				if (T.type === "begin" && r.type === "end" && T.index === r.index && a === "") {
					if (N += n.slice(r.index, r.index + 1), !o) {
						let t = /* @__PURE__ */ Error(`0 width match regex (${e})`);
						throw t.languageName = e, t.badRule = T.rule, t;
					}
					return 1;
				}
				if (T = r, r.type === "begin") return b(r);
				if (r.type === "illegal" && !i) {
					let e = /* @__PURE__ */ Error("Illegal lexeme \"" + a + "\" for mode \"" + (A.scope || "<unnamed>") + "\"");
					throw e.mode = A, e;
				}
				if (r.type === "end") {
					let e = C(r);
					if (e !== be) return e;
				}
				if (r.type === "illegal" && a === "") return r.index === n.length || (N += "\n"), 1;
				if (I > 1e5 && I > r.index * 3) throw /* @__PURE__ */ Error("potential infinite loop, way more iterations than matches");
				return N += a, a.length;
			}
			let D = M(e);
			if (!D) throw ue(s.replace("{}", e)), Error("Unknown language: \"" + e + "\"");
			let O = he(D), k = "", A = a || O, ee = {}, j = new l.__emitter(l);
			w();
			let N = "", P = 0, F = 0, I = 0, L = !1;
			try {
				if (D.__emitTokens) D.__emitTokens(n, j);
				else {
					for (A.matcher.considerAll();;) {
						I++, L ? L = !1 : A.matcher.considerAll(), A.matcher.lastIndex = F;
						let e = A.matcher.exec(n);
						if (!e) break;
						let t = E(n.substring(F, e.index), e);
						F = e.index + t;
					}
					E(n.substring(F));
				}
				return j.finalize(), k = j.toHTML(), {
					language: e,
					value: k,
					relevance: P,
					illegal: !1,
					_emitter: j,
					_top: A
				};
			} catch (t) {
				if (t.message && t.message.includes("Illegal")) return {
					language: e,
					value: ve(n),
					illegal: !0,
					relevance: 0,
					_illegalBy: {
						message: t.message,
						index: F,
						context: n.slice(F - 100, F + 100),
						mode: t.mode,
						resultSoFar: k
					},
					_emitter: j
				};
				if (o) return {
					language: e,
					value: ve(n),
					illegal: !1,
					relevance: 0,
					errorRaised: t,
					_emitter: j,
					_top: A
				};
				throw t;
			}
		}
		function b(e) {
			let t = {
				value: ve(e),
				illegal: !1,
				relevance: 0,
				_top: c,
				_emitter: new l.__emitter(l)
			};
			return t._emitter.addText(e), t;
		}
		function S(e, n) {
			n = n || l.languages || Object.keys(t);
			let r = b(e), i = n.filter(M).filter(P).map((t) => v(t, e, !1));
			i.unshift(r);
			let [a, o] = i.sort((e, t) => {
				if (e.relevance !== t.relevance) return t.relevance - e.relevance;
				if (e.language && t.language) {
					if (M(e.language).supersetOf === t.language) return 1;
					if (M(t.language).supersetOf === e.language) return -1;
				}
				return 0;
			}), s = a;
			return s.secondBest = o, s;
		}
		function C(e, t, n) {
			let r = t && i[t] || n;
			e.classList.add("hljs"), e.classList.add(`language-${r}`);
		}
		function w(e) {
			let t = null, n = d(e);
			if (u(n)) return;
			if (te("before:highlightElement", {
				el: e,
				language: n
			}), e.dataset.highlighted) {
				console.log("Element previously highlighted. To highlight again, first unset `dataset.highlighted`.", e);
				return;
			}
			if (e.children.length > 0 && (l.ignoreUnescapedHTML || (console.warn("One of your code blocks includes unescaped HTML. This is a potentially serious security risk."), console.warn("https://github.com/highlightjs/highlight.js/wiki/security"), console.warn("The element with unescaped HTML:"), console.warn(e)), l.throwUnescapedHTML)) throw new Y("One of your code blocks includes unescaped HTML.", e.innerHTML);
			t = e;
			let r = t.textContent, i = n ? p(r, {
				language: n,
				ignoreIllegals: !0
			}) : S(r);
			e.innerHTML = i.value, e.dataset.highlighted = "yes", C(e, n, i.language), e.result = {
				language: i.language,
				re: i.relevance,
				relevance: i.relevance
			}, i.secondBest && (e.secondBest = {
				language: i.secondBest.language,
				relevance: i.secondBest.relevance
			}), te("after:highlightElement", {
				el: e,
				result: i,
				text: r
			});
		}
		function T(e) {
			l = ye(l, e);
		}
		let E = () => {
			k(), W("10.6.0", "initHighlighting() deprecated.  Use highlightAll() now.");
		};
		function D() {
			k(), W("10.6.0", "initHighlightingOnLoad() deprecated.  Use highlightAll() now.");
		}
		let O = !1;
		function k() {
			function e() {
				k();
			}
			document.readyState === "loading" ? (O || window.addEventListener("DOMContentLoaded", e, !1), O = !0) : document.querySelectorAll(l.cssSelector).forEach(w);
		}
		function A(n, r) {
			let i = null;
			try {
				i = r(e);
			} catch (e) {
				if (ue("Language definition for '{}' could not be registered.".replace("{}", n)), o) ue(e);
				else throw e;
				i = c;
			}
			i.name || (i.name = n), t[n] = i, i.rawDefinition = r.bind(null, e), i.aliases && N(i.aliases, { languageName: n });
		}
		function ee(e) {
			delete t[e];
			for (let t of Object.keys(i)) i[t] === e && delete i[t];
		}
		function j() {
			return Object.keys(t);
		}
		function M(e) {
			return e = (e || "").toLowerCase(), t[e] || t[i[e]];
		}
		function N(e, { languageName: t }) {
			typeof e == "string" && (e = [e]), e.forEach((e) => {
				i[e.toLowerCase()] = t;
			});
		}
		function P(e) {
			let t = M(e);
			return t && !t.disableAutodetect;
		}
		function F(e) {
			e["before:highlightBlock"] && !e["before:highlightElement"] && (e["before:highlightElement"] = (t) => {
				e["before:highlightBlock"](Object.assign({ block: t.el }, t));
			}), e["after:highlightBlock"] && !e["after:highlightElement"] && (e["after:highlightElement"] = (t) => {
				e["after:highlightBlock"](Object.assign({ block: t.el }, t));
			});
		}
		function I(e) {
			F(e), a.push(e);
		}
		function L(e) {
			let t = a.indexOf(e);
			t !== -1 && a.splice(t, 1);
		}
		function te(e, t) {
			let n = e;
			a.forEach(function(e) {
				e[n] && e[n](t);
			});
		}
		function re(e) {
			return W("10.7.0", "highlightBlock will be removed entirely in v12.0"), W("10.7.0", "Please use highlightElement now."), w(e);
		}
		Object.assign(e, {
			highlight: p,
			highlightAuto: S,
			highlightAll: k,
			highlightElement: w,
			highlightBlock: re,
			configure: T,
			initHighlighting: E,
			initHighlightingOnLoad: D,
			registerLanguage: A,
			unregisterLanguage: ee,
			listLanguages: j,
			getLanguage: M,
			registerAliases: N,
			autoDetection: P,
			inherit: ye,
			addPlugin: I,
			removePlugin: L
		}), e.debugMode = function() {
			o = !1;
		}, e.safeMode = function() {
			o = !0;
		}, e.versionString = _e, e.regex = {
			concat: _,
			lookahead: m,
			either: y,
			optional: g,
			anyNumberOfTimes: h
		};
		for (let e in ne) typeof ne[e] == "object" && n(ne[e]);
		return Object.assign(e, ne), e;
	}, Ce = Se({});
	Ce.newInstance = () => Se({}), t.exports = Ce, Ce.HighlightJS = Ce, Ce.default = Ce;
})))())).default, qn = {}, Jn = "hljs-";
function Yn(e) {
	let t = Kn.newInstance();
	return e && a(e), {
		highlight: n,
		highlightAuto: r,
		listLanguages: i,
		register: a,
		registerAlias: o,
		registered: s
	};
	function n(e, n, r) {
		let i = r || qn, a = typeof i.prefix == "string" ? i.prefix : Jn;
		if (!t.getLanguage(e)) throw Error("Unknown language: `" + e + "` is not registered");
		t.configure({
			__emitter: Xn,
			classPrefix: a
		});
		let o = t.highlight(n, {
			ignoreIllegals: !0,
			language: e
		});
		/* c8 ignore next 5 */
		if (o.errorRaised) throw Error("Could not highlight with `Highlight.js`", { cause: o.errorRaised });
		let s = o._emitter.root, c = s.data;
		return c.language = o.language, c.relevance = o.relevance, s;
	}
	function r(e, r) {
		let a = (r || qn).subset || i(), o = -1, s = 0, c;
		for (; ++o < a.length;) {
			let i = a[o];
			if (!t.getLanguage(i)) continue;
			let l = n(i, e, r);
			l.data && l.data.relevance !== void 0 && l.data.relevance > s && (s = l.data.relevance, c = l);
		}
		return c || {
			type: "root",
			children: [],
			data: {
				language: void 0,
				relevance: s
			}
		};
	}
	function i() {
		return t.listLanguages();
	}
	function a(e, n) {
		if (typeof e == "string") t.registerLanguage(e, n);
		else {
			let n;
			for (n in e) Object.hasOwn(e, n) && t.registerLanguage(n, e[n]);
		}
	}
	function o(e, n) {
		if (typeof e == "string") t.registerAliases(typeof n == "string" ? n : [...n], { languageName: e });
		else {
			let n;
			for (n in e) if (Object.hasOwn(e, n)) {
				let r = e[n];
				t.registerAliases(typeof r == "string" ? r : [...r], { languageName: n });
			}
		}
	}
	function s(e) {
		return !!t.getLanguage(e);
	}
}
var Xn = class {
	constructor(e) {
		this.options = e, this.root = {
			type: "root",
			children: [],
			data: {
				language: void 0,
				relevance: 0
			}
		}, this.stack = [this.root];
	}
	addText(e) {
		if (e === "") return;
		let t = this.stack[this.stack.length - 1], n = t.children[t.children.length - 1];
		n && n.type === "text" ? n.value += e : t.children.push({
			type: "text",
			value: e
		});
	}
	startScope(e) {
		this.openNode(String(e));
	}
	endScope() {
		this.closeNode();
	}
	__addSublanguage(e, t) {
		let n = this.stack[this.stack.length - 1], r = e.root.children;
		t ? n.children.push({
			type: "element",
			tagName: "span",
			properties: { className: [t] },
			children: r
		}) : n.children.push(...r);
	}
	openNode(e) {
		let t = this, n = e.split(".").map(function(e, n) {
			return n ? e + "_".repeat(n) : t.options.classPrefix + e;
		}), r = this.stack[this.stack.length - 1], i = {
			type: "element",
			tagName: "span",
			properties: { className: n },
			children: []
		};
		r.children.push(i), this.stack.push(i);
	}
	closeNode() {
		this.stack.pop();
	}
	finalize() {}
	toHTML() {
		return "";
	}
}, Zn = (e) => ({
	name: "Cattca",
	subLanguage: "markdown",
	contains: [e.C_BLOCK_COMMENT_MODE, {
		begin: /<\//,
		end: /\/>/,
		relevance: 10,
		keywords: {
			keyword: "let set apply label goto if exit input case text log random",
			literal: "true false null undefined"
		},
		contains: [
			e.C_BLOCK_COMMENT_MODE,
			e.QUOTE_STRING_MODE,
			e.APOS_STRING_MODE,
			e.C_NUMBER_MODE,
			{
				scope: "operator",
				match: /->|===?|!==?|<=?|>=?|&&|\|\||[+*/%!-]/
			}
		]
	}]
}), Qn = (e) => ({
	name: "Mermaid",
	aliases: ["mmd"],
	keywords: {
		keyword: "graph flowchart sequenceDiagram classDiagram stateDiagram stateDiagram-v2 erDiagram gantt pie journey gitGraph mindmap timeline quadrantChart requirementDiagram sankey-beta xychart-beta block-beta packet-beta architecture-beta subgraph end direction participant actor activate deactivate loop alt else opt par and critical break rect Note note over left right of as autonumber title accTitle accDescr section class classDef style linkStyle click callback href state fork join choice dateFormat axisFormat excludes todayMarker milestone done active after",
		literal: "TD TB BT LR RL true false"
	},
	contains: [
		{
			scope: "meta",
			begin: /%%\{/,
			end: /\}%%/
		},
		e.COMMENT(/%%/, /$/),
		e.QUOTE_STRING_MODE,
		e.APOS_STRING_MODE,
		{
			scope: "string",
			begin: /\[/,
			end: /\]/,
			contains: [e.QUOTE_STRING_MODE]
		},
		{
			scope: "operator",
			match: /(?:<\|?|[ox])?[-=.]{1,3}(?:>|\|>|[ox])?|:::/
		},
		e.C_NUMBER_MODE
	]
}), $n = (e) => ({
	name: "Vue",
	disableAutodetect: !0,
	subLanguage: "xml",
	contains: [
		e.COMMENT(/<!--/, /-->/),
		{
			begin: /<script\b(?=[^>]*\blang\s*=\s*["'](?:ts|typescript)["'])[^>]*>/,
			end: /<\/script\s*>/,
			excludeBegin: !0,
			excludeEnd: !0,
			subLanguage: "typescript"
		},
		{
			begin: /<script\b[^>]*>/,
			end: /<\/script\s*>/,
			excludeBegin: !0,
			excludeEnd: !0,
			subLanguage: "javascript"
		},
		{
			begin: /<style\b(?=[^>]*\blang\s*=\s*["']scss["'])[^>]*>/,
			end: /<\/style\s*>/,
			excludeBegin: !0,
			excludeEnd: !0,
			subLanguage: "scss"
		},
		{
			begin: /<style\b[^>]*>/,
			end: /<\/style\s*>/,
			excludeBegin: !0,
			excludeEnd: !0,
			subLanguage: "css"
		},
		{
			begin: /\{\{/,
			end: /\}\}/,
			excludeBegin: !0,
			excludeEnd: !0,
			subLanguage: "javascript"
		}
	]
}), er = 2e4, tr = 100, nr = 2e3, rr = Yn(Gn);
rr.register({
	latex: Be,
	django: Re,
	dockerfile: ze,
	cattca: Zn,
	mermaid: Qn,
	vue: $n
});
var ir = [
	"javascript",
	"typescript",
	"python",
	"bash",
	"json",
	"yaml",
	"sql",
	"xml",
	"css",
	"java",
	"cpp",
	"rust",
	"go",
	"latex",
	"dockerfile",
	"mermaid",
	"cattca",
	"django"
], ar = {
	js: "javascript",
	jsx: "javascript",
	mjs: "javascript",
	cjs: "javascript",
	ts: "typescript",
	tsx: "typescript",
	py: "python",
	sh: "bash",
	shell: "bash",
	zsh: "bash",
	html: "xml",
	htm: "xml",
	svg: "xml",
	xml: "xml",
	json: "json",
	jsonc: "json",
	json5: "json",
	css: "css",
	md: "markdown",
	markdown: "markdown",
	yml: "yaml",
	yaml: "yaml",
	tex: "latex",
	jinja: "django",
	jinja2: "django",
	j2: "django",
	docker: "dockerfile",
	text: "plaintext",
	txt: "plaintext",
	plain: "plaintext",
	nohighlight: "plaintext"
};
function or(e) {
	if (e === void 0) return null;
	let t = e.trim().toLowerCase();
	return t.startsWith("language-") && (t = t.slice(9)), t === "" ? null : t;
}
function sr(e) {
	let t = Object.hasOwn(ar, e) ? ar[e] : void 0;
	return t !== void 0 && rr.registered(t) ? t : rr.registered(e) ? e : null;
}
function cr(e) {
	let t = e.className, n = (Array.isArray(t) ? t : typeof t == "string" ? [t] : []).filter((e) => typeof e == "string" && /^[A-Za-z0-9_-]+$/.test(e));
	return n.length > 0 ? n.join(" ") : void 0;
}
function lr(e) {
	let t = "", n = 0, r = [...e].reverse();
	for (; r.length > 0;) {
		let e = r.pop();
		if (n += 1, n > er) return null;
		if (e.type === "text") t += e.value;
		else {
			if (e.type !== "element" || e.tagName !== "span") return null;
			for (let t = e.children.length - 1; t >= 0; --t) r.push(e.children[t]);
		}
	}
	return t;
}
function ur(e, t = 0) {
	if (t > tr) throw Error("Code token tree is nested too deeply.");
	return e.map((e, n) => e.type === "text" ? e.value : e.type === "element" && e.tagName === "span" ? /* @__PURE__ */ W("span", {
		className: cr(e.properties),
		children: ur(e.children, t + 1)
	}, n) : null);
}
function dr(e, t) {
	let n = or(t);
	if (e === "" || e.length > 2e4) return {
		nodes: null,
		highlighted: !1
	};
	let r = n === null ? null : sr(n);
	if (n !== null && (r === null || r === "plaintext")) return {
		nodes: null,
		highlighted: !1
	};
	try {
		let t = r === null ? rr.highlightAuto(e, { subset: ir }) : rr.highlight(r, e);
		if (r === null && (!t.data?.language || (t.data.relevance ?? 0) < 2) || lr(t.children) !== e) return {
			nodes: null,
			highlighted: !1
		};
		let n = ur(t.children);
		return n.length === 0 && e !== "" ? {
			nodes: null,
			highlighted: !1
		} : {
			nodes: n,
			highlighted: !0,
			language: r ?? t.data?.language
		};
	} catch {
		return {
			nodes: null,
			highlighted: !1
		};
	}
}
function fr(e) {
	if (typeof document > "u" || document.body === null) return !1;
	let t = document.activeElement, n = typeof window > "u" ? null : window.getSelection(), r = [];
	if (n !== null) for (let e = 0; e < n.rangeCount; e += 1) r.push(n.getRangeAt(e).cloneRange());
	let i = document.createElement("textarea");
	i.value = e, i.setAttribute("readonly", ""), i.setAttribute("aria-hidden", "true"), i.tabIndex = -1, i.style.position = "fixed", i.style.top = "-1000px", i.style.left = "-1000px", i.style.opacity = "0", document.body.appendChild(i);
	let a = !1;
	try {
		i.focus({ preventScroll: !0 }), i.select(), i.setSelectionRange(0, i.value.length), a = typeof document.execCommand == "function" && document.execCommand("copy");
	} catch {
		a = !1;
	} finally {
		if (i.remove(), t !== null && typeof t.focus == "function") try {
			t.focus({ preventScroll: !0 });
		} catch {}
		if (n !== null) {
			n.removeAllRanges();
			for (let e of r) n.addRange(e);
		}
	}
	return a;
}
async function pr(e) {
	if (typeof navigator < "u" && navigator.clipboard && typeof navigator.clipboard.writeText == "function") try {
		return await navigator.clipboard.writeText(e), !0;
	} catch {
		return fr(e);
	}
	return fr(e);
}
var mr = /^[a-z0-9][a-z0-9+#._-]*$/;
function hr({ value: e, language: t, mode: n, htmlProps: r }) {
	let i = Me(), a = V(() => dr(e, t), [e, t]), [o, s] = U({
		value: e,
		state: "idle"
	}), c = H(e), l = H(null), u = H(!0);
	c.current = e;
	let d = o.value === e ? o.state : "idle";
	B(() => (u.current = !0, () => {
		u.current = !1, l.current !== null && (clearTimeout(l.current), l.current = null);
	}), []), B(() => {
		l.current !== null && (clearTimeout(l.current), l.current = null), s({
			value: e,
			state: "idle"
		});
	}, [e]);
	let f = z(async () => {
		let t = e;
		l.current !== null && (clearTimeout(l.current), l.current = null);
		let n = await pr(t);
		u.current && c.current === t && (s({
			value: t,
			state: n ? "success" : "error"
		}), l.current = setTimeout(() => {
			l.current = null, u.current && s((e) => e.value === t ? {
				value: t,
				state: "idle"
			} : e);
		}, nr));
	}, [e]), p = or(t), m = t !== void 0 && t.trim() !== "" ? t.trim() : a.language ?? i("Text", "文本"), h = p ?? a.language, g = [a.highlighted ? "hljs" : "", h && mr.test(h) ? `language-${h}` : ""].filter((e) => e !== "").join(" ") || void 0, _ = d === "success" ? i("Copied", "已复制") : d === "error" ? i("Copy failed", "复制失败") : "";
	return /* @__PURE__ */ G("div", {
		className: "md-code-block",
		"data-code-mode": n,
		children: [/* @__PURE__ */ G("div", {
			className: "md-code-block-toolbar",
			children: [/* @__PURE__ */ W("span", {
				className: "md-code-block-language",
				children: m
			}), n === "interactive" && /* @__PURE__ */ G(de, { children: [/* @__PURE__ */ W("span", {
				className: "md-code-block-feedback",
				"data-state": d,
				role: "status",
				"aria-live": "polite",
				children: /* @__PURE__ */ W("span", {
					className: "md-code-block-feedback-text",
					children: _
				}, d)
			}), /* @__PURE__ */ G("button", {
				type: "button",
				className: "md-code-block-copy",
				"data-rmd-appearance": "custom",
				"data-copy-state": d,
				"aria-label": i("Copy code", "复制代码"),
				onClick: () => {
					f();
				},
				children: [/* @__PURE__ */ W("span", {
					className: "md-code-block-copy-icon",
					"aria-hidden": "true",
					children: d === "success" ? /* @__PURE__ */ W("svg", {
						viewBox: "0 0 24 24",
						width: "15",
						height: "15",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.75",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						focusable: "false",
						children: /* @__PURE__ */ W("path", { d: "M20 6 9 17l-5-5" })
					}) : d === "error" ? /* @__PURE__ */ G("svg", {
						viewBox: "0 0 24 24",
						width: "15",
						height: "15",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.75",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						focusable: "false",
						children: [
							/* @__PURE__ */ W("circle", {
								cx: "12",
								cy: "12",
								r: "9"
							}),
							/* @__PURE__ */ W("path", { d: "M12 8v5" }),
							/* @__PURE__ */ W("path", { d: "M12 16.5h.01" })
						]
					}) : /* @__PURE__ */ G("svg", {
						viewBox: "0 0 24 24",
						width: "15",
						height: "15",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.75",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						focusable: "false",
						children: [/* @__PURE__ */ W("rect", {
							x: "9",
							y: "9",
							width: "11",
							height: "11",
							rx: "2"
						}), /* @__PURE__ */ W("path", { d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" })]
					})
				}, d), i("Copy", "复制")]
			})] })]
		}), /* @__PURE__ */ W("pre", {
			className: "md-code",
			...r,
			children: /* @__PURE__ */ W("code", {
				className: g,
				children: a.nodes ?? e
			})
		})]
	});
}
// src/local/widgets/image-view.tsx
function gr({ src: e, alt: t, title: n, mode: r, rootRef: i, imageProps: a }) {
	let o = Me(), s = H(null), c = H(null), l = H(!1), u = H(e), [d, f] = U(!1), [p, m] = U(!1), [h, g] = U(null), [_, v] = U(null), y = z(() => {
		let e = s.current;
		if (e && e.isConnected) try {
			e.focus({ preventScroll: !0 });
		} catch {
			e.focus();
		}
	}, []), b = z(() => {
		l.current && (l.current = !1, m(!1), y());
	}, [y]), x = z(() => {
		let e = c.current;
		if (e?.open) try {
			e.close();
		} catch {}
		b();
	}, [b]), S = z(() => {
		let t = i.current;
		t && !l.current && (v(e), g(t), l.current = !0, m(!0));
	}, [i, e]);
	B(() => {
		if (r !== "interactive") {
			f(!1), x();
			return;
		}
		let e = s.current;
		f(e !== null && e.closest("a") === null);
	}, [
		r,
		e,
		x
	]), B(() => {
		u.current !== e && (u.current = e, l.current && x());
	}, [e, x]), B(() => {
		if (!p) return;
		let e = c.current;
		if (e && !e.open) {
			if (typeof e.showModal != "function") b();
			else try {
				e.showModal();
			} catch {
				b();
			}
		}
	}, [p, b]);
	let C = d ? {
		role: "button",
		tabIndex: 0,
		"aria-haspopup": "dialog",
		"aria-label": t ? void 0 : o("View image", "查看图片"),
		"data-zoomable": "true",
		onClick: (e) => {
			e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.currentTarget.closest("a") || S();
		},
		onKeyDown: (e) => {
			e.key !== "Enter" && e.key !== " " && e.key !== "Spacebar" || e.currentTarget.closest("a") || (e.preventDefault(), S());
		}
	} : {}, w = /* @__PURE__ */ W("img", {
		ref: s,
		className: "md-image",
		...a,
		src: e,
		alt: t,
		title: n,
		loading: "lazy",
		referrerPolicy: "no-referrer",
		...C
	}), T = t || n ? o(`Image preview: ${t || n}`, `图片预览：${t || n}`) : o("Image preview", "图片预览"), E = !!(t || n), D = n && n !== t ? n : void 0;
	return /* @__PURE__ */ G(de, { children: [w, p && h && _ === e ? fe(/* @__PURE__ */ G("dialog", {
		ref: c,
		className: "md-image-zoom",
		"aria-label": T,
		onClose: b,
		onKeyDown: (e) => {
			e.key === "Tab" && (e.preventDefault(), e.currentTarget.querySelector("button")?.focus());
		},
		onCancel: (e) => {
			e.preventDefault(), x();
		},
		onClick: (e) => {
			e.target === e.currentTarget && x();
		},
		children: [/* @__PURE__ */ W("button", {
			type: "button",
			className: "md-image-zoom-close",
			"data-rmd-appearance": "custom",
			"aria-label": o("Close image preview", "关闭图片预览"),
			onClick: x,
			children: /* @__PURE__ */ W("span", {
				"aria-hidden": "true",
				children: "×"
			})
		}), /* @__PURE__ */ G("figure", {
			className: "md-image-zoom-figure",
			children: [/* @__PURE__ */ W("img", {
				className: "md-image-zoom-full",
				src: e,
				alt: t,
				title: n,
				referrerPolicy: "no-referrer"
			}), E ? /* @__PURE__ */ G("figcaption", {
				className: "md-image-zoom-caption",
				children: [t ? /* @__PURE__ */ W("span", { children: t }) : null, D ? /* @__PURE__ */ W("span", {
					className: "md-image-zoom-title",
					children: D
				}) : null]
			}) : null]
		})]
	}), h) : null] });
}
// src/local/rendering/validation-state.ts
var _r = 2e3, vr = { invalid: !1 }, yr = {
	hintFor: () => null,
	fieldFor: () => vr
};
function br(e) {
	return `${e.start}:${e.end}`;
}
function xr(e) {
	return e.length > _r ? `${f(e, 1999)}…` : e;
}
function Sr(e, t, n, r) {
	let i = Array.isArray(e.validations) ? e.validations : [];
	if (i.length === 0) return yr;
	let a = null;
	try {
		typeof t.validate == "function" && (a = t.validate());
	} catch {
		a = null;
	}
	let o = /* @__PURE__ */ new Map();
	for (let e of a ?? []) (e.code === "local.validation.failed" || e.code === "local.validation.expression") && o.set(br(e.range), e);
	let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = r("This rule cannot be evaluated", "无法计算此规则"), d = r("Validation failed.", "校验未通过。");
	for (let [t, r] of i.entries()) {
		let i = br(r.range), f = o.get(i), p = a === null || f?.code === "local.validation.expression", m = f?.code === _, h = m ? xr(f?.message || r.message || d) : p ? f?.message ? `${u}: ${xr(f.message)}` : u : "", g = {
			id: `${n}-validation-${t}`,
			failed: m,
			error: p,
			message: h
		};
		if (s.set(r.nodeId, g), c.set(i, g), m || p) for (let t of r.fields ?? []) {
			let n = Object.hasOwn(e.bindings, t) ? e.bindings[t] : void 0;
			if (n) for (let e of n.nodeIds ?? []) {
				let t = l.get(e);
				t ? t.includes(g.id) || t.push(g.id) : l.set(e, [g.id]);
			}
		}
	}
	return {
		hintFor(e) {
			return c.get(br(e.range)) ?? s.get(e.id) ?? null;
		},
		fieldFor(e) {
			let t = l.get(e.id);
			return t && t.length > 0 ? {
				describedBy: t.join(" "),
				invalid: !0
			} : vr;
		}
	};
}
// src/local/rendering/LocalDocumentViewCore.tsx
function Cr(e, t) {
	if (e !== void 0) {
		if (t.hostRenderer !== void 0) throw Error("reactConfig cannot be combined with hostRenderer.");
		if (t.hostData !== void 0) throw Error("reactConfig cannot be combined with hostData.");
		if (t.themes !== void 0) throw Error("reactConfig cannot be combined with themes; themes are derived from the config.");
	}
}
var wr = oe(null);
function Tr() {
	let e = ce(wr);
	if (!e) throw Error("LocalViewContext is not initialized");
	return e;
}
var Er = /^\s*\{\{([\s\S]*)\}\}\s*$/, Dr = {
	revision: 0,
	state: {}
};
function Or(e, t) {
	return e.attrs?.[t];
}
function kr(e) {
	return e === null ? "" : typeof e == "string" ? e : typeof e == "number" ? Number.isFinite(e) ? String(e) : null : typeof e == "boolean" ? e ? "true" : "false" : null;
}
function Ar(e, t, n) {
	return (t ?? []).map((t) => {
		if (t.type === "interpolation") try {
			return kr(e.evaluate(t.value ?? "")) ?? n("Cannot compute", "无法计算");
		} catch {
			return n("Cannot compute", "无法计算");
		}
		return t.type === "image" ? t.alt ?? "" : t.type === "break" ? " " : t.children?.length ? Ar(e, t.children, n) : t.value ?? "";
	}).join("");
}
function jr(e, t, n, r) {
	let i = Or(t, n);
	if (i === void 0) return {
		ok: !0,
		value: r
	};
	let a = Er.exec(i);
	if (!a) return {
		ok: !0,
		value: i === "true"
	};
	try {
		let t = e.evaluate(a[1]);
		return typeof t == "boolean" ? {
			ok: !0,
			value: t
		} : { ok: !1 };
	} catch {
		return { ok: !1 };
	}
}
function Mr(e) {
	try {
		return e.snapshot().revision;
	} catch {
		return 0;
	}
}
function Nr(e) {
	if (!Array.isArray(e) || e.length === 0) return "";
	try {
		return e.map((e) => {
			if (!e || typeof e != "object") return "";
			let t = Array.isArray(e.colorSchemes) ? e.colorSchemes.join("") : "";
			return `${e.name}\u0000${e.protocol}\u0000${t}`;
		}).join("");
	} catch {
		return "";
	}
}
function Pr(e) {
	return e.map((e) => `${e.code}\u0000${e.range.start}\u0000${e.range.end}\u0000${e.message}`).join("");
}
function Fr(...e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r of e) for (let e of r) {
		let r = `${e.code}\u0000${e.range.start}\u0000${e.range.end}\u0000${e.message}`;
		t.has(r) || (t.add(r), n.push(e));
	}
	return n;
}
function Ir(e, t, n, r) {
	let i = H(null), a = i.current;
	if (!a || a.document !== e) {
		let o = t(e);
		a = a && n(a.projection, o) ? {
			document: e,
			projection: o,
			value: a.value
		} : {
			document: e,
			projection: o,
			value: r()
		}, i.current = a;
	}
	return a.value;
}
function Lr(e, t) {
	let n = H(null), r = n.current;
	if (r || (r = {
		document: null,
		installed: null,
		index: s,
		lookup: { get: (e) => n.current?.index.get(e) }
	}, n.current = r), r.document !== e || r.installed !== t) {
		let n;
		try {
			n = u(e, t);
		} catch {
			n = s;
		}
		r.index = n, r.document = e, r.installed = t;
	}
	return r.lookup;
}
function Rr(e, t, n, r, i) {
	let a = H(null), o = a.current;
	return o && o.runtime === t && o.t === r && o.key === i || (o = {
		runtime: t,
		t: r,
		key: i,
		value: Sr(e, t, n, r)
	}, a.current = o), o.value;
}
function zr(e, t, n) {
	let r = 0;
	try {
		r = e.resetToken(t);
	} catch {
		r = 0;
	}
	let i = H(r), a = H(n);
	a.current = n, B(() => {
		i.current !== r && (i.current = r, a.current());
	}, [r]);
}
function Br({ message: e }) {
	let t = Me();
	return /* @__PURE__ */ W("span", {
		className: "local-error",
		role: "alert",
		children: e ?? t("Cannot compute", "无法计算")
	});
}
var Vr = class extends ie {
	state = { failed: !1 };
	static getDerivedStateFromError() {
		return { failed: !0 };
	}
	componentDidUpdate(e) {
		this.state.failed && e.revision !== this.props.revision && this.setState({ failed: !1 });
	}
	render() {
		return this.state.failed ? /* @__PURE__ */ W(Br, {}) : this.props.children;
	}
};
function Hr(e, t, n) {
	if (!e) return null;
	let r = e.trim();
	if (!r) return null;
	let i = r.replace(/[\u0000- ]+/g, ""), a = /^([a-z][a-z0-9+.-]*):/i.exec(i);
	if (a) {
		let e = a[1].toLowerCase();
		if (!(t === "image" ? e === "http" || e === "https" : e === "http" || e === "https" || e === "mailto" || e === "tel")) return null;
	}
	if (!n) return t === "image" ? null : r;
	try {
		return n(r, t) ? r : null;
	} catch {
		return null;
	}
}
function Ur(e) {
	return `h${Math.min(6, Math.max(1, e ?? 1))}`;
}
function Wr(e, t, n) {
	if (!e) return {};
	let { start: r, end: i } = t.range;
	return !Number.isInteger(r) || !Number.isInteger(i) || r < 0 || i < r ? {} : {
		"data-rmd-source-start": String(r),
		"data-rmd-source-end": String(i),
		"data-rmd-source-node": t.id,
		"data-rmd-source-type": t.type,
		...n ? { "data-rmd-source-component": n } : {}
	};
}
function Gr(e, t, n) {
	return Wr(e.sourceNavigation !== void 0, t, n);
}
function Kr(e, t) {
	let n = "";
	try {
		n = e.runtime.document.source ?? "";
	} catch {
		n = "";
	}
	if (typeof n != "string" || n.length === 0) return {
		line: 1,
		column: 1
	};
	let r = Math.max(0, Math.min(t, n.length)), i = 1, a = 0;
	for (let e = 0; e < r; e += 1) n[e] === "\n" && (i += 1, a = e + 1);
	return {
		line: i,
		column: r - a + 1
	};
}
function qr(e, t) {
	if (!e) return "missing";
	let n = null;
	try {
		n = e.querySelector(`[id="${t}"]`);
	} catch {
		n = null;
	}
	if (!n) return "missing";
	if (n.closest("[hidden]")) return "hidden";
	n.hasAttribute("tabindex") || (n.tabIndex = -1);
	try {
		n.focus({ preventScroll: !0 });
	} catch {}
	let r = "smooth";
	try {
		window.matchMedia("(prefers-reduced-motion: reduce)").matches && (r = "auto");
	} catch {
		r = "auto";
	}
	try {
		n.scrollIntoView({
			behavior: r,
			block: "start"
		});
	} catch {}
	return "ok";
}
function Jr(e, t, n) {
	let r = jr(e.runtime, t, "disabled", !1), i = 0;
	try {
		i = e.runtime.resetToken(t);
	} catch {
		i = 0;
	}
	return {
		runtime: e.runtime,
		services: e.runtime.services,
		mode: e.mode,
		visible: n,
		disabled: !r.ok || r.value,
		disabledInvalid: !r.ok,
		resetToken: i,
		locale: e.locale,
		renderChildren: (t, n) => $(e, t ?? [], n),
		renderInline: (t, n) => ai(e, t ?? [], n),
		renderToText: (t) => Ar(e.runtime, t, e.t),
		report: (t) => e.report?.(t),
		positionOf: (t) => Kr(e, t),
		definitionFor: (t) => e.definitions.get(t),
		validationField: (t) => e.validation.fieldFor(t),
		validationHint: (t) => e.validation.hintFor(t),
		sourceAttributes: (t, n) => Gr(e, t, n),
		targetId: (t) => e.anchors.targetId(t),
		anchorId: (t) => e.anchors.anchorIds.get(t),
		jumpAllowed: (t) => {
			if (e.anchors.targetId(t) === void 0) return !1;
			if (e.urlPolicy === void 0) return !0;
			try {
				return e.urlPolicy(`#${t}`, "link") === !0;
			} catch {
				return !1;
			}
		},
		jumpTo: (t) => qr(e.rootRef.current, t),
		urlPolicy: e.urlPolicy,
		imageResolver: e.imageResolver
	};
}
function Yr(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) t[n] = Array.isArray(r) ? r.slice() : r;
	return t;
}
function Xr(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => e === t[n]) : e === t;
}
function Zr(e, t) {
	let n = Object.keys(e), r = Object.keys(t);
	if (n.length !== r.length) return !1;
	for (let r of n) if (!Object.hasOwn(t, r) || !Xr(e[r], t[r])) return !1;
	return !0;
}
var Qr = /^(?:aria|data)-[a-z0-9_.:-]+$/, $r = /* @__PURE__ */ new Set([
	"aria-labelledby",
	"aria-describedby",
	"aria-controls",
	"aria-owns",
	"aria-details",
	"aria-errormessage",
	"aria-flowto",
	"aria-activedescendant"
]);
function Q(e, t) {
	let n = t.attrs;
	if (!n) return {};
	let r = {}, i = e.anchors.ids.get(t) ?? e.anchors.htmlIds.get(t);
	i && (r.id = i);
	for (let [i, a] of Object.entries(n)) {
		let n = i.toLowerCase();
		if (n !== "id") {
			if (n === "align" && (t.type === "div" || t.type === "paragraph" || t.type === "heading")) {
				let e = p(a);
				e && (r.align = e);
			} else if (n === "title" || n === "lang") r[n] = a;
			else if (n === "dir") {
				let e = a.trim().toLowerCase();
				(e === "ltr" || e === "rtl" || e === "auto") && (r.dir = e);
			} else Qr.test(n) && (r[n] = $r.has(n) ? a.trim().split(/\s+/).filter(Boolean).map((t) => e.anchors.referenceId(t)).join(" ") : a);
		}
	}
	return r;
}
function ei(e, t, n, r) {
	let i = [], a = (e) => {
		for (let t of e) t.name === "tr" ? i.push(t) : t.name !== "td" && t.name !== "th" && t.type !== "htmlTable" && a(t.children ?? []);
	};
	a(t.children ?? []);
	let o = i.some((e) => e.children?.some((e) => ["colspan", "rowspan"].some((t) => e.attrs?.[t] !== void 0 && e.attrs[t] !== "1"))), s = i.filter((e) => e.children?.some((e) => e.name === "td")), c = (t) => {
		if (t.type === "interpolation") try {
			return kr(e.runtime.evaluate(t.value ?? "")) ?? "";
		} catch {
			return "";
		}
		return (t.value ?? "") + (t.children ?? []).map(c).join("");
	}, l = o ? [] : Le(s.map((e) => e.children ?? []), e.runtime, e.t), u = (t, r = 0) => {
		if (t.type === "htmlTable") return ei(e, t, n, t.id);
		let i = t.name ?? "";
		if (!h.has(i) || i === "table") return null;
		let a = {
			...Q(e, t),
			key: t.id
		}, o = t.attrs ?? {};
		if (i === "th" || i === "td") {
			o.colspan !== void 0 && (a.colSpan = Number(o.colspan)), o.rowspan !== void 0 && (a.rowSpan = Number(o.rowspan)), o.scope !== void 0 && (a.scope = o.scope.trim().toLowerCase()), o.abbr !== void 0 && (a.abbr = o.abbr), o.headers !== void 0 && (a.headers = o.headers.trim().split(/\s+/).map((t) => e.anchors.referenceId(t)).join(" ")), l[r] && (a.className = "is-numeric");
			let s = o.align && p(o.align);
			return s && (a.style = { textAlign: s }), R(i, a, $(e, t.children, n));
		}
		return (i === "col" || i === "colgroup") && (o.span !== void 0 && (a.span = Number(o.span)), i === "col") ? R("col", a) : R(i, a, (t.children ?? []).map((e, t) => u(e, t)));
	}, d = t.children?.find((e) => e.name === "caption"), f = d ? $(e, (d.children ?? []).flatMap((e) => e.type === "paragraph" ? e.children ?? [] : [e]), n, !1) : e.t("Table", "表格");
	return /* @__PURE__ */ W(L, {
		className: "local-visual-table-block local-html-table-block",
		label: f,
		children: /* @__PURE__ */ G(F, {
			tableProps: {
				...Q(e, t),
				...o ? { "data-merged": "true" } : {}
			},
			children: [/* @__PURE__ */ W("caption", {
				...d ? Q(e, d) : {},
				className: "local-visual-sr-only",
				children: d ? c(d) : e.t("Table", "表格")
			}), (t.children ?? []).filter((e) => e.name !== "caption").map((e) => u(e))]
		})
	}, r);
}
function ti(e, t) {
	return Ee(e, t);
}
var ni = se(function({ node: e, index: t, visible: n, env: r }) {
	return ui(r, e, t, n, !0);
}, ti);
function $(e, t, n, r = !0) {
	if (!t || t.length === 0) return null;
	if (!r) return t.map((t, r) => ui(e, t, r, n, !1));
	let i = null, o = null;
	try {
		i = e.runtime.snapshot().state, o = a(e.runtime);
	} catch {
		i = null;
	}
	let s = i;
	return t.map((t, r) => {
		let i = e.dependencies.get(t.id), a = i == null || s === null || o === null ? null : i.map((e) => s[e]), c = o?.get(t.id) ?? 0;
		return /* @__PURE__ */ W(ni, {
			node: t,
			index: r,
			visible: n,
			env: e,
			depValues: a,
			resetToken: c
		}, t.id || `${t.type}-${r}`);
	});
}
function ri(e, t) {
	if (typeof t.value == "string") return t.value;
	let { start: n, end: r } = t.range;
	return Number.isInteger(n) && Number.isInteger(r) && n >= 0 && r >= n ? e.runtime.document.source.slice(n, r) : "";
}
function ii(e, t, n, r) {
	return /* @__PURE__ */ W("span", {
		className: r ? "local-fallback local-fallback-block" : "local-fallback local-fallback-inline",
		title: e.t("Unsupported syntax shown as source", "未支持的语法，已按源码原样显示"),
		"data-local-fallback": "",
		children: ri(e, t)
	}, n);
}
function ai(e, t, n) {
	return !t || t.length === 0 ? null : t.map((t, r) => t.type === "paragraph" || t.type === "root" ? /* @__PURE__ */ W("span", { children: $(e, t.children, n, !1) }, t.id || `inline-${r}`) : ui(e, t, r, n, !1));
}
function oi(e, t, n) {
	let r = e.footnotes.siteFor(t);
	if (!r || !r.entry) {
		let i = r?.label || c(t) || "?";
		return /* @__PURE__ */ W("span", {
			className: "local-footnote-missing",
			title: e.t("Undefined footnote", "未定义的脚注"),
			"data-local-footnote-missing": "",
			children: `[^${i}]`
		}, n);
	}
	let i = r.entry;
	return /* @__PURE__ */ W("sup", {
		className: "local-footnote-ref",
		children: /* @__PURE__ */ W("a", {
			id: r.id,
			href: `#${i.id}`,
			className: "local-footnote-ref-link",
			role: "doc-noteref",
			"data-local-footnote-number": i.number,
			"aria-label": e.t(`Footnote ${i.number}`, `脚注 ${i.number}`),
			children: i.number
		})
	}, n);
}
function si(e, t) {
	let n = Er.exec(t);
	if (n) try {
		let t = e.evaluate(n[1]);
		return t === null || typeof t == "string" || typeof t == "number" || typeof t == "boolean" ? t : null;
	} catch {
		return null;
	}
	try {
		return e.text(t);
	} catch {
		return null;
	}
}
function ci(e, t, n, r) {
	let i = t.name ?? "", a = (t, r = !1) => /* @__PURE__ */ W("span", {
		className: `local-host-component local-host-unavailable${r ? " local-sdk-unavailable" : ""}`,
		"data-local-host-component": i,
		"data-local-host-reason": t,
		role: "note",
		children: e.t(`Host component <${i}> is unavailable here.`, `宿主组件 <${i}> 在此不可用。`)
	}, n);
	if (e.extensionRenderer) try {
		return R(ae, { key: n }, e.extensionRenderer(t, Jr(e, t, r)));
	} catch (e) {
		return a(e instanceof P ? "renderer" : "error", !0);
	}
	let o = t.attrs?.kind?.trim() ?? "", s = t.attrs?.ref?.trim() ?? "", c = o !== "" && s !== "" ? `${o}:${s}` : null;
	if (c === null) {
		let n = !1;
		try {
			n = Object.values(e.runtime.document.bindings).some((e) => e.nodeIds.includes(t.id));
		} catch {
			n = !1;
		}
		if (!n && t.hostForm !== "container" && t.hostForm !== "inline") return a("data");
	}
	let l = e.hostRenderer;
	if (!l) return a("renderer");
	let u;
	if (c !== null && (u = e.hostData?.[c], u === void 0)) return a("data");
	let d = () => {
		try {
			return e.runtime.get(t);
		} catch {
			return null;
		}
	}, f = {};
	for (let [n, r] of Object.entries(t.attrs ?? {})) n !== "bind" && n !== "initial" && n !== "disabled" && (f[n] = si(e.runtime, r));
	let p = 0;
	try {
		p = e.runtime.resetToken(t);
	} catch {
		p = 0;
	}
	let m = jr(e.runtime, t, "disabled", !1), h = {
		runtime: e.runtime,
		render: (n, r = !0) => $(e, n ?? t.children ?? [], r),
		visible: r,
		mode: e.mode,
		value: d(),
		setValue: (n) => {
			try {
				let r = e.runtime.set(t, n);
				return !r.length || (e.report?.(r), !1);
			} catch {
				return !1;
			}
		},
		disabled: !m.ok || m.value,
		resetToken: p,
		props: Object.freeze(f),
		report: (t) => e.report?.(t)
	};
	try {
		return R(ae, { key: n }, l(t, u, h));
	} catch {
		return a("error");
	}
}
function li(e, t, n) {
	let r = (e) => e.type === "blockquote" || e.type === "list" || e.type === "listItem" && typeof e.checked != "boolean";
	if (!r(t) || t.children?.length !== 1 || !r(t.children[0])) return;
	let i = [], a = t;
	for (; i.push(a), a.children?.length === 1 && r(a.children[0]);) a = a.children[0];
	if (i.length < 32) return;
	let o = $(e, a.children, n);
	for (let t = i.length - 1; t >= 0; t--) {
		let n = i[t], r = Q(e, n), a = n.id;
		o = n.type === "blockquote" ? /* @__PURE__ */ W("blockquote", {
			...r,
			children: o
		}, a) : n.type === "listItem" ? /* @__PURE__ */ W("li", {
			...r,
			className: "md-list-item",
			children: o
		}, a) : n.ordered ? /* @__PURE__ */ W("ol", {
			...r,
			start: n.start ?? 1,
			className: "md-list",
			children: o
		}, a) : /* @__PURE__ */ W("ul", {
			...r,
			className: "md-list",
			children: o
		}, a);
	}
	return o;
}
function ui(e, t, n, r, i = !0) {
	let a = t.id || `${t.type}-${n}`, o = li(e, t, r);
	if (o !== void 0) return o;
	if (t.type === "component") return /* @__PURE__ */ W(Vr, {
		revision: Mr(e.runtime),
		children: fi(e, t, r)
	}, a);
	switch (t.type) {
		case "root": return /* @__PURE__ */ W("div", { children: $(e, t.children, r) }, a);
		case "heading": return R(Ur(t.depth), {
			key: a,
			id: e.anchors.ids.get(t),
			...Q(e, t),
			...Gr(e, t)
		}, $(e, t.children, r, !1));
		case "paragraph": return /* @__PURE__ */ W("p", {
			...Q(e, t),
			...Gr(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "text": return /* @__PURE__ */ W("span", { children: t.value ?? "" }, a);
		case "emphasis": return /* @__PURE__ */ W("em", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "strong": return /* @__PURE__ */ W("strong", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "delete": return /* @__PURE__ */ W("del", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "underline": return /* @__PURE__ */ W("u", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "mark": return /* @__PURE__ */ W("mark", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "sup": return /* @__PURE__ */ W("sup", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "sub": return /* @__PURE__ */ W("sub", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "span": return /* @__PURE__ */ W("span", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "div": return /* @__PURE__ */ W("div", {
			...Q(e, t),
			children: $(e, t.children, r)
		}, a);
		case "summary": return /* @__PURE__ */ W("span", {
			...Q(e, t),
			children: $(e, t.children, r, !1)
		}, a);
		case "details": return /* @__PURE__ */ W(pi, {
			node: t,
			visible: r
		}, a);
		case "inlineCode": return /* @__PURE__ */ W("code", {
			className: "md-inline-code",
			...Q(e, t),
			children: t.value ?? ""
		}, a);
		case "code": return /* @__PURE__ */ W(hr, {
			value: t.value ?? "",
			language: t.lang ?? void 0,
			mode: e.mode,
			htmlProps: Q(e, t)
		}, a);
		case "blockquote": return /* @__PURE__ */ W("blockquote", {
			...Q(e, t),
			...Gr(e, t),
			children: $(e, t.children, r)
		}, a);
		case "break": return /* @__PURE__ */ W("br", { ...Q(e, t) }, a);
		case "thematicBreak": return /* @__PURE__ */ W("hr", { ...Q(e, t) }, a);
		case "list": return t.ordered ? /* @__PURE__ */ W("ol", {
			start: t.start ?? 1,
			className: "md-list",
			...Q(e, t),
			children: $(e, t.children, r)
		}, a) : /* @__PURE__ */ W("ul", {
			className: "md-list",
			...Q(e, t),
			children: $(e, t.children, r)
		}, a);
		case "listItem": {
			let n = typeof t.checked == "boolean";
			return /* @__PURE__ */ G("li", {
				className: n ? "md-list-item md-task-item" : "md-list-item",
				...Q(e, t),
				...Gr(e, t),
				children: [n ? e.mode === "static" ? /* @__PURE__ */ W("span", {
					className: "md-task-marker",
					role: "img",
					"aria-label": t.checked ? e.t("Completed", "已完成") : e.t("Not completed", "未完成"),
					children: t.checked ? "✓" : "☐"
				}) : /* @__PURE__ */ W("input", {
					type: "checkbox",
					className: "md-task-checkbox",
					checked: t.checked === !0,
					readOnly: !0,
					tabIndex: -1,
					"aria-label": t.checked ? e.t("Completed", "已完成") : e.t("Not completed", "未完成")
				}) : null, $(e, t.children, r)]
			}, a);
		}
		case "link": {
			let n = Hr(t.url, "link", e.urlPolicy);
			if (!n) return /* @__PURE__ */ R("span", {
				...Q(e, t),
				className: "md-link-rejected",
				key: a,
				title: e.t("Unsafe link URL rejected", "已拒绝不安全的链接地址")
			}, $(e, t.children, r, !1));
			let i = e.anchors.resolve(n), o = /^https?:/i.test(i), s = t.attrs?.target ?? (o ? "_blank" : void 0), c = d(t.attrs?.rel ?? (o ? "noopener noreferrer" : void 0), s);
			return /* @__PURE__ */ W("a", {
				...Q(e, t),
				href: i,
				title: t.title ?? void 0,
				target: s,
				rel: c,
				children: $(e, t.children, r, !1)
			}, a);
		}
		case "image": {
			let n = Hr(t.url, "image", e.urlPolicy), r = n;
			if (n && e.imageResolver) try {
				let t = e.imageResolver(n);
				r = typeof t == "string" && t.trim() !== "" ? t : null;
			} catch {
				r = null;
			}
			if (!r) {
				let n = e.t("Unsafe image rejected", "已拒绝不安全的图片"), r = t.alt ? e.t(`: ${t.alt}`, `：${t.alt}`) : "";
				return /* @__PURE__ */ G("span", {
					className: "md-image-rejected",
					...Q(e, t),
					children: [
						"[",
						n,
						r,
						"]"
					]
				}, a);
			}
			return /* @__PURE__ */ W(gr, {
				src: r,
				alt: t.alt ?? "",
				title: t.title ?? void 0,
				mode: e.mode,
				rootRef: e.rootRef,
				imageProps: t.attrs === void 0 ? void 0 : {
					...Q(e, t),
					width: t.width,
					height: t.height
				}
			}, a);
		}
		case "htmlTable": return ei(e, t, r, a);
		case "table": {
			let [n, ...i] = t.children ?? [];
			return /* @__PURE__ */ W("div", {
				className: "md-table-scroll",
				children: /* @__PURE__ */ G("table", {
					className: "md-table",
					children: [n ? /* @__PURE__ */ W("thead", { children: /* @__PURE__ */ W("tr", { children: di(e, n, "th", t.align, r) }) }) : null, i.length ? /* @__PURE__ */ W("tbody", { children: i.map((n, i) => /* @__PURE__ */ W("tr", { children: di(e, n, "td", t.align, r) }, n.id || `${a}-row-${i}`)) }) : null]
				})
			}, a);
		}
		case "tableRow": return /* @__PURE__ */ W("tr", { children: di(e, t, "td", void 0, r) }, a);
		case "tableCell": {
			let n = t.align?.[0] ?? void 0;
			return /* @__PURE__ */ W("td", {
				style: { textAlign: n ?? void 0 },
				children: $(e, t.children, r, !1)
			}, a);
		}
		case "interpolation": try {
			let n = kr(e.runtime.evaluate(t.value ?? ""));
			if (n === null) throw Error("Cannot display an array");
			return /* @__PURE__ */ W("span", {
				className: "local-interpolation",
				...Gr(e, t),
				children: n
			}, a);
		} catch {
			return /* @__PURE__ */ W(Br, {}, a);
		}
		case "math":
		case "inlineMath": {
			let n = t.type === "math";
			return /* @__PURE__ */ W("span", {
				className: n ? "local-math-display" : "local-math-inline",
				...Gr(e, t),
				children: /* @__PURE__ */ W(Vr, {
					revision: Mr(e.runtime),
					children: /* @__PURE__ */ W(I, {
						source: t.value ?? "",
						display: n
					})
				})
			}, a);
		}
		case "html": return /* @__PURE__ */ W("span", {
			className: "md-raw-html",
			children: t.value ?? ""
		}, a);
		case "fallback": return ii(e, t, a, i);
		case "footnoteReference": return oi(e, t, a);
		case "footnoteDefinition": return null;
		case "comment":
		case "definition": return null;
		case "hostComponent": return ci(e, t, a, r);
		default: return t.children && t.children.length ? /* @__PURE__ */ W("span", { children: $(e, t.children, r, i) }, a) : typeof t.value == "string" ? /* @__PURE__ */ W("span", { children: t.value }, a) : null;
	}
}
function di(e, t, n, r, i) {
	return (t.children ?? []).map((a, o) => {
		let s = a.align?.[0] ?? t.align?.[o] ?? r?.[o] ?? void 0;
		return n === "th" ? /* @__PURE__ */ W("th", {
			style: { textAlign: s ?? void 0 },
			children: $(e, a.children, i, !1)
		}, a.id || `${t.id}-h-${o}`) : /* @__PURE__ */ W("td", {
			style: { textAlign: s ?? void 0 },
			children: $(e, a.children, i, !1)
		}, a.id || `${t.id}-c-${o}`);
	});
}
function fi(e, t, n) {
	let r = t.name ?? "";
	if (r === "computed" || r === "const" || r === "external") return null;
	let i = e.componentRenderer ?? e.extensionRenderer;
	if (i) try {
		return R(ae, { key: t.id }, i(t, Jr(e, t, n)));
	} catch (e) {
		if (!(e instanceof P)) throw e;
	}
	return /* @__PURE__ */ G("span", {
		className: "component-error",
		children: [
			e.t("Unknown component \"", "未知组件“"),
			r || e.t("(missing name)", "（缺少名称）"),
			e.t("\"", "”")
		]
	});
}
function pi({ node: e, visible: t }) {
	let n = le(), r = Tr(), { render: i, mode: a } = r, s = Me(), { summary: c, body: l } = o(e.children ?? []), u = c ? /* @__PURE__ */ W("span", {
		...Q(r, c),
		children: ai(r, c.children, t)
	}) : s("Details", "折叠内容"), d = e.attrs !== void 0 && Object.hasOwn(e.attrs, "open"), [f, p] = U(d);
	zr(r.runtime, e, () => p(d));
	let m = s("Accordion", "折叠面板");
	if (a === "static") return /* @__PURE__ */ W("div", {
		className: "local-accordion",
		role: "group",
		"aria-label": m,
		children: /* @__PURE__ */ G("section", {
			className: "local-disclosure local-static-disclosure local-html-details",
			...Q(r, e),
			children: [/* @__PURE__ */ W("h3", {
				className: "local-disclosure-heading",
				children: u
			}), /* @__PURE__ */ W("div", {
				className: "local-disclosure-panel",
				children: i(l, t)
			})]
		})
	});
	let h = `${n}-html-details-trigger`, g = `${n}-html-details-panel`;
	return /* @__PURE__ */ W("div", {
		className: "local-accordion",
		role: "group",
		"aria-label": m,
		children: /* @__PURE__ */ G("div", {
			className: "local-disclosure local-html-details",
			...Q(r, e),
			children: [/* @__PURE__ */ G("h3", {
				className: "local-disclosure-heading",
				children: [/* @__PURE__ */ G("button", {
					id: h,
					type: "button",
					className: "local-disclosure-trigger",
					"data-rmd-appearance": "custom",
					"aria-expanded": f,
					"aria-controls": g,
					onClick: () => p((e) => !e),
					children: [/* @__PURE__ */ W("span", {
						className: "local-disclosure-label",
						children: u
					}), /* @__PURE__ */ W("svg", {
						className: `local-chevron${f ? " is-open" : ""}`,
						viewBox: "0 0 24 24",
						width: "17",
						height: "17",
						fill: "none",
						stroke: "currentColor",
						strokeWidth: "1.75",
						strokeLinecap: "round",
						strokeLinejoin: "round",
						"aria-hidden": "true",
						focusable: "false",
						children: /* @__PURE__ */ W("path", { d: "m6 9 6 6 6-6" })
					})]
				}), /* @__PURE__ */ W(te, { value: u })]
			}), /* @__PURE__ */ W("div", {
				id: g,
				className: "local-disclosure-panel",
				role: "region",
				"aria-labelledby": h,
				hidden: !f,
				children: /* @__PURE__ */ W("div", {
					className: "local-disclosure-body",
					children: i(l, t && f)
				})
			})]
		})
	});
}
function mi(e, t) {
	let n = t.definition.children;
	return n && n.length > 0 ? $(e, n, !0) : typeof t.definition.value == "string" && t.definition.value !== "" ? /* @__PURE__ */ W("p", { children: t.definition.value }) : null;
}
function hi({ entries: e, env: t, t: n, titleId: r }) {
	return /* @__PURE__ */ G("section", {
		className: "local-footnotes",
		role: "doc-endnotes",
		"aria-labelledby": r,
		"data-local-footnotes": "",
		children: [/* @__PURE__ */ W("h2", {
			id: r,
			className: "local-footnotes-title",
			children: n("Footnotes", "脚注")
		}), /* @__PURE__ */ W("ol", {
			className: "local-footnotes-list",
			children: e.map((e) => {
				let r = e.references.length > 1;
				return /* @__PURE__ */ G("li", {
					id: e.id,
					className: "local-footnote",
					"data-local-footnote-number": e.number,
					children: [/* @__PURE__ */ W("div", {
						className: "local-footnote-body",
						children: mi(t, e)
					}), /* @__PURE__ */ W("span", {
						className: "local-footnote-backlinks",
						children: e.references.map((t, i) => /* @__PURE__ */ W("a", {
							href: `#${t.id}`,
							className: "local-footnote-backlink",
							role: "doc-backlink",
							"aria-label": r ? n(`Back to reference ${e.number} (${i + 1} of ${e.references.length})`, `返回脚注 ${e.number} 的第 ${i + 1} 处引用`) : n(`Back to reference ${e.number}`, `返回脚注 ${e.number}`),
							children: "↩"
						}, t.id))
					})]
				}, e.id);
			})
		})]
	});
}
function gi({ source: e, mode: t }) {
	return /* @__PURE__ */ W("article", {
		className: `md-document local-document${t === "static" ? " local-static" : ""}`,
		"data-source-mode": "html",
		"data-render-mode": t,
		"data-html-fallback": "document",
		children: /* @__PURE__ */ W("pre", {
			className: "local-fallback local-fallback-block",
			style: {
				whiteSpace: "pre-wrap",
				overflowWrap: "anywhere"
			},
			children: e
		})
	});
}
function _i({ document: e, mode: t = "interactive", staticFirst: r = !1, locale: i = "en", onDiagnostics: a }) {
	let [o, s] = U(!r);
	B(() => {
		r && s(!0);
	}, [r]);
	let c = t === "interactive" && r && !o ? "static" : t, l = e.html?.enableCss === !0, u = c === "interactive" && e.html?.enableJavaScript === !0, d = e.html?.enableExtendedHtml === !0, f = V(() => ({
		enableCss: l,
		enableJavaScript: u,
		enableExtendedHtml: d
	}), [
		l,
		u,
		d
	]), p = e.nodes.length === 1 && e.nodes[0].type === "fallback", m = V(() => p ? {
		markup: "",
		diagnostics: []
	} : y(e.source, f, Math.max(n, e.source.length * 2 + 10)), [
		e.source,
		f,
		p
	]), h = H(a);
	return h.current = a, B(() => {
		p || h.current?.(m.diagnostics);
	}, [m, p]), p || m.diagnostics.some((e) => e.severity === "error") ? /* @__PURE__ */ W(gi, {
		source: e.source,
		mode: c
	}) : /* @__PURE__ */ W("article", {
		className: `md-document local-document reactive-md-native-document${c === "static" ? " local-static" : ""}`,
		"data-source-mode": "html",
		"data-render-mode": c,
		children: /* @__PURE__ */ W("iframe", {
			className: "reactive-md-native-frame",
			title: je(i, "HTML document", "HTML 文档"),
			sandbox: v(f),
			referrerPolicy: "no-referrer",
			srcDoc: m.markup,
			style: {
				display: "block",
				width: "100%",
				minHeight: "60vh",
				border: 0,
				background: "#fff",
				colorScheme: "light"
			}
		}, `${Number(l)}${Number(u)}${Number(d)}:${e.source}`)
	});
}
function vi(e) {
	return Cr(e.reactConfig, e), N(e.runtime), e.document.html ? /* @__PURE__ */ W(_i, { ...e }) : /* @__PURE__ */ W(yi, { ...e });
}
function yi({ document: e, runtime: t, onDiagnostics: n, urlPolicy: a, locale: o = "en", themes: s, colorScheme: c = "auto", mode: l = "interactive", staticFirst: u = !1, imageResolver: d, hostData: f, hostRenderer: p, reactConfig: m, externalValues: h, onSourceNavigate: g, getBaseConfig: _ }) {
	let [v, y] = U(!u);
	B(() => {
		u && y(!0);
	}, [u]);
	let S = l === "interactive" && u && !v ? "static" : l, T = le(), E = V(() => (e, t) => je(o, e, t), [o]), D = V(() => m ?? _(), [m, _]), O = V(() => {
		try {
			return w(D.config);
		} catch {
			return [];
		}
	}, [D]), k = Ir(e, (e) => be(e, O), xe, () => i(e, `local-heading-${T}`, !0, O)), A = Ir(e, Se, Ce, () => r(e, T)), N = Lr(e, O), P = H(n);
	P.current = n;
	let F = H(null), I = z((e) => {
		P.current?.(e);
	}, []), L = V(() => {
		let e = /* @__PURE__ */ new Map();
		for (let t of O) e.set(t.name, t);
		return e;
	}, [O]), te = V(() => {
		try {
			return `${D.config.key}\u0000${JSON.stringify(e.extensions ?? null)}`;
		} catch {
			return `${D.config.key}\u0000unreadable`;
		}
	}, [D, e.extensions]), ne = V(() => {
		let t = j(D, e.extensions);
		return t.push(...x(e, D.config)), {
			valid: t.length === 0,
			diagnostics: t
		};
	}, [
		D,
		te,
		e.componentConfigKey
	]), re = V(() => ee({
		document: e,
		installed: O,
		externalNames: new Set(D.config.components.map((e) => e.name))
	}), [
		e,
		O,
		D
	]), ie = V(() => [...ne.diagnostics, ...re], [ne, re]), ae = ie.length === 0, oe = H("");
	B(() => {
		let e = Pr(ie);
		if (e === oe.current) return;
		let t = oe.current !== "";
		oe.current = e, (ie.length > 0 || t) && I(ie);
	}, [ie, I]);
	let R = V(() => M(ae ? D : _()), [
		D,
		ae,
		_
	]), se = V(() => m !== void 0 && ae ? M(D) : void 0, [
		m,
		D,
		ae
	]), ce = m?.themes ?? s, de = H(h);
	de.current = h, B(() => {
		let e = de.current;
		if (e) try {
			let n = t.setExternalValues(e);
			n.length && I(n);
		} catch {}
	}, [
		t,
		e,
		h,
		I
	]);
	let fe = H(g);
	fe.current = g;
	let pe = V(() => g === void 0 ? void 0 : (e) => {
		try {
			fe.current?.(e);
		} catch {}
	}, [g === void 0]), K = z((e) => {
		if (!pe || e.defaultPrevented || e.button !== 0 || e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
		let t = e.target;
		if (!(t instanceof Element) || t.closest("input, textarea, select, button, a, summary, [contenteditable=\"true\"], [role=\"button\"], [role=\"listbox\"], [role=\"option\"], [role=\"menu\"], [role=\"dialog\"]")) return;
		let n = t.closest("[data-rmd-source-start]");
		if (!n || !F.current?.contains(n)) return;
		let r = typeof window > "u" ? null : window.getSelection();
		if (r && r.toString().trim() && r.anchorNode && F.current?.contains(r.anchorNode)) return;
		let i = Number(n.dataset.rmdSourceStart), a = Number(n.dataset.rmdSourceEnd);
		if (!Number.isInteger(i) || !Number.isInteger(a) || i < 0 || a < i) return;
		let o = n.dataset.rmdSourceComponent;
		pe({
			range: {
				start: i,
				end: a
			},
			nodeId: n.dataset.rmdSourceNode ?? "",
			nodeType: n.dataset.rmdSourceType ?? "",
			...o ? { componentName: o } : {}
		});
	}, [F, pe]), me = Nr(ce), q = V(() => {
		try {
			return b(e.theme, ce, e.themeRange, e.source);
		} catch {
			return {
				name: C.name,
				diagnostics: []
			};
		}
	}, [
		e.theme,
		e.themeRange?.start,
		e.themeRange?.end,
		e.source,
		me
	]), J = he(F, c), ge = H("");
	B(() => {
		let e = Pr(q.diagnostics);
		if (e === ge.current) return;
		let t = ge.current !== "";
		ge.current = e, (q.diagnostics.length > 0 || t) && I(q.diagnostics);
	}, [q, I]);
	let _e = z((e) => {
		try {
			return t.subscribe(e);
		} catch {
			return () => {};
		}
	}, [t]), ve = z(() => {
		try {
			return t.snapshot();
		} catch {
			return Dr;
		}
	}, [t]);
	ue(_e, ve, ve);
	let ye = "";
	if (e.validations?.length) try {
		ye = Te(e, t.validate());
	} catch {
		ye = "unavailable";
	}
	let Ee = Rr(e, t, T, E, `${e.validations?.length ? we(e) : ""}\u0000${ye}`), De = V(() => ({
		runtime: t,
		rootRef: F,
		urlPolicy: a,
		imageResolver: d,
		hostData: f,
		hostRenderer: ae ? p : void 0,
		extensionRenderer: se,
		componentRenderer: R,
		definitions: L,
		anchors: k,
		t: E,
		locale: o,
		mode: S,
		dependencies: N,
		footnotes: A,
		sourceNavigation: pe,
		validation: Ee,
		report: I
	}), [
		t,
		F,
		a,
		d,
		f,
		p,
		ae,
		se,
		R,
		L,
		k,
		E,
		o,
		S,
		N,
		A,
		pe,
		Ee,
		I
	]), Oe = z((e, t = !0) => $(De, e ?? [], t), [De]), Ae = V(() => ({
		runtime: t,
		render: Oe,
		definitions: L,
		locale: o,
		visible: !0,
		mode: S,
		imageResolver: d,
		validation: Ee,
		report: I,
		urlPolicy: a,
		anchors: k,
		rootRef: F,
		t: E,
		dependencies: N,
		footnotes: A,
		sourceNavigation: pe
	}), [
		t,
		Oe,
		L,
		o,
		I,
		a,
		d,
		S,
		k,
		F,
		E,
		Ee,
		N,
		A,
		pe
	]);
	return /* @__PURE__ */ W(ke, {
		locale: o,
		children: /* @__PURE__ */ W("article", {
			ref: F,
			className: `md-document local-document${S === "static" ? " local-static" : ""}`,
			lang: o === "zh" ? "zh-CN" : "en",
			"data-rmd-theme": q.name,
			"data-color-scheme": J,
			"data-render-mode": S,
			"data-rmd-long-prose": e.nodes.length >= 200 ? "" : void 0,
			style: { colorScheme: J },
			onClick: pe ? K : void 0,
			"aria-label": S === "static" ? E("Static document", "静态文档") : E("Interactive document", "交互文档"),
			children: /* @__PURE__ */ G(wr.Provider, {
				value: Ae,
				children: [
					ie.length > 0 ? /* @__PURE__ */ W("div", {
						className: "local-extension-error",
						role: "alert",
						"data-local-extension-error": "",
						"data-rmd-extension-error": ie.map((e) => e.message).join("; "),
						children: ie.map((e, t) => /* @__PURE__ */ W("p", { children: e.message }, `${e.code}-${t}`))
					}) : null,
					Oe(e.nodes, !0),
					A.entries.length > 0 ? /* @__PURE__ */ W(hi, {
						entries: A.entries,
						env: De,
						t: E,
						titleId: `${T}-footnotes-title`
					}) : null,
					/* @__PURE__ */ W(Y, {
						rootRef: F,
						enabled: S !== "static"
					})
				]
			})
		})
	});
}
function bi({ source: e, onDiagnostics: t, urlPolicy: n, locale: r = "en", themes: i, colorScheme: a = "auto", mode: o = "interactive", staticFirst: s = !1, imageResolver: c, hostData: l, hostRenderer: u, reactConfig: d, useBaseCompileConfig: f, externalValues: p, documentId: h, randomSeed: g, componentState: _, componentStateStorage: v, componentStateWriteDelayMs: y, onComponentStateChange: x, initialParameters: C, onParametersChange: w, onSourceNavigate: ee, compileOptions: j, getBaseConfig: M }) {
	if (Cr(d, {
		hostData: l,
		hostRenderer: u,
		themes: i
	}), d !== void 0) {
		let e = j?.config;
		if (e !== void 0 && e !== d.config) {
			let t = !1;
			try {
				t = S(e).key === d.config.key;
			} catch {
				t = !1;
			}
			if (!t) throw Error("reactConfig and compileOptions.config must be the same local config.");
		}
		if (j?.hostComponents !== void 0) throw Error("reactConfig cannot be combined with compileOptions.hostComponents.");
	}
	let N = d === void 0 && f ? M() : void 0, P = N !== void 0 && j?.config === void 0 && j?.hostComponents === void 0, F = d === void 0 ? P ? {
		...j ?? {},
		config: N.config
	} : j : {
		...j ?? {},
		config: d.config
	}, I = d?.themes ?? i ?? N?.themes, L = E(F), te = `${L}|${h ?? ""}|${g ?? ""}`, ne = H(p);
	ne.current = p;
	let re = H(h);
	re.current = h;
	let ie = H(g);
	ie.current = g;
	let ae = H(_);
	ae.current = _;
	let oe = H(v);
	oe.current = v;
	let R = H(y);
	R.current = y;
	let se = H(x);
	se.current = x;
	let ce = H(C);
	ce.current = C;
	let le = H(w);
	le.current = w;
	let U = H([]), ue = F?.config, de = ue?.key, fe = ue?.legacyKeys.map((e) => e.key) ?? [], pe = (e) => {
		let t = A(e, {
			externalValues: ne.current,
			documentId: re.current,
			randomSeed: ie.current,
			componentState: ae.current,
			...oe.current === void 0 ? {} : { componentStateStorage: oe.current },
			...R.current === void 0 ? {} : { componentStateWriteDelayMs: R.current },
			...(de ?? e.componentConfigKey) === void 0 ? {} : { configKey: de ?? e.componentConfigKey },
			...fe.length === 0 ? {} : { legacyConfigKeys: fe }
		}), n = ce.current;
		return U.current = n && Object.keys(n).length ? t.setParameters(Yr(n)) : [], t;
	}, K = H(null), me = H(null), q = V(() => {
		K.current && me.current === L || (K.current?.dispose(), K.current = D(), me.current = L);
		let t = K.current;
		return typeof t.compileShared == "function" ? t.compileShared(e, F) : t.compile(e, F);
	}, [e, L]), he = H(null), J = H(null), ge = H([]), _e = H(!1), Y = he.current;
	if (!q.ok) Y = null;
	else {
		let e = q.document;
		if (Y && J.current !== te) {
			try {
				Y.services?.state.flush();
			} catch {}
			ge.current.push(Y), Y = null, he.current = null;
		}
		if (!Y) {
			try {
				Y = pe(e);
			} catch {
				Y = null;
			}
			he.current = Y;
		} else if (Y.document !== e) {
			let t = !1;
			try {
				let n = k(Y, e, { notify: !1 });
				t = n.ok, n.ok && n.changed && (_e.current = !0);
			} catch {
				t = !1;
			}
			if (!t) {
				try {
					Y.services?.state.flush();
				} catch {}
				ge.current.push(Y);
				let t = null;
				try {
					t = pe(e);
				} catch {
					t = null;
				}
				Y = t, he.current = t;
			}
		}
		J.current = te;
	}
	let ve = H(t);
	ve.current = t;
	let ye = H(0), be = Nr(I), xe = V(() => {
		if (!q.ok) return [];
		try {
			return b(q.document.theme, I, q.document.themeRange, q.document.source).diagnostics;
		} catch {
			return [];
		}
	}, [q, be]), Se = H(null), Ce = z((e) => {
		let t = Pr(e);
		t !== Se.current && (Se.current = t, ve.current?.(e));
	}, []), we = H([]), Te = H([]), Ee = z(() => {
		Ce(Fr(q.diagnostics, xe, U.current, we.current, Te.current));
	}, [
		q,
		xe,
		Ce
	]), De = H(Ee);
	De.current = Ee, B(() => {
		let e = Y?.services, t = e === void 0 ? [] : e.state.diagnostics(), n = Te.current;
		t.length === n.length && t.every((e, t) => e === n[t]) || (Te.current = [...t], De.current());
	}), B(() => {
		we.current = [];
	}, [q]), B(() => {
		Ee();
	}, [Ee]);
	let Oe = z((e) => {
		we.current = e, De.current();
	}, []);
	if (B(() => {
		if (!Y) return;
		De.current();
		let e = !0, t;
		try {
			t = Y.getParameters();
		} catch {
			return;
		}
		let n = () => {};
		try {
			n = Y.subscribe(() => {
				if (!e) return;
				let n, r;
				try {
					n = Y.getParameters(), r = Y.snapshot();
				} catch {
					return;
				}
				if (!Zr(t, n)) {
					t = n;
					try {
						le.current?.(n, r);
					} catch {}
				}
			});
		} catch {
			return;
		}
		return () => {
			e = !1, n();
		};
	}, [Y]), B(() => (ye.current += 1, () => {
		--ye.current, queueMicrotask(() => {
			if (ye.current !== 0) return;
			let e = he.current;
			he.current = null;
			try {
				e?.dispose();
			} catch {}
			try {
				K.current?.dispose();
			} catch {}
			K.current = null, me.current = null;
		});
	}), []), B(() => {
		let e = ge.current;
		ge.current = [];
		for (let t of e) queueMicrotask(() => {
			if (he.current !== t) try {
				t.dispose();
			} catch {}
		});
		if (!q.ok || !Y) {
			let e = he.current;
			e && (he.current = null, J.current = null, queueMicrotask(() => {
				if (he.current !== e) try {
					e.dispose();
				} catch {}
			})), K.current && (K.current.dispose(), K.current = null, me.current = null);
		}
		if (_e.current) {
			_e.current = !1;
			let e = he.current;
			e && O(e);
		}
	}), B(() => {
		let e = Y?.services;
		if (e && x !== void 0) return e.state.subscribe(() => {
			se.current?.(e.state.snapshot());
		});
	}, [Y, x]), B(() => {
		let e = Y?.services?.state;
		if (e === void 0) return;
		let t = () => e.flush(), n = () => {
			document.visibilityState === "hidden" && t();
		};
		return window.addEventListener("pagehide", t), document.addEventListener("visibilitychange", n), () => {
			window.removeEventListener("pagehide", t), document.removeEventListener("visibilitychange", n);
		};
	}, [Y]), !q.ok || !Y) {
		let t = T(F);
		return typeof e == "string" && t.ok && t.htmlActive ? /* @__PURE__ */ W(gi, {
			source: e,
			mode: o
		}) : /* @__PURE__ */ G("div", {
			className: `md-document local-document local-inactive${o === "static" ? " local-static" : ""}`,
			"data-render-mode": o,
			role: "alert",
			children: [/* @__PURE__ */ W("p", {
				className: "local-inactive-title",
				children: q.ok ? je(r, "Interactive initialization failed; preview is disabled.", "交互初始化失败，预览已停用。") : je(r, "The document contains syntax errors; interactive preview is disabled.", "文档包含语法错误，交互预览已停用。")
			}), q.diagnostics.length ? /* @__PURE__ */ W("ul", {
				className: "local-inactive-list",
				children: q.diagnostics.map((e, t) => /* @__PURE__ */ G("li", { children: [m(e, r), je(r, ` (line ${e.line}, column ${e.column})`, `（第 ${e.line} 行，第 ${e.column} 列）`)] }, `${e.code}-${t}`))
			}) : null]
		});
	}
	return /* @__PURE__ */ W(vi, {
		document: q.document,
		runtime: Y,
		onDiagnostics: Oe,
		urlPolicy: n,
		locale: r,
		themes: d === void 0 ? I : void 0,
		colorScheme: a,
		mode: o,
		staticFirst: s,
		imageResolver: c,
		hostData: l,
		hostRenderer: u,
		reactConfig: d,
		getBaseConfig: M,
		externalValues: p,
		onSourceNavigate: ee
	}, L);
}
export { bi as n, vi as t };
