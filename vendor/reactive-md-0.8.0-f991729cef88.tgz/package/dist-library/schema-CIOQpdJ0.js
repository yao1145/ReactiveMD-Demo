import "./preset-core-CKc5YXSM.js";
import { t as e } from "./registry-core-CwQvif0w.js";
import { r as t } from "./compiler-core-C83OmA9k.js";
import { b as n, x as r } from "./config-validation-BLmgvFIS.js";
import { r as i } from "./default-components-CGsBNWCT.js";
import { n as a } from "./options-DiCwIp4Z.js";
// src/local/parsing/parser.ts
function o(e, n, r, i, o) {
	return typeof e != "string" || e.length > 1e6 ? t(e, void 0, r, i, o) : t(e, a(n), r, i, o);
}
// src/local/configuration/schema.ts
function s() {
	let t = i.map(e), r = t.findIndex((e) => e.name === "validation"), a = r < 0 ? t.length : r;
	return Object.freeze([
		...t.slice(0, a),
		...n,
		...t.slice(a)
	]);
}
var c = s(), l = Object.freeze(Object.fromEntries(c.map((e) => [e.name, Object.freeze(e)]))), u = Object.freeze(c.map((e) => e.name)), d = Object.freeze({
	leaf: Object.freeze(c.filter((e) => e.form === "leaf").map((e) => e.name)),
	inline: Object.freeze(c.filter((e) => e.form === "inline").map((e) => e.name)),
	container: Object.freeze(c.filter((e) => e.form === "container").map((e) => e.name))
});
function f(e) {
	return d[e];
}
function p(e) {
	return Object.hasOwn(l, e) ? l[e] : void 0;
}
function m(e, t) {
	return e.props[t]?.default;
}
function h(e) {
	return r(e, u);
}
function g(e, t) {
	return r(t, Object.keys(e.props));
}
export { f as a, o as c, m as i, u as n, g as o, p as r, h as s, l as t };
