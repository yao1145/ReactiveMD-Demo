import { A as e, F as t, I as n, N as r, Q as i, R as a, X as o, Z as s, a as c, i as l, it as u, q as d, t as f } from "./preset-core-CKc5YXSM.js";
import { T as p, r as m } from "./registry-core-CwQvif0w.js";
import { n as h } from "./props-DGlBk0e5.js";
import { C as g, I as _, S as v, T as y, _ as b, a as x, b as S, c as C, d as w, h as T, i as E, m as ee, n as D, o as te, p as ne, r as O, s as re, t as ie, v as ae, w as oe } from "./config-validation-BLmgvFIS.js";
import { i as se, o as k, r as ce, t as A } from "./expression-By9QMkMR.js";
// src/local/contracts/types.ts
var le = (e) => e.attrs?.bind ?? `@${e.id}`;
// src/local/source/node-walk.ts
function* ue(e, t = !1) {
	let n = [{
		nodes: e,
		index: 0
	}];
	for (; n.length;) {
		let e = n[n.length - 1];
		if (e.index === e.nodes.length) {
			n.pop(), t && e.owner && (yield e.owner);
			continue;
		}
		let r = e.nodes[e.index++];
		t || (yield r), r.children?.length ? n.push({
			nodes: r.children,
			index: 0,
			owner: r
		}) : t && (yield r);
	}
}
// src/local/evaluation/computations.ts
function j(e, t, n) {
	let r = t ? se(t, n) : void 0;
	return e.expressionOffset + (r ?? Math.max(0, e.source.indexOf(n)));
}
function M(e, t, n, r = "local.expression") {
	t instanceof A ? e(`${r}.${t.code || "invalid"}`, `Expression error: ${t.message}`, n + (Number.isFinite(t.offset) ? t.offset : 0)) : e(`${r}.invalid`, `Expression error: ${t instanceof Error ? t.message : String(t)}`, n);
}
function N(e) {
	return e instanceof A ? e : new A("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function P(e, t) {
	let n = new Set(e), r = /* @__PURE__ */ new Map(), i = /* @__PURE__ */ new Map();
	for (let t of e) r.set(t, 0);
	for (let a of e) for (let e of t(a)) {
		if (!n.has(e)) continue;
		r.set(a, (r.get(a) ?? 0) + 1);
		let t = i.get(e);
		t ? t.push(a) : i.set(e, [a]);
	}
	let a = [];
	for (let t of e) (r.get(t) ?? 0) === 0 && a.push(t);
	let o = [];
	for (let e = 0; e < a.length; e += 1) {
		let t = a[e];
		o.push(t);
		for (let e of i.get(t) ?? []) {
			let t = (r.get(e) ?? 0) - 1;
			r.set(e, t), t === 0 && a.push(e);
		}
	}
	let s = new Set(o);
	return {
		order: o,
		cyclic: e.filter((e) => !s.has(e))
	};
}
function de(e) {
	let t = Object.keys(e), n = new Set(t);
	return P(t, (t) => {
		let r = e[t];
		return r ? r.dependencies.filter((e) => n.has(e)) : [];
	});
}
function fe(e, t, n, r = /* @__PURE__ */ new Set(), i) {
	let a = /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Map(), c = [], l = /* @__PURE__ */ new Set();
	for (let t of e) s.has(t.name) || (s.set(t.name, t), c.push(t.name));
	let u = new Set(c);
	for (let e of c) {
		let t = s.get(e), r;
		try {
			r = i?.expression(t.source) ?? ce(t.source);
		} catch (r) {
			M(n, r, t.expressionOffset), l.add(e);
			continue;
		}
		a.set(e, r), o.set(e, [...r.dependencies]);
	}
	for (let e of c) if (!l.has(e)) {
		for (let r of o.get(e) ?? []) if (!(u.has(r) || Object.hasOwn(t, r))) {
			n("local.computation.unknown", `Reference to undeclared parameter ${r} in computation "${e}".`, j(s.get(e), a.get(e), r)), l.add(e);
			break;
		}
	}
	let d = /* @__PURE__ */ new Set();
	for (let e of c) {
		if (l.has(e)) continue;
		let i = s.get(e);
		if (i.kind === "const") for (let c of o.get(e) ?? []) {
			let o = u.has(c) ? s.get(c).kind : null;
			Object.hasOwn(t, c) ? (n("local.computation.const", `Constant "${e}" cannot depend on ${r.has(c) ? "external data" : "control parameter"} "${c}".`, j(i, a.get(e), c)), d.add(e)) : o === "computed" && (n("local.computation.const", `Constant "${e}" cannot depend on computed value "${c}".`, j(i, a.get(e), c)), d.add(e));
		}
	}
	let { order: f, cyclic: p } = P(c, (e) => o.get(e) ?? []);
	if (p.length > 0) {
		let e = new Set(p), t = [], r = /* @__PURE__ */ new Map(), i = p[0];
		for (; !r.has(i);) {
			r.set(i, t.length), t.push(i);
			let n = (o.get(i) ?? []).find((t) => e.has(t));
			if (n === void 0) break;
			i = n;
		}
		let a = r.has(i) ? t.slice(r.get(i)) : [p[0]], c = a.slice(0, 12).join(" → ") + (a.length > 12 ? " → …" : ` → ${a[0]}`);
		for (let e of a.slice(0, 100)) {
			let t = s.get(e);
			n("local.computation.cycle", `Computation "${e}" is part of a dependency cycle: ${c}.`, t.range.start, t.range.end);
		}
		for (let e of p) l.add(e);
	}
	for (let e of f) if (!l.has(e) && !(s.get(e).kind !== "const" || d.has(e)) && (o.get(e) ?? []).some((e) => u.has(e) ? s.get(e).kind === "const" && d.has(e) : !1)) {
		let t = s.get(e);
		n("local.computation.const", `Constant "${e}" indirectly depends on a value that is not a constant.`, t.expressionOffset), d.add(e);
	}
	let m = {}, h = { ...t };
	for (let e of f) {
		if (l.has(e)) continue;
		let t = s.get(e);
		if ((o.get(e) ?? []).some((e) => l.has(e))) {
			l.add(e);
			continue;
		}
		let r = a.get(e);
		try {
			let t = i ? i.infer(r, h) : r.inferType(h);
			m[e] = t, h[e] = t;
		} catch (r) {
			M(n, r, t.expressionOffset), l.add(e);
		}
	}
	let g = {}, _ = {}, v = /* @__PURE__ */ Error("failed constant read"), y = (e) => {
		l.add(e), Object.defineProperty(_, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw v;
			}
		});
	};
	for (let e of f) {
		if (l.has(e) || s.get(e).kind !== "const" || d.has(e)) continue;
		let t = s.get(e), r = a.get(e);
		try {
			let i = r.evaluate(_), a = k(i);
			if (a) {
				n("local.computation.budget", `Constant "${e}": ${a}`, t.expressionOffset), y(e);
				continue;
			}
			g[e] = Array.isArray(i) ? i.slice() : i, _[e] = g[e];
		} catch (r) {
			if (r === v) {
				y(e);
				continue;
			}
			let i = N(r);
			n("local.computation.expression", `Constant "${e}" cannot be evaluated: ${i.message}`, t.expressionOffset + (Number.isFinite(i.offset) ? i.offset : 0)), y(e);
		}
	}
	let b = {};
	for (let e of c) {
		let t = s.get(e);
		if (l.has(e) || m[e] === void 0) continue;
		let n = {
			name: e,
			kind: t.kind,
			source: t.source,
			dependencies: [...o.get(e) ?? []],
			type: m[e],
			nodeId: t.nodeId,
			range: { ...t.range }
		};
		t.kind === "const" && Object.hasOwn(g, e) && (n.value = g[e]), b[e] = n;
	}
	return {
		computations: b,
		kinds: m,
		order: f.filter((e) => !l.has(e)),
		expressions: a,
		constValues: g
	};
}
function pe(e, t, n, r, i, a = /* @__PURE__ */ new Map()) {
	let o = {}, s = /* @__PURE__ */ new Map(), c = {};
	for (let [e, t] of Object.entries(r)) c[e] = t;
	for (let [e, t] of a) Object.defineProperty(c, e, {
		enumerable: !0,
		configurable: !0,
		get() {
			throw t;
		}
	});
	for (let [e, t] of Object.entries(i)) o[e] = t, c[e] = t;
	for (let r of t) {
		let t = e[r];
		if (!t || t.kind === "const") continue;
		let i = n.get(r);
		if (i) try {
			let e = i.evaluate(c), t = k(e);
			if (t) throw new A("expression-budget", t, 0);
			o[r] = e, c[r] = e;
		} catch (e) {
			let t = N(e);
			s.set(r, t), Object.defineProperty(c, r, {
				enumerable: !0,
				configurable: !0,
				get() {
					throw t;
				}
			});
		}
	}
	return {
		values: o,
		errors: s
	};
}
// node_modules/devlop/lib/default.js
function me() {}
// node_modules/mdast-util-to-string/lib/index.js
var he = {};
function ge(e, t) {
	let n = t || he;
	return F(e, typeof n.includeImageAlt != "boolean" || n.includeImageAlt, typeof n.includeHtml != "boolean" || n.includeHtml);
}
function F(e, t, n) {
	if (_e(e)) {
		if ("value" in e) return e.type === "html" && !n ? "" : e.value;
		if (t && "alt" in e && e.alt) return e.alt;
		if ("children" in e) return I(e.children, t, n);
	}
	return Array.isArray(e) ? I(e, t, n) : "";
}
function I(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) r[i] = F(e[i], t, n);
	return r.join("");
}
function _e(e) {
	return !!(e && typeof e == "object");
}
// node_modules/micromark-util-chunked/index.js
function L(e, t, n, r) {
	let i = e.length, a = 0, o;
	if (t = t < 0 ? -t > i ? 0 : i + t : t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4) o = Array.from(r), o.unshift(t, n), e.splice(...o);
	else for (n && e.splice(t, n); a < r.length;) o = r.slice(a, a + 1e4), o.unshift(t, 0), e.splice(...o), a += 1e4, t += 1e4;
}
function ve(e, t) {
	return e.length > 0 ? (L(e, e.length, 0, t), e) : t;
}
// node_modules/micromark-util-combine-extensions/index.js
var R = {}.hasOwnProperty;
function ye(e) {
	let t = {}, n = -1;
	for (; ++n < e.length;) be(t, e[n]);
	return t;
}
function be(e, t) {
	let n;
	for (n in t) {
		let r = (R.call(e, n) ? e[n] : void 0) || (e[n] = {}), i = t[n], a;
		if (i) for (a in i) {
			R.call(r, a) || (r[a] = []);
			let e = i[a];
			xe(r[a], Array.isArray(e) ? e : e ? [e] : []);
		}
	}
}
function xe(e, t) {
	let n = -1, r = [];
	for (; ++n < t.length;) (t[n].add === "after" ? e : r).push(t[n]);
	L(e, 0, 0, r);
}
// node_modules/micromark-util-normalize-identifier/index.js
function Se(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
// node_modules/micromark-util-character/index.js
var Ce = W(/[A-Za-z]/), we = W(/[\dA-Za-z]/), Te = W(/[#-'*+\--9=?A-Z^-~]/);
function Ee(e) {
	return e !== null && (e < 32 || e === 127);
}
var De = W(/\d/), Oe = W(/[\dA-Fa-f]/), ke = W(/[!-/:-@[-`{-~]/);
function z(e) {
	return e !== null && e < -2;
}
function B(e) {
	return e !== null && (e < 0 || e === 32);
}
function V(e) {
	return e === -2 || e === -1 || e === 32;
}
var H = W(/\p{P}|\p{S}/u), U = W(/\s/);
function W(e) {
	return t;
	function t(t) {
		return t !== null && t > -1 && e.test(String.fromCharCode(t));
	}
}
// node_modules/micromark-factory-space/index.js
function G(e, t, n, r) {
	let i = r ? r - 1 : Infinity, a = 0;
	return o;
	function o(r) {
		return V(r) ? (e.enter(n), s(r)) : t(r);
	}
	function s(r) {
		return V(r) && a++ < i ? (e.consume(r), s) : (e.exit(n), t(r));
	}
}
function Ae(e, t, n, r, i, a) {
	let o = 0;
	return s;
	function s(t) {
		return a > 0 && V(t) ? (e.enter(r), c(t)) : l(t);
	}
	function c(t) {
		return V(t) && o < a ? (e.consume(t), o++, c) : (e.exit(r), l(t));
	}
	function l(e) {
		return o >= i ? t(e) : n(e);
	}
}
// node_modules/micromark-util-classify-character/index.js
function je(e) {
	if (e === null || B(e) || U(e)) return 1;
	if (H(e)) return 2;
}
// node_modules/micromark-util-resolve-all/index.js
function Me(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) {
		let a = e[i].resolveAll;
		a && !r.includes(a) && (t = a(t, n), r.push(a));
	}
	return t;
}
// node_modules/micromark-core-commonmark/lib/blank-line.js
var Ne = {
	partial: !0,
	tokenize: Pe
};
function Pe(e, t, n) {
	return r;
	function r(t) {
		return V(t) ? G(e, i, "linePrefix")(t) : i(t);
	}
	function i(e) {
		return e === null || z(e) ? t(e) : n(e);
	}
}
// src/local/contracts/version.ts
var Fe = "local-draft-3", Ie = /* @__PURE__ */ new Set([
	"table",
	"caption",
	"colgroup",
	"col",
	"thead",
	"tbody",
	"tfoot",
	"tr",
	"th",
	"td"
]), K = {
	colgroup: /* @__PURE__ */ new Set(["span"]),
	col: /* @__PURE__ */ new Set(["span"]),
	td: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"align"
	]),
	th: /* @__PURE__ */ new Set([
		"colspan",
		"rowspan",
		"headers",
		"scope",
		"abbr",
		"align"
	])
};
function Le(e, t) {
	let n = t.trim();
	return [
		"colspan",
		"rowspan",
		"span"
	].includes(e) ? /^\d{1,5}$/.test(n) && Number(n) <= (e === "rowspan" ? 65534 : 1e3) && Number(n) >= (e === "rowspan" ? 0 : 1) : e === "align" ? y(t) !== null : e !== "scope" || [
		"row",
		"col",
		"rowgroup",
		"colgroup"
	].includes(n.toLowerCase());
}
// src/local/html/html-policy.ts
var Re = {
	b: "strong",
	strong: "strong",
	i: "emphasis",
	em: "emphasis",
	s: "delete",
	del: "delete",
	u: "underline",
	mark: "mark",
	sup: "sup",
	sub: "sub"
}, ze = /* @__PURE__ */ new Set([
	"br",
	"hr",
	"img",
	"col"
]), Be = /* @__PURE__ */ new Set([
	"pre",
	"code",
	"script",
	"style",
	"textarea",
	"title",
	"xmp",
	"iframe",
	"noembed",
	"noframes",
	"plaintext"
]), Ve = /* @__PURE__ */ new Set([
	"id",
	"title",
	"lang",
	"dir"
]), He = {
	a: g,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...K
};
function Ue(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") return i + 1;
	}
	return -1;
}
function We(e, t, n) {
	if (e.startsWith("<!-->", t)) return Math.min(n, t + 5);
	if (e.startsWith("<!--->", t)) return Math.min(n, t + 6);
	let r = e.indexOf("-->", t + 4);
	return r < 0 || r + 3 > n ? n : r + 3;
}
function Ge(e) {
	return e.trim().replace(/[\u0000- ]+/g, "");
}
function Ke(e, t) {
	let n = /^([a-z][a-z0-9+.-]*):/i.exec(Ge(e));
	if (!n) return !1;
	let r = n[1].toLowerCase();
	return t === "image" ? r !== "http" && r !== "https" : r !== "http" && r !== "https" && r !== "mailto" && r !== "tel";
}
function qe(e, t) {
	return t === "class" || t === "style" || /^on[a-z]/i.test(t) ? !1 : t === "align" && v.has(e) || Ve.has(t) || /^aria-[a-z0-9_.-]+$/.test(t) || /^data-[a-z0-9_.-]+$/.test(t) ? !0 : He[e]?.has(t) ?? !1;
}
function Je(e, t) {
	return !(e === "dir" && ![
		"ltr",
		"rtl",
		"auto"
	].includes(t.trim().toLowerCase()) || e === "id" && t.trim() === "" || (e === "width" || e === "height") && !/^\d{1,6}$/.test(t.trim()) || e === "start" && !/^-?\d{1,9}$/.test(t.trim()) || !Le(e, t) || e === "href" && Ke(t, "link") || e === "src" && Ke(t, "image"));
}
function Ye(e, t) {
	return v.has(e) ? y(t) : null;
}
// src/local/parsing/parser-capabilities.ts
var Xe = Object.freeze({}), Ze = Object.freeze([
	"anchor",
	"checkbox",
	"column",
	"coordinate",
	"counter",
	"date",
	"edge",
	"input",
	"number",
	"progress",
	"range-slider",
	"slider",
	"textarea",
	"timer",
	"toggle",
	"validation"
]);
function Qe(e) {
	let t = /* @__PURE__ */ new Set();
	for (let n of Ze) e(n) || t.add(n);
	return t;
}
// src/sdk/compiler-config.ts
var q = Object.freeze({
	id: l,
	version: c
}), $e = /* @__PURE__ */ new WeakMap(), et = /* @__PURE__ */ new WeakMap();
function tt(e, t = q) {
	if (e.length === 0) return;
	let n = t.id === q.id && t.version === q.version;
	if (n) {
		let t = $e.get(e);
		if (t) return t;
	}
	let r = f({
		protocol: a,
		id: t.id,
		version: t.version,
		components: e
	});
	return n && $e.set(e, r), r;
}
function nt(e, t, n, r, i = "reactive-md-config/v1") {
	let a = T(e, { legacyProfiles: t.length > 0 ? n : [] }), o = [...a.legacyKeys, ...r !== void 0 && !a.legacyKeys.some((e) => e.key === r) ? [Object.freeze({
		profile: i,
		key: r
	})] : []];
	return w(e, a, o);
}
function rt(e) {
	return x(e) || E("assembly", "must be an object."), O(e, /* @__PURE__ */ new Set([
		"protocol",
		"presets",
		"components",
		"replacementPolicy",
		"themes"
	]), "assembly"), e.protocol !== "reactive-md-assembly/v1" && E("assembly.protocol", `must be "${r}".`), ee(e);
}
function it(i, a = [], o = []) {
	let s = ae(o);
	if (x(i) || E("config", "must be an object."), O(i, ie, "config"), i.protocol === "reactive-md-config/v2") {
		let t = rt(i.assembly), n = nt(t, a, s);
		return e(t) > 16777216 && E("config", `serialized size exceeds the ${D}-byte budget.`), n;
	}
	i.protocol !== "reactive-md-config/v1" && E("config.protocol", `must be "${n}" (or legacy "${t}").`);
	let c = re(i.presets, q, s)[0] ?? q, l = b(c, s);
	l === void 0 && E("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${c.id}" ${c.version}.`);
	let u = l.legacyKeys[0];
	u === void 0 && E("presets", `local.config.migration-unsupported: profile "${l.name}" has no legacy key mapping.`), C(l, a);
	let d = te(i.components, a);
	d.some((e) => e.replaces !== void 0) && E("config", "replaces is not supported by reactive-md-config/v1.");
	let f = tt(a, l.preset), p = Object.freeze({
		protocol: r,
		presets: Object.freeze(f ? [f] : []),
		components: d,
		replacementPolicy: "forbid",
		themes: Object.freeze([])
	}), m = nt(p, a, s, a.length > 0 ? ne(l.preset, d) : void 0, u.profile);
	return e(p) > 16777216 && E("config", `serialized size exceeds the ${D}-byte budget.`), m;
}
function at(e) {
	let t = et.get(e);
	if (t !== void 0) return t;
	let n = tt(e), i = Object.freeze({
		protocol: r,
		presets: Object.freeze(n ? [n] : []),
		components: Object.freeze([]),
		replacementPolicy: "forbid",
		themes: Object.freeze([])
	}), a = T(i).key;
	return et.set(e, a), a;
}
// src/local/configuration/options-core.ts
var ot = [
	"enableCss",
	"enableJavaScript",
	"enableExtendedHtml"
], st = q;
function J(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var ct = "local.options.invalid.host-components", lt = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, ut = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), dt = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), ft = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean"
]), pt = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]), mt = /* @__PURE__ */ new Set([
	"maxSyntaxNodes",
	"maxParseWork",
	"maxMarkdownDepth"
]);
function Y(e, t, n) {
	if (!Object.hasOwn(e, t)) return {
		ok: !0,
		value: n
	};
	let r = e[t];
	if (r === void 0) return {
		ok: !0,
		value: n
	};
	if (typeof r != "number" || !Number.isSafeInteger(r) || r < 1) {
		let e = t === "maxSyntaxNodes" ? "max-syntax-nodes" : t === "maxParseWork" ? "max-parse-work" : "max-markdown-depth";
		return {
			ok: !1,
			message: `Compile option limits.${t} must be a positive safe integer.`,
			key: `local.options.invalid.${e}`
		};
	}
	return {
		ok: !0,
		value: r
	};
}
function X(e) {
	return {
		ok: !1,
		message: `Compile option hostComponents is invalid: ${e}`,
		key: ct,
		detail: e
	};
}
function ht(e, t) {
	if (e === void 0) return {
		ok: !0,
		binding: void 0
	};
	if (!J(e)) return X(`${t} "binding" must be an object.`);
	for (let n of Object.keys(e)) if (![
		"kind",
		"initialRule",
		"min",
		"max",
		"step",
		"options",
		"exclusive"
	].includes(n)) return X(`${t} "binding" has unknown field "${n}".`);
	let n = e.kind;
	if (typeof n != "string" || !ft.has(n)) return X(`${t} "binding.kind" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
	let r = { kind: n };
	if (Object.hasOwn(e, "exclusive") && e.exclusive !== void 0) {
		if (typeof e.exclusive != "boolean") return X(`${t} "binding.exclusive" must be a boolean.`);
		r.exclusive = e.exclusive;
	}
	if (Object.hasOwn(e, "initialRule") && e.initialRule !== void 0) {
		let n = e.initialRule;
		if (typeof n != "string" || ![
			"empty",
			"false",
			"nearest-zero",
			"min",
			"first-option"
		].includes(n)) return X(`${t} "binding.initialRule" is not supported.`);
		r.initialRule = n;
	}
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (!Object.hasOwn(e, n) || e[n] === void 0) continue;
		if (r.kind !== "number") return X(`${t} "binding.${n}" is only valid for number bindings.`);
		let i = e[n];
		if (typeof i != "number" || !Number.isFinite(i)) return X(`${t} "binding.${n}" must be a finite number.`);
		r[n] = i;
	}
	if (r.kind === "number") {
		if (r.step !== void 0 && !(r.step > 0)) return X(`${t} "binding.step" must be greater than 0.`);
		if (r.min !== void 0 && r.max !== void 0 && r.min > r.max) return X(`${t} "binding.min" cannot exceed "binding.max".`);
		if (r.initialRule !== void 0 && !["min", "nearest-zero"].includes(r.initialRule)) return X(`${t} "binding.initialRule" must be "min" or "nearest-zero" for number bindings.`);
		r.initialRule ??= "nearest-zero";
	}
	let i = Object.hasOwn(e, "options") && e.options !== void 0;
	if (i) {
		if (r.kind !== "string") return X(`${t} "binding.options" is only valid for string bindings.`);
		let n = e.options;
		if (!Array.isArray(n) || n.length === 0) return X(`${t} "binding.options" must be a non-empty string array.`);
		if (n.length > 64) return X(`${t} "binding.options" accepts at most 64 values.`);
		let i = /* @__PURE__ */ new Set(), a = [];
		for (let e of n) {
			if (typeof e != "string" || e === "") return X(`${t} "binding.options" must be a non-empty string array.`);
			if (e.length > 128) return X(`${t} "binding.options" value exceeds the 128-character limit.`);
			if (i.has(e)) return X(`${t} "binding.options" value "${e}" is declared more than once.`);
			i.add(e), a.push(e);
		}
		r.options = a, r.initialRule ??= "first-option";
	}
	if (r.kind === "string") {
		let e = i ? "first-option" : "empty";
		if (r.initialRule !== void 0 && r.initialRule !== e) return X(`${t} "binding.initialRule" must be "${e}" for ${i ? "choice" : "string"} bindings.`);
		r.initialRule ??= e;
	}
	if (r.kind === "boolean") {
		if (r.initialRule !== void 0 && r.initialRule !== "false") return X(`${t} "binding.initialRule" must be "false" for boolean bindings.`);
		r.initialRule ??= "false";
	}
	return {
		ok: !0,
		binding: r
	};
}
function gt(e, t) {
	let n = [], r = /* @__PURE__ */ new Map();
	if (e === void 0) return {
		ok: !0,
		hostComponents: n,
		hostByName: r
	};
	if (!Array.isArray(e)) return X("must be an array.");
	if (e.length > 32) return X("accepts at most 32 components.");
	let i = /* @__PURE__ */ new Set();
	for (let e of t) i.add(e.name.toLowerCase());
	for (let e of S) i.add(e.name.toLowerCase());
	for (let e of oe) i.add(e.toLowerCase());
	i.add("theme");
	for (let t = 0; t < e.length; t += 1) {
		let a = e[t], o = `hostComponents[${t}]`;
		if (!J(a)) return X(`${o} must be an object.`);
		let s = a.name;
		if (typeof s != "string") return X(`${o} "name" must be a string.`);
		if (s.length > 128) return X(`${o} "name" exceeds the 128-character limit.`);
		if (!lt.test(s)) return X(`${o} "name" ${s} must use lowercase kebab-case.`);
		if (i.has(s.toLowerCase())) return X(`${o} "name" ${s} conflicts with a built-in component, HTML tag or theme.`);
		if (r.has(s.toLowerCase())) return X(`${o} "name" ${s} is declared more than once.`);
		if (typeof a.form != "string" || !dt.has(a.form)) return X(`${o} "form" must be "leaf", "inline" or "container".`);
		let c = a.form, l = ht(a.binding, o);
		if (!l.ok) return l;
		let u = l.binding, f = a.props;
		if (!J(f)) return X(`${o} "props" must be an object.`);
		let p = {};
		for (let e of Object.keys(f)) {
			if (!lt.test(e)) return X(`${o} property "${e}" must use lowercase kebab-case.`);
			if (u && pt.has(e)) return X(`${o} property "${e}" is reserved by the host binding.`);
			let t = f[e];
			if (!J(t)) return X(`${o} property "${e}" must be an object.`);
			let n = t.kind;
			if (typeof n != "string" || !ut.has(n)) return X(`property "${e}" has unsupported kind ${typeof n == "string" ? `"${n}"` : String(n)}.`);
			let r = { kind: n };
			for (let n of ["required", "static"]) if (Object.hasOwn(t, n) && t[n] !== void 0) {
				if (typeof t[n] != "boolean") return X(`${o} property "${e}" "${n}" must be a boolean.`);
				r[n] = t[n];
			}
			let i = Object.hasOwn(t, "enum") && t.enum !== void 0;
			if (n !== "enum") {
				if (i) return X(`${o} property "${e}" has "enum" but kind is "${n}".`);
			} else {
				let n = t.enum;
				if (!Array.isArray(n) || n.length === 0) return X(`${o} property "${e}" "enum" must be a non-empty string array.`);
				if (n.length > 64) return X(`${o} property "${e}" "enum" accepts at most 64 values.`);
				let i = /* @__PURE__ */ new Set();
				for (let t of n) {
					if (typeof t != "string") return X(`${o} property "${e}" "enum" must be a non-empty string array.`);
					if (t.length > 128) return X(`${o} property "${e}" enum value exceeds the 128-character limit.`);
					if (i.has(t)) return X(`${o} property "${e}" enum value "${t}" is declared more than once.`);
					i.add(t);
				}
				r.enum = [...n];
			}
			let a = Object.hasOwn(t, "pattern") && t.pattern !== void 0;
			if (n !== "string") {
				if (a) return X(`${o} property "${e}" has "pattern" but kind is "${n}".`);
			} else if (a) {
				let n = t.pattern;
				if (typeof n != "string") return X(`${o} property "${e}" "pattern" must be a string.`);
				if (n.length > 512) return X(`${o} property "${e}" "pattern" exceeds the 512-character limit.`);
				try {
					new RegExp(n);
				} catch {
					return X(`${o} property "${e}" "pattern" is not a valid regular expression.`);
				}
				if (!d(n)) return X(`${o} property "${e}" "pattern" uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected.`);
				r.pattern = n;
			}
			p[e] = r;
		}
		let m = {
			name: s,
			form: c,
			props: p,
			...u ? { binding: u } : {}
		};
		n.push(m), r.set(s, m);
	}
	return {
		ok: !0,
		hostComponents: n,
		hostByName: r
	};
}
function _t(e) {
	return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function vt(e) {
	let t = e.static === !0 || e.dynamic === !1;
	if (e.kind === "enum") {
		let n = `^(?:${(e.enum ?? []).map(_t).join("|")})$`;
		if (n.length <= 512) return {
			kind: "string",
			...e.required === !0 ? { required: !0 } : {},
			...t ? { static: !0 } : {},
			pattern: n
		};
	}
	let n = { kind: e.kind };
	return e.required === !0 && e.default === void 0 && (n.required = !0), t && (n.static = !0), e.enum && (n.enum = [...e.enum]), e.pattern !== void 0 && (n.pattern = e.pattern), n;
}
function yt(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = /* @__PURE__ */ new Map();
	for (let i of e.components) {
		let e = {};
		for (let t of Object.keys(i.props)) e[t] = vt(i.props[t]);
		let a = h(i), o = {
			name: i.name,
			form: i.form,
			props: e,
			...a ? { binding: a } : {}
		};
		t.push(o), n.set(i.name, o), r.set(i.name, i);
	}
	return {
		hostComponents: t,
		hostByName: n,
		sdkByName: r
	};
}
function Z(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of e) n.set(t.name, t);
	let r = /* @__PURE__ */ new Map();
	for (let e of t.values()) r.set(e.name, e);
	for (let e of S) r.has(e.name) || r.set(e.name, p(e));
	return {
		componentByName: n,
		schemaByName: r
	};
}
function Q(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e) t.set(n.name, m(n));
	return t;
}
function $(e, t) {
	let n = t.defaults, r = new Set(n.map((e) => e.name));
	if (e !== void 0 && !J(e)) return {
		ok: !1,
		message: "Compile options must be an object.",
		key: "local.options.invalid.object"
	};
	let a = e ?? {}, c = {
		enableCss: !1,
		enableJavaScript: !1,
		enableExtendedHtml: !1
	};
	for (let e of ot) {
		if (!Object.hasOwn(a, e)) continue;
		let t = a[e];
		if (t !== void 0) {
			if (typeof t != "boolean") return {
				ok: !1,
				message: `Compile option ${e} must be a boolean.`,
				key: "local.options.invalid.html-flag"
			};
			c[e] = t;
		}
	}
	let l = !1;
	if (Object.hasOwn(a, "markdownBreaks")) {
		let e = a.markdownBreaks;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option markdownBreaks must be a boolean.",
				key: "local.options.invalid.markdown-breaks"
			};
			l = e;
		}
	}
	let u = !0;
	if (Object.hasOwn(a, "strict")) {
		let e = a.strict;
		if (e !== void 0) {
			if (typeof e != "boolean") return {
				ok: !1,
				message: "Compile option strict must be a boolean.",
				key: "local.options.invalid.strict"
			};
			u = e;
		}
	}
	let d = a.limits, f = i, m = s, h = o;
	if (d !== void 0) {
		if (!J(d)) return {
			ok: !1,
			message: "Compile option limits must be an object.",
			key: "local.options.invalid.limits"
		};
		for (let e of Object.keys(d)) if (!mt.has(e) && d[e] !== void 0) return {
			ok: !1,
			message: `Compile option limits.${e} is not supported.`,
			key: "local.options.invalid.limits-unknown",
			detail: e
		};
		let e = Y(d, "maxSyntaxNodes", f);
		if (!e.ok) return e;
		f = e.value;
		let t = Y(d, "maxParseWork", m);
		if (!t.ok) return t;
		m = t.value;
		let n = Y(d, "maxMarkdownDepth", h);
		if (!n.ok) return n;
		h = n.value;
	}
	let g = Object.hasOwn(a, "config") && a.config !== void 0, _ = Object.hasOwn(a, "hostComponents") && a.hostComponents !== void 0;
	if (g && _) return {
		ok: !1,
		message: "Compile option config cannot be combined with hostComponents.",
		key: "local.options.invalid.config-conflict"
	};
	let v, y, b, x, S, C, w, T, E;
	if (g) {
		try {
			v = t.readConfig(a.config, n);
		} catch (e) {
			let t = e instanceof Error ? e.message : String(e);
			return {
				ok: !1,
				message: `Compile option config is invalid: ${t}`,
				key: "local.options.invalid.config",
				detail: t
			};
		}
		let e = yt(v);
		y = e.hostComponents, b = e.hostByName, x = e.sdkByName, S = v.registry;
		let r = Z(S, Q(S));
		C = r.schemaByName, w = r.componentByName, T = new Set(v.components.map((e) => e.name)), E = /* @__PURE__ */ new Set();
	} else if (_) {
		let e = gt(a.hostComponents, n);
		if (!e.ok) return e;
		y = e.hostComponents, b = e.hostByName, x = /* @__PURE__ */ new Map(), S = n;
		let t = Q(n);
		for (let [n, r] of e.hostByName) t.set(n, p({
			...r,
			legacyHost: !0
		}));
		let r = Z(n, t);
		C = r.schemaByName, w = r.componentByName, T = new Set(e.hostByName.keys()), E = new Set(e.hostByName.keys());
	} else {
		y = [], b = /* @__PURE__ */ new Map(), x = /* @__PURE__ */ new Map(), S = n;
		let e = Z(n, Q(n));
		C = e.schemaByName, w = e.componentByName, T = /* @__PURE__ */ new Set(), E = /* @__PURE__ */ new Set();
	}
	return {
		ok: !0,
		maxSyntaxNodes: f,
		maxParseWork: m,
		maxMarkdownDepth: h,
		html: c,
		htmlActive: c.enableCss || c.enableJavaScript || c.enableExtendedHtml,
		markdownBreaks: l,
		strict: u,
		hostComponents: y,
		hostByName: b,
		...v ? { config: v } : {},
		sdkByName: x,
		registry: S,
		componentByName: w,
		schemaByName: C,
		defaultComponentNames: r,
		unmountedLeafNames: v?.presets.some((e) => e.id === "reactive-md/minimal") ? Qe((e) => C.has(e)) : /* @__PURE__ */ new Set(),
		externalComponentNames: T,
		legacyHostNames: E,
		componentConfigKey: v ? t.configKey(v) : t.defaultConfigKey,
		capabilities: t.capabilities ?? Xe,
		...t.preset ? { preset: t.preset } : {}
	};
}
function bt(e, t = [], n) {
	let r = t.length > 0 ? st : void 0;
	return $(e, {
		defaults: t,
		...r ? { preset: r } : {},
		defaultConfigKey: at(t),
		readConfig: it,
		configKey: (e) => e.key,
		...n ? { capabilities: n } : {}
	});
}
function xt(e) {
	return e.componentConfigKey;
}
// src/local/evaluation/validation.ts
var St = "local.validation.failed", Ct = "local.validation.expression", wt = "Validation failed.";
function Tt(e) {
	return e.length > 2e3 ? `${_(e, u - 1)}…` : e;
}
function Et(e) {
	let t = e.trim();
	return t ? t.split(/\s+/) : [];
}
function Dt(e) {
	let t = [0];
	for (let n = 0; n < e.length; n += 1) e[n] === "\n" && t.push(n + 1);
	return t;
}
function Ot(e) {
	if (!e || typeof e != "object") return !1;
	let t = e, n = t.range;
	return typeof t.expression == "string" && typeof t.message == "string" && Array.isArray(t.fields) && !!n && Number.isFinite(n.start) && Number.isFinite(n.end);
}
function kt(e, t, n, r, i) {
	let a = e.length, o = Math.max(0, Math.min(a, Math.trunc(n.start))), s = Math.max(o + 1, Math.min(a, Math.trunc(n.end))), c = 0, l = Math.max(0, t.length - 1);
	for (; c < l;) {
		let e = Math.ceil((c + l) / 2);
		t[e] <= o ? c = e : l = e - 1;
	}
	return {
		code: r,
		message: i,
		severity: "error",
		range: {
			start: o,
			end: s
		},
		line: c + 1,
		column: o - t[c] + 1
	};
}
export { Ce as A, H as B, Le as C, je as D, Me as E, Oe as F, L as G, Se as H, ke as I, pe as J, ge as K, z as L, Te as M, Ee as N, G as O, De as P, le as Q, B as R, Ie as S, Ne as T, ye as U, U as V, ve as W, fe as X, de as Y, ue as Z, We as _, Ot as a, Je as b, kt as c, bt as d, $ as f, Ye as g, ze as h, Tt as i, we as j, Ae as k, ot as l, Be as m, St as n, Dt as o, Re as p, me as q, wt as r, Et as s, Ct as t, xt as u, Ue as v, Fe as w, K as x, qe as y, V as z };
