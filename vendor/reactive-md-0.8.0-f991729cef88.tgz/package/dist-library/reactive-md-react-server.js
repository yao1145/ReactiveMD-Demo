import { l as e } from "./config-C7nMEidX.js";
import { n as t } from "./registry-B-xSD10y.js";
import { i as n, n as r, r as i } from "./resources-85Qoj6wA.js";
import { o as a } from "./sdk-core-CIxdxzII.js";
import { t as o } from "./LocalDocumentView-D6m6ImeU.js";
import { o as s, s as c, t as l } from "./export-D7zYw1nm.js";
import { createElement as u } from "react";
import { renderToString as d } from "react-dom/server";
// src/react/server.tsx
function f(f) {
	let p = e(f.document, f.reactConfig?.config);
	if (p.push(...f.reactConfig ? a(f.reactConfig, f.document.extensions) : n(f.document.extensions, void 0)), p.push(...i({
		document: f.document,
		installed: t(f.reactConfig?.config),
		externalNames: new Set(f.reactConfig?.config.components.map((e) => e.name) ?? [])
	})), p.length) return {
		ok: !1,
		diagnostics: p
	};
	if (f.reactConfig) {
		let e = l({
			document: f.document,
			config: f.reactConfig.config,
			target: "ssr",
			resources: f.resources
		});
		if (p.push(...e.diagnostics), !e.ok) return {
			ok: !1,
			diagnostics: p
		};
	}
	try {
		let e = d(u(o, {
			...f,
			mode: "static",
			staticFirst: !1,
			onDiagnostics(e) {
				p.push(...e), f.onDiagnostics?.(e);
			}
		})), t = s(e);
		return t && p.push(r("local.extension.ssr-render", c(t))), p.some((e) => e.severity === "error") ? {
			ok: !1,
			diagnostics: p
		} : {
			ok: !0,
			markup: e,
			diagnostics: p
		};
	} catch (e) {
		let t = f.document.extensions?.components.map((e) => e.id).join(", ");
		return p.push(r("local.extension.ssr-render", `Server rendering failed${t ? ` (document extensions: ${t})` : ""}: ${e instanceof Error ? e.message : String(e)}`)), {
			ok: !1,
			diagnostics: p
		};
	}
}
export { f as renderLocalStaticDocument };
