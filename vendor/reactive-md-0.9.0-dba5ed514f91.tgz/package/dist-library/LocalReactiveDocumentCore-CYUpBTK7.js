import { M as e, w as t } from "./config-validation-C5kJYk-J.js";
import { s as n } from "./config-BUo-8O5C.js";
import { n as r, t as ee } from "./options-BC_8M3La.js";
import { n as te } from "./incremental-gPTUEo36.js";
import { i as ne, n as re, r as ie } from "./runtime-C5YjCBQc.js";
import { a as ae, c as oe, i as se, l as i, n as ce, o as le, r as ue, s as de, t as fe } from "./LocalDocumentViewCore-DeUf4fDa.js";
import { useCallback as a, useEffect as o, useMemo as s, useRef as c } from "react";
import { jsx as l, jsxs as u } from "react/jsx-runtime";
// src/local/rendering/document/LocalReactiveDocumentCore.tsx
var pe = Symbol("implicit document identity");
function d({ source: d, onDiagnostics: me, sourcePhase: f, onTransientDiagnostics: he, urlPolicy: ge, locale: p = "en", themes: _e, colorScheme: ve = "auto", mode: m = "interactive", staticFirst: ye = !1, imageResolver: be, hostData: xe, hostRenderer: Se, reactConfig: h, useBaseCompileConfig: Ce, externalValues: g, network: we, documentId: _, randomSeed: v, componentState: Te, componentStateStorage: y, componentStateWriteDelayMs: b, onComponentStateChange: x, initialParameters: S, onParametersChange: C, onSourceNavigate: Ee, compileOptions: w, getBaseConfig: T }) {
	if (oe(h, {
		hostData: xe,
		hostRenderer: Se,
		themes: _e
	}), h !== void 0) {
		let e = w?.config;
		if (e !== void 0 && e !== h.config) {
			let t = !1;
			try {
				t = n(e).key === h.config.key;
			} catch {
				t = !1;
			}
			if (!t) throw Error("reactConfig and compileOptions.config must be the same local config.");
		}
		if (w?.hostComponents !== void 0) throw Error("reactConfig cannot be combined with compileOptions.hostComponents.");
	}
	let E = h === void 0 && Ce ? T() : void 0, De = E !== void 0 && w?.config === void 0 && w?.hostComponents === void 0, D = h === void 0 ? De ? {
		...w ?? {},
		config: E.config
	} : w : {
		...w ?? {},
		config: h.config
	}, O = h?.themes ?? _e ?? E?.themes, k = ee(D), A = `${k}|${_ ?? ""}|${v ?? ""}`, Oe = D?.sourcePhase, j = f === "streaming" || f === "final" ? f : Oe === "streaming" ? "streaming" : "final", M = j === "streaming", N = c(g);
	N.current = g;
	let P = c(_);
	P.current = _;
	let ke = c(v);
	ke.current = v;
	let Ae = c(Te);
	Ae.current = Te;
	let F = c(y);
	F.current = y;
	let I = c(b);
	I.current = b;
	let je = c(x);
	je.current = x;
	let Me = c(S);
	Me.current = S;
	let Ne = c(C);
	Ne.current = C;
	let Pe = c([]), Fe = D?.config, Ie = Fe?.key, Le = Fe?.legacyKeys.map((e) => e.key) ?? [], Re = (e) => {
		let t = re(e, {
			externalValues: N.current,
			documentId: P.current,
			randomSeed: ke.current,
			componentState: Ae.current,
			...F.current === void 0 ? {} : { componentStateStorage: F.current },
			...I.current === void 0 ? {} : { componentStateWriteDelayMs: I.current },
			...(Ie ?? e.componentConfigKey) === void 0 ? {} : { configKey: Ie ?? e.componentConfigKey },
			...Le.length === 0 ? {} : { legacyConfigKeys: Le }
		}), n = Me.current;
		return Pe.current = n && Object.keys(n).length ? t.setParameters(ue(n)) : [], t;
	}, L = c(null), R = c(null), z = s(() => {
		L.current && R.current === k || (L.current?.dispose(), L.current = te(), R.current = k);
		let e = L.current;
		return typeof e.compileShared == "function" ? e.compileShared(d, D, j) : e.compile(d, D, j);
	}, [
		d,
		k,
		j
	]), B = c(null), V = c(null), H = c([]), U = c(!1), W = B.current;
	if (!z.ok) W = null;
	else {
		let e = z.document;
		if (W && V.current !== A) {
			try {
				W.services?.state.flush();
			} catch {}
			H.current.push(W), W = null, B.current = null;
		}
		if (!W) {
			try {
				W = Re(e);
			} catch {
				W = null;
			}
			B.current = W;
		} else if (W.document !== e) {
			let t = !1;
			try {
				let n = ne(W, e, { notify: !1 });
				t = n.ok, n.ok && n.changed && (U.current = !0);
			} catch {
				t = !1;
			}
			if (!t) {
				try {
					W.services?.state.flush();
				} catch {}
				H.current.push(W);
				let t = null;
				try {
					t = Re(e);
				} catch {
					t = null;
				}
				W = t, B.current = t;
			}
		}
		V.current = A;
	}
	let ze = c(me);
	ze.current = me;
	let G = c(0), K = c(he);
	K.current = he;
	let Be = c(""), q = c(!1), J = z.transientDiagnostics ?? [], Y = J.length === 0 ? "" : ae(J);
	o(() => {
		if (Y !== Be.current) {
			if (Be.current = Y, J.length === 0) {
				if (!q.current) return;
				q.current = !1, K.current?.([]);
			} else q.current = !0, K.current?.(J);
		}
	}, [Y]);
	let Ve = de(O), He = s(() => {
		if (!z.ok) return [];
		try {
			return t(z.document.theme, O, z.document.themeRange, z.document.source).diagnostics;
		} catch {
			return [];
		}
	}, [z, Ve]), Ue = c(null), We = a((e) => {
		let t = ae(e);
		t !== Ue.current && (Ue.current = t, ze.current?.(e));
	}, []), X = c([]), Z = c([]), Q = a(() => {
		We(se(z.diagnostics, He, Pe.current, X.current, Z.current));
	}, [
		z,
		He,
		We
	]), $ = c(Q);
	$.current = Q, o(() => {
		let e = W?.services, t = e === void 0 ? [] : e.state.diagnostics(), n = Z.current;
		t.length === n.length && t.every((e, t) => e === n[t]) || (Z.current = [...t], $.current());
	}), o(() => {
		X.current = [];
	}, [z]), o(() => {
		Q();
	}, [Q]);
	let Ge = a((e) => {
		X.current = e, $.current();
	}, []);
	if (o(() => {
		if (!W) return;
		$.current();
		let e = !0, t;
		try {
			t = W.getParameters();
		} catch {
			return;
		}
		let n = () => {};
		try {
			n = W.subscribe(() => {
				if (!e) return;
				let n, r;
				try {
					n = W.getParameters(), r = W.snapshot();
				} catch {
					return;
				}
				if (!le(t, n)) {
					t = n;
					try {
						Ne.current?.(n, r);
					} catch {}
				}
			});
		} catch {
			return;
		}
		return () => {
			e = !1, n();
		};
	}, [W]), o(() => (G.current += 1, () => {
		--G.current, queueMicrotask(() => {
			if (G.current !== 0) return;
			let e = B.current;
			B.current = null;
			try {
				e?.dispose();
			} catch {}
			try {
				L.current?.dispose();
			} catch {}
			L.current = null, R.current = null;
		});
	}), []), o(() => {
		let e = H.current;
		H.current = [];
		for (let t of e) queueMicrotask(() => {
			if (B.current !== t) try {
				t.dispose();
			} catch {}
		});
		if (!z.ok || !W) {
			let e = B.current;
			e && (B.current = null, V.current = null, queueMicrotask(() => {
				if (B.current !== e) try {
					e.dispose();
				} catch {}
			})), L.current && (L.current.dispose(), L.current = null, R.current = null);
		}
		if (U.current) {
			U.current = !1;
			let e = B.current;
			e && ie(e);
		}
	}), o(() => {
		let e = W?.services;
		if (e && x !== void 0) return e.state.subscribe(() => {
			je.current?.(e.state.snapshot());
		});
	}, [W, x]), o(() => {
		let e = W?.services?.state;
		if (e === void 0) return;
		let t = () => e.flush(), n = () => {
			document.visibilityState === "hidden" && t();
		};
		return window.addEventListener("pagehide", t), document.addEventListener("visibilitychange", n), () => {
			window.removeEventListener("pagehide", t), document.removeEventListener("visibilitychange", n);
		};
	}, [W]), !z.ok || !W) {
		let t = r(D);
		return typeof d == "string" && t.ok && t.htmlActive ? /* @__PURE__ */ l(ce, {
			source: d,
			mode: m
		}) : /* @__PURE__ */ u("div", {
			className: `md-document local-document local-inactive${m === "static" ? " local-static" : ""}`,
			"data-render-mode": m,
			role: "alert",
			children: [/* @__PURE__ */ l("p", {
				className: "local-inactive-title",
				children: z.ok ? i(p, "Interactive initialization failed; preview is disabled.", "交互初始化失败，预览已停用。") : i(p, "The document contains syntax errors; interactive preview is disabled.", "文档包含语法错误，交互预览已停用。")
			}), z.diagnostics.length ? /* @__PURE__ */ l("ul", {
				className: "local-inactive-list",
				children: z.diagnostics.map((t, n) => /* @__PURE__ */ u("li", { children: [e(t, p), i(p, ` (line ${t.line}, column ${t.column})`, `（第 ${t.line} 行，第 ${t.column} 列）`)] }, `${t.code}-${n}`))
			}) : null]
		});
	}
	return /* @__PURE__ */ l(fe, {
		document: z.document,
		runtime: W,
		network: we,
		networkScope: _ ?? pe,
		onDiagnostics: Ge,
		urlPolicy: ge,
		locale: p,
		themes: h === void 0 ? O : void 0,
		colorScheme: ve,
		mode: M ? "static" : m,
		staticFirst: !M && ye,
		imageResolver: be,
		hostData: xe,
		hostRenderer: Se,
		reactConfig: h,
		getBaseConfig: T,
		externalValues: g,
		onSourceNavigate: Ee
	}, k);
}
export { d as t };
