import { t as e } from "./data-table-DfvytZKQ.js";
import { a as t, o as n } from "./visuals-BkYRmYGO.js";
import { o as r } from "./layout-C22VjZh0.js";
import { t as i } from "./plugin-packs-B1XPWcFs.js";
import { t as a } from "./mount-preset-C5s9ebEH.js";
import { t as o } from "./visuals-B5KSafVk.js";
// src/components/plugins/data.ts
var s = {
	column: r,
	"data-table": e,
	table: t,
	timeline: n
}, c = i("reactive-md/data", Object.keys(s)), l = a(c, s, [{
	id: "reactive-md/visuals.css",
	css: o
}]);
export { l as default };
