import { b as e } from "./validation-B58yB_8Z.js";
import { s as t, y as n } from "./config-BUo-8O5C.js";
import { n as r } from "./options-BC_8M3La.js";
import { t as i } from "./compiler-DWpxbgUX.js";
import { u as a, w as o } from "./component-state-BoLCGee4.js";
import { n as s } from "./runtime-C5YjCBQc.js";
import { _ as c, d as l, h as u, i as d, u as f } from "./shareable-jhmXihh4.js";
import { i as p, t as m } from "./resources-IeJomeUT.js";
import { jsx as h } from "react/jsx-runtime";
import { createRoot as g, hydrateRoot as _ } from "react-dom/client";
// src/standalone/diagnostics.ts
function v(e, t) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function y(e, t = 8) {
	let n = e.slice(0, t).map((e) => `- [${e.code}] ${e.message} (line ${e.line}, column ${e.column})`);
	return e.length > n.length && n.push(`- ${e.length - n.length} more diagnostic(s).`), n.join("\n");
}
function b(e) {
	return e instanceof Error ? e.message : String(e);
}
var x = class extends Error {
	diagnostics;
	constructor(e, t) {
		let n = y(t);
		super(n ? `${e}\n${n}` : e), this.name = "ReactiveMDMountError", this.diagnostics = t;
	}
};
function S(e, t = "standalone.mount") {
	if (typeof e == "object" && e && Array.isArray(e.diagnostics)) {
		let t = e.diagnostics;
		if (t.length > 0) return t;
	}
	return [v(t, b(e))];
}
// src/standalone/events.ts
var C = "reactive-md-diagnostics", w = "reactive-md-state-change", T = /^[A-Za-z][A-Za-z0-9_-]*$/, E = 256, D = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, O = /[\u0000-\u001f\u007f-\u009f]/, k = 64, A = 4096, j = 41943040;
function M(e, t) {
	if (e === void 0) return;
	if (!P(e)) {
		t("standalone.payload.images", "images must be a JSON object mapping image URLs to data URLs.");
		return;
	}
	let n = Object.entries(e);
	if (n.length > k) {
		t("standalone.payload.images", `images cannot contain more than ${k} entries.`);
		return;
	}
	let r = Object.create(null), i = 0;
	for (let [e, a] of n) if (!e || e.length > A || e === "__proto__" || O.test(e) || typeof a != "string" || !D.test(a)) t("standalone.payload.images", "Every image entry must use a bounded URL key and a base64 raster data URL.");
	else {
		if (i += a.length, i > j) {
			t("standalone.payload.images", "The embedded image map exceeds the 40 MiB budget.");
			return;
		}
		r[e] = a;
	}
	return r;
}
function N(e, t) {
	if (e === void 0) return;
	let n = r(e);
	if (!n.ok) t("standalone.payload.compile-options", `The payload compile options are invalid: ${n.message}`);
	else return l(e);
}
function P(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function F(e, t) {
	if (e === void 0) return;
	let n = o(e);
	if (typeof e != "string" || n !== e) t("standalone.payload.document-id", "The payload documentId must be a canonical 1-256 character string.");
	else return n;
}
function I(e, t) {
	if (e !== void 0) {
		if (typeof e != "number" || !Number.isInteger(e) || e < 0 || e > 4294967295) t("standalone.payload.random-seed", "The payload randomSeed must be a 32-bit unsigned integer.");
		else return e;
	}
}
function L(e, t) {
	if (e === void 0) return;
	let n = a(e);
	if (!n.ok || n.diagnostics.length > 0) {
		let e = n.diagnostics;
		e.length === 0 && t("standalone.payload.component-state", "The payload component state is invalid.");
		for (let n of e) t("standalone.payload.component-state", n.message);
	} else return n.document;
}
function R(e) {
	let t = [], n = (e, n) => {
		t.push(v(e, n));
	};
	if (!P(e)) return {
		ok: !1,
		diagnostics: [v("standalone.payload.shape", "The reactive-md payload must be a JSON object.")]
	};
	e.version !== 1 && e.version !== 2 && n("standalone.payload.version", "The reactive-md payload must use version 1 or 2."), e.version === 2 && e.restoration === void 0 && n("standalone.payload.requirements", "Version 2 requires restoration contracts."), e.version === 1 && (e.restoration !== void 0 || e.resources !== void 0) && n("standalone.payload.version", "Restoration contracts require payload version 2.");
	let r = e.target;
	typeof r != "string" || r.length === 0 || r.length > E ? n("standalone.payload.target", `The payload target must be an element id of 1-${E} characters.`) : T.test(r) || n("standalone.payload.target", "The payload target must start with a letter and use only letters, digits, underscores or hyphens.");
	let i = e.source;
	typeof i != "string" && n("standalone.payload.source", "The payload source must be a string.");
	let a = e.locale === void 0 ? "en" : e.locale;
	a !== "en" && a !== "zh" && n("standalone.payload.locale", "The payload locale must be \"en\" or \"zh\".");
	let o = e.colorScheme === void 0 ? "auto" : e.colorScheme;
	o !== "light" && o !== "dark" && o !== "auto" && n("standalone.payload.color-scheme", "The payload colorScheme must be \"light\", \"dark\" or \"auto\".");
	let s = e.hydrate !== void 0 && e.hydrate;
	typeof s != "boolean" && n("standalone.payload.hydrate", "The payload hydrate flag must be a boolean.");
	let c = e.state;
	P(c) || n("standalone.payload.state", "The payload state must be a JSON object.");
	let l = N(e.compileOptions, n);
	t.push(...p(e.extensions, l?.config));
	let u = m(e.resources ?? []);
	t.push(...u.diagnostics), t.push(...f(e.restoration, {
		config: l?.config,
		source: typeof i == "string" ? i : "",
		resources: u.resources
	}));
	let d = M(e.images, n), h = F(e.documentId, n), g = I(e.randomSeed, n), _ = L(e.componentState, n);
	return t.length > 0 ? {
		ok: !1,
		diagnostics: t
	} : {
		ok: !0,
		payload: {
			version: e.version,
			target: r,
			source: i,
			state: c,
			locale: a,
			colorScheme: o,
			hydrate: s,
			...l === void 0 ? {} : { compileOptions: l },
			...e.extensions === void 0 ? {} : { extensions: e.extensions },
			...e.restoration === void 0 ? {} : {
				restoration: e.restoration,
				resources: u.resources
			},
			...d && Object.keys(d).length > 0 ? { images: d } : {},
			...h === void 0 ? {} : { documentId: h },
			...g === void 0 ? {} : { randomSeed: g },
			..._ === void 0 ? {} : { componentState: _ }
		}
	};
}
function z(e) {
	try {
		return R(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [v("standalone.payload.invalid", `The reactive-md payload could not be read: ${b(e)}`)]
		};
	}
}
// src/standalone/prepare.ts
function B(t, n, a, o, s) {
	if (typeof t != "string") throw new x("Cannot mount a Reactive MD document: source must be a string.", [v("standalone.source", "source must be a string.")]);
	let l = i(t, o), u;
	if (l.ok) u = l.document;
	else {
		let n = r(o);
		if (!n.ok || !n.htmlActive) throw new x("Cannot mount a Reactive MD document: the source contains syntax errors.", l.diagnostics);
		u = {
			syntax: "local",
			syntaxVersion: e,
			source: t,
			html: n.html,
			initialState: {},
			bindings: {},
			nodes: [{
				type: "fallback",
				id: "local-0",
				range: {
					start: 0,
					end: t.length
				},
				value: t
			}]
		};
	}
	if (s?.(u), n !== void 0) {
		let e = c(n);
		if (!e.ok) throw new x("Cannot mount a Reactive MD document: the state payload is invalid.", e.diagnostics);
		let t = d(u, e.file);
		if (!t.ok) throw new x("Cannot mount a Reactive MD document: the state does not match this source.", t.diagnostics);
		u = t.baseline.document;
	}
	return typeof a == "string" && a.trim().length > 0 && (u = {
		...u,
		theme: a.trim(),
		themeRange: void 0
	}), {
		document: u,
		diagnostics: l.diagnostics.slice()
	};
}
var V = Object.freeze({
	name: "reactive-md-standalone",
	version: "0.4.0"
}), H = "data-reactive-md-mounted", U = "script[type=\"application/reactive-md+json\"][data-reactive-md-auto]", W = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, G = 64;
function K(e) {
	if (!e) return {};
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e).slice(0, G)) typeof n == "string" && n.length > 0 && typeof r == "string" && W.test(r) && t.set(n, r);
	return t.size === 0 ? {} : {
		urlPolicy: (e, n) => n === "link" || t.has(e),
		imageResolver: (e) => t.get(e) ?? null
	};
}
var q = /* @__PURE__ */ new WeakSet();
function J(e) {
	return q.has(e) || e.hasAttribute("data-reactive-md-mounted");
}
function Y(e, t) {
	return u(e, t);
}
function X(e) {
	if (e) try {
		e();
	} catch {}
}
function Z(e) {
	let t = () => {
		let t = e.querySelector("article.local-document");
		t && (t.classList.remove("local-static-first", "reactive-md-static-first", "reactive-md-hydrating"), t.removeAttribute("data-static-first"), t.removeAttribute("data-reactive-md-static-first")), e.classList.remove("local-static-first", "reactive-md-static-first"), e.removeAttribute("data-static-first");
	};
	if (typeof requestAnimationFrame != "function") return t(), () => {};
	let n = 0, r = 0;
	return n = requestAnimationFrame(() => {
		t(), r = requestAnimationFrame(t);
	}), () => {
		typeof cancelAnimationFrame == "function" && (cancelAnimationFrame(n), r && cancelAnimationFrame(r));
	};
}
function Q(e, r, i, a = {}) {
	if (!e || typeof e != "object" || !("nodeType" in e) || !e.hasAttribute) throw new x("Cannot mount a Reactive MD document: element must be an HTMLElement.", [v("standalone.element", "element must be an HTMLElement.")]);
	if (J(e)) throw new x("Cannot mount a Reactive MD document: this element is already mounted.", [v("standalone.mount", "The target element already hosts a Reactive MD document.")]);
	if (!r || typeof r != "object") throw new x("Cannot mount a Reactive MD document: options are required.", [v("standalone.options", "mount requires an options object with a source string.")]);
	let o = r.compileOptions;
	if (r.reactConfig) {
		if (o?.hostComponents !== void 0 || r.themes !== void 0) throw new x("Conflicting extension registration.", [v("local.extension.config", "reactConfig cannot be combined with hostComponents or themes.")]);
		if (o?.config && t(o.config).key !== r.reactConfig.config.key) throw new x("The export configuration differs from the installed bundle.", [v("local.extension.config", "Compile configuration does not match installed implementations.")]);
		o = {
			...o,
			config: r.reactConfig.config
		};
	}
	let c = p(r.extensions, r.reactConfig?.config);
	if (c.length) throw new x("Extension requirements are not satisfied.", c);
	let l = f(r.restoration, {
		config: r.reactConfig?.config ?? o?.config,
		source: r.source,
		resources: r.resources
	});
	if (l.length) throw new x("Restoration requirements are not satisfied.", l);
	let u = m(r.resources ?? []);
	if (u.diagnostics.length) throw new x("Style resources are invalid.", u.diagnostics);
	let d = B(r.source, r.state, a.theme, o, (e) => {
		let t = p(e.extensions, r.reactConfig?.config);
		if (t.push(...f(r.restoration, {
			config: r.reactConfig?.config ?? o?.config,
			source: r.source,
			resources: r.resources,
			document: e
		})), t.length) throw new x("Installed contracts must match before state recovery.", t);
	}), y = p(d.document.extensions, r.reactConfig?.config);
	if (y.length) throw new x("Installed extension implementations are required.", y);
	let C = o?.config, w = C?.key ?? d.document.componentConfigKey, T = C?.legacyKeys.map((e) => e.key) ?? [], E;
	try {
		E = s(d.document, {
			documentId: r.documentId,
			randomSeed: r.randomSeed,
			componentState: r.componentState,
			...w === void 0 ? {} : { configKey: w },
			...T.length === 0 ? {} : { legacyConfigKeys: T }
		});
	} catch (e) {
		throw new x("Cannot mount a Reactive MD document: the interactive runtime could not be created.", [v("standalone.runtime", b(e))]);
	}
	let D = r.generator ?? V, O = K(r.images), k = r.urlPolicy ?? O.urlPolicy, A = r.imageResolver ?? O.imageResolver, j = () => Y(E, D), M;
	try {
		M = j();
	} catch (e) {
		try {
			E.dispose();
		} catch {}
		throw new x("Cannot mount a Reactive MD document: the initial state could not be captured.", [v("standalone.state", b(e))]);
	}
	let N = !1, P = (e) => {
		N || X(a.onDiagnostics ? () => a.onDiagnostics(e) : void 0);
	}, F = (() => {
		try {
			return E.services?.state.diagnostics() ?? [];
		} catch {
			return [];
		}
	})(), I = r.hydrate === !0 && e.hasChildNodes(), L = /* @__PURE__ */ h(i, {
		document: d.document,
		runtime: E,
		onDiagnostics: P,
		urlPolicy: k,
		locale: r.locale ?? "en",
		themes: r.themes,
		reactConfig: r.reactConfig,
		colorScheme: r.colorScheme ?? "auto",
		mode: "interactive",
		staticFirst: I,
		imageResolver: A
	});
	if (!I) for (; e.firstChild;) e.removeChild(e.firstChild);
	let R = null, z = [];
	try {
		for (let [t, r] of u.resources.entries()) {
			let i = e.ownerDocument.createElement("style");
			i.setAttribute("data-reactive-md-resource", r.id), i.textContent = t === 0 ? `${n}\n${r.css}` : r.css, (e.ownerDocument.head ?? e.ownerDocument.documentElement).appendChild(i), z.push(i);
		}
		R = I ? _(e, L) : g(e), I || R.render(L);
	} catch (e) {
		z.forEach((e) => e.remove());
		try {
			R?.unmount();
		} catch {}
		try {
			E.dispose();
		} catch {}
		throw new x("Cannot mount a Reactive MD document: React could not render the document.", S(e, "standalone.render"));
	}
	q.add(e), e.setAttribute(H, "");
	let U = a.onStateChange ? E.subscribe(() => {
		if (N) return;
		let e;
		try {
			e = j();
		} catch {
			return;
		}
		X(a.onStateChange ? () => a.onStateChange(e) : void 0);
	}) : () => {};
	X(a.onStateChange ? () => a.onStateChange(M) : void 0), d.diagnostics.length > 0 && P(d.diagnostics), F.length > 0 && P([...F]);
	let W = I ? Z(e) : () => {};
	return {
		element: e,
		getState() {
			if (N) throw Error("This Reactive MD document has been unmounted.");
			return j();
		},
		unmount: () => {
			if (!N) {
				N = !0, U(), W(), z.forEach((e) => e.remove());
				try {
					R?.unmount();
				} catch {}
				try {
					E.dispose();
				} catch {}
				q.delete(e), e.getAttribute("data-reactive-md-mounted") === "" && e.removeAttribute(H);
			}
		}
	};
}
function $(e, t, n) {
	if (typeof console < "u" && typeof console.error == "function") try {
		console.error(`Reactive MD: ${n.map((e) => `[${e.code}] ${e.message}`).join(" ")}`);
	} catch {}
	let r = e.defaultView?.CustomEvent;
	if (typeof r == "function") try {
		t.dispatchEvent(new r(C, {
			detail: n,
			bubbles: !0,
			composed: !0
		}));
	} catch {}
}
function ee(e, t) {
	let n = t.defaultView?.HTMLElement;
	return n ? e instanceof n : e.namespaceURI === "http://www.w3.org/1999/xhtml";
}
function te(e, t, n = {}) {
	if (typeof document > "u") return [];
	let r = t ?? document, i = r, a = i.nodeType === 9 ? r : i.ownerDocument ?? document, o = [], s;
	try {
		s = Array.from(r.querySelectorAll(U));
	} catch {
		return o;
	}
	for (let t of s) {
		let s;
		try {
			s = z(JSON.parse(t.textContent ?? ""));
		} catch (e) {
			$(a, t, [v("standalone.payload.json", `The reactive-md payload is not valid JSON: ${b(e)}`)]);
			continue;
		}
		if (!s.ok) {
			$(a, t, s.diagnostics);
			continue;
		}
		let c = s.payload, l = r, u = (typeof l.getElementById == "function" ? l.getElementById(c.target) : null) ?? a.getElementById(c.target);
		if (!u) $(a, t, [v("standalone.target.missing", `The reactive-md payload target "#${c.target}" was not found.`)]);
		else if (i !== a && !i.contains(u)) $(a, t, [v("standalone.target.scope", "The reactive-md payload target is outside the scanned root.")]);
		else if (!ee(u, a)) $(a, t, [v("standalone.target.type", "The reactive-md payload target must be an HTML element.")]);
		else if (!J(u)) try {
			o.push(Q(u, {
				source: c.source,
				state: c.state,
				locale: c.locale,
				colorScheme: c.colorScheme,
				hydrate: c.hydrate,
				images: c.images,
				compileOptions: c.compileOptions,
				extensions: c.extensions,
				restoration: c.restoration,
				resources: c.resources,
				documentId: c.documentId,
				randomSeed: c.randomSeed,
				componentState: c.componentState,
				reactConfig: n.reactConfig
			}, e, { onDiagnostics: (e) => $(a, u, e) }));
		} catch (e) {
			$(a, u, S(e));
		}
	}
	return o;
}
export { z as a, x as c, te as i, Q as n, C as o, J as r, w as s, H as t };
