import { A as e, B as t, G as n, J as r, K as i, O as a, it as o } from "./preset-core-CKc5YXSM.js";
import { V as s, f as c, l, u } from "./config-validation-C5kJYk-J.js";
import { b as d } from "./validation-B58yB_8Z.js";
import { a as f, c as p, d as m, o as h, u as ee } from "./parser-standard-Be8iMC9W.js";
import { i as g, s as _ } from "./config-BUo-8O5C.js";
import { n as te } from "./options-BC_8M3La.js";
import { C as v, u as ne, w as re } from "./component-state-BoLCGee4.js";
import { n as y } from "./runtime-C5YjCBQc.js";
import { i as ie, t as b } from "./resources-IeJomeUT.js";
// src/local/runtime/state.ts
var x = "reactive-md-state/v1", S = 1048576, C = /^fnv1a32:[0-9a-f]{8}$/, w = /* @__PURE__ */ new Set([
	"format",
	"syntax",
	"sourceDigest",
	"parameters",
	"generator"
]), T = /* @__PURE__ */ new Set(["name", "version"]), ae = new TextEncoder();
function E(e, t) {
	return {
		code: e,
		message: t.length > 2e3 ? `${s(t, o - 1)}…` : t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function D(e, t, n) {
	e.length < 100 && e.push(E(t, n));
}
function O(e) {
	return e instanceof Error ? e.message : String(e);
}
function k(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function A(e) {
	if (typeof e == "string") return k(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "contains malformed Unicode."
	};
	if (typeof e == "number") return Number.isFinite(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "must be a finite number."
	};
	if (typeof e == "boolean" || e === null) return {
		ok: !0,
		value: e
	};
	if (Array.isArray(e)) {
		let t = [], n = e.length === 0 ? "string" : typeof e[0];
		for (let r = 0; r < e.length; r += 1) {
			let i = e[r];
			if (n === "string" && typeof i == "string") {
				if (!k(i)) return {
					ok: !1,
					message: "contains malformed Unicode."
				};
				t.push(i);
			} else if (n === "number" && typeof i == "number" && Number.isFinite(i)) t.push(i);
			else return {
				ok: !1,
				message: "must be an array of strings or finite numbers of one kind."
			};
		}
		return {
			ok: !0,
			value: Object.freeze(t)
		};
	}
	return {
		ok: !1,
		message: "must be a string, finite number, boolean, null or homogeneous primitive array."
	};
}
function j(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function M(e) {
	return Object.freeze(e.parameters), e.generator && Object.freeze(e.generator), Object.freeze(e);
}
function N(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("generator must be an object with string name and version.");
	if (typeof e.name != "string" || typeof e.version != "string") throw TypeError("generator must have string name and version.");
	if (!k(e.name) || !k(e.version)) throw TypeError("generator name and version must be well-formed Unicode strings.");
	return Object.freeze({
		name: e.name,
		version: e.version
	});
}
function P(e) {
	return typeof e == "string" ? `"${e.length > 48 ? `${s(e, 48)}…` : e}"` : e === null ? "null" : Array.isArray(e) ? "an array" : typeof e;
}
function F(e, t) {
	return e.length > t ? e.length : ae.encode(e).byteLength;
}
function oe(e, t) {
	let n;
	try {
		let t = JSON.stringify(e);
		if (typeof t != "string") return null;
		n = t;
	} catch {
		return null;
	}
	return F(n, t);
}
function se(e) {
	if (e === void 0) return S;
	if (typeof e != "object" || !e) throw TypeError("parseLocalState options must be an object.");
	let { maxLength: t } = e;
	if (t === void 0) return S;
	if (typeof t != "number" || !Number.isSafeInteger(t) || t <= 0) throw RangeError("maxLength must be a finite positive integer.");
	return t;
}
function I(e, t, n) {
	if (!e || e.syntax !== "local" || typeof e.source != "string") throw TypeError("createLocalStateFile requires a compiled local document.");
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("createLocalStateFile requires a state object.");
	let r = Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort(), i = new Set(r), a = /* @__PURE__ */ new Map();
	for (let n of Object.keys(t)) {
		if (Object.hasOwn(e.computations ?? {}, n)) continue;
		if (n.startsWith("@")) {
			if (!Object.hasOwn(e.bindings, n)) throw Error(`Cannot persist parameter "${n}": it is not a binding of this document.`);
			continue;
		}
		if (!i.has(n)) throw Error(`Cannot persist parameter "${n}": it is not a public binding of this document.`);
		let r = A(t[n]);
		if (!r.ok) throw TypeError(`Cannot persist parameter "${n}": the value ${r.message}`);
		a.set(n, r.value);
	}
	let o = {};
	for (let e of r) {
		if (!a.has(e)) throw Error(`Cannot persist the document: parameter "${e}" is missing from the supplied state.`);
		o[e] = a.get(e);
	}
	let s = {
		format: x,
		syntax: d,
		sourceDigest: v(e.source),
		parameters: o
	};
	return n !== void 0 && (s.generator = N(n)), M(s);
}
function ce(e, t) {
	let n = [], r = (e, t) => D(n, e, t), i = e;
	if (typeof e == "string") {
		if (F(e, t) > t) return {
			ok: !1,
			diagnostics: [E("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
		if (!k(e)) return {
			ok: !1,
			diagnostics: [E("local.state.utf", "The state payload contains malformed Unicode.")]
		};
		try {
			i = JSON.parse(e);
		} catch (e) {
			return {
				ok: !1,
				diagnostics: [E("local.state.json", `The state payload is not valid JSON: ${O(e)}`)]
			};
		}
	} else {
		let n = oe(e, t);
		if (n === null) return {
			ok: !1,
			diagnostics: [E("local.state.shape", "The state payload must be a JSON object.")]
		};
		if (n > t) return {
			ok: !1,
			diagnostics: [E("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
	}
	if (!j(i)) return {
		ok: !1,
		diagnostics: [E("local.state.shape", "The state payload must be a JSON object.")]
	};
	Object.getOwnPropertySymbols(i).length > 0 && r("local.state.shape", "The state payload cannot use symbol keys.");
	for (let e of Object.keys(i)) w.has(e) || r("local.state.key", `Unknown top-level state key "${e}".`);
	let a = i.format;
	a !== "reactive-md-state/v1" && r("local.state.format", `Unsupported state format ${P(a)}; expected "${x}".`);
	let o = i.syntax;
	o !== "local-draft-3" && r("local.state.syntax", `Unsupported state syntax ${P(o)}; expected "${d}".`);
	let s = i.sourceDigest;
	typeof s == "string" && C.test(s) || r("local.state.digest", "sourceDigest must match \"fnv1a32:\" followed by 8 lowercase hexadecimal digits.");
	let c = {}, l = i.parameters;
	if (!j(l)) r("local.state.parameters", "parameters must be a JSON object of public binding values.");
	else for (let e of Object.keys(l).sort()) {
		if (e === "__proto__") {
			r("local.state.parameter.prototype", "Parameter names cannot be \"__proto__\".");
			continue;
		}
		if (e.startsWith("@")) {
			r("local.state.parameter.internal", `Internal parameter "${e}" cannot be persisted.`);
			continue;
		}
		let t = A(l[e]);
		t.ok ? c[e] = t.value : r("local.state.parameter.value", `Parameter "${e}" ${t.message}`);
	}
	let u;
	if (Object.hasOwn(i, "generator")) {
		let e = i.generator;
		if (!j(e)) r("local.state.generator", "generator must be an object with string name and version.");
		else {
			for (let t of Object.keys(e)) T.has(t) || r("local.state.generator", `generator has unknown key "${t}".`);
			typeof e.name != "string" || typeof e.version != "string" ? r("local.state.generator", "generator must have string name and version.") : !k(e.name) || !k(e.version) ? r("local.state.utf", "generator contains malformed Unicode.") : u = Object.freeze({
				name: e.name,
				version: e.version
			});
		}
	}
	if (n.length) return {
		ok: !1,
		diagnostics: n
	};
	let f = {
		format: x,
		syntax: d,
		sourceDigest: s,
		parameters: c
	};
	return u && (f.generator = u), {
		ok: !0,
		file: M(f)
	};
}
function L(e, t) {
	let n = se(t);
	try {
		return ce(e, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [E("local.state.invalid", `Cannot read the local state: ${O(e)}`)]
		};
	}
}
function le(e) {
	let t = /* @__PURE__ */ new Map(), n = (e) => {
		for (let r of e) t.set(r.id, r), r.children && n(r.children);
	};
	return n(e.nodes), t;
}
function R(e) {
	let t = le(e), n = /* @__PURE__ */ new Map(), r = [];
	for (let [i, a] of Object.entries(e.bindingSlots ?? {})) {
		let e = t.get(i);
		if (!e) continue;
		let o = {
			node: e,
			slots: []
		};
		for (let [t, r] of Object.entries(a)) o.slots.push({
			slot: t,
			key: r
		}), r.startsWith("@") || n.set(r, {
			node: e,
			slot: t
		});
		o.slots.length && r.push(o);
	}
	let i = [];
	for (let [r, a] of Object.entries(e.bindings)) {
		if (r.startsWith("@")) continue;
		let e = n.get(r);
		if (e) {
			i.push({
				key: r,
				binding: a,
				node: e.node,
				slot: e.slot
			});
			continue;
		}
		let o = a.owner && t.has(a.owner) ? a.owner : a.nodeIds.find((e) => t.has(e));
		i.push({
			key: r,
			binding: a,
			node: o ? t.get(o) : void 0
		});
	}
	return {
		plans: i,
		groups: r
	};
}
function z(e, t, n) {
	let r = [], i = Object.create(null);
	for (let a of t.plans) a.slot === void 0 && Object.hasOwn(n, a.key) && (a.node ? Object.is(e.get(a.node), n[a.key]) || (i[a.key] = n[a.key]) : r.push(E("local.state.document", `The document has no component for parameter "${a.key}".`)));
	if (r.length) return r;
	r.push(...e.setParameters(i));
	for (let i of t.groups) {
		let t = {}, a = !1;
		for (let { slot: e, key: r } of i.slots) Object.hasOwn(n, r) && (t[e] = n[r], a = !0);
		a && r.push(...e.setMany(i.node, t));
	}
	return r;
}
function ue(e, t) {
	let n = e.snapshot(), r = {};
	for (let e of t) {
		let t = n.state[e];
		r[e] = Array.isArray(t) ? Object.freeze([...t]) : t;
	}
	return Object.freeze(r);
}
function B(e, t, n, r) {
	let i = L(t, r);
	if (!i.ok) return i;
	if (!e || e.syntax !== "local" || typeof e.source != "string" || !Array.isArray(e.nodes) || !e.bindings) return {
		ok: !1,
		diagnostics: [E("local.state.document", "resolveLocalState requires a compiled local document.")]
	};
	if (i.file.syntax !== "local-draft-3") return {
		ok: !1,
		diagnostics: [E("local.state.syntax", `This state file uses syntax "${i.file.syntax}", but this build accepts "${d}".`)]
	};
	if (i.file.sourceDigest !== v(e.source)) return {
		ok: !1,
		diagnostics: [E("local.state.source", "This state file was created for a different document (source digest mismatch).")]
	};
	let a = R(e), o = new Set(a.plans.map((e) => e.key)), s = [];
	for (let e of Object.keys(i.file.parameters)) o.has(e) || D(s, "local.state.parameter.unknown", `The state contains unknown parameter "${e}" for this document.`);
	for (let e of o) Object.hasOwn(i.file.parameters, e) || D(s, "local.state.parameter.missing", `The state is missing parameter "${e}".`);
	if (s.length) return {
		ok: !1,
		diagnostics: s
	};
	let c;
	try {
		c = y(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [E("local.state.document", `Cannot validate this document: ${O(e)}`)]
		};
	}
	try {
		if (n) {
			let e = z(c, a, n);
			if (e.length) return {
				ok: !1,
				diagnostics: e
			};
		}
		let e = z(c, a, i.file.parameters);
		if (e.length) return {
			ok: !1,
			diagnostics: e
		};
		let t = [...o].sort();
		return {
			ok: !0,
			file: i.file,
			state: ue(c, t)
		};
	} finally {
		c.dispose();
	}
}
function V(e, t, n) {
	try {
		return B(e, t, void 0, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [E("local.state.invalid", `Cannot resolve the local state: ${O(e)}`)]
		};
	}
}
function H(e, t, n) {
	let r;
	try {
		r = B(e.document, t, e.snapshot().state, n);
	} catch (e) {
		return [E("local.state.invalid", `Cannot apply the local state: ${O(e)}`)];
	}
	if (!r.ok) return r.diagnostics;
	let i = R(e.document);
	try {
		return z(e, i, r.state);
	} catch (e) {
		return [E("local.state.invalid", `Cannot apply the local state: ${O(e)}`)];
	}
}
function de(e, t) {
	return I(e.document, e.getParameters(), t);
}
function fe(e, t, n) {
	let r = L(t, n);
	return r.ok ? H(e, r.file, n) : r.diagnostics;
}
function pe(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("serializeLocalState requires a state file.");
	if (!e.parameters || typeof e.parameters != "object" || Array.isArray(e.parameters)) throw TypeError("serializeLocalState requires an object of parameters.");
	let t = Object.create(null);
	for (let n of Object.keys(e.parameters).sort()) {
		if (n === "__proto__" || n.startsWith("@")) throw TypeError(`Cannot serialize parameter "${n}".`);
		let r = A(e.parameters[n]);
		if (!r.ok) throw TypeError(`Cannot serialize parameter "${n}": the value ${r.message}`);
		t[n] = r.value;
	}
	let n = {
		format: e.format,
		syntax: e.syntax,
		sourceDigest: e.sourceDigest,
		parameters: t
	};
	if (e.generator !== void 0) {
		let t = N(e.generator);
		n.generator = {
			name: t.name,
			version: t.version
		};
	}
	return JSON.stringify(n);
}
// src/local/configuration/portable-options.ts
function U(e) {
	if (e === void 0) return;
	let t = te(e);
	if (!t.ok) throw TypeError(`Invalid portable compile options: ${t.message}`);
	return {
		enableCss: t.html.enableCss,
		enableJavaScript: t.html.enableJavaScript,
		enableExtendedHtml: t.html.enableExtendedHtml,
		...Object.hasOwn(e, "strict") && e.strict !== void 0 ? { strict: t.strict } : {},
		...e.markdownBreaks === void 0 ? {} : { markdownBreaks: t.markdownBreaks },
		...e.config === void 0 ? t.hostComponents.length ? { hostComponents: t.hostComponents } : {} : { config: _(e.config) },
		...e.limits === void 0 ? {} : { limits: {
			...e.limits.maxSyntaxNodes === void 0 ? {} : { maxSyntaxNodes: t.maxSyntaxNodes },
			...e.limits.maxParseWork === void 0 ? {} : { maxParseWork: t.maxParseWork },
			...e.limits.maxMarkdownDepth === void 0 ? {} : { maxMarkdownDepth: t.maxMarkdownDepth }
		} }
	};
}
// src/export/restoration.ts
var me = r;
function W(e) {
	return r(JSON.stringify([
		e.id,
		e.name,
		e.version,
		e.protocol,
		e.colorSchemes,
		e.css.map(({ id: e, css: t }) => [e, t])
	]));
}
function he(e, n) {
	let i = _(n), a = l(i);
	return Object.freeze({
		protocol: "reactive-md-bundle/v1",
		sdkVersion: t,
		configKey: i.key,
		scriptDigest: r(e),
		assembly: a,
		seal: u(i),
		themes: Object.freeze(i.themes.map((e) => Object.freeze({
			id: e.id,
			name: e.name,
			version: e.version,
			digest: W(e)
		})))
	});
}
function G(e, n, i, o = []) {
	let s = _(n), c = /* @__PURE__ */ new Set(), u = [...e.nodes];
	for (; u.length;) {
		let e = u.pop();
		(e.type === "component" || e.type === "hostComponent") && e.name && c.add(e.name), e.children && u.push(...e.children);
	}
	let d = s.registry.filter((e) => c.has(e.name)).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		range: e.version,
		digest: a(e)
	})).sort((e, t) => e.id.localeCompare(t.id)), f = s.themes.filter((t) => t.name === e.theme).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: W(e)
	}));
	return Object.freeze({
		protocol: "reactive-md-restore/v1",
		sdk: `^${t}`,
		configKey: s.key,
		sourceDigest: r(e.source),
		target: i,
		components: Object.freeze(d),
		themes: Object.freeze(f),
		assembly: l(s),
		resources: Object.freeze(o.map((e) => Object.freeze({
			id: e.id,
			digest: r(e.css)
		})))
	});
}
function K(e) {
	return typeof e == "object" && !!e && !Array.isArray(e) && [Object.prototype, null].includes(Object.getPrototypeOf(e));
}
function q(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 256;
}
function J(o, s) {
	if (o === void 0) return [];
	let l = [], u = (e, t) => l.push({
		code: `local.extension.restore-${e}`,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	});
	try {
		if (!K(o) || e(o) > 262144 || o.protocol !== "reactive-md-restore/v1" || !q(o.sdk) || !q(o.configKey) || !q(o.sourceDigest) || ![
			"static",
			"ssr",
			"offline"
		].includes(o.target) || !Array.isArray(o.components) || o.components.length > 192 || !Array.isArray(o.themes) || o.themes.length > 16 || !Array.isArray(o.resources) || o.resources.length > 128) return u("metadata", "Invalid or oversized restoration requirements."), l;
		let d = /* @__PURE__ */ new Set([
			"protocol",
			"sdk",
			"configKey",
			"sourceDigest",
			"target",
			"components",
			"themes",
			"resources",
			"assembly"
		]);
		Object.keys(o).some((e) => !d.has(e)) && u("metadata", "Unknown restoration requirement field.");
		let f = s.config === void 0 ? g() : _(s.config);
		i(o.sdk) && n("0.7.0", o.sdk) || u("sdk", `SDK ${t} does not satisfy ${o.sdk}.`), c(f, o.configKey) || u("config", "The installed configuration differs from the exported configuration."), o.assembly !== void 0 && (K(o.assembly) && o.assembly.protocol === "reactive-md-assembly-seal/v1" && q(o.assembly.configKey) && c(f, o.assembly.configKey) || u("assembly", "The exported assembly identity is invalid or belongs to another configuration.")), r(s.source) !== o.sourceDigest && u("source", "The source differs from the exported source. Recompile before restoring state.");
		let p = /* @__PURE__ */ new Set();
		for (let e of o.components) {
			if (!K(e) || ![
				"id",
				"name",
				"version",
				"range",
				"digest"
			].every((t) => q(e[t])) || !i(e.range) || p.has(e.id)) {
				u("metadata", "Invalid or duplicate component restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = f.registry.find((t) => t.id === e.id);
			if (!t) {
				u("component-missing", `Required component ${e.id}@${e.version} is not installed.`);
				continue;
			}
			n(t.version, e.range) || u("version", `Component ${e.id}@${t.version} does not satisfy ${e.range}.`), (t.version !== e.version || t.name !== e.name || a(t) !== e.digest) && u("contract", `Component ${e.id}@${e.version} differs from the installed contract. Recompile and validate state before upgrading.`);
			let r = o.target === "offline" ? [
				"interactive",
				"static",
				"offline"
			] : [o.target];
			for (let n of r) t.capabilities[n] || u("capability", `Component ${e.id} cannot render ${n}.`);
		}
		if (s.document) {
			let e = G(s.document, f, o.target);
			for (let t of e.components) p.has(t.id) || u("component-missing", `Used component ${t.id} is missing from restoration requirements.`);
		}
		p.clear();
		for (let e of o.themes) {
			if (!K(e) || ![
				"id",
				"name",
				"version",
				"digest"
			].every((t) => q(e[t])) || p.has(e.id)) {
				u("metadata", "Invalid or duplicate theme restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = f.themes.find((t) => t.id === e.id);
			t && t.name === e.name && t.version === e.version && W(t) === e.digest || u("theme", `Required theme ${e.id}@${e.version} does not match the installed theme.`);
		}
		if (s.document) {
			let e = f.themes.find((e) => e.name === s.document.theme);
			e && !p.has(e.id) && u("theme", `Selected theme ${e.id} is missing from restoration requirements.`);
		}
		let m = b(s.resources ?? []);
		l.push(...m.diagnostics);
		let h = new Map(m.resources.map((e) => [e.id, e.css]));
		p.clear();
		for (let e of o.resources) {
			if (!K(e) || !q(e.id) || !q(e.digest) || p.has(e.id)) {
				u("metadata", "Invalid or duplicate style restoration requirement.");
				continue;
			}
			p.add(e.id);
			let t = h.get(e.id);
			t === void 0 ? u("resource-missing", `Required style resource ${e.id} is missing before state restoration.`) : r(t) !== e.digest && u("resource-digest", `Style resource ${e.id} differs from the exported content.`);
		}
		if (s.document) {
			let e = G(s.document, f, o.target), t = new Set(e.components.map((e) => e.id)), n = f.registry.filter((e) => t.has(e.id)).flatMap((e) => e.styles ?? []);
			n.push(...f.themes.filter((e) => e.name === s.document.theme).flatMap((e) => e.css.map((e) => e.id)));
			for (let e of n) p.has(e) && h.has(e) || u("resource-missing", `Used style resource ${e} is required before state restoration.`);
		}
	} catch (e) {
		u("metadata", e instanceof Error ? e.message : String(e));
	}
	return l;
}
// src/shareable.ts
var Y = "reactive-md-html/v1", X = "reactive-md-html/v2", ge = /^[A-Za-z][A-Za-z0-9_-]*$/, _e = /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/, ve = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, ye = /[\u0000-\u001f\u007f-\u009f]/, be = 64, xe = 41943040, Se = 4096;
function Z(e, t = !1) {
	let n = e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return t && (n = n.replace(/"/g, "&quot;").replace(/'/g, "&#39;")), n;
}
function Ce(e) {
	return e.replace(/<\/style/gi, "<\\/style");
}
function we(e) {
	return e.replace(/<\/script/gi, "<\\/script").replace(/<!--/g, "<\\!--");
}
function Q(e) {
	return Z(e, !0);
}
function Te(e) {
	let t = JSON.stringify(e);
	if (typeof t != "string") throw TypeError("Cannot serialize a non-JSON value for an inline script.");
	return t.replace(/[<>&\u2028\u2029]/g, (e) => {
		switch (e) {
			case "<": return "\\u003c";
			case ">": return "\\u003e";
			case "&": return "\\u0026";
			case "\u2028": return "\\u2028";
			default: return "\\u2029";
		}
	});
}
function Ee(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function De(e) {
	try {
		return U(e);
	} catch (e) {
		throw TypeError(`createShareableHtml received invalid compileOptions: ${e instanceof Error ? e.message : String(e)}`);
	}
}
function $(e) {
	let t = [];
	for (let n of e.childNodes) {
		if (m.isElementNode(n)) {
			let e = n.tagName.toLowerCase();
			if (e === "script") continue;
			$(e === "template" ? m.getTemplateContent(n) : n);
		}
		t.push(n);
	}
	e.childNodes = t;
}
function Oe(e, t, n) {
	let r = !1;
	for (let i of e.childNodes) if (m.isElementNode(i)) {
		if (i.tagName.toLowerCase() === "iframe") {
			let e = i.attrs.filter((e) => {
				let t = e.name.toLowerCase();
				return t !== "srcdoc" && t !== "sandbox";
			});
			e.push({
				name: "srcdoc",
				value: t
			}), e.push({
				name: "sandbox",
				value: n
			}), i.attrs = e, r = !0;
		}
		Oe(i, t, n) && (r = !0);
	}
	return r;
}
function ke(e) {
	let t = "";
	for (let n of e.childNodes) t += ee(n, { scriptingEnabled: !1 });
	return t;
}
function Ae(e, t, n) {
	try {
		let r = p(e, { scriptingEnabled: !1 });
		if ($(r), Oe(r, t, n)) return ke(r);
	} catch {}
	return `<div class="reactive-md-native-document"><iframe class="reactive-md-native-frame" title="Reactive MD document" sandbox="${Z(n, !0)}" style="display:block;width:100%;min-height:60vh;border:0;background:#fff" srcdoc="${Z(t, !0)}"></iframe></div>`;
}
function je(e, t) {
	let n = t?.enableExtendedHtml === !0, r = t ? `frame-src about:${n ? " data: blob: http: https:" : ""}` : "frame-src 'none'", i = n ? "base-uri 'self' http: https:" : "base-uri 'none'", a = n ? "form-action http: https:" : "form-action 'none'";
	return e ? `default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; font-src data:; connect-src 'none'; media-src 'none'; object-src 'none'; ${r}; ${i}; ${a}` : `default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:; object-src 'none'; ${r}; ${i}; ${a}`;
}
function Me(e) {
	if (e === void 0) return;
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("images must be an object mapping relative URLs to data: image URLs.");
	let t = Object.entries(e);
	if (t.length > be) throw RangeError(`images cannot contain more than ${be} entries.`);
	let n = 0;
	for (let [e, r] of t) {
		if (!e || e.length > Se || ye.test(e) || e === "__proto__") throw TypeError("Every image key must be a bounded, control-free URL.");
		if (typeof r != "string" || !ve.test(r)) throw TypeError(`The image map for "${e}" must contain a base64 PNG, JPEG, GIF or WebP data URL.`);
		if (n += r.length, n > xe) throw RangeError("The embedded image map exceeds the 40 MiB budget.");
	}
	return Object.fromEntries(t);
}
function Ne(e, t) {
	let n = V(e, t);
	if (!n.ok) return n;
	let r = {};
	for (let [t, i] of Object.entries(e.bindings)) r[t] = Object.hasOwn(n.state, t) ? {
		...i,
		initial: Ee(n.state[t])
	} : i;
	let i = { ...e.initialState };
	for (let [e, t] of Object.entries(n.state)) i[e] = Ee(t);
	return {
		ok: !0,
		baseline: {
			document: {
				...e,
				bindings: r,
				initialState: i
			},
			state: n.state
		}
	};
}
var Pe = "\n:root { color-scheme: light; background: #f5f7fb; }\nhtml, body { margin: 0; }\nbody.reactive-md-export {\n  min-height: 100vh;\n  padding: clamp(16px, 4vw, 48px);\n  background: #f5f7fb;\n  color: #17233d;\n  font-family: system-ui, -apple-system, \"Segoe UI\", sans-serif;\n}\n.reactive-md-export-root { max-width: 840px; margin: 0 auto; }\n@media print {\n  :root, html, body.reactive-md-export { background: #fff !important; }\n  body.reactive-md-export { min-height: 0; padding: 0 !important; }\n  .reactive-md-export-root { max-width: none !important; margin: 0 !important; }\n}\n";
function Fe(e) {
	let t = e.targetId ?? "reactive-md-document";
	if (!ge.test(t)) throw TypeError("targetId must start with a letter and contain only letters, digits, underscores or hyphens.");
	let n = e.mode === "static" ? "static" : "interactive";
	if (!e.staticMarkup.trim()) throw TypeError("createShareableHtml requires rendered document markup.");
	if (!e.css.trim()) throw TypeError("createShareableHtml requires the document stylesheet.");
	if (e.state.sourceDigest !== v(e.source)) throw Error("The state file does not belong to the exported source.");
	if (n === "interactive" && !e.runtimeScript?.trim()) throw TypeError("Interactive HTML requires the standalone runtime script.");
	let r = De(e.compileOptions), i = ie(e.extensions, r?.config);
	if (i.push(...J(e.restoration, {
		config: r?.config,
		source: e.source,
		resources: e.resources
	})), i.length) throw TypeError(i.map((e) => e.message).join(" "));
	let a = te(r);
	if (!a.ok) throw TypeError(`createShareableHtml received invalid compileOptions: ${a.message}`);
	let o = a.htmlActive, s = e.documentId === void 0 ? void 0 : re(e.documentId);
	if (e.documentId !== void 0 && s === void 0) throw TypeError("createShareableHtml received an invalid documentId.");
	let c;
	if (e.randomSeed !== void 0) {
		if (!Number.isInteger(e.randomSeed) || e.randomSeed < 0 || e.randomSeed > 4294967295) throw TypeError("createShareableHtml received an invalid randomSeed; expected a 32-bit unsigned integer.");
		c = e.randomSeed;
	}
	let l;
	if (e.componentState !== void 0) {
		let t = ne(e.componentState);
		if (!t.ok || t.diagnostics.length > 0) {
			let e = t.diagnostics.map((e) => e.message).join(" ");
			throw TypeError(`createShareableHtml received an invalid component state${e ? `: ${e}` : "."}`);
		}
		l = t.document;
	}
	let u = e.staticMarkup;
	if (o && (n === "static" || !a.html.enableJavaScript)) {
		let t = {
			enableCss: a.html.enableCss,
			enableJavaScript: !1,
			enableExtendedHtml: a.html.enableExtendedHtml
		}, n = h(e.source, t, a.maxSyntaxNodes);
		if (!n.markup) throw Error("The native HTML document could not be regenerated without author JavaScript.");
		u = Ae(e.staticMarkup, n.markup, f(t));
	}
	let d = e.locale === "zh" ? "zh" : "en", p = d === "zh" ? "zh-CN" : "en", m = e.colorScheme === "light" || e.colorScheme === "dark" ? e.colorScheme : "auto", ee = e.assets === "omit" ? "omit" : "inline", g = e.generator ?? {
		name: "reactive-md",
		version: "unknown"
	}, _ = Me(e.images), y = Number.isSafeInteger(e.imageCount) && (e.imageCount ?? 0) > 0 ? String(e.imageCount) : String(Object.keys(_ ?? {}).length), b = n === "interactive", x = {
		version: e.restoration ? 2 : 1,
		target: t,
		source: e.source,
		state: e.state,
		locale: d,
		colorScheme: m,
		hydrate: !0,
		...r === void 0 ? {} : { compileOptions: r },
		...e.extensions === void 0 ? {} : { extensions: e.extensions },
		...e.restoration === void 0 ? {} : {
			restoration: e.restoration,
			resources: e.resources ?? []
		},
		..._ ? { images: _ } : {},
		...s === void 0 ? {} : { documentId: s },
		...c === void 0 ? {} : { randomSeed: c },
		...l === void 0 ? {} : { componentState: l }
	}, S = je(b, o ? a.html : void 0), C = b ? `<script type="application/reactive-md+json" data-reactive-md-auto>${Te(x)}<\/script>
<script>${we(e.runtimeScript)}<\/script>` : "", w = e.notices?.trim() ? `<template id="reactive-md-notices"><pre>${Z(e.notices)}</pre></template>` : "", T = !b && e.extensions ? `<template id="reactive-md-extensions">${Z(JSON.stringify(e.extensions))}</template>` : "";
	return `<!doctype html>
<html lang="${Z(_e.test(p) ? p : "en", !0)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="${Q(S)}">
<meta name="generator" content="${Q(`${g.name} ${g.version}`)}">
<meta name="reactive-md-html-format" content="${e.restoration ? X : Y}">
<meta name="reactive-md-syntax" content="${Q(e.state.syntax)}">
<meta name="reactive-md-output" content="${n}">
<meta name="reactive-md-state" content="${Q(e.state.sourceDigest)}">
<meta name="reactive-md-images" content="${ee}">
<meta name="reactive-md-image-count" content="${y}">
<title>${Z(e.title || "Reactive MD document")}</title>
<style>${Ce(e.css)}${Pe}</style>
</head>
<body class="reactive-md-export">
<div id="${t}" class="reactive-md-export-root">${u}</div>
${C}
${T}
${w}
</body>
</html>
`;
}
export { L as _, Te as a, me as c, U as d, x as f, fe as g, de as h, Ne as i, W as l, I as m, X as n, he as o, H as p, Fe as r, G as s, Y as t, J as u, V as v, pe as y };
