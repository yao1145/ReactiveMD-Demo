import { o as e } from "./preset-core-DeZPA8IE.js";
import { d as t, g as n, i as r, l as i, m as a, n as o, r as s, s as c, t as l, u } from "./controls-DtBXKDHu.js";
import { t as d } from "./plugin-packs-Bh1HhLym.js";
import { t as f } from "./mount-preset-DlKD1LQa.js";
// src/components/plugins/forms.ts
var p = {
	"range-slider": n,
	checkbox: l,
	choices: s,
	"radio-group": t,
	"multi-select": c,
	progress: i,
	timer: a,
	quiz: u,
	counter: r,
	checklist: o
}, m = d("reactive-md/forms", Object.keys(p), [e]), h = f(m, p);
export { h as default };
