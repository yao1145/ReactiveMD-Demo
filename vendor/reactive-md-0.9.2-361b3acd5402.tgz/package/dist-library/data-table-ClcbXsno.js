import { C as e } from "./version-DAxuGOG2.js";
import { t } from "./compile-Dx6Uw3D9.js";
import { I as n, L as r, P as i } from "./sdk-core-CrFjF3DQ.js";
import { jsx as a, jsxs as o } from "react/jsx-runtime";
// src/components/table/data-table.tsx
var s = class extends Error {
	failure;
	constructor(e) {
		super(e), this.name = "DataTableFailureError", this.failure = e;
	}
};
function c(e) {
	return e === null ? "" : typeof e == "string" ? e : typeof e == "number" ? Number.isFinite(e) ? String(e) : null : typeof e == "boolean" ? e ? "true" : "false" : null;
}
function l(e) {
	return typeof e == "string" ? e === "" ? null : `s:${e}` : typeof e == "number" && Number.isFinite(e) ? `n:${e === 0 ? 0 : e}` : null;
}
function u(e, t, n) {
	let r = { ...n };
	for (let i of t) Object.hasOwn(n, i) || Object.defineProperty(r, i, {
		enumerable: !0,
		configurable: !0,
		get() {
			return e.evaluate(i);
		}
	});
	return r;
}
function d(e) {
	if (e.length === 0) return null;
	let t = typeof e[0];
	if (t !== "string" && t !== "number") return "rows";
	for (let n of e) if (typeof n !== t || typeof n == "number" && !Number.isFinite(n)) return "rows";
	return null;
}
function f(e, n) {
	let r;
	try {
		r = t(n);
	} catch {
		throw new s("rows");
	}
	let i;
	try {
		i = r.evaluate(u(e, r.dependencies, {}));
	} catch {
		throw new s("rows");
	}
	if (!Array.isArray(i)) throw new s("rows");
	let a = d(i);
	if (a) throw new s(a);
	return i;
}
function p(e) {
	let { rows: n, columns: r, keyExpression: i, runtime: a } = e, o = e.maxRows ?? 100, f = e.budget ?? 1e5;
	if (!Number.isSafeInteger(o) || o <= 0 || o > 1e3) return {
		ok: !1,
		failure: "max-rows"
	};
	if (r.length < 1 || r.length > 20) return {
		ok: !1,
		failure: "columns"
	};
	let p = d(n);
	if (p) return {
		ok: !1,
		failure: p
	};
	if (n.length > o) return {
		ok: !1,
		failure: "rows-budget"
	};
	let m;
	try {
		m = t(i);
	} catch {
		return {
			ok: !1,
			failure: "key"
		};
	}
	let h = m.dependencies;
	if (h.length !== 1 || h[0] !== "item") return {
		ok: !1,
		failure: "key"
	};
	let g = r.map((e) => {
		try {
			return {
				spec: e,
				expression: t(e.value)
			};
		} catch {
			return {
				spec: e,
				expression: null
			};
		}
	}), _ = 0;
	for (let e of r) _ += e.label.length;
	if (n.length === 0 && (_ += 7), _ > f) return {
		ok: !1,
		failure: "text-budget"
	};
	let v = (e) => {
		if (_ += e, _ > f) throw new s("text-budget");
	}, y = /* @__PURE__ */ new Set(), b = [];
	try {
		for (let e = 0; e < n.length; e += 1) {
			let t = {
				item: n[e],
				index: e
			}, r = null;
			try {
				r = l(m.evaluate(t));
			} catch {
				return {
					ok: !1,
					failure: "key"
				};
			}
			if (r === null || y.has(r)) return {
				ok: !1,
				failure: "key"
			};
			v(r.length), y.add(r);
			let i = [];
			for (let e of g) {
				if (!e.expression) {
					v(14), i.push({
						ok: !1,
						text: ""
					});
					continue;
				}
				let n = null;
				try {
					n = c(e.expression.evaluate(u(a, e.expression.dependencies, t)));
				} catch {
					n = null;
				}
				n === null ? (v(14), i.push({
					ok: !1,
					text: ""
				})) : (v(n.length), i.push({
					ok: !0,
					text: n
				}));
			}
			b.push({
				key: r,
				cells: i
			});
		}
	} catch (e) {
		return e instanceof s ? {
			ok: !1,
			failure: e.failure
		} : {
			ok: !1,
			failure: "rows"
		};
	}
	return {
		ok: !0,
		model: {
			columns: r.map((e) => e.label),
			rows: b,
			empty: n.length === 0
		}
	};
}
function m(t, n) {
	switch (n) {
		case "label": return t("Data table requires a label.", "数据表需要标签。");
		case "columns": return t("Data table requires between 1 and 20 column definitions.", "数据表需要 1 到 20 个列定义。");
		case "max-rows": return t(`max-rows must be a positive integer no greater than ${e}.`, `max-rows 必须是 1 到 ${e} 之间的整数。`);
		case "rows": return t("Rows must evaluate to a list.", "行数据必须计算为列表。");
		case "rows-budget": return t("Too many rows for this table.", "此数据表的行数超过上限。");
		case "key": return t("Every row needs a unique, non-empty key.", "每一行都需要唯一且非空的键。");
		case "text-budget": return t("The table content exceeds the text budget.", "数据表内容超过文本上限。");
	}
}
var h = /^\s*\{\{([\s\S]*)\}\}\s*$/;
function g(e) {
	if (e === void 0) return null;
	let t = h.exec(e), n = t ? t[1].trim() : "";
	return n === "" ? null : n;
}
function _(e) {
	return e.kind === "comment" || e.kind === "text" && e.text.trim() === "" || e.kind === "paragraph" && e.children.length === 0 && e.text.trim() === "";
}
function v(e) {
	let t = i(e, "label", "").trim();
	if (t === "") return {
		ok: !1,
		failure: "label"
	};
	let n = g(e.content.attrs.rows);
	if (!n) return {
		ok: !1,
		failure: "rows"
	};
	let r = g(e.content.attrs.key);
	if (!r) return {
		ok: !1,
		failure: "key"
	};
	let a = e.content.attrs["max-rows"], o = 100;
	if (a !== void 0 && (!/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(a.trim()) || (o = Number(a.trim()), !Number.isSafeInteger(o) || o <= 0 || o > 1e3))) return {
		ok: !1,
		failure: "max-rows"
	};
	let s = e.content.children.filter((e) => !_(e)), c = [];
	for (let e of s) {
		let t = e.children.filter((e) => !_(e));
		if (e.kind !== "component" || e.name !== "column" || t.length > 0) return {
			ok: !1,
			failure: "columns"
		};
		let n = (e.attrs.label ?? "").trim(), r = g(e.attrs.value);
		if (n === "" || !r) return {
			ok: !1,
			failure: "columns"
		};
		c.push({
			label: n,
			value: r
		});
	}
	return c.length < 1 || c.length > 20 ? {
		ok: !1,
		failure: "columns"
	} : {
		ok: !0,
		table: {
			label: t,
			rows: n,
			key: r,
			maxRows: o,
			columns: c
		}
	};
}
function y(e) {
	let t = n(e), i = r(e), c = v(e);
	if (!c.ok) return /* @__PURE__ */ a("div", {
		...t(),
		className: "local-error local-data-table-error",
		role: "alert",
		children: m(i.t, c.failure)
	});
	let l = { evaluate: (t) => e.runtime.evaluate(t) }, u;
	try {
		u = p({
			rows: f(l, c.table.rows),
			columns: c.table.columns,
			keyExpression: c.table.key,
			maxRows: c.table.maxRows,
			runtime: l
		});
	} catch (e) {
		u = {
			ok: !1,
			failure: e instanceof s ? e.failure : "rows"
		};
	}
	if (!u.ok) return /* @__PURE__ */ a("div", {
		...t(),
		className: "local-error local-data-table-error",
		role: "alert",
		children: m(i.t, u.failure)
	});
	let { model: d } = u;
	return /* @__PURE__ */ a("div", {
		...t(),
		className: "md-table-scroll local-data-table-scroll",
		"data-local-data-table": "",
		children: /* @__PURE__ */ o("table", {
			className: "md-table local-data-table",
			"aria-label": c.table.label,
			children: [/* @__PURE__ */ a("thead", { children: /* @__PURE__ */ a("tr", { children: d.columns.map((e, t) => /* @__PURE__ */ a("th", {
				scope: "col",
				children: e
			}, `column-${t}`)) }) }), /* @__PURE__ */ a("tbody", { children: d.empty ? /* @__PURE__ */ a("tr", { children: /* @__PURE__ */ a("td", {
				className: "local-data-table-empty",
				colSpan: d.columns.length,
				children: i.t("No rows", "没有数据")
			}) }) : d.rows.map((e) => /* @__PURE__ */ a("tr", { children: e.cells.map((e, t) => /* @__PURE__ */ a("td", { children: e.ok ? e.text : /* @__PURE__ */ a("span", {
				className: "local-error local-data-table-cell-error",
				children: i.t("Cannot compute", "无法计算")
			}) }, `cell-${t}`)) }, e.key)) })]
		})
	});
}
export { y as t };
