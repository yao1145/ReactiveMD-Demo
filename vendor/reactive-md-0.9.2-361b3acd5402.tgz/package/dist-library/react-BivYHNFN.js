import { n as e } from "./sdk-core-CrFjF3DQ.js";
import { a as t } from "./LocalDocumentView-pzlKEVjH.js";
// src/react/sdk.tsx
function n(n, r) {
	return e(n, r, t().components);
}
export { n as t };
