import { s as e } from "./version-DAxuGOG2.js";
import { G as t } from "./sdk-core-CrFjF3DQ.js";
import { r as n } from "./package-core-CfK15chH.js";
// src/components/mount-preset.ts
function r(r, i, a = []) {
	return n({
		protocol: e,
		preset: r,
		components: r.components.map((e) => t(e, { render: i[e.name] })),
		resources: a
	});
}
export { r as t };
