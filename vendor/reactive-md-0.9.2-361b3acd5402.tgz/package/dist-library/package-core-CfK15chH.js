import { n as e, s as t } from "./version-DAxuGOG2.js";
import { O as n, T as r } from "./preset-core-DeZPA8IE.js";
import { f as i, i as a, y as o } from "./config-DXLvctiZ.js";
import { t as s } from "./resources-DrSG608b.js";
import { G as c, n as l } from "./sdk-core-CrFjF3DQ.js";
// src/react/package-core.ts
function u(e) {
	let t = s(e);
	if (t.diagnostics.length) throw TypeError(t.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	return t.resources;
}
function d(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("defineReactPreset requires a preset package object.");
	if (e.protocol !== "reactive-md-react-preset/v1") throw TypeError(`React preset protocol must be "${t}".`);
	let r = i(e.preset);
	if (!Array.isArray(e.components)) throw TypeError("React preset components must be an array.");
	let a = new Map(r.components.map((e) => [e.id, e])), o = /* @__PURE__ */ new Set(), s = [];
	for (let t of e.components) {
		let e = t?.definition;
		if (!e || typeof e.id != "string") throw TypeError("React preset contains a component without a manifest definition.");
		let i = a.get(e.id);
		if (!i) throw TypeError(`React preset "${r.id}" has no semantic component "${e.id}".`);
		if (n(i) !== n(e) || t.digest !== n(e)) throw TypeError(`React preset component "${e.id}" does not match its semantic manifest.`);
		if (o.has(e.id)) throw TypeError(`React preset "${r.id}" declares "${e.id}" more than once.`);
		o.add(e.id), s.push(t);
	}
	let c = r.components.filter((e) => !o.has(e.id)).map((e) => e.id);
	if (c.length > 0) throw TypeError(`React preset "${r.id}" is missing implementations for: ${c.join(", ")}.`);
	let l = e.resources === void 0 ? Object.freeze([]) : u(e.resources);
	return Object.freeze({
		protocol: t,
		preset: r,
		components: Object.freeze(s),
		resources: l,
		...e.notices === void 0 ? {} : { notices: Object.freeze([...e.notices]) }
	});
}
function f(t) {
	let { render: n, renderStatic: i, css: a, resources: o = [], ...s } = t, l = s.styles ?? [...new Set(a === void 0 ? o.map((e) => e.id) : [`${s.id}.css`, ...o.map((e) => e.id)])];
	if (a !== void 0 && l.length === 0) throw TypeError("Inline css requires a style resource identity.");
	let d = r({
		...s,
		protocol: s.protocol === void 0 ? e : s.protocol,
		form: s.form === void 0 ? "leaf" : s.form,
		props: s.props === void 0 ? {} : s.props,
		...l.length ? { styles: l } : {}
	});
	if (a !== void 0 && typeof a != "string") throw TypeError("Component css must be an inline string.");
	let f = u([...a === void 0 ? [] : [{
		id: l[0] ?? `${d.id}.css`,
		css: a
	}], ...o]);
	for (let e of d.styles ?? []) if (!f.some((t) => t.id === e)) throw TypeError(`Component ${d.id} is missing style resource ${e}.`);
	let p = c(d, {
		render: n,
		...i === void 0 ? {} : { renderStatic: i }
	});
	return Object.freeze({
		definition: d,
		components: Object.freeze([p]),
		resources: f
	});
}
function p(e, t, n, r) {
	let i = /* @__PURE__ */ new Map(), a = (e, t) => {
		let n = i.get(e.id);
		if (n !== void 0 && n !== e.css) throw TypeError(`Style resource "${e.id}" has conflicting contents in ${t}.`);
		n === void 0 && i.set(e.id, e.css);
	};
	for (let e of u(t)) a(e, "a component or preset package");
	for (let e of u(n)) a(e, "host resources");
	for (let e of r) for (let t of e.css) a(t, `theme "${e.id}"`);
	let o = [], s = /* @__PURE__ */ new Set();
	for (let t of e.registry) for (let e of t.styles ?? []) {
		if (s.has(e)) continue;
		let n = i.get(e);
		if (n === void 0) throw TypeError(`Component ${t.id} is missing style resource ${e}.`);
		s.add(e), o.push(Object.freeze({
			id: e,
			css: n
		}));
	}
	for (let e of n) {
		if (s.has(e.id)) continue;
		let t = i.get(e.id);
		s.add(e.id), o.push(Object.freeze({
			id: e.id,
			css: t
		}));
	}
	for (let e of r) for (let t of e.css) s.has(t.id) || (s.add(t.id), o.push(Object.freeze({
		id: t.id,
		css: t.css
	})));
	return Object.freeze(o);
}
function m(e, t) {
	let n = e.presets, r = (n ?? ["default"]).map((e) => e === "default" ? t.preset : e.preset), i = n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.components), s = n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.resources ?? []), c = e.packages ?? [], u = [...c.flatMap((e) => e.components), ...e.components ?? []], d = a({
		presets: r,
		components: u.map((e) => e.definition),
		...e.replacements === void 0 ? {} : { replacements: e.replacements },
		themes: [...c.flatMap((e) => e.themes ?? []), ...e.themes ?? []]
	}), f = l(d, { components: [...i, ...u] }, n === void 0 || n.includes("default") ? t.components : []), m = p(d, c.flatMap((e) => e.resources ?? []), [...s, ...e.resources ?? []], d.themes), h = Object.freeze([
		...n === void 0 ? [] : n.flatMap((e) => e === "default" ? [] : e.notices ?? []),
		...c.flatMap((e) => e.notices ?? []),
		...e.notices ?? []
	]);
	return Object.freeze({
		config: f.config,
		reactConfig: f,
		compileOptions: Object.freeze({ config: f.config }),
		resources: m,
		css: `${o}\n${m.map((e) => e.css).join("\n")}`,
		notices: h
	});
}
export { f as n, d as r, m as t };
