import { type LocalComponentDefinition } from '../sdk/types.js';
/**
 * The rendered/structural components of the default preset, in declaration
 * order. `computed`, `const` and `external` stay kernel grammar
 * metadata in `src/local/configuration/schema.ts`.
 */
export declare const DEFAULT_SEMANTIC_COMPONENTS: readonly LocalComponentDefinition[];
export declare const DEFAULT_COMPONENT_NAMES: readonly string[];
