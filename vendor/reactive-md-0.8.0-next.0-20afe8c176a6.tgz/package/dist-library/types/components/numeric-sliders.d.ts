import type { LocalComponentContext } from '../react/component-api.js';
export declare function SliderView(context: LocalComponentContext): import("react").JSX.Element;
export declare function RangeSliderView(context: LocalComponentContext): import("react").JSX.Element;
