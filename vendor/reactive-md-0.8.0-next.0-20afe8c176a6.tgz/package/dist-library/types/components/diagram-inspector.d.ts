import { type ReactNode } from 'react';
interface Anchor {
    id: string;
    element: SVGElement;
    pinned: boolean;
}
/** Keeps transient inspection separate from the diagram's persistent selection. */
export declare function useDiagramInspector(enabled: boolean, resetToken: number): {
    active: Anchor | null;
    tooltipRef: import("react").RefObject<HTMLDivElement | null>;
    show: (id: string, element: SVGElement, source: 'pointer' | 'focus' | 'click') => void;
    leave: (source?: 'pointer' | 'focus') => void;
    close: () => void;
    cancel: () => void;
};
export declare function DiagramInspector({ inspector, id, title, tone, children, closeLabel }: {
    inspector: ReturnType<typeof useDiagramInspector>;
    id: string;
    title: string;
    tone: string;
    children: ReactNode;
    closeLabel: string;
}): import("react").ReactPortal | null;
export {};
