import type { DefaultChartProps } from './default-chart-types.js';
export declare function DefaultChart(props: DefaultChartProps): import("react").JSX.Element;
