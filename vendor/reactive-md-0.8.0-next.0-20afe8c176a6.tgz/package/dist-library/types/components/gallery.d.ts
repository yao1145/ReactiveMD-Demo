import type { LocalComponentContext } from '../react/component-api.js';
export declare function Gallery(context: LocalComponentContext): import("react").JSX.Element;
export declare function GalleryStatic(context: LocalComponentContext): import("react").JSX.Element;
export declare function GalleryItemView(context: LocalComponentContext): import("react").JSX.Element;
/** Render every item in static documents without interactive controls. */
export declare function GalleryView(context: LocalComponentContext): import("react").JSX.Element;
