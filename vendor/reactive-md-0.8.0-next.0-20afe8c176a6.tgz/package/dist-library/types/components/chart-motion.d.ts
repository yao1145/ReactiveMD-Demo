import type * as React from 'react';
export declare function ChartMotionPath(props: React.SVGProps<SVGPathElement>): React.JSX.Element;
export declare function ChartMotionRect(props: React.SVGProps<SVGRectElement>): React.JSX.Element;
export declare function ChartMotionCircle(props: React.SVGProps<SVGCircleElement>): React.JSX.Element;
export declare function ChartMotionArc(props: React.SVGProps<SVGPathElement> & {
    cx: number;
    cy: number;
    outerRadius: number;
    innerRadius: number;
    startAngle: number;
    endAngle: number;
}): React.JSX.Element;
