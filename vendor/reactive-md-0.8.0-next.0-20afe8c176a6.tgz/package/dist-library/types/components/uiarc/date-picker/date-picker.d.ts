import type { ButtonHTMLAttributes } from "react";
import { type CalendarDateMatcher } from "../calendar/calendar.js";
export interface DatePickerProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, "value" | "onChange"> {
    label: string;
    value?: Date;
    onChange?: (date: Date | undefined) => void;
    description?: string;
    placeholder?: string;
    minDate?: Date;
    maxDate?: Date;
    disabledDates?: CalendarDateMatcher;
    locale?: string;
    format?: Intl.DateTimeFormatOptions;
    /** Adds a Today button to the calendar header. */
    showToday?: boolean;
    /** Marks the trigger invalid so the surrounding field can announce it. */
    invalid?: boolean;
    /** Ids of hints or errors that describe the trigger. */
    describedBy?: string;
    /** Localized calendar and footer labels. */
    todayLabel?: string;
    previousMonthLabel?: string;
    nextMonthLabel?: string;
    clearLabel?: string;
    calendarLabel?: string;
    /** Builds the footer status from the formatted value, or from null when empty. */
    statusLabel?: (formatted: string | null) => string;
}
export declare function DatePicker({ label, value, onChange, description, placeholder, minDate, maxDate, disabledDates, locale, format, showToday, invalid, describedBy, todayLabel, previousMonthLabel, nextMonthLabel, clearLabel, calendarLabel, statusLabel, id, className, disabled, ...buttonProps }: DatePickerProps): import("react").JSX.Element;
