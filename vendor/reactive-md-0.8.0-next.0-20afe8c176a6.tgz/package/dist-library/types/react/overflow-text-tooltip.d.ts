import { type RefObject } from 'react';
/** One delegated tooltip per default document, shared by all clipped labels. */
export declare function OverflowTextTooltip({ rootRef, enabled }: {
    rootRef: RefObject<HTMLElement | null>;
    enabled: boolean;
}): import("react").JSX.Element | null;
