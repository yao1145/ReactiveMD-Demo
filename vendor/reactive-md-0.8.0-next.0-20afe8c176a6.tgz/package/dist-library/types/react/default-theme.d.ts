import { type ReactNode } from 'react';
export declare function DefaultThemeProvider({ name, children }: {
    name: string;
    children: ReactNode;
}): import("react").JSX.Element;
export declare function useDefaultTheme(): boolean;
