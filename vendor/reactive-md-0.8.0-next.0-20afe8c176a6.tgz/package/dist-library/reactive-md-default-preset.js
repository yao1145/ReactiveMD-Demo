import { L as e, n as t, r as n, t as r } from "./identity-MYJXKSkB.js";
import { t as i } from "./default-components-Z_YMio5P.js";
// src/presets/default.ts
var a = n({
	protocol: e,
	id: r,
	version: t,
	components: i
});
export { a as default, a as defaultPreset };
