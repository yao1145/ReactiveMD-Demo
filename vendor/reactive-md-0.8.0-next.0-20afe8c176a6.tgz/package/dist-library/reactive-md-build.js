import { createHash } from "node:crypto";
import { readFile, realpath, stat } from "node:fs/promises";
import { dirname, isAbsolute, relative, resolve, sep } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
// src/local/configuration/limits.ts
/** Number of elements in one array value or selection. */
var MAX_LOCAL_ARRAY_LENGTH = 1e4;
/** Curve sample points requested across one document compilation. */
var MAX_LOCAL_PLOT_POINTS = 2e4;
var MAX_LOCAL_DATA_TABLE_ROWS = 1e3;
var MAX_LOCAL_DATA_DOCUMENT_ROWS = 2e3;
var MAX_LOCAL_DATA_DOCUMENT_CELLS = 1e4;
// src/local/html/html-names.ts
/**
* P0 native HTML tag names. The parser handles these before component tags, and
* host component schemas may not reuse them because document parsing would
* never dispatch such a tag to a host component.
*/
var LOCAL_HTML_NAMES = /* @__PURE__ */ new Set([
	"b",
	"strong",
	"i",
	"em",
	"s",
	"del",
	"u",
	"mark",
	"sup",
	"sub",
	"br",
	"hr",
	"img",
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"div",
	"span",
	"details",
	"summary",
	"blockquote",
	"code",
	"pre",
	"ul",
	"ol",
	"li",
	"a"
]);
var LOCAL_KERNEL_DECLARATIONS = Object.freeze([
	Object.freeze({
		name: "computed",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: true,
				required: true
			},
			value: {
				kind: "string",
				required: true
			}
		},
		structure: {
			rule: "none",
			label: "none"
		},
		rules: [{
			kind: "require-full-interpolation",
			attributes: ["value"]
		}]
	}),
	Object.freeze({
		name: "const",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: true,
				required: true
			},
			value: {
				kind: "string",
				required: true
			}
		},
		structure: {
			rule: "none",
			label: "none"
		},
		rules: [{
			kind: "require-full-interpolation",
			attributes: ["value"]
		}]
	}),
	Object.freeze({
		name: "external",
		form: "leaf",
		childRule: "none",
		label: "none",
		props: {
			name: {
				kind: "string",
				static: true,
				required: true
			},
			type: {
				kind: "enum",
				static: true,
				required: true,
				values: [
					"string",
					"number",
					"boolean",
					"string-array",
					"number-array"
				]
			}
		},
		structure: {
			rule: "none",
			label: "none"
		}
	})
]);
// src/sdk/hash.ts
/**
* Deterministic, non-cryptographic digest for SDK semantic identity.
*
* The digest is stable across processes and platforms (unlike object identity
* or `Math.random`), and is used only to detect contract changes. It is not a
* security primitive: document payloads must still be validated by the
* receiving side.
*/
function localHash(text) {
	let first = 2166136261;
	let second = 16777619;
	for (let index = 0; index < text.length; index += 1) {
		const code = text.charCodeAt(index);
		first ^= code;
		first = Math.imul(first, 16777619) >>> 0;
		second ^= code + index;
		second = Math.imul(second, 2246822507) >>> 0;
	}
	const length = text.length;
	first ^= length;
	first = Math.imul(first, 16777619) >>> 0;
	second ^= length;
	second = Math.imul(second, 3266489909) >>> 0;
	return `rmd-${first.toString(16).padStart(8, "0")}${second.toString(16).padStart(8, "0")}`;
}
// src/sdk/pattern.ts
/**
* Restricted regular-expression subset shared by host schemas and SDK
* manifests. Rejected constructs are the ones that can backtrack
* super-linearly on document-controlled input.
*/
function patternQuantifier(source, index) {
	const char = source[index];
	if (char === "*" || char === "+" || char === "?") return { length: source[index + 1] === "?" ? 2 : 1 };
	if (char !== "{") return null;
	const match = /^\{(\d+)(?:,(\d*))?\}/.exec(source.slice(index));
	if (!match) return null;
	return { length: match[0].length + (source[index + match[0].length] === "?" ? 1 : 0) };
}
/**
* True when `source` uses only linear-time-safe regex syntax: no
* backreferences, lookarounds, named groups, and no quantifier applied to a
* group that itself contains a quantifier or alternation.
*/
function isSafeLocalPattern(source) {
	const groups = [];
	let escaped = false;
	let inClass = false;
	for (let index = 0; index < source.length; index += 1) {
		const char = source[index];
		if (escaped) {
			escaped = false;
			continue;
		}
		if (char === "\\") {
			const next = source[index + 1];
			if (next !== void 0 && next >= "1" && next <= "9") return false;
			if (next === "k" && source[index + 2] === "<") return false;
			escaped = true;
			continue;
		}
		if (inClass) {
			if (char === "]") inClass = false;
			continue;
		}
		if (char === "[") {
			inClass = true;
			continue;
		}
		if (char === "(") {
			if (source[index + 1] === "?") {
				if (source[index + 2] !== ":") return false;
				groups.push({
					quantified: false,
					alternation: false
				});
				index += 2;
				continue;
			}
			groups.push({
				quantified: false,
				alternation: false
			});
			continue;
		}
		if (char === "|") {
			const group = groups[groups.length - 1];
			if (group) group.alternation = true;
			continue;
		}
		if (char === ")") {
			const group = groups.pop();
			if (!group) return false;
			const quantifier = patternQuantifier(source, index + 1);
			if (quantifier && (group.quantified || group.alternation)) return false;
			const parent = groups[groups.length - 1];
			if (parent) {
				parent.quantified = parent.quantified || group.quantified || quantifier !== null;
				parent.alternation = parent.alternation || group.alternation;
			}
			if (quantifier) index += quantifier.length;
			continue;
		}
		const quantifier = patternQuantifier(source, index);
		if (quantifier) {
			const group = groups[groups.length - 1];
			if (group) group.quantified = true;
			index += quantifier.length - 1;
		}
	}
	return groups.length === 0 && !escaped && !inClass;
}
// src/sdk/version.ts
/**
* SDK protocol identities and package version.
*
* These revisions are independent from each other and from the document
* syntax revision: a package release may move one without changing the others.
*/
var LOCAL_SDK_VERSION = "0.7.0";
var LOCAL_COMPONENT_PROTOCOL = "reactive-md-component/v1";
/** Legacy configuration protocol. Readable through the v1 compatibility profile. */
var LOCAL_CONFIG_PROTOCOL = "reactive-md-config/v1";
/** Assembly-based configuration protocol. New configs are written in this form. */
var LOCAL_CONFIG_PROTOCOL_V2 = "reactive-md-config/v2";
var LOCAL_PRESET_PROTOCOL = "reactive-md-preset/v1";
var LOCAL_REACT_PRESET_PROTOCOL = "reactive-md-react-preset/v1";
var LOCAL_ASSEMBLY_PROTOCOL = "reactive-md-assembly/v1";
var VERSION$2 = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/;
var LEADING_ZERO = /^0\d+$/;
function parsePrerelease(text) {
	if (text === void 0) return Object.freeze([]);
	const parts = text.split(".");
	const parsed = [];
	for (const part of parts) {
		if (part.length === 0) return null;
		if (LEADING_ZERO.test(part) && part !== "0" && /^\d+$/.test(part)) return null;
		if (/^\d+$/.test(part) && !Number.isSafeInteger(Number(part))) return null;
		parsed.push(/^\d+$/.test(part) ? Number(part) : part);
	}
	return Object.freeze(parsed);
}
function parseVersion(text) {
	const match = VERSION$2.exec(text);
	if (!match) return null;
	const [, majorText, minorText, patchText, prereleaseText] = match;
	for (const part of [
		majorText,
		minorText,
		patchText
	]) {
		if (part.length > 1 && part.startsWith("0")) return null;
		if (!Number.isSafeInteger(Number(part))) return null;
	}
	const prerelease = parsePrerelease(prereleaseText);
	if (prerelease === null) return null;
	return {
		major: Number(majorText),
		minor: Number(minorText),
		patch: Number(patchText),
		prerelease
	};
}
function compareIdentifier(left, right) {
	if (typeof left === "number" && typeof right === "number") return left === right ? 0 : left < right ? -1 : 1;
	if (typeof left === "number") return -1;
	if (typeof right === "number") return 1;
	return left === right ? 0 : left < right ? -1 : 1;
}
function compareVersions(left, right) {
	for (const key of [
		"major",
		"minor",
		"patch"
	]) if (left[key] !== right[key]) return left[key] < right[key] ? -1 : 1;
	if (left.prerelease.length === 0 && right.prerelease.length === 0) return 0;
	if (left.prerelease.length === 0) return 1;
	if (right.prerelease.length === 0) return -1;
	const length = Math.min(left.prerelease.length, right.prerelease.length);
	for (let index = 0; index < length; index += 1) {
		const order = compareIdentifier(left.prerelease[index], right.prerelease[index]);
		if (order !== 0) return order;
	}
	return left.prerelease.length === right.prerelease.length ? 0 : left.prerelease.length < right.prerelease.length ? -1 : 1;
}
function mainVersion(major, minor, patch) {
	return {
		major,
		minor,
		patch,
		prerelease: Object.freeze([])
	};
}
function expandComparator(operator, version) {
	if (operator === "^") {
		const upper = version.major > 0 ? mainVersion(version.major + 1, 0, 0) : version.minor > 0 ? mainVersion(0, version.minor + 1, 0) : mainVersion(0, 0, version.patch + 1);
		return [{
			operator: ">=",
			version
		}, {
			operator: "<",
			version: upper
		}];
	}
	if (operator === "~") return [{
		operator: ">=",
		version
	}, {
		operator: "<",
		version: mainVersion(version.major, version.minor + 1, 0)
	}];
	return [{
		operator,
		version
	}];
}
/**
* Parse a bounded semver range. Unsupported syntax (`*`, `||`, hyphen ranges,
* wildcards, `v` prefixes, spaced operators) returns null instead of being
* approximated.
*/
function parseLocalVersionRange(source) {
	if (typeof source !== "string") return null;
	const text = source.trim();
	if (text.length === 0 || text.length > 128) return null;
	const tokens = text.split(/\s+/);
	if (tokens.length === 0 || tokens.length > 8) return null;
	const comparators = [];
	try {
		for (const token of tokens) {
			let operator = "=";
			let body = token;
			if (token.startsWith(">=") || token.startsWith("<=")) {
				operator = token.slice(0, 2);
				body = token.slice(2);
			} else if (token.startsWith(">") || token.startsWith("<") || token.startsWith("=")) {
				operator = token[0];
				body = token.slice(1);
			} else if (token.startsWith("^") || token.startsWith("~")) {
				operator = token[0];
				body = token.slice(1);
			}
			const version = parseVersion(body);
			if (version === null) return null;
			comparators.push(...expandComparator(operator, version));
			if (comparators.length > 16) return null;
		}
	} catch {
		return null;
	}
	return Object.freeze({
		source: text,
		comparators: Object.freeze(comparators)
	});
}
/** True when `version` is a valid, complete semantic version. */
function isLocalVersion(value) {
	return typeof value === "string" && parseVersion(value) !== null;
}
/**
* Check one installed version against a parsed or textual range. Invalid
* versions or ranges never satisfy the range.
*/
function localVersionSatisfies(version, range) {
	try {
		const installed = parseVersion(version);
		if (installed === null) return false;
		const parsed = typeof range === "string" ? parseLocalVersionRange(range) : range;
		if (!parsed || !Array.isArray(parsed.comparators) || parsed.comparators.length === 0) return false;
		if (installed.prerelease.length && !parsed.comparators.some(({ version: candidate }) => candidate.prerelease.length && candidate.major === installed.major && candidate.minor === installed.minor && candidate.patch === installed.patch)) return false;
		for (const comparator of parsed.comparators) {
			const order = compareVersions(installed, comparator.version);
			switch (comparator.operator) {
				case "=":
					if (order !== 0) return false;
					break;
				case ">":
					if (order <= 0) return false;
					break;
				case ">=":
					if (order < 0) return false;
					break;
				case "<":
					if (order >= 0) return false;
					break;
				case "<=":
					if (order > 0) return false;
					break;
				default: return false;
			}
		}
		return true;
	} catch {
		return false;
	}
}
var MAX_LOCAL_SDK_STRING_LENGTH = 4096;
/** Aggregate serialized-size budget for one component manifest. */
var MAX_LOCAL_SDK_MANIFEST_BYTES = 65536;
var NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
var ID = /^[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*$/;
var VERSION$1 = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/;
var LOCALE = /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/;
var DANGEROUS_KEYS$2 = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
var validatedDefinitions = /* @__PURE__ */ new WeakSet();
var PROP_KINDS = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]);
var FORMS = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]);
var BINDING_KINDS = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]);
var FAMILIES = /* @__PURE__ */ new Set([
	"text",
	"number",
	"boolean",
	"choice",
	"date",
	"timer",
	"checklist",
	"tabs",
	"diagram",
	"multi-select",
	"selection",
	"steps",
	"collection"
]);
var INITIAL_RULES = /* @__PURE__ */ new Set([
	"empty",
	"false",
	"max-step",
	"nearest-zero",
	"min",
	"first-option",
	"first-tab",
	"first-step",
	"first-node",
	"checked",
	"duration",
	"empty-array",
	"none"
]);
var CHILD_KINDS = /* @__PURE__ */ new Set([
	"none",
	"inline",
	"markdown"
]);
var CHILD_RULES = /* @__PURE__ */ new Set([
	"none",
	"any",
	"inline",
	"content",
	"table",
	"plot",
	"diagram",
	"quiz",
	"options",
	"tabs",
	"steps",
	"components"
]);
var RULE_KINDS = /* @__PURE__ */ new Set([
	"numeric-range",
	"text-length",
	"date-bounds",
	"nonempty",
	"progress-bounds",
	"timer-duration",
	"option-count",
	"selection-requires",
	"inline-body",
	"no-components",
	"single-table",
	"math-body",
	"options-body",
	"value-sequence",
	"only-children",
	"diagram-body",
	"quiz-body",
	"checklist-body",
	"dynamic-constraints",
	"require-full-interpolation",
	"scoped-expressions",
	"row-values",
	"validation-rule",
	"anchor",
	"navigation",
	"data-table",
	"plot-math",
	"chart-table",
	"timeline-table",
	"table-selection",
	"retain",
	"self-binding-read",
	"inline-math-reads",
	"value-date",
	"value-length",
	"value-required",
	"value-email"
]);
var LABELS = /* @__PURE__ */ new Set([
	"none",
	"required",
	"optional"
]);
var TOP_KEYS = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"form",
	"props",
	"bindings",
	"children",
	"structure",
	"rules",
	"slotRelations",
	"legacyHost",
	"capabilities",
	"authoring",
	"dependencies",
	"styles",
	"requires",
	"replaces"
]);
var PROP_KEYS = /* @__PURE__ */ new Set([
	"kind",
	"required",
	"static",
	"dynamic",
	"default",
	"nullable",
	"enum",
	"values",
	"pattern",
	"min",
	"max",
	"integer",
	"positive",
	"color",
	"coerce",
	"description"
]);
var BINDING_KEYS = /* @__PURE__ */ new Set([
	"kind",
	"family",
	"bind",
	"initial",
	"initialRule",
	"required",
	"exclusive",
	"constraints",
	"options",
	"maxItems",
	"requiresAttributes",
	"compare",
	"retain"
]);
var CONSTRAINT_KEYS = /* @__PURE__ */ new Set([
	"min",
	"max",
	"step"
]);
var CAPABILITY_KEYS = /* @__PURE__ */ new Set([
	"interactive",
	"static",
	"ssr",
	"offline"
]);
var AUTHORING_KEYS$1 = /* @__PURE__ */ new Set([
	"title",
	"description",
	"category",
	"insertText"
]);
var CHILD_KEYS = /* @__PURE__ */ new Set(["kind", "required"]);
var STRUCTURE_KEYS = /* @__PURE__ */ new Set([
	"rule",
	"label",
	"parents",
	"child",
	"children",
	"min",
	"max",
	"inlineOnly",
	"noComponents",
	"valueAttribute",
	"generatedPrefix",
	"forbidSeparator",
	"maxItems"
]);
var DEPENDENCY_KEYS$1 = /* @__PURE__ */ new Set(["id", "version"]);
var REQUIRES_KEYS = /* @__PURE__ */ new Set(["kernel"]);
var REPLACEMENT_KEYS = /* @__PURE__ */ new Set(["id", "version"]);
var STYLE_ID$1 = /^[A-Za-z0-9][A-Za-z0-9._/-]*$/;
/** Slot names and `setMany` are part of the public binding API. */
var SLOT_NAME = /^[A-Za-z][A-Za-z0-9]*$/;
var RESERVED_SLOT_NAMES = /* @__PURE__ */ new Set(["setMany"]);
function fail$2(path, message) {
	throw new Error(`Invalid local component manifest (${path}): ${message}`);
}
/** UTF-8 byte length of JSON-compatible data, bounded by the caller. */
function localJsonByteLength(value) {
	try {
		const text = JSON.stringify(value);
		if (typeof text !== "string") return Number.POSITIVE_INFINITY;
		if (typeof TextEncoder === "function") return new TextEncoder().encode(text).length;
		return text.length * 2;
	} catch {
		return Number.POSITIVE_INFINITY;
	}
}
function isPlainRecord$1(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
function checkKeys$2(record, allowed, path) {
	for (const key of Object.keys(record)) {
		if (DANGEROUS_KEYS$2.has(key)) fail$2(path, `field "${key}" is not allowed.`);
		if (!allowed.has(key)) fail$2(path, `unknown field "${key}".`);
	}
}
function readBoolean(value, path) {
	if (typeof value !== "boolean") fail$2(path, "must be a boolean.");
	return value;
}
function readString(value, path, limit = MAX_LOCAL_SDK_STRING_LENGTH) {
	if (typeof value !== "string") fail$2(path, "must be a string.");
	if (value.length > limit) fail$2(path, `exceeds the ${limit}-character limit.`);
	return value;
}
function readFiniteNumber(value, path) {
	if (typeof value !== "number" || !Number.isFinite(value)) fail$2(path, "must be a finite number.");
	return value;
}
function readIdentifier(value, path) {
	if (typeof value !== "string") fail$2(path, "must be a string.");
	if (value.length > 128) fail$2(path, `exceeds the 128-character limit.`);
	if (!NAME.test(value)) fail$2(path, "must use lowercase kebab-case.");
	return value;
}
function readTextMap(value, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	const out = {};
	const keys = Object.keys(value).sort();
	for (const key of keys) {
		if (DANGEROUS_KEYS$2.has(key)) fail$2(path, `locale "${key}" is not allowed.`);
		if (!LOCALE.test(key)) fail$2(path, `locale "${key}" must look like "en" or "zh-CN".`);
		out[key] = readString(value[key], `${path}.${key}`, 256);
	}
	return out;
}
function readAuthoring$1(value, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	checkKeys$2(value, AUTHORING_KEYS$1, path);
	const out = {};
	if (value.title !== void 0) out.title = readTextMap(value.title, `${path}.title`);
	if (value.description !== void 0) out.description = readTextMap(value.description, `${path}.description`);
	if (value.category !== void 0) out.category = readString(value.category, `${path}.category`, 64);
	if (value.insertText !== void 0) out.insertText = readString(value.insertText, `${path}.insertText`, MAX_LOCAL_SDK_STRING_LENGTH);
	return out;
}
function readChildren(value, form, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	checkKeys$2(value, CHILD_KEYS, path);
	const rawKind = value.kind;
	if (typeof rawKind !== "string" || !CHILD_KINDS.has(rawKind)) fail$2(`${path}.kind`, "must be \"none\", \"inline\" or \"markdown\".");
	const kind = rawKind;
	if (value.required !== void 0) readBoolean(value.required, `${path}.required`);
	const required = value.required === true;
	if (form === "leaf" && kind !== "none") fail$2(path, "a leaf component cannot declare body content.");
	if (form === "inline" && kind === "markdown") fail$2(path, "an inline component cannot declare Markdown block content.");
	if (required && kind === "none") fail$2(path, "cannot require body content of kind \"none\".");
	return {
		kind,
		...required ? { required: true } : {}
	};
}
/** Map a legacy `children` declaration to the equivalent public structure. */
function localStructureFromChildren(children) {
	if (children === void 0) return void 0;
	if (children.kind === "none") return Object.freeze({
		rule: "none",
		label: "none"
	});
	if (children.kind === "inline") return Object.freeze({
		rule: "inline",
		label: "none",
		inlineOnly: true,
		noComponents: true,
		...children.required ? { min: 1 } : {}
	});
	return Object.freeze({
		rule: "any",
		label: "none",
		...children.required ? { min: 1 } : {}
	});
}
function readNameList(value, path) {
	if (!Array.isArray(value)) fail$2(path, "must be an array of component names.");
	if (value.length > 32) fail$2(path, `accepts at most 32 names.`);
	const seen = /* @__PURE__ */ new Set();
	const names = [];
	for (const item of value) {
		const name = readIdentifier(item, path);
		if (seen.has(name)) fail$2(path, `name "${name}" is declared more than once.`);
		seen.add(name);
		names.push(name);
	}
	return names;
}
function readPositiveCount(value, path) {
	const numeric = readFiniteNumber(value, path);
	if (!Number.isInteger(numeric) || numeric < 0) fail$2(path, "must be a nonnegative integer.");
	return numeric;
}
function readStructure(value, form, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	checkKeys$2(value, STRUCTURE_KEYS, path);
	const rawRule = value.rule;
	if (typeof rawRule !== "string" || !CHILD_RULES.has(rawRule)) fail$2(`${path}.rule`, "is not a supported child rule.");
	const rule = rawRule;
	if (form === "leaf" && rule !== "none") fail$2(path, "a leaf component cannot declare body content.");
	if (form === "inline" && rule !== "none" && rule !== "inline" && rule !== "any") fail$2(path, "an inline component only supports \"none\", \"inline\" or \"any\".");
	const out = { rule };
	if (value.label !== void 0) {
		if (typeof value.label !== "string" || !LABELS.has(value.label)) fail$2(`${path}.label`, "must be \"none\", \"required\" or \"optional\".");
		out.label = value.label;
	}
	if (value.parents !== void 0) out.parents = readNameList(value.parents, `${path}.parents`);
	if (value.child !== void 0) out.child = readIdentifier(value.child, `${path}.child`);
	if (value.children !== void 0) out.children = readNameList(value.children, `${path}.children`);
	if (value.min !== void 0) out.min = readBoundedCount(value.min, `${path}.min`, MAX_LOCAL_ARRAY_LENGTH);
	if (value.max !== void 0) out.max = readBoundedCount(value.max, `${path}.max`, MAX_LOCAL_ARRAY_LENGTH);
	if (out.min !== void 0 && out.max !== void 0 && out.min > out.max) fail$2(path, "\"min\" cannot exceed \"max\".");
	if (value.inlineOnly !== void 0) out.inlineOnly = readBoolean(value.inlineOnly, `${path}.inlineOnly`);
	if (value.noComponents !== void 0) out.noComponents = readBoolean(value.noComponents, `${path}.noComponents`);
	if (value.valueAttribute !== void 0) out.valueAttribute = readIdentifier(value.valueAttribute, `${path}.valueAttribute`);
	if (value.generatedPrefix !== void 0) {
		const prefix = readString(value.generatedPrefix, `${path}.generatedPrefix`, 128);
		if (prefix.length === 0) fail$2(`${path}.generatedPrefix`, "must not be empty.");
		out.generatedPrefix = prefix;
	}
	if (value.forbidSeparator !== void 0) {
		const separator = readString(value.forbidSeparator, `${path}.forbidSeparator`, 4);
		if (separator.length === 0) fail$2(`${path}.forbidSeparator`, "must not be empty.");
		out.forbidSeparator = separator;
	}
	if (value.maxItems !== void 0) out.maxItems = readBoundedCount(value.maxItems, `${path}.maxItems`, MAX_LOCAL_ARRAY_LENGTH);
	return out;
}
function readRuleAttribute(value, path) {
	return readIdentifier(value, path);
}
function readRuleCount(value, path) {
	return readPositiveCount(value, path);
}
/** A declared budget may lower a kernel hard limit, never raise it. */
function readBoundedCount(value, path, limit) {
	const numeric = readPositiveCount(value, path);
	if (numeric > limit) fail$2(path, `cannot exceed the kernel limit ${limit}.`);
	return numeric;
}
function readRuleStringList(value, path) {
	return readNameList(value, path);
}
/** Display strings such as timeline headers; not identifiers. */
function readPlainStringList(value, path) {
	if (!Array.isArray(value)) fail$2(path, "must be an array of strings.");
	if (value.length > 32) fail$2(path, `accepts at most 32 values.`);
	return value.map((item) => readString(item, path, 128));
}
function readRule(value, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	const kind = value.kind;
	if (typeof kind !== "string" || !RULE_KINDS.has(kind)) fail$2(`${path}.kind`, "is not a supported rule.");
	const allow = (keys) => checkKeys$2(value, /* @__PURE__ */ new Set(["kind", ...keys]), path);
	const strings = (keys) => {
		const out = {};
		for (const key of keys) if (value[key] !== void 0) out[key] = readRuleAttribute(value[key], `${path}.${key}`);
		return out;
	};
	switch (kind) {
		case "numeric-range": {
			allow([
				"min",
				"max",
				"step",
				"order",
				"integer",
				"positiveInteger"
			]);
			let order;
			if (value.order !== void 0) {
				if (value.order !== "nondecreasing" && value.order !== "increasing") fail$2(`${path}.order`, "must be \"nondecreasing\" or \"increasing\".");
				order = value.order;
			}
			return {
				kind,
				...strings([
					"min",
					"max",
					"step",
					"integer",
					"positiveInteger"
				]),
				...order ? { order } : {}
			};
		}
		case "text-length":
			allow(["min", "max"]);
			return {
				kind,
				...strings(["min", "max"])
			};
		case "date-bounds":
			allow([
				"min",
				"max",
				"required"
			]);
			return {
				kind,
				...strings([
					"min",
					"max",
					"required"
				])
			};
		case "nonempty":
			allow(["attribute"]);
			return {
				kind,
				attribute: readRuleAttribute(value.attribute, `${path}.attribute`)
			};
		case "progress-bounds":
			allow([
				"value",
				"max",
				"defaultMax"
			]);
			return {
				kind,
				value: readRuleAttribute(value.value, `${path}.value`),
				max: readRuleAttribute(value.max, `${path}.max`),
				defaultMax: readFiniteNumber(value.defaultMax, `${path}.defaultMax`)
			};
		case "timer-duration":
			allow(["attribute", "default"]);
			return {
				kind,
				attribute: readRuleAttribute(value.attribute, `${path}.attribute`),
				default: readFiniteNumber(value.default, `${path}.default`)
			};
		case "option-count":
			allow(["max"]);
			return {
				kind,
				...value.max !== void 0 ? { max: readRuleAttribute(value.max, `${path}.max`) } : {}
			};
		case "selection-requires":
			allow(["key", "attributes"]);
			return {
				kind,
				key: readRuleAttribute(value.key, `${path}.key`),
				attributes: readRuleStringList(value.attributes, `${path}.attributes`)
			};
		case "inline-body":
			allow(["strict"]);
			return {
				kind,
				...value.strict !== void 0 ? { strict: readBoolean(value.strict, `${path}.strict`) } : {}
			};
		case "no-components":
		case "math-body":
		case "inline-math-reads":
			allow([]);
			return { kind };
		case "single-table":
			allow(["fallbackSingle"]);
			return {
				kind,
				...value.fallbackSingle === void 0 ? {} : { fallbackSingle: readBoolean(value.fallbackSingle, `${path}.fallbackSingle`) }
			};
		case "options-body":
			allow([
				"child",
				"valueAttribute",
				"unique",
				"max",
				"forbidSeparator"
			]);
			return {
				kind,
				child: readRuleAttribute(value.child, `${path}.child`),
				valueAttribute: readRuleAttribute(value.valueAttribute, `${path}.valueAttribute`),
				unique: value.unique === void 0 ? true : readBoolean(value.unique, `${path}.unique`),
				...value.max !== void 0 ? { max: readBoundedCount(value.max, `${path}.max`, MAX_LOCAL_ARRAY_LENGTH) } : {},
				...value.forbidSeparator !== void 0 ? { forbidSeparator: readString(value.forbidSeparator, `${path}.forbidSeparator`, 4) } : {}
			};
		case "value-sequence":
			allow([
				"child",
				"valueAttribute",
				"min",
				"generatedPrefix",
				"unique",
				"duplicateCode"
			]);
			return {
				kind,
				child: readRuleAttribute(value.child, `${path}.child`),
				valueAttribute: readRuleAttribute(value.valueAttribute, `${path}.valueAttribute`),
				min: readRuleCount(value.min, `${path}.min`),
				generatedPrefix: readString(value.generatedPrefix, `${path}.generatedPrefix`, 128),
				unique: value.unique === void 0 ? true : readBoolean(value.unique, `${path}.unique`),
				...value.duplicateCode === void 0 ? {} : { duplicateCode: readString(value.duplicateCode, `${path}.duplicateCode`, 128) }
			};
		case "only-children":
			allow([
				"children",
				"min",
				"max",
				"maxCode",
				"onlyCode"
			]);
			return {
				kind,
				children: readRuleStringList(value.children, `${path}.children`),
				min: readRuleCount(value.min, `${path}.min`),
				...value.max !== void 0 ? { max: readBoundedCount(value.max, `${path}.max`, MAX_LOCAL_ARRAY_LENGTH) } : {},
				...value.maxCode !== void 0 ? { maxCode: readString(value.maxCode, `${path}.maxCode`, 128) } : {},
				...value.onlyCode !== void 0 ? { onlyCode: readString(value.onlyCode, `${path}.onlyCode`, 128) } : {}
			};
		case "diagram-body":
			allow([
				"node",
				"edge",
				"id",
				"from",
				"to",
				"label"
			]);
			return {
				kind,
				node: readRuleAttribute(value.node, `${path}.node`),
				edge: readRuleAttribute(value.edge, `${path}.edge`),
				id: readRuleAttribute(value.id, `${path}.id`),
				from: readRuleAttribute(value.from, `${path}.from`),
				to: readRuleAttribute(value.to, `${path}.to`),
				...value.label !== void 0 ? { label: readRuleAttribute(value.label, `${path}.label`) } : {}
			};
		case "quiz-body":
			allow([
				"type",
				"answer",
				"tolerance",
				"child",
				"valueAttribute",
				"max"
			]);
			return {
				kind,
				type: readRuleAttribute(value.type, `${path}.type`),
				answer: readRuleAttribute(value.answer, `${path}.answer`),
				tolerance: readRuleAttribute(value.tolerance, `${path}.tolerance`),
				child: readRuleAttribute(value.child, `${path}.child`),
				valueAttribute: readRuleAttribute(value.valueAttribute, `${path}.valueAttribute`),
				...value.max !== void 0 ? { max: readBoundedCount(value.max, `${path}.max`, MAX_LOCAL_ARRAY_LENGTH) } : {}
			};
		case "checklist-body":
			allow(["itemLimit"]);
			return {
				kind,
				itemLimit: readBoundedCount(value.itemLimit, `${path}.itemLimit`, MAX_LOCAL_ARRAY_LENGTH)
			};
		case "dynamic-constraints":
		case "require-full-interpolation":
			allow(["attributes"]);
			return {
				kind,
				attributes: readRuleStringList(value.attributes, `${path}.attributes`)
			};
		case "scoped-expressions":
			allow(["attributes", "scope"]);
			if (value.scope !== "row" && value.scope !== "validation") fail$2(`${path}.scope`, "must be \"row\" or \"validation\".");
			return {
				kind,
				attributes: readRuleStringList(value.attributes, `${path}.attributes`),
				scope: value.scope
			};
		case "row-values":
			allow([
				"rows",
				"key",
				"child",
				"childValue"
			]);
			return {
				kind,
				rows: readRuleAttribute(value.rows, `${path}.rows`),
				key: readRuleAttribute(value.key, `${path}.key`),
				child: readRuleAttribute(value.child, `${path}.child`),
				childValue: readRuleAttribute(value.childValue, `${path}.childValue`)
			};
		case "validation-rule":
			allow([
				"when",
				"fields",
				"message",
				"placement",
				"max"
			]);
			if (value.placement !== "container" && value.placement !== "prose") fail$2(`${path}.placement`, "must be \"container\" or \"prose\".");
			return {
				kind,
				when: readRuleAttribute(value.when, `${path}.when`),
				fields: readRuleAttribute(value.fields, `${path}.fields`),
				message: readRuleAttribute(value.message, `${path}.message`),
				placement: value.placement,
				max: readBoundedCount(value.max, `${path}.max`, 100)
			};
		case "anchor":
			allow(["id"]);
			return {
				kind,
				id: readRuleAttribute(value.id, `${path}.id`)
			};
		case "navigation":
			allow(["target"]);
			return {
				kind,
				target: readRuleAttribute(value.target, `${path}.target`)
			};
		case "data-table":
			allow([
				"rows",
				"key",
				"child",
				"childValue",
				"label",
				"maxRows",
				"defaultMaxRows",
				"documentRows",
				"documentCells",
				"maxColumns"
			]);
			return {
				kind,
				rows: readRuleAttribute(value.rows, `${path}.rows`),
				key: readRuleAttribute(value.key, `${path}.key`),
				child: readRuleAttribute(value.child, `${path}.child`),
				childValue: readRuleAttribute(value.childValue, `${path}.childValue`),
				label: readRuleAttribute(value.label, `${path}.label`),
				maxRows: readRuleAttribute(value.maxRows, `${path}.maxRows`),
				defaultMaxRows: readBoundedCount(value.defaultMaxRows, `${path}.defaultMaxRows`, MAX_LOCAL_DATA_TABLE_ROWS),
				documentRows: readBoundedCount(value.documentRows, `${path}.documentRows`, MAX_LOCAL_DATA_DOCUMENT_ROWS),
				documentCells: readBoundedCount(value.documentCells, `${path}.documentCells`, MAX_LOCAL_DATA_DOCUMENT_CELLS),
				maxColumns: readBoundedCount(value.maxColumns, `${path}.maxColumns`, 20)
			};
		case "plot-math":
			allow([
				"min",
				"max",
				"samples",
				"curves",
				"points"
			]);
			return {
				kind,
				min: readRuleAttribute(value.min, `${path}.min`),
				max: readRuleAttribute(value.max, `${path}.max`),
				samples: readRuleAttribute(value.samples, `${path}.samples`),
				curves: readBoundedCount(value.curves, `${path}.curves`, 16),
				points: readBoundedCount(value.points, `${path}.points`, MAX_LOCAL_PLOT_POINTS)
			};
		case "chart-table":
			allow([
				"chartKind",
				"x",
				"y"
			]);
			return {
				kind,
				chartKind: readRuleAttribute(value.chartKind, `${path}.chartKind`),
				x: readRuleAttribute(value.x, `${path}.x`),
				y: readRuleAttribute(value.y, `${path}.y`)
			};
		case "timeline-table":
			allow(["headerSets"]);
			if (!Array.isArray(value.headerSets)) fail$2(`${path}.headerSets`, "must be an array.");
			return {
				kind,
				headerSets: value.headerSets.map((entry, index) => readPlainStringList(entry, `${path}.headerSets[${index}]`))
			};
		case "table-selection":
			allow(["key", "bindings"]);
			return {
				kind,
				key: readRuleAttribute(value.key, `${path}.key`),
				bindings: readRuleStringList(value.bindings, `${path}.bindings`)
			};
		case "retain":
			allow(["value"]);
			return {
				kind,
				value: readBoolean(value.value, `${path}.value`)
			};
		case "self-binding-read":
			allow(["mode", "attribute"]);
			if (value.mode !== "always" && value.mode !== "attribute") fail$2(`${path}.mode`, "must be \"always\" or \"attribute\".");
			return {
				kind,
				mode: value.mode,
				...value.attribute !== void 0 ? { attribute: readRuleAttribute(value.attribute, `${path}.attribute`) } : {}
			};
		case "value-date":
			allow([
				"min",
				"max",
				"required"
			]);
			return {
				kind,
				...strings([
					"min",
					"max",
					"required"
				])
			};
		case "value-length":
			allow([
				"min",
				"max",
				"email",
				"emailType"
			]);
			return {
				kind,
				...strings([
					"min",
					"max",
					"email"
				]),
				...value.emailType !== void 0 ? { emailType: readString(value.emailType, `${path}.emailType`, 128) } : {}
			};
		case "value-required":
			allow(["required"]);
			return {
				kind,
				required: readRuleAttribute(value.required, `${path}.required`)
			};
		case "value-email":
			allow(["type", "value"]);
			return {
				kind,
				...strings(["type"]),
				...value.value === void 0 ? {} : { value: readString(value.value, `${path}.value`, 128) }
			};
		default: fail$2(`${path}.kind`, "is not a supported rule.");
	}
}
function readRules(value) {
	if (!Array.isArray(value)) fail$2("rules", "must be an array.");
	if (value.length > 32) fail$2("rules", `accepts at most 32 rules.`);
	const rules = [];
	for (let index = 0; index < value.length; index += 1) rules.push(readRule(value[index], `rules[${index}]`));
	return rules;
}
function readSlotRelations(value) {
	if (!Array.isArray(value)) fail$2("slotRelations", "must be an array.");
	if (value.length > 16) fail$2("slotRelations", `accepts at most 16 relations.`);
	const relations = [];
	for (let index = 0; index < value.length; index += 1) {
		const raw = value[index];
		const lead = `slotRelations[${index}]`;
		if (!isPlainRecord$1(raw)) fail$2(lead, "must be an object.");
		checkKeys$2(raw, /* @__PURE__ */ new Set(["lower", "upper"]), lead);
		relations.push({
			lower: readIdentifier(raw.lower, `${lead}.lower`),
			upper: readIdentifier(raw.upper, `${lead}.upper`)
		});
	}
	return relations;
}
function readCapabilities(value, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	checkKeys$2(value, CAPABILITY_KEYS, path);
	const read = (key) => value[key] === void 0 ? false : readBoolean(value[key], `${path}.${key}`);
	return {
		interactive: read("interactive"),
		static: read("static"),
		ssr: read("ssr"),
		offline: read("offline")
	};
}
function readProp(value, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	checkKeys$2(value, PROP_KEYS, path);
	const kind = value.kind;
	if (typeof kind !== "string" || !PROP_KINDS.has(kind)) fail$2(`${path}.kind`, "must be \"string\", \"number\", \"boolean\" or \"enum\".");
	const typedKind = kind;
	const out = { kind: typedKind };
	for (const flag of [
		"required",
		"static",
		"dynamic",
		"integer",
		"positive",
		"color",
		"nullable"
	]) {
		if (value[flag] === void 0) continue;
		out[flag] = readBoolean(value[flag], `${path}.${flag}`);
	}
	if (out.static === true && out.dynamic === true) fail$2(path, "cannot be both static and dynamic.");
	if (value.coerce !== void 0) {
		if (value.coerce !== "text") fail$2(`${path}.coerce`, "must be \"text\".");
		if (typedKind !== "string") fail$2(`${path}.coerce`, "is only valid for kind \"string\".");
		out.coerce = "text";
	}
	const rawEnum = value.enum !== void 0 ? value.enum : value.values;
	const hasEnum = rawEnum !== void 0;
	if (typedKind !== "enum") {
		if (hasEnum) fail$2(path, `"enum" is only valid for kind "enum", not "${typedKind}".`);
	} else {
		if (value.enum !== void 0 && value.values !== void 0) fail$2(path, "use \"enum\" or \"values\", not both.");
		if (!Array.isArray(rawEnum) || rawEnum.length === 0) fail$2(`${path}.enum`, "must be a non-empty string array.");
		if (rawEnum.length > 64) fail$2(`${path}.enum`, `accepts at most 64 values.`);
		const seen = /* @__PURE__ */ new Set();
		const values = [];
		for (const item of rawEnum) {
			const text = readString(item, `${path}.enum`, 128);
			if (seen.has(text)) fail$2(`${path}.enum`, `value "${text}" is declared more than once.`);
			seen.add(text);
			values.push(text);
		}
		out.enum = values;
	}
	const hasPattern = value.pattern !== void 0;
	if (typedKind !== "string") {
		if (hasPattern) fail$2(path, `"pattern" is only valid for kind "string", not "${typedKind}".`);
	} else if (hasPattern) {
		if (typeof value.pattern !== "string") fail$2(`${path}.pattern`, "must be a string.");
		if (value.pattern.length > 512) fail$2(`${path}.pattern`, `exceeds the 512-character limit.`);
		try {
			new RegExp(value.pattern);
		} catch {
			fail$2(`${path}.pattern`, "is not a valid regular expression.");
		}
		if (!isSafeLocalPattern(value.pattern)) fail$2(`${path}.pattern`, "uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected.");
		out.pattern = value.pattern;
	}
	const hasMin = value.min !== void 0;
	const hasMax = value.max !== void 0;
	if (typedKind !== "number") {
		if (hasMin || hasMax) fail$2(path, "\"min\" and \"max\" are only valid for kind \"number\".");
		if (out.integer === true) fail$2(path, "\"integer\" is only valid for kind \"number\".");
		if (out.positive === true) fail$2(path, "\"positive\" is only valid for kind \"number\".");
	} else {
		if (hasMin) out.min = readFiniteNumber(value.min, `${path}.min`);
		if (hasMax) out.max = readFiniteNumber(value.max, `${path}.max`);
		if (out.min !== void 0 && out.max !== void 0 && out.min > out.max) fail$2(path, "\"min\" cannot exceed \"max\".");
	}
	if (out.color === true && typedKind !== "string") fail$2(path, "\"color\" is only valid for kind \"string\".");
	if (value.description !== void 0) out.description = readTextMap(value.description, `${path}.description`);
	if (value.default !== void 0) {
		const fallback = value.default;
		if (fallback === null) {
			if (out.nullable !== true) fail$2(`${path}.default`, "is null but the prop is not nullable.");
			out.default = null;
		} else if (typedKind === "string") out.default = readString(fallback, `${path}.default`);
		else if (typedKind === "number") {
			const numeric = readFiniteNumber(fallback, `${path}.default`);
			if (out.integer === true && !Number.isInteger(numeric)) fail$2(`${path}.default`, "must be an integer.");
			if (out.positive === true && !(numeric > 0)) fail$2(`${path}.default`, "must be greater than zero.");
			if (out.min !== void 0 && numeric < out.min) fail$2(`${path}.default`, `is below the minimum ${out.min}.`);
			if (out.max !== void 0 && numeric > out.max) fail$2(`${path}.default`, `exceeds the maximum ${out.max}.`);
			out.default = numeric;
		} else if (typedKind === "boolean") out.default = readBoolean(fallback, `${path}.default`);
		else {
			const text = readString(fallback, `${path}.default`, 128);
			if (!out.enum?.includes(text)) fail$2(`${path}.default`, `"${text}" is not an allowed enum value.`);
			out.default = text;
		}
		if (out.pattern !== void 0 && typedKind === "string" && typeof out.default === "string") {
			let accepted = true;
			try {
				accepted = new RegExp(out.pattern).test(out.default);
			} catch {
				accepted = false;
			}
			if (!accepted) fail$2(`${path}.default`, `does not match pattern ${out.pattern}.`);
		}
	}
	return out;
}
function readConstraint(value, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object with \"literal\" or \"prop\".");
	const keys = Object.keys(value);
	if (keys.length !== 1) fail$2(path, "must contain exactly one of \"literal\" or \"prop\".");
	const key = keys[0];
	if (DANGEROUS_KEYS$2.has(key)) fail$2(path, `field "${key}" is not allowed.`);
	if (key === "literal") return { literal: readFiniteNumber(value.literal, `${path}.literal`) };
	if (key === "prop") return { prop: readIdentifier(value.prop, `${path}.prop`) };
	fail$2(path, `unknown field "${key}"; use "literal" or "prop".`);
}
function readConstraints(value, props, kind, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	checkKeys$2(value, CONSTRAINT_KEYS, path);
	const out = {};
	for (const key of [
		"min",
		"max",
		"step"
	]) {
		if (value[key] === void 0) continue;
		const constraint = readConstraint(value[key], `${path}.${key}`);
		if ("prop" in constraint) {
			const prop = props[constraint.prop];
			if (prop === void 0) fail$2(`${path}.${key}`, `references undeclared prop "${constraint.prop}".`);
			if (prop.kind !== "number") fail$2(`${path}.${key}`, `references prop "${constraint.prop}", which is not a number.`);
		}
		if (key === "step" && "literal" in constraint && !(constraint.literal > 0)) fail$2(`${path}.step`, "must be greater than 0.");
		out[key] = constraint;
	}
	if (kind !== "number" && (out.min || out.max || out.step)) fail$2(path, "\"min\", \"max\" and \"step\" are only valid for number bindings.");
	if (out.min && "literal" in out.min && out.max && "literal" in out.max && out.min.literal > out.max.literal) fail$2(path, "\"min\" cannot exceed \"max\".");
	return out;
}
/** The initial rules a binding kind/family may declare. */
function initialRulesFor(kind, family) {
	if (kind === "number") return family === "timer" ? /* @__PURE__ */ new Set([
		"duration",
		"min",
		"nearest-zero"
	]) : /* @__PURE__ */ new Set([
		"min",
		"nearest-zero",
		"max-step"
	]);
	if (kind === "boolean") return /* @__PURE__ */ new Set(["false"]);
	if (kind === "null") return /* @__PURE__ */ new Set(["empty"]);
	if (kind === "array") {
		if (family === "checklist") return /* @__PURE__ */ new Set(["checked", "empty-array"]);
		return /* @__PURE__ */ new Set(["empty-array"]);
	}
	if (kind === "number-array") return /* @__PURE__ */ new Set(["empty-array"]);
	switch (family) {
		case "choice":
		case "selection": return /* @__PURE__ */ new Set(["first-option", "none"]);
		case "tabs": return /* @__PURE__ */ new Set(["first-tab"]);
		case "steps": return /* @__PURE__ */ new Set(["first-step"]);
		case "diagram": return /* @__PURE__ */ new Set(["first-node"]);
		case "date": return /* @__PURE__ */ new Set(["empty"]);
		default: return /* @__PURE__ */ new Set(["empty"]);
	}
}
function readBinding(value, props, path, structuralOptions = false) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	checkKeys$2(value, BINDING_KEYS, path);
	const kind = value.kind;
	if (typeof kind !== "string" || !BINDING_KINDS.has(kind)) fail$2(`${path}.kind`, "must be \"string\", \"number\", \"boolean\", \"array\", \"number-array\" or \"null\".");
	const typedKind = kind;
	const family = value.family;
	if (typeof family !== "string" || !FAMILIES.has(family)) fail$2(`${path}.family`, "must be a supported binding family.");
	const typedFamily = family;
	if (!{
		number: /* @__PURE__ */ new Set(["number", "timer"]),
		boolean: /* @__PURE__ */ new Set(["boolean"]),
		string: /* @__PURE__ */ new Set([
			"text",
			"choice",
			"date",
			"tabs",
			"diagram",
			"steps",
			"selection"
		]),
		array: /* @__PURE__ */ new Set([
			"multi-select",
			"checklist",
			"collection"
		]),
		"number-array": /* @__PURE__ */ new Set(["collection"]),
		null: /* @__PURE__ */ new Set(["text"])
	}[typedKind]?.has(typedFamily)) fail$2(`${path}.family`, `"${typedFamily}" is not supported for a ${typedKind} binding.`);
	let options;
	if (value.options !== void 0) {
		if (typedKind !== "string") fail$2(`${path}.options`, "is only valid for a string binding.");
		if (typedFamily !== "choice") fail$2(`${path}.options`, "requires family \"choice\".");
		const rawOptions = value.options;
		if (!Array.isArray(rawOptions) || rawOptions.length === 0) fail$2(`${path}.options`, "must be a non-empty string array.");
		if (rawOptions.length > 64) fail$2(`${path}.options`, `accepts at most 64 values.`);
		const seen = /* @__PURE__ */ new Set();
		const values = [];
		for (const item of rawOptions) {
			const text = readString(item, `${path}.options`, 128);
			if (text.length === 0) fail$2(`${path}.options`, "values must be non-empty.");
			if (seen.has(text)) fail$2(`${path}.options`, `value "${text}" is declared more than once.`);
			seen.add(text);
			values.push(text);
		}
		options = values;
	}
	if (typedKind === "string" && typedFamily === "choice" && options === void 0 && !structuralOptions) fail$2(`${path}.options`, "is required for a choice binding.");
	if (typedFamily !== "choice" && options !== void 0) fail$2(`${path}.options`, "is only valid for family \"choice\".");
	const bind = readIdentifier(value.bind, `${path}.bind`);
	const initial = readIdentifier(value.initial, `${path}.initial`);
	if (bind === initial) fail$2(path, "\"bind\" and \"initial\" must name different attributes.");
	if (RESERVED_SLOT_NAMES.has(bind) || RESERVED_SLOT_NAMES.has(initial)) fail$2(path, "binding attributes cannot use a reserved slot name.");
	if (Object.hasOwn(props, bind) || Object.hasOwn(props, initial)) fail$2(path, "binding attributes are reserved and cannot be declared as props.");
	const allowedRules = initialRulesFor(typedKind, typedFamily);
	let initialRule;
	if (value.initialRule === void 0) switch (typedKind) {
		case "number":
			initialRule = typedFamily === "timer" ? "duration" : "nearest-zero";
			break;
		case "boolean":
			initialRule = "false";
			break;
		case "array":
			initialRule = typedFamily === "checklist" ? "checked" : "empty-array";
			break;
		case "number-array":
			initialRule = "empty-array";
			break;
		case "null":
			initialRule = "empty";
			break;
		default: initialRule = typedFamily === "choice" ? "first-option" : typedFamily === "tabs" ? "first-tab" : typedFamily === "steps" ? "first-step" : typedFamily === "diagram" ? "first-node" : typedFamily === "selection" ? "none" : "empty";
	}
	else {
		if (typeof value.initialRule !== "string" || !INITIAL_RULES.has(value.initialRule)) fail$2(`${path}.initialRule`, "is not a supported initial rule.");
		initialRule = value.initialRule;
	}
	if (!allowedRules.has(initialRule)) fail$2(`${path}.initialRule`, `is not supported for a ${typedKind} ${typedFamily} binding.`);
	if (value.required !== void 0) readBoolean(value.required, `${path}.required`);
	if (value.exclusive !== void 0) readBoolean(value.exclusive, `${path}.exclusive`);
	if (value.retain !== void 0) readBoolean(value.retain, `${path}.retain`);
	let constraints;
	if (value.constraints !== void 0) constraints = readConstraints(value.constraints, props, typedKind, `${path}.constraints`);
	let maxItems;
	if (value.maxItems !== void 0) {
		if (typedKind !== "array" && typedKind !== "number-array") fail$2(`${path}.maxItems`, "is only valid for array or number-array bindings.");
		maxItems = readConstraint(value.maxItems, `${path}.maxItems`);
		if ("prop" in maxItems) {
			const prop = props[maxItems.prop];
			if (prop === void 0) fail$2(`${path}.maxItems`, `references undeclared prop "${maxItems.prop}".`);
			if (prop.kind !== "number") fail$2(`${path}.maxItems`, `references prop "${maxItems.prop}", which is not a number.`);
			if (prop.dynamic === true) fail$2(`${path}.maxItems`, "requires a static numeric property.");
		} else if (!Number.isInteger(maxItems.literal) || maxItems.literal < 0) fail$2(`${path}.maxItems`, "must be a nonnegative integer.");
	}
	let requiresAttributes;
	if (value.requiresAttributes !== void 0) {
		requiresAttributes = readNameList(value.requiresAttributes, `${path}.requiresAttributes`);
		for (const name of requiresAttributes) if (!Object.hasOwn(props, name)) fail$2(`${path}.requiresAttributes`, `references undeclared prop "${name}".`);
	}
	let compare;
	if (value.compare !== void 0) {
		compare = readNameList(value.compare, `${path}.compare`);
		for (const name of compare) if (!Object.hasOwn(props, name)) fail$2(`${path}.compare`, `references undeclared prop "${name}".`);
	}
	return {
		kind: typedKind,
		family: typedFamily,
		bind,
		initial,
		initialRule,
		...value.required === true ? { required: true } : {},
		...value.exclusive === true ? { exclusive: true } : {},
		...options ? { options } : {},
		...constraints ? { constraints } : {},
		...maxItems ? { maxItems } : {},
		...requiresAttributes ? { requiresAttributes } : {},
		...compare ? { compare } : {},
		...value.retain === false ? { retain: false } : {}
	};
}
function readDependency(value, path) {
	if (!isPlainRecord$1(value)) fail$2(path, "must be an object.");
	checkKeys$2(value, DEPENDENCY_KEYS$1, path);
	const id = value.id;
	if (typeof id !== "string" || !ID.test(id) || id.length > 160) fail$2(`${path}.id`, "must be a lowercase namespaced id.");
	let version;
	if (value.version !== void 0) {
		const raw = value.version;
		const parsed = parseLocalVersionRange(raw);
		if (parsed === null) fail$2(`${path}.version`, "must be an exact version or a supported range (exact, ^, ~, >=, <=, >, <).");
		version = parsed.source;
	}
	return {
		id,
		...version ? { version } : {}
	};
}
function readRequires(value) {
	if (!isPlainRecord$1(value)) fail$2("requires", "must be an object.");
	checkKeys$2(value, REQUIRES_KEYS, "requires");
	let kernel;
	if (value.kernel !== void 0) {
		const parsed = parseLocalVersionRange(value.kernel);
		if (parsed === null) fail$2("requires.kernel", "must be a supported kernel version range (exact, ^, ~, >=, <=, >, <).");
		kernel = parsed.source;
	}
	return { ...kernel ? { kernel } : {} };
}
/** Replacement declarations are bounded plain data and stay on the manifest. */
function readReplacement(value, ownId) {
	if (!isPlainRecord$1(value)) fail$2("replaces", "must be an object.");
	checkKeys$2(value, REPLACEMENT_KEYS, "replaces");
	const id = value.id;
	if (typeof id !== "string" || !ID.test(id) || id.length > 160) fail$2("replaces.id", "must be a lowercase namespaced id.");
	if (id !== ownId) fail$2("replaces.id", "must equal the declaring manifest id.");
	let version;
	if (value.version !== void 0) {
		const parsed = parseLocalVersionRange(value.version);
		if (parsed === null) fail$2("replaces.version", "must be an exact version or a supported range (exact, ^, ~, >=, <=, >, <).");
		version = parsed.source;
	}
	return {
		id,
		...version ? { version } : {}
	};
}
function readStyles(value) {
	if (!Array.isArray(value)) fail$2("styles", "must be an array of style-resource ids.");
	if (value.length > 32) fail$2("styles", `accepts at most 32 resources.`);
	const seen = /* @__PURE__ */ new Set();
	const styles = [];
	for (let index = 0; index < value.length; index += 1) {
		const raw = value[index];
		if (typeof raw !== "string" || raw.length === 0 || raw.length > 256) fail$2(`styles[${index}]`, `must be a non-empty string of at most 256 characters.`);
		if (!STYLE_ID$1.test(raw)) fail$2(`styles[${index}]`, "must be a bounded resource id.");
		if (seen.has(raw)) fail$2("styles", `resource "${raw}" is declared more than once.`);
		seen.add(raw);
		styles.push(raw);
	}
	return styles;
}
/**
* Validate and normalize one component manifest. Unknown fields, unsafe
* regexes, conflicting prop modes and invalid defaults are rejected; the
* result is fresh, bounded, JSON-only data.
*/
function readLocalComponentManifest(value) {
	if (typeof value === "object" && value !== null && validatedDefinitions.has(value)) return value;
	if (!isPlainRecord$1(value)) fail$2("manifest", "must be an object.");
	checkKeys$2(value, TOP_KEYS, "manifest");
	const id = value.id;
	if (typeof id !== "string" || id.length > 160 || !ID.test(id)) fail$2("id", "must be a lowercase namespaced id such as \"example/rating\".");
	const name = readIdentifier(value.name, "name");
	const version = value.version;
	if (typeof version !== "string" || version.length > 64 || !VERSION$1.test(version)) fail$2("version", "must be a semantic version such as 1.0.0.");
	if (value.protocol !== "reactive-md-component/v1") fail$2("protocol", `must be "${LOCAL_COMPONENT_PROTOCOL}".`);
	const rawForm = value.form;
	if (typeof rawForm !== "string" || !FORMS.has(rawForm)) fail$2("form", "must be \"leaf\", \"inline\" or \"container\".");
	const form = rawForm;
	if (!isPlainRecord$1(value.props)) fail$2("props", "must be an object.");
	const propNames = Object.keys(value.props).sort();
	if (propNames.length > 64) fail$2("props", `accepts at most 64 properties.`);
	const props = {};
	for (const propName of propNames) {
		if (DANGEROUS_KEYS$2.has(propName)) fail$2("props", `property "${propName}" is not allowed.`);
		if (!NAME.test(propName) || propName.length > 128) fail$2("props", `property "${propName}" must use lowercase kebab-case.`);
		props[propName] = readProp(value.props[propName], `props.${propName}`);
	}
	let bindings;
	if (value.bindings !== void 0) {
		if (!isPlainRecord$1(value.bindings)) fail$2("bindings", "must be an object.");
		const bindingKeys = Object.keys(value.bindings);
		if (bindingKeys.length === 0) fail$2("bindings", "must declare at least one binding slot.");
		if (bindingKeys.length > 16) fail$2("bindings", `accepts at most 16 slots.`);
		const slots = {};
		const attributes = /* @__PURE__ */ new Set();
		for (const key of bindingKeys) {
			if (DANGEROUS_KEYS$2.has(key)) fail$2("bindings", `field "${key}" is not allowed.`);
			if (!SLOT_NAME.test(key)) fail$2("bindings", `slot "${key}" must be a letter followed by letters or digits.`);
			if (RESERVED_SLOT_NAMES.has(key)) fail$2("bindings", `slot "${key}" is reserved by the runtime.`);
			const binding = readBinding(value.bindings[key], props, `bindings.${key}`, form === "container" && Array.isArray(value.rules) && value.rules.some((rule) => isPlainRecord$1(rule) && rule.kind === "options-body"));
			if (key !== "value" && (binding.kind !== "number" || binding.family !== "number")) fail$2(`bindings.${key}`, "numeric named slots support kind \"number\" with family \"number\" in this contract.");
			if (key !== "value" && isPlainRecord$1(value.bindings[key]) && value.bindings[key].exclusive === false) fail$2(`bindings.${key}.exclusive`, "named slots require exclusive ownership in this contract.");
			for (const attribute of [binding.bind, binding.initial]) {
				if (attributes.has(attribute)) fail$2("bindings", `attribute "${attribute}" is claimed by more than one binding.`);
				attributes.add(attribute);
			}
			slots[key] = key === "value" ? binding : {
				...binding,
				exclusive: true
			};
		}
		bindings = slots;
	}
	const children = value.children === void 0 ? void 0 : readChildren(value.children, form, "children");
	if (value.children !== void 0 && value.structure !== void 0) fail$2("manifest", "cannot declare both \"children\" and \"structure\"; use \"structure\".");
	const structure = value.structure !== void 0 ? readStructure(value.structure, form, "structure") : localStructureFromChildren(children);
	const rules = value.rules === void 0 ? void 0 : readRules(value.rules);
	const slotRelations = value.slotRelations === void 0 ? void 0 : readSlotRelations(value.slotRelations);
	if (value.legacyHost !== void 0) readBoolean(value.legacyHost, "legacyHost");
	const capabilities = readCapabilities(value.capabilities, "capabilities");
	const authoring = value.authoring === void 0 ? void 0 : readAuthoring$1(value.authoring, "authoring");
	const styles = value.styles === void 0 ? void 0 : readStyles(value.styles);
	const requires = value.requires === void 0 ? void 0 : readRequires(value.requires);
	const replaces = value.replaces === void 0 ? void 0 : readReplacement(value.replaces, id);
	let dependencies;
	if (value.dependencies !== void 0) {
		if (!Array.isArray(value.dependencies)) fail$2("dependencies", "must be an array.");
		if (value.dependencies.length > 16) fail$2("dependencies", `accepts at most 16 entries.`);
		const seen = /* @__PURE__ */ new Set();
		const list = [];
		for (let index = 0; index < value.dependencies.length; index += 1) {
			const dependency = readDependency(value.dependencies[index], `dependencies[${index}]`);
			if (seen.has(dependency.id)) fail$2("dependencies", `"${dependency.id}" is declared more than once.`);
			seen.add(dependency.id);
			list.push(dependency);
		}
		dependencies = list;
	}
	const definition = {
		id,
		name,
		version,
		protocol: LOCAL_COMPONENT_PROTOCOL,
		form,
		props,
		...bindings ? { bindings } : {},
		...children ? { children } : {},
		...structure && !children ? { structure } : {},
		...rules ? { rules } : {},
		...slotRelations ? { slotRelations } : {},
		...value.legacyHost === true ? { legacyHost: true } : {},
		capabilities,
		...authoring ? { authoring } : {},
		...styles ? { styles } : {},
		...requires ? { requires } : {},
		...dependencies ? { dependencies } : {},
		...replaces ? { replaces } : {}
	};
	if (localJsonByteLength(definition) > 65536) fail$2("manifest", `serialized size exceeds the ${MAX_LOCAL_SDK_MANIFEST_BYTES}-byte budget.`);
	const frozen = deepFreeze(definition);
	validatedDefinitions.add(frozen);
	return frozen;
}
/** `defineLocalComponent` validates, clones and freezes a manifest. */
function defineLocalComponent(input) {
	return readLocalComponentManifest(input);
}
function deepFreeze(value) {
	if (value === null || typeof value !== "object") return value;
	for (const key of Object.keys(value)) deepFreeze(value[key]);
	return Object.freeze(value);
}
function canonicalProp(prop) {
	return {
		kind: prop.kind,
		...prop.required === true ? { required: true } : {},
		...prop.static === true ? { static: true } : {},
		...prop.dynamic !== void 0 ? { dynamic: prop.dynamic } : {},
		...prop.default !== void 0 ? { default: prop.default } : {},
		...prop.nullable === true ? { nullable: true } : {},
		...prop.enum ? { enum: [...prop.enum] } : {},
		...prop.pattern !== void 0 ? { pattern: prop.pattern } : {},
		...prop.min !== void 0 ? { min: prop.min } : {},
		...prop.max !== void 0 ? { max: prop.max } : {},
		...prop.integer === true ? { integer: true } : {},
		...prop.positive === true ? { positive: true } : {},
		...prop.color === true ? { color: true } : {},
		...prop.coerce !== void 0 ? { coerce: prop.coerce } : {}
	};
}
function canonicalConstraint(constraint) {
	return "literal" in constraint ? { literal: constraint.literal } : { prop: constraint.prop };
}
function canonicalConstraints(constraints) {
	return {
		...constraints.min ? { min: canonicalConstraint(constraints.min) } : {},
		...constraints.max ? { max: canonicalConstraint(constraints.max) } : {},
		...constraints.step ? { step: canonicalConstraint(constraints.step) } : {}
	};
}
function canonicalBinding(binding) {
	const constraints = binding.constraints;
	return {
		kind: binding.kind,
		family: binding.family,
		bind: binding.bind,
		initial: binding.initial,
		initialRule: binding.initialRule,
		...binding.required === true ? { required: true } : {},
		...binding.exclusive === true ? { exclusive: true } : {},
		...binding.options ? { options: [...binding.options] } : {},
		...constraints ? { constraints: canonicalConstraints(constraints) } : {},
		...binding.maxItems ? { maxItems: canonicalConstraint(binding.maxItems) } : {},
		...binding.requiresAttributes ? { requiresAttributes: [...binding.requiresAttributes] } : {},
		...binding.compare ? { compare: [...binding.compare] } : {},
		...binding.retain === false ? { retain: false } : {}
	};
}
function canonicalStructure(structure) {
	return {
		rule: structure.rule,
		...structure.label !== void 0 ? { label: structure.label } : {},
		...structure.parents ? { parents: [...structure.parents] } : {},
		...structure.child !== void 0 ? { child: structure.child } : {},
		...structure.children ? { children: [...structure.children] } : {},
		...structure.min !== void 0 ? { min: structure.min } : {},
		...structure.max !== void 0 ? { max: structure.max } : {},
		...structure.inlineOnly !== void 0 ? { inlineOnly: structure.inlineOnly } : {},
		...structure.noComponents !== void 0 ? { noComponents: structure.noComponents } : {},
		...structure.valueAttribute !== void 0 ? { valueAttribute: structure.valueAttribute } : {},
		...structure.generatedPrefix !== void 0 ? { generatedPrefix: structure.generatedPrefix } : {},
		...structure.forbidSeparator !== void 0 ? { forbidSeparator: structure.forbidSeparator } : {},
		...structure.maxItems !== void 0 ? { maxItems: structure.maxItems } : {}
	};
}
function canonicalRule(rule) {
	const source = rule;
	const keys = Object.keys(source).sort();
	const out = {};
	for (const key of keys) {
		const value = source[key];
		out[key] = Array.isArray(value) ? value.map((item) => Array.isArray(item) ? [...item] : item) : value;
	}
	return out;
}
/**
* Deterministic, key-order-independent view of a normalized manifest.
*
* Authoring metadata and per-prop descriptions are deliberately excluded:
* editor copy must not change a component's compile semantic digest.
*/
function canonicalLocalComponent(definition) {
	const props = {};
	for (const name of Object.keys(definition.props).sort()) props[name] = canonicalProp(definition.props[name]);
	const bindings = {};
	if (definition.bindings) for (const name of Object.keys(definition.bindings).sort()) bindings[name] = canonicalBinding(definition.bindings[name]);
	return {
		protocol: definition.protocol,
		id: definition.id,
		name: definition.name,
		version: definition.version,
		form: definition.form,
		props,
		...definition.bindings ? { bindings } : {},
		...definition.children ? { children: {
			kind: definition.children.kind,
			...definition.children.required ? { required: true } : {}
		} } : {},
		...definition.structure ? { structure: canonicalStructure(definition.structure) } : {},
		...definition.rules ? { rules: definition.rules.map(canonicalRule) } : {},
		...definition.slotRelations ? { slotRelations: definition.slotRelations.map((relation) => ({ ...relation })) } : {},
		capabilities: {
			interactive: definition.capabilities.interactive,
			static: definition.capabilities.static,
			ssr: definition.capabilities.ssr,
			offline: definition.capabilities.offline
		},
		...definition.styles ? { styles: [...definition.styles] } : {},
		...definition.requires?.kernel ? { requires: { kernel: definition.requires.kernel } } : {},
		...definition.dependencies ? { dependencies: [...definition.dependencies].map((item) => ({ ...item })).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0) } : {},
		...definition.replaces ? { replaces: {
			id: definition.replaces.id,
			...definition.replaces.version ? { version: definition.replaces.version } : {}
		} } : {}
	};
}
var digestCache = /* @__PURE__ */ new WeakMap();
/** Stable semantic digest of one manifest. */
function localComponentDigest(definition) {
	const normalized = validatedDefinitions.has(definition) ? definition : readLocalComponentManifest(definition);
	const cached = digestCache.get(normalized);
	if (cached !== void 0) return cached;
	const digest = localHash(JSON.stringify(canonicalLocalComponent(normalized)));
	digestCache.set(normalized, digest);
	return digest;
}
/** Plain requirement record used by compiled documents and export checks. */
function localComponentRequirement(definition) {
	return Object.freeze({
		id: definition.id,
		name: definition.name,
		version: definition.version,
		digest: localComponentDigest(definition)
	});
}
/** Read-only namespaced-id check shared by presets and replacement records. */
function isLocalComponentId(value) {
	return typeof value === "string" && value.length > 0 && value.length <= 160 && ID.test(value);
}
// src/sdk/compat-profile.ts
/**
* The only released SDK line that emitted `reactive-md-config/v1` is 0.7.0.
* Tags v0.5.x and v0.6.x predate the SDK configuration protocol, so they have
* no v1 artifact identity to map.
*/
var LOCAL_COMPAT_PROFILES = Object.freeze([Object.freeze({
	name: "reactive-md-config/v1@0.7.0",
	protocol: LOCAL_CONFIG_PROTOCOL,
	sdkRange: "0.7.0",
	targetProtocol: LOCAL_CONFIG_PROTOCOL_V2,
	targetSdkRange: "0.7.0",
	preset: Object.freeze({
		id: "reactive-md/default",
		version: "0.7.0"
	}),
	legacyKeys: Object.freeze([Object.freeze({
		profile: LOCAL_CONFIG_PROTOCOL,
		algorithm: "external-components/v1"
	})]),
	source: "git tag v0.7.0:src/presets/default.ts and src/sdk/config.ts; docs/compatibility/compatibility-ch.md"
})]);
/** Find an exact preset-identity match; no version-range guessing. */
function findLocalCompatProfile(preset, profiles = LOCAL_COMPAT_PROFILES) {
	for (const profile of profiles) if (profile.preset.id === preset.id && profile.preset.version === preset.version) return profile;
}
/** SDK built-in profiles plus explicitly supplied extensions. */
function localCompatProfiles(additional = []) {
	return additional.length === 0 ? LOCAL_COMPAT_PROFILES : Object.freeze([...LOCAL_COMPAT_PROFILES, ...additional]);
}
// src/sdk/preset-core.ts
/**
* Preset packages are plain, frozen data. They are the semantic input of an
* assembly; React implementations, resources and build metadata stay in the
* host layer and are paired by manifest identity.
*/
var MAX_PRESET_ID_LENGTH = 160;
var MAX_PRESET_COMPONENTS = 256;
var MAX_PRESET_DEPENDENCIES = 32;
var MAX_PRESET_AUTHORING = 256;
var MAX_PRESET_TEXT_LENGTH = 4096;
var PRESET_ID = /^[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*$/;
var DANGEROUS_KEYS$1 = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
var PRESET_KEYS = /* @__PURE__ */ new Set([
	"protocol",
	"id",
	"version",
	"components",
	"authoring",
	"themes",
	"dependencies",
	"metadata"
]);
var AUTHORING_KEYS = /* @__PURE__ */ new Set([
	"title",
	"description",
	"category",
	"insertText"
]);
var METADATA_KEYS = /* @__PURE__ */ new Set(["title", "description"]);
var DEPENDENCY_KEYS = /* @__PURE__ */ new Set(["id", "version"]);
var validatedPresets$1 = /* @__PURE__ */ new WeakSet();
function presetError(path, message) {
	throw new Error(`Invalid local preset (${path}): ${message}`);
}
function isRecord$4(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
function checkKeys$1(record, allowed, path) {
	for (const key of Object.keys(record)) {
		if (DANGEROUS_KEYS$1.has(key)) presetError(path, `field "${key}" is not allowed.`);
		if (!allowed.has(key)) presetError(path, `unknown field "${key}".`);
	}
}
function readText$1(value, path) {
	if (!isRecord$4(value)) presetError(path, "must be a locale-keyed string map.");
	const out = {};
	for (const key of Object.keys(value).sort()) {
		if (DANGEROUS_KEYS$1.has(key)) presetError(path, `locale "${key}" is not allowed.`);
		if (!/^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/.test(key)) presetError(path, `locale "${key}" must look like "en" or "zh-CN".`);
		const text = value[key];
		if (typeof text !== "string" || text.length > MAX_PRESET_TEXT_LENGTH) presetError(path, `locale "${key}" must be a bounded string.`);
		out[key] = text;
	}
	return Object.freeze(out);
}
function readAuthoring(value) {
	if (!isRecord$4(value)) presetError("authoring", "must be an object.");
	checkKeys$1(value, AUTHORING_KEYS, "authoring");
	const out = {};
	if (value.title !== void 0) out.title = readText$1(value.title, "authoring.title");
	if (value.description !== void 0) out.description = readText$1(value.description, "authoring.description");
	if (value.category !== void 0) {
		if (typeof value.category !== "string" || value.category.length > 64) presetError("authoring.category", "must be a bounded string.");
		out.category = value.category;
	}
	if (value.insertText !== void 0) {
		if (typeof value.insertText !== "string" || value.insertText.length > MAX_PRESET_TEXT_LENGTH) presetError("authoring.insertText", "must be a bounded string.");
		out.insertText = value.insertText;
	}
	return Object.freeze(out);
}
function readAuthoringList(value, components) {
	if (!Array.isArray(value)) presetError("authoring", "must be an array.");
	if (value.length > MAX_PRESET_AUTHORING) presetError("authoring", `accepts at most ${MAX_PRESET_AUTHORING} entries.`);
	const known = new Set(components.map((component) => component.id));
	const seen = /* @__PURE__ */ new Set();
	const entries = [];
	for (let index = 0; index < value.length; index += 1) {
		const entry = value[index];
		if (!isRecord$4(entry)) presetError(`authoring[${index}]`, "must be an object.");
		checkKeys$1(entry, /* @__PURE__ */ new Set(["componentId", "authoring"]), `authoring[${index}]`);
		const componentId = entry.componentId;
		if (typeof componentId !== "string" || !isLocalComponentId(componentId)) presetError(`authoring[${index}].componentId`, "must be a lowercase namespaced id.");
		if (!known.has(componentId)) presetError(`authoring[${index}].componentId`, `"${componentId}" is not declared by this preset.`);
		if (seen.has(componentId)) presetError("authoring", `component "${componentId}" is declared more than once.`);
		seen.add(componentId);
		entries.push(Object.freeze({
			componentId,
			authoring: readAuthoring(entry.authoring)
		}));
	}
	return Object.freeze(entries.sort((a, b) => a.componentId < b.componentId ? -1 : a.componentId > b.componentId ? 1 : 0));
}
function readDependencies(value) {
	if (!Array.isArray(value)) presetError("dependencies", "must be an array.");
	if (value.length > MAX_PRESET_DEPENDENCIES) presetError("dependencies", `accepts at most ${MAX_PRESET_DEPENDENCIES} entries.`);
	const seen = /* @__PURE__ */ new Set();
	const dependencies = [];
	for (let index = 0; index < value.length; index += 1) {
		const entry = value[index];
		if (!isRecord$4(entry)) presetError(`dependencies[${index}]`, "must be an object.");
		checkKeys$1(entry, DEPENDENCY_KEYS, `dependencies[${index}]`);
		const id = entry.id;
		if (typeof id !== "string" || !isLocalComponentId(id)) presetError(`dependencies[${index}].id`, "must be a lowercase namespaced id.");
		if (seen.has(id)) presetError("dependencies", `"${id}" is declared more than once.`);
		seen.add(id);
		const version = entry.version;
		if (typeof version !== "string" || !isLocalVersion(version)) presetError(`dependencies[${index}].version`, "must be an exact semantic version.");
		dependencies.push(Object.freeze({
			id,
			version
		}));
	}
	return Object.freeze(dependencies.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
}
/**
* Semantic readers treat preset themes as opaque bounded data. The full SDK
* reader revalidates them through `defineLocalTheme`; the compiler projection
* must not pull theme CSS validation into its import graph.
*/
function readThemeList(value) {
	if (!Array.isArray(value)) presetError("themes", "must be an array.");
	const themes = [];
	const ids = /* @__PURE__ */ new Set();
	const names = /* @__PURE__ */ new Set();
	for (let index = 0; index < value.length; index += 1) {
		const entry = value[index];
		if (!isRecord$4(entry)) presetError(`themes[${index}]`, "must be an object.");
		const id = entry.id;
		const name = entry.name;
		const version = entry.version;
		if (typeof id !== "string" || id.length === 0) presetError(`themes[${index}].id`, "must be a non-empty string.");
		if (typeof name !== "string" || name.length === 0) presetError(`themes[${index}].name`, "must be a non-empty string.");
		if (typeof version !== "string" || !isLocalVersion(version)) presetError(`themes[${index}].version`, "must be a semantic version.");
		if (ids.has(id)) presetError("themes", `theme id "${id}" is declared more than once.`);
		if (names.has(name)) presetError("themes", `theme name "${name}" is declared more than once.`);
		ids.add(id);
		names.add(name);
		themes.push(Object.freeze({ ...entry }));
	}
	return Object.freeze(themes.sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
}
function readMetadata(value) {
	if (!isRecord$4(value)) presetError("metadata", "must be an object.");
	checkKeys$1(value, METADATA_KEYS, "metadata");
	return Object.freeze({
		...value.title === void 0 ? {} : { title: readText$1(value.title, "metadata.title") },
		...value.description === void 0 ? {} : { description: readText$1(value.description, "metadata.description") }
	});
}
/** Validate, clone and freeze one preset package. */
function readLocalPresetPackage$1(value) {
	if (isRecord$4(value) && validatedPresets$1.has(value)) return value;
	if (!isRecord$4(value)) presetError("preset", "must be an object.");
	checkKeys$1(value, PRESET_KEYS, "preset");
	if (value.protocol !== "reactive-md-preset/v1") presetError("protocol", `must be "${LOCAL_PRESET_PROTOCOL}".`);
	const id = value.id;
	if (typeof id !== "string" || id.length > MAX_PRESET_ID_LENGTH || !PRESET_ID.test(id)) presetError("id", "must be a lowercase namespaced id.");
	const version = value.version;
	if (typeof version !== "string" || !isLocalVersion(version)) presetError("version", "must be a semantic version such as \"1.0.0\".");
	if (!Array.isArray(value.components)) presetError("components", "must be an array.");
	if (value.components.length > MAX_PRESET_COMPONENTS) presetError("components", `accepts at most ${MAX_PRESET_COMPONENTS} components.`);
	const components = [];
	const ids = /* @__PURE__ */ new Set();
	const names = /* @__PURE__ */ new Set();
	for (let index = 0; index < value.components.length; index += 1) {
		let component;
		try {
			component = defineLocalComponent(value.components[index]);
		} catch (error) {
			presetError(`components[${index}]`, error instanceof Error ? error.message : String(error));
		}
		if (ids.has(component.id)) presetError("components", `component id "${component.id}" is declared more than once.`);
		if (names.has(component.name)) presetError("components", `component name "${component.name}" is declared more than once.`);
		ids.add(component.id);
		names.add(component.name);
		components.push(component);
	}
	const authoring = value.authoring === void 0 ? void 0 : readAuthoringList(value.authoring, components);
	const themes = value.themes === void 0 ? void 0 : readThemeList(value.themes);
	const dependencies = value.dependencies === void 0 ? void 0 : readDependencies(value.dependencies);
	const metadata = value.metadata === void 0 ? void 0 : readMetadata(value.metadata);
	const sourceComponents = value.components;
	const componentsOut = Object.isFrozen(sourceComponents) && sourceComponents.length === components.length && sourceComponents.every((entry, index) => entry === components[index]) ? sourceComponents : Object.freeze(components);
	const preset = Object.freeze({
		protocol: LOCAL_PRESET_PROTOCOL,
		id,
		version,
		components: componentsOut,
		...authoring ? { authoring } : {},
		...themes ? { themes } : {},
		...dependencies ? { dependencies } : {},
		...metadata ? { metadata } : {}
	});
	validatedPresets$1.add(preset);
	return preset;
}
/** Public factory mirroring `defineLocalComponent`. */
function defineLocalPreset(input) {
	return readLocalPresetPackage$1(input);
}
/**
* Semantic preset digest: sorted component id/version/digest plus exact
* dependency references. Authoring, metadata, themes and declaration order are
* intentionally excluded.
*/
function localPresetDigest(preset) {
	const validated = readLocalPresetPackage$1(preset);
	return localHash(JSON.stringify({
		protocol: LOCAL_PRESET_PROTOCOL,
		id: validated.id,
		version: validated.version,
		components: [...validated.components].map((component) => ({
			id: component.id,
			version: component.version,
			digest: localComponentDigest(component)
		})).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0),
		dependencies: [...validated.dependencies ?? []].map((dependency) => ({
			id: dependency.id,
			version: dependency.version
		})).sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0)
	}));
}
// src/sdk/assembly.ts
var SNAPSHOT_KEYS = /* @__PURE__ */ new Set([
	"protocol",
	"presets",
	"components",
	"replacementPolicy",
	"themes"
]);
var MAX_ASSEMBLY_PRESETS = 32;
var MAX_ASSEMBLY_COMPONENTS = 256;
var MAX_ASSEMBLY_THEMES = 32;
function fail$1(path, message) {
	throw new Error(`Invalid local SDK config (${path}): ${message}`);
}
function compareText(left, right) {
	return left < right ? -1 : left > right ? 1 : 0;
}
function sortById(items, id) {
	return [...items].sort((a, b) => compareText(id(a), id(b)));
}
function isRecord$3(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
function stableValue(value) {
	if (Array.isArray(value)) return value.map(stableValue);
	if (isRecord$3(value)) {
		const out = {};
		for (const key of Object.keys(value).sort(compareText)) out[key] = stableValue(value[key]);
		return out;
	}
	return value;
}
function sameSemantics(left, right) {
	return JSON.stringify(stableValue(left)) === JSON.stringify(stableValue(right));
}
function readAssemblyPresets(value) {
	if (!Array.isArray(value)) fail$1("assembly.presets", "must be an array.");
	if (value.length > MAX_ASSEMBLY_PRESETS) fail$1("assembly.presets", `accepts at most ${MAX_ASSEMBLY_PRESETS} packages.`);
	const presets = sortById(value.map((entry, index) => {
		try {
			return readLocalPresetPackage$1(entry);
		} catch (error) {
			fail$1(`assembly.presets[${index}]`, error instanceof Error ? error.message : String(error));
		}
	}), (preset) => preset.id);
	const seen = /* @__PURE__ */ new Set();
	for (const preset of presets) {
		if (seen.has(preset.id)) fail$1("assembly.presets", `preset "${preset.id}" is selected more than once.`);
		seen.add(preset.id);
	}
	return Object.freeze(presets);
}
function readAssemblyComponents(value) {
	if (!Array.isArray(value)) fail$1("assembly.components", "must be an array.");
	if (value.length > MAX_ASSEMBLY_COMPONENTS) fail$1("assembly.components", `accepts at most ${MAX_ASSEMBLY_COMPONENTS} components.`);
	const components = sortById(value.map((entry, index) => {
		try {
			return readLocalComponentManifest(entry);
		} catch (error) {
			fail$1(`assembly.components[${index}]`, error instanceof Error ? error.message : String(error));
		}
	}), (component) => component.id);
	return Object.freeze(components);
}
/**
* Host themes are opaque bounded data at this layer. The full SDK reader
* revalidates them through `defineLocalTheme`; the compiler projection must not
* load theme CSS validation.
*/
function readAssemblyThemes(value) {
	if (!Array.isArray(value)) fail$1("assembly.themes", "must be an array.");
	if (value.length > MAX_ASSEMBLY_THEMES) fail$1("assembly.themes", `accepts at most ${MAX_ASSEMBLY_THEMES} themes.`);
	const ids = /* @__PURE__ */ new Set();
	return Object.freeze(sortById(value.map((entry, index) => {
		if (!isRecord$3(entry)) fail$1(`assembly.themes[${index}]`, "must be an object.");
		const id = entry.id;
		const name = entry.name;
		const version = entry.version;
		if (typeof id !== "string" || id.length === 0) fail$1(`assembly.themes[${index}].id`, "must be a non-empty string.");
		if (typeof name !== "string" || name.length === 0) fail$1(`assembly.themes[${index}].name`, "must be a non-empty string.");
		if (typeof version !== "string" || !isLocalVersion(version)) fail$1(`assembly.themes[${index}].version`, "must be a semantic version.");
		if (ids.has(id)) fail$1("assembly.themes", `theme id "${id}" is declared more than once.`);
		ids.add(id);
		return Object.freeze({ ...entry });
	}), (theme) => theme.id));
}
/** Validate and freeze a transported assembly snapshot. */
function readLocalAssemblySnapshot(value) {
	if (!isRecord$3(value)) fail$1("assembly", "must be an object.");
	for (const key of Object.keys(value)) if (!SNAPSHOT_KEYS.has(key)) fail$1("assembly", `unknown field "${key}".`);
	if (value.protocol !== "reactive-md-assembly/v1") fail$1("assembly.protocol", `must be "${LOCAL_ASSEMBLY_PROTOCOL}".`);
	const replacementPolicy = value.replacementPolicy;
	if (replacementPolicy !== "allow" && replacementPolicy !== "forbid") fail$1("assembly.replacementPolicy", "must be \"allow\" or \"forbid\".");
	return Object.freeze({
		protocol: LOCAL_ASSEMBLY_PROTOCOL,
		presets: readAssemblyPresets(value.presets),
		components: readAssemblyComponents(value.components),
		replacementPolicy,
		themes: readAssemblyThemes(value.themes)
	});
}
function orderPresets(presets) {
	const byId = new Map(presets.map((preset) => [preset.id, preset]));
	const state = /* @__PURE__ */ new Map();
	const ordered = [];
	const visit = (id) => {
		const status = state.get(id);
		if (status === "done") return;
		if (status === "visiting") fail$1("assembly.presets", `preset dependency cycle at "${id}".`);
		const preset = byId.get(id);
		if (!preset) fail$1("assembly.presets", `missing preset dependency "${id}".`);
		state.set(id, "visiting");
		for (const dependency of sortById(preset.dependencies ?? [], (item) => item.id)) {
			const target = byId.get(dependency.id);
			if (!target) fail$1("assembly.presets", `preset "${preset.id}" requires missing preset "${dependency.id}".`);
			if (!isLocalVersion(dependency.version)) fail$1("assembly.presets", `preset dependency "${dependency.id}" must use an exact version.`);
			if (target.version !== dependency.version) fail$1("assembly.presets", `preset "${preset.id}" requires "${dependency.id}" ${dependency.version}, but ${target.version} is installed.`);
			visit(dependency.id);
		}
		state.set(id, "done");
		ordered.push(preset);
	};
	for (const id of [...byId.keys()].sort(compareText)) visit(id);
	return Object.freeze(ordered);
}
function propSemantics(prop) {
	const { description: _description, ...rest } = prop;
	return rest;
}
function structureOf(definition) {
	return definition.structure ?? localStructureFromChildren(definition.children) ?? null;
}
function capabilitySuperset(replacement, target) {
	for (const key of [
		"interactive",
		"static",
		"ssr",
		"offline"
	]) if (target.capabilities[key] && !replacement.capabilities[key]) return false;
	return true;
}
function assertReplacementCompatible(target, replacement) {
	const base = target.definition;
	const next = replacement.definition;
	const path = `assembly.replacements["${base.id}"]`;
	if (base.id !== next.id || base.name !== next.name) fail$1(path, "the replacement must keep the target id and tag name.");
	if (base.form !== next.form) fail$1(path, "the replacement must keep the target form.");
	for (const name of Object.keys(base.props)) {
		const targetProp = base.props[name];
		const nextProp = next.props[name];
		if (!nextProp) fail$1(path, `the replacement removed prop "${name}".`);
		if (!sameSemantics(propSemantics(targetProp), propSemantics(nextProp))) fail$1(path, `the replacement changed the semantics of prop "${name}".`);
	}
	for (const name of Object.keys(next.props)) {
		if (Object.hasOwn(base.props, name)) continue;
		if (next.props[name].required === true) fail$1(path, `the replacement added required prop "${name}".`);
	}
	const baseBindings = base.bindings ?? {};
	const nextBindings = next.bindings ?? {};
	const baseSlots = Object.keys(baseBindings).sort(compareText);
	if (!sameSemantics(baseSlots, Object.keys(nextBindings).sort(compareText))) fail$1(path, "the replacement must keep the target binding slots unchanged.");
	for (const slot of baseSlots) if (!sameSemantics(baseBindings[slot], nextBindings[slot])) fail$1(path, `the replacement changed binding slot "${slot}".`);
	if (!sameSemantics(structureOf(base), structureOf(next))) fail$1(path, "the replacement changed the target child structure.");
	if (!sameSemantics(base.rules ?? [], next.rules ?? [])) fail$1(path, "the replacement changed semantic rules.");
	if (!sameSemantics(base.slotRelations ?? [], next.slotRelations ?? [])) fail$1(path, "the replacement changed slot relations.");
	if (base.legacyHost === true !== (next.legacyHost === true)) fail$1(path, "the replacement changed legacyHost.");
	if (!capabilitySuperset(next, base)) fail$1(path, "the replacement downgraded a declared capability.");
}
function replacementMatches(target, replacement) {
	if (target.id !== replacement.id) return false;
	if (replacement.version === void 0) return true;
	if (parseLocalVersionRange(replacement.version) === null) return false;
	return localVersionSatisfies(target.version, replacement.version);
}
function replacementRecord(target, replacement) {
	return Object.freeze({
		id: target.definition.id,
		name: target.definition.name,
		fromVersion: target.definition.version,
		toVersion: replacement.definition.version,
		fromDigest: localComponentDigest(target.definition),
		toDigest: localComponentDigest(replacement.definition),
		...target.origin.kind === "preset" ? { fromPreset: target.origin.id } : {},
		...replacement.origin.kind === "preset" ? { toPreset: replacement.origin.id } : {}
	});
}
function collectContributions(presets, components) {
	const contributions = [];
	let index = 0;
	for (const preset of presets) for (const definition of preset.components) {
		contributions.push({
			definition,
			origin: {
				kind: "preset",
				id: preset.id
			},
			index
		});
		index += 1;
	}
	for (const definition of sortById(components, (item) => item.id)) {
		contributions.push({
			definition,
			origin: { kind: "external" },
			index
		});
		index += 1;
	}
	return contributions;
}
/** Preset authoring entries indexed by preset id and component id. */
function indexPresetAuthoring(presets) {
	const index = /* @__PURE__ */ new Map();
	for (const preset of presets) {
		if (preset.authoring === void 0 || preset.authoring.length === 0) continue;
		index.set(preset.id, new Map(preset.authoring.map((entry) => [entry.componentId, entry.authoring])));
	}
	return index;
}
/**
* Field-level authoring merge. Fields present on the override win; missing
* fields keep the base value. Authoring never enters digests or keys.
*/
function mergeAuthoring(base, override) {
	if (override === void 0) return base;
	if (base === void 0) return override;
	return Object.freeze({
		...base.title !== void 0 ? { title: base.title } : {},
		...base.description !== void 0 ? { description: base.description } : {},
		...base.category !== void 0 ? { category: base.category } : {},
		...base.insertText !== void 0 ? { insertText: base.insertText } : {},
		...override.title !== void 0 ? { title: override.title } : {},
		...override.description !== void 0 ? { description: override.description } : {},
		...override.category !== void 0 ? { category: override.category } : {},
		...override.insertText !== void 0 ? { insertText: override.insertText } : {}
	});
}
/** Manifest authoring with the contributing preset's override applied. */
function effectiveAuthoring(contribution, presetAuthoring) {
	const presetOverride = contribution.origin.kind === "preset" ? presetAuthoring.get(contribution.origin.id)?.get(contribution.definition.id) : void 0;
	return mergeAuthoring(contribution.definition.authoring, presetOverride);
}
/** Revalidate and freeze a manifest carrying merged authoring. */
function withResolvedAuthoring(definition, authoring) {
	if (authoring === void 0 || authoring === definition.authoring) return definition;
	return readLocalComponentManifest({
		...definition,
		authoring
	});
}
function resolveContributions(contributions, replacementPolicy, presetAuthoring) {
	const groups = /* @__PURE__ */ new Map();
	for (const contribution of contributions) {
		const group = groups.get(contribution.definition.id);
		if (group) group.push(contribution);
		else groups.set(contribution.definition.id, [contribution]);
	}
	const active = [];
	const replacements = [];
	for (const group of groups.values()) {
		if (group.length === 1) {
			const only = group[0];
			if (only.definition.replaces !== void 0) {
				if (replacementPolicy === "forbid") fail$1("assembly.replacements", `replacement for "${only.definition.id}" is forbidden.`);
				fail$1("assembly.replacements", `replacement for "${only.definition.id}" has no base contribution.`);
			}
			const authoring = effectiveAuthoring(only, presetAuthoring);
			active.push({
				...only,
				position: only.index,
				...authoring !== void 0 ? { authoring } : {}
			});
			continue;
		}
		const replacers = group.filter((item) => item.definition.replaces !== void 0);
		if (replacementPolicy === "forbid" && replacers.length > 0) fail$1("assembly.replacements", `replacement for "${group[0].definition.id}" is forbidden.`);
		if (replacers.length === 0) fail$1("assembly.components", `component id "${group[0].definition.id}" is declared more than once.`);
		if (replacers.length > 1) fail$1("assembly.replacements", `component id "${group[0].definition.id}" has more than one replacement.`);
		if (group.length > 2) fail$1("assembly.replacements", `component id "${group[0].definition.id}" has ambiguous base contributions.`);
		const replacement = replacers[0];
		const targets = group.filter((item) => item !== replacement);
		if (targets.length !== 1) fail$1("assembly.replacements", `component id "${group[0].definition.id}" must have exactly one base.`);
		const target = targets[0];
		if (target.definition.replaces !== void 0) fail$1("assembly.replacements", `component id "${group[0].definition.id}" uses a replacement chain.`);
		const declaration = replacement.definition.replaces;
		if (!replacementMatches(target.definition, declaration)) fail$1("assembly.replacements", `replacement for "${target.definition.id}" does not match base version ${target.definition.version}.`);
		assertReplacementCompatible(target, replacement);
		const authoring = mergeAuthoring(effectiveAuthoring(target, presetAuthoring), effectiveAuthoring(replacement, presetAuthoring));
		active.push({
			...replacement,
			position: target.index,
			...authoring !== void 0 ? { authoring } : {}
		});
		replacements.push(replacementRecord(target, replacement));
	}
	active.sort((left, right) => left.position - right.position);
	return {
		active: Object.freeze(active),
		replacements: Object.freeze(sortById(replacements, (item) => item.id))
	};
}
function validateActiveRegistry(active) {
	const names = /* @__PURE__ */ new Map();
	const byId = new Map(active.map((item) => [item.definition.id, item.definition]));
	for (const item of active) {
		const definition = item.definition;
		const previous = names.get(definition.name);
		if (previous !== void 0) {
			if (previous.origin.kind === "preset" || item.origin.kind === "preset") fail$1("assembly.components", `name "${definition.name}" conflicts with a built-in component "${previous.definition.id}".`);
			fail$1("assembly.components", `component name "${definition.name}" is declared more than once by "${previous.definition.id}" and "${definition.id}".`);
		}
		names.set(definition.name, item);
		const kernel = definition.requires?.kernel;
		if (kernel !== void 0 && !localVersionSatisfies("0.7.0", kernel)) fail$1("assembly.components", `component "${definition.id}" requires kernel ${kernel}, but ${LOCAL_SDK_VERSION} is installed.`);
		for (const dependency of definition.dependencies ?? []) {
			const installed = byId.get(dependency.id);
			if (!installed) fail$1("assembly.dependencies", `component "${definition.id}" requires missing component "${dependency.id}".`);
			if (dependency.version !== void 0 && !localVersionSatisfies(installed.version, dependency.version)) fail$1("assembly.dependencies", `component "${definition.id}" requires "${dependency.id}" ${dependency.version}, but version ${installed.version} is installed.`);
		}
	}
	const state = /* @__PURE__ */ new Map();
	const visit = (id, path) => {
		const status = state.get(id);
		if (status === "done") return;
		if (status === "visiting") fail$1("assembly.dependencies", `dependency cycle: ${[...path, id].join(" -> ")}.`);
		state.set(id, "visiting");
		for (const dependency of byId.get(id)?.dependencies ?? []) if (byId.has(dependency.id)) visit(dependency.id, [...path, id]);
		state.set(id, "done");
	};
	for (const id of [...byId.keys()].sort(compareText)) visit(id, []);
}
function mergeThemes(presets, hostThemes) {
	const byId = /* @__PURE__ */ new Map();
	const byName = /* @__PURE__ */ new Map();
	const add = (theme, origin) => {
		if (byId.get(theme.id)) fail$1("assembly.themes", `theme id "${theme.id}" is declared by both ${origin} and another source.`);
		if (byName.get(theme.name)) fail$1("assembly.themes", `theme name "${theme.name}" is declared by both ${origin} and another source.`);
		byId.set(theme.id, theme);
		byName.set(theme.name, theme);
	};
	for (const preset of presets) for (const theme of preset.themes ?? []) add(theme, `preset:${preset.id}`);
	for (const theme of hostThemes) add(theme, "external");
	return Object.freeze(sortById([...byId.values()], (theme) => theme.id));
}
function presetDigests(presets) {
	return Object.freeze(sortById(presets.map((preset) => ({
		id: preset.id,
		version: preset.version,
		digest: localPresetDigest(preset)
	})), (item) => item.id));
}
/** Stable semantic configuration key. */
function localAssemblyKey(presets, registry, replacements) {
	return localHash(JSON.stringify({
		protocol: LOCAL_CONFIG_PROTOCOL_V2,
		presets: sortById(presets, (item) => item.id),
		registry: [...registry].map((component) => ({
			id: component.id,
			name: component.name,
			version: component.version,
			digest: localComponentDigest(component)
		})).sort((a, b) => compareText(a.id, b.id)),
		replacements: sortById(replacements, (item) => item.id)
	}));
}
/**
* Legacy v1 key for the default-only profile. It is emitted as an alias, never
* as the primary identity of a v2 configuration.
*/
function localLegacyV1Key(preset, components) {
	return localHash(JSON.stringify({
		protocol: LOCAL_CONFIG_PROTOCOL,
		presets: [{
			id: preset.id,
			version: preset.version
		}],
		components: [...components].map((component) => ({
			id: component.id,
			version: component.version,
			digest: localComponentDigest(component)
		})).sort((a, b) => compareText(a.id, b.id))
	}));
}
/** Resolve a validated snapshot into a frozen registry and semantic identity. */
function resolveLocalAssembly(snapshot, options = {}) {
	const ordered = orderPresets(snapshot.presets);
	const resolved = resolveContributions(collectContributions(ordered, snapshot.components), snapshot.replacementPolicy, indexPresetAuthoring(ordered));
	validateActiveRegistry(resolved.active);
	const registry = Object.freeze(resolved.active.map((item) => withResolvedAuthoring(item.definition, item.authoring)));
	const components = Object.freeze(sortById(resolved.active.filter((item) => item.origin.kind === "external").map((item) => item.definition), (item) => item.id));
	const presets = presetDigests(ordered);
	const themes = mergeThemes(ordered, snapshot.themes);
	const key = localAssemblyKey(presets, registry, resolved.replacements);
	const legacyKeys = [];
	const legacyProfile = options.legacyProfiles === void 0 || ordered.length !== 1 || resolved.replacements.length !== 0 ? void 0 : findLocalCompatProfile({
		id: ordered[0].id,
		version: ordered[0].version
	}, options.legacyProfiles);
	const legacyRule = legacyProfile?.legacyKeys[0];
	if (legacyProfile !== void 0 && legacyRule !== void 0) legacyKeys.push(Object.freeze({
		profile: legacyRule.profile,
		key: localLegacyV1Key(legacyProfile.preset, components)
	}));
	return Object.freeze({
		presets,
		components,
		replacements: resolved.replacements,
		registry,
		themes,
		key,
		legacyKeys: Object.freeze(legacyKeys)
	});
}
/**
* Build the frozen public configuration view from one resolved assembly.
* Readers keep their own normalization, profile selection and legacy-key
* rules; this function owns only the shared result shape.
*/
function localConfigFromAssembly(assembly, resolved, legacyKeys = resolved.legacyKeys) {
	return Object.freeze({
		protocol: LOCAL_CONFIG_PROTOCOL_V2,
		assembly,
		key: resolved.key,
		presets: resolved.presets,
		components: resolved.components,
		replacements: resolved.replacements,
		registry: resolved.registry,
		themes: resolved.themes,
		legacyKeys: Object.freeze(legacyKeys)
	});
}
function localAssemblyIdentity(input) {
	return Object.freeze({
		protocol: "reactive-md-assembly-seal/v1",
		configKey: input.key,
		presets: Object.freeze(sortById(input.presets, (item) => item.id)),
		components: Object.freeze(sortById(input.registry.map(localComponentRequirement), (item) => item.id)),
		replacements: Object.freeze(sortById(input.replacements, (item) => item.id)),
		legacyKeys: Object.freeze(sortById(input.legacyKeys, (item) => item.key))
	});
}
/** Deterministic digest over the assembly identity. */
function localAssemblySeal(input) {
	return localHash(JSON.stringify(localAssemblyIdentity(input)));
}
// src/sdk/config-validation.ts
/**
* Theme-free SDK configuration validation shared by the full SDK entry and the
* single-compilation reader.
*
* This module deliberately imports neither `theme.ts` nor the default preset.
* Callers pass their assembled built-in component set, so the same rules serve
* an assembly that installs `defaultPreset.components` and one that installs no
* preset at all.
*/
/** Aggregate serialized-size budget for one configuration, excluding themes. */
var MAX_LOCAL_SDK_CONFIG_BYTES = 16777216;
var DANGEROUS_KEYS = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]);
var CONFIG_KEYS = /* @__PURE__ */ new Set([
	"protocol",
	"key",
	"assembly",
	"presets",
	"components",
	"replacements",
	"registry",
	"themes",
	"legacyKeys"
]);
function fail(path, message) {
	throw new Error(`Invalid local SDK config (${path}): ${message}`);
}
function isPlainRecord(value) {
	if (typeof value !== "object" || value === null || Array.isArray(value)) return false;
	const prototype = Object.getPrototypeOf(value);
	return prototype === Object.prototype || prototype === null;
}
function checkKeys(record, allowed, path) {
	for (const key of Object.keys(record)) {
		if (DANGEROUS_KEYS.has(key)) fail(path, `field "${key}" is not allowed.`);
		if (!allowed.has(key)) fail(path, `unknown field "${key}".`);
	}
}
/**
* Read the selected preset references against the current default identity and
* any legacy identities supported by compatibility profiles. Omitting
* `presets` selects the current default; `"default"` normalizes to it. A
* declared identity must match a profile exactly, including its version.
*/
function readPresetReferences(value, preset, profiles = []) {
	if (value === void 0) return Object.freeze([preset]);
	if (!Array.isArray(value)) fail("presets", "must be an array.");
	if (value.length === 0) fail("presets", "must select at least the default preset.");
	const candidates = [];
	for (const candidate of [preset, ...profiles.map((profile) => profile.preset)]) if (!candidates.some((entry) => entry.id === candidate.id && entry.version === candidate.version)) candidates.push(candidate);
	const seen = /* @__PURE__ */ new Set();
	const presets = [];
	for (let index = 0; index < value.length; index += 1) {
		const entry = value[index];
		let id;
		let version;
		if (typeof entry === "string") id = entry;
		else if (isPlainRecord(entry)) {
			if (entry.id === void 0 || typeof entry.id !== "string") fail(`presets[${index}].id`, "must be a string.");
			id = entry.id;
			if (entry.version !== void 0) {
				if (typeof entry.version !== "string") fail(`presets[${index}].version`, "must be a string.");
				version = entry.version;
			}
		} else fail(`presets[${index}]`, "must be a preset id or preset reference.");
		const normalized = id === "default" ? preset.id : id;
		const matches = candidates.filter((candidate) => candidate.id === normalized);
		if (matches.length === 0) fail(`presets[${index}]`, `unsupported preset "${id}"; local.config.migration-unsupported: no compatibility profile matches this identity.`);
		const match = version === void 0 ? matches.length === 1 ? matches[0] : void 0 : matches.find((candidate) => candidate.version === version);
		if (match === void 0) fail(`presets[${index}]`, `unsupported preset "${id}"${version === void 0 ? "" : ` version "${version}"`}; local.config.migration-unsupported: no compatibility profile matches this identity.`);
		if (seen.has(match.id)) fail("presets", `"${match.id}" is selected more than once.`);
		if (presets.length > 0 && presets[0].id !== match.id) fail("presets", "reactive-md-config/v1 selects exactly one default preset identity.");
		seen.add(match.id);
		presets.push(match);
	}
	return Object.freeze(presets);
}
/** Verify the optional legacy component snapshot against installed manifests. */
function validateCompatProfileComponents(profile, installed) {
	if (profile.components === void 0) return;
	const byId = new Map(installed.map((component) => [component.id, component]));
	for (const expected of profile.components) {
		const actual = byId.get(expected.id);
		if (!actual || actual.name !== expected.name || actual.version !== expected.version || localComponentDigest(actual) !== expected.digest) fail("presets", `local.config.migration-unsupported: profile "${profile.name}" cannot map legacy component "${expected.id}".`);
	}
}
function builtinIds(defaults) {
	const ids = /* @__PURE__ */ new Set();
	for (const component of defaults) {
		ids.add(component.name);
		ids.add(component.id);
	}
	return ids;
}
function validateDependencies(components, defaults) {
	const byId = new Map(components.map((component) => [component.id, component]));
	const builtins = builtinIds(defaults);
	for (const component of components) {
		const kernelRange = component.requires?.kernel;
		if (kernelRange !== void 0 && !localVersionSatisfies("0.7.0", kernelRange)) fail("requires", `component "${component.id}" requires kernel ${kernelRange}, but ${LOCAL_SDK_VERSION} is installed.`);
		for (const dependency of component.dependencies ?? []) {
			const installed = byId.get(dependency.id)?.version ?? (builtins.has(dependency.id) ? "0.7.0" : null);
			if (installed === null) fail("dependencies", `component "${component.id}" requires missing component "${dependency.id}".`);
			if (dependency.version !== void 0 && !localVersionSatisfies(installed, dependency.version)) fail("dependencies", `component "${component.id}" requires "${dependency.id}" ${dependency.version}, but version ${installed} is installed.`);
		}
	}
	const state = /* @__PURE__ */ new Map();
	const visit = (id, path) => {
		const status = state.get(id);
		if (status === "done") return;
		if (status === "visiting") fail("dependencies", `dependency cycle: ${[...path, id].join(" -> ")}.`);
		state.set(id, "visiting");
		const component = byId.get(id);
		for (const dependency of component?.dependencies ?? []) if (byId.has(dependency.id)) visit(dependency.id, [...path, id]);
		state.set(id, "done");
	};
	for (const id of byId.keys()) visit(id, []);
}
/**
* Read external component manifests. Built-in names, kernel grammar names,
* HTML tag names and the theme declaration are reserved, and external ids may
* not collide with each other or with the built-in registry.
*/
function readComponents(value, defaults) {
	if (value === void 0) return Object.freeze([]);
	if (!Array.isArray(value)) fail("components", "must be an array.");
	if (value.length > 64) fail("components", `accepts at most 64 external components.`);
	const reserved = new Set([
		...defaults.map((component) => component.name),
		...LOCAL_KERNEL_DECLARATIONS.map((schema) => schema.name),
		...LOCAL_HTML_NAMES
	].map((name) => name.toLowerCase()));
	reserved.add("theme");
	const ids = new Set(defaults.map((component) => component.id));
	const names = /* @__PURE__ */ new Set();
	const components = [];
	for (let index = 0; index < value.length; index += 1) {
		const component = readLocalComponentManifest(value[index]);
		if (reserved.has(component.name.toLowerCase())) fail(`components[${index}]`, `name "${component.name}" conflicts with a built-in component, HTML tag or theme declaration.`);
		if (ids.has(component.id)) fail("components", `component id "${component.id}" is declared more than once.`);
		if (names.has(component.name)) fail("components", `component name "${component.name}" is declared more than once.`);
		ids.add(component.id);
		names.add(component.name);
		components.push(component);
	}
	validateDependencies(components, defaults);
	return Object.freeze(components);
}
// src/presets/identity.ts
/**
* Shared identity of the built-in default preset. Keeping the identity in one
* plain-data module lets the minimal compiler validate preset references
* without importing the preset implementation or its component table.
*/
var DEFAULT_PRESET_ID$1 = "reactive-md/default";
var DEFAULT_PRESET_VERSION$1 = LOCAL_SDK_VERSION;
// src/presets/default-authoring.ts
var DEFAULT_AUTHORING_GROUPS = Object.freeze([
	{
		id: "input",
		title: {
			en: "Input controls",
			zh: "输入控件"
		}
	},
	{
		id: "action",
		title: {
			en: "Interactive tools",
			zh: "交互工具"
		}
	},
	{
		id: "layout",
		title: {
			en: "Content layout",
			zh: "内容组织"
		}
	},
	{
		id: "data",
		title: {
			en: "Data visualization",
			zh: "数据可视化"
		}
	},
	{
		id: "hint",
		title: {
			en: "Feedback",
			zh: "提示反馈"
		}
	}
]);
var GROUP_IDS = new Set(DEFAULT_AUTHORING_GROUPS.map((group) => group.id));
var DEFAULT_COMPONENT_AUTHORING = Object.freeze({
	jump: {
		title: {
			en: "Jump and anchor",
			zh: "跳转与锚点"
		},
		description: {
			en: "Link to a named position in this document.",
			zh: "跳到当前文档中的指定位置。"
		},
		category: "action",
		keywords: {
			en: [
				"jump",
				"anchor",
				"navigation"
			],
			zh: [
				"跳转",
				"锚点",
				"导航"
			]
		},
		insertText: {
			en: "<jump to=\"{{bind:destination}}\" appearance=\"button\" color=\"#2563eb\">View results</jump>\n\n<anchor id=\"{{bind:destination}}\">\n\n{{selection:Results appear here.}}",
			zh: "<jump to=\"{{bind:destination}}\" appearance=\"button\" color=\"#2563eb\">查看结果</jump>\n\n<anchor id=\"{{bind:destination}}\">\n\n{{selection:结果显示在这里。}}"
		},
		extended: true
	},
	anchor: {
		title: {
			en: "Anchor",
			zh: "锚点"
		},
		description: {
			en: "Name a destination for document links.",
			zh: "为文档内的跳转指定目标位置。"
		},
		category: "layout",
		keywords: {
			en: [
				"anchor",
				"target",
				"destination"
			],
			zh: [
				"锚点",
				"目标",
				"位置"
			]
		},
		insertText: {
			en: "<anchor id=\"{{bind:destination}}\">",
			zh: "<anchor id=\"{{bind:destination}}\">"
		},
		extended: true
	},
	text: {
		title: {
			en: "Colored text",
			zh: "文字颜色"
		},
		description: {
			en: "Give selected words a foreground color.",
			zh: "为选中的局部文字指定颜色。"
		},
		category: "hint",
		keywords: {
			en: [
				"text",
				"color",
				"foreground"
			],
			zh: [
				"文字",
				"颜色",
				"前景"
			]
		},
		inline: true,
		insertText: {
			en: "<text color=\"#a2273a\">{{selection:Important reminder}}</text>",
			zh: "<text color=\"#a2273a\">{{selection:重要提醒}}</text>"
		},
		extended: true
	},
	section: {
		title: {
			en: "Colored section",
			zh: "正文颜色"
		},
		description: {
			en: "Apply a shared text color to several paragraphs.",
			zh: "为一段或多段正文指定统一颜色。"
		},
		category: "layout",
		keywords: {
			en: [
				"section",
				"color",
				"paragraph"
			],
			zh: [
				"正文",
				"段落",
				"颜色"
			]
		},
		insertText: {
			en: "<section color=\"#45536f\">\n\n{{selection:Your paragraphs go here.}}\n\n</section>",
			zh: "<section color=\"#45536f\">\n\n{{selection:在这里填写正文。}}\n\n</section>"
		},
		extended: true
	},
	"multi-select": {
		title: {
			en: "Multiple selection",
			zh: "多选"
		},
		description: {
			en: "Choose up to two items and read their values.",
			zh: "最多选择两个选项，公开选项值数组。"
		},
		category: "input",
		keywords: {
			en: [
				"multiple",
				"select",
				"subjects",
				"checkbox"
			],
			zh: [
				"多选",
				"选项",
				"主题"
			]
		},
		insertText: {
			en: "<multi-select bind=\"{{bind:subjects}}\" label=\"Subjects\" max-selected=\"2\">\n<option value=\"math\">Math</option>\n<option value=\"physics\">Physics</option>\n<option value=\"chemistry\">Chemistry</option>\n</multi-select>",
			zh: "<multi-select bind=\"{{bind:subjects}}\" label=\"主题\" max-selected=\"2\">\n<option value=\"math\">数学</option>\n<option value=\"physics\">物理</option>\n<option value=\"chemistry\">化学</option>\n</multi-select>"
		},
		extended: true
	},
	"range-slider": {
		title: {
			en: "Interval slider",
			zh: "区间滑块"
		},
		description: {
			en: "Choose the lower and upper bounds of an interval.",
			zh: "同时选择区间的起点和终点。"
		},
		category: "input",
		keywords: {
			en: [
				"range",
				"interval",
				"slider",
				"bounds"
			],
			zh: [
				"区间",
				"滑块",
				"上下限"
			]
		},
		insertText: {
			en: "<range-slider label=\"Interval\" bind-start=\"{{bind:low}}\" bind-end=\"{{bind:high}}\" initial-start=\"20\" initial-end=\"80\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<range-slider label=\"观察区间\" bind-start=\"{{bind:low}}\" bind-end=\"{{bind:high}}\" initial-start=\"20\" initial-end=\"80\" min=\"0\" max=\"100\" step=\"1\">"
		},
		extended: true
	},
	coordinate: {
		title: {
			en: "Coordinate point",
			zh: "二维坐标"
		},
		description: {
			en: "Drag a point or change its two coordinates.",
			zh: "拖动坐标点，或直接修改两个坐标。"
		},
		category: "input",
		keywords: {
			en: [
				"coordinate",
				"point",
				"drag",
				"geometry"
			],
			zh: [
				"坐标",
				"拖动",
				"几何"
			]
		},
		insertText: {
			en: "<coordinate label=\"Point\" bind-x=\"{{bind:px}}\" bind-y=\"{{bind:py}}\" initial-x=\"1\" initial-y=\"2\" x-min=\"-5\" x-max=\"5\" y-min=\"-5\" y-max=\"5\">",
			zh: "<coordinate label=\"坐标点\" bind-x=\"{{bind:px}}\" bind-y=\"{{bind:py}}\" initial-x=\"1\" initial-y=\"2\" x-min=\"-5\" x-max=\"5\" y-min=\"-5\" y-max=\"5\">"
		},
		extended: true
	},
	quiz: {
		title: {
			en: "Practice question",
			zh: "练习题"
		},
		description: {
			en: "Check an answer and read a short explanation.",
			zh: "检查答案并阅读简短解析。"
		},
		category: "action",
		keywords: {
			en: [
				"quiz",
				"practice",
				"answer",
				"learn"
			],
			zh: [
				"练习",
				"题目",
				"答案"
			]
		},
		insertText: {
			en: "<quiz type=\"choice\" label=\"What is 2 + 3?\" answer=\"b\" explanation=\"The sum is 5.\">\n<option value=\"a\">4</option>\n<option value=\"b\">5</option>\n</quiz>",
			zh: "<quiz type=\"choice\" label=\"2 + 3 等于多少？\" answer=\"b\" explanation=\"相加得到 5。\">\n<option value=\"a\">4</option>\n<option value=\"b\">5</option>\n</quiz>"
		},
		extended: true
	},
	steps: {
		title: {
			en: "Guided steps",
			zh: "分步阅读"
		},
		description: {
			en: "Read instructions one step at a time.",
			zh: "按顺序阅读说明，内置上一步和下一步。"
		},
		category: "layout",
		keywords: {
			en: [
				"steps",
				"guide",
				"previous",
				"next"
			],
			zh: [
				"步骤",
				"引导",
				"下一步"
			]
		},
		insertText: {
			en: "<steps label=\"Learning path\" bind=\"{{bind:lesson}}\">\n<step label=\"Observe\">\nChange a parameter.\n</step>\n<step label=\"Practice\">\nCheck an answer.\n</step>\n</steps>",
			zh: "<steps label=\"学习路线\" bind=\"{{bind:lesson}}\">\n<step label=\"观察\">\n调整参数。\n</step>\n<step label=\"练习\">\n检查答案。\n</step>\n</steps>"
		},
		extended: true
	},
	slider: {
		title: {
			en: "Slider",
			zh: "滑块"
		},
		description: {
			en: "Drag the slider to choose a number within a range.",
			zh: "拖动滑块在指定范围内选择一个数值。"
		},
		category: "input",
		keywords: {
			en: [
				"slider",
				"range",
				"number",
				"drag",
				"value"
			],
			zh: [
				"滑块",
				"范围",
				"数值",
				"拖动",
				"滑动"
			]
		},
		insertText: {
			en: "<slider bind=\"{{bind:amount}}\" label=\"Amount\" initial=\"10\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<slider bind=\"{{bind:amount}}\" label=\"数量\" initial=\"10\" min=\"0\" max=\"100\" step=\"1\">"
		}
	},
	number: {
		title: {
			en: "Number input",
			zh: "数字输入"
		},
		description: {
			en: "Enter an exact number with an optional range and step.",
			zh: "输入精确数字，可限制范围和步长。"
		},
		category: "input",
		keywords: {
			en: [
				"number",
				"numeric",
				"input",
				"step",
				"quantity"
			],
			zh: [
				"数字",
				"数值",
				"输入",
				"步长",
				"数量"
			]
		},
		insertText: {
			en: "<number bind=\"{{bind:quantity}}\" label=\"Quantity\" initial=\"1\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<number bind=\"{{bind:quantity}}\" label=\"数量\" initial=\"1\" min=\"0\" max=\"100\" step=\"1\">"
		}
	},
	input: {
		title: {
			en: "Single-line text",
			zh: "单行文本"
		},
		description: {
			en: "Enter a name, title or other single-line text.",
			zh: "输入姓名、标题等单行文本。"
		},
		category: "input",
		keywords: {
			en: [
				"input",
				"text",
				"single-line",
				"field",
				"name"
			],
			zh: [
				"文本",
				"单行",
				"输入框",
				"名称",
				"输入"
			]
		},
		insertText: {
			en: "<input bind=\"{{bind:name}}\" label=\"Name\" placeholder=\"Enter a name\">",
			zh: "<input bind=\"{{bind:name}}\" label=\"名称\" placeholder=\"请输入名称\">"
		}
	},
	textarea: {
		title: {
			en: "Multi-line text",
			zh: "多行文本"
		},
		description: {
			en: "Enter notes, descriptions or other multi-line text.",
			zh: "输入说明、备注等多行文字。"
		},
		category: "input",
		keywords: {
			en: [
				"textarea",
				"text area",
				"multi-line",
				"notes",
				"description"
			],
			zh: [
				"文本域",
				"多行",
				"说明",
				"备注",
				"详细"
			]
		},
		insertText: {
			en: "<textarea bind=\"{{bind:message}}\" label=\"Details\" placeholder=\"Enter details\" rows=\"4\">",
			zh: "<textarea bind=\"{{bind:message}}\" label=\"详细说明\" placeholder=\"请输入详细说明\" rows=\"4\">"
		}
	},
	toggle: {
		title: {
			en: "Toggle",
			zh: "开关"
		},
		description: {
			en: "Switch a boolean option on or off.",
			zh: "在开启与关闭之间切换一个布尔选项。"
		},
		category: "input",
		keywords: {
			en: [
				"toggle",
				"switch",
				"boolean",
				"enable",
				"on"
			],
			zh: [
				"开关",
				"布尔",
				"启用",
				"切换",
				"选项"
			]
		},
		insertText: {
			en: "<toggle bind=\"{{bind:enabled}}\" label=\"Enable option\">",
			zh: "<toggle bind=\"{{bind:enabled}}\" label=\"启用选项\">"
		}
	},
	checkbox: {
		title: {
			en: "Checkbox",
			zh: "复选框"
		},
		description: {
			en: "Check or uncheck a boolean option.",
			zh: "勾选或取消一个布尔选项。"
		},
		category: "input",
		keywords: {
			en: [
				"checkbox",
				"check",
				"boolean",
				"confirm",
				"option"
			],
			zh: [
				"复选",
				"勾选",
				"布尔",
				"确认",
				"选项"
			]
		},
		insertText: {
			en: "<checkbox bind=\"{{bind:confirmed}}\" label=\"Confirm option\">",
			zh: "<checkbox bind=\"{{bind:confirmed}}\" label=\"确认选项\">"
		}
	},
	date: {
		title: {
			en: "Date picker",
			zh: "日期选择"
		},
		description: {
			en: "Pick a date; the value stays empty until one is chosen.",
			zh: "选择一个日期，未选择时为空字符串。"
		},
		category: "input",
		keywords: {
			en: [
				"date",
				"calendar",
				"picker",
				"day"
			],
			zh: [
				"日期",
				"日历",
				"时间",
				"选择"
			]
		},
		insertText: {
			en: "<date bind=\"{{bind:date}}\" label=\"Pick a date\">",
			zh: "<date bind=\"{{bind:date}}\" label=\"选择日期\">"
		}
	},
	choices: {
		title: {
			en: "Choice cards",
			zh: "选项卡片"
		},
		description: {
			en: "Pick one option from a set of cards.",
			zh: "从多个选项卡中选择一项。"
		},
		category: "input",
		keywords: {
			en: [
				"choices",
				"options",
				"cards",
				"select",
				"radio"
			],
			zh: [
				"选项",
				"选择",
				"卡片",
				"单选",
				"方案"
			]
		},
		insertText: {
			en: "<choices bind=\"{{bind:plan}}\" label=\"Choose a plan\">\n<option value=\"basic\">Basic</option>\n<option value=\"pro\">Pro</option>\n</choices>",
			zh: "<choices bind=\"{{bind:plan}}\" label=\"选择方案\">\n<option value=\"basic\">基础版</option>\n<option value=\"pro\">专业版</option>\n</choices>"
		}
	},
	counter: {
		title: {
			en: "Counter",
			zh: "计数器"
		},
		description: {
			en: "Adjust an integer with plus and minus buttons, then reset it in one click.",
			zh: "通过加减按钮调整整数，并可一键重置。"
		},
		category: "action",
		keywords: {
			en: [
				"counter",
				"count",
				"plus",
				"minus",
				"integer"
			],
			zh: [
				"计数",
				"加减",
				"整数",
				"调整",
				"重置"
			]
		},
		insertText: {
			en: "<counter bind=\"{{bind:count}}\" label=\"Count\" initial=\"0\" min=\"0\" max=\"99\">",
			zh: "<counter bind=\"{{bind:count}}\" label=\"计数\" initial=\"0\" min=\"0\" max=\"99\">"
		}
	},
	timer: {
		title: {
			en: "Countdown timer",
			zh: "倒计时"
		},
		description: {
			en: "Start, pause and reset a focus timer.",
			zh: "启动、暂停和重置一段专注计时。"
		},
		category: "action",
		keywords: {
			en: [
				"timer",
				"countdown",
				"focus",
				"seconds",
				"pause"
			],
			zh: [
				"计时",
				"倒计时",
				"专注",
				"秒",
				"暂停"
			]
		},
		insertText: {
			en: "<timer bind=\"{{bind:remaining}}\" label=\"Focus timer\" duration=\"60\">",
			zh: "<timer bind=\"{{bind:remaining}}\" label=\"专注计时\" duration=\"60\">"
		}
	},
	checklist: {
		title: {
			en: "Checklist",
			zh: "任务清单"
		},
		description: {
			en: "Track completion with a checkable task list.",
			zh: "用可勾选的任务列表记录完成情况。"
		},
		category: "action",
		keywords: {
			en: [
				"checklist",
				"tasks",
				"todo",
				"check",
				"done"
			],
			zh: [
				"清单",
				"任务",
				"勾选",
				"待办",
				"完成"
			]
		},
		insertText: {
			en: "<checklist bind=\"{{bind:done}}\" label=\"Task checklist\">\n- [ ] First task\n- [ ] Second task\n- [ ] Third task\n</checklist>",
			zh: "<checklist bind=\"{{bind:done}}\" label=\"完成清单\">\n- [ ] 第一项任务\n- [ ] 第二项任务\n- [ ] 第三项任务\n</checklist>"
		}
	},
	progress: {
		title: {
			en: "Progress bar",
			zh: "进度条"
		},
		description: {
			en: "Show completion from 0 to 100.",
			zh: "展示 0 到 100 之间的完成进度。"
		},
		category: "action",
		keywords: {
			en: [
				"progress",
				"completion",
				"bar",
				"percent"
			],
			zh: [
				"进度",
				"完成度",
				"进度条",
				"百分比"
			]
		},
		insertText: {
			en: "<progress label=\"Progress\" value=\"{{ 40 }}\">",
			zh: "<progress label=\"完成进度\" value=\"{{ 40 }}\">"
		}
	},
	panel: {
		title: {
			en: "Parameter panel",
			zh: "参数面板"
		},
		description: {
			en: "Group controls in a panel with a restore-defaults button.",
			zh: "把一组控件包进面板，并附带恢复默认按钮。"
		},
		category: "layout",
		keywords: {
			en: [
				"panel",
				"parameters",
				"reset",
				"form",
				"group"
			],
			zh: [
				"面板",
				"参数",
				"重置",
				"表单",
				"控件"
			]
		},
		insertText: {
			en: "<panel title=\"Parameters\">\n{{selection:Sample content}}\n</panel>",
			zh: "<panel title=\"参数面板\">\n{{selection:示例内容}}\n</panel>"
		}
	},
	card: {
		title: {
			en: "Content card",
			zh: "内容卡片"
		},
		description: {
			en: "Organize a self-contained piece of content in a card.",
			zh: "用卡片组织一段独立内容。"
		},
		category: "layout",
		keywords: {
			en: [
				"card",
				"container",
				"content",
				"section"
			],
			zh: [
				"卡片",
				"容器",
				"内容",
				"区块"
			]
		},
		insertText: {
			en: "<card title=\"Content card\">\n{{selection:Sample content}}\n</card>",
			zh: "<card title=\"内容卡片\">\n{{selection:示例内容}}\n</card>"
		}
	},
	if: {
		title: {
			en: "Conditional section",
			zh: "条件区域"
		},
		description: {
			en: "Show the contents only when a condition is true.",
			zh: "只有条件为真时才显示其中内容。"
		},
		category: "layout",
		keywords: {
			en: [
				"if",
				"condition",
				"when",
				"show",
				"visible"
			],
			zh: [
				"条件",
				"判断",
				"显示",
				"当"
			]
		},
		insertText: {
			en: "<if when=\"{{ {{select:true}} }}\">\n{{selection:Sample content}}\n</if>",
			zh: "<if when=\"{{ {{select:true}} }}\">\n{{selection:示例内容}}\n</if>"
		}
	},
	gallery: {
		title: {
			en: "Gallery",
			zh: "横向画廊"
		},
		description: {
			en: "Browse images, cards and Markdown in a horizontal strip.",
			zh: "横向浏览图片、卡片与 Markdown 内容。"
		},
		category: "layout",
		keywords: {
			en: [
				"gallery",
				"images",
				"cards",
				"scroll"
			],
			zh: [
				"画廊",
				"图片",
				"卡片",
				"横向滚动"
			]
		},
		insertText: {
			en: "<gallery label=\"Gallery\" item-width=\"280\">\n<gallery-item label=\"First item\">\n{{selection:Sample content}}\n</gallery-item>\n<gallery-item label=\"Second item\">\nMore content.\n</gallery-item>\n</gallery>",
			zh: "<gallery label=\"横向画廊\" item-width=\"280\">\n<gallery-item label=\"项目一\">\n{{selection:示例内容}}\n</gallery-item>\n<gallery-item label=\"项目二\">\n更多内容。\n</gallery-item>\n</gallery>"
		}
	},
	"gallery-item": {
		title: {
			en: "Gallery item",
			zh: "画廊项目"
		},
		description: {
			en: "One gallery item with Markdown or nested components.",
			zh: "一项画廊内容，可包含 Markdown 和子组件。"
		},
		category: "layout",
		keywords: {
			en: [
				"gallery",
				"item",
				"slide"
			],
			zh: [
				"画廊",
				"项目",
				"切片"
			]
		},
		insertText: {
			en: "<gallery-item label=\"Item\">\n{{selection:Sample content}}\n</gallery-item>",
			zh: "<gallery-item label=\"项目\">\n{{selection:示例内容}}\n</gallery-item>"
		}
	},
	tabs: {
		title: {
			en: "Tabs",
			zh: "标签页"
		},
		description: {
			en: "Split content across switchable tabs.",
			zh: "把内容分到多个可切换的标签页中。"
		},
		category: "layout",
		keywords: {
			en: [
				"tabs",
				"switch",
				"sections",
				"groups"
			],
			zh: [
				"标签页",
				"切换",
				"分组",
				"选项卡"
			]
		},
		insertText: {
			en: "<tabs label=\"Content tabs\">\n<tab label=\"Tab one\">\n{{selection:Sample content}}\n</tab>\n\n<tab label=\"Tab two\">\nContent for the second tab.\n</tab>\n</tabs>",
			zh: "<tabs label=\"内容标签页\">\n<tab label=\"标签一\">\n{{selection:示例内容}}\n</tab>\n\n<tab label=\"标签二\">\n第二个标签页的内容。\n</tab>\n</tabs>"
		}
	},
	accordion: {
		title: {
			en: "Accordion",
			zh: "折叠面板"
		},
		description: {
			en: "Put notes into items that expand and collapse.",
			zh: "把说明放进可展开和收起的条目。"
		},
		category: "layout",
		keywords: {
			en: [
				"accordion",
				"collapse",
				"expand",
				"faq",
				"disclosure"
			],
			zh: [
				"折叠",
				"展开",
				"问答",
				"手风琴",
				"条目"
			]
		},
		insertText: {
			en: "<accordion label=\"FAQ\">\n<disclosure label=\"Question one\">\n{{selection:Sample content}}\n</disclosure>\n\n<disclosure label=\"Question two\">\nDetails for the second item.\n</disclosure>\n</accordion>",
			zh: "<accordion label=\"常见问题\">\n<disclosure label=\"问题一\">\n{{selection:示例内容}}\n</disclosure>\n\n<disclosure label=\"问题二\">\n第二个条目的说明。\n</disclosure>\n</accordion>"
		}
	},
	chart: {
		title: {
			en: "Bar chart",
			zh: "柱状图"
		},
		description: {
			en: "Turn a Markdown table into a bar chart.",
			zh: "把 Markdown 表格转换成柱状图。"
		},
		category: "data",
		keywords: {
			en: [
				"chart",
				"bar",
				"graph",
				"table",
				"data"
			],
			zh: [
				"图表",
				"柱状图",
				"表格",
				"数据",
				"对比"
			]
		},
		insertText: {
			en: "<chart kind=\"bar\" title=\"Category comparison\" y-label=\"Value\">\n| Item | Value |\n| --- | ---: |\n| Item A | 20 |\n| Item B | 35 |\n</chart>",
			zh: "<chart kind=\"bar\" title=\"分类对比\" y-label=\"数值\">\n| 项目 | 数值 |\n| --- | ---: |\n| 项目甲 | 20 |\n| 项目乙 | 35 |\n</chart>"
		}
	},
	table: {
		title: {
			en: "Enhanced table",
			zh: "增强表格"
		},
		description: {
			en: "A Markdown table with search, sorting and paging.",
			zh: "带搜索、排序和分页的 Markdown 表格。"
		},
		category: "data",
		keywords: {
			en: [
				"table",
				"search",
				"sort",
				"paging",
				"data"
			],
			zh: [
				"表格",
				"搜索",
				"排序",
				"分页",
				"数据"
			]
		},
		insertText: {
			en: "<table label=\"Data table\" page-size=\"5\">\n| Name | Category | Value |\n| --- | --- | ---: |\n| Item A | Category one | 20 |\n| Item B | Category two | 35 |\n</table>",
			zh: "<table label=\"数据表格\" page-size=\"5\">\n| 名称 | 分类 | 数值 |\n| --- | --- | ---: |\n| 项目甲 | 分类一 | 20 |\n| 项目乙 | 分类二 | 35 |\n</table>"
		}
	},
	timeline: {
		title: {
			en: "Timeline",
			zh: "时间轴"
		},
		description: {
			en: "Show task start times and durations in a table.",
			zh: "用表格展示任务的开始时间与时长。"
		},
		category: "data",
		keywords: {
			en: [
				"timeline",
				"schedule",
				"plan",
				"duration",
				"gantt"
			],
			zh: [
				"时间轴",
				"计划",
				"时长",
				"日程",
				"任务"
			]
		},
		insertText: {
			en: "<timeline title=\"Task timeline\">\n| Task | Start | Duration | Notes |\n| --- | ---: | ---: | --- |\n| Prepare | 0 | 10 | List the materials |\n| Execute | 10 | 20 | Complete the main work |\n| Review | 30 | 5 | Check the results |\n</timeline>",
			zh: "<timeline title=\"任务时间轴\">\n| 事项 | 开始 | 时长 | 说明 |\n| --- | ---: | ---: | --- |\n| 准备 | 0 | 10 | 列出所需材料 |\n| 执行 | 10 | 20 | 完成主要内容 |\n| 检查 | 30 | 5 | 复核结果 |\n</timeline>"
		}
	},
	diagram: {
		title: {
			en: "Interactive diagram",
			zh: "交互图解"
		},
		description: {
			en: "Show a flow with nodes and edges; hover or focus a node to read its notes.",
			zh: "用节点和连线展示流程，悬浮或聚焦节点查看说明。"
		},
		category: "data",
		keywords: {
			en: [
				"diagram",
				"flow",
				"node",
				"edge",
				"graph"
			],
			zh: [
				"图解",
				"流程",
				"节点",
				"连线",
				"关系图"
			]
		},
		insertText: {
			en: "<diagram label=\"Flow overview\">\n<node id=\"start\" label=\"Start\">\nWhere the flow begins.\n</node>\n\n<node id=\"process\" label=\"Process\">\nPerform the main step.\n</node>\n\n<node id=\"end\" label=\"End\">\nReview the result.\n</node>\n\n<edge from=\"start\" to=\"process\" label=\"Proceed\">\n<edge from=\"process\" to=\"end\" label=\"Complete\">\n</diagram>",
			zh: "<diagram label=\"流程示意\">\n<node id=\"start\" label=\"开始\">\n流程起点。\n</node>\n\n<node id=\"process\" label=\"处理\">\n执行主要步骤。\n</node>\n\n<node id=\"end\" label=\"结束\">\n查看结果。\n</node>\n\n<edge from=\"start\" to=\"process\" label=\"进入\">\n<edge from=\"process\" to=\"end\" label=\"完成\">\n</diagram>"
		}
	},
	plot: {
		title: {
			en: "Function plot",
			zh: "函数曲线"
		},
		description: {
			en: "Plot explicit, parametric or implicit curves from LaTeX formulas.",
			zh: "用 LaTeX 公式绘制显式、参数方程或隐函数曲线。"
		},
		category: "data",
		keywords: {
			en: [
				"plot",
				"curve",
				"function",
				"parametric",
				"implicit",
				"formula",
				"latex",
				"math"
			],
			zh: [
				"曲线",
				"函数",
				"参数方程",
				"隐函数",
				"公式",
				"数学",
				"绘图"
			]
		},
		insertText: {
			en: "<plot min=\"-5\" max=\"5\" label=\"Function plot\">\n$$ y = x^2 $$\n</plot>",
			zh: "<plot min=\"-5\" max=\"5\" label=\"函数曲线\">\n$$ y = x^2 $$\n</plot>"
		}
	},
	alert: {
		title: {
			en: "Alert",
			zh: "提示框"
		},
		description: {
			en: "Highlight info, success or warning messages with different tones.",
			zh: "用不同语气突出普通、成功或警告信息。"
		},
		category: "hint",
		keywords: {
			en: [
				"alert",
				"notice",
				"warning",
				"info",
				"message"
			],
			zh: [
				"提示",
				"警告",
				"通知",
				"信息",
				"消息"
			]
		},
		insertText: {
			en: "<alert tone=\"info\" title=\"Notice\">\n{{selection:Sample content}}\n</alert>",
			zh: "<alert tone=\"info\" title=\"提示\">\n{{selection:示例内容}}\n</alert>"
		}
	},
	badge: {
		title: {
			en: "Badge",
			zh: "徽标"
		},
		description: {
			en: "Show a short status marker inside a sentence.",
			zh: "在句子里显示一个简短状态标记。"
		},
		category: "hint",
		keywords: {
			en: [
				"badge",
				"label",
				"status",
				"inline",
				"tag"
			],
			zh: [
				"徽标",
				"标签",
				"状态",
				"行内",
				"标记"
			]
		},
		inline: true,
		insertText: {
			en: "<badge tone=\"success\">Badge</badge>",
			zh: "<badge tone=\"success\">标签</badge>"
		}
	},
	tooltip: {
		title: {
			en: "Tooltip",
			zh: "行内提示"
		},
		description: {
			en: "Attach a hover or focus note to a word in a sentence.",
			zh: "为句中的词语附加悬停或聚焦说明。"
		},
		category: "hint",
		keywords: {
			en: [
				"tooltip",
				"hint",
				"hover",
				"focus",
				"inline"
			],
			zh: [
				"提示",
				"悬停",
				"说明",
				"行内",
				"气泡"
			]
		},
		inline: true,
		insertText: {
			en: "<tooltip text=\"Extra details appear here.\">Hover to view</tooltip>",
			zh: "<tooltip text=\"这里显示补充说明。\">悬停查看</tooltip>"
		}
	}
});
Object.freeze(Object.keys(DEFAULT_COMPONENT_AUTHORING));
function defaultComponentAuthoring(name) {
	return Object.hasOwn(DEFAULT_COMPONENT_AUTHORING, name) ? DEFAULT_COMPONENT_AUTHORING[name] : void 0;
}
/**
* Canonical manifest authoring metadata: English titles and templates are the
* portable form carried by `defaultPreset.components`. Localized templates stay
* in this module and are consumed by the editor catalog directly.
*/
function defaultManifestAuthoring(name) {
	const data = defaultComponentAuthoring(name);
	if (!data) return void 0;
	const insertText = data.insertText.en;
	if (typeof insertText !== "string" || insertText.trim() === "") return void 0;
	return {
		title: data.title,
		description: data.description,
		category: GROUP_IDS.has(data.category) ? data.category : void 0,
		insertText
	};
}
// src/presets/default-semantics.ts
var VERSION = LOCAL_SDK_VERSION;
var props = {
	text: (extra = {}) => ({
		kind: "string",
		coerce: "text",
		...extra
	}),
	/** Strict string with no text coercion; used for expression-bearing props. */
	expressionText: (extra = {}) => ({
		kind: "string",
		...extra
	}),
	dynamicText: (extra = {}) => ({
		kind: "string",
		dynamic: true,
		...extra
	}),
	staticText: (extra = {}) => ({
		kind: "string",
		static: true,
		...extra
	}),
	number: (extra = {}) => ({
		kind: "number",
		...extra
	}),
	boolean: (extra = {}) => ({
		kind: "boolean",
		...extra
	}),
	choice: (values, extra = {}) => ({
		kind: "enum",
		enum: values,
		...extra
	})
};
var label = (extra = {}) => props.text(extra);
var optionalLabel = () => props.text();
var optionalTitle = () => props.text();
var disabled = () => props.boolean({
	dynamic: true,
	default: false
});
var color = () => props.staticText({ color: true });
function caps() {
	return Object.freeze({
		interactive: true,
		static: true,
		ssr: true,
		offline: true
	});
}
function binding(kind, family, initialRule, extra = {}) {
	return Object.freeze({
		kind,
		family,
		bind: "bind",
		initial: "initial",
		initialRule,
		...extra
	});
}
function slot(name, initialRule, extra = {}) {
	return Object.freeze({
		kind: "number",
		family: "number",
		bind: `bind-${name}`,
		initial: `initial-${name}`,
		initialRule,
		exclusive: true,
		...extra
	});
}
var numericConstraints = (min, max, step = "step") => ({
	min: { prop: min },
	max: { prop: max },
	step: { prop: step }
});
function structure(value) {
	return Object.freeze(value);
}
function rules(...list) {
	return Object.freeze(list.map((rule) => Object.freeze(rule)));
}
function definition(name, form, value) {
	return defineLocalComponent({
		id: `reactive-md/${name}`,
		name,
		version: VERSION,
		protocol: LOCAL_COMPONENT_PROTOCOL,
		form,
		capabilities: caps(),
		...value
	});
}
var inputDef = definition("input", "leaf", {
	props: {
		label: label(),
		type: props.choice(["text", "email"], {
			static: true,
			default: "text"
		}),
		placeholder: props.text(),
		required: props.boolean({
			dynamic: true,
			default: false
		}),
		"min-length": props.number({
			integer: true,
			min: 0,
			default: 0
		}),
		"max-length": props.number({
			integer: true,
			min: 0
		}),
		disabled: disabled()
	},
	bindings: { value: binding("string", "text", "empty") },
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "text-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "dynamic-constraints",
		attributes: ["required"]
	}, {
		kind: "value-length",
		min: "min-length",
		max: "max-length",
		email: "type",
		emailType: "email"
	}, {
		kind: "value-required",
		required: "required"
	})
});
var textareaDef = definition("textarea", "leaf", {
	props: {
		label: label(),
		placeholder: props.text(),
		rows: props.number({
			integer: true,
			positive: true,
			default: 4
		}),
		required: props.boolean({
			dynamic: true,
			default: false
		}),
		"min-length": props.number({
			integer: true,
			min: 0,
			default: 0
		}),
		"max-length": props.number({
			integer: true,
			min: 0
		}),
		disabled: disabled()
	},
	bindings: { value: binding("string", "text", "empty") },
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "text-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "dynamic-constraints",
		attributes: ["required"]
	}, {
		kind: "value-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "value-required",
		required: "required"
	})
});
var numberDef = definition("number", "leaf", {
	props: {
		label: label(),
		min: props.number({ dynamic: true }),
		max: props.number({ dynamic: true }),
		step: props.number({
			positive: true,
			default: 1
		}),
		disabled: disabled()
	},
	bindings: { value: binding("number", "number", "nearest-zero", { constraints: numericConstraints("min", "max") }) },
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	}, {
		kind: "dynamic-constraints",
		attributes: ["min", "max"]
	})
});
var sliderDef = definition("slider", "leaf", {
	props: {
		label: label(),
		min: props.number({
			dynamic: true,
			default: 0
		}),
		max: props.number({
			dynamic: true,
			default: 100
		}),
		step: props.number({
			positive: true,
			default: 1
		}),
		disabled: disabled(),
		color: color()
	},
	bindings: { value: binding("number", "number", "min", { constraints: numericConstraints("min", "max") }) },
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	}, {
		kind: "dynamic-constraints",
		attributes: ["min", "max"]
	})
});
var rangeSliderDef = definition("range-slider", "leaf", {
	props: {
		label: label(),
		min: props.number({ default: 0 }),
		max: props.number({ default: 100 }),
		step: props.number({
			positive: true,
			default: 1
		}),
		disabled: disabled(),
		color: color()
	},
	bindings: {
		start: slot("start", "min", { constraints: numericConstraints("min", "max") }),
		end: slot("end", "max-step", { constraints: numericConstraints("min", "max") })
	},
	slotRelations: [{
		lower: "start",
		upper: "end"
	}],
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	})
});
var coordinateDef = definition("coordinate", "leaf", {
	props: {
		label: label(),
		"x-min": props.number({ default: -5 }),
		"x-max": props.number({ default: 5 }),
		"y-min": props.number({ default: -5 }),
		"y-max": props.number({ default: 5 }),
		step: props.number({
			positive: true,
			default: 1
		}),
		disabled: disabled(),
		color: color()
	},
	bindings: {
		x: slot("x", "nearest-zero", { constraints: {
			min: { prop: "x-min" },
			max: { prop: "x-max" },
			step: { prop: "step" }
		} }),
		y: slot("y", "nearest-zero", { constraints: {
			min: { prop: "y-min" },
			max: { prop: "y-max" },
			step: { prop: "step" }
		} })
	},
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "numeric-range",
		min: "x-min",
		max: "x-max",
		step: "step"
	}, {
		kind: "numeric-range",
		min: "y-min",
		max: "y-max"
	})
});
var toggleDef = definition("toggle", "leaf", {
	props: {
		label: label(),
		disabled: disabled(),
		color: color()
	},
	bindings: { value: binding("boolean", "boolean", "false") },
	structure: structure({
		rule: "none",
		label: "required"
	})
});
var checkboxDef = definition("checkbox", "leaf", {
	props: {
		label: label(),
		disabled: disabled(),
		color: color()
	},
	bindings: { value: binding("boolean", "boolean", "false") },
	structure: structure({
		rule: "none",
		label: "required"
	})
});
var dateDef = definition("date", "leaf", {
	props: {
		label: label(),
		min: props.dynamicText(),
		max: props.dynamicText(),
		required: props.boolean({
			dynamic: true,
			default: false
		}),
		disabled: disabled()
	},
	bindings: { value: binding("string", "date", "empty") },
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "date-bounds",
		min: "min",
		max: "max"
	}, {
		kind: "dynamic-constraints",
		attributes: [
			"min",
			"max",
			"required"
		]
	}, {
		kind: "value-date",
		min: "min",
		max: "max",
		required: "required"
	})
});
function optionsComponent(name, def = "container") {
	return definition(name, def, {
		props: {
			label: label(),
			disabled: disabled(),
			color: color()
		},
		bindings: { value: binding("string", "choice", "first-option") },
		structure: structure({
			rule: "options",
			label: "required",
			child: "option",
			children: ["option"],
			min: 1,
			max: MAX_LOCAL_ARRAY_LENGTH,
			valueAttribute: "value"
		}),
		rules: rules({
			kind: "options-body",
			child: "option",
			valueAttribute: "value",
			unique: true,
			max: MAX_LOCAL_ARRAY_LENGTH
		})
	});
}
var selectDef = optionsComponent("select");
var choicesDef = optionsComponent("choices");
var radioGroupDef = optionsComponent("radio-group");
var multiSelectDef = definition("multi-select", "container", {
	props: {
		label: label(),
		"max-selected": props.number({
			integer: true,
			min: 0
		}),
		disabled: disabled(),
		color: color()
	},
	bindings: { value: binding("array", "multi-select", "empty-array", {
		exclusive: true,
		maxItems: { prop: "max-selected" }
	}) },
	structure: structure({
		rule: "options",
		label: "required",
		child: "option",
		children: ["option"],
		min: 1,
		max: MAX_LOCAL_ARRAY_LENGTH,
		valueAttribute: "value",
		forbidSeparator: ","
	}),
	rules: rules({
		kind: "options-body",
		child: "option",
		valueAttribute: "value",
		unique: true,
		max: MAX_LOCAL_ARRAY_LENGTH,
		forbidSeparator: ","
	}, {
		kind: "option-count",
		max: "max-selected"
	})
});
var optionDef = definition("option", "container", {
	props: { value: props.staticText({ required: true }) },
	structure: structure({
		rule: "inline",
		label: "none",
		inlineOnly: true,
		noComponents: true
	}),
	rules: rules({
		kind: "inline-body",
		strict: true
	}, { kind: "no-components" })
});
var counterDef = definition("counter", "leaf", {
	props: {
		label: label(),
		min: props.number({ default: 0 }),
		max: props.number(),
		step: props.number({
			positive: true,
			default: 1
		}),
		disabled: disabled()
	},
	bindings: { value: binding("number", "number", "nearest-zero", { constraints: numericConstraints("min", "max") }) },
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	})
});
var timerDef = definition("timer", "leaf", {
	props: {
		label: label(),
		duration: props.number({
			integer: true,
			positive: true,
			default: 60
		})
	},
	bindings: { value: binding("number", "timer", "duration", {
		exclusive: true,
		constraints: {
			min: { literal: 0 },
			max: { prop: "duration" },
			step: { literal: 1 }
		},
		retain: false
	}) },
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "timer-duration",
		attribute: "duration",
		default: 60
	}, {
		kind: "retain",
		value: false
	})
});
var checklistDef = definition("checklist", "container", {
	props: {
		label: label(),
		disabled: disabled(),
		color: color()
	},
	bindings: { value: binding("array", "checklist", "checked", {
		exclusive: true,
		retain: false
	}) },
	structure: structure({
		rule: "content",
		label: "required",
		noComponents: true
	}),
	rules: rules({
		kind: "checklist-body",
		itemLimit: MAX_LOCAL_ARRAY_LENGTH
	}, {
		kind: "retain",
		value: false
	})
});
var progressDef = definition("progress", "leaf", {
	props: {
		label: label(),
		value: props.number({
			dynamic: true,
			required: true
		}),
		max: props.number({
			positive: true,
			default: 100
		}),
		color: color()
	},
	structure: structure({
		rule: "none",
		label: "required"
	}),
	rules: rules({
		kind: "progress-bounds",
		value: "value",
		max: "max",
		defaultMax: 100
	})
});
var jumpDef = definition("jump", "inline", {
	props: {
		to: props.staticText({ required: true }),
		appearance: props.choice(["link", "button"], {
			static: true,
			default: "link"
		}),
		color: color()
	},
	structure: structure({
		rule: "inline",
		label: "none",
		inlineOnly: true,
		noComponents: true
	}),
	rules: rules({
		kind: "inline-body",
		strict: true
	}, { kind: "no-components" }, {
		kind: "navigation",
		target: "to"
	})
});
var anchorDef = definition("anchor", "leaf", {
	props: { id: props.staticText({ required: true }) },
	structure: structure({
		rule: "none",
		label: "none"
	}),
	rules: rules({
		kind: "anchor",
		id: "id"
	})
});
var textDef = definition("text", "inline", {
	props: { color: props.staticText({
		required: true,
		color: true
	}) },
	structure: structure({
		rule: "inline",
		label: "none",
		inlineOnly: true,
		noComponents: true
	}),
	rules: rules({
		kind: "inline-body",
		strict: true
	}, { kind: "no-components" })
});
var sectionDef = definition("section", "container", {
	props: { color: props.staticText({
		required: true,
		color: true
	}) },
	structure: structure({
		rule: "any",
		label: "none"
	})
});
var quizDef = definition("quiz", "container", {
	props: {
		type: props.choice(["choice", "number"], {
			static: true,
			default: "choice"
		}),
		label: label(),
		answer: props.staticText({ required: true }),
		explanation: props.text(),
		tolerance: props.number({
			min: 0,
			default: 0
		}),
		disabled: disabled()
	},
	structure: structure({
		rule: "quiz",
		label: "required",
		child: "option",
		children: ["option"],
		max: MAX_LOCAL_ARRAY_LENGTH,
		valueAttribute: "value"
	}),
	rules: rules({
		kind: "quiz-body",
		type: "type",
		answer: "answer",
		tolerance: "tolerance",
		child: "option",
		valueAttribute: "value",
		max: MAX_LOCAL_ARRAY_LENGTH
	}, {
		kind: "nonempty",
		attribute: "answer"
	})
});
var panelDef = definition("panel", "container", {
	props: {
		title: optionalTitle(),
		reset: props.boolean({ default: true })
	},
	structure: structure({
		rule: "any",
		label: "none"
	}),
	rules: rules({
		kind: "self-binding-read",
		mode: "always"
	})
});
var cardDef = definition("card", "container", {
	props: { title: optionalTitle() },
	structure: structure({
		rule: "any",
		label: "none"
	})
});
var gridDef = definition("grid", "container", {
	props: { columns: props.number({
		integer: true,
		min: 1,
		max: 4,
		default: 2
	}) },
	structure: structure({
		rule: "components",
		label: "none",
		child: "card",
		children: ["card"],
		min: 1
	}),
	rules: rules({
		kind: "only-children",
		children: ["card"],
		min: 1
	})
});
var galleryDef = definition("gallery", "container", {
	props: {
		label: label({ required: true }),
		"item-width": props.number({
			dynamic: true,
			integer: true,
			default: 280,
			min: 180,
			max: 480
		})
	},
	structure: structure({
		rule: "components",
		label: "required",
		child: "gallery-item",
		children: ["gallery-item"],
		min: 1
	}),
	rules: rules({
		kind: "only-children",
		children: ["gallery-item"],
		min: 1
	})
});
var galleryItemDef = definition("gallery-item", "container", {
	props: { label: optionalLabel() },
	structure: structure({
		rule: "any",
		label: "none"
	})
});
var tabsDef = definition("tabs", "container", {
	props: { label: optionalLabel() },
	bindings: { value: binding("string", "tabs", "first-tab", { exclusive: true }) },
	structure: structure({
		rule: "tabs",
		label: "optional",
		child: "tab",
		children: ["tab"],
		min: 1,
		valueAttribute: "value",
		generatedPrefix: "tab-"
	}),
	rules: rules({
		kind: "value-sequence",
		child: "tab",
		valueAttribute: "value",
		min: 1,
		generatedPrefix: "tab-",
		unique: true
	})
});
var tabDef = definition("tab", "container", {
	props: {
		label: label(),
		value: props.staticText()
	},
	structure: structure({
		rule: "any",
		label: "required",
		parents: ["tabs"]
	})
});
var stepsDef = definition("steps", "container", {
	props: { label: optionalLabel() },
	bindings: { value: binding("string", "steps", "first-step", { exclusive: true }) },
	structure: structure({
		rule: "steps",
		label: "optional",
		child: "step",
		children: ["step"],
		min: 1,
		valueAttribute: "value",
		generatedPrefix: "step-"
	}),
	rules: rules({
		kind: "value-sequence",
		child: "step",
		valueAttribute: "value",
		min: 1,
		generatedPrefix: "step-",
		unique: true
	})
});
var stepDef = definition("step", "container", {
	props: {
		label: label(),
		value: props.staticText()
	},
	structure: structure({
		rule: "any",
		label: "required",
		parents: ["steps"]
	})
});
var accordionDef = definition("accordion", "container", {
	props: { label: optionalLabel() },
	structure: structure({
		rule: "components",
		label: "optional",
		child: "disclosure",
		children: ["disclosure"],
		min: 1
	}),
	rules: rules({
		kind: "only-children",
		children: ["disclosure"],
		min: 1
	})
});
var disclosureDef = definition("disclosure", "container", {
	props: {
		label: label(),
		open: props.boolean({ default: false })
	},
	structure: structure({
		rule: "any",
		label: "required",
		parents: ["accordion"]
	})
});
var ifDef = definition("if", "container", {
	props: { when: props.boolean({
		dynamic: true,
		required: true
	}) },
	structure: structure({
		rule: "any",
		label: "none"
	}),
	rules: rules({
		kind: "require-full-interpolation",
		attributes: ["when"]
	})
});
var alertDef = definition("alert", "container", {
	props: {
		title: optionalTitle(),
		tone: props.choice([
			"info",
			"success",
			"warning"
		], {
			dynamic: true,
			default: "info"
		})
	},
	structure: structure({
		rule: "any",
		label: "none"
	})
});
var badgeDef = definition("badge", "inline", {
	props: {
		tone: props.choice([
			"neutral",
			"success",
			"warning"
		], {
			dynamic: true,
			default: "neutral"
		}),
		color: color()
	},
	structure: structure({
		rule: "inline",
		label: "none",
		inlineOnly: true,
		noComponents: true
	}),
	rules: rules({
		kind: "inline-body",
		strict: true
	}, { kind: "no-components" })
});
var tooltipDef = definition("tooltip", "inline", {
	props: { text: props.text({ required: true }) },
	structure: structure({
		rule: "inline",
		label: "none",
		inlineOnly: true,
		noComponents: true
	}),
	rules: rules({
		kind: "inline-body",
		strict: true
	}, { kind: "no-components" })
});
var validationDef = definition("validation", "leaf", {
	props: {
		when: props.boolean({
			dynamic: true,
			required: true
		}),
		message: props.text({ required: true }),
		fields: props.staticText({ required: true })
	},
	structure: structure({
		rule: "none",
		label: "none"
	}),
	rules: rules({
		kind: "validation-rule",
		when: "when",
		fields: "fields",
		message: "message",
		placement: "prose",
		max: 100
	}, {
		kind: "scoped-expressions",
		attributes: ["fields"],
		scope: "validation"
	})
});
var dataTableDef = definition("data-table", "container", {
	props: {
		label: props.staticText(),
		rows: props.expressionText({ required: true }),
		key: props.expressionText({ required: true }),
		"max-rows": props.number({
			integer: true,
			positive: true,
			max: MAX_LOCAL_DATA_TABLE_ROWS,
			default: 100
		})
	},
	structure: structure({
		rule: "components",
		label: "required",
		child: "column",
		children: ["column"],
		min: 1,
		max: 20
	}),
	rules: rules({
		kind: "data-table",
		rows: "rows",
		key: "key",
		child: "column",
		childValue: "value",
		label: "label",
		maxRows: "max-rows",
		defaultMaxRows: 100,
		documentRows: MAX_LOCAL_DATA_DOCUMENT_ROWS,
		documentCells: MAX_LOCAL_DATA_DOCUMENT_CELLS,
		maxColumns: 20
	}, {
		kind: "require-full-interpolation",
		attributes: ["rows", "key"]
	}, {
		kind: "scoped-expressions",
		attributes: ["key"],
		scope: "row"
	}, {
		kind: "row-values",
		rows: "rows",
		key: "key",
		child: "column",
		childValue: "value"
	})
});
var columnDef = definition("column", "leaf", {
	props: {
		label: props.staticText({ required: true }),
		value: props.expressionText({ required: true })
	},
	structure: structure({
		rule: "none",
		label: "none",
		parents: ["data-table"]
	}),
	rules: rules({
		kind: "require-full-interpolation",
		attributes: ["value"]
	}, {
		kind: "scoped-expressions",
		attributes: ["value"],
		scope: "row"
	})
});
var tableDef = definition("table", "container", {
	props: {
		label: optionalLabel(),
		searchable: props.boolean({ default: true }),
		sortable: props.boolean({ default: true }),
		"page-size": props.number({
			integer: true,
			positive: true,
			default: 10
		}),
		key: props.staticText()
	},
	bindings: { value: binding("string", "selection", "none", { requiresAttributes: ["key"] }) },
	structure: structure({
		rule: "table",
		label: "optional"
	}),
	rules: rules({ kind: "single-table" }, {
		kind: "selection-requires",
		key: "key",
		attributes: ["bind", "initial"]
	}, {
		kind: "table-selection",
		key: "key",
		bindings: ["bind"]
	}, {
		kind: "self-binding-read",
		mode: "attribute",
		attribute: "key"
	})
});
var chartDef = definition("chart", "container", {
	props: {
		kind: props.choice([
			"bar",
			"line",
			"area",
			"scatter",
			"donut",
			"pie"
		], {
			static: true,
			default: "bar"
		}),
		title: optionalTitle(),
		x: props.staticText(),
		y: props.staticText(),
		"x-label": props.text(),
		"y-label": props.text(),
		key: props.staticText()
	},
	bindings: { value: binding("string", "selection", "none", { requiresAttributes: ["key"] }) },
	structure: structure({
		rule: "table",
		label: "none"
	}),
	rules: rules({ kind: "single-table" }, {
		kind: "chart-table",
		chartKind: "kind",
		x: "x",
		y: "y"
	}, {
		kind: "table-selection",
		key: "key",
		bindings: ["bind"]
	}, {
		kind: "selection-requires",
		key: "key",
		attributes: ["bind", "initial"]
	}, {
		kind: "self-binding-read",
		mode: "attribute",
		attribute: "key"
	})
});
var plotDef = definition("plot", "container", {
	props: {
		label: optionalLabel(),
		min: props.number({
			dynamic: true,
			default: -10
		}),
		max: props.number({
			dynamic: true,
			default: 10
		}),
		samples: props.number({
			integer: true,
			min: 2,
			max: 2e3,
			static: true,
			default: 200
		}),
		"x-label": props.text({ default: "x" }),
		"y-label": props.text({ default: "y" })
	},
	structure: structure({
		rule: "plot",
		label: "optional"
	}),
	rules: rules({ kind: "math-body" }, {
		kind: "numeric-range",
		min: "min",
		max: "max",
		order: "increasing"
	}, {
		kind: "plot-math",
		min: "min",
		max: "max",
		samples: "samples",
		curves: 16,
		points: MAX_LOCAL_PLOT_POINTS
	}, { kind: "inline-math-reads" })
});
var timelineDef = definition("timeline", "container", {
	props: {
		title: optionalTitle(),
		unit: props.text({ default: "minutes" })
	},
	structure: structure({
		rule: "table",
		label: "none"
	}),
	rules: rules({ kind: "single-table" }, {
		kind: "timeline-table",
		headerSets: [[
			"Task",
			"Start",
			"Duration",
			"Notes"
		], [
			"事项",
			"开始",
			"时长",
			"说明"
		]]
	})
});
var diagramDef = definition("diagram", "container", {
	props: {
		label: optionalLabel(),
		direction: props.choice(["right", "down"], {
			static: true,
			default: "right"
		})
	},
	bindings: { value: binding("string", "diagram", "first-node", { exclusive: true }) },
	structure: structure({
		rule: "diagram",
		label: "optional",
		child: "node",
		children: ["node", "edge"],
		min: 1
	}),
	rules: rules({
		kind: "diagram-body",
		node: "node",
		edge: "edge",
		id: "id",
		from: "from",
		to: "to",
		label: "label"
	}, {
		kind: "self-binding-read",
		mode: "always"
	})
});
var nodeDef = definition("node", "container", {
	props: {
		id: props.staticText({ required: true }),
		label: label(),
		tone: props.choice([
			"neutral",
			"success",
			"warning"
		], {
			dynamic: true,
			default: "neutral"
		})
	},
	structure: structure({
		rule: "content",
		label: "required",
		noComponents: true,
		parents: ["diagram"]
	}),
	rules: rules({ kind: "no-components" })
});
var edgeDef = definition("edge", "leaf", {
	props: {
		from: props.staticText({ required: true }),
		to: props.staticText({ required: true }),
		label: optionalLabel()
	},
	structure: structure({
		rule: "none",
		label: "none",
		parents: ["diagram"]
	})
});
/**
* The rendered/structural components of the default preset, in declaration
* order. `computed`, `const` and `external` stay kernel grammar
* metadata in `src/local/configuration/schema.ts`.
*/
var DEFAULT_SEMANTIC_COMPONENTS = Object.freeze([
	inputDef,
	textareaDef,
	numberDef,
	sliderDef,
	rangeSliderDef,
	coordinateDef,
	toggleDef,
	checkboxDef,
	dateDef,
	selectDef,
	choicesDef,
	radioGroupDef,
	multiSelectDef,
	optionDef,
	counterDef,
	timerDef,
	checklistDef,
	progressDef,
	jumpDef,
	anchorDef,
	textDef,
	sectionDef,
	quizDef,
	panelDef,
	cardDef,
	gridDef,
	galleryDef,
	galleryItemDef,
	tabsDef,
	tabDef,
	stepsDef,
	stepDef,
	accordionDef,
	disclosureDef,
	ifDef,
	alertDef,
	badgeDef,
	tooltipDef,
	validationDef,
	dataTableDef,
	columnDef,
	tableDef,
	chartDef,
	plotDef,
	timelineDef,
	diagramDef,
	nodeDef,
	edgeDef
]);
Object.freeze(DEFAULT_SEMANTIC_COMPONENTS.map((component) => component.name));
// src/presets/default-components.ts
/**
* Authored assembly of the default preset.
*
* Semantic declarations live in `default-semantics.ts` and import nothing from
* authoring. This module adds the portable English titles, descriptions and
* insertion templates that editor catalogs read. Compilers that only need
* component semantics can import the semantic module without pulling authoring
* copy into their graph.
*/
function withAuthoring(definition) {
	const authoring = defaultManifestAuthoring(definition.name);
	return authoring ? defineLocalComponent({
		...definition,
		authoring
	}) : definition;
}
// src/presets/default.ts
var defaultPreset = defineLocalPreset({
	protocol: LOCAL_PRESET_PROTOCOL,
	id: DEFAULT_PRESET_ID$1,
	version: DEFAULT_PRESET_VERSION$1,
	components: Object.freeze(DEFAULT_SEMANTIC_COMPONENTS.map(withAuthoring))
});
// src/local/theme/theme-name.ts
/**
* Theme name grammar shared by document parsing and host manifests.
*
* This module is deliberately dependency-free so the compiler kernel can
* validate `<theme name="...">` without loading theme definitions, CSS or host
* code. `theme.ts` re-exports it for the existing public surface.
*/
var THEME_NAME = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/;
/** Bounded, URL-free theme identifier used by documents and host manifests. */
function isLocalThemeName(value) {
	return typeof value === "string" && value.length > 0 && value.length <= 64 && THEME_NAME.test(value);
}
// src/local/theme/theme.ts
/**
* Versioned theme contract. A host registers CSS for a theme name and declares
* that contract here; the document only carries a name, never CSS or a URL.
*/
var LOCAL_THEME_PROTOCOL = "reactive-md-theme-1";
Object.freeze({
	name: "default",
	protocol: LOCAL_THEME_PROTOCOL,
	colorSchemes: Object.freeze(["light", "dark"])
});
// src/sdk/theme.ts
var MAX_THEME_PACKAGE_ID_LENGTH = 128;
var MAX_THEME_RESOURCE_COUNT = 32;
var MAX_STYLE_RESOURCE_ID_LENGTH = 128;
var MAX_THEME_RESOURCE_CSS_LENGTH = 262144;
var MAX_THEME_TOTAL_CSS_LENGTH = 524288;
var THEME_PACKAGE_ID = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/;
var STYLE_RESOURCE_ID = /^[a-z][a-z0-9._/-]*$/;
var THEME_VERSION = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/;
var THEME_SCOPE_AT_START = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/;
var HOST_GLOBAL_SELECTOR = /^(?::root|html|body)(?![A-Za-z0-9_-])/i;
var CONDITIONAL_AT_RULES = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]);
var MAX_FONT_FAMILY_NAME_BYTES = 256;
var GENERIC_FONT_FAMILIES = /* @__PURE__ */ new Set([
	"serif",
	"sans-serif",
	"monospace",
	"cursive",
	"fantasy",
	"system-ui",
	"ui-serif",
	"ui-sans-serif",
	"ui-monospace",
	"ui-rounded",
	"math",
	"emoji",
	"fangsong",
	"-apple-system",
	"blinkmacsystemfont"
]);
var CSS_WIDE_KEYWORDS = /* @__PURE__ */ new Set([
	"inherit",
	"initial",
	"unset",
	"revert",
	"revert-layer"
]);
var SYSTEM_FONT_KEYWORDS = /* @__PURE__ */ new Set([
	"caption",
	"icon",
	"menu",
	"message-box",
	"small-caption",
	"status-bar"
]);
var FONT_SIZE_KEYWORDS = /* @__PURE__ */ new Set([
	"xx-small",
	"x-small",
	"small",
	"medium",
	"large",
	"x-large",
	"xx-large",
	"xxx-large",
	"smaller",
	"larger"
]);
/** Generated family names carry the theme name and an injective encoding. */
var GENERATED_FONT_FAMILY = /^rmd-theme-([a-z][a-z0-9-]*)-font-([0-9a-f]+)$/;
function themeError$1(path, message) {
	return /* @__PURE__ */ new Error(`Invalid local theme ${path}: ${message}`);
}
function isRecord$2(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function requireRecord(value, path) {
	if (!isRecord$2(value)) throw themeError$1(path, "must be an object.");
	return value;
}
function readThemeId(value, path) {
	if (typeof value !== "string" || value.length === 0) throw themeError$1(path, "must be a non-empty string.");
	if (value.length > MAX_THEME_PACKAGE_ID_LENGTH) throw themeError$1(path, `must not exceed ${MAX_THEME_PACKAGE_ID_LENGTH} characters.`);
	if (!THEME_PACKAGE_ID.test(value)) throw themeError$1(path, `"${value}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return value;
}
function readThemeName(value, path) {
	if (!isLocalThemeName(value)) throw themeError$1(path, "must be a lowercase kebab-case name that starts with a letter.");
	if (value === "default") throw themeError$1(path, "must not replace the reserved built-in \"default\" theme.");
	return value;
}
function readThemeVersion(value, path) {
	if (typeof value !== "string" || !THEME_VERSION.test(value)) throw themeError$1(path, "must be a semantic version such as \"1.0.0\".");
	return value;
}
function readColorSchemes(value, path) {
	if (value === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(value)) throw themeError$1(path, "must be an array of \"light\" and \"dark\".");
	const schemes = [];
	for (const entry of value) {
		if (entry !== "light" && entry !== "dark") throw themeError$1(path, "may only contain \"light\" and \"dark\".");
		if (schemes.includes(entry)) throw themeError$1(path, `must not repeat "${entry}".`);
		schemes.push(entry);
	}
	if (!schemes.includes("light") || !schemes.includes("dark")) throw themeError$1(path, "must declare both \"light\" and \"dark\".");
	return Object.freeze(schemes);
}
function skipString(css, start) {
	const quote = css[start];
	let index = start + 1;
	while (index < css.length) {
		if (css[index] === "\\") {
			index += 2;
			continue;
		}
		if (css[index] === quote) return index + 1;
		index += 1;
	}
	return css.length;
}
function skipBalanced(css, start, open, close) {
	let depth = 0;
	for (let index = start; index < css.length; index += 1) {
		const character = css[index];
		if (character === "\"" || character === "'") {
			index = skipString(css, index) - 1;
			continue;
		}
		if (character === "/" && css[index + 1] === "*") {
			const end = css.indexOf("*/", index + 2);
			index = (end < 0 ? css.length : end + 2) - 1;
			continue;
		}
		if (character === open) depth += 1;
		else if (character === close) {
			depth -= 1;
			if (depth === 0) return index + 1;
		}
	}
	return css.length;
}
/** Read a `url(...)` value and return the trimmed target plus the end offset. */
function readUrlValue(css, start, path) {
	let cursor = start + 3;
	while (cursor < css.length && /\s/.test(css[cursor])) cursor += 1;
	if (css[cursor] !== "(") throw themeError$1(path, "has a malformed url() value.");
	cursor += 1;
	while (cursor < css.length && /\s/.test(css[cursor])) cursor += 1;
	const quote = css[cursor];
	if (quote === "\"" || quote === "'") {
		const close = css.indexOf(quote, cursor + 1);
		if (close < 0) throw themeError$1(path, "has an unterminated url() string.");
		const value = css.slice(cursor + 1, close);
		cursor = close + 1;
		while (cursor < css.length && /\s/.test(css[cursor])) cursor += 1;
		if (css[cursor] !== ")") throw themeError$1(path, "has a malformed url() value.");
		return {
			value: value.trim(),
			end: cursor + 1
		};
	}
	const close = css.indexOf(")", cursor);
	if (close < 0) throw themeError$1(path, "has an unterminated url() value.");
	return {
		value: css.slice(cursor, close).trim(),
		end: close + 1
	};
}
/** Read the argument body of a function at `start`, e.g. `image-set(...)`. */
function readFunctionBody(css, start, name, path) {
	let open = start;
	while (open < css.length && css[open] !== "(") open += 1;
	if (open >= css.length) throw themeError$1(path, `has a malformed ${name}() value.`);
	const end = skipBalanced(css, open, "(", ")");
	if (end <= open + 1 || css[end - 1] !== ")") throw themeError$1(path, `has an unterminated ${name}() value.`);
	return {
		body: css.slice(open + 1, end - 1),
		end
	};
}
/**
* `image-set("https://…")` fetches an image without a `url()` token. Phase-one
* themes may only use inline `data:` entries, in either string or url() form.
*/
function assertImageSetEntries(body, path) {
	let index = 0;
	while (index < body.length) {
		const character = body[index];
		if (character === "\"" || character === "'") {
			const end = skipString(body, index);
			if (end > body.length || body[end - 1] !== character) throw themeError$1(path, "has an unterminated image-set() string.");
			const value = body.slice(index + 1, end - 1).trim();
			if (!/^data:/i.test(value)) throw themeError$1(path, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			index = end;
			continue;
		}
		if (character === "/" && body[index + 1] === "*") {
			const end = body.indexOf("*/", index + 2);
			index = end < 0 ? body.length : end + 2;
			continue;
		}
		index += 1;
	}
}
/**
* Reject CSS that could escape the inline stylesheet or fetch a remote
* resource. Only `data:` URLs are accepted in phase one.
*/
function assertSafeCss(css, path, allowFragments = false) {
	if (css.toLowerCase().includes("</style")) throw themeError$1(path, "must not contain a closing style tag.");
	let index = 0;
	while (index < css.length) {
		const character = css[index];
		if (character === "\"" || character === "'") {
			index = skipString(css, index);
			continue;
		}
		if (character === "/" && css[index + 1] === "*") {
			const end = css.indexOf("*/", index + 2);
			index = end < 0 ? css.length : end + 2;
			continue;
		}
		if (character === "\\") throw themeError$1(path, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
		if (character === "@" && /^@import\b/i.test(css.slice(index, index + 8))) throw themeError$1(path, "must not use @import; inline every resource.");
		if ((character === "i" || character === "I" || character === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(css.slice(index, index + 24))) {
			const { body } = readFunctionBody(css, index, "image-set", path);
			assertImageSetEntries(body, path);
			index += 1;
			continue;
		}
		if ((character === "u" || character === "U") && /^url\s*\(/i.test(css.slice(index, index + 12))) {
			const url = readUrlValue(css, index, path);
			if (!/^data:/i.test(url.value) && !(allowFragments && url.value.startsWith("#"))) throw themeError$1(path, "may only reference data: URLs; network and file URLs are not allowed.");
			index = url.end;
			continue;
		}
		if ((character === "e" || character === "E") && /^expression\s*\(/i.test(css.slice(index, index + 16))) throw themeError$1(path, "must not use CSS expression().");
		index += 1;
	}
}
function splitSelectors(prelude) {
	const selectors = [];
	let start = 0;
	let parentheses = 0;
	let brackets = 0;
	for (let index = 0; index < prelude.length; index += 1) {
		const character = prelude[index];
		if (character === "\"" || character === "'") {
			index = skipString(prelude, index) - 1;
			continue;
		}
		if (character === "/" && prelude[index + 1] === "*") {
			const end = prelude.indexOf("*/", index + 2);
			index = (end < 0 ? prelude.length : end + 2) - 1;
			continue;
		}
		if (character === "\\") {
			index += 1;
			continue;
		}
		if (character === "(") parentheses += 1;
		else if (character === ")") parentheses = Math.max(0, parentheses - 1);
		else if (character === "[") brackets += 1;
		else if (character === "]") brackets = Math.max(0, brackets - 1);
		else if (character === "," && parentheses === 0 && brackets === 0) {
			selectors.push(prelude.slice(start, index));
			start = index + 1;
		}
	}
	selectors.push(prelude.slice(start));
	return selectors;
}
function scopeSelector(selector, name) {
	const trimmed = selector.trim();
	const scope = `[data-rmd-theme="${name}"]`;
	const existing = THEME_SCOPE_AT_START.exec(trimmed);
	if (existing) return `${scope}${trimmed.slice(existing[0].length)}`;
	return `${scope} ${trimmed}`;
}
function skipTrivia(input, start) {
	let index = start;
	while (index < input.length) {
		if (/\s/.test(input[index])) {
			index += 1;
			continue;
		}
		if (input[index] === "/" && input[index + 1] === "*") {
			const end = input.indexOf("*/", index + 2);
			index = end < 0 ? input.length : end + 2;
			continue;
		}
		break;
	}
	return index;
}
/** Reject relative selectors in `:has()` that target siblings of the theme root. */
function assertHasNoSiblingSelectors(selector, rootEnd) {
	const lower = selector.toLowerCase();
	const pattern = /:has\s*\(/g;
	for (let match = pattern.exec(lower); match; match = pattern.exec(lower)) {
		pattern.lastIndex = match.index + 1;
		if (match.index >= rootEnd) continue;
		const open = match.index + match[0].length - 1;
		const end = skipBalanced(selector, open, "(", ")");
		const body = selector.slice(open + 1, Math.max(open + 1, end - 1));
		for (const part of splitSelectors(body)) if (/^\s*[+~]/.test(part)) throw themeError$1("theme.css", `selector "${selector.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
/**
* A selector that starts at the theme root may not continue with a sibling
* combinator: `[data-rmd-theme="paper"] + .host` would restyle an element
* outside the document root.
*/
function assertNoSiblingEscape(selector) {
	const trimmed = selector.trim();
	if (trimmed === "") return;
	if (trimmed[0] === "+" || trimmed[0] === "~") throw themeError$1("theme.css", `selector "${trimmed}" begins with a sibling combinator and cannot be scoped.`);
	const scope = THEME_SCOPE_AT_START.exec(trimmed);
	if (scope) {
		let index = scope[0].length;
		while (index < trimmed.length) {
			const character = trimmed[index];
			if (/\s/.test(character) || character === "+" || character === "~" || character === ">" || character === ",") break;
			if (character === "[") {
				index = skipBalanced(trimmed, index, "[", "]");
				continue;
			}
			if (character === "(") {
				index = skipBalanced(trimmed, index, "(", ")");
				continue;
			}
			index += 1;
		}
		const combinator = skipTrivia(trimmed, index);
		if (trimmed[combinator] === "+" || trimmed[combinator] === "~") throw themeError$1("theme.css", `selector "${trimmed}" uses a sibling combinator that can escape the theme root.`);
		assertHasNoSiblingSelectors(trimmed, index);
	}
}
function scopeSelectorList(prelude, name) {
	const selectors = splitSelectors(prelude).map((selector) => selector.trim()).filter(Boolean);
	if (selectors.length === 0) return prelude.trim();
	for (const selector of selectors) {
		if (HOST_GLOBAL_SELECTOR.test(selector)) throw themeError$1("theme.css", `selector "${selector}" targets the host document; scope it under the theme root instead.`);
		assertNoSiblingEscape(selector);
	}
	return selectors.map((selector) => scopeSelector(selector, name)).join(", ");
}
function findBlockEnd(css, start) {
	let depth = 1;
	for (let index = start; index < css.length; index += 1) {
		const character = css[index];
		if (character === "\"" || character === "'") {
			index = skipString(css, index) - 1;
			continue;
		}
		if (character === "/" && css[index + 1] === "*") {
			const end = css.indexOf("*/", index + 2);
			index = (end < 0 ? css.length : end + 2) - 1;
			continue;
		}
		if (character === "{") depth += 1;
		else if (character === "}") {
			depth -= 1;
			if (depth === 0) return index;
		}
	}
	return css.length;
}
function normalizeFontFamily(value) {
	return value.trim().replace(/\s+/g, " ").toLowerCase();
}
function utf8Bytes(value) {
	const bytes = [];
	for (const character of value) {
		const code = character.codePointAt(0);
		if (code <= 127) bytes.push(code);
		else if (code <= 2047) bytes.push(192 | code >> 6, 128 | code & 63);
		else if (code <= 65535) bytes.push(224 | code >> 12, 128 | code >> 6 & 63, 128 | code & 63);
		else bytes.push(240 | code >> 18, 128 | code >> 12 & 63, 128 | code >> 6 & 63, 128 | code & 63);
	}
	return bytes;
}
function utf8String(bytes) {
	let result = "";
	let index = 0;
	while (index < bytes.length) {
		const first = bytes[index];
		let code;
		let length;
		if (first <= 127) {
			code = first;
			length = 1;
		} else if (first >= 194 && first <= 223) {
			code = first & 31;
			length = 2;
		} else if (first >= 224 && first <= 239) {
			code = first & 15;
			length = 3;
		} else if (first >= 240 && first <= 244) {
			code = first & 7;
			length = 4;
		} else return null;
		if (index + length > bytes.length) return null;
		for (let offset = 1; offset < length; offset += 1) {
			const continuation = bytes[index + offset];
			if ((continuation & 192) !== 128) return null;
			code = code << 6 | continuation & 63;
		}
		if (length === 3 && (code < 2048 || code >= 55296 && code <= 57343)) return null;
		if (length === 4 && (code < 65536 || code > 1114111)) return null;
		result += String.fromCodePoint(code);
		index += length;
	}
	return result;
}
/** A deterministic, theme-scoped family name; the hex suffix is invertible. */
function generatedFontFamily(themeName, family) {
	return `rmd-theme-${themeName}-font-${utf8Bytes(family).map((byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}
/** Recognise a family produced here and recover its original normalized name. */
function readGeneratedFontFamily(value) {
	const match = GENERATED_FONT_FAMILY.exec(value);
	if (!match || match[2].length % 2 !== 0) return null;
	const bytes = [];
	for (let index = 0; index < match[2].length; index += 2) bytes.push(Number.parseInt(match[2].slice(index, index + 2), 16));
	const original = utf8String(bytes);
	if (original === null || original.length === 0) return null;
	if (normalizeFontFamily(original) !== original) return null;
	return {
		themeName: match[1],
		original
	};
}
function isIdentChar(character) {
	if (character === void 0) return false;
	return /[A-Za-z0-9_-]/.test(character) || character.codePointAt(0) >= 128;
}
function isIdentStart(css, index) {
	const character = css[index];
	if (character === void 0) return false;
	if (/[A-Za-z_]/.test(character)) return true;
	if (character.codePointAt(0) >= 128) return true;
	if (character === "-") {
		const next = css[index + 1];
		return next !== void 0 && (isIdentChar(next) || next === "-");
	}
	return false;
}
function startsNumber(css, index) {
	const character = css[index];
	if (character === void 0) return false;
	if (character >= "0" && character <= "9") return true;
	const next = css[index + 1];
	if (character === "+" || character === "-") return next !== void 0 && (next >= "0" && next <= "9" || next === ".");
	if (character === ".") return next !== void 0 && next >= "0" && next <= "9";
	return false;
}
/** Tokenize a declaration value without interpreting functions other than URL. */
function tokenizeCssValue(value) {
	const tokens = [];
	let index = 0;
	while (index < value.length) {
		const character = value[index];
		if (/\s/.test(character)) {
			index += 1;
			continue;
		}
		if (character === "/" && value[index + 1] === "*") {
			const end = value.indexOf("*/", index + 2);
			index = end < 0 ? value.length : end + 2;
			continue;
		}
		const start = index;
		if (character === "\"" || character === "'") {
			const end = skipString(value, index);
			tokens.push({
				type: "string",
				text: value.slice(start, end),
				start,
				end,
				name: "",
				stringValue: value.slice(start + 1, Math.max(start + 1, end - 1))
			});
			index = end;
			continue;
		}
		if (character === ",") {
			tokens.push({
				type: "comma",
				text: ",",
				start,
				end: index + 1,
				name: "",
				stringValue: ""
			});
			index += 1;
			continue;
		}
		if (startsNumber(value, index)) {
			let end = index;
			if (value[end] === "+" || value[end] === "-") end += 1;
			while (value[end] >= "0" && value[end] <= "9") end += 1;
			if (value[end] === ".") {
				end += 1;
				while (value[end] >= "0" && value[end] <= "9") end += 1;
			}
			if (value[end] === "e" || value[end] === "E") {
				const exponentStart = end;
				end += 1;
				if (value[end] === "+" || value[end] === "-") end += 1;
				const digitsStart = end;
				while (value[end] >= "0" && value[end] <= "9") end += 1;
				if (end === digitsStart) end = exponentStart;
			}
			let type = "number";
			if (value[end] === "%") {
				end += 1;
				type = "percentage";
			} else if (isIdentStart(value, end)) {
				end += 1;
				while (isIdentChar(value[end])) end += 1;
				type = "dimension";
			}
			tokens.push({
				type,
				text: value.slice(start, end),
				start,
				end,
				name: "",
				stringValue: ""
			});
			index = end;
			continue;
		}
		if (isIdentStart(value, index)) {
			let end = index + 1;
			while (isIdentChar(value[end])) end += 1;
			const name = value.slice(index, end).toLowerCase();
			if (value[end] === "(") {
				const close = skipBalanced(value, end, "(", ")");
				const tokenEnd = Math.min(close, value.length);
				tokens.push({
					type: "function",
					text: value.slice(index, tokenEnd),
					start,
					end: tokenEnd,
					name,
					stringValue: ""
				});
				index = tokenEnd;
				continue;
			}
			tokens.push({
				type: "ident",
				text: value.slice(index, end),
				start,
				end,
				name,
				stringValue: ""
			});
			index = end;
			continue;
		}
		if (character === "(") {
			const close = skipBalanced(value, index, "(", ")");
			const end = Math.min(close, value.length);
			tokens.push({
				type: "function",
				text: value.slice(index, end),
				start,
				end,
				name: "",
				stringValue: ""
			});
			index = end;
			continue;
		}
		tokens.push({
			type: "delimiter",
			text: character,
			start,
			end: index + 1,
			name: "",
			stringValue: ""
		});
		index += 1;
	}
	return tokens;
}
function isCssTrivia(value) {
	return skipTrivia(value, 0) === value.length;
}
/**
* Read one `<family-name>`: a quoted string or an unquoted ident sequence.
* Returns null for system/generic/CSS-wide keywords and for syntax this
* validator cannot resolve (functions and mixed token kinds).
*/
function parseCssFamily(segment) {
	const tokens = tokenizeCssValue(segment);
	if (tokens.length === 0) return null;
	if (tokens.length === 1 && tokens[0].type === "string") {
		const key = normalizeFontFamily(tokens[0].stringValue);
		if (key === "") return null;
		return {
			key,
			start: tokens[0].start,
			end: tokens[0].end
		};
	}
	if (tokens[0].type === "string") return null;
	for (let index = 0; index < tokens.length; index += 1) {
		if (tokens[index].type !== "ident") return null;
		if (index > 0 && !isCssTrivia(segment.slice(tokens[index - 1].end, tokens[index].start))) return null;
	}
	if (tokens.length === 1) {
		if (CSS_WIDE_KEYWORDS.has(tokens[0].name) || GENERIC_FONT_FAMILIES.has(tokens[0].name)) return null;
	}
	const key = normalizeFontFamily(tokens.map((token) => token.text).join(" "));
	if (key === "") return null;
	return {
		key,
		start: tokens[0].start,
		end: tokens[tokens.length - 1].end
	};
}
/** Split a declaration value on top-level commas, preserving offsets. */
function splitValueSegments(value) {
	const segments = [];
	let start = 0;
	let index = 0;
	while (index < value.length) {
		const character = value[index];
		if (character === "\"" || character === "'") {
			index = skipString(value, index);
			continue;
		}
		if (character === "/" && value[index + 1] === "*") {
			const end = value.indexOf("*/", index + 2);
			index = end < 0 ? value.length : end + 2;
			continue;
		}
		if (character === "(" || character === "[") {
			index = skipBalanced(value, index, character, character === "(" ? ")" : "]");
			continue;
		}
		if (character === ",") {
			segments.push({
				start,
				end: index
			});
			start = index + 1;
		}
		index += 1;
	}
	segments.push({
		start,
		end: value.length
	});
	return segments;
}
function splitTrailingImportant(value) {
	const tokens = tokenizeCssValue(value);
	if (tokens.length < 2) return {
		body: value,
		important: ""
	};
	const last = tokens[tokens.length - 1];
	const marker = tokens[tokens.length - 2];
	if (last.type !== "ident" || last.name !== "important") return {
		body: value,
		important: ""
	};
	if (marker.type !== "delimiter" || marker.text !== "!") return {
		body: value,
		important: ""
	};
	if (!isCssTrivia(value.slice(marker.end, last.start))) return {
		body: value,
		important: ""
	};
	return {
		body: value.slice(0, marker.start),
		important: value.slice(marker.start)
	};
}
function applyReplacements(value, replacements) {
	if (replacements.length === 0) return value;
	const ordered = [...replacements].sort((left, right) => left.start - right.start);
	let result = "";
	let index = 0;
	for (const replacement of ordered) {
		if (replacement.start < index) continue;
		result += value.slice(index, replacement.start) + replacement.text;
		index = replacement.end;
	}
	return result + value.slice(index);
}
function quotedFamily(family) {
	return `"${family}"`;
}
/** Rewrite only family entries that are declared by this theme. */
function rewriteFontFamilyList(value, families, depth = 0) {
	if (families.size === 0) return value;
	if (depth > 64) throw themeError$1("theme.css", "font-family fallback nesting exceeds 64 levels.");
	const { body, important } = splitTrailingImportant(value);
	const replacements = [];
	for (const segment of splitValueSegments(body)) {
		const part = body.slice(segment.start, segment.end);
		const parsed = parseCssFamily(part);
		if (parsed) {
			const target = families.get(parsed.key);
			if (target) replacements.push({
				start: segment.start + parsed.start,
				end: segment.start + parsed.end,
				text: quotedFamily(target)
			});
			continue;
		}
		const tokens = tokenizeCssValue(part);
		if (tokens.length === 0) continue;
		if (tokens.length === 1 && tokens[0].type === "ident" && (GENERIC_FONT_FAMILIES.has(tokens[0].name) || CSS_WIDE_KEYWORDS.has(tokens[0].name))) continue;
		if (tokens.length === 1 && tokens[0].type === "function" && tokens[0].name === "var") {
			const token = tokens[0];
			const open = token.text.indexOf("(");
			const argumentsText = token.text.slice(open + 1, -1);
			const argumentsList = splitValueSegments(argumentsText);
			const variable = tokenizeCssValue(argumentsText.slice(0, argumentsList[0].end));
			if (!token.text.endsWith(")") || variable.length !== 1 || variable[0].type !== "ident" || !variable[0].text.startsWith("--")) throw themeError$1("theme.css", "font-family var() must start with a custom property name.");
			if (argumentsList.length > 1) {
				const fallbackStart = argumentsList[0].end + 1;
				const fallback = argumentsText.slice(fallbackStart);
				replacements.push({
					start: segment.start + token.start + open + 1 + fallbackStart,
					end: segment.start + token.end - 1,
					text: rewriteFontFamilyList(fallback, families, depth + 1)
				});
			}
			continue;
		}
		throw themeError$1("theme.css", "unsupported font-family syntax; use literal families or var() with a family-list fallback.");
	}
	return applyReplacements(body, replacements) + important;
}
/** Locate the family list inside a `font` shorthand, or null if unsupported. */
function findFontFamilyStart(value) {
	const tokens = tokenizeCssValue(value);
	if (tokens.length === 0) return null;
	if (tokens.length === 1 && tokens[0].type === "ident" && (SYSTEM_FONT_KEYWORDS.has(tokens[0].name) || CSS_WIDE_KEYWORDS.has(tokens[0].name))) return null;
	let sizeIndex = -1;
	for (let index = 0; index < tokens.length; index += 1) {
		const token = tokens[index];
		if (token.type === "dimension" && !/(?:deg|grad|rad|turn)$/i.test(token.text) || token.type === "percentage") {
			sizeIndex = index;
			break;
		}
		if (token.type === "ident" && FONT_SIZE_KEYWORDS.has(token.name)) {
			sizeIndex = index;
			break;
		}
		if (token.type === "number" && Number(token.text) === 0) {
			sizeIndex = index;
			break;
		}
		if (token.type === "function") {
			const next = tokens[index + 1];
			if ([
				"calc",
				"min",
				"max",
				"clamp"
			].includes(token.name) || token.name === "var" && next?.type === "delimiter" && next.text === "/") {
				sizeIndex = index;
				break;
			}
		}
	}
	if (sizeIndex < 0) return null;
	let familyIndex = sizeIndex + 1;
	const slash = tokens[familyIndex];
	if (slash?.type === "delimiter" && slash.text === "/") familyIndex += 2;
	if (familyIndex >= tokens.length) return null;
	return tokens[familyIndex].start;
}
function rewriteFontShorthand(value, families) {
	if (families.size === 0) return value;
	const { body, important } = splitTrailingImportant(value);
	const familyStart = findFontFamilyStart(body);
	if (familyStart === null) {
		const tokens = tokenizeCssValue(body);
		if (tokens.length === 1 && tokens[0].type === "ident" && (SYSTEM_FONT_KEYWORDS.has(tokens[0].name) || CSS_WIDE_KEYWORDS.has(tokens[0].name))) return value;
		if (tokens.length === 1 && tokens[0].type === "function" && tokens[0].name === "var" && splitValueSegments(tokens[0].text.slice(tokens[0].text.indexOf("(") + 1, -1)).length === 1) return value;
		throw themeError$1("theme.css", "unsupported font shorthand; use an explicit font size (including calc/min/max/clamp) and a family list.");
	}
	const family = rewriteFontFamilyList(body.slice(familyStart), families);
	return body.slice(0, familyStart) + family + important;
}
/** Read declaration spans, optionally descending into nested rules with original offsets. */
function scanDeclarations(body, includeNested = false, depth = 0) {
	if (depth > 64) throw themeError$1("theme.css", "nested font declarations exceed 64 levels.");
	const declarations = [];
	const nested = (open) => {
		const end = findBlockEnd(body, open + 1);
		if (includeNested) for (const item of scanDeclarations(body.slice(open + 1, end), true, depth + 1)) declarations.push({
			name: item.name,
			valueStart: open + 1 + item.valueStart,
			valueEnd: open + 1 + item.valueEnd
		});
		return Math.min(end + 1, body.length);
	};
	let index = 0;
	while (index < body.length) {
		index = skipTrivia(body, index);
		if (index >= body.length) break;
		if (body[index] === ";" || body[index] === "}") {
			index += 1;
			continue;
		}
		if (body[index] === "{") {
			index = nested(index);
			continue;
		}
		const declarationStart = index;
		let cursor = index;
		while (cursor < body.length) {
			const current = body[cursor];
			if (current === "\"" || current === "'") {
				cursor = skipString(body, cursor);
				continue;
			}
			if (current === "/" && body[cursor + 1] === "*") {
				cursor = skipTrivia(body, cursor);
				continue;
			}
			if (current === "(" || current === "[") {
				cursor = skipBalanced(body, cursor, current, current === "(" ? ")" : "]");
				continue;
			}
			if (current === ":" || current === ";" || current === "{" || current === "}") break;
			cursor += 1;
		}
		if (cursor >= body.length) break;
		if (body[cursor] !== ":") {
			index = body[cursor] === "{" ? nested(cursor) : cursor + 1;
			continue;
		}
		const propertyTokens = tokenizeCssValue(body.slice(declarationStart, cursor));
		const property = propertyTokens.length === 1 && propertyTokens[0].type === "ident" ? propertyTokens[0] : void 0;
		const authoredName = property?.text ?? "";
		const name = authoredName.startsWith("--") ? authoredName : authoredName.toLowerCase();
		const valueStart = cursor + 1;
		let valueEnd = valueStart;
		while (valueEnd < body.length) {
			const current = body[valueEnd];
			if (current === "\"" || current === "'") {
				valueEnd = skipString(body, valueEnd);
				continue;
			}
			if (current === "/" && body[valueEnd + 1] === "*") {
				valueEnd = skipTrivia(body, valueEnd);
				continue;
			}
			if (current === "(" || current === "[") {
				valueEnd = skipBalanced(body, valueEnd, current, current === "(" ? ")" : "]");
				continue;
			}
			if (current === "{" && authoredName.startsWith("--")) {
				valueEnd = findBlockEnd(body, valueEnd + 1) + 1;
				continue;
			}
			if (current === ";" || current === "{" || current === "}") break;
			valueEnd += 1;
		}
		if (body[valueEnd] === "{") {
			index = nested(valueEnd);
			continue;
		}
		if (property) declarations.push({
			name,
			valueStart,
			valueEnd
		});
		index = valueEnd;
		if (body[valueEnd] === ";") index += 1;
	}
	return declarations;
}
function rewriteDeclarationBody(body, families) {
	if (families.size === 0) return body;
	const replacements = [];
	for (const declaration of scanDeclarations(body, true)) {
		const familyProperty = declaration.name === "font-family" || declaration.name === "--font-sans" || declaration.name === "--font-mono";
		if (!familyProperty && declaration.name !== "font") continue;
		const value = body.slice(declaration.valueStart, declaration.valueEnd);
		const rewritten = familyProperty ? rewriteFontFamilyList(value, families) : rewriteFontShorthand(value, families);
		if (rewritten === value) continue;
		replacements.push({
			start: declaration.valueStart,
			end: declaration.valueEnd,
			text: rewritten
		});
	}
	return applyReplacements(body, replacements);
}
/** Walk every `@font-face` block, including those nested in conditional rules. */
function visitFontFaces(css, path, visit) {
	let index = 0;
	while (index < css.length) {
		const character = css[index];
		if (/\s/.test(character) || character === ";" || character === "}") {
			index += 1;
			continue;
		}
		if (character === "/" && css[index + 1] === "*") {
			const end = css.indexOf("*/", index + 2);
			index = end < 0 ? css.length : end + 2;
			continue;
		}
		if (character === "{") {
			index = findBlockEnd(css, index + 1) + 1;
			continue;
		}
		const start = index;
		let cursor = index;
		while (cursor < css.length) {
			const current = css[cursor];
			if (current === "\"" || current === "'") {
				cursor = skipString(css, cursor);
				continue;
			}
			if (current === "/" && css[cursor + 1] === "*") {
				const end = css.indexOf("*/", cursor + 2);
				cursor = end < 0 ? css.length : end + 2;
				continue;
			}
			if (current === "(" || current === "[") {
				cursor = skipBalanced(css, cursor, current, current === "(" ? ")" : "]");
				continue;
			}
			if (current === "{" || current === ";" || current === "}") break;
			cursor += 1;
		}
		if (cursor >= css.length) break;
		if (css[cursor] !== "{") {
			index = cursor + 1;
			continue;
		}
		const end = findBlockEnd(css, cursor + 1);
		const head = css.slice(start, cursor).trim();
		if (head.startsWith("@")) {
			const atName = (/^@([A-Za-z-]+)/.exec(head)?.[1] ?? "").toLowerCase();
			if (atName === "font-face") visit(css.slice(cursor + 1, end), path);
			else if (CONDITIONAL_AT_RULES.has(atName)) visitFontFaces(css.slice(cursor + 1, end), path, visit);
		}
		index = Math.min(end + 1, css.length);
	}
}
/** Validate and return the single declared family name of one `@font-face`. */
function readFontFaceFamily(body, path) {
	const declarations = scanDeclarations(body).filter((declaration) => declaration.name === "font-family");
	if (declarations.length === 0) throw themeError$1(path, "@font-face must declare a font-family descriptor.");
	if (declarations.length > 1) throw themeError$1(path, "@font-face may declare font-family only once.");
	const { body: core, important } = splitTrailingImportant(body.slice(declarations[0].valueStart, declarations[0].valueEnd));
	if (important !== "") throw themeError$1(path, "@font-face descriptors must not use !important.");
	if (splitValueSegments(core).length !== 1) throw themeError$1(path, "@font-face font-family must be a single family name, not a list.");
	const parsed = parseCssFamily(core);
	if (!parsed) throw themeError$1(path, "@font-face font-family must be one quoted or unquoted family name; generic families, keywords, var() and other functions are not allowed.");
	if (utf8Bytes(readGeneratedFontFamily(parsed.key)?.original ?? parsed.key).length > MAX_FONT_FAMILY_NAME_BYTES) throw themeError$1(path, `@font-face font-family must not exceed ${MAX_FONT_FAMILY_NAME_BYTES} UTF-8 bytes.`);
	return parsed.key;
}
/**
* Build the family mapping for a whole package. Declared families are read
* from every resource first, so a reference in one resource resolves against a
* `@font-face` declared in another.
*/
function buildFontFamilyMap(resources, themeName, path) {
	const families = /* @__PURE__ */ new Map();
	for (const resource of resources) visitFontFaces(resource.css, path, (body, facePath) => {
		const declared = readFontFaceFamily(body, facePath);
		const generated = readGeneratedFontFamily(declared);
		const original = generated ? generated.original : declared;
		const target = generatedFontFamily(themeName, original);
		const existing = families.get(declared);
		if (existing !== void 0 && existing !== target) throw themeError$1(facePath, `@font-face family "${declared}" maps to more than one name.`);
		families.set(declared, target);
		families.set(original, target);
	});
	return families;
}
function rewriteFontFaceBody(body, families, path) {
	const declarations = scanDeclarations(body).filter((declaration) => declaration.name === "font-family");
	if (declarations.length !== 1) throw themeError$1(path, "@font-face must declare exactly one font-family descriptor.");
	const declaration = declarations[0];
	const { body: core } = splitTrailingImportant(body.slice(declaration.valueStart, declaration.valueEnd));
	if (splitValueSegments(core).length !== 1) throw themeError$1(path, "@font-face font-family must be a single family name, not a list.");
	const parsed = parseCssFamily(core);
	if (!parsed) throw themeError$1(path, "@font-face has an unsupported font-family descriptor.");
	const target = families.get(parsed.key);
	if (target === void 0) throw themeError$1(path, `@font-face family "${parsed.key}" was not registered.`);
	return applyReplacements(body, [{
		start: declaration.valueStart + parsed.start,
		end: declaration.valueStart + parsed.end,
		text: quotedFamily(target)
	}]);
}
var EMPTY_FONT_FAMILIES = /* @__PURE__ */ new Map();
function transformCss(css, name, families = EMPTY_FONT_FAMILIES) {
	let result = "";
	let index = 0;
	while (index < css.length) {
		const character = css[index];
		if (character === "/" && css[index + 1] === "*") {
			const end = css.indexOf("*/", index + 2);
			const stop = end < 0 ? css.length : end + 2;
			result += css.slice(index, stop);
			index = stop;
			continue;
		}
		if (/\s/.test(character) || character === ";" || character === "}") {
			result += character;
			index += 1;
			continue;
		}
		const preludeStart = index;
		let cursor = index;
		while (cursor < css.length) {
			const current = css[cursor];
			if (current === "\"" || current === "'") {
				cursor = skipString(css, cursor);
				continue;
			}
			if (current === "/" && css[cursor + 1] === "*") {
				const end = css.indexOf("*/", cursor + 2);
				cursor = end < 0 ? css.length : end + 2;
				continue;
			}
			if (current === "(") {
				cursor = skipBalanced(css, cursor, "(", ")");
				continue;
			}
			if (current === "[") {
				cursor = skipBalanced(css, cursor, "[", "]");
				continue;
			}
			if (current === "{" || current === ";" || current === "}") break;
			cursor += 1;
		}
		if (cursor >= css.length) {
			result += css.slice(preludeStart);
			break;
		}
		const prelude = css.slice(preludeStart, cursor);
		const delimiter = css[cursor];
		if (delimiter === ";" || delimiter === "}") {
			result += prelude + delimiter;
			index = cursor + 1;
			continue;
		}
		const end = findBlockEnd(css, cursor + 1);
		const body = css.slice(cursor + 1, end);
		const head = prelude.trim();
		if (head.startsWith("@")) {
			const atName = (/^@([A-Za-z-]+)/.exec(head)?.[1] ?? "").toLowerCase();
			if (atName === "import") throw themeError$1("theme.css", "must not use @import.");
			if (atName === "keyframes" || atName.endsWith("-keyframes")) throw themeError$1("theme.css", `@${atName} declares a global name; phase one only supports document-scoped CSS.`);
			if (atName === "font-face") result += `${head} {${rewriteFontFaceBody(body, families, "theme.css")}}`;
			else {
				const inner = CONDITIONAL_AT_RULES.has(atName) ? transformCss(body, name, families) : body;
				result += `${head} {${inner}}`;
			}
		} else result += `${scopeSelectorList(head, name)} {${rewriteDeclarationBody(body, families)}}`;
		index = Math.min(end + 1, css.length);
	}
	return result;
}
/** Scope every rule in `css` to the document root that selects `name`. */
function scopeCss(css, name, families = EMPTY_FONT_FAMILIES) {
	return transformCss(css, name, families);
}
function readStyleResources(value, path) {
	if (!Array.isArray(value)) throw themeError$1(path, "must be an array of { id, css } resources.");
	if (value.length > MAX_THEME_RESOURCE_COUNT) throw themeError$1(path, `may contain at most ${MAX_THEME_RESOURCE_COUNT} resources.`);
	const ids = /* @__PURE__ */ new Set();
	const resources = [];
	let totalLength = 0;
	for (let index = 0; index < value.length; index += 1) {
		const entry = value[index];
		const lead = `${path}[${index}]`;
		if (!isRecord$2(entry)) throw themeError$1(lead, "must be an object.");
		const id = entry.id;
		if (typeof id !== "string" || id.length === 0) throw themeError$1(`${lead}.id`, "must be a non-empty string.");
		if (id.length > MAX_STYLE_RESOURCE_ID_LENGTH) throw themeError$1(`${lead}.id`, `must not exceed ${MAX_STYLE_RESOURCE_ID_LENGTH} characters.`);
		if (!STYLE_RESOURCE_ID.test(id)) throw themeError$1(`${lead}.id`, `"${id}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (ids.has(id)) throw themeError$1(`${lead}.id`, `"${id}" is declared more than once.`);
		ids.add(id);
		const css = entry.css;
		if (typeof css !== "string") throw themeError$1(`${lead}.css`, "must be a string.");
		if (css.length > MAX_THEME_RESOURCE_CSS_LENGTH) throw themeError$1(`${lead}.css`, `must not exceed ${MAX_THEME_RESOURCE_CSS_LENGTH} characters.`);
		totalLength += css.length;
		if (totalLength > MAX_THEME_TOTAL_CSS_LENGTH) throw themeError$1(path, `must not exceed ${MAX_THEME_TOTAL_CSS_LENGTH} characters in total.`);
		assertSafeCss(css, `${lead}.css`);
		resources.push(Object.freeze({
			id,
			css
		}));
	}
	return {
		resources: Object.freeze(resources),
		totalLength
	};
}
function freezePackage(input) {
	return Object.freeze({
		id: input.id,
		name: input.name,
		version: input.version,
		protocol: input.protocol,
		colorSchemes: Object.freeze([...input.colorSchemes]),
		css: Object.freeze(input.css.map((resource) => Object.freeze({
			id: resource.id,
			css: resource.css
		})))
	});
}
/**
* Validate, scope and freeze a theme package. The input is cloned; the result
* and every nested resource are frozen.
*/
function defineLocalTheme(input) {
	const record = requireRecord(input, "input");
	const id = readThemeId(record.id, "theme.id");
	const name = readThemeName(record.name, "theme.name");
	const version = readThemeVersion(record.version, "theme.version");
	if ((record.protocol === void 0 ? "reactive-md-theme-1" : record.protocol) !== "reactive-md-theme-1") throw themeError$1("theme.protocol", `must be "${LOCAL_THEME_PROTOCOL}".`);
	const colorSchemes = readColorSchemes(record.colorSchemes, "theme.colorSchemes");
	const { resources } = readStyleResources(record.css, "theme.css");
	const families = buildFontFamilyMap(resources, name, "theme.css");
	return freezePackage({
		id,
		name,
		version,
		protocol: LOCAL_THEME_PROTOCOL,
		colorSchemes,
		css: resources.map((resource) => Object.freeze({
			id: resource.id,
			css: scopeCss(resource.css, name, families)
		}))
	});
}
// src/sdk/preset.ts
/**
* Full preset reader. Semantic validation lives in `preset-core.ts`, which the
* compiler entry uses without loading theme CSS validation. This module adds
* the full SDK's theme validation and freezes the complete package.
*/
var validatedPresets = /* @__PURE__ */ new WeakSet();
function themeError(index, error) {
	const detail = error instanceof Error ? error.message : String(error);
	throw new Error(`Invalid local preset (themes[${index}]): ${detail}`);
}
/** Validate, clone and freeze one preset package, including its themes. */
function readLocalPresetPackage(value) {
	if (typeof value === "object" && value !== null && validatedPresets.has(value)) return value;
	const core = readLocalPresetPackage$1(value);
	if (core.themes === void 0) {
		validatedPresets.add(core);
		return core;
	}
	const themes = core.themes.map((theme, index) => {
		try {
			return defineLocalTheme(theme);
		} catch (error) {
			themeError(index, error);
		}
	});
	const preset = Object.freeze({
		...core,
		themes: Object.freeze(themes)
	});
	validatedPresets.add(preset);
	return preset;
}
// src/sdk/config.ts
/** Identifiers the default preset contributes in phase one. */
var DEFAULT_PRESET_ID = defaultPreset.id;
var DEFAULT_PRESET_VERSION = defaultPreset.version;
var DEFAULT_PRESET_IDENTITY = Object.freeze({
	id: DEFAULT_PRESET_ID,
	version: DEFAULT_PRESET_VERSION
});
var INPUT_KEYS = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"replacements",
	"themes"
]);
/**
* Configurations produced by this module are deeply frozen and already
* validated. Remembering them by identity keeps per-block compile keys cheap
* without ever trusting an arbitrary caller-supplied object.
*/
var trustedConfigs = /* @__PURE__ */ new WeakSet();
function readThemePackage(value) {
	if (!isPlainRecord(value)) fail("themes", "each theme must be an object.");
	checkKeys(value, /* @__PURE__ */ new Set([
		"id",
		"name",
		"version",
		"protocol",
		"colorSchemes",
		"css"
	]), "theme");
	try {
		return defineLocalTheme(value);
	} catch (error) {
		fail("theme", error instanceof Error ? error.message : String(error));
	}
}
function readInputThemes(value) {
	if (value === void 0) return Object.freeze([]);
	if (!Array.isArray(value)) fail("themes", "must be an array.");
	if (value.length > 16) fail("themes", `accepts at most 16 themes.`);
	const ids = /* @__PURE__ */ new Set();
	const names = /* @__PURE__ */ new Set();
	const themes = [];
	for (const entry of value) {
		const theme = readThemePackage(entry);
		if (ids.has(theme.id)) fail("themes", `theme id "${theme.id}" is declared more than once.`);
		if (names.has(theme.name)) fail("themes", `theme name "${theme.name}" is declared more than once.`);
		ids.add(theme.id);
		names.add(theme.name);
		themes.push(theme);
	}
	return Object.freeze(themes.sort((left, right) => left.id < right.id ? -1 : left.id > right.id ? 1 : 0));
}
function readPresetInput(value, index) {
	if (typeof value === "string") {
		if (value !== "default" && value !== defaultPreset.id) fail(`presets[${index}]`, `unsupported preset "${value}"; phase one accepts only the built-in default package.`);
		return defaultPreset;
	}
	if (!isPlainRecord(value)) fail(`presets[${index}]`, "must be a preset package, \"default\" or a preset reference.");
	if (value.protocol !== void 0 || value.components !== void 0) try {
		return readLocalPresetPackage(value);
	} catch (error) {
		fail(`presets[${index}]`, error instanceof Error ? error.message : String(error));
	}
	const id = value.id;
	const version = value.version;
	if (typeof id !== "string") fail(`presets[${index}].id`, "must be a string.");
	if (typeof version !== "string") fail(`presets[${index}].version`, "must be a string.");
	if ((id === "default" ? defaultPreset.id : id) !== defaultPreset.id) fail(`presets[${index}]`, `unsupported preset "${id}"; phase one accepts only "${defaultPreset.id}".`);
	if (version !== defaultPreset.version) fail(`presets[${index}].version`, `must be "${defaultPreset.version}".`);
	return defaultPreset;
}
function readPresetInputs(value) {
	if (value === void 0) return Object.freeze([defaultPreset]);
	if (!Array.isArray(value)) fail("presets", "must be an array.");
	const presets = [];
	const seen = /* @__PURE__ */ new Set();
	for (let index = 0; index < value.length; index += 1) {
		const preset = readPresetInput(value[index], index);
		if (seen.has(preset.id)) fail("presets", `preset "${preset.id}" is selected more than once.`);
		seen.add(preset.id);
		presets.push(preset);
	}
	return Object.freeze([...presets].sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
}
function readInputComponents(value) {
	if (value === void 0) return Object.freeze([]);
	if (!Array.isArray(value)) fail("components", "must be an array.");
	const components = value.map((entry, index) => {
		try {
			return readLocalComponentManifest(entry);
		} catch (error) {
			fail(`components[${index}]`, error instanceof Error ? error.message : String(error));
		}
	});
	return Object.freeze(components.sort((left, right) => {
		if (left.id !== right.id) return left.id < right.id ? -1 : 1;
		const leftReplacement = left.replaces === void 0 ? 0 : 1;
		const rightReplacement = right.replaces === void 0 ? 0 : 1;
		if (leftReplacement !== rightReplacement) return leftReplacement - rightReplacement;
		if (left.version !== right.version) return left.version < right.version ? -1 : 1;
		return left.name < right.name ? -1 : left.name > right.name ? 1 : 0;
	}));
}
function readReplacementPolicy(value) {
	if (value === void 0) return "allow";
	if (value !== "allow" && value !== "forbid") fail("replacements", "must be \"allow\" or \"forbid\".");
	return value;
}
function buildAssembly(input, path) {
	if (!isPlainRecord(input)) fail(path, "must be an object.");
	checkKeys(input, INPUT_KEYS, path);
	const assembly = Object.freeze({
		protocol: LOCAL_ASSEMBLY_PROTOCOL,
		presets: readPresetInputs(input.presets),
		components: readInputComponents(input.components),
		replacementPolicy: readReplacementPolicy(input.replacements),
		themes: readInputThemes(input.themes)
	});
	if (localJsonByteLength(assembly) > 16777216) fail(path, `serialized size exceeds the ${MAX_LOCAL_SDK_CONFIG_BYTES}-byte budget.`);
	return assembly;
}
function normalizeAssembly(assembly) {
	return Object.freeze({
		...assembly,
		presets: Object.freeze(assembly.presets.map((preset) => readLocalPresetPackage(preset))),
		themes: readInputThemes(assembly.themes)
	});
}
function buildConfigFromAssembly(assembly) {
	const normalized = normalizeAssembly(assembly);
	const config = localConfigFromAssembly(normalized, resolveLocalAssembly(normalized, { legacyProfiles: LOCAL_COMPAT_PROFILES }));
	trustedConfigs.add(config);
	return config;
}
/** Create an immutable, validated instance configuration. */
function createLocalConfig(input = {}) {
	return buildConfigFromAssembly(buildAssembly(input, "config"));
}
/**
* Build the semantic preset for a profile hit. The current built-in package is
* reused only when the profile identity is the current default; otherwise the
* profile identity names the same verified default semantics.
*/
function presetForCompatProfile(profile) {
	if (profile.preset.id === defaultPreset.id && profile.preset.version === defaultPreset.version) return defaultPreset;
	return readLocalPresetPackage({
		...defaultPreset,
		id: profile.preset.id,
		version: profile.preset.version
	});
}
/**
* Read a v1 configuration through a compatibility profile. v1 never carried
* replacements or custom presets; both become migration errors instead of
* being silently accepted.
*/
function readLegacyConfig(value, profiles) {
	const selected = readPresetReferences(value.presets, DEFAULT_PRESET_IDENTITY, profiles)[0] ?? DEFAULT_PRESET_IDENTITY;
	const profile = findLocalCompatProfile(selected, profiles);
	if (profile === void 0) fail("presets", `local.config.migration-unsupported: no compatibility profile matches preset "${selected.id}" ${selected.version}.`);
	const legacyRule = profile.legacyKeys[0];
	if (legacyRule === void 0) fail("presets", `local.config.migration-unsupported: profile "${profile.name}" has no legacy key mapping.`);
	validateCompatProfileComponents(profile, defaultPreset.components);
	const preset = presetForCompatProfile(profile);
	const components = readComponents(value.components, defaultPreset.components);
	if (components.some((component) => component.replaces !== void 0)) fail("config", "replaces is not supported by reactive-md-config/v1.");
	const themes = readInputThemes(value.themes);
	const assembly = Object.freeze({
		protocol: LOCAL_ASSEMBLY_PROTOCOL,
		presets: Object.freeze([preset]),
		components,
		replacementPolicy: "forbid",
		themes
	});
	const resolved = resolveLocalAssembly(assembly, { legacyProfiles: profiles });
	const legacyKey = localLegacyV1Key(profile.preset, resolved.components);
	const config = localConfigFromAssembly(assembly, resolved, [...resolved.legacyKeys, ...resolved.legacyKeys.some((entry) => entry.key === legacyKey) ? [] : [Object.freeze({
		profile: legacyRule.profile,
		key: legacyKey
	})]]);
	trustedConfigs.add(config);
	return config;
}
/**
* Revalidate arbitrary configuration data, including a Worker snapshot or a
* hand-built payload. Supplied derived fields are ignored and rebuilt from the
* assembly snapshot.
*
* `additionalProfiles` extends the SDK-built-in compatibility table with
* explicit data. It never infers a legacy identity from the current SDK
* version.
*/
function readLocalConfig(value, additionalProfiles = []) {
	if (typeof value === "object" && value !== null && trustedConfigs.has(value)) return value;
	if (!isPlainRecord(value)) fail("config", "must be an object.");
	checkKeys(value, CONFIG_KEYS, "config");
	if (value.protocol === "reactive-md-config/v1") return readLegacyConfig(value, localCompatProfiles(additionalProfiles));
	if (value.protocol !== "reactive-md-config/v2") fail("config.protocol", `must be "${LOCAL_CONFIG_PROTOCOL_V2}" (or legacy "${LOCAL_CONFIG_PROTOCOL}").`);
	return buildConfigFromAssembly(readLocalAssemblySnapshot(value.assembly));
}
// src/export/restoration.ts
function localThemeContractDigest(theme) {
	return localHash(JSON.stringify([
		theme.id,
		theme.name,
		theme.version,
		theme.protocol,
		theme.colorSchemes,
		theme.css.map(({ id, css }) => [id, css])
	]));
}
function createLocalBundleManifest(script, config) {
	const installed = readLocalConfig(config);
	const assembly = localAssemblyIdentity(installed);
	return Object.freeze({
		protocol: "reactive-md-bundle/v1",
		sdkVersion: LOCAL_SDK_VERSION,
		configKey: installed.key,
		scriptDigest: localHash(script),
		assembly,
		seal: localAssemblySeal(installed),
		themes: Object.freeze(installed.themes.map((theme) => Object.freeze({
			id: theme.id,
			name: theme.name,
			version: theme.version,
			digest: localThemeContractDigest(theme)
		})))
	});
}
// src/export/index.ts
/** Bind an explicitly built standalone script to the installed manifest set. */
function defineLocalStandaloneBundle(script, config) {
	const installed = readLocalConfig(config);
	if (typeof script !== "string" || !script.trim() || script.length > 33554432) throw new TypeError("A standalone bundle must contain a nonempty script of at most 32 MiB.");
	return Object.freeze({
		script,
		seal: createLocalBundleManifest(script, installed),
		extensions: Object.freeze({
			protocol: "reactive-md-extensions/v1",
			components: Object.freeze(installed.registry.map((definition) => Object.freeze({
				id: definition.id,
				name: definition.name,
				version: definition.version,
				digest: localComponentDigest(definition)
			})))
		})
	});
}
// src/build/diagnostics.ts
/** Build-side diagnostics use the same shape as compile and export diagnostics. */
function buildDiagnostic(code, message) {
	return {
		code,
		message,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function summary(diagnostics) {
	return diagnostics.slice(0, 12).map((item) => `[${item.code}] ${item.message.length > 400 ? `${item.message.slice(0, 400)}…` : item.message}`).join("\n");
}
/** Thrown by the Node build adapter; carries every preflight/build diagnostic. */
var LocalBuildError = class extends Error {
	diagnostics;
	constructor(message, diagnostics = []) {
		super(diagnostics.length === 0 ? message : `${message}\n${summary(diagnostics)}`);
		this.name = "LocalBuildError";
		this.diagnostics = Object.freeze(diagnostics.slice());
	}
};
// src/build/digest.ts
/** Byte length of one UTF-8 string; build budgets are byte based. */
function utf8ByteLength(text) {
	return new TextEncoder().encode(text).byteLength;
}
/** Stable content digest for build artifacts. */
function sha256(text) {
	return `sha256:${createHash("sha256").update(text, "utf8").digest("hex")}`;
}
function sha256Bytes(bytes) {
	return `sha256:${createHash("sha256").update(bytes).digest("hex")}`;
}
// src/build/resources.ts
var STYLE_ID = /^[A-Za-z0-9][A-Za-z0-9._/-]*$/;
var MAX_STYLE_ID_LENGTH = 256;
var REMOTE_SCHEME = /^[A-Za-z][A-Za-z0-9+.-]*:/;
var DATA_URL = /^data:/i;
var DEFAULT_LOCAL_BUILD_BUDGETS = Object.freeze({
	maxResources: 128,
	maxCssBytes: 4194304,
	maxFileBytes: 8388608,
	maxInlinedBytes: 25165824,
	maxFiles: 256,
	maxImportDepth: 16
});
var ABSOLUTE_BUDGETS = Object.freeze({
	maxResources: 512,
	maxCssBytes: 33554432,
	maxFileBytes: 33554432,
	maxInlinedBytes: 67108864,
	maxFiles: 1024,
	maxImportDepth: 32
});
var MIME_BY_EXTENSION = {
	".avif": "image/avif",
	".css": "text/css",
	".eot": "application/vnd.ms-fontobject",
	".gif": "image/gif",
	".ico": "image/x-icon",
	".jpeg": "image/jpeg",
	".jpg": "image/jpeg",
	".otf": "font/otf",
	".png": "image/png",
	".svg": "image/svg+xml",
	".ttf": "font/ttf",
	".webp": "image/webp",
	".woff": "font/woff",
	".woff2": "font/woff2"
};
function mimeFor(file) {
	const dot = file.lastIndexOf(".");
	if (dot < 0) return "application/octet-stream";
	return MIME_BY_EXTENSION[file.slice(dot).toLowerCase()] ?? "application/octet-stream";
}
function isInside$1(parent, child) {
	const path = relative(parent, child);
	return path === "" || !path.startsWith(`..${sep}`) && path !== ".." && !isAbsolute(path);
}
function posixRelative(root, file) {
	return relative(root, file).split(sep).join("/");
}
function isPositiveInteger(value) {
	return typeof value === "number" && Number.isSafeInteger(value) && value > 0;
}
/** Read host-supplied budget overrides; invalid entries fall back individually. */
function readLocalBuildBudgets(value, diagnostics) {
	if (value === void 0) return DEFAULT_LOCAL_BUILD_BUDGETS;
	if (!value || typeof value !== "object" || Array.isArray(value)) {
		diagnostics.push(buildDiagnostic("local.build.budget", "budgets must be an object."));
		return DEFAULT_LOCAL_BUILD_BUDGETS;
	}
	const record = value;
	const read = (key, allowZero = false) => {
		if (record[key] === void 0) return DEFAULT_LOCAL_BUILD_BUDGETS[key];
		const candidate = record[key];
		if (!(allowZero ? typeof candidate === "number" && Number.isSafeInteger(candidate) && candidate >= 0 : isPositiveInteger(candidate)) || candidate > ABSOLUTE_BUDGETS[key]) {
			diagnostics.push(buildDiagnostic("local.build.budget", `budgets.${key} must be ${allowZero ? "a nonnegative" : "a positive"} integer at most ${ABSOLUTE_BUDGETS[key]}.`));
			return DEFAULT_LOCAL_BUILD_BUDGETS[key];
		}
		return candidate;
	};
	return Object.freeze({
		maxResources: read("maxResources"),
		maxCssBytes: read("maxCssBytes"),
		maxFileBytes: read("maxFileBytes"),
		maxInlinedBytes: read("maxInlinedBytes", true),
		maxFiles: read("maxFiles"),
		maxImportDepth: read("maxImportDepth", true)
	});
}
/** Validate explicit { id, css | path } resource declarations. */
function readLocalStyleResourceInputs(value, path, diagnostics) {
	if (value === void 0) return [];
	if (!Array.isArray(value)) {
		diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${path} must be an array of { id, css | path } resources.`));
		return [];
	}
	const byId = /* @__PURE__ */ new Map();
	for (let index = 0; index < value.length; index += 1) {
		const entry = value[index];
		const lead = `${path}[${index}]`;
		if (!entry || typeof entry !== "object" || Array.isArray(entry)) {
			diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${lead} must be an object.`));
			continue;
		}
		const record = entry;
		const id = record.id;
		if (typeof id !== "string" || id.length === 0 || id.length > MAX_STYLE_ID_LENGTH || !STYLE_ID.test(id)) {
			diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${lead}.id must be a bounded style-resource id.`));
			continue;
		}
		const hasCss = record.css !== void 0;
		const hasPath = record.path !== void 0;
		if (hasCss === hasPath) {
			diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${lead} must declare exactly one of "css" or "path".`));
			continue;
		}
		if (hasCss && typeof record.css !== "string") {
			diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${lead}.css must be a string.`));
			continue;
		}
		if (hasPath && (typeof record.path !== "string" || record.path.length === 0)) {
			diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${lead}.path must be a non-empty string.`));
			continue;
		}
		if (record.base !== void 0 && (typeof record.base !== "string" || record.base.length === 0)) {
			diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${lead}.base must be a non-empty root-relative directory.`));
			continue;
		}
		const resource = Object.freeze({
			id,
			...hasCss ? { css: record.css } : { path: record.path },
			...record.base === void 0 ? {} : { base: record.base }
		});
		const previous = byId.get(id);
		if (previous) {
			if (canonicalResourceInput(previous) !== canonicalResourceInput(resource)) diagnostics.push(buildDiagnostic("local.build.resource-conflict", `Resource "${id}" is declared more than once with different contents.`));
			continue;
		}
		byId.set(id, resource);
	}
	return [...byId.values()];
}
function canonicalResourceInput(input) {
	return JSON.stringify({
		id: input.id,
		css: input.css,
		path: input.path,
		base: input.base
	});
}
function reportFileBudget(ctx) {
	if (ctx.fileBudgetReported) return;
	ctx.fileBudgetReported = true;
	ctx.diagnostics.push(buildDiagnostic("local.build.resource-budget", `Resource collection exceeds ${ctx.budgets.maxFiles} files or a ${ctx.budgets.maxFileBytes}-byte file.`));
}
function reportInlineBudget(ctx) {
	if (ctx.inlinedBudgetReported) return;
	ctx.inlinedBudgetReported = true;
	ctx.diagnostics.push(buildDiagnostic("local.build.resource-budget", `Inlined resources exceed the ${ctx.budgets.maxInlinedBytes}-byte budget.`));
}
function recordAsset(ctx, file, bytes, mime) {
	const path = posixRelative(ctx.root, file);
	if (ctx.assets.has(path)) return;
	ctx.assets.set(path, Object.freeze({
		path,
		digest: sha256Bytes(bytes),
		bytes: bytes.byteLength,
		mime
	}));
}
async function resolveAllowed(candidate, ctx, label) {
	if (!isInside$1(ctx.root, candidate)) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-traversal", `${label} resolves outside the declared root.`));
		return null;
	}
	let real;
	try {
		real = await realpath(candidate);
	} catch {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-missing", `${label} does not exist.`));
		return null;
	}
	if (!isInside$1(ctx.root, real)) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-traversal", `${label} resolves outside the declared root through a symbolic link.`));
		return null;
	}
	if (!ctx.allowlist.some((directory) => isInside$1(directory, real))) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-traversal", `${label} is not inside the declared allowlist.`));
		return null;
	}
	let info;
	try {
		info = await stat(real);
	} catch {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-missing", `${label} is not readable.`));
		return null;
	}
	if (!info || !info.isFile()) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${label} is not a regular file.`));
		return null;
	}
	if (ctx.files >= ctx.budgets.maxFiles || info.size > ctx.budgets.maxFileBytes) {
		reportFileBudget(ctx);
		return null;
	}
	ctx.files += 1;
	return real;
}
async function resolveAllowedDirectory(candidate, ctx, label) {
	if (!isInside$1(ctx.root, candidate)) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-traversal", `${label} resolves outside the declared root.`));
		return null;
	}
	let real;
	try {
		real = await realpath(candidate);
	} catch {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-missing", `${label} does not exist.`));
		return null;
	}
	if (!isInside$1(ctx.root, real) || !ctx.allowlist.some((directory) => isInside$1(directory, real))) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-traversal", `${label} is not inside the declared root and allowlist.`));
		return null;
	}
	let info;
	try {
		info = await stat(real);
	} catch {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-missing", `${label} is not readable.`));
		return null;
	}
	if (!info || !info.isDirectory()) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${label} is not a directory.`));
		return null;
	}
	return real;
}
function findStringEnd(css, start) {
	const quote = css[start];
	let index = start + 1;
	while (index < css.length) {
		if (css[index] === "\\") {
			index += 2;
			continue;
		}
		if (css[index] === quote) return index + 1;
		index += 1;
	}
	return -1;
}
function findBalancedEnd(css, start) {
	let depth = 0;
	for (let index = start; index < css.length; index += 1) {
		const character = css[index];
		if (character === "\"" || character === "'") {
			const end = findStringEnd(css, index);
			if (end < 0) return -1;
			index = end - 1;
			continue;
		}
		if (character === "/" && css[index + 1] === "*") {
			const close = css.indexOf("*/", index + 2);
			if (close < 0) return -1;
			index = close + 1;
			continue;
		}
		if (character === "(") depth += 1;
		else if (character === ")") {
			depth -= 1;
			if (depth === 0) return index + 1;
		}
	}
	return -1;
}
function readCssUrl(css, start) {
	let cursor = start + 3;
	while (cursor < css.length && /\s/.test(css[cursor])) cursor += 1;
	if (css[cursor] !== "(") return null;
	cursor += 1;
	while (cursor < css.length && /\s/.test(css[cursor])) cursor += 1;
	const valueStart = cursor;
	let value;
	if (css[cursor] === "\"" || css[cursor] === "'") {
		const end = findStringEnd(css, cursor);
		if (end < 0) return null;
		value = css.slice(cursor + 1, end - 1);
		cursor = end;
		while (cursor < css.length && /\s/.test(css[cursor])) cursor += 1;
		if (css[cursor] !== ")") return null;
		cursor += 1;
	} else {
		const close = css.indexOf(")", cursor);
		if (close < 0) return null;
		value = css.slice(cursor, close);
		cursor = close + 1;
	}
	return {
		value: value.trim(),
		end: cursor,
		start: valueStart
	};
}
function readCssImport(css, start) {
	const match = /^@import\b/i.exec(css.slice(start, start + 8));
	if (!match) return null;
	let cursor = start + match[0].length;
	while (cursor < css.length && /\s/.test(css[cursor])) cursor += 1;
	let specifier;
	if (css[cursor] === "\"" || css[cursor] === "'") {
		const end = findStringEnd(css, cursor);
		if (end < 0) return null;
		specifier = css.slice(cursor + 1, end - 1).trim();
		cursor = end;
	} else if (/^url\s*\(/i.test(css.slice(cursor, cursor + 16))) {
		const url = readCssUrl(css, cursor);
		if (!url) return null;
		specifier = url.value;
		cursor = url.end;
	} else return null;
	let conditional = false;
	while (cursor < css.length) {
		const character = css[cursor];
		if (character === "\"" || character === "'") {
			const end = findStringEnd(css, cursor);
			if (end < 0) return null;
			cursor = end;
			continue;
		}
		if (character === "/" && css[cursor + 1] === "*") {
			const close = css.indexOf("*/", cursor + 2);
			if (close < 0) return null;
			cursor = close + 2;
			continue;
		}
		if (character === "(") {
			const close = findBalancedEnd(css, cursor);
			if (close < 0) return null;
			cursor = close;
			continue;
		}
		if (character === ";") return {
			specifier,
			end: cursor + 1,
			conditional
		};
		if (!/\s/.test(character)) conditional = true;
		cursor += 1;
	}
	return null;
}
function validateImageSet(body, diagnostics, label) {
	let index = 0;
	while (index < body.length) {
		const character = body[index];
		if (character === "/" && body[index + 1] === "*") {
			const close = body.indexOf("*/", index + 2);
			index = close < 0 ? body.length : close + 2;
			continue;
		}
		if ((character === "t" || character === "T") && /^type\s*\(/i.test(body.slice(index, index + 8))) {
			let open = index;
			while (open < body.length && body[open] !== "(") open += 1;
			const close = open < body.length ? findBalancedEnd(body, open) : -1;
			index = close < 0 ? body.length : close;
			continue;
		}
		if (character === "\"" || character === "'") {
			const end = findStringEnd(body, index);
			if (end < 0) {
				diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${label} has an unterminated image-set() string.`));
				return;
			}
			const value = body.slice(index + 1, end - 1).trim();
			if (!DATA_URL.test(value)) diagnostics.push(buildDiagnostic("local.build.resource-remote", `${label} has a non-inline image-set() entry; URL resolution is only supported through url().`));
			index = end;
			continue;
		}
		index += 1;
	}
}
async function loadCssFile(file, ctx, stack) {
	if (stack.length > ctx.budgets.maxImportDepth) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-budget", `CSS imports exceed the ${ctx.budgets.maxImportDepth}-level depth budget.`));
		return null;
	}
	let text;
	try {
		text = await readFile(file, "utf8");
	} catch {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-missing", `CSS resource "${posixRelative(ctx.root, file)}" is not readable.`));
		return null;
	}
	recordAsset(ctx, file, new TextEncoder().encode(text), "text/css");
	return resolveCss(text, dirname(file), [...stack, file], ctx);
}
async function readBinaryAsset(file, ctx, label) {
	let bytes;
	try {
		bytes = await readFile(file);
	} catch {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-missing", `${label} is not readable.`));
		return null;
	}
	if (ctx.inlinedBytes + bytes.byteLength > ctx.budgets.maxInlinedBytes) {
		reportInlineBudget(ctx);
		return null;
	}
	ctx.inlinedBytes += bytes.byteLength;
	const mime = mimeFor(file);
	recordAsset(ctx, file, bytes, mime);
	return `data:${mime};base64,${Buffer.from(bytes).toString("base64")}`;
}
async function resolveUrl(value, baseDir, ctx, label) {
	if (value === "") {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${label} has an empty url().`));
		return null;
	}
	if (DATA_URL.test(value) || value.startsWith("#")) return value;
	if (value.startsWith("//")) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-remote", `${label} references the protocol-relative remote resource "${value}".`));
		return null;
	}
	if (value.startsWith("/") || /^[A-Za-z]:[\\/]/.test(value)) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-traversal", `${label} references the absolute path "${value}".`));
		return null;
	}
	if (REMOTE_SCHEME.test(value)) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-remote", `${label} references the remote resource "${value.length > 160 ? `${value.slice(0, 160)}…` : value}".`));
		return null;
	}
	if (value.includes("\\")) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", `${label} uses an unsupported escaped url().`));
		return null;
	}
	if (baseDir === null) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-unresolved", `${label} has a relative url() without a base directory.`));
		return null;
	}
	const file = await resolveAllowed(resolve(baseDir, value), ctx, `${label} url("${value}")`);
	if (!file) return null;
	return readBinaryAsset(file, ctx, `${label} url("${value}")`);
}
/**
* Inline local `@import` and `url()` targets in one stylesheet. Remote,
* missing, traversal, cyclic and over-budget targets become diagnostics.
*/
async function resolveCss(css, baseDir, stack, ctx) {
	if (css.toLowerCase().includes("</style")) {
		ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", "CSS must not contain a closing style tag."));
		return css;
	}
	let output = "";
	let index = 0;
	let depth = 0;
	while (index < css.length) {
		const character = css[index];
		if (character === "/" && css[index + 1] === "*") {
			const close = css.indexOf("*/", index + 2);
			const end = close < 0 ? css.length : close + 2;
			output += css.slice(index, end);
			index = end;
			continue;
		}
		if (character === "\"" || character === "'") {
			const end = findStringEnd(css, index);
			if (end < 0) {
				ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", "CSS has an unterminated string."));
				output += css.slice(index);
				break;
			}
			output += css.slice(index, end);
			index = end;
			continue;
		}
		if (character === "\\") {
			ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", "CSS must not use escapes outside strings; escaped tokens can disguise url() or @import."));
			output += css.slice(index, index + 2);
			index += 2;
			continue;
		}
		if (character === "{") {
			depth += 1;
			output += character;
			index += 1;
			continue;
		}
		if (character === "}") {
			depth = Math.max(0, depth - 1);
			output += character;
			index += 1;
			continue;
		}
		const boundary = index === 0 || !/[\w-]/.test(css[index - 1]);
		if (boundary && depth === 0 && character === "@" && /^@import\b/i.test(css.slice(index, index + 8))) {
			const parsed = readCssImport(css, index);
			if (!parsed) {
				ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", "CSS has a malformed @import."));
				output += "/* rejected @import */";
				index += 7;
				continue;
			}
			if (parsed.conditional) ctx.diagnostics.push(buildDiagnostic("local.build.resource-unsupported", "@import with layer, support or media conditions is not supported; inline the stylesheet instead."));
			const specifier = parsed.specifier;
			if (DATA_URL.test(specifier)) ctx.diagnostics.push(buildDiagnostic("local.build.resource-unsupported", "@import must name a local CSS file, not a data: URL."));
			else if (specifier.startsWith("//")) ctx.diagnostics.push(buildDiagnostic("local.build.resource-remote", `@import references the remote URL "${specifier}".`));
			else if (specifier.startsWith("/") || /^[A-Za-z]:[\\/]/.test(specifier)) ctx.diagnostics.push(buildDiagnostic("local.build.resource-traversal", `@import references the absolute path "${specifier}".`));
			else if (REMOTE_SCHEME.test(specifier)) ctx.diagnostics.push(buildDiagnostic("local.build.resource-remote", `@import references the remote URL "${specifier}".`));
			else if (baseDir === null) ctx.diagnostics.push(buildDiagnostic("local.build.resource-unresolved", `@import "${specifier}" has no base directory.`));
			else {
				const file = await resolveAllowed(resolve(baseDir, specifier), ctx, `@import "${specifier}"`);
				if (file && stack.includes(file)) ctx.diagnostics.push(buildDiagnostic("local.build.resource-cycle", `@import cycle through "${specifier}".`));
				else if (file) {
					const inlined = await loadCssFile(file, ctx, stack);
					if (inlined !== null) output += `\n${inlined}\n`;
				}
			}
			index = parsed.end;
			continue;
		}
		if (boundary && (character === "u" || character === "U") && /^url\s*\(/i.test(css.slice(index, index + 12))) {
			const url = readCssUrl(css, index);
			if (!url) {
				ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", "CSS has a malformed url()."));
				output += "url(\"\")";
				const close = css.indexOf(")", index);
				index = close < 0 ? css.length : close + 1;
				continue;
			}
			const resolved = DATA_URL.test(url.value) || url.value.startsWith("#") ? css.slice(index, url.end) : await resolveUrl(url.value, baseDir, ctx, "CSS");
			output += resolved === null ? "url(\"\")" : DATA_URL.test(url.value) || url.value.startsWith("#") ? resolved : `url("${resolved}")`;
			index = url.end;
			continue;
		}
		if (boundary && (character === "i" || character === "I" || character === "-")) {
			const match = /^(?:-webkit-)?image-set\s*\(/i.exec(css.slice(index, index + 32));
			if (match) {
				const open = index + match[0].length - 1;
				const end = findBalancedEnd(css, open);
				if (end < 0) {
					ctx.diagnostics.push(buildDiagnostic("local.build.resource-invalid", "CSS has an unterminated image-set()."));
					output += css.slice(index);
					break;
				}
				const resolvedBody = await resolveCss(css.slice(open + 1, end - 1), baseDir, stack, ctx);
				validateImageSet(resolvedBody, ctx.diagnostics, "CSS");
				output += `${match[0]}${resolvedBody})`;
				index = end;
				continue;
			}
		}
		output += character;
		index += 1;
	}
	return output;
}
async function resolveDeclared(input, ctx) {
	if (input.path !== void 0) {
		const file = await resolveAllowed(resolve(ctx.root, input.path), ctx, `resource "${input.id}"`);
		if (!file) return null;
		return loadCssFile(file, ctx, []);
	}
	let baseDir = null;
	if (input.base !== void 0) {
		baseDir = await resolveAllowedDirectory(resolve(ctx.root, input.base), ctx, `resource "${input.id}" base`);
		if (!baseDir) return null;
	}
	return resolveCss(input.css ?? "", baseDir, [], ctx);
}
function selectedThemes(config, names, diagnostics) {
	if (names === void 0) return config.themes;
	const byName = new Map(config.themes.map((theme) => [theme.name, theme]));
	const seen = /* @__PURE__ */ new Set();
	const selected = [];
	for (const name of names) {
		if (seen.has(name)) {
			diagnostics.push(buildDiagnostic("local.build.theme", `Theme "${name}" is selected more than once.`));
			continue;
		}
		seen.add(name);
		if (name === "default") continue;
		const theme = byName.get(name);
		if (!theme) {
			diagnostics.push(buildDiagnostic("local.extension.theme-missing", `Theme ${name} is not installed for this build.`));
			continue;
		}
		selected.push(theme);
	}
	return selected;
}
function themeResources(theme) {
	return theme.css;
}
/**
* Collect explicit component CSS, extra host resources and selected theme CSS.
* Order is deterministic: component style ids, extra declarations, themes.
*/
async function collectLocalBuildResources(input) {
	const diagnostics = [];
	const ctx = {
		root: input.root,
		allowlist: input.allowlist,
		budgets: input.budgets,
		diagnostics,
		assets: /* @__PURE__ */ new Map(),
		files: 0,
		inlinedBytes: 0,
		fileBudgetReported: false,
		inlinedBudgetReported: false,
		resourceBudgetReported: false,
		cssBudgetReported: false
	};
	const declared = new Map(input.declared.map((resource) => [resource.id, resource]));
	const order = [];
	const origins = /* @__PURE__ */ new Map();
	const required = [];
	const push = (id, origin) => {
		if (origins.has(id)) return;
		origins.set(id, origin);
		order.push(id);
	};
	for (const component of input.config.registry) for (const style of component.styles ?? []) {
		required.push(style);
		push(style, "component");
	}
	for (const resource of input.declared) push(resource.id, "resource");
	const themes = selectedThemes(input.config, input.themes, diagnostics);
	const byThemeId = /* @__PURE__ */ new Map();
	for (const theme of themes) for (const resource of themeResources(theme)) {
		push(resource.id, "theme");
		const existing = byThemeId.get(resource.id);
		if (existing) {
			if (existing.css !== resource.css) diagnostics.push(buildDiagnostic("local.build.resource-conflict", `Theme resource "${resource.id}" is declared by more than one theme with different contents.`));
			continue;
		}
		byThemeId.set(resource.id, resource);
	}
	if (order.length > input.budgets.maxResources) {
		ctx.resourceBudgetReported = true;
		diagnostics.push(buildDiagnostic("local.build.resource-budget", `Resource collection exceeds the ${input.budgets.maxResources}-resource budget.`));
	}
	const limited = order.slice(0, input.budgets.maxResources);
	const resources = [];
	let cssBytes = 0;
	for (const id of limited) {
		let css = null;
		const declaration = declared.get(id);
		if (declaration) css = await resolveDeclared(declaration, ctx);
		else {
			const themeResource = byThemeId.get(id);
			if (themeResource) css = await resolveCss(themeResource.css, null, [], ctx);
		}
		if (css === null) continue;
		const bytes = utf8ByteLength(css);
		cssBytes += bytes;
		if (cssBytes > input.budgets.maxCssBytes && !ctx.cssBudgetReported) {
			ctx.cssBudgetReported = true;
			diagnostics.push(buildDiagnostic("local.build.resource-budget", `Collected CSS exceeds the ${input.budgets.maxCssBytes}-byte budget.`));
		}
		resources.push(Object.freeze({
			id,
			css,
			digest: sha256(css),
			bytes,
			origin: origins.get(id) ?? "resource"
		}));
		if (declaration && byThemeId.has(id)) {
			if (sha256(byThemeId.get(id).css) !== sha256(css)) diagnostics.push(buildDiagnostic("local.build.resource-conflict", `Resource "${id}" is declared by both the host and a theme with different contents.`));
		}
	}
	const present = new Set(resources.map((resource) => resource.id));
	for (const id of required) if (!present.has(id)) diagnostics.push(buildDiagnostic("local.extension.resource-missing", `Required component style resource ${id} is missing from the build.`));
	const assets = [...ctx.assets.values()].sort((left, right) => left.path < right.path ? -1 : left.path > right.path ? 1 : 0);
	return Object.freeze({
		resources: Object.freeze(resources),
		assets: Object.freeze(assets),
		css: resources.map((resource) => resource.css).join("\n"),
		diagnostics: Object.freeze(diagnostics)
	});
}
// src/build/host.ts
function isRecord$1(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function isInside(parent, child) {
	const path = relative(parent, child);
	return path === "" || !path.startsWith(`..${sep}`) && path !== ".." && !isAbsolute(path);
}
function messageOf$1(error) {
	return error instanceof Error ? error.message : String(error);
}
function fileUrlToPath(value, label, diagnostics) {
	if (value.protocol !== "file:") {
		diagnostics.push(buildDiagnostic("local.build.host", `${label} must be a file: URL or a path.`));
		return null;
	}
	const clean = new URL(value.href);
	clean.search = "";
	clean.hash = "";
	try {
		return fileURLToPath(clean);
	} catch {
		diagnostics.push(buildDiagnostic("local.build.host", `${label} is not a valid file: URL.`));
		return null;
	}
}
function pathFromValue(value, base, label, diagnostics) {
	if (value instanceof URL) return fileUrlToPath(value, label, diagnostics);
	if (typeof value === "string" && value.trim().length > 0) {
		if (value.startsWith("file:")) try {
			return fileUrlToPath(new URL(value), label, diagnostics);
		} catch {
			diagnostics.push(buildDiagnostic("local.build.host", `${label} is not a valid file: URL.`));
			return null;
		}
		return resolve(base, value);
	}
	diagnostics.push(buildDiagnostic("local.build.host", `${label} must be a file: URL or a path.`));
	return null;
}
function pick(source, key) {
	return Object.hasOwn(source, key) ? source[key] : void 0;
}
function readImplementation(definition, components, diagnostics) {
	const implementation = components.find((entry) => {
		if (!isRecord$1(entry) || !isRecord$1(entry.definition)) return false;
		return entry.definition.id === definition.id;
	});
	if (!implementation || !isRecord$1(implementation) || !isRecord$1(implementation.definition)) {
		diagnostics.push(buildDiagnostic("local.build.config", `reactConfig is missing an implementation for ${definition.id}@${definition.version}.`));
		return;
	}
	const manifest = implementation.definition;
	if (manifest.name !== definition.name || manifest.version !== definition.version) {
		diagnostics.push(buildDiagnostic("local.build.config", `reactConfig implementation ${definition.id} does not match the declared name or version.`));
		return;
	}
	let digest;
	try {
		digest = localComponentDigest(manifest);
	} catch (error) {
		diagnostics.push(buildDiagnostic("local.build.config", `reactConfig implementation ${definition.id} has an invalid manifest: ${messageOf$1(error)}`));
		return;
	}
	if (digest !== localComponentDigest(definition)) {
		diagnostics.push(buildDiagnostic("local.build.config", `reactConfig implementation ${definition.id} does not match the declared manifest contract.`));
		return;
	}
	if (implementation.digest !== void 0 && implementation.digest !== digest) diagnostics.push(buildDiagnostic("local.build.config", `reactConfig implementation ${definition.id} has a stale digest.`));
}
function mergeDeclared(lists, diagnostics) {
	const byId = /* @__PURE__ */ new Map();
	for (const list of lists) for (const input of list) {
		const canonical = JSON.stringify({
			id: input.id,
			css: input.css,
			path: input.path,
			base: input.base
		});
		const previous = byId.get(input.id);
		if (previous) {
			if (JSON.stringify({
				id: previous.id,
				css: previous.css,
				path: previous.path,
				base: previous.base
			}) !== canonical) diagnostics.push(buildDiagnostic("local.build.resource-conflict", `Resource "${input.id}" is declared by the host and the build options with different contents.`));
			continue;
		}
		byId.set(input.id, input);
	}
	return [...byId.values()];
}
/**
* Load the explicit host module, validate its LocalConfig and prepared React
* config, and resolve its resource root/allowlist before collection.
*
* The entry must be Node-loadable JavaScript (`.mjs`, or `.js` in a module
* package). The same file is the Vite build entry, so implementations are
* imported explicitly and never reconstructed from `function.toString()`.
*/
async function readLocalBuildHost(options) {
	const diagnostics = [];
	const entryPath = pathFromValue(options.entry, process.cwd(), "entry", diagnostics);
	if (!entryPath) return { diagnostics: Object.freeze(diagnostics) };
	let module;
	try {
		const stamp = await stat(entryPath).then((info) => Math.trunc(info.mtimeMs)).catch(() => 0);
		module = await import(`${pathToFileURL(entryPath).href}?rmd=${stamp}`);
	} catch (error) {
		diagnostics.push(buildDiagnostic("local.build.host-import", `The host entry could not be imported by Node: ${messageOf$1(error)}`));
		return { diagnostics: Object.freeze(diagnostics) };
	}
	const rawConfig = pick(module, "config");
	const rawReactConfig = pick(module, "reactConfig");
	const rawRoot = pick(module, "root");
	const rawAllowlist = pick(module, "allowlist");
	let config = null;
	if (rawConfig === void 0) diagnostics.push(buildDiagnostic("local.build.host", "The host entry must export \"config\"."));
	else try {
		config = readLocalConfig(rawConfig);
		if (isRecord$1(rawConfig) && typeof rawConfig.key === "string" && rawConfig.key !== config.key) diagnostics.push(buildDiagnostic("local.build.config-key", "The host config.key is stale; use the key computed by createLocalConfig or readLocalConfig."));
	} catch (error) {
		diagnostics.push(buildDiagnostic("local.build.config", `The host config is invalid: ${messageOf$1(error)}`));
	}
	let reactConfig = null;
	if (rawReactConfig === void 0) diagnostics.push(buildDiagnostic("local.build.host", "The host entry must export a prepared \"reactConfig\"."));
	else if (!isRecord$1(rawReactConfig) || rawReactConfig.config === void 0) diagnostics.push(buildDiagnostic("local.build.host", "reactConfig must expose its LocalConfig as reactConfig.config."));
	else {
		let reactConfigConfig = null;
		try {
			reactConfigConfig = readLocalConfig(rawReactConfig.config);
		} catch (error) {
			diagnostics.push(buildDiagnostic("local.build.config", `reactConfig.config is invalid: ${messageOf$1(error)}`));
		}
		if (reactConfigConfig && config && reactConfigConfig.key !== config.key) diagnostics.push(buildDiagnostic("local.build.config", "reactConfig.config.key does not match the exported LocalConfig key."));
		if (reactConfigConfig && config && JSON.stringify(reactConfigConfig.themes) !== JSON.stringify(config.themes)) diagnostics.push(buildDiagnostic("local.build.config", "reactConfig.config themes do not match the exported LocalConfig themes."));
		const components = rawReactConfig.components;
		if (!Array.isArray(components)) diagnostics.push(buildDiagnostic("local.build.host", "reactConfig.components must be an array."));
		else if (config) for (const definition of config.components) readImplementation(definition, components, diagnostics);
		reactConfig = rawReactConfig;
	}
	const entryBase = dirname(entryPath);
	let root = null;
	if (rawRoot === void 0) diagnostics.push(buildDiagnostic("local.build.host", "The host entry must export an explicit \"root\"."));
	else {
		const candidate = pathFromValue(rawRoot, entryBase, "root", diagnostics);
		if (candidate) try {
			root = await realpath(candidate);
			if (!(await stat(root)).isDirectory()) {
				diagnostics.push(buildDiagnostic("local.build.host", "root must be a directory."));
				root = null;
			}
		} catch (error) {
			diagnostics.push(buildDiagnostic("local.build.host", `root is not readable: ${messageOf$1(error)}`));
			root = null;
		}
	}
	let entry = null;
	try {
		entry = await realpath(entryPath);
	} catch (error) {
		diagnostics.push(buildDiagnostic("local.build.host", `entry is not readable: ${messageOf$1(error)}`));
	}
	if (root && entry && !isInside(root, entry)) diagnostics.push(buildDiagnostic("local.build.host", "The host entry must be inside the declared root."));
	let allowlist = [];
	if (rawAllowlist === void 0) diagnostics.push(buildDiagnostic("local.build.host", "The host entry must export an explicit \"allowlist\"."));
	else if (!Array.isArray(rawAllowlist) || rawAllowlist.length === 0) diagnostics.push(buildDiagnostic("local.build.host", "allowlist must be a non-empty array of directories."));
	else if (root) {
		for (const item of rawAllowlist) {
			const candidate = pathFromValue(item, root, "allowlist entry", diagnostics);
			if (!candidate) continue;
			try {
				const real = await realpath(candidate);
				if (!(await stat(real)).isDirectory()) {
					diagnostics.push(buildDiagnostic("local.build.host", "Every allowlist entry must be a directory."));
					continue;
				}
				if (!isInside(root, real)) {
					diagnostics.push(buildDiagnostic("local.build.host", "Every allowlist directory must be inside root."));
					continue;
				}
				allowlist.push(real);
			} catch (error) {
				diagnostics.push(buildDiagnostic("local.build.host", `An allowlist directory is not readable: ${messageOf$1(error)}`));
			}
		}
		allowlist = [...new Set(allowlist)];
	}
	const declared = mergeDeclared([readLocalStyleResourceInputs(pick(module, "resources") ?? pick(module, "styles"), "resources", diagnostics), readLocalStyleResourceInputs(options.resources, "options.resources", diagnostics)], diagnostics);
	const hostNotices = pick(module, "notices");
	const notices = [options.notices, hostNotices].filter((value) => value !== void 0);
	if (!config || !reactConfig || !root || !entry || allowlist.length === 0) return { diagnostics: Object.freeze(diagnostics) };
	return {
		diagnostics: Object.freeze(diagnostics),
		host: Object.freeze({
			entry,
			root,
			allowlist: Object.freeze(allowlist),
			config,
			reactConfig,
			declared: Object.freeze(declared),
			notices: Object.freeze(notices)
		})
	};
}
// src/build/notices.ts
var MAX_NOTICE_ID_LENGTH = 192;
var MAX_NOTICE_FIELD_LENGTH = 2048;
var MAX_NOTICE_TEXT_LENGTH = 1048576;
var MAX_NOTICES_TOTAL_BYTES = 1048576;
var NOTICE_ID = /^[A-Za-z0-9@][A-Za-z0-9@._/-]*$/;
var NOTICE_URL = /^https?:\/\/[^\s]+$/i;
function readText(value, path, limit, diagnostics) {
	if (value === void 0) return void 0;
	if (typeof value !== "string") {
		diagnostics.push(buildDiagnostic("local.build.notice-invalid", `${path} must be a string.`));
		return;
	}
	if (value.length > limit) {
		diagnostics.push(buildDiagnostic("local.build.notice-invalid", `${path} exceeds ${limit} characters.`));
		return;
	}
	return value;
}
function readNotice(value, index, diagnostics) {
	if (!value || typeof value !== "object" || Array.isArray(value)) {
		diagnostics.push(buildDiagnostic("local.build.notice-invalid", `notices[${index}] must be an object.`));
		return null;
	}
	const record = value;
	const id = record.id;
	if (typeof id !== "string" || id.length === 0 || id.length > MAX_NOTICE_ID_LENGTH || !NOTICE_ID.test(id)) {
		diagnostics.push(buildDiagnostic("local.build.notice-invalid", `notices[${index}].id must be a bounded package-like identifier.`));
		return null;
	}
	const name = readText(record.name, `notices[${index}].name`, MAX_NOTICE_FIELD_LENGTH, diagnostics);
	const version = readText(record.version, `notices[${index}].version`, MAX_NOTICE_FIELD_LENGTH, diagnostics);
	const license = readText(record.license, `notices[${index}].license`, MAX_NOTICE_FIELD_LENGTH, diagnostics);
	const text = readText(record.text, `notices[${index}].text`, MAX_NOTICE_TEXT_LENGTH, diagnostics);
	let url;
	if (record.url !== void 0) {
		url = readText(record.url, `notices[${index}].url`, MAX_NOTICE_FIELD_LENGTH, diagnostics);
		if (url !== void 0 && !NOTICE_URL.test(url)) {
			diagnostics.push(buildDiagnostic("local.build.notice-invalid", `notices[${index}].url must be an http(s) URL.`));
			url = void 0;
		}
	}
	const identity = JSON.stringify({
		name,
		version,
		license,
		url,
		text
	});
	return Object.freeze({
		id,
		...name === void 0 ? {} : { name },
		...version === void 0 ? {} : { version },
		...license === void 0 ? {} : { license },
		...url === void 0 ? {} : { url },
		...text === void 0 ? {} : { text },
		digest: sha256(identity)
	});
}
function formatNotice(notice) {
	const identity = [notice.name, notice.version].filter((part) => typeof part === "string" && part.length > 0).join(" ");
	const lines = [identity.length > 0 ? `${notice.id} (${identity})` : notice.id];
	if (notice.license) lines.push(`License: ${notice.license}`);
	if (notice.url) lines.push(notice.url);
	if (notice.text) lines.push(notice.text);
	return lines.join("\n");
}
/**
* Merge explicit notice sources deterministically. Duplicate identities
* deduplicate; the same id with different contents is a conflict.
*/
function collectLocalBuildNotices(sources, diagnostics) {
	const strings = [];
	const byId = /* @__PURE__ */ new Map();
	let index = 0;
	for (const source of sources) {
		if (source === void 0 || source === null) continue;
		if (typeof source === "string") {
			if (source.length > MAX_NOTICES_TOTAL_BYTES) diagnostics.push(buildDiagnostic("local.build.notice-budget", "The notice text exceeds its 1 MiB budget."));
			else if (source.trim().length > 0) strings.push(source);
			continue;
		}
		if (!Array.isArray(source)) {
			diagnostics.push(buildDiagnostic("local.build.notice-invalid", "notices must be an array or a string."));
			continue;
		}
		for (const entry of source) {
			const notice = readNotice(entry, index, diagnostics);
			index += 1;
			if (!notice) continue;
			const previous = byId.get(notice.id);
			if (previous) {
				if (previous.digest !== notice.digest) diagnostics.push(buildDiagnostic("local.build.notice-conflict", `Notice "${notice.id}" is declared with conflicting contents.`));
				continue;
			}
			byId.set(notice.id, notice);
		}
	}
	const entries = [...byId.values()].sort((left, right) => left.id < right.id ? -1 : left.id > right.id ? 1 : 0);
	const text = [...strings, ...entries.map(formatNotice)].join("\n\n");
	if (utf8ByteLength(text) > MAX_NOTICES_TOTAL_BYTES) diagnostics.push(buildDiagnostic("local.build.notice-budget", "Collected notices exceed the 1 MiB budget."));
	return Object.freeze({
		text,
		digest: sha256(text),
		entries: Object.freeze(entries)
	});
}
// src/build/entry.ts
var VIRTUAL_HOST_ENTRY = "virtual:reactive-md-host-entry";
var VIRTUAL_HOST_MODULE = "virtual:reactive-md-host-module";
var CONFIG_KEY = /^rmd-[0-9a-f]{16}$/;
/**
* Generate the Vite entry. It imports the host module for the prepared React
* implementations and uses only the public standalone mount API. The config key
* baked into the bundle is checked again at runtime so a host cannot mount the
* bundle after changing its extension configuration.
*/
function createLocalStandaloneEntrySource(configKey) {
	if (!CONFIG_KEY.test(configKey)) throw new TypeError("A standalone build entry requires a valid LocalConfig key.");
	return `import { mountAll } from "reactive-md/standalone";
import {
  config as __reactiveMDConfig,
  reactConfig as __reactiveMDReactConfig,
} from "${VIRTUAL_HOST_MODULE}";

const __reactiveMDExpectedConfigKey = ${JSON.stringify(configKey)};
const __reactiveMDHandles = new Set();

function __reactiveMDInstalledConfig() {
  const reactConfig = __reactiveMDReactConfig;
  const installed = reactConfig && reactConfig.config;
  const declared = __reactiveMDConfig;
  if (!installed || installed.key !== __reactiveMDExpectedConfigKey
    || !declared || declared.key !== __reactiveMDExpectedConfigKey) {
    throw new Error("Reactive MD standalone bundle configuration does not match its build.");
  }
  return reactConfig;
}

export function mountReactiveMD(target) {
  const reactConfig = __reactiveMDInstalledConfig();
  const handles = mountAll(target === undefined ? document : target, { reactConfig });
  for (const handle of handles) __reactiveMDHandles.add(handle);
  return handles;
}

export function unmountReactiveMD() {
  for (const handle of __reactiveMDHandles) handle.unmount();
  __reactiveMDHandles.clear();
}

function __reactiveMDRun() {
  try {
    mountReactiveMD(document);
  } catch (error) {
    if (typeof console !== "undefined" && typeof console.error === "function") {
      console.error("Reactive MD: the standalone extension bundle could not start.", error);
    }
  }
}

if (typeof document !== "undefined") {
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", __reactiveMDRun, { once: true });
  } else if (typeof queueMicrotask === "function") {
    queueMicrotask(__reactiveMDRun);
  } else {
    Promise.resolve().then(__reactiveMDRun);
  }
}
`;
}
// src/build/vite.ts
var MAX_SCRIPT_BYTES = 33554432;
var FORBIDDEN_SCRIPT_TOKENS = [
	[/\bimport\s*\.\s*meta\b/, "import.meta"],
	[/\bimport\s*\(/, "a dynamic import"],
	[/\bnew\s+(?:(?:window|self|globalThis)\s*\.\s*)?(?:Shared)?Worker\s*\(/, "a Worker"],
	[/\bimportScripts\s*\(/, "importScripts()"],
	[/\bnavigator\s*\.\s*serviceWorker\b/, "a service worker"],
	[/(?<![.\w$])(?:fetch|XMLHttpRequest)\s*\([^)]*\)(?!\s*\{)/, "a network request"],
	[/\b(?:window|self|globalThis)\s*\.\s*(?:fetch|XMLHttpRequest)\s*\(/, "a network request"],
	[/(?:from|import)\s*\(?\s*["'](?:https?:)?\/\//, "a remote module"]
];
function isRecord(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
function messageOf(error) {
	return error instanceof Error ? error.message : String(error);
}
/** Load the optional Vite peer through a dynamic import, or accept an injected facade. */
async function resolveLocalVite(source, diagnostics) {
	let candidate;
	try {
		candidate = typeof source === "function" ? await source() : source;
	} catch (error) {
		diagnostics.push(buildDiagnostic("local.build.vite", `The Vite facade failed to load: ${messageOf(error)}`));
		return null;
	}
	if (candidate !== void 0) {
		if (!isRecord(candidate) || typeof candidate.build !== "function") {
			diagnostics.push(buildDiagnostic("local.build.vite", "The injected Vite facade must expose build(config)."));
			return null;
		}
		return candidate;
	}
	try {
		const module = await import("vite");
		if (typeof module.build !== "function") {
			diagnostics.push(buildDiagnostic("local.build.vite", "The installed Vite package does not export build()."));
			return null;
		}
		return module;
	} catch (error) {
		diagnostics.push(buildDiagnostic("local.build.vite", `The optional Vite peer is required to build a standalone bundle: ${messageOf(error)}`));
		return null;
	}
}
function readSingleOutput(result, diagnostics) {
	let value = result;
	if (Array.isArray(value)) {
		if (value.length !== 1) {
			diagnostics.push(buildDiagnostic("local.build.script", `Vite produced ${value.length} build outputs; exactly one is required.`));
			return null;
		}
		value = value[0];
	}
	if (!isRecord(value) || !Array.isArray(value.output)) {
		diagnostics.push(buildDiagnostic("local.build.script", "Vite did not return a completed single-output build."));
		return null;
	}
	return value;
}
function validateOutput(output, diagnostics) {
	const files = output.output;
	const chunks = files.filter((file) => isRecord(file) && file.type === "chunk");
	const assets = files.filter((file) => isRecord(file) && file.type === "asset");
	if (assets.length > 0) {
		const names = assets.map((asset) => isRecord(asset) && typeof asset.fileName === "string" ? asset.fileName : "unnamed").slice(0, 8).join(", ");
		diagnostics.push(buildDiagnostic("local.build.script", `The standalone build emitted ${assets.length} asset(s) instead of one inline script (${names}). Pass CSS and files as explicit resources.`));
		return null;
	}
	if (chunks.length !== 1) {
		diagnostics.push(buildDiagnostic("local.build.script", `The standalone build emitted ${chunks.length} chunks; exactly one is required.`));
		return null;
	}
	const chunk = chunks[0];
	if (!isRecord(chunk) || typeof chunk.code !== "string") {
		diagnostics.push(buildDiagnostic("local.build.script", "The standalone build did not return script text."));
		return null;
	}
	for (const key of [
		"imports",
		"dynamicImports",
		"implicitlyLoadedBefore"
	]) {
		const value = chunk[key];
		if (Array.isArray(value) && value.length > 0) {
			diagnostics.push(buildDiagnostic("local.build.script", `The standalone script still contains ${key} (${value.length}); it is not self-contained.`));
			return null;
		}
	}
	const code = chunk.code;
	const bytes = utf8ByteLength(code);
	if (code.trim().length === 0) {
		diagnostics.push(buildDiagnostic("local.build.script", "The standalone script is empty."));
		return null;
	}
	if (bytes > MAX_SCRIPT_BYTES) {
		diagnostics.push(buildDiagnostic("local.build.script", `The standalone script exceeds the ${MAX_SCRIPT_BYTES}-byte budget.`));
		return null;
	}
	for (const [pattern, label] of FORBIDDEN_SCRIPT_TOKENS) if (pattern.test(code)) {
		diagnostics.push(buildDiagnostic("local.build.script", `The standalone script contains ${label}; offline bundles must not fetch code or resources at runtime.`));
		return null;
	}
	return code;
}
/** Bundle the explicit host entry into one IIFE script with no chunks or assets. */
async function buildLocalStandaloneScript(input, vite, diagnostics) {
	const hostId = input.hostEntry.split("\\").join("/");
	const normalizeId = (id) => id.split("?")[0].split("\\").join("/");
	const config = {
		configFile: false,
		root: input.root,
		logLevel: "silent",
		publicDir: false,
		appType: "custom",
		define: {
			"process.env.NODE_ENV": JSON.stringify("production"),
			Worker: "undefined",
			SharedWorker: "undefined",
			"import.meta.url": JSON.stringify("file:///reactive-md-host.mjs")
		},
		plugins: [{
			name: "reactive-md-standalone-host",
			enforce: "pre",
			resolveId(id) {
				if (id === "virtual:reactive-md-host-entry") return `\0${VIRTUAL_HOST_ENTRY}`;
				if (id === "virtual:reactive-md-host-module") return hostId;
				return null;
			},
			load(id) {
				if (id === `\0virtual:reactive-md-host-entry`) return createLocalStandaloneEntrySource(input.configKey);
				return null;
			},
			transform(code, id) {
				if (!(normalizeId(id).includes("/reactive-md/dist-library/") || normalizeId(id).includes("/ReactiveMD/dist-library/")) && /\bnew\s+(?:(?:window|self|globalThis)\s*\.\s*)?(?:Shared)?Worker\s*\(/.test(code)) throw new Error("Offline extension modules cannot construct a Worker: " + id);
				if (normalizeId(id) === hostId && code.includes("import.meta.url")) return {
					code: code.split("import.meta.url").join(JSON.stringify("file:///reactive-md-host.mjs")),
					map: null
				};
				return null;
			}
		}],
		build: {
			write: false,
			emptyOutDir: false,
			copyPublicDir: false,
			modulePreload: false,
			target: "es2022",
			minify: "oxc",
			sourcemap: false,
			cssCodeSplit: false,
			assetsInlineLimit: 0,
			rolldownOptions: {
				preserveEntrySignatures: "strict",
				input: VIRTUAL_HOST_ENTRY,
				output: {
					format: "iife",
					name: "ReactiveMDStandaloneHost",
					entryFileNames: "reactive-md-standalone-host.js"
				}
			}
		}
	};
	let result;
	try {
		result = await vite.build(config);
	} catch (error) {
		diagnostics.push(buildDiagnostic("local.build.vite", `The Vite build failed: ${messageOf(error)}`));
		return null;
	}
	const output = readSingleOutput(result, diagnostics);
	if (!output) return null;
	return validateOutput(output, diagnostics);
}
// src/build/index.ts
/** Version of the build manifest, independent from SDK and document revisions. */
var LOCAL_BUILD_PROTOCOL = "reactive-md-build/v1";
var EMPTY_NOTICES = Object.freeze({
	text: "",
	digest: sha256(""),
	entries: Object.freeze([])
});
var OFFLINE_CAPABILITIES = [
	"static",
	"interactive",
	"offline"
];
function capabilityDiagnostics(config) {
	const diagnostics = [];
	for (const component of config.registry) for (const capability of OFFLINE_CAPABILITIES) if (!component.capabilities[capability]) diagnostics.push(buildDiagnostic("local.extension.export-capability", `${component.id}@${component.version} does not support ${capability} for an offline standalone bundle.`));
	return diagnostics;
}
function readOptionsEntry(entry) {
	return typeof entry === "string" ? entry : entry.toString();
}
/**
* Build the structured plan first: validate the host module, the LocalConfig
* key, React implementations, capabilities and every CSS/resource reference.
* No Vite build or script output happens here.
*/
async function preflightLocalStandaloneBuild(options) {
	const hostResult = await readLocalBuildHost(options);
	const diagnostics = [...hostResult.diagnostics];
	const host = hostResult.host;
	if (!host) return Object.freeze({
		ok: false,
		diagnostics: Object.freeze(diagnostics),
		entry: readOptionsEntry(options.entry),
		root: "",
		allowlist: Object.freeze([]),
		resources: Object.freeze([]),
		assets: Object.freeze([]),
		css: "",
		notices: EMPTY_NOTICES
	});
	diagnostics.push(...capabilityDiagnostics(host.config));
	const budgets = readLocalBuildBudgets(options.budgets, diagnostics);
	const collected = await collectLocalBuildResources({
		config: host.config,
		declared: host.declared,
		themes: options.themes,
		root: host.root,
		allowlist: host.allowlist,
		budgets
	});
	diagnostics.push(...collected.diagnostics);
	const notices = collectLocalBuildNotices(host.notices, diagnostics);
	return Object.freeze({
		ok: diagnostics.length === 0,
		diagnostics: Object.freeze(diagnostics),
		entry: host.entry,
		root: host.root,
		allowlist: host.allowlist,
		config: host.config,
		configKey: host.config.key,
		resources: collected.resources,
		assets: collected.assets,
		css: collected.css,
		notices
	});
}
function createManifest(preflight, script, notices) {
	const config = preflight.config;
	return Object.freeze({
		protocol: LOCAL_BUILD_PROTOCOL,
		sdkVersion: LOCAL_SDK_VERSION,
		configKey: preflight.configKey,
		assembly: localAssemblyIdentity(config),
		seal: localAssemblySeal(config),
		format: "iife",
		script: Object.freeze({
			digest: sha256(script),
			bytes: utf8ByteLength(script)
		}),
		resources: Object.freeze(preflight.resources.map((resource) => Object.freeze({
			id: resource.id,
			origin: resource.origin,
			digest: resource.digest,
			bytes: resource.bytes
		}))),
		inlinedAssets: preflight.assets,
		components: Object.freeze(config.registry.map(localComponentRequirement)),
		themes: Object.freeze(config.themes.map((theme) => Object.freeze({
			id: theme.id,
			name: theme.name,
			version: theme.version,
			digest: localThemeContractDigest(theme)
		}))),
		notices: Object.freeze({
			digest: notices.digest,
			entries: Object.freeze(notices.entries.map((entry) => Object.freeze({
				id: entry.id,
				...entry.name === void 0 ? {} : { name: entry.name },
				...entry.version === void 0 ? {} : { version: entry.version },
				...entry.license === void 0 ? {} : { license: entry.license },
				...entry.url === void 0 ? {} : { url: entry.url },
				digest: entry.digest
			})))
		})
	});
}
/**
* Build one inline self-contained standalone script plus the deterministic
* resource, notice and manifest data an offline exporter needs.
*
* The optional Vite peer is loaded dynamically, so consumers that only read
* manifests or preflight do not install Vite. The returned object is
* structurally compatible with `LocalStandaloneBundle` for the existing
* exporter and standalone restoration path.
*/
async function buildLocalStandaloneBundle(options) {
	const preflight = await preflightLocalStandaloneBuild(options);
	if (!preflight.ok || !preflight.config || !preflight.configKey) throw new LocalBuildError("The standalone bundle preflight failed.", preflight.diagnostics);
	const config = preflight.config;
	const configKey = preflight.configKey;
	const diagnostics = [];
	const vite = await resolveLocalVite(options.vite, diagnostics);
	if (!vite) throw new LocalBuildError("The standalone bundle build could not load Vite.", diagnostics);
	const script = await buildLocalStandaloneScript({
		root: preflight.root,
		hostEntry: preflight.entry,
		configKey
	}, vite, diagnostics);
	if (!script) throw new LocalBuildError("The standalone bundle build failed.", diagnostics);
	const bundle = defineLocalStandaloneBundle(script, config);
	const manifest = createManifest({
		...preflight,
		config,
		configKey
	}, script, preflight.notices);
	return Object.freeze({
		script: bundle.script,
		extensions: bundle.extensions,
		seal: bundle.seal,
		configKey,
		resources: preflight.resources,
		assets: preflight.assets,
		css: preflight.css,
		notices: preflight.notices.text,
		manifest
	});
}
export { DEFAULT_LOCAL_BUILD_BUDGETS, LOCAL_BUILD_PROTOCOL, LocalBuildError, VIRTUAL_HOST_ENTRY, VIRTUAL_HOST_MODULE, buildLocalStandaloneBundle, collectLocalBuildNotices, collectLocalBuildResources, createLocalStandaloneEntrySource, defineLocalTheme as n, preflightLocalStandaloneBuild, LOCAL_REACT_PRESET_PROTOCOL as r, readLocalBuildBudgets, readLocalBuildHost, readLocalStyleResourceInputs, resolveLocalVite, createLocalConfig as t };
