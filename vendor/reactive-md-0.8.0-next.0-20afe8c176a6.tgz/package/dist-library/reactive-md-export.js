import { D as e } from "./identity-MYJXKSkB.js";
import { f as t, l as n, u as r } from "./config-validation-DXTynAw7.js";
import { f as i, n as a, u as o } from "./registry-B9Jc3FVe.js";
import { _ as s, c, i as l, l as u, o as d, r as f, s as p, u as m } from "./shareable-DDVL4Fi9.js";
import { i as h, n as g, r as _, t as v } from "./resources-BGt8mpDA.js";
import { t as y } from "./component-state-D_cw_EHe.js";
// src/export/index.ts
function b(t, n) {
	let r = o(n);
	if (typeof t != "string" || !t.trim() || t.length > 33554432) throw TypeError("A standalone bundle must contain a nonempty script of at most 32 MiB.");
	return Object.freeze({
		script: t,
		seal: d(t, r),
		extensions: Object.freeze({
			protocol: "reactive-md-extensions/v1",
			components: Object.freeze(r.registry.map((t) => Object.freeze({
				id: t.id,
				name: t.name,
				version: t.version,
				digest: e(t)
			})))
		})
	});
}
function x(e) {
	let s = o(e.config), l = e.document.extensions ?? {
		protocol: "reactive-md-extensions/v1",
		components: []
	}, d = h(l, s);
	d.push(...i(e.document, s)), d.push(..._({
		document: e.document,
		installed: a(s),
		externalNames: new Set(s.components.map((e) => e.name))
	}));
	let f = new Set(e.requiredResources ?? []), p = e.target;
	if (![
		"static",
		"ssr",
		"offline"
	].includes(p)) throw TypeError("Unknown export target.");
	for (let e of l.components) {
		let t = s.registry.find((t) => t.id === e.id);
		if (!t) continue;
		for (let e of t.styles ?? []) f.add(e);
		let n = p === "offline" ? [
			"static",
			"interactive",
			"offline"
		] : [p];
		for (let e of n) t.capabilities[e] || d.push(g("local.extension.export-capability", `${t.id}@${t.version} does not support ${e} for ${p} export.`));
	}
	if (p === "offline") {
		if (!e.bundle?.script?.trim()) d.push(g("local.extension.bundle-missing", "Offline output requires an explicitly built standalone bundle."));
		else {
			d.push(...h(e.bundle.extensions, s));
			let i = e.bundle.seal;
			if (i && (i.protocol !== "reactive-md-bundle/v1" || i.sdkVersion !== "0.7.0" || !t(s, i.configKey) || i.scriptDigest !== c(e.bundle.script)) && d.push(g("local.extension.bundle-integrity", "The bundle script or installed configuration differs from its sealed build manifest.")), i?.assembly !== void 0) {
				let e = n(s);
				(JSON.stringify(i.assembly) !== JSON.stringify(e) || i.seal !== void 0 && i.seal !== r(s)) && d.push(g("local.extension.bundle-assembly", "The bundle assembly identity differs from the installed assembly."));
			}
			for (let t of l.components) e.bundle.extensions.components.some((e) => e.id === t.id && e.digest === t.digest) || d.push(g("local.extension.bundle-mismatch", `The standalone bundle does not include ${t.id}@${t.version}.`));
		}
	}
	let m = e.document.theme ?? "default", y = s.themes.find((e) => e.name === m);
	if (p === "offline" && y && e.bundle?.seal) {
		let t = e.bundle.seal.themes;
		Array.isArray(t) && t.some((e) => e.id === y.id && e.name === y.name && e.version === y.version && e.digest === u(y)) || d.push(g("local.extension.bundle-theme", `Bundle theme ${y.id}@${y.version} differs from the selected export theme. Rebuild the bundle.`));
	}
	m !== "default" && !y && d.push(g("local.extension.theme-missing", `Theme ${m} is not installed for export.`));
	let b = v([...e.resources ?? [], ...y?.css ?? []]);
	d.push(...b.diagnostics);
	let x = new Map(b.resources.map((e) => [e.id, e]));
	for (let e of f) x.has(e) || d.push(g("local.extension.resource-missing", `Required style resource ${e} is missing.`));
	let S = Object.freeze([...x.values()]);
	return Object.freeze({
		target: p,
		extensions: l,
		resources: S,
		css: S.map((e) => e.css).join("\n"),
		diagnostics: Object.freeze(d),
		ok: d.length === 0
	});
}
function S(e) {
	if (e.document.source !== e.source) throw TypeError("The compiled document does not belong to this source.");
	let t = s(e.state);
	if (!t.ok) throw TypeError(t.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let n = l(e.document, t.file);
	if (!n.ok) throw TypeError(n.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	let r = o(e.config);
	if (e.compileOptions?.hostComponents !== void 0 || e.compileOptions?.config && o(e.compileOptions.config).key !== r.key) throw TypeError("Conflicting export component configuration.");
	let i = x({
		...e,
		target: e.mode === "static" ? "static" : "offline"
	});
	if (!i.ok) throw TypeError(i.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	if (/data-rmd-extension-error\s*=|local-sdk-unavailable/.test(e.staticMarkup)) throw TypeError("Static output contains an unavailable extension component.");
	return f({
		...e,
		compileOptions: {
			...e.compileOptions,
			config: r
		},
		extensions: i.extensions,
		restoration: p(e.document, r, i.target, i.resources),
		resources: i.resources,
		runtimeScript: e.bundle?.script,
		css: `${e.css}\n${i.css}`
	});
}
export { d as createLocalBundleManifest, x as createLocalExportPlan, p as createLocalRestorationRequirements, S as createLocalShareableHtml, b as defineLocalStandaloneBundle, c as localExportContentDigest, u as localThemeContractDigest, v as readLocalExportResources, y as resolveLocalComponentStateExport, _ as validateLocalComponentContracts, h as validateLocalExtensionRequirements, m as validateLocalRestorationRequirements };
