import { r as e } from "./compiler-core-MF3N1RCF.js";
import "./manifest-gj41AWZb.js";
import { l as t, m as n, p as r } from "./config-validation-DaLdxnS1.js";
import { n as i } from "./default-d2u6mrJW.js";
import { n as a } from "./options-CKtqVWpM.js";
// src/local/parsing/parser.ts
function o(t, n, r, i, o) {
	return typeof t != "string" || t.length > 1e6 ? e(t, void 0, r, i, o) : e(t, a(n), r, i, o);
}
// src/local/configuration/schema.ts
function s() {
	let e = i.map(t), n = e.findIndex((e) => e.name === "validation"), a = n < 0 ? e.length : n;
	return Object.freeze([
		...e.slice(0, a),
		...r,
		...e.slice(a)
	]);
}
var c = s(), l = Object.freeze(Object.fromEntries(c.map((e) => [e.name, Object.freeze(e)]))), u = Object.freeze(c.map((e) => e.name)), d = Object.freeze({
	leaf: Object.freeze(c.filter((e) => e.form === "leaf").map((e) => e.name)),
	inline: Object.freeze(c.filter((e) => e.form === "inline").map((e) => e.name)),
	container: Object.freeze(c.filter((e) => e.form === "container").map((e) => e.name))
});
function f(e) {
	return d[e];
}
function p(e) {
	return Object.hasOwn(l, e) ? l[e] : void 0;
}
function m(e, t) {
	return e.props[t]?.default;
}
function h(e) {
	return n(e, u);
}
function g(e, t) {
	return n(t, Object.keys(e.props));
}
export { f as a, o as c, m as i, u as n, g as o, p as r, h as s, l as t };
