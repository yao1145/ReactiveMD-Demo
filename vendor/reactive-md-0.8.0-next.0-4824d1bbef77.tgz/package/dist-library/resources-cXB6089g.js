import { C as e, T as t, x as n } from "./manifest-gj41AWZb.js";
import { g as r, u as i } from "./registry-DeUrtCFb.js";
// src/export/requirements.ts
var a = 128, o = 16777216, s = 5e5;
function c(e, t) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function l(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function u(e, t) {
	if (e === void 0) return [];
	let r = [], a = (e) => r.push(c("local.extension.requirements", e));
	try {
		if (!e || typeof e != "object" || Array.isArray(e)) return a("Extension requirements must be a plain object."), r;
		let o = e;
		if (o.protocol !== "reactive-md-extensions/v1" || !Array.isArray(o.components) || o.components.length > 64) return a("Unsupported or oversized extension requirements."), r;
		let s = t === void 0 ? void 0 : i(t), c = /* @__PURE__ */ new Set();
		for (let e of o.components) {
			if (!e || typeof e != "object" || typeof e.id != "string" || typeof e.name != "string" || typeof e.version != "string" || typeof e.digest != "string" || [
				e.id,
				e.name,
				e.version,
				e.digest
			].some((e) => e.length > 256) || c.has(e.id)) {
				a("Invalid or duplicate component requirement.");
				continue;
			}
			c.add(e.id);
			let t = s?.components.find((t) => t.id === e.id);
			t ? (t.name !== e.name || t.version !== e.version || n(t) !== e.digest) && a(`Component ${e.id}@${e.version} does not match the installed component contract.`) : a(`Component ${e.id}@${e.version} is not installed in this host.`);
		}
	} catch (e) {
		a(e instanceof Error ? e.message : String(e));
	}
	return r;
}
function d(n) {
	let r = [], i = (e) => r.push(c("local.extension.contract-metadata", e)), s = n.componentDefinitions;
	if (s === void 0) return {
		definitions: [],
		diagnostics: r
	};
	if (!Array.isArray(s)) return i("Carried component definitions must be an array."), {
		definitions: [],
		diagnostics: r
	};
	if (s.length > a) return i(`Carried component definitions exceed the ${a}-entry budget.`), {
		definitions: [],
		diagnostics: r
	};
	let l = e(s);
	if (!Number.isFinite(l) || l > o) return i(`Carried component definitions exceed the ${o}-byte budget.`), {
		definitions: [],
		diagnostics: r
	};
	let u = [];
	for (let e = 0; e < s.length; e += 1) try {
		u.push(t(s[e]));
	} catch (t) {
		i(`Carried component definition ${e} is invalid: ${t instanceof Error ? t.message : String(t)}`);
	}
	return {
		definitions: u,
		diagnostics: r
	};
}
function f(e) {
	let t = /* @__PURE__ */ new Map(), n = e.extensions;
	if (!l(n) || n.protocol !== "reactive-md-extensions/v1" || !Array.isArray(n.components) || n.components.length > 64) return t;
	for (let e of n.components) {
		if (!l(e)) continue;
		let { id: n, name: r, version: i, digest: a } = e;
		typeof n == "string" && typeof r == "string" && typeof i == "string" && typeof a == "string" && t.set(r, {
			id: n,
			name: r,
			version: i,
			digest: a
		});
	}
	return t;
}
function p(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	if (!Array.isArray(e.nodes)) return n.push(c("local.extension.contract-metadata", "Document nodes must be an array.")), {
		names: t,
		diagnostics: n
	};
	let r = [...e.nodes], i = 0;
	for (; r.length > 0;) {
		let e = r.pop();
		if (e && typeof e == "object") {
			if (i += 1, i > s) {
				n.push(c("local.extension.contract-metadata", "Document component scan exceeded its node budget."));
				break;
			}
			if (e.type === "hostComponent" || e.type === "component") {
				let n = typeof e.name == "string" ? e.name : "";
				n && t.add(n);
			}
			if (Array.isArray(e.children)) for (let t of e.children) r.push(t);
		}
	}
	return {
		names: t,
		diagnostics: n
	};
}
function m(e) {
	let t = [], r = (e) => t.push(c("local.extension.contract", e));
	try {
		let { document: i, installed: a } = e, o = d(i);
		t.push(...o.diagnostics);
		let s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map();
		for (let e of a) s.set(e.id, e), c.set(e.name, e);
		let l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map();
		for (let e of o.definitions) {
			if (l.has(e.id) || u.has(e.name)) {
				r(`Carried component definition ${e.id} is declared more than once.`);
				continue;
			}
			l.set(e.id, e), u.set(e.name, e);
			let t = s.get(e.id) ?? c.get(e.name);
			t ? (t.id !== e.id || t.name !== e.name || t.version !== e.version || n(t) !== n(e)) && r(`Carried component ${e.id}@${e.version} does not match the installed component contract.`) : r(`Carried component ${e.id}@${e.version} is not installed in this host.`);
		}
		let m = e.externalNames ?? /* @__PURE__ */ new Set();
		if (m.size > 0) {
			let e = p(i);
			t.push(...e.diagnostics);
			let a = f(i);
			for (let t of e.names) {
				if (!m.has(t)) continue;
				let e = c.get(t);
				if (!e) {
					r(`Component <${t}> is used but no matching installed component contract exists.`);
					continue;
				}
				let i = a.get(t);
				i ? (i.id !== e.id || i.version !== e.version || i.digest !== n(e)) && r(`Component <${t}> requirement does not match the installed ${e.id}@${e.version}.`) : r(`Component <${t}> is used but the document has no extension requirement for ${e.id}@${e.version}.`);
			}
		}
	} catch (e) {
		r(e instanceof Error ? e.message : String(e));
	}
	return t;
}
// src/export/resources.ts
function h(e) {
	return r(e);
}
function g(e) {
	let t = [], n = (e, n) => t.push({
		code: e,
		message: n,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}), r = /* @__PURE__ */ new Map();
	if (!Array.isArray(e) || e.length > 256) return n("local.extension.resource-budget", "Styles must be a bounded resource array."), {
		resources: [],
		diagnostics: t
	};
	let i = 0;
	for (let t of e) {
		if (!t || typeof t != "object" || typeof t.id != "string" || !t.id || t.id.length > 256 || /[\u0000-\u001f]/.test(t.id) || typeof t.css != "string" || !h(t.css)) {
			n("local.extension.resource-invalid", "Export styles must be identified inline CSS without network resources.");
			continue;
		}
		if (t.css.length > 4194304) {
			n("local.extension.resource-budget", "A style resource exceeds the 4 MiB budget.");
			break;
		}
		let e = r.get(t.id);
		if (e && e.css !== t.css && n("local.extension.resource-conflict", `Style resource ${t.id} has conflicting contents.`), !e) {
			if (i += new TextEncoder().encode(t.css).byteLength, r.size >= 128 || i > 4194304) {
				n("local.extension.resource-budget", "Export styles exceed 128 resources or 4 MiB.");
				break;
			}
			r.set(t.id, Object.freeze({
				id: t.id,
				css: t.css
			}));
		}
	}
	return {
		resources: Object.freeze([...r.values()]),
		diagnostics: t
	};
}
export { u as i, c as n, m as r, g as t };
