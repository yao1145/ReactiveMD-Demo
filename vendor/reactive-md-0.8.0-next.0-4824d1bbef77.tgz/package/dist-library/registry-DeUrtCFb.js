import { C as e, D as t, L as n } from "./manifest-gj41AWZb.js";
import { K as r, U as i, a, c as o, f as s, i as c, l, n as u, o as d, r as f, s as ee, t as p } from "./config-validation-DaLdxnS1.js";
import { n as te, t as m } from "./default-d2u6mrJW.js";
// src/local/theme/theme.ts
var h = "reactive-md-theme-1", g = Object.freeze({
	name: "default",
	protocol: h,
	colorSchemes: Object.freeze(["light", "dark"])
});
function ne(e, t) {
	let n = typeof t == "string" ? t.length : Infinity;
	if (!e || typeof e.start != "number" || typeof e.end != "number" || !Number.isFinite(e.start) || !Number.isFinite(e.end)) return {
		start: 0,
		end: 0
	};
	let r = Math.max(0, Math.min(n, Math.floor(e.start)));
	return {
		start: r,
		end: Math.max(r, Math.min(n, Math.floor(e.end)))
	};
}
function re(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.min(t, e.length), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: t - i + 1
	};
}
function ie(e, t, n, r) {
	let a = ne(n, r), { line: o, column: s } = re(r, a.start);
	return {
		code: e,
		message: i(t),
		severity: "warning",
		range: a,
		line: o,
		column: s,
		messageKey: t.key,
		...t.params ? { params: t.params } : {}
	};
}
function ae(e, t, n, i) {
	let a = (e, t) => ({
		name: g.name,
		diagnostics: [ie(e, t, n, i)]
	}), o = e;
	if (o == null || o === "") return {
		name: g.name,
		diagnostics: []
	};
	if (!s(o)) return a("local.theme.name", r("local.theme.name", {
		name: String(o),
		limit: 64
	}));
	let c = o;
	if (c === g.name) return {
		name: g.name,
		diagnostics: []
	};
	if (!Array.isArray(t)) return a("local.theme.missing", r("local.theme.missing", { name: c }));
	let l = 0, u = null;
	try {
		for (let e of t) typeof e == "object" && e && !Array.isArray(e) && e.name === c && (l += 1, u = e);
	} catch {
		return a("local.theme.manifest", r("local.theme.manifest.unreadable"));
	}
	if (l === 0) return a("local.theme.missing", r("local.theme.missing", { name: c }));
	if (l > 1) return a("local.theme.duplicate", r("local.theme.duplicate", { name: c }));
	try {
		let e = u;
		if (!e || typeof e != "object") return a("local.theme.manifest", r("local.theme.manifest.definition", { name: c }));
		if (e.protocol !== "reactive-md-theme-1") return a("local.theme.protocol", r("local.theme.protocol", {
			name: c,
			protocol: h
		}));
		let t = e.colorSchemes;
		if (!Array.isArray(t) || !t.includes("light") || !t.includes("dark")) return a("local.theme.modes", r("local.theme.modes", { name: c }));
	} catch {
		return a("local.theme.manifest", r("local.theme.manifest.selected", { name: c }));
	}
	return {
		name: c,
		diagnostics: []
	};
}
// src/sdk/theme.ts
var _ = 128, oe = 32, se = 128, v = 262144, y = 524288, ce = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/, le = /^[a-z][a-z0-9._/-]*$/, ue = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/, b = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/, de = /^(?::root|html|body)(?![A-Za-z0-9_-])/i, x = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]), fe = 256, pe = /* @__PURE__ */ new Set([
	"serif",
	"sans-serif",
	"monospace",
	"cursive",
	"fantasy",
	"system-ui",
	"ui-serif",
	"ui-sans-serif",
	"ui-monospace",
	"ui-rounded",
	"math",
	"emoji",
	"fangsong",
	"-apple-system",
	"blinkmacsystemfont"
]), S = /* @__PURE__ */ new Set([
	"inherit",
	"initial",
	"unset",
	"revert",
	"revert-layer"
]), me = /* @__PURE__ */ new Set([
	"caption",
	"icon",
	"menu",
	"message-box",
	"small-caption",
	"status-bar"
]), he = /* @__PURE__ */ new Set([
	"xx-small",
	"x-small",
	"small",
	"medium",
	"large",
	"x-large",
	"xx-large",
	"xxx-large",
	"smaller",
	"larger"
]), ge = /^rmd-theme-([a-z][a-z0-9-]*)-font-([0-9a-f]+)$/;
function C(e, t) {
	return /* @__PURE__ */ Error(`Invalid local theme ${e}: ${t}`);
}
function _e(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function w(e, t) {
	if (!_e(e)) throw C(t, "must be an object.");
	return e;
}
function T(e, t) {
	if (typeof e != "string" || e.length === 0) throw C(t, "must be a non-empty string.");
	if (e.length > _) throw C(t, `must not exceed ${_} characters.`);
	if (!ce.test(e)) throw C(t, `"${e}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return e;
}
function E(e, t) {
	if (!s(e)) throw C(t, "must be a lowercase kebab-case name that starts with a letter.");
	if (e === "default") throw C(t, "must not replace the reserved built-in \"default\" theme.");
	return e;
}
function D(e, t) {
	if (typeof e != "string" || !ue.test(e)) throw C(t, "must be a semantic version such as \"1.0.0\".");
	return e;
}
function O(e, t) {
	if (e === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(e)) throw C(t, "must be an array of \"light\" and \"dark\".");
	let n = [];
	for (let r of e) {
		if (r !== "light" && r !== "dark") throw C(t, "may only contain \"light\" and \"dark\".");
		if (n.includes(r)) throw C(t, `must not repeat "${r}".`);
		n.push(r);
	}
	if (!n.includes("light") || !n.includes("dark")) throw C(t, "must declare both \"light\" and \"dark\".");
	return Object.freeze(n);
}
function k(e, t) {
	let n = e[t], r = t + 1;
	for (; r < e.length;) if (e[r] === "\\") r += 2;
	else {
		if (e[r] === n) return r + 1;
		r += 1;
	}
	return e.length;
}
function A(e, t, n, r) {
	let i = 0;
	for (let a = t; a < e.length; a += 1) {
		let t = e[a];
		if (t === "\"" || t === "'") a = k(e, a) - 1;
		else if (t === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === n) i += 1;
		else if (t === r && (--i, i === 0)) return a + 1;
	}
	return e.length;
}
function ve(e, t, n) {
	let r = t + 3;
	for (; r < e.length && /\s/.test(e[r]);) r += 1;
	if (e[r] !== "(") throw C(n, "has a malformed url() value.");
	for (r += 1; r < e.length && /\s/.test(e[r]);) r += 1;
	let i = e[r];
	if (i === "\"" || i === "'") {
		let t = e.indexOf(i, r + 1);
		if (t < 0) throw C(n, "has an unterminated url() string.");
		let a = e.slice(r + 1, t);
		for (r = t + 1; r < e.length && /\s/.test(e[r]);) r += 1;
		if (e[r] !== ")") throw C(n, "has a malformed url() value.");
		return {
			value: a.trim(),
			end: r + 1
		};
	}
	let a = e.indexOf(")", r);
	if (a < 0) throw C(n, "has an unterminated url() value.");
	return {
		value: e.slice(r, a).trim(),
		end: a + 1
	};
}
function ye(e, t, n, r) {
	let i = t;
	for (; i < e.length && e[i] !== "(";) i += 1;
	if (i >= e.length) throw C(r, `has a malformed ${n}() value.`);
	let a = A(e, i, "(", ")");
	if (a <= i + 1 || e[a - 1] !== ")") throw C(r, `has an unterminated ${n}() value.`);
	return {
		body: e.slice(i + 1, a - 1),
		end: a
	};
}
function be(e, t) {
	let n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (r === "\"" || r === "'") {
			let i = k(e, n);
			if (i > e.length || e[i - 1] !== r) throw C(t, "has an unterminated image-set() string.");
			let a = e.slice(n + 1, i - 1).trim();
			if (!/^data:/i.test(a)) throw C(t, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			n = i;
		} else if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else n += 1;
	}
}
function j(e, t, n = !1) {
	if (e.toLowerCase().includes("</style")) throw C(t, "must not contain a closing style tag.");
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = k(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else {
			if (i === "\\") throw C(t, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
			if (i === "@" && /^@import\b/i.test(e.slice(r, r + 8))) throw C(t, "must not use @import; inline every resource.");
			if ((i === "i" || i === "I" || i === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(e.slice(r, r + 24))) {
				let { body: n } = ye(e, r, "image-set", t);
				be(n, t), r += 1;
			} else if ((i === "u" || i === "U") && /^url\s*\(/i.test(e.slice(r, r + 12))) {
				let i = ve(e, r, t);
				if (!/^data:/i.test(i.value) && !(n && i.value.startsWith("#"))) throw C(t, "may only reference data: URLs; network and file URLs are not allowed.");
				r = i.end;
			} else {
				if ((i === "e" || i === "E") && /^expression\s*\(/i.test(e.slice(r, r + 16))) throw C(t, "must not use CSS expression().");
				r += 1;
			}
		}
	}
}
function xe(e) {
	if (typeof e != "string" || e.length > 4194304) return !1;
	try {
		return j(e, "css", !0), !0;
	} catch {
		return !1;
	}
}
function M(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		if (o === "\"" || o === "'") a = k(e, a) - 1;
		else if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else o === "\\" ? a += 1 : o === "(" ? r += 1 : o === ")" ? r = Math.max(0, r - 1) : o === "[" ? i += 1 : o === "]" ? i = Math.max(0, i - 1) : o === "," && r === 0 && i === 0 && (t.push(e.slice(n, a)), n = a + 1);
	}
	return t.push(e.slice(n)), t;
}
function Se(e, t) {
	let n = e.trim(), r = `[data-rmd-theme="${t}"]`, i = b.exec(n);
	return i ? `${r}${n.slice(i[0].length)}` : `${r} ${n}`;
}
function N(e, t) {
	let n = t;
	for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
	else if (e[n] === "/" && e[n + 1] === "*") {
		let t = e.indexOf("*/", n + 2);
		n = t < 0 ? e.length : t + 2;
	} else break;
	return n;
}
function Ce(e, t) {
	let n = e.toLowerCase(), r = /:has\s*\(/g;
	for (let i = r.exec(n); i; i = r.exec(n)) {
		if (r.lastIndex = i.index + 1, i.index >= t) continue;
		let n = i.index + i[0].length - 1, a = A(e, n, "(", ")"), o = e.slice(n + 1, Math.max(n + 1, a - 1));
		for (let t of M(o)) if (/^\s*[+~]/.test(t)) throw C("theme.css", `selector "${e.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
function we(e) {
	let t = e.trim();
	if (t === "") return;
	if (t[0] === "+" || t[0] === "~") throw C("theme.css", `selector "${t}" begins with a sibling combinator and cannot be scoped.`);
	let n = b.exec(t);
	if (n) {
		let e = n[0].length;
		for (; e < t.length;) {
			let n = t[e];
			if (/\s/.test(n) || n === "+" || n === "~" || n === ">" || n === ",") break;
			n === "[" ? e = A(t, e, "[", "]") : n === "(" ? e = A(t, e, "(", ")") : e += 1;
		}
		let r = N(t, e);
		if (t[r] === "+" || t[r] === "~") throw C("theme.css", `selector "${t}" uses a sibling combinator that can escape the theme root.`);
		Ce(t, e);
	}
}
function Te(e, t) {
	let n = M(e).map((e) => e.trim()).filter(Boolean);
	if (n.length === 0) return e.trim();
	for (let e of n) {
		if (de.test(e)) throw C("theme.css", `selector "${e}" targets the host document; scope it under the theme root instead.`);
		we(e);
	}
	return n.map((e) => Se(e, t)).join(", ");
}
function P(e, t) {
	let n = 1;
	for (let r = t; r < e.length; r += 1) {
		let t = e[r];
		if (t === "\"" || t === "'") r = k(e, r) - 1;
		else if (t === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return r;
	}
	return e.length;
}
function F(e) {
	return e.trim().replace(/\s+/g, " ").toLowerCase();
}
function I(e) {
	let t = [];
	for (let n of e) {
		let e = n.codePointAt(0);
		e <= 127 ? t.push(e) : e <= 2047 ? t.push(192 | e >> 6, 128 | e & 63) : e <= 65535 ? t.push(224 | e >> 12, 128 | e >> 6 & 63, 128 | e & 63) : t.push(240 | e >> 18, 128 | e >> 12 & 63, 128 | e >> 6 & 63, 128 | e & 63);
	}
	return t;
}
function Ee(e) {
	let t = "", n = 0;
	for (; n < e.length;) {
		let r = e[n], i, a;
		if (r <= 127) i = r, a = 1;
		else if (r >= 194 && r <= 223) i = r & 31, a = 2;
		else if (r >= 224 && r <= 239) i = r & 15, a = 3;
		else if (r >= 240 && r <= 244) i = r & 7, a = 4;
		else return null;
		if (n + a > e.length) return null;
		for (let t = 1; t < a; t += 1) {
			let r = e[n + t];
			if ((r & 192) != 128) return null;
			i = i << 6 | r & 63;
		}
		if (a === 3 && (i < 2048 || i >= 55296 && i <= 57343) || a === 4 && (i < 65536 || i > 1114111)) return null;
		t += String.fromCodePoint(i), n += a;
	}
	return t;
}
function De(e, t) {
	return `rmd-theme-${e}-font-${I(t).map((e) => e.toString(16).padStart(2, "0")).join("")}`;
}
function L(e) {
	let t = ge.exec(e);
	if (!t || t[2].length % 2 != 0) return null;
	let n = [];
	for (let e = 0; e < t[2].length; e += 2) n.push(Number.parseInt(t[2].slice(e, e + 2), 16));
	let r = Ee(n);
	return r === null || r.length === 0 || F(r) !== r ? null : {
		themeName: t[1],
		original: r
	};
}
function R(e) {
	return e === void 0 ? !1 : /[A-Za-z0-9_-]/.test(e) || e.codePointAt(0) >= 128;
}
function z(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (/[A-Za-z_]/.test(n) || n.codePointAt(0) >= 128) return !0;
	if (n === "-") {
		let n = e[t + 1];
		return n !== void 0 && (R(n) || n === "-");
	}
	return !1;
}
function Oe(e, t) {
	let n = e[t];
	if (n === void 0) return !1;
	if (n >= "0" && n <= "9") return !0;
	let r = e[t + 1];
	return n === "+" || n === "-" ? r !== void 0 && (r >= "0" && r <= "9" || r === ".") : n === "." && r !== void 0 && r >= "0" && r <= "9";
}
function B(e) {
	let t = [], n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (/\s/.test(r)) {
			n += 1;
			continue;
		}
		if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
			continue;
		}
		let i = n;
		if (r === "\"" || r === "'") {
			let r = k(e, n);
			t.push({
				type: "string",
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: e.slice(i + 1, Math.max(i + 1, r - 1))
			}), n = r;
		} else if (r === ",") t.push({
			type: "comma",
			text: ",",
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
		else if (Oe(e, n)) {
			let r = n;
			for ((e[r] === "+" || e[r] === "-") && (r += 1); e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === ".") for (r += 1; e[r] >= "0" && e[r] <= "9";) r += 1;
			if (e[r] === "e" || e[r] === "E") {
				let t = r;
				r += 1, (e[r] === "+" || e[r] === "-") && (r += 1);
				let n = r;
				for (; e[r] >= "0" && e[r] <= "9";) r += 1;
				r === n && (r = t);
			}
			let a = "number";
			if (e[r] === "%") r += 1, a = "percentage";
			else if (z(e, r)) {
				for (r += 1; R(e[r]);) r += 1;
				a = "dimension";
			}
			t.push({
				type: a,
				text: e.slice(i, r),
				start: i,
				end: r,
				name: "",
				stringValue: ""
			}), n = r;
		} else if (z(e, n)) {
			let r = n + 1;
			for (; R(e[r]);) r += 1;
			let a = e.slice(n, r).toLowerCase();
			if (e[r] === "(") {
				let o = A(e, r, "(", ")"), s = Math.min(o, e.length);
				t.push({
					type: "function",
					text: e.slice(n, s),
					start: i,
					end: s,
					name: a,
					stringValue: ""
				}), n = s;
				continue;
			}
			t.push({
				type: "ident",
				text: e.slice(n, r),
				start: i,
				end: r,
				name: a,
				stringValue: ""
			}), n = r;
		} else if (r === "(") {
			let r = A(e, n, "(", ")"), a = Math.min(r, e.length);
			t.push({
				type: "function",
				text: e.slice(n, a),
				start: i,
				end: a,
				name: "",
				stringValue: ""
			}), n = a;
		} else t.push({
			type: "delimiter",
			text: r,
			start: i,
			end: n + 1,
			name: "",
			stringValue: ""
		}), n += 1;
	}
	return t;
}
function V(e) {
	return N(e, 0) === e.length;
}
function H(e) {
	let t = B(e);
	if (t.length === 0) return null;
	if (t.length === 1 && t[0].type === "string") {
		let e = F(t[0].stringValue);
		return e === "" ? null : {
			key: e,
			start: t[0].start,
			end: t[0].end
		};
	}
	if (t[0].type === "string") return null;
	for (let n = 0; n < t.length; n += 1) if (t[n].type !== "ident" || n > 0 && !V(e.slice(t[n - 1].end, t[n].start))) return null;
	if (t.length === 1 && (S.has(t[0].name) || pe.has(t[0].name))) return null;
	let n = F(t.map((e) => e.text).join(" "));
	return n === "" ? null : {
		key: n,
		start: t[0].start,
		end: t[t.length - 1].end
	};
}
function U(e) {
	let t = [], n = 0, r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = k(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else i === "(" || i === "[" ? r = A(e, r, i, i === "(" ? ")" : "]") : (i === "," && (t.push({
			start: n,
			end: r
		}), n = r + 1), r += 1);
	}
	return t.push({
		start: n,
		end: e.length
	}), t;
}
function W(e) {
	let t = B(e);
	if (t.length < 2) return {
		body: e,
		important: ""
	};
	let n = t[t.length - 1], r = t[t.length - 2];
	return n.type !== "ident" || n.name !== "important" || r.type !== "delimiter" || r.text !== "!" || !V(e.slice(r.end, n.start)) ? {
		body: e,
		important: ""
	} : {
		body: e.slice(0, r.start),
		important: e.slice(r.start)
	};
}
function G(e, t) {
	if (t.length === 0) return e;
	let n = [...t].sort((e, t) => e.start - t.start), r = "", i = 0;
	for (let t of n) t.start < i || (r += e.slice(i, t.start) + t.text, i = t.end);
	return r + e.slice(i);
}
function ke(e) {
	return `"${e}"`;
}
function K(e, t, n = 0) {
	if (t.size === 0) return e;
	if (n > 64) throw C("theme.css", "font-family fallback nesting exceeds 64 levels.");
	let { body: r, important: i } = W(e), a = [];
	for (let e of U(r)) {
		let i = r.slice(e.start, e.end), o = H(i);
		if (o) {
			let n = t.get(o.key);
			n && a.push({
				start: e.start + o.start,
				end: e.start + o.end,
				text: ke(n)
			});
			continue;
		}
		let s = B(i);
		if (s.length !== 0 && (s.length !== 1 || s[0].type !== "ident" || !pe.has(s[0].name) && !S.has(s[0].name))) {
			if (s.length === 1 && s[0].type === "function" && s[0].name === "var") {
				let r = s[0], i = r.text.indexOf("("), o = r.text.slice(i + 1, -1), c = U(o), l = B(o.slice(0, c[0].end));
				if (!r.text.endsWith(")") || l.length !== 1 || l[0].type !== "ident" || !l[0].text.startsWith("--")) throw C("theme.css", "font-family var() must start with a custom property name.");
				if (c.length > 1) {
					let s = c[0].end + 1, l = o.slice(s);
					a.push({
						start: e.start + r.start + i + 1 + s,
						end: e.start + r.end - 1,
						text: K(l, t, n + 1)
					});
				}
			} else throw C("theme.css", "unsupported font-family syntax; use literal families or var() with a family-list fallback.");
		}
	}
	return G(r, a) + i;
}
function Ae(e) {
	let t = B(e);
	if (t.length === 0 || t.length === 1 && t[0].type === "ident" && (me.has(t[0].name) || S.has(t[0].name))) return null;
	let n = -1;
	for (let e = 0; e < t.length; e += 1) {
		let r = t[e];
		if (r.type === "dimension" && !/(?:deg|grad|rad|turn)$/i.test(r.text) || r.type === "percentage" || r.type === "ident" && he.has(r.name) || r.type === "number" && Number(r.text) === 0) {
			n = e;
			break;
		}
		if (r.type === "function") {
			let i = t[e + 1];
			if ([
				"calc",
				"min",
				"max",
				"clamp"
			].includes(r.name) || r.name === "var" && i?.type === "delimiter" && i.text === "/") {
				n = e;
				break;
			}
		}
	}
	if (n < 0) return null;
	let r = n + 1, i = t[r];
	return i?.type === "delimiter" && i.text === "/" && (r += 2), r >= t.length ? null : t[r].start;
}
function je(e, t) {
	if (t.size === 0) return e;
	let { body: n, important: r } = W(e), i = Ae(n);
	if (i === null) {
		let t = B(n);
		if (t.length === 1 && t[0].type === "ident" && (me.has(t[0].name) || S.has(t[0].name)) || t.length === 1 && t[0].type === "function" && t[0].name === "var" && U(t[0].text.slice(t[0].text.indexOf("(") + 1, -1)).length === 1) return e;
		throw C("theme.css", "unsupported font shorthand; use an explicit font size (including calc/min/max/clamp) and a family list.");
	}
	let a = K(n.slice(i), t);
	return n.slice(0, i) + a + r;
}
function q(e, t = !1, n = 0) {
	if (n > 64) throw C("theme.css", "nested font declarations exceed 64 levels.");
	let r = [], i = (i) => {
		let a = P(e, i + 1);
		if (t) for (let t of q(e.slice(i + 1, a), !0, n + 1)) r.push({
			name: t.name,
			valueStart: i + 1 + t.valueStart,
			valueEnd: i + 1 + t.valueEnd
		});
		return Math.min(a + 1, e.length);
	}, a = 0;
	for (; a < e.length && (a = N(e, a), !(a >= e.length));) {
		if (e[a] === ";" || e[a] === "}") {
			a += 1;
			continue;
		}
		if (e[a] === "{") {
			a = i(a);
			continue;
		}
		let t = a, n = a;
		for (; n < e.length;) {
			let t = e[n];
			if (t === "\"" || t === "'") n = k(e, n);
			else if (t === "/" && e[n + 1] === "*") n = N(e, n);
			else if (t === "(" || t === "[") n = A(e, n, t, t === "(" ? ")" : "]");
			else {
				if (t === ":" || t === ";" || t === "{" || t === "}") break;
				n += 1;
			}
		}
		if (n >= e.length) break;
		if (e[n] !== ":") {
			a = e[n] === "{" ? i(n) : n + 1;
			continue;
		}
		let o = B(e.slice(t, n)), s = o.length === 1 && o[0].type === "ident" ? o[0] : void 0, c = s?.text ?? "", l = c.startsWith("--") ? c : c.toLowerCase(), u = n + 1, d = u;
		for (; d < e.length;) {
			let t = e[d];
			if (t === "\"" || t === "'") d = k(e, d);
			else if (t === "/" && e[d + 1] === "*") d = N(e, d);
			else if (t === "(" || t === "[") d = A(e, d, t, t === "(" ? ")" : "]");
			else if (t === "{" && c.startsWith("--")) d = P(e, d + 1) + 1;
			else {
				if (t === ";" || t === "{" || t === "}") break;
				d += 1;
			}
		}
		e[d] === "{" ? a = i(d) : (s && r.push({
			name: l,
			valueStart: u,
			valueEnd: d
		}), a = d, e[d] === ";" && (a += 1));
	}
	return r;
}
function Me(e, t) {
	if (t.size === 0) return e;
	let n = [];
	for (let r of q(e, !0)) {
		let i = r.name === "font-family" || r.name === "--font-sans" || r.name === "--font-mono";
		if (!i && r.name !== "font") continue;
		let a = e.slice(r.valueStart, r.valueEnd), o = i ? K(a, t) : je(a, t);
		o !== a && n.push({
			start: r.valueStart,
			end: r.valueEnd,
			text: o
		});
	}
	return G(e, n);
}
function Ne(e, t, n) {
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (/\s/.test(i) || i === ";" || i === "}") {
			r += 1;
			continue;
		}
		if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
			continue;
		}
		if (i === "{") {
			r = P(e, r + 1) + 1;
			continue;
		}
		let a = r, o = r;
		for (; o < e.length;) {
			let t = e[o];
			if (t === "\"" || t === "'") o = k(e, o);
			else if (t === "/" && e[o + 1] === "*") {
				let t = e.indexOf("*/", o + 2);
				o = t < 0 ? e.length : t + 2;
			} else if (t === "(" || t === "[") o = A(e, o, t, t === "(" ? ")" : "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				o += 1;
			}
		}
		if (o >= e.length) break;
		if (e[o] !== "{") {
			r = o + 1;
			continue;
		}
		let s = P(e, o + 1), c = e.slice(a, o).trim();
		if (c.startsWith("@")) {
			let r = (/^@([A-Za-z-]+)/.exec(c)?.[1] ?? "").toLowerCase();
			r === "font-face" ? n(e.slice(o + 1, s), t) : x.has(r) && Ne(e.slice(o + 1, s), t, n);
		}
		r = Math.min(s + 1, e.length);
	}
}
function Pe(e, t) {
	let n = q(e).filter((e) => e.name === "font-family");
	if (n.length === 0) throw C(t, "@font-face must declare a font-family descriptor.");
	if (n.length > 1) throw C(t, "@font-face may declare font-family only once.");
	let { body: r, important: i } = W(e.slice(n[0].valueStart, n[0].valueEnd));
	if (i !== "") throw C(t, "@font-face descriptors must not use !important.");
	if (U(r).length !== 1) throw C(t, "@font-face font-family must be a single family name, not a list.");
	let a = H(r);
	if (!a) throw C(t, "@font-face font-family must be one quoted or unquoted family name; generic families, keywords, var() and other functions are not allowed.");
	if (I(L(a.key)?.original ?? a.key).length > fe) throw C(t, `@font-face font-family must not exceed ${fe} UTF-8 bytes.`);
	return a.key;
}
function Fe(e, t, n) {
	let r = /* @__PURE__ */ new Map();
	for (let i of e) Ne(i.css, n, (e, n) => {
		let i = Pe(e, n), a = L(i), o = a ? a.original : i, s = De(t, o), c = r.get(i);
		if (c !== void 0 && c !== s) throw C(n, `@font-face family "${i}" maps to more than one name.`);
		r.set(i, s), r.set(o, s);
	});
	return r;
}
function Ie(e, t, n) {
	let r = q(e).filter((e) => e.name === "font-family");
	if (r.length !== 1) throw C(n, "@font-face must declare exactly one font-family descriptor.");
	let i = r[0], { body: a } = W(e.slice(i.valueStart, i.valueEnd));
	if (U(a).length !== 1) throw C(n, "@font-face font-family must be a single family name, not a list.");
	let o = H(a);
	if (!o) throw C(n, "@font-face has an unsupported font-family descriptor.");
	let s = t.get(o.key);
	if (s === void 0) throw C(n, `@font-face family "${o.key}" was not registered.`);
	return G(e, [{
		start: i.valueStart + o.start,
		end: i.valueStart + o.end,
		text: ke(s)
	}]);
}
var Le = /* @__PURE__ */ new Map();
function Re(e, t, n = Le) {
	let r = "", i = 0;
	for (; i < e.length;) {
		let a = e[i];
		if (a === "/" && e[i + 1] === "*") {
			let t = e.indexOf("*/", i + 2), n = t < 0 ? e.length : t + 2;
			r += e.slice(i, n), i = n;
			continue;
		}
		if (/\s/.test(a) || a === ";" || a === "}") {
			r += a, i += 1;
			continue;
		}
		let o = i, s = i;
		for (; s < e.length;) {
			let t = e[s];
			if (t === "\"" || t === "'") s = k(e, s);
			else if (t === "/" && e[s + 1] === "*") {
				let t = e.indexOf("*/", s + 2);
				s = t < 0 ? e.length : t + 2;
			} else if (t === "(") s = A(e, s, "(", ")");
			else if (t === "[") s = A(e, s, "[", "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				s += 1;
			}
		}
		if (s >= e.length) {
			r += e.slice(o);
			break;
		}
		let c = e.slice(o, s), l = e[s];
		if (l === ";" || l === "}") {
			r += c + l, i = s + 1;
			continue;
		}
		let u = P(e, s + 1), d = e.slice(s + 1, u), f = c.trim();
		if (f.startsWith("@")) {
			let e = (/^@([A-Za-z-]+)/.exec(f)?.[1] ?? "").toLowerCase();
			if (e === "import") throw C("theme.css", "must not use @import.");
			if (e === "keyframes" || e.endsWith("-keyframes")) throw C("theme.css", `@${e} declares a global name; phase one only supports document-scoped CSS.`);
			if (e === "font-face") r += `${f} {${Ie(d, n, "theme.css")}}`;
			else {
				let i = x.has(e) ? Re(d, t, n) : d;
				r += `${f} {${i}}`;
			}
		} else r += `${Te(f, t)} {${Me(d, n)}}`;
		i = Math.min(u + 1, e.length);
	}
	return r;
}
function J(e, t, n = Le) {
	return Re(e, t, n);
}
function Y(e, t) {
	if (!Array.isArray(e)) throw C(t, "must be an array of { id, css } resources.");
	if (e.length > oe) throw C(t, `may contain at most ${oe} resources.`);
	let n = /* @__PURE__ */ new Set(), r = [], i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a], s = `${t}[${a}]`;
		if (!_e(o)) throw C(s, "must be an object.");
		let c = o.id;
		if (typeof c != "string" || c.length === 0) throw C(`${s}.id`, "must be a non-empty string.");
		if (c.length > se) throw C(`${s}.id`, `must not exceed ${se} characters.`);
		if (!le.test(c)) throw C(`${s}.id`, `"${c}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (n.has(c)) throw C(`${s}.id`, `"${c}" is declared more than once.`);
		n.add(c);
		let l = o.css;
		if (typeof l != "string") throw C(`${s}.css`, "must be a string.");
		if (l.length > v) throw C(`${s}.css`, `must not exceed ${v} characters.`);
		if (i += l.length, i > y) throw C(t, `must not exceed ${y} characters in total.`);
		j(l, `${s}.css`), r.push(Object.freeze({
			id: c,
			css: l
		}));
	}
	return {
		resources: Object.freeze(r),
		totalLength: i
	};
}
function X(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		protocol: e.protocol,
		colorSchemes: Object.freeze([...e.colorSchemes]),
		css: Object.freeze(e.css.map((e) => Object.freeze({
			id: e.id,
			css: e.css
		})))
	});
}
function ze(e, t) {
	let n = w(e, t), r = T(n.id, `${t}.id`), i = E(n.name, `${t}.name`), a = D(n.version, `${t}.version`);
	if (n.protocol !== "reactive-md-theme-1") throw C(`${t}.protocol`, `must be "${h}".`);
	let o = O(n.colorSchemes, `${t}.colorSchemes`), { resources: s } = Y(n.css, `${t}.css`);
	return X({
		id: r,
		name: i,
		version: a,
		protocol: h,
		colorSchemes: o,
		css: s
	});
}
function Be(e) {
	let t = w(e, "input"), n = T(t.id, "theme.id"), r = E(t.name, "theme.name"), i = D(t.version, "theme.version");
	if ((t.protocol === void 0 ? "reactive-md-theme-1" : t.protocol) !== "reactive-md-theme-1") throw C("theme.protocol", `must be "${h}".`);
	let a = O(t.colorSchemes, "theme.colorSchemes"), { resources: o } = Y(t.css, "theme.css"), s = Fe(o, r, "theme.css");
	return X({
		id: n,
		name: r,
		version: i,
		protocol: h,
		colorSchemes: a,
		css: o.map((e) => Object.freeze({
			id: e.id,
			css: J(e.css, r, s)
		}))
	});
}
function Ve(e) {
	let t = w(e, "input"), n = T(t.id, "theme.id"), r = E(t.name, "theme.name"), i = D(t.version, "theme.version"), a = ze(t.base, "theme.base"), o = Y(t.overrides, "theme.overrides"), s = Fe([...a.css, ...o.resources], r, "theme.css"), c = new Set(a.css.map((e) => e.id));
	for (let e of o.resources) {
		if (c.has(e.id)) throw C("theme.overrides", `resource "${e.id}" is already declared by the base theme.`);
		c.add(e.id);
	}
	let l = [...a.css.map((e) => Object.freeze({
		id: e.id,
		css: J(e.css, r, s)
	})), ...o.resources.map((e) => Object.freeze({
		id: e.id,
		css: J(e.css, r, s)
	}))], u = 0;
	for (let e of l) if (u += e.css.length, u > y) throw C("theme.css", `must not exceed ${y} characters in total.`);
	return X({
		id: n,
		name: r,
		version: i,
		protocol: a.protocol,
		colorSchemes: a.colorSchemes,
		css: l
	});
}
function He(e) {
	let { resources: t } = Y(w(e, "theme").css, "theme.css");
	return t.map((e) => e.css).join("\n");
}
// src/sdk/config.ts
var Ue = m.id, We = m.version, Ge = Object.freeze({
	id: Ue,
	version: We
}), Ke = 16, qe = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"themes"
]), Je = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"colorSchemes",
	"css"
]), Z = /* @__PURE__ */ new WeakSet();
function Ye(e) {
	d(e) || a("themes", "each theme must be an object."), f(e, Je, "theme");
	try {
		return Be(e);
	} catch (e) {
		a("theme", e instanceof Error ? e.message : String(e));
	}
}
function Xe(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || a("themes", "must be an array."), e.length > 16 && a("themes", "accepts at most 16 themes.");
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = Ye(i);
		t.has(e.id) && a("themes", `theme id "${e.id}" is declared more than once.`), n.has(e.name) && a("themes", `theme name "${e.name}" is declared more than once.`), t.add(e.id), n.add(e.name), r.push(e);
	}
	return Object.freeze(r);
}
function Ze(n, r) {
	d(n) || a(r, "must be an object."), f(n, qe, r);
	let i = o(n.presets, Ge), s = ee(n.components, m.components), l = Xe(n.themes);
	e({
		protocol: "reactive-md-config/v1",
		presets: i,
		components: s,
		themes: l
	}) > 16777216 && a(r, `serialized size exceeds the ${u}-byte budget.`);
	let p = Object.freeze({
		protocol: t,
		key: c(i, s),
		presets: i,
		components: s,
		registry: Object.freeze([...m.components, ...s]),
		themes: l
	});
	return Z.add(p), p;
}
function Qe(e = {}) {
	return Ze(e, "config");
}
var $e;
function et(e) {
	return e === void 0 ? $e ??= Qe().key : Q(e).key;
}
function tt(e, t) {
	return e.componentConfigKey === void 0 || e.componentConfigKey === et(t) ? [] : [{
		code: "local.extension.config-mismatch",
		severity: "error",
		message: "The document compiler configuration differs from the installed renderer. Recompile with the same host.config used by host.reactConfig (including Worker requests).",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}];
}
function Q(e) {
	return typeof e == "object" && e && Z.has(e) ? e : (d(e) || a("config", "must be an object."), f(e, p, "config"), e.protocol !== "reactive-md-config/v1" && a("config.protocol", `must be "${t}".`), Ze({
		presets: e.presets,
		components: e.components,
		themes: e.themes
	}, "config"));
}
function nt(e) {
	if (typeof e == "object" && e && Z.has(e)) return e.key;
	try {
		return Q(e).key;
	} catch {
		try {
			return `invalid:${n(JSON.stringify(e))}`;
		} catch {
			return "invalid";
		}
	}
}
function rt(e) {
	try {
		return Q(e);
	} catch {
		return e;
	}
}
// src/sdk/registry.ts
function it() {
	return te;
}
function $(e) {
	return e ? Q(e).registry : it();
}
function at(e, t) {
	let n = $(t);
	for (let t of n) if (t.name === e) return t;
}
function ot(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of $(e)) t.set(n.name, l(n));
	return t;
}
export { g as _, We as a, et as c, rt as d, tt as f, xe as g, Be as h, Ue as i, nt as l, Ve as m, $ as n, Ke as o, He as p, ot as r, Qe as s, at as t, Q as u, h as v, ae as y };
