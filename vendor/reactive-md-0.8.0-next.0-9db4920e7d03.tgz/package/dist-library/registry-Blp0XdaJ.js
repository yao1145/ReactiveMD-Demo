import { C as e, D as t, L as n } from "./manifest-gj41AWZb.js";
import { K as r, U as i, a, c as o, f as s, i as c, l, n as u, o as d, r as f, s as ee, t as p } from "./config-validation-DaLdxnS1.js";
import { n as te, t as m } from "./default-d2u6mrJW.js";
// src/local/theme/theme.ts
var h = "reactive-md-theme-1", g = Object.freeze({
	name: "default",
	protocol: h,
	colorSchemes: Object.freeze(["light", "dark"])
});
function ne(e, t) {
	let n = typeof t == "string" ? t.length : Infinity;
	if (!e || typeof e.start != "number" || typeof e.end != "number" || !Number.isFinite(e.start) || !Number.isFinite(e.end)) return {
		start: 0,
		end: 0
	};
	let r = Math.max(0, Math.min(n, Math.floor(e.start)));
	return {
		start: r,
		end: Math.max(r, Math.min(n, Math.floor(e.end)))
	};
}
function re(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.min(t, e.length), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: t - i + 1
	};
}
function ie(e, t, n, r) {
	let a = ne(n, r), { line: o, column: s } = re(r, a.start);
	return {
		code: e,
		message: i(t),
		severity: "warning",
		range: a,
		line: o,
		column: s,
		messageKey: t.key,
		...t.params ? { params: t.params } : {}
	};
}
function ae(e, t, n, i) {
	let a = (e, t) => ({
		name: g.name,
		diagnostics: [ie(e, t, n, i)]
	}), o = e;
	if (o == null || o === "") return {
		name: g.name,
		diagnostics: []
	};
	if (!s(o)) return a("local.theme.name", r("local.theme.name", {
		name: String(o),
		limit: 64
	}));
	let c = o;
	if (c === g.name) return {
		name: g.name,
		diagnostics: []
	};
	if (!Array.isArray(t)) return a("local.theme.missing", r("local.theme.missing", { name: c }));
	let l = 0, u = null;
	try {
		for (let e of t) typeof e == "object" && e && !Array.isArray(e) && e.name === c && (l += 1, u = e);
	} catch {
		return a("local.theme.manifest", r("local.theme.manifest.unreadable"));
	}
	if (l === 0) return a("local.theme.missing", r("local.theme.missing", { name: c }));
	if (l > 1) return a("local.theme.duplicate", r("local.theme.duplicate", { name: c }));
	try {
		let e = u;
		if (!e || typeof e != "object") return a("local.theme.manifest", r("local.theme.manifest.definition", { name: c }));
		if (e.protocol !== "reactive-md-theme-1") return a("local.theme.protocol", r("local.theme.protocol", {
			name: c,
			protocol: h
		}));
		let t = e.colorSchemes;
		if (!Array.isArray(t) || !t.includes("light") || !t.includes("dark")) return a("local.theme.modes", r("local.theme.modes", { name: c }));
	} catch {
		return a("local.theme.manifest", r("local.theme.manifest.selected", { name: c }));
	}
	return {
		name: c,
		diagnostics: []
	};
}
// src/sdk/theme.ts
var _ = 128, v = 32, y = 128, b = 262144, x = 524288, oe = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/, se = /^[a-z][a-z0-9._/-]*$/, ce = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/, S = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/, le = /^(?::root|html|body)(?![A-Za-z0-9_-])/i, ue = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]);
function C(e, t) {
	return /* @__PURE__ */ Error(`Invalid local theme ${e}: ${t}`);
}
function w(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function T(e, t) {
	if (!w(e)) throw C(t, "must be an object.");
	return e;
}
function E(e, t) {
	if (typeof e != "string" || e.length === 0) throw C(t, "must be a non-empty string.");
	if (e.length > _) throw C(t, `must not exceed ${_} characters.`);
	if (!oe.test(e)) throw C(t, `"${e}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return e;
}
function D(e, t) {
	if (!s(e)) throw C(t, "must be a lowercase kebab-case name that starts with a letter.");
	if (e === "default") throw C(t, "must not replace the reserved built-in \"default\" theme.");
	return e;
}
function O(e, t) {
	if (typeof e != "string" || !ce.test(e)) throw C(t, "must be a semantic version such as \"1.0.0\".");
	return e;
}
function k(e, t) {
	if (e === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(e)) throw C(t, "must be an array of \"light\" and \"dark\".");
	let n = [];
	for (let r of e) {
		if (r !== "light" && r !== "dark") throw C(t, "may only contain \"light\" and \"dark\".");
		if (n.includes(r)) throw C(t, `must not repeat "${r}".`);
		n.push(r);
	}
	if (!n.includes("light") || !n.includes("dark")) throw C(t, "must declare both \"light\" and \"dark\".");
	return Object.freeze(n);
}
function A(e, t) {
	let n = e[t], r = t + 1;
	for (; r < e.length;) if (e[r] === "\\") r += 2;
	else {
		if (e[r] === n) return r + 1;
		r += 1;
	}
	return e.length;
}
function j(e, t, n, r) {
	let i = 0;
	for (let a = t; a < e.length; a += 1) {
		let t = e[a];
		if (t === "\"" || t === "'") a = A(e, a) - 1;
		else if (t === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === n) i += 1;
		else if (t === r && (--i, i === 0)) return a + 1;
	}
	return e.length;
}
function de(e, t, n) {
	let r = t + 3;
	for (; r < e.length && /\s/.test(e[r]);) r += 1;
	if (e[r] !== "(") throw C(n, "has a malformed url() value.");
	for (r += 1; r < e.length && /\s/.test(e[r]);) r += 1;
	let i = e[r];
	if (i === "\"" || i === "'") {
		let t = e.indexOf(i, r + 1);
		if (t < 0) throw C(n, "has an unterminated url() string.");
		let a = e.slice(r + 1, t);
		for (r = t + 1; r < e.length && /\s/.test(e[r]);) r += 1;
		if (e[r] !== ")") throw C(n, "has a malformed url() value.");
		return {
			value: a.trim(),
			end: r + 1
		};
	}
	let a = e.indexOf(")", r);
	if (a < 0) throw C(n, "has an unterminated url() value.");
	return {
		value: e.slice(r, a).trim(),
		end: a + 1
	};
}
function fe(e, t, n, r) {
	let i = t;
	for (; i < e.length && e[i] !== "(";) i += 1;
	if (i >= e.length) throw C(r, `has a malformed ${n}() value.`);
	let a = j(e, i, "(", ")");
	if (a <= i + 1 || e[a - 1] !== ")") throw C(r, `has an unterminated ${n}() value.`);
	return {
		body: e.slice(i + 1, a - 1),
		end: a
	};
}
function pe(e, t) {
	let n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (r === "\"" || r === "'") {
			let i = A(e, n);
			if (i > e.length || e[i - 1] !== r) throw C(t, "has an unterminated image-set() string.");
			let a = e.slice(n + 1, i - 1).trim();
			if (!/^data:/i.test(a)) throw C(t, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			n = i;
		} else if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else n += 1;
	}
}
function M(e, t, n = !1) {
	if (e.toLowerCase().includes("</style")) throw C(t, "must not contain a closing style tag.");
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = A(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else {
			if (i === "\\") throw C(t, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
			if (i === "@" && /^@import\b/i.test(e.slice(r, r + 8))) throw C(t, "must not use @import; inline every resource.");
			if ((i === "i" || i === "I" || i === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(e.slice(r, r + 24))) {
				let { body: n } = fe(e, r, "image-set", t);
				pe(n, t), r += 1;
			} else if ((i === "u" || i === "U") && /^url\s*\(/i.test(e.slice(r, r + 12))) {
				let i = de(e, r, t);
				if (!/^data:/i.test(i.value) && !(n && i.value.startsWith("#"))) throw C(t, "may only reference data: URLs; network and file URLs are not allowed.");
				r = i.end;
			} else {
				if ((i === "e" || i === "E") && /^expression\s*\(/i.test(e.slice(r, r + 16))) throw C(t, "must not use CSS expression().");
				r += 1;
			}
		}
	}
}
function me(e) {
	if (typeof e != "string" || e.length > 4194304) return !1;
	try {
		return M(e, "css", !0), !0;
	} catch {
		return !1;
	}
}
function N(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		if (o === "\"" || o === "'") a = A(e, a) - 1;
		else if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else o === "\\" ? a += 1 : o === "(" ? r += 1 : o === ")" ? r = Math.max(0, r - 1) : o === "[" ? i += 1 : o === "]" ? i = Math.max(0, i - 1) : o === "," && r === 0 && i === 0 && (t.push(e.slice(n, a)), n = a + 1);
	}
	return t.push(e.slice(n)), t;
}
function P(e, t) {
	let n = e.trim(), r = `[data-rmd-theme="${t}"]`, i = S.exec(n);
	return i ? `${r}${n.slice(i[0].length)}` : `${r} ${n}`;
}
function F(e, t) {
	let n = t;
	for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
	else if (e[n] === "/" && e[n + 1] === "*") {
		let t = e.indexOf("*/", n + 2);
		n = t < 0 ? e.length : t + 2;
	} else break;
	return n;
}
function I(e, t) {
	let n = e.toLowerCase(), r = /:has\s*\(/g;
	for (let i = r.exec(n); i; i = r.exec(n)) {
		if (r.lastIndex = i.index + 1, i.index >= t) continue;
		let n = i.index + i[0].length - 1, a = j(e, n, "(", ")"), o = e.slice(n + 1, Math.max(n + 1, a - 1));
		for (let t of N(o)) if (/^\s*[+~]/.test(t)) throw C("theme.css", `selector "${e.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
function L(e) {
	let t = e.trim();
	if (t === "") return;
	if (t[0] === "+" || t[0] === "~") throw C("theme.css", `selector "${t}" begins with a sibling combinator and cannot be scoped.`);
	let n = S.exec(t);
	if (n) {
		let e = n[0].length;
		for (; e < t.length;) {
			let n = t[e];
			if (/\s/.test(n) || n === "+" || n === "~" || n === ">" || n === ",") break;
			n === "[" ? e = j(t, e, "[", "]") : n === "(" ? e = j(t, e, "(", ")") : e += 1;
		}
		let r = F(t, e);
		if (t[r] === "+" || t[r] === "~") throw C("theme.css", `selector "${t}" uses a sibling combinator that can escape the theme root.`);
		I(t, e);
	}
}
function R(e, t) {
	let n = N(e).map((e) => e.trim()).filter(Boolean);
	if (n.length === 0) return e.trim();
	for (let e of n) {
		if (le.test(e)) throw C("theme.css", `selector "${e}" targets the host document; scope it under the theme root instead.`);
		L(e);
	}
	return n.map((e) => P(e, t)).join(", ");
}
function z(e, t) {
	let n = 1;
	for (let r = t; r < e.length; r += 1) {
		let t = e[r];
		if (t === "\"" || t === "'") r = A(e, r) - 1;
		else if (t === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return r;
	}
	return e.length;
}
function B(e, t) {
	let n = "", r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2), i = t < 0 ? e.length : t + 2;
			n += e.slice(r, i), r = i;
			continue;
		}
		if (/\s/.test(i) || i === ";" || i === "}") {
			n += i, r += 1;
			continue;
		}
		let a = r, o = r;
		for (; o < e.length;) {
			let t = e[o];
			if (t === "\"" || t === "'") o = A(e, o);
			else if (t === "/" && e[o + 1] === "*") {
				let t = e.indexOf("*/", o + 2);
				o = t < 0 ? e.length : t + 2;
			} else if (t === "(") o = j(e, o, "(", ")");
			else if (t === "[") o = j(e, o, "[", "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				o += 1;
			}
		}
		if (o >= e.length) {
			n += e.slice(a);
			break;
		}
		let s = e.slice(a, o), c = e[o];
		if (c === ";" || c === "}") {
			n += s + c, r = o + 1;
			continue;
		}
		let l = z(e, o + 1), u = e.slice(o + 1, l), d = s.trim();
		if (d.startsWith("@")) {
			let e = (/^@([A-Za-z-]+)/.exec(d)?.[1] ?? "").toLowerCase();
			if (e === "import") throw C("theme.css", "must not use @import.");
			if (e === "font-face" || e === "keyframes" || e.endsWith("-keyframes")) throw C("theme.css", `@${e} declares a global name; phase one only supports document-scoped CSS.`);
			let r = ue.has(e) ? B(u, t) : u;
			n += `${d} {${r}}`;
		} else n += `${R(d, t)} {${u}}`;
		r = Math.min(l + 1, e.length);
	}
	return n;
}
function V(e, t) {
	return B(e, t);
}
function H(e, t, n) {
	if (!Array.isArray(e)) throw C(t, "must be an array of { id, css } resources.");
	if (e.length > v) throw C(t, `may contain at most ${v} resources.`);
	let r = /* @__PURE__ */ new Set(), i = [], a = 0;
	for (let o = 0; o < e.length; o += 1) {
		let s = e[o], c = `${t}[${o}]`;
		if (!w(s)) throw C(c, "must be an object.");
		let l = s.id;
		if (typeof l != "string" || l.length === 0) throw C(`${c}.id`, "must be a non-empty string.");
		if (l.length > y) throw C(`${c}.id`, `must not exceed ${y} characters.`);
		if (!se.test(l)) throw C(`${c}.id`, `"${l}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (r.has(l)) throw C(`${c}.id`, `"${l}" is declared more than once.`);
		r.add(l);
		let u = s.css;
		if (typeof u != "string") throw C(`${c}.css`, "must be a string.");
		if (u.length > b) throw C(`${c}.css`, `must not exceed ${b} characters.`);
		if (a += u.length, a > x) throw C(t, `must not exceed ${x} characters in total.`);
		M(u, `${c}.css`), i.push(Object.freeze({
			id: l,
			css: n === null ? u : V(u, n)
		}));
	}
	return {
		resources: Object.freeze(i),
		totalLength: a
	};
}
function U(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		protocol: e.protocol,
		colorSchemes: Object.freeze([...e.colorSchemes]),
		css: Object.freeze(e.css.map((e) => Object.freeze({
			id: e.id,
			css: e.css
		})))
	});
}
function he(e, t) {
	let n = T(e, t), r = E(n.id, `${t}.id`), i = D(n.name, `${t}.name`), a = O(n.version, `${t}.version`);
	if (n.protocol !== "reactive-md-theme-1") throw C(`${t}.protocol`, `must be "${h}".`);
	let o = k(n.colorSchemes, `${t}.colorSchemes`), { resources: s } = H(n.css, `${t}.css`, null);
	return U({
		id: r,
		name: i,
		version: a,
		protocol: h,
		colorSchemes: o,
		css: s
	});
}
function W(e) {
	let t = T(e, "input"), n = E(t.id, "theme.id"), r = D(t.name, "theme.name"), i = O(t.version, "theme.version");
	if ((t.protocol === void 0 ? "reactive-md-theme-1" : t.protocol) !== "reactive-md-theme-1") throw C("theme.protocol", `must be "${h}".`);
	let a = k(t.colorSchemes, "theme.colorSchemes"), { resources: o } = H(t.css, "theme.css", r);
	return U({
		id: n,
		name: r,
		version: i,
		protocol: h,
		colorSchemes: a,
		css: o
	});
}
function ge(e) {
	let t = T(e, "input"), n = E(t.id, "theme.id"), r = D(t.name, "theme.name"), i = O(t.version, "theme.version"), a = he(t.base, "theme.base"), o = H(t.overrides, "theme.overrides", r), s = new Set(a.css.map((e) => e.id));
	for (let e of o.resources) {
		if (s.has(e.id)) throw C("theme.overrides", `resource "${e.id}" is already declared by the base theme.`);
		s.add(e.id);
	}
	let c = [...a.css.map((e) => Object.freeze({
		id: e.id,
		css: V(e.css, r)
	})), ...o.resources], l = 0;
	for (let e of c) if (l += e.css.length, l > x) throw C("theme.css", `must not exceed ${x} characters in total.`);
	return U({
		id: n,
		name: r,
		version: i,
		protocol: a.protocol,
		colorSchemes: a.colorSchemes,
		css: c
	});
}
function _e(e) {
	let { resources: t } = H(T(e, "theme").css, "theme.css", null);
	return t.map((e) => e.css).join("\n");
}
// src/sdk/config.ts
var G = m.id, K = m.version, ve = Object.freeze({
	id: G,
	version: K
}), ye = 16, be = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"themes"
]), xe = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"colorSchemes",
	"css"
]), q = /* @__PURE__ */ new WeakSet();
function Se(e) {
	d(e) || a("themes", "each theme must be an object."), f(e, xe, "theme");
	try {
		return W(e);
	} catch (e) {
		a("theme", e instanceof Error ? e.message : String(e));
	}
}
function Ce(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || a("themes", "must be an array."), e.length > 16 && a("themes", "accepts at most 16 themes.");
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = Se(i);
		t.has(e.id) && a("themes", `theme id "${e.id}" is declared more than once.`), n.has(e.name) && a("themes", `theme name "${e.name}" is declared more than once.`), t.add(e.id), n.add(e.name), r.push(e);
	}
	return Object.freeze(r);
}
function J(n, r) {
	d(n) || a(r, "must be an object."), f(n, be, r);
	let i = o(n.presets, ve), s = ee(n.components, m.components), l = Ce(n.themes);
	e({
		protocol: "reactive-md-config/v1",
		presets: i,
		components: s,
		themes: l
	}) > 16777216 && a(r, `serialized size exceeds the ${u}-byte budget.`);
	let p = Object.freeze({
		protocol: t,
		key: c(i, s),
		presets: i,
		components: s,
		registry: Object.freeze([...m.components, ...s]),
		themes: l
	});
	return q.add(p), p;
}
function Y(e = {}) {
	return J(e, "config");
}
var X;
function Z(e) {
	return e === void 0 ? X ??= Y().key : Q(e).key;
}
function we(e, t) {
	return e.componentConfigKey === void 0 || e.componentConfigKey === Z(t) ? [] : [{
		code: "local.extension.config-mismatch",
		severity: "error",
		message: "The document compiler configuration differs from the installed renderer. Recompile with the same host.config used by host.reactConfig (including Worker requests).",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}];
}
function Q(e) {
	return typeof e == "object" && e && q.has(e) ? e : (d(e) || a("config", "must be an object."), f(e, p, "config"), e.protocol !== "reactive-md-config/v1" && a("config.protocol", `must be "${t}".`), J({
		presets: e.presets,
		components: e.components,
		themes: e.themes
	}, "config"));
}
function Te(e) {
	if (typeof e == "object" && e && q.has(e)) return e.key;
	try {
		return Q(e).key;
	} catch {
		try {
			return `invalid:${n(JSON.stringify(e))}`;
		} catch {
			return "invalid";
		}
	}
}
function Ee(e) {
	try {
		return Q(e);
	} catch {
		return e;
	}
}
// src/sdk/registry.ts
function De() {
	return te;
}
function $(e) {
	return e ? Q(e).registry : De();
}
function Oe(e, t) {
	let n = $(t);
	for (let t of n) if (t.name === e) return t;
}
function ke(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of $(e)) t.set(n.name, l(n));
	return t;
}
export { g as _, K as a, Z as c, Ee as d, we as f, me as g, W as h, G as i, Te as l, ge as m, $ as n, ye as o, _e as p, ke as r, Y as s, Oe as t, Q as u, h as v, ae as y };
