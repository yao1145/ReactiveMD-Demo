import { w as e } from "./validation-BXMN-r9R.js";
import { u as t } from "./registry-Blp0XdaJ.js";
import { n } from "./options-BAPXQP6a.js";
import { t as r } from "./compiler-po8Eq6NP.js";
import { t as i } from "./runtime-ndbtRhmt.js";
import { _ as a, d as o, h as s, i as c, u as l } from "./shareable-DlEiA5qt.js";
import { i as u, t as d } from "./resources-BthX3LbK.js";
import { t as f } from "./LocalDocumentView-DsRToPVy.js";
import { jsx as p } from "react/jsx-runtime";
import { createRoot as m, hydrateRoot as h } from "react-dom/client";
// src/standalone/diagnostics.ts
function g(e, t) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function _(e, t = 8) {
	let n = e.slice(0, t).map((e) => `- [${e.code}] ${e.message} (line ${e.line}, column ${e.column})`);
	return e.length > n.length && n.push(`- ${e.length - n.length} more diagnostic(s).`), n.join("\n");
}
function v(e) {
	return e instanceof Error ? e.message : String(e);
}
var y = class extends Error {
	diagnostics;
	constructor(e, t) {
		let n = _(t);
		super(n ? `${e}\n${n}` : e), this.name = "ReactiveMDMountError", this.diagnostics = t;
	}
};
function b(e, t = "standalone.mount") {
	if (typeof e == "object" && e && Array.isArray(e.diagnostics)) {
		let t = e.diagnostics;
		if (t.length > 0) return t;
	}
	return [g(t, v(e))];
}
// src/standalone/events.ts
var x = "reactive-md-diagnostics", S = "reactive-md-state-change", C = /^[A-Za-z][A-Za-z0-9_-]*$/, w = 256, T = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, E = /[\u0000-\u001f\u007f-\u009f]/, D = 64, O = 4096, k = 41943040;
function A(e, t) {
	if (e === void 0) return;
	if (!M(e)) {
		t("standalone.payload.images", "images must be a JSON object mapping image URLs to data URLs.");
		return;
	}
	let n = Object.entries(e);
	if (n.length > D) {
		t("standalone.payload.images", `images cannot contain more than ${D} entries.`);
		return;
	}
	let r = Object.create(null), i = 0;
	for (let [e, a] of n) if (!e || e.length > O || e === "__proto__" || E.test(e) || typeof a != "string" || !T.test(a)) t("standalone.payload.images", "Every image entry must use a bounded URL key and a base64 raster data URL.");
	else {
		if (i += a.length, i > k) {
			t("standalone.payload.images", "The embedded image map exceeds the 40 MiB budget.");
			return;
		}
		r[e] = a;
	}
	return r;
}
function j(e, t) {
	if (e === void 0) return;
	let r = n(e);
	if (!r.ok) t("standalone.payload.compile-options", `The payload compile options are invalid: ${r.message}`);
	else return o(e);
}
function M(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function N(e) {
	let t = [], n = (e, n) => {
		t.push(g(e, n));
	};
	if (!M(e)) return {
		ok: !1,
		diagnostics: [g("standalone.payload.shape", "The reactive-md payload must be a JSON object.")]
	};
	e.version !== 1 && e.version !== 2 && n("standalone.payload.version", "The reactive-md payload must use version 1 or 2."), e.version === 2 && e.restoration === void 0 && n("standalone.payload.requirements", "Version 2 requires restoration contracts."), e.version === 1 && (e.restoration !== void 0 || e.resources !== void 0) && n("standalone.payload.version", "Restoration contracts require payload version 2.");
	let r = e.target;
	typeof r != "string" || r.length === 0 || r.length > w ? n("standalone.payload.target", `The payload target must be an element id of 1-${w} characters.`) : C.test(r) || n("standalone.payload.target", "The payload target must start with a letter and use only letters, digits, underscores or hyphens.");
	let i = e.source;
	typeof i != "string" && n("standalone.payload.source", "The payload source must be a string.");
	let a = e.locale === void 0 ? "en" : e.locale;
	a !== "en" && a !== "zh" && n("standalone.payload.locale", "The payload locale must be \"en\" or \"zh\".");
	let o = e.colorScheme === void 0 ? "auto" : e.colorScheme;
	o !== "light" && o !== "dark" && o !== "auto" && n("standalone.payload.color-scheme", "The payload colorScheme must be \"light\", \"dark\" or \"auto\".");
	let s = e.hydrate !== void 0 && e.hydrate;
	typeof s != "boolean" && n("standalone.payload.hydrate", "The payload hydrate flag must be a boolean.");
	let c = e.state;
	M(c) || n("standalone.payload.state", "The payload state must be a JSON object.");
	let f = j(e.compileOptions, n);
	t.push(...u(e.extensions, f?.config));
	let p = d(e.resources ?? []);
	t.push(...p.diagnostics), t.push(...l(e.restoration, {
		config: f?.config,
		source: typeof i == "string" ? i : "",
		resources: p.resources
	}));
	let m = A(e.images, n);
	return t.length > 0 ? {
		ok: !1,
		diagnostics: t
	} : {
		ok: !0,
		payload: {
			version: e.version,
			target: r,
			source: i,
			state: c,
			locale: a,
			colorScheme: o,
			hydrate: s,
			...f === void 0 ? {} : { compileOptions: f },
			...e.extensions === void 0 ? {} : { extensions: e.extensions },
			...e.restoration === void 0 ? {} : {
				restoration: e.restoration,
				resources: p.resources
			},
			...m && Object.keys(m).length > 0 ? { images: m } : {}
		}
	};
}
function P(e) {
	try {
		return N(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [g("standalone.payload.invalid", `The reactive-md payload could not be read: ${v(e)}`)]
		};
	}
}
// src/standalone/prepare.ts
function F(t, i, o, s, l) {
	if (typeof t != "string") throw new y("Cannot mount a Reactive MD document: source must be a string.", [g("standalone.source", "source must be a string.")]);
	let u = r(t, s), d;
	if (u.ok) d = u.document;
	else {
		let r = n(s);
		if (!r.ok || !r.htmlActive) throw new y("Cannot mount a Reactive MD document: the source contains syntax errors.", u.diagnostics);
		d = {
			syntax: "local",
			syntaxVersion: e,
			source: t,
			html: r.html,
			initialState: {},
			bindings: {},
			nodes: [{
				type: "fallback",
				id: "local-0",
				range: {
					start: 0,
					end: t.length
				},
				value: t
			}]
		};
	}
	if (l?.(d), i !== void 0) {
		let e = a(i);
		if (!e.ok) throw new y("Cannot mount a Reactive MD document: the state payload is invalid.", e.diagnostics);
		let t = c(d, e.file);
		if (!t.ok) throw new y("Cannot mount a Reactive MD document: the state does not match this source.", t.diagnostics);
		d = t.baseline.document;
	}
	return typeof o == "string" && o.trim().length > 0 && (d = {
		...d,
		theme: o.trim(),
		themeRange: void 0
	}), {
		document: d,
		diagnostics: u.diagnostics.slice()
	};
}
var I = Object.freeze({
	name: "reactive-md-standalone",
	version: "0.4.0"
}), L = "data-reactive-md-mounted", R = "script[type=\"application/reactive-md+json\"][data-reactive-md-auto]", z = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, B = 64;
function V(e) {
	if (!e) return {};
	let t = /* @__PURE__ */ new Map();
	for (let [n, r] of Object.entries(e).slice(0, B)) typeof n == "string" && n.length > 0 && typeof r == "string" && z.test(r) && t.set(n, r);
	return t.size === 0 ? {} : {
		urlPolicy: (e, n) => n === "link" || t.has(e),
		imageResolver: (e) => t.get(e) ?? null
	};
}
var H = /* @__PURE__ */ new WeakSet();
function U(e) {
	return H.has(e) || e.hasAttribute("data-reactive-md-mounted");
}
function W(e, t) {
	return s(e, t);
}
function G(e) {
	if (e) try {
		e();
	} catch {}
}
function K(e) {
	let t = () => {
		let t = e.querySelector("article.local-document");
		t && (t.classList.remove("local-static-first", "reactive-md-static-first", "reactive-md-hydrating"), t.removeAttribute("data-static-first"), t.removeAttribute("data-reactive-md-static-first")), e.classList.remove("local-static-first", "reactive-md-static-first"), e.removeAttribute("data-static-first");
	};
	if (typeof requestAnimationFrame != "function") return t(), () => {};
	let n = 0, r = 0;
	return n = requestAnimationFrame(() => {
		t(), r = requestAnimationFrame(t);
	}), () => {
		typeof cancelAnimationFrame == "function" && (cancelAnimationFrame(n), r && cancelAnimationFrame(r));
	};
}
function q(e, n, r = {}) {
	if (!e || typeof e != "object" || !("nodeType" in e) || !e.hasAttribute) throw new y("Cannot mount a Reactive MD document: element must be an HTMLElement.", [g("standalone.element", "element must be an HTMLElement.")]);
	if (U(e)) throw new y("Cannot mount a Reactive MD document: this element is already mounted.", [g("standalone.mount", "The target element already hosts a Reactive MD document.")]);
	if (!n || typeof n != "object") throw new y("Cannot mount a Reactive MD document: options are required.", [g("standalone.options", "mount requires an options object with a source string.")]);
	let a = n.compileOptions;
	if (n.reactConfig) {
		if (a?.hostComponents !== void 0 || n.themes !== void 0) throw new y("Conflicting extension registration.", [g("local.extension.config", "reactConfig cannot be combined with hostComponents or themes.")]);
		if (a?.config && t(a.config).key !== n.reactConfig.config.key) throw new y("The export configuration differs from the installed bundle.", [g("local.extension.config", "Compile configuration does not match installed implementations.")]);
		a = {
			...a,
			config: n.reactConfig.config
		};
	}
	let o = u(n.extensions, n.reactConfig?.config);
	if (o.length) throw new y("Extension requirements are not satisfied.", o);
	let s = l(n.restoration, {
		config: n.reactConfig?.config ?? a?.config,
		source: n.source,
		resources: n.resources
	});
	if (s.length) throw new y("Restoration requirements are not satisfied.", s);
	let c = d(n.resources ?? []);
	if (c.diagnostics.length) throw new y("Style resources are invalid.", c.diagnostics);
	let _ = F(n.source, n.state, r.theme, a, (e) => {
		let t = u(e.extensions, n.reactConfig?.config);
		if (t.push(...l(n.restoration, {
			config: n.reactConfig?.config ?? a?.config,
			source: n.source,
			resources: n.resources,
			document: e
		})), t.length) throw new y("Installed contracts must match before state recovery.", t);
	}), x = u(_.document.extensions, n.reactConfig?.config);
	if (x.length) throw new y("Installed extension implementations are required.", x);
	let S;
	try {
		S = i(_.document);
	} catch (e) {
		throw new y("Cannot mount a Reactive MD document: the interactive runtime could not be created.", [g("standalone.runtime", v(e))]);
	}
	let C = n.generator ?? I, w = V(n.images), T = n.urlPolicy ?? w.urlPolicy, E = n.imageResolver ?? w.imageResolver, D = () => W(S, C), O;
	try {
		O = D();
	} catch (e) {
		try {
			S.dispose();
		} catch {}
		throw new y("Cannot mount a Reactive MD document: the initial state could not be captured.", [g("standalone.state", v(e))]);
	}
	let k = !1, A = (e) => {
		k || G(r.onDiagnostics ? () => r.onDiagnostics(e) : void 0);
	}, j = n.hydrate === !0 && e.hasChildNodes(), M = /* @__PURE__ */ p(f, {
		document: _.document,
		runtime: S,
		onDiagnostics: A,
		urlPolicy: T,
		locale: n.locale ?? "en",
		themes: n.themes,
		reactConfig: n.reactConfig,
		colorScheme: n.colorScheme ?? "auto",
		mode: "interactive",
		staticFirst: j,
		imageResolver: E
	});
	if (!j) for (; e.firstChild;) e.removeChild(e.firstChild);
	let N = null, P = [];
	try {
		for (let t of c.resources) {
			let n = e.ownerDocument.createElement("style");
			n.setAttribute("data-reactive-md-resource", t.id), n.textContent = t.css, (e.ownerDocument.head ?? e.ownerDocument.documentElement).appendChild(n), P.push(n);
		}
		N = j ? h(e, M) : m(e), j || N.render(M);
	} catch (e) {
		P.forEach((e) => e.remove());
		try {
			N?.unmount();
		} catch {}
		try {
			S.dispose();
		} catch {}
		throw new y("Cannot mount a Reactive MD document: React could not render the document.", b(e, "standalone.render"));
	}
	H.add(e), e.setAttribute(L, "");
	let R = r.onStateChange ? S.subscribe(() => {
		if (k) return;
		let e;
		try {
			e = D();
		} catch {
			return;
		}
		G(r.onStateChange ? () => r.onStateChange(e) : void 0);
	}) : () => {};
	G(r.onStateChange ? () => r.onStateChange(O) : void 0), _.diagnostics.length > 0 && A(_.diagnostics);
	let z = j ? K(e) : () => {};
	return {
		element: e,
		getState() {
			if (k) throw Error("This Reactive MD document has been unmounted.");
			return D();
		},
		unmount: () => {
			if (!k) {
				k = !0, R(), z(), P.forEach((e) => e.remove());
				try {
					N?.unmount();
				} catch {}
				try {
					S.dispose();
				} catch {}
				H.delete(e), e.getAttribute("data-reactive-md-mounted") === "" && e.removeAttribute(L);
			}
		}
	};
}
function J(e, t) {
	return q(e, t);
}
function Y(e, t, n) {
	if (typeof console < "u" && typeof console.error == "function") try {
		console.error(`Reactive MD: ${n.map((e) => `[${e.code}] ${e.message}`).join(" ")}`);
	} catch {}
	let r = e.defaultView?.CustomEvent;
	if (typeof r == "function") try {
		t.dispatchEvent(new r(x, {
			detail: n,
			bubbles: !0,
			composed: !0
		}));
	} catch {}
}
function X(e, t) {
	let n = t.defaultView?.HTMLElement;
	return n ? e instanceof n : e.namespaceURI === "http://www.w3.org/1999/xhtml";
}
function Z(e, t = {}) {
	if (typeof document > "u") return [];
	let n = e ?? document, r = n, i = r.nodeType === 9 ? n : r.ownerDocument ?? document, a = [], o;
	try {
		o = Array.from(n.querySelectorAll(R));
	} catch {
		return a;
	}
	for (let e of o) {
		let o;
		try {
			o = P(JSON.parse(e.textContent ?? ""));
		} catch (t) {
			Y(i, e, [g("standalone.payload.json", `The reactive-md payload is not valid JSON: ${v(t)}`)]);
			continue;
		}
		if (!o.ok) {
			Y(i, e, o.diagnostics);
			continue;
		}
		let s = o.payload, c = n, l = (typeof c.getElementById == "function" ? c.getElementById(s.target) : null) ?? i.getElementById(s.target);
		if (!l) Y(i, e, [g("standalone.target.missing", `The reactive-md payload target "#${s.target}" was not found.`)]);
		else if (r !== i && !r.contains(l)) Y(i, e, [g("standalone.target.scope", "The reactive-md payload target is outside the scanned root.")]);
		else if (!X(l, i)) Y(i, e, [g("standalone.target.type", "The reactive-md payload target must be an HTML element.")]);
		else if (!U(l)) try {
			a.push(J(l, {
				source: s.source,
				state: s.state,
				locale: s.locale,
				colorScheme: s.colorScheme,
				hydrate: s.hydrate,
				images: s.images,
				compileOptions: s.compileOptions,
				extensions: s.extensions,
				restoration: s.restoration,
				resources: s.resources,
				reactConfig: t.reactConfig
			}));
		} catch (e) {
			Y(i, l, b(e));
		}
	}
	return a;
}
export { x as REACTIVE_MD_DIAGNOSTICS_EVENT, L as REACTIVE_MD_MOUNTED_ATTRIBUTE, S as REACTIVE_MD_STATE_CHANGE_EVENT, y as ReactiveMDMountError, U as isReactiveMDMounted, J as mount, Z as mountAll, P as parseMountPayload };
