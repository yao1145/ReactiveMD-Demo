import { et as e } from "./manifest-gj41AWZb.js";
import { B as t, K as n, T as r, U as i, x as a } from "./config-validation-DaLdxnS1.js";
import { J as o, Q as s, Y as c, Z as l, a as u, at as d, c as f, et as p, i as m, n as h, nt as g, o as _, ot as v, r as ee, rt as y, t as b, tt as x, w as S } from "./validation-BXMN-r9R.js";
import { t as C } from "./registry-Blp0XdaJ.js";
import { S as te, T as w, n as T } from "./runtime-CXAWSoln.js";
// src/local/runtime/retention.ts
function E(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of l(e.nodes)) t.set(n.id, n);
	return t;
}
function D(e, t, n) {
	let r = e.bindingSlots?.[t.id];
	return r !== void 0 && Object.values(r).includes(n);
}
function O(e, t, n) {
	let r = t.name ? C(t.name) : void 0;
	if (r?.bindings) {
		let i = e.bindingSlots?.[t.id];
		for (let [e, a] of Object.entries(r.bindings)) if (t.attrs?.[a.bind] === n || e !== "value" && i?.[e] === n) return a.retain === !1 ? void 0 : a.initial;
	} else if (t.attrs?.bind === n || D(e, t, n)) return "initial";
}
function k(e) {
	let t = E(e), n = r(e), i = new Set(n?.retentionExclusions ?? []), a = /* @__PURE__ */ new Map();
	for (let [r, o] of Object.entries(e.bindings)) {
		let s = o.nodeIds.flatMap((e) => {
			let n = t.get(e);
			return n ? [n] : [];
		});
		if (!s.length || r.startsWith("@") || i.has(r)) continue;
		let c;
		if (n === void 0) {
			let t = s.map((t) => O(e, t, r));
			if (t.some((e) => e === void 0)) continue;
			c = t;
		} else {
			let e = n.bindingAttributes?.[r]?.initial ?? "initial";
			c = s.map(() => e);
		}
		let l = s.flatMap((e, t) => Object.hasOwn(e.attrs ?? {}, c[t]) ? [e.attrs[c[t]]] : []).sort();
		a.set(r, {
			type: o.type,
			initialDefinition: JSON.stringify([o.initial, l])
		});
	}
	return a;
}
function A(e, t) {
	return Object.freeze({
		name: e,
		reason: t
	});
}
function ne(e) {
	let t = k(e.previous), n = k(e.next), r = {}, i = [], a = [];
	for (let o of Object.keys(e.state).sort()) {
		if (o.startsWith("@")) {
			a.push(A(o, "internal"));
			continue;
		}
		if (!Object.hasOwn(e.previous.bindings, o) || !Object.hasOwn(e.next.bindings, o)) {
			a.push(A(o, "unknown"));
			continue;
		}
		let s = t.get(o), c = n.get(o);
		if (!s || !c) {
			a.push(A(o, "unretainable"));
			continue;
		}
		if (s.type !== c.type) {
			a.push(A(o, "type"));
			continue;
		}
		if (s.initialDefinition !== c.initialDefinition) {
			a.push(A(o, "initial"));
			continue;
		}
		let l = e.state[o];
		r[o] = Array.isArray(l) ? Object.freeze([...l]) : l, i.push(o);
	}
	return Object.freeze({
		values: Object.freeze(r),
		retained: Object.freeze(i),
		dropped: Object.freeze(a)
	});
}
function j(e, t, n) {
	return Object.freeze({
		retained: Object.freeze([...e]),
		dropped: Object.freeze(t.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...n])
	});
}
function M(e, t) {
	let n = Object.keys(t.values).sort();
	if (!e.setParameters(t.values).length) return j(n, t.dropped, []);
	let r = [], i = [...t.dropped], a = [];
	for (let o of n) {
		let n = e.setParameter(o, t.values[o]);
		n.length ? (i.push(A(o, "invalid")), a.push(...n)) : r.push(o);
	}
	return i.sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name)), j(r, i, a);
}
// src/local/runtime/runtime.ts
var N = 1e-9, re = 200;
function P(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function ie(e) {
	return {
		...e,
		range: { ...e.range }
	};
}
function F(e, t) {
	return Array.isArray(e) || Array.isArray(t) ? !Array.isArray(e) || !Array.isArray(t) || e.length !== t.length ? !1 : e.every((e, n) => e === t[n]) : e === t;
}
function I(e, t, n) {
	let r = (e - t) / n;
	return Math.abs(r - Math.round(r)) <= N * Math.max(1, Math.abs(r));
}
function ae(e) {
	for (let [t, n] of Object.entries(e)) Array.isArray(n) && !Object.isFrozen(n) && (e[t] = Object.freeze([...n]));
	return Object.freeze(e);
}
function L(e, t, n, r) {
	let a = Math.max(0, Math.min(e.source.length, t.range.start)), o = e.source.slice(0, a).split("\n");
	return {
		code: n,
		message: i(r),
		severity: "error",
		range: {
			start: a,
			end: Math.max(a + 1, Math.min(e.source.length, t.range.end))
		},
		line: o.length,
		column: (o.at(-1) ?? "").length + 1,
		messageKey: r.key,
		...r.params ? { params: r.params } : {}
	};
}
function R(e, t, n) {
	return {
		code: e,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1,
		...n ? {
			messageKey: n.key,
			...n.params ? { params: n.params } : {}
		} : {}
	};
}
function z(e, t) {
	return e.attrs?.[t];
}
function B(e, t) {
	let n = z(e, t);
	if (n === "true") return !0;
	if (n === "false") return !1;
}
function V(e, t) {
	let n = z(e, t);
	if (n === void 0) return;
	let r = Number(n);
	return Number.isFinite(r) ? r : void 0;
}
function H(e) {
	return v(e);
}
function U(e, t) {
	return {
		ok: !1,
		detail: n(e, t)
	};
}
function W(e, t) {
	if (t !== void 0) return z(e, t);
}
function G(e, t) {
	if (t !== void 0) return V(e, t);
}
function K(t, n, r, i = {}) {
	for (let o of r) if (o.kind === "date") {
		if (!a(n)) return U("local.runtime.value.date-invalid");
		let e = i.required ?? (o.required !== void 0 && B(t, o.required) === !0);
		if (n === "" && e) return U("local.runtime.value.date-required");
		let r = i.min ?? W(t, o.min), s = i.max ?? W(t, o.max);
		if (n !== "" && r && n < r) return U("local.runtime.value.date-earlier", { min: r });
		if (n !== "" && s && n > s) return U("local.runtime.value.date-later", { max: s });
	} else if (o.kind === "required") {
		let e = i.required ?? B(t, o.required) === !0;
		if (n === "" && e) return U("local.runtime.value.field-required");
	} else if (o.kind === "length") {
		let e = H(n), r = G(t, o.min), i = G(t, o.max);
		if (r !== void 0 && r > 0 && n !== "" && e < r) return U("local.runtime.value.min-length", { min: r });
		if (i !== void 0 && e > i) return U("local.runtime.value.max-length", { max: i });
	} else if (o.kind === "email" && (W(t, o.type) ?? "text") === o.value && n !== "") {
		if (n.length > 254) return U("local.runtime.value.email-length", { limit: 254 });
		if (!e(n)) return U("local.runtime.value.email-invalid");
	}
	return {
		ok: !0,
		value: n
	};
}
var q = /* @__PURE__ */ new Map();
function oe(e) {
	if (!e.name) return J;
	let n = q.get(e.name);
	if (n !== void 0) return n ?? J;
	let r = C(e.name), i = r ? t(r) : J;
	return q.set(e.name, r ? i : null), i;
}
var J = Object.freeze([]);
function Y(e, t, n, r, o, s = !1) {
	switch (e.type) {
		case "number": {
			if (typeof n != "number" || !Number.isFinite(n)) return U("local.runtime.value.finite-number", { name: e.name });
			let i = e.step ?? 1, a = e.min ?? 0;
			for (let i of t) {
				let t = r(i, "min");
				if (t.present && !t.ok) return U("local.runtime.value.constraint", {
					name: e.name,
					attribute: "min"
				});
				if (t.present && t.ok) {
					if (typeof t.value != "number" || !Number.isFinite(t.value)) return U("local.runtime.value.constraint", {
						name: e.name,
						attribute: "min"
					});
					if (a = t.value, n < t.value) return U("local.runtime.value.min", {
						name: e.name,
						min: t.value
					});
				}
				let o = r(i, "max");
				if (o.present && !o.ok) return U("local.runtime.value.constraint", {
					name: e.name,
					attribute: "max"
				});
				if (o.present && o.ok) {
					if (typeof o.value != "number" || !Number.isFinite(o.value)) return U("local.runtime.value.constraint", {
						name: e.name,
						attribute: "max"
					});
					if (n > o.value) return U("local.runtime.value.max", {
						name: e.name,
						max: o.value
					});
				}
				if (t.present && t.ok && o.present && o.ok && typeof t.value == "number" && typeof o.value == "number" && t.value > o.value) return U("local.runtime.value.constraint-range", { name: e.name });
			}
			return e.min !== void 0 && n < e.min ? U("local.runtime.value.min", {
				name: e.name,
				min: e.min
			}) : e.max !== void 0 && n > e.max ? U("local.runtime.value.max", {
				name: e.name,
				max: e.max
			}) : i > 0 && !I(n, a, i) ? U("local.runtime.value.step", {
				name: e.name,
				step: i,
				base: a
			}) : {
				ok: !0,
				value: n
			};
		}
		case "boolean": return typeof n == "boolean" ? {
			ok: !0,
			value: n
		} : U("local.runtime.value.boolean", { name: e.name });
		case "string": {
			if (typeof n != "string") return U("local.runtime.value.string", { name: e.name });
			let c = y(n);
			if (c) return U("local.runtime.value.budget", {
				name: e.name,
				detail: i(c),
				detailKey: c.key,
				...c.params
			});
			for (let i of t) {
				let t = o?.get(i.id) ?? (s ? oe(i) : J);
				if (!t.length) continue;
				let c = {};
				for (let n of t) {
					if (n.kind === "date") {
						for (let t of ["min", "max"]) {
							if (n[t] === void 0) continue;
							let o = r(i, t);
							if (o.present) {
								if (!o.ok || typeof o.value != "string" || !a(o.value)) return U("local.runtime.value.constraint-date", {
									name: e.name,
									attribute: t
								});
								c[t] = o.value;
							}
						}
						let t = c.min ?? W(i, n.min), o = c.max ?? W(i, n.max);
						if (t && o && a(t) && a(o) && t > o) return U("local.runtime.value.constraint-range", { name: e.name });
					}
					if ((n.kind === "date" || n.kind === "required" ? n.required : void 0) !== void 0) {
						let t = r(i, "required");
						if (t.present) {
							if (!t.ok || typeof t.value != "boolean") return U("local.runtime.value.constraint", {
								name: e.name,
								attribute: "required"
							});
							c.required = t.value;
						}
					}
				}
				let l = K(i, n, t, c);
				if (!l.ok) return l;
			}
			return e.options?.length && !e.options.includes(n) ? U("local.runtime.value.option", {
				value: n,
				options: e.options.join(", ")
			}) : {
				ok: !0,
				value: n
			};
		}
		case "array": {
			if (!Array.isArray(n)) return U("local.runtime.value.array", { name: e.name });
			let t = y(n);
			if (t) return U("local.runtime.value.budget", {
				name: e.name,
				detail: i(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "string") return U("local.runtime.value.array-members", { name: e.name });
			if (e.family === "collection") return e.maxItems !== void 0 && n.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
			let r = /* @__PURE__ */ new Set();
			for (let t of n) {
				if (e.options && !e.options.includes(t)) return U("local.runtime.value.checklist-option", { value: t });
				r.add(t);
			}
			let a = e.options ? e.options.filter((e) => r.has(e)) : [...r];
			return e.maxItems !== void 0 && a.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: a
			};
		}
		case "number-array": {
			if (!Array.isArray(n)) return U("local.runtime.value.number-array", { name: e.name });
			let t = y(n);
			if (t) return U("local.runtime.value.budget", {
				name: e.name,
				detail: i(t),
				detailKey: t.key,
				...t.params
			});
			for (let t of n) if (typeof t != "number" || !Number.isFinite(t)) return U("local.runtime.value.number-array-members", { name: e.name });
			return e.maxItems !== void 0 && n.length > e.maxItems ? U("local.runtime.value.max-items", {
				name: e.name,
				max: e.maxItems
			}) : {
				ok: !0,
				value: n.slice()
			};
		}
		case "null": return n === null ? {
			ok: !0,
			value: n
		} : U("local.runtime.value.null", { name: e.name });
	}
	return U("local.runtime.value.unsupported-type", { name: e.name });
}
function X(e) {
	return e instanceof s ? e : new s("expression-eval", e instanceof Error ? e.message : String(e), 0);
}
function Z(e, t) {
	switch (e) {
		case "string": {
			if (typeof t != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string" }
			};
			let e = y(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t
			};
		}
		case "number": return typeof t == "number" && Number.isFinite(t) ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "number" }
		};
		case "boolean": return typeof t == "boolean" ? {
			ok: !0,
			value: t
		} : {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: "boolean" }
		};
		case "array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			for (let e of t) if (typeof e != "string") return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "string-array" }
			};
			let e = y(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		case "number-array": {
			if (!Array.isArray(t)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			for (let e of t) if (typeof e != "number" || !Number.isFinite(e)) return {
				ok: !1,
				key: "local.runtime.external-value",
				params: { kind: "number-array" }
			};
			let e = y(t);
			return e ? {
				ok: !1,
				key: "local.runtime.external-budget",
				params: {
					detailKey: e.key,
					...e.params ?? {}
				}
			} : {
				ok: !0,
				value: t.slice()
			};
		}
		default: return {
			ok: !1,
			key: "local.runtime.external-value",
			params: { kind: String(e) }
		};
	}
}
function se(e, t) {
	let n = t.get(e);
	if (n) return {
		expression: n,
		error: null
	};
	try {
		let n = p(e);
		if (t.size >= re) {
			let e = t.keys().next().value;
			e !== void 0 && t.delete(e);
		}
		return t.set(e, n), {
			expression: n,
			error: null
		};
	} catch (e) {
		return {
			expression: null,
			error: X(e)
		};
	}
}
function ce(e, t) {
	let n = /* @__PURE__ */ new Map();
	for (let t of l(e.nodes)) n.set(t.id, t);
	let a = {}, o = /* @__PURE__ */ new Map();
	for (let [t, r] of Object.entries(e.bindings)) {
		let e = y(r.initial);
		if (e) throw new s("expression-budget", `Parameter "${t}": ${i(e)}`, 0);
		a[t] = P(r.initial);
		let c = [];
		for (let e of r.nodeIds) {
			let t = n.get(e);
			t && c.push(t);
		}
		o.set(t, c);
	}
	let d = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots ?? {})) d.set(t, { ...n });
	let f = r(e), p = new Map(Object.entries(f?.valueRules ?? {})), m = f === void 0, h = /* @__PURE__ */ new Map();
	if (f) for (let e of f.slotRelations) {
		let t = d.get(e.nodeId), n = t?.[e.lower], r = t?.[e.upper];
		if (!n || !r) continue;
		let i = h.get(e.nodeId) ?? [];
		i.push({
			lower: n,
			upper: r
		}), h.set(e.nodeId, i);
	}
	else for (let [e, t] of d) t.start && t.end && h.set(e, [{
		lower: t.start,
		upper: t.end
	}]);
	let v = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindings)) for (let e of n.nodeIds) {
		if (d.has(e)) continue;
		let n = v.get(e);
		(n === void 0 || n.startsWith("@") && !t.startsWith("@")) && v.set(e, t);
	}
	let ee = Object.freeze(Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort()), b = /* @__PURE__ */ new Map();
	for (let [e, t] of d) for (let n of Object.values(t)) {
		if (n.startsWith("@")) continue;
		let t = b.get(n) ?? /* @__PURE__ */ new Set();
		t.add(e), b.set(n, t);
	}
	let x = e.computations ?? {}, S = Object.keys(x), C = /* @__PURE__ */ new Map();
	for (let [e, n] of Object.entries(x)) {
		let r = se(n.source, t);
		r.expression && C.set(e, r.expression);
	}
	let { order: te, cyclic: w } = c(x), T = {}, E = /* @__PURE__ */ new Map();
	for (let e of te) {
		let t = x[e];
		if (!t || t.kind !== "const") continue;
		if (Object.hasOwn(t, "value")) {
			let n = t.value, r = g(n);
			if (r) {
				E.set(e, new s("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			T[e] = P(n);
			continue;
		}
		let n = C.get(e);
		if (!n) E.set(e, new s("expression-eval", `Constant "${e}" cannot be evaluated.`, 0));
		else try {
			let t = n.evaluate({ ...T }), r = g(t);
			if (r) {
				E.set(e, new s("expression-budget", `Constant "${e}": ${r}`, 0));
				continue;
			}
			T[e] = P(t);
		} catch (t) {
			E.set(e, X(t));
		}
	}
	let D = /* @__PURE__ */ new Map();
	for (let e of w) D.set(e, new s("expression-cycle", `Computation "${e}" is part of a dependency cycle.`, 0));
	let O = [];
	if (Array.isArray(e.validations)) for (let n of e.validations) {
		if (!u(n)) continue;
		let e = se(n.expression, t);
		O.push({
			rule: n,
			expression: e.expression,
			error: e.error
		});
	}
	return {
		document: e,
		nodeIndex: n,
		controls: o,
		slotKeys: d,
		publicNames: ee,
		publicSlotOwners: b,
		initial: a,
		valueRules: p,
		legacyValueRules: m,
		slotRelations: h,
		bindingByNode: v,
		computationMetadata: x,
		computationNames: S,
		computationOrder: te,
		cyclicComputations: w,
		computationExpressions: C,
		constValues: T,
		constErrors: E,
		cycleErrors: D,
		validationRules: O,
		validationLineStarts: _(typeof e.source == "string" ? e.source : "")
	};
}
function le(e) {
	return !e || e.syntax !== "local" ? "createLocalRuntime requires a local interaction document." : e.syntaxVersion !== void 0 && e.syntaxVersion !== "local-draft-3" || e.versionDeclaration && e.versionDeclaration.version !== "local-draft-3" ? `createLocalRuntime requires ${S}; migrate the source before constructing a runtime.` : null;
}
function ue(e, t) {
	return (e.controls.get(t.name) ?? [])[0] ?? (t.owner ? e.nodeIndex.get(t.owner) : void 0) ?? (t.nodeIds[0] ? e.nodeIndex.get(t.nodeIds[0]) : void 0);
}
function de(e, t, n) {
	let r = ue(e, t);
	return r ? L(e.document, r, "local.runtime.value", n) : R("local.runtime.value", i(n));
}
function Q(e, t, n) {
	let r = e.slotRelations.get(t);
	return r?.length ? r.some(({ lower: e, upper: t }) => {
		let r = n[e], i = n[t];
		return typeof r == "number" && typeof i == "number" && r > i;
	}) : !1;
}
function fe(e, t) {
	let r = e.nodeIndex.get(t);
	return r ? L(e.document, r, "local.runtime.value", n("local.runtime.value.range-order")) : R("local.runtime.value", i(n("local.runtime.value.range-order")));
}
var pe = /* @__PURE__ */ new WeakMap();
function $(e) {
	return Object.freeze({
		ok: e.ok,
		changed: e.changed,
		revision: e.revision,
		retained: Object.freeze([...e.retained]),
		dropped: Object.freeze(e.dropped.map((e) => Object.freeze({ ...e }))),
		diagnostics: Object.freeze([...e.diagnostics])
	});
}
function me(e, t, n) {
	let r = pe.get(e);
	if (!r) throw TypeError("updateLocalRuntime requires a runtime created by createLocalRuntime.");
	return r.update(t, n?.notify !== !1);
}
function he(e) {
	pe.get(e)?.notify();
}
function ge(e, t) {
	let r = le(e);
	if (r) throw Error(r);
	let a = t?.services === void 0, c = w(e.source), u = /* @__PURE__ */ new Map(), g = /* @__PURE__ */ new Map(), _ = ce(e, g), v = () => _, S = t?.services ?? T({
		documentId: t?.documentId,
		sourceDigest: c,
		randomSeed: t?.randomSeed,
		componentState: t?.componentState,
		...a ? { knownStateKeys: () => {
			let e = /* @__PURE__ */ new Set();
			for (let n of l(_.document.nodes)) n.name !== void 0 && e.add(te({
				documentId: t?.documentId,
				sourceDigest: c,
				nodeId: n.id,
				stateKey: n.attrs?.["state-key"]
			}));
			return e;
		} } : {}
	}), C = {};
	for (let [n, r] of Object.entries(e.externals ?? {})) {
		let e = t?.externalValues?.[n];
		if (e === void 0) continue;
		let i = Z(r.type, e);
		i.ok && (C[n] = i.value);
	}
	let E = (e) => {
		let t = {};
		for (let [n, r] of Object.entries(e.document.externals ?? {})) {
			if (!Object.hasOwn(C, n)) continue;
			let e = Z(r.type, C[n]);
			e.ok && (t[n] = e.value);
		}
		return t;
	}, D = (e, t, n, r = v()) => {
		let i = r.document.dynamicConstraints?.[e.id]?.[t];
		if (!i) return { present: !1 };
		let a = se(i.source, g);
		if (!a.expression) return {
			present: !0,
			ok: !1
		};
		try {
			let e = a.expression.evaluate(n), t = i.numeric;
			return t && (typeof e != "number" || !Number.isFinite(e) || t.integer === !0 && !Number.isInteger(e) || t.min !== void 0 && e < t.min || t.max !== void 0 && e > t.max) ? {
				present: !0,
				ok: !1
			} : {
				present: !0,
				ok: !0,
				value: e
			};
		} catch {
			return {
				present: !0,
				ok: !1
			};
		}
	}, O = _.initial, k = 0, A = {}, j = {}, M = {
		revision: 0,
		state: ae({})
	}, N = !1, I = null, z = /* @__PURE__ */ new Set(), B = /* @__PURE__ */ new Map(), V = () => {
		if (N) throw Error("The local interaction runtime has been disposed.");
	}, H = (e, t) => {
		let n = E(e), r = /* @__PURE__ */ new Map();
		for (let t of Object.keys(e.document.externals ?? {})) Object.hasOwn(n, t) || r.set(t, new s("external-missing", "External data \"" + t + "\" is not available.", 0));
		let i = {}, a = /* @__PURE__ */ new Map();
		if (e.computationNames.length > 0) {
			let s = o(e.computationMetadata, e.computationOrder, e.computationExpressions, {
				...t,
				...n
			}, e.constValues, r);
			i = s.values, a = s.errors;
			for (let [t, n] of e.constErrors) Object.hasOwn(i, t) || a.set(t, n);
			for (let [t, n] of e.cycleErrors) Object.hasOwn(i, t) || a.set(t, n);
		}
		let c = {};
		for (let [e, n] of Object.entries(t)) c[e] = n;
		for (let [e, t] of Object.entries(n)) c[e] = t;
		for (let [e, t] of Object.entries(i)) c[e] = t;
		for (let [e, t] of [...r, ...a]) Object.hasOwn(i, e) || Object.defineProperty(c, e, {
			enumerable: !0,
			configurable: !0,
			get() {
				throw t;
			}
		});
		let l = {};
		for (let [e, n] of Object.entries(t)) l[e] = n;
		for (let [e, t] of Object.entries(n)) l[e] = t;
		for (let [e, t] of Object.entries(i)) l[e] = t;
		return {
			values: i,
			errors: a,
			environment: c,
			snapshotState: l
		};
	}, U = () => {
		let e = H(v(), O);
		e.values, e.errors, A = e.environment, j = e.snapshotState;
	}, W = (e, t = v(), n = O) => {
		let r;
		return (i, a) => t.document.dynamicConstraints?.[i.id]?.[a] ? (r ??= H(t, {
			...n,
			...e
		}).environment, D(i, a, r, t)) : { present: !1 };
	}, G = () => {
		M = {
			revision: k,
			state: ae(j)
		};
	}, K = () => {
		for (let e of z) e();
	}, q = (e) => {
		O = e, k += 1, U(), G(), K();
	}, oe = (e) => {
		if (V(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setExternalValues requires an object of external values.");
		let t = [], r = {}, a = Object.keys(e).sort();
		for (let o of a) {
			if (o === "__proto__") {
				t.push(R("local.runtime.external", "External names cannot be \"__proto__\"."));
				continue;
			}
			let a = v().document.externals ?? {}, s = Object.hasOwn(a, o) ? a[o] : void 0;
			if (!s) {
				let e = n("local.runtime.external", { name: o });
				t.push(R("local.runtime.external", i(e), e));
				continue;
			}
			let c = Z(s.type, e[o]);
			if (c.ok) r[o] = c.value;
			else {
				let e = n(c.key, {
					name: o,
					...c.params ?? {}
				});
				t.push(R("local.runtime.external", i(e), e));
			}
		}
		if (t.length) return t;
		if (!a.some((e) => !F(C[e], r[e]))) return [];
		for (let [e, t] of Object.entries(r)) C[e] = t;
		return k += 1, U(), G(), K(), [];
	}, J = (e) => {
		V();
		let t = v(), n = [], r = {}, i = Object.keys(e).sort(), a = W(e);
		for (let o of i) {
			if (o === "__proto__") {
				n.push(R("local.runtime.parameter", "Parameter names cannot be \"__proto__\"."));
				continue;
			}
			if (o.startsWith("@")) {
				n.push(R("local.runtime.parameter", `Internal parameter "${o}" cannot be written by name.`));
				continue;
			}
			if (!Object.hasOwn(t.document.bindings, o)) {
				n.push(R("local.runtime.parameter", `Unknown parameter "${o}".`));
				continue;
			}
			let i = t.document.bindings[o], s = Y(i, t.controls.get(o) ?? [], e[o], a, t.valueRules, t.legacyValueRules);
			s.ok ? r[o] = P(s.value) : n.push(de(t, i, s.detail));
		}
		if (n.length) return n;
		if (!i.some((e) => !F(O[e], r[e]))) return [];
		let o = {
			...O,
			...r
		}, s = /* @__PURE__ */ new Set();
		for (let e of i) for (let n of t.publicSlotOwners.get(e) ?? []) s.add(n);
		for (let e of [...s].sort()) Q(t, e, o) && n.push(fe(t, e));
		return n.length ? n : (q(o), []);
	}, X = (e) => {
		let t = u.get(e);
		if (!t) {
			if (t = p(e), u.size >= re) {
				let e = u.keys().next().value;
				e !== void 0 && u.delete(e);
			}
			u.set(e, t);
		}
		return t;
	}, ue = () => {
		let e = v(), t = [], n = typeof e.document.source == "string" ? e.document.source : "";
		for (let r of e.validationRules) {
			if (r.error) {
				t.push(f(n, e.validationLineStarts, r.rule.range, b, m(`Validation expression is invalid: ${r.error.message}`)));
				continue;
			}
			if (!r.expression) continue;
			let i;
			try {
				i = r.expression.evaluate(A);
			} catch (i) {
				t.push(f(n, e.validationLineStarts, r.rule.range, b, m(`Validation expression failed: ${i instanceof Error ? i.message : String(i)}`)));
				continue;
			}
			typeof i == "boolean" ? i || t.push(f(n, e.validationLineStarts, r.rule.range, h, me(r.rule.message))) : t.push(f(n, e.validationLineStarts, r.rule.range, b, "Validation expression must evaluate to a boolean."));
		}
		return t;
	}, me = (e) => {
		let t;
		try {
			t = x(e, A);
		} catch {
			t = ee;
		}
		return m(t);
	}, he = (e, t) => {
		let n = ne({
			previous: _.document,
			state: O,
			next: e
		}), r = {};
		for (let [t, n] of Object.entries(e.bindings)) r[t] = P(n.initial);
		let i = /* @__PURE__ */ new Map();
		for (let e of n.dropped) i.set(e.name, Object.freeze({ ...e }));
		let a = [], o = {}, s = [];
		for (let c of n.retained) {
			let l = e.bindings[c];
			if (!l) continue;
			let u = Y(l, t.controls.get(c) ?? [], n.values[c], W(n.values, t, r), t.valueRules, t.legacyValueRules);
			u.ok ? (o[c] = P(u.value), s.push(c)) : (a.push(de(t, l, u.detail)), i.set(c, Object.freeze({
				name: c,
				reason: "invalid"
			})));
		}
		let c = {
			...r,
			...o
		}, l = /* @__PURE__ */ new Set();
		for (let e of s) for (let n of t.publicSlotOwners.get(e) ?? []) l.add(n);
		let u = !1;
		for (let e of [...l].sort()) if (Q(t, e, c)) {
			u = !0;
			break;
		}
		let d;
		if (!u) Object.assign(r, o), d = s;
		else {
			d = [];
			for (let e of s) {
				let n = r[e];
				r[e] = o[e];
				let s = !1;
				for (let n of [...t.publicSlotOwners.get(e) ?? []].sort()) Q(t, n, r) && (a.push(fe(t, n)), s = !0);
				s ? (r[e] = n, i.set(e, Object.freeze({
					name: e,
					reason: "invalid"
				}))) : d.push(e);
			}
		}
		for (let [n, o] of t.slotRelations) if (Q(t, n, r)) {
			for (let t of o) for (let n of [t.lower, t.upper]) {
				let t = e.bindings[n];
				if (!t) continue;
				r[n] = P(t.initial);
				let a = d.indexOf(n);
				a >= 0 && d.splice(a, 1), i.set(n, Object.freeze({
					name: n,
					reason: "invalid"
				}));
			}
			if (a.push(fe(t, n)), Q(t, n, r)) return {
				values: {},
				retained: [],
				dropped: [],
				diagnostics: []
			};
		}
		let f = !0;
		for (; f;) {
			let n = W({}, t, r), o = [];
			for (let i of d) {
				let s = e.bindings[i], c = Y(s, t.controls.get(i) ?? [], r[i], n, t.valueRules, t.legacyValueRules);
				c.ok || (a.push(de(t, s, c.detail)), o.push(i));
			}
			for (let t of o) r[t] = P(e.bindings[t].initial), d.splice(d.indexOf(t), 1), i.set(t, Object.freeze({
				name: t,
				reason: "invalid"
			}));
			f = o.length > 0;
		}
		let p = [...i.values()].sort((e, t) => e.name < t.name ? -1 : +(e.name > t.name));
		return d.sort(), {
			values: r,
			retained: d,
			dropped: p,
			diagnostics: a
		};
	}, ge = (e, t) => {
		if (V(), e === _.document) return $({
			ok: !0,
			changed: !1,
			revision: k,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		if (le(e)) return $({
			ok: !1,
			changed: !1,
			revision: k,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let n;
		try {
			n = ce(e, g);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: k,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let r = he(e, n);
		if (Object.keys(r.values).length === 0 && Object.keys(e.bindings).length > 0) return $({
			ok: !1,
			changed: !1,
			revision: k,
			retained: [],
			dropped: [],
			diagnostics: []
		});
		let i;
		try {
			i = H(n, r.values);
		} catch {
			return $({
				ok: !1,
				changed: !1,
				revision: k,
				retained: [],
				dropped: [],
				diagnostics: []
			});
		}
		let a = E(n);
		for (let e of Object.keys(C)) delete C[e];
		if (Object.assign(C, a), _ = n, O = r.values, i.values, i.errors, A = i.environment, j = i.snapshotState, I = null, k += 1, G(), t) for (let e of z) e();
		return $({
			ok: !0,
			changed: !0,
			revision: k,
			retained: r.retained,
			dropped: r.dropped,
			diagnostics: r.diagnostics
		});
	}, _e = (e) => {
		let t = /* @__PURE__ */ new Set();
		for (let n of l([e])) t.add(n.id);
		return t;
	}, ve = {
		get document() {
			return _.document;
		},
		services: S,
		snapshot() {
			return V(), M;
		},
		get(e, t) {
			V();
			let n = v(), r = n.nodeIndex.get(e.id);
			if (!r) return null;
			let i = t === void 0 ? n.slotKeys.get(r.id)?.value ?? n.bindingByNode.get(r.id) ?? d(r) : n.slotKeys.get(r.id)?.[t];
			return i && Object.hasOwn(O, i) ? P(O[i]) : null;
		},
		set(e, t, r) {
			V();
			let i = v(), a = i.nodeIndex.get(e.id);
			if (!a) return [L(i.document, e, "local.runtime.binding", n("local.runtime.binding.no-writable"))];
			let o = i.slotKeys.get(a.id), s;
			if (r === void 0) {
				if (o && !o.value) return [L(i.document, a, "local.runtime.binding", n("local.runtime.binding.needs-slot"))];
				s = o?.value ?? i.bindingByNode.get(a.id) ?? d(a);
			} else if (s = o?.[r], !s) return [L(i.document, a, "local.runtime.binding", n("local.runtime.binding.unknown-slot", { slot: r }))];
			let c = Object.hasOwn(i.document.bindings, s) ? i.document.bindings[s] : void 0;
			if (!c) return [L(i.document, a, "local.runtime.binding", n("local.runtime.binding.no-writable"))];
			let l = Y(c, i.controls.get(s) ?? [], t, W({ [s]: t }), i.valueRules, i.legacyValueRules);
			if (!l.ok) return [L(i.document, a, "local.runtime.value", l.detail)];
			let u = P(l.value);
			if (F(O[s], u)) return [];
			let f = {
				...O,
				[s]: u
			};
			return Q(i, a.id, f) ? [L(i.document, a, "local.runtime.value", n("local.runtime.value.range-order"))] : (q(f), []);
		},
		setMany(e, t) {
			V();
			let r = v(), i = r.nodeIndex.get(e.id);
			if (!i) return [L(r.document, e, "local.runtime.binding", n("local.runtime.binding.no-writable"))];
			let a = r.slotKeys.get(i.id);
			if (!a) return [L(r.document, i, "local.runtime.binding", n("local.runtime.binding.no-multi-slot"))];
			let o = Object.entries(t);
			if (!o.length) return [];
			let s = { ...O }, c = H(r, {
				...O,
				...Object.fromEntries(o.map(([e, t]) => [a[e], t]))
			}).environment;
			for (let [e, t] of o) {
				let o = a[e];
				if (!o || !Object.hasOwn(r.document.bindings, o)) return [L(r.document, i, "local.runtime.binding", n("local.runtime.binding.unknown-slot", { slot: e }))];
				let l = Y(r.document.bindings[o], r.controls.get(o) ?? [], t, (e, t) => D(e, t, c), r.valueRules, r.legacyValueRules);
				if (!l.ok) return [L(r.document, i, "local.runtime.value", l.detail)];
				s[o] = P(l.value);
			}
			return Q(r, i.id, s) ? [L(r.document, i, "local.runtime.value", n("local.runtime.value.range-order"))] : (o.every(([e, t]) => F(O[a[e]], t)) || q(s), []);
		},
		parameterNames() {
			return V(), v().publicNames;
		},
		getParameter(e) {
			V();
			let t = v();
			if (!e.startsWith("@") && Object.hasOwn(t.document.bindings, e)) return Object.hasOwn(O, e) ? P(O[e]) : void 0;
		},
		getParameters() {
			V();
			let e = v(), t = {};
			for (let n of e.publicNames) {
				let e = O[n];
				t[n] = Array.isArray(e) ? Object.freeze([...e]) : e;
			}
			return Object.freeze(t);
		},
		setParameter(e, t) {
			V();
			let n = Object.create(null);
			return n[e] = t, J(n);
		},
		setParameters(e) {
			if (V(), typeof e != "object" || !e || Array.isArray(e)) throw TypeError("setParameters requires an object of parameter values.");
			return J(e);
		},
		getExternal(e) {
			if (V(), Object.hasOwn(v().document.externals ?? {}, e) && Object.hasOwn(C, e)) return P(C[e]);
		},
		getExternalValues() {
			V();
			let e = {};
			for (let [t, n] of Object.entries(C)) e[t] = Array.isArray(n) ? Object.freeze([...n]) : n;
			return Object.freeze(e);
		},
		setExternalValues(e) {
			return oe(e);
		},
		evaluate(e) {
			V();
			let t = X(e).evaluate(A);
			return Array.isArray(t) ? t.slice() : t;
		},
		validate() {
			if (V(), I && I.revision === k) return I.diagnostics.map(ie);
			let e = ue();
			return I = {
				revision: k,
				diagnostics: e
			}, e.map(ie);
		},
		text(e) {
			return V(), x(e, A);
		},
		reset(e) {
			V();
			let t = v(), n = t.nodeIndex.get(e.id);
			if (!n) return;
			let r = _e(n), a = { ...O };
			for (let [e, n] of Object.entries(t.document.bindings)) {
				if (!(t.controls.get(e) ?? []).some((e) => r.has(e.id))) continue;
				let o = y(n.initial);
				if (o) throw new s("expression-budget", `Parameter "${e}": ${i(o)}`, 0);
				a[e] = P(n.initial);
			}
			for (let e of r) B.set(e, (B.get(e) ?? 0) + 1);
			q(a);
		},
		resetToken(e) {
			V();
			let t = v().nodeIndex.get(e.id);
			return t ? B.get(t.id) ?? 0 : 0;
		},
		subscribe(e) {
			return V(), z.add(e), () => {
				z.delete(e);
			};
		},
		dispose() {
			N || (N = !0, a && S.scheduler.dispose(), z.clear(), u.clear(), g.clear(), _.computationExpressions.clear(), _.constErrors.clear(), _.cycleErrors.clear(), _.validationRules.length = 0, B.clear());
		}
	};
	return pe.set(ve, {
		update: ge,
		notify() {
			if (!N) for (let e of z) e();
		}
	}), U(), G(), ve;
}
export { ne as a, M as i, he as n, me as r, ge as t };
