import { d as e, m as t } from "./html-DgECD9QC.js";
import n from "./reactive-md-default-preset.js";
import { d as r, l as i, n as a, u as o } from "./registry-DaHST1VN.js";
// src/local/configuration/options.ts
function s(e) {
	return t(e, {
		defaults: a(),
		preset: {
			id: n.id,
			version: n.version
		},
		defaultConfigKey: i(),
		readConfig: (e) => r(e),
		configKey: (e) => i(e)
	});
}
function c(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
var l = 256, u = 4096, d = /* @__PURE__ */ new WeakMap(), f = /* @__PURE__ */ new Map(), p = /* @__PURE__ */ new WeakMap(), m = 0;
function h() {
	return m += 1, m;
}
function g(e) {
	if (typeof e == "object" && e || typeof e == "function") {
		let t = e, n = p.get(t);
		return n === void 0 && (n = h(), p.set(t, n)), `unreadable#${n}`;
	}
	return `unreadable:${typeof e}:${String(e)}`;
}
function _(e) {
	let t = [], n = 0, r = (e) => {
		if (n += 1, n > u) throw RangeError("signature budget");
		switch (typeof e) {
			case "string": return `s${JSON.stringify(e)}`;
			case "number": return `n${Object.is(e, -0) ? "-0" : String(e)}`;
			case "boolean": return e ? "b1" : "b0";
			case "undefined": return "u";
			case "bigint": return `g${e.toString()}`;
			case "symbol": {
				let t = f.get(e);
				return t === void 0 && (t = h(), f.set(e, t)), `y${t}`;
			}
			case "function": {
				let t = d.get(e);
				return t === void 0 && (t = h(), d.set(e, t)), `f${t}`;
			}
		}
		if (e === null) return "null";
		let i = e, a = t.indexOf(i);
		if (a >= 0) return `r${a}`;
		t.push(i);
		try {
			if (Array.isArray(i)) {
				let e = Math.min(i.length, 8);
				if (i.length > l) {
					let t = `a#${i.length}[`;
					for (let n = 0; n < e; n += 1) t += `${r(i[n])},`;
					return `${t}]`;
				}
				let t = `a${i.length}[`;
				for (let e = 0; e < i.length; e += 1) t += `${r(i[e])},`;
				return `${t}]`;
			}
			let e = Object.keys(i);
			if (e.length > l) {
				let t = `o#${e.length}{`;
				for (let n of e.slice(0, 8)) t += `${r(n)},`;
				return `${t}}`;
			}
			e.sort();
			let t = "o{";
			for (let n of e) t += `${r(n)}:${r(i[n])},`;
			return `${t}}`;
		} finally {
			t.pop();
		}
	};
	try {
		return r(e);
	} catch {
		return g(e);
	}
}
function v(t) {
	if (t === void 0 && (t = {}), !c(t)) return "invalid";
	let n = e.map((e) => {
		if (!Object.hasOwn(t, e)) return "-";
		let n = t[e];
		return n === void 0 ? "-" : n === !0 ? "1" : n === !1 ? "0" : "!";
	}).join(""), r = "";
	if (Object.hasOwn(t, "limits")) {
		let e = t.limits;
		if (e === void 0) r = "default";
		else if (!c(e)) r = "invalid";
		else {
			let t = (t) => !Object.hasOwn(e, t) || e[t] === void 0 ? "default" : String(e[t]);
			r = `${t("maxSyntaxNodes")}:${t("maxParseWork")}:${t("maxMarkdownDepth")}`;
		}
	}
	let i = "";
	if (Object.hasOwn(t, "hostComponents") && t.hostComponents !== void 0) {
		let e = t.hostComponents;
		try {
			Array.isArray(e) ? e.length > 0 && (i = e.length > 32 ? `:hosts=oversize:${e.length}` : `:hosts=${_(e)}`) : i = `:hosts=${_(e)}`;
		} catch {
			i = `:hosts=${g(e)}`;
		}
	}
	let a = !Object.hasOwn(t, "markdownBreaks") || t.markdownBreaks === void 0 ? "-" : t.markdownBreaks === !0 ? "1" : t.markdownBreaks === !1 ? "0" : "!", s = !Object.hasOwn(t, "strict") || t.strict === void 0 || t.strict === !0 ? "strict=1" : t.strict === !1 ? "strict=0:recovery=2" : "strict=!", l = "";
	return Object.hasOwn(t, "config") && t.config !== void 0 && (l = `:config=${o(t.config)}`), `${n}:${r}:${a}:${s}${i}${l}`;
}
export { s as n, v as t };
