import { o as e } from "./props-DGlBk0e5.js";
import { $ as t, A as n, B as r, D as i, E as a, F as o, G as s, H as c, I as l, J as u, K as d, L as f, M as p, N as m, O as h, P as g, Q as _, R as v, S as y, T as b, U as x, V as S, W as C, X as w, Y as T, Z as E, _ as D, at as O, b as k, et as A, f as ee, g as te, it as ne, j as re, k as j, l as ie, n as ae, ot as oe, q as M, st as se, tt as ce, v as le, w as ue, x as de, y as fe, z as pe } from "./html-DgECD9QC.js";
import { $ as me, L as he, Q as ge, Z as _e, at as ve, j as N, lt as P, nt as ye, rt as be, st as xe, t as Se, tt as Ce } from "./default-components-qRt0E8bl.js";
import { a as we, g as Te, i as Ee, o as De, p as Oe, r as ke, s as Ae } from "./registry-core-BIJfeW7H.js";
// \0rolldown/runtime.js
var je = Object.create, Me = Object.defineProperty, Ne = Object.getOwnPropertyDescriptor, Pe = Object.getOwnPropertyNames, Fe = Object.getPrototypeOf, Ie = Object.prototype.hasOwnProperty, Le = (e, t) => () => (t || (e((t = { exports: {} }).exports, t, t.exports), e = null), t.exports), Re = (e, t) => {
	let n = {};
	for (var r in e) Me(n, r, {
		get: e[r],
		enumerable: !0
	});
	return t || Me(n, Symbol.toStringTag, { value: "Module" }), n;
}, ze = (e, t, n, r) => {
	if (t && typeof t == "object" || typeof t == "function") for (var i = Pe(t), a = 0, o = i.length, s; a < o; a++) s = i[a], !Ie.call(e, s) && s !== n && Me(e, s, {
		get: ((e) => t[e]).bind(null, s),
		enumerable: !(r = Ne(t, s)) || r.enumerable
	});
	return e;
}, Be = (e, t, n) => (n = e == null ? {} : je(Fe(e)), ze(t || !e || !e.__esModule || !Ie.call(e, "default") ? Me(n, "default", {
	value: e,
	enumerable: !0
}) : n, e)), Ve = /* @__PURE__ */ ((e) => typeof require < "u" ? require : typeof Proxy < "u" ? new Proxy(e, { get: (e, t) => (typeof require < "u" ? require : e)[t] }) : e)(function(e) {
	if (typeof require < "u") return require.apply(this, arguments);
	throw Error("Calling `require` for \"" + e + "\" in an environment that doesn't expose the `require` function. See https://rolldown.rs/in-depth/bundling-cjs#require-external-modules for more details.");
}), F = class extends Error {
	code;
	offset;
	constructor(e, t, n = 0) {
		super(t), this.name = "LatexError", this.code = e, this.offset = n;
	}
}, I = 5e4, He = 2e4, Ue = 5e3, We = 120, Ge = 2e4, Ke = 1e3, qe = 2e3, Je = 5, Ye = 1e6, Xe = /* @__PURE__ */ new Set([
	"quad",
	"qquad",
	"enspace",
	"thinspace",
	"medspace",
	"thickspace",
	"negthinspace",
	"displaystyle",
	"textstyle",
	"scriptstyle",
	"scriptscriptstyle",
	"limits",
	"nolimits"
]), Ze = {
	alpha: "alpha",
	beta: "beta",
	gamma: "gamma",
	theta: "theta",
	omega: "omega",
	lambda: "lambda",
	mu: "mu",
	sigma: "sigma"
}, Qe = /* @__PURE__ */ new Set([
	"sin",
	"cos",
	"tan",
	"arcsin",
	"arccos",
	"arctan",
	"exp",
	"ln",
	"log",
	"min",
	"max"
]), $e = {
	"{": "lbrace",
	"}": "rbrace",
	"|": "vert",
	"%": "percent",
	"&": "amp",
	"#": "hash",
	_: "underscore",
	$: "dollar"
};
function et(e) {
	let t = [], n = 0, r = (e, n, r) => {
		if (t.length >= He) throw new F("latex-budget", "Math input contains too many tokens.", r);
		t.push({
			kind: e,
			value: n,
			offset: r
		});
	};
	for (; n < e.length;) {
		let t = e[n];
		if (t === " " || t === "	" || t === "\r" || t === "\n") n += 1;
		else if (t === "%") for (; n < e.length && e[n] !== "\n";) n += 1;
		else if (t === "\\") {
			if (n + 1 >= e.length) throw new F("latex-syntax", "Formula ends with a lone backslash.", n);
			let t = e[n + 1];
			if (t === "\\") {
				r("command", "newline", n), n += 2;
				continue;
			}
			if (/[A-Za-z]/.test(t)) {
				let t = n + 1;
				for (; t < e.length && /[A-Za-z]/.test(e[t]);) t += 1;
				let i = e.slice(n + 1, t);
				Xe.has(i) || r("command", i, n), n = t;
				continue;
			}
			if (t === " " || t === "," || t === ";" || t === ":" || t === "!") {
				n += 2;
				continue;
			}
			let i = $e[t];
			if (i) {
				r("command", i, n), n += 2;
				continue;
			}
			r("command", t, n), n += 2;
		} else if (t >= "0" && t <= "9") {
			let t = /^(?:\d+(?:\.\d*)?|\.\d+)/.exec(e.slice(n));
			r("number", t[0], n), n += t[0].length;
		} else if (t === "." && e[n + 1] >= "0" && e[n + 1] <= "9") {
			let t = /^(?:\d+(?:\.\d*)?|\.\d+)/.exec(e.slice(n));
			r("number", t[0], n), n += t[0].length;
		} else /[A-Za-z]/.test(t) ? (r("letter", t, n), n += 1) : (r("punct", t, n), n += 1);
	}
	return r("eof", "", e.length), t;
}
function tt(e) {
	return Object.prototype.hasOwnProperty.call(Ze, e);
}
function nt(e) {
	switch (e.kind) {
		case "number":
		case "letter": return !0;
		case "punct": return e.value === "(" || e.value === "{" || e.value === "[" || e.value === "|";
		case "command": {
			let t = e.value;
			return Qe.has(t) || tt(t) ? !0 : t === "frac" || t === "dfrac" || t === "tfrac" || t === "sqrt" || t === "left" || t === "pi" || t === "mathrm" || t === "begin" || t === "lvert" || t === "vert" || t === "lbrace";
		}
		default: return !1;
	}
}
function rt(e) {
	if (e.kind === "punct") return e.value === "=" ? "eq" : e.value === "<" ? "lt" : e.value === ">" ? "gt" : null;
	if (e.kind === "command") {
		if (e.value === "ne" || e.value === "neq") return "ne";
		if (e.value === "le" || e.value === "leq") return "le";
		if (e.value === "ge" || e.value === "geq") return "ge";
	}
	return null;
}
var it = class {
	tokens;
	source;
	pos = 0;
	nodes = 0;
	allowY;
	constructor(e, t, n = {}) {
		this.source = e, this.tokens = t, this.allowY = n.allowY === !0;
	}
	parseDocument() {
		if (this.peek().kind === "eof") throw new F("latex-empty", "Formula is empty.", 0);
		if (this.atLetter("y") && this.atPunctAt(1, "=") && (this.pos += 2), this.peek().kind === "eof") throw new F("latex-empty", "Missing expression after y.", this.peek().offset);
		let e = this.parseAdditive(0), t = this.peek();
		if (t.kind !== "eof") throw rt(t) || t.kind === "punct" && t.value === "=" ? new F("latex-relation", "Plots support only explicit y = f(x) equations.", t.offset) : new F("latex-syntax", `Unexpected token "${this.raw(t)}".`, t.offset);
		return e;
	}
	parseEquation() {
		if (this.peek().kind === "eof") throw new F("latex-empty", "Formula is empty.", 0);
		let e = this.parseAdditive(0), t = this.peek();
		if (t.kind !== "punct" || t.value !== "=") throw new F("latex-relation", "Plot formulas must be written as an equation.", t.offset);
		this.take();
		let n = this.parseAdditive(0), r = this.peek();
		if (r.kind !== "eof") throw new F("latex-syntax", `Unexpected token "${this.raw(r)}".`, r.offset);
		return {
			left: e,
			right: n
		};
	}
	peek(e = 0) {
		return this.tokens[Math.min(this.pos + e, this.tokens.length - 1)];
	}
	take() {
		return this.tokens[this.pos++];
	}
	atPunct(e) {
		let t = this.peek();
		return t.kind === "punct" && t.value === e;
	}
	atPunctAt(e, t) {
		let n = this.peek(e);
		return n.kind === "punct" && n.value === t;
	}
	atCommand(e) {
		let t = this.peek();
		return t.kind === "command" && t.value === e;
	}
	atLetter(e) {
		let t = this.peek();
		return t.kind === "letter" && t.value === e;
	}
	expectPunct(e) {
		let t = this.peek();
		if (t.kind !== "punct" || t.value !== e) throw new F("latex-syntax", `Missing "${e}".`, t.offset);
		return this.take();
	}
	raw(e) {
		return e.kind === "eof" ? "end of input" : e.kind === "command" ? `\\${e.value}` : this.source.slice(e.offset, e.offset + Math.max(1, e.value.length));
	}
	make(e, t, n) {
		if (this.nodes += 1, this.nodes > Ue) throw new F("latex-budget", "Formula is too complex.", t);
		if (n > We) throw new F("latex-budget", "Formula is nested too deeply.", t);
		return e;
	}
	parseAdditive(e) {
		let t = this.parseMultiplicative(e + 1, !1);
		for (;;) {
			let n = this.peek();
			if (n.kind !== "punct" || n.value !== "+" && n.value !== "-") break;
			let r = this.take().value, i = this.parseMultiplicative(e + 1, !1);
			t = this.make({
				kind: "binary",
				op: r,
				left: t,
				right: i,
				offset: n.offset
			}, n.offset, e);
		}
		return t;
	}
	parseMultiplicative(e, t) {
		let n = this.parseUnary(e + 1, t);
		for (;;) {
			let r = this.peek();
			if (r.kind === "punct" && r.value === "/") {
				this.take();
				let i = this.parseUnary(e + 1, t);
				n = this.make({
					kind: "binary",
					op: "/",
					left: n,
					right: i,
					offset: r.offset
				}, r.offset, e);
				continue;
			}
			if (r.kind === "punct" && r.value === "*" || r.kind === "command" && (r.value === "cdot" || r.value === "times")) {
				this.take();
				let i = this.parseUnary(e + 1, t);
				n = this.make({
					kind: "binary",
					op: "*",
					left: n,
					right: i,
					offset: r.offset
				}, r.offset, e);
				continue;
			}
			if (t && r.kind === "command" && Qe.has(r.value) || !nt(r)) break;
			let i = this.parseUnary(e + 1, t);
			n = this.make({
				kind: "binary",
				op: "*",
				left: n,
				right: i,
				offset: r.offset
			}, r.offset, e);
		}
		return n;
	}
	parseUnary(e, t) {
		let n = this.peek();
		if (n.kind === "punct" && (n.value === "+" || n.value === "-")) {
			this.take();
			let r = this.parseUnary(e + 1, t);
			return n.value === "+" ? r : this.make({
				kind: "unary",
				op: "-",
				operand: r,
				offset: n.offset
			}, n.offset, e);
		}
		return this.parsePower(e, t);
	}
	parsePower(e, t) {
		let n = this.parseAtom(e + 1, t), r = this.peek();
		if (r.kind === "punct" && r.value === "^") {
			this.take();
			let t = this.parseScriptArgument(e + 1);
			return this.make({
				kind: "binary",
				op: "^",
				left: n,
				right: t,
				offset: r.offset
			}, r.offset, e);
		}
		return n;
	}
	parseScriptArgument(e) {
		if (this.atPunct("{")) return this.parseBraceGroup(e + 1);
		if (this.atPunct("+") || this.atPunct("-")) {
			let t = this.take(), n = this.parseUnary(e + 1, !1);
			return t.value === "+" ? n : this.make({
				kind: "unary",
				op: "-",
				operand: n,
				offset: t.offset
			}, t.offset, e);
		}
		return this.parseUnary(e + 1, !1);
	}
	parseAtom(e, t) {
		let n = this.peek();
		if (n.kind === "number") {
			this.take();
			let t = Number(n.value);
			if (!Number.isFinite(t)) throw new F("latex-number", `Number "${n.value}" is not finite.`, n.offset);
			return this.make({
				kind: "number",
				value: t,
				offset: n.offset
			}, n.offset, e);
		}
		if (n.kind === "letter") return this.take(), this.variable(n.value, n.offset, e);
		if (n.kind === "punct") {
			if (n.value === "(") return this.parseParenthesized(e);
			if (n.value === "{") return this.parseBraceGroup(e);
			if (n.value === "[") return this.parseBracketGroup(e);
			if (n.value === "|") return this.parsePlainAbs(e, n.offset);
			throw new F("latex-syntax", `Cannot start an expression with "${n.value}".`, n.offset);
		}
		if (n.kind === "command") {
			let t = n.value;
			if (t === "frac" || t === "dfrac" || t === "tfrac") {
				this.take();
				let t = this.parseArgument(e + 1), r = this.parseArgument(e + 1);
				return this.make({
					kind: "binary",
					op: "/",
					left: t,
					right: r,
					offset: n.offset
				}, n.offset, e);
			}
			if (t === "sqrt") {
				this.take();
				let t = null;
				this.atPunct("[") && (this.take(), t = this.parseAdditive(e + 1), this.expectPunct("]"));
				let r = this.parseArgument(e + 1);
				return this.make({
					kind: "call",
					name: "sqrt",
					args: [r],
					base: t,
					power: null,
					offset: n.offset
				}, n.offset, e);
			}
			if (t === "left") return this.parseLeft(e);
			if (Qe.has(t)) return this.parseFunction(t, e);
			if (t === "pi") return this.take(), this.make({
				kind: "constant",
				value: "pi",
				offset: n.offset
			}, n.offset, e);
			if (tt(t)) return this.take(), this.variable(Ze[t], n.offset, e);
			if (t === "mathrm") {
				this.take();
				let t = this.readRawGroup();
				if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(t.raw)) throw new F("latex-name", "\\mathrm requires a valid parameter name.", t.offset);
				return this.variable(t.raw, n.offset, e);
			}
			if (t === "begin") return this.parseCases(e);
			if (t === "lvert" || t === "vert") return this.parseCommandAbs(e, n.offset);
			throw t === "right" ? new F("latex-syntax", "\\right has no matching \\left.", n.offset) : t === "text" ? new F("latex-unsupported", "\\text is only allowed as the otherwise condition of a piecewise function.", n.offset) : new F("latex-unsupported", `Command \\${t} is not supported for computation.`, n.offset);
		}
		throw new F("latex-syntax", "Expression is incomplete.", n.offset);
	}
	parseArgument(e) {
		if (this.atPunct("{")) return this.parseBraceGroup(e + 1);
		if (this.peek().kind === "eof") throw new F("latex-syntax", "Command is missing an argument.", this.peek().offset);
		return this.parseUnary(e + 1, !1);
	}
	parseParenthesized(e) {
		let t = this.expectPunct("(");
		if (this.atPunct(")")) throw new F("latex-syntax", "Missing expression inside parentheses.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct(")"), n;
	}
	parseBraceGroup(e) {
		let t = this.expectPunct("{");
		if (this.atPunct("}")) throw new F("latex-syntax", "Missing expression inside braces.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct("}"), n;
	}
	parseBracketGroup(e) {
		let t = this.expectPunct("[");
		if (this.atPunct("]")) throw new F("latex-syntax", "Missing expression inside brackets.", t.offset);
		let n = this.parseAdditive(e + 1);
		return this.expectPunct("]"), n;
	}
	parsePlainAbs(e, t) {
		if (this.take(), this.atPunct("|")) throw new F("latex-syntax", "Absolute value is missing its contents.", t);
		let n = this.parseAdditive(e + 1);
		if (this.atPunct("|")) this.take();
		else if (this.atCommand("rvert")) this.take();
		else throw new F("latex-syntax", "Unpaired absolute value bar.", t);
		return this.make({
			kind: "abs",
			value: n,
			offset: t
		}, t, e);
	}
	parseCommandAbs(e, t) {
		if (this.take(), this.atCommand("rvert") || this.atCommand("vert") || this.atPunct("|")) throw new F("latex-syntax", "Absolute value is missing its contents.", t);
		let n = this.parseAdditive(e + 1);
		if (this.atCommand("rvert") || this.atCommand("vert") || this.atPunct("|")) this.take();
		else throw new F("latex-syntax", "Unpaired absolute value bar.", t);
		return this.make({
			kind: "abs",
			value: n,
			offset: t
		}, t, e);
	}
	parseLeft(e) {
		let t = this.take(), n = this.readDelimiter(), r = this.parseAdditive(e + 1);
		if (!this.atCommand("right")) throw new F("latex-syntax", "\\left has no matching \\right.", t.offset);
		this.take();
		let i = this.readDelimiter();
		if (n === "|" && i !== "|") throw new F("latex-syntax", "Unpaired absolute value bar.", t.offset);
		return n === "|" ? this.make({
			kind: "abs",
			value: r,
			offset: t.offset
		}, t.offset, e) : r;
	}
	readDelimiter() {
		let e = this.peek();
		if (e.kind === "punct" && (e.value === "(" || e.value === ")" || e.value === "[" || e.value === "]" || e.value === "|" || e.value === ".")) return this.take(), e.value;
		if (e.kind === "command" && (e.value === "lbrace" || e.value === "rbrace" || e.value === "lvert" || e.value === "rvert" || e.value === "vert" || e.value === "Vert")) return this.take(), e.value === "lbrace" || e.value === "rbrace" ? "{" : e.value === "lvert" || e.value === "rvert" || e.value === "vert" ? "|" : "Vert";
		throw new F("latex-syntax", "Missing delimiter after \\left/\\right.", e.offset);
	}
	variable(e, t, n) {
		if (e === "y" && !this.allowY) throw new F("latex-name", "y is the plot output marker and cannot appear in the expression.", t);
		return e === "e" || e === "pi" ? this.make({
			kind: "constant",
			value: e,
			offset: t
		}, t, n) : this.make({
			kind: "variable",
			name: e,
			offset: t
		}, t, n);
	}
	parseFunction(e, t) {
		let n = this.take().offset, r = null, i = null;
		e === "log" && this.atPunct("_") && (this.take(), r = this.parseScriptArgument(t + 1)), this.atPunct("^") && (this.take(), i = this.parseScriptArgument(t + 1));
		let a = [];
		if ((e === "min" || e === "max") && this.atPunct("(")) {
			if (this.take(), this.atPunct(")")) throw new F("latex-syntax", `\\${e} requires at least one argument.`, n);
			for (a.push(this.parseAdditive(t + 1)); this.atPunct(",");) this.take(), a.push(this.parseAdditive(t + 1));
			this.expectPunct(")");
		} else a.push(this.parseFunctionArgument(t + 1));
		return this.make({
			kind: "call",
			name: e,
			args: a,
			base: r,
			power: i,
			offset: n
		}, n, t);
	}
	parseFunctionArgument(e) {
		if (this.atPunct("(")) {
			this.take();
			let t = this.parseAdditive(e + 1);
			return this.expectPunct(")"), t;
		}
		return this.parseMultiplicative(e + 1, !0);
	}
	parseCases(e) {
		let t = this.take(), n = this.readRawGroup();
		if (n.raw.trim() !== "cases") throw new F("latex-unsupported", `Environment "${n.raw.trim()}" is not supported.`, n.offset);
		let r = [];
		for (; !this.atCommand("end");) {
			if (this.peek().kind === "eof") throw new F("latex-syntax", "cases environment is missing \\end{cases}.", t.offset);
			if (this.atCommand("newline")) {
				this.take();
				continue;
			}
			let n = this.parseAdditive(e + 1);
			this.atPunct(",") && this.take();
			let i = null;
			if (this.atPunct("&") && (this.take(), i = this.parseCaseCondition(e + 1), this.atPunct(",") && this.take()), r.push({
				value: n,
				when: i
			}), this.atCommand("newline")) {
				this.take();
				continue;
			}
			if (this.atCommand("end")) break;
			let a = this.peek();
			throw new F("latex-syntax", `Unexpected "${this.raw(a)}" after a cases branch.`, a.offset);
		}
		let i = this.take();
		if (this.readRawGroup().raw.trim() !== "cases") throw new F("latex-syntax", "\\begin{cases} must be closed with \\end{cases}.", i.offset);
		if (r.length === 0) throw new F("latex-syntax", "cases environment has no branches.", t.offset);
		return this.make({
			kind: "cases",
			branches: r,
			offset: t.offset
		}, t.offset, e);
	}
	parseCaseCondition(e) {
		if (this.atCommand("text")) {
			let e = this.take(), t = this.readRawGroup();
			if (t.raw.trim() !== "otherwise") throw new F("latex-unsupported", `Unsupported piecewise condition text "${t.raw.trim()}".`, e.offset);
			return null;
		}
		let t = this.parseAdditive(e + 1), n = this.peek(), r = rt(n);
		if (!r) throw new F("latex-syntax", "Piecewise condition requires one comparison.", n.offset);
		return this.take(), {
			op: r,
			left: t,
			right: this.parseAdditive(e + 1)
		};
	}
	readRawGroup() {
		let e = this.expectPunct("{"), t = 1, n = this.pos;
		for (; n < this.tokens.length; n += 1) {
			let e = this.tokens[n];
			if (e.kind === "eof") break;
			if (e.kind === "punct") {
				if (e.value === "{") t += 1;
				else if (e.value === "}" && (--t, t === 0)) break;
			}
		}
		if (n >= this.tokens.length || this.tokens[n].kind === "eof") throw new F("latex-syntax", "Unclosed brace.", e.offset);
		let r = this.tokens[n];
		return this.pos = n + 1, {
			raw: this.source.slice(e.offset + 1, r.offset),
			offset: e.offset + 1
		};
	}
};
function at(e, t) {
	switch (e.kind) {
		case "variable":
			e.name !== "x" && t.add(e.name);
			return;
		case "number":
		case "constant": return;
		case "unary":
			at(e.operand, t);
			return;
		case "binary":
			at(e.left, t), at(e.right, t);
			return;
		case "abs":
			at(e.value, t);
			return;
		case "call":
			e.base && at(e.base, t), e.power && at(e.power, t);
			for (let n of e.args) at(n, t);
			return;
		case "cases":
			for (let n of e.branches) at(n.value, t), n.when && (at(n.when.left, t), at(n.when.right, t));
			return;
	}
}
function ot(e, t, n, r) {
	let i = [], a = (t) => {
		switch (t.kind) {
			case "variable": {
				if (r.has(t.name)) return;
				let a = n + t.offset, o = a + 1;
				e.startsWith("\\mathrm", t.offset) ? o = n + e.indexOf("}", t.offset) + 1 : e[t.offset] === "\\" && (o = a + 1 + t.name.length), i.push({
					name: t.name,
					range: {
						start: a,
						end: o
					}
				});
				return;
			}
			case "unary":
				a(t.operand);
				return;
			case "binary":
				a(t.left), a(t.right);
				return;
			case "abs":
				a(t.value);
				return;
			case "call":
				t.base && a(t.base), t.power && a(t.power), t.args.forEach(a);
				return;
			case "cases":
				for (let e of t.branches) a(e.value), e.when && (a(e.when.left), a(e.when.right));
				return;
			case "number":
			case "constant": return;
		}
	};
	return a(t), i;
}
function st(e) {
	let t = e.trim(), n = e.length - e.trimStart().length, r = St(t);
	if (r) {
		let e = /* @__PURE__ */ new Set([
			"x",
			"y",
			"t"
		]), t = [];
		for (let i of [{
			text: r.x,
			offset: r.xOffset
		}, {
			text: r.y,
			offset: r.yOffset
		}]) {
			_t(i.text);
			let r = new it(i.text, et(i.text)).parseDocument();
			t.push(...ot(i.text, r, n + i.offset, e));
		}
		return t.sort((e, t) => e.range.start - t.range.start);
	}
	try {
		return ot(e, new it(e, et(e)).parseDocument(), 0, /* @__PURE__ */ new Set(["x", "y"])).sort((e, t) => e.range.start - t.range.start);
	} catch (t) {
		try {
			let t = new it(e, et(e), { allowY: !0 }).parseEquation(), n = /* @__PURE__ */ new Set(["x", "y"]);
			return [...ot(e, t.left, 0, n), ...ot(e, t.right, 0, n)].sort((e, t) => e.range.start - t.range.start);
		} catch {
			throw t;
		}
	}
}
function L(e, t, n) {
	throw new F(e, t, n);
}
function ct(e, t) {
	return Number.isFinite(e) || L("latex-number", "Result is not finite.", t), e;
}
function lt(e, t, n) {
	if (e === "x") return t.x;
	let r = t.env[e];
	return r === void 0 && !Object.prototype.hasOwnProperty.call(t.env, e) && L("latex-variable", `Parameter "${e}" is not declared.`, n), typeof r == "number" && Number.isFinite(r) || L("latex-type", `Parameter "${e}" must be a finite number.`, n), r;
}
function ut(e, t, n) {
	return e === 0 && t < 0 && L("latex-divide-by-zero", "Negative powers of zero are undefined.", n), e < 0 && !Number.isInteger(t) && L("latex-domain", "A negative base with a non-integer exponent is not real.", n), ct(e ** +t, n);
}
function dt(e, t, n) {
	let r = t ?? 2;
	return (!Number.isFinite(r) || r <= 0) && L("latex-domain", "Root index must be positive.", n), e < 0 ? (Number.isInteger(r) && r % 2 != 0 || L("latex-domain", "A negative number has no real even root.", n), ct(r === 3 ? -Math.cbrt(-e) : -((-e) ** (1 / r)), n)) : ct(e ** (1 / r), n);
}
function ft(e, t) {
	let n = mt(e.left, t), r = mt(e.right, t);
	switch (e.op) {
		case "eq": return n === r;
		case "ne": return n !== r;
		case "lt": return n < r;
		case "le": return n <= r;
		case "gt": return n > r;
		case "ge": return n >= r;
		default: return !1;
	}
}
function pt(e, t) {
	let n = e.args.map((e) => mt(e, t)), r = 0;
	switch (e.name) {
		case "sin":
			r = Math.sin(n[0]);
			break;
		case "cos":
			r = Math.cos(n[0]);
			break;
		case "tan":
			Math.abs(Math.cos(n[0])) < 1e-15 && L("latex-domain", "tan is undefined at this point.", e.offset), r = Math.tan(n[0]);
			break;
		case "arcsin":
			(n[0] < -1 || n[0] > 1) && L("latex-domain", "arcsin argument must be in [-1, 1].", e.offset), r = Math.asin(n[0]);
			break;
		case "arccos":
			(n[0] < -1 || n[0] > 1) && L("latex-domain", "arccos argument must be in [-1, 1].", e.offset), r = Math.acos(n[0]);
			break;
		case "arctan":
			r = Math.atan(n[0]);
			break;
		case "exp":
			r = Math.exp(n[0]);
			break;
		case "ln":
			n[0] <= 0 && L("latex-domain", "ln argument must be positive.", e.offset), r = Math.log(n[0]);
			break;
		case "log": {
			let i = e.base ? mt(e.base, t) : 10;
			(i <= 0 || i === 1) && L("latex-domain", "Logarithm base must be positive and not equal to 1.", e.offset), n[0] <= 0 && L("latex-domain", "Logarithm argument must be positive.", e.offset), r = Math.log(n[0]) / Math.log(i);
			break;
		}
		case "min":
			r = Math.min(...n);
			break;
		case "max":
			r = Math.max(...n);
			break;
		case "sqrt":
			r = dt(n[0], e.base ? mt(e.base, t) : null, e.offset);
			break;
		default: L("latex-unsupported", "Unsupported function.", e.offset);
	}
	return e.power && (r = ut(r, mt(e.power, t), e.offset)), ct(r, e.offset);
}
function mt(e, t) {
	let n = e.offset;
	t.steps += 1, t.depth += 1;
	try {
		switch (t.steps > t.limit && L("latex-budget", "Math evaluation exceeded its budget.", n), t.depth > Ke && L("latex-budget", "Math evaluation is nested too deeply.", n), e.kind) {
			case "number": return e.value;
			case "constant": return e.value === "pi" ? Math.PI : Math.E;
			case "variable": return lt(e.name, t, e.offset);
			case "unary": {
				let n = mt(e.operand, t);
				return e.op === "-" ? -n : n;
			}
			case "binary": {
				let n = mt(e.left, t), r = mt(e.right, t);
				switch (e.op) {
					case "+": return ct(n + r, e.offset);
					case "-": return ct(n - r, e.offset);
					case "*": return ct(n * r, e.offset);
					case "/": return r === 0 && L("latex-divide-by-zero", "Division by zero.", e.offset), ct(n / r, e.offset);
					case "^": return ut(n, r, e.offset);
				}
				break;
			}
			case "abs": return ct(Math.abs(mt(e.value, t)), e.offset);
			case "call": return pt(e, t);
			case "cases":
				for (let n of e.branches) if (n.when === null || ft(n.when, t)) return mt(n.value, t);
				L("latex-undefined", "No piecewise branch matched.", e.offset);
		}
		L("latex-unsupported", "Cannot compute this math structure.", n);
	} finally {
		--t.depth;
	}
}
var ht = /* @__PURE__ */ new Map();
function gt(e, t, n) {
	return {
		source: e,
		dependencies: n,
		evaluate(e, n, r) {
			if (typeof e != "number" || !Number.isFinite(e)) throw new F("latex-variable", "Plot input x must be a finite number.", 0);
			let i = {
				x: e,
				env: n ?? {},
				steps: r?.steps ?? 0,
				limit: r?.limit ?? Ge,
				depth: 0
			};
			try {
				return mt(t, i);
			} finally {
				r && (r.steps = i.steps);
			}
		}
	};
}
function _t(e) {
	if (typeof e != "string") throw new F("latex-syntax", "Math source must be a string.", 0);
	if (e.length > I) throw new F("latex-budget", "Formula exceeds the length limit.", I);
	let t = ht.get(e);
	if (t) return t;
	let n = new it(e, et(e)).parseDocument(), r = /* @__PURE__ */ new Set();
	at(n, r);
	let i = gt(e, n, [...r]);
	return ht.size >= 512 && ht.clear(), ht.set(e, i), i;
}
function vt(e, t) {
	switch (e.kind) {
		case "variable": return e.name === t;
		case "number":
		case "constant": return !1;
		case "unary": return vt(e.operand, t);
		case "binary": return vt(e.left, t) || vt(e.right, t);
		case "abs": return vt(e.value, t);
		case "call": return e.base !== null && vt(e.base, t) || e.power !== null && vt(e.power, t) || e.args.some((e) => vt(e, t));
		case "cases": return e.branches.some((e) => vt(e.value, t) || e.when !== null && (vt(e.when.left, t) || vt(e.when.right, t)));
	}
}
function yt(e, t) {
	return e.kind === "variable" && e.name === t;
}
function bt(e) {
	let t = 0;
	for (let n = 0; n < e.length; n += 1) {
		let r = e[n];
		if (r === "{") t += 1;
		else if (r === "}") t = Math.max(0, t - 1);
		else if (r === "=" && t === 0) return n;
	}
	return -1;
}
function xt(e, t) {
	let n = [], r = 0, i = 0, a = (r) => {
		let a = e.slice(i, r), o = a.length - a.trimStart().length, s = a.trim();
		s && n.push({
			text: s,
			offset: t + i + o
		});
	};
	for (let t = 0; t < e.length; t += 1) {
		let n = e[t];
		n === "{" ? r += 1 : n === "}" ? r = Math.max(0, r - 1) : n === "\\" && e[t + 1] === "\\" && r === 0 && (a(t), i = t + 2, t += 1);
	}
	return a(e.length), n;
}
function St(e) {
	let t = /^\\begin\{cases\}([\s\S]*)\\end\{cases\}$/u.exec(e);
	if (!t) return null;
	let n = t.index + 13, r = xt(t[1], n);
	if (r.length !== 2) return null;
	let i = null, a = null;
	for (let e of r) {
		let t = bt(e.text);
		if (t < 0) return null;
		let n = e.text.slice(0, t).trim(), r = e.text.slice(t + 1), o = r.length - r.trimStart().length, s = r.trim();
		if (!s) return null;
		let c = e.offset + t + 1 + o;
		if (n === "x" && i === null) i = {
			text: s,
			offset: c
		};
		else if (n === "y" && a === null) a = {
			text: s,
			offset: c
		};
		else return null;
	}
	return i !== null && a !== null ? {
		x: i.text,
		y: a.text,
		xOffset: i.offset,
		yOffset: a.offset
	} : null;
}
function Ct(e) {
	let t = e.trim();
	if (!t) return null;
	if (/^\\begin\{cases\}/u.test(t)) return "parametric";
	let n = bt(t);
	if (n < 0) return null;
	if (t.slice(0, n).trim() !== "y") return "implicit";
	try {
		let { right: e } = new it(t, et(t), { allowY: !0 }).parseEquation();
		return vt(e, "y") ? "implicit" : "explicit";
	} catch {
		return "explicit";
	}
}
function wt(e) {
	if (typeof e != "string") throw new F("latex-syntax", "Math source must be a string.", 0);
	if (e.length > I) throw new F("latex-budget", "Formula exceeds the length limit.", I);
	let t = e.trim();
	if (!t) throw new F("latex-empty", "Formula is empty.", 0);
	let n = St(t);
	if (n) {
		let e = (e) => et(e).some((e) => e.kind === "letter" && e.value === "x");
		if (e(n.x) || e(n.y)) throw new F("latex-variable", "Parametric formulas use t and cannot read x.", 0);
		let r = _t(n.x), i = _t(n.y), a = /* @__PURE__ */ new Set();
		for (let e of [...r.dependencies, ...i.dependencies]) e !== "t" && e !== "x" && e !== "y" && a.add(e);
		return {
			kind: "parametric",
			source: t,
			expression: r,
			yExpression: i,
			dependencies: [...a]
		};
	}
	let { left: r, right: i } = new it(t, et(t), { allowY: !0 }).parseEquation();
	if (yt(r, "y") && !vt(i, "y")) {
		let e = _t(t);
		return {
			kind: "explicit",
			source: t,
			expression: e,
			yExpression: null,
			dependencies: e.dependencies
		};
	}
	let a = {
		kind: "binary",
		op: "-",
		left: r,
		right: i,
		offset: r.offset
	}, o = /* @__PURE__ */ new Set();
	return at(a, o), o.delete("x"), o.delete("y"), {
		kind: "implicit",
		source: t,
		expression: gt(t, a, [...o]),
		yExpression: null,
		dependencies: [...o]
	};
}
function Tt(e, t, n, r) {
	try {
		return e.evaluate(t, n, r);
	} catch (e) {
		if (e instanceof F) {
			if (e.code === "latex-budget") throw e;
			return null;
		}
		throw e;
	}
}
function Et(e) {
	if (e.length === 0) return 0;
	let t = [...e].sort((e, t) => e - t);
	return t[Math.floor(t.length / 2)];
}
function Dt(e, t, n, r, i, a) {
	let o = n - e;
	if (!(o > 0)) return !1;
	let s = 0, c = 0;
	for (let i = 1; i <= Je; i += 1) {
		let l = 1 << i, u = o / l, d = t, f = 0;
		for (let t = 1; t <= l; t += 1) {
			let i = t === l ? n : e + t * u, o = t === l ? r : a(i);
			if (o === null) return !0;
			let s = Math.abs(o - d) / u;
			s > f && (f = s), d = o;
		}
		i === 2 && (s = f), c = f;
	}
	return c > Math.max(s * 6, i * 12, 1e-9);
}
function Ot(e, t, n, r, i = 200, a) {
	if (!Number.isFinite(n) || !Number.isFinite(r)) throw new F("latex-plot-range", "Plot min/max must be finite numbers.", 0);
	if (!(n < r)) throw new F("latex-plot-range", "Plot min must be less than max.", 0);
	if (!Number.isInteger(i) || i < 2 || i > qe) throw new F("latex-plot-samples", `Sample count must be an integer between 2 and ${qe}.`, 0);
	let o = {
		steps: 0,
		limit: Math.max(Ye, i * 1024)
	}, s = (n) => {
		let r = o.limit - o.steps, i = a ? Number.isFinite(a.limit) && Number.isFinite(a.steps) ? a.limit - a.steps : 0 : Infinity, s = {
			steps: 0,
			limit: Math.max(0, Math.min(r, i))
		};
		try {
			return Tt(e, n, t, s);
		} finally {
			o.steps += s.steps, a && (a.steps = Number.isFinite(a.steps) ? a.steps + s.steps : s.steps);
		}
	}, c = (r - n) / (i - 1), l = [];
	for (let e = 0; e < i; e += 1) {
		let t = e === i - 1 ? r : n + e * c;
		l.push({
			x: t,
			y: s(t)
		});
	}
	let u = l.map((e) => e.y).filter((e) => e !== null).map((e) => Math.abs(e)), d = Math.max(1e-9, Et(u) * 8);
	for (let e = 1; e < l.length - 1; e += 1) {
		let t = l[e - 1].y, n = l[e].y, r = l[e + 1].y;
		t !== null && n !== null && r !== null && Math.abs(n) > Math.max(1, Math.abs(t), Math.abs(r)) * 100 && Math.abs(n) > d && (l[e] = {
			x: l[e].x,
			y: null
		});
	}
	let f = l.length - 1, p = l[f].y, m = f > 0 ? l[f - 1].y : null;
	p !== null && m !== null && Math.abs(p) > Math.max(1, Math.abs(m)) * 100 && Math.abs(p) > d && (p = null, l[f] = {
		x: l[f].x,
		y: null
	});
	let h = [], g = [];
	for (let e = 0; e < l.length - 1; e += 1) {
		let t = l[e], n = l[e + 1];
		if (t.y === null || n.y === null) continue;
		let r = Math.abs(n.y - t.y);
		h.push(r);
		let i = n.x - t.x;
		i > 0 && g.push(r / i);
	}
	let _ = Et(h), v = Et(g);
	for (let e = 0; e < l.length - 1; e += 1) {
		let t = l[e], n = l[e + 1], r = t.y, i = n.y;
		if (r === null || i === null) continue;
		let a = () => {
			l[e + 1] = {
				x: n.x,
				y: null
			};
		}, o = s(t.x + (n.x - t.x) / 2);
		if (o === null) {
			a();
			continue;
		}
		let c = Math.abs(i - r);
		(Math.abs(o - (r + i) / 2) > Math.max(c * .25, _ * .4, 1e-9) || c > Math.max(_ * 16, 1e-9)) && Dt(t.x, r, n.x, i, v, (e) => s(e)) && a();
	}
	return {
		points: l,
		endpoint: p
	};
}
function kt(e, t, n, r) {
	if (!Number.isFinite(e) || !Number.isFinite(t)) throw new F("latex-plot-range", "Plot min/max must be finite numbers.", 0);
	if (!(e < t)) throw new F("latex-plot-range", "Plot min must be less than max.", 0);
	if (!Number.isInteger(n) || n < 2 || n > r) throw new F("latex-plot-samples", `Sample count must be an integer between 2 and ${r}.`, 0);
}
function At(e, t) {
	let n = e.limit - e.steps, r = t ? Number.isFinite(t.limit) && Number.isFinite(t.steps) ? t.limit - t.steps : 0 : Infinity;
	return {
		steps: 0,
		limit: Math.max(0, Math.min(n, r))
	};
}
function jt(e, t, n) {
	e.steps += n.steps, t && (t.steps = Number.isFinite(t.steps) ? t.steps + n.steps : n.steps);
}
function Mt(e, t, n, r, i, a = 200, o) {
	kt(r, i, a, qe);
	let s = {
		steps: 0,
		limit: Math.max(Ye, a * 2048)
	}, c = (i - r) / (a - 1), l = [];
	for (let u = 0; u < a; u += 1) {
		let d = u === a - 1 ? i : r + u * c, f = {
			...n,
			t: d
		}, p = At(s, o), m = null;
		try {
			m = Tt(e, d, f, p);
		} finally {
			jt(s, o, p);
		}
		let h = At(s, o), g = null;
		try {
			g = m === null ? null : Tt(t, d, f, h);
		} finally {
			jt(s, o, h);
		}
		l.push({
			x: m === null || !Number.isFinite(m) ? NaN : m,
			y: m === null || g === null || !Number.isFinite(g) ? null : g,
			t: d
		});
	}
	let u = l[l.length - 1];
	return {
		points: l,
		endpoint: u && u.y !== null ? u.y : null
	};
}
var Nt = 100, Pt = 32;
function Ft(e) {
	return Math.max(32, Math.min(100, Math.floor(e)));
}
function It(e, t, n, r, i, a) {
	let o = n - a, s = o === 0 ? .5 : Math.max(0, Math.min(1, n / o));
	return {
		x: e + (r - e) * s,
		y: t + (i - t) * s
	};
}
function Lt(e, t) {
	switch (e) {
		case 1: return [[3, 0]];
		case 2: return [[0, 1]];
		case 3: return [[3, 1]];
		case 4: return [[1, 2]];
		case 5: return t ? [[0, 1], [2, 3]] : [[3, 0], [1, 2]];
		case 6: return [[0, 2]];
		case 7: return [[3, 2]];
		case 8: return [[2, 3]];
		case 9: return [[0, 2]];
		case 10: return t ? [[3, 0], [1, 2]] : [[0, 1], [2, 3]];
		case 11: return [[1, 2]];
		case 12: return [[3, 1]];
		case 13: return [[0, 1]];
		case 14: return [[3, 0]];
		default: return [];
	}
}
function Rt(e, t, n, r, i) {
	if (e.length === 0) return [];
	let a = n - t || 1, o = i - r || 1, s = (e) => `${Math.round((e.x - t) / a * 1e7)},${Math.round((e.y - r) / o * 1e7)}`, c = /* @__PURE__ */ new Map(), l = (e, t) => {
		let n = c.get(e);
		n ? n.push(t) : c.set(e, [t]);
	};
	e.forEach((e, t) => {
		l(s(e.a), t), l(s(e.b), t);
	});
	let u = new Uint8Array(e.length), d = [], f = (t, n) => {
		let r = c.get(s(n));
		if (!r) return !1;
		for (let i of r) {
			if (u[i]) continue;
			let r = e[i], a = s(r.a) === s(n) ? r.b : r.a;
			if (s(a) === s(n)) u[i] = 1;
			else return u[i] = 1, t.push(a), !0;
		}
		return !1;
	};
	for (let t = 0; t < e.length; t += 1) {
		if (u[t]) continue;
		let n = e[t];
		if (s(n.a) === s(n.b)) {
			u[t] = 1;
			continue;
		}
		u[t] = 1;
		let r = [n.a, n.b], i = 0;
		for (; i < e.length && f(r, r[r.length - 1]);) i += 1;
		for (r.reverse(), i = 0; i < e.length && f(r, r[r.length - 1]);) i += 1;
		r.reverse(), d.push(r);
	}
	return d;
}
function zt(e, t, n, r, i, a, o = 100, s) {
	if (kt(n, r, o, 100), !Number.isFinite(i) || !Number.isFinite(a) || !(i < a)) throw new F("latex-plot-range", "The vertical plot range must be finite and increasing.", 0);
	let c = {
		steps: 0,
		limit: Math.max(Ye, o * o * 2048)
	}, l = o + 1, u = Array(l * l).fill(null), d = (r - n) / o, f = (a - i) / o;
	for (let p = 0; p <= o; p += 1) {
		let m = p === o ? a : i + p * f, h = {
			...t,
			y: m
		};
		for (let t = 0; t <= o; t += 1) {
			let i = t === o ? r : n + t * d, a = At(c, s), f = null;
			try {
				f = Tt(e, i, h, a);
			} finally {
				jt(c, s, a);
			}
			u[p * l + t] = f !== null && Number.isFinite(f) ? f : null;
		}
	}
	let p = [], m = (e, t) => u[t * l + e];
	for (let e = 0; e < o; e += 1) {
		let t = e + 1 === o, s = t ? a - f : i + e * f, c = t ? a : i + (e + 1) * f;
		for (let t = 0; t < o; t += 1) {
			let i = t + 1 === o, a = i ? r - d : n + t * d, l = i ? r : n + (t + 1) * d, u = m(t, e), f = m(t + 1, e), h = m(t + 1, e + 1), g = m(t, e + 1);
			if (u === null || f === null || h === null || g === null) continue;
			let _ = u >= 0 | (f >= 0 ? 2 : 0) | (h >= 0 ? 4 : 0) | (g >= 0 ? 8 : 0);
			if (_ === 0 || _ === 15) continue;
			let v = [
				It(a, s, u, l, s, f),
				It(l, s, f, l, c, h),
				It(a, c, g, l, c, h),
				It(a, s, u, a, c, g)
			], y = (u + f + h + g) / 4;
			for (let [e, t] of Lt(_, y >= 0)) p.push({
				a: v[e],
				b: v[t]
			});
		}
	}
	return Rt(p, n, r, i, a);
}
// src/local/compilation/dependencies.ts
var Bt = /* @__PURE__ */ new Map(), Vt = /* @__PURE__ */ new WeakMap(), Ht = /* @__PURE__ */ new WeakMap();
function Ut(e) {
	let t = e.snapshot().revision, r = Ht.get(e);
	if (r?.revision === t) return r.tokens;
	let i = /* @__PURE__ */ new Map(), a = /* @__PURE__ */ new WeakMap();
	for (let t of n(e.document.nodes, !0)) {
		let n = e.resetToken(t);
		for (let e of t.children ?? []) n += a.get(e);
		i.set(t.id, n), a.set(t, n);
	}
	return Ht.set(e, {
		revision: t,
		tokens: i
	}), i;
}
function Wt(e, t) {
	for (let n of t) e.add(n);
}
function Gt(e) {
	let t = Vt.get(e);
	if (t !== void 0) return t;
	let r = e.dependencies;
	if (r !== void 0) {
		let t = new Map(Object.entries(r));
		return Vt.set(e, t), t;
	}
	let i = /* @__PURE__ */ new Map(), a = l(e), o = /* @__PURE__ */ new Map(), s = /* @__PURE__ */ new Set();
	for (let [t, n] of Object.entries(e.bindings)) {
		for (let e of n.nodeIds) s.add(e);
		if (!t.startsWith("@")) for (let e of n.nodeIds) {
			let n = o.get(e) ?? [];
			n.push(t), o.set(e, n);
		}
	}
	let c = (e) => o.get(e.id) ?? [oe(e)], u = (t, n) => {
		let r = e.bindingSlots?.[n.id];
		if (r !== void 0) {
			t.add(oe(n));
			for (let e of Object.values(r)) t.add(e);
		}
	}, d = /* @__PURE__ */ new WeakMap();
	for (let t of n(e.nodes, !0)) {
		let n = /* @__PURE__ */ new Set(), r = !1;
		if (t.attrs !== void 0) for (let e of Object.values(t.attrs)) try {
			Wt(n, O(e));
		} catch {
			r = !0;
			break;
		}
		if (!r) {
			if (t.type === "interpolation") try {
				Wt(n, ce(t.value ?? "").dependencies);
			} catch {
				r = !0;
			}
			else if (t.type === "math") try {
				Wt(n, _t(t.value ?? "").dependencies);
			} catch {
				r = !0;
			}
			else if (t.name !== void 0) {
				if (a) {
					let r = a.dependencyRules?.[t.id];
					if (r?.selfBinding) {
						let e = r.selfBinding.attribute;
						(r.selfBinding.mode === "always" || e !== void 0 && (t.attrs?.[e] ?? "").trim() !== "") && Wt(n, c(t));
					}
					if (r?.inlineMathReads) for (let e of t.children ?? []) {
						if (e.type !== "inlineMath") continue;
						let t = (e.value ?? "").trim();
						if (/^y\s*=/u.test(t)) try {
							Wt(n, _t(t).dependencies);
						} catch {}
					}
					r || (e.bindingSlots?.[t.id] !== void 0 && n.add(oe(t)), s.has(t.id) && Wt(n, c(t)), u(n, t));
				} else {
					let e = t.name ? Se.find((e) => e.name === t.name) : void 0, r = e ? x(e) : [], i = r.find((e) => e.kind === "self-binding-read"), a = r.some((e) => e.kind === "inline-math-reads");
					if (i ? (i.mode === "always" || i.attribute !== void 0 && (t.attrs?.[i.attribute] ?? "").trim() !== "") && Wt(n, c(t)) : !a && s.has(t.id) && Wt(n, c(t)), a) for (let e of t.children ?? []) {
						if (e.type !== "inlineMath") continue;
						let t = (e.value ?? "").trim();
						if (/^y\s*=/u.test(t)) try {
							Wt(n, _t(t).dependencies);
						} catch {}
					}
					u(n, t);
				}
			}
		}
		let o = !1;
		for (let e of t.children ?? []) {
			let t = d.get(e);
			t === null ? o = !0 : Wt(n, t);
		}
		let l = r || o ? null : [...n];
		i.set(t.id, l), d.set(t, l);
	}
	return Vt.set(e, i), i;
}
function Kt(e) {
	if (e.dependencies !== void 0) return;
	let t = Gt(e), n = Object.create(null);
	for (let [e, r] of t) n[e] = r === null ? null : Object.freeze([...r]);
	e.dependencies = Object.freeze(n);
}
// src/local/markdown/heading-anchors.ts
function qt(e, t) {
	return (e ?? []).map((e) => {
		switch (e.type) {
			case "text":
			case "inlineCode":
			case "inlineMath":
			case "fallback": return e.value ?? "";
			case "image": return e.alt ?? "";
			case "break": return " ";
			case "interpolation": try {
				let n = ce(e.value ?? "").evaluate(t);
				return Array.isArray(n) ? "Cannot compute" : n === null ? "" : String(n);
			} catch {
				return "Cannot compute";
			}
			default: return qt(e.children, t);
		}
	}).join("");
}
function Jt(e) {
	return e.trim().toLowerCase().replace(/[^\p{L}\p{N}\p{M}\s_-]/gu, "").replace(/\s+/g, "-") || "section";
}
function Yt(e, t) {
	let n = /* @__PURE__ */ new Map(), r = t ?? (Array.isArray(e.componentDefinitions) ? e.componentDefinitions : Se);
	for (let e of r.slice(0, 192)) {
		if (!e || typeof e.name != "string" || !Array.isArray(e.rules)) continue;
		let t = e.rules.find((e) => e?.kind === "anchor");
		t?.kind === "anchor" && n.set(e.name, t.id);
	}
	return n;
}
function Xt(e, t) {
	if (e.type !== "component" && e.type !== "hostComponent") return;
	let n = t.get(e.name ?? "");
	if (n === void 0) return;
	let r = e.attrs?.[n];
	if (typeof r == "string" && r.length !== 0) return /^[A-Za-z_][A-Za-z0-9_-]*$/.test(r) ? r : void 0;
}
function Zt(e) {
	if (e.type === "component" || e.type === "hostComponent") return;
	let t = e.attrs?.id;
	if (typeof t != "string") return;
	let n = t.trim().replace(/[\u0000- \u007f-\u009f]+/g, "-").replace(/^-+|-+$/g, "");
	return n === "" ? void 0 : n;
}
function Qt(e, t, r = !0, a) {
	let o = Yt(e, a), s = e.initialState;
	if (e.computations) {
		let t = {}, n = /* @__PURE__ */ new Map();
		for (let [r, i] of Object.entries(e.computations)) {
			i.kind === "const" && Object.hasOwn(i, "value") && (t[r] = i.value);
			try {
				n.set(r, ce(i.source));
			} catch {}
		}
		let { order: r } = h(e.computations), a = i(e.computations, r, n, s, t);
		s = {
			...s,
			...a.values
		};
	}
	let c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = /* @__PURE__ */ new Map(), d = /* @__PURE__ */ new Map(), f = /* @__PURE__ */ new Map();
	function p(e) {
		let n = e, r = f.get(e) ?? 0;
		for (; d.has(n);) r += 1, n = `${e}-${r}`;
		f.set(e, r);
		let i = `${t}-${n}`;
		return d.set(n, i), {
			slug: n,
			id: i
		};
	}
	for (let t of n(e.nodes)) if (t.type === "heading") {
		let e = Zt(t) ?? Jt(qt(t.children, s));
		c.set(t, p(e).id);
	} else {
		if (r) {
			let e = Xt(t, o);
			e && l.set(t, p(e).id);
		}
		let e = Zt(t);
		e && u.set(t, p(e).id);
	}
	function m(e) {
		if (e.length === 0) return;
		let t = d.get(e);
		if (t) return t;
		try {
			return d.get(decodeURIComponent(e));
		} catch {
			return;
		}
	}
	return {
		ids: c,
		anchorIds: l,
		htmlIds: u,
		targetId(e) {
			return m(e);
		},
		referenceId(e) {
			return m(e) ?? `${t}-${e}`;
		},
		resolve(e) {
			if (!e.startsWith("#")) return e;
			let t = m(e.slice(1));
			return t ? `#${t}` : e;
		}
	};
}
// node_modules/bail/index.js
function $t(e) {
	if (e) throw e;
}
// node_modules/devlop/lib/default.js
var en = /* @__PURE__ */ Be((/* @__PURE__ */ Le(((e, t) => {
	var n = Object.prototype.hasOwnProperty, r = Object.prototype.toString, i = Object.defineProperty, a = Object.getOwnPropertyDescriptor, o = function(e) {
		return typeof Array.isArray == "function" ? Array.isArray(e) : r.call(e) === "[object Array]";
	}, s = function(e) {
		if (!e || r.call(e) !== "[object Object]") return !1;
		var t = n.call(e, "constructor"), i = e.constructor && e.constructor.prototype && n.call(e.constructor.prototype, "isPrototypeOf");
		if (e.constructor && !t && !i) return !1;
		for (var a in e);
		return a === void 0 || n.call(e, a);
	}, c = function(e, t) {
		i && t.name === "__proto__" ? i(e, t.name, {
			enumerable: !0,
			configurable: !0,
			value: t.newValue,
			writable: !0
		}) : e[t.name] = t.newValue;
	}, l = function(e, t) {
		if (t === "__proto__") {
			if (!n.call(e, t)) return;
			if (a) return a(e, t).value;
		}
		return e[t];
	};
	t.exports = function e() {
		var t, n, r, i, a, u, d = arguments[0], f = 1, p = arguments.length, m = !1;
		for (typeof d == "boolean" && (m = d, d = arguments[1] || {}, f = 2), (d == null || typeof d != "object" && typeof d != "function") && (d = {}); f < p; ++f) if (t = arguments[f], t != null) for (n in t) r = l(d, n), i = l(t, n), d !== i && (m && i && (s(i) || (a = o(i))) ? (a ? (a = !1, u = r && o(r) ? r : []) : u = r && s(r) ? r : {}, c(d, {
			name: n,
			newValue: e(m, u, i)
		})) : i !== void 0 && c(d, {
			name: n,
			newValue: i
		}));
		return d;
	};
})))(), 1);
function tn() {}
// node_modules/is-plain-obj/index.js
function nn(e) {
	if (typeof e != "object" || !e) return !1;
	let t = Object.getPrototypeOf(e);
	return (t === null || t === Object.prototype || Object.getPrototypeOf(t) === null) && !(Symbol.toStringTag in e) && !(Symbol.iterator in e);
}
// node_modules/trough/lib/index.js
function rn() {
	let e = [], t = {
		run: n,
		use: r
	};
	return t;
	function n(...t) {
		let n = -1, r = t.pop();
		if (typeof r != "function") throw TypeError("Expected function as last argument, not " + r);
		i(null, ...t);
		function i(a, ...o) {
			let s = e[++n], c = -1;
			if (a) r(a);
			else {
				for (; ++c < t.length;) (o[c] === null || o[c] === void 0) && (o[c] = t[c]);
				t = o, s ? an(s, i)(...o) : r(null, ...o);
			}
		}
	}
	function r(n) {
		if (typeof n != "function") throw TypeError("Expected `middelware` to be a function, not " + n);
		return e.push(n), t;
	}
}
function an(e, t) {
	let n;
	return r;
	function r(...t) {
		let r = e.length > t.length, o;
		r && t.push(i);
		try {
			o = e.apply(this, t);
		} catch (e) {
			let t = e;
			if (r && n) throw t;
			return i(t);
		}
		r || (o && o.then && typeof o.then == "function" ? o.then(a, i) : o instanceof Error ? i(o) : a(o));
	}
	function i(e, ...r) {
		n || (n = !0, t(e, ...r));
	}
	function a(e) {
		i(null, e);
	}
}
// node_modules/unist-util-stringify-position/lib/index.js
function on(e) {
	return !e || typeof e != "object" ? "" : "position" in e || "type" in e ? cn(e.position) : "start" in e || "end" in e ? cn(e) : "line" in e || "column" in e ? sn(e) : "";
}
function sn(e) {
	return ln(e && e.line) + ":" + ln(e && e.column);
}
function cn(e) {
	return sn(e && e.start) + "-" + sn(e && e.end);
}
function ln(e) {
	return e && typeof e == "number" ? e : 1;
}
// node_modules/vfile-message/lib/index.js
var R = class extends Error {
	constructor(e, t, n) {
		super(), typeof t == "string" && (n = t, t = void 0);
		let r = "", i = {}, a = !1;
		if (t && (i = "line" in t && "column" in t || "start" in t && "end" in t ? { place: t } : "type" in t ? {
			ancestors: [t],
			place: t.position
		} : { ...t }), typeof e == "string" ? r = e : !i.cause && e && (a = !0, r = e.message, i.cause = e), !i.ruleId && !i.source && typeof n == "string") {
			let e = n.indexOf(":");
			e === -1 ? i.ruleId = n : (i.source = n.slice(0, e), i.ruleId = n.slice(e + 1));
		}
		if (!i.place && i.ancestors && i.ancestors) {
			let e = i.ancestors[i.ancestors.length - 1];
			e && (i.place = e.position);
		}
		let o = i.place && "start" in i.place ? i.place.start : i.place;
		this.ancestors = i.ancestors || void 0, this.cause = i.cause || void 0, this.column = o ? o.column : void 0, this.fatal = void 0, this.file = "", this.message = r, this.line = o ? o.line : void 0, this.name = on(i.place) || "1:1", this.place = i.place || void 0, this.reason = this.message, this.ruleId = i.ruleId || void 0, this.source = i.source || void 0, this.stack = a && i.cause && typeof i.cause.stack == "string" ? i.cause.stack : "", this.actual = void 0, this.expected = void 0, this.note = void 0, this.url = void 0;
	}
};
R.prototype.file = "", R.prototype.name = "", R.prototype.reason = "", R.prototype.message = "", R.prototype.stack = "", R.prototype.column = void 0, R.prototype.line = void 0, R.prototype.ancestors = void 0, R.prototype.cause = void 0, R.prototype.fatal = void 0, R.prototype.place = void 0, R.prototype.ruleId = void 0, R.prototype.source = void 0;
// node_modules/vfile/lib/minpath.browser.js
var un = {
	basename: dn,
	dirname: fn,
	extname: pn,
	join: mn,
	sep: "/"
};
function dn(e, t) {
	if (t !== void 0 && typeof t != "string") throw TypeError("\"ext\" argument must be a string");
	_n(e);
	let n = 0, r = -1, i = e.length, a;
	if (t === void 0 || t.length === 0 || t.length > e.length) {
		for (; i--;) if (e.codePointAt(i) === 47) {
			if (a) {
				n = i + 1;
				break;
			}
		} else r < 0 && (a = !0, r = i + 1);
		return r < 0 ? "" : e.slice(n, r);
	}
	if (t === e) return "";
	let o = -1, s = t.length - 1;
	for (; i--;) if (e.codePointAt(i) === 47) {
		if (a) {
			n = i + 1;
			break;
		}
	} else o < 0 && (a = !0, o = i + 1), s > -1 && (e.codePointAt(i) === t.codePointAt(s--) ? s < 0 && (r = i) : (s = -1, r = o));
	return n === r ? r = o : r < 0 && (r = e.length), e.slice(n, r);
}
function fn(e) {
	if (_n(e), e.length === 0) return ".";
	let t = -1, n = e.length, r;
	for (; --n;) if (e.codePointAt(n) === 47) {
		if (r) {
			t = n;
			break;
		}
	} else r ||= !0;
	return t < 0 ? e.codePointAt(0) === 47 ? "/" : "." : t === 1 && e.codePointAt(0) === 47 ? "//" : e.slice(0, t);
}
function pn(e) {
	_n(e);
	let t = e.length, n = -1, r = 0, i = -1, a = 0, o;
	for (; t--;) {
		let s = e.codePointAt(t);
		if (s === 47) {
			if (o) {
				r = t + 1;
				break;
			}
		} else n < 0 && (o = !0, n = t + 1), s === 46 ? i < 0 ? i = t : a !== 1 && (a = 1) : i > -1 && (a = -1);
	}
	return i < 0 || n < 0 || a === 0 || a === 1 && i === n - 1 && i === r + 1 ? "" : e.slice(i, n);
}
function mn(...e) {
	let t = -1, n;
	for (; ++t < e.length;) _n(e[t]), e[t] && (n = n === void 0 ? e[t] : n + "/" + e[t]);
	return n === void 0 ? "." : hn(n);
}
function hn(e) {
	_n(e);
	let t = e.codePointAt(0) === 47, n = gn(e, !t);
	return n.length === 0 && !t && (n = "."), n.length > 0 && e.codePointAt(e.length - 1) === 47 && (n += "/"), t ? "/" + n : n;
}
function gn(e, t) {
	let n = "", r = 0, i = -1, a = 0, o = -1, s, c;
	for (; ++o <= e.length;) {
		if (o < e.length) s = e.codePointAt(o);
		else if (s === 47) break;
		else s = 47;
		if (s === 47) {
			if (i !== o - 1 && a !== 1) {
				if (i !== o - 1 && a === 2) {
					if (n.length < 2 || r !== 2 || n.codePointAt(n.length - 1) !== 46 || n.codePointAt(n.length - 2) !== 46) {
						if (n.length > 2) {
							if (c = n.lastIndexOf("/"), c !== n.length - 1) {
								c < 0 ? (n = "", r = 0) : (n = n.slice(0, c), r = n.length - 1 - n.lastIndexOf("/")), i = o, a = 0;
								continue;
							}
						} else if (n.length > 0) {
							n = "", r = 0, i = o, a = 0;
							continue;
						}
					}
					t && (n = n.length > 0 ? n + "/.." : "..", r = 2);
				} else n.length > 0 ? n += "/" + e.slice(i + 1, o) : n = e.slice(i + 1, o), r = o - i - 1;
			}
			i = o, a = 0;
		} else s === 46 && a > -1 ? a++ : a = -1;
	}
	return n;
}
function _n(e) {
	if (typeof e != "string") throw TypeError("Path must be a string. Received " + JSON.stringify(e));
}
// node_modules/vfile/lib/minproc.browser.js
var vn = { cwd: yn };
function yn() {
	return "/";
}
// node_modules/vfile/lib/minurl.shared.js
function bn(e) {
	return !!(typeof e == "object" && e && "href" in e && e.href && "protocol" in e && e.protocol && e.auth === void 0);
}
// node_modules/vfile/lib/minurl.browser.js
function xn(e) {
	if (typeof e == "string") e = new URL(e);
	else if (!bn(e)) {
		let t = /* @__PURE__ */ TypeError("The \"path\" argument must be of type string or an instance of URL. Received `" + e + "`");
		throw t.code = "ERR_INVALID_ARG_TYPE", t;
	}
	if (e.protocol !== "file:") {
		let e = /* @__PURE__ */ TypeError("The URL must be of scheme file");
		throw e.code = "ERR_INVALID_URL_SCHEME", e;
	}
	return Sn(e);
}
function Sn(e) {
	if (e.hostname !== "") {
		let e = /* @__PURE__ */ TypeError("File URL host must be \"localhost\" or empty on darwin");
		throw e.code = "ERR_INVALID_FILE_URL_HOST", e;
	}
	let t = e.pathname, n = -1;
	for (; ++n < t.length;) if (t.codePointAt(n) === 37 && t.codePointAt(n + 1) === 50) {
		let e = t.codePointAt(n + 2);
		if (e === 70 || e === 102) {
			let e = /* @__PURE__ */ TypeError("File URL path must not include encoded / characters");
			throw e.code = "ERR_INVALID_FILE_URL_PATH", e;
		}
	}
	return decodeURIComponent(t);
}
// node_modules/vfile/lib/index.js
var Cn = [
	"history",
	"path",
	"basename",
	"stem",
	"extname",
	"dirname"
], wn = class {
	constructor(e) {
		let t;
		t = e ? bn(e) ? { path: e } : typeof e == "string" || On(e) ? { value: e } : e : {}, this.cwd = "cwd" in t ? "" : vn.cwd(), this.data = {}, this.history = [], this.messages = [], this.value, this.map, this.result, this.stored;
		let n = -1;
		for (; ++n < Cn.length;) {
			let e = Cn[n];
			e in t && t[e] !== void 0 && t[e] !== null && (this[e] = e === "history" ? [...t[e]] : t[e]);
		}
		let r;
		for (r in t) Cn.includes(r) || (this[r] = t[r]);
	}
	get basename() {
		return typeof this.path == "string" ? un.basename(this.path) : void 0;
	}
	set basename(e) {
		En(e, "basename"), Tn(e, "basename"), this.path = un.join(this.dirname || "", e);
	}
	get dirname() {
		return typeof this.path == "string" ? un.dirname(this.path) : void 0;
	}
	set dirname(e) {
		Dn(this.basename, "dirname"), this.path = un.join(e || "", this.basename);
	}
	get extname() {
		return typeof this.path == "string" ? un.extname(this.path) : void 0;
	}
	set extname(e) {
		if (Tn(e, "extname"), Dn(this.dirname, "extname"), e) {
			if (e.codePointAt(0) !== 46) throw Error("`extname` must start with `.`");
			if (e.includes(".", 1)) throw Error("`extname` cannot contain multiple dots");
		}
		this.path = un.join(this.dirname, this.stem + (e || ""));
	}
	get path() {
		return this.history[this.history.length - 1];
	}
	set path(e) {
		bn(e) && (e = xn(e)), En(e, "path"), this.path !== e && this.history.push(e);
	}
	get stem() {
		return typeof this.path == "string" ? un.basename(this.path, this.extname) : void 0;
	}
	set stem(e) {
		En(e, "stem"), Tn(e, "stem"), this.path = un.join(this.dirname || "", e + (this.extname || ""));
	}
	fail(e, t, n) {
		let r = this.message(e, t, n);
		throw r.fatal = !0, r;
	}
	info(e, t, n) {
		let r = this.message(e, t, n);
		return r.fatal = void 0, r;
	}
	message(e, t, n) {
		let r = new R(e, t, n);
		return this.path && (r.name = this.path + ":" + r.name, r.file = this.path), r.fatal = !1, this.messages.push(r), r;
	}
	toString(e) {
		return this.value === void 0 ? "" : typeof this.value == "string" ? this.value : new TextDecoder(e || void 0).decode(this.value);
	}
};
function Tn(e, t) {
	if (e && e.includes(un.sep)) throw Error("`" + t + "` cannot be a path: did not expect `" + un.sep + "`");
}
function En(e, t) {
	if (!e) throw Error("`" + t + "` cannot be empty");
}
function Dn(e, t) {
	if (!e) throw Error("Setting `" + t + "` requires `path` to be set too");
}
function On(e) {
	return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
// node_modules/unified/lib/callable-instance.js
var kn = (function(e) {
	let t = this.constructor.prototype, n = t[e], r = function() {
		return n.apply(r, arguments);
	};
	return Object.setPrototypeOf(r, t), r;
}), An = {}.hasOwnProperty, jn = new class e extends kn {
	constructor() {
		super("copy"), this.Compiler = void 0, this.Parser = void 0, this.attachers = [], this.compiler = void 0, this.freezeIndex = -1, this.frozen = void 0, this.namespace = {}, this.parser = void 0, this.transformers = rn();
	}
	copy() {
		let t = new e(), n = -1;
		for (; ++n < this.attachers.length;) {
			let e = this.attachers[n];
			t.use(...e);
		}
		return t.data((0, en.default)(!0, {}, this.namespace)), t;
	}
	data(e, t) {
		return typeof e == "string" ? arguments.length === 2 ? (Pn("data", this.frozen), this.namespace[e] = t, this) : An.call(this.namespace, e) && this.namespace[e] || void 0 : e ? (Pn("data", this.frozen), this.namespace = e, this) : this.namespace;
	}
	freeze() {
		if (this.frozen) return this;
		let e = this;
		for (; ++this.freezeIndex < this.attachers.length;) {
			let [t, ...n] = this.attachers[this.freezeIndex];
			if (n[0] === !1) continue;
			n[0] === !0 && (n[0] = void 0);
			let r = t.call(e, ...n);
			typeof r == "function" && this.transformers.use(r);
		}
		return this.frozen = !0, this.freezeIndex = Infinity, this;
	}
	parse(e) {
		this.freeze();
		let t = Ln(e), n = this.parser || this.Parser;
		return Mn("parse", n), n(String(t), t);
	}
	process(e, t) {
		let n = this;
		return this.freeze(), Mn("process", this.parser || this.Parser), Nn("process", this.compiler || this.Compiler), t ? r(void 0, t) : new Promise(r);
		function r(r, i) {
			let a = Ln(e), o = n.parse(a);
			n.run(o, a, function(e, t, r) {
				if (e || !t || !r) return s(e);
				let i = t, a = n.stringify(i, r);
				zn(a) ? r.value = a : r.result = a, s(e, r);
			});
			function s(e, n) {
				e || !n ? i(e) : r ? r(n) : t(void 0, n);
			}
		}
	}
	processSync(e) {
		let t = !1, n;
		return this.freeze(), Mn("processSync", this.parser || this.Parser), Nn("processSync", this.compiler || this.Compiler), this.process(e, r), In("processSync", "process", t), n;
		function r(e, r) {
			t = !0, $t(e), n = r;
		}
	}
	run(e, t, n) {
		Fn(e), this.freeze();
		let r = this.transformers;
		return !n && typeof t == "function" && (n = t, t = void 0), n ? i(void 0, n) : new Promise(i);
		function i(i, a) {
			let o = Ln(t);
			r.run(e, o, s);
			function s(t, r, o) {
				let s = r || e;
				t ? a(t) : i ? i(s) : n(void 0, s, o);
			}
		}
	}
	runSync(e, t) {
		let n = !1, r;
		return this.run(e, t, i), In("runSync", "run", n), r;
		function i(e, t) {
			$t(e), r = t, n = !0;
		}
	}
	stringify(e, t) {
		this.freeze();
		let n = Ln(t), r = this.compiler || this.Compiler;
		return Nn("stringify", r), Fn(e), r(e, n);
	}
	use(e, ...t) {
		let n = this.attachers, r = this.namespace;
		if (Pn("use", this.frozen), e != null) {
			if (typeof e == "function") s(e, t);
			else if (typeof e == "object") Array.isArray(e) ? o(e) : a(e);
			else throw TypeError("Expected usable value, not `" + e + "`");
		}
		return this;
		function i(e) {
			if (typeof e == "function") s(e, []);
			else if (typeof e == "object") {
				if (Array.isArray(e)) {
					let [t, ...n] = e;
					s(t, n);
				} else a(e);
			} else throw TypeError("Expected usable value, not `" + e + "`");
		}
		function a(e) {
			if (!("plugins" in e) && !("settings" in e)) throw Error("Expected usable value but received an empty preset, which is probably a mistake: presets typically come with `plugins` and sometimes with `settings`, but this has neither");
			o(e.plugins), e.settings && (r.settings = (0, en.default)(!0, r.settings, e.settings));
		}
		function o(e) {
			let t = -1;
			if (e != null) {
				if (Array.isArray(e)) for (; ++t < e.length;) {
					let n = e[t];
					i(n);
				}
				else throw TypeError("Expected a list of plugins, not `" + e + "`");
			}
		}
		function s(e, t) {
			let r = -1, i = -1;
			for (; ++r < n.length;) if (n[r][0] === e) {
				i = r;
				break;
			}
			if (i === -1) n.push([e, ...t]);
			else if (t.length > 0) {
				let [r, ...a] = t, o = n[i][1];
				nn(o) && nn(r) && (r = (0, en.default)(!0, o, r)), n[i] = [
					e,
					r,
					...a
				];
			}
		}
	}
}().freeze();
function Mn(e, t) {
	if (typeof t != "function") throw TypeError("Cannot `" + e + "` without `parser`");
}
function Nn(e, t) {
	if (typeof t != "function") throw TypeError("Cannot `" + e + "` without `compiler`");
}
function Pn(e, t) {
	if (t) throw Error("Cannot call `" + e + "` on a frozen processor.\nCreate a new processor first, by calling it: use `processor()` instead of `processor`.");
}
function Fn(e) {
	if (!nn(e) || typeof e.type != "string") throw TypeError("Expected node, got `" + e + "`");
}
function In(e, t, n) {
	if (!n) throw Error("`" + e + "` finished async. Use `" + t + "` instead");
}
function Ln(e) {
	return Rn(e) ? e : new wn(e);
}
function Rn(e) {
	return !!(e && typeof e == "object" && "message" in e && "messages" in e);
}
function zn(e) {
	return typeof e == "string" || Bn(e);
}
function Bn(e) {
	return !!(e && typeof e == "object" && "byteLength" in e && "byteOffset" in e);
}
// node_modules/mdast-util-to-string/lib/index.js
var Vn = {};
function Hn(e, t) {
	let n = t || Vn;
	return Un(e, typeof n.includeImageAlt != "boolean" || n.includeImageAlt, typeof n.includeHtml != "boolean" || n.includeHtml);
}
function Un(e, t, n) {
	if (Gn(e)) {
		if ("value" in e) return e.type === "html" && !n ? "" : e.value;
		if (t && "alt" in e && e.alt) return e.alt;
		if ("children" in e) return Wn(e.children, t, n);
	}
	return Array.isArray(e) ? Wn(e, t, n) : "";
}
function Wn(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) r[i] = Un(e[i], t, n);
	return r.join("");
}
function Gn(e) {
	return !!(e && typeof e == "object");
}
// node_modules/character-entities/index.js
var Kn = {
	AElig: "Æ",
	AMP: "&",
	Aacute: "Á",
	Abreve: "Ă",
	Acirc: "Â",
	Acy: "А",
	Afr: "𝔄",
	Agrave: "À",
	Alpha: "Α",
	Amacr: "Ā",
	And: "⩓",
	Aogon: "Ą",
	Aopf: "𝔸",
	ApplyFunction: "⁡",
	Aring: "Å",
	Ascr: "𝒜",
	Assign: "≔",
	Atilde: "Ã",
	Auml: "Ä",
	Backslash: "∖",
	Barv: "⫧",
	Barwed: "⌆",
	Bcy: "Б",
	Because: "∵",
	Bernoullis: "ℬ",
	Beta: "Β",
	Bfr: "𝔅",
	Bopf: "𝔹",
	Breve: "˘",
	Bscr: "ℬ",
	Bumpeq: "≎",
	CHcy: "Ч",
	COPY: "©",
	Cacute: "Ć",
	Cap: "⋒",
	CapitalDifferentialD: "ⅅ",
	Cayleys: "ℭ",
	Ccaron: "Č",
	Ccedil: "Ç",
	Ccirc: "Ĉ",
	Cconint: "∰",
	Cdot: "Ċ",
	Cedilla: "¸",
	CenterDot: "·",
	Cfr: "ℭ",
	Chi: "Χ",
	CircleDot: "⊙",
	CircleMinus: "⊖",
	CirclePlus: "⊕",
	CircleTimes: "⊗",
	ClockwiseContourIntegral: "∲",
	CloseCurlyDoubleQuote: "”",
	CloseCurlyQuote: "’",
	Colon: "∷",
	Colone: "⩴",
	Congruent: "≡",
	Conint: "∯",
	ContourIntegral: "∮",
	Copf: "ℂ",
	Coproduct: "∐",
	CounterClockwiseContourIntegral: "∳",
	Cross: "⨯",
	Cscr: "𝒞",
	Cup: "⋓",
	CupCap: "≍",
	DD: "ⅅ",
	DDotrahd: "⤑",
	DJcy: "Ђ",
	DScy: "Ѕ",
	DZcy: "Џ",
	Dagger: "‡",
	Darr: "↡",
	Dashv: "⫤",
	Dcaron: "Ď",
	Dcy: "Д",
	Del: "∇",
	Delta: "Δ",
	Dfr: "𝔇",
	DiacriticalAcute: "´",
	DiacriticalDot: "˙",
	DiacriticalDoubleAcute: "˝",
	DiacriticalGrave: "`",
	DiacriticalTilde: "˜",
	Diamond: "⋄",
	DifferentialD: "ⅆ",
	Dopf: "𝔻",
	Dot: "¨",
	DotDot: "⃜",
	DotEqual: "≐",
	DoubleContourIntegral: "∯",
	DoubleDot: "¨",
	DoubleDownArrow: "⇓",
	DoubleLeftArrow: "⇐",
	DoubleLeftRightArrow: "⇔",
	DoubleLeftTee: "⫤",
	DoubleLongLeftArrow: "⟸",
	DoubleLongLeftRightArrow: "⟺",
	DoubleLongRightArrow: "⟹",
	DoubleRightArrow: "⇒",
	DoubleRightTee: "⊨",
	DoubleUpArrow: "⇑",
	DoubleUpDownArrow: "⇕",
	DoubleVerticalBar: "∥",
	DownArrow: "↓",
	DownArrowBar: "⤓",
	DownArrowUpArrow: "⇵",
	DownBreve: "̑",
	DownLeftRightVector: "⥐",
	DownLeftTeeVector: "⥞",
	DownLeftVector: "↽",
	DownLeftVectorBar: "⥖",
	DownRightTeeVector: "⥟",
	DownRightVector: "⇁",
	DownRightVectorBar: "⥗",
	DownTee: "⊤",
	DownTeeArrow: "↧",
	Downarrow: "⇓",
	Dscr: "𝒟",
	Dstrok: "Đ",
	ENG: "Ŋ",
	ETH: "Ð",
	Eacute: "É",
	Ecaron: "Ě",
	Ecirc: "Ê",
	Ecy: "Э",
	Edot: "Ė",
	Efr: "𝔈",
	Egrave: "È",
	Element: "∈",
	Emacr: "Ē",
	EmptySmallSquare: "◻",
	EmptyVerySmallSquare: "▫",
	Eogon: "Ę",
	Eopf: "𝔼",
	Epsilon: "Ε",
	Equal: "⩵",
	EqualTilde: "≂",
	Equilibrium: "⇌",
	Escr: "ℰ",
	Esim: "⩳",
	Eta: "Η",
	Euml: "Ë",
	Exists: "∃",
	ExponentialE: "ⅇ",
	Fcy: "Ф",
	Ffr: "𝔉",
	FilledSmallSquare: "◼",
	FilledVerySmallSquare: "▪",
	Fopf: "𝔽",
	ForAll: "∀",
	Fouriertrf: "ℱ",
	Fscr: "ℱ",
	GJcy: "Ѓ",
	GT: ">",
	Gamma: "Γ",
	Gammad: "Ϝ",
	Gbreve: "Ğ",
	Gcedil: "Ģ",
	Gcirc: "Ĝ",
	Gcy: "Г",
	Gdot: "Ġ",
	Gfr: "𝔊",
	Gg: "⋙",
	Gopf: "𝔾",
	GreaterEqual: "≥",
	GreaterEqualLess: "⋛",
	GreaterFullEqual: "≧",
	GreaterGreater: "⪢",
	GreaterLess: "≷",
	GreaterSlantEqual: "⩾",
	GreaterTilde: "≳",
	Gscr: "𝒢",
	Gt: "≫",
	HARDcy: "Ъ",
	Hacek: "ˇ",
	Hat: "^",
	Hcirc: "Ĥ",
	Hfr: "ℌ",
	HilbertSpace: "ℋ",
	Hopf: "ℍ",
	HorizontalLine: "─",
	Hscr: "ℋ",
	Hstrok: "Ħ",
	HumpDownHump: "≎",
	HumpEqual: "≏",
	IEcy: "Е",
	IJlig: "Ĳ",
	IOcy: "Ё",
	Iacute: "Í",
	Icirc: "Î",
	Icy: "И",
	Idot: "İ",
	Ifr: "ℑ",
	Igrave: "Ì",
	Im: "ℑ",
	Imacr: "Ī",
	ImaginaryI: "ⅈ",
	Implies: "⇒",
	Int: "∬",
	Integral: "∫",
	Intersection: "⋂",
	InvisibleComma: "⁣",
	InvisibleTimes: "⁢",
	Iogon: "Į",
	Iopf: "𝕀",
	Iota: "Ι",
	Iscr: "ℐ",
	Itilde: "Ĩ",
	Iukcy: "І",
	Iuml: "Ï",
	Jcirc: "Ĵ",
	Jcy: "Й",
	Jfr: "𝔍",
	Jopf: "𝕁",
	Jscr: "𝒥",
	Jsercy: "Ј",
	Jukcy: "Є",
	KHcy: "Х",
	KJcy: "Ќ",
	Kappa: "Κ",
	Kcedil: "Ķ",
	Kcy: "К",
	Kfr: "𝔎",
	Kopf: "𝕂",
	Kscr: "𝒦",
	LJcy: "Љ",
	LT: "<",
	Lacute: "Ĺ",
	Lambda: "Λ",
	Lang: "⟪",
	Laplacetrf: "ℒ",
	Larr: "↞",
	Lcaron: "Ľ",
	Lcedil: "Ļ",
	Lcy: "Л",
	LeftAngleBracket: "⟨",
	LeftArrow: "←",
	LeftArrowBar: "⇤",
	LeftArrowRightArrow: "⇆",
	LeftCeiling: "⌈",
	LeftDoubleBracket: "⟦",
	LeftDownTeeVector: "⥡",
	LeftDownVector: "⇃",
	LeftDownVectorBar: "⥙",
	LeftFloor: "⌊",
	LeftRightArrow: "↔",
	LeftRightVector: "⥎",
	LeftTee: "⊣",
	LeftTeeArrow: "↤",
	LeftTeeVector: "⥚",
	LeftTriangle: "⊲",
	LeftTriangleBar: "⧏",
	LeftTriangleEqual: "⊴",
	LeftUpDownVector: "⥑",
	LeftUpTeeVector: "⥠",
	LeftUpVector: "↿",
	LeftUpVectorBar: "⥘",
	LeftVector: "↼",
	LeftVectorBar: "⥒",
	Leftarrow: "⇐",
	Leftrightarrow: "⇔",
	LessEqualGreater: "⋚",
	LessFullEqual: "≦",
	LessGreater: "≶",
	LessLess: "⪡",
	LessSlantEqual: "⩽",
	LessTilde: "≲",
	Lfr: "𝔏",
	Ll: "⋘",
	Lleftarrow: "⇚",
	Lmidot: "Ŀ",
	LongLeftArrow: "⟵",
	LongLeftRightArrow: "⟷",
	LongRightArrow: "⟶",
	Longleftarrow: "⟸",
	Longleftrightarrow: "⟺",
	Longrightarrow: "⟹",
	Lopf: "𝕃",
	LowerLeftArrow: "↙",
	LowerRightArrow: "↘",
	Lscr: "ℒ",
	Lsh: "↰",
	Lstrok: "Ł",
	Lt: "≪",
	Map: "⤅",
	Mcy: "М",
	MediumSpace: " ",
	Mellintrf: "ℳ",
	Mfr: "𝔐",
	MinusPlus: "∓",
	Mopf: "𝕄",
	Mscr: "ℳ",
	Mu: "Μ",
	NJcy: "Њ",
	Nacute: "Ń",
	Ncaron: "Ň",
	Ncedil: "Ņ",
	Ncy: "Н",
	NegativeMediumSpace: "​",
	NegativeThickSpace: "​",
	NegativeThinSpace: "​",
	NegativeVeryThinSpace: "​",
	NestedGreaterGreater: "≫",
	NestedLessLess: "≪",
	NewLine: "\n",
	Nfr: "𝔑",
	NoBreak: "⁠",
	NonBreakingSpace: "\xA0",
	Nopf: "ℕ",
	Not: "⫬",
	NotCongruent: "≢",
	NotCupCap: "≭",
	NotDoubleVerticalBar: "∦",
	NotElement: "∉",
	NotEqual: "≠",
	NotEqualTilde: "≂̸",
	NotExists: "∄",
	NotGreater: "≯",
	NotGreaterEqual: "≱",
	NotGreaterFullEqual: "≧̸",
	NotGreaterGreater: "≫̸",
	NotGreaterLess: "≹",
	NotGreaterSlantEqual: "⩾̸",
	NotGreaterTilde: "≵",
	NotHumpDownHump: "≎̸",
	NotHumpEqual: "≏̸",
	NotLeftTriangle: "⋪",
	NotLeftTriangleBar: "⧏̸",
	NotLeftTriangleEqual: "⋬",
	NotLess: "≮",
	NotLessEqual: "≰",
	NotLessGreater: "≸",
	NotLessLess: "≪̸",
	NotLessSlantEqual: "⩽̸",
	NotLessTilde: "≴",
	NotNestedGreaterGreater: "⪢̸",
	NotNestedLessLess: "⪡̸",
	NotPrecedes: "⊀",
	NotPrecedesEqual: "⪯̸",
	NotPrecedesSlantEqual: "⋠",
	NotReverseElement: "∌",
	NotRightTriangle: "⋫",
	NotRightTriangleBar: "⧐̸",
	NotRightTriangleEqual: "⋭",
	NotSquareSubset: "⊏̸",
	NotSquareSubsetEqual: "⋢",
	NotSquareSuperset: "⊐̸",
	NotSquareSupersetEqual: "⋣",
	NotSubset: "⊂⃒",
	NotSubsetEqual: "⊈",
	NotSucceeds: "⊁",
	NotSucceedsEqual: "⪰̸",
	NotSucceedsSlantEqual: "⋡",
	NotSucceedsTilde: "≿̸",
	NotSuperset: "⊃⃒",
	NotSupersetEqual: "⊉",
	NotTilde: "≁",
	NotTildeEqual: "≄",
	NotTildeFullEqual: "≇",
	NotTildeTilde: "≉",
	NotVerticalBar: "∤",
	Nscr: "𝒩",
	Ntilde: "Ñ",
	Nu: "Ν",
	OElig: "Œ",
	Oacute: "Ó",
	Ocirc: "Ô",
	Ocy: "О",
	Odblac: "Ő",
	Ofr: "𝔒",
	Ograve: "Ò",
	Omacr: "Ō",
	Omega: "Ω",
	Omicron: "Ο",
	Oopf: "𝕆",
	OpenCurlyDoubleQuote: "“",
	OpenCurlyQuote: "‘",
	Or: "⩔",
	Oscr: "𝒪",
	Oslash: "Ø",
	Otilde: "Õ",
	Otimes: "⨷",
	Ouml: "Ö",
	OverBar: "‾",
	OverBrace: "⏞",
	OverBracket: "⎴",
	OverParenthesis: "⏜",
	PartialD: "∂",
	Pcy: "П",
	Pfr: "𝔓",
	Phi: "Φ",
	Pi: "Π",
	PlusMinus: "±",
	Poincareplane: "ℌ",
	Popf: "ℙ",
	Pr: "⪻",
	Precedes: "≺",
	PrecedesEqual: "⪯",
	PrecedesSlantEqual: "≼",
	PrecedesTilde: "≾",
	Prime: "″",
	Product: "∏",
	Proportion: "∷",
	Proportional: "∝",
	Pscr: "𝒫",
	Psi: "Ψ",
	QUOT: "\"",
	Qfr: "𝔔",
	Qopf: "ℚ",
	Qscr: "𝒬",
	RBarr: "⤐",
	REG: "®",
	Racute: "Ŕ",
	Rang: "⟫",
	Rarr: "↠",
	Rarrtl: "⤖",
	Rcaron: "Ř",
	Rcedil: "Ŗ",
	Rcy: "Р",
	Re: "ℜ",
	ReverseElement: "∋",
	ReverseEquilibrium: "⇋",
	ReverseUpEquilibrium: "⥯",
	Rfr: "ℜ",
	Rho: "Ρ",
	RightAngleBracket: "⟩",
	RightArrow: "→",
	RightArrowBar: "⇥",
	RightArrowLeftArrow: "⇄",
	RightCeiling: "⌉",
	RightDoubleBracket: "⟧",
	RightDownTeeVector: "⥝",
	RightDownVector: "⇂",
	RightDownVectorBar: "⥕",
	RightFloor: "⌋",
	RightTee: "⊢",
	RightTeeArrow: "↦",
	RightTeeVector: "⥛",
	RightTriangle: "⊳",
	RightTriangleBar: "⧐",
	RightTriangleEqual: "⊵",
	RightUpDownVector: "⥏",
	RightUpTeeVector: "⥜",
	RightUpVector: "↾",
	RightUpVectorBar: "⥔",
	RightVector: "⇀",
	RightVectorBar: "⥓",
	Rightarrow: "⇒",
	Ropf: "ℝ",
	RoundImplies: "⥰",
	Rrightarrow: "⇛",
	Rscr: "ℛ",
	Rsh: "↱",
	RuleDelayed: "⧴",
	SHCHcy: "Щ",
	SHcy: "Ш",
	SOFTcy: "Ь",
	Sacute: "Ś",
	Sc: "⪼",
	Scaron: "Š",
	Scedil: "Ş",
	Scirc: "Ŝ",
	Scy: "С",
	Sfr: "𝔖",
	ShortDownArrow: "↓",
	ShortLeftArrow: "←",
	ShortRightArrow: "→",
	ShortUpArrow: "↑",
	Sigma: "Σ",
	SmallCircle: "∘",
	Sopf: "𝕊",
	Sqrt: "√",
	Square: "□",
	SquareIntersection: "⊓",
	SquareSubset: "⊏",
	SquareSubsetEqual: "⊑",
	SquareSuperset: "⊐",
	SquareSupersetEqual: "⊒",
	SquareUnion: "⊔",
	Sscr: "𝒮",
	Star: "⋆",
	Sub: "⋐",
	Subset: "⋐",
	SubsetEqual: "⊆",
	Succeeds: "≻",
	SucceedsEqual: "⪰",
	SucceedsSlantEqual: "≽",
	SucceedsTilde: "≿",
	SuchThat: "∋",
	Sum: "∑",
	Sup: "⋑",
	Superset: "⊃",
	SupersetEqual: "⊇",
	Supset: "⋑",
	THORN: "Þ",
	TRADE: "™",
	TSHcy: "Ћ",
	TScy: "Ц",
	Tab: "	",
	Tau: "Τ",
	Tcaron: "Ť",
	Tcedil: "Ţ",
	Tcy: "Т",
	Tfr: "𝔗",
	Therefore: "∴",
	Theta: "Θ",
	ThickSpace: "  ",
	ThinSpace: " ",
	Tilde: "∼",
	TildeEqual: "≃",
	TildeFullEqual: "≅",
	TildeTilde: "≈",
	Topf: "𝕋",
	TripleDot: "⃛",
	Tscr: "𝒯",
	Tstrok: "Ŧ",
	Uacute: "Ú",
	Uarr: "↟",
	Uarrocir: "⥉",
	Ubrcy: "Ў",
	Ubreve: "Ŭ",
	Ucirc: "Û",
	Ucy: "У",
	Udblac: "Ű",
	Ufr: "𝔘",
	Ugrave: "Ù",
	Umacr: "Ū",
	UnderBar: "_",
	UnderBrace: "⏟",
	UnderBracket: "⎵",
	UnderParenthesis: "⏝",
	Union: "⋃",
	UnionPlus: "⊎",
	Uogon: "Ų",
	Uopf: "𝕌",
	UpArrow: "↑",
	UpArrowBar: "⤒",
	UpArrowDownArrow: "⇅",
	UpDownArrow: "↕",
	UpEquilibrium: "⥮",
	UpTee: "⊥",
	UpTeeArrow: "↥",
	Uparrow: "⇑",
	Updownarrow: "⇕",
	UpperLeftArrow: "↖",
	UpperRightArrow: "↗",
	Upsi: "ϒ",
	Upsilon: "Υ",
	Uring: "Ů",
	Uscr: "𝒰",
	Utilde: "Ũ",
	Uuml: "Ü",
	VDash: "⊫",
	Vbar: "⫫",
	Vcy: "В",
	Vdash: "⊩",
	Vdashl: "⫦",
	Vee: "⋁",
	Verbar: "‖",
	Vert: "‖",
	VerticalBar: "∣",
	VerticalLine: "|",
	VerticalSeparator: "❘",
	VerticalTilde: "≀",
	VeryThinSpace: " ",
	Vfr: "𝔙",
	Vopf: "𝕍",
	Vscr: "𝒱",
	Vvdash: "⊪",
	Wcirc: "Ŵ",
	Wedge: "⋀",
	Wfr: "𝔚",
	Wopf: "𝕎",
	Wscr: "𝒲",
	Xfr: "𝔛",
	Xi: "Ξ",
	Xopf: "𝕏",
	Xscr: "𝒳",
	YAcy: "Я",
	YIcy: "Ї",
	YUcy: "Ю",
	Yacute: "Ý",
	Ycirc: "Ŷ",
	Ycy: "Ы",
	Yfr: "𝔜",
	Yopf: "𝕐",
	Yscr: "𝒴",
	Yuml: "Ÿ",
	ZHcy: "Ж",
	Zacute: "Ź",
	Zcaron: "Ž",
	Zcy: "З",
	Zdot: "Ż",
	ZeroWidthSpace: "​",
	Zeta: "Ζ",
	Zfr: "ℨ",
	Zopf: "ℤ",
	Zscr: "𝒵",
	aacute: "á",
	abreve: "ă",
	ac: "∾",
	acE: "∾̳",
	acd: "∿",
	acirc: "â",
	acute: "´",
	acy: "а",
	aelig: "æ",
	af: "⁡",
	afr: "𝔞",
	agrave: "à",
	alefsym: "ℵ",
	aleph: "ℵ",
	alpha: "α",
	amacr: "ā",
	amalg: "⨿",
	amp: "&",
	and: "∧",
	andand: "⩕",
	andd: "⩜",
	andslope: "⩘",
	andv: "⩚",
	ang: "∠",
	ange: "⦤",
	angle: "∠",
	angmsd: "∡",
	angmsdaa: "⦨",
	angmsdab: "⦩",
	angmsdac: "⦪",
	angmsdad: "⦫",
	angmsdae: "⦬",
	angmsdaf: "⦭",
	angmsdag: "⦮",
	angmsdah: "⦯",
	angrt: "∟",
	angrtvb: "⊾",
	angrtvbd: "⦝",
	angsph: "∢",
	angst: "Å",
	angzarr: "⍼",
	aogon: "ą",
	aopf: "𝕒",
	ap: "≈",
	apE: "⩰",
	apacir: "⩯",
	ape: "≊",
	apid: "≋",
	apos: "'",
	approx: "≈",
	approxeq: "≊",
	aring: "å",
	ascr: "𝒶",
	ast: "*",
	asymp: "≈",
	asympeq: "≍",
	atilde: "ã",
	auml: "ä",
	awconint: "∳",
	awint: "⨑",
	bNot: "⫭",
	backcong: "≌",
	backepsilon: "϶",
	backprime: "‵",
	backsim: "∽",
	backsimeq: "⋍",
	barvee: "⊽",
	barwed: "⌅",
	barwedge: "⌅",
	bbrk: "⎵",
	bbrktbrk: "⎶",
	bcong: "≌",
	bcy: "б",
	bdquo: "„",
	becaus: "∵",
	because: "∵",
	bemptyv: "⦰",
	bepsi: "϶",
	bernou: "ℬ",
	beta: "β",
	beth: "ℶ",
	between: "≬",
	bfr: "𝔟",
	bigcap: "⋂",
	bigcirc: "◯",
	bigcup: "⋃",
	bigodot: "⨀",
	bigoplus: "⨁",
	bigotimes: "⨂",
	bigsqcup: "⨆",
	bigstar: "★",
	bigtriangledown: "▽",
	bigtriangleup: "△",
	biguplus: "⨄",
	bigvee: "⋁",
	bigwedge: "⋀",
	bkarow: "⤍",
	blacklozenge: "⧫",
	blacksquare: "▪",
	blacktriangle: "▴",
	blacktriangledown: "▾",
	blacktriangleleft: "◂",
	blacktriangleright: "▸",
	blank: "␣",
	blk12: "▒",
	blk14: "░",
	blk34: "▓",
	block: "█",
	bne: "=⃥",
	bnequiv: "≡⃥",
	bnot: "⌐",
	bopf: "𝕓",
	bot: "⊥",
	bottom: "⊥",
	bowtie: "⋈",
	boxDL: "╗",
	boxDR: "╔",
	boxDl: "╖",
	boxDr: "╓",
	boxH: "═",
	boxHD: "╦",
	boxHU: "╩",
	boxHd: "╤",
	boxHu: "╧",
	boxUL: "╝",
	boxUR: "╚",
	boxUl: "╜",
	boxUr: "╙",
	boxV: "║",
	boxVH: "╬",
	boxVL: "╣",
	boxVR: "╠",
	boxVh: "╫",
	boxVl: "╢",
	boxVr: "╟",
	boxbox: "⧉",
	boxdL: "╕",
	boxdR: "╒",
	boxdl: "┐",
	boxdr: "┌",
	boxh: "─",
	boxhD: "╥",
	boxhU: "╨",
	boxhd: "┬",
	boxhu: "┴",
	boxminus: "⊟",
	boxplus: "⊞",
	boxtimes: "⊠",
	boxuL: "╛",
	boxuR: "╘",
	boxul: "┘",
	boxur: "└",
	boxv: "│",
	boxvH: "╪",
	boxvL: "╡",
	boxvR: "╞",
	boxvh: "┼",
	boxvl: "┤",
	boxvr: "├",
	bprime: "‵",
	breve: "˘",
	brvbar: "¦",
	bscr: "𝒷",
	bsemi: "⁏",
	bsim: "∽",
	bsime: "⋍",
	bsol: "\\",
	bsolb: "⧅",
	bsolhsub: "⟈",
	bull: "•",
	bullet: "•",
	bump: "≎",
	bumpE: "⪮",
	bumpe: "≏",
	bumpeq: "≏",
	cacute: "ć",
	cap: "∩",
	capand: "⩄",
	capbrcup: "⩉",
	capcap: "⩋",
	capcup: "⩇",
	capdot: "⩀",
	caps: "∩︀",
	caret: "⁁",
	caron: "ˇ",
	ccaps: "⩍",
	ccaron: "č",
	ccedil: "ç",
	ccirc: "ĉ",
	ccups: "⩌",
	ccupssm: "⩐",
	cdot: "ċ",
	cedil: "¸",
	cemptyv: "⦲",
	cent: "¢",
	centerdot: "·",
	cfr: "𝔠",
	chcy: "ч",
	check: "✓",
	checkmark: "✓",
	chi: "χ",
	cir: "○",
	cirE: "⧃",
	circ: "ˆ",
	circeq: "≗",
	circlearrowleft: "↺",
	circlearrowright: "↻",
	circledR: "®",
	circledS: "Ⓢ",
	circledast: "⊛",
	circledcirc: "⊚",
	circleddash: "⊝",
	cire: "≗",
	cirfnint: "⨐",
	cirmid: "⫯",
	cirscir: "⧂",
	clubs: "♣",
	clubsuit: "♣",
	colon: ":",
	colone: "≔",
	coloneq: "≔",
	comma: ",",
	commat: "@",
	comp: "∁",
	compfn: "∘",
	complement: "∁",
	complexes: "ℂ",
	cong: "≅",
	congdot: "⩭",
	conint: "∮",
	copf: "𝕔",
	coprod: "∐",
	copy: "©",
	copysr: "℗",
	crarr: "↵",
	cross: "✗",
	cscr: "𝒸",
	csub: "⫏",
	csube: "⫑",
	csup: "⫐",
	csupe: "⫒",
	ctdot: "⋯",
	cudarrl: "⤸",
	cudarrr: "⤵",
	cuepr: "⋞",
	cuesc: "⋟",
	cularr: "↶",
	cularrp: "⤽",
	cup: "∪",
	cupbrcap: "⩈",
	cupcap: "⩆",
	cupcup: "⩊",
	cupdot: "⊍",
	cupor: "⩅",
	cups: "∪︀",
	curarr: "↷",
	curarrm: "⤼",
	curlyeqprec: "⋞",
	curlyeqsucc: "⋟",
	curlyvee: "⋎",
	curlywedge: "⋏",
	curren: "¤",
	curvearrowleft: "↶",
	curvearrowright: "↷",
	cuvee: "⋎",
	cuwed: "⋏",
	cwconint: "∲",
	cwint: "∱",
	cylcty: "⌭",
	dArr: "⇓",
	dHar: "⥥",
	dagger: "†",
	daleth: "ℸ",
	darr: "↓",
	dash: "‐",
	dashv: "⊣",
	dbkarow: "⤏",
	dblac: "˝",
	dcaron: "ď",
	dcy: "д",
	dd: "ⅆ",
	ddagger: "‡",
	ddarr: "⇊",
	ddotseq: "⩷",
	deg: "°",
	delta: "δ",
	demptyv: "⦱",
	dfisht: "⥿",
	dfr: "𝔡",
	dharl: "⇃",
	dharr: "⇂",
	diam: "⋄",
	diamond: "⋄",
	diamondsuit: "♦",
	diams: "♦",
	die: "¨",
	digamma: "ϝ",
	disin: "⋲",
	div: "÷",
	divide: "÷",
	divideontimes: "⋇",
	divonx: "⋇",
	djcy: "ђ",
	dlcorn: "⌞",
	dlcrop: "⌍",
	dollar: "$",
	dopf: "𝕕",
	dot: "˙",
	doteq: "≐",
	doteqdot: "≑",
	dotminus: "∸",
	dotplus: "∔",
	dotsquare: "⊡",
	doublebarwedge: "⌆",
	downarrow: "↓",
	downdownarrows: "⇊",
	downharpoonleft: "⇃",
	downharpoonright: "⇂",
	drbkarow: "⤐",
	drcorn: "⌟",
	drcrop: "⌌",
	dscr: "𝒹",
	dscy: "ѕ",
	dsol: "⧶",
	dstrok: "đ",
	dtdot: "⋱",
	dtri: "▿",
	dtrif: "▾",
	duarr: "⇵",
	duhar: "⥯",
	dwangle: "⦦",
	dzcy: "џ",
	dzigrarr: "⟿",
	eDDot: "⩷",
	eDot: "≑",
	eacute: "é",
	easter: "⩮",
	ecaron: "ě",
	ecir: "≖",
	ecirc: "ê",
	ecolon: "≕",
	ecy: "э",
	edot: "ė",
	ee: "ⅇ",
	efDot: "≒",
	efr: "𝔢",
	eg: "⪚",
	egrave: "è",
	egs: "⪖",
	egsdot: "⪘",
	el: "⪙",
	elinters: "⏧",
	ell: "ℓ",
	els: "⪕",
	elsdot: "⪗",
	emacr: "ē",
	empty: "∅",
	emptyset: "∅",
	emptyv: "∅",
	emsp13: " ",
	emsp14: " ",
	emsp: " ",
	eng: "ŋ",
	ensp: " ",
	eogon: "ę",
	eopf: "𝕖",
	epar: "⋕",
	eparsl: "⧣",
	eplus: "⩱",
	epsi: "ε",
	epsilon: "ε",
	epsiv: "ϵ",
	eqcirc: "≖",
	eqcolon: "≕",
	eqsim: "≂",
	eqslantgtr: "⪖",
	eqslantless: "⪕",
	equals: "=",
	equest: "≟",
	equiv: "≡",
	equivDD: "⩸",
	eqvparsl: "⧥",
	erDot: "≓",
	erarr: "⥱",
	escr: "ℯ",
	esdot: "≐",
	esim: "≂",
	eta: "η",
	eth: "ð",
	euml: "ë",
	euro: "€",
	excl: "!",
	exist: "∃",
	expectation: "ℰ",
	exponentiale: "ⅇ",
	fallingdotseq: "≒",
	fcy: "ф",
	female: "♀",
	ffilig: "ﬃ",
	fflig: "ﬀ",
	ffllig: "ﬄ",
	ffr: "𝔣",
	filig: "ﬁ",
	fjlig: "fj",
	flat: "♭",
	fllig: "ﬂ",
	fltns: "▱",
	fnof: "ƒ",
	fopf: "𝕗",
	forall: "∀",
	fork: "⋔",
	forkv: "⫙",
	fpartint: "⨍",
	frac12: "½",
	frac13: "⅓",
	frac14: "¼",
	frac15: "⅕",
	frac16: "⅙",
	frac18: "⅛",
	frac23: "⅔",
	frac25: "⅖",
	frac34: "¾",
	frac35: "⅗",
	frac38: "⅜",
	frac45: "⅘",
	frac56: "⅚",
	frac58: "⅝",
	frac78: "⅞",
	frasl: "⁄",
	frown: "⌢",
	fscr: "𝒻",
	gE: "≧",
	gEl: "⪌",
	gacute: "ǵ",
	gamma: "γ",
	gammad: "ϝ",
	gap: "⪆",
	gbreve: "ğ",
	gcirc: "ĝ",
	gcy: "г",
	gdot: "ġ",
	ge: "≥",
	gel: "⋛",
	geq: "≥",
	geqq: "≧",
	geqslant: "⩾",
	ges: "⩾",
	gescc: "⪩",
	gesdot: "⪀",
	gesdoto: "⪂",
	gesdotol: "⪄",
	gesl: "⋛︀",
	gesles: "⪔",
	gfr: "𝔤",
	gg: "≫",
	ggg: "⋙",
	gimel: "ℷ",
	gjcy: "ѓ",
	gl: "≷",
	glE: "⪒",
	gla: "⪥",
	glj: "⪤",
	gnE: "≩",
	gnap: "⪊",
	gnapprox: "⪊",
	gne: "⪈",
	gneq: "⪈",
	gneqq: "≩",
	gnsim: "⋧",
	gopf: "𝕘",
	grave: "`",
	gscr: "ℊ",
	gsim: "≳",
	gsime: "⪎",
	gsiml: "⪐",
	gt: ">",
	gtcc: "⪧",
	gtcir: "⩺",
	gtdot: "⋗",
	gtlPar: "⦕",
	gtquest: "⩼",
	gtrapprox: "⪆",
	gtrarr: "⥸",
	gtrdot: "⋗",
	gtreqless: "⋛",
	gtreqqless: "⪌",
	gtrless: "≷",
	gtrsim: "≳",
	gvertneqq: "≩︀",
	gvnE: "≩︀",
	hArr: "⇔",
	hairsp: " ",
	half: "½",
	hamilt: "ℋ",
	hardcy: "ъ",
	harr: "↔",
	harrcir: "⥈",
	harrw: "↭",
	hbar: "ℏ",
	hcirc: "ĥ",
	hearts: "♥",
	heartsuit: "♥",
	hellip: "…",
	hercon: "⊹",
	hfr: "𝔥",
	hksearow: "⤥",
	hkswarow: "⤦",
	hoarr: "⇿",
	homtht: "∻",
	hookleftarrow: "↩",
	hookrightarrow: "↪",
	hopf: "𝕙",
	horbar: "―",
	hscr: "𝒽",
	hslash: "ℏ",
	hstrok: "ħ",
	hybull: "⁃",
	hyphen: "‐",
	iacute: "í",
	ic: "⁣",
	icirc: "î",
	icy: "и",
	iecy: "е",
	iexcl: "¡",
	iff: "⇔",
	ifr: "𝔦",
	igrave: "ì",
	ii: "ⅈ",
	iiiint: "⨌",
	iiint: "∭",
	iinfin: "⧜",
	iiota: "℩",
	ijlig: "ĳ",
	imacr: "ī",
	image: "ℑ",
	imagline: "ℐ",
	imagpart: "ℑ",
	imath: "ı",
	imof: "⊷",
	imped: "Ƶ",
	in: "∈",
	incare: "℅",
	infin: "∞",
	infintie: "⧝",
	inodot: "ı",
	int: "∫",
	intcal: "⊺",
	integers: "ℤ",
	intercal: "⊺",
	intlarhk: "⨗",
	intprod: "⨼",
	iocy: "ё",
	iogon: "į",
	iopf: "𝕚",
	iota: "ι",
	iprod: "⨼",
	iquest: "¿",
	iscr: "𝒾",
	isin: "∈",
	isinE: "⋹",
	isindot: "⋵",
	isins: "⋴",
	isinsv: "⋳",
	isinv: "∈",
	it: "⁢",
	itilde: "ĩ",
	iukcy: "і",
	iuml: "ï",
	jcirc: "ĵ",
	jcy: "й",
	jfr: "𝔧",
	jmath: "ȷ",
	jopf: "𝕛",
	jscr: "𝒿",
	jsercy: "ј",
	jukcy: "є",
	kappa: "κ",
	kappav: "ϰ",
	kcedil: "ķ",
	kcy: "к",
	kfr: "𝔨",
	kgreen: "ĸ",
	khcy: "х",
	kjcy: "ќ",
	kopf: "𝕜",
	kscr: "𝓀",
	lAarr: "⇚",
	lArr: "⇐",
	lAtail: "⤛",
	lBarr: "⤎",
	lE: "≦",
	lEg: "⪋",
	lHar: "⥢",
	lacute: "ĺ",
	laemptyv: "⦴",
	lagran: "ℒ",
	lambda: "λ",
	lang: "⟨",
	langd: "⦑",
	langle: "⟨",
	lap: "⪅",
	laquo: "«",
	larr: "←",
	larrb: "⇤",
	larrbfs: "⤟",
	larrfs: "⤝",
	larrhk: "↩",
	larrlp: "↫",
	larrpl: "⤹",
	larrsim: "⥳",
	larrtl: "↢",
	lat: "⪫",
	latail: "⤙",
	late: "⪭",
	lates: "⪭︀",
	lbarr: "⤌",
	lbbrk: "❲",
	lbrace: "{",
	lbrack: "[",
	lbrke: "⦋",
	lbrksld: "⦏",
	lbrkslu: "⦍",
	lcaron: "ľ",
	lcedil: "ļ",
	lceil: "⌈",
	lcub: "{",
	lcy: "л",
	ldca: "⤶",
	ldquo: "“",
	ldquor: "„",
	ldrdhar: "⥧",
	ldrushar: "⥋",
	ldsh: "↲",
	le: "≤",
	leftarrow: "←",
	leftarrowtail: "↢",
	leftharpoondown: "↽",
	leftharpoonup: "↼",
	leftleftarrows: "⇇",
	leftrightarrow: "↔",
	leftrightarrows: "⇆",
	leftrightharpoons: "⇋",
	leftrightsquigarrow: "↭",
	leftthreetimes: "⋋",
	leg: "⋚",
	leq: "≤",
	leqq: "≦",
	leqslant: "⩽",
	les: "⩽",
	lescc: "⪨",
	lesdot: "⩿",
	lesdoto: "⪁",
	lesdotor: "⪃",
	lesg: "⋚︀",
	lesges: "⪓",
	lessapprox: "⪅",
	lessdot: "⋖",
	lesseqgtr: "⋚",
	lesseqqgtr: "⪋",
	lessgtr: "≶",
	lesssim: "≲",
	lfisht: "⥼",
	lfloor: "⌊",
	lfr: "𝔩",
	lg: "≶",
	lgE: "⪑",
	lhard: "↽",
	lharu: "↼",
	lharul: "⥪",
	lhblk: "▄",
	ljcy: "љ",
	ll: "≪",
	llarr: "⇇",
	llcorner: "⌞",
	llhard: "⥫",
	lltri: "◺",
	lmidot: "ŀ",
	lmoust: "⎰",
	lmoustache: "⎰",
	lnE: "≨",
	lnap: "⪉",
	lnapprox: "⪉",
	lne: "⪇",
	lneq: "⪇",
	lneqq: "≨",
	lnsim: "⋦",
	loang: "⟬",
	loarr: "⇽",
	lobrk: "⟦",
	longleftarrow: "⟵",
	longleftrightarrow: "⟷",
	longmapsto: "⟼",
	longrightarrow: "⟶",
	looparrowleft: "↫",
	looparrowright: "↬",
	lopar: "⦅",
	lopf: "𝕝",
	loplus: "⨭",
	lotimes: "⨴",
	lowast: "∗",
	lowbar: "_",
	loz: "◊",
	lozenge: "◊",
	lozf: "⧫",
	lpar: "(",
	lparlt: "⦓",
	lrarr: "⇆",
	lrcorner: "⌟",
	lrhar: "⇋",
	lrhard: "⥭",
	lrm: "‎",
	lrtri: "⊿",
	lsaquo: "‹",
	lscr: "𝓁",
	lsh: "↰",
	lsim: "≲",
	lsime: "⪍",
	lsimg: "⪏",
	lsqb: "[",
	lsquo: "‘",
	lsquor: "‚",
	lstrok: "ł",
	lt: "<",
	ltcc: "⪦",
	ltcir: "⩹",
	ltdot: "⋖",
	lthree: "⋋",
	ltimes: "⋉",
	ltlarr: "⥶",
	ltquest: "⩻",
	ltrPar: "⦖",
	ltri: "◃",
	ltrie: "⊴",
	ltrif: "◂",
	lurdshar: "⥊",
	luruhar: "⥦",
	lvertneqq: "≨︀",
	lvnE: "≨︀",
	mDDot: "∺",
	macr: "¯",
	male: "♂",
	malt: "✠",
	maltese: "✠",
	map: "↦",
	mapsto: "↦",
	mapstodown: "↧",
	mapstoleft: "↤",
	mapstoup: "↥",
	marker: "▮",
	mcomma: "⨩",
	mcy: "м",
	mdash: "—",
	measuredangle: "∡",
	mfr: "𝔪",
	mho: "℧",
	micro: "µ",
	mid: "∣",
	midast: "*",
	midcir: "⫰",
	middot: "·",
	minus: "−",
	minusb: "⊟",
	minusd: "∸",
	minusdu: "⨪",
	mlcp: "⫛",
	mldr: "…",
	mnplus: "∓",
	models: "⊧",
	mopf: "𝕞",
	mp: "∓",
	mscr: "𝓂",
	mstpos: "∾",
	mu: "μ",
	multimap: "⊸",
	mumap: "⊸",
	nGg: "⋙̸",
	nGt: "≫⃒",
	nGtv: "≫̸",
	nLeftarrow: "⇍",
	nLeftrightarrow: "⇎",
	nLl: "⋘̸",
	nLt: "≪⃒",
	nLtv: "≪̸",
	nRightarrow: "⇏",
	nVDash: "⊯",
	nVdash: "⊮",
	nabla: "∇",
	nacute: "ń",
	nang: "∠⃒",
	nap: "≉",
	napE: "⩰̸",
	napid: "≋̸",
	napos: "ŉ",
	napprox: "≉",
	natur: "♮",
	natural: "♮",
	naturals: "ℕ",
	nbsp: "\xA0",
	nbump: "≎̸",
	nbumpe: "≏̸",
	ncap: "⩃",
	ncaron: "ň",
	ncedil: "ņ",
	ncong: "≇",
	ncongdot: "⩭̸",
	ncup: "⩂",
	ncy: "н",
	ndash: "–",
	ne: "≠",
	neArr: "⇗",
	nearhk: "⤤",
	nearr: "↗",
	nearrow: "↗",
	nedot: "≐̸",
	nequiv: "≢",
	nesear: "⤨",
	nesim: "≂̸",
	nexist: "∄",
	nexists: "∄",
	nfr: "𝔫",
	ngE: "≧̸",
	nge: "≱",
	ngeq: "≱",
	ngeqq: "≧̸",
	ngeqslant: "⩾̸",
	nges: "⩾̸",
	ngsim: "≵",
	ngt: "≯",
	ngtr: "≯",
	nhArr: "⇎",
	nharr: "↮",
	nhpar: "⫲",
	ni: "∋",
	nis: "⋼",
	nisd: "⋺",
	niv: "∋",
	njcy: "њ",
	nlArr: "⇍",
	nlE: "≦̸",
	nlarr: "↚",
	nldr: "‥",
	nle: "≰",
	nleftarrow: "↚",
	nleftrightarrow: "↮",
	nleq: "≰",
	nleqq: "≦̸",
	nleqslant: "⩽̸",
	nles: "⩽̸",
	nless: "≮",
	nlsim: "≴",
	nlt: "≮",
	nltri: "⋪",
	nltrie: "⋬",
	nmid: "∤",
	nopf: "𝕟",
	not: "¬",
	notin: "∉",
	notinE: "⋹̸",
	notindot: "⋵̸",
	notinva: "∉",
	notinvb: "⋷",
	notinvc: "⋶",
	notni: "∌",
	notniva: "∌",
	notnivb: "⋾",
	notnivc: "⋽",
	npar: "∦",
	nparallel: "∦",
	nparsl: "⫽⃥",
	npart: "∂̸",
	npolint: "⨔",
	npr: "⊀",
	nprcue: "⋠",
	npre: "⪯̸",
	nprec: "⊀",
	npreceq: "⪯̸",
	nrArr: "⇏",
	nrarr: "↛",
	nrarrc: "⤳̸",
	nrarrw: "↝̸",
	nrightarrow: "↛",
	nrtri: "⋫",
	nrtrie: "⋭",
	nsc: "⊁",
	nsccue: "⋡",
	nsce: "⪰̸",
	nscr: "𝓃",
	nshortmid: "∤",
	nshortparallel: "∦",
	nsim: "≁",
	nsime: "≄",
	nsimeq: "≄",
	nsmid: "∤",
	nspar: "∦",
	nsqsube: "⋢",
	nsqsupe: "⋣",
	nsub: "⊄",
	nsubE: "⫅̸",
	nsube: "⊈",
	nsubset: "⊂⃒",
	nsubseteq: "⊈",
	nsubseteqq: "⫅̸",
	nsucc: "⊁",
	nsucceq: "⪰̸",
	nsup: "⊅",
	nsupE: "⫆̸",
	nsupe: "⊉",
	nsupset: "⊃⃒",
	nsupseteq: "⊉",
	nsupseteqq: "⫆̸",
	ntgl: "≹",
	ntilde: "ñ",
	ntlg: "≸",
	ntriangleleft: "⋪",
	ntrianglelefteq: "⋬",
	ntriangleright: "⋫",
	ntrianglerighteq: "⋭",
	nu: "ν",
	num: "#",
	numero: "№",
	numsp: " ",
	nvDash: "⊭",
	nvHarr: "⤄",
	nvap: "≍⃒",
	nvdash: "⊬",
	nvge: "≥⃒",
	nvgt: ">⃒",
	nvinfin: "⧞",
	nvlArr: "⤂",
	nvle: "≤⃒",
	nvlt: "<⃒",
	nvltrie: "⊴⃒",
	nvrArr: "⤃",
	nvrtrie: "⊵⃒",
	nvsim: "∼⃒",
	nwArr: "⇖",
	nwarhk: "⤣",
	nwarr: "↖",
	nwarrow: "↖",
	nwnear: "⤧",
	oS: "Ⓢ",
	oacute: "ó",
	oast: "⊛",
	ocir: "⊚",
	ocirc: "ô",
	ocy: "о",
	odash: "⊝",
	odblac: "ő",
	odiv: "⨸",
	odot: "⊙",
	odsold: "⦼",
	oelig: "œ",
	ofcir: "⦿",
	ofr: "𝔬",
	ogon: "˛",
	ograve: "ò",
	ogt: "⧁",
	ohbar: "⦵",
	ohm: "Ω",
	oint: "∮",
	olarr: "↺",
	olcir: "⦾",
	olcross: "⦻",
	oline: "‾",
	olt: "⧀",
	omacr: "ō",
	omega: "ω",
	omicron: "ο",
	omid: "⦶",
	ominus: "⊖",
	oopf: "𝕠",
	opar: "⦷",
	operp: "⦹",
	oplus: "⊕",
	or: "∨",
	orarr: "↻",
	ord: "⩝",
	order: "ℴ",
	orderof: "ℴ",
	ordf: "ª",
	ordm: "º",
	origof: "⊶",
	oror: "⩖",
	orslope: "⩗",
	orv: "⩛",
	oscr: "ℴ",
	oslash: "ø",
	osol: "⊘",
	otilde: "õ",
	otimes: "⊗",
	otimesas: "⨶",
	ouml: "ö",
	ovbar: "⌽",
	par: "∥",
	para: "¶",
	parallel: "∥",
	parsim: "⫳",
	parsl: "⫽",
	part: "∂",
	pcy: "п",
	percnt: "%",
	period: ".",
	permil: "‰",
	perp: "⊥",
	pertenk: "‱",
	pfr: "𝔭",
	phi: "φ",
	phiv: "ϕ",
	phmmat: "ℳ",
	phone: "☎",
	pi: "π",
	pitchfork: "⋔",
	piv: "ϖ",
	planck: "ℏ",
	planckh: "ℎ",
	plankv: "ℏ",
	plus: "+",
	plusacir: "⨣",
	plusb: "⊞",
	pluscir: "⨢",
	plusdo: "∔",
	plusdu: "⨥",
	pluse: "⩲",
	plusmn: "±",
	plussim: "⨦",
	plustwo: "⨧",
	pm: "±",
	pointint: "⨕",
	popf: "𝕡",
	pound: "£",
	pr: "≺",
	prE: "⪳",
	prap: "⪷",
	prcue: "≼",
	pre: "⪯",
	prec: "≺",
	precapprox: "⪷",
	preccurlyeq: "≼",
	preceq: "⪯",
	precnapprox: "⪹",
	precneqq: "⪵",
	precnsim: "⋨",
	precsim: "≾",
	prime: "′",
	primes: "ℙ",
	prnE: "⪵",
	prnap: "⪹",
	prnsim: "⋨",
	prod: "∏",
	profalar: "⌮",
	profline: "⌒",
	profsurf: "⌓",
	prop: "∝",
	propto: "∝",
	prsim: "≾",
	prurel: "⊰",
	pscr: "𝓅",
	psi: "ψ",
	puncsp: " ",
	qfr: "𝔮",
	qint: "⨌",
	qopf: "𝕢",
	qprime: "⁗",
	qscr: "𝓆",
	quaternions: "ℍ",
	quatint: "⨖",
	quest: "?",
	questeq: "≟",
	quot: "\"",
	rAarr: "⇛",
	rArr: "⇒",
	rAtail: "⤜",
	rBarr: "⤏",
	rHar: "⥤",
	race: "∽̱",
	racute: "ŕ",
	radic: "√",
	raemptyv: "⦳",
	rang: "⟩",
	rangd: "⦒",
	range: "⦥",
	rangle: "⟩",
	raquo: "»",
	rarr: "→",
	rarrap: "⥵",
	rarrb: "⇥",
	rarrbfs: "⤠",
	rarrc: "⤳",
	rarrfs: "⤞",
	rarrhk: "↪",
	rarrlp: "↬",
	rarrpl: "⥅",
	rarrsim: "⥴",
	rarrtl: "↣",
	rarrw: "↝",
	ratail: "⤚",
	ratio: "∶",
	rationals: "ℚ",
	rbarr: "⤍",
	rbbrk: "❳",
	rbrace: "}",
	rbrack: "]",
	rbrke: "⦌",
	rbrksld: "⦎",
	rbrkslu: "⦐",
	rcaron: "ř",
	rcedil: "ŗ",
	rceil: "⌉",
	rcub: "}",
	rcy: "р",
	rdca: "⤷",
	rdldhar: "⥩",
	rdquo: "”",
	rdquor: "”",
	rdsh: "↳",
	real: "ℜ",
	realine: "ℛ",
	realpart: "ℜ",
	reals: "ℝ",
	rect: "▭",
	reg: "®",
	rfisht: "⥽",
	rfloor: "⌋",
	rfr: "𝔯",
	rhard: "⇁",
	rharu: "⇀",
	rharul: "⥬",
	rho: "ρ",
	rhov: "ϱ",
	rightarrow: "→",
	rightarrowtail: "↣",
	rightharpoondown: "⇁",
	rightharpoonup: "⇀",
	rightleftarrows: "⇄",
	rightleftharpoons: "⇌",
	rightrightarrows: "⇉",
	rightsquigarrow: "↝",
	rightthreetimes: "⋌",
	ring: "˚",
	risingdotseq: "≓",
	rlarr: "⇄",
	rlhar: "⇌",
	rlm: "‏",
	rmoust: "⎱",
	rmoustache: "⎱",
	rnmid: "⫮",
	roang: "⟭",
	roarr: "⇾",
	robrk: "⟧",
	ropar: "⦆",
	ropf: "𝕣",
	roplus: "⨮",
	rotimes: "⨵",
	rpar: ")",
	rpargt: "⦔",
	rppolint: "⨒",
	rrarr: "⇉",
	rsaquo: "›",
	rscr: "𝓇",
	rsh: "↱",
	rsqb: "]",
	rsquo: "’",
	rsquor: "’",
	rthree: "⋌",
	rtimes: "⋊",
	rtri: "▹",
	rtrie: "⊵",
	rtrif: "▸",
	rtriltri: "⧎",
	ruluhar: "⥨",
	rx: "℞",
	sacute: "ś",
	sbquo: "‚",
	sc: "≻",
	scE: "⪴",
	scap: "⪸",
	scaron: "š",
	sccue: "≽",
	sce: "⪰",
	scedil: "ş",
	scirc: "ŝ",
	scnE: "⪶",
	scnap: "⪺",
	scnsim: "⋩",
	scpolint: "⨓",
	scsim: "≿",
	scy: "с",
	sdot: "⋅",
	sdotb: "⊡",
	sdote: "⩦",
	seArr: "⇘",
	searhk: "⤥",
	searr: "↘",
	searrow: "↘",
	sect: "§",
	semi: ";",
	seswar: "⤩",
	setminus: "∖",
	setmn: "∖",
	sext: "✶",
	sfr: "𝔰",
	sfrown: "⌢",
	sharp: "♯",
	shchcy: "щ",
	shcy: "ш",
	shortmid: "∣",
	shortparallel: "∥",
	shy: "­",
	sigma: "σ",
	sigmaf: "ς",
	sigmav: "ς",
	sim: "∼",
	simdot: "⩪",
	sime: "≃",
	simeq: "≃",
	simg: "⪞",
	simgE: "⪠",
	siml: "⪝",
	simlE: "⪟",
	simne: "≆",
	simplus: "⨤",
	simrarr: "⥲",
	slarr: "←",
	smallsetminus: "∖",
	smashp: "⨳",
	smeparsl: "⧤",
	smid: "∣",
	smile: "⌣",
	smt: "⪪",
	smte: "⪬",
	smtes: "⪬︀",
	softcy: "ь",
	sol: "/",
	solb: "⧄",
	solbar: "⌿",
	sopf: "𝕤",
	spades: "♠",
	spadesuit: "♠",
	spar: "∥",
	sqcap: "⊓",
	sqcaps: "⊓︀",
	sqcup: "⊔",
	sqcups: "⊔︀",
	sqsub: "⊏",
	sqsube: "⊑",
	sqsubset: "⊏",
	sqsubseteq: "⊑",
	sqsup: "⊐",
	sqsupe: "⊒",
	sqsupset: "⊐",
	sqsupseteq: "⊒",
	squ: "□",
	square: "□",
	squarf: "▪",
	squf: "▪",
	srarr: "→",
	sscr: "𝓈",
	ssetmn: "∖",
	ssmile: "⌣",
	sstarf: "⋆",
	star: "☆",
	starf: "★",
	straightepsilon: "ϵ",
	straightphi: "ϕ",
	strns: "¯",
	sub: "⊂",
	subE: "⫅",
	subdot: "⪽",
	sube: "⊆",
	subedot: "⫃",
	submult: "⫁",
	subnE: "⫋",
	subne: "⊊",
	subplus: "⪿",
	subrarr: "⥹",
	subset: "⊂",
	subseteq: "⊆",
	subseteqq: "⫅",
	subsetneq: "⊊",
	subsetneqq: "⫋",
	subsim: "⫇",
	subsub: "⫕",
	subsup: "⫓",
	succ: "≻",
	succapprox: "⪸",
	succcurlyeq: "≽",
	succeq: "⪰",
	succnapprox: "⪺",
	succneqq: "⪶",
	succnsim: "⋩",
	succsim: "≿",
	sum: "∑",
	sung: "♪",
	sup1: "¹",
	sup2: "²",
	sup3: "³",
	sup: "⊃",
	supE: "⫆",
	supdot: "⪾",
	supdsub: "⫘",
	supe: "⊇",
	supedot: "⫄",
	suphsol: "⟉",
	suphsub: "⫗",
	suplarr: "⥻",
	supmult: "⫂",
	supnE: "⫌",
	supne: "⊋",
	supplus: "⫀",
	supset: "⊃",
	supseteq: "⊇",
	supseteqq: "⫆",
	supsetneq: "⊋",
	supsetneqq: "⫌",
	supsim: "⫈",
	supsub: "⫔",
	supsup: "⫖",
	swArr: "⇙",
	swarhk: "⤦",
	swarr: "↙",
	swarrow: "↙",
	swnwar: "⤪",
	szlig: "ß",
	target: "⌖",
	tau: "τ",
	tbrk: "⎴",
	tcaron: "ť",
	tcedil: "ţ",
	tcy: "т",
	tdot: "⃛",
	telrec: "⌕",
	tfr: "𝔱",
	there4: "∴",
	therefore: "∴",
	theta: "θ",
	thetasym: "ϑ",
	thetav: "ϑ",
	thickapprox: "≈",
	thicksim: "∼",
	thinsp: " ",
	thkap: "≈",
	thksim: "∼",
	thorn: "þ",
	tilde: "˜",
	times: "×",
	timesb: "⊠",
	timesbar: "⨱",
	timesd: "⨰",
	tint: "∭",
	toea: "⤨",
	top: "⊤",
	topbot: "⌶",
	topcir: "⫱",
	topf: "𝕥",
	topfork: "⫚",
	tosa: "⤩",
	tprime: "‴",
	trade: "™",
	triangle: "▵",
	triangledown: "▿",
	triangleleft: "◃",
	trianglelefteq: "⊴",
	triangleq: "≜",
	triangleright: "▹",
	trianglerighteq: "⊵",
	tridot: "◬",
	trie: "≜",
	triminus: "⨺",
	triplus: "⨹",
	trisb: "⧍",
	tritime: "⨻",
	trpezium: "⏢",
	tscr: "𝓉",
	tscy: "ц",
	tshcy: "ћ",
	tstrok: "ŧ",
	twixt: "≬",
	twoheadleftarrow: "↞",
	twoheadrightarrow: "↠",
	uArr: "⇑",
	uHar: "⥣",
	uacute: "ú",
	uarr: "↑",
	ubrcy: "ў",
	ubreve: "ŭ",
	ucirc: "û",
	ucy: "у",
	udarr: "⇅",
	udblac: "ű",
	udhar: "⥮",
	ufisht: "⥾",
	ufr: "𝔲",
	ugrave: "ù",
	uharl: "↿",
	uharr: "↾",
	uhblk: "▀",
	ulcorn: "⌜",
	ulcorner: "⌜",
	ulcrop: "⌏",
	ultri: "◸",
	umacr: "ū",
	uml: "¨",
	uogon: "ų",
	uopf: "𝕦",
	uparrow: "↑",
	updownarrow: "↕",
	upharpoonleft: "↿",
	upharpoonright: "↾",
	uplus: "⊎",
	upsi: "υ",
	upsih: "ϒ",
	upsilon: "υ",
	upuparrows: "⇈",
	urcorn: "⌝",
	urcorner: "⌝",
	urcrop: "⌎",
	uring: "ů",
	urtri: "◹",
	uscr: "𝓊",
	utdot: "⋰",
	utilde: "ũ",
	utri: "▵",
	utrif: "▴",
	uuarr: "⇈",
	uuml: "ü",
	uwangle: "⦧",
	vArr: "⇕",
	vBar: "⫨",
	vBarv: "⫩",
	vDash: "⊨",
	vangrt: "⦜",
	varepsilon: "ϵ",
	varkappa: "ϰ",
	varnothing: "∅",
	varphi: "ϕ",
	varpi: "ϖ",
	varpropto: "∝",
	varr: "↕",
	varrho: "ϱ",
	varsigma: "ς",
	varsubsetneq: "⊊︀",
	varsubsetneqq: "⫋︀",
	varsupsetneq: "⊋︀",
	varsupsetneqq: "⫌︀",
	vartheta: "ϑ",
	vartriangleleft: "⊲",
	vartriangleright: "⊳",
	vcy: "в",
	vdash: "⊢",
	vee: "∨",
	veebar: "⊻",
	veeeq: "≚",
	vellip: "⋮",
	verbar: "|",
	vert: "|",
	vfr: "𝔳",
	vltri: "⊲",
	vnsub: "⊂⃒",
	vnsup: "⊃⃒",
	vopf: "𝕧",
	vprop: "∝",
	vrtri: "⊳",
	vscr: "𝓋",
	vsubnE: "⫋︀",
	vsubne: "⊊︀",
	vsupnE: "⫌︀",
	vsupne: "⊋︀",
	vzigzag: "⦚",
	wcirc: "ŵ",
	wedbar: "⩟",
	wedge: "∧",
	wedgeq: "≙",
	weierp: "℘",
	wfr: "𝔴",
	wopf: "𝕨",
	wp: "℘",
	wr: "≀",
	wreath: "≀",
	wscr: "𝓌",
	xcap: "⋂",
	xcirc: "◯",
	xcup: "⋃",
	xdtri: "▽",
	xfr: "𝔵",
	xhArr: "⟺",
	xharr: "⟷",
	xi: "ξ",
	xlArr: "⟸",
	xlarr: "⟵",
	xmap: "⟼",
	xnis: "⋻",
	xodot: "⨀",
	xopf: "𝕩",
	xoplus: "⨁",
	xotime: "⨂",
	xrArr: "⟹",
	xrarr: "⟶",
	xscr: "𝓍",
	xsqcup: "⨆",
	xuplus: "⨄",
	xutri: "△",
	xvee: "⋁",
	xwedge: "⋀",
	yacute: "ý",
	yacy: "я",
	ycirc: "ŷ",
	ycy: "ы",
	yen: "¥",
	yfr: "𝔶",
	yicy: "ї",
	yopf: "𝕪",
	yscr: "𝓎",
	yucy: "ю",
	yuml: "ÿ",
	zacute: "ź",
	zcaron: "ž",
	zcy: "з",
	zdot: "ż",
	zeetrf: "ℨ",
	zeta: "ζ",
	zfr: "𝔷",
	zhcy: "ж",
	zigrarr: "⇝",
	zopf: "𝕫",
	zscr: "𝓏",
	zwj: "‍",
	zwnj: "‌"
}, qn = {}.hasOwnProperty;
function Jn(e) {
	return qn.call(Kn, e) ? Kn[e] : !1;
}
// node_modules/micromark-util-chunked/index.js
function Yn(e, t, n, r) {
	let i = e.length, a = 0, o;
	if (t = t < 0 ? -t > i ? 0 : i + t : t > i ? i : t, n = n > 0 ? n : 0, r.length < 1e4) o = Array.from(r), o.unshift(t, n), e.splice(...o);
	else for (n && e.splice(t, n); a < r.length;) o = r.slice(a, a + 1e4), o.unshift(t, 0), e.splice(...o), a += 1e4, t += 1e4;
}
function Xn(e, t) {
	return e.length > 0 ? (Yn(e, e.length, 0, t), e) : t;
}
// node_modules/micromark-util-combine-extensions/index.js
var Zn = {}.hasOwnProperty;
function Qn(e) {
	let t = {}, n = -1;
	for (; ++n < e.length;) $n(t, e[n]);
	return t;
}
function $n(e, t) {
	let n;
	for (n in t) {
		let r = (Zn.call(e, n) ? e[n] : void 0) || (e[n] = {}), i = t[n], a;
		if (i) for (a in i) {
			Zn.call(r, a) || (r[a] = []);
			let e = i[a];
			er(r[a], Array.isArray(e) ? e : e ? [e] : []);
		}
	}
}
function er(e, t) {
	let n = -1, r = [];
	for (; ++n < t.length;) (t[n].add === "after" ? e : r).push(t[n]);
	Yn(e, 0, 0, r);
}
// node_modules/micromark-util-decode-numeric-character-reference/index.js
function tr(e, t) {
	let n = Number.parseInt(e, t);
	return n < 9 || n === 11 || n > 13 && n < 32 || n > 126 && n < 160 || n > 55295 && n < 57344 || n > 64975 && n < 65008 || (n & 65535) == 65535 || (n & 65535) == 65534 || n > 1114111 ? "�" : String.fromCodePoint(n);
}
// node_modules/micromark-util-normalize-identifier/index.js
function nr(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase();
}
// node_modules/micromark-util-character/index.js
var z = ur(/[A-Za-z]/), B = ur(/[\dA-Za-z]/), rr = ur(/[#-'*+\--9=?A-Z^-~]/);
function ir(e) {
	return e !== null && (e < 32 || e === 127);
}
var ar = ur(/\d/), or = ur(/[\dA-Fa-f]/), sr = ur(/[!-/:-@[-`{-~]/);
function V(e) {
	return e !== null && e < -2;
}
function H(e) {
	return e !== null && (e < 0 || e === 32);
}
function U(e) {
	return e === -2 || e === -1 || e === 32;
}
var cr = ur(/\p{P}|\p{S}/u), lr = ur(/\s/);
function ur(e) {
	return t;
	function t(t) {
		return t !== null && t > -1 && e.test(String.fromCharCode(t));
	}
}
// node_modules/micromark-factory-space/index.js
function W(e, t, n, r) {
	let i = r ? r - 1 : Infinity, a = 0;
	return o;
	function o(r) {
		return U(r) ? (e.enter(n), s(r)) : t(r);
	}
	function s(r) {
		return U(r) && a++ < i ? (e.consume(r), s) : (e.exit(n), t(r));
	}
}
function dr(e, t, n, r, i, a) {
	let o = 0;
	return s;
	function s(t) {
		return a > 0 && U(t) ? (e.enter(r), c(t)) : l(t);
	}
	function c(t) {
		return U(t) && o < a ? (e.consume(t), o++, c) : (e.exit(r), l(t));
	}
	function l(e) {
		return o >= i ? t(e) : n(e);
	}
}
// node_modules/micromark/lib/initialize/content.js
var fr = { tokenize: pr };
function pr(e) {
	let t = e.attempt(this.parser.constructs.contentInitial, r, i), n;
	return t;
	function r(n) {
		if (n === null) e.consume(n);
		else return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), W(e, t, "linePrefix");
	}
	function i(t) {
		return e.enter("paragraph"), a(t);
	}
	function a(t) {
		let r = e.enter("chunkText", {
			contentType: "text",
			previous: n
		});
		return n && (n.next = r), n = r, o(t);
	}
	function o(t) {
		if (t === null) e.exit("chunkText"), e.exit("paragraph"), e.consume(t);
		else return V(t) ? (e.consume(t), e.exit("chunkText"), a) : (e.consume(t), o);
	}
}
// node_modules/micromark-util-edit-map/index.js
var mr = class {
	constructor() {
		this.index = /* @__PURE__ */ new Map(), this.map = [];
	}
	add(e, t, n) {
		hr(this, e, t, n, !1);
	}
	addBefore(e, t, n) {
		hr(this, e, t, n, !0);
	}
	consume(e) {
		if (this.map.sort(function(e, t) {
			return e[0] - t[0];
		}), this.map.length === 0) return;
		let t = this.map.length, n = [];
		for (; t > 0;) --t, n.push(e.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), e.length = this.map[t][0];
		n.push(e.slice()), e.length = 0;
		let r = n.pop();
		for (; r;) {
			for (let t of r) e.push(t);
			r = n.pop();
		}
		this.map.length = 0, this.index.clear();
	}
};
function hr(e, t, n, r, i) {
	if (n === 0 && r.length === 0) return;
	let a = e.index.get(t);
	if (a) {
		a[1] += n, i ? (r.push(...a[2]), a[2] = r) : a[2].push(...r);
		return;
	}
	let o = [
		t,
		n,
		r
	];
	e.map.push(o), e.index.set(t, o);
}
// node_modules/micromark/lib/initialize/document.js
var gr = { tokenize: vr }, _r = { tokenize: yr };
function vr(e) {
	let t = this, n = [], r = 0, i, a, o;
	return s;
	function s(i) {
		if (r < n.length) {
			let a = n[r];
			return t.containerState = a[1], e.attempt(a[0].continuation, c, l)(i);
		}
		return l(i);
	}
	function c(e) {
		if (r++, t.containerState._closeFlow) {
			t.containerState._closeFlow = void 0, i && v();
			let n = t.events.length, a = n, o;
			for (; a--;) if (t.events[a][0] === "exit" && t.events[a][1].type === "chunkFlow") {
				o = t.events[a][1].end;
				break;
			}
			_(r);
			let s = n;
			for (; s < t.events.length;) t.events[s][1].end = { ...o }, s++;
			let c = new mr();
			return c.add(a + 1, 0, t.events.slice(n)), c.add(n, s - n, []), c.consume(t.events), l(e);
		}
		return s(e);
	}
	function l(a) {
		if (r === n.length) {
			if (!i) return f(a);
			if (i.currentConstruct && i.currentConstruct.concrete) return m(a);
			t.interrupt = !(!i.currentConstruct || i._gfmTableDynamicInterruptHack);
		}
		return t.containerState = {}, e.check(_r, u, d)(a);
	}
	function u(e) {
		return i && v(), _(r), f(e);
	}
	function d(e) {
		return t.parser.lazy[t.now().line] = r !== n.length, o = t.now().offset, m(e);
	}
	function f(n) {
		return t.containerState = {}, e.attempt(_r, p, m)(n);
	}
	function p(e) {
		return r++, n.push([t.currentConstruct, t.containerState]), f(e);
	}
	function m(n) {
		if (n === null) i && v(), _(0), e.consume(n);
		else return i ||= t.parser.flow(t.now()), e.enter("chunkFlow", {
			_tokenizer: i,
			contentType: "flow",
			previous: a
		}), h(n);
	}
	function h(n) {
		if (n === null) g(e.exit("chunkFlow"), !0), _(0), e.consume(n);
		else return V(n) ? (e.consume(n), g(e.exit("chunkFlow")), r = 0, t.interrupt = void 0, s) : (e.consume(n), h);
	}
	function g(e, n) {
		let s = t.sliceStream(e);
		if (n && s.push(null), e.previous = a, a && (a.next = e), a = e, i.defineSkip(e.start), i.write(s), t.parser.lazy[e.start.line]) {
			let e = i.events.length;
			for (; e--;) if (i.events[e][1].start.offset < o && (!i.events[e][1].end || i.events[e][1].end.offset > o)) return;
			let n = t.events.length, a = n, s, c;
			for (; a--;) if (t.events[a][0] === "exit" && t.events[a][1].type === "chunkFlow") {
				if (s) {
					c = t.events[a][1].end;
					break;
				}
				s = !0;
			}
			for (_(r), e = n; e < t.events.length;) t.events[e][1].end = { ...c }, e++;
			let l = new mr();
			l.add(a + 1, 0, t.events.slice(n)), l.add(n, e - n, []), l.consume(t.events);
		}
	}
	function _(r) {
		let i = n.length;
		for (; i-- > r;) {
			let r = n[i];
			t.containerState = r[1], r[0].exit.call(t, e);
		}
		n.length = r;
	}
	function v() {
		i.write([null]), a = void 0, i = void 0, t.containerState._closeFlow = void 0;
	}
}
function yr(e, t, n) {
	return W(e, e.attempt(this.parser.constructs.document, t, n), "linePrefix", this.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4);
}
// node_modules/micromark-util-classify-character/index.js
function br(e) {
	if (e === null || H(e) || lr(e)) return 1;
	if (cr(e)) return 2;
}
// node_modules/micromark-util-resolve-all/index.js
function xr(e, t, n) {
	let r = [], i = -1;
	for (; ++i < e.length;) {
		let a = e[i].resolveAll;
		a && !r.includes(a) && (t = a(t, n), r.push(a));
	}
	return t;
}
// node_modules/micromark-core-commonmark/lib/attention.js
var Sr = {
	name: "attention",
	resolveAll: Cr,
	tokenize: wr
};
function Cr(e, t) {
	let n = -1, r;
	for (; ++n < e.length;) if (e[n][0] === "enter" && e[n][1].type === "attentionSequence" && e[n][1]._close) {
		let i = n;
		for (; i--;) if (e[i][0] === "exit" && e[i][1].type === "attentionSequence" && e[i][1]._open && t.sliceSerialize(e[i][1]).charCodeAt(0) === t.sliceSerialize(e[n][1]).charCodeAt(0)) {
			if ((e[i][1]._close || e[n][1]._open) && (e[n][1].end.offset - e[n][1].start.offset) % 3 && !((e[i][1].end.offset - e[i][1].start.offset + e[n][1].end.offset - e[n][1].start.offset) % 3)) continue;
			let a = e[i][1].end.offset - e[i][1].start.offset > 1 && e[n][1].end.offset - e[n][1].start.offset > 1 ? 2 : 1, o = { ...e[i][1].end }, s = { ...e[n][1].start };
			Tr(o, -a), Tr(s, a);
			let c = {
				type: a > 1 ? "strongSequence" : "emphasisSequence",
				start: o,
				end: { ...e[i][1].end }
			}, l = {
				type: a > 1 ? "strongSequence" : "emphasisSequence",
				start: { ...e[n][1].start },
				end: s
			}, u = {
				type: a > 1 ? "strongText" : "emphasisText",
				start: { ...e[i][1].end },
				end: { ...e[n][1].start }
			}, d = {
				type: a > 1 ? "strong" : "emphasis",
				start: { ...c.start },
				end: { ...l.end }
			};
			e[i][1].end = { ...c.start }, e[n][1].start = { ...l.end }, r = [], e[i][1].end.offset - e[i][1].start.offset && (r = Xn(r, [[
				"enter",
				e[i][1],
				t
			], [
				"exit",
				e[i][1],
				t
			]])), r = Xn(r, [
				[
					"enter",
					d,
					t
				],
				[
					"enter",
					c,
					t
				],
				[
					"exit",
					c,
					t
				],
				[
					"enter",
					u,
					t
				]
			]), r = Xn(r, xr(t.parser.constructs.insideSpan.null, e.slice(i + 1, n), t)), r = Xn(r, [
				[
					"exit",
					u,
					t
				],
				[
					"enter",
					l,
					t
				],
				[
					"exit",
					l,
					t
				],
				[
					"exit",
					d,
					t
				]
			]);
			let f = 0;
			e[n][1].end.offset - e[n][1].start.offset && (f = 2, r = Xn(r, [[
				"enter",
				e[n][1],
				t
			], [
				"exit",
				e[n][1],
				t
			]])), Yn(e, i - 1, n - i + 3, r), n = i + r.length - f - 2;
			break;
		}
	}
	for (n = -1; ++n < e.length;) e[n][1].type === "attentionSequence" && (e[n][1].type = "data");
	return e;
}
function wr(e, t) {
	let n = this.parser.constructs.attentionMarkers.null, r = this.previous, i = br(r), a;
	return o;
	function o(t) {
		return a = t, e.enter("attentionSequence"), s(t);
	}
	function s(o) {
		if (o === a) return e.consume(o), s;
		let c = e.exit("attentionSequence"), l = br(o), u = !l || l === 2 && i || n.includes(o) && o !== 42 && o !== 95, d = !i || i === 2 && l || n.includes(r) && r !== 42 && r !== 95;
		return c._open = !!(a === 42 ? u : u && (i || !d)), c._close = !!(a === 42 ? d : d && (l || !u)), t(o);
	}
}
function Tr(e, t) {
	e.column += t, e.offset += t, e._bufferIndex += t;
}
// node_modules/micromark-core-commonmark/lib/autolink.js
var Er = {
	name: "autolink",
	tokenize: Dr
};
function Dr(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return e.enter("autolink"), e.enter("autolinkMarker"), e.consume(t), e.exit("autolinkMarker"), e.enter("autolinkProtocol"), a;
	}
	function a(t) {
		return z(t) ? (e.consume(t), o) : t === 64 ? n(t) : l(t);
	}
	function o(e) {
		return e === 43 || e === 45 || e === 46 || B(e) ? (r = 1, s(e)) : l(e);
	}
	function s(t) {
		return t === 58 ? (e.consume(t), r = 0, c) : (t === 43 || t === 45 || t === 46 || B(t)) && r++ < 32 ? (e.consume(t), s) : (r = 0, l(t));
	}
	function c(r) {
		return r === 62 ? (e.exit("autolinkProtocol"), e.enter("autolinkMarker"), e.consume(r), e.exit("autolinkMarker"), e.exit("autolink"), t) : r === null || r === 32 || r === 60 || ir(r) ? n(r) : (e.consume(r), c);
	}
	function l(t) {
		return t === 64 ? (e.consume(t), u) : rr(t) ? (e.consume(t), l) : n(t);
	}
	function u(e) {
		return B(e) ? d(e) : n(e);
	}
	function d(n) {
		return n === 46 ? (e.consume(n), r = 0, u) : n === 62 ? (e.exit("autolinkProtocol").type = "autolinkEmail", e.enter("autolinkMarker"), e.consume(n), e.exit("autolinkMarker"), e.exit("autolink"), t) : f(n);
	}
	function f(t) {
		if ((t === 45 || B(t)) && r++ < 63) {
			let n = t === 45 ? f : d;
			return e.consume(t), n;
		}
		return n(t);
	}
}
// node_modules/micromark-core-commonmark/lib/blank-line.js
var Or = {
	partial: !0,
	tokenize: kr
};
function kr(e, t, n) {
	return r;
	function r(t) {
		return U(t) ? W(e, i, "linePrefix")(t) : i(t);
	}
	function i(e) {
		return e === null || V(e) ? t(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/block-quote.js
var Ar = {
	continuation: { tokenize: Mr },
	exit: Nr,
	name: "blockQuote",
	tokenize: jr
};
function jr(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		if (t === 62) {
			let n = r.containerState;
			return n.open ||= (e.enter("blockQuote", { _container: !0 }), !0), e.enter("blockQuotePrefix"), e.enter("blockQuoteMarker"), e.consume(t), e.exit("blockQuoteMarker"), a;
		}
		return n(t);
	}
	function a(n) {
		return U(n) ? (e.enter("blockQuotePrefixWhitespace"), e.consume(n), e.exit("blockQuotePrefixWhitespace"), e.exit("blockQuotePrefix"), t) : (e.exit("blockQuotePrefix"), t(n));
	}
}
function Mr(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return U(t) ? W(e, a, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : a(t);
	}
	function a(r) {
		return e.attempt(Ar, t, n)(r);
	}
}
function Nr(e) {
	e.exit("blockQuote");
}
// node_modules/micromark-core-commonmark/lib/character-escape.js
var Pr = {
	name: "characterEscape",
	tokenize: Fr
};
function Fr(e, t, n) {
	return r;
	function r(t) {
		return e.enter("characterEscape"), e.enter("escapeMarker"), e.consume(t), e.exit("escapeMarker"), i;
	}
	function i(r) {
		return sr(r) ? (e.enter("characterEscapeValue"), e.consume(r), e.exit("characterEscapeValue"), e.exit("characterEscape"), t) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/character-reference.js
var Ir = {
	name: "characterReference",
	tokenize: Lr
};
function Lr(e, t, n) {
	let r = this, i = 0, a, o;
	return s;
	function s(t) {
		return e.enter("characterReference"), e.enter("characterReferenceMarker"), e.consume(t), e.exit("characterReferenceMarker"), c;
	}
	function c(t) {
		return t === 35 ? (e.enter("characterReferenceMarkerNumeric"), e.consume(t), e.exit("characterReferenceMarkerNumeric"), l) : (e.enter("characterReferenceValue"), a = 31, o = B, u(t));
	}
	function l(t) {
		return t === 88 || t === 120 ? (e.enter("characterReferenceMarkerHexadecimal"), e.consume(t), e.exit("characterReferenceMarkerHexadecimal"), e.enter("characterReferenceValue"), a = 6, o = or, u) : (e.enter("characterReferenceValue"), a = 7, o = ar, u(t));
	}
	function u(s) {
		if (s === 59 && i) {
			let i = e.exit("characterReferenceValue");
			return o === B && !Jn(r.sliceSerialize(i)) ? n(s) : (e.enter("characterReferenceMarker"), e.consume(s), e.exit("characterReferenceMarker"), e.exit("characterReference"), t);
		}
		return o(s) && i++ < a ? (e.consume(s), u) : n(s);
	}
}
// node_modules/micromark-core-commonmark/lib/partial-non-lazy-continuation.js
var Rr = {
	partial: !0,
	tokenize: zr
};
function zr(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return t === null ? n(t) : (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), a);
	}
	function a(e) {
		return r.parser.lazy[r.now().line] ? n(e) : t(e);
	}
}
// node_modules/micromark-core-commonmark/lib/code-fenced.js
var Br = {
	concrete: !0,
	name: "codeFenced",
	tokenize: Vr
};
function Vr(e, t, n) {
	let r = this, i = {
		partial: !0,
		tokenize: x
	}, a = 0, o = 0, s;
	return c;
	function c(e) {
		return l(e);
	}
	function l(t) {
		let n = r.events[r.events.length - 1];
		return a = n && n[1].type === "linePrefix" ? n[2].sliceSerialize(n[1], !0).length : 0, s = t, e.enter("codeFenced"), e.enter("codeFencedFence"), e.enter("codeFencedFenceSequence"), u(t);
	}
	function u(t) {
		return t === s ? (o++, e.consume(t), u) : o < 3 ? n(t) : (e.exit("codeFencedFenceSequence"), U(t) ? W(e, d, "whitespace")(t) : d(t));
	}
	function d(n) {
		return n === null || V(n) ? (e.exit("codeFencedFence"), r.interrupt ? t(n) : e.check(Rr, h, b)(n)) : (e.enter("codeFencedFenceInfo"), e.enter("chunkString", { contentType: "string" }), f(n));
	}
	function f(t) {
		return t === null || V(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), d(t)) : U(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceInfo"), W(e, p, "whitespace")(t)) : t === 96 && t === s ? n(t) : (e.consume(t), f);
	}
	function p(t) {
		return t === null || V(t) ? d(t) : (e.enter("codeFencedFenceMeta"), e.enter("chunkString", { contentType: "string" }), m(t));
	}
	function m(t) {
		return t === null || V(t) ? (e.exit("chunkString"), e.exit("codeFencedFenceMeta"), d(t)) : t === 96 && t === s ? n(t) : (e.consume(t), m);
	}
	function h(t) {
		return e.attempt(i, b, g)(t);
	}
	function g(t) {
		return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), _;
	}
	function _(t) {
		return a > 0 && U(t) ? W(e, v, "linePrefix", a + 1)(t) : v(t);
	}
	function v(t) {
		return t === null || V(t) ? e.check(Rr, h, b)(t) : (e.enter("codeFlowValue"), y(t));
	}
	function y(t) {
		return t === null || V(t) ? (e.exit("codeFlowValue"), v(t)) : (e.consume(t), y);
	}
	function b(n) {
		return e.exit("codeFenced"), t(n);
	}
	function x(e, t, n) {
		let i = 0;
		return a;
		function a(t) {
			return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), c;
		}
		function c(t) {
			return e.enter("codeFencedFence"), U(t) ? W(e, l, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : l(t);
		}
		function l(t) {
			return t === s ? (e.enter("codeFencedFenceSequence"), u(t)) : n(t);
		}
		function u(t) {
			return t === s ? (i++, e.consume(t), u) : i >= o ? (e.exit("codeFencedFenceSequence"), U(t) ? W(e, d, "whitespace")(t) : d(t)) : n(t);
		}
		function d(r) {
			return r === null || V(r) ? (e.exit("codeFencedFence"), t(r)) : n(r);
		}
	}
}
// node_modules/micromark-core-commonmark/lib/code-indented.js
var Hr = {
	name: "codeIndented",
	tokenize: Wr
}, Ur = {
	partial: !0,
	tokenize: Gr
};
function Wr(e, t, n) {
	return r;
	function r(t) {
		return e.enter("codeIndented"), dr(e, i, n, "linePrefix", 4, 4)(t);
	}
	function i(t) {
		return t === null ? o(t) : V(t) ? e.attempt(Ur, i, o)(t) : (e.enter("codeFlowValue"), a(t));
	}
	function a(t) {
		return t === null || V(t) ? (e.exit("codeFlowValue"), i(t)) : (e.consume(t), a);
	}
	function o(n) {
		return e.exit("codeIndented"), t(n);
	}
}
function Gr(e, t, n) {
	let r = this;
	return i;
	function i(o) {
		return r.parser.lazy[r.now().line] ? n(o) : V(o) ? (e.enter("lineEnding"), e.consume(o), e.exit("lineEnding"), i) : dr(e, t, a, "linePrefix", 4, 4)(o);
	}
	function a(e) {
		return V(e) ? i(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/code-text.js
var Kr = {
	name: "codeText",
	previous: Jr,
	resolve: qr,
	tokenize: Yr
};
function qr(e) {
	let t = e.length - 4, n = 3, r, i;
	if ((e[n][1].type === "lineEnding" || e[n][1].type === "space") && (e[t][1].type === "lineEnding" || e[t][1].type === "space")) {
		for (r = n; ++r < t;) if (e[r][1].type === "codeTextData") {
			e[n][1].type = "codeTextPadding", e[t][1].type = "codeTextPadding", n += 2, t -= 2;
			break;
		}
	}
	for (r = n - 1, t++; ++r <= t;) i === void 0 ? r !== t && e[r][1].type !== "lineEnding" && (i = r) : (r === t || e[r][1].type === "lineEnding") && (e[i][1].type = "codeTextData", r !== i + 2 && (e[i][1].end = e[r - 1][1].end, e.splice(i + 2, r - i - 2), t -= r - i - 2, r = i + 2), i = void 0);
	return e;
}
function Jr(e) {
	return e !== 96 || this.events[this.events.length - 1][1].type === "characterEscape";
}
function Yr(e, t, n) {
	let r = 0, i, a;
	return o;
	function o(t) {
		return e.enter("codeText"), e.enter("codeTextSequence"), s(t);
	}
	function s(t) {
		return t === 96 ? (e.consume(t), r++, s) : (e.exit("codeTextSequence"), c(t));
	}
	function c(t) {
		return t === null ? n(t) : t === 32 ? (e.enter("space"), e.consume(t), e.exit("space"), c) : t === 96 ? (a = e.enter("codeTextSequence"), i = 0, u(t)) : V(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), c) : (e.enter("codeTextData"), l(t));
	}
	function l(t) {
		return t === null || t === 32 || t === 96 || V(t) ? (e.exit("codeTextData"), c(t)) : (e.consume(t), l);
	}
	function u(n) {
		return n === 96 ? (e.consume(n), i++, u) : i === r ? (e.exit("codeTextSequence"), e.exit("codeText"), t(n)) : (a.type = "codeTextData", l(n));
	}
}
// node_modules/micromark-util-subtokenize/lib/splice-buffer.js
var Xr = class {
	constructor(e) {
		this.left = e ? [...e] : [], this.right = [];
	}
	get(e) {
		if (e < 0 || e >= this.left.length + this.right.length) throw RangeError("Cannot access index `" + e + "` in a splice buffer of size `" + (this.left.length + this.right.length) + "`");
		return e < this.left.length ? this.left[e] : this.right[this.right.length - e + this.left.length - 1];
	}
	get length() {
		return this.left.length + this.right.length;
	}
	shift() {
		return this.setCursor(0), this.right.pop();
	}
	slice(e, t) {
		let n = t ?? Infinity;
		return n < this.left.length ? this.left.slice(e, n) : e > this.left.length ? this.right.slice(this.right.length - n + this.left.length, this.right.length - e + this.left.length).reverse() : this.left.slice(e).concat(this.right.slice(this.right.length - n + this.left.length).reverse());
	}
	splice(e, t, n) {
		let r = t || 0;
		this.setCursor(Math.trunc(e));
		let i = this.right.splice(this.right.length - r, Infinity);
		return n && Zr(this.left, n), i.reverse();
	}
	pop() {
		return this.setCursor(Infinity), this.left.pop();
	}
	push(e) {
		this.setCursor(Infinity), this.left.push(e);
	}
	pushMany(e) {
		this.setCursor(Infinity), Zr(this.left, e);
	}
	unshift(e) {
		this.setCursor(0), this.right.push(e);
	}
	unshiftMany(e) {
		this.setCursor(0), Zr(this.right, e.reverse());
	}
	setCursor(e) {
		if (!(e === this.left.length || e > this.left.length && this.right.length === 0 || e < 0 && this.left.length === 0)) {
			if (e < this.left.length) {
				let t = this.left.splice(e, Infinity);
				Zr(this.right, t.reverse());
			} else {
				let t = this.right.splice(this.left.length + this.right.length - e, Infinity);
				Zr(this.left, t.reverse());
			}
		}
	}
};
function Zr(e, t) {
	let n = 0;
	if (t.length < 1e4) e.push(...t);
	else for (; n < t.length;) e.push(...t.slice(n, n + 1e4)), n += 1e4;
}
// node_modules/micromark-util-subtokenize/index.js
function Qr(e) {
	let t = {}, n = -1, r, i, a, o, s, c, l, u = new Xr(e);
	for (; ++n < u.length;) {
		for (; n in t;) n = t[n];
		if (r = u.get(n), n && r[1].type === "chunkFlow" && u.get(n - 1)[1].type === "listItemPrefix" && (c = r[1]._tokenizer.events, a = 0, a < c.length && c[a][1].type === "lineEndingBlank" && (a += 2), a < c.length && c[a][1].type === "content")) for (; ++a < c.length && c[a][1].type !== "content";) c[a][1].type === "chunkText" && (c[a][1]._isInFirstContentOfListItem = !0, a++);
		if (r[0] === "enter") r[1].contentType && (Object.assign(t, $r(u, n)), n = t[n], l = !0);
		else if (r[1]._container) {
			for (a = n, i = void 0; a--;) if (o = u.get(a), o[1].type === "lineEnding" || o[1].type === "lineEndingBlank") o[0] === "enter" && (i && (u.get(i)[1].type = "lineEndingBlank"), o[1].type = "lineEnding", i = a);
			else if (o[1].type !== "linePrefix" && o[1].type !== "listItemIndent") break;
			i && (r[1].end = { ...u.get(i)[1].start }, s = u.slice(i, n), s.unshift(r), u.splice(i, n - i + 1, s));
		}
	}
	return Yn(e, 0, Infinity, u.slice(0)), !l;
}
function $r(e, t) {
	let n = e.get(t)[1], r = e.get(t)[2], i = t - 1, a = [], o = n._tokenizer;
	o || (o = r.parser[n.contentType](n.start), n._contentTypeTextTrailing && (o._contentTypeTextTrailing = !0));
	let s = o.events, c = [], l = {}, u, d, f = -1, p = n, m = 0, h = 0, g = [h];
	for (; p;) {
		for (; e.get(++i)[1] !== p;);
		a.push(i), p._tokenizer || (u = r.sliceStream(p), p.next || u.push(null), d && o.defineSkip(p.start), p._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = !0), o.write(u), p._isInFirstContentOfListItem && (o._gfmTasklistFirstContentOfListItem = void 0)), d = p, p = p.next;
	}
	for (p = n; ++f < s.length;) s[f][0] === "exit" && s[f - 1][0] === "enter" && s[f][1].type === s[f - 1][1].type && s[f][1].start.line !== s[f][1].end.line && (h = f + 1, g.push(h), p._tokenizer = void 0, p.previous = void 0, p = p.next);
	for (o.events = [], p ? (p._tokenizer = void 0, p.previous = void 0) : g.pop(), f = g.length; f--;) {
		let t = s.slice(g[f], g[f + 1]), n = a.pop();
		c.push([n, n + t.length - 1]), e.splice(n, 2, t);
	}
	for (c.reverse(), f = -1; ++f < c.length;) l[m + c[f][0]] = m + c[f][1], m += c[f][1] - c[f][0] - 1;
	return l;
}
// node_modules/micromark-core-commonmark/lib/content.js
var ei = {
	resolve: ni,
	tokenize: ri
}, ti = {
	partial: !0,
	tokenize: ii
};
function ni(e) {
	return Qr(e), e;
}
function ri(e, t) {
	let n;
	return r;
	function r(t) {
		return e.enter("content"), n = e.enter("chunkContent", { contentType: "content" }), i(t);
	}
	function i(t) {
		return t === null ? a(t) : V(t) ? e.check(ti, o, a)(t) : (e.consume(t), i);
	}
	function a(n) {
		return e.exit("chunkContent"), e.exit("content"), t(n);
	}
	function o(t) {
		return e.consume(t), e.exit("chunkContent"), n.next = e.enter("chunkContent", {
			contentType: "content",
			previous: n
		}), n = n.next, i;
	}
}
function ii(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return e.exit("chunkContent"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), W(e, a, "linePrefix");
	}
	function a(i) {
		if (i === null || V(i)) return n(i);
		let a = r.events[r.events.length - 1];
		return !r.parser.constructs.disable.null.includes("codeIndented") && a && a[1].type === "linePrefix" && a[2].sliceSerialize(a[1], !0).length >= 4 ? t(i) : e.interrupt(r.parser.constructs.flow, n, t)(i);
	}
}
// node_modules/micromark-factory-destination/index.js
function ai(e, t, n, r, i, a, o, s, c) {
	let l = c || Infinity, u = 0;
	return d;
	function d(t) {
		return t === 60 ? (e.enter(r), e.enter(i), e.enter(a), e.consume(t), e.exit(a), f) : t === null || t === 32 || t === 41 || ir(t) ? n(t) : (e.enter(r), e.enter(o), e.enter(s), e.enter("chunkString", { contentType: "string" }), h(t));
	}
	function f(n) {
		return n === 62 ? (e.enter(a), e.consume(n), e.exit(a), e.exit(i), e.exit(r), t) : (e.enter(s), e.enter("chunkString", { contentType: "string" }), p(n));
	}
	function p(t) {
		return t === 62 ? (e.exit("chunkString"), e.exit(s), f(t)) : t === null || t === 60 || V(t) ? n(t) : (e.consume(t), t === 92 ? m : p);
	}
	function m(t) {
		return t === 60 || t === 62 || t === 92 ? (e.consume(t), p) : p(t);
	}
	function h(i) {
		return !u && (i === null || i === 41 || H(i)) ? (e.exit("chunkString"), e.exit(s), e.exit(o), e.exit(r), t(i)) : u < l && i === 40 ? (e.consume(i), u++, h) : i === 41 ? (e.consume(i), u--, h) : i === null || i === 32 || i === 40 || ir(i) ? n(i) : (e.consume(i), i === 92 ? g : h);
	}
	function g(t) {
		return t === 40 || t === 41 || t === 92 ? (e.consume(t), h) : h(t);
	}
}
// node_modules/micromark-factory-label/index.js
function oi(e, t, n, r, i, a) {
	let o = this, s = 0, c;
	return l;
	function l(t) {
		return e.enter(r), e.enter(i), e.consume(t), e.exit(i), e.enter(a), u;
	}
	function u(l) {
		return s > 999 || l === null || l === 91 || l === 93 && !c || 
		/* c8 ignore next 3 */
		l === 94 && !s && "_hiddenFootnoteSupport" in o.parser.constructs ? n(l) : l === 93 ? (e.exit(a), e.enter(i), e.consume(l), e.exit(i), e.exit(r), t) : V(l) ? (e.enter("lineEnding"), e.consume(l), e.exit("lineEnding"), u) : (e.enter("chunkString", { contentType: "string" }), d(l));
	}
	function d(t) {
		return t === null || t === 91 || t === 93 || V(t) || s++ > 999 ? (e.exit("chunkString"), u(t)) : (e.consume(t), c ||= !U(t), t === 92 ? f : d);
	}
	function f(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), s++, d) : d(t);
	}
}
// node_modules/micromark-factory-title/index.js
function si(e, t, n, r, i, a) {
	let o;
	return s;
	function s(t) {
		return t === 34 || t === 39 || t === 40 ? (e.enter(r), e.enter(i), e.consume(t), e.exit(i), o = t === 40 ? 41 : t, c) : n(t);
	}
	function c(n) {
		return n === o ? (e.enter(i), e.consume(n), e.exit(i), e.exit(r), t) : (e.enter(a), l(n));
	}
	function l(t) {
		return t === o ? (e.exit(a), c(o)) : t === null ? n(t) : V(t) ? (e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), W(e, l, "linePrefix")) : (e.enter("chunkString", { contentType: "string" }), u(t));
	}
	function u(t) {
		return t === o || t === null || V(t) ? (e.exit("chunkString"), l(t)) : (e.consume(t), t === 92 ? d : u);
	}
	function d(t) {
		return t === o || t === 92 ? (e.consume(t), u) : u(t);
	}
}
// node_modules/micromark-factory-whitespace/index.js
function ci(e, t) {
	let n;
	return r;
	function r(i) {
		return V(i) ? (e.enter("lineEnding"), e.consume(i), e.exit("lineEnding"), n = !0, r) : U(i) ? W(e, r, n ? "linePrefix" : "lineSuffix")(i) : t(i);
	}
}
// node_modules/micromark-core-commonmark/lib/definition.js
var li = {
	name: "definition",
	tokenize: di
}, ui = {
	partial: !0,
	tokenize: fi
};
function di(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("definition"), o(t);
	}
	function o(t) {
		return oi.call(r, e, s, n, "definitionLabel", "definitionLabelMarker", "definitionLabelString")(t);
	}
	function s(t) {
		return i = nr(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1)), t === 58 ? (e.enter("definitionMarker"), e.consume(t), e.exit("definitionMarker"), c) : n(t);
	}
	function c(t) {
		return H(t) ? ci(e, l)(t) : l(t);
	}
	function l(t) {
		return ai(e, u, n, "definitionDestination", "definitionDestinationLiteral", "definitionDestinationLiteralMarker", "definitionDestinationRaw", "definitionDestinationString")(t);
	}
	function u(t) {
		return e.attempt(ui, d, d)(t);
	}
	function d(t) {
		return U(t) ? W(e, f, "whitespace")(t) : f(t);
	}
	function f(a) {
		return a === null || V(a) ? (e.exit("definition"), r.parser.defined.push(i), t(a)) : n(a);
	}
}
function fi(e, t, n) {
	return r;
	function r(t) {
		return H(t) ? ci(e, i)(t) : n(t);
	}
	function i(t) {
		return si(e, a, n, "definitionTitle", "definitionTitleMarker", "definitionTitleString")(t);
	}
	function a(t) {
		return U(t) ? W(e, o, "whitespace")(t) : o(t);
	}
	function o(e) {
		return e === null || V(e) ? t(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/hard-break-escape.js
var pi = {
	name: "hardBreakEscape",
	tokenize: mi
};
function mi(e, t, n) {
	return r;
	function r(t) {
		return e.enter("hardBreakEscape"), e.consume(t), i;
	}
	function i(r) {
		return V(r) ? (e.exit("hardBreakEscape"), t(r)) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/heading-atx.js
var hi = {
	name: "headingAtx",
	resolve: gi,
	tokenize: _i
};
function gi(e, t) {
	let n = e.length - 2, r = 3;
	if (e[r][1].type === "whitespace" && (r += 2), n - 2 > r && e[n][1].type === "whitespace" && (n -= 2), e[n][1].type === "atxHeadingSequence" && (r === n - 1 || n - 4 > r && e[n - 2][1].type === "whitespace") && (n -= r + 1 === n ? 2 : 4), n > r) {
		let i = {
			type: "atxHeadingText",
			start: e[r][1].start,
			end: e[n][1].end
		}, a = {
			type: "chunkText",
			start: e[r][1].start,
			end: e[n][1].end,
			contentType: "text"
		};
		Yn(e, r, n - r + 1, [
			[
				"enter",
				i,
				t
			],
			[
				"enter",
				a,
				t
			],
			[
				"exit",
				a,
				t
			],
			[
				"exit",
				i,
				t
			]
		]);
	}
	return e;
}
function _i(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return e.enter("atxHeading"), a(t);
	}
	function a(t) {
		return e.enter("atxHeadingSequence"), o(t);
	}
	function o(t) {
		return t === 35 && r++ < 6 ? (e.consume(t), o) : t === null || H(t) ? (e.exit("atxHeadingSequence"), s(t)) : n(t);
	}
	function s(n) {
		return n === 35 ? (e.enter("atxHeadingSequence"), c(n)) : n === null || V(n) ? (e.exit("atxHeading"), t(n)) : U(n) ? W(e, s, "whitespace")(n) : (e.enter("atxHeadingText"), l(n));
	}
	function c(t) {
		return t === 35 ? (e.consume(t), c) : (e.exit("atxHeadingSequence"), s(t));
	}
	function l(t) {
		return t === null || t === 35 || H(t) ? (e.exit("atxHeadingText"), s(t)) : (e.consume(t), l);
	}
}
// node_modules/micromark-util-html-tag-name/index.js
var vi = /* @__PURE__ */ "address.article.aside.base.basefont.blockquote.body.caption.center.col.colgroup.dd.details.dialog.dir.div.dl.dt.fieldset.figcaption.figure.footer.form.frame.frameset.h1.h2.h3.h4.h5.h6.head.header.hr.html.iframe.legend.li.link.main.menu.menuitem.nav.noframes.ol.optgroup.option.p.param.search.section.summary.table.tbody.td.tfoot.th.thead.title.tr.track.ul".split("."), yi = [
	"pre",
	"script",
	"style",
	"textarea"
], bi = {
	concrete: !0,
	name: "htmlFlow",
	resolveTo: Si,
	tokenize: Ci
}, xi = {
	partial: !0,
	tokenize: wi
};
function Si(e) {
	let t = e.length;
	for (; t-- && (e[t][0] !== "enter" || e[t][1].type !== "htmlFlow"););
	return t > 1 && e[t - 2][1].type === "linePrefix" && (e[t][1].start = e[t - 2][1].start, e[t + 1][1].start = e[t - 2][1].start, e.splice(t - 2, 2)), e;
}
function Ci(e, t, n) {
	let r = this, i, a, o, s, c;
	return l;
	function l(e) {
		return u(e);
	}
	function u(t) {
		return e.enter("htmlFlow"), e.enter("htmlFlowData"), e.consume(t), d;
	}
	function d(s) {
		return s === 33 ? (e.consume(s), f) : s === 47 ? (e.consume(s), a = !0, h) : s === 63 ? (e.consume(s), i = 3, r.interrupt ? t : ie) : z(s) ? (e.consume(s), o = String.fromCharCode(s), g) : n(s);
	}
	function f(a) {
		return a === 45 ? (e.consume(a), i = 2, p) : a === 91 ? (e.consume(a), i = 5, s = 0, m) : z(a) ? (e.consume(a), i = 4, r.interrupt ? t : ie) : n(a);
	}
	function p(i) {
		return i === 45 ? (e.consume(i), r.interrupt ? t : ie) : n(i);
	}
	function m(i) {
		return i === "CDATA[".charCodeAt(s++) ? (e.consume(i), s === 6 ? r.interrupt ? t : O : m) : n(i);
	}
	function h(t) {
		return z(t) ? (e.consume(t), o = String.fromCharCode(t), g) : n(t);
	}
	function g(s) {
		if (s === null || s === 47 || s === 62 || H(s)) {
			let c = s === 47, l = o.toLowerCase();
			return !c && !a && yi.includes(l) ? (i = 1, r.interrupt ? t(s) : O(s)) : vi.includes(o.toLowerCase()) ? (i = 6, c ? (e.consume(s), _) : r.interrupt ? t(s) : O(s)) : (i = 7, r.interrupt && !r.parser.lazy[r.now().line] ? n(s) : a ? v(s) : y(s));
		}
		return s === 45 || B(s) ? (e.consume(s), o += String.fromCharCode(s), g) : n(s);
	}
	function _(i) {
		return i === 62 ? (e.consume(i), r.interrupt ? t : O) : n(i);
	}
	function v(t) {
		return U(t) ? (e.consume(t), v) : E(t);
	}
	function y(t) {
		return t === 47 ? (e.consume(t), E) : t === 58 || t === 95 || z(t) ? (e.consume(t), b) : U(t) ? (e.consume(t), y) : E(t);
	}
	function b(t) {
		return t === 45 || t === 46 || t === 58 || t === 95 || B(t) ? (e.consume(t), b) : x(t);
	}
	function x(t) {
		return t === 61 ? (e.consume(t), S) : U(t) ? (e.consume(t), x) : y(t);
	}
	function S(t) {
		return t === null || t === 60 || t === 61 || t === 62 || t === 96 ? n(t) : t === 34 || t === 39 ? (e.consume(t), c = t, C) : U(t) ? (e.consume(t), S) : w(t);
	}
	function C(t) {
		return t === c ? (e.consume(t), c = null, T) : t === null || V(t) ? n(t) : (e.consume(t), C);
	}
	function w(t) {
		return t === null || t === 34 || t === 39 || t === 47 || t === 60 || t === 61 || t === 62 || t === 96 || H(t) ? x(t) : (e.consume(t), w);
	}
	function T(e) {
		return e === 47 || e === 62 || U(e) ? y(e) : n(e);
	}
	function E(t) {
		return t === 62 ? (e.consume(t), D) : n(t);
	}
	function D(t) {
		return t === null || V(t) ? O(t) : U(t) ? (e.consume(t), D) : n(t);
	}
	function O(t) {
		return t === 45 && i === 2 ? (e.consume(t), te) : t === 60 && i === 1 ? (e.consume(t), ne) : t === 62 && i === 4 ? (e.consume(t), ae) : t === 63 && i === 3 ? (e.consume(t), ie) : t === 93 && i === 5 ? (e.consume(t), j) : V(t) && (i === 6 || i === 7) ? (e.exit("htmlFlowData"), e.check(xi, oe, k)(t)) : t === null || V(t) ? (e.exit("htmlFlowData"), k(t)) : (e.consume(t), O);
	}
	function k(t) {
		return e.check(Rr, A, oe)(t);
	}
	function A(t) {
		return e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), ee;
	}
	function ee(t) {
		return t === null || V(t) ? k(t) : (e.enter("htmlFlowData"), O(t));
	}
	function te(t) {
		return t === 45 ? (e.consume(t), ie) : O(t);
	}
	function ne(t) {
		return t === 47 ? (e.consume(t), o = "", re) : O(t);
	}
	function re(t) {
		if (t === 62) {
			let n = o.toLowerCase();
			return yi.includes(n) ? (e.consume(t), ae) : O(t);
		}
		return z(t) && o.length < 8 ? (e.consume(t), o += String.fromCharCode(t), re) : O(t);
	}
	function j(t) {
		return t === 93 ? (e.consume(t), ie) : O(t);
	}
	function ie(t) {
		return t === 62 ? (e.consume(t), ae) : t === 45 && i === 2 ? (e.consume(t), ie) : O(t);
	}
	function ae(t) {
		return t === null || V(t) ? (e.exit("htmlFlowData"), oe(t)) : (e.consume(t), ae);
	}
	function oe(n) {
		return e.exit("htmlFlow"), t(n);
	}
}
function wi(e, t, n) {
	return r;
	function r(r) {
		return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), e.attempt(Or, t, n);
	}
}
// node_modules/micromark-core-commonmark/lib/html-text.js
var Ti = {
	name: "htmlText",
	tokenize: Ei
};
function Ei(e, t, n) {
	let r = this, i, a, o;
	return s;
	function s(t) {
		return e.enter("htmlText"), e.enter("htmlTextData"), e.consume(t), c;
	}
	function c(t) {
		return t === 33 ? (e.consume(t), l) : t === 47 ? (e.consume(t), x) : t === 63 ? (e.consume(t), y) : z(t) ? (e.consume(t), w) : n(t);
	}
	function l(t) {
		return t === 45 ? (e.consume(t), u) : t === 91 ? (e.consume(t), a = 0, m) : z(t) ? (e.consume(t), v) : n(t);
	}
	function u(t) {
		return t === 45 ? (e.consume(t), p) : n(t);
	}
	function d(t) {
		return t === null ? n(t) : t === 45 ? (e.consume(t), f) : V(t) ? (o = d, ne(t)) : (e.consume(t), d);
	}
	function f(t) {
		return t === 45 ? (e.consume(t), p) : d(t);
	}
	function p(e) {
		return e === 62 ? te(e) : e === 45 ? f(e) : d(e);
	}
	function m(t) {
		return t === "CDATA[".charCodeAt(a++) ? (e.consume(t), a === 6 ? h : m) : n(t);
	}
	function h(t) {
		return t === null ? n(t) : t === 93 ? (e.consume(t), g) : V(t) ? (o = h, ne(t)) : (e.consume(t), h);
	}
	function g(t) {
		return t === 93 ? (e.consume(t), _) : h(t);
	}
	function _(t) {
		return t === 62 ? te(t) : t === 93 ? (e.consume(t), _) : h(t);
	}
	function v(t) {
		return t === null || t === 62 ? te(t) : V(t) ? (o = v, ne(t)) : (e.consume(t), v);
	}
	function y(t) {
		return t === null ? n(t) : t === 63 ? (e.consume(t), b) : V(t) ? (o = y, ne(t)) : (e.consume(t), y);
	}
	function b(e) {
		return e === 62 ? te(e) : y(e);
	}
	function x(t) {
		return z(t) ? (e.consume(t), S) : n(t);
	}
	function S(t) {
		return t === 45 || B(t) ? (e.consume(t), S) : C(t);
	}
	function C(t) {
		return V(t) ? (o = C, ne(t)) : U(t) ? (e.consume(t), C) : te(t);
	}
	function w(t) {
		return t === 45 || B(t) ? (e.consume(t), w) : t === 47 || t === 62 || H(t) ? T(t) : n(t);
	}
	function T(t) {
		return t === 47 ? (e.consume(t), te) : t === 58 || t === 95 || z(t) ? (e.consume(t), E) : V(t) ? (o = T, ne(t)) : U(t) ? (e.consume(t), T) : te(t);
	}
	function E(t) {
		return t === 45 || t === 46 || t === 58 || t === 95 || B(t) ? (e.consume(t), E) : D(t);
	}
	function D(t) {
		return t === 61 ? (e.consume(t), O) : V(t) ? (o = D, ne(t)) : U(t) ? (e.consume(t), D) : T(t);
	}
	function O(t) {
		return t === null || t === 60 || t === 61 || t === 62 || t === 96 ? n(t) : t === 34 || t === 39 ? (e.consume(t), i = t, k) : V(t) ? (o = O, ne(t)) : U(t) ? (e.consume(t), O) : (e.consume(t), A);
	}
	function k(t) {
		return t === i ? (e.consume(t), i = void 0, ee) : t === null ? n(t) : V(t) ? (o = k, ne(t)) : (e.consume(t), k);
	}
	function A(t) {
		return t === null || t === 34 || t === 39 || t === 60 || t === 61 || t === 96 ? n(t) : t === 47 || t === 62 || H(t) ? T(t) : (e.consume(t), A);
	}
	function ee(e) {
		return e === 47 || e === 62 || H(e) ? T(e) : n(e);
	}
	function te(r) {
		return r === 62 ? (e.consume(r), e.exit("htmlTextData"), e.exit("htmlText"), t) : n(r);
	}
	function ne(t) {
		return e.exit("htmlTextData"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), re;
	}
	function re(t) {
		return U(t) ? W(e, j, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : j(t);
	}
	function j(t) {
		return e.enter("htmlTextData"), o(t);
	}
}
// node_modules/micromark-core-commonmark/lib/label-end.js
var Di = {
	name: "labelEnd",
	resolveAll: ji,
	resolveTo: Mi,
	tokenize: Ni
}, Oi = { tokenize: Pi }, ki = { tokenize: Fi }, Ai = { tokenize: Ii };
function ji(e) {
	let t = -1, n = [];
	for (; ++t < e.length;) {
		let r = e[t][1];
		if (n.push(e[t]), r.type === "labelImage" || r.type === "labelLink" || r.type === "labelEnd") {
			let e = r.type === "labelImage" ? 4 : 2;
			r.type = "data", t += e;
		}
	}
	return e.length !== n.length && Yn(e, 0, e.length, n), e;
}
function Mi(e, t) {
	let n = e.length, r = 0, i, a, o;
	for (; n--;) {
		let t = e[n][1];
		if (i) {
			if (t.type === "link" || t.type === "labelLink" && t._inactive) break;
			e[n][0] === "enter" && t.type === "labelLink" && (t._inactive = !0);
		} else if (a) {
			if (e[n][0] === "enter" && (t.type === "labelImage" || t.type === "labelLink") && !t._balanced && (i = n, t.type !== "labelLink")) {
				r = 2;
				break;
			}
		} else t.type === "labelEnd" && (a = n);
	}
	let s = {
		type: e[i][1].type === "labelLink" ? "link" : "image",
		start: { ...e[i][1].start },
		end: { ...e[e.length - 1][1].end }
	}, c = {
		type: "label",
		start: { ...e[i][1].start },
		end: { ...e[a][1].end }
	}, l = {
		type: "labelText",
		start: { ...e[i + r + 2][1].end },
		end: { ...e[a - 2][1].start }
	};
	return o = [[
		"enter",
		s,
		t
	], [
		"enter",
		c,
		t
	]], o = Xn(o, e.slice(i + 1, i + r + 3)), o = Xn(o, [[
		"enter",
		l,
		t
	]]), o = Xn(o, xr(t.parser.constructs.insideSpan.null, e.slice(i + r + 4, a - 3), t)), o = Xn(o, [
		[
			"exit",
			l,
			t
		],
		e[a - 2],
		e[a - 1],
		[
			"exit",
			c,
			t
		]
	]), o = Xn(o, e.slice(a + 1)), o = Xn(o, [[
		"exit",
		s,
		t
	]]), Yn(e, i, e.length, o), e;
}
function Ni(e, t, n) {
	let r = this, i = r._labelStarts, a, o;
	if (i) {
		for (; i.length > 0 && i[i.length - 1]._balanced;) i.pop();
		a = i[i.length - 1];
	}
	return s;
	function s(t) {
		return a ? a._inactive ? d(t) : (o = r.parser.defined.includes(nr(r.sliceSerialize({
			start: a.end,
			end: r.now()
		}))), e.enter("labelEnd"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), e.exit("labelEnd"), c) : n(t);
	}
	function c(t) {
		return t === 40 ? e.attempt(Oi, u, o ? u : d)(t) : t === 91 ? e.attempt(ki, u, o ? l : d)(t) : o ? u(t) : d(t);
	}
	function l(t) {
		return e.attempt(Ai, u, d)(t);
	}
	function u(e) {
		return i.pop(), t(e);
	}
	function d(e) {
		return a._balanced = !0, n(e);
	}
}
function Pi(e, t, n) {
	return r;
	function r(t) {
		return e.enter("resource"), e.enter("resourceMarker"), e.consume(t), e.exit("resourceMarker"), i;
	}
	function i(t) {
		return H(t) ? ci(e, a)(t) : a(t);
	}
	function a(t) {
		return t === 41 ? u(t) : ai(e, o, s, "resourceDestination", "resourceDestinationLiteral", "resourceDestinationLiteralMarker", "resourceDestinationRaw", "resourceDestinationString", 32)(t);
	}
	function o(t) {
		return H(t) ? ci(e, c)(t) : u(t);
	}
	function s(e) {
		return n(e);
	}
	function c(t) {
		return t === 34 || t === 39 || t === 40 ? si(e, l, n, "resourceTitle", "resourceTitleMarker", "resourceTitleString")(t) : u(t);
	}
	function l(t) {
		return H(t) ? ci(e, u)(t) : u(t);
	}
	function u(r) {
		return r === 41 ? (e.enter("resourceMarker"), e.consume(r), e.exit("resourceMarker"), e.exit("resource"), t) : n(r);
	}
}
function Fi(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return oi.call(r, e, a, o, "reference", "referenceMarker", "referenceString")(t);
	}
	function a(e) {
		return r.parser.defined.includes(nr(r.sliceSerialize(r.events[r.events.length - 1][1]).slice(1, -1))) ? t(e) : n(e);
	}
	function o(e) {
		return n(e);
	}
}
function Ii(e, t, n) {
	return r;
	function r(t) {
		return e.enter("reference"), e.enter("referenceMarker"), e.consume(t), e.exit("referenceMarker"), i;
	}
	function i(r) {
		return r === 93 ? (e.enter("referenceMarker"), e.consume(r), e.exit("referenceMarker"), e.exit("reference"), t) : n(r);
	}
}
// node_modules/micromark-core-commonmark/lib/label-start-image.js
var Li = {
	name: "labelStartImage",
	resolveAll: Di.resolveAll,
	tokenize: Ri
};
function Ri(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("labelImage"), e.enter("labelImageMarker"), e.consume(t), e.exit("labelImageMarker"), o;
	}
	function o(t) {
		return t === 91 ? (e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), i = e.exit("labelImage"), s) : n(t);
	}
	function s(e) {
		return e === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(e));
	}
}
// node_modules/micromark-core-commonmark/lib/label-start-link.js
var zi = {
	name: "labelStartLink",
	resolveAll: Di.resolveAll,
	tokenize: Bi
};
function Bi(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		return e.enter("labelLink"), e.enter("labelMarker"), e.consume(t), e.exit("labelMarker"), i = e.exit("labelLink"), o;
	}
	function o(e) {
		return e === 94 && "_hiddenFootnoteSupport" in r.parser.constructs ? n(e) : (r._labelStarts = r._labelStarts || [], r._labelStarts.push(i), t(e));
	}
}
// node_modules/micromark-core-commonmark/lib/line-ending.js
var Vi = {
	name: "lineEnding",
	tokenize: Hi
};
function Hi(e, t) {
	return n;
	function n(n) {
		return e.enter("lineEnding"), e.consume(n), e.exit("lineEnding"), W(e, t, "linePrefix");
	}
}
// node_modules/micromark-core-commonmark/lib/thematic-break.js
var Ui = {
	name: "thematicBreak",
	tokenize: Wi
};
function Wi(e, t, n) {
	let r = 0, i;
	return a;
	function a(t) {
		return e.enter("thematicBreak"), o(t);
	}
	function o(e) {
		return i = e, s(e);
	}
	function s(a) {
		return a === i ? (e.enter("thematicBreakSequence"), c(a)) : r >= 3 && (a === null || V(a)) ? (e.exit("thematicBreak"), t(a)) : n(a);
	}
	function c(t) {
		return t === i ? (e.consume(t), r++, c) : (e.exit("thematicBreakSequence"), U(t) ? W(e, s, "whitespace")(t) : s(t));
	}
}
// node_modules/micromark-core-commonmark/lib/list.js
var G = {
	continuation: { tokenize: Ji },
	exit: Xi,
	name: "list",
	tokenize: qi
}, Gi = {
	partial: !0,
	tokenize: Zi
}, Ki = {
	partial: !0,
	tokenize: Yi
};
function qi(e, t, n) {
	let r = this, i = r.events[r.events.length - 1], a = i && i[1].type === "linePrefix" ? i[2].sliceSerialize(i[1], !0).length : 0, o = 0;
	return s;
	function s(t) {
		let i = r.containerState.type || (t === 42 || t === 43 || t === 45 ? "listUnordered" : "listOrdered");
		if (i === "listUnordered" ? !r.containerState.marker || t === r.containerState.marker : ar(t)) {
			if (r.containerState.type || (r.containerState.type = i, e.enter(i, { _container: !0 })), i === "listUnordered") return e.enter("listItemPrefix"), t === 42 || t === 45 ? e.check(Ui, n, l)(t) : l(t);
			if (!r.interrupt || t === 49) return e.enter("listItemPrefix"), e.enter("listItemValue"), c(t);
		}
		return n(t);
	}
	function c(t) {
		return ar(t) && ++o < 10 ? (e.consume(t), c) : (!r.interrupt || o < 2) && (r.containerState.marker ? t === r.containerState.marker : t === 41 || t === 46) ? (e.exit("listItemValue"), l(t)) : n(t);
	}
	function l(t) {
		return e.enter("listItemMarker"), e.consume(t), e.exit("listItemMarker"), r.containerState.marker = r.containerState.marker || t, e.check(Or, r.interrupt ? n : u, e.attempt(Gi, f, d));
	}
	function u(e) {
		return r.containerState.initialBlankLine = !0, a++, f(e);
	}
	function d(t) {
		return U(t) ? (e.enter("listItemPrefixWhitespace"), e.consume(t), e.exit("listItemPrefixWhitespace"), f) : n(t);
	}
	function f(n) {
		return r.containerState.size = a + r.sliceSerialize(e.exit("listItemPrefix"), !0).length, t(n);
	}
}
function Ji(e, t, n) {
	let r = this;
	return r.containerState._closeFlow = void 0, e.check(Or, i, a);
	function i(n) {
		return r.containerState.furtherBlankLines = r.containerState.furtherBlankLines || r.containerState.initialBlankLine, W(e, t, "listItemIndent", r.containerState.size + 1)(n);
	}
	function a(n) {
		return r.containerState.furtherBlankLines || !U(n) ? (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, o(n)) : (r.containerState.furtherBlankLines = void 0, r.containerState.initialBlankLine = void 0, e.attempt(Ki, t, o)(n));
	}
	function o(i) {
		return r.containerState._closeFlow = !0, r.interrupt = void 0, W(e, e.attempt(G, t, n), "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(i);
	}
}
function Yi(e, t, n) {
	let r = this;
	return W(e, i, "listItemIndent", r.containerState.size + 1);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return i && i[1].type === "listItemIndent" && i[2].sliceSerialize(i[1], !0).length === r.containerState.size ? t(e) : n(e);
	}
}
function Xi(e) {
	e.exit(this.containerState.type);
}
function Zi(e, t, n) {
	let r = this;
	return W(e, i, "listItemPrefixWhitespace", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 5);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return !U(e) && i && i[1].type === "listItemPrefixWhitespace" ? t(e) : n(e);
	}
}
// node_modules/micromark-core-commonmark/lib/setext-underline.js
var Qi = {
	name: "setextUnderline",
	resolveTo: $i,
	tokenize: ea
};
function $i(e, t) {
	let n = new mr(), r = e.length, i, a, o;
	for (; r--;) if (e[r][0] === "enter") {
		if (e[r][1].type === "content") {
			i = r;
			break;
		}
		e[r][1].type === "paragraph" && (a = r);
	} else e[r][1].type === "content" && n.add(r, 1, []), !o && e[r][1].type === "definition" && (o = r);
	let s = {
		type: "setextHeading",
		start: { ...e[i][1].start },
		end: { ...e[e.length - 1][1].end }
	};
	return e[a][1].type = "setextHeadingText", o ? (n.add(a, 0, [[
		"enter",
		s,
		t
	]]), n.add(o + 1, 0, [[
		"exit",
		e[i][1],
		t
	]]), e[i][1].end = { ...e[o][1].end }) : e[i][1] = s, n.add(e.length, 0, [[
		"exit",
		s,
		t
	]]), n.consume(e), e;
}
function ea(e, t, n) {
	let r = this, i;
	return a;
	function a(t) {
		let a = r.events.length, s;
		for (; a--;) if (r.events[a][1].type !== "lineEnding" && r.events[a][1].type !== "linePrefix" && r.events[a][1].type !== "content") {
			s = r.events[a][1].type === "paragraph";
			break;
		}
		return !r.parser.lazy[r.now().line] && (r.interrupt || s) ? (e.enter("setextHeadingLine"), i = t, o(t)) : n(t);
	}
	function o(t) {
		return e.enter("setextHeadingLineSequence"), s(t);
	}
	function s(t) {
		return t === i ? (e.consume(t), s) : (e.exit("setextHeadingLineSequence"), U(t) ? W(e, c, "lineSuffix")(t) : c(t));
	}
	function c(r) {
		return r === null || V(r) ? (e.exit("setextHeadingLine"), t(r)) : n(r);
	}
}
// node_modules/micromark/lib/initialize/flow.js
var ta = { tokenize: na };
function na(e) {
	let t = this, n = e.attempt(Or, r, e.attempt(this.parser.constructs.flowInitial, i, W(e, e.attempt(this.parser.constructs.flow, i, e.attempt(ei, i)), "linePrefix")));
	return n;
	function r(r) {
		if (r === null) e.consume(r);
		else return e.enter("lineEndingBlank"), e.consume(r), e.exit("lineEndingBlank"), t.currentConstruct = void 0, n;
	}
	function i(r) {
		if (r === null) e.consume(r);
		else return e.enter("lineEnding"), e.consume(r), e.exit("lineEnding"), t.currentConstruct = void 0, n;
	}
}
// node_modules/micromark/lib/initialize/text.js
var ra = { resolveAll: sa() }, ia = oa("string"), aa = oa("text");
function oa(e) {
	return {
		resolveAll: sa(e === "text" ? ca : void 0),
		tokenize: t
	};
	function t(t) {
		let n = this, r = this.parser.constructs[e], i = t.attempt(r, a, o);
		return a;
		function a(e) {
			return c(e) ? i(e) : o(e);
		}
		function o(e) {
			if (e === null) t.consume(e);
			else return t.enter("data"), t.consume(e), s;
		}
		function s(e) {
			return c(e) ? (t.exit("data"), i(e)) : (t.consume(e), s);
		}
		function c(e) {
			if (e === null) return !0;
			let t = r[e], i = -1;
			if (t) for (; ++i < t.length;) {
				let e = t[i];
				if (!e.previous || e.previous.call(n, n.previous)) return !0;
			}
			return !1;
		}
	}
}
function sa(e) {
	return t;
	function t(t, n) {
		let r = -1, i;
		for (; ++r <= t.length;) i === void 0 ? t[r] && t[r][1].type === "data" && (i = r, r++) : t[r] && t[r][1].type === "data" || (r !== i + 2 && (t[i][1].end = t[r - 1][1].end, t.splice(i + 2, r - i - 2), r = i + 2), i = void 0);
		return e ? e(t, n) : t;
	}
}
function ca(e, t) {
	let n = new mr(), r = 0;
	for (; ++r <= e.length;) if ((r === e.length || e[r][1].type === "lineEnding") && e[r - 1][1].type === "data") {
		let i = e[r - 1][1], a = t.sliceStream(i), o = a.length, s = -1, c = 0, l;
		for (; o--;) {
			let e = a[o];
			if (typeof e == "string") {
				for (s = e.length; e.charCodeAt(s - 1) === 32;) c++, s--;
				if (s) break;
				s = -1;
			} else if (e === -2) l = !0, c++;
			else if (e !== -1) {
				o++;
				break;
			}
		}
		if (t._contentTypeTextTrailing && r === e.length && (c = 0), c) {
			let a = {
				type: r === e.length || l || c < 2 ? "lineSuffix" : "hardBreakTrailing",
				start: {
					_bufferIndex: o ? s : i.start._bufferIndex + s,
					_index: i.start._index + o,
					line: i.end.line,
					column: i.end.column - c,
					offset: i.end.offset - c
				},
				end: { ...i.end }
			};
			i.end = { ...a.start }, i.start.offset === i.end.offset ? Object.assign(i, a) : n.add(r, 0, [[
				"enter",
				a,
				t
			], [
				"exit",
				a,
				t
			]]);
		}
		r++;
	}
	return n.consume(e), e;
}
// node_modules/micromark/lib/constructs.js
var la = /* @__PURE__ */ Re({
	attentionMarkers: () => _a,
	contentInitial: () => da,
	disable: () => va,
	document: () => ua,
	flow: () => pa,
	flowInitial: () => fa,
	insideSpan: () => ga,
	string: () => ma,
	text: () => ha
}), ua = {
	42: G,
	43: G,
	45: G,
	48: G,
	49: G,
	50: G,
	51: G,
	52: G,
	53: G,
	54: G,
	55: G,
	56: G,
	57: G,
	62: Ar
}, da = { 91: li }, fa = {
	[-2]: Hr,
	[-1]: Hr,
	32: Hr
}, pa = {
	35: hi,
	42: Ui,
	45: [Qi, Ui],
	60: bi,
	61: Qi,
	95: Ui,
	96: Br,
	126: Br
}, ma = {
	38: Ir,
	92: Pr
}, ha = {
	[-5]: Vi,
	[-4]: Vi,
	[-3]: Vi,
	33: Li,
	38: Ir,
	42: Sr,
	60: [Er, Ti],
	91: zi,
	92: [pi, Pr],
	93: Di,
	95: Sr,
	96: Kr
}, ga = { null: [Sr, ra] }, _a = { null: [42, 95] }, va = { null: [] };
// node_modules/micromark/lib/create-tokenizer.js
function ya(e, t, n) {
	let r = {
		_bufferIndex: -1,
		_index: 0,
		line: n && n.line || 1,
		column: n && n.column || 1,
		offset: n && n.offset || 0
	}, i = {}, a = [], o = [], s = [], c = {
		attempt: C(x),
		check: C(S),
		consume: v,
		enter: y,
		exit: b,
		interrupt: C(S, { interrupt: !0 })
	}, l = {
		code: null,
		containerState: {},
		defineSkip: h,
		events: [],
		now: m,
		parser: e,
		previous: null,
		sliceSerialize: f,
		sliceStream: p,
		write: d
	}, u = t.tokenize.call(l, c);
	return t.resolveAll && a.push(t), l;
	function d(e) {
		return o = Xn(o, e), g(), o[o.length - 1] === null ? (w(t, 0), l.events = xr(a, l.events, l), l.events) : [];
	}
	function f(e, t) {
		return xa(p(e), t);
	}
	function p(e) {
		return ba(o, e);
	}
	function m() {
		let { _bufferIndex: e, _index: t, line: n, column: i, offset: a } = r;
		return {
			_bufferIndex: e,
			_index: t,
			line: n,
			column: i,
			offset: a
		};
	}
	function h(e) {
		i[e.line] = e.column, E();
	}
	function g() {
		for (; r._index < o.length;) {
			let e = o[r._index];
			if (typeof e == "string") {
				let t = r._index;
				for (r._bufferIndex < 0 && (r._bufferIndex = 0); r._index === t && r._bufferIndex < e.length;) _(e.charCodeAt(r._bufferIndex));
			} else _(e);
		}
	}
	function _(e) {
		u = u(e);
	}
	function v(e) {
		V(e) ? (r.line++, r.column = 1, r.offset += e === -3 ? 2 : 1, E()) : e !== -1 && (r.column++, r.offset++), r._bufferIndex < 0 ? r._index++ : (r._bufferIndex++, r._bufferIndex === o[r._index].length && (r._bufferIndex = -1, r._index++)), l.previous = e;
	}
	function y(e, t) {
		let n = t || {};
		return n.type = e, n.start = m(), l.events.push([
			"enter",
			n,
			l
		]), s.push(n), n;
	}
	function b(e) {
		let t = s.pop();
		return t.end = m(), l.events.push([
			"exit",
			t,
			l
		]), t;
	}
	function x(e, t) {
		w(e, t.from);
	}
	function S(e, t) {
		t.restore();
	}
	function C(e, t) {
		return n;
		function n(n, r, i) {
			let a, o, s, u;
			return Array.isArray(n) ? f(n) : "tokenize" in n ? f([n]) : d(n);
			function d(e) {
				return t;
				function t(t) {
					let n = t !== null && e[t], r = t !== null && e.null;
					return f([...Array.isArray(n) ? n : n ? [n] : [], ...Array.isArray(r) ? r : r ? [r] : []])(t);
				}
			}
			function f(e) {
				return a = e, o = 0, e.length === 0 ? i : p(e[o]);
			}
			function p(e) {
				return n;
				function n(n) {
					return u = T(), s = e, e.partial || (l.currentConstruct = e), e.name && l.parser.constructs.disable.null.includes(e.name) ? h(n) : e.tokenize.call(t ? Object.assign(Object.create(l), t) : l, c, m, h)(n);
				}
			}
			function m(t) {
				return e(s, u), r;
			}
			function h(e) {
				return u.restore(), ++o < a.length ? p(a[o]) : i;
			}
		}
	}
	function w(e, t) {
		e.resolveAll && !a.includes(e) && a.push(e), e.resolve && Yn(l.events, t, l.events.length - t, e.resolve(l.events.slice(t), l)), e.resolveTo && (l.events = e.resolveTo(l.events, l));
	}
	function T() {
		let e = m(), t = l.previous, n = l.currentConstruct, i = l.events.length, a = Array.from(s);
		return {
			from: i,
			restore: o
		};
		function o() {
			r = e, l.previous = t, l.currentConstruct = n, l.events.length = i, s = a, E();
		}
	}
	function E() {
		r.line in i && r.column < 2 && (r.column = i[r.line], r.offset += i[r.line] - 1);
	}
}
function ba(e, t) {
	let n = t.start._index, r = t.start._bufferIndex, i = t.end._index, a = t.end._bufferIndex, o;
	if (n === i) o = [e[n].slice(r, a)];
	else {
		if (o = e.slice(n, i), r > -1) {
			let e = o[0];
			typeof e == "string" ? o[0] = e.slice(r) : o.shift();
		}
		a > 0 && o.push(e[i].slice(0, a));
	}
	return o;
}
function xa(e, t) {
	let n = -1, r = [], i;
	for (; ++n < e.length;) {
		let a = e[n], o;
		if (typeof a == "string") o = a;
		else switch (a) {
			case -5:
				o = "\r";
				break;
			case -4:
				o = "\n";
				break;
			case -3:
				o = "\r\n";
				break;
			case -2:
				o = t ? " " : "	";
				break;
			case -1:
				if (!t && i) continue;
				o = " ";
				break;
			default: o = String.fromCharCode(a);
		}
		i = a === -2, r.push(o);
	}
	return r.join("");
}
// node_modules/micromark/lib/parse.js
function Sa(e) {
	let t = {
		constructs: Qn([la, ...(e || {}).extensions || []]),
		content: n(fr),
		defined: [],
		document: n(gr),
		flow: n(ta),
		lazy: {},
		string: n(ia),
		text: n(aa)
	};
	return t;
	function n(e) {
		return n;
		function n(n) {
			return ya(t, e, n);
		}
	}
}
// node_modules/micromark/lib/postprocess.js
function Ca(e) {
	for (; !Qr(e););
	return e;
}
// node_modules/micromark/lib/preprocess.js
var wa = /[\0\t\n\r]/g;
function Ta() {
	let e = 1, t = "", n = !0, r;
	return i;
	function i(i, a, o) {
		i = t + (typeof i == "string" ? i.toString() : new TextDecoder(a || void 0).decode(i));
		let s = [], c = 0;
		for (t = "", n &&= (i.charCodeAt(0) === 65279 && c++, void 0); c < i.length;) {
			wa.lastIndex = c;
			let n = wa.exec(i), a = n && n.index !== void 0 ? n.index : i.length, o = i.charCodeAt(a);
			if (!n) {
				t = i.slice(c);
				break;
			}
			if (o === 10 && c === a && r) s.push(-3), r = void 0;
			else switch (r &&= (s.push(-5), void 0), c < a && (s.push(i.slice(c, a)), e += a - c), o) {
				case 0:
					s.push(65533), e++;
					break;
				case 9: {
					let t = Math.ceil(e / 4) * 4;
					for (s.push(-2); e++ < t;) s.push(-1);
					break;
				}
				case 10:
					s.push(-4), e = 1;
					break;
				default: r = !0, e = 1;
			}
			c = a + 1;
		}
		return o && (r && s.push(-5), t && s.push(t), s.push(null)), s;
	}
}
// node_modules/micromark-util-decode-string/index.js
var Ea = /\\([!-/:-@[-`{-~])|&(#(?:\d{1,7}|x[\da-f]{1,6})|[\da-z]{1,31});/gi;
function Da(e) {
	return e.replace(Ea, Oa);
}
function Oa(e, t, n) {
	if (t) return t;
	if (n.charCodeAt(0) === 35) {
		let e = n.charCodeAt(1), t = e === 120 || e === 88;
		return tr(n.slice(t ? 2 : 1), t ? 16 : 10);
	}
	return Jn(n) || e;
}
// node_modules/mdast-util-from-markdown/lib/index.js
var ka = {}.hasOwnProperty;
function Aa(e, t, n) {
	return t && typeof t == "object" && (n = t, t = void 0), ja(n)(Ca(Sa(n).document().write(Ta()(e, t, !0))));
}
function ja(e) {
	let t = {
		afterExit: [],
		beforeEnter: [],
		transforms: [],
		canContainEols: [
			"emphasis",
			"fragment",
			"heading",
			"paragraph",
			"strong"
		],
		enter: {
			autolink: o(xe),
			autolinkProtocol: E,
			autolinkEmail: E,
			atxHeading: o(N),
			blockQuote: o(me),
			characterEscape: E,
			characterReference: E,
			codeFenced: o(he),
			codeFencedFenceInfo: s,
			codeFencedFenceMeta: s,
			codeIndented: o(he, s),
			codeText: o(ge, s),
			codeTextData: E,
			data: E,
			codeFlowValue: E,
			definition: o(_e),
			definitionDestinationString: s,
			definitionLabelString: s,
			definitionTitleString: s,
			emphasis: o(ve),
			hardBreakEscape: o(P),
			hardBreakTrailing: o(P),
			htmlFlow: o(ye, s),
			htmlFlowData: E,
			htmlText: o(ye, s),
			htmlTextData: E,
			image: o(be),
			label: s,
			link: o(xe),
			listItem: o(Ce),
			listItemValue: p,
			listOrdered: o(Se, f),
			listUnordered: o(Se),
			paragraph: o(we),
			reference: se,
			referenceString: s,
			resourceDestinationString: s,
			resourceTitleString: s,
			setextHeading: o(N),
			strong: o(Te),
			thematicBreak: o(De)
		},
		exit: {
			atxHeading: l(),
			atxHeadingSequence: S,
			autolink: l(),
			autolinkEmail: pe,
			autolinkProtocol: fe,
			blockQuote: l(),
			characterEscapeValue: D,
			characterReferenceMarkerHexadecimal: le,
			characterReferenceMarkerNumeric: le,
			characterReferenceValue: ue,
			characterReference: de,
			codeFenced: l(_),
			codeFencedFence: g,
			codeFencedFenceInfo: m,
			codeFencedFenceMeta: h,
			codeFlowValue: D,
			codeIndented: l(v),
			codeText: l(te),
			codeTextData: D,
			data: D,
			definition: l(),
			definitionDestinationString: x,
			definitionLabelString: y,
			definitionTitleString: b,
			emphasis: l(),
			hardBreakEscape: l(k),
			hardBreakTrailing: l(k),
			htmlFlow: l(A),
			htmlFlowData: D,
			htmlText: l(ee),
			htmlTextData: D,
			image: l(re),
			label: ie,
			labelText: j,
			lineEnding: O,
			link: l(ne),
			listItem: l(),
			listOrdered: l(),
			listUnordered: l(),
			paragraph: l(),
			referenceString: ce,
			resourceDestinationString: ae,
			resourceTitleString: oe,
			resource: M,
			setextHeading: l(T),
			setextHeadingLineSequence: w,
			setextHeadingText: C,
			strong: l(),
			thematicBreak: l()
		}
	};
	Na(t, (e || {}).mdastExtensions || []);
	let n = {};
	return r;
	function r(e) {
		let r = {
			type: "root",
			children: [],
			position: void 0
		}, o = {
			stack: [r],
			tokenStack: [],
			config: t,
			enter: c,
			exit: u,
			buffer: s,
			resume: d,
			data: n
		}, l = [], f = [], p = -1;
		for (; ++p < e.length;) f.push(e[p]), (e[p][1].type === "listOrdered" || e[p][1].type === "listUnordered") && (e[p][0] === "enter" ? l.push(f.length - 1) : a(f, l.pop()));
		for (e = f, p = -1; ++p < e.length;) {
			let n = t[e[p][0]];
			e[p][0] === "enter" && t.beforeEnter.length > 0 && i(t.beforeEnter, {
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]), ka.call(n, e[p][1].type) && n[e[p][1].type].call({
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]), e[p][0] === "exit" && t.afterExit.length > 0 && i(t.afterExit, {
				...o,
				sliceSerialize: e[p][2].sliceSerialize
			}, e[p][1]);
		}
		if (o.tokenStack.length > 0) {
			let e = o.tokenStack[o.tokenStack.length - 1];
			(e[1] || Fa).call(o, void 0, e[0]);
		}
		for (r.position = {
			start: Ma(e.length > 0 ? e[0][1].start : {
				line: 1,
				column: 1,
				offset: 0
			}),
			end: Ma(e.length > 0 ? e[e.length - 2][1].end : {
				line: 1,
				column: 1,
				offset: 0
			})
		}, p = -1; ++p < t.transforms.length;) r = t.transforms[p](r) || r;
		return r;
	}
	function i(e, t, n) {
		let r = -1;
		for (; ++r < e.length;) e[r].call(t, n);
	}
	function a(e, t) {
		let n = e.length - 1, r = t - 1, i = -1, a = !1, o, s, c, l, u = [];
		for (; ++r <= n;) {
			let t = e[r];
			switch (t[1].type) {
				case "listUnordered":
				case "listOrdered":
				case "blockQuote":
					t[0] === "enter" ? i++ : i--, l = void 0;
					break;
				case "lineEndingBlank":
					t[0] === "enter" && (o && !l && !i && !c && (c = r), l = void 0);
					break;
				case "linePrefix":
				case "listItemValue":
				case "listItemMarker":
				case "listItemPrefix":
				case "listItemPrefixWhitespace": break;
				default: l = void 0;
			}
			if (!i && t[0] === "enter" && t[1].type === "listItemPrefix" || i === -1 && t[0] === "exit" && (t[1].type === "listUnordered" || t[1].type === "listOrdered")) {
				if (o) {
					let n = r;
					for (s = void 0; n--;) {
						let t = e[n];
						if (t[1].type === "lineEnding" || t[1].type === "lineEndingBlank") {
							if (t[0] === "exit") continue;
							s && (e[s][1].type = "lineEndingBlank", a = !0), t[1].type = "lineEnding", s = n;
						} else if (t[1].type !== "linePrefix" && t[1].type !== "blockQuotePrefix" && t[1].type !== "blockQuotePrefixWhitespace" && t[1].type !== "blockQuoteMarker" && t[1].type !== "listItemIndent") break;
					}
					c && (!s || c < s) && (o._spread = !0), o.end = Object.assign({}, s ? e[s][1].start : t[1].end), u.push({
						at: s || r,
						event: [
							"exit",
							o,
							t[2]
						]
					});
				}
				if (t[1].type === "listItemPrefix") {
					let e = {
						type: "listItem",
						_spread: !1,
						start: Object.assign({}, t[1].start),
						end: void 0
					};
					o = e, u.push({
						at: r,
						event: [
							"enter",
							e,
							t[2]
						]
					}), c = void 0, l = !0;
				}
			}
		}
		let d = e.splice(t), f = 0;
		for (r = -1; ++r < d.length;) {
			for (; f < u.length && u[f].at === t + r;) e.push(u[f++].event);
			e.push(d[r]);
		}
		e[t][1]._spread = a;
	}
	function o(e, t) {
		return n;
		function n(n) {
			c.call(this, e(n), n), t && t.call(this, n);
		}
	}
	function s() {
		this.stack.push({
			type: "fragment",
			children: []
		});
	}
	function c(e, t, n) {
		this.stack[this.stack.length - 1].children.push(e), this.stack.push(e), this.tokenStack.push([t, n || void 0]), e.position = {
			start: Ma(t.start),
			end: void 0
		};
	}
	function l(e) {
		return t;
		function t(t) {
			e && e.call(this, t), u.call(this, t);
		}
	}
	function u(e, t) {
		let n = this.stack.pop(), r = this.tokenStack.pop();
		if (!r) throw Error("Cannot close `" + e.type + "` (" + on({
			start: e.start,
			end: e.end
		}) + "): it’s not open");
		r[0].type !== e.type && (t ? t.call(this, e, r[0]) : (r[1] || Fa).call(this, e, r[0])), n.position.end = Ma(e.end);
	}
	function d() {
		return Hn(this.stack.pop());
	}
	function f() {
		this.data.expectingFirstListItemValue = !0;
	}
	function p(e) {
		if (this.data.expectingFirstListItemValue) {
			let t = this.stack[this.stack.length - 2];
			t.start = Number.parseInt(this.sliceSerialize(e), 10), this.data.expectingFirstListItemValue = void 0;
		}
	}
	function m() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.lang = e;
	}
	function h() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.meta = e;
	}
	function g() {
		this.data.flowCodeInside || (this.buffer(), this.data.flowCodeInside = !0);
	}
	function _() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e.replace(/^(\r?\n|\r)|(\r?\n|\r)$/g, ""), this.data.flowCodeInside = void 0;
	}
	function v() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e.replace(/(\r?\n|\r)$/g, "");
	}
	function y(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.label = t, n.identifier = nr(this.sliceSerialize(e)).toLowerCase();
	}
	function b() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.title = e;
	}
	function x() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.url = e;
	}
	function S(e) {
		let t = this.stack[this.stack.length - 1];
		t.depth ||= this.sliceSerialize(e).length;
	}
	function C() {
		this.data.setextHeadingSlurpLineEnding = !0;
	}
	function w(e) {
		let t = this.stack[this.stack.length - 1];
		t.depth = this.sliceSerialize(e).codePointAt(0) === 61 ? 1 : 2;
	}
	function T() {
		this.data.setextHeadingSlurpLineEnding = void 0;
	}
	function E(e) {
		let t = this.stack[this.stack.length - 1].children, n = t[t.length - 1];
		n && n.type === "text" || (n = Ee(), n.position = {
			start: Ma(e.start),
			end: void 0
		}, t.push(n)), this.stack.push(n);
	}
	function D(e) {
		let t = this.stack.pop();
		t.value += this.sliceSerialize(e), t.position.end = Ma(e.end);
	}
	function O(e) {
		let n = this.stack[this.stack.length - 1];
		if (this.data.atHardBreak) {
			let t = n.children[n.children.length - 1];
			t.position.end = Ma(e.end), this.data.atHardBreak = void 0;
		} else !this.data.setextHeadingSlurpLineEnding && t.canContainEols.includes(n.type) && (E.call(this, e), D.call(this, e));
	}
	function k() {
		this.data.atHardBreak = !0;
	}
	function A() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function ee() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function te() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.value = e;
	}
	function ne() {
		let e = this.stack[this.stack.length - 1];
		if (this.data.inReference) {
			let t = this.data.referenceType || "shortcut";
			e.type += "Reference", e.referenceType = t, delete e.url, delete e.title;
		} else delete e.identifier, delete e.label;
		this.data.referenceType = void 0;
	}
	function re() {
		let e = this.stack[this.stack.length - 1];
		if (this.data.inReference) {
			let t = this.data.referenceType || "shortcut";
			e.type += "Reference", e.referenceType = t, delete e.url, delete e.title;
		} else delete e.identifier, delete e.label;
		this.data.referenceType = void 0;
	}
	function j(e) {
		let t = this.sliceSerialize(e), n = this.stack[this.stack.length - 2];
		n.label = Da(t), n.identifier = nr(t).toLowerCase();
	}
	function ie() {
		let e = this.stack[this.stack.length - 1], t = this.resume(), n = this.stack[this.stack.length - 1];
		this.data.inReference = !0, n.type === "link" ? n.children = e.children : n.alt = t;
	}
	function ae() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.url = e;
	}
	function oe() {
		let e = this.resume(), t = this.stack[this.stack.length - 1];
		t.title = e;
	}
	function M() {
		this.data.inReference = void 0;
	}
	function se() {
		this.data.referenceType = "collapsed";
	}
	function ce(e) {
		let t = this.resume(), n = this.stack[this.stack.length - 1];
		n.label = t, n.identifier = nr(this.sliceSerialize(e)).toLowerCase(), this.data.referenceType = "full";
	}
	function le(e) {
		this.data.characterReferenceType = e.type;
	}
	function ue(e) {
		let t = this.sliceSerialize(e), n = this.data.characterReferenceType, r;
		n ? (r = tr(t, n === "characterReferenceMarkerNumeric" ? 10 : 16), this.data.characterReferenceType = void 0) : r = Jn(t);
		let i = this.stack[this.stack.length - 1];
		i.value += r;
	}
	function de(e) {
		let t = this.stack.pop();
		t.position.end = Ma(e.end);
	}
	function fe(e) {
		D.call(this, e);
		let t = this.stack[this.stack.length - 1];
		t.url = this.sliceSerialize(e);
	}
	function pe(e) {
		D.call(this, e);
		let t = this.stack[this.stack.length - 1];
		t.url = "mailto:" + this.sliceSerialize(e);
	}
	function me() {
		return {
			type: "blockquote",
			children: [],
			position: void 0
		};
	}
	function he() {
		return {
			type: "code",
			lang: null,
			meta: null,
			value: "",
			position: void 0
		};
	}
	function ge() {
		return {
			type: "inlineCode",
			value: "",
			position: void 0
		};
	}
	function _e() {
		return {
			type: "definition",
			identifier: "",
			label: null,
			title: null,
			url: "",
			position: void 0
		};
	}
	function ve() {
		return {
			type: "emphasis",
			children: [],
			position: void 0
		};
	}
	function N() {
		return {
			type: "heading",
			depth: 0,
			children: [],
			position: void 0
		};
	}
	function P() {
		return {
			type: "break",
			position: void 0
		};
	}
	function ye() {
		return {
			type: "html",
			value: "",
			position: void 0
		};
	}
	function be() {
		return {
			type: "image",
			title: null,
			url: "",
			alt: null,
			position: void 0
		};
	}
	function xe() {
		return {
			type: "link",
			title: null,
			url: "",
			children: [],
			position: void 0
		};
	}
	function Se(e) {
		return {
			type: "list",
			ordered: e.type === "listOrdered",
			start: null,
			spread: e._spread,
			children: [],
			position: void 0
		};
	}
	function Ce(e) {
		return {
			type: "listItem",
			spread: e._spread,
			checked: null,
			children: [],
			position: void 0
		};
	}
	function we() {
		return {
			type: "paragraph",
			children: [],
			position: void 0
		};
	}
	function Te() {
		return {
			type: "strong",
			children: [],
			position: void 0
		};
	}
	function Ee() {
		return {
			type: "text",
			value: "",
			position: void 0
		};
	}
	function De() {
		return {
			type: "thematicBreak",
			position: void 0
		};
	}
}
function Ma(e) {
	return {
		line: e.line,
		column: e.column,
		offset: e.offset
	};
}
function Na(e, t) {
	let n = -1;
	for (; ++n < t.length;) {
		let r = t[n];
		Array.isArray(r) ? Na(e, r) : Pa(e, r);
	}
}
function Pa(e, t) {
	let n;
	for (n in t) if (ka.call(t, n)) switch (n) {
		case "canContainEols": {
			let r = t[n];
			r && e[n].push(...r);
			break;
		}
		case "transforms": {
			let r = t[n];
			r && e[n].push(...r);
			break;
		}
		case "afterExit":
		case "beforeEnter": {
			let r = t[n];
			r && e[n].push(r);
			break;
		}
		case "enter":
		case "exit": {
			let r = t[n];
			r && Object.assign(e[n], r);
			break;
		}
	}
}
function Fa(e, t) {
	throw Error(e ? "Cannot close `" + e.type + "` (" + on({
		start: e.start,
		end: e.end
	}) + "): a different token (`" + t.type + "`, " + on({
		start: t.start,
		end: t.end
	}) + ") is open" : "Cannot close document, a token (`" + t.type + "`, " + on({
		start: t.start,
		end: t.end
	}) + ") is still open");
}
// node_modules/remark-parse/lib/index.js
function Ia(e) {
	let t = this;
	t.parser = n;
	function n(n) {
		return Aa(n, {
			...t.data("settings"),
			...e,
			extensions: t.data("micromarkExtensions") || [],
			mdastExtensions: t.data("fromMarkdownExtensions") || []
		});
	}
}
// node_modules/ccount/index.js
function La(e, t) {
	let n = String(e);
	if (typeof t != "string") throw TypeError("Expected character");
	let r = 0, i = n.indexOf(t);
	for (; i !== -1;) r++, i = n.indexOf(t, i + t.length);
	return r;
}
// node_modules/escape-string-regexp/index.js
function Ra(e) {
	if (typeof e != "string") throw TypeError("Expected a string");
	return e.replace(/[|\\{}()[\]^$+*?.]/g, "\\$&").replace(/-/g, "\\x2d");
}
// node_modules/unist-util-is/lib/index.js
var za = (function(e) {
	if (e == null) return Wa;
	if (typeof e == "function") return Ua(e);
	if (typeof e == "object") return Array.isArray(e) ? Ba(e) : Va(e);
	if (typeof e == "string") return Ha(e);
	throw Error("Expected function, string, or object as test");
});
function Ba(e) {
	let t = [], n = -1;
	for (; ++n < e.length;) t[n] = za(e[n]);
	return Ua(r);
	function r(...e) {
		let n = -1;
		for (; ++n < t.length;) if (t[n].apply(this, e)) return !0;
		return !1;
	}
}
function Va(e) {
	let t = e;
	return Ua(n);
	function n(n) {
		let r = n, i;
		for (i in e) if (r[i] !== t[i]) return !1;
		return !0;
	}
}
function Ha(e) {
	return Ua(t);
	function t(t) {
		return t && t.type === e;
	}
}
function Ua(e) {
	return t;
	function t(t, n, r) {
		return !!(Ga(t) && e.call(this, t, typeof n == "number" ? n : void 0, r || void 0));
	}
}
function Wa() {
	return !0;
}
function Ga(e) {
	return typeof e == "object" && !!e && "type" in e;
}
// node_modules/unist-util-visit-parents/lib/color.js
function Ka(e) {
	return e;
}
// node_modules/unist-util-visit-parents/lib/index.js
var qa = [];
function Ja(e, t, n, r) {
	let i;
	typeof t == "function" && typeof n != "function" ? (r = n, n = t) : i = t;
	let a = za(i), o = r ? -1 : 1;
	s(e, void 0, [])();
	function s(e, i, c) {
		let l = e && typeof e == "object" ? e : {};
		if (typeof l.type == "string") {
			let t = typeof l.tagName == "string" ? l.tagName : typeof l.name == "string" ? l.name : void 0;
			Object.defineProperty(u, "name", { value: "node (" + Ka(e.type + (t ? "<" + t + ">" : "")) + ")" });
		}
		return u;
		function u() {
			let l = qa, u, d, f;
			if ((!t || a(e, i, c[c.length - 1] || void 0)) && (l = Ya(n(e, c)), l[0] === !1)) return l;
			if ("children" in e && e.children) {
				let t = e;
				if (t.children && l[0] !== "skip") for (d = (r ? t.children.length : -1) + o, f = c.concat(t); d > -1 && d < t.children.length;) {
					let e = t.children[d];
					if (u = s(e, d, f)(), u[0] === !1) return u;
					d = typeof u[1] == "number" ? u[1] : d + o;
				}
			}
			return l;
		}
	}
}
function Ya(e) {
	return Array.isArray(e) ? e : typeof e == "number" ? [!0, e] : e == null ? qa : [e];
}
// node_modules/mdast-util-find-and-replace/lib/index.js
function Xa(e, t, n) {
	let r = za((n || {}).ignore || []), i = Za(t), a = -1;
	for (; ++a < i.length;) Ja(e, "text", o);
	function o(e, t) {
		let n = -1, i;
		for (; ++n < t.length;) {
			let e = t[n], a = i ? i.children : void 0;
			if (r(e, a ? a.indexOf(e) : void 0, i)) return;
			i = e;
		}
		if (i) return s(e, t);
	}
	function s(e, t) {
		let n = t[t.length - 1], r = i[a][0], o = i[a][1], s = 0, c = n.children.indexOf(e), l = !1, u = [];
		r.lastIndex = 0;
		let d = r.exec(e.value);
		for (; d;) {
			let n = d.index, i = {
				index: d.index,
				input: d.input,
				stack: [...t, e]
			}, a = o(...d, i);
			if (typeof a == "string" && (a = a.length > 0 ? {
				type: "text",
				value: a
			} : void 0), a === !1) r.lastIndex = n + 1;
			else {
				if (s !== n && f({
					type: "text",
					value: e.value.slice(s, n)
				}), Array.isArray(a)) for (let e of a) f(e);
				else a && f(a);
				s = n + d[0].length, l = !0;
			}
			if (!r.global) break;
			d = r.exec(e.value);
		}
		return l ? (s < e.value.length && f({
			type: "text",
			value: e.value.slice(s)
		}), n.children.splice(c, 1, ...u)) : u = [e], c + u.length;
		function f(e) {
			let t = u[u.length - 1];
			t && t.type === "text" && e.type === "text" ? t.value += e.value : u.push(e);
		}
	}
}
function Za(e) {
	if (!Array.isArray(e)) throw TypeError("Expected find and replace tuple or list of tuples");
	let t = [], n = !e[0] || Array.isArray(e[0]) ? e : [e], r = -1;
	for (; ++r < n.length;) {
		let e = n[r];
		t.push([Qa(e[0]), $a(e[1])]);
	}
	return t;
}
function Qa(e) {
	return typeof e == "string" ? new RegExp(Ra(e), "g") : e;
}
function $a(e) {
	return typeof e == "function" ? e : function() {
		return e;
	};
}
// node_modules/mdast-util-gfm-autolink-literal/lib/index.js
var eo = "phrasing", to = [
	"autolink",
	"link",
	"image",
	"label"
];
function no() {
	return {
		transforms: [uo],
		enter: {
			literalAutolink: io,
			literalAutolinkEmail: ao,
			literalAutolinkHttp: ao,
			literalAutolinkWww: ao
		},
		exit: {
			literalAutolink: lo,
			literalAutolinkEmail: co,
			literalAutolinkHttp: oo,
			literalAutolinkWww: so
		}
	};
}
function ro() {
	return { unsafe: [
		{
			character: "@",
			before: "[+\\-.\\w]",
			after: "[\\-.\\w]",
			inConstruct: eo,
			notInConstruct: to
		},
		{
			character: ".",
			before: "[Ww]",
			after: "[\\-.\\w]",
			inConstruct: eo,
			notInConstruct: to
		},
		{
			character: ":",
			before: "[ps]",
			after: "\\/",
			inConstruct: eo,
			notInConstruct: to
		}
	] };
}
function io(e) {
	this.enter({
		type: "link",
		title: null,
		url: "",
		children: []
	}, e);
}
function ao(e) {
	this.config.enter.autolinkProtocol.call(this, e);
}
function oo(e) {
	this.config.exit.autolinkProtocol.call(this, e);
}
function so(e) {
	this.config.exit.data.call(this, e);
	let t = this.stack[this.stack.length - 1];
	t.type, t.url = "http://" + this.sliceSerialize(e);
}
function co(e) {
	this.config.exit.autolinkEmail.call(this, e);
}
function lo(e) {
	this.exit(e);
}
function uo(e) {
	Xa(e, [[/(https?:\/\/|www(?=\.))([-.\w]+)([^ \t\r\n]*)/gi, fo], [/(?<=^|\s|\p{P}|\p{S})([-.\w+]+)@([-\w]+(?:\.[-\w]+)+)/gu, po]], { ignore: ["link", "linkReference"] });
}
function fo(e, t, n, r, i) {
	let a = "";
	if (!go(i) || (/^w/i.test(t) && (n = t + n, t = "", a = "http://"), !mo(n))) return !1;
	let o = ho(n + r);
	if (!o[0]) return !1;
	let s = {
		type: "link",
		title: null,
		url: a + t + o[0],
		children: [{
			type: "text",
			value: t + o[0]
		}]
	};
	return o[1] ? [s, {
		type: "text",
		value: o[1]
	}] : s;
}
function po(e, t, n, r) {
	return !go(r, !0) || /[-\d_]$/.test(n) ? !1 : {
		type: "link",
		title: null,
		url: "mailto:" + t + "@" + n,
		children: [{
			type: "text",
			value: t + "@" + n
		}]
	};
}
function mo(e) {
	let t = e.split(".");
	return !(t.length < 2 || t[t.length - 1] && (/_/.test(t[t.length - 1]) || !/[a-zA-Z\d]/.test(t[t.length - 1])) || t[t.length - 2] && (/_/.test(t[t.length - 2]) || !/[a-zA-Z\d]/.test(t[t.length - 2])));
}
function ho(e) {
	let t = /[!"&'),.:;<>?\]}]+$/.exec(e);
	if (!t) return [e, void 0];
	e = e.slice(0, t.index);
	let n = t[0], r = n.indexOf(")"), i = La(e, "("), a = La(e, ")");
	for (; r !== -1 && i > a;) e += n.slice(0, r + 1), n = n.slice(r + 1), r = n.indexOf(")"), a++;
	return [e, n];
}
function go(e, t) {
	let n = e.input.charCodeAt(e.index - 1);
	return (e.index === 0 || lr(n) || cr(n)) && (!t || n !== 47);
}
// node_modules/mdast-util-gfm-footnote/lib/index.js
Eo.peek = To;
function _o() {
	this.buffer();
}
function vo(e) {
	this.enter({
		type: "footnoteReference",
		identifier: "",
		label: ""
	}, e);
}
function yo() {
	this.buffer();
}
function bo(e) {
	this.enter({
		type: "footnoteDefinition",
		identifier: "",
		label: "",
		children: []
	}, e);
}
function xo(e) {
	let t = this.resume(), n = this.stack[this.stack.length - 1];
	n.type, n.identifier = nr(this.sliceSerialize(e)).toLowerCase(), n.label = t;
}
function So(e) {
	this.exit(e);
}
function Co(e) {
	let t = this.resume(), n = this.stack[this.stack.length - 1];
	n.type, n.identifier = nr(this.sliceSerialize(e)).toLowerCase(), n.label = t;
}
function wo(e) {
	this.exit(e);
}
function To() {
	return "[";
}
function Eo(e, t, n, r) {
	let i = n.createTracker(r), a = i.move("[^"), o = n.enter("footnoteReference"), s = n.enter("reference");
	return a += i.move(n.safe(n.associationId(e), {
		after: "]",
		before: a
	})), s(), o(), a += i.move("]"), a;
}
function Do() {
	return {
		enter: {
			gfmFootnoteCallString: _o,
			gfmFootnoteCall: vo,
			gfmFootnoteDefinitionLabelString: yo,
			gfmFootnoteDefinition: bo
		},
		exit: {
			gfmFootnoteCallString: xo,
			gfmFootnoteCall: So,
			gfmFootnoteDefinitionLabelString: Co,
			gfmFootnoteDefinition: wo
		}
	};
}
function Oo(e) {
	let t = !1;
	return e && e.firstLineBlank && (t = !0), {
		handlers: {
			footnoteDefinition: n,
			footnoteReference: Eo
		},
		unsafe: [{
			character: "[",
			inConstruct: [
				"label",
				"phrasing",
				"reference"
			]
		}]
	};
	function n(e, n, r, i) {
		let a = r.createTracker(i), o = a.move("[^"), s = r.enter("footnoteDefinition"), c = r.enter("label");
		return o += a.move(r.safe(r.associationId(e), {
			before: o,
			after: "]"
		})), c(), o += a.move("]:"), e.children && e.children.length > 0 && (a.shift(4), o += a.move((t ? "\n" : " ") + r.indentLines(r.containerFlow(e, a.current()), t ? Ao : ko))), s(), o;
	}
}
function ko(e, t, n) {
	return t === 0 ? e : Ao(e, t, n);
}
function Ao(e, t, n) {
	return (n ? "" : "    ") + e;
}
// node_modules/mdast-util-gfm-strikethrough/lib/index.js
var jo = [
	"autolink",
	"destinationLiteral",
	"destinationRaw",
	"reference",
	"titleQuote",
	"titleApostrophe"
];
Io.attention = Lo, Io.peek = Ro;
function Mo() {
	return {
		canContainEols: ["delete"],
		enter: { strikethrough: Po },
		exit: { strikethrough: Fo }
	};
}
function No() {
	return {
		handlers: { delete: Io },
		unsafe: [{
			character: "~",
			inConstruct: "phrasing",
			notInConstruct: jo
		}]
	};
}
function Po(e) {
	this.enter({
		type: "delete",
		children: [],
		position: void 0
	}, e);
}
function Fo(e) {
	this.exit(e);
}
function Io(e, t, n, r) {
	let i = n.createTracker(r), a = n.stack.includes("strikethrough") ? "~" : "~~", o = n.enter("strikethrough"), s = i.move(a);
	return s += n.containerPhrasing(e, {
		...i.current(),
		before: s,
		after: "~"
	}), s += i.move(a), o(), s;
}
function Lo() {
	return {
		construct: "strikethrough",
		markers: ["~"],
		sizes: [2, 1]
	};
}
function Ro() {
	return "~";
}
// node_modules/markdown-table/index.js
function zo(e) {
	return e.length;
}
function Bo(e, t) {
	let n = t || {}, r = (n.align || []).concat(), i = n.stringLength || zo, a = [], o = [], s = [], c = [], l = 0, u = -1;
	for (; ++u < e.length;) {
		let t = [], r = [], a = -1;
		for (e[u].length > l && (l = e[u].length); ++a < e[u].length;) {
			let o = Vo(e[u][a]);
			if (n.alignDelimiters !== !1) {
				let e = i(o);
				r[a] = e, (c[a] === void 0 || e > c[a]) && (c[a] = e);
			}
			t.push(o);
		}
		o[u] = t, s[u] = r;
	}
	let d = -1;
	if (typeof r == "object" && "length" in r) for (; ++d < l;) a[d] = Ho(r[d]);
	else {
		let e = Ho(r);
		for (; ++d < l;) a[d] = e;
	}
	d = -1;
	let f = [], p = [];
	for (; ++d < l;) {
		let e = a[d], t = "", r = "";
		e === 99 ? (t = ":", r = ":") : e === 108 ? t = ":" : e === 114 && (r = ":");
		let i = n.alignDelimiters === !1 ? 1 : Math.max(1, c[d] - t.length - r.length), o = t + "-".repeat(i) + r;
		n.alignDelimiters !== !1 && (i = t.length + i + r.length, i > c[d] && (c[d] = i), p[d] = i), f[d] = o;
	}
	o.splice(1, 0, f), s.splice(1, 0, p), u = -1;
	let m = [];
	for (; ++u < o.length;) {
		let e = o[u], t = s[u];
		d = -1;
		let r = [];
		for (; ++d < l;) {
			let i = e[d] || "", o = "", s = "";
			if (n.alignDelimiters !== !1) {
				let e = c[d] - (t[d] || 0), n = a[d];
				n === 114 ? o = " ".repeat(e) : n === 99 ? e % 2 ? (o = " ".repeat(e / 2 + .5), s = " ".repeat(e / 2 - .5)) : (o = " ".repeat(e / 2), s = o) : s = " ".repeat(e);
			}
			n.delimiterStart !== !1 && !d && r.push("|"), n.padding === !1 || n.alignDelimiters === !1 && i === "" || n.delimiterStart === !1 && !d || r.push(" "), n.alignDelimiters !== !1 && r.push(o), r.push(i), n.alignDelimiters !== !1 && r.push(s), n.padding !== !1 && r.push(" "), (n.delimiterEnd !== !1 || d !== l - 1) && r.push("|");
		}
		m.push(n.delimiterEnd === !1 ? r.join("").replace(/ +$/, "") : r.join(""));
	}
	return m.join("\n");
}
function Vo(e) {
	return e == null ? "" : String(e);
}
function Ho(e) {
	let t = typeof e == "string" ? e.codePointAt(0) : 0;
	return t === 67 || t === 99 ? 99 : t === 76 || t === 108 ? 108 : t === 82 || t === 114 ? 114 : 0;
}
// node_modules/mdast-util-phrasing/lib/index.js
var Uo = za([
	"break",
	"delete",
	"emphasis",
	"footnote",
	"footnoteReference",
	"image",
	"imageReference",
	"inlineCode",
	"inlineMath",
	"link",
	"linkReference",
	"mdxJsxTextElement",
	"mdxTextExpression",
	"strong",
	"text",
	"textDirective"
]);
// node_modules/mdast-util-to-markdown/lib/handle/blockquote.js
function Wo(e, t, n, r) {
	let i = n.enter("blockquote"), a = n.createTracker(r);
	a.move("> "), a.shift(2);
	let o = n.indentLines(n.containerFlow(e, a.current()), Go);
	return i(), o;
}
function Go(e, t, n) {
	return ">" + (n ? "" : " ") + e;
}
// node_modules/mdast-util-to-markdown/lib/util/pattern-in-scope.js
function Ko(e, t) {
	return qo(e, t.inConstruct, !0) && !qo(e, t.notInConstruct, !1);
}
function qo(e, t, n) {
	if (typeof t == "string" && (t = [t]), !t || t.length === 0) return n;
	let r = -1;
	for (; ++r < t.length;) if (e.includes(t[r])) return !0;
	return !1;
}
// node_modules/mdast-util-to-markdown/lib/handle/break.js
function Jo(e, t, n, r) {
	let i = -1;
	for (; ++i < n.unsafe.length;) {
		let e = n.unsafe[i];
		if (e.character === "\n" && !e.before && !e.after && Ko(n.stack, e)) return /[\t ]/.test(r.before) ? "" : " ";
	}
	return "\\\n";
}
// node_modules/longest-streak/index.js
function Yo(e, t) {
	let n = String(e), r = n.indexOf(t), i = r, a = 0, o = 0;
	if (typeof t != "string") throw TypeError("Expected substring");
	for (; r !== -1;) r === i ? ++a > o && (o = a) : a = 1, i = r + t.length, r = n.indexOf(t, i);
	return o;
}
// node_modules/mdast-util-to-markdown/lib/util/format-code-as-indented.js
function Xo(e, t) {
	return !(t.options.fences !== !1 || !e.value || e.lang || !/[^\n\r ]/.test(e.value) || /^[\t ]*(?:[\n\r]|$)|(?:^|[\n\r])[\t ]*$/.test(e.value));
}
// node_modules/mdast-util-to-markdown/lib/util/check-fence.js
function Zo(e) {
	let t = e.options.fence || "`";
	if (t !== "`" && t !== "~") throw Error("Cannot serialize code with `" + t + "` for `options.fence`, expected `` ` `` or `~`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/code.js
function Qo(e, t, n, r) {
	let i = Zo(n), a = e.value || "";
	if (Xo(e, n)) {
		let e = n.enter("codeIndented"), t = n.indentLines(a, $o);
		return e(), t;
	}
	let o = n.createTracker(r), s = i.repeat(Math.max(Yo(a, i) + 1, 3)), c = n.enter("codeFenced"), l = i === "`" ? "GraveAccent" : "Tilde", u = o.move(s);
	if (e.lang) {
		let t = n.enter(`codeFencedLang${l}`);
		u += o.move(n.safe(e.lang, {
			before: u,
			after: " ",
			encode: ["`"],
			...o.current()
		})), t();
	}
	if (e.lang && e.meta) {
		let t = n.enter(`codeFencedMeta${l}`);
		u += o.move(" "), u += o.move(n.safe(e.meta, {
			before: u,
			after: "\n",
			encode: ["`"],
			...o.current()
		})), t();
	}
	return u += o.move("\n"), a && (u += o.move(a + "\n")), u += o.move(s), c(), u;
}
function $o(e, t, n) {
	return (n ? "" : "    ") + e;
}
// node_modules/mdast-util-to-markdown/lib/util/check-quote.js
function es(e) {
	let t = e.options.quote || "\"";
	if (t !== "\"" && t !== "'") throw Error("Cannot serialize title with `" + t + "` for `options.quote`, expected `\"`, or `'`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/definition.js
function ts(e, t, n, r) {
	let i = es(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.enter("definition"), s = n.enter("label"), c = n.createTracker(r), l = c.move("[");
	return l += c.move(n.safe(n.associationId(e), {
		before: l,
		after: "]",
		...c.current()
	})), l += c.move("]: "), s(), !e.url || /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), l += c.move("<"), l += c.move(n.safe(e.url, {
		before: l,
		after: ">",
		...c.current()
	})), l += c.move(">")) : (s = n.enter("destinationRaw"), l += c.move(n.safe(e.url, {
		before: l,
		after: e.title ? " " : "\n",
		...c.current()
	}))), s(), e.title && (s = n.enter(`title${a}`), l += c.move(" " + i), l += c.move(n.safe(e.title, {
		before: l,
		after: i,
		...c.current()
	})), l += c.move(i), s()), o(), l;
}
// node_modules/mdast-util-to-markdown/lib/util/check-emphasis.js
function ns(e) {
	let t = e.options.emphasis || "*";
	if (t !== "*" && t !== "_") throw Error("Cannot serialize emphasis with `" + t + "` for `options.emphasis`, expected `*`, or `_`");
	return t;
}
rs.attention = is, rs.peek = as;
function rs(e, t, n, r) {
	let i = n.enter("phrasing"), a = n.containerPhrasing({
		type: "root",
		children: [e]
	}, r);
	return i(), a;
}
function is(e, t) {
	return {
		construct: "emphasis",
		markers: ns(t) === "*" ? ["*", "_"] : ["_", "*"],
		sizes: [1]
	};
}
function as(e, t, n) {
	return n.options.emphasis || "*";
}
// node_modules/mdast-util-to-markdown/lib/util/encode-character-reference.js
function os(e) {
	return "&#x" + e.toString(16).toUpperCase() + ";";
}
// node_modules/unist-util-visit/lib/index.js
function ss(e, t, n, r) {
	let i, a, o;
	typeof t == "function" && typeof n != "function" ? (a = void 0, o = t, i = n) : (a = t, o = n, i = r), Ja(e, a, s, i);
	function s(e, t) {
		let n = t[t.length - 1], r = n ? n.children.indexOf(e) : void 0;
		return o(e, r, n);
	}
}
// node_modules/mdast-util-to-markdown/lib/util/format-heading-as-setext.js
function cs(e, t) {
	let n = !1;
	return ss(e, function(e) {
		if ("value" in e && /\r?\n|\r/.test(e.value) || e.type === "break") return n = !0, !1;
	}), !!((!e.depth || e.depth < 3) && Hn(e) && (t.options.setext || n));
}
// node_modules/mdast-util-to-markdown/lib/handle/heading.js
function ls(e, t, n, r) {
	let i = Math.max(Math.min(6, e.depth || 1), 1), a = n.createTracker(r);
	if (cs(e, n)) {
		let t = n.enter("headingSetext"), r = n.enter("phrasing"), o = n.containerPhrasing(e, {
			...a.current(),
			before: "\n",
			after: "\n"
		});
		return r(), t(), o + "\n" + (i === 1 ? "=" : "-").repeat(o.length - (Math.max(o.lastIndexOf("\r"), o.lastIndexOf("\n")) + 1));
	}
	let o = "#".repeat(i), s = n.enter("headingAtx"), c = n.enter("phrasing");
	a.move(o + " ");
	let l = n.containerPhrasing(e, {
		before: "# ",
		after: "\n",
		...a.current()
	}), u = l.charCodeAt(0);
	return (u === 9 || u === 32) && (l = os(u) + l.slice(1)), l = l ? o + " " + l : o, n.options.closeAtx && (l += " " + o), c(), s(), l;
}
// node_modules/mdast-util-to-markdown/lib/handle/html.js
us.peek = ds;
function us(e) {
	return e.value || "";
}
function ds() {
	return "<";
}
// node_modules/mdast-util-to-markdown/lib/handle/image.js
fs.peek = ps;
function fs(e, t, n, r) {
	let i = es(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.enter("image"), s = n.enter("label"), c = n.createTracker(r), l = c.move("![");
	return l += c.move(n.safe(e.alt, {
		before: l,
		after: "]",
		...c.current()
	})), l += c.move("]("), s(), !e.url && e.title || /[\0- \u007F]/.test(e.url) ? (s = n.enter("destinationLiteral"), l += c.move("<"), l += c.move(n.safe(e.url, {
		before: l,
		after: ">",
		...c.current()
	})), l += c.move(">")) : (s = n.enter("destinationRaw"), l += c.move(n.safe(e.url, {
		before: l,
		after: e.title ? " " : ")",
		...c.current()
	}))), s(), e.title && (s = n.enter(`title${a}`), l += c.move(" " + i), l += c.move(n.safe(e.title, {
		before: l,
		after: i,
		...c.current()
	})), l += c.move(i), s()), l += c.move(")"), o(), l;
}
function ps() {
	return "!";
}
// node_modules/mdast-util-to-markdown/lib/handle/image-reference.js
ms.peek = hs;
function ms(e, t, n, r) {
	let i = e.referenceType, a = n.enter("imageReference"), o = n.enter("label"), s = n.createTracker(r), c = s.move("!["), l = n.safe(e.alt, {
		before: c,
		after: "]",
		...s.current()
	});
	c += s.move(l + "]["), o();
	let u = n.stack;
	n.stack = u.filter(function(e) {
		return e !== "phrasing";
	}), o = n.enter("reference");
	let d = n.safe(n.associationId(e), {
		before: c,
		after: "]",
		...s.current()
	});
	return o(), n.stack = u, a(), i === "full" || !l || l !== d ? c += s.move(d + "]") : i === "shortcut" ? c = c.slice(0, -1) : c += s.move("]"), c;
}
function hs() {
	return "!";
}
// node_modules/mdast-util-to-markdown/lib/handle/inline-code.js
gs.peek = _s;
function gs(e, t, n) {
	let r = e.value || "", i = "`", a = -1;
	for (; RegExp("(^|[^`])" + i + "([^`]|$)").test(r);) i += "`";
	for (/[^\n\r ]/.test(r) && (/^[\n\r ]/.test(r) && /[\n\r ]$/.test(r) || /^`|`$/.test(r)) && (r = " " + r + " "); ++a < n.unsafe.length;) {
		let e = n.unsafe[a], t = n.compilePattern(e);
		if (!e.atBreak) continue;
		let i;
		for (; i = t.exec(r);) {
			let e = i.index;
			r.charCodeAt(e) === 10 && r.charCodeAt(e - 1) === 13 && e--, r = r.slice(0, e) + " " + r.slice(i.index + 1);
		}
	}
	return i + r + i;
}
function _s() {
	return "`";
}
// node_modules/mdast-util-to-markdown/lib/util/format-link-as-autolink.js
function vs(e, t) {
	let n = Hn(e);
	return !(t.options.resourceLink || !e.url || e.title || !e.children || e.children.length !== 1 || e.children[0].type !== "text" || n !== e.url && "mailto:" + n !== e.url || !/^[a-z][+\-.a-z]+:/i.test(e.url) || /[\0- <>\u007F]/.test(e.url));
}
// node_modules/mdast-util-to-markdown/lib/handle/link.js
ys.peek = bs;
function ys(e, t, n, r) {
	let i = es(n), a = i === "\"" ? "Quote" : "Apostrophe", o = n.createTracker(r);
	if (vs(e, n)) {
		let t = n.stack;
		n.stack = t.filter(function(e) {
			return e !== "phrasing";
		});
		let r = n.enter("autolink"), i = o.move("<");
		return i += o.move(n.containerPhrasing(e, {
			before: i,
			after: ">",
			...o.current()
		})), i += o.move(">"), r(), n.stack = t, i;
	}
	let s = n.enter("link"), c = n.enter("label"), l = o.move("[");
	return l += o.move(n.containerPhrasing(e, {
		before: l,
		after: "](",
		...o.current()
	})), l += o.move("]("), c(), !e.url && e.title || /[\0- \u007F]/.test(e.url) ? (c = n.enter("destinationLiteral"), l += o.move("<"), l += o.move(n.safe(e.url, {
		before: l,
		after: ">",
		...o.current()
	})), l += o.move(">")) : (c = n.enter("destinationRaw"), l += o.move(n.safe(e.url, {
		before: l,
		after: e.title ? " " : ")",
		...o.current()
	}))), c(), e.title && (c = n.enter(`title${a}`), l += o.move(" " + i), l += o.move(n.safe(e.title, {
		before: l,
		after: i,
		...o.current()
	})), l += o.move(i), c()), l += o.move(")"), s(), l;
}
function bs(e, t, n) {
	return vs(e, n) ? "<" : "[";
}
// node_modules/mdast-util-to-markdown/lib/handle/link-reference.js
xs.peek = Ss;
function xs(e, t, n, r) {
	let i = e.referenceType, a = n.enter("linkReference"), o = n.enter("label"), s = n.createTracker(r), c = s.move("["), l = n.containerPhrasing(e, {
		before: c,
		after: "]",
		...s.current()
	});
	c += s.move(l + "]["), o();
	let u = n.stack;
	n.stack = u.filter(function(e) {
		return e !== "phrasing";
	}), o = n.enter("reference");
	let d = n.safe(n.associationId(e), {
		before: c,
		after: "]",
		...s.current()
	});
	return o(), n.stack = u, a(), i === "full" || !l || l !== d ? c += s.move(d + "]") : i === "shortcut" ? c = c.slice(0, -1) : c += s.move("]"), c;
}
function Ss() {
	return "[";
}
// node_modules/mdast-util-to-markdown/lib/util/check-bullet.js
function Cs(e) {
	let t = e.options.bullet || "*";
	if (t !== "*" && t !== "+" && t !== "-") throw Error("Cannot serialize items with `" + t + "` for `options.bullet`, expected `*`, `+`, or `-`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/util/check-bullet-other.js
function ws(e) {
	let t = Cs(e), n = e.options.bulletOther;
	if (!n) return t === "*" ? "-" : "*";
	if (n !== "*" && n !== "+" && n !== "-") throw Error("Cannot serialize items with `" + n + "` for `options.bulletOther`, expected `*`, `+`, or `-`");
	if (n === t) throw Error("Expected `bullet` (`" + t + "`) and `bulletOther` (`" + n + "`) to be different");
	return n;
}
// node_modules/mdast-util-to-markdown/lib/util/check-bullet-ordered.js
function Ts(e) {
	let t = e.options.bulletOrdered || ".";
	if (t !== "." && t !== ")") throw Error("Cannot serialize items with `" + t + "` for `options.bulletOrdered`, expected `.` or `)`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/util/check-rule.js
function Es(e) {
	let t = e.options.rule || "*";
	if (t !== "*" && t !== "-" && t !== "_") throw Error("Cannot serialize rules with `" + t + "` for `options.rule`, expected `*`, `-`, or `_`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/list.js
function Ds(e, t, n, r) {
	let i = n.enter("list"), a = n.bulletCurrent, o = e.ordered ? Ts(n) : Cs(n), s = e.ordered ? o === "." ? ")" : "." : ws(n), c = t && n.bulletLastUsed ? o === n.bulletLastUsed : !1;
	if (!e.ordered) {
		let t = e.children ? e.children[0] : void 0;
		if (o !== "*" && o !== "-" || !t || t.children && t.children[0] || n.stack[n.stack.length - 1] !== "list" || n.stack[n.stack.length - 2] !== "listItem" || n.stack[n.stack.length - 3] !== "list" || n.stack[n.stack.length - 4] !== "listItem" || n.indexStack[n.indexStack.length - 1] !== 0 || n.indexStack[n.indexStack.length - 2] !== 0 || n.indexStack[n.indexStack.length - 3] !== 0 || (c = !0), Es(n) === o && t) {
			let t = -1;
			for (; ++t < e.children.length;) {
				let n = e.children[t];
				if (n && n.type === "listItem" && n.children && n.children[0] && n.children[0].type === "thematicBreak") {
					c = !0;
					break;
				}
			}
		}
	}
	c && (o = s), n.bulletCurrent = o;
	let l = n.containerFlow(e, r);
	return n.bulletLastUsed = o, n.bulletCurrent = a, i(), l;
}
// node_modules/mdast-util-to-markdown/lib/util/check-list-item-indent.js
function Os(e) {
	let t = e.options.listItemIndent || "one";
	if (t !== "tab" && t !== "one" && t !== "mixed") throw Error("Cannot serialize items with `" + t + "` for `options.listItemIndent`, expected `tab`, `one`, or `mixed`");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/list-item.js
function ks(e, t, n, r) {
	let i = Os(n), a = n.bulletCurrent || Cs(n);
	t && t.type === "list" && t.ordered && (a = (typeof t.start == "number" && t.start > -1 ? t.start : 1) + (n.options.incrementListMarker === !1 ? 0 : t.children.indexOf(e)) + a);
	let o = a.length + 1;
	(i === "tab" || i === "mixed" && (t && t.type === "list" && t.spread || e.spread)) && (o = Math.ceil(o / 4) * 4);
	let s = n.createTracker(r);
	s.move(a + " ".repeat(o - a.length)), s.shift(o);
	let c = n.enter("listItem"), l = n.indentLines(n.containerFlow(e, s.current()), u);
	return c(), l;
	function u(e, t, n) {
		return t ? (n ? "" : " ".repeat(o)) + e : (n ? a : a + " ".repeat(o - a.length)) + e;
	}
}
// node_modules/mdast-util-to-markdown/lib/handle/paragraph.js
function As(e, t, n, r) {
	let i = n.enter("paragraph"), a = n.enter("phrasing"), o = n.containerPhrasing(e, r);
	return a(), i(), o;
}
// node_modules/mdast-util-to-markdown/lib/handle/root.js
function js(e, t, n, r) {
	if (!e.children.some(function(e) {
		return Uo(e);
	})) return n.containerFlow(e, r);
	let i = n.enter("phrasing"), a = n.containerPhrasing(e, r);
	return i(), a;
}
// node_modules/mdast-util-to-markdown/lib/util/check-strong.js
function Ms(e) {
	let t = e.options.strong || "*";
	if (t !== "*" && t !== "_") throw Error("Cannot serialize strong with `" + t + "` for `options.strong`, expected `*`, or `_`");
	return t;
}
Ns.attention = Ps, Ns.peek = Fs;
function Ns(e, t, n, r) {
	let i = n.enter("phrasing"), a = n.containerPhrasing({
		type: "root",
		children: [e]
	}, r);
	return i(), a;
}
function Ps(e, t) {
	return {
		construct: "strong",
		markers: Ms(t) === "*" ? ["*", "_"] : ["_", "*"],
		sizes: [2]
	};
}
function Fs(e, t, n) {
	return n.options.strong || "*";
}
// node_modules/mdast-util-to-markdown/lib/handle/text.js
function Is(e, t, n, r) {
	/* c8 ignore next -- parent always passed */
	let i = t ? t.children : [], a = i.indexOf(e);
	return n.safe(e.value, {
		...r,
		afterNode: i[a + 1],
		beforeNode: i[a - 1]
	});
}
// node_modules/mdast-util-to-markdown/lib/util/check-rule-repetition.js
function Ls(e) {
	let t = e.options.ruleRepetition || 3;
	if (t < 3) throw Error("Cannot serialize rules with repetition `" + t + "` for `options.ruleRepetition`, expected `3` or more");
	return t;
}
// node_modules/mdast-util-to-markdown/lib/handle/thematic-break.js
function Rs(e, t, n) {
	let r = (Es(n) + (n.options.ruleSpaces ? " " : "")).repeat(Ls(n));
	return n.options.ruleSpaces ? r.slice(0, -1) : r;
}
// node_modules/mdast-util-to-markdown/lib/handle/index.js
var zs = {
	blockquote: Wo,
	break: Jo,
	code: Qo,
	definition: ts,
	emphasis: rs,
	hardBreak: Jo,
	heading: ls,
	html: us,
	image: fs,
	imageReference: ms,
	inlineCode: gs,
	link: ys,
	linkReference: xs,
	list: Ds,
	listItem: ks,
	paragraph: As,
	root: js,
	strong: Ns,
	text: Is,
	thematicBreak: Rs
};
// node_modules/mdast-util-gfm-table/lib/index.js
function Bs() {
	return {
		enter: {
			table: Vs,
			tableData: Gs,
			tableHeader: Gs,
			tableRow: Us
		},
		exit: {
			codeText: Ks,
			table: Hs,
			tableData: Ws,
			tableHeader: Ws,
			tableRow: Ws
		}
	};
}
function Vs(e) {
	let t = e._align;
	this.enter({
		type: "table",
		align: t.map(function(e) {
			return e === "none" ? null : e;
		}),
		children: []
	}, e), this.data.inTable = !0;
}
function Hs(e) {
	this.exit(e), this.data.inTable = void 0;
}
function Us(e) {
	this.enter({
		type: "tableRow",
		children: []
	}, e);
}
function Ws(e) {
	this.exit(e);
}
function Gs(e) {
	this.enter({
		type: "tableCell",
		children: []
	}, e);
}
function Ks(e) {
	let t = this.resume();
	this.data.inTable && (t = t.replace(/\\([\\|])/g, qs));
	let n = this.stack[this.stack.length - 1];
	n.type, n.value = t, this.exit(e);
}
function qs(e, t) {
	return t === "|" ? t : e;
}
function Js(e) {
	let t = e || {}, n = t.tableCellPadding, r = t.tablePipeAlign, i = t.stringLength, a = n ? " " : "|";
	return {
		unsafe: [
			{
				character: "\r",
				inConstruct: "tableCell"
			},
			{
				character: "\n",
				inConstruct: "tableCell"
			},
			{
				atBreak: !0,
				character: "|",
				after: "[	 :-]"
			},
			{
				character: "|",
				inConstruct: "tableCell"
			},
			{
				atBreak: !0,
				character: ":",
				after: "-"
			},
			{
				atBreak: !0,
				character: "-",
				after: "[:|-]"
			}
		],
		handlers: {
			inlineCode: f,
			table: o,
			tableCell: c,
			tableRow: s
		}
	};
	function o(e, t, n, r) {
		return l(u(e, n, r), e.align);
	}
	function s(e, t, n, r) {
		let i = l([d(e, n, r)]);
		return i.slice(0, i.indexOf("\n"));
	}
	function c(e, t, n, r) {
		let i = n.enter("tableCell"), o = n.enter("phrasing"), s = n.containerPhrasing(e, {
			...r,
			before: a,
			after: a
		});
		return o(), i(), s;
	}
	function l(e, t) {
		return Bo(e, {
			align: t,
			alignDelimiters: r,
			padding: n,
			stringLength: i
		});
	}
	function u(e, t, n) {
		let r = e.children, i = -1, a = [], o = t.enter("table");
		for (; ++i < r.length;) a[i] = d(r[i], t, n);
		return o(), a;
	}
	function d(e, t, n) {
		let r = e.children, i = -1, a = [], o = t.enter("tableRow");
		for (; ++i < r.length;) a[i] = c(r[i], e, t, n);
		return o(), a;
	}
	function f(e, t, n) {
		let r = zs.inlineCode(e, t, n);
		return n.stack.includes("tableCell") && (r = r.replace(/\|/g, "\\$&")), r;
	}
}
// node_modules/mdast-util-gfm-task-list-item/lib/index.js
function Ys() {
	return { exit: {
		taskListCheckValueChecked: Zs,
		taskListCheckValueUnchecked: Zs,
		paragraph: Qs
	} };
}
function Xs() {
	return {
		unsafe: [{
			atBreak: !0,
			character: "-",
			after: "[:|-]"
		}],
		handlers: { listItem: $s }
	};
}
function Zs(e) {
	let t = this.stack[this.stack.length - 2];
	t.type, t.checked = e.type === "taskListCheckValueChecked";
}
function Qs(e) {
	let t = this.stack[this.stack.length - 2];
	if (t && t.type === "listItem" && typeof t.checked == "boolean") {
		let e = this.stack[this.stack.length - 1];
		e.type;
		let n = e.children[0];
		if (n && n.type === "text") {
			let r = t.children, i = -1, a;
			for (; ++i < r.length;) {
				let e = r[i];
				if (e.type === "paragraph") {
					a = e;
					break;
				}
			}
			a === e && (n.value = n.value.slice(1), n.value.length === 0 ? e.children.shift() : e.position && n.position && typeof n.position.start.offset == "number" && (n.position.start.column++, n.position.start.offset++, e.position.start = Object.assign({}, n.position.start)));
		}
	}
	this.exit(e);
}
function $s(e, t, n, r) {
	let i = e.children[0], a = typeof e.checked == "boolean" && i && i.type === "paragraph", o = "[" + (e.checked ? "x" : " ") + "] ", s = n.createTracker(r);
	a && s.move(o);
	let c = zs.listItem(e, t, n, {
		...r,
		...s.current()
	});
	return a && (c = c.replace(/^(?:[*+-]|\d+\.)([\r\n]| {1,3})/, l)), c;
	function l(e) {
		return e + o;
	}
}
// node_modules/mdast-util-gfm/lib/index.js
function ec() {
	return [
		no(),
		Do(),
		Mo(),
		Bs(),
		Ys()
	];
}
function tc(e) {
	return { extensions: [
		ro(),
		Oo(e),
		No(),
		Js(e),
		Xs()
	] };
}
// node_modules/micromark-extension-gfm-autolink-literal/lib/syntax.js
var nc = {
	tokenize: gc,
	partial: !0
}, rc = {
	tokenize: _c,
	partial: !0
}, ic = {
	tokenize: vc,
	partial: !0
}, ac = {
	tokenize: yc,
	partial: !0
}, oc = {
	tokenize: bc,
	partial: !0
}, sc = {
	name: "wwwAutolink",
	tokenize: mc,
	previous: xc
}, cc = {
	name: "protocolAutolink",
	tokenize: hc,
	previous: Sc
}, lc = {
	name: "emailAutolink",
	tokenize: pc,
	previous: Cc
}, uc = {};
function dc() {
	return { text: uc };
}
for (var fc = 48; fc < 123;) uc[fc] = lc, fc++, fc === 58 ? fc = 65 : fc === 91 && (fc = 97);
uc[43] = lc, uc[45] = lc, uc[46] = lc, uc[95] = lc, uc[72] = [lc, cc], uc[104] = [lc, cc], uc[87] = [lc, sc], uc[119] = [lc, sc];
function pc(e, t, n) {
	let r = this, i, a;
	return o;
	function o(t) {
		return !wc(t) || !Cc.call(r, r.previous) || Tc(r.events) ? n(t) : (e.enter("literalAutolink"), e.enter("literalAutolinkEmail"), s(t));
	}
	function s(t) {
		return wc(t) ? (e.consume(t), s) : t === 64 ? (e.consume(t), c) : n(t);
	}
	function c(t) {
		return t === 46 ? e.check(oc, u, l)(t) : t === 45 || t === 95 || B(t) ? (a = !0, e.consume(t), c) : u(t);
	}
	function l(t) {
		return e.consume(t), i = !0, c;
	}
	function u(o) {
		return a && i && z(r.previous) ? (e.exit("literalAutolinkEmail"), e.exit("literalAutolink"), t(o)) : n(o);
	}
}
function mc(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return t !== 87 && t !== 119 || !xc.call(r, r.previous) || Tc(r.events) ? n(t) : (e.enter("literalAutolink"), e.enter("literalAutolinkWww"), e.check(nc, e.attempt(rc, e.attempt(ic, a), n), n)(t));
	}
	function a(n) {
		return e.exit("literalAutolinkWww"), e.exit("literalAutolink"), t(n);
	}
}
function hc(e, t, n) {
	let r = this, i = "", a = !1;
	return o;
	function o(t) {
		return (t === 72 || t === 104) && Sc.call(r, r.previous) && !Tc(r.events) ? (e.enter("literalAutolink"), e.enter("literalAutolinkHttp"), i += String.fromCodePoint(t), e.consume(t), s) : n(t);
	}
	function s(t) {
		if (z(t) && i.length < 5) return i += String.fromCodePoint(t), e.consume(t), s;
		if (t === 58) {
			let n = i.toLowerCase();
			if (n === "http" || n === "https") return e.consume(t), c;
		}
		return n(t);
	}
	function c(t) {
		return t === 47 ? (e.consume(t), a ? l : (a = !0, c)) : n(t);
	}
	function l(t) {
		return t === null || ir(t) || H(t) || lr(t) || cr(t) ? n(t) : e.attempt(rc, e.attempt(ic, u), n)(t);
	}
	function u(n) {
		return e.exit("literalAutolinkHttp"), e.exit("literalAutolink"), t(n);
	}
}
function gc(e, t, n) {
	let r = 0;
	return i;
	function i(t) {
		return (t === 87 || t === 119) && r < 3 ? (r++, e.consume(t), i) : t === 46 && r === 3 ? (e.consume(t), a) : n(t);
	}
	function a(e) {
		return e === null ? n(e) : t(e);
	}
}
function _c(e, t, n) {
	let r, i, a;
	return o;
	function o(t) {
		return t === 46 || t === 95 ? e.check(ac, c, s)(t) : t === null || H(t) || lr(t) || t !== 45 && cr(t) ? c(t) : (a = !0, e.consume(t), o);
	}
	function s(t) {
		return t === 95 ? r = !0 : (i = r, r = void 0), e.consume(t), o;
	}
	function c(e) {
		return i || r || !a ? n(e) : t(e);
	}
}
function vc(e, t) {
	let n = 0, r = 0;
	return i;
	function i(o) {
		return o === 40 ? (n++, e.consume(o), i) : o === 41 && r < n ? a(o) : o === 33 || o === 34 || o === 38 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 60 || o === 63 || o === 93 || o === 95 || o === 126 ? e.check(ac, t, a)(o) : o === null || H(o) || lr(o) ? t(o) : (e.consume(o), i);
	}
	function a(t) {
		return t === 41 && r++, e.consume(t), i;
	}
}
function yc(e, t, n) {
	return r;
	function r(o) {
		return o === 33 || o === 34 || o === 39 || o === 41 || o === 42 || o === 44 || o === 46 || o === 58 || o === 59 || o === 63 || o === 95 || o === 126 ? (e.consume(o), r) : o === 38 ? (e.consume(o), a) : o === 93 ? (e.consume(o), i) : o === 60 || o === null || H(o) || lr(o) ? t(o) : n(o);
	}
	function i(e) {
		return e === null || e === 40 || e === 91 || H(e) || lr(e) ? t(e) : r(e);
	}
	function a(e) {
		return z(e) ? o(e) : n(e);
	}
	function o(t) {
		return t === 59 ? (e.consume(t), r) : z(t) ? (e.consume(t), o) : n(t);
	}
}
function bc(e, t, n) {
	return r;
	function r(t) {
		return e.consume(t), i;
	}
	function i(e) {
		return B(e) ? n(e) : t(e);
	}
}
function xc(e) {
	return e === null || e === 40 || e === 42 || e === 95 || e === 91 || e === 93 || e === 126 || H(e);
}
function Sc(e) {
	return !z(e);
}
function Cc(e) {
	return !(e === 47 || wc(e));
}
function wc(e) {
	return e === 43 || e === 45 || e === 46 || e === 95 || B(e);
}
function Tc(e) {
	let t = e.length, n = !1;
	for (; t--;) {
		let r = e[t][1];
		if ((r.type === "labelLink" || r.type === "labelImage") && !r._balanced) {
			n = !0;
			break;
		}
		if (r._gfmAutolinkLiteralWalkedInto) {
			n = !1;
			break;
		}
	}
	return e.length > 0 && !n && (e[e.length - 1][1]._gfmAutolinkLiteralWalkedInto = !0), n;
}
// node_modules/micromark-extension-gfm-footnote/lib/syntax.js
var Ec = {
	tokenize: Pc,
	partial: !0
};
function Dc() {
	return {
		document: { 91: {
			name: "gfmFootnoteDefinition",
			tokenize: jc,
			continuation: { tokenize: Mc },
			exit: Nc
		} },
		text: {
			91: {
				name: "gfmFootnoteCall",
				tokenize: Ac
			},
			93: {
				name: "gfmPotentialFootnoteCall",
				add: "after",
				tokenize: Oc,
				resolveTo: kc
			}
		}
	};
}
function Oc(e, t, n) {
	let r = this, i = r.events.length, a = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), o;
	for (; i--;) {
		let e = r.events[i][1];
		if (e.type === "labelImage") {
			o = e;
			break;
		}
		if (e.type === "gfmFootnoteCall" || e.type === "labelLink" || e.type === "label" || e.type === "image" || e.type === "link") break;
	}
	return s;
	function s(i) {
		if (!o || !o._balanced) return n(i);
		let s = nr(r.sliceSerialize({
			start: o.end,
			end: r.now()
		}));
		return s.codePointAt(0) !== 94 || !a.includes(s.slice(1)) ? n(i) : (e.enter("gfmFootnoteCallLabelMarker"), e.consume(i), e.exit("gfmFootnoteCallLabelMarker"), t(i));
	}
}
function kc(e, t) {
	let n = e.length;
	for (; n--;) if (e[n][1].type === "labelImage" && e[n][0] === "enter") {
		e[n][1];
		break;
	}
	e[n + 1][1].type = "data", e[n + 3][1].type = "gfmFootnoteCallLabelMarker";
	let r = {
		type: "gfmFootnoteCall",
		start: Object.assign({}, e[n + 3][1].start),
		end: Object.assign({}, e[e.length - 1][1].end)
	}, i = {
		type: "gfmFootnoteCallMarker",
		start: Object.assign({}, e[n + 3][1].end),
		end: Object.assign({}, e[n + 3][1].end)
	};
	i.end.column++, i.end.offset++, i.end._bufferIndex++;
	let a = {
		type: "gfmFootnoteCallString",
		start: Object.assign({}, i.end),
		end: Object.assign({}, e[e.length - 1][1].start)
	}, o = {
		type: "chunkString",
		contentType: "string",
		start: Object.assign({}, a.start),
		end: Object.assign({}, a.end)
	}, s = [
		e[n + 1],
		e[n + 2],
		[
			"enter",
			r,
			t
		],
		e[n + 3],
		e[n + 4],
		[
			"enter",
			i,
			t
		],
		[
			"exit",
			i,
			t
		],
		[
			"enter",
			a,
			t
		],
		[
			"enter",
			o,
			t
		],
		[
			"exit",
			o,
			t
		],
		[
			"exit",
			a,
			t
		],
		e[e.length - 2],
		e[e.length - 1],
		[
			"exit",
			r,
			t
		]
	];
	return e.splice(n, e.length - n + 1, ...s), e;
}
function Ac(e, t, n) {
	let r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), a = 0, o;
	return s;
	function s(t) {
		return e.enter("gfmFootnoteCall"), e.enter("gfmFootnoteCallLabelMarker"), e.consume(t), e.exit("gfmFootnoteCallLabelMarker"), c;
	}
	function c(t) {
		return t === 94 ? (e.enter("gfmFootnoteCallMarker"), e.consume(t), e.exit("gfmFootnoteCallMarker"), e.enter("gfmFootnoteCallString"), e.enter("chunkString").contentType = "string", l) : n(t);
	}
	function l(s) {
		if (a > 999 || s === 93 && !o || s === null || s === 91 || H(s)) return n(s);
		if (s === 93) {
			e.exit("chunkString");
			let a = e.exit("gfmFootnoteCallString");
			return i.includes(nr(r.sliceSerialize(a))) ? (e.enter("gfmFootnoteCallLabelMarker"), e.consume(s), e.exit("gfmFootnoteCallLabelMarker"), e.exit("gfmFootnoteCall"), t) : n(s);
		}
		return H(s) || (o = !0), a++, e.consume(s), s === 92 ? u : l;
	}
	function u(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), a++, l) : l(t);
	}
}
function jc(e, t, n) {
	let r = this, i = r.parser.gfmFootnotes || (r.parser.gfmFootnotes = []), a, o = 0, s;
	return c;
	function c(t) {
		return e.enter("gfmFootnoteDefinition")._container = !0, e.enter("gfmFootnoteDefinitionLabel"), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionLabelMarker"), l;
	}
	function l(t) {
		return t === 94 ? (e.enter("gfmFootnoteDefinitionMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionMarker"), e.enter("gfmFootnoteDefinitionLabelString"), e.enter("chunkString").contentType = "string", u) : n(t);
	}
	function u(t) {
		if (o > 999 || t === 93 && !s || t === null || t === 91 || H(t)) return n(t);
		if (t === 93) {
			e.exit("chunkString");
			let n = e.exit("gfmFootnoteDefinitionLabelString");
			return a = nr(r.sliceSerialize(n)), e.enter("gfmFootnoteDefinitionLabelMarker"), e.consume(t), e.exit("gfmFootnoteDefinitionLabelMarker"), e.exit("gfmFootnoteDefinitionLabel"), f;
		}
		return H(t) || (s = !0), o++, e.consume(t), t === 92 ? d : u;
	}
	function d(t) {
		return t === 91 || t === 92 || t === 93 ? (e.consume(t), o++, u) : u(t);
	}
	function f(t) {
		return t === 58 ? (e.enter("definitionMarker"), e.consume(t), e.exit("definitionMarker"), i.includes(a) || i.push(a), W(e, p, "gfmFootnoteDefinitionWhitespace")) : n(t);
	}
	function p(e) {
		return t(e);
	}
}
function Mc(e, t, n) {
	return e.check(Or, t, e.attempt(Ec, t, n));
}
function Nc(e) {
	e.exit("gfmFootnoteDefinition");
}
function Pc(e, t, n) {
	let r = this;
	return W(e, i, "gfmFootnoteDefinitionIndent", 5);
	function i(e) {
		let i = r.events[r.events.length - 1];
		return i && i[1].type === "gfmFootnoteDefinitionIndent" && i[2].sliceSerialize(i[1], !0).length === 4 ? t(e) : n(e);
	}
}
// node_modules/micromark-extension-gfm-strikethrough/lib/syntax.js
function Fc(e) {
	let t = (e || {}).singleTilde, n = {
		name: "strikethrough",
		tokenize: i,
		resolveAll: r
	};
	return t ??= !0, {
		text: { 126: n },
		insideSpan: { null: [n] },
		attentionMarkers: { null: [126] }
	};
	function r(e, t) {
		let n = -1;
		for (; ++n < e.length;) if (e[n][0] === "enter" && e[n][1].type === "strikethroughSequenceTemporary" && e[n][1]._close) {
			let r = n;
			for (; r--;) if (e[r][0] === "exit" && e[r][1].type === "strikethroughSequenceTemporary" && e[r][1]._open && e[n][1].end.offset - e[n][1].start.offset === e[r][1].end.offset - e[r][1].start.offset) {
				e[n][1].type = "strikethroughSequence", e[r][1].type = "strikethroughSequence";
				let i = {
					type: "strikethrough",
					start: Object.assign({}, e[r][1].start),
					end: Object.assign({}, e[n][1].end)
				}, a = {
					type: "strikethroughText",
					start: Object.assign({}, e[r][1].end),
					end: Object.assign({}, e[n][1].start)
				}, o = [
					[
						"enter",
						i,
						t
					],
					[
						"enter",
						e[r][1],
						t
					],
					[
						"exit",
						e[r][1],
						t
					],
					[
						"enter",
						a,
						t
					]
				], s = t.parser.constructs.insideSpan.null;
				s && Yn(o, o.length, 0, xr(s, e.slice(r + 1, n), t)), Yn(o, o.length, 0, [
					[
						"exit",
						a,
						t
					],
					[
						"enter",
						e[n][1],
						t
					],
					[
						"exit",
						e[n][1],
						t
					],
					[
						"exit",
						i,
						t
					]
				]), Yn(e, r - 1, n - r + 3, o), n = r + o.length - 2;
				break;
			}
		}
		for (n = -1; ++n < e.length;) e[n][1].type === "strikethroughSequenceTemporary" && (e[n][1].type = "data");
		return e;
	}
	function i(e, n, r) {
		let i = this.previous, a = this.events, o = 0;
		return s;
		function s(t) {
			return i === 126 && a[a.length - 1][1].type !== "characterEscape" ? r(t) : (e.enter("strikethroughSequenceTemporary"), c(t));
		}
		function c(a) {
			let s = br(i);
			if (a === 126) return o > 1 ? r(a) : (e.consume(a), o++, c);
			if (o < 2 && !t) return r(a);
			let l = e.exit("strikethroughSequenceTemporary"), u = br(a);
			return l._open = !u || u === 2 && !!s, l._close = !s || s === 2 && !!u, n(a);
		}
	}
}
// node_modules/micromark-extension-gfm-table/lib/edit-map.js
var Ic = class {
	constructor() {
		this.map = [], this.index = /* @__PURE__ */ new Map();
	}
	add(e, t, n) {
		Lc(this, e, t, n);
	}
	consume(e) {
		/* c8 ignore next 3 -- `resolve` is never called without tables, so without edits. */
		if (this.map.sort(function(e, t) {
			return e[0] - t[0];
		}), this.map.length === 0) return;
		let t = this.map.length, n = [];
		for (; t > 0;) --t, n.push(e.slice(this.map[t][0] + this.map[t][1]), this.map[t][2]), e.length = this.map[t][0];
		n.push(e.slice()), e.length = 0;
		let r = n.pop();
		for (; r;) {
			for (let t of r) e.push(t);
			r = n.pop();
		}
		this.map.length = 0, this.index.clear();
	}
};
function Lc(e, t, n, r) {
	/* c8 ignore next 3 -- `resolve` is never called without tables, so without edits. */
	if (n === 0 && r.length === 0) return;
	let i = e.index.get(t);
	if (i) {
		i[1] += n, i[2].push(...r);
		return;
	}
	let a = [
		t,
		n,
		r
	];
	e.map.push(a), e.index.set(t, a);
}
// node_modules/micromark-extension-gfm-table/lib/infer.js
function Rc(e, t) {
	let n = !1, r = [];
	for (; t < e.length;) {
		let i = e[t];
		if (n) {
			if (i[0] === "enter") i[1].type === "tableContent" && r.push(e[t + 1][1].type === "tableDelimiterMarker" ? "left" : "none");
			else if (i[1].type === "tableContent") {
				if (e[t - 1][1].type === "tableDelimiterMarker") {
					let e = r.length - 1;
					r[e] = r[e] === "left" ? "center" : "right";
				}
			} else if (i[1].type === "tableDelimiterRow") break;
		} else i[0] === "enter" && i[1].type === "tableDelimiterRow" && (n = !0);
		t += 1;
	}
	return r;
}
// node_modules/micromark-extension-gfm-table/lib/syntax.js
function zc() {
	return { flow: { null: {
		name: "table",
		tokenize: Bc,
		resolveAll: Vc
	} } };
}
function Bc(e, t, n) {
	let r = this, i = 0, a = 0, o;
	return s;
	function s(e) {
		let t = r.events.length - 1;
		for (; t > -1;) {
			let { type: e } = r.events[t][1];
			if (e === "lineEnding" || e === "linePrefix") t--;
			else break;
		}
		let i = t > -1 ? r.events[t][1].type : null, a = i === "tableHead" || i === "tableRow" ? S : c;
		return a === S && r.parser.lazy[r.now().line] ? n(e) : a(e);
	}
	function c(t) {
		return e.enter("tableHead"), e.enter("tableRow"), l(t);
	}
	function l(e) {
		return e === 124 || (o = !0, a += 1), u(e);
	}
	function u(t) {
		return t === null ? n(t) : V(t) ? a > 1 ? (a = 0, r.interrupt = !0, e.exit("tableRow"), e.enter("lineEnding"), e.consume(t), e.exit("lineEnding"), p) : n(t) : U(t) ? W(e, u, "whitespace")(t) : (a += 1, o && (o = !1, i += 1), t === 124 ? (e.enter("tableCellDivider"), e.consume(t), e.exit("tableCellDivider"), o = !0, u) : (e.enter("data"), d(t)));
	}
	function d(t) {
		return t === null || t === 124 || H(t) ? (e.exit("data"), u(t)) : (e.consume(t), t === 92 ? f : d);
	}
	function f(t) {
		return t === 92 || t === 124 ? (e.consume(t), d) : d(t);
	}
	function p(t) {
		return r.interrupt = !1, r.parser.lazy[r.now().line] ? n(t) : (e.enter("tableDelimiterRow"), o = !1, U(t) ? W(e, m, "linePrefix", r.parser.constructs.disable.null.includes("codeIndented") ? void 0 : 4)(t) : m(t));
	}
	function m(t) {
		return t === 45 || t === 58 ? g(t) : t === 124 ? (o = !0, e.enter("tableCellDivider"), e.consume(t), e.exit("tableCellDivider"), h) : x(t);
	}
	function h(t) {
		return U(t) ? W(e, g, "whitespace")(t) : g(t);
	}
	function g(t) {
		return t === 58 ? (a += 1, o = !0, e.enter("tableDelimiterMarker"), e.consume(t), e.exit("tableDelimiterMarker"), _) : t === 45 ? (a += 1, _(t)) : t === null || V(t) ? b(t) : x(t);
	}
	function _(t) {
		return t === 45 ? (e.enter("tableDelimiterFiller"), v(t)) : x(t);
	}
	function v(t) {
		return t === 45 ? (e.consume(t), v) : t === 58 ? (o = !0, e.exit("tableDelimiterFiller"), e.enter("tableDelimiterMarker"), e.consume(t), e.exit("tableDelimiterMarker"), y) : (e.exit("tableDelimiterFiller"), y(t));
	}
	function y(t) {
		return U(t) ? W(e, b, "whitespace")(t) : b(t);
	}
	function b(n) {
		return n === 124 ? m(n) : n === null || V(n) ? !o || i !== a ? x(n) : (e.exit("tableDelimiterRow"), e.exit("tableHead"), t(n)) : x(n);
	}
	function x(e) {
		return n(e);
	}
	function S(t) {
		return e.enter("tableRow"), C(t);
	}
	function C(n) {
		return n === 124 ? (e.enter("tableCellDivider"), e.consume(n), e.exit("tableCellDivider"), C) : n === null || V(n) ? (e.exit("tableRow"), t(n)) : U(n) ? W(e, C, "whitespace")(n) : (e.enter("data"), w(n));
	}
	function w(t) {
		return t === null || t === 124 || H(t) ? (e.exit("data"), C(t)) : (e.consume(t), t === 92 ? T : w);
	}
	function T(t) {
		return t === 92 || t === 124 ? (e.consume(t), w) : w(t);
	}
}
function Vc(e, t) {
	let n = -1, r = !0, i = 0, a = [
		0,
		0,
		0,
		0
	], o = [
		0,
		0,
		0,
		0
	], s = !1, c = 0, l, u, d, f = new Ic();
	for (; ++n < e.length;) {
		let p = e[n], m = p[1];
		p[0] === "enter" ? m.type === "tableHead" ? (s = !1, c !== 0 && (Uc(f, t, c, l, u), u = void 0, c = 0), l = {
			type: "table",
			start: Object.assign({}, m.start),
			end: Object.assign({}, m.end)
		}, f.add(n, 0, [[
			"enter",
			l,
			t
		]])) : m.type === "tableRow" || m.type === "tableDelimiterRow" ? (r = !0, d = void 0, a = [
			0,
			0,
			0,
			0
		], o = [
			0,
			n + 1,
			0,
			0
		], s && (s = !1, u = {
			type: "tableBody",
			start: Object.assign({}, m.start),
			end: Object.assign({}, m.end)
		}, f.add(n, 0, [[
			"enter",
			u,
			t
		]])), i = m.type === "tableDelimiterRow" ? 2 : u ? 3 : 1) : i && (m.type === "data" || m.type === "tableDelimiterMarker" || m.type === "tableDelimiterFiller") ? (r = !1, o[2] === 0 && (a[1] !== 0 && (o[0] = o[1], d = Hc(f, t, a, i, void 0, d), a = [
			0,
			0,
			0,
			0
		]), o[2] = n)) : m.type === "tableCellDivider" && (r ? r = !1 : (a[1] !== 0 && (o[0] = o[1], d = Hc(f, t, a, i, void 0, d)), a = o, o = [
			a[1],
			n,
			0,
			0
		])) : m.type === "tableHead" ? (s = !0, c = n) : m.type === "tableRow" || m.type === "tableDelimiterRow" ? (c = n, a[1] === 0 ? o[1] !== 0 && (d = Hc(f, t, o, i, n, d)) : (o[0] = o[1], d = Hc(f, t, a, i, n, d)), i = 0) : i && (m.type === "data" || m.type === "tableDelimiterMarker" || m.type === "tableDelimiterFiller") && (o[3] = n);
	}
	for (c !== 0 && Uc(f, t, c, l, u), f.consume(t.events), n = -1; ++n < t.events.length;) {
		let e = t.events[n];
		e[0] === "enter" && e[1].type === "table" && (e[1]._align = Rc(t.events, n));
	}
	return e;
}
function Hc(e, t, n, r, i, a) {
	let o = r === 1 ? "tableHeader" : r === 2 ? "tableDelimiter" : "tableData";
	n[0] !== 0 && (a.end = Object.assign({}, Wc(t.events, n[0])), e.add(n[0], 0, [[
		"exit",
		a,
		t
	]]));
	let s = Wc(t.events, n[1]);
	if (a = {
		type: o,
		start: Object.assign({}, s),
		end: Object.assign({}, s)
	}, e.add(n[1], 0, [[
		"enter",
		a,
		t
	]]), n[2] !== 0) {
		let i = Wc(t.events, n[2]), a = Wc(t.events, n[3]), o = {
			type: "tableContent",
			start: Object.assign({}, i),
			end: Object.assign({}, a)
		};
		if (e.add(n[2], 0, [[
			"enter",
			o,
			t
		]]), r !== 2) {
			let r = t.events[n[2]], i = t.events[n[3]];
			if (r[1].end = Object.assign({}, i[1].end), r[1].type = "chunkText", r[1].contentType = "text", n[3] > n[2] + 1) {
				let t = n[2] + 1, r = n[3] - n[2] - 1;
				e.add(t, r, []);
			}
		}
		e.add(n[3] + 1, 0, [[
			"exit",
			o,
			t
		]]);
	}
	return i !== void 0 && (a.end = Object.assign({}, Wc(t.events, i)), e.add(i, 0, [[
		"exit",
		a,
		t
	]]), a = void 0), a;
}
function Uc(e, t, n, r, i) {
	let a = [], o = Wc(t.events, n);
	i && (i.end = Object.assign({}, o), a.push([
		"exit",
		i,
		t
	])), r.end = Object.assign({}, o), a.push([
		"exit",
		r,
		t
	]), e.add(n + 1, 0, a);
}
function Wc(e, t) {
	let n = e[t], r = n[0] === "enter" ? "start" : "end";
	return n[1][r];
}
// node_modules/micromark-extension-gfm-task-list-item/lib/syntax.js
var Gc = {
	name: "tasklistCheck",
	tokenize: qc
};
function Kc() {
	return { text: { 91: Gc } };
}
function qc(e, t, n) {
	let r = this;
	return i;
	function i(t) {
		return r.previous !== null || !r._gfmTasklistFirstContentOfListItem ? n(t) : (e.enter("taskListCheck"), e.enter("taskListCheckMarker"), e.consume(t), e.exit("taskListCheckMarker"), a);
	}
	function a(t) {
		return H(t) ? (e.enter("taskListCheckValueUnchecked"), e.consume(t), e.exit("taskListCheckValueUnchecked"), o) : t === 88 || t === 120 ? (e.enter("taskListCheckValueChecked"), e.consume(t), e.exit("taskListCheckValueChecked"), o) : n(t);
	}
	function o(t) {
		return t === 93 ? (e.enter("taskListCheckMarker"), e.consume(t), e.exit("taskListCheckMarker"), e.exit("taskListCheck"), s) : n(t);
	}
	function s(r) {
		return V(r) ? t(r) : U(r) ? e.check({ tokenize: Jc }, t, n)(r) : n(r);
	}
}
function Jc(e, t, n) {
	return W(e, r, "whitespace");
	function r(e) {
		return e === null ? n(e) : t(e);
	}
}
// node_modules/micromark-extension-gfm/index.js
function Yc(e) {
	return Qn([
		dc(),
		Dc(),
		Fc(e),
		zc(),
		Kc()
	]);
}
// node_modules/remark-gfm/lib/index.js
var Xc = {};
function Zc(e) {
	let t = this, n = e || Xc, r = t.data(), i = r.micromarkExtensions ||= [], a = r.fromMarkdownExtensions ||= [], o = r.toMarkdownExtensions ||= [];
	i.push(Yc(n)), a.push(ec()), o.push(tc(n));
}
// src/local/markdown/footnotes.ts
function Qc(e) {
	return typeof e == "string" && e.trim() !== "" ? e : void 0;
}
function $c(e) {
	let t = /^\[\^([\s\S]*)\]$/.exec(e.trim());
	return t ? t[1] : e;
}
function el(e) {
	return e;
}
function tl(e, t) {
	return Qc(e.attrs?.[t]);
}
function nl(e) {
	return e.replace(/[\t\n\r ]+/g, " ").replace(/^ | $/g, "").toLowerCase().toUpperCase().toLowerCase();
}
function rl(e) {
	let t = el(e), n = Qc(e.value);
	return Qc(t.identifier) ?? Qc(t.label) ?? tl(e, "identifier") ?? tl(e, "label") ?? (n ? $c(n) : "");
}
function il(e) {
	return nl(rl(e));
}
function al(e) {
	let t = el(e), n = Qc(e.value);
	return (Qc(t.label) ?? Qc(t.identifier) ?? tl(e, "label") ?? tl(e, "identifier") ?? (n ? $c(n) : "")).trim().replace(/\s+/g, " ");
}
function ol(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [], i = /* @__PURE__ */ new Map(), a = [{
		nodes: e.nodes,
		index: 0
	}];
	for (; a.length;) {
		let e = a[a.length - 1];
		if (e.index === e.nodes.length) {
			a.pop();
			continue;
		}
		let t = e.nodes[e.index++];
		if (t.type === "footnoteDefinition") {
			let e = il(t);
			e && !n.has(e) && n.set(e, t), t.children && a.push({
				nodes: t.children,
				index: 0,
				owner: t
			});
		} else if (t.type === "footnoteReference") {
			let n = e.owner;
			if (n) {
				let e = i.get(n);
				e ? e.push(t) : i.set(n, [t]);
			} else r.push(t);
		} else t.children && a.push({
			nodes: t.children,
			index: 0,
			owner: e.owner
		});
	}
	let o = [], s = /* @__PURE__ */ new Map(), c = /* @__PURE__ */ new Map(), l = /* @__PURE__ */ new Map(), u = (e) => {
		let r = n.get(e);
		if (!r) return null;
		let i = s.get(e);
		if (i) return i;
		let a = {
			identifier: e,
			number: o.length + 1,
			definition: r,
			id: `${t}-fn-${o.length + 1}`,
			references: []
		};
		return o.push(a), s.set(e, a), a;
	}, d = (e) => {
		let n = il(e), r = n ? u(n) : null;
		if (!r) {
			c.set(e, {
				id: "",
				entry: null,
				label: al(e)
			});
			return;
		}
		let i = (l.get(n) ?? 0) + 1;
		l.set(n, i);
		let a = `${t}-fnref-${r.number}-${i}`;
		r.references.push({
			node: e,
			id: a
		}), c.set(e, {
			id: a,
			entry: r,
			label: al(e)
		});
	};
	for (let e of r) d(e);
	for (let e = 0; e < o.length; e += 1) {
		let t = o[e];
		for (let e of i.get(t.definition) ?? []) d(e);
	}
	return {
		entries: o,
		siteFor(e) {
			return c.get(e);
		}
	};
}
// src/local/markdown/plain-paragraphs.ts
function sl(e, t, n) {
	if (/[\u0000-\u0009\u000b\u000c\u000e-\u001f\u007f\ufeff\\`*_{}\[\]<>!~&|$@]/.test(e) || /(?:^|[\r\n])(?:[ #>+=-]|\d{1,9}[.)](?: |[\r\n]|$))/.test(e) || / [\r\n]/.test(e) || e.includes("://") || /www\./i.test(e)) return;
	let r = [], i = -1, a = 0;
	function o() {
		if (i < 0) return;
		let o = a;
		for (; e[o - 1] === " ";) o--;
		let s = [];
		if (t) {
			let t = i;
			for (let r = t; r < o; r++) {
				if (e[r] !== "\r" && e[r] !== "\n") continue;
				r > t && s.push(n("text", t, r, { value: e.slice(t, r) }));
				let i = e[r] === "\r" && e[r + 1] === "\n" ? r + 2 : r + 1;
				s.push(n("break", r, i)), t = i, r = i - 1;
			}
			t < o && s.push(n("text", t, o, { value: e.slice(t, o) }));
		} else s.push(n("text", i, o, { value: e.slice(i, o) }));
		r.push(n("paragraph", i, a, { children: s })), i = -1;
	}
	for (let t = 0; t < e.length;) {
		let n = t;
		for (; n < e.length && e[n] !== "\r" && e[n] !== "\n";) n++;
		n === t ? o() : (i < 0 && (i = t), a = n), t = e[n] === "\r" && e[n + 1] === "\n" ? n + 2 : n + 1;
	}
	return o(), r;
}
// node_modules/@lezer/common/dist/index.js
var cl = 1024, ll = 0, ul = class {
	constructor(e, t) {
		this.from = e, this.to = t;
	}
}, K = class {
	constructor(e = {}) {
		this.id = ll++, this.perNode = !!e.perNode, this.deserialize = e.deserialize || (() => {
			throw Error("This node type doesn't define a deserialize function");
		}), this.combine = e.combine || null;
	}
	add(e) {
		if (this.perNode) throw RangeError("Can't add per-node props to node types");
		return typeof e != "function" && (e = pl.match(e)), (t) => {
			let n = e(t);
			return n === void 0 ? null : [this, n];
		};
	}
};
K.closedBy = new K({ deserialize: (e) => e.split(" ") }), K.openedBy = new K({ deserialize: (e) => e.split(" ") }), K.group = new K({ deserialize: (e) => e.split(" ") }), K.isolate = new K({ deserialize: (e) => {
	if (e && e != "rtl" && e != "ltr" && e != "auto") throw RangeError("Invalid value for isolate: " + e);
	return e || "auto";
} }), K.contextHash = new K({ perNode: !0 }), K.lookAhead = new K({ perNode: !0 }), K.mounted = new K({ perNode: !0 });
var dl = class {
	constructor(e, t, n, r = !1) {
		this.tree = e, this.overlay = t, this.parser = n, this.bracketed = r;
	}
	static get(e) {
		return e && e.props && e.props[K.mounted.id];
	}
}, fl = Object.create(null), pl = class e {
	constructor(e, t, n, r = 0) {
		this.name = e, this.props = t, this.id = n, this.flags = r;
	}
	static define(t) {
		let n = t.props && t.props.length ? Object.create(null) : fl, r = +!!t.top | (t.skipped ? 2 : 0) | (t.error ? 4 : 0) | (t.name == null ? 8 : 0), i = new e(t.name || "", n, t.id, r);
		if (t.props) {
			for (let e of t.props) if (Array.isArray(e) || (e = e(i)), e) {
				if (e[0].perNode) throw RangeError("Can't store a per-node prop on a node type");
				n[e[0].id] = e[1];
			}
		}
		return i;
	}
	prop(e) {
		return this.props[e.id];
	}
	get isTop() {
		return (this.flags & 1) > 0;
	}
	get isSkipped() {
		return (this.flags & 2) > 0;
	}
	get isError() {
		return (this.flags & 4) > 0;
	}
	get isAnonymous() {
		return (this.flags & 8) > 0;
	}
	is(e) {
		if (typeof e == "string") {
			if (this.name == e) return !0;
			let t = this.prop(K.group);
			return t ? t.indexOf(e) > -1 : !1;
		}
		return this.id == e;
	}
	static match(e) {
		let t = Object.create(null);
		for (let n in e) for (let r of n.split(" ")) t[r] = e[n];
		return (e) => {
			for (let n = e.prop(K.group), r = -1; r < (n ? n.length : 0); r++) {
				let i = t[r < 0 ? e.name : n[r]];
				if (i) return i;
			}
		};
	}
};
pl.none = new pl("", Object.create(null), 0, 8);
var ml = class e {
	constructor(e) {
		this.types = e;
		for (let t = 0; t < e.length; t++) if (e[t].id != t) throw RangeError("Node type ids should correspond to array positions when creating a node set");
	}
	extend(...t) {
		let n = [];
		for (let e of this.types) {
			let r = null;
			for (let n of t) {
				let t = n(e);
				if (t) {
					r ||= Object.assign({}, e.props);
					let n = t[1], i = t[0];
					i.combine && i.id in r && (n = i.combine(r[i.id], n)), r[i.id] = n;
				}
			}
			n.push(r ? new pl(e.name, r, e.id, e.flags) : e);
		}
		return new e(n);
	}
}, hl = /* @__PURE__ */ new WeakMap(), gl = /* @__PURE__ */ new WeakMap(), q;
(function(e) {
	e[e.ExcludeBuffers = 1] = "ExcludeBuffers", e[e.IncludeAnonymous = 2] = "IncludeAnonymous", e[e.IgnoreMounts = 4] = "IgnoreMounts", e[e.IgnoreOverlays = 8] = "IgnoreOverlays", e[e.EnterBracketed = 16] = "EnterBracketed";
})(q ||= {});
var J = class e {
	constructor(e, t, n, r, i) {
		if (this.type = e, this.children = t, this.positions = n, this.length = r, this.props = null, i && i.length) {
			this.props = Object.create(null);
			for (let [e, t] of i) this.props[typeof e == "number" ? e : e.id] = t;
		}
	}
	toString() {
		let e = dl.get(this);
		if (e && !e.overlay) return e.tree.toString();
		let t = "";
		for (let e of this.children) {
			let n = e.toString();
			n && (t && (t += ","), t += n);
		}
		return this.type.name ? (/\W/.test(this.type.name) && !this.type.isError ? JSON.stringify(this.type.name) : this.type.name) + (t.length ? "(" + t + ")" : "") : t;
	}
	cursor(e = 0) {
		return new Al(this.topNode, e);
	}
	cursorAt(e, t = 0, n = 0) {
		let r = new Al(hl.get(this) || this.topNode);
		return r.moveTo(e, t), hl.set(this, r._tree), r;
	}
	get topNode() {
		return new Sl(this, 0, 0, null);
	}
	resolve(e, t = 0) {
		let n = bl(hl.get(this) || this.topNode, e, t, !1);
		return hl.set(this, n), n;
	}
	resolveInner(e, t = 0) {
		let n = bl(gl.get(this) || this.topNode, e, t, !0);
		return gl.set(this, n), n;
	}
	resolveStack(e, t = 0) {
		return kl(this, e, t);
	}
	iterate(e) {
		let { enter: t, leave: n, from: r = 0, to: i = this.length } = e, a = e.mode || 0, o = (a & q.IncludeAnonymous) > 0;
		for (let e = this.cursor(a | q.IncludeAnonymous);;) {
			let a = !1;
			if (e.from <= i && e.to >= r && (!o && e.type.isAnonymous || t(e) !== !1)) {
				if (e.firstChild()) continue;
				a = !0;
			}
			for (; a && n && (o || !e.type.isAnonymous) && n(e), !e.nextSibling();) {
				if (!e.parent()) return;
				a = !0;
			}
		}
	}
	prop(e) {
		return e.perNode ? this.props ? this.props[e.id] : void 0 : this.type.prop(e);
	}
	get propValues() {
		let e = [];
		if (this.props) for (let t in this.props) e.push([+t, this.props[t]]);
		return e;
	}
	balance(t = {}) {
		return this.children.length <= 8 ? this : Fl(pl.none, this.children, this.positions, 0, this.children.length, 0, this.length, (t, n, r) => new e(this.type, t, n, r, this.propValues), t.makeTree || ((t, n, r) => new e(pl.none, t, n, r)));
	}
	static build(e) {
		return Ml(e);
	}
};
J.empty = new J(pl.none, [], [], 0);
var _l = class e {
	constructor(e, t) {
		this.buffer = e, this.index = t;
	}
	get id() {
		return this.buffer[this.index - 4];
	}
	get start() {
		return this.buffer[this.index - 3];
	}
	get end() {
		return this.buffer[this.index - 2];
	}
	get size() {
		return this.buffer[this.index - 1];
	}
	get pos() {
		return this.index;
	}
	next() {
		this.index -= 4;
	}
	fork() {
		return new e(this.buffer, this.index);
	}
}, vl = class e {
	constructor(e, t, n) {
		this.buffer = e, this.length = t, this.set = n;
	}
	get type() {
		return pl.none;
	}
	toString() {
		let e = [];
		for (let t = 0; t < this.buffer.length;) e.push(this.childString(t)), t = this.buffer[t + 3];
		return e.join(",");
	}
	childString(e) {
		let t = this.buffer[e], n = this.buffer[e + 3], r = this.set.types[t], i = r.name;
		if (/\W/.test(i) && !r.isError && (i = JSON.stringify(i)), e += 4, n == e) return i;
		let a = [];
		for (; e < n;) a.push(this.childString(e)), e = this.buffer[e + 3];
		return i + "(" + a.join(",") + ")";
	}
	findChild(e, t, n, r, i) {
		let { buffer: a } = this, o = -1;
		for (let s = e; s != t && !(yl(i, r, a[s + 1], a[s + 2]) && (o = s, n > 0)); s = a[s + 3]);
		return o;
	}
	slice(t, n, r) {
		let i = this.buffer, a = new Uint16Array(n - t), o = 0;
		for (let e = t, s = 0; e < n;) {
			a[s++] = i[e++], a[s++] = i[e++] - r;
			let n = a[s++] = i[e++] - r;
			a[s++] = i[e++] - t, o = Math.max(o, n);
		}
		return new e(a, o, this.set);
	}
};
function yl(e, t, n, r) {
	switch (e) {
		case -2: return n < t;
		case -1: return r >= t && n < t;
		case 0: return n < t && r > t;
		case 1: return n <= t && r > t;
		case 2: return r > t;
		case 4: return !0;
	}
}
function bl(e, t, n, r) {
	for (; e.from == e.to || (n < 1 ? e.from >= t : e.from > t) || (n > -1 ? e.to <= t : e.to < t);) {
		let t = !r && e instanceof Sl && e.index < 0 ? null : e.parent;
		if (!t) return e;
		e = t;
	}
	let i = r ? 0 : q.IgnoreOverlays;
	if (r) for (let r = e, a = r.parent; a; r = a, a = r.parent) r instanceof Sl && r.index < 0 && a.enter(t, n, i)?.from != r.from && (e = a);
	for (;;) {
		let r = e.enter(t, n, i);
		if (!r) return e;
		e = r;
	}
}
var xl = class {
	cursor(e = 0) {
		return new Al(this, e);
	}
	getChild(e, t = null, n = null) {
		let r = Cl(this, e, t, n);
		return r.length ? r[0] : null;
	}
	getChildren(e, t = null, n = null) {
		return Cl(this, e, t, n);
	}
	resolve(e, t = 0) {
		return bl(this, e, t, !1);
	}
	resolveInner(e, t = 0) {
		return bl(this, e, t, !0);
	}
	matchContext(e) {
		return wl(this.parent, e);
	}
	enterUnfinishedNodesBefore(e) {
		let t = this.childBefore(e), n = this;
		for (; t;) {
			let e = t.lastChild;
			if (!e || e.to != t.to) break;
			e.type.isError && e.from == e.to ? (n = t, t = e.prevSibling) : t = e;
		}
		return n;
	}
	get node() {
		return this;
	}
	get next() {
		return this.parent;
	}
}, Sl = class e extends xl {
	constructor(e, t, n, r) {
		super(), this._tree = e, this.from = t, this.index = n, this._parent = r;
	}
	get type() {
		return this._tree.type;
	}
	get name() {
		return this._tree.type.name;
	}
	get to() {
		return this.from + this._tree.length;
	}
	nextChild(t, n, r, i, a = 0) {
		for (let o = this;;) {
			for (let { children: s, positions: c } = o._tree, l = n > 0 ? s.length : -1; t != l; t += n) {
				let l = s[t], u = c[t] + o.from, d;
				if (a & q.EnterBracketed && l instanceof J && (d = dl.get(l)) && !d.overlay && d.bracketed && r >= u && r <= u + l.length || yl(i, r, u, u + l.length)) {
					if (l instanceof vl) {
						if (a & q.ExcludeBuffers) continue;
						let e = l.findChild(0, l.buffer.length, n, r - u, i);
						if (e > -1) return new El(new Tl(o, l, t, u), null, e);
					} else if (a & q.IncludeAnonymous || !l.type.isAnonymous || jl(l)) {
						let s;
						if (!(a & q.IgnoreMounts) && (s = dl.get(l)) && !s.overlay) return new e(s.tree, u, t, o);
						let c = new e(l, u, t, o);
						return a & q.IncludeAnonymous || !c.type.isAnonymous ? c : c.nextChild(n < 0 ? l.children.length - 1 : 0, n, r, i, a);
					}
				}
			}
			if (a & q.IncludeAnonymous || !o.type.isAnonymous || (t = o.index >= 0 ? o.index + n : n < 0 ? -1 : o._parent._tree.children.length, o = o._parent, !o)) return null;
		}
	}
	get firstChild() {
		return this.nextChild(0, 1, 0, 4);
	}
	get lastChild() {
		return this.nextChild(this._tree.children.length - 1, -1, 0, 4);
	}
	childAfter(e) {
		return this.nextChild(0, 1, e, 2);
	}
	childBefore(e) {
		return this.nextChild(this._tree.children.length - 1, -1, e, -2);
	}
	prop(e) {
		return this._tree.prop(e);
	}
	enter(t, n, r = 0) {
		let i;
		if (!(r & q.IgnoreOverlays) && (i = dl.get(this._tree)) && i.overlay) {
			let a = t - this.from, o = r & q.EnterBracketed && i.bracketed;
			for (let { from: t, to: r } of i.overlay) if ((n > 0 || o ? t <= a : t < a) && (n < 0 || o ? r >= a : r > a)) return new e(i.tree, i.overlay[0].from + this.from, -1, this);
		}
		return this.nextChild(0, 1, t, n, r);
	}
	nextSignificantParent() {
		let e = this;
		for (; e.type.isAnonymous && e._parent;) e = e._parent;
		return e;
	}
	get parent() {
		return this._parent ? this._parent.nextSignificantParent() : null;
	}
	get nextSibling() {
		return this._parent && this.index >= 0 ? this._parent.nextChild(this.index + 1, 1, 0, 4) : null;
	}
	get prevSibling() {
		return this._parent && this.index >= 0 ? this._parent.nextChild(this.index - 1, -1, 0, 4) : null;
	}
	get tree() {
		return this._tree;
	}
	toTree() {
		return this._tree;
	}
	toString() {
		return this._tree.toString();
	}
};
function Cl(e, t, n, r) {
	let i = e.cursor(), a = [];
	if (!i.firstChild()) return a;
	if (n != null) {
		for (let e = !1; !e;) if (e = i.type.is(n), !i.nextSibling()) return a;
	}
	for (;;) {
		if (r != null && i.type.is(r)) return a;
		if (i.type.is(t) && a.push(i.node), !i.nextSibling()) return r == null ? a : [];
	}
}
function wl(e, t, n = t.length - 1) {
	for (let r = e; n >= 0; r = r.parent) {
		if (!r) return !1;
		if (!r.type.isAnonymous) {
			if (t[n] && t[n] != r.name) return !1;
			n--;
		}
	}
	return !0;
}
var Tl = class {
	constructor(e, t, n, r) {
		this.parent = e, this.buffer = t, this.index = n, this.start = r;
	}
}, El = class e extends xl {
	get name() {
		return this.type.name;
	}
	get from() {
		return this.context.start + this.context.buffer.buffer[this.index + 1];
	}
	get to() {
		return this.context.start + this.context.buffer.buffer[this.index + 2];
	}
	constructor(e, t, n) {
		super(), this.context = e, this._parent = t, this.index = n, this.type = e.buffer.set.types[e.buffer.buffer[n]];
	}
	child(t, n, r) {
		let { buffer: i } = this.context, a = i.findChild(this.index + 4, i.buffer[this.index + 3], t, n - this.context.start, r);
		return a < 0 ? null : new e(this.context, this, a);
	}
	get firstChild() {
		return this.child(1, 0, 4);
	}
	get lastChild() {
		return this.child(-1, 0, 4);
	}
	childAfter(e) {
		return this.child(1, e, 2);
	}
	childBefore(e) {
		return this.child(-1, e, -2);
	}
	prop(e) {
		return this.type.prop(e);
	}
	enter(t, n, r = 0) {
		if (r & q.ExcludeBuffers) return null;
		let { buffer: i } = this.context, a = i.findChild(this.index + 4, i.buffer[this.index + 3], n > 0 ? 1 : -1, t - this.context.start, n);
		return a < 0 ? null : new e(this.context, this, a);
	}
	get parent() {
		return this._parent || this.context.parent.nextSignificantParent();
	}
	externalSibling(e) {
		return this._parent ? null : this.context.parent.nextChild(this.context.index + e, e, 0, 4);
	}
	get nextSibling() {
		let { buffer: t } = this.context, n = t.buffer[this.index + 3];
		return n < (this._parent ? t.buffer[this._parent.index + 3] : t.buffer.length) ? new e(this.context, this._parent, n) : this.externalSibling(1);
	}
	get prevSibling() {
		let { buffer: t } = this.context, n = this._parent ? this._parent.index + 4 : 0;
		return this.index == n ? this.externalSibling(-1) : new e(this.context, this._parent, t.findChild(n, this.index, -1, 0, 4));
	}
	get tree() {
		return null;
	}
	toTree() {
		let e = [], t = [], { buffer: n } = this.context, r = this.index + 4, i = n.buffer[this.index + 3];
		if (i > r) {
			let a = n.buffer[this.index + 1];
			e.push(n.slice(r, i, a)), t.push(0);
		}
		return new J(this.type, e, t, this.to - this.from);
	}
	toString() {
		return this.context.buffer.childString(this.index);
	}
};
function Dl(e) {
	if (!e.length) return null;
	let t = 0, n = e[0];
	for (let r = 1; r < e.length; r++) {
		let i = e[r];
		(i.from > n.from || i.to < n.to) && (n = i, t = r);
	}
	let r = n instanceof Sl && n.index < 0 ? null : n.parent, i = e.slice();
	return r ? i[t] = r : i.splice(t, 1), new Ol(i, n);
}
var Ol = class {
	constructor(e, t) {
		this.heads = e, this.node = t;
	}
	get next() {
		return Dl(this.heads);
	}
};
function kl(e, t, n) {
	let r = e.resolveInner(t, n), i = null;
	for (let e = r instanceof Sl ? r : r.context.parent; e; e = e.parent) if (e.index < 0) {
		let a = e.parent;
		(i ||= [r]).push(a.resolve(t, n)), e = a;
	} else {
		let a = dl.get(e.tree);
		if (a && a.overlay && a.overlay[0].from <= t && a.overlay[a.overlay.length - 1].to >= t) {
			let o = new Sl(a.tree, a.overlay[0].from + e.from, -1, e);
			(i ||= [r]).push(bl(o, t, n, !1));
		}
	}
	return i ? Dl(i) : r;
}
var Al = class {
	get name() {
		return this.type.name;
	}
	constructor(e, t = 0) {
		if (this.buffer = null, this.stack = [], this.index = 0, this.bufferNode = null, this.mode = t & ~q.EnterBracketed, e instanceof Sl) this.yieldNode(e);
		else {
			this._tree = e.context.parent, this.buffer = e.context;
			for (let t = e._parent; t; t = t._parent) this.stack.unshift(t.index);
			this.bufferNode = e, this.yieldBuf(e.index);
		}
	}
	yieldNode(e) {
		return e ? (this._tree = e, this.type = e.type, this.from = e.from, this.to = e.to, !0) : !1;
	}
	yieldBuf(e, t) {
		this.index = e;
		let { start: n, buffer: r } = this.buffer;
		return this.type = t || r.set.types[r.buffer[e]], this.from = n + r.buffer[e + 1], this.to = n + r.buffer[e + 2], !0;
	}
	yield(e) {
		return e ? e instanceof Sl ? (this.buffer = null, this.yieldNode(e)) : (this.buffer = e.context, this.yieldBuf(e.index, e.type)) : !1;
	}
	toString() {
		return this.buffer ? this.buffer.buffer.childString(this.index) : this._tree.toString();
	}
	enterChild(e, t, n) {
		if (!this.buffer) return this.yield(this._tree.nextChild(e < 0 ? this._tree._tree.children.length - 1 : 0, e, t, n, this.mode));
		let { buffer: r } = this.buffer, i = r.findChild(this.index + 4, r.buffer[this.index + 3], e, t - this.buffer.start, n);
		return i < 0 ? !1 : (this.stack.push(this.index), this.yieldBuf(i));
	}
	firstChild() {
		return this.enterChild(1, 0, 4);
	}
	lastChild() {
		return this.enterChild(-1, 0, 4);
	}
	childAfter(e) {
		return this.enterChild(1, e, 2);
	}
	childBefore(e) {
		return this.enterChild(-1, e, -2);
	}
	enter(e, t, n = this.mode) {
		return this.buffer ? n & q.ExcludeBuffers ? !1 : this.enterChild(1, e, t) : this.yield(this._tree.enter(e, t, n));
	}
	parent() {
		if (!this.buffer) return this.yieldNode(this.mode & q.IncludeAnonymous ? this._tree._parent : this._tree.parent);
		if (this.stack.length) return this.yieldBuf(this.stack.pop());
		let e = this.mode & q.IncludeAnonymous ? this.buffer.parent : this.buffer.parent.nextSignificantParent();
		return this.buffer = null, this.yieldNode(e);
	}
	sibling(e) {
		if (!this.buffer) return this._tree._parent ? this.yield(this._tree.index < 0 ? null : this._tree._parent.nextChild(this._tree.index + e, e, 0, 4, this.mode)) : !1;
		let { buffer: t } = this.buffer, n = this.stack.length - 1;
		if (e < 0) {
			let e = n < 0 ? 0 : this.stack[n] + 4;
			if (this.index != e) return this.yieldBuf(t.findChild(e, this.index, -1, 0, 4));
		} else {
			let e = t.buffer[this.index + 3];
			if (e < (n < 0 ? t.buffer.length : t.buffer[this.stack[n] + 3])) return this.yieldBuf(e);
		}
		return n < 0 && this.yield(this.buffer.parent.nextChild(this.buffer.index + e, e, 0, 4, this.mode));
	}
	nextSibling() {
		return this.sibling(1);
	}
	prevSibling() {
		return this.sibling(-1);
	}
	atLastNode(e) {
		let t, n, { buffer: r } = this;
		if (r) {
			if (e > 0) {
				if (this.index < r.buffer.buffer.length) return !1;
			} else for (let e = 0; e < this.index; e++) if (r.buffer.buffer[e + 3] < this.index) return !1;
			({index: t, parent: n} = r);
		} else ({index: t, _parent: n} = this._tree);
		for (; n; {index: t, _parent: n} = n) if (t > -1) for (let r = t + e, i = e < 0 ? -1 : n._tree.children.length; r != i; r += e) {
			let e = n._tree.children[r];
			if (this.mode & q.IncludeAnonymous || e instanceof vl || !e.type.isAnonymous || jl(e)) return !1;
		}
		return !0;
	}
	move(e, t) {
		if (t && this.enterChild(e, 0, 4)) return !0;
		for (;;) {
			if (this.sibling(e)) return !0;
			if (this.atLastNode(e) || !this.parent()) return !1;
		}
	}
	next(e = !0) {
		return this.move(1, e);
	}
	prev(e = !0) {
		return this.move(-1, e);
	}
	moveTo(e, t = 0) {
		for (; (this.from == this.to || (t < 1 ? this.from >= e : this.from > e) || (t > -1 ? this.to <= e : this.to < e)) && this.parent(););
		for (; this.enterChild(1, e, t););
		return this;
	}
	get node() {
		if (!this.buffer) return this._tree;
		let e = this.bufferNode, t = null, n = 0;
		if (e && e.context == this.buffer) scan: for (let r = this.index, i = this.stack.length; i >= 0;) {
			for (let a = e; a; a = a._parent) if (a.index == r) {
				if (r == this.index) return a;
				t = a, n = i + 1;
				break scan;
			}
			r = this.stack[--i];
		}
		for (let e = n; e < this.stack.length; e++) t = new El(this.buffer, t, this.stack[e]);
		return this.bufferNode = new El(this.buffer, t, this.index);
	}
	get tree() {
		return this.buffer ? null : this._tree._tree;
	}
	iterate(e, t) {
		for (let n = 0;;) {
			let r = !1;
			if (this.type.isAnonymous || e(this) !== !1) {
				if (this.firstChild()) {
					n++;
					continue;
				}
				this.type.isAnonymous || (r = !0);
			}
			for (;;) {
				if (r && t && t(this), r = this.type.isAnonymous, !n) return;
				if (this.nextSibling()) break;
				this.parent(), n--, r = !0;
			}
		}
	}
	matchContext(e) {
		if (!this.buffer) return wl(this.node.parent, e);
		let { buffer: t } = this.buffer, { types: n } = t.set;
		for (let r = e.length - 1, i = this.stack.length - 1; r >= 0; i--) {
			if (i < 0) return wl(this._tree, e, r);
			let a = n[t.buffer[this.stack[i]]];
			if (!a.isAnonymous) {
				if (e[r] && e[r] != a.name) return !1;
				r--;
			}
		}
		return !0;
	}
};
function jl(e) {
	return e.children.some((e) => e instanceof vl || !e.type.isAnonymous || jl(e));
}
function Ml(e) {
	let { buffer: t, nodeSet: n, maxBufferLength: r = cl, reused: i = [], minRepeatType: a = n.types.length } = e, o = Array.isArray(t) ? new _l(t, t.length) : t, s = n.types, c = 0, l = 0;
	function u(e, t, _, v, y, b) {
		let { id: x, start: S, end: C, size: w } = o, T = l, E = c;
		if (w < 0) {
			if (o.next(), w == -1) {
				let t = i[x];
				_.push(t), v.push(S - e);
				return;
			}
			if (w == -3) {
				c = x;
				return;
			}
			if (w == -4) {
				l = x;
				return;
			}
			throw RangeError(`Unrecognized record size: ${w}`);
		}
		let D = s[x], O, k, A = S - e;
		if (C - S <= r && (k = h(o.pos - t, y))) {
			let t = new Uint16Array(k.size - k.skip), r = o.pos - k.size, i = t.length;
			for (; o.pos > r;) i = g(k.start, t, i);
			O = new vl(t, C - k.start, n), A = k.start - e;
		} else {
			let e = o.pos - w;
			o.next();
			let t = [], n = [], i = x >= a ? x : -1, s = 0, c = C, h = T;
			for (; o.pos > e;) i >= 0 && o.id == i && o.size >= 0 ? (o.end <= c - r && (p(t, n, S, s, o.end, c, i, h, E), s = t.length, c = o.end, h = l), o.next()) : b > 2500 ? d(S, e, t, n) : u(S, e, t, n, i, b + 1);
			if (i >= 0 && s > 0 && s < t.length && p(t, n, S, s, S, c, i, h, E), t.reverse(), n.reverse(), i > -1 && s > 0) {
				let e = f(D, E);
				O = Fl(D, t, n, 0, t.length, 0, C - S, e, e);
			} else O = m(D, t, n, C - S, T - C, E);
		}
		_.push(O), v.push(A);
	}
	function d(e, t, i, a) {
		let s = [], c = 0, l = -1;
		for (; o.pos > t;) {
			let { id: e, start: t, end: n, size: i } = o;
			if (i > 4) o.next();
			else if (l > -1 && t < l) break;
			else l < 0 && (l = n - r), s.push(e, t, n), c++, o.next();
		}
		if (c) {
			let t = new Uint16Array(c * 4), r = s[s.length - 2];
			for (let e = s.length - 3, n = 0; e >= 0; e -= 3) t[n++] = s[e], t[n++] = s[e + 1] - r, t[n++] = s[e + 2] - r, t[n++] = n;
			i.push(new vl(t, s[2] - r, n)), a.push(r - e);
		}
	}
	function f(e, t) {
		return (n, r, i) => {
			let a = 0, o = n.length - 1, s, c;
			if (o >= 0 && (s = n[o]) instanceof J) {
				if (!o && s.type == e && s.length == i) return s;
				(c = s.prop(K.lookAhead)) && (a = r[o] + s.length + c - i);
			}
			return m(e, n, r, i, a, t);
		};
	}
	function p(e, t, r, i, a, o, s, c, l) {
		let u = [], d = [];
		for (; e.length > i;) u.push(e.pop()), d.push(t.pop() + r - a);
		e.push(m(n.types[s], u, d, o - a, c - o, l)), t.push(a - r);
	}
	function m(e, t, n, r, i, a, o) {
		if (a) {
			let e = [K.contextHash, a];
			o = o ? [e].concat(o) : [e];
		}
		if (i > 25) {
			let e = [K.lookAhead, i];
			o = o ? [e].concat(o) : [e];
		}
		return new J(e, t, n, r, o);
	}
	function h(e, t) {
		let n = o.fork(), i = 0, s = 0, c = 0, l = n.end - r, u = {
			size: 0,
			start: 0,
			skip: 0
		};
		scan: for (let r = n.pos - e; n.pos > r;) {
			let e = n.size;
			if (n.id == t && e >= 0) {
				u.size = i, u.start = s, u.skip = c, c += 4, i += 4, n.next();
				continue;
			}
			let o = n.pos - e;
			if (e < 0 || o < r || n.start < l) break;
			let d = n.id >= a ? 4 : 0, f = n.start;
			for (n.next(); n.pos > o;) {
				if (n.size < 0) {
					if (n.size == -3 || n.size == -4) d += 4;
					else break scan;
				} else n.id >= a && (d += 4);
				n.next();
			}
			s = f, i += e, c += d;
		}
		return (t < 0 || i == e) && (u.size = i, u.start = s, u.skip = c), u.size > 4 ? u : void 0;
	}
	function g(e, t, n) {
		let { id: r, start: i, end: s, size: u } = o;
		if (o.next(), u >= 0 && r < a) {
			let a = n;
			if (u > 4) {
				let r = o.pos - (u - 4);
				for (; o.pos > r;) n = g(e, t, n);
			}
			t[--n] = a, t[--n] = s - e, t[--n] = i - e, t[--n] = r;
		} else u == -3 ? c = r : u == -4 && (l = r);
		return n;
	}
	let _ = [], v = [];
	for (; o.pos > 0;) u(e.start || 0, e.bufferStart || 0, _, v, -1, 0);
	let y = e.length ?? (_.length ? v[0] + _[0].length : 0);
	return new J(s[e.topID], _.reverse(), v.reverse(), y);
}
var Nl = /* @__PURE__ */ new WeakMap();
function Pl(e, t) {
	if (!e.isAnonymous || t instanceof vl || t.type != e) return 1;
	let n = Nl.get(t);
	if (n == null) {
		n = 1;
		for (let r of t.children) {
			if (r.type != e || !(r instanceof J)) {
				n = 1;
				break;
			}
			n += Pl(e, r);
		}
		Nl.set(t, n);
	}
	return n;
}
function Fl(e, t, n, r, i, a, o, s, c) {
	let l = 0;
	for (let n = r; n < i; n++) l += Pl(e, t[n]);
	let u = Math.ceil(l * 1.5 / 8), d = [], f = [];
	function p(t, n, r, i, o) {
		for (let s = r; s < i;) {
			let r = s, l = n[s], m = Pl(e, t[s]);
			for (s++; s < i; s++) {
				let n = Pl(e, t[s]);
				if (m + n >= u) break;
				m += n;
			}
			if (s == r + 1) {
				if (m > u) {
					let e = t[r];
					p(e.children, e.positions, 0, e.children.length, n[r] + o);
					continue;
				}
				d.push(t[r]);
			} else {
				let i = n[s - 1] + t[s - 1].length - l;
				d.push(Fl(e, t, n, r, s, l, i, null, c));
			}
			f.push(l + o - a);
		}
	}
	return p(t, n, r, i, 0), (s || c)(d, f, o);
}
var Il = class e {
	constructor(e, t, n, r, i = !1, a = !1) {
		this.from = e, this.to = t, this.tree = n, this.offset = r, this.open = !!i | (a ? 2 : 0);
	}
	get openStart() {
		return (this.open & 1) > 0;
	}
	get openEnd() {
		return (this.open & 2) > 0;
	}
	static addTree(t, n = [], r = !1) {
		let i = [new e(0, t.length, t, 0, !1, r)];
		for (let e of n) e.to > t.length && i.push(e);
		return i;
	}
	static applyChanges(t, n, r = 128) {
		if (!n.length) return t;
		let i = [], a = 1, o = t.length ? t[0] : null;
		for (let s = 0, c = 0, l = 0;; s++) {
			let u = s < n.length ? n[s] : null, d = u ? u.fromA : 1e9;
			if (d - c >= r) for (; o && o.from < d;) {
				let n = o;
				if (c >= n.from || d <= n.to || l) {
					let t = Math.max(n.from, c) - l, r = Math.min(n.to, d) - l;
					n = t >= r ? null : new e(t, r, n.tree, n.offset + l, s > 0, !!u);
				}
				if (n && i.push(n), o.to > d) break;
				o = a < t.length ? t[a++] : null;
			}
			if (!u) break;
			c = u.toA, l = u.toA - u.toB;
		}
		return i;
	}
}, Ll = class {
	startParse(e, t, n) {
		return typeof e == "string" && (e = new Rl(e)), n = n ? n.length ? n.map((e) => new ul(e.from, e.to)) : [new ul(0, 0)] : [new ul(0, e.length)], this.createParse(e, t || [], n);
	}
	parse(e, t, n) {
		let r = this.startParse(e, t, n);
		for (;;) {
			let e = r.advance();
			if (e) return e;
		}
	}
}, Rl = class {
	constructor(e) {
		this.string = e;
	}
	get length() {
		return this.string.length;
	}
	chunk(e) {
		return this.string.slice(e);
	}
	get lineChunks() {
		return !1;
	}
	read(e, t) {
		return this.string.slice(e, t);
	}
};
new K({ perNode: !0 });
// node_modules/@lezer/highlight/dist/index.js
var zl = 0, Bl = class e {
	constructor(e, t, n, r) {
		this.name = e, this.set = t, this.base = n, this.modified = r, this.id = zl++;
	}
	toString() {
		let { name: e } = this;
		for (let t of this.modified) t.name && (e = `${t.name}(${e})`);
		return e;
	}
	static define(t, n) {
		let r = typeof t == "string" ? t : "?";
		if (t instanceof e && (n = t), n?.base) throw Error("Can not derive from a modified tag");
		let i = new e(r, [], null, []);
		if (i.set.push(i), n) for (let e of n.set) i.set.push(e);
		return i;
	}
	static defineModifier(e) {
		let t = new Hl(e);
		return (e) => e.modified.indexOf(t) > -1 ? e : Hl.get(e.base || e, e.modified.concat(t).sort((e, t) => e.id - t.id));
	}
}, Vl = 0, Hl = class e {
	constructor(e) {
		this.name = e, this.instances = [], this.id = Vl++;
	}
	static get(t, n) {
		if (!n.length) return t;
		let r = n[0].instances.find((e) => e.base == t && Ul(n, e.modified));
		if (r) return r;
		let i = [], a = new Bl(t.name, i, t, n);
		for (let e of n) e.instances.push(a);
		let o = Wl(n);
		for (let n of t.set) if (!n.modified.length) for (let t of o) i.push(e.get(n, t));
		return a;
	}
};
function Ul(e, t) {
	return e.length == t.length && e.every((e, n) => e == t[n]);
}
function Wl(e) {
	let t = [[]];
	for (let n = 0; n < e.length; n++) for (let r = 0, i = t.length; r < i; r++) t.push(t[r].concat(e[n]));
	return t.sort((e, t) => t.length - e.length);
}
function Gl(e) {
	let t = Object.create(null);
	for (let n in e) {
		let r = e[n];
		Array.isArray(r) || (r = [r]);
		for (let e of n.split(" ")) if (e) {
			let n = [], i = 2, a = e;
			for (let t = 0;;) {
				if (a == "..." && t > 0 && t + 3 == e.length) {
					i = 1;
					break;
				}
				let r = /^"(?:[^"\\]|\\.)*?"|[^\/!]+/.exec(a);
				if (!r) throw RangeError("Invalid path: " + e);
				if (n.push(r[0] == "*" ? "" : r[0][0] == "\"" ? JSON.parse(r[0]) : r[0]), t += r[0].length, t == e.length) break;
				let o = e[t++];
				if (t == e.length && o == "!") {
					i = 0;
					break;
				}
				if (o != "/") throw RangeError("Invalid path: " + e);
				a = e.slice(t);
			}
			let o = n.length - 1, s = n[o];
			if (!s) throw RangeError("Invalid path: " + e);
			t[s] = new ql(r, i, o > 0 ? n.slice(0, o) : null).sort(t[s]);
		}
	}
	return Kl.add(t);
}
var Kl = new K({ combine(e, t) {
	let n, r, i;
	for (; e || t;) {
		if (!e || t && e.depth <= t.depth ? (i = t, t = t.next) : (i = e, e = e.next), n && n.mode == i.mode && !i.context && !n.context) continue;
		let a = new ql(i.tags, i.mode, i.context);
		n ? n.next = a : r = a, n = a;
	}
	return r;
} }), ql = class {
	constructor(e, t, n, r) {
		this.tags = e, this.mode = t, this.context = n, this.next = r;
	}
	get opaque() {
		return this.mode == 0;
	}
	get inherit() {
		return this.mode == 1;
	}
	sort(e) {
		return !e || e.depth < this.depth ? (this.next = e, this) : (e.next = this.sort(e.next), e);
	}
	get depth() {
		return this.context ? this.context.length : 0;
	}
};
ql.empty = new ql([], 2, null);
function Jl(e, t) {
	let n = Object.create(null);
	for (let t of e) if (!Array.isArray(t.tag)) n[t.tag.id] = t.class;
	else for (let e of t.tag) n[e.id] = t.class;
	let { scope: r, all: i = null } = t || {};
	return {
		style: (e) => {
			let t = i;
			for (let r of e) for (let e of r.set) {
				let r = n[e.id];
				if (r) {
					t = t ? t + " " + r : r;
					break;
				}
			}
			return t;
		},
		scope: r
	};
}
var Y = Bl.define, Yl = Y(), Xl = Y(), Zl = Y(Xl), Ql = Y(Xl), $l = Y(), eu = Y($l), tu = Y($l), nu = Y(), ru = Y(nu), iu = Y(), au = Y(), ou = Y(), su = Y(ou), cu = Y(), X = {
	comment: Yl,
	lineComment: Y(Yl),
	blockComment: Y(Yl),
	docComment: Y(Yl),
	name: Xl,
	variableName: Y(Xl),
	typeName: Zl,
	tagName: Y(Zl),
	propertyName: Ql,
	attributeName: Y(Ql),
	className: Y(Xl),
	labelName: Y(Xl),
	namespace: Y(Xl),
	macroName: Y(Xl),
	literal: $l,
	string: eu,
	docString: Y(eu),
	character: Y(eu),
	attributeValue: Y(eu),
	number: tu,
	integer: Y(tu),
	float: Y(tu),
	bool: Y($l),
	regexp: Y($l),
	escape: Y($l),
	color: Y($l),
	url: Y($l),
	keyword: iu,
	self: Y(iu),
	null: Y(iu),
	atom: Y(iu),
	unit: Y(iu),
	modifier: Y(iu),
	operatorKeyword: Y(iu),
	controlKeyword: Y(iu),
	definitionKeyword: Y(iu),
	moduleKeyword: Y(iu),
	operator: au,
	derefOperator: Y(au),
	arithmeticOperator: Y(au),
	logicOperator: Y(au),
	bitwiseOperator: Y(au),
	compareOperator: Y(au),
	updateOperator: Y(au),
	definitionOperator: Y(au),
	typeOperator: Y(au),
	controlOperator: Y(au),
	punctuation: ou,
	separator: Y(ou),
	bracket: su,
	angleBracket: Y(su),
	squareBracket: Y(su),
	paren: Y(su),
	brace: Y(su),
	content: nu,
	heading: ru,
	heading1: Y(ru),
	heading2: Y(ru),
	heading3: Y(ru),
	heading4: Y(ru),
	heading5: Y(ru),
	heading6: Y(ru),
	contentSeparator: Y(nu),
	list: Y(nu),
	quote: Y(nu),
	emphasis: Y(nu),
	strong: Y(nu),
	link: Y(nu),
	monospace: Y(nu),
	strikethrough: Y(nu),
	inserted: Y(),
	deleted: Y(),
	changed: Y(),
	invalid: Y(),
	meta: cu,
	documentMeta: Y(cu),
	annotation: Y(cu),
	processingInstruction: Y(cu),
	definition: Bl.defineModifier("definition"),
	constant: Bl.defineModifier("constant"),
	function: Bl.defineModifier("function"),
	standard: Bl.defineModifier("standard"),
	local: Bl.defineModifier("local"),
	special: Bl.defineModifier("special")
};
for (let e in X) {
	let t = X[e];
	t instanceof Bl && (t.name = e);
}
Jl([
	{
		tag: X.link,
		class: "tok-link"
	},
	{
		tag: X.heading,
		class: "tok-heading"
	},
	{
		tag: X.emphasis,
		class: "tok-emphasis"
	},
	{
		tag: X.strong,
		class: "tok-strong"
	},
	{
		tag: X.keyword,
		class: "tok-keyword"
	},
	{
		tag: X.atom,
		class: "tok-atom"
	},
	{
		tag: X.bool,
		class: "tok-bool"
	},
	{
		tag: X.url,
		class: "tok-url"
	},
	{
		tag: X.labelName,
		class: "tok-labelName"
	},
	{
		tag: X.inserted,
		class: "tok-inserted"
	},
	{
		tag: X.deleted,
		class: "tok-deleted"
	},
	{
		tag: X.literal,
		class: "tok-literal"
	},
	{
		tag: X.string,
		class: "tok-string"
	},
	{
		tag: X.number,
		class: "tok-number"
	},
	{
		tag: [
			X.regexp,
			X.escape,
			X.special(X.string)
		],
		class: "tok-string2"
	},
	{
		tag: X.variableName,
		class: "tok-variableName"
	},
	{
		tag: X.local(X.variableName),
		class: "tok-variableName tok-local"
	},
	{
		tag: X.definition(X.variableName),
		class: "tok-variableName tok-definition"
	},
	{
		tag: X.special(X.variableName),
		class: "tok-variableName2"
	},
	{
		tag: X.definition(X.propertyName),
		class: "tok-propertyName tok-definition"
	},
	{
		tag: X.typeName,
		class: "tok-typeName"
	},
	{
		tag: X.namespace,
		class: "tok-namespace"
	},
	{
		tag: X.className,
		class: "tok-className"
	},
	{
		tag: X.macroName,
		class: "tok-macroName"
	},
	{
		tag: X.propertyName,
		class: "tok-propertyName"
	},
	{
		tag: X.operator,
		class: "tok-operator"
	},
	{
		tag: X.comment,
		class: "tok-comment"
	},
	{
		tag: X.meta,
		class: "tok-meta"
	},
	{
		tag: X.invalid,
		class: "tok-invalid"
	},
	{
		tag: X.punctuation,
		class: "tok-punctuation"
	}
]);
// node_modules/@lezer/markdown/dist/index.js
var lu = class e {
	static create(t, n, r, i, a) {
		let o = i + (i << 8) + t + (n << 4) | 0;
		return new e(t, n, r, o, a, [], []);
	}
	constructor(e, t, n, r, i, a, o) {
		this.type = e, this.value = t, this.from = n, this.hash = r, this.end = i, this.children = a, this.positions = o, this.blankFirstLine = !1, this.hashProp = [[K.contextHash, r]];
	}
	addChild(e, t) {
		e.prop(K.contextHash) != this.hash && (e = new J(e.type, e.children, e.positions, e.length, this.hashProp)), this.children.push(e), this.positions.push(t);
	}
	toTree(e, t = this.end) {
		let n = this.children.length - 1;
		return n >= 0 && (t = Math.max(t, this.positions[n] + this.children[n].length + this.from)), new J(e.types[this.type], this.children, this.positions, t - this.from).balance({ makeTree: (e, t, n) => new J(pl.none, e, t, n, this.hashProp) });
	}
}, Z;
(function(e) {
	e[e.Document = 1] = "Document", e[e.CodeBlock = 2] = "CodeBlock", e[e.FencedCode = 3] = "FencedCode", e[e.Blockquote = 4] = "Blockquote", e[e.HorizontalRule = 5] = "HorizontalRule", e[e.BulletList = 6] = "BulletList", e[e.OrderedList = 7] = "OrderedList", e[e.ListItem = 8] = "ListItem", e[e.ATXHeading1 = 9] = "ATXHeading1", e[e.ATXHeading2 = 10] = "ATXHeading2", e[e.ATXHeading3 = 11] = "ATXHeading3", e[e.ATXHeading4 = 12] = "ATXHeading4", e[e.ATXHeading5 = 13] = "ATXHeading5", e[e.ATXHeading6 = 14] = "ATXHeading6", e[e.SetextHeading1 = 15] = "SetextHeading1", e[e.SetextHeading2 = 16] = "SetextHeading2", e[e.HTMLBlock = 17] = "HTMLBlock", e[e.LinkReference = 18] = "LinkReference", e[e.Paragraph = 19] = "Paragraph", e[e.CommentBlock = 20] = "CommentBlock", e[e.ProcessingInstructionBlock = 21] = "ProcessingInstructionBlock", e[e.Escape = 22] = "Escape", e[e.Entity = 23] = "Entity", e[e.HardBreak = 24] = "HardBreak", e[e.Emphasis = 25] = "Emphasis", e[e.StrongEmphasis = 26] = "StrongEmphasis", e[e.Link = 27] = "Link", e[e.Image = 28] = "Image", e[e.InlineCode = 29] = "InlineCode", e[e.HTMLTag = 30] = "HTMLTag", e[e.Comment = 31] = "Comment", e[e.ProcessingInstruction = 32] = "ProcessingInstruction", e[e.Autolink = 33] = "Autolink", e[e.HeaderMark = 34] = "HeaderMark", e[e.QuoteMark = 35] = "QuoteMark", e[e.ListMark = 36] = "ListMark", e[e.LinkMark = 37] = "LinkMark", e[e.EmphasisMark = 38] = "EmphasisMark", e[e.CodeMark = 39] = "CodeMark", e[e.CodeText = 40] = "CodeText", e[e.CodeInfo = 41] = "CodeInfo", e[e.LinkTitle = 42] = "LinkTitle", e[e.LinkLabel = 43] = "LinkLabel", e[e.URL = 44] = "URL";
})(Z ||= {});
var uu = class {
	constructor(e, t) {
		this.start = e, this.content = t, this.marks = [], this.parsers = [];
	}
}, du = class {
	constructor() {
		this.text = "", this.baseIndent = 0, this.basePos = 0, this.depth = 0, this.markers = [], this.pos = 0, this.indent = 0, this.next = -1;
	}
	forward() {
		this.basePos > this.pos && this.forwardInner();
	}
	forwardInner() {
		let e = this.skipSpace(this.basePos);
		this.indent = this.countIndent(e, this.pos, this.indent), this.pos = e, this.next = e == this.text.length ? -1 : this.text.charCodeAt(e);
	}
	skipSpace(e) {
		return hu(this.text, e);
	}
	reset(e) {
		for (this.text = e, this.baseIndent = this.basePos = this.pos = this.indent = 0, this.forwardInner(), this.depth = 1; this.markers.length;) this.markers.pop();
	}
	moveBase(e) {
		this.basePos = e, this.baseIndent = this.countIndent(e, this.pos, this.indent);
	}
	moveBaseColumn(e) {
		this.baseIndent = e, this.basePos = this.findColumn(e);
	}
	addMarker(e) {
		this.markers.push(e);
	}
	countIndent(e, t = 0, n = 0) {
		for (let r = t; r < e; r++) n += this.text.charCodeAt(r) == 9 ? 4 - n % 4 : 1;
		return n;
	}
	findColumn(e) {
		let t = 0;
		for (let n = 0; t < this.text.length && n < e; t++) n += this.text.charCodeAt(t) == 9 ? 4 - n % 4 : 1;
		return t;
	}
	scrub() {
		if (!this.baseIndent) return this.text;
		let e = "";
		for (let t = 0; t < this.basePos; t++) e += " ";
		return e + this.text.slice(this.basePos);
	}
};
function fu(e, t, n) {
	if (n.pos == n.text.length || e != t.block && n.indent >= t.stack[n.depth + 1].value + n.baseIndent) return !0;
	if (n.indent >= n.baseIndent + 4) return !1;
	let r = (e.type == Z.OrderedList ? Su : xu)(n, t, !1);
	return r > 0 && (e.type != Z.BulletList || yu(n, t, !1) < 0) && n.text.charCodeAt(n.pos + r - 1) == e.value;
}
var pu = {
	[Z.Blockquote](e, t, n) {
		return n.next == 62 && (n.markers.push(Q(Z.QuoteMark, t.lineStart + n.pos, t.lineStart + n.pos + 1)), n.moveBase(n.pos + (mu(n.text.charCodeAt(n.pos + 1)) ? 2 : 1)), e.end = t.lineStart + n.text.length, !0);
	},
	[Z.ListItem](e, t, n) {
		return !(n.next < 0 ? e.blankFirstLine && e.children.length == 1 : n.indent < n.baseIndent + e.value) && (n.moveBaseColumn(n.baseIndent + e.value), !0);
	},
	[Z.OrderedList]: fu,
	[Z.BulletList]: fu,
	[Z.Document]() {
		return !0;
	}
};
function mu(e) {
	return e == 32 || e == 9 || e == 10 || e == 13;
}
function hu(e, t = 0) {
	for (; t < e.length && mu(e.charCodeAt(t));) t++;
	return t;
}
function gu(e, t, n) {
	for (; t > n && mu(e.charCodeAt(t - 1));) t--;
	return t;
}
function _u(e) {
	if (e.next != 96 && e.next != 126) return -1;
	let t = e.pos + 1;
	for (; t < e.text.length && e.text.charCodeAt(t) == e.next;) t++;
	if (t < e.pos + 3) return -1;
	if (e.next == 96) {
		for (let n = t; n < e.text.length; n++) if (e.text.charCodeAt(n) == 96) return -1;
	}
	return t;
}
function vu(e) {
	return e.next == 62 ? e.text.charCodeAt(e.pos + 1) == 32 ? 2 : 1 : -1;
}
function yu(e, t, n) {
	if (e.next != 42 && e.next != 45 && e.next != 95) return -1;
	let r = 1;
	for (let t = e.pos + 1; t < e.text.length; t++) {
		let n = e.text.charCodeAt(t);
		if (n == e.next) r++;
		else if (!mu(n)) return -1;
	}
	return n && e.next == 45 && wu(e) > -1 && e.depth == t.stack.length && t.parser.leafBlockParsers.indexOf(Iu.SetextHeading) > -1 || r < 3 ? -1 : 1;
}
function bu(e, t) {
	for (let n = e.stack.length - 1; n >= 0; n--) if (e.stack[n].type == t) return !0;
	return !1;
}
function xu(e, t, n) {
	return (e.next == 45 || e.next == 43 || e.next == 42) && (e.pos == e.text.length - 1 || mu(e.text.charCodeAt(e.pos + 1))) && (!n || bu(t, Z.BulletList) || e.skipSpace(e.pos + 2) < e.text.length) ? 1 : -1;
}
function Su(e, t, n) {
	let r = e.pos, i = e.next;
	for (; i >= 48 && i <= 57;) {
		if (r++, r == e.text.length) return -1;
		i = e.text.charCodeAt(r);
	}
	return r == e.pos || r > e.pos + 9 || i != 46 && i != 41 || r < e.text.length - 1 && !mu(e.text.charCodeAt(r + 1)) || n && !bu(t, Z.OrderedList) && (e.skipSpace(r + 1) == e.text.length || r > e.pos + 1 || e.next != 49) ? -1 : r + 1 - e.pos;
}
function Cu(e) {
	if (e.next != 35) return -1;
	let t = e.pos + 1;
	for (; t < e.text.length && e.text.charCodeAt(t) == 35;) t++;
	if (t < e.text.length && !mu(e.text.charCodeAt(t))) return -1;
	let n = t - e.pos;
	return n > 6 ? -1 : n;
}
function wu(e) {
	if (e.next != 45 && e.next != 61 || e.indent >= e.baseIndent + 4) return -1;
	let t = e.pos + 1;
	for (; t < e.text.length && e.text.charCodeAt(t) == e.next;) t++;
	let n = t;
	for (; t < e.text.length && mu(e.text.charCodeAt(t));) t++;
	return t == e.text.length ? n : -1;
}
var Tu = /^[ \t]*$/, Eu = /-->/, Du = /\?>/, Ou = [
	[/^<(?:script|pre|style|textarea)(?:\s|>|$)/i, /<\/(?:script|pre|style|textarea)>/i],
	[/^\s*<!--/, Eu],
	[/^\s*<\?/, Du],
	[/^\s*<![A-Z]/, />/],
	[/^\s*<!\[CDATA\[/, /\]\]>/],
	[/^\s*<\/?(?:address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h1|h2|h3|h4|h5|h6|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|nav|noframes|ol|optgroup|option|p|param|section|source|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul)(?:\s|\/?>|$)/i, Tu],
	[/^\s*(?:<\/[a-z][\w-]*\s*>|<[a-z][\w-]*(\s+[a-z:_][\w-.]*(?:\s*=\s*(?:[^\s"'=<>`]+|'[^']*'|"[^"]*"))?)*\s*>)\s*$/i, Tu]
];
function ku(e, t, n) {
	if (e.next != 60) return -1;
	let r = e.text.slice(e.pos);
	for (let e = 0, t = Ou.length - +!!n; e < t; e++) if (Ou[e][0].test(r)) return e;
	return -1;
}
function Au(e, t) {
	let n = e.countIndent(t, e.pos, e.indent), r = e.skipSpace(t), i = e.countIndent(r, t, n);
	return i >= n + 5 || r == e.text.length ? n + 1 : i;
}
function ju(e, t, n) {
	let r = e.length - 1;
	r >= 0 && e[r].to == t && e[r].type == Z.CodeText ? e[r].to = n : e.push(Q(Z.CodeText, t, n));
}
var Mu = {
	LinkReference: void 0,
	IndentedCode(e, t) {
		let n = t.baseIndent + 4;
		if (t.indent < n) return !1;
		let r = t.findColumn(n), i = e.lineStart + r, a = e.lineStart + t.text.length, o = [], s = [];
		for (ju(o, i, a); e.nextLine() && t.depth >= e.stack.length;) if (t.pos == t.text.length) {
			ju(s, e.lineStart - 1, e.lineStart);
			for (let e of t.markers) s.push(e);
		} else if (t.indent < n) break;
		else {
			if (s.length) {
				for (let e of s) e.type == Z.CodeText ? ju(o, e.from, e.to) : o.push(e);
				s = [];
			}
			ju(o, e.lineStart - 1, e.lineStart);
			for (let e of t.markers) o.push(e);
			a = e.lineStart + t.text.length;
			let n = e.lineStart + t.findColumn(t.baseIndent + 4);
			n < a && ju(o, n, a);
		}
		return s.length && (s = s.filter((e) => e.type != Z.CodeText), s.length && (t.markers = s.concat(t.markers))), e.addNode(e.buffer.writeElements(o, -i).finish(Z.CodeBlock, a - i), i), !0;
	},
	FencedCode(e, t) {
		let n = _u(t);
		if (n < 0) return !1;
		let r = e.lineStart + t.pos, i = t.next, a = n - t.pos, o = t.skipSpace(n), s = gu(t.text, t.text.length, o), c = [Q(Z.CodeMark, r, r + a)];
		o < s && c.push(Q(Z.CodeInfo, e.lineStart + o, e.lineStart + s));
		for (let n = !0, r = !0, o = !1; e.nextLine() && t.depth >= e.stack.length; n = !1) {
			let s = t.pos;
			if (t.indent - t.baseIndent < 4) for (; s < t.text.length && t.text.charCodeAt(s) == i;) s++;
			if (s - t.pos >= a && t.skipSpace(s) == t.text.length) {
				for (let e of t.markers) c.push(e);
				r && o && ju(c, e.lineStart - 1, e.lineStart), c.push(Q(Z.CodeMark, e.lineStart + t.pos, e.lineStart + s)), e.nextLine();
				break;
			}
			{
				o = !0, n || (ju(c, e.lineStart - 1, e.lineStart), r = !1);
				for (let e of t.markers) c.push(e);
				let i = e.lineStart + t.basePos, a = e.lineStart + t.text.length;
				i < a && (ju(c, i, a), r = !1);
			}
		}
		return e.addNode(e.buffer.writeElements(c, -r).finish(Z.FencedCode, e.prevLineEnd() - r), r), !0;
	},
	Blockquote(e, t) {
		let n = vu(t);
		return n < 0 ? !1 : (e.startContext(Z.Blockquote, t.pos), e.addNode(Z.QuoteMark, e.lineStart + t.pos, e.lineStart + t.pos + 1), t.moveBase(t.pos + n), null);
	},
	HorizontalRule(e, t) {
		if (yu(t, e, !1) < 0) return !1;
		let n = e.lineStart + t.pos;
		return e.nextLine(), e.addNode(Z.HorizontalRule, n), !0;
	},
	BulletList(e, t) {
		let n = xu(t, e, !1);
		if (n < 0) return !1;
		e.block.type != Z.BulletList && e.startContext(Z.BulletList, t.basePos, t.next);
		let r = Au(t, t.pos + 1);
		return e.startContext(Z.ListItem, t.basePos, r - t.baseIndent), e.addNode(Z.ListMark, e.lineStart + t.pos, e.lineStart + t.pos + n), t.moveBaseColumn(r), e.block.blankFirstLine = r >= t.text.length, null;
	},
	OrderedList(e, t) {
		let n = Su(t, e, !1);
		if (n < 0) return !1;
		e.block.type != Z.OrderedList && e.startContext(Z.OrderedList, t.basePos, t.text.charCodeAt(t.pos + n - 1));
		let r = Au(t, t.pos + n);
		return e.startContext(Z.ListItem, t.basePos, r - t.baseIndent), e.addNode(Z.ListMark, e.lineStart + t.pos, e.lineStart + t.pos + n), t.moveBaseColumn(r), e.block.blankFirstLine = r == t.text.length, null;
	},
	ATXHeading(e, t) {
		let n = Cu(t);
		if (n < 0) return !1;
		let r = t.pos, i = e.lineStart + r, a = gu(t.text, t.text.length, r), o = a;
		for (; o > r && t.text.charCodeAt(o - 1) == t.next;) o--;
		o != a && o != r && mu(t.text.charCodeAt(o - 1)) || (o = t.text.length);
		let s = e.buffer.write(Z.HeaderMark, 0, n).writeElements(e.parser.parseInline(t.text.slice(r + n + 1, o), i + n + 1), -i);
		o < t.text.length && s.write(Z.HeaderMark, o - r, a - r);
		let c = s.finish(Z.ATXHeading1 - 1 + n, t.text.length - r);
		return e.nextLine(), e.addNode(c, i), !0;
	},
	HTMLBlock(e, t) {
		let n = ku(t, e, !1);
		if (n < 0) return !1;
		let r = e.lineStart + t.pos, i = Ou[n][1], a = [], o = i != Tu;
		for (; !i.test(t.text) && e.nextLine();) {
			if (t.depth < e.stack.length) {
				o = !1;
				break;
			}
			for (let e of t.markers) a.push(e);
		}
		o && e.nextLine();
		let s = i == Eu ? Z.CommentBlock : i == Du ? Z.ProcessingInstructionBlock : Z.HTMLBlock, c = e.prevLineEnd();
		return e.addNode(e.buffer.writeElements(a, -r).finish(s, c - r), r), !0;
	},
	SetextHeading: void 0
}, Nu = class {
	constructor(e) {
		this.stage = 0, this.elts = [], this.pos = 0, this.start = e.start, this.advance(e.content);
	}
	nextLine(e, t, n) {
		if (this.stage == -1) return !1;
		let r = n.content + "\n" + t.scrub(), i = this.advance(r);
		return i > -1 && i < r.length && this.complete(e, n, i);
	}
	finish(e, t) {
		return (this.stage == 2 || this.stage == 3) && hu(t.content, this.pos) == t.content.length && this.complete(e, t, t.content.length);
	}
	complete(e, t, n) {
		return e.addLeafElement(t, Q(Z.LinkReference, this.start, this.start + n, this.elts)), !0;
	}
	nextStage(e) {
		return e ? (this.pos = e.to - this.start, this.elts.push(e), this.stage++, !0) : (e === !1 && (this.stage = -1), !1);
	}
	advance(e) {
		for (;;) if (this.stage == -1) return -1;
		else if (this.stage == 0) {
			if (!this.nextStage(sd(e, this.pos, this.start, !0))) return -1;
			if (e.charCodeAt(this.pos) != 58) return this.stage = -1;
			this.elts.push(Q(Z.LinkMark, this.pos + this.start, this.pos + this.start + 1)), this.pos++;
		} else if (this.stage == 1) {
			if (!this.nextStage(ad(e, hu(e, this.pos), this.start))) return -1;
		} else if (this.stage == 2) {
			let t = hu(e, this.pos), n = 0;
			if (t > this.pos) {
				let r = od(e, t, this.start);
				if (r) {
					let t = Pu(e, r.to - this.start);
					t > 0 && (this.nextStage(r), n = t);
				}
			}
			return n ||= Pu(e, this.pos), n > 0 && n < e.length ? n : -1;
		} else return Pu(e, this.pos);
	}
};
function Pu(e, t) {
	for (; t < e.length; t++) {
		let n = e.charCodeAt(t);
		if (n == 10) break;
		if (!mu(n)) return -1;
	}
	return t;
}
var Fu = class {
	nextLine(e, t, n) {
		let r = t.depth < e.stack.length ? -1 : wu(t), i = t.next;
		if (r < 0) return !1;
		let a = Q(Z.HeaderMark, e.lineStart + t.pos, e.lineStart + r);
		return e.nextLine(), e.addLeafElement(n, Q(i == 61 ? Z.SetextHeading1 : Z.SetextHeading2, n.start, e.prevLineEnd(), [...e.parser.parseInline(n.content, n.start), a])), !0;
	}
	finish() {
		return !1;
	}
}, Iu = {
	LinkReference(e, t) {
		return t.content.charCodeAt(0) == 91 ? new Nu(t) : null;
	},
	SetextHeading() {
		return new Fu();
	}
}, Lu = [
	(e, t) => Cu(t) >= 0,
	(e, t) => _u(t) >= 0,
	(e, t) => vu(t) >= 0,
	(e, t) => xu(t, e, !0) >= 0,
	(e, t) => Su(t, e, !0) >= 0,
	(e, t) => yu(t, e, !0) >= 0,
	(e, t) => ku(t, e, !0) >= 0
], Ru = {
	text: "",
	end: 0
}, zu = class {
	constructor(e, t, n, r) {
		this.parser = e, this.input = t, this.ranges = r, this.line = new du(), this.atEnd = !1, this.reusePlaceholders = /* @__PURE__ */ new Map(), this.stoppedAt = null, this.rangeI = 0, this.to = r[r.length - 1].to, this.lineStart = this.absoluteLineStart = this.absoluteLineEnd = r[0].from, this.block = lu.create(Z.Document, 0, this.lineStart, 0, 0), this.stack = [this.block], this.fragments = n.length ? new dd(n, t) : null, this.readLine();
	}
	get parsedPos() {
		return this.absoluteLineStart;
	}
	advance() {
		if (this.stoppedAt != null && this.absoluteLineStart > this.stoppedAt) return this.finish();
		let { line: e } = this;
		for (;;) {
			for (let t = 0;;) {
				let n = e.depth < this.stack.length ? this.stack[this.stack.length - 1] : null;
				for (; t < e.markers.length && (!n || e.markers[t].from < n.end);) {
					let n = e.markers[t++];
					this.addNode(n.type, n.from, n.to);
				}
				if (!n) break;
				this.finishContext();
			}
			if (e.pos < e.text.length) break;
			if (!this.nextLine()) return this.finish();
		}
		if (this.fragments && this.reuseFragment(e.basePos)) return null;
		start: for (;;) {
			for (let t of this.parser.blockParsers) if (t) {
				let n = t(this, e);
				if (n != 0) {
					if (n == 1) return null;
					e.forward();
					continue start;
				}
			}
			break;
		}
		if (e.pos == e.text.length) return this.nextLine() ? null : this.finish();
		let t = new uu(this.lineStart + e.pos, e.text.slice(e.pos));
		for (let e of this.parser.leafBlockParsers) if (e) {
			let n = e(this, t);
			n && t.parsers.push(n);
		}
		lines: for (; this.nextLine() && e.pos != e.text.length;) {
			if (e.indent < e.baseIndent + 4) {
				for (let n of this.parser.endLeafBlock) if (n(this, e, t)) break lines;
			}
			for (let n of t.parsers) if (n.nextLine(this, e, t)) return null;
			t.content += "\n" + e.scrub();
			for (let n of e.markers) t.marks.push(n);
		}
		return this.finishLeaf(t), null;
	}
	stopAt(e) {
		if (this.stoppedAt != null && this.stoppedAt < e) throw RangeError("Can't move stoppedAt forward");
		this.stoppedAt = e;
	}
	reuseFragment(e) {
		if (!this.fragments.moveTo(this.absoluteLineStart + e, this.absoluteLineStart) || !this.fragments.matches(this.block.hash)) return !1;
		let t = this.fragments.takeNodes(this);
		return t ? (this.absoluteLineStart += t, this.lineStart = pd(this.absoluteLineStart, this.ranges), this.moveRangeI(), this.absoluteLineStart < this.to ? (this.lineStart++, this.absoluteLineStart++, this.readLine()) : (this.atEnd = !0, this.readLine()), !0) : !1;
	}
	get depth() {
		return this.stack.length;
	}
	parentType(e = this.depth - 1) {
		return this.parser.nodeSet.types[this.stack[e].type];
	}
	nextLine() {
		return this.lineStart += this.line.text.length, this.absoluteLineEnd >= this.to ? (this.absoluteLineStart = this.absoluteLineEnd, this.atEnd = !0, this.readLine(), !1) : (this.lineStart++, this.absoluteLineStart = this.absoluteLineEnd + 1, this.moveRangeI(), this.readLine(), !0);
	}
	peekLine() {
		return this.scanLine(this.absoluteLineEnd + 1).text;
	}
	moveRangeI() {
		for (; this.rangeI < this.ranges.length - 1 && this.absoluteLineStart >= this.ranges[this.rangeI].to;) this.rangeI++, this.absoluteLineStart = Math.max(this.absoluteLineStart, this.ranges[this.rangeI].from);
	}
	scanLine(e) {
		let t = Ru;
		if (t.end = e, e >= this.to) t.text = "";
		else if (t.text = this.lineChunkAt(e), t.end += t.text.length, this.ranges.length > 1) {
			let e = this.absoluteLineStart, n = this.rangeI;
			for (; this.ranges[n].to < t.end;) {
				n++;
				let r = this.ranges[n].from, i = this.lineChunkAt(r);
				t.end = r + i.length, t.text = t.text.slice(0, this.ranges[n - 1].to - e) + i, e = t.end - t.text.length;
			}
		}
		return t;
	}
	readLine() {
		let { line: e } = this, { text: t, end: n } = this.scanLine(this.absoluteLineStart);
		for (this.absoluteLineEnd = n, e.reset(t); e.depth < this.stack.length; e.depth++) {
			let t = this.stack[e.depth], n = this.parser.skipContextMarkup[t.type];
			if (!n) throw Error("Unhandled block context " + Z[t.type]);
			let r = this.line.markers.length;
			if (!n(t, this, e)) {
				this.line.markers.length > r && (t.end = this.line.markers[this.line.markers.length - 1].to), e.forward();
				break;
			}
			e.forward();
		}
	}
	lineChunkAt(e) {
		let t = this.input.chunk(e), n;
		if (this.input.lineChunks) n = t == "\n" ? "" : t;
		else {
			let e = t.indexOf("\n");
			n = e < 0 ? t : t.slice(0, e);
		}
		return e + n.length > this.to ? n.slice(0, this.to - e) : n;
	}
	prevLineEnd() {
		return this.atEnd ? this.lineStart : this.lineStart - 1;
	}
	startContext(e, t, n = 0) {
		this.block = lu.create(e, n, this.lineStart + t, this.block.hash, this.lineStart + this.line.text.length), this.stack.push(this.block);
	}
	startComposite(e, t, n = 0) {
		this.startContext(this.parser.getNodeType(e), t, n);
	}
	addNode(e, t, n) {
		typeof e == "number" && (e = new J(this.parser.nodeSet.types[e], Ku, Ku, (n ?? this.prevLineEnd()) - t)), this.block.addChild(e, t - this.block.from);
	}
	addElement(e) {
		this.block.addChild(e.toTree(this.parser.nodeSet), e.from - this.block.from);
	}
	addLeafElement(e, t) {
		this.addNode(this.buffer.writeElements(ld(t.children, e.marks), -t.from).finish(t.type, t.to - t.from), t.from);
	}
	finishContext() {
		let e = this.stack.pop(), t = this.stack[this.stack.length - 1];
		t.addChild(e.toTree(this.parser.nodeSet), e.from - t.from), this.block = t;
	}
	finish() {
		for (; this.stack.length > 1;) this.finishContext();
		return this.addGaps(this.block.toTree(this.parser.nodeSet, this.lineStart));
	}
	addGaps(e) {
		return this.ranges.length > 1 ? Bu(this.ranges, 0, e.topNode, this.ranges[0].from, this.reusePlaceholders) : e;
	}
	finishLeaf(e) {
		for (let t of e.parsers) if (t.finish(this, e)) return;
		let t = ld(this.parser.parseInline(e.content, e.start), e.marks);
		this.addNode(this.buffer.writeElements(t, -e.start).finish(Z.Paragraph, e.content.length), e.start);
	}
	elt(e, t, n, r) {
		return typeof e == "string" ? Q(this.parser.getNodeType(e), t, n, r) : new Yu(e, t);
	}
	get buffer() {
		return new qu(this.parser.nodeSet);
	}
};
function Bu(e, t, n, r, i) {
	let a = e[t].to, o = [], s = [], c = n.from + r;
	function l(n, i) {
		for (; i ? n >= a : n > a;) {
			let i = e[t + 1].from - a;
			r += i, n += i, t++, a = e[t].to;
		}
	}
	for (let u = n.firstChild; u; u = u.nextSibling) {
		l(u.from + r, !0);
		let n = u.from + r, d, f = i.get(u.tree);
		f ? d = f : u.to + r > a ? (d = Bu(e, t, u, r, i), l(u.to + r, !1)) : d = u.toTree(), o.push(d), s.push(n - c);
	}
	return l(n.to + r, !1), new J(n.type, o, s, n.to + r - c, n.tree ? n.tree.propValues : void 0);
}
var Vu = class e extends Ll {
	constructor(e, t, n, r, i, a, o, s, c) {
		super(), this.nodeSet = e, this.blockParsers = t, this.leafBlockParsers = n, this.blockNames = r, this.endLeafBlock = i, this.skipContextMarkup = a, this.inlineParsers = o, this.inlineNames = s, this.wrappers = c, this.nodeTypes = Object.create(null);
		for (let t of e.types) this.nodeTypes[t.name] = t.id;
	}
	createParse(e, t, n) {
		let r = new zu(this, e, t, n);
		for (let i of this.wrappers) r = i(r, e, t, n);
		return r;
	}
	configure(t) {
		let n = Uu(t);
		if (!n) return this;
		let { nodeSet: r, skipContextMarkup: i } = this, a = this.blockParsers.slice(), o = this.leafBlockParsers.slice(), s = this.blockNames.slice(), c = this.inlineParsers.slice(), l = this.inlineNames.slice(), u = this.endLeafBlock.slice(), d = this.wrappers;
		if (Hu(n.defineNodes)) {
			i = Object.assign({}, i);
			let e = r.types.slice(), t;
			for (let r of n.defineNodes) {
				let { name: n, block: a, composite: o, style: s } = typeof r == "string" ? { name: r } : r;
				if (e.some((e) => e.name == n)) continue;
				o && (i[e.length] = (e, t, n) => o(t, n, e.value));
				let c = e.length, l = o ? ["Block", "BlockContext"] : a ? c >= Z.ATXHeading1 && c <= Z.SetextHeading2 ? [
					"Block",
					"LeafBlock",
					"Heading"
				] : ["Block", "LeafBlock"] : void 0;
				e.push(pl.define({
					id: c,
					name: n,
					props: l && [[K.group, l]]
				})), s && (t ||= {}, Array.isArray(s) || s instanceof Bl ? t[n] = s : Object.assign(t, s));
			}
			r = new ml(e), t && (r = r.extend(Gl(t)));
		}
		if (Hu(n.props) && (r = r.extend(...n.props)), Hu(n.remove)) for (let e of n.remove) {
			let t = this.blockNames.indexOf(e), n = this.inlineNames.indexOf(e);
			t > -1 && (a[t] = o[t] = void 0), n > -1 && (c[n] = void 0);
		}
		if (Hu(n.parseBlock)) for (let e of n.parseBlock) {
			let t = s.indexOf(e.name);
			if (t > -1) a[t] = e.parse, o[t] = e.leaf;
			else {
				let t = e.before ? Wu(s, e.before) : e.after ? Wu(s, e.after) + 1 : s.length - 1;
				a.splice(t, 0, e.parse), o.splice(t, 0, e.leaf), s.splice(t, 0, e.name);
			}
			e.endLeaf && u.push(e.endLeaf);
		}
		if (Hu(n.parseInline)) for (let e of n.parseInline) {
			let t = l.indexOf(e.name);
			if (t > -1) c[t] = e.parse;
			else {
				let t = e.before ? Wu(l, e.before) : e.after ? Wu(l, e.after) + 1 : l.length - 1;
				c.splice(t, 0, e.parse), l.splice(t, 0, e.name);
			}
		}
		return n.wrap && (d = d.concat(n.wrap)), new e(r, a, o, s, u, i, c, l, d);
	}
	getNodeType(e) {
		let t = this.nodeTypes[e];
		if (t == null) throw RangeError(`Unknown node type '${e}'`);
		return t;
	}
	parseInline(e, t) {
		let n = new cd(this, e, t);
		outer: for (let e = t; e < n.end;) {
			let t = n.char(e);
			for (let r of this.inlineParsers) if (r) {
				let i = r(n, t, e);
				if (i >= 0) {
					e = i;
					continue outer;
				}
			}
			e++;
		}
		return n.resolveMarkers(0);
	}
};
function Hu(e) {
	return e != null && e.length > 0;
}
function Uu(e) {
	if (!Array.isArray(e)) return e;
	if (e.length == 0) return null;
	let t = Uu(e[0]);
	if (e.length == 1) return t;
	let n = Uu(e.slice(1));
	if (!n || !t) return t || n;
	let r = (e, t) => (e || Ku).concat(t || Ku), i = t.wrap, a = n.wrap;
	return {
		props: r(t.props, n.props),
		defineNodes: r(t.defineNodes, n.defineNodes),
		parseBlock: r(t.parseBlock, n.parseBlock),
		parseInline: r(t.parseInline, n.parseInline),
		remove: r(t.remove, n.remove),
		wrap: i ? a ? (e, t, n, r) => i(a(e, t, n, r), t, n, r) : i : a
	};
}
function Wu(e, t) {
	let n = e.indexOf(t);
	if (n < 0) throw RangeError(`Position specified relative to unknown parser ${t}`);
	return n;
}
var Gu = [pl.none];
for (let e = 1, t; t = Z[e]; e++) Gu[e] = pl.define({
	id: e,
	name: t,
	props: e >= Z.Escape ? [] : [[K.group, e in pu ? ["Block", "BlockContext"] : ["Block", "LeafBlock"]]],
	top: t == "Document"
});
var Ku = [], qu = class {
	constructor(e) {
		this.nodeSet = e, this.content = [], this.nodes = [];
	}
	write(e, t, n, r = 0) {
		return this.content.push(e, t, n, 4 + r * 4), this;
	}
	writeElements(e, t = 0) {
		for (let n of e) n.writeTo(this, t);
		return this;
	}
	finish(e, t) {
		return J.build({
			buffer: this.content,
			nodeSet: this.nodeSet,
			reused: this.nodes,
			topID: e,
			length: t
		});
	}
}, Ju = class {
	constructor(e, t, n, r = Ku) {
		this.type = e, this.from = t, this.to = n, this.children = r;
	}
	writeTo(e, t) {
		let n = e.content.length;
		e.writeElements(this.children, t), e.content.push(this.type, this.from + t, this.to + t, e.content.length + 4 - n);
	}
	toTree(e) {
		return new qu(e).writeElements(this.children, -this.from).finish(this.type, this.to - this.from);
	}
}, Yu = class {
	constructor(e, t) {
		this.tree = e, this.from = t;
	}
	get to() {
		return this.from + this.tree.length;
	}
	get type() {
		return this.tree.type.id;
	}
	get children() {
		return Ku;
	}
	writeTo(e, t) {
		e.nodes.push(this.tree), e.content.push(e.nodes.length - 1, this.from + t, this.to + t, -1);
	}
	toTree() {
		return this.tree;
	}
};
function Q(e, t, n, r) {
	return new Ju(e, t, n, r);
}
var Xu = {
	resolve: "Emphasis",
	mark: "EmphasisMark"
}, Zu = {
	resolve: "Emphasis",
	mark: "EmphasisMark"
}, Qu = {}, $u = {}, ed = class {
	constructor(e, t, n, r, i = n - t) {
		this.type = e, this.from = t, this.to = n, this.side = r, this.size = i;
	}
}, td = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~", nd = /[!"#$%&'()*+,\-.\/:;<=>?@\[\\\]^_`{|}~\xA1\u2010-\u2027]/;
try {
	nd = /* @__PURE__ */ RegExp("[\\p{S}|\\p{P}]", "u");
} catch {}
var rd = {
	Escape(e, t, n) {
		if (t != 92 || n == e.end - 1) return -1;
		let r = e.char(n + 1);
		for (let t = 0; t < 32; t++) if (td.charCodeAt(t) == r) return e.append(Q(Z.Escape, n, n + 2));
		return -1;
	},
	Entity(e, t, n) {
		if (t != 38) return -1;
		let r = /^(?:#\d+|#x[a-f\d]+|\w+);/i.exec(e.slice(n + 1, n + 31));
		return r ? e.append(Q(Z.Entity, n, n + 1 + r[0].length)) : -1;
	},
	InlineCode(e, t, n) {
		if (t != 96 || n && e.char(n - 1) == 96) return -1;
		let r = n + 1;
		for (; r < e.end && e.char(r) == 96;) r++;
		let i = r - n, a = 0;
		for (; r < e.end; r++) if (e.char(r) == 96) {
			if (a++, a == i && e.char(r + 1) != 96) return e.append(Q(Z.InlineCode, n, r + 1, [Q(Z.CodeMark, n, n + i), Q(Z.CodeMark, r + 1 - i, r + 1)]));
		} else a = 0;
		return -1;
	},
	HTMLTag(e, t, n) {
		if (t != 60 || n == e.end - 1) return -1;
		let r = e.slice(n + 1, e.end), i = /^(?:[a-z][-\w+.]+:[^\s>]+|[a-z\d.!#$%&'*+/=?^_`{|}~-]+@[a-z\d](?:[a-z\d-]{0,61}[a-z\d])?(?:\.[a-z\d](?:[a-z\d-]{0,61}[a-z\d])?)*)>/i.exec(r);
		if (i) return e.append(Q(Z.Autolink, n, n + 1 + i[0].length, [
			Q(Z.LinkMark, n, n + 1),
			Q(Z.URL, n + 1, n + i[0].length),
			Q(Z.LinkMark, n + i[0].length, n + 1 + i[0].length)
		]));
		let a = /^!--(?:-?>|[^]*?-->)/.exec(r);
		if (a) return e.append(Q(Z.Comment, n, n + 1 + a[0].length));
		let o = /^\?[^]*?\?>/.exec(r);
		if (o) return e.append(Q(Z.ProcessingInstruction, n, n + 1 + o[0].length));
		let s = /^(?:![A-Z][^]*?>|!\[CDATA\[[^]*?\]\]>|\/[a-zA-Z][\w-]*\s*>|[a-zA-Z][\w-]*(\s+[a-zA-Z:_][\w-.:]*(?:\s*=\s*(?:[^\s"'=<>`]+|'[^']*'|"[^"]*"))?)*\s*\/?>)/.exec(r);
		return s ? e.append(Q(Z.HTMLTag, n, n + 1 + s[0].length)) : -1;
	},
	Emphasis(e, t, n) {
		if (t != 95 && t != 42) return -1;
		let r = n + 1;
		for (; e.char(r) == t;) r++;
		let i = e.slice(n - 1, n), a = e.slice(r, r + 1), o = nd.test(i), s = nd.test(a), c = /\s|^$/.test(i), l = /\s|^$/.test(a), u = !l && (!s || c || o), d = !c && (!o || l || s), f = u && (t == 42 || !d || o), p = d && (t == 42 || !u || s);
		return e.append(new ed(t == 95 ? Xu : Zu, n, r, !!f | (p ? 2 : 0)));
	},
	HardBreak(e, t, n) {
		if (t == 92 && e.char(n + 1) == 10) return e.append(Q(Z.HardBreak, n, n + 2));
		if (t == 32) {
			let t = n + 1;
			for (; e.char(t) == 32;) t++;
			if (e.char(t) == 10 && t >= n + 2) return e.append(Q(Z.HardBreak, n, t + 1));
		}
		return -1;
	},
	Link(e, t, n) {
		return t == 91 ? e.append(new ed(Qu, n, n + 1, 1)) : -1;
	},
	Image(e, t, n) {
		return t == 33 && e.char(n + 1) == 91 ? e.append(new ed($u, n, n + 2, 1)) : -1;
	},
	LinkEnd(e, t, n) {
		if (t != 93) return -1;
		for (let t = e.parts.length - 1; t >= 0; t--) {
			let r = e.parts[t];
			if (r instanceof ed && (r.type == Qu || r.type == $u)) {
				if (!r.side || e.skipSpace(r.to) == n && !/[(\[]/.test(e.slice(n + 1, n + 2))) return e.parts[t] = null, -1;
				let i = e.takeContent(t), a = e.parts[t] = id(e, i, r.type == Qu ? Z.Link : Z.Image, r.from, n + 1);
				if (r.type == Qu) for (let n = 0; n < t; n++) {
					let t = e.parts[n];
					t instanceof ed && t.type == Qu && (t.side = 0);
				}
				return a.to;
			}
		}
		return -1;
	}
};
function id(e, t, n, r, i) {
	let { text: a } = e, o = e.char(i), s = i;
	if (t.unshift(Q(Z.LinkMark, r, r + (n == Z.Image ? 2 : 1))), t.push(Q(Z.LinkMark, i - 1, i)), o == 40) {
		let n = e.skipSpace(i + 1), r = ad(a, n - e.offset, e.offset), o;
		r && (n = e.skipSpace(r.to), n != r.to && (o = od(a, n - e.offset, e.offset), o && (n = e.skipSpace(o.to)))), e.char(n) == 41 && (t.push(Q(Z.LinkMark, i, i + 1)), s = n + 1, r && t.push(r), o && t.push(o), t.push(Q(Z.LinkMark, n, s)));
	} else if (o == 91) {
		let n = sd(a, i - e.offset, e.offset, !1);
		n && (t.push(n), s = n.to);
	}
	return Q(n, r, s, t);
}
function ad(e, t, n) {
	if (e.charCodeAt(t) == 60) {
		for (let r = t + 1, i = !1; r < e.length; r++) {
			let a = e.charCodeAt(r);
			if (a == 62 && !i) return Q(Z.URL, t + n, r + 1 + n);
			if (a == 60 && !i || a == 10) return !1;
			i = a == 92;
		}
		return null;
	}
	{
		let r = 0, i = t;
		for (let t = !1; i < e.length; i++) {
			let n = e.charCodeAt(i);
			if (mu(n)) break;
			if (t) t = !1;
			else if (n == 40) r++;
			else if (n == 41) {
				if (!r) break;
				r--;
			} else n == 92 && (t = !0);
		}
		return i > t ? Q(Z.URL, t + n, i + n) : i == e.length && null;
	}
}
function od(e, t, n) {
	let r = e.charCodeAt(t);
	if (r != 39 && r != 34 && r != 40) return !1;
	let i = r == 40 ? 41 : r;
	for (let r = t + 1, a = !1; r < e.length; r++) {
		let o = e.charCodeAt(r);
		if (a) a = !1;
		else if (o == i) return Q(Z.LinkTitle, t + n, r + 1 + n);
		else o == 92 && (a = !0);
	}
	return null;
}
function sd(e, t, n, r) {
	for (let i = !1, a = t + 1, o = Math.min(e.length, a + 999); a < o; a++) {
		let o = e.charCodeAt(a);
		if (i) i = !1;
		else if (o == 93) return !r && Q(Z.LinkLabel, t + n, a + 1 + n);
		else {
			if (r && !mu(o) && (r = !1), o == 91) return !1;
			o == 92 && (i = !0);
		}
	}
	return null;
}
var cd = class {
	constructor(e, t, n) {
		this.parser = e, this.text = t, this.offset = n, this.parts = [];
	}
	char(e) {
		return e >= this.end ? -1 : this.text.charCodeAt(e - this.offset);
	}
	get end() {
		return this.offset + this.text.length;
	}
	slice(e, t) {
		return this.text.slice(e - this.offset, t - this.offset);
	}
	append(e) {
		return this.parts.push(e), e.to;
	}
	addDelimiter(e, t, n, r, i) {
		return this.append(new ed(e, t, n, !!r | (i ? 2 : 0)));
	}
	get hasOpenLink() {
		for (let e = this.parts.length - 1; e >= 0; e--) {
			let t = this.parts[e];
			if (t instanceof ed && (t.type == Qu || t.type == $u)) return !0;
		}
		return !1;
	}
	addElement(e) {
		return this.append(e);
	}
	resolveMarkers(e) {
		for (let t = e; t < this.parts.length; t++) {
			let n = this.parts[t];
			if (!(n instanceof ed && n.type.resolve && n.side & 2)) continue;
			let r = n.type == Xu || n.type == Zu, i = n.to - n.from, a, o = t - 1;
			for (; o >= e; o--) {
				let e = this.parts[o];
				if (e instanceof ed && e.side & 1 && e.type == n.type && !(r && (n.side & 1 || e.side & 2) && (e.size + n.size) % 3 == 0 && (e.size % 3 || n.size % 3))) {
					a = e;
					break;
				}
			}
			if (!a) continue;
			let s = n.type.resolve, c = [], l = a.from, u = n.to;
			if (r) {
				let e = Math.min(2, a.to - a.from, i);
				l = a.to - e, u = n.from + e, s = e == 1 ? "Emphasis" : "StrongEmphasis";
			}
			a.type.mark && c.push(this.elt(a.type.mark, l, a.to));
			for (let e = o + 1; e < t; e++) this.parts[e] instanceof Ju && c.push(this.parts[e]), this.parts[e] = null;
			n.type.mark && c.push(this.elt(n.type.mark, n.from, u));
			let d = this.elt(s, l, u, c);
			this.parts[o] = r && a.from != l ? new ed(a.type, a.from, l, a.side, a.size) : null, (this.parts[t] = r && n.to != u ? new ed(n.type, u, n.to, n.side, n.size) : null) ? this.parts.splice(t, 0, d) : this.parts[t] = d;
		}
		let t = [];
		for (let n = e; n < this.parts.length; n++) {
			let e = this.parts[n];
			e instanceof Ju && t.push(e);
		}
		return t;
	}
	findOpeningDelimiter(e) {
		for (let t = this.parts.length - 1; t >= 0; t--) {
			let n = this.parts[t];
			if (n instanceof ed && n.type == e && n.side & 1) return t;
		}
		return null;
	}
	takeContent(e) {
		let t = this.resolveMarkers(e);
		return this.parts.length = e, t;
	}
	getDelimiterAt(e) {
		let t = this.parts[e];
		return t instanceof ed ? t : null;
	}
	skipSpace(e) {
		return hu(this.text, e - this.offset) + this.offset;
	}
	elt(e, t, n, r) {
		return typeof e == "string" ? Q(this.parser.getNodeType(e), t, n, r) : new Yu(e, t);
	}
};
cd.linkStart = Qu, cd.imageStart = $u, cd.emphasisAsterisk = Zu, cd.emphasisUnderscore = Xu;
function ld(e, t) {
	if (!t.length) return e;
	if (!e.length) return t;
	let n = e.slice(), r = 0;
	for (let e of t) {
		for (; r < n.length && n[r].to < e.to;) r++;
		if (r < n.length && n[r].from < e.from) {
			let t = n[r];
			t instanceof Ju && (n[r] = new Ju(t.type, t.from, t.to, ld(t.children, [e])));
		} else n.splice(r++, 0, e);
	}
	return n;
}
var ud = [
	Z.CodeBlock,
	Z.ListItem,
	Z.OrderedList,
	Z.BulletList
], dd = class {
	constructor(e, t) {
		this.fragments = e, this.input = t, this.i = 0, this.fragment = null, this.fragmentEnd = -1, this.cursor = null, e.length && (this.fragment = e[this.i++]);
	}
	nextFragment() {
		this.fragment = this.i < this.fragments.length ? this.fragments[this.i++] : null, this.cursor = null, this.fragmentEnd = -1;
	}
	moveTo(e, t) {
		for (; this.fragment && this.fragment.to <= e;) this.nextFragment();
		if (!this.fragment || this.fragment.from > (e ? e - 1 : 0)) return !1;
		if (this.fragmentEnd < 0) {
			let e = this.fragment.to;
			for (; e > 0 && this.input.read(e - 1, e) != "\n";) e--;
			this.fragmentEnd = e ? e - 1 : 0;
		}
		let n = this.cursor;
		n || (n = this.cursor = this.fragment.tree.cursor(q.IncludeAnonymous | q.IgnoreMounts), n.firstChild());
		let r = e + this.fragment.offset;
		for (; n.to <= r;) if (!n.parent()) return !1;
		for (;;) {
			if (n.from >= r) return this.fragment.from <= t;
			if (!n.childAfter(r)) return !1;
		}
	}
	matches(e) {
		let t = this.cursor.tree;
		for (; t && t.type.isAnonymous && t.children[0] instanceof J;) t = t.children[0];
		return t && t.prop(K.contextHash) == e;
	}
	takeNodes(e) {
		let t = this.cursor, n = this.fragment.offset, r = this.fragmentEnd - +!!this.fragment.openEnd, i = e.absoluteLineStart, a = i, o = e.block.children.length, s = e.lineStart - e.block.from >> 2, c = a, l = o;
		scan: for (;;) {
			if (t.to - n > Math.min(r, e.to) || t.type.isAnonymous && t.tree && (t.to - t.from > s || !fd(t.tree))) {
				if (t.type.isAnonymous && t.firstChild()) continue;
				break;
			}
			let i = pd(t.from - n, e.ranges);
			if (t.to - n <= e.ranges[e.rangeI].to) e.addNode(t.tree, i);
			else {
				let n = new J(e.parser.nodeSet.types[Z.Paragraph], [], [], 0, e.block.hashProp);
				e.reusePlaceholders.set(n, t.tree), e.addNode(n, i);
			}
			for ((t.type.isAnonymous || t.type.is("Block")) && (t.type.isAnonymous || ud.indexOf(t.type.id) < 0 ? (a = t.to - n, o = e.block.children.length) : (a = c, o = l), c = t.to - n, l = e.block.children.length);;) {
				if (t.nextSibling()) continue scan;
				if (!t.parent() || !t.type.isAnonymous) break scan;
			}
		}
		for (; e.block.children.length > o;) e.block.children.pop(), e.block.positions.pop();
		return a - i;
	}
};
function fd(e) {
	for (; e.type.isAnonymous;) {
		let t = e.children[e.children.length - 1];
		if (t instanceof J) e = t;
		else return !1;
	}
	return e.type.is("Block") && ud.indexOf(e.type.id) < 0;
}
function pd(e, t) {
	let n = e;
	for (let r = 1; r < t.length; r++) {
		let i = t[r - 1].to, a = t[r].from;
		i < e && (n -= a - i);
	}
	return n;
}
var md = Gl({
	"Blockquote/...": X.quote,
	HorizontalRule: X.contentSeparator,
	"ATXHeading1/... SetextHeading1/...": X.heading1,
	"ATXHeading2/... SetextHeading2/...": X.heading2,
	"ATXHeading3/...": X.heading3,
	"ATXHeading4/...": X.heading4,
	"ATXHeading5/...": X.heading5,
	"ATXHeading6/...": X.heading6,
	"Comment CommentBlock": X.comment,
	Escape: X.escape,
	Entity: X.character,
	"Emphasis/...": X.emphasis,
	"StrongEmphasis/...": X.strong,
	"Link/... Image/...": X.link,
	"OrderedList/... BulletList/...": X.list,
	"BlockQuote/...": X.quote,
	"InlineCode CodeText": X.monospace,
	"URL Autolink": X.url,
	"HeaderMark HardBreak QuoteMark ListMark LinkMark EmphasisMark CodeMark": X.processingInstruction,
	"CodeInfo LinkLabel": X.labelName,
	LinkTitle: X.string,
	Paragraph: X.content
}), hd = new Vu(new ml(Gu).extend(md), Object.keys(Mu).map((e) => Mu[e]), Object.keys(Mu).map((e) => Iu[e]), Object.keys(Mu), Lu, pu, Object.keys(rd).map((e) => rd[e]), Object.keys(rd), []), gd = {
	resolve: "Strikethrough",
	mark: "StrikethroughMark"
}, _d = {
	defineNodes: [{
		name: "Strikethrough",
		style: { "Strikethrough/...": X.strikethrough }
	}, {
		name: "StrikethroughMark",
		style: X.processingInstruction
	}],
	parseInline: [{
		name: "Strikethrough",
		parse(e, t, n) {
			if (t != 126 || e.char(n + 1) != 126 || e.char(n + 2) == 126) return -1;
			let r = e.slice(n - 1, n), i = e.slice(n + 2, n + 3), a = /\s|^$/.test(r), o = /\s|^$/.test(i), s = nd.test(r), c = nd.test(i);
			return e.addDelimiter(gd, n, n + 2, !o && (!c || a || s), !a && (!s || o || c));
		},
		after: "Emphasis"
	}]
};
function vd(e, t, n = 0, r, i = 0) {
	let a = 0, o = !0, s = -1, c = -1, l = !1, u = () => {
		r.push(e.elt("TableCell", i + s, i + c, e.parser.parseInline(t.slice(s, c), i + s)));
	};
	for (let d = n; d < t.length; d++) {
		let n = t.charCodeAt(d);
		n == 124 && !l ? ((!o || s > -1) && a++, o = !1, r && (s > -1 && u(), r.push(e.elt("TableDelimiter", d + i, d + i + 1))), s = c = -1) : (l || n != 32 && n != 9) && (s < 0 && (s = d), c = d + 1), l = !l && n == 92;
	}
	return s > -1 && (a++, r && u()), a;
}
function yd(e, t) {
	for (let n = t; n < e.length; n++) {
		let t = e.charCodeAt(n);
		if (t == 124) return !0;
		t == 92 && n++;
	}
	return !1;
}
var bd = /^[>\s]*\|?(\s*:?-+:?\s*\|)+(\s*:?-+:?\s*)?$/, xd = class {
	constructor() {
		this.rows = null;
	}
	nextLine(e, t, n) {
		if (this.rows == null) {
			this.rows = !1;
			let r;
			if ((t.next == 45 || t.next == 58 || t.next == 124) && bd.test(r = t.text.slice(t.pos))) {
				let i = [];
				vd(e, n.content, 0, i, n.start) == vd(e, r, 0) && (this.rows = [e.elt("TableHeader", n.start, n.start + n.content.length, i), e.elt("TableDelimiter", e.lineStart + t.pos, e.lineStart + t.text.length)]);
			}
		} else if (this.rows) {
			let n = [];
			vd(e, t.text, t.pos, n, e.lineStart), this.rows.push(e.elt("TableRow", e.lineStart + t.pos, e.lineStart + t.text.length, n));
		}
		return !1;
	}
	finish(e, t) {
		return this.rows ? (e.addLeafElement(t, e.elt("Table", t.start, t.start + t.content.length, this.rows)), !0) : !1;
	}
}, Sd = {
	defineNodes: [
		{
			name: "Table",
			block: !0
		},
		{
			name: "TableHeader",
			style: { "TableHeader/...": X.heading }
		},
		"TableRow",
		{
			name: "TableCell",
			style: X.content
		},
		{
			name: "TableDelimiter",
			style: X.processingInstruction
		}
	],
	parseBlock: [{
		name: "Table",
		leaf(e, t) {
			return yd(t.content, 0) ? new xd() : null;
		},
		endLeaf(e, t, n) {
			if (n.parsers.some((e) => e instanceof xd) || !yd(t.text, t.basePos)) return !1;
			let r = e.peekLine();
			return bd.test(r) && vd(e, t.text, t.basePos) == vd(e, r, t.basePos);
		},
		before: "SetextHeading"
	}]
}, Cd = class {
	nextLine() {
		return !1;
	}
	finish(e, t) {
		return e.addLeafElement(t, e.elt("Task", t.start, t.start + t.content.length, [e.elt("TaskMarker", t.start, t.start + 3), ...e.parser.parseInline(t.content.slice(3), t.start + 3)])), !0;
	}
}, wd = {
	defineNodes: [{
		name: "Task",
		block: !0,
		style: X.list
	}, {
		name: "TaskMarker",
		style: X.atom
	}],
	parseBlock: [{
		name: "TaskList",
		leaf(e, t) {
			return /^\[[ xX]\][ \t]/.test(t.content) && e.parentType().name == "ListItem" ? new Cd() : null;
		},
		after: "SetextHeading"
	}]
}, Td = /(www\.)|(https?:\/\/)|([\w.+-]{1,100}@)|(mailto:|xmpp:)/gy, Ed = /[\w-]+(\.[\w-]+)+(:\d+)?(\/[^\s<]*)?/gy, Dd = /[\w-]+\.[\w-]+($|[/:])/, Od = /[\w.+-]+@[\w-]+(\.[\w.-]+)+/gy, kd = /\/[a-zA-Z\d@.]+/gy;
function Ad(e, t, n, r) {
	let i = 0;
	for (let a = t; a < n; a++) e[a] == r && i++;
	return i;
}
function jd(e, t) {
	Ed.lastIndex = t;
	let n = Ed.exec(e);
	if (!n || Dd.exec(n[0])[0].indexOf("_") > -1) return -1;
	let r = t + n[0].length;
	for (;;) {
		let n = e[r - 1], i;
		if (/[?!.,:*_~]/.test(n) || n == ")" && Ad(e, t, r, ")") > Ad(e, t, r, "(")) r--;
		else if (n == ";" && (i = /&(?:#\d+|#x[a-f\d]+|\w+);$/.exec(e.slice(t, r)))) r = t + i.index;
		else break;
	}
	return r;
}
function Md(e, t) {
	Od.lastIndex = t;
	let n = Od.exec(e);
	if (!n) return -1;
	let r = n[0][n[0].length - 1];
	return r == "_" || r == "-" ? -1 : t + n[0].length - +(r == ".");
}
var Nd = [
	Sd,
	wd,
	_d,
	{ parseInline: [{
		name: "Autolink",
		parse(e, t, n) {
			let r = n - e.offset;
			if (r && /\w/.test(e.text[r - 1])) return -1;
			Td.lastIndex = r;
			let i = Td.exec(e.text), a = -1;
			return !i || (i[1] || i[2] ? (a = jd(e.text, r + i[0].length), a > -1 && e.hasOpenLink && (a = r + /([^\[\]]|\[[^\]]*\])*/.exec(e.text.slice(r, a))[0].length)) : i[3] ? a = Md(e.text, r) : (a = Md(e.text, r + i[0].length), a > -1 && i[0] == "xmpp:" && (kd.lastIndex = a, i = kd.exec(e.text), i && (a = i.index + i[0].length))), a < 0) ? -1 : (e.addElement(e.elt("URL", n, a + e.offset)), a + e.offset);
		}
	}] }
];
X.special(X.content), X.processingInstruction, X.special(X.content), X.processingInstruction, X.character;
// src/local/markdown/fast-markdown.ts
var Pd = /^([-+*]|\d{1,9}[.)]) /, Fd = /!\[(\ue000[0-9]+\ue001)\]\(rmd-internal:placeholder\)/g;
function Id(e, t) {
	let n = t?.placeholders ? e.replace(Fd, (e, n, r) => {
		let i = t.placeholders.get(r + (t.offset ?? 0));
		return i && i.marker === n && i.end === r + (t.offset ?? 0) + e.length ? "x".repeat(e.length) : e;
	}) : e;
	if (e.includes("﻿") || /[\u0000-\u0009\u000b\u000c\u000e-\u001f\u007f\\`_\[\]<>!~&$@#]/.test(n) || !t?.allowBraces && /[{}]/.test(e) || e.includes("://") || /www\./i.test(e)) return;
	let r = [];
	for (let t = 0; t < e.length;) {
		let n = t;
		for (; n < e.length && e[n] !== "\r" && e[n] !== "\n";) n++;
		let i = e.slice(t, n);
		if (i.startsWith(" ") || i.endsWith(" ")) return;
		r.push({
			from: t,
			to: n,
			text: i
		}), t = e[n] === "\r" && e[n + 1] === "\n" ? n + 2 : n + 1;
	}
	return r;
}
function Ld(e, t = !1) {
	let n = [], r = 0;
	for (; r < e.length;) {
		let i = r;
		for (; i < e.length && e[i] !== "*" && !(t && e[i] === "!");) i++;
		if (i === e.length) {
			n.push({
				type: "text",
				from: r,
				to: e.length,
				value: e.slice(r)
			});
			break;
		}
		if (t && e[i] === "!") {
			Fd.lastIndex = i;
			let t = Fd.exec(e);
			if (!t || t.index !== i) return;
			i > r && n.push({
				type: "text",
				from: r,
				to: i,
				value: e.slice(r, i)
			}), n.push({
				type: "opaque",
				from: i,
				to: i + t[0].length,
				value: t[1]
			}), r = i + t[0].length;
			continue;
		}
		if (e.slice(i, i + 2) !== "**" || i > 0 && e[i - 1] !== " ") return;
		let a = i + 2;
		for (; a < e.length && e[a] !== "*";) a++;
		if (a + 2 > e.length || e.slice(a, a + 2) !== "**" || a + 2 < e.length && !/[ .,;:?)\-]/.test(e[a + 2])) return;
		let o = e.slice(i + 2, a);
		if (!/^[\p{L}\p{N}](?:[\p{L}\p{N} .,:;()/-]*[\p{L}\p{N}])?$/u.test(o)) return;
		i > r && n.push({
			type: "text",
			from: r,
			to: i,
			value: e.slice(r, i)
		}), n.push({
			type: "strong",
			from: i,
			to: a + 2,
			value: o
		}), r = a + 2;
	}
	return n;
}
function Rd(e, t, n, r, i) {
	let a = i(e, t, n);
	if (a === void 0) return;
	let o = [];
	for (let t of a) if (t.type === "text") o.push(r("text", e + t.from, e + t.to, { value: t.value }));
	else if (t.type === "opaque") o.push(r("rmdOpaque", e + t.from, e + t.to, { value: t.value }));
	else {
		let n = r("text", e + t.from + 2, e + t.to - 2, { value: t.value });
		o.push(r("strong", e + t.from, e + t.to, { children: [n] }));
	}
	return o;
}
function zd(e, t, n, r) {
	function i(e, t, i) {
		return Rd(e, t, i, n, r);
	}
	function a(t, r, a) {
		let o = e.slice(t, r);
		if (!o || /^[ >+=-]/.test(o) || Pd.test(o) || o.includes("|") || !a && o.startsWith("![")) return;
		let s = i(t, r, a);
		if (s !== void 0) return n("paragraph", t, r, { children: s });
	}
	function o(t) {
		if (!t.text.startsWith("|") || !t.text.endsWith("|") || t.text.length < 2) return;
		let n = [], r = t.from;
		for (let i = r + 1; i < t.to; i++) {
			if (e[i] !== "|") continue;
			let t = r + 1, a = i;
			for (; e[t] === " " && t < a;) t++;
			for (; e[a - 1] === " " && a > t;) a--;
			n.push({
				from: t,
				to: a,
				left: r,
				right: i
			}), r = i;
		}
		return n;
	}
	function s(e, t) {
		let r = [];
		for (let a = 0; a < t.length; a++) {
			let o = t[a], s = i(o.from, o.to, "row");
			if (s === void 0) return;
			r.push(n("tableCell", o.left, a === t.length - 1 ? e.to : o.right, { children: s }));
		}
		return n("tableRow", e.from, e.to, { children: r });
	}
	let c = [];
	for (let r = 0; r < t.length;) {
		let i = t[r];
		if (!i.text) {
			r++;
			continue;
		}
		let l = Pd.exec(i.text);
		if (l) {
			let e = [], o = l[1].length > 1, s = o ? l[1].at(-1) : l[1];
			for (; r < t.length;) {
				let i = t[r], c = Pd.exec(i.text);
				if (!c || (o ? c[1].length === 1 || c[1].at(-1) !== s : c[1] !== s)) break;
				let l = a(i.from + c[0].length, i.to, "item");
				if (l === void 0) return;
				e.push(n("listItem", i.from, i.to, {
					checked: null,
					children: [l]
				})), r++;
			}
			let u = r;
			for (; u < t.length && !t[u].text;) u++;
			if (u < t.length && Pd.test(t[u].text)) return;
			c.push(n("list", i.from, t[r - 1].to, {
				ordered: o,
				start: o ? parseInt(l[1], 10) : null,
				children: e
			}));
		} else if (i.text.startsWith("|")) {
			let a = o(i), l = t[r + 1] && o(t[r + 1]);
			if (!a?.length || !l || a.length !== l.length) return;
			let u = [];
			for (let t of l) {
				let n = e.slice(t.from, t.to);
				if (!/^:?-+:?$/.test(n)) return;
				u.push(n.startsWith(":") ? n.endsWith(":") ? "center" : "left" : n.endsWith(":") ? "right" : null);
			}
			let d = s(i, a);
			if (d === void 0) return;
			let f = [d];
			for (r += 2; r < t.length && t[r].text.startsWith("|");) {
				let e = o(t[r]);
				if (!e || e.length !== a.length) return;
				let n = s(t[r], e);
				if (n === void 0) return;
				f.push(n), r++;
			}
			c.push(n("table", i.from, t[r - 1].to, {
				align: u,
				children: f
			}));
		} else {
			let e = a(i.from, i.to);
			if (e === void 0) return;
			c.push(e), r++;
		}
		if (r < t.length && t[r].text) return;
	}
	return c;
}
function Bd(e, t, n, r, i) {
	let a = i ?? Id(e, r);
	if (a === void 0) return;
	let o = /* @__PURE__ */ new Map(), s = (i, a, s) => {
		let c = e.slice(i, a);
		if (o.has(c)) return o.get(c);
		if (n?.has(c)) {
			let e = n.get(c);
			return o.set(c, e), s && e !== void 0 && t?.noteInlineReuse?.(s), e;
		}
		if (t) {
			let e = t.readInline(r?.placeholders ? "\0opaque\0" + c : c);
			if (e.hit) return s && e.value !== void 0 && t.noteInlineReuse?.(s), o.set(c, e.value), e.value;
		}
		let l = Ld(c, !!r?.placeholders);
		return o.set(c, l), t?.writeInline(r?.placeholders ? "\0opaque\0" + c : c, l), l;
	}, c = 0, l = zd(e, a, (e) => (e !== "rmdOpaque" && (c += 1), null), s);
	if (l === void 0) return;
	let u = l.length;
	return {
		nodeCount: c,
		blockCount: u,
		source: e,
		rows: o,
		overflowAt(t) {
			let n = t + 1;
			if (!Number.isSafeInteger(n) || n < 1 || n > c) return;
			let r = 0, i, o = {};
			try {
				zd(e, a, (e, t, a) => {
					if (e === "rmdOpaque") return null;
					if (r += 1, r === n) throw i = {
						start: t,
						end: a
					}, o;
					return null;
				}, s);
			} catch (e) {
				if (e !== o) throw e;
			}
			return i;
		},
		emit(t) {
			let n = zd(e, a, (e, n, r, i) => t(e, n, r, i), s);
			if (n === void 0) throw Error("Fast Markdown plan became invalid during emission.");
			return n;
		}
	};
}
function Vd(e, t, n, r) {
	let i = r?.placeholders ? Id(e, r) : void 0;
	if (r?.placeholders && !i) return;
	let a = r ? "\0" + (r.allowBraces ? "braces" : "") + (r.placeholders ? "opaque" : "") + "\0" + e : e;
	if (t) {
		let e = t.readPlan(a);
		if (e.hit) return e.value !== void 0 && t.notePlanReuse?.(), e.value;
	}
	let o = Bd(e, t, n, r, i);
	return t?.writePlan(a, o), o;
}
// src/local/markdown/markdown-blocks.ts
var Hd = hd.configure(Nd), Ud = "rmdFastBlock", Wd = "[^";
function Gd(e, t, n, r, i, a, o) {
	let s = n?.source === e ? n.logicalLineCount : uf(e), c = Kd(e, r, a, o);
	if (c) return {
		tree: cf(e, [sf(0, e.length, c)]),
		stats: {
			fastBlocks: c.blockCount,
			generalBlocks: 0,
			fastCharacters: e.length,
			generalCharacters: 0,
			lines: s
		}
	};
	let l = (i ?? Jd(e)).candidates, u = [], d = 0;
	for (let t = 0; t < l.length; t++) {
		let n = l[t];
		if (n.from < d || !Zd(e, n) || !Qd(e, n, l[t - 1])) continue;
		let i = Kd(e.slice(n.from, n.to), r, a, o ? {
			...o,
			offset: n.from
		} : void 0);
		i && (u.push({
			from: n.from,
			to: n.to,
			plan: i
		}), d = n.to);
	}
	if (!u.length) return qd(e, t, s);
	let f = t(tf(e, u));
	if (!f || !Array.isArray(f.children) || nf(f.children, u) || rf(e, f.children, u)) return qd(e, t, s);
	let p = 0, m = 0;
	for (let e of u) p += e.to - e.from, m += e.plan.blockCount;
	return {
		tree: cf(e, of(f.children, u)),
		stats: {
			fastBlocks: m,
			generalBlocks: f.children.length,
			fastCharacters: p,
			generalCharacters: e.length - p,
			lines: s
		}
	};
}
function Kd(e, t, n, r) {
	if (!e.length || typeof Vd != "function") return;
	let i;
	try {
		let a = r?.shield?.(e, r.offset ?? 0);
		if (a !== void 0) {
			let e = Vd(a, t, void 0, { allowBraces: !0 });
			if (e) return {
				...e,
				shieldOnly: !0,
				emit() {
					throw Error("Cannot emit an advisory shielding plan");
				}
			};
		}
		i = Vd(e, t, n, r);
	} catch {
		return;
	}
	return i && Number.isInteger(i.blockCount) && i.blockCount > 0 && typeof i.emit == "function" && typeof i.overflowAt == "function" ? i : void 0;
}
function qd(e, t, n) {
	let r = t(e);
	return {
		tree: r,
		stats: {
			fastBlocks: 0,
			generalBlocks: r && Array.isArray(r.children) ? r.children.length : 0,
			fastCharacters: 0,
			generalCharacters: e.length,
			lines: n
		}
	};
}
function Jd(e) {
	let t;
	try {
		t = Hd.parse(e.replace(/\r(?!\n)/g, "\n"));
	} catch {
		return {
			candidates: [],
			maxDepth: 0,
			codeRanges: []
		};
	}
	let n = [];
	for (let e = t.topNode.firstChild; e; e = e.nextSibling) n.push({
		from: e.from,
		to: e.to,
		type: e.type.name
	});
	let r = 0, i = 0, a = [], o = /* @__PURE__ */ new Set([
		"Blockquote",
		"BulletList",
		"OrderedList"
	]);
	return t.iterate({
		enter(e) {
			o.has(e.name) && (r++, i = Math.max(i, r)), (e.name === "FencedCode" || e.name === "CodeBlock") && a.push({
				start: e.from,
				end: e.to
			});
		},
		leave(e) {
			o.has(e.name) && r--;
		}
	}), {
		candidates: n,
		maxDepth: i,
		codeRanges: a
	};
}
var Yd = /* @__PURE__ */ new WeakMap();
function Xd(e, t = !0) {
	let n = Yd.get(e) ?? {}, r = t ? "all" : "outer";
	if (n[r]) return n[r];
	let i = {
		codeRanges: [],
		definitions: [],
		mathLiterals: []
	}, a = [e];
	for (; a.length;) {
		let e = a.pop(), n = e.position?.start?.offset, r = e.position?.end?.offset;
		e.type === "code" && Number.isInteger(n) && Number.isInteger(r) && i.codeRanges.push({
			start: n,
			end: r
		}), e.type === "footnoteDefinition" && Number.isInteger(n) && Number.isInteger(r) && i.definitions.push({
			start: n,
			end: r
		});
		let o = [
			"image",
			"imageReference",
			"definition"
		].includes(e.type);
		if (o || e.type === "link" || e.type === "linkReference") {
			let t = o ? n : e.children?.at(-1)?.position?.end?.offset ?? n;
			Number.isInteger(t) && Number.isInteger(r) && i.mathLiterals.push({
				start: t,
				end: r
			});
		}
		if (!t && e.type === "footnoteDefinition") continue;
		let s = e.children ?? [];
		for (let e = s.length - 1; e >= 0; e--) a.push(s[e]);
	}
	return n[r] = i, Yd.set(e, n), i;
}
function Zd(e, t) {
	return Number.isInteger(t.from) && Number.isInteger(t.to) && t.from >= 0 && t.to <= e.length && t.from < t.to && (t.from === 0 || lf(e.charCodeAt(t.from - 1))) && (t.to === e.length || lf(e.charCodeAt(t.to)));
}
function Qd(e, t, n) {
	if (t.from === 0) return !0;
	let r = $d(e, t.from);
	return ef(e, r) ? !0 : !(!n || n.to !== r || n.type === "LinkReference" && t.type === "Paragraph" && e.startsWith(Wd, n.from));
}
function $d(e, t) {
	let n = t;
	return e.charCodeAt(n - 1) === 10 && n--, n > 0 && e.charCodeAt(n - 1) === 13 && n--, n;
}
function ef(e, t) {
	for (let n = t; n > 0;) {
		let t = e.charCodeAt(n - 1);
		if (lf(t)) return !0;
		if (t !== 32 && t !== 9) return !1;
		n--;
	}
	return !0;
}
function tf(e, t) {
	let n = [], r = 0;
	for (let i of t) n.push(e.slice(r, i.from)), n.push(e.slice(i.from, i.to).replace(/[^\r\n]/g, " ")), r = i.to;
	return n.push(e.slice(r)), n.join("");
}
function nf(e, t) {
	let n = 0, r = -1;
	for (let i of e) {
		let e = i?.position?.start?.offset, a = i?.position?.end?.offset;
		if (!Number.isInteger(e) || !Number.isInteger(a) || a < e || e < r) return !0;
		for (r = e; n < t.length && t[n].to <= e;) n++;
		let o = t[n];
		if (o && o.from < a && e < o.to) return !0;
	}
	return !1;
}
function rf(e, t, n) {
	let r = new Set(n.map((e) => e.from)), i = [...t];
	for (; i.length;) {
		let t = i.pop();
		if (t?.type === "footnoteDefinition") {
			let n = t.position?.end?.offset, i = Number.isInteger(n) ? af(e, n) : void 0;
			if (i !== void 0 && r.has(i)) return !0;
		}
		let n = t?.children;
		if (Array.isArray(n)) for (let e of n) i.push(e);
	}
	return !1;
}
function af(e, t) {
	let n = t;
	for (; n < e.length && (e.charCodeAt(n) === 32 || e.charCodeAt(n) === 9);) n++;
	if (n >= e.length) return;
	let r = e.charCodeAt(n);
	if (r === 10) return n + 1;
	if (r === 13) return n + (e.charCodeAt(n + 1) === 10 ? 2 : 1);
}
function of(e, t) {
	let n = [], r = 0;
	for (let i of e) {
		let e = i.position.start.offset;
		for (; r < t.length && t[r].to <= e;) n.push(sf(t[r].from, t[r].to, t[r].plan)), r++;
		n.push(i);
	}
	for (; r < t.length;) n.push(sf(t[r].from, t[r].to, t[r].plan)), r++;
	return n;
}
function sf(e, t, n) {
	return {
		type: Ud,
		position: {
			start: { offset: e },
			end: { offset: t }
		},
		plan: n
	};
}
function cf(e, t) {
	return {
		type: "root",
		position: {
			start: { offset: 0 },
			end: { offset: e.length }
		},
		children: t
	};
}
function lf(e) {
	return e === 10 || e === 13;
}
function uf(e) {
	if (!e.length) return 0;
	let t = 1;
	for (let n = 0; n < e.length; n++) {
		let r = e.charCodeAt(n);
		r === 10 ? t++ : r === 13 && (t++, e.charCodeAt(n + 1) === 10 && n++);
	}
	return t;
}
// src/local/source/source-context.ts
function df(e, t) {
	let n = e[t];
	if (n !== "`" && n !== "~") return;
	let r = 0;
	for (; e[t + r] === n;) r++;
	return r >= 3 ? {
		char: n,
		length: r
	} : void 0;
}
function ff(e) {
	if (!e.length) return {
		lines: [],
		maxMarkdownDepth: 0,
		potentialDepth: 0,
		fenceSpans: []
	};
	let t = [0];
	for (let n = 0; n < e.length; n++) {
		let r = e[n];
		r === "\r" ? (e[n + 1] === "\n" && n++, t.push(n + 1)) : r === "\n" && t.push(n + 1);
	}
	let n = [], r = [], i = [], a = null, o = 0, s = 0;
	for (let c = 0; c < t.length; c++) {
		let l = t[c], u = c + 1 < t.length ? t[c + 1] : e.length;
		for (; u > l && (e[u - 1] === "\r" || e[u - 1] === "\n");) u--;
		let d = e.slice(l, u), f = l, p = 0;
		for (; f < u;) {
			for (; e[f] === " " || e[f] === "	";) p += e[f] === "	" ? 4 : 1, f++;
			if (e[f] === ">") {
				p++, f++;
				continue;
			}
			let t = /^(?:[-+*]|\d{1,9}[.)])(?=[ \t])/.exec(e.slice(f, u));
			if (t) p++, f += t[0].length;
			else break;
		}
		s = Math.max(s, p);
		let m = c === 0 && e.charCodeAt(0) === 65279 ? l + 1 : l, h = 0;
		for (; e[m + h] === " " || e[m + h] === "	";) h++;
		let g = /^[ \t]*$/.test(e.slice(m, u)), _ = m;
		for (let t = 0; t < 3 && e[_] === " "; t++) _++;
		let v = !1;
		if (a) {
			let t = e.slice(_, u), n = df(t, 0);
			if (n && n.char === a.char && n.length >= a.length && /^[ \t]*$/.test(t.slice(n.length))) {
				a = null;
				let e = r[r.length - 1];
				e && (e.to = u);
			}
			v = !0;
		} else {
			let t = df(e.slice(_, u), 0);
			t && (a = {
				char: t.char,
				length: t.length
			}, v = !0, r.push({
				from: l,
				to: e.length
			}));
		}
		let y = 0, b = 0;
		if (!v && !g) {
			let t = m;
			for (;;) {
				let n = t;
				for (let t = 0; t < 3 && e[n] === " "; t++) n++;
				if (e[n] !== ">") break;
				t = n + 1, e[t] === " " && t++, y++;
			}
			let n = t;
			for (; n < u && (e[n] === " " || e[n] === "	");) n++;
			let r = /^([-+*]|\d{1,9}[.)])(?=[ \t]|$)/.exec(e.slice(n, u)), a = n - t >= 4 && i.length === 0;
			if (r && !a) {
				let e = n - m;
				for (; i.length && i[i.length - 1] >= e;) i.pop();
				i.push(e);
			} else {
				let e = n - t;
				for (; i.length && e < i[i.length - 1];) i.pop();
			}
			b = y + i.length, b > o && (o = b);
		}
		n.push({
			from: l,
			to: u,
			text: d,
			blank: g,
			indent: h,
			quoteDepth: y,
			fenced: v,
			depth: b
		});
	}
	return {
		lines: n,
		maxMarkdownDepth: o,
		potentialDepth: s,
		fenceSpans: r
	};
}
var pf = class {
	source;
	lineStarts = [0];
	logicalLines;
	factsValue;
	constructor(e) {
		this.source = e;
		for (let t = 0; t < e.length; t++) e[t] === "\n" && this.lineStarts.push(t + 1);
	}
	get logicalLineCount() {
		if (this.logicalLines !== void 0) return this.logicalLines;
		let e = this.source.length ? this.lineStarts.length : 0;
		for (let t = this.source.indexOf("\r"); t >= 0; t = this.source.indexOf("\r", t + 1)) this.source[t + 1] !== "\n" && e++;
		return this.logicalLines = e;
	}
	get facts() {
		return this.factsValue ??= ff(this.source);
	}
	lineIndexAt(e) {
		let t = 0, n = this.lineStarts.length - 1;
		for (; t < n;) {
			let r = t + n + 1 >>> 1;
			this.lineStarts[r] <= e ? t = r : n = r - 1;
		}
		return t;
	}
	lineStartAt(e) {
		return this.lineStarts[this.lineIndexAt(e)];
	}
}, mf = class {
	context;
	chunks = [];
	segments = [];
	end = 0;
	recent = 0;
	length = 0;
	constructor(e) {
		this.context = e;
	}
	get segmentCount() {
		return this.segments.length;
	}
	append(e, t, n) {
		if (!e.length) return;
		let r = this.segments.at(-1);
		r && r.step === n && r.source + (r.to - r.from) * n === t ? r.to += e.length : this.segments.push({
			from: this.length,
			to: this.length + e.length,
			source: t,
			step: n
		}), this.chunks.push(e), this.length += e.length;
	}
	generated(e, t) {
		this.append(e, t, 0);
	}
	original(e, t, n = 0, r = !1, i = !1) {
		let { source: a, lineStarts: o } = this.context;
		if (i && e === 0 && a.charCodeAt(0) === 65279 && e++, e >= t) return;
		if (!n) {
			this.append(a.slice(e, t), e, 1);
			return;
		}
		let s = this.context.lineIndexAt(e);
		for (; e < t;) {
			let i = o[s], c = o[s + 1] ?? a.length, l = Math.min(t, c), u = r ? /^(?:[ \t]{0,3}>[ \t]?)+/.exec(a.slice(i, c))?.[0].length ?? 0 : 0, d = 0;
			for (; d < n && (a[i + u] === " " || a[i + u] === "	");) u++, d++;
			let f = Math.min(l, Math.max(e, i + u));
			this.append(a.slice(f, l), f, 1), e = l, s++;
		}
	}
	finish(e) {
		this.end = e;
	}
	text() {
		return this.chunks.join("");
	}
	at(e, t) {
		if (e === this.length) return this.end;
		if (e < 0 || e > this.length || !Number.isInteger(e)) return t;
		let n = this.segments[this.recent];
		if (!n || e < n.from || e >= n.to) {
			let t = 0, r = this.segments.length - 1;
			for (; t < r;) {
				let n = t + r + 1 >>> 1;
				this.segments[n].from <= e ? t = n : r = n - 1;
			}
			this.recent = t, n = this.segments[t];
		}
		return n ? n.source + (e - n.from) * n.step : t;
	}
}, hf = class extends Error {
	kind;
	limit;
	start;
	end;
	constructor(e, t, n, r) {
		super(e === "parse-work" ? `Parsing work exceeds the limit of ${t}.` : `Markdown nesting exceeds the ${t}-level limit.`), this.kind = e, this.limit = t, this.start = n, this.end = r, this.name = "ParseBudgetError";
	}
}, gf = class {
	limits;
	usedWork = 0;
	observedDepth = 0;
	constructor(e) {
		this.limits = e;
	}
	get parseWork() {
		return this.usedWork;
	}
	get maxDepth() {
		return this.observedDepth;
	}
	charge(e, t, n) {
		if (!(!Number.isFinite(e) || e <= 0) && (this.usedWork += Math.floor(e), this.usedWork > this.limits.maxParseWork)) throw new hf("parse-work", this.limits.maxParseWork, t, Math.max(t + 1, n));
	}
	observeDepth(e, t, n) {
		if (!Number.isFinite(e) || e <= 0) e > this.observedDepth && (this.observedDepth = e);
		else if (e > this.observedDepth && (this.observedDepth = e), e > this.limits.maxMarkdownDepth) throw new hf("markdown-depth", this.limits.maxMarkdownDepth, t, Math.max(t + 1, n));
	}
}, _f = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, vf = 128, yf = /* @__PURE__ */ new Set([
	"pre",
	"code",
	"script",
	"style",
	"textarea",
	"title",
	"xmp",
	"iframe",
	"noembed",
	"noframes",
	"plaintext"
]), bf = "local.recovery.unclosed", xf = "local.recovery.mismatch", Sf = "local.recovery.stray-close";
function Cf(e, t) {
	let n = e.lines, r = 0, i = n.length - 1;
	for (; r < i;) {
		let e = r + i + 1 >>> 1;
		n[e].from <= t ? r = e : i = e - 1;
	}
	return r;
}
function wf(e, t) {
	let n = "";
	for (let r = t + 2; r < e.length - 1; r += 1) {
		let t = e[r];
		if (n) t === "\\" ? r += 1 : t === n && (n = "");
		else if (t === "\"" || t === "'") n = t;
		else if (t === "}" && e[r + 1] === "}") return r + 2;
	}
	return t + 2;
}
function Tf(e, t, n, r) {
	for (let i = t; i + 1 < n; i += 1) if (e[i] === "\\") {
		if (e[i + 1] === r) return i + 2;
		i += 1;
	}
	return null;
}
function Ef(e, t, n) {
	for (let r = t; r + 2 < n; r += 1) if (e[r] === "\\") {
		if (e[r + 1] === "\\" && e[r + 2] === "]" && /\s/.test(e[r - 1] ?? "")) return r + 3;
		r += 1;
	}
	return null;
}
function Df(e, t, n) {
	if (e.startsWith("\\\\[", t)) return Ef(e, t + 3, n) ?? t + 3;
	if (e[t] === "\\" && e[t + 1] === "(") return Tf(e, t + 2, n, ")") ?? t + 2;
	if (e[t] === "\\" && e[t + 1] === "[") return Tf(e, t + 2, n, "]") ?? t + 2;
	if (e[t] !== "$") return null;
	if (e[t + 1] === "$") {
		for (let r = t + 2; r + 1 < n; r += 1) if (e[r] === "\\") r += 1;
		else if (e[r] === "$" && e[r + 1] === "$") return r + 2;
		return t + 2;
	}
	for (let r = t + 1; r < n; r += 1) {
		let n = e[r];
		if (n === "\\") {
			r += 1;
			continue;
		}
		if (n === "\n" || n === "\r") break;
		if (n !== "$") continue;
		let i = e.slice(t + 1, r), a = e[r + 1];
		if (!i.trim() || a !== void 0 && a >= "0" && a <= "9") break;
		return r + 1;
	}
	return t + 1;
}
function Of(e, t) {
	let n = e.slice(t.from, t.to), r = 0;
	for (;;) {
		let e = r;
		for (let t = 0; t < 3 && n[e] === " "; t += 1) e += 1;
		if (n[e] !== ">") break;
		e += 1, n[e] === " " && (e += 1), r = e;
	}
	let i = r;
	for (; n[i] === " " || n[i] === "	";) i += 1;
	if (i - r > 3 && t.depth === 0) return !1;
	let a = /^(?:[-+*]|\d{1,9}[.)])[ \t]+/.exec(n.slice(i));
	return a && (i += a[0].length), /^#{1,6}(?:[ \t]+|$)/.test(n.slice(i));
}
function kf(e) {
	return e !== void 0 && (e.blank || /^[ \t]*(?:>[ \t]*)*$/.test(e.text));
}
function Af(e, t, n) {
	for (let r = e.length - 1; r >= 0; --r) if (n(), t(e[r])) return r;
	return -1;
}
function jf(e, t) {
	let n = [], r = [];
	t.charge(e.length, 0, Math.max(1, e.length));
	let i = (e, t, r, i) => {
		r.end <= r.start || n.push({
			code: e,
			causeRange: {
				start: t.start,
				end: t.end
			},
			affectedRange: {
				start: r.start,
				end: r.end
			},
			action: "literal-fallback",
			boundary: i
		});
	}, a = (e, n) => n === "theme" ? "theme" : t.isKnown(e) ? "rmd" : t.isHtmlName(n) ? "html" : _f.test(e) ? "rmd" : "ignore", o = (e, t) => {
		let n = r[e + 1];
		if (!n) return;
		let a = r.slice(e + 1).filter((e) => e.kind === "rmd" && e.structural);
		if (!a.length) return;
		let o = n.start;
		for (let e of a) i(xf, {
			start: e.start,
			end: e.end
		}, {
			start: o,
			end: t
		}, "container-end");
	}, s = 0, c = 0;
	for (; c < e.length;) {
		for (; s < t.definitions.length && t.definitions[s].end <= c;) s += 1;
		let l = t.definitions[s];
		if (l && l.start <= c) {
			c = l.end;
			continue;
		}
		let u = r.length > 0;
		if (!u) {
			let n = t.codeEndAt(c);
			if (n !== null && n > c) {
				c = Math.min(n, e.length);
				continue;
			}
		}
		let d = Df(e, c, e.length);
		if (d !== null) {
			c = d;
			continue;
		}
		let f = t.protectedEnd(c, u);
		if (f !== null && f > c) {
			c = Math.min(f, e.length);
			continue;
		}
		if (e.startsWith("<!--", c)) {
			let t = e.indexOf("-->", c + 4);
			c = t < 0 ? e.length : t + 3;
			continue;
		}
		if (e.startsWith("{{", c)) {
			c = wf(e, c);
			continue;
		}
		if (e[c] !== "<") {
			c += 1;
			continue;
		}
		let p = t.readTag(c);
		if (!p) {
			c += 1;
			continue;
		}
		let m = p.name.toLowerCase(), h = a(p.name, m), g = Math.max(p.end, c + 1);
		if (h === "theme" || h === "ignore" || p.name.length > vf) {
			c = g;
			continue;
		}
		if (!p.complete) {
			if (h === "html" || p.closing && !t.isKnown(p.name) && !t.beginsLine(c) || !p.closing && !t.isKnown(p.name) && !t.beginsLine(c)) {
				c = g;
				continue;
			}
			let n = null;
			for (let i = e.indexOf("<", g); i >= 0; i = e.indexOf("<", i + 1)) {
				if (t.facts.lines[Cf(t.facts, i)]?.fenced || t.codeEndAt(i) !== null) continue;
				if (e.startsWith("<!--", i)) {
					let t = e.indexOf("-->", i + 4);
					if (t < 0) break;
					i = t + 2;
					continue;
				}
				let a = /^<\/([a-z][a-z0-9-]*)\s*>/.exec(e.slice(i, i + 256));
				if (a && Af(r, (e) => e.name === a[1], () => t.charge(1, i, i + a[0].length)) >= 0) {
					n = i;
					break;
				}
			}
			let a = n ?? Mf(e, c, c, t);
			if (i(bf, {
				start: c,
				end: g
			}, {
				start: c,
				end: a ?? e.length
			}, n === null ? a === null ? "eof" : "fragment" : "container-end"), n !== null) {
				c = n;
				continue;
			}
			break;
		}
		if (h === "html") {
			if (p.closing) {
				let e = Af(r, (e) => e.kind === "html" && e.lower === m, () => t.charge(1, c, g));
				e >= 0 && (o(e, c), r.length = e), c = g;
				continue;
			}
			if (p.self || t.isVoidHtml(m)) {
				c = g;
				continue;
			}
			if (yf.has(m)) {
				let n = t.rawHtmlEnd(m, p.end, u);
				c = n === null ? e.length : Math.max(n, g);
				continue;
			}
			r.push({
				name: p.name,
				lower: m,
				start: c,
				end: p.end,
				kind: "html",
				known: !1,
				structural: !1,
				complete: !0,
				pendingMark: n.length
			}), c = g;
			continue;
		}
		if (p.closing) {
			let e = Af(r, (e) => e.kind === "rmd" && e.name === p.name, () => t.charge(1, c, g));
			if (e < 0) {
				if (!t.isPaired(p.name)) {
					c = g;
					continue;
				}
				i(Sf, {
					start: c,
					end: p.end
				}, {
					start: c,
					end: p.end
				}, "token");
			} else {
				let t = r[e];
				t.known ? o(e, c) : n.length = t.pendingMark, r.length = e;
			}
			c = g;
			continue;
		}
		if (p.self || !t.isPaired(p.name)) {
			c = g;
			continue;
		}
		let _ = t.isKnown(p.name);
		r.push({
			name: p.name,
			lower: m,
			start: c,
			end: p.end,
			kind: "rmd",
			known: _,
			structural: _ || t.beginsLine(c),
			complete: !0,
			pendingMark: n.length
		}), c = g;
	}
	let l = -1;
	for (let n of r) {
		if (n.kind !== "rmd" || !n.structural || n.start < l) continue;
		let r = e.length, a = "eof";
		if (n.complete) {
			let i = Nf(e, n.end, n.start, t);
			i !== null && (r = i, a = "heading");
		}
		if (a === "eof") {
			let i = Mf(e, n.end, n.start, t);
			i !== null && (r = i, a = "fragment");
		}
		i(bf, {
			start: n.start,
			end: n.end
		}, {
			start: n.start,
			end: r
		}, a), l = r;
	}
	return Pf(n);
}
function Mf(e, t, n, r) {
	let { facts: i } = r, a = i.lines[Cf(i, n)];
	if (!a || a.quoteDepth === 0 && a.depth === 0) return null;
	let o = Cf(i, Math.min(t, e.length)) + 1;
	for (; o < i.lines.length; o += 1) {
		let e = i.lines[o];
		if (!(!e || e.blank || e.fenced) && (e.quoteDepth < a.quoteDepth || e.depth < a.depth)) return e.from;
	}
	return null;
}
function Nf(e, t, n, r) {
	let { facts: i } = r, a = i.lines;
	if (!a.length) return null;
	let o = a[Cf(i, n)], s = Cf(i, Math.min(t, e.length)) + 1;
	if (s >= a.length) return null;
	r.charge(Math.max(1, e.length - t), Math.max(0, t), e.length);
	let c = 0, l = a[s].from;
	for (; l < e.length;) {
		for (; c < r.definitions.length && r.definitions[c].end <= l;) c += 1;
		let t = r.definitions[c];
		if (t && t.start <= l) {
			l = t.end;
			continue;
		}
		s = Cf(i, l);
		let n = a[s];
		if (n && l === n.from) {
			let t = s > 0 ? a[s - 1] : void 0;
			if (n.quoteDepth === o.quoteDepth && n.depth === o.depth && !n.fenced && kf(t) && Of(e, n)) return n.from;
		}
		let u = n !== void 0 && n.depth > 0, d = r.codeEndAt(l);
		if (d !== null && d > l) {
			l = Math.min(d, e.length);
			continue;
		}
		let f = Df(e, l, e.length);
		if (f !== null) {
			l = f;
			continue;
		}
		let p = r.protectedEnd(l, u);
		if (p !== null && p > l) l = Math.min(p, e.length);
		else if (e.startsWith("<!--", l)) {
			let t = e.indexOf("-->", l + 4);
			l = t < 0 ? e.length : t + 3;
		} else if (e.startsWith("{{", l)) l = wf(e, l);
		else if (e[l] === "<") {
			let e = r.readTag(l);
			if (!e) {
				l += 1;
				continue;
			}
			if (!e.complete) return null;
			let t = e.name.toLowerCase();
			if (!e.closing && yf.has(t) && r.isHtmlName(t) && !e.self) {
				let n = r.rawHtmlEnd(t, e.end, u);
				if (n === null) return null;
				l = Math.max(n, l + 1);
				continue;
			}
			l = Math.max(e.end, l + 1);
		} else l += 1;
	}
	return null;
}
function Pf(e) {
	let t = e.map((e, t) => ({
		record: e,
		index: t
	})).sort((e, t) => e.record.affectedRange.start - t.record.affectedRange.start || e.record.affectedRange.end - t.record.affectedRange.end || e.record.causeRange.start - t.record.causeRange.start || e.index - t.index), n = [];
	for (let { record: e } of t) {
		let t = n[n.length - 1];
		t && e.affectedRange.start < t.affectedRange.end ? e.affectedRange.end > t.affectedRange.end && (t.affectedRange = {
			start: t.affectedRange.start,
			end: e.affectedRange.end
		}) : n.push({
			code: e.code,
			causeRange: {
				start: e.causeRange.start,
				end: e.causeRange.end
			},
			affectedRange: {
				start: e.affectedRange.start,
				end: e.affectedRange.end
			},
			action: e.action,
			boundary: e.boundary
		});
	}
	let r = n.map(({ affectedRange: e }) => e), i = /* @__PURE__ */ new Map();
	for (let e of r) i.set(e.start, e.end);
	return {
		recoveries: n,
		ranges: r,
		byStart: i
	};
}
// src/local/html/html-recovery.ts
var Ff = b.HTML, If = /* @__PURE__ */ new Set([
	"html",
	"head",
	"body"
]), Lf = {
	b: "strong",
	strong: "strong",
	i: "emphasis",
	em: "emphasis",
	s: "delete",
	del: "delete",
	u: "underline",
	mark: "mark",
	sup: "sup",
	sub: "sub"
}, Rf = /* @__PURE__ */ new Set([
	"br",
	"hr",
	"img",
	"col"
]), zf = /* @__PURE__ */ new Set([
	"id",
	"title",
	"lang",
	"dir"
]), Bf = {
	a: we,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...D
}, Vf = le, Hf = {
	table: [
		"caption",
		"colgroup",
		"thead",
		"tbody",
		"tfoot"
	],
	colgroup: ["col"],
	thead: ["tr"],
	tbody: ["tr"],
	tfoot: ["tr"],
	tr: ["th", "td"],
	col: []
}, Uf = 100;
function Wf(e, t, n) {
	let r = "";
	for (let i = t; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") return i + 1;
	}
	return -1;
}
function Gf(e, t, n) {
	if (e.startsWith("<!-->", t)) return Math.min(n, t + 5);
	if (e.startsWith("<!--->", t)) return Math.min(n, t + 6);
	let r = e.indexOf("-->", t + 4);
	return r < 0 || r + 3 > n ? n : r + 3;
}
function Kf(e, t, n, r, i) {
	let a = i === void 0 ? null : i.toLowerCase();
	if (a !== null && !De.has(a) && !le.has(a)) return null;
	let o = a !== null && Vf.has(a), s = [], c = null, l = o, u = t;
	for (; u < n;) {
		let t = e.indexOf("<", u), i = t < 0 || t >= n ? n : t;
		if (e.slice(u, i).includes("{{")) return null;
		if (t < 0 || t >= n) break;
		if (u = t, e.startsWith("<!--", u)) {
			u = Gf(e, u, n);
			continue;
		}
		let a = /^<(\/?)([A-Za-z][A-Za-z0-9:-]*)/.exec(e.slice(u, Math.min(n, u + 80)));
		if (!a) {
			u += 1;
			continue;
		}
		let d = u + a[0].length, f = e[d];
		if (!(f === ">" || f === "/" || f !== void 0 && /\s/.test(f))) {
			u = d;
			continue;
		}
		let p = a[2].toLowerCase(), m = a[1] === "/", h = Wf(e, d, n);
		if (h < 0) return null;
		let g = {
			name: p,
			closing: m,
			self: !m && /\/\s*$/.test(e.slice(d, h - 1)),
			start: u,
			end: h
		};
		if (r.has(p)) return null;
		if (m) {
			if (p !== "table" && !le.has(p) && !De.has(p) || p !== "table" && le.has(p) && !o && !s.some((e) => e.name === "table")) return null;
			let e = -1;
			for (let t = s.length - 1; t >= 0; --t) if (s[t].name === p) {
				e = t;
				break;
			}
			e >= 0 ? s.length = e : c ??= g, u = g.end;
		} else {
			if (p === "table") l = !0;
			else if (le.has(p)) {
				if (!o && !s.some((e) => e.name === "table")) return null;
			} else if (!De.has(p)) return null;
			if (If.has(p)) return null;
			if (!Rf.has(p) && !g.self) {
				if (p === "code" || p === "pre") {
					let t = RegExp(`</${p}\\s*>`, "gi");
					t.lastIndex = g.end;
					let r = t.exec(e);
					if (r && r.index < n) {
						u = r.index + r[0].length;
						continue;
					}
					s.push(g), u = n;
					continue;
				}
				s.push(g);
			}
			u = g.end;
		}
	}
	return s.length > 0 ? {
		tableMode: l,
		contextTag: a,
		strayClose: c,
		unclosed: s[0]
	} : {
		tableMode: l,
		contextTag: a,
		strayClose: c,
		unclosed: null
	};
}
function qf(e) {
	if (!e.includes("&")) return e.replace(/\u0000/g, "�");
	try {
		let t = y(e.replace(/</g, "&lt;"), { scriptingEnabled: !1 }), n = "", r = (e) => {
			if (e.nodeName === "#text") n += e.value;
			else {
				for (let t of e.childNodes ?? []) r(t);
				if (e.content?.childNodes) for (let t of e.content.childNodes) r(t);
			}
		};
		for (let e of t.childNodes) r(e);
		return n.replace(/\u0000/g, "�");
	} catch {
		return e.replace(/\u0000/g, "�");
	}
}
function Jf(e) {
	return e.trim().replace(/[\u0000- ]+/g, "");
}
function Yf(e, t) {
	let n = /^([a-z][a-z0-9+.-]*):/i.exec(Jf(e));
	if (!n) return !1;
	let r = n[1].toLowerCase();
	return t === "image" ? r !== "http" && r !== "https" : r !== "http" && r !== "https" && r !== "mailto" && r !== "tel";
}
function Xf(e, t) {
	let n = {};
	for (let r of t.attrs) {
		if (r.prefix || r.namespace || r.value.includes("{{")) return null;
		let t = r.name.toLowerCase();
		if (t === "class" || t === "style" || /^on[a-z]/i.test(t)) return null;
		if (t === "align" && Ee.has(e)) {
			let e = Ae(r.value);
			if (!e) return null;
			n.align = e;
			continue;
		}
		let i = zf.has(t), a = /^aria-[a-z0-9_.-]+$/.test(t), o = /^data-[a-z0-9_.-]+$/.test(t), s = Bf[e]?.has(t) ?? !1;
		if (!i && !a && !o && !s || t === "dir" && ![
			"ltr",
			"rtl",
			"auto"
		].includes(r.value.trim().toLowerCase()) || t === "id" && r.value.trim() === "" || (t === "width" || t === "height") && !/^\d{1,6}$/.test(r.value.trim()) || t === "start" && !/^-?\d{1,9}$/.test(r.value.trim()) || !k(t, r.value) || (t === "href" || t === "src") && Yf(r.value, t === "src" ? "image" : "link")) return null;
		n[t] = r.value;
	}
	return e === "details" && Object.hasOwn(n, "open") && (n.open = "true"), n;
}
function Zf(e, t, n, r, i, a) {
	if (!Number.isInteger(t) || !Number.isInteger(n) || t < 0 || n > e.length || n <= t) return null;
	let o = Kf(e, t, n, i, a);
	if (o === null) return null;
	let s = n - t, c = (e) => Math.max(0, Math.min(s, e)), l = (e) => t + c(e), u = [], d = [];
	o.strayClose && u.push({
		start: o.strayClose.start,
		end: o.strayClose.end
	}), o.unclosed && u.push({
		start: o.unclosed.start,
		end: o.unclosed.end
	});
	let f = o.tableMode, p = {
		scriptingEnabled: !1,
		sourceCodeLocationInfo: !0
	}, m = e.slice(t, n), h = o.contextTag === null ? y(m, p) : y(ue.createElement(o.contextTag, Ff, []), m, p);
	function g(e) {
		if (!Number.isInteger(e.startOffset) || !Number.isInteger(e.endOffset)) return null;
		let t = l(e.startOffset), n = l(e.endOffset);
		return n < t ? null : {
			start: t,
			end: n
		};
	}
	function _(e) {
		if (e.length === 0) return null;
		let r = Infinity, i = -Infinity;
		for (let t of e) r = Math.min(r, t.range.start), i = Math.max(i, t.range.end);
		return {
			start: Math.max(t, r),
			end: Math.min(n, Math.max(r, i))
		};
	}
	function v(e, r) {
		return _(e) ?? {
			start: Math.max(t, Math.min(n, r)),
			end: Math.max(t, Math.min(n, r))
		};
	}
	function b(e, t) {
		e.synthetic = !0, e.syntheticBoundary = {
			start: t.start,
			end: t.end
		}, d.push({
			start: t.start,
			end: t.end
		});
	}
	function x(e, t) {
		let n = t;
		if (e === "details") {
			let e = n.findIndex((e) => e.type === "summary");
			if (e > 0) {
				let [t] = n.splice(e, 1);
				n.unshift(t);
			}
			return n;
		}
		if (e === "li" && n.length === 1 && n[0].type === "paragraph") return n[0].children ?? [];
		if (e === "ul" || e === "ol") {
			let e = n.filter((e) => !(e.type === "comment" || e.type === "text" && !(e.value ?? "").trim()));
			return e.every((e) => e.type === "listItem") ? e : null;
		}
		return n;
	}
	function S(e, t, n, r) {
		let i = [], a = -Infinity;
		for (let t of e.childNodes) {
			let e = C(t, n + 1, r);
			if (e === null) return null;
			if (e !== void 0) {
				if (e.range.start < a) return null;
				a = e.range.end, i.push(e);
			}
		}
		return x(t, i);
	}
	function C(e, t, n) {
		if (ue.isTextNode(e)) {
			let t = e.sourceCodeLocation;
			if (!t) return null;
			let n = g(t);
			return n === null ? null : n.start === n.end ? void 0 : e.value.includes("{{") ? null : r("text", n.start, n.end, { value: e.value.replace(/\u0000/g, "�") });
		}
		if (ue.isCommentNode(e)) {
			let t = e.sourceCodeLocation;
			if (!t) return null;
			let n = g(t);
			return n === null ? null : r("comment", n.start, n.end);
		}
		return ue.isElementNode(e) ? T(e, t, n) : null;
	}
	function w(e, t, n) {
		let r = {
			attrs: t,
			children: n
		};
		if (e === "a") return t.href === void 0 ? r.type = "span" : (r.type = "link", r.url = t.href, r.title = t.title ?? null), r;
		if (/^h[1-6]$/.test(e)) return r.type = "heading", r.depth = Number(e.slice(1)), r;
		if (e === "ul" || e === "ol") {
			r.type = "list", r.ordered = e === "ol";
			let n = t.start === void 0 ? void 0 : Number(t.start);
			return e === "ol" && n !== void 0 && Number.isFinite(n) && (r.start = n), r;
		}
		return r.type = e === "p" ? "paragraph" : e === "div" ? "div" : e === "blockquote" ? "blockquote" : e === "details" ? "details" : e === "li" ? "listItem" : Lf[e] ?? e, r;
	}
	function T(t, n, i) {
		if (n > Uf || t.namespaceURI !== Ff) return null;
		let a = t.tagName.toLowerCase();
		if (If.has(a) || !De.has(a) && !(f && le.has(a))) return null;
		let o = t.sourceCodeLocation, s = !o, c = Xf(a, t);
		if (c === null) return null;
		if (a === "br" || a === "hr" || a === "img") {
			if (!o) return null;
			let e = g(o);
			if (e === null) return null;
			if (a === "br") return r("break", e.start, e.end, { attrs: c });
			if (a === "hr") return r("thematicBreak", e.start, e.end, { attrs: c });
			let t = c.width === void 0 ? void 0 : Number(c.width), n = c.height === void 0 ? void 0 : Number(c.height);
			return r("image", e.start, e.end, {
				attrs: c,
				url: c.src,
				alt: c.alt ?? "",
				title: c.title ?? null,
				...t === void 0 ? {} : { width: t },
				...n === void 0 ? {} : { height: n }
			});
		}
		if (a === "code" || a === "pre") {
			if (!o || !o.startTag) return null;
			let t = g(o);
			if (t === null) return null;
			let n = l(o.startTag.endOffset), i = o.endTag ? l(o.endTag.startOffset) : l(o.endOffset);
			if (i < n) return null;
			let s = e.slice(n, i);
			if (o.endTag === void 0 && u.push({
				start: l(o.startTag.startOffset),
				end: l(o.startTag.endOffset)
			}), a === "pre") {
				let e = /^<code(?:\s[^>]*)?>([\s\S]*)<\/code>$/.exec(s);
				return r("code", t.start, t.end, {
					attrs: c,
					value: qf(e ? e[1] : s)
				});
			}
			return r("inlineCode", t.start, t.end, {
				attrs: c,
				value: qf(s)
			});
		}
		if (le.has(a)) return D(t, a, c, n, i, o);
		let d = S(t, a, n, i);
		if (d === null) return null;
		let p = w(a, c, d), m;
		if (s) m = v(d, i), b(p, m);
		else {
			let e = g(o);
			if (e === null) return null;
			m = e, !o?.endTag && o?.startTag && u.push({
				start: l(o.startTag.startOffset),
				end: l(o.startTag.endOffset)
			});
		}
		return r(p.type ?? a, m.start, m.end, p);
	}
	function E(e, t, n, r) {
		let i = Hf[t];
		if (i === void 0) return null;
		let a = [], o = -Infinity;
		for (let t of e.childNodes) {
			if (ue.isTextNode(t)) {
				if (!t.value.trim()) continue;
				return null;
			}
			if (ue.isCommentNode(t)) continue;
			if (!ue.isElementNode(t) || t.namespaceURI !== Ff) return null;
			let e = t.tagName.toLowerCase();
			if (!i.includes(e)) return null;
			let s = Xf(e, t);
			if (s === null) return null;
			let c = D(t, e, s, n + 1, r, t.sourceCodeLocation);
			if (c === null || c.range.start < o) return null;
			o = c.range.end, a.push(c);
		}
		return a;
	}
	function D(e, t, n, i, a, o) {
		if (i > Uf) return null;
		let s = !o, c;
		if (c = t === "td" || t === "th" || t === "caption" ? S(e, t, i, a) : E(e, t, i, a), c === null) return null;
		let d, f = t === "table" ? {
			attrs: n,
			children: c
		} : {
			attrs: n,
			children: c,
			name: t
		};
		if (s) d = v(c, a), b(f, d);
		else {
			let e = g(o);
			if (e === null) return null;
			d = e, !o?.endTag && !Rf.has(t) && o?.startTag && u.push({
				start: l(o.startTag.startOffset),
				end: l(o.startTag.endOffset)
			});
		}
		return r(t === "table" ? "htmlTable" : "htmlTableElement", d.start, d.end, f);
	}
	let O = [], k = -Infinity;
	for (let e of h.childNodes) {
		let r = C(e, 0, t);
		if (r === null) return null;
		if (r !== void 0) {
			if (r.range.start < k || r.range.start < t || r.range.end > n) return null;
			k = r.range.end, O.push(r);
		}
	}
	if (O.length === 0 || !O.some((e) => !(e.type === "comment" || e.type === "text" && !(e.value ?? "").trim()))) return null;
	u.sort((e, t) => e.start - t.start || e.end - t.end), d.sort((e, t) => e.start - t.start || e.end - t.end);
	let A = u[0] ?? d[0], ee = A === void 0 ? t : Math.max(t, Math.min(n, A.start));
	return {
		nodes: O,
		recovery: {
			code: "local.html.repair",
			causeRange: {
				start: ee,
				end: A === void 0 ? ee : Math.max(ee, Math.min(n, A.end))
			},
			affectedRange: {
				start: t,
				end: n
			},
			action: "html-repair",
			boundary: "fragment"
		},
		end: n
	};
}
// src/local/html/html-details.ts
var Qf = /^\s*$/;
function $f(e) {
	return e.type !== "text" || !Qf.test(e.value ?? "");
}
function ep(e, t) {
	let n = t[0]?.range, r = t[t.length - 1]?.range;
	return n !== void 0 && r !== void 0 && Number.isInteger(n.start) && Number.isInteger(r.end) && n.start >= e.range.start && r.end <= e.range.end && n.start <= r.end ? {
		...e,
		children: t,
		range: {
			start: n.start,
			end: r.end
		}
	} : {
		...e,
		children: t
	};
}
function tp(e) {
	let t = e.children;
	if (!t || t.length === 0) return null;
	let n = t.findIndex((e) => e.type === "summary");
	if (n < 0) return null;
	let r = t.filter((e, t) => t !== n);
	return r.some($f) ? {
		summary: t[n],
		body: ep(e, r)
	} : { summary: t[n] };
}
function np(e) {
	let t = e.findIndex((e) => e.type === "summary");
	if (t >= 0) return {
		summary: e[t],
		body: e.filter((e, n) => n !== t)
	};
	let n = [], r;
	for (let t of e) {
		if (r === void 0 && t.type === "paragraph") {
			let e = tp(t);
			if (e) {
				r = e.summary, e.body && n.push(e.body);
				continue;
			}
		}
		n.push(t);
	}
	return r === void 0 ? { body: n } : {
		summary: r,
		body: n
	};
}
function rp(e) {
	let { summary: t, body: n } = np(e);
	return t === void 0 ? n : [t, ...n];
}
// src/local/parsing/parser-core.ts
var ip = "", ap = "", op = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, sp = op, cp = {
	b: "strong",
	strong: "strong",
	i: "emphasis",
	em: "emphasis",
	s: "delete",
	del: "delete",
	u: "underline",
	mark: "mark",
	sup: "sup",
	sub: "sub"
}, lp = De, up = /* @__PURE__ */ new Set([
	"br",
	"hr",
	"img"
]), dp = /* @__PURE__ */ new Set([
	"p",
	"h1",
	"h2",
	"h3",
	"h4",
	"h5",
	"h6",
	"div",
	"details",
	"blockquote",
	"pre",
	"ul",
	"ol",
	"li"
]), fp = /* @__PURE__ */ new Set([
	"paragraph",
	"heading",
	"div",
	"details",
	"blockquote",
	"code",
	"list",
	"listItem",
	"thematicBreak",
	"htmlTable"
]), pp = /* @__PURE__ */ new Set([
	"local.recovery.unclosed",
	"local.recovery.mismatch",
	"local.recovery.stray-close",
	"local.html.repair",
	"local.html.literal"
]), mp = /* @__PURE__ */ new Set([
	"id",
	"title",
	"lang",
	"dir"
]), hp = new Set(Object.values(a)), gp = /* @__PURE__ */ new Set([
	"area",
	"base",
	"br",
	"col",
	"embed",
	"hr",
	"img",
	"input",
	"link",
	"meta",
	"param",
	"source",
	"track",
	"wbr"
]), _p = {
	a: we,
	img: /* @__PURE__ */ new Set([
		"src",
		"alt",
		"width",
		"height"
	]),
	ol: /* @__PURE__ */ new Set(["start"]),
	details: /* @__PURE__ */ new Set(["open"]),
	...D
};
function vp(e) {
	if (!e.includes("&")) return e;
	try {
		let t = y(e.replace(/</g, "&lt;"), { scriptingEnabled: !1 }), n = "", r = (e) => {
			if (e.nodeName === "#text") n += e.value;
			else {
				for (let t of e.childNodes ?? []) r(t);
				if (e.content?.childNodes) for (let t of e.content.childNodes) r(t);
			}
		};
		for (let e of t.childNodes) r(e);
		return n;
	} catch {
		return e;
	}
}
function yp(e, t) {
	let n = Object.create(null), r = [], i = [], a = 0;
	for (; a < e.length;) {
		for (; a < e.length && /\s/.test(e[a]);) a += 1;
		if (a >= e.length || e[a] === "/") break;
		let o = a, s = /^[A-Za-z_:][A-Za-z0-9_.:-]*/.exec(e.slice(a));
		if (!s) {
			a += 1;
			continue;
		}
		let c = s[0].toLowerCase();
		for (a += s[0].length; a < e.length && /\s/.test(e[a]);) a += 1;
		let l = "true";
		if (e[a] === "=") {
			for (a += 1; a < e.length && /\s/.test(e[a]);) a += 1;
			let n = e[a];
			if (n === "\"" || n === "'") {
				a += 1;
				let r = e.indexOf(n, a);
				if (r < 0) {
					i.push({
						name: c,
						value: "",
						start: t + o,
						end: t + e.length
					});
					break;
				}
				l = vp(e.slice(a, r)), a = r + 1;
			} else {
				let t = a;
				for (; a < e.length && !/[\s>]/.test(e[a]);) a += 1;
				l = vp(e.slice(t, a));
			}
		}
		let u = {
			name: c,
			value: l,
			start: t + o,
			end: t + a
		};
		Object.hasOwn(n, c) || (n[c] = l), r.push(u);
	}
	return {
		attrs: n,
		entries: r,
		invalid: i
	};
}
var bp = 128, xp = Math.min(5e4, xe), Sp = 100, Cp = 1e3;
function wp() {
	let e = globalThis.performance;
	return e && typeof e.now == "function" ? e.now() : Date.now();
}
function Tp(e) {
	return Math.round(e * 1e3) / 1e3;
}
var Ep = /(?:^|[\r\n])(?:[ \t]{0,3}>|[ \t]*(?:[-+*]|\d{1,9}[.)])(?=[ \t]|[\r\n]|$))/;
function Dp(e) {
	return Ep.test(e) || e.charCodeAt(0) === 65279 && Ep.test(e.slice(1));
}
var Op = jn().use(Ia).use(Zc), kp = class extends Error {
	code;
	start;
	end;
	key;
	params;
	constructor(e, t, n, r, i = e, a) {
		super(t), this.code = e, this.start = n, this.end = r, this.key = i, this.params = a, this.name = "LocalBudgetError";
	}
};
function Ap(e, t, n, r, i) {
	let a = [];
	if (typeof e != "string" || e.length > 1e6) {
		let t = typeof e == "string" ? Oe("local.budget.document", { limit: be }) : Oe("local.parse.source");
		return {
			nodes: [],
			diagnostics: [{
				code: typeof e == "string" ? "local.budget" : "local.parse",
				message: typeof e == "string" ? `Document exceeds the ${be}-character limit.` : "Document source must be a string.",
				severity: "error",
				range: {
					start: 0,
					end: typeof e == "string" && e.length ? 1 : 0
				},
				line: 1,
				column: 1,
				messageKey: t.key,
				...t.params ? { params: t.params } : {}
			}]
		};
	}
	if (!t.ok) return {
		nodes: [],
		diagnostics: [{
			code: "local.options.invalid",
			message: t.message,
			severity: "error",
			range: {
				start: 0,
				end: 0
			},
			line: 1,
			column: 1,
			messageKey: t.key,
			...t.detail === void 0 ? {} : { params: { detail: t.detail } }
		}]
	};
	let o = t.maxSyntaxNodes, s = t.strict !== !1, c = new gf({
		maxParseWork: t.maxParseWork,
		maxMarkdownDepth: t.maxMarkdownDepth
	}), l = t.markdownBreaks, u = t.schemaByName, d = t.externalComponentNames;
	t.legacyHostNames;
	let f = (e) => u.get(e)?.form === "inline", p = u, m = [...u.keys()], h = n?.source === e ? n : new pf(e), { lineStarts: g } = h, _ = {
		markdownCalls: 0,
		fastBlocks: 0,
		generalBlocks: 0,
		fastCharacters: 0,
		generalCharacters: 0,
		mappingSegments: 0,
		sourceLines: g.length,
		maxComponentDepth: 0
	}, v = r?.counters(), y = wp(), b = 0, x = 0, S = 0, C = /* @__PURE__ */ new Map(), w = /* @__PURE__ */ new Set(), T = (n) => {
		if (w.has(n) || !Dp(n)) return;
		w.add(n);
		let r = (n === e ? h : new pf(n)).facts, i = r.maxMarkdownDepth;
		if (r.potentialDepth > t.maxMarkdownDepth || i > t.maxMarkdownDepth) {
			let e = Jd(n);
			C.set(n, e), i = e.maxDepth;
		}
		c.observeDepth(i, 0, Math.max(1, n.length));
	}, E = () => {
		if (_.parseWork = c.parseWork, _.maxMarkdownDepth = c.maxDepth, r) {
			let e = r.counters();
			_.cacheHits = e.hits - (v?.hits ?? e.hits), _.cacheMisses = e.misses - (v?.misses ?? e.misses), _.reusedBlocks = e.reusedBlocks - (v?.reusedBlocks ?? e.reusedBlocks), _.reusedRows = e.reusedRows - (v?.reusedRows ?? e.reusedRows), _.reusedItems = e.reusedItems - (v?.reusedItems ?? e.reusedItems), _.reusedAst = e.reusedAst - (v?.reusedAst ?? e.reusedAst);
		}
		_.timings = {
			shieldMs: Tp(b),
			regionMs: Tp(x),
			convertMs: Tp(S),
			totalMs: Tp(wp() - y)
		};
	}, D = (e) => {
		let t = r?.readTree(e);
		if (t?.hit) return t.value;
		let n = Op.parse(e);
		return r?.writeTree(e, n), n;
	}, O = (e, t = !0, n = { allowBraces: !0 }) => {
		if (c.charge(e.length + 1, 0, Math.max(1, e.length)), T(e), !t) {
			let t = D(e);
			return _.markdownCalls++, _.generalBlocks += t.children.length, _.generalCharacters += e.length, t;
		}
		let { tree: a, stats: o } = Gd(e, D, h, r, C.get(e), i, n);
		return _.markdownCalls++, _.fastBlocks += o.fastBlocks, _.generalBlocks += o.generalBlocks, _.fastCharacters += o.fastCharacters, _.generalCharacters += o.generalCharacters, a;
	}, A = 0, ee = 0, ne = 0, re = /* @__PURE__ */ new Set(), j = (e, t, n, r = {}) => {
		if (ee >= o) throw new kp("local.budget", `Syntax nodes exceed the limit of ${o}.`, t, n, "local.budget.nodes", { limit: o });
		return ee += 1, {
			type: e,
			id: `local-${A++}`,
			range: {
				start: t,
				end: n
			},
			...r
		};
	};
	try {
		c.charge(e.length, 0, Math.max(1, e.length)), T(e);
		let t = sl(e, l, j);
		if (t !== void 0) return _.fastBlocks = t.length, _.fastCharacters = e.length, E(), {
			nodes: t,
			diagnostics: a,
			syntaxNodes: ee,
			work: _
		};
	} catch (e) {
		if (e instanceof hf) return xe(e), E(), {
			nodes: [],
			diagnostics: a,
			work: _
		};
		if (!(e instanceof kp)) throw e;
		return N(e.code, e.message, e.start, e.end, {
			key: e.key,
			params: e.params
		}), {
			nodes: [],
			diagnostics: a
		};
	}
	let ie = new Set(e.match(/* @__PURE__ */ RegExp("[0-9]+", "g")) ?? []), ae = [], oe = [], M = [], se = [];
	function ce(e, t) {
		let n = 0, r = e.length - 1;
		for (; n <= r;) {
			let i = n + r >>> 1, a = e[i];
			if (t < a.start) r = i - 1;
			else if (t >= a.end) n = i + 1;
			else return !0;
		}
		return !1;
	}
	let ue = [], pe = +(e.charCodeAt(0) === 65279), me;
	try {
		if (me = O(e.slice(pe), !0, {
			allowBraces: !0,
			shield(e, t) {
				if (!e.includes("{{")) return;
				let n = [], r = 0, i = 0;
				for (; i < e.length;) {
					let a = e.indexOf("{{", i);
					if (a < 0) break;
					let o = et(a + t + pe, t + pe + e.length) - t - pe;
					if (o <= a || /[\r\n]/.test(e.slice(a, o))) return;
					n.push(e.slice(r, a), "v".repeat(o - a)), r = i = o;
				}
				if (n.length) return n.push(e.slice(r)), n.join("");
			}
		}), !e.includes("{{") && me.children.length === 1 && me.children[0].type === "rmdFastBlock") {
			let e = me.children[0].plan.overflowAt(o);
			if (e) throw new kp("local.budget", `Syntax nodes exceed the limit of ${o}.`, e.start + pe, e.end + pe, "local.budget.nodes", { limit: o });
		}
		let t = Xd(me), n = (e) => ({
			start: e.start + pe,
			end: e.end + pe
		});
		for (let e of t.codeRanges) ae.push(n(e));
		for (let e of t.definitions) e.end > e.start && ue.push(n(e));
		for (let e of t.mathLiterals) se.push(n(e));
		b = wp() - y;
	} catch (e) {
		return e instanceof hf ? (xe(e), E(), {
			nodes: [],
			diagnostics: a,
			work: _
		}) : e instanceof kp ? (N(e.code, e.message, e.start, e.end, {
			key: e.key,
			params: e.params
		}), {
			nodes: [],
			diagnostics: a,
			work: _
		}) : (N("local.parse", "Cannot parse the Markdown document.", 0, void 0, { key: "local.parse.markdown" }), {
			nodes: [],
			diagnostics: a
		});
	}
	ue.sort((e, t) => e.start - t.start || t.end - e.end), se.sort((e, t) => e.start - t.start);
	let he = [];
	for (let e of ue) {
		let t = he[he.length - 1];
		t && e.start < t.end ? e.end > t.end && (t.end = e.end) : he.push({ ...e });
	}
	let ge = (e) => {
		let t = 0, n = ae.length - 1;
		for (; t <= n;) {
			let r = t + n >> 1, i = ae[r];
			if (e < i.start) n = r - 1;
			else if (e >= i.end) t = r + 1;
			else return i.end;
		}
		return null;
	}, _e = 0;
	function ve(t, n, r, i, o = i + 1, s) {
		if (a.length >= 100) {
			if (r === "warning") return;
			let e = a.length - 1;
			for (; e >= 0 && a[e].severity !== "warning";) --e;
			if (e < 0) return;
			a.splice(e, 1);
		}
		let c = Math.max(0, Math.min(e.length, i)), l = Math.max(c, Math.min(e.length, Math.max(c, o))), u = 0, d = g.length - 1;
		for (; u < d;) {
			let e = Math.ceil((u + d) / 2);
			g[e] <= c ? u = e : d = e - 1;
		}
		let f = u + 1, p = n.length > 2e3 ? `${n.slice(0, ye - 1)}…` : n, m = Oe(s?.key ?? t, s?.params);
		a.push({
			code: t,
			message: p,
			severity: r,
			range: {
				start: c,
				end: l
			},
			line: f,
			column: c - g[u] + 1,
			messageKey: m.key,
			...m.params ? { params: m.params } : {}
		});
	}
	function N(e, t, n, r = n + 1, i) {
		ve(e, t, "error", n, r, i);
	}
	function P(e, t, n, r = n + 1, i) {
		ve(e, t, "warning", n, r, i);
	}
	function xe(e) {
		let t = e.kind === "parse-work" ? "local.budget.parse-work" : "local.budget.markdown-depth";
		N("local.budget", Te(t, "en", { limit: e.limit }), e.start, e.end, {
			key: t,
			params: { limit: e.limit }
		});
	}
	let Se, Ce, we = 0, De = 0, je, Me = 0;
	function Ne(t) {
		let n = e.startsWith("</theme", t), r = !n && e.startsWith("<theme", t);
		if (!n && !r) return !1;
		let i = e[t + (n ? 7 : 6)];
		return i !== void 0 && (i === ">" || i === "/" || /\s/.test(i));
	}
	function Pe(t, n) {
		let r = /^<(\/?)theme(?=[\s/>])/.exec(e.slice(t, n));
		if (!r) return null;
		let i = t + r[0].length, a = e.indexOf("\n", i), o = a < 0 ? n : Math.min(n, a), s = "", c = i;
		for (; c < o; c += 1) {
			let t = e[c];
			if (s) t === s && (s = "");
			else if (t === "\"" || t === "'") s = t;
			else if (t === ">") break;
		}
		let l = !!r[1];
		if (c >= o) {
			let n = o;
			return {
				start: t,
				end: n,
				rest: e.slice(i, n),
				closing: l,
				selfClosing: !1,
				unclosed: !0
			};
		}
		let u = e.slice(i, c);
		return {
			start: t,
			end: c + 1,
			rest: u,
			closing: l,
			selfClosing: /\/\s*$/.test(u),
			unclosed: !1
		};
	}
	function Fe(t, n) {
		let r = t;
		for (; r < n;) {
			let t = e[r];
			if (t.charCodeAt(0) === 65279 || t === " " || t === "	" || t === "\r" || t === "\n") r += 1;
			else if (e.startsWith("<!--", r)) {
				let t = e.indexOf("-->", r + 4);
				if (t < 0 || t + 3 > n) return -1;
				r = t + 3;
			} else break;
		}
		return r;
	}
	function Ie(t) {
		if (t.unclosed) return !1;
		let n = t.end;
		for (; n < e.length && (e[n] === " " || e[n] === "	" || e[n] === "\r");) n += 1;
		return n >= e.length || e[n] === "\n";
	}
	function Le(e) {
		if (/\{\{|\}\}/.test(e)) return {
			code: "local.theme.expression",
			key: "local.theme.expression",
			message: "Theme names must be static text, not expressions."
		};
		let t = e.replace(/\/\s*$/, ""), n = /^\s*name\s*=\s*(?:"([^"]*)"|'([^']*)')\s*$/.exec(t);
		if (!n) return /\bname\s*=/.test(t) ? {
			code: "local.theme.attribute",
			key: "local.theme.attribute",
			message: "Theme declarations only accept a quoted name attribute."
		} : {
			code: "local.theme.name",
			key: "local.theme.name.missing",
			message: "A theme declaration requires a quoted name attribute."
		};
		let r = n[1] ?? n[2] ?? "";
		return ke(r) ? { name: r } : {
			code: "local.theme.name",
			key: "local.theme.name.invalid",
			params: {
				name: r,
				limit: 64
			},
			message: `Theme name "${r}" must use lowercase letters, digits and single hyphens (maximum 64 characters).`
		};
	}
	function Re(e) {
		return e.replace(/&(quot|apos|amp|lt|gt);/g, (e, t) => ({
			quot: "\"",
			apos: "'",
			amp: "&",
			lt: "<",
			gt: ">"
		})[t]);
	}
	function ze(e, t) {
		let n = Object.create(null), r = 0;
		for (; r < e.length;) {
			for (; r < e.length && /\s/.test(e[r]);) r++;
			if (r >= e.length || e[r] === "/") break;
			let i = r, a = /^[A-Za-z][A-Za-z0-9_-]*/.exec(e.slice(r));
			if (!a) {
				for (N("local.attribute", "Attribute names must use lowercase kebab-case.", t + r, void 0, { key: "local.attribute.format" }); r < e.length && !/\s/.test(e[r]);) r++;
				continue;
			}
			let o = a[0];
			for (r += o.length, o.length > bp ? N("local.budget.name", `Attribute name exceeds the ${bp}-character limit.`, t + i, t + r, {
				key: "local.budget.name.attribute",
				params: { limit: bp }
			}) : sp.test(o) || N("local.attribute.name", `Attribute name ${o} must use lowercase kebab-case.`, t + i, t + r, {
				key: "local.attribute.name",
				params: { name: o }
			}); r < e.length && /\s/.test(e[r]);) r++;
			let s = "true";
			if (e[r] === "=") {
				for (r++; r < e.length && /\s/.test(e[r]);) r++;
				let n = e[r++];
				if (n !== "\"" && n !== "'") {
					N("local.attribute", `Attribute ${o} value must be quoted.`, t + Math.max(0, r - 1), void 0, {
						key: "local.attribute.value-quoted",
						params: { name: o }
					});
					break;
				}
				let i = e.indexOf(n, r);
				if (i < 0) {
					N("local.attribute", `Attribute ${o} is missing a closing quote.`, t + Math.max(0, r - 1), void 0, {
						key: "local.attribute.closing-quote",
						params: { name: o }
					});
					break;
				}
				s = Re(e.slice(r, i)), r = i + 1;
			}
			if (Object.hasOwn(n, o) ? N("local.attribute.duplicate", `Duplicate attribute ${o}.`, t + i, t + r, {
				key: "local.attribute.duplicate",
				params: { name: o }
			}) : n[o] = s, r < e.length && !/\s|\//.test(e[r])) {
				N("local.attribute", "Attributes must be separated by whitespace.", t + r, void 0, { key: "local.attribute.separator" });
				break;
			}
		}
		return n;
	}
	function Be(t, n) {
		let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, n));
		if (!r) return null;
		let i = t + r[0].length, a = n, o = e[i];
		if ((o === " " || o === "	" || o === "\n" || o === "\r") && !p.has(r[2].toLowerCase()) && !I(t)) {
			let t = e.indexOf("\n", i);
			t >= 0 && (a = Math.min(n, t));
		}
		let s = "", c = i;
		for (; c < a; c++) {
			let t = e[c];
			if (s) t === s && (s = "");
			else if (t === "\"" || t === "'") s = t;
			else if (t === ">") break;
		}
		let l = r[2];
		if (c >= a) return {
			name: l,
			closing: !!r[1],
			self: !1,
			start: t,
			end: a,
			attrs: {},
			head: i,
			unclosed: !0
		};
		l.length > bp && N("local.budget.name", `Tag name exceeds the ${bp}-character limit.`, t, t + 1 + l.length, {
			key: "local.budget.name.tag",
			params: { limit: bp }
		});
		let u = e.slice(i, c);
		return r[1] ? (u.trim() && N("local.tag.closing", `Closing tag </${l}> cannot have attributes.`, t, c + 1, {
			key: "local.tag.closing",
			params: { name: l }
		}), {
			name: l,
			closing: !0,
			self: !1,
			start: t,
			end: c + 1,
			attrs: {},
			head: i,
			unclosed: !1
		}) : {
			name: l,
			closing: !1,
			self: /\/\s*$/.test(u),
			start: t,
			end: c + 1,
			attrs: p.has(l.toLowerCase()) ? ze(u, i) : {},
			head: i,
			unclosed: !1
		};
	}
	function Ve(t, n) {
		let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, n));
		if (!r) return null;
		let i = t + r[0].length, a = n, o = e[i];
		if ((o === " " || o === "	" || o === "\n" || o === "\r") && !p.has(r[2].toLowerCase()) && !I(t)) {
			let t = e.indexOf("\n", i);
			t >= 0 && (a = Math.min(n, t));
		}
		let s = "", c = i;
		for (; c < a; c++) {
			let t = e[c];
			if (s) t === s && (s = "");
			else if (t === "\"" || t === "'") s = t;
			else if (t === ">") break;
		}
		if (c >= a) return null;
		let l = e.slice(i, c);
		return {
			name: r[2],
			closing: !!r[1],
			self: !r[1] && /\/\s*$/.test(l),
			end: c + 1
		};
	}
	function F(t, n, r, i) {
		if (!s && i && yf.has(i.toLowerCase())) return n;
		let a = /\r?\n[\t ]*\r?\n/.exec(e.slice(t, n)), o = a ? t + a.index : n;
		if (r) {
			let n = RegExp(`</${r}\\s*>`, "g");
			n.lastIndex = t;
			let i = n.exec(e);
			i && i.index < o && (o = i.index);
		}
		return o;
	}
	function I(t) {
		let n = h.lineStartAt(t);
		return /^[ \t]*$/.test(e.slice(n, t));
	}
	function He(t, n) {
		if (e[t] !== "[" || e[t + 1] !== "^") return null;
		let r = t + 2, i = Math.min(n, t + 2 + Cp);
		for (; r < i; r++) {
			let t = e[r];
			if (t === "\\" && /[!-/:-@\[\]\\^_`{|}~]/.test(e[r + 1] ?? "")) r += 1;
			else {
				if (t === "]") break;
				if (t === "[" || t === "\n" || t === "\r") return null;
			}
		}
		if (r >= i || e[r] !== "]") return null;
		let a = e.slice(t + 2, r);
		if (!a.trim()) return null;
		let o = nl(a);
		return o ? {
			label: a,
			identifier: o,
			openEnd: t + 2,
			closeEnd: r + 1
		} : null;
	}
	function Ue(t) {
		let n = He(t, e.length);
		return !n || e[n.closeEnd] !== ":" ? null : {
			label: n.label,
			identifier: n.identifier,
			bodyStart: n.closeEnd + 1
		};
	}
	function We(t, n, r = !1) {
		let i = /^<(\/?)([A-Za-z][A-Za-z0-9]*)(?=[\s/>])/.exec(e.slice(t, Math.min(n, t + 64)));
		if (!i) return null;
		let a = i[2].toLowerCase();
		if (!lp.has(a) && !(r && le.has(a))) return null;
		let o = t + i[0].length, s = "", c = o;
		for (; c < n; c++) {
			let t = e[c];
			if (s) t === s && (s = "");
			else if (t === "\"" || t === "'") s = t;
			else if (t === ">") break;
		}
		if (c >= n) return null;
		let l = e.slice(o, c), u = !!i[1], d = u ? {
			attrs: Object.create(null),
			entries: [],
			invalid: []
		} : yp(l, o);
		return {
			lower: a,
			closing: u,
			self: !u && /\/\s*$/.test(l),
			rest: l,
			attrs: d.attrs,
			entries: d.entries,
			invalid: d.invalid,
			start: t,
			head: o,
			end: c + 1
		};
	}
	function Ge(t, n, r, i) {
		let a = 1;
		for (let o = t; o < r;) {
			if (!i) {
				let e = ge(o);
				if (e !== null && e > o) {
					o = Math.min(e, r);
					continue;
				}
			}
			let t = Qe(o, r, i);
			if (t !== null) o = t;
			else if (e.startsWith("<!--", o)) {
				let t = e.indexOf("-->", o + 4);
				o = t < 0 || t + 3 > r ? r : t + 3;
			} else {
				if (e[o] === "<") {
					let e = We(o, r);
					if (e) {
						if (e.lower === n) {
							if (e.closing) {
								if (--a, a === 0) return {
									start: o,
									end: e.end
								};
							} else !e.self && !up.has(n) && (a += 1);
						} else if (!e.closing && (e.lower === "pre" || e.lower === "code") && !up.has(e.lower)) {
							let t = Ge(e.end, e.lower, r, i);
							if (t) {
								o = t.end;
								continue;
							}
						}
						o = e.end;
						continue;
					}
				}
				o++;
			}
		}
		return null;
	}
	function Ke(e, t) {
		if (!t) return {
			ok: !1,
			attr: ""
		};
		let n = Object.create(null);
		if (t.invalid.length) return {
			ok: !1,
			attr: t.invalid[0].name
		};
		for (let r of t.entries) {
			let t = r.name;
			if (t === "align" && Ee.has(e)) {
				let e = Ae(r.value);
				if (!e) return {
					ok: !1,
					attr: t
				};
				n.align = e;
				continue;
			}
			if (t === "class" || t === "style" || /^on[a-z]/.test(t)) return {
				ok: !1,
				attr: t
			};
			let i = mp.has(t), a = /^aria-[a-z0-9_.-]+$/.test(t), o = /^data-[a-z0-9_.-]+$/.test(t), s = _p[e]?.has(t) ?? !1;
			if (!i && !a && !o && !s || t === "dir" && ![
				"ltr",
				"rtl",
				"auto"
			].includes(r.value.trim().toLowerCase()) || t === "id" && r.value.trim() === "" || (t === "width" || t === "height") && !/^\d{1,6}$/.test(r.value.trim()) || t === "start" && !/^-?\d{1,9}$/.test(r.value.trim()) || !k(t, r.value)) return {
				ok: !1,
				attr: t
			};
			if (t === "href" || t === "src") {
				let e = /^([a-z][a-z0-9+.-]*):/i.exec(r.value.trim().replace(/[\u0000- ]+/g, ""));
				if (e && !((t === "src" ? "image" : "link") == "image" ? e[1].toLowerCase() === "http" || e[1].toLowerCase() === "https" : [
					"http",
					"https",
					"mailto",
					"tel"
				].includes(e[1].toLowerCase()))) return {
					ok: !1,
					attr: t
				};
			}
			n[t] = r.value;
		}
		return e === "details" && Object.hasOwn(n, "open") && (n.open = "true"), {
			ok: !0,
			attrs: n
		};
	}
	function qe(e) {
		return e.length === 1 && e[0].type === "paragraph" ? e[0].children ?? [] : e;
	}
	function Je(e) {
		return e.flatMap((e) => e.type === "paragraph" ? e.children ?? [] : [e]);
	}
	function Ye(t, n, r, i) {
		let a = t.start, o = n.end, s = () => {
			let e = nt(t.end, n.start, void 0, a, t.end, i.depth + 1, {
				footnote: i.footnote,
				indent: i.indent,
				container: i.container,
				definitions: [],
				stripBlockquote: i.stripBlockquote
			});
			return rt(t.end, n.start, e.tokens, i.indent, {
				literalHtml: i.footnote,
				stripBlockquote: i.stripBlockquote
			});
		}, c = () => qe(s()), l = (e) => {
			let t = [];
			for (let n of e) if (n.type === "list") for (let e of n.children ?? []) e.type === "listItem" && t.push(e);
			else n.type === "listItem" ? t.push(n) : n.type === "comment" || n.type === "text" && !(n.value ?? "").trim() || t.push(j("listItem", n.range.start, n.range.end, { children: n.type === "paragraph" ? n.children ?? [] : [n] }));
			return t;
		};
		switch (t.lower) {
			case "code": return j("inlineCode", a, o, { value: vp(e.slice(t.end, n.start)) });
			case "pre": {
				let i = e.slice(t.end, n.start), s = /^<code(?:\s[^>]*)?>([\s\S]*)<\/code>$/.exec(i);
				return j("code", a, o, {
					value: vp(s ? s[1] : i),
					attrs: r
				});
			}
			case "summary": return j("summary", a, o, {
				attrs: r,
				children: c()
			});
			case "details": return j("details", a, o, {
				attrs: r,
				children: rp(s())
			});
			case "p": return j("paragraph", a, o, {
				attrs: r,
				children: Je(s())
			});
			case "h1":
			case "h2":
			case "h3":
			case "h4":
			case "h5":
			case "h6": return j("heading", a, o, {
				depth: Number(t.lower.slice(1)),
				attrs: r,
				children: Je(s())
			});
			case "div": return j("div", a, o, {
				attrs: r,
				children: s()
			});
			case "blockquote": return j("blockquote", a, o, {
				attrs: r,
				children: s()
			});
			case "ul":
			case "ol": {
				let e = t.lower === "ol", n = r.start, i = e && n !== void 0 ? Number(n) : void 0;
				return j("list", a, o, {
					ordered: e,
					...e && i !== void 0 && Number.isFinite(i) ? { start: i } : {},
					attrs: r,
					children: l(s())
				});
			}
			case "li": {
				let e = s();
				return j("listItem", a, o, {
					attrs: r,
					children: e.length === 1 && e[0].type === "paragraph" ? e[0].children ?? [] : e
				});
			}
			case "a": return r.href === void 0 ? j("span", a, o, {
				attrs: r,
				children: c()
			}) : j("link", a, o, {
				url: r.href,
				title: r.title ?? null,
				attrs: r,
				children: c()
			});
			case "span": return j("span", a, o, {
				attrs: r,
				children: c()
			});
			default: return j(cp[t.lower] ?? t.lower, a, o, {
				attrs: r,
				children: c()
			});
		}
	}
	let Xe = /^ {0,3}$/, Ze = /^[ \t]*$/;
	function Qe(t, n, r) {
		let i = e[t];
		if (i === "\\") return Math.min(n, t + 2);
		if (i !== "`" && i !== "~") return null;
		let a = h.lineStartAt(t);
		if ((r ? Ze : Xe).test(e.slice(a, t))) {
			let i = /^(`{3,}|~{3,})[^\n]*(?:\n|$)/.exec(e.slice(t, n));
			if (i) {
				let a = RegExp(`^${r ? "[ \\t]*" : " {0,3}"}${i[1][0]}{${i[1].length},}[ \\t]*\\r?$`, "gm");
				a.lastIndex = t + i[0].length;
				let o = a.exec(e);
				return o && o.index < n ? Math.min(n, o.index + o[0].length) : n;
			}
		}
		if (i === "`") {
			let r = /^`+/.exec(e.slice(t, n))[0], i = e.indexOf(r, t + r.length);
			for (; i >= 0 && i < n;) {
				if (e[i - 1] !== "`" && e[i + r.length] !== "`") return i + r.length;
				i = e.indexOf(r, i + r.length);
			}
			return t + r.length;
		}
		return null;
	}
	function $e(t, n, r, i, a = !1) {
		let o = 1;
		for (let s = t; s < r;) {
			if (!i) {
				let e = ge(s);
				if (e !== null && e > s) {
					s = Math.min(e, r);
					continue;
				}
			}
			let t = Qe(s, r, i);
			if (t !== null) s = t;
			else if (e.startsWith("<!--", s)) {
				let t = e.indexOf("-->", s + 4);
				s = t < 0 || t + 3 > r ? r : t + 3;
			} else {
				if (e[s] === "<") {
					let e = Ve(s, r);
					if (e) {
						if (e.name === n || a && e.name.toLowerCase() === n.toLowerCase()) {
							if (e.closing) {
								if (--o, o === 0) return {
									start: s,
									end: e.end
								};
							} else e.self || (o += 1);
						}
						s = e.end;
						continue;
					}
				}
				s++;
			}
		}
		return null;
	}
	function et(t, n) {
		let r = "";
		for (let i = t + 2; i < n - 1; i++) {
			let t = e[i];
			if (r) t === "\\" ? i++ : t === r && (r = "");
			else if (t === "\"" || t === "'") r = t;
			else if (t === "}" && e[i + 1] === "}") return i + 2;
		}
		return -1;
	}
	function tt(t, n) {
		let r = Infinity, i = "", a = 0, o = t;
		for (; o < n;) {
			let t = e.indexOf("\n", o), s = t < 0 || t > n ? n : t, c = e.slice(o, s);
			if (h.lineStartAt(o) === o) {
				if (i) RegExp(`^[ \\t]*${i}{${a},}[ \\t]*\\r?$`).test(c) && (i = "");
				else {
					let e = /^([ \t]*)(`{3,}|~{3,})/.exec(c);
					e ? (r = Math.min(r, e[1].length), i = e[2][0], a = e[2].length) : c.trim() !== "" && (r = Math.min(r, /^[ \t]*/.exec(c)[0].length));
				}
			}
			if (s >= n) break;
			o = s + 1;
		}
		return Number.isFinite(r) ? r : 0;
	}
	function nt(t, n, r, i = t, l = t, f = 0, g = {}) {
		let v = [];
		if (n > t && c.charge(n - t, t, n), _.maxComponentDepth = Math.max(_.maxComponentDepth, f), f > Sp) throw new kp("local.budget", "Component nesting exceeds the 100-level limit.", i, l, "local.budget.nesting", { limit: Sp });
		let y = g.footnote === !0, b = g.container ?? r !== void 0, x = g.indent ?? 0, S = g.definitions ?? he, C = se;
		if (r) {
			let e = $e(t, r, n, !0)?.start ?? n, i = tt(t, e);
			x = i;
			let a = new mf(h);
			a.original(t, e, i), a.finish(e), _.mappingSegments += a.segmentCount;
			let o = a.text(), s;
			/[\[:@]|www\./i.test(o) ? s = Xd(O(o), !1) : (c.charge(o.length + 1, 0, Math.max(1, o.length)), T(o), s = {
				definitions: [],
				mathLiterals: []
			});
			let l = (t) => ({
				start: a.at(t.start, e),
				end: a.at(t.end, e)
			}), u = s.definitions.map(l).filter((e) => e.end > e.start);
			C = s.mathLiterals.map(l).sort((e, t) => e.start - t.start), S = u.filter((n) => n.start >= t && n.end <= e).sort((e, t) => e.start - t.start || t.end - e.end);
		} else t > 0 && g.definitions !== void 0 && !y && (C = Xd(O(e.slice(t, n))).mathLiterals.map((e) => ({
			start: e.start + t,
			end: e.end + t
		})).sort((e, t) => e.start - t.start));
		let w = 0, E = 0;
		for (; E < oe.length && oe[E].end <= t;) E += 1;
		for (let i = t; i < n;) {
			for (; E < oe.length && oe[E].end <= i;) E += 1;
			let l = oe[E];
			if (l && l.start <= i && i < l.end) {
				let t = Math.min(n, l.end);
				v.push({
					start: i,
					end: t,
					block: I(i),
					node: j("fallback", i, t, { value: e.slice(i, t) })
				}), i = t;
				continue;
			}
			if (!b) {
				for (; ae[_e]?.end <= i;) _e++;
				let e = ae[_e];
				if (e && e.start <= i) {
					i = e.end;
					continue;
				}
			}
			for (; S[w]?.end <= i;) w++;
			let _ = S[w];
			if (_ && _.start === i) {
				let t = i, n = Ue(t);
				for (; !n && t - i < 4 && t < _.end && (e[t] === " " || e[t] === "	");) t += 1, n = Ue(t);
				if (n && n.bodyStart <= _.end) {
					let r = h.lineStartAt(t), a = e.slice(r, t), o = /^(?:[ \t]{0,3}>[ \t]?)+/.exec(a)?.[0] ?? "", s = /^[ \t]*/.exec(a.slice(o.length))[0].length, c = s + 4, l = nt(n.bodyStart, _.end, void 0, n.bodyStart, n.bodyStart, f + 1, {
						footnote: !0,
						indent: c,
						container: b || s > 0,
						definitions: [],
						stripBlockquote: o.length > 0
					}), u = rt(n.bodyStart, _.end, l.tokens, c, {
						literalHtml: !0,
						stripBlockquote: o.length > 0
					});
					v.push({
						start: _.start,
						end: _.end,
						block: !0,
						node: j("footnoteDefinition", _.start, _.end, {
							identifier: n.identifier,
							label: n.label,
							children: u
						})
					}), i = _.end, w += 1;
					continue;
				}
				w += 1;
			}
			let T = e.startsWith("\\\\[", i) && /\s/.test(e[i + 3] ?? "");
			if (!y && r !== "plot" && e[i] === "\\" && (e[i + 1] === "(" || e[i + 1] === "[" || T) && !ce(C, i)) {
				let t = T || e[i + 1] === "[", r = T ? 3 : 2, a = t ? "]" : ")", o = i + r;
				for (; o < n;) if (e[o] === "\\") {
					if (T ? e.startsWith("\\\\]", o) && o + 2 < n && /\s/.test(e[o - 1] ?? "") : e[o + 1] === a && o + 1 < n) break;
					o += 2;
				} else o++;
				if (o >= n) {
					N("local.math.unclosed", "Formula is missing its closing delimiter.", i, n, { key: "local.math.unclosed" }), i = n;
					continue;
				}
				let s = o + r, c = e.slice(i + r, o);
				c.length > xp && (N("local.budget.math", `Formula exceeds the ${xp}-character limit.`, i, s, {
					key: "local.budget.math",
					params: { limit: xp }
				}), c = c.slice(0, xp)), v.push({
					start: i,
					end: s,
					node: j(t ? "math" : "inlineMath", i, s, { value: c })
				}), i = s;
				continue;
			}
			let D = Qe(i, n, b);
			if (D !== null) i = D;
			else if (e.startsWith("<!--", i)) {
				let t = e.indexOf("-->", i + 4), a = t < 0 ? n : Math.min(n, t + 3), o = e.slice(i, a);
				if (!y && /^<!--\s*reactive-md(?=[\s:]|-->|$)/i.test(o)) {
					Me += 1;
					let n = h.lineStartAt(i), s = e.indexOf("\n", a), c = /^\s*$/.test(e.slice(n, i)) && /^\s*$/.test(e.slice(a, s < 0 ? e.length : s)), l = /^<!--[ \t]*reactive-md:[ \t]*(local-draft-[1-9][0-9]*)[ \t]*-->$/.exec(o);
					Me > 1 ? N("local.version.duplicate", "Only one source syntax declaration is allowed.", i, a) : !l || t < 0 || /[\r\n]/.test(o) ? N("local.version.malformed", `Use <!-- reactive-md: ${de} --> on one line.`, i, a) : (je = {
						version: l[1],
						range: {
							start: i,
							end: a
						}
					}, r !== void 0 || !c || Fe(0, i) !== i ? N("local.version.placement", "The syntax declaration must be on its own line before the theme and document body.", i, a) : l[1] !== "local-draft-3" && N("local.version.unsupported", `This reader accepts ${de}; migrate ${l[1]} or use a compatible reader.`, i, a, {
						key: "local.version.unsupported",
						params: {
							declared: l[1],
							supported: de
						}
					}));
				}
				v.push({
					start: i,
					end: a,
					node: j("comment", i, a)
				}), i = a;
			} else if (!y && e.startsWith("{{", i)) {
				let t = et(i, n);
				if (t < 0) {
					N("local.interpolation", "Interpolation is missing }}.", i, n, { key: "local.interpolation.unclosed" }), i += 2;
					continue;
				}
				v.push({
					start: i,
					end: t,
					node: j("interpolation", i, t, { value: e.slice(i + 2, t - 2).trim() })
				}), i = t;
			} else if (!y && e[i] === "$") {
				let t = e[i + 1] === "$", r = t ? "$$" : "$";
				if (t) {
					let t = i + r.length;
					for (; t < n; t++) if (e[t] === "\\") t++;
					else if (e.startsWith(r, t)) break;
					if (t >= n || !e.startsWith(r, t)) {
						N("local.math.unclosed", "Formula is missing its closing delimiter.", i, void 0, { key: "local.math.unclosed" }), i += r.length;
						continue;
					}
					let a = e.slice(i + r.length, t);
					a.length > xp && (N("local.budget.math", `Formula exceeds the ${xp}-character limit.`, i, t + r.length, {
						key: "local.budget.math",
						params: { limit: xp }
					}), a = a.slice(0, xp));
					let o = t + r.length;
					v.push({
						start: i,
						end: o,
						node: j("math", i, o, { value: a })
					}), i = o;
					continue;
				}
				let a = i + 1, o = -1;
				for (; a < n; a++) {
					let t = e[a];
					if (t === "\\") {
						a++;
						continue;
					}
					if (t === "\n" || t === "\r") break;
					if (t !== "$") continue;
					let n = e.slice(i + 1, a), r = e[a + 1];
					if (!n.trim() || /\s$/.test(n) && /^\d[\d.,]*(?:[，、；：。！？]|[.,;:!?]\s|\s+(?:and|or|to|each|per|for)\b)/i.test(n) || r !== void 0 && r >= "0" && r <= "9") break;
					o = a;
					break;
				}
				if (o < 0) {
					i += 1;
					continue;
				}
				let s = e.slice(i + 1, o);
				s.length > xp && (N("local.budget.math", `Formula exceeds the ${xp}-character limit.`, i, o + 1, {
					key: "local.budget.math",
					params: { limit: xp }
				}), s = s.slice(0, xp));
				let c = o + 1;
				v.push({
					start: i,
					end: c,
					node: j("inlineMath", i, c, { value: s })
				}), i = c;
			} else {
				if (e[i] === "[") {
					let t = He(i, n);
					if (t && (e[t.closeEnd] !== ":" || !I(i))) {
						v.push({
							start: i,
							end: t.closeEnd,
							node: j("footnoteReference", i, t.closeEnd, {
								identifier: t.identifier,
								label: t.label
							})
						}), i = t.closeEnd;
						continue;
					}
				}
				if (e[i] === "<") {
					let l = a.length, h = !1, _;
					try {
						_ = fe(e, i, n, {
							shield: (t, n) => {
								if (e.startsWith("{{", t)) {
									let e = et(t, n);
									if (e >= 0) return e;
								}
								if (e[t] === "<") {
									let e = Ve(t, n);
									if (e && !e.closing && !le.has(e.name.toLowerCase()) && !lp.has(e.name.toLowerCase()) && !p.has(e.name.toLowerCase())) {
										let t = $e(e.end, e.name, n, b);
										if (t) return t.end;
									}
								}
								return Qe(t, n, b);
							},
							budget: (e, t) => {
								if (t > o * 2) throw new kp("local.budget", `Syntax nodes exceed the limit of ${o}.`, e, e + 1, "local.budget.nodes", { limit: o });
							},
							node: j,
							problem: (e, t, n, r, i) => {
								h = !0;
								let a = `html.table.${e}`, o = {
									tag: r ?? "table",
									name: i ?? ""
								};
								P("local.html.fallback", Te(a, "en", o), t, n, {
									key: a,
									params: o
								});
							},
							attributes: (e, t, n) => {
								let r = We(t, n, !0), i = r && Ke(e, r);
								if (!i || !i.ok) {
									h = !0;
									let r = i && !i.ok ? i.attr : "", a = `html.table.${[
										"colspan",
										"rowspan",
										"span",
										"scope",
										"align"
									].includes(r) ? "value" : "attribute"}`, o = {
										tag: e,
										name: r
									};
									return P("local.html.fallback", Te(a, "en", o), t, n, {
										key: a,
										params: o
									}), {};
								}
								return i.attrs;
							},
							content: (e, t) => rt(e, t, nt(e, t, void 0, e, e, f + 1, {
								...g,
								definitions: []
							}).tokens, tt(e, t), {
								literalHtml: y,
								stripBlockquote: g.stripBlockquote === !0
							})
						});
					} catch (t) {
						if (t instanceof kp) throw t;
						let o = Ve(i, n);
						if (!o || o.closing || o.name.toLowerCase() !== "table") throw t;
						let s = $e(o.end, o.name, n, b, !0)?.end ?? F(o.end, n, r), c = a.slice(l).filter((e) => e.code.startsWith("local.budget"));
						a.splice(l, a.length - l, ...c), P("local.html.fallback", Te("local.html.fallback", "en"), i, s, { key: "local.html.fallback" }), _ = {
							node: j("fallback", i, s, { value: e.slice(i, s) }),
							end: s
						}, h = !1;
					}
					if (_) {
						if (h) {
							let e = a.slice(l).filter((e) => e.code === "local.html.fallback" || e.code.startsWith("local.budget"));
							a.splice(l, a.length - l, ...e);
						}
						v.push({
							start: i,
							end: _.end,
							block: !0,
							node: h ? j("fallback", i, _.end, { value: e.slice(i, _.end) }) : _.node
						}), i = _.end;
						continue;
					}
					let S = We(i, n);
					if (S) {
						if (S.closing) {
							P("local.html.fallback", Te("local.html.fallback", "en"), i, S.end, { key: "local.html.fallback" }), v.push({
								start: i,
								end: S.end,
								block: !1,
								node: j("fallback", i, S.end, { value: e.slice(i, S.end) })
							}), i = S.end;
							continue;
						}
						let t = Ke(S.lower, S);
						if (!t.ok) {
							let a = S.self || up.has(S.lower) ? S.end : Ge(S.end, S.lower, n, b)?.end ?? F(S.end, n, r, S.lower);
							P("local.html.fallback", Te("local.html.fallback.attribute", "en", { name: t.attr }), i, a, {
								key: "local.html.fallback.attribute",
								params: { name: t.attr }
							}), v.push({
								start: i,
								end: a,
								block: !1,
								node: j("fallback", i, a, { value: e.slice(i, a) })
							}), i = a;
							continue;
						}
						let a = t.attrs;
						if (up.has(S.lower)) {
							if (S.lower === "br") v.push({
								start: i,
								end: S.end,
								node: j("break", i, S.end, { attrs: a })
							});
							else if (S.lower === "hr") v.push({
								start: i,
								end: S.end,
								block: !0,
								node: j("thematicBreak", i, S.end, { attrs: a })
							});
							else {
								let e = a.width === void 0 ? void 0 : Number(a.width), t = a.height === void 0 ? void 0 : Number(a.height);
								v.push({
									start: i,
									end: S.end,
									node: j("image", i, S.end, {
										url: a.src,
										alt: a.alt ?? "",
										title: a.title ?? null,
										...e === void 0 ? {} : { width: e },
										...t === void 0 ? {} : { height: t },
										attrs: a
									})
								});
							}
							i = S.end;
							continue;
						}
						let o = Ge(S.end, S.lower, n, b);
						if (!o) {
							let t = F(S.end, n, r, S.lower);
							if (!s) {
								c.charge(t - i, i, t);
								let n = Zf(e, i, t, j, new Set(p.keys()));
								if (n) {
									M.push(n.recovery);
									for (let e of n.nodes) v.push({
										start: e.range.start,
										end: e.range.end,
										block: dp.has(S.lower) || fp.has(e.type),
										node: e
									});
								} else M.push({
									code: "local.html.literal",
									causeRange: {
										start: i,
										end: S.end
									},
									affectedRange: {
										start: i,
										end: t
									},
									action: "literal-fallback",
									boundary: "fragment"
								}), v.push({
									start: i,
									end: t,
									block: I(i),
									node: j("fallback", i, t, { value: e.slice(i, t) })
								});
								i = t;
								continue;
							}
							P("local.html.fallback", Te("local.html.fallback", "en"), i, t, { key: "local.html.fallback" }), v.push({
								start: i,
								end: t,
								block: I(i),
								node: j("fallback", i, t, { value: e.slice(i, t) })
							}), i = t;
							continue;
						}
						let l = dp.has(S.lower), u = Ye(S, o, a, {
							footnote: y,
							container: b,
							indent: x,
							stripBlockquote: g.stripBlockquote === !0,
							depth: f
						});
						v.push({
							start: i,
							end: o.end,
							...l ? { block: !0 } : {},
							node: u
						}), i = o.end;
						continue;
					}
					if (y) {
						i += 1;
						continue;
					}
					let C = Ne(i) ? Pe(i, n) : null;
					if (C) {
						if (r === void 0 && Fe(De, i) === i) {
							if (we += 1, we === 1 && (Ce = {
								start: C.start,
								end: C.end
							}), C.unclosed) P("local.theme.malformed", "Theme declaration is missing >.", i, C.end, { key: "local.theme.malformed.unclosed" });
							else if (C.closing) P("local.theme.malformed", "A theme declaration cannot be a closing tag.", i, C.end, { key: "local.theme.malformed.closing" });
							else if (!Ie(C)) P("local.theme.malformed", "A theme declaration must be on its own line before the document content.", i, C.end, { key: "local.theme.malformed.placement" });
							else if (we > 1) P("local.theme.duplicate", "Only one theme declaration is allowed before the document content; this declaration is ignored.", i, C.end, { key: "local.theme.duplicate.declaration" });
							else {
								let e = Le(C.rest);
								e.code ? P(e.code, e.message ?? "Invalid theme declaration.", i, C.end, {
									key: e.key ?? e.code,
									...e.params ? { params: e.params } : {}
								}) : Se = e.name;
							}
							De = C.end, v.push({
								start: i,
								end: C.end,
								block: !0,
								node: j("comment", i, C.end)
							}), i = C.end;
							continue;
						}
						let t = r === void 0 ? "local.theme.late" : "local.theme.nested";
						P(t, r === void 0 ? "Theme declarations after document content are ignored." : "Theme declarations inside document content are ignored.", i, C.end, { key: t }), v.push({
							start: i,
							end: C.end,
							block: !1,
							node: j("fallback", i, C.end, { value: e.slice(i, C.end) })
						}), i = C.end;
						continue;
					}
					let w = Ve(i, n);
					if (w && !p.has(w.name.toLowerCase()) && hp.has(w.name.toLowerCase())) {
						let t = !w.closing && !w.self && !gp.has(w.name.toLowerCase()) ? $e(w.end, w.name, n, b, !0) : null, a = !s && !w.closing && !w.self && yf.has(w.name.toLowerCase()) && (!t || w.name.toLowerCase() === "plaintext"), o = w.closing || w.self || gp.has(w.name.toLowerCase()) ? w.end : a ? n : t?.end ?? F(w.end, n, r, w.name);
						a ? M.push({
							code: "local.html.literal",
							causeRange: {
								start: i,
								end: w.end
							},
							affectedRange: {
								start: i,
								end: o
							},
							action: "literal-fallback",
							boundary: o === e.length ? "eof" : "fragment"
						}) : P("local.html.fallback", Te("local.html.fallback", "en"), i, o, { key: "local.html.fallback" }), v.push({
							start: i,
							end: o,
							block: I(i),
							node: j("fallback", i, o, { value: e.slice(i, o) })
						}), i = o;
						continue;
					}
					if (w && !w.closing && op.test(w.name) && w.name.length <= bp && !p.has(w.name)) {
						let t = w.self ? w.end : $e(w.end, w.name, n, b)?.end ?? null;
						if (t === null) {
							if (!I(i)) {
								v.push({
									start: i,
									end: w.end,
									block: !1,
									node: j("text", i, w.end, { value: e.slice(i, w.end) })
								}), i = w.end;
								continue;
							}
							N("local.tag.unclosed", `<${w.name}> is missing </${w.name}>.`, i, w.end, {
								key: "local.tag.unclosed.pair",
								params: { name: w.name }
							}), i = w.end;
							continue;
						}
						let r = te(w.name, m);
						P("local.component.unknown", `Unknown component <${w.name}>. ${r ? `Did you mean <${r}>?` : "This mode only accepts local interaction components."}`, i, t, {
							key: r ? "local.component.unknown.suggestion" : "local.component.unknown",
							params: r ? {
								name: w.name,
								suggestion: r
							} : { name: w.name }
						}), v.push({
							start: i,
							end: t,
							block: I(i),
							node: j("fallback", i, t, { value: e.slice(i, t) })
						}), i = t;
						continue;
					}
					let T = Be(i, n);
					if (T) {
						if (T.unclosed) {
							if (!p.has(T.name.toLowerCase()) && hp.has(T.name.toLowerCase())) {
								let t = F(T.head, n, r, T.name);
								!s && yf.has(T.name.toLowerCase()) ? M.push({
									code: "local.html.literal",
									causeRange: {
										start: i,
										end: T.head
									},
									affectedRange: {
										start: i,
										end: t
									},
									action: "literal-fallback",
									boundary: t === e.length ? "eof" : "fragment"
								}) : P("local.html.fallback", Te("local.html.fallback", "en"), i, t, { key: "local.html.fallback" }), v.push({
									start: i,
									end: t,
									block: I(i),
									node: j("fallback", i, t, { value: e.slice(i, t) })
								}), i = t;
								continue;
							}
							if (!p.has(T.name.toLowerCase()) && !I(i)) {
								v.push({
									start: i,
									end: T.head,
									block: !1,
									node: j("text", i, T.head, { value: e.slice(i, T.head) })
								}), i = T.head;
								continue;
							}
							N("local.tag.unclosed", `Tag ${T.name} is missing >.`, i, n, {
								key: "local.tag.unclosed.open",
								params: { name: T.name }
							}), i = n;
							continue;
						}
						if (!op.test(T.name) && !p.has(T.name.toLowerCase())) {
							v.push({
								start: i,
								end: T.end,
								block: !1,
								node: j("text", i, T.end, { value: e.slice(i, T.end) })
							}), i = T.end;
							continue;
						}
						if (op.test(T.name) || N("local.tag.name", `Tag name ${T.name} must use lowercase kebab-case.`, i, i + 1 + T.name.length, {
							key: "local.tag.name",
							params: { name: T.name }
						}), T.closing) {
							if (T.name === r) return {
								tokens: v,
								end: T.end,
								contentEnd: i,
								indent: tt(t, i)
							};
							if (d.has(T.name) && u.get(T.name)?.form === "leaf") {
								N("local.host.structure", `Host component <${T.name}> is a leaf and cannot have a closing tag.`, i, T.end, {
									key: "local.host.structure.leaf",
									params: { component: T.name }
								}), i = T.end;
								continue;
							}
							N("local.tag.mismatch", `Closing tag </${T.name}> does not match ${r ? `<${r}>` : "the document root"}.`, i, T.end, {
								key: r ? "local.tag.mismatch.parent" : "local.tag.mismatch.root",
								params: r ? {
									name: T.name,
									parent: r
								} : { name: T.name }
							}), i = T.end;
							continue;
						}
						let a = u.get(T.name), o = d.has(T.name), c = o ? a?.form : void 0, l = a === void 0 || a.form !== "leaf", m = a?.form === "inline", h = !l || T.self;
						if (T.self && l && N("local.tag.shape", `<${T.name}> requires a closing tag.`, i, T.end, {
							key: "local.tag.shape",
							params: { name: T.name }
						}), h) {
							v.push({
								start: i,
								end: T.end,
								...o ? { block: I(i) } : {},
								node: j(o ? "hostComponent" : "component", i, T.end, {
									name: T.name,
									attrs: T.attrs,
									children: [],
									...o ? { hostForm: c } : {}
								})
							}), i = T.end;
							continue;
						}
						let g = nt(T.end, n, T.name, i, T.end, f + 1), _ = rt(T.end, g.contentEnd, g.tokens, m ? 0 : g.indent), y = j(o ? "hostComponent" : "component", i, g.end, {
							name: T.name,
							attrs: T.attrs,
							children: m && _.length === 1 && _[0].type === "paragraph" ? _[0].children ?? [] : _,
							...o ? { hostForm: c } : {}
						});
						v.push({
							start: i,
							end: g.end,
							...o ? { block: I(i) } : {},
							node: y
						}), i = g.end;
						continue;
					}
				}
				i++;
			}
		}
		return r && N("local.tag.unclosed", `<${r}> is missing </${r}>.`, i, Math.min(e.length, Math.max(l, i + 1)), {
			key: "local.tag.unclosed.pair",
			params: { name: r }
		}), {
			tokens: v,
			end: n,
			contentEnd: n,
			indent: r ? tt(t, n) : 0
		};
	}
	function rt(t, n, r, i = 0, a = {}) {
		n > t && c.charge(n - t, t, n);
		let s = "", u = t, d = !1, p = t === 0 && n === e.length && r.length === 0 && i === 0 && !a.stripBlockquote && !a.literalHtml && !me?.children.some((e) => e.plan?.shieldOnly), m = new mf(h), g = (e, t) => p ? e + pe : m.at(e, t), v = /* @__PURE__ */ new Map();
		function y(e, t, n) {
			n ? (e.trim().length && (d = !0), m.original(t, t + e.length, i, a.stripBlockquote, !0)) : m.generated(e, t);
		}
		let b;
		if (p) s = e.slice(pe), b = me, me = void 0;
		else {
			t === 0 && n === e.length && (me = void 0);
			for (let t of r) {
				y(e.slice(u, t.start), u, !0);
				let n;
				do
					n = ip + ne++ + ap;
				while (ie.has(n));
				let r = t.block ?? (t.node.type === "math" || (t.node.type === "component" || t.node.type === "hostComponent") && !f(t.node.name));
				r && y("\n\n", t.start, !1);
				let i = m.length;
				y(`![${n}](rmd-internal:placeholder)`, t.start, !1), v.set(i, {
					marker: n,
					end: m.length,
					node: t.node
				}), r && y("\n\n", t.end, !1), u = t.end;
			}
			y(e.slice(u, n), u, !0), m.finish(n), s = m.text(), _.mappingSegments += m.segmentCount;
			let i = new Map([...v].filter(([, e]) => e.node.type === "interpolation"));
			b = O(s, d, {
				allowBraces: !0,
				...i.size ? { placeholders: i } : {}
			});
		}
		function x(e) {
			for (let t of e) t.type === "interpolation" && t.value !== void 0 && (t.value = t.value.replace(/\\\|/g, "|")), t.children && x(t.children);
		}
		function S(t, n, r) {
			let i = t.value;
			if (typeof i != "string" || !i) return [];
			if (!l || !/[\r\n]/.test(i)) return [j("text", n, r, { value: i })];
			let a = t.position?.start?.offset, o = t.position?.end?.offset;
			if (!Number.isInteger(a) || !Number.isInteger(o) || a < 0 || o <= a || o > s.length) return [j("text", n, r, { value: i })];
			let c = (t, n) => {
				if (n === void 0) return t;
				let r = t;
				for (let t = 0; r < e.length && t < 32; t += 1) {
					let t = e[r];
					if (t !== " " && t !== "	" && t !== ">") break;
					r += 1;
				}
				return r < e.length && e[r] === n ? r : t;
			}, u = [];
			for (let e = a; e < o; e += 1) if (s[e] === "\\" && /[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(s[e + 1] ?? "")) e += 1;
			else {
				if (s[e] === "&") {
					let t = /^&(?:#(?:[xX][\da-fA-F]{1,6}|\d{1,7})|NewLine);/.exec(s.slice(e, Math.min(o, e + 34)))?.[0];
					if (t) {
						let n = t === "&NewLine;" ? 10 : t[2].toLowerCase() === "x" ? Number.parseInt(t.slice(3, -1), 16) : Number.parseInt(t.slice(2, -1), 10);
						(n === 10 || n === 13) && u.push({
							start: e,
							end: e + t.length,
							literal: !0
						}), e += t.length - 1;
						continue;
					}
				}
				if (s[e] === "\r") {
					let t = e + 1 < o && s[e + 1] === "\n" ? e + 2 : e + 1;
					u.push({
						start: e,
						end: t
					}), e = t - 1;
				} else s[e] === "\n" && u.push({
					start: e,
					end: e + 1
				});
			}
			if (!u.length) return [j("text", n, r, { value: i })];
			let d = [], f = 0, p = n, m = 0;
			for (let e = 0; e < i.length; e += 1) {
				let t = i[e];
				if (t !== "\n" && t !== "\r") continue;
				let n = u[m];
				if (n === void 0) break;
				m += 1;
				let r = !n.literal && t === "\r" && i[e + 1] === "\n" ? e + 2 : e + 1;
				if (n.literal) continue;
				let a = g(n.start, p), o = a + (n.end - n.start);
				e > f && d.push(j("text", p, a, { value: i.slice(f, e) })), d.push(j("break", a, o)), f = r, p = c(g(n.end, o), i[r]), e = r - 1;
			}
			return f < i.length && d.push(j("text", p, r, { value: i.slice(f) })), d;
		}
		function C(e, r) {
			let i = g(e.position?.start?.offset ?? 0, t), c = g(e.position?.end?.offset ?? s.length, n);
			if (e.type === "rmdFastBlock") {
				let t = e.plan, n = e.position.start.offset;
				re.add(t);
				let r = t.overflowAt(o - ee);
				if (r) throw new kp("local.budget", `Syntax nodes exceed the limit of ${o}.`, g(n + r.start, i), g(n + r.end, c), "local.budget.nodes", { limit: o });
				return t.emit((e, t, r, a) => {
					if (e === "rmdOpaque") {
						let e = v.get(n + t);
						if (!e || e.node.type !== "interpolation" || e.end !== n + r || e.marker !== a?.value) throw Error("Invalid interpolation placeholder");
						return v.delete(n + t), e.node;
					}
					return j(e, g(n + t, i), g(n + r, c), a);
				});
			}
			if (e.type === "image") {
				let t = v.get(e.position?.start?.offset);
				if (t && e.position.end.offset === t.end && e.url === "rmd-internal:placeholder" && e.alt === t.marker) return v.delete(e.position.start.offset), t.node.type === "comment" ? [] : [t.node];
			}
			if (e.type === "text") return S(e, i, c);
			if (e.type === "footnoteReference" || e.type === "footnoteDefinition") {
				let t = typeof e.label == "string" && e.label ? e.label : String(e.identifier ?? ""), n = nl(String(e.identifier ?? t));
				return e.type === "footnoteDefinition" ? [j("footnoteDefinition", i, c, {
					identifier: n,
					label: t,
					children: r ?? []
				})] : [j("footnoteReference", i, c, {
					identifier: n,
					label: t
				})];
			}
			if (e.type === "paragraph" && r?.length === 1 && (r[0].type === "math" || r[0].type === "fallback" || r[0].type === "footnoteDefinition" || fp.has(r[0].type) || (r[0].type === "component" || r[0].type === "hostComponent") && !f(r[0].name))) return r;
			if (e.type === "paragraph" && !r?.length) return [];
			if (e.type === "html") return a.literalHtml ? typeof e.value == "string" && e.value ? [j("text", i, c, { value: e.value })] : [] : (N("local.html", "Raw HTML is not part of the local interaction syntax.", i, c, { key: "local.html" }), []);
			let l = j(e.type, i, c);
			for (let t of [
				"value",
				"depth",
				"ordered",
				"start",
				"checked",
				"url",
				"title",
				"alt",
				"lang",
				"align"
			]) e[t] !== void 0 && (l[t] = e[t]);
			return r && (l.children = r), e.type === "table" && l.children && x(l.children), [l];
		}
		let w = [{
			raw: b,
			index: 0,
			children: []
		}];
		for (; w.length;) {
			let e = w[w.length - 1];
			if (e.raw.children && e.index < e.raw.children.length) {
				let t = e.raw.children[e.index++];
				w.push({
					raw: t,
					index: 0,
					children: t.children ? [] : void 0
				});
				continue;
			}
			if (w.pop(), !w.length) return e.children ?? [];
			let t = C(e.raw, e.children);
			for (let e of t) w[w.length - 1].children.push(e);
		}
		return [];
	}
	function it(t) {
		let n = /* @__PURE__ */ new Set(), r = [...t];
		for (; r.length;) {
			let e = r.pop();
			if (e.type === "footnoteDefinition" && e.identifier && n.add(e.identifier), e.children) for (let t of e.children) r.push(t);
		}
		for (r.push(...t); r.length;) {
			let t = r.pop();
			if (t.type !== "footnoteReference" || t.identifier && n.has(t.identifier) || (t.type = "text", t.value = e.slice(t.range.start, t.range.end), delete t.identifier, delete t.label), t.children) for (let e of t.children) r.push(e);
		}
	}
	function at() {
		if (s || M.length === 0) return;
		let e = /* @__PURE__ */ new Set(), t = !1;
		for (let n of M) {
			if (!pp.has(n.code)) continue;
			let { causeRange: r, affectedRange: i } = n, a = `${n.code}:${r.start}:${r.end}:${i.start}:${i.end}:${n.boundary}`;
			e.has(a) || (e.add(a), P(n.code, Te(n.code, "en"), r.start, r.end, { key: n.code }), t = !0);
		}
		t && a.sort((e, t) => e.range.start - t.range.start || e.range.end - t.range.end);
	}
	try {
		if (!s && e.includes("<")) {
			let t = jf(e, {
				facts: h.facts,
				definitions: he,
				isKnown: (e) => p.has(e),
				isPaired: (e) => {
					let t = p.get(e);
					return t === void 0 || t.form !== "leaf";
				},
				isHtmlName: (e) => lp.has(e) || hp.has(e),
				isVoidHtml: (e) => gp.has(e) || up.has(e),
				rawHtmlEnd: (t, n, r) => {
					if (t === "plaintext") return e.length;
					if (t === "pre" || t === "code") return Ge(n, t, e.length, r)?.end ?? null;
					let i = RegExp(`</${t}\\s*>`, "i").exec(e.slice(n));
					return i ? n + i.index + i[0].length : null;
				},
				protectedEnd: (t, n) => Qe(t, e.length, n),
				codeEndAt: (e) => ge(e),
				readTag: (t) => {
					let n = Ve(t, e.length);
					if (n) return {
						name: n.name,
						closing: n.closing,
						self: n.self,
						end: n.end,
						complete: !0
					};
					let r = /^<(\/?)([A-Za-z][A-Za-z0-9_-]*)(?=[\s/>])/.exec(e.slice(t, Math.min(e.length, t + 256)));
					return r ? {
						name: r[2],
						closing: !!r[1],
						self: !1,
						end: t + r[0].length,
						complete: !1
					} : null;
				},
				beginsLine: I,
				charge: (e, t, n) => c.charge(e, t, n)
			});
			oe = t.ranges, M = [...t.recoveries];
		}
		let t = wp(), n = nt(0, e.length);
		x = wp() - t;
		let r = wp(), i = rt(0, e.length, n.tokens);
		return S = wp() - r, it(i), M.sort((e, t) => e.causeRange.start - t.causeRange.start || e.causeRange.end - t.causeRange.end || e.affectedRange.start - t.affectedRange.start || e.affectedRange.end - t.affectedRange.end || e.code.localeCompare(t.code)), at(), E(), {
			nodes: i,
			diagnostics: a,
			syntaxNodes: ee,
			work: _,
			...re.size ? { plans: [...re] } : {},
			...je ? { versionDeclaration: je } : {},
			...Se === void 0 ? {} : { theme: Se },
			...Ce ? { themeRange: Ce } : {},
			...M.length ? { recoveries: M } : {}
		};
	} catch (e) {
		return e instanceof hf ? (xe(e), E(), {
			nodes: [],
			diagnostics: a,
			work: _,
			...M.length ? { recoveries: M } : {}
		}) : e instanceof kp ? (N(e.code, e.message, e.start, e.end, {
			key: e.key,
			params: e.params
		}), E(), {
			nodes: [],
			diagnostics: a,
			work: _,
			...M.length ? { recoveries: M } : {}
		}) : (N("local.parse", `Cannot parse document: ${e instanceof Error ? e.message : String(e)}`, 0, void 0, {
			key: "local.parse.document",
			params: { detail: e instanceof Error ? e.message : String(e) }
		}), {
			nodes: [],
			diagnostics: a,
			...M.length ? { recoveries: M } : {}
		});
	}
}
// src/local/transport/compiled-data.ts
function jp(e, t = !0) {
	let n = /* @__PURE__ */ new WeakMap(), r = [], i = (e) => {
		if (typeof e != "object" || !e) return e;
		let t = n.get(e);
		if (t) return t;
		let i = Array.isArray(e) ? Array(e.length) : {};
		return n.set(e, i), r.push({
			input: e,
			output: i
		}), i;
	}, a = i(e);
	for (; r.length;) {
		let { input: e, output: n } = r.pop();
		for (let [t, r] of Object.entries(e)) Object.defineProperty(n, t, {
			value: i(r),
			enumerable: !0,
			configurable: !0,
			writable: !0
		});
		t && Object.isFrozen(e) && Object.freeze(n);
	}
	return a;
}
// src/local/compilation/compiler-core.ts
var Mp = /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/, Np = /^[A-Za-z_][A-Za-z0-9_]*$/, Pp = 128, Fp = 4, Ip = 3, Lp = /* @__PURE__ */ new Set([
	"x",
	"y",
	"true",
	"false",
	"null",
	"pi",
	"e"
]);
function Rp(e) {
	let t = e.trim();
	if (!Mp.test(t)) return null;
	let n = Number(t);
	return Number.isFinite(n) ? n : null;
}
function zp(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function Bp(e) {
	let t = [], n = [];
	for (let r = 0; r < e.length;) {
		if (e[r] === "\\" && e.startsWith("{{", r + 1)) {
			r += 3;
			continue;
		}
		if (!e.startsWith("{{", r)) {
			r++;
			continue;
		}
		let i = "", a = r + 2;
		for (; a < e.length - 1; a++) {
			let t = e[a];
			if (i) t === "\\" ? a++ : t === i && (i = "");
			else if (t === "\"" || t === "'") i = t;
			else if (t === "}" && e[a + 1] === "}") break;
		}
		if (a >= e.length - 1) {
			n.push(r);
			break;
		}
		let o = e.slice(r + 2, a), s = o.length - o.trimStart().length;
		t.push({
			expression: o.trim(),
			start: r + 2 + s,
			end: a
		}), r = a + 2;
	}
	return {
		segments: t,
		unterminated: n
	};
}
function Vp(e) {
	let t = /^\s*\{\{([\s\S]*)\}\}\s*$/.exec(e);
	if (!t) return null;
	let n = t[1], r = n.length - n.trimStart().length, i = e.indexOf("{{");
	return {
		expression: n.trim(),
		start: i + 2 + r
	};
}
function Hp(e) {
	return e.type === "comment" || e.type === "text" && !(e.value ?? "").trim() || e.type === "paragraph" && !e.children?.length && !(e.value ?? "").trim();
}
function Up(e) {
	return (e ?? []).filter((e) => !Hp(e));
}
function Wp(e) {
	return e.type === "text" || e.type === "inlineCode" || e.type === "fallback" ? e.value ?? "" : e.type === "interpolation" ? "\0" : e.type === "break" ? " " : (e.children ?? []).map(Wp).join("");
}
function Gp(e) {
	return e.type === "interpolation" || (e.children ?? []).some(Gp);
}
function Kp(e) {
	return e.type === "component" || (e.children ?? []).some(Kp);
}
function $(e) {
	switch (e) {
		case "string": return "string";
		case "number": return "number";
		case "boolean": return "boolean";
		case "null": return "null";
		case "array": return "array";
		case "number-array": return "number-array";
	}
}
function qp(e, t) {
	return !t || t.length === 0 ? e : {
		...e,
		recoveries: [...t]
	};
}
function Jp(e) {
	return e.schemaByName ?? /* @__PURE__ */ new Map();
}
function Yp(e) {
	return e.componentByName ?? /* @__PURE__ */ new Map();
}
function Xp(e, t) {
	return d(e, t);
}
function Zp(e, t) {
	if (!(e.length > Pp)) return te(e, [...t]);
}
function Qp(e, t) {
	if (typeof e != "string" || e.length > 1e6) return {
		ok: !1,
		diagnostics: [{
			code: typeof e == "string" ? "local.budget" : "local.parse",
			message: typeof e == "string" ? `Document exceeds the ${be}-character limit.` : "Document source must be a string.",
			severity: "error",
			range: {
				start: 0,
				end: typeof e == "string" && e.length ? 1 : 0
			},
			line: 1,
			column: 1,
			messageKey: typeof e == "string" ? "local.budget.document" : "local.parse.source",
			...typeof e == "string" ? { params: { limit: be } } : {}
		}]
	};
	let n = ae(e, t.html, t.maxSyntaxNodes);
	return n.diagnostics.some((e) => e.severity === "error") ? {
		ok: !1,
		diagnostics: n.diagnostics
	} : {
		ok: !0,
		document: {
			syntax: "local",
			source: e,
			syntaxVersion: de,
			html: t.html,
			nodes: [{
				type: "htmlDocument",
				id: "local-0",
				range: {
					start: 0,
					end: e.length
				},
				value: n.markup
			}],
			initialState: {},
			bindings: {}
		},
		diagnostics: n.diagnostics
	};
}
function $p(e, t, n, r, i, a) {
	if (n.htmlActive) return Qp(e, n);
	if (typeof e != "string" || e.length > 1e6) {
		let t = Ap(e, n);
		return qp({
			ok: !1,
			diagnostics: t.diagnostics
		}, t.recoveries);
	}
	let o = [], s = new pf(e), { lineStarts: c } = s, l = (t, n, r, i = r + 1, a) => {
		if (o.length >= 100) {
			let e = o.length - 1;
			for (; e >= 0 && o[e].severity !== "warning";) --e;
			if (e < 0) return;
			o.splice(e, 1);
		}
		let s = Math.max(0, Math.min(e.length, r)), l = Math.max(s, Math.min(e.length, Math.max(s, i))), u = 0, d = c.length - 1;
		for (; u < d;) {
			let e = Math.ceil((u + d) / 2);
			c[e] <= s ? u = e : d = e - 1;
		}
		let f = Oe(a?.key ?? t, a?.params);
		o.push({
			code: t,
			message: n.length > 2e3 ? `${n.slice(0, ye - 1)}…` : n,
			severity: "error",
			range: {
				start: s,
				end: l
			},
			line: u + 1,
			column: s - c[u] + 1,
			messageKey: f.key,
			...f.params ? { params: f.params } : {}
		});
	}, u;
	try {
		u = r?.parser ? r.parser.parse(e, t, s, r.rowPlans) : Ap(e, n, s), i?.(u), a?.("parseMs");
	} catch (e) {
		return l("local.parse", `Cannot parse document: ${e instanceof Error ? e.message : String(e)}`, 0, void 0, {
			key: "local.parse.document",
			params: { detail: e instanceof Error ? e.message : String(e) }
		}), {
			ok: !1,
			diagnostics: o
		};
	}
	o.push(...u.diagnostics);
	let d = u.recoveries;
	if (o.some((e) => e.severity === "error" && e.code.startsWith("local.version."))) {
		let e = new Set((d ?? []).map((e) => `${e.code}:${e.causeRange.start}:${e.causeRange.end}`));
		return qp({
			ok: !1,
			diagnostics: o.filter((t) => t.code.startsWith("local.version.") || t.severity === "warning" && e.has(`${t.code}:${t.range.start}:${t.range.end}`))
		}, d);
	}
	for (let e of em(u.nodes)) l("local.legacy", "Legacy reactive-md configuration fences (state/data/computed/actions, etc.) are not part of the local interaction syntax; select legacy mode explicitly in the host.", e.range.start, e.range.end, { key: "local.legacy" });
	let f = {
		semantic: r?.semantic,
		display: r?.display,
		source: e,
		lineStarts: c,
		nodes: u.nodes,
		diagnostics: o,
		schemaByName: Jp(n),
		definitionsByName: Yp(n),
		report: l,
		entries: [],
		attrs: /* @__PURE__ */ new Map(),
		options: /* @__PURE__ */ new Map(),
		tabs: /* @__PURE__ */ new Map(),
		steps: /* @__PURE__ */ new Map(),
		selections: /* @__PURE__ */ new Map(),
		diagramNodes: /* @__PURE__ */ new Map(),
		checklists: /* @__PURE__ */ new Map(),
		tables: /* @__PURE__ */ new Map(),
		tableShapes: /* @__PURE__ */ new Map(),
		bindingSlots: Object.create(null),
		bindingKinds: {},
		computationKinds: {},
		computations: {},
		externals: {},
		externalKinds: {},
		dynamicConstraints: {},
		expressionKinds: /* @__PURE__ */ new Map()
	};
	tm(u.nodes, null, f.entries, f);
	for (let e of f.entries) f.attrs.set(e.node.id, im(e, f)), fm(e, f), dm(e, f);
	a?.("attributesMs");
	for (let e of f.entries) km(e, f);
	Th(f), a?.("structureMs");
	let p = Mm(f);
	f.bindingKinds = Nm(p), a?.("bindingsMs"), ih(f), eh(f), a?.("computationsMs"), ah(f), oh(f), a?.("expressionsMs"), fh(f), a?.("dataTablesMs");
	let m = ph(f);
	a?.("validationsMs"), _h(f), a?.("plotsMs"), Sh(f), a?.("tablesMs");
	let h = {};
	for (let [e, t] of Object.entries(p)) h[e] = zp(t.initial);
	sh(f, p, h), Nh(u.nodes, f), a?.("hostAndNavigationMs");
	let g = [...u.nodes];
	for (; g.length && o.length < 100;) {
		let t = g.pop();
		if (t.type === "math" || t.type === "inlineMath") {
			let n = e.startsWith("\\\\[", t.range.start) ? 3 : t.type === "math" || e.startsWith("\\(", t.range.start) ? 2 : 1, r = t.range.start + n;
			if (f.display) for (let e of f.display(t.value ?? "", t.type === "math")) Oh(f, e.code, e.message, r + e.start, r + e.end, {
				key: e.messageKey,
				params: e.params
			});
		} else t.children && g.push(...t.children);
	}
	if (a?.("mathDisplayMs"), o.sort((e, t) => e.range.start - t.range.start || e.range.end - t.range.end), o.some((e) => e.severity === "error")) return qp({
		ok: !1,
		diagnostics: o
	}, d);
	let _ = Zm(f), v = Object.keys(f.computations), y = Object.keys(f.externals), b = Object.keys(f.dynamicConstraints).length ? f.dynamicConstraints : void 0, x = kh(u.nodes, n.sdkByName), S = jh(f, p), C = Mh(f), w = {
		syntax: "local",
		source: e,
		...n.config || !t?.hostComponents ? { componentConfigKey: ee(n) } : {},
		syntaxVersion: de,
		...u.versionDeclaration ? { versionDeclaration: u.versionDeclaration } : {},
		nodes: nh(u.nodes),
		initialState: h,
		bindings: p,
		theme: u.theme ?? "default",
		...u.themeRange ? { themeRange: u.themeRange } : {},
		..._ ? { bindingSlots: _ } : {},
		...v.length ? { computations: f.computations } : {},
		...y.length ? { externals: f.externals } : {},
		...b ? { dynamicConstraints: b } : {},
		...m.length ? { validations: m } : {},
		...x ? { extensions: x } : {},
		kernel: S,
		...C.length ? { componentDefinitions: Object.freeze(C) } : {}
	};
	return Kt(w), wh(w, f.tableShapes), a?.("publicationMs"), qp({
		ok: !0,
		document: w,
		diagnostics: o
	}, d);
}
function em(e) {
	let t = [];
	for (let r of n(e)) r.type === "code" && (r.lang ?? "").trim().toLowerCase() === "reactive-md" && t.push(r);
	return t;
}
function tm(e, t, n, r) {
	let i = [{
		nodes: e,
		parent: t,
		index: 0
	}];
	for (; i.length;) {
		let e = i[i.length - 1];
		if (e.index === e.nodes.length) {
			i.pop();
			continue;
		}
		let t = e.nodes[e.index++], a = e.parent, o = a;
		if ((t.type === "component" || t.type === "hostComponent") && t.name) {
			let e = r.schemaByName.get(t.name);
			if (e) {
				let i = r.definitionsByName.get(t.name), s = Xp(e, i), c = w(s) || i !== void 0 && !i.rules?.length && t.type === "hostComponent", l = {
					node: t,
					name: t.name,
					schema: e,
					kernel: s,
					...i ? { definition: i } : {},
					legacy: c,
					parent: a
				};
				n.push(l), o = l;
			} else if (t.type === "component") {
				let e = Zp(t.name, r.schemaByName.keys());
				r.report("local.component.unknown", `Unknown component <${t.name}>. ${e ? `Did you mean <${e}>?` : "This mode only accepts local interaction components."}`, t.range.start, t.range.end, {
					key: e ? "local.component.unknown.suggestion" : "local.component.unknown",
					params: e ? {
						name: t.name,
						suggestion: e
					} : { name: t.name }
				});
			}
		}
		t.children && i.push({
			nodes: t.children,
			parent: o,
			index: 0
		});
	}
}
function nm(e, t, n) {
	let r = "", i = t;
	for (; i < n; i += 1) {
		let t = e[i];
		if (r) t === r && (r = "");
		else if (t === "\"" || t === "'") r = t;
		else if (t === ">") {
			i += 1;
			break;
		}
	}
	return e.slice(t, i);
}
function rm(e, t, n) {
	if (n.length > Pp) return t.range.start;
	let r = nm(e.source, t.range.start, t.range.end), i = RegExp(`(?:^|[\\s"'/])${n.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}(?=\\s|=|/|>)`).exec(r);
	return i ? t.range.start + i.index + (i[0].length - n.length) : t.range.start;
}
function im(e, t) {
	if (!t.semantic) return am(e, t);
	let n = e.name + "\0" + nm(t.source, e.node.range.start, e.node.range.end), r = t.semantic.attributes(n), i = (e, t) => Object.fromEntries(Object.entries(e).map(([e, n]) => [e, {
		...n,
		offset: n.offset + t,
		...n.expressionOffset === void 0 ? {} : { expressionOffset: n.expressionOffset + t },
		...Array.isArray(n.value) ? { value: zp(n.value) } : {}
	}]));
	if (r) return i(r.value, e.node.range.start - r.origin);
	let a = t.diagnostics.length, o = am(e, t);
	return a < 100 && t.diagnostics.length === a && t.semantic.rememberAttributes(n, e.node.range.start, i(o, 0)), o;
}
function am(t, n) {
	let r = {}, i = t.node.attrs ?? {}, a = t.kernel.props, o = t.legacy, s = o ? om(t) : void 0;
	for (let [c, l] of Object.entries(i)) {
		let i = rm(n, t.node, c);
		if (o && l.length > 1e5) {
			n.report("local.budget.attribute", `Attribute ${c} on component <${t.name}> exceeds the ${xe}-character limit.`, i, i + c.length, {
				key: "local.budget.attribute",
				params: {
					name: c,
					component: t.name,
					limit: xe
				}
			});
			continue;
		}
		if (s?.bind.has(c) || s?.initial.has(c)) {
			r[c] = sm(t, c, l, i);
			continue;
		}
		let u = a[c];
		if (!u) {
			let e = te(c, Object.keys(a));
			o ? n.report("local.host.attribute", `Component <${t.name}> does not support attribute ${c}.`, i, i + c.length, {
				key: "local.host.attribute.unknown",
				params: {
					component: t.name,
					name: c
				}
			}) : n.report("local.attribute.unknown", `Component <${t.name}> does not support attribute ${c}.${e ? ` Did you mean ${e}?` : ""}`, i, i + c.length, {
				key: e ? "local.attribute.unknown.suggestion" : "local.attribute.unknown",
				params: e ? {
					component: t.name,
					name: c,
					suggestion: e
				} : {
					component: t.name,
					name: c
				}
			});
			continue;
		}
		let d = {
			raw: l,
			offset: i,
			dynamic: !1
		};
		if (u.kind === "string" && l.length > 1e5 && (n.report("local.budget.attribute", `Attribute ${c} on component <${t.name}> exceeds the ${xe}-character limit.`, i, i + c.length, {
			key: "local.budget.attribute",
			params: {
				name: c,
				component: t.name,
				limit: xe
			}
		}), d.raw = l.slice(0, xe)), lm(t, c, u, d, n, o), u.color) {
			let r = Bp(d.raw);
			r.segments.length || r.unterminated.length || e(d.raw) || n.report("local.attribute.color", `Attribute ${c} on component <${t.name}> must be a standard CSS named color or #RGB/#RRGGBB, got "${d.raw}".`, i, i + c.length, {
				key: "local.attribute.color",
				params: {
					name: c,
					component: t.name,
					value: d.raw
				}
			});
		}
		r[c] = d;
	}
	for (let [e, i] of Object.entries(a)) s?.bind.has(e) || s?.initial.has(e) || i.required && i.default === void 0 && !Object.hasOwn(r, e) && (o ? n.report("local.host.attribute", `Component <${t.name}> is missing required attribute ${e}.`, t.node.range.start, t.node.range.end, {
		key: "local.host.attribute.required",
		params: {
			component: t.name,
			name: e
		}
	}) : n.report("local.attribute.required", `Component <${t.name}> is missing required attribute ${e}.`, t.node.range.start, t.node.range.end, {
		key: "local.attribute.required",
		params: {
			component: t.name,
			name: e
		}
	}));
	return T(t.kernel).label === "required" && (Object.hasOwn(r, "label") ? String(r.label.raw).trim() || n.report("local.label.required", `Component <${t.name}> label cannot be empty.`, r.label.offset, void 0, {
		key: "local.label.required.empty",
		params: { component: t.name }
	}) : n.report("local.label.required", `Component <${t.name}> requires a label.`, t.node.range.start, t.node.range.end, {
		key: "local.label.required.missing",
		params: { component: t.name }
	})), r;
}
function om(e) {
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = E(e.kernel);
	r && (t.add(r.bind), n.add(r.initial));
	for (let r of M(e.kernel)) t.add(r.bind), n.add(r.initial);
	return t.size || n.size ? {
		bind: t,
		initial: n
	} : void 0;
}
function sm(e, t, n, r) {
	let i = E(e.kernel), a = i && i.bind === t ? i : M(e.kernel).find((e) => e.bind === t || e.initial === t) ?? (i && i.initial === t ? i : void 0), o = {
		raw: n,
		offset: r,
		dynamic: !1
	};
	if (!a || a.bind === t) return o.value = n, o;
	if (a.kind === "number") {
		let e = Rp(n);
		e !== null && (o.value = e);
	} else a.kind === "boolean" ? (n === "true" || n === "false") && (o.value = n === "true") : o.value = n;
	return o;
}
function cm(e) {
	return e.values ?? e.enum ?? [];
}
function lm(e, t, n, r, i, a) {
	let o = a ? "local.host.attribute.static" : "local.attribute.static", s = a ? "local.host.attribute" : "local.attribute.static";
	if (n.kind === "string") {
		if (n.dynamic) {
			let e = Vp(r.raw);
			if (e) {
				r.dynamic = !0, r.expression = e.expression, r.expressionOffset = r.offset + e.start, e.expression || i.report("local.expression.empty", `Attribute ${t} interpolation cannot be empty.`, r.expressionOffset, void 0, {
					key: "local.expression.empty.attribute",
					params: { name: t }
				});
				return;
			}
		}
		if (n.static) {
			let e = Bp(r.raw);
			(e.segments.length || e.unterminated.length) && i.report(s, `Attribute ${t} is static and cannot contain interpolations.`, r.offset, r.offset + r.raw.length, {
				key: o,
				params: { name: t }
			}), r.value = r.raw;
			return;
		}
		if (n.dynamic === !1) {
			let e = Bp(r.raw);
			if (e.segments.length || e.unterminated.length) {
				i.report(a ? "local.host.attribute" : "local.attribute.interpolation", `Attribute ${t} does not accept interpolations.`, r.offset, r.offset + r.raw.length, {
					key: "local.attribute.interpolation.dynamic",
					params: { name: t }
				});
				return;
			}
		}
		if (n.pattern !== void 0) {
			let e = Bp(r.raw);
			if (e.segments.length > 0 || e.unterminated.length > 0) {
				Ah(r.raw) || i.report(a ? "local.host.attribute" : "local.attribute.interpolation", `Attribute ${t} must be a literal matching ${n.pattern} or one full interpolation.`, r.offset, r.offset + r.raw.length, {
					key: a ? "local.host.attribute.interpolation" : "local.attribute.interpolation.pattern",
					params: {
						name: t,
						pattern: n.pattern
					}
				}), r.value = r.raw;
				return;
			}
			let o = !0;
			try {
				o = new RegExp(n.pattern).test(r.raw);
			} catch {}
			o || (a ? i.report("local.host.attribute", `Attribute ${t} must match pattern ${n.pattern}.`, r.offset, r.offset + r.raw.length, {
				key: "local.host.attribute.pattern",
				params: {
					name: t,
					pattern: n.pattern
				}
			}) : i.report("local.attribute.type", `Attribute ${t} must match pattern ${n.pattern}.`, r.offset, r.offset + r.raw.length, {
				key: "local.attribute.type.pattern",
				params: {
					name: t,
					pattern: n.pattern
				}
			})), r.value = r.raw;
			return;
		}
		r.value = r.raw;
		return;
	}
	let c = n.static !== !0 && n.dynamic !== !1 && (n.dynamic === !0 || a);
	if (n.kind === "number") {
		let e = c ? Vp(r.raw) : null;
		if (e) {
			r.dynamic = !0, r.expression = e.expression, r.expressionOffset = r.offset + e.start, e.expression || i.report("local.expression.empty", `Attribute ${t} interpolation cannot be empty.`, r.expressionOffset, void 0, {
				key: "local.expression.empty.attribute",
				params: { name: t }
			});
			return;
		}
		let o = Rp(r.raw);
		if (o === null) {
			a ? i.report("local.host.attribute", `Attribute ${t} requires a number, got "${r.raw}".`, r.offset, r.offset + r.raw.length, {
				key: "local.host.attribute.type",
				params: {
					name: t,
					value: r.raw,
					kind: "number"
				}
			}) : i.report("local.attribute.type", `Attribute ${t} requires a number${n.dynamic ? " or a full number interpolation" : ""}, got "${r.raw}".`, r.offset, r.offset + r.raw.length, {
				key: n.dynamic ? "local.attribute.type.number-interpolation" : "local.attribute.type.number",
				params: {
					name: t,
					value: r.raw
				}
			});
			return;
		}
		n.integer && !Number.isInteger(o) && (a ? i.report("local.host.attribute", `Attribute ${t} requires an integer, got "${r.raw}".`, r.offset, r.offset + r.raw.length, {
			key: "local.attribute.type.integer",
			params: { name: t }
		}) : i.report("local.attribute.type", `Attribute ${t} requires an integer.`, r.offset, void 0, {
			key: "local.attribute.type.integer",
			params: { name: t }
		})), n.positive && !(o > 0) && i.report("local.attribute.type", `Attribute ${t} requires a positive number.`, r.offset, void 0, {
			key: "local.attribute.type.positive",
			params: { name: t }
		}), n.min !== void 0 && o < n.min && (a ? i.report("local.host.attribute", `Attribute ${t} must be at least ${n.min}, got "${r.raw}".`, r.offset, r.offset + r.raw.length, {
			key: "local.attribute.range.min",
			params: {
				name: t,
				min: n.min
			}
		}) : i.report("local.attribute.range", `Attribute ${t} must be at least ${n.min}.`, r.offset, void 0, {
			key: "local.attribute.range.min",
			params: {
				name: t,
				min: n.min
			}
		})), n.max !== void 0 && o > n.max && (a ? i.report("local.host.attribute", `Attribute ${t} must be at most ${n.max}, got "${r.raw}".`, r.offset, r.offset + r.raw.length, {
			key: "local.attribute.range.max",
			params: {
				name: t,
				max: n.max
			}
		}) : i.report("local.attribute.range", `Attribute ${t} must be at most ${n.max}.`, r.offset, void 0, {
			key: "local.attribute.range.max",
			params: {
				name: t,
				max: n.max
			}
		})), r.value = o;
		return;
	}
	if (n.kind === "boolean") {
		let o = c ? Vp(r.raw) : null;
		if (o) {
			r.dynamic = !0, r.expression = o.expression, r.expressionOffset = r.offset + o.start, o.expression || i.report("local.expression.empty", `Attribute ${t} interpolation cannot be empty.`, r.expressionOffset, void 0, {
				key: "local.expression.empty.attribute",
				params: { name: t }
			});
			return;
		}
		if (r.raw === "true" || r.raw === "false") {
			r.value = r.raw === "true";
			return;
		}
		a ? i.report("local.host.attribute", `Component <${e.name}> attribute ${t} requires a boolean, got "${r.raw}".`, r.offset, r.offset + r.raw.length, {
			key: "local.host.attribute.type",
			params: {
				name: t,
				value: r.raw,
				kind: "boolean"
			}
		}) : i.report("local.attribute.type", `Attribute ${t} requires true or false${n.dynamic ? ", or a full boolean interpolation" : ""}.`, r.offset, r.offset + r.raw.length, {
			key: n.dynamic ? "local.attribute.type.boolean-interpolation" : "local.attribute.type.boolean",
			params: { name: t }
		});
		return;
	}
	let l = c ? Vp(r.raw) : null;
	if (l) {
		r.dynamic = !0, r.expression = l.expression, r.expressionOffset = r.offset + l.start, l.expression || i.report("local.expression.empty", `Attribute ${t} interpolation cannot be empty.`, r.expressionOffset, void 0, {
			key: "local.expression.empty.attribute",
			params: { name: t }
		});
		return;
	}
	let u = cm(n);
	u.includes(r.raw) ? r.value = r.raw : a ? i.report("local.host.attribute", `Attribute ${t} must be one of ${u.join(" / ")}, got "${r.raw}".`, r.offset, r.offset + r.raw.length, {
		key: "local.host.attribute.enum",
		params: {
			name: t,
			values: u.join(" / "),
			value: r.raw
		}
	}) : i.report("local.attribute.type", `Attribute ${t} must be one of ${u.join(" / ")}, got "${r.raw}".`, r.offset, r.offset + r.raw.length, {
		key: "local.attribute.type.enum",
		params: {
			name: t,
			values: u.join(" / "),
			value: r.raw
		}
	});
}
function um(e, t, n) {
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.kernel.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function dm(e, t) {
	if (!e.legacy) return;
	let n = E(e.kernel), r = n?.kind === "number" ? n.constraints?.step : void 0;
	if (!r || !("prop" in r)) return;
	let i = t.attrs.get(e.node.id) ?? {}, a = r.prop, o = e.kernel.props[a], s = i[a], c = s?.offset ?? rm(t, e.node, a);
	if (s) s.dynamic ? t.report("local.host.attribute", `Attribute ${a} is used as a step and must be a static number.`, c, c + s.raw.length, {
		key: "local.host.attribute.static",
		params: { name: a }
	}) : typeof s.value == "number" && !(s.value > 0) && t.report("local.host.attribute", `Attribute ${a} requires a positive number.`, c, c + s.raw.length, {
		key: "local.attribute.type.positive",
		params: { name: a }
	});
	else {
		let n = o?.default;
		typeof n == "number" ? n > 0 || t.report("local.host.attribute", `Attribute ${a} requires a positive number.`, e.node.range.start, e.node.range.end, {
			key: "local.attribute.type.positive",
			params: { name: a }
		}) : t.report("local.host.attribute", `Attribute ${a} is required by the step constraint.`, e.node.range.start, e.node.range.end, {
			key: "local.host.attribute.type",
			params: {
				name: a,
				value: "missing",
				kind: "number"
			}
		});
	}
}
function fm(e, t) {
	let n = t.attrs.get(e.node.id) ?? {};
	for (let r of m(e.kernel, n, e.node.range)) t.report(r.code, r.message, r.start, r.end, {
		key: r.key,
		...r.params ? { params: r.params } : {}
	});
}
function pm(e, t) {
	let n = [];
	for (let r of e.node.children ?? []) (r.type === "component" || r.type === "hostComponent") && r.name && t.schemaByName.has(r.name) && n.push({
		node: r,
		name: r.name
	});
	return n;
}
function mm(e, t) {
	switch (t) {
		case "options": return e.options;
		case "tabs": return e.tabs;
		case "steps": return e.steps;
		case "diagram-nodes": return e.diagramNodes;
	}
}
function hm(e, t, n, r) {
	n === "selection" ? e.selections.set(t.node.id, r) : n !== "checklist" && mm(e, n).set(t.node.id, r);
}
function gm(e) {
	return e.children ?? e.items ?? (e.child ? [e.child] : []);
}
function _m(e) {
	return e.min ?? e.minItems ?? 0;
}
function vm(e, t) {
	if (gm(T(e.kernel)).includes(t)) return !0;
	for (let n of x(e.kernel)) switch (n.kind) {
		case "options-body":
		case "value-sequence":
			if (n.child === t) return !0;
			break;
		case "only-children":
			if (n.children.includes(t)) return !0;
			break;
		case "data-table":
			if (n.child === t) return !0;
			break;
		case "quiz-body":
			if (n.child === t) return !0;
			break;
		case "diagram-body": if (n.node === t || n.edge === t) return !0;
	}
	return !1;
}
function ym(e) {
	return e.max ?? e.maxItems ?? e.maxItemsCount ?? e.maxItems;
}
var bm = /* @__PURE__ */ new Set([
	"text",
	"emphasis",
	"strong",
	"delete",
	"underline",
	"mark",
	"link",
	"image",
	"inlineCode",
	"inlineMath",
	"interpolation",
	"break",
	"comment",
	"fallback",
	"footnoteReference"
]);
function xm(e) {
	return bm.has(e.type) && (e.children ?? []).every(xm);
}
function Sm(e, t, n, r) {
	r && ((t.length === 1 && t[0].type === "paragraph" ? t[0].children ?? [] : t).every(xm) || n.report("local.structure.children", `<${e.name}> only accepts inline Markdown.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.inline-only",
		params: { name: e.name }
	}));
	for (let r of t) Kp(r) && n.report("local.structure.children", `The body of <${e.name}> cannot contain other interactive components.`, r.range.start, r.range.end, {
		key: "local.structure.no-nested-components",
		params: { name: e.name }
	});
}
function Cm(e, t) {
	let n = (r) => {
		for (let i of r) i.type === "component" || i.type === "hostComponent" ? t.report("local.structure.children", `The body of <${e.name}> cannot contain interactive components.`, i.range.start, i.range.end, {
			key: "local.structure.no-components",
			params: { name: e.name }
		}) : i.children && n(i.children);
	};
	n(e.node.children ?? []);
}
function wm(e, t, n, r, i, a, o, s) {
	let c = pm(e, t), l = c.filter((e) => e.name === r);
	l.length || t.report("local.structure.children", `<${e.name}> requires at least one <${r} value="...">.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.options.needed",
		params: { name: e.name }
	});
	for (let n of c) n.name !== r && t.report("local.structure.children", `<${e.name}> can only contain <${r}>.`, n.node.range.start, n.node.range.end, {
		key: "local.structure.options.only",
		params: { name: e.name }
	});
	Up(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || e.name !== r) && t.report("local.structure.children", `<${e.name}> can only contain <${r}>.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.options.only",
		params: { name: e.name }
	}), l.length > o && t.report("local.budget.array", `<${e.name}> options exceed the limit of ${o}.`, e.node.range.start, e.node.range.end, {
		key: "local.budget.array.options",
		params: {
			name: e.name,
			limit: o
		}
	});
	let u = [];
	for (let n of l) {
		let o = t.attrs.get(n.node.id) ?? {}, c = typeof o[i]?.value == "string" ? o[i].value : "";
		c ? s !== void 0 && c.includes(s) ? t.report("local.option.value", `<${e.name}> option values cannot contain ${s}: "${c}".`, n.node.range.start, n.node.range.end, {
			key: "local.option.value.comma",
			params: { value: c }
		}) : a && u.includes(c) ? t.report("local.option.value", `Option values in <${e.name}> must be unique; duplicate value "${c}".`, n.node.range.start, n.node.range.end, {
			key: "local.option.value.duplicate",
			params: {
				name: e.name,
				value: c
			}
		}) : ((n.node.children ?? []).some(Kp) && t.report("local.structure.children", `The body of <${r}> cannot contain interactive components.`, n.node.range.start, n.node.range.end, { key: "local.structure.option.no-components" }), u.push(c)) : t.report("local.option.value", `<${r}> requires a non-empty ${i}.`, n.node.range.start, n.node.range.end, { key: "local.option.value.required" });
	}
	hm(t, e, "options", u);
}
function Tm(e, t, n, r, i, a) {
	let o = pm(e, t), s = o.filter((e) => e.name === n);
	s.length || t.report("local.structure.children", `<${e.name}> requires at least one <${n}>.`, e.node.range.start, e.node.range.end, { key: `local.structure.${e.name}.needs-${n}` });
	for (let r of o) r.name !== n && t.report("local.structure.children", `<${e.name}> can only contain <${n}>.`, r.node.range.start, r.node.range.end, { key: `local.structure.${e.name}.only-${n}` });
	Up(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || e.name !== n) && t.report("local.structure.children", `<${e.name}> can only contain <${n}>.`, e.node.range.start, e.node.range.end, { key: `local.structure.${e.name}.only-${n}` });
	let c = [];
	s.forEach((n, o) => {
		let s = t.attrs.get(n.node.id) ?? {}, l = (typeof s[r]?.value == "string" ? s[r].value.trim() : "") || `${i}${o + 1}`;
		c.includes(l) ? t.report(a, `Values in <${e.name}> must be unique; duplicate value "${l}".`, n.node.range.start, n.node.range.end, {
			key: `${a}.duplicate`,
			params: { value: l }
		}) : c.push(l);
	});
	let l = E(e.kernel)?.family;
	hm(t, e, S(l ?? "") === "tabs" ? "tabs" : "steps", c);
}
function Em(e, t, n, r, i, a, o) {
	let s = pm(e, t), c = s.filter((e) => n.includes(e.name)), l = n.map((e) => `<${e}>`).join(" or "), u = i !== void 0 && o === "local.budget.data-table.columns" ? Math.min(i, 20) : i;
	c.length < r && t.report("local.structure.children", `<${e.name}> requires at least ${r} ${l}.`, e.node.range.start, e.node.range.end, { key: `local.structure.${e.name}.needs-${n[0]}` }), u !== void 0 && c.length > u && t.report(o ?? "local.budget.array", `<${e.name}> supports at most ${u} ${l}, but has ${c.length}.`, e.node.range.start, e.node.range.end);
	for (let r of s) n.includes(r.name) || t.report("local.structure.children", `Direct children of <${e.name}> must be ${l}.`, r.node.range.start, r.node.range.end, { key: a ?? `local.structure.${e.name}.only` });
	Up(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || !e.name || !t.schemaByName.has(e.name)) && t.report("local.structure.children", `Direct children of <${e.name}> must be ${l}.`, e.node.range.start, e.node.range.end, { key: a ?? `local.structure.${e.name}.only` });
}
function Dm(e, t, n) {
	let r = pm(e, t), i = r.filter((e) => e.name === n.node), a = r.filter((e) => e.name === n.edge);
	i.length || t.report("local.diagram.node", `<${e.name}> requires at least one <${n.node}>.`, e.node.range.start, e.node.range.end, { key: "local.diagram.node.required" });
	for (let i of r) i.name !== n.node && i.name !== n.edge && t.report("local.structure.children", `<${e.name}> can only contain <${n.node}> and <${n.edge}>.`, i.node.range.start, i.node.range.end, { key: "local.structure.diagram.only" });
	Up(e.node.children).some((e) => e.type !== "component" && e.type !== "hostComponent" || !e.name || e.name !== n.node && e.name !== n.edge) && t.report("local.structure.children", `<${e.name}> can only contain <${n.node}> and <${n.edge}>.`, e.node.range.start, e.node.range.end, { key: "local.structure.diagram.only" });
	let o = [];
	for (let e of i) {
		let r = (t.attrs.get(e.node.id) ?? {})[n.id]?.value, i = typeof r == "string" ? r : "";
		i && (/^[A-Za-z_][A-Za-z0-9_-]*$/.test(i) || t.report("local.diagram.node", `Node ID "${i}" may only contain letters, digits, underscores and hyphens, and cannot start with a digit.`, e.node.range.start, e.node.range.end, {
			key: "local.diagram.node.invalid",
			params: { id: i }
		}), o.includes(i) ? t.report("local.diagram.node", `Duplicate node ID "${i}".`, e.node.range.start, e.node.range.end, {
			key: "local.diagram.node.duplicate",
			params: { id: i }
		}) : o.push(i));
	}
	hm(t, e, "diagram-nodes", o);
	let s = /* @__PURE__ */ new Set();
	for (let e of a) {
		let r = t.attrs.get(e.node.id) ?? {}, i = r[n.from]?.value, a = r[n.to]?.value, c = n.label ? r[n.label]?.value : void 0, l = typeof i == "string" ? i : "", u = typeof a == "string" ? a : "", d = typeof c == "string" ? c : "";
		l && !o.includes(l) && t.report("local.diagram.edge", `Edge from references unknown node "${l}".`, e.node.range.start, e.node.range.end, {
			key: "local.diagram.edge.from",
			params: { id: l }
		}), u && !o.includes(u) && t.report("local.diagram.edge", `Edge to references unknown node "${u}".`, e.node.range.start, e.node.range.end, {
			key: "local.diagram.edge.to",
			params: { id: u }
		});
		let f = `${l}\u0000${u}\u0000${d}`;
		s.has(f) && t.report("local.diagram.edge", `Duplicate edge: ${l} → ${u}${d ? ` (${d})` : ""}.`, e.node.range.start, e.node.range.end, {
			key: "local.diagram.edge.duplicate",
			params: {
				from: l,
				to: u,
				label: d ? ` (${d})` : ""
			}
		}), s.add(f);
	}
}
function Om(e, t, n, r) {
	let i = typeof n[r.type]?.value == "string" ? String(n[r.type].value) : "choice", a = Hm(e, n, r.answer) ?? "";
	if (a.trim() || t.report("local.quiz.answer", `<${e.name}> requires a non-empty ${r.answer}.`, n[r.answer]?.offset ?? e.node.range.start, void 0, { key: "local.quiz.answer.required" }), i === "number") {
		Up(e.node.children).length && t.report("local.structure.children", `A numeric <${e.name}> cannot have body content; use type="choice" for option-based quizzes.`, e.node.range.start, e.node.range.end, { key: "local.structure.quiz.numeric-no-body" }), a.trim() && Rp(a) === null && t.report("local.quiz.answer", `A numeric <${e.name}> answer must be a finite number.`, n[r.answer]?.offset ?? e.node.range.start, void 0, { key: "local.quiz.answer.numeric" });
		let i = um(e, n, r.tolerance);
		i !== void 0 && (!Number.isFinite(i) || i < 0) && t.report("local.constraint", `<${e.name}> tolerance must be a nonnegative finite number.`, n[r.tolerance]?.offset ?? e.node.range.start, void 0, { key: "local.constraint.quiz-tolerance" });
		return;
	}
	wm(e, t, n, r.child, r.valueAttribute, !0, Math.min(r.max ?? 1e4, _e), void 0);
	let o = t.options.get(e.node.id) ?? [];
	a.trim() && o.length && !o.includes(a) && t.report("local.quiz.answer", `<${e.name}> answer "${a}" is not one of the option values: ${o.join(", ")}.`, n[r.answer]?.offset ?? e.node.range.start, void 0, {
		key: "local.quiz.answer.not-option",
		params: {
			answer: a,
			options: o.join(", ")
		}
	});
}
function km(e, t) {
	let n = t.attrs.get(e.node.id) ?? {}, r = Up(e.node.children), i = t.report, a = T(e.kernel), o = x(e.kernel);
	a.parents && (e.parent === null || !a.parents.includes(e.parent.name) && !vm(e.parent, e.name)) && i("local.structure.parent", `<${e.name}> can only appear directly inside ${a.parents.map((e) => `<${e}>`).join(" or ")}.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.parent",
		params: {
			name: e.name,
			parents: a.parents.map((e) => `<${e}>`).join(" / ")
		}
	});
	let s = !1, l = !1;
	for (let c of o) switch (c.kind) {
		case "inline-body":
			s = !0, Sm(e, r, t, c.strict === !0 || a.inlineOnly === !0);
			break;
		case "no-components":
			s = !0, Cm(e, t);
			break;
		case "single-table": {
			s = !0, l = !0;
			let n = r.filter((e) => e.type === "table");
			(n.length !== 1 || r.length !== 1) && i("local.structure.children", `The body of <${e.name}> must be exactly one Markdown table.`, e.node.range.start, e.node.range.end, {
				key: "local.structure.table.single",
				params: { name: e.name }
			}), n.length ? t.tables.set(e.node.id, n[0]) : c.fallbackSingle === !0 && r.length === 1 && t.tables.set(e.node.id, r[0]);
			break;
		}
		case "math-body":
			s = !0, l = !0, r.filter((e) => e.type === "math").length || i("local.structure.children", `<${e.name}> requires at least one $$...$$ formula block.`, e.node.range.start, e.node.range.end, { key: "local.structure.plot.needs-formula" });
			for (let t of r) t.type !== "math" && i("local.structure.children", `The body of <${e.name}> can only contain blank lines and $$...$$ formula blocks.`, t.range.start, t.range.end, { key: "local.structure.plot.only-formulas" });
			break;
		case "options-body":
			s = !0, l = !0, wm(e, t, n, c.child, c.valueAttribute, c.unique, Math.min(c.max ?? 1e4, _e), c.forbidSeparator);
			break;
		case "value-sequence":
			s = !0, l = !0, Tm(e, t, c.child, c.valueAttribute, c.generatedPrefix, c.duplicateCode ?? `local.${c.child}.value`);
			break;
		case "only-children":
			s = !0, l = !0, Em(e, t, c.children, c.min, c.max, c.onlyCode, c.maxCode);
			break;
		case "diagram-body":
			s = !0, l = !0, Dm(e, t, c);
			break;
		case "quiz-body":
			s = !0, l = !0, Om(e, t, n, c);
			break;
		case "checklist-body": s = !0, l = !0, Am(e, t, Math.min(c.itemLimit, _e));
	}
	if (!s) switch (a.rule) {
		case "none":
			r.length && (e.legacy ? i("local.host.structure", `Host component <${e.name}> is a leaf and cannot have body content.`, r[0].range.start, r[0].range.end, {
				key: "local.host.structure.leaf",
				params: { component: e.name }
			}) : i("local.structure.children", `<${e.name}> does not accept body content.`, r[0].range.start, r[0].range.end, {
				key: "local.structure.no-body",
				params: { name: e.name }
			}));
			break;
		case "inline":
			Sm(e, r, t, a.inlineOnly === !0 || a.markdown === "inline");
			break;
		case "content":
			(a.noComponents === !0 || a.allowComponents === !1) && Cm(e, t);
			break;
		case "components": {
			(a.noComponents === !0 || a.allowComponents === !1) && Cm(e, t);
			let n = gm(a);
			if (n.length) {
				l = !0;
				let r = c(e.kernel, "data-table");
				Em(e, t, n, _m(a), ym(a), void 0, r ? "local.budget.data-table.columns" : void 0);
			}
			break;
		}
		case "options":
			l = !0, wm(e, t, n, gm(a)[0] ?? "option", a.valueAttribute ?? "value", !0, Math.min(a.maxItems ?? 1e4, _e), a.forbidSeparator);
			break;
		case "tabs":
		case "steps": l = !0, Tm(e, t, gm(a)[0] ?? (a.rule === "tabs" ? "tab" : "step"), a.valueAttribute ?? "value", a.generatedPrefix ?? a.valuePrefix ?? `${a.rule === "tabs" ? "tab" : "step"}-`, `local.${a.rule === "tabs" ? "tab" : "step"}.value`);
	}
	let u = _m(a);
	!l && u > 0 && r.length < u && i(e.legacy ? "local.host.structure" : "local.structure.children", `Component <${e.name}> requires body content.`, e.node.range.start, e.node.range.end, {
		key: e.legacy ? "local.host.structure.leaf" : "local.structure.content-required",
		params: { component: e.name }
	});
	let d = ym(a);
	!l && d !== void 0 && r.length > d && i("local.structure.children", `<${e.name}> accepts at most ${d} body blocks.`, e.node.range.start, e.node.range.end, {
		key: "local.structure.body-max",
		params: {
			name: e.name,
			max: d
		}
	});
}
function Am(e, t, n = _e) {
	let r = t.checklists.get(e.node.id);
	if (r) return r;
	let i = Up(e.node.children), a = i.filter((e) => e.type === "list");
	(i.length !== 1 || a.length !== 1) && t.report("local.checklist.body", `The body of <${e.name}> must be exactly one single-level Markdown task list.`, e.node.range.start, e.node.range.end, { key: "local.checklist.body.single" });
	let o = a[0], s = [], c = [];
	if (!o) return t.checklists.set(e.node.id, {
		ids: s,
		checked: c
	}), {
		ids: s,
		checked: c
	};
	let l = o.children ?? [];
	l.length || t.report("local.checklist.body", `<${e.name}> requires at least one task list item.`, o.range.start, o.range.end, { key: "local.checklist.body.item-required" }), l.length > n && t.report("local.budget.array", `<${e.name}> items exceed the limit of ${n}.`, o.range.start, o.range.end, {
		key: "local.checklist.body.items-limit",
		params: { limit: n }
	}), l.slice(0, n).forEach((n, r) => {
		if (n.type !== "listItem" || n.checked === null || n.checked === void 0) {
			t.report("local.checklist.body", `<${e.name}> can only contain task list items (- [ ] / - [x]).`, n.range.start, n.range.end, { key: "local.checklist.body.task-only" });
			return;
		}
		(n.children ?? []).some((e) => e.type === "list") && t.report("local.checklist.body", `<${e.name}> does not support nested lists.`, n.range.start, n.range.end, { key: "local.checklist.body.no-nested" }), Kp(n) && t.report("local.checklist.body", `<${e.name}> items cannot contain interactive components.`, n.range.start, n.range.end, { key: "local.checklist.body.no-components" });
		let i = `item-${r + 1}`;
		s.push(i), n.checked && c.push(i);
	});
	let u = {
		ids: s,
		checked: c
	};
	return t.checklists.set(e.node.id, u), u;
}
function jm(e, t, n, r) {
	t.required && !Object.hasOwn(n, t.bind) && r.report("local.attribute.required", `Component <${e.name}> requires attribute "${t.bind}".`, e.node.range.start, e.node.range.end, {
		key: "local.attribute.required",
		params: {
			component: e.name,
			name: t.bind
		}
	});
}
function Mm(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of e.entries) {
		let r = E(n.kernel);
		if (!r) continue;
		let i = e.attrs.get(n.node.id) ?? {};
		if (r.requiresAttributes?.some((e) => !Object.hasOwn(i, e))) continue;
		jm(n, r, i, e);
		let a = typeof i[r.bind]?.value == "string" ? String(i[r.bind].value) : "", o = a || `@${n.node.id}`;
		if (Object.hasOwn(i, r.bind)) {
			let t = i[r.bind].offset ?? n.node.range.start;
			a.length > Pp ? (e.report("local.budget.identifier", `Parameter name exceeds the ${Pp}-character limit.`, t, void 0, {
				key: "local.budget.identifier",
				params: { limit: Pp }
			}), o = `@${n.node.id}`) : Np.test(a) ? (A.has(a) || Lp.has(a)) && (e.report("local.binding.reserved", `Parameter name "${a}" is reserved; choose another name.`, t, void 0, {
				key: "local.binding.reserved",
				params: { name: a }
			}), o = `@${n.node.id}`) : (e.report("local.binding.name", `Parameter name "${a}" must match [A-Za-z_][A-Za-z0-9_]*.`, t, void 0, {
				key: "local.binding.name",
				params: { name: a }
			}), o = `@${n.node.id}`);
		}
		let s = t.get(o);
		s ? s.members.push({
			entry: n,
			attrs: i
		}) : t.set(o, {
			key: o,
			binding: r,
			members: [{
				entry: n,
				attrs: i
			}]
		});
	}
	let n = {};
	for (let r of t.values()) {
		let t = r.binding.family, i = e.semantic && t !== "checklist" ? JSON.stringify([r.key, r.members.map(({ entry: n }) => [
			n.name,
			n.node.id,
			n.node.attrs,
			Um(n, e, n.kernel, t)
		])]) : void 0, a = i ? e.semantic.binding(i) : void 0, o = e.diagnostics.length, s = a ? jp(a) : Rm(r, e);
		!a && s && i && o < 100 && e.diagnostics.length === o && e.semantic.rememberBinding(i, jp(s)), s && (n[r.key] = s);
	}
	return Ym(e, n), n;
}
function Nm(e) {
	let t = {};
	for (let [n, r] of Object.entries(e)) n.startsWith("@") || (t[n] = r.type);
	return t;
}
function Pm(e, t) {
	let n = E(e.kernel);
	return n ? pe(e.kernel, n, t) : { step: 1 };
}
var Fm = s, Im = o;
function Lm(e, t) {
	let n = e.attrs[t];
	if (n) return n.dynamic ? `{{ ${(n.expression ?? "").trim()} }}` : typeof n.value == "string" ? n.value : String(n.value ?? "");
}
function Rm(e, t) {
	let n = e.members[0], r = e.binding, i = r.family;
	for (let a of e.members.slice(1)) {
		let o = E(a.entry.kernel);
		o && o.family === i && o.kind === r.kind || t.report("local.binding.type", `Parameter "${e.key}" is already declared as ${$(r.kind)} by <${n.entry.name}> and cannot also bind <${a.entry.name}>.`, a.entry.node.range.start, a.entry.node.range.end, {
			key: "local.binding.type",
			params: {
				key: e.key,
				kind: $(r.kind),
				first: n.entry.name,
				second: a.entry.name
			}
		});
	}
	let a = e.members.find((e) => E(e.entry.kernel)?.exclusive === !0);
	if (a && e.members.length > 1) for (let n of e.members) n !== a && t.report("local.binding.exclusive", `Parameter "${e.key}" of <${a.entry.name}> can only be owned by one component and cannot be shared with <${n.entry.name}>.`, n.entry.node.range.start, n.entry.node.range.end, {
		key: "local.binding.exclusive",
		params: {
			key: e.key,
			first: a.entry.name,
			second: n.entry.name
		}
	});
	let o = Um(n.entry, t, n.entry.kernel, i), s;
	if (r.kind === "number") {
		s = Pm(n.entry, n.attrs);
		for (let r of e.members.slice(1)) {
			let i = Pm(r.entry, r.attrs);
			Fm(i, s, "min") && Fm(i, s, "max") && i.step === s.step || t.report("local.binding.constraint", `Parameter "${e.key}" must use the same numeric range and step: <${n.entry.name}> has ${Im(s)}, <${r.entry.name}> has ${Im(i)}.`, r.entry.node.range.start, r.entry.node.range.end, {
				key: "local.binding.constraint",
				params: {
					key: e.key,
					first: n.entry.name,
					second: r.entry.name,
					firstConstraints: Im(s),
					secondConstraints: Im(i)
				}
			});
		}
	}
	if (i === "choice" || i === "selection") for (let n of e.members.slice(1)) Um(n.entry, t, n.entry.kernel, i).join("\0") !== o.join("\0") && t.report("local.binding.option", `Parameter "${e.key}" must use the same option set in the same order.`, n.entry.node.range.start, n.entry.node.range.end, {
		key: "local.binding.option",
		params: { key: e.key }
	});
	let c = new Set(r.compare ?? []);
	for (let e of x(n.entry.kernel)) e.kind === "date-bounds" && (e.min && c.add(e.min), e.max && c.add(e.max));
	for (let r of c) {
		let i = Lm(n, r);
		for (let a of e.members.slice(1)) Lm(a, r) !== i && t.report("local.binding.constraint", `Parameter "${e.key}" must use the same ${r} bound: <${n.entry.name}> and <${a.entry.name}> differ.`, a.entry.node.range.start, a.entry.node.range.end, {
			key: "local.binding.constraint",
			params: {
				key: e.key,
				first: n.entry.name,
				second: a.entry.name,
				firstConstraints: `${r} bounds`,
				secondConstraints: `${r} bounds`
			}
		});
	}
	let l = r.maxItems ? f(n.entry.kernel, r, n.attrs) : void 0, u = e.members.filter((e) => Object.hasOwn(e.attrs, r.initial)), d;
	if (u.length > 1) {
		let n = u.map((e) => zm(t, e.attrs[r.initial].offset)), i = Math.min(u.length, Fp);
		for (let a = 0; a < i; a += 1) {
			let i = [];
			for (let e = 1; e < n.length && i.length < Ip; e += 1) i.push(n[(a + e) % n.length]);
			t.report("local.initial.duplicate", `Parameter "${e.key}" has multiple explicit initial values (${u.length} in total${i.length ? `; see also line ${i.join(", ")}` : ""}).`, u[a].attrs[r.initial].offset, void 0, i.length ? {
				key: "local.initial.duplicate-peers",
				params: {
					key: e.key,
					count: u.length,
					lines: i.join(", ")
				}
			} : {
				key: "local.initial.duplicate",
				params: {
					key: e.key,
					count: u.length
				}
			});
		}
	}
	d = i === "multi-select" ? u.length ? Gm(u[0], o, l, t, r) : [] : i === "collection" ? u.length ? Wm(u[0], t, r) : [] : u.length > 0 ? Km(u[0], t, r, o) : qm(n, t, r, o, s), i === "checklist" && !Array.isArray(d) && (d = []), Jm(e, n, d, r, o, s, t), Bm(e, d, t);
	let p = {
		family: r.family,
		name: e.key,
		nodeIds: e.members.map((e) => e.entry.node.id),
		type: r.kind,
		initial: zp(d),
		owner: n.entry.node.id
	};
	return s && (s.min !== void 0 && (p.min = s.min), s.max !== void 0 && (p.max = s.max), p.step = s.step), o.length && (p.options = [...o]), i === "multi-select" ? p.maxItems = l ?? o.length : l !== void 0 && (p.maxItems = l), p;
}
function zm(e, t) {
	let n = Math.max(0, Math.min(e.source.length, t)), r = 0, i = e.lineStarts.length - 1;
	for (; r < i;) {
		let t = Math.ceil((r + i) / 2);
		e.lineStarts[t] <= n ? r = t : i = t - 1;
	}
	return r + 1;
}
function Bm(e, t, n, r) {
	if (typeof t != "string" || t === "") return;
	let i = e.members[0], a = E(i.entry.kernel)?.initial ?? "initial", o = r ?? i.attrs[a]?.offset ?? i.entry.node.range.start, s = se(t);
	for (let r of e.members) {
		let { entry: i, attrs: a } = r;
		for (let r of _(i.kernel)) if (r.kind === "length") {
			let t = Vm(i, a, r.min) ?? 0, c = Vm(i, a, r.max);
			t > 0 && s < t && n.report("local.initial.length", `Initial value of parameter "${e.key}" has length ${s}, below the minimum length ${t} required by <${i.name}>.`, o, void 0, {
				key: "local.initial.length.min",
				params: {
					key: e.key,
					length: s,
					min: t,
					name: i.name
				}
			}), c !== void 0 && s > c && n.report("local.initial.length", `Initial value of parameter "${e.key}" has length ${s}, exceeding the maximum length ${c} allowed by <${i.name}>.`, o, void 0, {
				key: "local.initial.length.max",
				params: {
					key: e.key,
					length: s,
					max: c,
					name: i.name
				}
			});
		} else if (r.kind === "email") (Hm(i, a, r.type) ?? "text") === r.value && (t.length > 254 || !P(t)) && n.report("local.initial.email", `Initial value of parameter "${e.key}" is not a valid email address.`, o, void 0, {
			key: "local.initial.email",
			params: { key: e.key }
		});
		else if (r.kind === "date" && p(t)) {
			let s = Hm(i, a, r.min), c = Hm(i, a, r.max);
			s && p(s) && t < s && n.report("local.initial.range", `Initial value ${t} of parameter "${e.key}" is earlier than the minimum date ${s} of <${i.name}>.`, o, void 0, {
				key: "local.initial.date.min",
				params: {
					key: e.key,
					value: t,
					min: s
				}
			}), c && p(c) && t > c && n.report("local.initial.range", `Initial value ${t} of parameter "${e.key}" is later than the maximum date ${c} of <${i.name}>.`, o, void 0, {
				key: "local.initial.date.max",
				params: {
					key: e.key,
					value: t,
					max: c
				}
			});
		}
	}
}
function Vm(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "number" ? r.value : void 0;
	let i = e.kernel.props[n]?.default;
	return typeof i == "number" ? i : void 0;
}
function Hm(e, t, n) {
	if (n === void 0) return;
	let r = t[n];
	if (r) return !r.dynamic && typeof r.value == "string" ? r.value : void 0;
	let i = e.kernel.props[n]?.default;
	return typeof i == "string" ? i : void 0;
}
function Um(e, t, n, r) {
	let i = S(r);
	if (!i) return [];
	if (i === "checklist") {
		let r = c(n, "checklist-body")?.itemLimit;
		return Am(e, t, r).ids;
	}
	if (i === "selection") return t.selections.get(e.node.id) ?? [""];
	let a = mm(t, i).get(e.node.id);
	return a === void 0 ? [...E(n)?.options ?? []] : a;
}
function Wm(e, t, n) {
	let r = e.attrs[n.initial];
	if (!r) return [];
	let i = typeof r.value == "string" ? r.value : String(r.value ?? ""), a;
	try {
		a = JSON.parse(i);
	} catch {
		return t.report("local.initial.type", `Initial value of parameter "${e.entry.node.id}" must be a JSON array.`, r.offset, void 0, {
			key: "local.initial.type.collection",
			params: { key: e.entry.node.id }
		}), [];
	}
	return Array.isArray(a) ? n.kind === "number-array" ? a.every((e) => typeof e == "number" && Number.isFinite(e)) ? a : (t.report("local.initial.type", `Initial value of parameter "${e.entry.node.id}" must contain only finite numbers.`, r.offset, void 0, {
		key: "local.initial.type.number-array",
		params: { key: e.entry.node.id }
	}), []) : a.every((e) => typeof e == "string") ? a : (t.report("local.initial.type", `Initial value of parameter "${e.entry.node.id}" must contain only strings.`, r.offset, void 0, {
		key: "local.initial.type.array",
		params: { key: e.entry.node.id }
	}), []) : (t.report("local.initial.type", `Initial value of parameter "${e.entry.node.id}" must be a JSON array.`, r.offset, void 0, {
		key: "local.initial.type.collection",
		params: { key: e.entry.node.id }
	}), []);
}
function Gm(e, t, n, r, i) {
	let a = e.attrs[i.initial];
	if (!a) return [];
	let o = typeof a.value == "string" ? a.value : String(a.value ?? ""), s = [];
	for (let n of o.split(",").map((e) => e.trim()).filter(Boolean)) t.includes(n) ? s.includes(n) || s.push(n) : r.report("local.initial.option", `Initial value "${n}" of parameter "${e.entry.node.id}" is not an option of <${e.entry.name}>.`, a.offset, void 0, {
		key: "local.initial.option.multi-select",
		params: {
			key: e.entry.node.id,
			value: n
		}
	});
	return n !== void 0 && s.length > n && r.report("local.initial.range", `Initial values of <${e.entry.name}> exceed max-selected ${n}.`, a.offset, void 0, {
		key: "local.initial.multi-select",
		params: { max: n }
	}), t.filter((e) => s.includes(e));
}
function Km(e, t, n, r) {
	let i = e.attrs[n.initial], a = e.entry, o = Pm(a, e.attrs);
	if (!i) return qm(e, t, n, r, void 0);
	if (n.kind === "null") return i.raw.trim() !== "null" && t.report("local.initial.type", `Initial value of parameter "${a.node.id}" must be null.`, i.offset, void 0, {
		key: "local.initial.type",
		params: { name: a.node.id }
	}), null;
	if (a.legacy) {
		let e = Bp(i.raw);
		if (e.segments.length || e.unterminated.length) {
			t.report("local.host.attribute", "Attribute initial is static and cannot contain interpolations.", i.offset, i.offset + i.raw.length, {
				key: "local.host.attribute.static",
				params: { name: n.initial }
			});
			let e = g(n.initialRule, o, r);
			return "value" in e ? e.value : "";
		}
	}
	if (n.kind === "number") return typeof i.value == "number" ? i.value : (t.report("local.initial.type", `Initial value of parameter "${a.node.id}" has the wrong type.`, i.offset, void 0, {
		key: "local.initial.type",
		params: { name: a.node.id }
	}), 0);
	if (n.kind === "boolean") return typeof i.value == "boolean" ? i.value : (t.report("local.initial.type", `Initial value of parameter "${a.node.id}" has the wrong type.`, i.offset, void 0, {
		key: "local.initial.type",
		params: { name: a.node.id }
	}), !1);
	let s = typeof i.value == "string" ? i.value : String(i.value ?? "");
	return _(a.kernel).some((e) => e.kind === "date") && !p(s) && t.report("local.initial.date", `Initial date "${s}" is not a valid YYYY-MM-DD.`, i.offset, void 0, {
		key: "local.initial.date",
		params: { value: s }
	}), r.length && !r.includes(s) && n.family !== "text" && n.family !== "date" && t.report("local.initial.option", `Initial value "${s}" is not an available option: ${r.join(", ")}.`, i.offset, void 0, {
		key: "local.initial.value.option",
		params: {
			value: s,
			options: r.join(", ")
		}
	}), s;
}
function qm(e, t, n, r, i) {
	let a = e.entry;
	if (n.kind === "null") return null;
	if (n.family === "checklist") return [...Am(a, t, c(a.kernel, "checklist-body")?.itemLimit).checked];
	let o = i ?? Pm(a, e.attrs), s = g(n.initialRule, o, r);
	return "value" in s && s.value !== void 0 ? s.value : "error" in s && s.error === "no-step" ? (t.report("local.initial.range", `Parameter "${a.node.id}" has no valid step value within range [${o.min ?? "-∞"}, ${o.max ?? "∞"}].`, a.node.range.start, a.node.range.end, {
		key: "local.initial.no-step",
		params: {
			key: a.node.id,
			min: o.min ?? "-∞",
			max: o.max ?? "∞"
		}
	}), 0) : (t.report("local.initial", `Cannot derive a default initial value for <${a.name}> parameter "${a.node.id}".`, a.node.range.start, a.node.range.end, {
		key: "local.initial.cannot-derive",
		params: {
			name: a.name,
			key: a.node.id
		}
	}), "");
}
function Jm(e, t, n, i, a, o, s) {
	let c = e.key, l = t.attrs[i.initial]?.offset ?? t.entry.node.range.start;
	if (i.kind === "array" || i.kind === "number-array") {
		if (!Array.isArray(n)) {
			s.report("local.initial.type", `Initial value of parameter "${c}" must be an array.`, l, void 0, {
				key: "local.initial.type.array",
				params: { key: c }
			});
			return;
		}
		let e = ne(n);
		if (e) {
			s.report("local.budget.array", `Initial value of parameter "${c}" exceeds the value budget.`, l, void 0, {
				key: e.key,
				params: {
					...e.params,
					key: c
				}
			});
			return;
		}
		if (i.kind === "number-array") {
			if (!n.every((e) => typeof e == "number" && Number.isFinite(e))) {
				s.report("local.initial.type", `Initial value of parameter "${c}" must contain only finite numbers.`, l, void 0, {
					key: "local.initial.type.number-array",
					params: { key: c }
				});
				return;
			}
		} else {
			if (!n.every((e) => typeof e == "string")) {
				s.report("local.initial.type", `Initial value of parameter "${c}" must contain only strings.`, l, void 0, {
					key: "local.initial.type.array",
					params: { key: c }
				});
				return;
			}
			if (a.length) for (let e of n) a.includes(e) || s.report("local.initial.option", `Initial value "${e}" is not an available option: ${a.join(", ")}.`, l, void 0, {
				key: "local.initial.value.option",
				params: {
					value: e,
					options: a.join(", ")
				}
			});
		}
		let r = f(t.entry.kernel, i, t.attrs);
		r !== void 0 && n.length > r && s.report("local.initial.range", `Initial value of parameter "${c}" exceeds the ${r}-item limit.`, l, void 0, {
			key: "local.initial.value.max-items",
			params: {
				key: c,
				max: r
			}
		});
	} else if (i.kind === "number") {
		if (typeof n != "number" || !Number.isFinite(n)) {
			s.report("local.initial.type", `Initial value of parameter "${c}" must be a finite number.`, t.entry.node.range.start, void 0, {
				key: "local.initial.type.number",
				params: { key: c }
			});
			return;
		}
		let e = o ?? Pm(t.entry, t.attrs);
		e.min !== void 0 && n < e.min && s.report("local.initial.range", `Initial value ${n} of parameter "${c}" is below the minimum ${e.min}.`, l, void 0, {
			key: "local.initial.range.min",
			params: {
				value: n,
				key: c,
				min: e.min
			}
		}), e.max !== void 0 && n > e.max && s.report("local.initial.range", `Initial value ${n} of parameter "${c}" exceeds the maximum ${e.max}.`, l, void 0, {
			key: "local.initial.range.max",
			params: {
				value: n,
				key: c,
				max: e.max
			}
		});
		let i = e.min ?? 0;
		e.dynamicMin === void 0 && n >= (e.min ?? -Infinity) && n <= (e.max ?? Infinity) && !r(n, i, e.step) && s.report("local.initial.step", `Initial value ${n} of parameter "${c}" is not on step ${e.step} (based at ${e.min ?? 0}).`, l, void 0, {
			key: "local.initial.range.step",
			params: {
				value: n,
				key: c,
				step: e.step,
				base: e.min ?? 0
			}
		});
	} else i.kind === "boolean" && typeof n != "boolean" && s.report("local.initial.type", `Initial value of parameter "${c}" must be a boolean.`, t.entry.node.range.start, void 0, {
		key: "local.initial.type.boolean",
		params: { key: c }
	}), (i.family === "choice" || i.family === "tabs" || i.family === "steps" || i.family === "diagram" || i.family === "selection") && a.length && !a.includes(String(n)) && s.report("local.initial.option", `Initial value "${String(n)}" of parameter "${c}" is not among the available values ${a.join(", ")}.`, l, void 0, {
		key: "local.initial.value.options",
		params: {
			value: String(n),
			key: c,
			options: a.join(", ")
		}
	});
}
function Ym(e, t) {
	let n = new Set(Object.keys(t)), r = /* @__PURE__ */ new Map();
	for (let [e, n] of Object.entries(t)) for (let t of n.nodeIds) r.set(t, e);
	for (let i of e.entries) {
		let a = M(i.kernel);
		if (!a.length) continue;
		let o = e.attrs.get(i.node.id) ?? {}, s = Object.create(null), c = /* @__PURE__ */ new Map(), l = E(i.kernel);
		if (l && !l.requiresAttributes?.some((e) => !Object.hasOwn(o, e))) {
			let e = r.get(i.node.id);
			e && (s.value = e, c.set("value", e));
		}
		for (let r of a) {
			if (r.requiresAttributes?.some((e) => !Object.hasOwn(o, e))) continue;
			jm(i, r, o, e);
			let a = o[r.bind], l;
			if (a) {
				let t = typeof a.value == "string" ? a.value : "";
				t.length > Pp ? e.report("local.budget.identifier", `Parameter name exceeds the ${Pp}-character limit.`, a.offset ?? i.node.range.start, void 0, {
					key: "local.budget.identifier",
					params: { limit: Pp }
				}) : Np.test(t) ? A.has(t) || Lp.has(t) ? e.report("local.binding.reserved", `Parameter name "${t}" is reserved; choose another name.`, a.offset ?? i.node.range.start, void 0, {
					key: "local.binding.reserved",
					params: { name: t }
				}) : l = t : e.report("local.binding.name", `Parameter name "${t}" must match [A-Za-z_][A-Za-z0-9_]*.`, a.offset ?? i.node.range.start, void 0, {
					key: "local.binding.name",
					params: { name: t }
				});
			}
			let u = l ?? `@${i.node.id}:${r.slot}`;
			l && n.has(l) && (e.report("local.binding.exclusive", `Parameter "${l}" of the ${r.slot} slot of <${i.name}> is exclusive and cannot be shared with another control.`, a?.offset ?? i.node.range.start, void 0, {
				key: "local.binding.exclusive.slot",
				params: {
					key: l,
					slot: r.slot,
					name: i.name
				}
			}), u = `@${i.node.id}:${r.slot}`), n.add(u);
			let d = pe(i.kernel, r, o), f = Xm(i, o, r, d, e), p = {
				name: u,
				nodeIds: [i.node.id],
				type: r.kind,
				initial: f,
				owner: i.node.id
			};
			d.min !== void 0 && (p.min = d.min), d.max !== void 0 && (p.max = d.max), p.step = d.step, t[u] = p, s[r.slot] = u, c.set(r.slot, u);
		}
		for (let n of u(i.kernel)) {
			let r = c.get(n.lower), a = c.get(n.upper);
			if (!r || !a) continue;
			let o = t[r].initial, s = t[a].initial;
			typeof o == "number" && typeof s == "number" && o > s && e.report("local.initial.range", `<${i.name}> ${n.lower} ${o} cannot be greater than ${n.upper} ${s}.`, i.node.range.start, i.node.range.end, {
				key: "local.initial.range-slider",
				params: {
					start: o,
					end: s
				}
			});
		}
		Object.keys(s).length && (e.bindingSlots[i.node.id] = s);
	}
}
function Xm(e, t, n, i, a) {
	let o = i.min ?? 0, s = t[n.initial];
	if (s && typeof s.value == "number") {
		let t = s.value;
		return i.min !== void 0 && t < i.min && a.report("local.initial.range", `Initial value ${t} of <${e.name}> ${n.initial} is below the minimum ${i.min}.`, s.offset, void 0, {
			key: "local.initial.slot.min",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				min: i.min
			}
		}), i.max !== void 0 && t > i.max && a.report("local.initial.range", `Initial value ${t} of <${e.name}> ${n.initial} exceeds the maximum ${i.max}.`, s.offset, void 0, {
			key: "local.initial.slot.max",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				max: i.max
			}
		}), r(t, o, i.step) || a.report("local.initial.step", `Initial value ${t} of <${e.name}> ${n.initial} is not on step ${i.step} (based at ${o}).`, s.offset, void 0, {
			key: "local.initial.slot.step",
			params: {
				value: t,
				name: e.name,
				slot: n.initial,
				step: i.step,
				base: o
			}
		}), t;
	}
	let c = g(n.initialRule, i, []);
	return "value" in c && c.value !== void 0 ? c.value : 0;
}
function Zm(e) {
	return Object.keys(e.bindingSlots).length ? e.bindingSlots : void 0;
}
function Qm(e, t) {
	let n = e.lineStarts[zm(e, t.range.start) - 1], r = e.lineStarts[zm(e, t.range.end)], i = r === void 0 ? e.source.length : r - 1;
	return e.source.slice(n, t.range.start).trim() === "" && e.source.slice(t.range.end, i).trim() === "";
}
function $m(e, t, n) {
	let r = nm(e.source, t.node.range.start, t.node.range.end), i = /(?:^|[\s"'/])value\s*=\s*(["'])/.exec(r);
	if (!i) return t.node.range.start;
	let a = t.node.range.start + i.index + i[0].length;
	return Math.min(t.node.range.end, a + n);
}
function eh(e) {
	let t = [], n = /* @__PURE__ */ new Map(), r = new Set(e.nodes);
	for (let i of e.entries) {
		if (i.name !== "computed" && i.name !== "const") continue;
		let a = i.name, o = i.node;
		if (!r.has(o) || !Qm(e, o)) {
			e.report("local.computation.placement", `<${a}> declarations must be standalone tags at the document top level.`, o.range.start, o.range.end);
			continue;
		}
		let s = e.attrs.get(o.id) ?? {}, c = s.name, l = typeof c?.value == "string" ? c.value : "";
		if (!c || !l) continue;
		if (l.length > Pp) {
			e.report("local.budget.identifier", `Computation name exceeds the ${Pp}-character limit.`, c.offset);
			continue;
		}
		if (!Np.test(l)) {
			e.report("local.computation.name", `Computation name "${l}" must match [A-Za-z_][A-Za-z0-9_]*.`, c.offset);
			continue;
		}
		if (A.has(l) || Lp.has(l)) {
			e.report("local.computation.reserved", `Computation name "${l}" is reserved; choose another name.`, c.offset);
			continue;
		}
		if (Object.hasOwn(e.bindingKinds, l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" conflicts with a control parameter of the same name.`, c.offset);
			continue;
		}
		if (Object.hasOwn(e.externalKinds, l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" conflicts with an external declaration of the same name.`, c.offset);
			continue;
		}
		if (n.has(l)) {
			e.report("local.computation.duplicate", `Computation name "${l}" is declared more than once.`, c.offset);
			continue;
		}
		n.set(l, a);
		let u = s.value;
		if (!u) continue;
		let d = Vp(u.raw);
		d ? d.expression ? t.push({
			name: l,
			kind: a,
			source: d.expression,
			expressionOffset: $m(e, i, d.start),
			nodeId: o.id,
			range: { ...o.range }
		}) : e.report("local.expression.empty", "Interpolation expression cannot be empty.", u.offset) : e.report("local.computation.value", `The value of <${a}> must be exactly one {{ expression }} interpolation.`, u.offset, u.offset + u.raw.length);
	}
	let i = j(t, {
		...e.bindingKinds,
		...e.externalKinds
	}, e.report, new Set(Object.keys(e.externalKinds)), e.semantic);
	e.computations = i.computations, e.computationKinds = i.kinds;
}
function th(e) {
	return {
		...e.bindingKinds,
		...e.externalKinds,
		...e.computationKinds
	};
}
function nh(e) {
	let t = [], n = [{
		nodes: e,
		kept: t,
		index: 0
	}];
	for (; n.length;) {
		let e = n[n.length - 1];
		if (e.index === e.nodes.length) {
			n.pop();
			continue;
		}
		let t = e.nodes[e.index++];
		if ((t.type !== "component" || t.name !== "computed" && t.name !== "const" && t.name !== "external") && (e.kept.push(t), t.children)) {
			let e = t.children;
			t.children = [], n.push({
				nodes: e,
				kept: t.children,
				index: 0
			});
		}
	}
	return t;
}
var rh = {
	string: "string",
	number: "number",
	boolean: "boolean",
	"string-array": "array",
	"number-array": "number-array"
};
function ih(e) {
	let t = new Set(e.nodes);
	for (let n of e.entries) {
		if (n.name !== "external") continue;
		let r = n.node;
		if (!t.has(r) || !Qm(e, r)) {
			e.report("local.external.placement", "<external> declarations must be standalone tags at the document top level.", r.range.start, r.range.end, { key: "local.external.placement" });
			continue;
		}
		let i = e.attrs.get(r.id) ?? {}, a = i.name, o = typeof a?.value == "string" ? a.value : "";
		if (!a || !o) continue;
		if (o.length > Pp) {
			e.report("local.budget.identifier", `External name exceeds the ${Pp}-character limit.`, a.offset, void 0, {
				key: "local.budget.identifier",
				params: { limit: Pp }
			});
			continue;
		}
		if (!Np.test(o)) {
			e.report("local.external.name", `External name "${o}" must match [A-Za-z_][A-Za-z0-9_]*.`, a.offset, void 0, {
				key: "local.external.name",
				params: { name: o }
			});
			continue;
		}
		if (A.has(o) || Lp.has(o)) {
			e.report("local.external.reserved", `External name "${o}" is reserved; choose another name.`, a.offset, void 0, {
				key: "local.external.reserved",
				params: { name: o }
			});
			continue;
		}
		if (Object.hasOwn(e.bindingKinds, o)) {
			e.report("local.external.duplicate", `External name "${o}" conflicts with a control parameter of the same name.`, a.offset, void 0, {
				key: "local.external.conflict",
				params: { name: o }
			});
			continue;
		}
		if (Object.hasOwn(e.externals, o)) {
			e.report("local.external.duplicate", `External name "${o}" is declared more than once.`, a.offset, void 0, {
				key: "local.external.duplicate",
				params: { name: o }
			});
			continue;
		}
		let s = i.type, c = rh[typeof s?.value == "string" ? s.value : ""];
		c ? (e.externals[o] = {
			name: o,
			type: c,
			nodeId: r.id,
			range: { ...r.range }
		}, e.externalKinds[o] = c) : e.report("local.external.type", `External "${o}" must declare type string, number, boolean, string-array or number-array.`, s?.offset ?? r.range.start, void 0, {
			key: "local.external.type",
			params: { name: o }
		});
	}
}
function ah(e) {
	for (let t of e.entries) {
		let n = e.attrs.get(t.node.id) ?? {}, r, i = (e, t, n) => {
			t.dynamic && t.expression !== void 0 && (r ??= {}, r[e] = {
				source: t.expression,
				offset: t.expressionOffset ?? t.offset,
				...n ? { numeric: n } : {}
			});
		};
		for (let e of C(t.kernel, "dynamic-constraints")) for (let t of e.attributes) if (t === "min" || t === "max" || t === "required") {
			let e = n[t];
			e && i(t, e);
		}
		let a = E(t.kernel);
		if (a?.kind === "number" && a.constraints) for (let e of ["min", "max"]) {
			let r = a.constraints[e];
			if (!r || !("prop" in r)) continue;
			let o = n[r.prop];
			if (!o) continue;
			let s = t.kernel.props[r.prop];
			i(e, o, s ? {
				...s.min === void 0 ? {} : { min: s.min },
				...s.max === void 0 ? {} : { max: s.max },
				...s.integer === !0 ? { integer: !0 } : {}
			} : void 0);
		}
		r && (e.dynamicConstraints[t.node.id] = r);
	}
}
function oh(e) {
	let r = th(e), i = Object.keys(r), a = (n, r) => {
		n instanceof t ? e.report(`local.expression.${n.code || "invalid"}`, `Expression error: ${n.message}`, r + (Number.isFinite(n.offset) ? n.offset : 0), void 0, {
			key: "local.expression.error",
			params: {
				detail: n.message,
				code: n.code || "invalid",
				near: e.source.slice(Math.max(r, r + n.offset - 16), r + n.offset + 24)
			}
		}) : e.report("local.expression.invalid", `Expression error: ${n instanceof Error ? n.message : String(n)}`, r, void 0, {
			key: "local.expression.error",
			params: {
				detail: n instanceof Error ? n.message : String(n),
				code: "invalid"
			}
		});
	}, o = (t, n, o) => {
		if (!t.trim()) return e.report("local.expression.empty", "Interpolation expression cannot be empty.", n, void 0, { key: "local.expression.empty" }), null;
		let s = null;
		try {
			s = e.semantic?.expression(t) ?? ce(t);
		} catch (e) {
			return a(e, n), null;
		}
		if (!s) return null;
		let c = !1;
		for (let a of s.dependencies) if (!Object.hasOwn(r, a)) {
			let r = mh(a, i);
			e.report("local.binding.unknown", `Reference to undeclared parameter ${a}.${r ? ` Did you mean ${r}?` : ""}`, n + Math.max(0, t.indexOf(a)), void 0, r ? {
				key: "local.binding.unknown.suggestion",
				params: {
					name: a,
					suggestion: r
				}
			} : {
				key: "local.binding.unknown",
				params: { name: a }
			}), c = !0;
		}
		if (c) return null;
		let l;
		try {
			l = e.semantic ? e.semantic.infer(s, r) : s.inferType(r);
		} catch (e) {
			return a(e, n), null;
		}
		return o === "number" && l !== "number" ? e.report("local.type", `Expected a number here, but the expression evaluates to ${$(l)}.`, n, void 0, {
			key: "local.type.number",
			params: { kind: $(l) }
		}) : o === "boolean" && l !== "boolean" ? e.report("local.type", `Expected a boolean here, but the expression evaluates to ${$(l)}.`, n, void 0, {
			key: "local.type.boolean",
			params: { kind: $(l) }
		}) : o === "string" && l !== "string" ? e.report("local.type", `Expected a string here, but the expression evaluates to ${$(l)}.`, n, void 0, {
			key: "local.type.string",
			params: { kind: $(l) }
		}) : o === "text" && (l === "array" || l === "number-array") && e.report("local.type", "Arrays cannot be displayed directly; convert them first with a function such as len.", n, void 0, { key: "local.type.array" }), l;
	};
	for (let t of n(e.nodes)) if (t.type === "interpolation") {
		let n = e.source.slice(t.range.start + 2, Math.max(t.range.start + 2, t.range.end - 2)), r = t.value ?? "", i = Math.max(0, n.indexOf(r)), a = t.range.start + 2 + i;
		e.expressionKinds.set(t.id, o(r, a, "text"));
	}
	for (let t of e.entries) {
		if (t.name === "computed" || t.name === "const") continue;
		let n = e.attrs.get(t.node.id) ?? {}, r = /* @__PURE__ */ new Set(), i = /* @__PURE__ */ new Set();
		for (let e of x(t.kernel)) if (e.kind === "scoped-expressions") for (let t of e.attributes) r.add(t);
		else if (e.kind === "row-values") r.add(e.rows), r.add(e.key);
		else if (e.kind === "validation-rule") r.add(e.when);
		else if (e.kind === "require-full-interpolation") for (let t of e.attributes) i.add(t);
		for (let [i, a] of Object.entries(n)) {
			let n = t.kernel.props[i];
			if (n && !n.static && !r.has(i)) {
				if (n.kind === "string") {
					if (n.dynamic) {
						a.dynamic && o(a.expression ?? "", a.expressionOffset ?? a.offset, "string");
						continue;
					}
					let t = Bp(a.raw);
					for (let n of t.unterminated) e.report("local.interpolation", "Interpolation is missing }}.", a.offset + n, void 0, { key: "local.interpolation.unclosed" });
					for (let e of t.segments) o(e.expression, a.offset + e.start, "text");
				} else a.dynamic && (n.kind === "number" ? o(a.expression ?? "", a.expressionOffset ?? a.offset, "number") : n.kind === "boolean" ? o(a.expression ?? "", a.expressionOffset ?? a.offset, "boolean") : n.kind === "enum" && o(a.expression ?? "", a.expressionOffset ?? a.offset, "string"));
			}
		}
		for (let r of i) {
			let i = n[r];
			i && !Ah(i.raw) && e.report("local.attribute.interpolation", `The ${r} attribute of <${t.name}> must be a full interpolation.`, i.offset, void 0, {
				key: "local.attribute.interpolation",
				params: {
					name: r,
					component: t.name
				}
			});
		}
	}
}
function sh(e, t, r) {
	let i = {
		syntax: "local",
		source: e.source,
		nodes: e.nodes,
		initialState: r,
		bindings: t,
		...Object.keys(e.computations).length ? { computations: e.computations } : {}
	}, a = "__local_core_check__", o = Qt(i, a, !1), s = /* @__PURE__ */ new Set();
	for (let t of n(e.nodes)) if (t.type === "heading") {
		let e = o.ids.get(t);
		e && e.startsWith(`${a}-`) && s.add(e.slice(21));
	}
	let l = /* @__PURE__ */ new Set();
	for (let t of e.entries) {
		let n = c(t.kernel, "anchor");
		if (!n) continue;
		let r = (e.attrs.get(t.node.id) ?? {})[n.id];
		if (!r) continue;
		let i = typeof r.value == "string" ? r.value : "";
		!i || !re(i) ? e.report("local.anchor.id", `Anchor id "${i}" must match [A-Za-z_][A-Za-z0-9_-]*.`, r.offset, void 0, {
			key: "local.anchor.id",
			params: { id: i }
		}) : (l.has(i) ? e.report("local.anchor.duplicate", `Duplicate anchor id "${i}".`, r.offset, void 0, {
			key: "local.anchor.duplicate",
			params: { id: i }
		}) : l.add(i), s.has(i) && e.report("local.anchor.duplicate", `Anchor id "${i}" collides with an automatic heading target.`, r.offset, void 0, {
			key: "local.anchor.heading-collision",
			params: { id: i }
		}));
	}
	let u = [];
	for (let t of e.entries) {
		let n = c(t.kernel, "navigation");
		if (!n) continue;
		let r = (e.attrs.get(t.node.id) ?? {})[n.target];
		r && u.push({
			name: t.name,
			target: typeof r.value == "string" ? r.value : "",
			offset: r.offset
		});
	}
	for (let t of v(u, l, s)) e.report(t.code, t.message, t.start, t.end, {
		key: t.key,
		...t.params ? { params: t.params } : {}
	});
}
function ch(e, n, r) {
	n instanceof t ? e.report(`local.expression.${n.code || "invalid"}`, `Expression error: ${n.message}`, r + (Number.isFinite(n.offset) ? n.offset : 0)) : e.report("local.expression.invalid", `Expression error: ${n instanceof Error ? n.message : String(n)}`, r);
}
function lh(e, t, n, r, i) {
	if (!t.trim()) return e.report("local.expression.empty", "Interpolation expression cannot be empty.", n), null;
	let a;
	try {
		a = e.semantic?.expression(t) ?? ce(t);
	} catch (t) {
		return ch(e, t, n), null;
	}
	let o = Object.keys(r), s = !1;
	for (let i of a.dependencies) if (!Object.hasOwn(r, i)) {
		let r = mh(i, o);
		e.report("local.binding.unknown", `Reference to undeclared parameter ${i}.${r ? ` Did you mean ${r}?` : ""}`, n + Math.max(0, t.indexOf(i))), s = !0;
	}
	if (s || !i) return {
		compiled: a,
		kind: null
	};
	let c;
	try {
		c = e.semantic ? e.semantic.infer(a, r) : a.inferType(r);
	} catch (t) {
		return ch(e, t, n), null;
	}
	return {
		compiled: a,
		kind: c
	};
}
function uh(e, t, n, r, i) {
	if (!e) return null;
	let a = Vp(e.raw);
	return a ? a.expression ? {
		expression: a.expression,
		base: e.offset + a.start
	} : (i.report("local.expression.empty", "Interpolation expression cannot be empty.", e.offset + a.start), null) : (i.report(t, `<${n}> ${r} must be exactly one {{ expression }} interpolation.`, e.offset, e.offset + e.raw.length), null);
}
function dh(e, t) {
	let n = e[t.maxRows], r = Math.min(t.defaultMaxRows, Ce);
	return n && !n.dynamic && typeof n.value == "number" && Number.isInteger(n.value) && n.value > 0 && n.value <= 1e3 ? n.value : r;
}
function fh(e) {
	let t = [];
	for (let n of e.entries) {
		let e = c(n.kernel, "data-table");
		e && t.push([n, e]);
	}
	if (!t.length) return;
	let n = th(e), r = 0, i = 0, a = !1, o = !1;
	for (let [s, c] of t) {
		let t = e.attrs.get(s.node.id) ?? {}, l = Up(s.node.children).filter((e) => (e.type === "component" || e.type === "hostComponent") && e.name === c.child), u = dh(t, c), d = Math.min(c.maxColumns, 20), f = Math.min(c.documentRows, me), p = Math.min(c.documentCells, ge), m = Math.min(l.length, d);
		r += u, i += u * m, !a && r > f && (a = !0, e.report("local.budget.data-table.rows", `The document's generated row budget exceeds ${f}; ${c.maxRows} summed over every <${s.name}> must stay within it.`, s.node.range.start, s.node.range.end)), !o && i > p && (o = !0, e.report("local.budget.data-table.cells", `The document's generated cell budget exceeds ${p}; ${c.maxRows} multiplied by columns, summed over every <${s.name}>, must stay within it.`, s.node.range.start, s.node.range.end));
		let h = uh(t[c.rows], "local.data-table.rows", s.name, c.rows, e), g = "string", _ = !1;
		if (h) {
			let t = lh(e, h.expression, h.base, n, !0);
			t?.kind === "array" ? (g = "string", _ = !0) : t?.kind === "number-array" ? (g = "number", _ = !0) : t && t.kind !== null && e.report("local.data-table.rows", `<${s.name}> ${c.rows} must evaluate to an array, but the expression evaluates to ${$(t.kind)}.`, h.base);
		}
		let v = {
			...n,
			item: g,
			index: "number"
		}, y = uh(t[c.key], "local.data-table.key", s.name, c.key, e);
		if (y) {
			let t = lh(e, y.expression, y.base, v, _);
			if (t) {
				let r = t.compiled.dependencies;
				r.includes("item") || e.report("local.data-table.key", `<${s.name}> key must depend on item.`, y.base);
				for (let t of r) t !== "item" && (t === "index" ? e.report("local.data-table.key", `<${s.name}> key cannot depend on index; use a stable item identifier.`, y.base) : Object.hasOwn(n, t) && e.report("local.data-table.key", `<${s.name}> key cannot depend on global parameter "${t}"; it must be derived from item only.`, y.base));
				t.kind !== null && t.kind !== "string" && t.kind !== "number" && e.report("local.data-table.key", `<${s.name}> key must evaluate to a string or number, got ${$(t.kind)}.`, y.base);
			}
		}
		for (let t of l) {
			let n = e.attrs.get(t.id) ?? {}, r = n[c.label];
			r && !String(r.value ?? "").trim() && e.report("local.data-table.column", `<${c.child}> ${c.label} cannot be empty.`, r.offset);
			let i = uh(n[c.childValue], "local.data-table.value", c.child, c.childValue, e);
			if (!i) continue;
			let a = lh(e, i.expression, i.base, v, _);
			a && (a.kind === "array" || a.kind === "number-array") && e.report("local.data-table.value", `<${c.child}> ${c.childValue} must be a scalar string, number, boolean or null, got ${$(a.kind)}.`, i.base);
		}
	}
}
function ph(e) {
	let t = [], n = 0, r = !1, i = Object.keys(e.bindingKinds), a = th(e);
	for (let o of e.entries) {
		let s = c(o.kernel, "validation-rule");
		if (!s) continue;
		n += 1;
		let l = o.node, u = Math.min(s.max, 100);
		if (n > u) {
			r || (r = !0, e.report("local.validation.budget", `The document declares more than ${u} validation rules; rules in hidden regions count too.`, l.range.start, l.range.end));
			continue;
		}
		o.parent && (o.parent.kernel.form !== "container" || c(o.parent.kernel, "data-table") !== void 0) && e.report("local.validation.placement", `<${o.name}> can appear in normal prose or a container, but not inside inline content or a data table.`, l.range.start, l.range.end);
		let d = e.attrs.get(l.id) ?? {}, f = "", p = [], m = d[s.when];
		if (m) {
			let t = Vp(m.raw);
			if (!t) e.report("local.validation.when", `<${o.name}> ${s.when} must be exactly one {{ boolean }} interpolation.`, m.offset, m.offset + m.raw.length);
			else if (t.expression) {
				f = t.expression;
				let n = lh(e, f, m.offset + t.start, a, !0);
				n && (p = [...n.compiled.dependencies], n.kind !== null && n.kind !== "boolean" && e.report("local.type", `Expected a boolean here, but the expression evaluates to ${$(n.kind)}.`, m.offset + t.start));
			}
		}
		let h = d[s.fields], g = h ? ie(h.raw) : [];
		h && !g.length && e.report("local.validation.fields", `<${o.name}> requires at least one field name.`, h.offset, h.offset + h.raw.length);
		let _ = /* @__PURE__ */ new Set();
		for (let t of g) if (_.has(t)) e.report("local.validation.fields", `Duplicate field "${t}" in <${o.name}> fields.`, h?.offset ?? l.range.start);
		else if (_.add(t), !Object.hasOwn(e.bindingKinds, t)) {
			let n = mh(t, i);
			e.report("local.validation.fields", `Field "${t}" is not a public writable parameter.${n ? ` Did you mean ${n}?` : ""}`, h?.offset ?? l.range.start);
		}
		f && t.push({
			nodeId: l.id,
			expression: f,
			dependencies: p,
			message: typeof d[s.message]?.value == "string" ? String(d[s.message].value) : "",
			fields: [..._],
			range: { ...l.range }
		});
	}
	return t;
}
function mh(e, t) {
	if (e.length > Pp) return;
	let n, r = Infinity;
	for (let i of t) {
		let t = hh(e, i);
		t < r && (n = i, r = t);
	}
	return r <= 2 ? n : void 0;
}
function hh(e, t) {
	let n = Array.from({ length: t.length + 1 }, (e, t) => t);
	for (let r = 1; r <= e.length; r++) {
		let i = n[0];
		n[0] = r;
		for (let a = 1; a <= t.length; a++) {
			let o = n[a];
			n[a] = Math.min(n[a] + 1, n[a - 1] + 1, i + (e[r - 1] === t[a - 1] ? 0 : 1)), i = o;
		}
	}
	return n[t.length];
}
function gh(e, t, n) {
	let r = e.kernel.props[n.samples]?.default, i = typeof r == "number" ? r : 200;
	return um(e, t, n.samples) ?? i;
}
function _h(e) {
	let t = th(e), n = 0, r = !1;
	for (let i of e.entries) {
		let a = c(i.kernel, "plot-math");
		if (!a) continue;
		let o = e.attrs.get(i.node.id) ?? {}, s = Up(i.node.children).filter((e) => e.type === "math"), l = gh(i, o, a), u = Math.min(a.curves, 16), d = Math.min(a.points, ve);
		s.length > u && e.report("local.budget.plot.curves", `<${i.name}> supports at most ${u} curves, but has ${s.length}.`, i.node.range.start, i.node.range.end, {
			key: "local.budget.plot.curves",
			params: {
				limit: u,
				count: s.length
			}
		});
		let f = s.map((e) => Ct(e.value ?? "")), p = f.reduce((e, t) => e + (t === "implicit" ? Ft(l) ** 2 : l), 0), m = n + p;
		if (!r && m > d && (e.report("local.budget.plot.points", `The document's total plot sample count exceeds the limit of ${d}.`, i.node.range.start, i.node.range.end, {
			key: "local.budget.plot.points",
			params: { limit: d }
		}), r = !0), n = Math.min(d + 1, m), !(s.length > u || r)) for (let n = 0; n < s.length; n += 1) {
			let r = s[n], a = (r.value ?? "").trim();
			if (f[n] === null) {
				e.report("local.math.formula", `<${i.name}> formulas must be an equation: y = f(x), a parametric cases block, or an implicit equation in x and y.`, r.range.start, r.range.end, { key: "local.math.formula.shape" });
				continue;
			}
			let o = null;
			try {
				o = wt(a);
			} catch (t) {
				e.report("local.math", `Cannot compute plot formula: ${t instanceof Error ? t.message : String(t)}`, r.range.start, r.range.end, {
					key: "local.math.compute",
					params: {
						detail: t instanceof Error ? t.message : String(t),
						code: t && typeof t == "object" && "code" in t && typeof t.code == "string" ? t.code : "latex-syntax",
						near: a.slice(0, 120)
					}
				});
			}
			if (o) for (let n of o.dependencies) n !== "x" && n !== "y" && n !== "t" && (Object.hasOwn(t, n) ? t[n] !== "number" && e.report("local.math.binding", `Plot parameter "${n}" must be a number, but is ${$(t[n])}.`, r.range.start, r.range.end, {
				key: "local.math.binding.type",
				params: {
					name: n,
					kind: $(t[n])
				}
			}) : e.report("local.math.binding", `Plot formula references undeclared parameter "${n}".`, r.range.start, r.range.end, {
				key: "local.math.binding.unknown",
				params: { name: n }
			}));
		}
	}
}
function vh(e, t, n) {
	let r = (e.children ?? []).filter((e) => e.type === "tableRow");
	if (!r.length) return t.report("local.table.header", `The table for <${n.name}> is missing a header.`, e.range.start, e.range.end, {
		key: "local.table.header.missing",
		params: { name: n.name }
	}), null;
	let i = r[0].children ?? [], a = [];
	for (let e of i) {
		if (Gp(e)) return t.report("local.table.header", "Table headers cannot contain interpolations.", e.range.start, e.range.end, { key: "local.table.header.interpolation" }), null;
		let n = Wp(e).trim();
		if (!n) return t.report("local.table.header", "Table headers cannot be empty.", e.range.start, e.range.end, { key: "local.table.header.empty" }), null;
		if (a.includes(n)) return t.report("local.table.header", `Duplicate table header "${n}".`, e.range.start, e.range.end, {
			key: "local.table.header.duplicate",
			params: { name: n }
		}), null;
		a.push(n);
	}
	if (!a.length) return t.report("local.table.header", "Table headers cannot be empty.", e.range.start, e.range.end, { key: "local.table.header.empty" }), null;
	let o = [];
	for (let e of r.slice(1)) {
		let n = e.children ?? [];
		n.length === a.length ? o.push(n) : t.report("local.table.row", `Table row has a different column count: header has ${a.length} columns, this row has ${n.length}.`, e.range.start, e.range.end, {
			key: "local.table.row.mismatch",
			params: {
				header: a.length,
				row: n.length
			}
		});
	}
	return {
		header: a,
		rows: o
	};
}
function yh(e, t) {
	let n = Up(e.children);
	if (n.length === 1 && n[0].type === "interpolation") {
		let e = t.expressionKinds.get(n[0].id);
		if (e === "number" || e === null) return !0;
		if (e !== void 0) return !1;
	}
	let r = Wp(e).trim();
	return r ? Rp(r) !== null : !1;
}
function bh(e, t, n, r, i) {
	let a = e.header[t], o = c(r.kernel, "timeline-table") !== void 0;
	e.rows.forEach((e, r) => {
		let i = e[t];
		if (!i) return;
		let s = Up(i.children);
		if (s.length === 1 && s[0].type === "interpolation") {
			let e = n.expressionKinds.get(s[0].id);
			e != null && e !== "number" && n.report("local.chart.numeric", `${o ? "Timeline" : "Chart"} column "${a}" requires a number in row ${r + 1}, but the expression evaluates to ${$(e)}.`, i.range.start, i.range.end, {
				key: o ? "local.timeline.numeric.expression" : "local.chart.numeric.expression",
				params: {
					name: a,
					row: r + 1,
					kind: $(e)
				}
			});
		} else yh(i, n) || n.report("local.chart.numeric", `${o ? "Timeline" : "Chart"} column "${a}" requires a plain number in row ${r + 1}, got "${Wp(i).trim() || "empty"}".`, i.range.start, i.range.end, {
			key: o ? "local.timeline.numeric.plain" : "local.chart.numeric.plain",
			params: {
				name: a,
				row: r + 1,
				value: Wp(i).trim() || "empty"
			}
		});
	});
}
function xh(e, t) {
	return e.indexOf(t);
}
function Sh(e) {
	for (let t of e.entries) {
		if (!c(t.kernel, "single-table")) continue;
		let n = c(t.kernel, "chart-table"), r = c(t.kernel, "timeline-table");
		if (!n && !r) {
			Ch(t, e);
			continue;
		}
		let i = Ch(t, e);
		i && (n ? Eh(t, i, e, n) : r && Dh(t, i, e, r));
	}
}
function Ch(e, t) {
	if (t.tableShapes.has(e.node.id)) return t.tableShapes.get(e.node.id) ?? null;
	let n = t.tables.get(e.node.id), r = n ? vh(n, t, e) : null;
	return t.tableShapes.set(e.node.id, r), r;
}
function wh(e, t) {
	if (t.size === 0) return;
	let n = Object.create(null), r = 0;
	for (let [e, i] of t) i && (n[e] = Object.freeze({
		header: Object.freeze([...i.header]),
		rowIds: Object.freeze(i.rows.map((e) => Object.freeze(e.map((e) => e.id))))
	}), r += 1);
	r !== 0 && (e.tableShapes = Object.freeze(n));
}
function Th(e) {
	for (let t of e.entries) {
		let n = c(t.kernel, "table-selection");
		if (!n) continue;
		let r = e.attrs.get(t.node.id) ?? {}, i = r[n.key];
		if (!i) continue;
		let a = typeof i.value == "string" ? i.value.trim() : "";
		if (!a) {
			e.report("local.selection.key", `<${t.name}> key cannot be empty.`, i.offset, void 0, {
				key: "local.selection.key.empty",
				params: { component: t.name }
			}), e.selections.set(t.node.id, [""]);
			continue;
		}
		let o = Ch(t, e);
		if (!o) {
			e.selections.set(t.node.id, [""]);
			continue;
		}
		let s = xh(o.header, a);
		if (s < 0) {
			e.report("local.selection.key", `<${t.name}> key column "${a}" does not exist in its table.`, i.offset, void 0, {
				key: "local.selection.key.missing-column",
				params: {
					component: t.name,
					name: a
				}
			}), e.selections.set(t.node.id, [""]);
			continue;
		}
		let l = [], u = /* @__PURE__ */ new Set();
		o.rows.forEach((n, r) => {
			let i = n[s];
			if (!i) return;
			if (Gp(i)) {
				e.report("local.selection.key", `<${t.name}> key column "${a}" must contain static text; row ${r + 1} contains an interpolation.`, i.range.start, i.range.end, {
					key: "local.selection.key.interpolation",
					params: {
						component: t.name,
						name: a,
						row: r + 1
					}
				});
				return;
			}
			let o = Wp(i).trim();
			o ? u.has(o) ? e.report("local.selection.key", `<${t.name}> key column "${a}" must be unique; duplicate value "${o}".`, i.range.start, i.range.end, {
				key: "local.selection.key.duplicate",
				params: {
					component: t.name,
					name: a,
					value: o
				}
			}) : (u.add(o), l.push(o)) : e.report("local.selection.key", `<${t.name}> key column "${a}" cannot be empty in row ${r + 1}.`, i.range.start, i.range.end, {
				key: "local.selection.key.empty-cell",
				params: {
					component: t.name,
					name: a,
					row: r + 1
				}
			});
		}), e.selections.set(t.node.id, ["", ...l]);
		let d = r.initial;
		d && typeof d.value == "string" && d.value !== "" && !l.includes(d.value) && e.report("local.initial.option", `Initial selection "${d.value}" of <${t.name}> is not a value of key column "${a}".`, d.offset, void 0, {
			key: "local.selection.key.initial",
			params: {
				value: d.value,
				component: t.name,
				name: a
			}
		});
	}
}
function Eh(e, t, n, r) {
	let i = n.attrs.get(e.node.id) ?? {}, a = typeof i[r.chartKind]?.value == "string" ? String(i[r.chartKind].value) : "bar", o = t.header;
	for (let t of o) t.includes(",") && n.report("local.chart.column", `Chart column names cannot contain commas: "${t}".`, e.node.range.start, e.node.range.end, {
		key: "local.chart.column.comma",
		params: { name: t }
	});
	let s = typeof i[r.x]?.value == "string" ? String(i[r.x].value).trim() : "", c = typeof i[r.y]?.value == "string" ? String(i[r.y].value).trim() : "";
	s && xh(o, s) < 0 && n.report("local.chart.column", `Chart x column "${s}" does not exist.`, i[r.x]?.offset ?? e.node.range.start, void 0, {
		key: "local.chart.column.x-missing",
		params: { name: s }
	});
	let l = [];
	if (c) {
		l = c.split(",").map((e) => e.trim()).filter(Boolean), l.length || n.report("local.chart.column", "Chart y requires a column name.", i[r.y]?.offset ?? e.node.range.start, void 0, { key: "local.chart.column.y-required" });
		for (let t of l) xh(o, t) < 0 && n.report("local.chart.column", `Chart y column "${t}" does not exist.`, i[r.y]?.offset ?? e.node.range.start, void 0, {
			key: "local.chart.column.y-missing",
			params: { name: t }
		});
	}
	let u = [];
	if (a === "bar" || a === "line" || a === "area") {
		let t = s ? Math.max(0, xh(o, s)) : 0;
		u = l.length ? l.map((e) => xh(o, e)).filter((e) => e >= 0) : o.map((e, t) => t).filter((e) => e !== t), u.length || n.report("local.chart.column", "Chart requires at least one numeric column.", e.node.range.start, e.node.range.end, { key: "local.chart.column.needs-numeric" });
	} else if (a === "scatter") {
		let r = s ? xh(o, s) : 0;
		r < 0 ? n.report("local.chart.column", `Scatter chart x column "${s}" does not exist.`, e.node.range.start, void 0, {
			key: "local.chart.column.scatter-x-missing",
			params: { name: s }
		}) : bh(t, r, n, e, "x"), u = l.length ? l.map((e) => xh(o, e)).filter((e) => e >= 0) : o.map((e, t) => t).filter((e) => e !== r), u.length || n.report("local.chart.column", "Scatter chart requires at least one numeric column.", e.node.range.start, e.node.range.end, { key: "local.chart.column.scatter-needs-numeric" });
	} else if (a === "donut") {
		if (o.length < 2) {
			n.report("local.chart.column", "Donut chart requires a label column and a value column.", e.node.range.start, e.node.range.end, { key: "local.chart.column.donut-columns" });
			return;
		}
		if (l.length === 1) {
			let e = xh(o, l[0]);
			e >= 0 && (u = [e]);
		} else l.length > 1 ? n.report("local.chart.column", "Donut chart y can only specify one numeric column.", i[r.y]?.offset ?? e.node.range.start, void 0, { key: "local.chart.column.donut-y" }) : o.length > 2 ? n.report("local.chart.column", "A donut chart with more than two columns must use y to specify the single numeric column.", e.node.range.start, e.node.range.end, { key: "local.chart.column.donut-need-y" }) : u = [1];
	}
	u = [...new Set(u)];
	for (let r of u) bh(t, r, n, e, "y");
	if (a === "donut") for (let e of u) t.rows.forEach((t, r) => {
		let i = t[e];
		if (!i || Up(i.children).length) return;
		let a = Rp(Wp(i).trim());
		a !== null && a < 0 && n.report("local.chart.negative", `Donut chart values cannot be negative; row ${r + 1} is ${a}.`, i.range.start, i.range.end, {
			key: "local.chart.negative",
			params: {
				row: r + 1,
				value: a
			}
		});
	});
}
function Dh(e, t, n, r) {
	let i = r.headerSets.map((e) => ({
		title: e[0] ?? "",
		start: e[1] ?? "",
		duration: e[2] ?? "",
		notes: e[3] ?? ""
	})).find((e) => t.header.includes(e.title) && t.header.includes(e.start) && t.header.includes(e.duration));
	if (!i) {
		n.report("local.timeline.header", `<${e.name}> requires title, start and duration columns, with an optional notes column.`, e.node.range.start, e.node.range.end, { key: "local.timeline.header.missing" });
		return;
	}
	let a = new Set(Object.values(i));
	for (let r of t.header) a.has(r) || n.report("local.timeline.header", `Timeline does not support column "${r}".`, e.node.range.start, e.node.range.end, {
		key: "local.timeline.header.column",
		params: { name: r }
	});
	for (let r of [i.start, i.duration]) {
		let i = xh(t.header, r);
		i >= 0 && bh(t, i, n, e, r);
	}
	let o = xh(t.header, i.start), s = xh(t.header, i.duration);
	t.rows.forEach((e, r) => {
		for (let i of [o, s]) {
			if (i < 0) continue;
			let a = e[i];
			if (!a || Up(a.children).length) continue;
			let o = Rp(Wp(a).trim());
			o !== null && o < 0 && n.report("local.timeline.value", `Timeline column "${t.header[i]}" cannot be negative in row ${r + 1}.`, a.range.start, a.range.end, {
				key: "local.timeline.value.negative",
				params: {
					name: t.header[i],
					row: r + 1
				}
			});
		}
	});
}
function Oh(e, t, n, r, i = r + 1, a) {
	if (e.diagnostics.length >= 100) return;
	let o = Math.max(0, Math.min(e.source.length, r)), s = Math.max(o, Math.min(e.source.length, Math.max(o, i))), c = 0, l = e.lineStarts.length - 1;
	for (; c < l;) {
		let t = Math.ceil((c + l) / 2);
		e.lineStarts[t] <= o ? c = t : l = t - 1;
	}
	let u = Oe(a?.key ?? t, a?.params);
	e.diagnostics.push({
		code: t,
		message: n.length > 2e3 ? `${n.slice(0, ye - 1)}…` : n,
		severity: "warning",
		range: {
			start: o,
			end: s
		},
		line: c + 1,
		column: o - e.lineStarts[c] + 1,
		messageKey: u.key,
		...u.params ? { params: u.params } : {}
	});
}
function kh(e, t) {
	if (t.size === 0) return;
	let r = /* @__PURE__ */ new Map();
	for (let i of n(e)) {
		if (i.type !== "hostComponent" || !i.name) continue;
		let e = t.get(i.name);
		e !== void 0 && r.set(e.id, N(e));
	}
	if (r.size === 0) return;
	let i = Object.freeze([...r.values()].sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)));
	return Object.freeze({
		protocol: he,
		components: i
	});
}
function Ah(e) {
	if (!Vp(e)) return !1;
	let t = Bp(e);
	return t.segments.length === 1 && t.unterminated.length === 0;
}
function jh(e, t) {
	let n = {}, r = {}, i = {}, a = [], o = new Map(e.entries.map((e) => [e.node.id, e])), s = /* @__PURE__ */ new Map();
	for (let [t, n] of Object.entries(e.bindingSlots)) {
		let e = o.get(t);
		if (e) for (let [t, r] of Object.entries(n)) s.set(r, {
			entry: e,
			slot: t
		});
	}
	for (let [e, n] of Object.entries(t)) {
		let t = s.get(e);
		if (t) {
			let n = M(t.entry.kernel).find((e) => e.slot === t.slot);
			n && (i[e] = {
				bind: n.bind,
				initial: n.initial
			});
			continue;
		}
		let r = o.get(n.owner ?? n.nodeIds[0] ?? ""), a = r ? E(r.kernel) : void 0;
		a && (i[e] = {
			bind: a.bind,
			initial: a.initial
		});
	}
	for (let t of e.entries) {
		let i = _(t.kernel);
		i.length && (n[t.node.id] = Object.freeze([...i]));
		let o = c(t.kernel, "self-binding-read"), s = c(t.kernel, "inline-math-reads");
		(o || s) && (r[t.node.id] = {
			...o ? { selfBinding: {
				mode: o.mode,
				...o.attribute ? { attribute: o.attribute } : {}
			} } : {},
			...s ? { inlineMathReads: !0 } : {}
		});
		for (let n of u(t.kernel)) e.bindingSlots[t.node.id]?.[n.lower] && e.bindingSlots[t.node.id]?.[n.upper] && a.push({
			nodeId: t.node.id,
			lower: n.lower,
			upper: n.upper
		});
	}
	let l = [];
	for (let [e, n] of Object.entries(t)) n.nodeIds.some((e) => {
		let t = o.get(e);
		return (t ? E(t.kernel) : void 0)?.retain === !1;
	}) && l.push(e);
	return Object.keys(n).length === 0 && Object.keys(r).length === 0 && Object.keys(i).length === 0 && a.length === 0 && l.length === 0 ? {
		valueRules: Object.freeze({}),
		slotRelations: Object.freeze([]),
		retentionExclusions: Object.freeze([])
	} : {
		valueRules: Object.freeze(n),
		slotRelations: Object.freeze(a.map((e) => Object.freeze(e))),
		retentionExclusions: Object.freeze(l.sort()),
		...Object.keys(i).length ? { bindingAttributes: Object.freeze(i) } : {},
		...Object.keys(r).length ? { dependencyRules: Object.freeze(r) } : {}
	};
}
function Mh(e) {
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r of e.entries) {
		let e = r.definition;
		e && !t.has(e.id) && (t.add(e.id), n.push(e));
	}
	return n;
}
function Nh(e, t) {
	for (let r of n(e)) {
		if (r.type !== "hostComponent" || r.name && t.schemaByName.has(r.name)) continue;
		let e = r.name ?? "";
		Oh(t, "local.component.unknown", `Unknown component <${e}>. This mode only accepts local interaction components.`, r.range.start, r.range.end, {
			key: "local.component.unknown",
			params: { name: e }
		});
	}
}
export { Ct as C, Le as D, Ot as E, Ve as O, st as S, Mt as T, Nt as _, Nd as a, wt as b, ol as c, Yt as d, Qt as f, F as g, Ut as h, np as i, Be as k, al as l, Gt as m, jp as n, hd as o, Bt as p, Ap as r, Il as s, $p as t, tn as u, Pt as v, zt as w, Ft as x, _t as y };
