import { R as e, t } from "./default-components-qRt0E8bl.js";
// src/presets/default.ts
var n = Object.freeze({
	id: "reactive-md/default",
	version: e,
	components: t
});
export { n as default, n as defaultPreset };
