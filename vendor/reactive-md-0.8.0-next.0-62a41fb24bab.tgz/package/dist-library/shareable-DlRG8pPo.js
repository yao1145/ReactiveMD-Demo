import { C as e, S as t, n, t as r, w as i, x as a } from "./html-DgECD9QC.js";
import { A as o, K as s, M as c, R as l, U as u, W as d, nt as f } from "./default-components-qRt0E8bl.js";
import { c as p, d as m } from "./registry-DaHST1VN.js";
import { n as h } from "./options-Dre16Jby.js";
import { t as g } from "./runtime-DQx7Eb59.js";
import { i as ee, t as _ } from "./resources-Uw1NWO5K.js";
// src/local/runtime/state.ts
var v = "reactive-md-state/v1", y = 1048576, b = /^fnv1a32:[0-9a-f]{8}$/, x = 2166136261, S = 16777619, te = /* @__PURE__ */ new Set([
	"format",
	"syntax",
	"sourceDigest",
	"parameters",
	"generator"
]), ne = /* @__PURE__ */ new Set(["name", "version"]), C = new TextEncoder();
function w(e, t) {
	return {
		code: e,
		message: t.length > 2e3 ? `${t.slice(0, f - 1)}…` : t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	};
}
function T(e, t, n) {
	e.length < 100 && e.push(w(t, n));
}
function E(e) {
	return e instanceof Error ? e.message : String(e);
}
function D(e) {
	for (let t = 0; t < e.length; t += 1) {
		let n = e.charCodeAt(t);
		if (n >= 55296 && n <= 56319) {
			let n = e.charCodeAt(t + 1);
			if (n >= 56320 && n <= 57343) {
				t += 1;
				continue;
			}
			return !1;
		}
		if (n >= 56320 && n <= 57343) return !1;
	}
	return !0;
}
function O(e) {
	if (typeof e != "string") throw TypeError("localSourceDigest requires a source string.");
	let t = C.encode(e), n = x;
	for (let e = 0; e < t.length; e += 1) n ^= t[e], n = Math.imul(n, S) >>> 0;
	return `fnv1a32:${n.toString(16).padStart(8, "0")}`;
}
function k(e) {
	if (typeof e == "string") return D(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "contains malformed Unicode."
	};
	if (typeof e == "number") return Number.isFinite(e) ? {
		ok: !0,
		value: e
	} : {
		ok: !1,
		message: "must be a finite number."
	};
	if (typeof e == "boolean" || e === null) return {
		ok: !0,
		value: e
	};
	if (Array.isArray(e)) {
		let t = [], n = e.length === 0 ? "string" : typeof e[0];
		for (let r = 0; r < e.length; r += 1) {
			let i = e[r];
			if (n === "string" && typeof i == "string") {
				if (!D(i)) return {
					ok: !1,
					message: "contains malformed Unicode."
				};
				t.push(i);
			} else if (n === "number" && typeof i == "number" && Number.isFinite(i)) t.push(i);
			else return {
				ok: !1,
				message: "must be an array of strings or finite numbers of one kind."
			};
		}
		return {
			ok: !0,
			value: Object.freeze(t)
		};
	}
	return {
		ok: !1,
		message: "must be a string, finite number, boolean, null or homogeneous primitive array."
	};
}
function A(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function re(e) {
	return Object.freeze(e.parameters), e.generator && Object.freeze(e.generator), Object.freeze(e);
}
function j(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("generator must be an object with string name and version.");
	if (typeof e.name != "string" || typeof e.version != "string") throw TypeError("generator must have string name and version.");
	if (!D(e.name) || !D(e.version)) throw TypeError("generator name and version must be well-formed Unicode strings.");
	return Object.freeze({
		name: e.name,
		version: e.version
	});
}
function M(e) {
	return typeof e == "string" ? `"${e.length > 48 ? `${e.slice(0, 48)}…` : e}"` : e === null ? "null" : Array.isArray(e) ? "an array" : typeof e;
}
function N(e, t) {
	return e.length > t ? e.length : C.encode(e).byteLength;
}
function ie(e, t) {
	let n;
	try {
		let t = JSON.stringify(e);
		if (typeof t != "string") return null;
		n = t;
	} catch {
		return null;
	}
	return N(n, t);
}
function ae(e) {
	if (e === void 0) return y;
	if (typeof e != "object" || !e) throw TypeError("parseLocalState options must be an object.");
	let { maxLength: t } = e;
	if (t === void 0) return y;
	if (typeof t != "number" || !Number.isSafeInteger(t) || t <= 0) throw RangeError("maxLength must be a finite positive integer.");
	return t;
}
function P(e, t, n) {
	if (!e || e.syntax !== "local" || typeof e.source != "string") throw TypeError("createLocalStateFile requires a compiled local document.");
	if (!t || typeof t != "object" || Array.isArray(t)) throw TypeError("createLocalStateFile requires a state object.");
	let r = Object.keys(e.bindings).filter((e) => !e.startsWith("@")).sort(), i = new Set(r), o = /* @__PURE__ */ new Map();
	for (let n of Object.keys(t)) {
		if (Object.hasOwn(e.computations ?? {}, n)) continue;
		if (n.startsWith("@")) {
			if (!Object.hasOwn(e.bindings, n)) throw Error(`Cannot persist parameter "${n}": it is not a binding of this document.`);
			continue;
		}
		if (!i.has(n)) throw Error(`Cannot persist parameter "${n}": it is not a public binding of this document.`);
		let r = k(t[n]);
		if (!r.ok) throw TypeError(`Cannot persist parameter "${n}": the value ${r.message}`);
		o.set(n, r.value);
	}
	let s = {};
	for (let e of r) {
		if (!o.has(e)) throw Error(`Cannot persist the document: parameter "${e}" is missing from the supplied state.`);
		s[e] = o.get(e);
	}
	let c = {
		format: v,
		syntax: a,
		sourceDigest: O(e.source),
		parameters: s
	};
	return n !== void 0 && (c.generator = j(n)), re(c);
}
function oe(e, t) {
	let n = [], r = (e, t) => T(n, e, t), i = e;
	if (typeof e == "string") {
		if (N(e, t) > t) return {
			ok: !1,
			diagnostics: [w("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
		if (!D(e)) return {
			ok: !1,
			diagnostics: [w("local.state.utf", "The state payload contains malformed Unicode.")]
		};
		try {
			i = JSON.parse(e);
		} catch (e) {
			return {
				ok: !1,
				diagnostics: [w("local.state.json", `The state payload is not valid JSON: ${E(e)}`)]
			};
		}
	} else {
		let n = ie(e, t);
		if (n === null) return {
			ok: !1,
			diagnostics: [w("local.state.shape", "The state payload must be a JSON object.")]
		};
		if (n > t) return {
			ok: !1,
			diagnostics: [w("local.state.size", `The state payload exceeds the ${t}-byte limit.`)]
		};
	}
	if (!A(i)) return {
		ok: !1,
		diagnostics: [w("local.state.shape", "The state payload must be a JSON object.")]
	};
	Object.getOwnPropertySymbols(i).length > 0 && r("local.state.shape", "The state payload cannot use symbol keys.");
	for (let e of Object.keys(i)) te.has(e) || r("local.state.key", `Unknown top-level state key "${e}".`);
	let o = i.format;
	o !== "reactive-md-state/v1" && r("local.state.format", `Unsupported state format ${M(o)}; expected "${v}".`);
	let s = i.syntax;
	s !== "local-draft-3" && r("local.state.syntax", `Unsupported state syntax ${M(s)}; expected "${a}".`);
	let c = i.sourceDigest;
	typeof c == "string" && b.test(c) || r("local.state.digest", "sourceDigest must match \"fnv1a32:\" followed by 8 lowercase hexadecimal digits.");
	let l = {}, u = i.parameters;
	if (!A(u)) r("local.state.parameters", "parameters must be a JSON object of public binding values.");
	else for (let e of Object.keys(u).sort()) {
		if (e === "__proto__") {
			r("local.state.parameter.prototype", "Parameter names cannot be \"__proto__\".");
			continue;
		}
		if (e.startsWith("@")) {
			r("local.state.parameter.internal", `Internal parameter "${e}" cannot be persisted.`);
			continue;
		}
		let t = k(u[e]);
		t.ok ? l[e] = t.value : r("local.state.parameter.value", `Parameter "${e}" ${t.message}`);
	}
	let d;
	if (Object.hasOwn(i, "generator")) {
		let e = i.generator;
		if (!A(e)) r("local.state.generator", "generator must be an object with string name and version.");
		else {
			for (let t of Object.keys(e)) ne.has(t) || r("local.state.generator", `generator has unknown key "${t}".`);
			typeof e.name != "string" || typeof e.version != "string" ? r("local.state.generator", "generator must have string name and version.") : !D(e.name) || !D(e.version) ? r("local.state.utf", "generator contains malformed Unicode.") : d = Object.freeze({
				name: e.name,
				version: e.version
			});
		}
	}
	if (n.length) return {
		ok: !1,
		diagnostics: n
	};
	let f = {
		format: v,
		syntax: a,
		sourceDigest: c,
		parameters: l
	};
	return d && (f.generator = d), {
		ok: !0,
		file: re(f)
	};
}
function F(e, t) {
	let n = ae(t);
	try {
		return oe(e, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [w("local.state.invalid", `Cannot read the local state: ${E(e)}`)]
		};
	}
}
function se(e) {
	let t = /* @__PURE__ */ new Map(), n = (e) => {
		for (let r of e) t.set(r.id, r), r.children && n(r.children);
	};
	return n(e.nodes), t;
}
function I(e) {
	let t = se(e), n = /* @__PURE__ */ new Map(), r = [];
	for (let [i, a] of Object.entries(e.bindingSlots ?? {})) {
		let e = t.get(i);
		if (!e) continue;
		let o = {
			node: e,
			slots: []
		};
		for (let [t, r] of Object.entries(a)) o.slots.push({
			slot: t,
			key: r
		}), r.startsWith("@") || n.set(r, {
			node: e,
			slot: t
		});
		o.slots.length && r.push(o);
	}
	let i = [];
	for (let [r, a] of Object.entries(e.bindings)) {
		if (r.startsWith("@")) continue;
		let e = n.get(r);
		if (e) {
			i.push({
				key: r,
				binding: a,
				node: e.node,
				slot: e.slot
			});
			continue;
		}
		let o = a.owner && t.has(a.owner) ? a.owner : a.nodeIds.find((e) => t.has(e));
		i.push({
			key: r,
			binding: a,
			node: o ? t.get(o) : void 0
		});
	}
	return {
		plans: i,
		groups: r
	};
}
function L(e, t, n) {
	let r = [];
	for (let i of t.plans) i.slot === void 0 && Object.hasOwn(n, i.key) && (i.node ? Object.is(e.get(i.node), n[i.key]) || r.push(...e.set(i.node, n[i.key])) : r.push(w("local.state.document", `The document has no component for parameter "${i.key}".`)));
	for (let i of t.groups) {
		let t = {}, a = !1;
		for (let { slot: e, key: r } of i.slots) Object.hasOwn(n, r) && (t[e] = n[r], a = !0);
		a && r.push(...e.setMany(i.node, t));
	}
	return r;
}
function ce(e, t) {
	let n = e.snapshot(), r = {};
	for (let e of t) {
		let t = n.state[e];
		r[e] = Array.isArray(t) ? Object.freeze([...t]) : t;
	}
	return Object.freeze(r);
}
function R(e, t, n, r) {
	let i = F(t, r);
	if (!i.ok) return i;
	if (!e || e.syntax !== "local" || typeof e.source != "string" || !Array.isArray(e.nodes) || !e.bindings) return {
		ok: !1,
		diagnostics: [w("local.state.document", "resolveLocalState requires a compiled local document.")]
	};
	if (i.file.syntax !== "local-draft-3") return {
		ok: !1,
		diagnostics: [w("local.state.syntax", `This state file uses syntax "${i.file.syntax}", but this build accepts "${a}".`)]
	};
	if (i.file.sourceDigest !== O(e.source)) return {
		ok: !1,
		diagnostics: [w("local.state.source", "This state file was created for a different document (source digest mismatch).")]
	};
	let o = I(e), s = new Set(o.plans.map((e) => e.key)), c = [];
	for (let e of Object.keys(i.file.parameters)) s.has(e) || T(c, "local.state.parameter.unknown", `The state contains unknown parameter "${e}" for this document.`);
	for (let e of s) Object.hasOwn(i.file.parameters, e) || T(c, "local.state.parameter.missing", `The state is missing parameter "${e}".`);
	if (c.length) return {
		ok: !1,
		diagnostics: c
	};
	let l;
	try {
		l = g(e);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [w("local.state.document", `Cannot validate this document: ${E(e)}`)]
		};
	}
	try {
		if (n) {
			let e = L(l, o, n);
			if (e.length) return {
				ok: !1,
				diagnostics: e
			};
		}
		let e = L(l, o, i.file.parameters);
		if (e.length) return {
			ok: !1,
			diagnostics: e
		};
		let t = [...s].sort();
		return {
			ok: !0,
			file: i.file,
			state: ce(l, t)
		};
	} finally {
		l.dispose();
	}
}
function z(e, t, n) {
	try {
		return R(e, t, void 0, n);
	} catch (e) {
		return {
			ok: !1,
			diagnostics: [w("local.state.invalid", `Cannot resolve the local state: ${E(e)}`)]
		};
	}
}
function B(e, t, n) {
	let r;
	try {
		r = R(e.document, t, e.snapshot().state, n);
	} catch (e) {
		return [w("local.state.invalid", `Cannot apply the local state: ${E(e)}`)];
	}
	if (!r.ok) return r.diagnostics;
	let i = I(e.document);
	try {
		return L(e, i, r.state);
	} catch (e) {
		return [w("local.state.invalid", `Cannot apply the local state: ${E(e)}`)];
	}
}
function le(e, t) {
	return P(e.document, e.getParameters(), t);
}
function ue(e, t, n) {
	let r = F(t, n);
	return r.ok ? B(e, r.file, n) : r.diagnostics;
}
function de(e) {
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("serializeLocalState requires a state file.");
	if (!e.parameters || typeof e.parameters != "object" || Array.isArray(e.parameters)) throw TypeError("serializeLocalState requires an object of parameters.");
	let t = Object.create(null);
	for (let n of Object.keys(e.parameters).sort()) {
		if (n === "__proto__" || n.startsWith("@")) throw TypeError(`Cannot serialize parameter "${n}".`);
		let r = k(e.parameters[n]);
		if (!r.ok) throw TypeError(`Cannot serialize parameter "${n}": the value ${r.message}`);
		t[n] = r.value;
	}
	let n = {
		format: e.format,
		syntax: e.syntax,
		sourceDigest: e.sourceDigest,
		parameters: t
	};
	if (e.generator !== void 0) {
		let t = j(e.generator);
		n.generator = {
			name: t.name,
			version: t.version
		};
	}
	return JSON.stringify(n);
}
// src/local/configuration/portable-options.ts
function V(e) {
	if (e === void 0) return;
	let t = h(e);
	if (!t.ok) throw TypeError(`Invalid portable compile options: ${t.message}`);
	return {
		enableCss: t.html.enableCss,
		enableJavaScript: t.html.enableJavaScript,
		enableExtendedHtml: t.html.enableExtendedHtml,
		...Object.hasOwn(e, "strict") && e.strict !== void 0 ? { strict: t.strict } : {},
		...e.markdownBreaks === void 0 ? {} : { markdownBreaks: t.markdownBreaks },
		...e.config === void 0 ? t.hostComponents.length ? { hostComponents: t.hostComponents } : {} : { config: m(e.config) },
		...e.limits === void 0 ? {} : { limits: {
			...e.limits.maxSyntaxNodes === void 0 ? {} : { maxSyntaxNodes: t.maxSyntaxNodes },
			...e.limits.maxParseWork === void 0 ? {} : { maxParseWork: t.maxParseWork },
			...e.limits.maxMarkdownDepth === void 0 ? {} : { maxMarkdownDepth: t.maxMarkdownDepth }
		} }
	};
}
// src/export/restoration.ts
var fe = s;
function H(e) {
	return s(JSON.stringify([
		e.id,
		e.name,
		e.version,
		e.protocol,
		e.colorSchemes,
		e.css.map(({ id: e, css: t }) => [e, t])
	]));
}
function pe(e, t) {
	let n = m(t);
	return Object.freeze({
		protocol: "reactive-md-bundle/v1",
		sdkVersion: l,
		configKey: n.key,
		scriptDigest: s(e),
		themes: Object.freeze(n.themes.map((e) => Object.freeze({
			id: e.id,
			name: e.name,
			version: e.version,
			digest: H(e)
		})))
	});
}
function U(e, t, n, r = []) {
	let i = m(t), a = /* @__PURE__ */ new Set(), c = [...e.nodes];
	for (; c.length;) {
		let e = c.pop();
		(e.type === "component" || e.type === "hostComponent") && e.name && a.add(e.name), e.children && c.push(...e.children);
	}
	let u = i.registry.filter((e) => a.has(e.name)).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		range: e.version,
		digest: o(e)
	})).sort((e, t) => e.id.localeCompare(t.id)), d = i.themes.filter((t) => t.name === e.theme).map((e) => Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: H(e)
	}));
	return Object.freeze({
		protocol: "reactive-md-restore/v1",
		sdk: `^${l}`,
		configKey: i.key,
		sourceDigest: s(e.source),
		target: n,
		components: Object.freeze(u),
		themes: Object.freeze(d),
		resources: Object.freeze(r.map((e) => Object.freeze({
			id: e.id,
			digest: s(e.css)
		})))
	});
}
function W(e) {
	return typeof e == "object" && !!e && !Array.isArray(e) && [Object.prototype, null].includes(Object.getPrototypeOf(e));
}
function G(e) {
	return typeof e == "string" && e.length > 0 && e.length <= 256;
}
function K(e, t) {
	if (e === void 0) return [];
	let n = [], r = (e, t) => n.push({
		code: `local.extension.restore-${e}`,
		message: t,
		severity: "error",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	});
	try {
		if (!W(e) || c(e) > 262144 || e.protocol !== "reactive-md-restore/v1" || !G(e.sdk) || !G(e.configKey) || !G(e.sourceDigest) || ![
			"static",
			"ssr",
			"offline"
		].includes(e.target) || !Array.isArray(e.components) || e.components.length > 192 || !Array.isArray(e.themes) || e.themes.length > 16 || !Array.isArray(e.resources) || e.resources.length > 128) return r("metadata", "Invalid or oversized restoration requirements."), n;
		let i = /* @__PURE__ */ new Set([
			"protocol",
			"sdk",
			"configKey",
			"sourceDigest",
			"target",
			"components",
			"themes",
			"resources"
		]);
		Object.keys(e).some((e) => !i.has(e)) && r("metadata", "Unknown restoration requirement field.");
		let a = t.config === void 0 ? p() : m(t.config);
		d(e.sdk) && u("0.7.0", e.sdk) || r("sdk", `SDK ${l} does not satisfy ${e.sdk}.`), a.key !== e.configKey && r("config", "The installed configuration differs from the exported configuration."), s(t.source) !== e.sourceDigest && r("source", "The source differs from the exported source. Recompile before restoring state.");
		let f = /* @__PURE__ */ new Set();
		for (let t of e.components) {
			if (!W(t) || ![
				"id",
				"name",
				"version",
				"range",
				"digest"
			].every((e) => G(t[e])) || !d(t.range) || f.has(t.id)) {
				r("metadata", "Invalid or duplicate component restoration requirement.");
				continue;
			}
			f.add(t.id);
			let n = a.registry.find((e) => e.id === t.id);
			if (!n) {
				r("component-missing", `Required component ${t.id}@${t.version} is not installed.`);
				continue;
			}
			u(n.version, t.range) || r("version", `Component ${t.id}@${n.version} does not satisfy ${t.range}.`), (n.version !== t.version || n.name !== t.name || o(n) !== t.digest) && r("contract", `Component ${t.id}@${t.version} differs from the installed contract. Recompile and validate state before upgrading.`);
			let i = e.target === "offline" ? [
				"interactive",
				"static",
				"offline"
			] : [e.target];
			for (let e of i) n.capabilities[e] || r("capability", `Component ${t.id} cannot render ${e}.`);
		}
		if (t.document) {
			let n = U(t.document, a, e.target);
			for (let e of n.components) f.has(e.id) || r("component-missing", `Used component ${e.id} is missing from restoration requirements.`);
		}
		f.clear();
		for (let t of e.themes) {
			if (!W(t) || ![
				"id",
				"name",
				"version",
				"digest"
			].every((e) => G(t[e])) || f.has(t.id)) {
				r("metadata", "Invalid or duplicate theme restoration requirement.");
				continue;
			}
			f.add(t.id);
			let e = a.themes.find((e) => e.id === t.id);
			e && e.name === t.name && e.version === t.version && H(e) === t.digest || r("theme", `Required theme ${t.id}@${t.version} does not match the installed theme.`);
		}
		if (t.document) {
			let e = a.themes.find((e) => e.name === t.document.theme);
			e && !f.has(e.id) && r("theme", `Selected theme ${e.id} is missing from restoration requirements.`);
		}
		let h = _(t.resources ?? []);
		n.push(...h.diagnostics);
		let g = new Map(h.resources.map((e) => [e.id, e.css]));
		f.clear();
		for (let t of e.resources) {
			if (!W(t) || !G(t.id) || !G(t.digest) || f.has(t.id)) {
				r("metadata", "Invalid or duplicate style restoration requirement.");
				continue;
			}
			f.add(t.id);
			let e = g.get(t.id);
			e === void 0 ? r("resource-missing", `Required style resource ${t.id} is missing before state restoration.`) : s(e) !== t.digest && r("resource-digest", `Style resource ${t.id} differs from the exported content.`);
		}
		if (t.document) {
			let n = U(t.document, a, e.target), i = new Set(n.components.map((e) => e.id)), o = a.registry.filter((e) => i.has(e.id)).flatMap((e) => e.styles ?? []);
			o.push(...a.themes.filter((e) => e.name === t.document.theme).flatMap((e) => e.css.map((e) => e.id)));
			for (let e of o) f.has(e) && g.has(e) || r("resource-missing", `Used style resource ${e} is required before state restoration.`);
		}
	} catch (e) {
		r("metadata", e instanceof Error ? e.message : String(e));
	}
	return n;
}
// src/shareable.ts
var q = "reactive-md-html/v1", J = "reactive-md-html/v2", me = /^[A-Za-z][A-Za-z0-9_-]*$/, he = /^[A-Za-z]{2,8}(?:-[A-Za-z0-9]{1,8})*$/, ge = /^data:image\/(?:png|jpeg|gif|webp);base64,[A-Za-z0-9+/]+={0,2}$/, _e = /[\u0000-\u001f\u007f-\u009f]/, Y = 64, ve = 41943040, ye = 4096;
function X(e, t = !1) {
	let n = e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	return t && (n = n.replace(/"/g, "&quot;").replace(/'/g, "&#39;")), n;
}
function be(e) {
	return e.replace(/<\/style/gi, "<\\/style");
}
function xe(e) {
	return e.replace(/<\/script/gi, "<\\/script").replace(/<!--/g, "<\\!--");
}
function Z(e) {
	return X(e, !0);
}
function Q(e) {
	let t = JSON.stringify(e);
	if (typeof t != "string") throw TypeError("Cannot serialize a non-JSON value for an inline script.");
	return t.replace(/[<>&\u2028\u2029]/g, (e) => {
		switch (e) {
			case "<": return "\\u003c";
			case ">": return "\\u003e";
			case "&": return "\\u0026";
			case "\u2028": return "\\u2028";
			default: return "\\u2029";
		}
	});
}
function Se(e) {
	return Array.isArray(e) ? e.slice() : e;
}
function Ce(e) {
	try {
		return V(e);
	} catch (e) {
		throw TypeError(`createShareableHtml received invalid compileOptions: ${e instanceof Error ? e.message : String(e)}`);
	}
}
function $(e) {
	let t = [];
	for (let n of e.childNodes) {
		if (i.isElementNode(n)) {
			let e = n.tagName.toLowerCase();
			if (e === "script") continue;
			$(e === "template" ? i.getTemplateContent(n) : n);
		}
		t.push(n);
	}
	e.childNodes = t;
}
function we(e, t, n) {
	let r = !1;
	for (let a of e.childNodes) if (i.isElementNode(a)) {
		if (a.tagName.toLowerCase() === "iframe") {
			let e = a.attrs.filter((e) => {
				let t = e.name.toLowerCase();
				return t !== "srcdoc" && t !== "sandbox";
			});
			e.push({
				name: "srcdoc",
				value: t
			}), e.push({
				name: "sandbox",
				value: n
			}), a.attrs = e, r = !0;
		}
		we(a, t, n) && (r = !0);
	}
	return r;
}
function Te(t) {
	let n = "";
	for (let r of t.childNodes) n += e(r, { scriptingEnabled: !1 });
	return n;
}
function Ee(e, n, r) {
	try {
		let i = t(e, { scriptingEnabled: !1 });
		if ($(i), we(i, n, r)) return Te(i);
	} catch {}
	return `<div class="reactive-md-native-document"><iframe class="reactive-md-native-frame" title="Reactive MD document" sandbox="${X(r, !0)}" style="display:block;width:100%;min-height:60vh;border:0;background:#fff" srcdoc="${X(n, !0)}"></iframe></div>`;
}
function De(e, t) {
	let n = t?.enableExtendedHtml === !0, r = t ? `frame-src about:${n ? " data: blob: http: https:" : ""}` : "frame-src 'none'", i = n ? "base-uri 'self' http: https:" : "base-uri 'none'", a = n ? "form-action http: https:" : "form-action 'none'";
	return e ? `default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; font-src data:; connect-src 'none'; media-src 'none'; object-src 'none'; ${r}; ${i}; ${a}` : `default-src 'none'; img-src data:; style-src 'unsafe-inline'; font-src data:; object-src 'none'; ${r}; ${i}; ${a}`;
}
function Oe(e) {
	if (e === void 0) return;
	if (!e || typeof e != "object" || Array.isArray(e)) throw TypeError("images must be an object mapping relative URLs to data: image URLs.");
	let t = Object.entries(e);
	if (t.length > Y) throw RangeError(`images cannot contain more than ${Y} entries.`);
	let n = 0;
	for (let [e, r] of t) {
		if (!e || e.length > ye || _e.test(e) || e === "__proto__") throw TypeError("Every image key must be a bounded, control-free URL.");
		if (typeof r != "string" || !ge.test(r)) throw TypeError(`The image map for "${e}" must contain a base64 PNG, JPEG, GIF or WebP data URL.`);
		if (n += r.length, n > ve) throw RangeError("The embedded image map exceeds the 40 MiB budget.");
	}
	return Object.fromEntries(t);
}
function ke(e, t) {
	let n = z(e, t);
	if (!n.ok) return n;
	let r = {};
	for (let [t, i] of Object.entries(e.bindings)) r[t] = Object.hasOwn(n.state, t) ? {
		...i,
		initial: Se(n.state[t])
	} : i;
	let i = { ...e.initialState };
	for (let [e, t] of Object.entries(n.state)) i[e] = Se(t);
	return {
		ok: !0,
		baseline: {
			document: {
				...e,
				bindings: r,
				initialState: i
			},
			state: n.state
		}
	};
}
var Ae = "\n:root { color-scheme: light; background: #f5f7fb; }\nhtml, body { margin: 0; }\nbody.reactive-md-export {\n  min-height: 100vh;\n  padding: clamp(16px, 4vw, 48px);\n  background: #f5f7fb;\n  color: #17233d;\n  font-family: system-ui, -apple-system, \"Segoe UI\", sans-serif;\n}\n.reactive-md-export-root { max-width: 840px; margin: 0 auto; }\n@media print {\n  :root, html, body.reactive-md-export { background: #fff !important; }\n  body.reactive-md-export { min-height: 0; padding: 0 !important; }\n  .reactive-md-export-root { max-width: none !important; margin: 0 !important; }\n}\n";
function je(e) {
	let t = e.targetId ?? "reactive-md-document";
	if (!me.test(t)) throw TypeError("targetId must start with a letter and contain only letters, digits, underscores or hyphens.");
	let i = e.mode === "static" ? "static" : "interactive";
	if (!e.staticMarkup.trim()) throw TypeError("createShareableHtml requires rendered document markup.");
	if (!e.css.trim()) throw TypeError("createShareableHtml requires the document stylesheet.");
	if (e.state.sourceDigest !== O(e.source)) throw Error("The state file does not belong to the exported source.");
	if (i === "interactive" && !e.runtimeScript?.trim()) throw TypeError("Interactive HTML requires the standalone runtime script.");
	let a = Ce(e.compileOptions), o = ee(e.extensions, a?.config);
	if (o.push(...K(e.restoration, {
		config: a?.config,
		source: e.source,
		resources: e.resources
	})), o.length) throw TypeError(o.map((e) => e.message).join(" "));
	let s = h(a);
	if (!s.ok) throw TypeError(`createShareableHtml received invalid compileOptions: ${s.message}`);
	let c = s.htmlActive, l = e.staticMarkup;
	if (c && (i === "static" || !s.html.enableJavaScript)) {
		let t = {
			enableCss: s.html.enableCss,
			enableJavaScript: !1,
			enableExtendedHtml: s.html.enableExtendedHtml
		}, i = n(e.source, t, s.maxSyntaxNodes);
		if (!i.markup) throw Error("The native HTML document could not be regenerated without author JavaScript.");
		l = Ee(e.staticMarkup, i.markup, r(t));
	}
	let u = e.locale === "zh" ? "zh" : "en", d = u === "zh" ? "zh-CN" : "en", f = e.colorScheme === "light" || e.colorScheme === "dark" ? e.colorScheme : "auto", p = e.assets === "omit" ? "omit" : "inline", m = e.generator ?? {
		name: "reactive-md",
		version: "unknown"
	}, g = Oe(e.images), _ = Number.isSafeInteger(e.imageCount) && (e.imageCount ?? 0) > 0 ? String(e.imageCount) : String(Object.keys(g ?? {}).length), v = i === "interactive", y = {
		version: e.restoration ? 2 : 1,
		target: t,
		source: e.source,
		state: e.state,
		locale: u,
		colorScheme: f,
		hydrate: !0,
		...a === void 0 ? {} : { compileOptions: a },
		...e.extensions === void 0 ? {} : { extensions: e.extensions },
		...e.restoration === void 0 ? {} : {
			restoration: e.restoration,
			resources: e.resources ?? []
		},
		...g ? { images: g } : {}
	}, b = De(v, c ? s.html : void 0), x = v ? `<script type="application/reactive-md+json" data-reactive-md-auto>${Q(y)}<\/script>
<script>${xe(e.runtimeScript)}<\/script>` : "", S = e.notices?.trim() ? `<template id="reactive-md-notices"><pre>${X(e.notices)}</pre></template>` : "", te = !v && e.extensions ? `<template id="reactive-md-extensions">${X(JSON.stringify(e.extensions))}</template>` : "";
	return `<!doctype html>
<html lang="${X(he.test(d) ? d : "en", !0)}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Content-Security-Policy" content="${Z(b)}">
<meta name="generator" content="${Z(`${m.name} ${m.version}`)}">
<meta name="reactive-md-html-format" content="${e.restoration ? J : q}">
<meta name="reactive-md-syntax" content="${Z(e.state.syntax)}">
<meta name="reactive-md-output" content="${i}">
<meta name="reactive-md-state" content="${Z(e.state.sourceDigest)}">
<meta name="reactive-md-images" content="${p}">
<meta name="reactive-md-image-count" content="${_}">
<title>${X(e.title || "Reactive MD document")}</title>
<style>${be(e.css)}${Ae}</style>
</head>
<body class="reactive-md-export">
<div id="${t}" class="reactive-md-export-root">${l}</div>
${x}
${te}
${S}
</body>
</html>
`;
}
export { O as _, Q as a, de as b, fe as c, V as d, v as f, ue as g, le as h, ke as i, H as l, P as m, J as n, pe as o, B as p, je as r, U as s, q as t, K as u, F as v, z as y };
