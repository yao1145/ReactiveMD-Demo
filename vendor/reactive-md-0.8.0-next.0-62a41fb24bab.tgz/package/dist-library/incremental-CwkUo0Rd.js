import { a as e, n as t, o as n, s as r, y as i } from "./compiler-core-Fk6_fRXo.js";
import { tt as a } from "./html-DgECD9QC.js";
import "./default-components-qRt0E8bl.js";
import { n as o } from "./math-display-CwTpS1cA.js";
import { d as s } from "./registry-DaHST1VN.js";
import { n as c, t as l } from "./options-Dre16Jby.js";
import { n as u } from "./compiler-C7S3EzsO.js";
import { c as d, r as f } from "./schema-D8pyY5P9.js";
// src/local/session/compiler-cache.ts
var p = () => ({
	expressionsCompiled: 0,
	expressionsReused: 0,
	typesInferred: 0,
	typesReused: 0,
	attributesValidated: 0,
	attributesReused: 0,
	bindingsResolved: 0,
	bindingsReused: 0,
	formulasCompiled: 0,
	formulasReused: 0,
	displaysInspected: 0,
	displaysReused: 0
}), m = class {
	capacity;
	maxWeight;
	key;
	values = /* @__PURE__ */ new Map();
	weight = 0;
	counts = p();
	constructor(e = 16384, t = 8e6) {
		this.capacity = e, this.maxWeight = t;
	}
	begin(e) {
		this.key !== e && (this.clear(), this.key = e), this.counts = p();
	}
	get stats() {
		return {
			...this.counts,
			entries: this.values.size
		};
	}
	clear() {
		this.values.clear(), this.weight = 0, this.key = void 0, this.counts = p();
	}
	get(e) {
		let t = this.values.get(e);
		return t !== void 0 && (this.values.delete(e), this.values.set(e, t)), t;
	}
	put(e, t) {
		let n = e.length + 128;
		if (!(n > this.maxWeight)) for (this.values.has(e) && (this.values.delete(e), this.weight -= n), this.values.set(e, t), this.weight += n; this.values.size > this.capacity || this.weight > this.maxWeight;) {
			let e = this.values.keys().next().value;
			this.values.delete(e), this.weight -= e.length + 128;
		}
	}
	expression(e) {
		let t = "expression:" + e, n = this.get(t);
		if (n) return this.counts.expressionsReused++, n;
		let r = a(e);
		return this.counts.expressionsCompiled++, this.put(t, r), r;
	}
	infer(e, t) {
		let n = e.dependencies.map((e) => [e, Object.hasOwn(t, e) ? t[e] : null]), r = "type:" + JSON.stringify([e.source, n]), i = this.get(r);
		if (i !== void 0) return this.counts.typesReused++, i;
		let a = e.inferType(t);
		return this.counts.typesInferred++, this.put(r, a), a;
	}
	attributes(e) {
		let t = this.get("attributes:" + e);
		return t ? this.counts.attributesReused++ : this.counts.attributesValidated++, t;
	}
	rememberAttributes(e, t, n) {
		this.put("attributes:" + e, {
			origin: t,
			value: n
		});
	}
	binding(e) {
		let t = this.get("binding:" + e);
		return t === void 0 ? this.counts.bindingsResolved++ : this.counts.bindingsReused++, t;
	}
	rememberBinding(e, t) {
		this.put("binding:" + e, t);
	}
	latex(e) {
		let t = "latex:" + e, n = this.get(t);
		if (n) return this.counts.formulasReused++, n;
		let r = i(e);
		return this.counts.formulasCompiled++, this.put(t, r), r;
	}
	display(e, t) {
		let n = "display:" + JSON.stringify([e, t]), r = this.get(n);
		if (r) return this.counts.displaysReused++, r;
		let i = o(e, t);
		return this.counts.displaysInspected++, this.put(n, i), i;
	}
}, h = 128, g = 512, _ = 32, v = 131072, y = (e) => JSON.parse(JSON.stringify(e));
function b(e) {
	return typeof e == "object" && !!e && e.strict === !1;
}
var x = class {
	limit;
	byteLimit;
	entries = /* @__PURE__ */ new Map();
	bytes = 0;
	constructor(e, t) {
		this.limit = e, this.byteLimit = t;
	}
	get size() {
		return this.entries.size;
	}
	read(e) {
		let t = this.entries.get(e);
		return t === void 0 ? { hit: !1 } : (this.entries.delete(e), this.entries.set(e, t), {
			hit: !0,
			value: t.value
		});
	}
	write(e, t) {
		if (!(e.length > this.byteLimit / 2)) for (this.entries.get(e) !== void 0 && (this.entries.delete(e), this.bytes -= e.length), this.entries.set(e, { value: t }), this.bytes += e.length; this.entries.size > this.limit || this.bytes > this.byteLimit;) {
			let e = this.entries.keys().next();
			if (e.done) break;
			this.entries.delete(e.value), this.bytes -= e.value.length;
		}
	}
	clear() {
		this.entries.clear(), this.bytes = 0;
	}
}, S = class {
	disposed = !1;
	optionKey;
	recoveryMode;
	plans = new x(h, 524288);
	inline = new x(g, 262144);
	trees = new x(_, 524288);
	counts = {
		hits: 0,
		misses: 0,
		reusedBlocks: 0,
		reusedRows: 0,
		reusedItems: 0,
		reusedRowNodes: 0,
		reusedItemNodes: 0,
		reusedAst: 0
	};
	parse(e, t, n, r) {
		if (this.disposed) throw Error("Local parse session is disposed");
		let i = l(t), a = b(t);
		return (i !== this.optionKey || a !== this.recoveryMode) && (this.optionKey = i, this.recoveryMode = a, this.reset()), d(e, t, n, this, r);
	}
	clear() {
		this.optionKey = void 0, this.recoveryMode = void 0, this.reset();
	}
	dispose() {
		this.clear(), this.disposed = !0;
	}
	get stats() {
		return {
			hits: this.counts.hits,
			misses: this.counts.misses,
			reusedBlocks: this.counts.reusedBlocks,
			reusedRows: this.counts.reusedRows,
			reusedItems: this.counts.reusedItems,
			reusedRowNodes: this.counts.reusedRowNodes,
			reusedItemNodes: this.counts.reusedItemNodes,
			entries: this.plans.size + this.inline.size + this.trees.size
		};
	}
	reset() {
		this.plans.clear(), this.inline.clear(), this.trees.clear(), this.counts = {
			hits: 0,
			misses: 0,
			reusedBlocks: 0,
			reusedRows: 0,
			reusedItems: 0,
			reusedRowNodes: 0,
			reusedItemNodes: 0,
			reusedAst: 0
		};
	}
	counters() {
		return { ...this.counts };
	}
	readPlan(e) {
		return this.lookup(this.plans, e);
	}
	writePlan(e, t) {
		this.plans.write(e, t);
	}
	readInline(e) {
		return this.lookup(this.inline, e);
	}
	writeInline(e, t) {
		e.length > v || this.inline.write(y(e), t?.map((e) => ({
			...e,
			value: y(e.value)
		})));
	}
	notePlanReuse() {
		this.counts.reusedBlocks += 1;
	}
	noteInlineReuse(e) {
		e === "row" ? this.counts.reusedRows += 1 : this.counts.reusedItems += 1;
	}
	noteRowReuse(e) {
		e === "row" ? this.counts.reusedRowNodes += 1 : this.counts.reusedItemNodes += 1;
	}
	readTree(e) {
		return this.lookup(this.trees, e, !0);
	}
	writeTree(e, t) {
		this.trees.write(e, t);
	}
	lookup(e, t, n = !1) {
		let r = e.read(t);
		return r.hit ? (this.counts.hits += 1, n && (this.counts.reusedAst += 1)) : this.counts.misses += 1, r;
	}
}, C = /* @__PURE__ */ new WeakSet();
function w(e, t) {
	let n = 0, r = 0, i = /* @__PURE__ */ new WeakMap(), a = [], o = (e, t, n) => {
		e && (Object.defineProperty(e.output, t, {
			value: n,
			enumerable: !0,
			writable: !0,
			configurable: !0
		}), e.old && Object.hasOwn(e.old, t) && e.old[t] === n || (e.equal = !1));
	}, s = (e, t, r, o) => {
		if (typeof t != "object" || !t) return t;
		if (e === t) return n++, e;
		if (e === void 0 && C.has(t)) return n++, t;
		if (i.has(t)) return i.get(t);
		let s = Array.isArray(t), c = typeof e == "object" && e && Array.isArray(e) === s ? e : void 0, l = Object.keys(t), u = c ? Object.keys(c) : [], d = s ? Array(t.length) : {};
		i.set(t, d);
		let f = s && Array.isArray(e) ? new Map(e.filter((e) => e && typeof e == "object" && typeof e.id == "string").map((e) => [e.id, e])) : void 0, p = !!c && l.length === u.length && (!s || e.length === t.length);
		return a.push({
			before: e,
			after: t,
			old: c,
			keys: l,
			index: 0,
			output: d,
			equal: p,
			byId: f,
			parent: r,
			key: o
		}), d;
	}, c = s(e, t);
	for (; a.length;) {
		let e = a[a.length - 1];
		if (e.index < e.keys.length) {
			let t = e.keys[e.index++], n = e.after[t], r = e.byId && n && typeof n == "object" && typeof n.id == "string" ? e.byId.get(n.id) : e.old?.[t], i = a.length, c = s(r, n, e, t);
			a.length === i && o(e, t, c);
			continue;
		}
		a.pop();
		let t;
		e.equal ? (t = e.before, n++) : (r++, t = Object.isFrozen(e.after) ? Object.freeze(e.output) : e.output, C.add(t)), i.set(e.after, t), e.parent ? o(e.parent, e.key, t) : c = t;
	}
	return {
		value: c,
		reused: n,
		created: r
	};
}
function T(e, t) {
	if (!e?.ok || !t.ok) return 0;
	let n = /* @__PURE__ */ new Set(), r = [...e.document.nodes];
	for (; r.length;) {
		let e = r.pop();
		n.add(e), e.children && r.push(...e.children);
	}
	let i = 0, a = [...t.document.nodes];
	for (; a.length;) {
		let e = a.pop();
		n.has(e) && i++, e.children && a.push(...e.children);
	}
	return i;
}
// src/local/session/row-reuse.ts
function E(e) {
	if (e.nodes.length !== 1) return;
	let t = e.nodes[0], n, r;
	if (t.type === "list") n = "item", r = "listItem";
	else if (t.type === "table") n = "row", r = "tableRow";
	else return;
	let i = t.children ?? [];
	if (!i.length) return;
	let a = [];
	for (let t of i) {
		if (t.type !== r) return;
		let n = t.range.start - e.origin, i = t.range.end - e.origin;
		if (!Number.isInteger(n) || !Number.isInteger(i) || n < 0 || i > e.text.length || i <= n) return;
		let o = e.text.slice(n, i);
		if (o.includes("\n") || o.includes("\r")) return;
		a.push({
			text: o,
			node: t
		});
	}
	return {
		kind: n,
		parent: t,
		rows: a
	};
}
function D(e, t) {
	if (e === t) return !0;
	if (typeof e != "object" || typeof t != "object" || e === null || t === null || Array.isArray(e) !== Array.isArray(t)) return !1;
	let n = Object.keys(e), r = Object.keys(t);
	if (n.length !== r.length) return !1;
	for (let r of n) if (!Object.hasOwn(t, r) || !D(e[r], t[r])) return !1;
	return !0;
}
function O(e, t, n, r) {
	if (e.type !== t.type || e.range.start - n !== t.range.start - r || e.range.end - n !== t.range.end - r) return !1;
	let i = Object.keys(e), a = Object.keys(t);
	if (i.length !== a.length) return !1;
	for (let n of i) if (n !== "id" && n !== "range" && n !== "children" && (!Object.hasOwn(t, n) || !D(e[n], t[n]))) return !1;
	let o = e.children ?? [], s = t.children ?? [];
	if (o.length !== s.length) return !1;
	for (let e = 0; e < o.length; e++) if (!O(o[e], s[e], n, r)) return !1;
	return !0;
}
function k(e, t) {
	let n = {
		...e,
		range: {
			start: e.range.start + t,
			end: e.range.end + t
		}
	};
	return e.attrs && (n.attrs = { ...e.attrs }), e.align && (n.align = [...e.align]), e.children && (n.children = e.children.map((e) => k(e, t))), n;
}
function A(e, t) {
	if (t.add(e.id), e.children) for (let n of e.children) A(n, t);
}
function j(e, t) {
	if (!e) return;
	let n = E(e), r = E(t);
	if (!n || !r || n.kind !== r.kind) return;
	let i = n.rows, a = r.rows, o = Math.min(i.length, a.length), s = 0;
	for (; s < o && i[s].text === a[s].text;) s += 1;
	let c = 0;
	for (; c < o - s && i[i.length - 1 - c].text === a[a.length - 1 - c].text;) c += 1;
	if (s === 0 && c === 0) return;
	let l = /* @__PURE__ */ new Set(), u = 0, d = a.map((e, t) => {
		let n;
		if (t < s ? n = t : t >= a.length - c && (n = i.length - (a.length - t)), n === void 0) return e.node;
		let r = i[n];
		if (!O(r.node, e.node, r.node.range.start, e.node.range.start)) return e.node;
		let o = e.node.range.start - r.node.range.start, d = o === 0 ? r.node : k(r.node, o);
		return u += 1, A(d, l), d;
	});
	if (!u) return;
	let f = {
		...r.parent,
		id: n.parent.id,
		children: d
	};
	return l.add(n.parent.id), {
		nodes: [f],
		reused: u,
		kind: r.kind,
		reusedIds: l
	};
}
// src/local/session/incremental.ts
function M(e) {
	return typeof e == "object" && !!e && e.strict === !1;
}
function N(e) {
	return Object.hasOwn(e, "recoveries") && e.recoveries !== void 0;
}
var P = n.configure(e), F = "\n\n<!-- incremental-boundary -->\n\n";
function I(e) {
	let t = [], n = [...e].reverse();
	for (; n.length;) {
		let e = n.pop();
		if (t.push(e), e.children) for (let t = e.children.length - 1; t >= 0; t--) n.push(e.children[t]);
	}
	return t;
}
function L(e, t, n) {
	return t === 0 && !n ? e : e.map((e) => ({
		...e,
		id: n?.get(e.id) ?? e.id,
		range: {
			start: e.range.start + t,
			end: e.range.end + t
		},
		...e.attrs ? { attrs: { ...e.attrs } } : {},
		...e.align ? { align: [...e.align] } : {},
		...e.children ? { children: L(e.children, t, n) } : {}
	}));
}
function R(e, t, n) {
	let r = Object.create(null);
	for (let i of I(e)) r[n?.get(i.id) ?? i.id] = t.dependencies?.[i.id] ?? null;
	return r;
}
function z(e) {
	let t = !1;
	for (let n of I([e])) {
		if ([
			"definition",
			"footnoteDefinition",
			"footnoteReference",
			"linkReference",
			"imageReference"
		].includes(n.type) || n.type === "hostComponent" || n.type === "htmlDocument" || n.type === "fallback") return "unsupported";
		if (n.type === "component") {
			if (["anchor", "jump"].includes(n.name ?? "") || !f(n.name ?? "")) return "unsupported";
			t = !0;
		}
		n.type === "comment" && (t = !0);
	}
	return t ? "context" : "fragment";
}
function B(e, t) {
	let n = "", r = 0;
	for (let i of t) n += e.slice(r, i.from) + i.text.replace(/[^\r\n]/g, " "), r = i.to;
	return n + e.slice(r);
}
function V(e, t, n) {
	let r = e.cursor();
	do
		if (r.name === "LinkReference") return null;
	while (r.next());
	let i = [], a = 0;
	for (let r = e.topNode.firstChild; r; r = r.nextSibling) {
		let e = r.from, o = r.to;
		for (; e > 0 && (n[e - 1] === " " || n[e - 1] === "	");) e--;
		for (e > 0 && n[e - 1] !== "\r" && n[e - 1] !== "\n" && (e = r.from); n[o] === " " || n[o] === "	";) o++;
		for (; a < t.length && t[a].to <= e;) a++;
		if (a < t.length && t[a].from < o) return null;
		i.push({
			start: e,
			end: o
		});
	}
	return i;
}
function H(e, t) {
	let n = 0, r = e.length, i = t.length;
	for (; n < r && n < i && e.charCodeAt(n) === t.charCodeAt(n);) n++;
	for (; r > n && i > n && e.charCodeAt(r - 1) === t.charCodeAt(i - 1);) r--, i--;
	return {
		from: n,
		oldTo: r,
		newTo: i,
		delta: i - r
	};
}
function U(e, t) {
	let n = e.parsed?.plans;
	if (n?.length) {
		for (let e of n) if (e.source === t) return e.rows;
		if (n.length === 1) return n[0].rows;
	}
}
var W = class {
	disposed = !1;
	snapshot = null;
	deferred = null;
	parseSession = new S();
	semantic = new m();
	services = {
		parser: this.parseSession,
		semantic: this.semantic
	};
	shared = null;
	sharedKey;
	sharedMode;
	epoch = 0;
	cacheBuilds = 0;
	serial = 0;
	lastStats = {
		mode: "full",
		totalBlocks: 0,
		compiledBlocks: 0,
		reusedBlocks: 0,
		compiledCharacters: 0
	};
	get stats() {
		return {
			...this.lastStats,
			cacheBuilds: this.cacheBuilds
		};
	}
	compile(e, n) {
		let r = this.compileShared(e, n), i = performance.now(), a = t(r);
		return this.lastStats = {
			...this.lastStats,
			stages: {
				...this.lastStats.stages,
				publicSnapshotMs: performance.now() - i
			}
		}, a;
	}
	compileShared(e, t) {
		if (this.disposed) throw Error("Local compile session is disposed");
		this.epoch++;
		let n = l(t), r = M(t);
		(n !== this.sharedKey || r !== this.sharedMode) && (this.shared = null, this.sharedKey = n, this.sharedMode = r);
		let i = this.compileCore(e, t), a = performance.now(), o = this.shared, s = w(o ?? void 0, i).value;
		return this.shared = s, this.lastStats = {
			...this.lastStats,
			sharedNodes: T(o, s),
			parse: this.parseSession.stats,
			semantic: this.lastStats.semantic ?? this.semantic.stats,
			stages: {
				...this.lastStats.stages,
				sharedPublicationMs: performance.now() - a
			}
		}, s;
	}
	compileCore(e, n) {
		if (this.disposed) throw Error("Local compile session is disposed");
		this.cacheBuilds = 0;
		let r = l(n), i = c(n), a = M(n), o = a ? "recovery-reference" : "initial", d = !1, f = this.deferred;
		if (this.deferred = null, !a && f && f.key === r && i.ok && !i.htmlActive && typeof e == "string" && e.length <= 1e6) {
			if (e === f.source) return this.deferred = f, this.lastStats = {
				mode: "cached",
				totalBlocks: this.lastStats.totalBlocks,
				compiledBlocks: 0,
				reusedBlocks: this.lastStats.totalBlocks,
				compiledCharacters: 0
			}, f.tracked.result;
			d = !0, o = "scope-or-boundary";
			let t = H(f.source, e), i = (e) => t.from <= e.end && t.oldTo >= e.start, a = f.tracked.parsed;
			if (a && !/[`\\~]/.test(f.source.slice(t.from, t.oldTo) + e.slice(t.from, t.newTo)) && !a.nodes.some((e) => i(e.range) && z(e) !== "fragment") && ![a.versionDeclaration?.range, a.themeRange].some((e) => e && i(e))) try {
				this.snapshot = this.seed(f.source, r, f.tracked, n);
			} catch {
				this.snapshot = null;
			}
		} else f && (o = a ? "recovery-reference" : "options-or-limits");
		let p = this.snapshot;
		if (!a && p && p.key === r && i.ok && !i.htmlActive && typeof e == "string" && e.length <= 1e6) {
			if (e === p.source) return this.lastStats = {
				mode: "cached",
				totalBlocks: p.blocks.length,
				compiledBlocks: 0,
				reusedBlocks: p.blocks.length,
				compiledCharacters: 0
			}, this.publish(p);
			let t = null;
			try {
				t = this.update(p, e, n, i.maxSyntaxNodes);
			} catch {}
			if (t) return this.snapshot = t, this.publish(t);
			o = "scope-or-boundary", d = !0;
		} else p && (o = a ? "recovery-reference" : "options-or-limits");
		this.snapshot = null;
		let m = u(e, n, this.services);
		if (this.lastStats = {
			mode: "full",
			totalBlocks: m.parsed?.nodes.length ?? 0,
			compiledBlocks: m.parsed?.nodes.length ?? 0,
			reusedBlocks: 0,
			compiledCharacters: typeof e == "string" ? e.length : 0,
			fallbackReason: o,
			semantic: m.semantic,
			stages: m.timings
		}, !a && m.result.ok && m.result.diagnostics.length === 0 && !N(m.result) && i.ok && !i.htmlActive && r !== "invalid") {
			if (d) {
				let i = n === void 0 ? void 0 : t(n), a = i;
				if (i?.config !== void 0) try {
					a = {
						...i,
						config: s(i.config)
					};
				} catch {}
				this.deferred = {
					source: e,
					key: r,
					tracked: m,
					options: a
				};
			} else try {
				this.snapshot = this.seed(e, r, m, n);
			} catch {
				this.snapshot = null;
			}
			this.snapshot && (this.lastStats.totalBlocks = this.lastStats.compiledBlocks = this.snapshot.blocks.length);
		}
		return this.snapshot ? this.publish(this.snapshot) : m.result;
	}
	seed(e, t, n, r, i) {
		if (this.cacheBuilds++, !n.result.ok || !n.parsed || N(n.result) || e.includes("[^") || e.includes("﻿")) return null;
		let a = n.parsed.nodes, o = a.map(z), s = a.length === 1 && o[0] === "fragment" && (a[0].type === "list" || a[0].type === "table");
		if (o.includes("unsupported") || !s && o.filter((e) => e === "fragment").length < 2) return null;
		let c = {
			...n.result.document,
			nodes: [],
			source: ""
		}, l = new Map(n.result.document.nodes.map((e) => [e.id, e])), u = [], d = [];
		for (let t = 0; t < a.length; t++) {
			let n = a[t];
			if (o[t] === "fragment") d.push(n);
			else {
				let t = l.has(n.id) ? [l.get(n.id)] : [];
				u.push({
					from: n.range.start,
					to: n.range.end,
					origin: n.range.start,
					text: e.slice(n.range.start, n.range.end),
					nodes: t,
					dependencies: R(t, c),
					cost: 0
				});
			}
		}
		for (let t of [n.parsed.versionDeclaration?.range, n.parsed.themeRange]) t && !u.some((e) => t.start >= e.from && t.end <= e.to) && u.push({
			from: t.start,
			to: t.end,
			origin: t.start,
			text: e.slice(t.start, t.end),
			nodes: [],
			dependencies: {},
			cost: 0
		});
		u.sort((e, t) => e.from - t.from);
		let f = B(e, u);
		if (f.includes("<")) return null;
		let p = i ?? P.parse(f), m = V(p, u, f);
		if (!m) return null;
		let h = [], g = 0;
		for (let t of m) {
			let r = [];
			for (; g < d.length && d[g].range.start < t.end;) {
				let e = d[g];
				if (e.range.start < t.start || e.range.end > t.end) return null;
				r.push(e), g++;
			}
			if (!r.length) return null;
			let i = r.flatMap((e) => l.has(e.id) ? [l.get(e.id)] : []), a = I(i).length, o = e.slice(t.start, t.end);
			h.push({
				from: t.start,
				to: t.end,
				origin: t.start,
				text: o,
				nodes: i,
				dependencies: R(i, c),
				cost: a,
				rowPlans: U(n, o)
			});
		}
		if (g !== d.length) return null;
		let _ = u.length ? u.map((e) => e.text).join(F) + F : "", v = _ ? this.parseSession.parse(_, r) : null;
		if (v?.diagnostics.length) return null;
		let y = (n.parsed.syntaxNodes ?? 0) - h.reduce((e, t) => e + t.cost, 0);
		return y < 0 ? null : (c.nodes = [], c.source = "", delete c.dependencies, {
			source: e,
			key: t,
			tree: p,
			metadata: c,
			blocks: h,
			context: u,
			contextCost: y,
			prefix: _,
			prefixCost: v?.syntaxNodes ?? 0
		});
	}
	update(e, t, n, i) {
		if (t.includes("[^") || t.includes("﻿")) return null;
		let a = H(e.source, t);
		if (/[`\\~]/.test(e.source.slice(a.from, a.oldTo) + t.slice(a.from, a.newTo))) return null;
		let o = [];
		for (let n of e.context) {
			if (a.from <= n.to && a.oldTo >= n.from) return null;
			let e = n.from >= a.oldTo ? a.delta : 0, r = {
				...n,
				from: n.from + e,
				to: n.to + e
			};
			if (t.slice(r.from, r.to) !== n.text) return null;
			o.push(r);
		}
		let s = r.applyChanges(r.addTree(e.tree), [{
			fromA: a.from,
			toA: a.oldTo,
			fromB: a.from,
			toB: a.newTo
		}], 0), c = B(t, o);
		if (c.includes("<")) return null;
		let l = P.parse(c, s), d = V(l, o, c);
		if (!d) return null;
		let f = new Map(e.blocks.map((e) => [`${e.from}:${e.to}`, e])), p = [], m = /* @__PURE__ */ new Set(), h = 0, g = 0, _ = 0, v = e.contextCost;
		for (let r of d) {
			let o = r.start >= a.newTo ? a.delta : 0, s = r.end <= a.from || r.start >= a.newTo ? f.get(`${r.start - o}:${r.end - o}`) : void 0, c = t.slice(r.start, r.end);
			if (s && s.text === c) {
				p.push({
					...s,
					from: r.start,
					to: r.end
				}), h++, v += s.cost;
				for (let e of I(s.nodes)) m.add(e.id);
			} else {
				let t = e.prefix.length, i = e.blocks.find((e) => {
					let t = e.from >= a.oldTo ? e.from + a.delta : e.from, n = e.to >= a.oldTo ? e.to + a.delta : e.to;
					return t < r.end && n > r.start;
				}), o = i?.rowPlans ? {
					...this.services,
					rowPlans: i.rowPlans
				} : this.services, s = u(e.prefix + c, n, o);
				if (_ += t + c.length, g++, !s.result.ok || s.result.diagnostics.length || !s.parsed || N(s.result)) return null;
				let l = s.parsed.nodes.filter((e) => e.range.start >= t);
				if (!l.length || l.some((e) => z(e) !== "fragment")) return null;
				let d = s.result.document.nodes.filter((e) => e.range.start >= t), f = new Map(I(d).map((e) => [e.id, `incremental-${++this.serial}-${e.id}`])), h = L(d, 0, f), y = i ? j({
					text: i.text,
					origin: i.origin,
					nodes: i.nodes
				}, {
					text: c,
					origin: t,
					nodes: h
				}) : void 0;
				if (y) {
					for (let e of y.reusedIds) if (m.has(e)) {
						y = void 0;
						break;
					}
				}
				let b = y?.nodes ?? h, x = (s.parsed.syntaxNodes ?? 0) - e.prefixCost;
				if (x < I(b).length) return null;
				let S = R(d, s.result.document, f), C = Object.create(null);
				for (let e of I(b)) C[e.id] = S[e.id] ?? null;
				if (y && i) {
					let e = i.nodes[0]?.id, t = h[0]?.id;
					for (let n of y.reusedIds) C[n] = n === e && t !== void 0 ? S[t] ?? null : i.dependencies[n] ?? null, m.add(n);
					for (let e = 0; e < y.reused; e++) this.parseSession.noteRowReuse(y.kind);
				}
				p.push({
					from: r.start,
					to: r.end,
					origin: t,
					text: c,
					nodes: b,
					dependencies: C,
					cost: x,
					rowPlans: U(s, c)
				}), v += x;
			}
			if (v > i) return null;
		}
		return v > i ? null : (this.lastStats = {
			mode: "incremental",
			totalBlocks: p.length,
			compiledBlocks: g,
			reusedBlocks: h,
			compiledCharacters: _
		}, {
			...e,
			source: t,
			tree: l,
			context: o,
			blocks: p
		});
	}
	publish(e) {
		let n = t(e.metadata);
		n.source = e.source;
		let r = [...e.blocks, ...e.context].sort((e, t) => e.from - t.from), i = new Map(this.shared?.ok ? this.shared.document.nodes.map((e) => [e.id, e]) : []);
		n.nodes = r.flatMap((e) => {
			let t = e.from - e.origin;
			if (e.publication?.delta === t) return e.publication.nodes;
			let n = w(e.publication?.nodes ?? e.nodes.map((e) => i.get(e.id)).filter((e) => !!e), L(e.nodes, t)).value;
			return e.publication = {
				delta: t,
				nodes: n
			}, n;
		});
		let a = {};
		for (let e of r) for (let [t, n] of Object.entries(e.dependencies)) Object.defineProperty(a, t, {
			value: n === null ? null : Object.freeze([...n]),
			enumerable: !0
		});
		n.dependencies = Object.freeze(a);
		let o = (t) => {
			let n = e.context.find((e) => t.start >= e.origin && t.end <= e.origin + e.text.length), r = n ? n.from - n.origin : 0;
			return {
				start: t.start + r,
				end: t.end + r
			};
		};
		n.versionDeclaration && (n.versionDeclaration.range = o(n.versionDeclaration.range)), n.themeRange &&= o(n.themeRange);
		for (let e of Object.values(n.computations ?? {})) e.range = o(e.range);
		for (let e of n.validations ?? []) e.range = o(e.range);
		for (let e of Object.values(n.externals ?? {})) e.range = o(e.range);
		for (let e of Object.values(n.dynamicConstraints ?? {})) for (let t of Object.values(e)) t.offset = o({
			start: t.offset,
			end: t.offset
		}).start;
		return {
			ok: !0,
			document: n,
			diagnostics: []
		};
	}
	get hasPendingPreparation() {
		return !this.disposed && this.deferred !== null;
	}
	prepare() {
		if (this.disposed || !this.deferred) return !1;
		let e = this.deferred, t = this.epoch, n = this.cacheBuilds;
		try {
			let n = this.seed(e.source, e.key, e.tracked, e.options);
			return this.disposed || t !== this.epoch || this.deferred !== e ? !1 : (this.snapshot = n, this.deferred = null, n !== null);
		} catch {
			return !1;
		} finally {
			this.cacheBuilds = n;
		}
	}
	async prepareAsync(e, t = () => new Promise((e) => setTimeout(e, 0))) {
		if (this.disposed || !this.deferred || e?.aborted) return !1;
		let n = this.deferred, r = this.epoch, i = () => !this.disposed && !e?.aborted && this.epoch === r && this.deferred === n;
		if (await t(), !i() || !n.tracked.result.ok || !n.tracked.parsed) return !1;
		let a = [], o = n.tracked.parsed.nodes;
		for (let e = 0; e < o.length; e++) {
			let r = o[e], s = z(r);
			if (s === "unsupported" || (s === "context" && a.push({
				from: r.range.start,
				to: r.range.end,
				origin: r.range.start,
				text: n.source.slice(r.range.start, r.range.end),
				nodes: [],
				dependencies: {},
				cost: 0
			}), e % 64 == 63 && (await t(), !i()))) return !1;
		}
		for (let e of [n.tracked.parsed.versionDeclaration?.range, n.tracked.parsed.themeRange]) e && !a.some((t) => e.start >= t.from && e.end <= t.to) && a.push({
			from: e.start,
			to: e.end,
			origin: e.start,
			text: n.source.slice(e.start, e.end),
			nodes: [],
			dependencies: {},
			cost: 0
		});
		a.sort((e, t) => e.from - t.from);
		let s = B(n.source, a);
		if (s.includes("<")) return !1;
		let c = P.startParse(s), l = null;
		for (; !l;) if (l = c.advance(), !l && (await t(), !i())) return !1;
		if (await t(), !i()) return !1;
		let u = this.cacheBuilds;
		try {
			let e = this.seed(n.source, n.key, n.tracked, n.options, l);
			return i() ? (this.snapshot = e, this.deferred = null, e !== null) : !1;
		} catch {
			return !1;
		} finally {
			this.cacheBuilds = u;
		}
	}
	clear() {
		this.epoch++, this.snapshot = null, this.deferred = null, this.serial = 0, this.cacheBuilds = 0, this.shared = null, this.sharedKey = void 0, this.sharedMode = void 0, this.parseSession.clear(), this.semantic.clear();
	}
	dispose() {
		this.clear(), this.parseSession.dispose(), this.disposed = !0;
	}
};
function G() {
	return new W();
}
export { G as n, W as t };
