import { t as e } from "./compiler-core-Fk6_fRXo.js";
import { p as t } from "./html-DgECD9QC.js";
import { i as n, n as r, t as i } from "./types-CMqKCmnF.js";
// src/compiler/index.ts
function a(e) {
	let n = t(e);
	if (n.ok) return n;
	throw new i(n.message, {
		code: n.key,
		...n.detail === void 0 ? {} : { detail: n.detail }
	});
}
function o(e) {
	return e === void 0 ? void 0 : Object.freeze({ ...e });
}
function s(t) {
	let i = a(t), s = o(t);
	return { compile(t) {
		return n(e(t, s, i), r);
	} };
}
export { i as CompilerConfigurationError, s as createCompiler };
