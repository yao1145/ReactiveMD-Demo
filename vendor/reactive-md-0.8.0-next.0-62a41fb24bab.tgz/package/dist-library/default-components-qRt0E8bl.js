// src/local/configuration/limits.ts
var e = 1e6, t = 1e4, n = 2e7, r = 1e3, i = 1e5, a = 1e4, o = 1e5, s = 2e3, c = 16, l = 2e4, u = 2e6, d = 1e3, f = 100, p = 20, m = 2e3, h = 1e4;
function g(e) {
	if (e.length > 254 || /\s/.test(e)) return !1;
	let t = e.indexOf("@");
	if (t < 1 || t !== e.lastIndexOf("@")) return !1;
	let n = e.lastIndexOf(".");
	return n > t + 1 && n < e.length - 1;
}
// src/sdk/hash.ts
function _(e) {
	let t = 2166136261, n = 16777619;
	for (let r = 0; r < e.length; r += 1) {
		let i = e.charCodeAt(r);
		t ^= i, t = Math.imul(t, 16777619) >>> 0, n ^= i + r, n = Math.imul(n, 2246822507) >>> 0;
	}
	let r = e.length;
	return t ^= r, t = Math.imul(t, 16777619) >>> 0, n ^= r, n = Math.imul(n, 3266489909) >>> 0, `rmd-${t.toString(16).padStart(8, "0")}${n.toString(16).padStart(8, "0")}`;
}
// src/sdk/pattern.ts
function v(e, t) {
	let n = e[t];
	if (n === "*" || n === "+" || n === "?") return { length: e[t + 1] === "?" ? 2 : 1 };
	if (n !== "{") return null;
	let r = /^\{(\d+)(?:,(\d*))?\}/.exec(e.slice(t));
	return r ? { length: r[0].length + +(e[t + r[0].length] === "?") } : null;
}
function y(e) {
	let t = [], n = !1, r = !1;
	for (let i = 0; i < e.length; i += 1) {
		let a = e[i];
		if (n) {
			n = !1;
			continue;
		}
		if (a === "\\") {
			let t = e[i + 1];
			if (t !== void 0 && t >= "1" && t <= "9" || t === "k" && e[i + 2] === "<") return !1;
			n = !0;
			continue;
		}
		if (r) {
			a === "]" && (r = !1);
			continue;
		}
		if (a === "[") {
			r = !0;
			continue;
		}
		if (a === "(") {
			if (e[i + 1] === "?") {
				if (e[i + 2] !== ":") return !1;
				t.push({
					quantified: !1,
					alternation: !1
				}), i += 2;
				continue;
			}
			t.push({
				quantified: !1,
				alternation: !1
			});
			continue;
		}
		if (a === "|") {
			let e = t[t.length - 1];
			e && (e.alternation = !0);
			continue;
		}
		if (a === ")") {
			let n = t.pop();
			if (!n) return !1;
			let r = v(e, i + 1);
			if (r && (n.quantified || n.alternation)) return !1;
			let a = t[t.length - 1];
			a && (a.quantified = a.quantified || n.quantified || r !== null, a.alternation = a.alternation || n.alternation), r && (i += r.length);
			continue;
		}
		let o = v(e, i);
		if (o) {
			let e = t[t.length - 1];
			e && (e.quantified = !0), i += o.length - 1;
		}
	}
	return t.length === 0 && !n && !r;
}
// src/sdk/version.ts
var ee = "0.7.0", b = "reactive-md-component/v1", te = "reactive-md-config/v1", ne = "reactive-md-extensions/v1", re = 128, ie = 8, ae = /^(\d+)\.(\d+)\.(\d+)(?:-([0-9A-Za-z.-]+))?(?:\+[0-9A-Za-z.-]+)?$/, oe = /^0\d+$/;
function se(e) {
	if (e === void 0) return Object.freeze([]);
	let t = e.split("."), n = [];
	for (let e of t) {
		if (e.length === 0 || oe.test(e) && e !== "0" && /^\d+$/.test(e) || /^\d+$/.test(e) && !Number.isSafeInteger(Number(e))) return null;
		n.push(/^\d+$/.test(e) ? Number(e) : e);
	}
	return Object.freeze(n);
}
function x(e) {
	let t = ae.exec(e);
	if (!t) return null;
	let [, n, r, i, a] = t;
	for (let e of [
		n,
		r,
		i
	]) if (e.length > 1 && e.startsWith("0") || !Number.isSafeInteger(Number(e))) return null;
	let o = se(a);
	return o === null ? null : {
		major: Number(n),
		minor: Number(r),
		patch: Number(i),
		prerelease: o
	};
}
function ce(e, t) {
	return typeof e == "number" && typeof t == "number" ? e === t ? 0 : e < t ? -1 : 1 : typeof e == "number" ? -1 : typeof t == "number" ? 1 : e === t ? 0 : e < t ? -1 : 1;
}
function le(e, t) {
	for (let n of [
		"major",
		"minor",
		"patch"
	]) if (e[n] !== t[n]) return e[n] < t[n] ? -1 : 1;
	if (e.prerelease.length === 0 && t.prerelease.length === 0) return 0;
	if (e.prerelease.length === 0) return 1;
	if (t.prerelease.length === 0) return -1;
	let n = Math.min(e.prerelease.length, t.prerelease.length);
	for (let r = 0; r < n; r += 1) {
		let n = ce(e.prerelease[r], t.prerelease[r]);
		if (n !== 0) return n;
	}
	return e.prerelease.length === t.prerelease.length ? 0 : e.prerelease.length < t.prerelease.length ? -1 : 1;
}
function S(e, t, n) {
	return {
		major: e,
		minor: t,
		patch: n,
		prerelease: Object.freeze([])
	};
}
function ue(e, t) {
	if (e === "^") {
		let e = t.major > 0 ? S(t.major + 1, 0, 0) : t.minor > 0 ? S(0, t.minor + 1, 0) : S(0, 0, t.patch + 1);
		return [{
			operator: ">=",
			version: t
		}, {
			operator: "<",
			version: e
		}];
	}
	return e === "~" ? [{
		operator: ">=",
		version: t
	}, {
		operator: "<",
		version: S(t.major, t.minor + 1, 0)
	}] : [{
		operator: e,
		version: t
	}];
}
function C(e) {
	if (typeof e != "string") return null;
	let t = e.trim();
	if (t.length === 0 || t.length > 128) return null;
	let n = t.split(/\s+/);
	if (n.length === 0 || n.length > 8) return null;
	let r = [];
	try {
		for (let e of n) {
			let t = "=", n = e;
			e.startsWith(">=") || e.startsWith("<=") ? (t = e.slice(0, 2), n = e.slice(2)) : (e.startsWith(">") || e.startsWith("<") || e.startsWith("=") || e.startsWith("^") || e.startsWith("~")) && (t = e[0], n = e.slice(1));
			let i = x(n);
			if (i === null || (r.push(...ue(t, i)), r.length > 16)) return null;
		}
	} catch {
		return null;
	}
	return Object.freeze({
		source: t,
		comparators: Object.freeze(r)
	});
}
function de(e) {
	return typeof e == "string" && x(e) !== null;
}
function fe(e, t) {
	try {
		let n = x(e);
		if (n === null) return !1;
		let r = typeof t == "string" ? C(t) : t;
		if (!r || !Array.isArray(r.comparators) || r.comparators.length === 0 || n.prerelease.length && !r.comparators.some(({ version: e }) => e.prerelease.length && e.major === n.major && e.minor === n.minor && e.patch === n.patch)) return !1;
		for (let e of r.comparators) {
			let t = le(n, e.version);
			switch (e.operator) {
				case "=":
					if (t !== 0) return !1;
					break;
				case ">":
					if (t <= 0) return !1;
					break;
				case ">=":
					if (t < 0) return !1;
					break;
				case "<":
					if (t >= 0) return !1;
					break;
				case "<=":
					if (t > 0) return !1;
					break;
				default: return !1;
			}
		}
		return !0;
	} catch {
		return !1;
	}
}
function pe(e) {
	return typeof e == "object" && !!e && typeof e.source == "string" && Array.isArray(e.comparators);
}
// src/sdk/manifest.ts
var me = 64, he = 64, ge = 128, _e = 160, ve = 64, ye = 64, be = 512, xe = 4096, Se = 16, Ce = 32, we = 256, Te = 65536, Ee = /^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/, De = /^[a-z0-9][a-z0-9._-]*(?:\/[a-z0-9][a-z0-9._-]*)*$/, Oe = /^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/, ke = /^[a-z]{2,3}(?:-[A-Za-z0-9]{2,8})*$/, w = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), Ae = /* @__PURE__ */ new WeakSet(), je = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"enum"
]), Me = /* @__PURE__ */ new Set([
	"leaf",
	"inline",
	"container"
]), Ne = /* @__PURE__ */ new Set([
	"string",
	"number",
	"boolean",
	"null",
	"array",
	"number-array"
]), Pe = /* @__PURE__ */ new Set([
	"text",
	"number",
	"boolean",
	"choice",
	"date",
	"timer",
	"checklist",
	"tabs",
	"diagram",
	"multi-select",
	"selection",
	"steps",
	"collection"
]), Fe = /* @__PURE__ */ new Set([
	"empty",
	"false",
	"max-step",
	"nearest-zero",
	"min",
	"first-option",
	"first-tab",
	"first-step",
	"first-node",
	"checked",
	"duration",
	"empty-array",
	"none"
]), Ie = /* @__PURE__ */ new Set([
	"none",
	"inline",
	"markdown"
]), Le = /* @__PURE__ */ new Set([
	"none",
	"any",
	"inline",
	"content",
	"table",
	"plot",
	"diagram",
	"quiz",
	"options",
	"tabs",
	"steps",
	"components"
]), Re = /* @__PURE__ */ new Set(/* @__PURE__ */ "numeric-range.text-length.date-bounds.nonempty.progress-bounds.timer-duration.option-count.selection-requires.inline-body.no-components.single-table.math-body.options-body.value-sequence.only-children.diagram-body.quiz-body.checklist-body.dynamic-constraints.require-full-interpolation.scoped-expressions.row-values.validation-rule.anchor.navigation.data-table.plot-math.chart-table.timeline-table.table-selection.retain.self-binding-read.inline-math-reads.value-date.value-length.value-required.value-email".split(".")), ze = /* @__PURE__ */ new Set([
	"none",
	"required",
	"optional"
]), Be = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"form",
	"props",
	"bindings",
	"children",
	"structure",
	"rules",
	"slotRelations",
	"legacyHost",
	"capabilities",
	"authoring",
	"dependencies",
	"styles",
	"requires"
]), Ve = /* @__PURE__ */ new Set([
	"kind",
	"required",
	"static",
	"dynamic",
	"default",
	"nullable",
	"enum",
	"values",
	"pattern",
	"min",
	"max",
	"integer",
	"positive",
	"color",
	"coerce",
	"description"
]), He = /* @__PURE__ */ new Set([
	"kind",
	"family",
	"bind",
	"initial",
	"initialRule",
	"required",
	"exclusive",
	"constraints",
	"options",
	"maxItems",
	"requiresAttributes",
	"compare",
	"retain"
]), Ue = /* @__PURE__ */ new Set([
	"min",
	"max",
	"step"
]), We = /* @__PURE__ */ new Set([
	"interactive",
	"static",
	"ssr",
	"offline"
]), Ge = /* @__PURE__ */ new Set([
	"title",
	"description",
	"category",
	"insertText"
]), Ke = /* @__PURE__ */ new Set(["kind", "required"]), qe = /* @__PURE__ */ new Set([
	"rule",
	"label",
	"parents",
	"child",
	"children",
	"min",
	"max",
	"inlineOnly",
	"noComponents",
	"valueAttribute",
	"generatedPrefix",
	"forbidSeparator",
	"maxItems"
]), Je = /* @__PURE__ */ new Set(["id", "version"]), Ye = /* @__PURE__ */ new Set(["kernel"]), Xe = /^[A-Za-z0-9][A-Za-z0-9._/-]*$/, Ze = /^[A-Za-z][A-Za-z0-9]*$/, T = /* @__PURE__ */ new Set(["setMany"]), Qe = 16, $e = 32, et = 16, tt = 32, nt = /* @__PURE__ */ new Set([
	"bind",
	"initial",
	"disabled"
]);
function E(e, t) {
	throw Error(`Invalid local component manifest (${e}): ${t}`);
}
function rt(e) {
	try {
		let t = JSON.stringify(e);
		return typeof t == "string" ? typeof TextEncoder == "function" ? new TextEncoder().encode(t).length : t.length * 2 : Infinity;
	} catch {
		return Infinity;
	}
}
function D(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function O(e, t, n) {
	for (let r of Object.keys(e)) w.has(r) && E(n, `field "${r}" is not allowed.`), t.has(r) || E(n, `unknown field "${r}".`);
}
function k(e, t) {
	return typeof e != "boolean" && E(t, "must be a boolean."), e;
}
function A(e, t, n = xe) {
	return typeof e != "string" && E(t, "must be a string."), e.length > n && E(t, `exceeds the ${n}-character limit.`), e;
}
function j(e, t) {
	return typeof e == "number" && Number.isFinite(e) || E(t, "must be a finite number."), e;
}
function M(e, t) {
	return typeof e != "string" && E(t, "must be a string."), e.length > 128 && E(t, "exceeds the 128-character limit."), Ee.test(e) || E(t, "must use lowercase kebab-case."), e;
}
function it(e, t) {
	D(e) || E(t, "must be an object.");
	let n = {}, r = Object.keys(e).sort();
	for (let i of r) w.has(i) && E(t, `locale "${i}" is not allowed.`), ke.test(i) || E(t, `locale "${i}" must look like "en" or "zh-CN".`), n[i] = A(e[i], `${t}.${i}`, 256);
	return n;
}
function at(e, t) {
	D(e) || E(t, "must be an object."), O(e, Ge, t);
	let n = {};
	return e.title !== void 0 && (n.title = it(e.title, `${t}.title`)), e.description !== void 0 && (n.description = it(e.description, `${t}.description`)), e.category !== void 0 && (n.category = A(e.category, `${t}.category`, 64)), e.insertText !== void 0 && (n.insertText = A(e.insertText, `${t}.insertText`, xe)), n;
}
function ot(e, t, n) {
	D(e) || E(n, "must be an object."), O(e, Ke, n);
	let r = e.kind;
	typeof r == "string" && Ie.has(r) || E(`${n}.kind`, "must be \"none\", \"inline\" or \"markdown\".");
	let i = r;
	e.required !== void 0 && k(e.required, `${n}.required`);
	let a = e.required === !0;
	return t === "leaf" && i !== "none" && E(n, "a leaf component cannot declare body content."), t === "inline" && i === "markdown" && E(n, "an inline component cannot declare Markdown block content."), a && i === "none" && E(n, "cannot require body content of kind \"none\"."), {
		kind: i,
		...a ? { required: !0 } : {}
	};
}
function st(e) {
	if (e !== void 0) return e.kind === "none" ? Object.freeze({
		rule: "none",
		label: "none"
	}) : e.kind === "inline" ? Object.freeze({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0,
		...e.required ? { min: 1 } : {}
	}) : Object.freeze({
		rule: "any",
		label: "none",
		...e.required ? { min: 1 } : {}
	});
}
function N(e, t) {
	Array.isArray(e) || E(t, "must be an array of component names."), e.length > 32 && E(t, "accepts at most 32 names.");
	let n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = M(i, t);
		n.has(e) && E(t, `name "${e}" is declared more than once.`), n.add(e), r.push(e);
	}
	return Object.freeze(r);
}
function ct(e, t) {
	let n = j(e, t);
	return (!Number.isInteger(n) || n < 0) && E(t, "must be a nonnegative integer."), n;
}
function lt(e, t, n) {
	D(e) || E(n, "must be an object."), O(e, qe, n);
	let r = e.rule;
	typeof r == "string" && Le.has(r) || E(`${n}.rule`, "is not a supported child rule.");
	let i = r;
	t === "leaf" && i !== "none" && E(n, "a leaf component cannot declare body content."), t === "inline" && i !== "none" && i !== "inline" && i !== "any" && E(n, "an inline component only supports \"none\", \"inline\" or \"any\".");
	let o = { rule: i };
	if (e.label !== void 0 && (typeof e.label == "string" && ze.has(e.label) || E(`${n}.label`, "must be \"none\", \"required\" or \"optional\"."), o.label = e.label), e.parents !== void 0 && (o.parents = N(e.parents, `${n}.parents`)), e.child !== void 0 && (o.child = M(e.child, `${n}.child`)), e.children !== void 0 && (o.children = N(e.children, `${n}.children`)), e.min !== void 0 && (o.min = F(e.min, `${n}.min`, a)), e.max !== void 0 && (o.max = F(e.max, `${n}.max`, a)), o.min !== void 0 && o.max !== void 0 && o.min > o.max && E(n, "\"min\" cannot exceed \"max\"."), e.inlineOnly !== void 0 && (o.inlineOnly = k(e.inlineOnly, `${n}.inlineOnly`)), e.noComponents !== void 0 && (o.noComponents = k(e.noComponents, `${n}.noComponents`)), e.valueAttribute !== void 0 && (o.valueAttribute = M(e.valueAttribute, `${n}.valueAttribute`)), e.generatedPrefix !== void 0) {
		let t = A(e.generatedPrefix, `${n}.generatedPrefix`, 128);
		t.length === 0 && E(`${n}.generatedPrefix`, "must not be empty."), o.generatedPrefix = t;
	}
	if (e.forbidSeparator !== void 0) {
		let t = A(e.forbidSeparator, `${n}.forbidSeparator`, 4);
		t.length === 0 && E(`${n}.forbidSeparator`, "must not be empty."), o.forbidSeparator = t;
	}
	return e.maxItems !== void 0 && (o.maxItems = F(e.maxItems, `${n}.maxItems`, a)), Object.freeze(o);
}
function P(e, t) {
	return M(e, t);
}
function ut(e, t) {
	return ct(e, t);
}
function F(e, t, n) {
	let r = ct(e, t);
	return r > n && E(t, `cannot exceed the kernel limit ${n}.`), r;
}
function I(e, t) {
	return N(e, t);
}
function dt(e, t) {
	return Array.isArray(e) || E(t, "must be an array of strings."), e.length > 32 && E(t, "accepts at most 32 values."), Object.freeze(e.map((e) => A(e, t, 128)));
}
function ft(e, t) {
	D(e) || E(t, "must be an object.");
	let n = e.kind;
	typeof n == "string" && Re.has(n) || E(`${t}.kind`, "is not a supported rule.");
	let r = (n) => O(e, /* @__PURE__ */ new Set(["kind", ...n]), t), i = (n) => {
		let r = {};
		for (let i of n) e[i] !== void 0 && (r[i] = P(e[i], `${t}.${i}`));
		return r;
	};
	switch (n) {
		case "numeric-range": {
			r([
				"min",
				"max",
				"step",
				"order",
				"integer",
				"positiveInteger"
			]);
			let a;
			return e.order !== void 0 && (e.order !== "nondecreasing" && e.order !== "increasing" && E(`${t}.order`, "must be \"nondecreasing\" or \"increasing\"."), a = e.order), Object.freeze({
				kind: n,
				...i([
					"min",
					"max",
					"step",
					"integer",
					"positiveInteger"
				]),
				...a ? { order: a } : {}
			});
		}
		case "text-length": return r(["min", "max"]), Object.freeze({
			kind: n,
			...i(["min", "max"])
		});
		case "date-bounds": return r([
			"min",
			"max",
			"required"
		]), Object.freeze({
			kind: n,
			...i([
				"min",
				"max",
				"required"
			])
		});
		case "nonempty": return r(["attribute"]), Object.freeze({
			kind: n,
			attribute: P(e.attribute, `${t}.attribute`)
		});
		case "progress-bounds": return r([
			"value",
			"max",
			"defaultMax"
		]), Object.freeze({
			kind: n,
			value: P(e.value, `${t}.value`),
			max: P(e.max, `${t}.max`),
			defaultMax: j(e.defaultMax, `${t}.defaultMax`)
		});
		case "timer-duration": return r(["attribute", "default"]), Object.freeze({
			kind: n,
			attribute: P(e.attribute, `${t}.attribute`),
			default: j(e.default, `${t}.default`)
		});
		case "option-count": return r(["max"]), Object.freeze({
			kind: n,
			...e.max === void 0 ? {} : { max: P(e.max, `${t}.max`) }
		});
		case "selection-requires": return r(["key", "attributes"]), Object.freeze({
			kind: n,
			key: P(e.key, `${t}.key`),
			attributes: I(e.attributes, `${t}.attributes`)
		});
		case "inline-body": return r(["strict"]), Object.freeze({
			kind: n,
			...e.strict === void 0 ? {} : { strict: k(e.strict, `${t}.strict`) }
		});
		case "no-components":
		case "math-body":
		case "inline-math-reads": return r([]), Object.freeze({ kind: n });
		case "single-table": return r(["fallbackSingle"]), Object.freeze({
			kind: n,
			...e.fallbackSingle === void 0 ? {} : { fallbackSingle: k(e.fallbackSingle, `${t}.fallbackSingle`) }
		});
		case "options-body": return r([
			"child",
			"valueAttribute",
			"unique",
			"max",
			"forbidSeparator"
		]), Object.freeze({
			kind: n,
			child: P(e.child, `${t}.child`),
			valueAttribute: P(e.valueAttribute, `${t}.valueAttribute`),
			unique: e.unique === void 0 || k(e.unique, `${t}.unique`),
			...e.max === void 0 ? {} : { max: F(e.max, `${t}.max`, a) },
			...e.forbidSeparator === void 0 ? {} : { forbidSeparator: A(e.forbidSeparator, `${t}.forbidSeparator`, 4) }
		});
		case "value-sequence": return r([
			"child",
			"valueAttribute",
			"min",
			"generatedPrefix",
			"unique",
			"duplicateCode"
		]), Object.freeze({
			kind: n,
			child: P(e.child, `${t}.child`),
			valueAttribute: P(e.valueAttribute, `${t}.valueAttribute`),
			min: ut(e.min, `${t}.min`),
			generatedPrefix: A(e.generatedPrefix, `${t}.generatedPrefix`, 128),
			unique: e.unique === void 0 || k(e.unique, `${t}.unique`),
			...e.duplicateCode === void 0 ? {} : { duplicateCode: A(e.duplicateCode, `${t}.duplicateCode`, 128) }
		});
		case "only-children": return r([
			"children",
			"min",
			"max",
			"maxCode",
			"onlyCode"
		]), Object.freeze({
			kind: n,
			children: I(e.children, `${t}.children`),
			min: ut(e.min, `${t}.min`),
			...e.max === void 0 ? {} : { max: F(e.max, `${t}.max`, a) },
			...e.maxCode === void 0 ? {} : { maxCode: A(e.maxCode, `${t}.maxCode`, 128) },
			...e.onlyCode === void 0 ? {} : { onlyCode: A(e.onlyCode, `${t}.onlyCode`, 128) }
		});
		case "diagram-body": return r([
			"node",
			"edge",
			"id",
			"from",
			"to",
			"label"
		]), Object.freeze({
			kind: n,
			node: P(e.node, `${t}.node`),
			edge: P(e.edge, `${t}.edge`),
			id: P(e.id, `${t}.id`),
			from: P(e.from, `${t}.from`),
			to: P(e.to, `${t}.to`),
			...e.label === void 0 ? {} : { label: P(e.label, `${t}.label`) }
		});
		case "quiz-body": return r([
			"type",
			"answer",
			"tolerance",
			"child",
			"valueAttribute",
			"max"
		]), Object.freeze({
			kind: n,
			type: P(e.type, `${t}.type`),
			answer: P(e.answer, `${t}.answer`),
			tolerance: P(e.tolerance, `${t}.tolerance`),
			child: P(e.child, `${t}.child`),
			valueAttribute: P(e.valueAttribute, `${t}.valueAttribute`),
			...e.max === void 0 ? {} : { max: F(e.max, `${t}.max`, a) }
		});
		case "checklist-body": return r(["itemLimit"]), Object.freeze({
			kind: n,
			itemLimit: F(e.itemLimit, `${t}.itemLimit`, a)
		});
		case "dynamic-constraints":
		case "require-full-interpolation": return r(["attributes"]), Object.freeze({
			kind: n,
			attributes: I(e.attributes, `${t}.attributes`)
		});
		case "scoped-expressions": return r(["attributes", "scope"]), e.scope !== "row" && e.scope !== "validation" && E(`${t}.scope`, "must be \"row\" or \"validation\"."), Object.freeze({
			kind: n,
			attributes: I(e.attributes, `${t}.attributes`),
			scope: e.scope
		});
		case "row-values": return r([
			"rows",
			"key",
			"child",
			"childValue"
		]), Object.freeze({
			kind: n,
			rows: P(e.rows, `${t}.rows`),
			key: P(e.key, `${t}.key`),
			child: P(e.child, `${t}.child`),
			childValue: P(e.childValue, `${t}.childValue`)
		});
		case "validation-rule": return r([
			"when",
			"fields",
			"message",
			"placement",
			"max"
		]), e.placement !== "container" && e.placement !== "prose" && E(`${t}.placement`, "must be \"container\" or \"prose\"."), Object.freeze({
			kind: n,
			when: P(e.when, `${t}.when`),
			fields: P(e.fields, `${t}.fields`),
			message: P(e.message, `${t}.message`),
			placement: e.placement,
			max: F(e.max, `${t}.max`, 100)
		});
		case "anchor": return r(["id"]), Object.freeze({
			kind: n,
			id: P(e.id, `${t}.id`)
		});
		case "navigation": return r(["target"]), Object.freeze({
			kind: n,
			target: P(e.target, `${t}.target`)
		});
		case "data-table": return r([
			"rows",
			"key",
			"child",
			"childValue",
			"label",
			"maxRows",
			"defaultMaxRows",
			"documentRows",
			"documentCells",
			"maxColumns"
		]), Object.freeze({
			kind: n,
			rows: P(e.rows, `${t}.rows`),
			key: P(e.key, `${t}.key`),
			child: P(e.child, `${t}.child`),
			childValue: P(e.childValue, `${t}.childValue`),
			label: P(e.label, `${t}.label`),
			maxRows: P(e.maxRows, `${t}.maxRows`),
			defaultMaxRows: F(e.defaultMaxRows, `${t}.defaultMaxRows`, d),
			documentRows: F(e.documentRows, `${t}.documentRows`, m),
			documentCells: F(e.documentCells, `${t}.documentCells`, h),
			maxColumns: F(e.maxColumns, `${t}.maxColumns`, 20)
		});
		case "plot-math": return r([
			"min",
			"max",
			"samples",
			"curves",
			"points"
		]), Object.freeze({
			kind: n,
			min: P(e.min, `${t}.min`),
			max: P(e.max, `${t}.max`),
			samples: P(e.samples, `${t}.samples`),
			curves: F(e.curves, `${t}.curves`, 16),
			points: F(e.points, `${t}.points`, l)
		});
		case "chart-table": return r([
			"chartKind",
			"x",
			"y"
		]), Object.freeze({
			kind: n,
			chartKind: P(e.chartKind, `${t}.chartKind`),
			x: P(e.x, `${t}.x`),
			y: P(e.y, `${t}.y`)
		});
		case "timeline-table": {
			r(["headerSets"]), Array.isArray(e.headerSets) || E(`${t}.headerSets`, "must be an array.");
			let i = e.headerSets.map((e, n) => dt(e, `${t}.headerSets[${n}]`));
			return Object.freeze({
				kind: n,
				headerSets: Object.freeze(i)
			});
		}
		case "table-selection": return r(["key", "bindings"]), Object.freeze({
			kind: n,
			key: P(e.key, `${t}.key`),
			bindings: I(e.bindings, `${t}.bindings`)
		});
		case "retain": return r(["value"]), Object.freeze({
			kind: n,
			value: k(e.value, `${t}.value`)
		});
		case "self-binding-read": return r(["mode", "attribute"]), e.mode !== "always" && e.mode !== "attribute" && E(`${t}.mode`, "must be \"always\" or \"attribute\"."), Object.freeze({
			kind: n,
			mode: e.mode,
			...e.attribute === void 0 ? {} : { attribute: P(e.attribute, `${t}.attribute`) }
		});
		case "value-date": return r([
			"min",
			"max",
			"required"
		]), Object.freeze({
			kind: n,
			...i([
				"min",
				"max",
				"required"
			])
		});
		case "value-length": return r([
			"min",
			"max",
			"email",
			"emailType"
		]), Object.freeze({
			kind: n,
			...i([
				"min",
				"max",
				"email"
			]),
			...e.emailType === void 0 ? {} : { emailType: A(e.emailType, `${t}.emailType`, 128) }
		});
		case "value-required": return r(["required"]), Object.freeze({
			kind: n,
			required: P(e.required, `${t}.required`)
		});
		case "value-email": return r(["type", "value"]), Object.freeze({
			kind: n,
			...i(["type"]),
			...e.value === void 0 ? {} : { value: A(e.value, `${t}.value`, 128) }
		});
		default: E(`${t}.kind`, "is not a supported rule.");
	}
}
function pt(e) {
	Array.isArray(e) || E("rules", "must be an array."), e.length > 32 && E("rules", "accepts at most 32 rules.");
	let t = [];
	for (let n = 0; n < e.length; n += 1) t.push(ft(e[n], `rules[${n}]`));
	return Object.freeze(t);
}
function mt(e) {
	Array.isArray(e) || E("slotRelations", "must be an array."), e.length > 16 && E("slotRelations", "accepts at most 16 relations.");
	let t = [];
	for (let n = 0; n < e.length; n += 1) {
		let r = e[n], i = `slotRelations[${n}]`;
		D(r) || E(i, "must be an object."), O(r, /* @__PURE__ */ new Set(["lower", "upper"]), i), t.push(Object.freeze({
			lower: M(r.lower, `${i}.lower`),
			upper: M(r.upper, `${i}.upper`)
		}));
	}
	return Object.freeze(t);
}
function ht(e, t) {
	D(e) || E(t, "must be an object."), O(e, We, t);
	let n = (n) => e[n] !== void 0 && k(e[n], `${t}.${n}`);
	return {
		interactive: n("interactive"),
		static: n("static"),
		ssr: n("ssr"),
		offline: n("offline")
	};
}
function gt(e, t) {
	D(e) || E(t, "must be an object."), O(e, Ve, t);
	let n = e.kind;
	typeof n == "string" && je.has(n) || E(`${t}.kind`, "must be \"string\", \"number\", \"boolean\" or \"enum\".");
	let r = n, i = { kind: r };
	for (let n of [
		"required",
		"static",
		"dynamic",
		"integer",
		"positive",
		"color",
		"nullable"
	]) e[n] !== void 0 && (i[n] = k(e[n], `${t}.${n}`));
	i.static === !0 && i.dynamic === !0 && E(t, "cannot be both static and dynamic."), e.coerce !== void 0 && (e.coerce !== "text" && E(`${t}.coerce`, "must be \"text\"."), r !== "string" && E(`${t}.coerce`, "is only valid for kind \"string\"."), i.coerce = "text");
	let a = e.enum === void 0 ? e.values : e.enum, o = a !== void 0;
	if (r !== "enum") o && E(t, `"enum" is only valid for kind "enum", not "${r}".`);
	else {
		e.enum !== void 0 && e.values !== void 0 && E(t, "use \"enum\" or \"values\", not both."), Array.isArray(a) && a.length !== 0 || E(`${t}.enum`, "must be a non-empty string array."), a.length > 64 && E(`${t}.enum`, "accepts at most 64 values.");
		let n = /* @__PURE__ */ new Set(), r = [];
		for (let e of a) {
			let i = A(e, `${t}.enum`, 128);
			n.has(i) && E(`${t}.enum`, `value "${i}" is declared more than once.`), n.add(i), r.push(i);
		}
		i.enum = r;
	}
	let s = e.pattern !== void 0;
	if (r !== "string") s && E(t, `"pattern" is only valid for kind "string", not "${r}".`);
	else if (s) {
		typeof e.pattern != "string" && E(`${t}.pattern`, "must be a string."), e.pattern.length > 512 && E(`${t}.pattern`, "exceeds the 512-character limit.");
		try {
			new RegExp(e.pattern);
		} catch {
			E(`${t}.pattern`, "is not a valid regular expression.");
		}
		y(e.pattern) || E(`${t}.pattern`, "uses unsupported regex syntax; nested quantifiers, quantified alternation, backreferences and lookarounds are rejected."), i.pattern = e.pattern;
	}
	let c = e.min !== void 0, l = e.max !== void 0;
	if (r === "number" ? (c && (i.min = j(e.min, `${t}.min`)), l && (i.max = j(e.max, `${t}.max`)), i.min !== void 0 && i.max !== void 0 && i.min > i.max && E(t, "\"min\" cannot exceed \"max\".")) : ((c || l) && E(t, "\"min\" and \"max\" are only valid for kind \"number\"."), i.integer === !0 && E(t, "\"integer\" is only valid for kind \"number\"."), i.positive === !0 && E(t, "\"positive\" is only valid for kind \"number\".")), i.color === !0 && r !== "string" && E(t, "\"color\" is only valid for kind \"string\"."), e.description !== void 0 && (i.description = it(e.description, `${t}.description`)), e.default !== void 0) {
		let n = e.default;
		if (n === null) i.nullable !== !0 && E(`${t}.default`, "is null but the prop is not nullable."), i.default = null;
		else if (r === "string") i.default = A(n, `${t}.default`);
		else if (r === "number") {
			let e = j(n, `${t}.default`);
			i.integer === !0 && !Number.isInteger(e) && E(`${t}.default`, "must be an integer."), i.positive === !0 && !(e > 0) && E(`${t}.default`, "must be greater than zero."), i.min !== void 0 && e < i.min && E(`${t}.default`, `is below the minimum ${i.min}.`), i.max !== void 0 && e > i.max && E(`${t}.default`, `exceeds the maximum ${i.max}.`), i.default = e;
		} else if (r === "boolean") i.default = k(n, `${t}.default`);
		else {
			let e = A(n, `${t}.default`, 128);
			i.enum?.includes(e) || E(`${t}.default`, `"${e}" is not an allowed enum value.`), i.default = e;
		}
		if (i.pattern !== void 0 && r === "string" && typeof i.default == "string") {
			let e = !0;
			try {
				e = new RegExp(i.pattern).test(i.default);
			} catch {
				e = !1;
			}
			e || E(`${t}.default`, `does not match pattern ${i.pattern}.`);
		}
	}
	return i;
}
function _t(e, t) {
	D(e) || E(t, "must be an object with \"literal\" or \"prop\".");
	let n = Object.keys(e);
	n.length !== 1 && E(t, "must contain exactly one of \"literal\" or \"prop\".");
	let r = n[0];
	if (w.has(r) && E(t, `field "${r}" is not allowed.`), r === "literal") return { literal: j(e.literal, `${t}.literal`) };
	if (r === "prop") return { prop: M(e.prop, `${t}.prop`) };
	E(t, `unknown field "${r}"; use "literal" or "prop".`);
}
function vt(e, t, n, r) {
	D(e) || E(r, "must be an object."), O(e, Ue, r);
	let i = {};
	for (let n of [
		"min",
		"max",
		"step"
	]) {
		if (e[n] === void 0) continue;
		let a = _t(e[n], `${r}.${n}`);
		if ("prop" in a) {
			let e = t[a.prop];
			e === void 0 && E(`${r}.${n}`, `references undeclared prop "${a.prop}".`), e.kind !== "number" && E(`${r}.${n}`, `references prop "${a.prop}", which is not a number.`);
		}
		n === "step" && "literal" in a && !(a.literal > 0) && E(`${r}.step`, "must be greater than 0."), i[n] = a;
	}
	return n !== "number" && (i.min || i.max || i.step) && E(r, "\"min\", \"max\" and \"step\" are only valid for number bindings."), i.min && "literal" in i.min && i.max && "literal" in i.max && i.min.literal > i.max.literal && E(r, "\"min\" cannot exceed \"max\"."), i;
}
function yt(e, t) {
	if (e === "number") return t === "timer" ? /* @__PURE__ */ new Set([
		"duration",
		"min",
		"nearest-zero"
	]) : /* @__PURE__ */ new Set([
		"min",
		"nearest-zero",
		"max-step"
	]);
	if (e === "boolean") return /* @__PURE__ */ new Set(["false"]);
	if (e === "null") return /* @__PURE__ */ new Set(["empty"]);
	if (e === "array") return t === "checklist" ? /* @__PURE__ */ new Set(["checked", "empty-array"]) : /* @__PURE__ */ new Set(["empty-array"]);
	if (e === "number-array") return /* @__PURE__ */ new Set(["empty-array"]);
	switch (t) {
		case "choice":
		case "selection": return /* @__PURE__ */ new Set(["first-option", "none"]);
		case "tabs": return /* @__PURE__ */ new Set(["first-tab"]);
		case "steps": return /* @__PURE__ */ new Set(["first-step"]);
		case "diagram": return /* @__PURE__ */ new Set(["first-node"]);
		case "date": return /* @__PURE__ */ new Set(["empty"]);
		default: return /* @__PURE__ */ new Set(["empty"]);
	}
}
function bt(e, t, n, r = !1) {
	D(e) || E(n, "must be an object."), O(e, He, n);
	let i = e.kind;
	typeof i == "string" && Ne.has(i) || E(`${n}.kind`, "must be \"string\", \"number\", \"boolean\", \"array\", \"number-array\" or \"null\".");
	let a = i, o = e.family;
	typeof o == "string" && Pe.has(o) || E(`${n}.family`, "must be a supported binding family.");
	let s = o;
	({
		number: /* @__PURE__ */ new Set(["number", "timer"]),
		boolean: /* @__PURE__ */ new Set(["boolean"]),
		string: /* @__PURE__ */ new Set([
			"text",
			"choice",
			"date",
			"tabs",
			"diagram",
			"steps",
			"selection"
		]),
		array: /* @__PURE__ */ new Set([
			"multi-select",
			"checklist",
			"collection"
		]),
		"number-array": /* @__PURE__ */ new Set(["collection"]),
		null: /* @__PURE__ */ new Set(["text"])
	})[a]?.has(s) || E(`${n}.family`, `"${s}" is not supported for a ${a} binding.`);
	let c;
	if (e.options !== void 0) {
		a !== "string" && E(`${n}.options`, "is only valid for a string binding."), s !== "choice" && E(`${n}.options`, "requires family \"choice\".");
		let t = e.options;
		Array.isArray(t) && t.length !== 0 || E(`${n}.options`, "must be a non-empty string array."), t.length > 64 && E(`${n}.options`, "accepts at most 64 values.");
		let r = /* @__PURE__ */ new Set(), i = [];
		for (let e of t) {
			let t = A(e, `${n}.options`, 128);
			t.length === 0 && E(`${n}.options`, "values must be non-empty."), r.has(t) && E(`${n}.options`, `value "${t}" is declared more than once.`), r.add(t), i.push(t);
		}
		c = Object.freeze(i);
	}
	a === "string" && s === "choice" && c === void 0 && !r && E(`${n}.options`, "is required for a choice binding."), s !== "choice" && c !== void 0 && E(`${n}.options`, "is only valid for family \"choice\".");
	let l = M(e.bind, `${n}.bind`), u = M(e.initial, `${n}.initial`);
	l === u && E(n, "\"bind\" and \"initial\" must name different attributes."), (T.has(l) || T.has(u)) && E(n, "binding attributes cannot use a reserved slot name."), (Object.hasOwn(t, l) || Object.hasOwn(t, u)) && E(n, "binding attributes are reserved and cannot be declared as props.");
	let d = yt(a, s), f;
	if (e.initialRule === void 0) switch (a) {
		case "number":
			f = s === "timer" ? "duration" : "nearest-zero";
			break;
		case "boolean":
			f = "false";
			break;
		case "array":
			f = s === "checklist" ? "checked" : "empty-array";
			break;
		case "number-array":
			f = "empty-array";
			break;
		case "null":
			f = "empty";
			break;
		default: f = s === "choice" ? "first-option" : s === "tabs" ? "first-tab" : s === "steps" ? "first-step" : s === "diagram" ? "first-node" : s === "selection" ? "none" : "empty";
	}
	else typeof e.initialRule == "string" && Fe.has(e.initialRule) || E(`${n}.initialRule`, "is not a supported initial rule."), f = e.initialRule;
	d.has(f) || E(`${n}.initialRule`, `is not supported for a ${a} ${s} binding.`), e.required !== void 0 && k(e.required, `${n}.required`), e.exclusive !== void 0 && k(e.exclusive, `${n}.exclusive`), e.retain !== void 0 && k(e.retain, `${n}.retain`);
	let p;
	e.constraints !== void 0 && (p = vt(e.constraints, t, a, `${n}.constraints`));
	let m;
	if (e.maxItems !== void 0) {
		if (a !== "array" && a !== "number-array" && E(`${n}.maxItems`, "is only valid for array or number-array bindings."), m = _t(e.maxItems, `${n}.maxItems`), "prop" in m) {
			let e = t[m.prop];
			e === void 0 && E(`${n}.maxItems`, `references undeclared prop "${m.prop}".`), e.kind !== "number" && E(`${n}.maxItems`, `references prop "${m.prop}", which is not a number.`), e.dynamic === !0 && E(`${n}.maxItems`, "requires a static numeric property.");
		} else (!Number.isInteger(m.literal) || m.literal < 0) && E(`${n}.maxItems`, "must be a nonnegative integer.");
	}
	let h;
	if (e.requiresAttributes !== void 0) {
		h = N(e.requiresAttributes, `${n}.requiresAttributes`);
		for (let e of h) Object.hasOwn(t, e) || E(`${n}.requiresAttributes`, `references undeclared prop "${e}".`);
	}
	let g;
	if (e.compare !== void 0) {
		g = N(e.compare, `${n}.compare`);
		for (let e of g) Object.hasOwn(t, e) || E(`${n}.compare`, `references undeclared prop "${e}".`);
	}
	return Object.freeze({
		kind: a,
		family: s,
		bind: l,
		initial: u,
		initialRule: f,
		...e.required === !0 ? { required: !0 } : {},
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...c ? { options: c } : {},
		...p ? { constraints: Object.freeze(p) } : {},
		...m ? { maxItems: m } : {},
		...h ? { requiresAttributes: h } : {},
		...g ? { compare: g } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	});
}
function xt(e, t) {
	D(e) || E(t, "must be an object."), O(e, Je, t);
	let n = e.id;
	(typeof n != "string" || !De.test(n) || n.length > 160) && E(`${t}.id`, "must be a lowercase namespaced id.");
	let r;
	if (e.version !== void 0) {
		let n = e.version, i = C(n);
		i === null && E(`${t}.version`, "must be an exact version or a supported range (exact, ^, ~, >=, <=, >, <)."), r = i.source;
	}
	return {
		id: n,
		...r ? { version: r } : {}
	};
}
function St(e) {
	D(e) || E("requires", "must be an object."), O(e, Ye, "requires");
	let t;
	if (e.kernel !== void 0) {
		let n = C(e.kernel);
		n === null && E("requires.kernel", "must be a supported kernel version range (exact, ^, ~, >=, <=, >, <)."), t = n.source;
	}
	return { ...t ? { kernel: t } : {} };
}
function Ct(e) {
	Array.isArray(e) || E("styles", "must be an array of style-resource ids."), e.length > 32 && E("styles", "accepts at most 32 resources.");
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r];
		(typeof i != "string" || i.length === 0 || i.length > 256) && E(`styles[${r}]`, "must be a non-empty string of at most 256 characters."), Xe.test(i) || E(`styles[${r}]`, "must be a bounded resource id."), t.has(i) && E("styles", `resource "${i}" is declared more than once.`), t.add(i), n.push(i);
	}
	return Object.freeze(n);
}
function L(e) {
	D(e) || E("manifest", "must be an object."), O(e, Be, "manifest");
	let t = e.id;
	(typeof t != "string" || t.length > 160 || !De.test(t)) && E("id", "must be a lowercase namespaced id such as \"example/rating\".");
	let n = M(e.name, "name"), r = e.version;
	(typeof r != "string" || r.length > 64 || !Oe.test(r)) && E("version", "must be a semantic version such as 1.0.0."), e.protocol !== "reactive-md-component/v1" && E("protocol", `must be "${b}".`);
	let i = e.form;
	typeof i == "string" && Me.has(i) || E("form", "must be \"leaf\", \"inline\" or \"container\".");
	let a = i;
	D(e.props) || E("props", "must be an object.");
	let o = Object.keys(e.props).sort();
	o.length > 64 && E("props", "accepts at most 64 properties.");
	let s = {};
	for (let t of o) w.has(t) && E("props", `property "${t}" is not allowed.`), (!Ee.test(t) || t.length > 128) && E("props", `property "${t}" must use lowercase kebab-case.`), s[t] = gt(e.props[t], `props.${t}`);
	let c;
	if (e.bindings !== void 0) {
		D(e.bindings) || E("bindings", "must be an object.");
		let t = Object.keys(e.bindings);
		t.length === 0 && E("bindings", "must declare at least one binding slot."), t.length > 16 && E("bindings", "accepts at most 16 slots.");
		let n = {}, r = /* @__PURE__ */ new Set();
		for (let i of t) {
			w.has(i) && E("bindings", `field "${i}" is not allowed.`), Ze.test(i) || E("bindings", `slot "${i}" must be a letter followed by letters or digits.`), T.has(i) && E("bindings", `slot "${i}" is reserved by the runtime.`);
			let t = bt(e.bindings[i], s, `bindings.${i}`, a === "container" && Array.isArray(e.rules) && e.rules.some((e) => D(e) && e.kind === "options-body"));
			i !== "value" && (t.kind !== "number" || t.family !== "number") && E(`bindings.${i}`, "numeric named slots support kind \"number\" with family \"number\" in this contract."), i !== "value" && D(e.bindings[i]) && e.bindings[i].exclusive === !1 && E(`bindings.${i}.exclusive`, "named slots require exclusive ownership in this contract.");
			for (let e of [t.bind, t.initial]) r.has(e) && E("bindings", `attribute "${e}" is claimed by more than one binding.`), r.add(e);
			n[i] = i === "value" ? t : Object.freeze({
				...t,
				exclusive: !0
			});
		}
		c = Object.freeze(n);
	}
	let l = e.children === void 0 ? void 0 : ot(e.children, a, "children");
	e.children !== void 0 && e.structure !== void 0 && E("manifest", "cannot declare both \"children\" and \"structure\"; use \"structure\".");
	let u = e.structure === void 0 ? st(l) : lt(e.structure, a, "structure"), d = e.rules === void 0 ? void 0 : pt(e.rules), f = e.slotRelations === void 0 ? void 0 : mt(e.slotRelations);
	e.legacyHost !== void 0 && k(e.legacyHost, "legacyHost");
	let p = ht(e.capabilities, "capabilities"), m = e.authoring === void 0 ? void 0 : at(e.authoring, "authoring"), h = e.styles === void 0 ? void 0 : Ct(e.styles), g = e.requires === void 0 ? void 0 : St(e.requires), _;
	if (e.dependencies !== void 0) {
		Array.isArray(e.dependencies) || E("dependencies", "must be an array."), e.dependencies.length > 16 && E("dependencies", "accepts at most 16 entries.");
		let t = /* @__PURE__ */ new Set(), n = [];
		for (let r = 0; r < e.dependencies.length; r += 1) {
			let i = xt(e.dependencies[r], `dependencies[${r}]`);
			t.has(i.id) && E("dependencies", `"${i.id}" is declared more than once.`), t.add(i.id), n.push(Object.freeze(i));
		}
		_ = Object.freeze(n);
	}
	let v = {
		id: t,
		name: n,
		version: r,
		protocol: b,
		form: a,
		props: Object.freeze(s),
		...c ? { bindings: c } : {},
		...l ? { children: Object.freeze(l) } : {},
		...u && !l ? { structure: u } : {},
		...d ? { rules: d } : {},
		...f ? { slotRelations: f } : {},
		...e.legacyHost === !0 ? { legacyHost: !0 } : {},
		capabilities: Object.freeze(p),
		...m ? { authoring: Object.freeze(m) } : {},
		...h ? { styles: h } : {},
		...g ? { requires: Object.freeze(g) } : {},
		..._ ? { dependencies: _ } : {}
	};
	rt(v) > 65536 && E("manifest", `serialized size exceeds the ${Te}-byte budget.`);
	let y = Tt(v);
	return Ae.add(y), y;
}
function wt(e) {
	return L(e);
}
function Tt(e) {
	if (typeof e != "object" || !e) return e;
	for (let t of Object.keys(e)) Tt(e[t]);
	return Object.freeze(e);
}
function Et(e) {
	return {
		kind: e.kind,
		...e.required === !0 ? { required: !0 } : {},
		...e.static === !0 ? { static: !0 } : {},
		...e.dynamic === void 0 ? {} : { dynamic: e.dynamic },
		...e.default === void 0 ? {} : { default: e.default },
		...e.nullable === !0 ? { nullable: !0 } : {},
		...e.enum ? { enum: [...e.enum] } : {},
		...e.pattern === void 0 ? {} : { pattern: e.pattern },
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.integer === !0 ? { integer: !0 } : {},
		...e.positive === !0 ? { positive: !0 } : {},
		...e.color === !0 ? { color: !0 } : {},
		...e.coerce === void 0 ? {} : { coerce: e.coerce }
	};
}
function R(e) {
	return "literal" in e ? { literal: e.literal } : { prop: e.prop };
}
function Dt(e) {
	return {
		...e.min ? { min: R(e.min) } : {},
		...e.max ? { max: R(e.max) } : {},
		...e.step ? { step: R(e.step) } : {}
	};
}
function Ot(e) {
	let t = e.constraints;
	return {
		kind: e.kind,
		family: e.family,
		bind: e.bind,
		initial: e.initial,
		initialRule: e.initialRule,
		...e.required === !0 ? { required: !0 } : {},
		...e.exclusive === !0 ? { exclusive: !0 } : {},
		...e.options ? { options: [...e.options] } : {},
		...t ? { constraints: Dt(t) } : {},
		...e.maxItems ? { maxItems: R(e.maxItems) } : {},
		...e.requiresAttributes ? { requiresAttributes: [...e.requiresAttributes] } : {},
		...e.compare ? { compare: [...e.compare] } : {},
		...e.retain === !1 ? { retain: !1 } : {}
	};
}
function kt(e) {
	return {
		rule: e.rule,
		...e.label === void 0 ? {} : { label: e.label },
		...e.parents ? { parents: [...e.parents] } : {},
		...e.child === void 0 ? {} : { child: e.child },
		...e.children ? { children: [...e.children] } : {},
		...e.min === void 0 ? {} : { min: e.min },
		...e.max === void 0 ? {} : { max: e.max },
		...e.inlineOnly === void 0 ? {} : { inlineOnly: e.inlineOnly },
		...e.noComponents === void 0 ? {} : { noComponents: e.noComponents },
		...e.valueAttribute === void 0 ? {} : { valueAttribute: e.valueAttribute },
		...e.generatedPrefix === void 0 ? {} : { generatedPrefix: e.generatedPrefix },
		...e.forbidSeparator === void 0 ? {} : { forbidSeparator: e.forbidSeparator },
		...e.maxItems === void 0 ? {} : { maxItems: e.maxItems }
	};
}
function At(e) {
	let t = e, n = Object.keys(t).sort(), r = {};
	for (let e of n) {
		let n = t[e];
		r[e] = Array.isArray(n) ? n.map((e) => Array.isArray(e) ? [...e] : e) : n;
	}
	return r;
}
function jt(e) {
	let t = {};
	for (let n of Object.keys(e.props).sort()) t[n] = Et(e.props[n]);
	let n = {};
	if (e.bindings) for (let t of Object.keys(e.bindings).sort()) n[t] = Ot(e.bindings[t]);
	return {
		protocol: e.protocol,
		id: e.id,
		name: e.name,
		version: e.version,
		form: e.form,
		props: t,
		...e.bindings ? { bindings: n } : {},
		...e.children ? { children: {
			kind: e.children.kind,
			...e.children.required ? { required: !0 } : {}
		} } : {},
		...e.structure ? { structure: kt(e.structure) } : {},
		...e.rules ? { rules: e.rules.map(At) } : {},
		...e.slotRelations ? { slotRelations: e.slotRelations.map((e) => ({ ...e })) } : {},
		capabilities: {
			interactive: e.capabilities.interactive,
			static: e.capabilities.static,
			ssr: e.capabilities.ssr,
			offline: e.capabilities.offline
		},
		...e.styles ? { styles: [...e.styles] } : {},
		...e.requires?.kernel ? { requires: { kernel: e.requires.kernel } } : {},
		...e.dependencies ? { dependencies: [...e.dependencies].map((e) => ({ ...e })).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id)) } : {}
	};
}
var Mt = /* @__PURE__ */ new WeakMap();
function Nt(e) {
	let t = Ae.has(e) ? e : L(e), n = Mt.get(t);
	if (n !== void 0) return n;
	let r = _(JSON.stringify(jt(t)));
	return Mt.set(t, r), r;
}
function Pt(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		digest: Nt(e)
	});
}
function Ft(e) {
	return typeof e == "string" && e.length <= 128 && Ee.test(e);
}
// src/presets/default-authoring.ts
var z = Object.freeze([
	{
		id: "input",
		title: {
			en: "Input controls",
			zh: "输入控件"
		}
	},
	{
		id: "action",
		title: {
			en: "Interactive tools",
			zh: "交互工具"
		}
	},
	{
		id: "layout",
		title: {
			en: "Content layout",
			zh: "内容组织"
		}
	},
	{
		id: "data",
		title: {
			en: "Data visualization",
			zh: "数据可视化"
		}
	},
	{
		id: "hint",
		title: {
			en: "Feedback",
			zh: "提示反馈"
		}
	}
]), It = new Set(z.map((e) => e.id)), B = Object.freeze({
	jump: {
		title: {
			en: "Jump and anchor",
			zh: "跳转与锚点"
		},
		description: {
			en: "Link to a named position in this document.",
			zh: "跳到当前文档中的指定位置。"
		},
		category: "action",
		keywords: {
			en: [
				"jump",
				"anchor",
				"navigation"
			],
			zh: [
				"跳转",
				"锚点",
				"导航"
			]
		},
		insertText: {
			en: "<jump to=\"{{bind:destination}}\" appearance=\"button\" color=\"#2563eb\">View results</jump>\n\n<anchor id=\"{{bind:destination}}\">\n\n{{selection:Results appear here.}}",
			zh: "<jump to=\"{{bind:destination}}\" appearance=\"button\" color=\"#2563eb\">查看结果</jump>\n\n<anchor id=\"{{bind:destination}}\">\n\n{{selection:结果显示在这里。}}"
		},
		extended: !0
	},
	anchor: {
		title: {
			en: "Anchor",
			zh: "锚点"
		},
		description: {
			en: "Name a destination for document links.",
			zh: "为文档内的跳转指定目标位置。"
		},
		category: "layout",
		keywords: {
			en: [
				"anchor",
				"target",
				"destination"
			],
			zh: [
				"锚点",
				"目标",
				"位置"
			]
		},
		insertText: {
			en: "<anchor id=\"{{bind:destination}}\">",
			zh: "<anchor id=\"{{bind:destination}}\">"
		},
		extended: !0
	},
	text: {
		title: {
			en: "Colored text",
			zh: "文字颜色"
		},
		description: {
			en: "Give selected words a foreground color.",
			zh: "为选中的局部文字指定颜色。"
		},
		category: "hint",
		keywords: {
			en: [
				"text",
				"color",
				"foreground"
			],
			zh: [
				"文字",
				"颜色",
				"前景"
			]
		},
		inline: !0,
		insertText: {
			en: "<text color=\"#a2273a\">{{selection:Important reminder}}</text>",
			zh: "<text color=\"#a2273a\">{{selection:重要提醒}}</text>"
		},
		extended: !0
	},
	section: {
		title: {
			en: "Colored section",
			zh: "正文颜色"
		},
		description: {
			en: "Apply a shared text color to several paragraphs.",
			zh: "为一段或多段正文指定统一颜色。"
		},
		category: "layout",
		keywords: {
			en: [
				"section",
				"color",
				"paragraph"
			],
			zh: [
				"正文",
				"段落",
				"颜色"
			]
		},
		insertText: {
			en: "<section color=\"#45536f\">\n\n{{selection:Your paragraphs go here.}}\n\n</section>",
			zh: "<section color=\"#45536f\">\n\n{{selection:在这里填写正文。}}\n\n</section>"
		},
		extended: !0
	},
	"multi-select": {
		title: {
			en: "Multiple selection",
			zh: "多选"
		},
		description: {
			en: "Choose up to two items and read their values.",
			zh: "最多选择两个选项，公开选项值数组。"
		},
		category: "input",
		keywords: {
			en: [
				"multiple",
				"select",
				"subjects",
				"checkbox"
			],
			zh: [
				"多选",
				"选项",
				"主题"
			]
		},
		insertText: {
			en: "<multi-select bind=\"{{bind:subjects}}\" label=\"Subjects\" max-selected=\"2\">\n<option value=\"math\">Math</option>\n<option value=\"physics\">Physics</option>\n<option value=\"chemistry\">Chemistry</option>\n</multi-select>",
			zh: "<multi-select bind=\"{{bind:subjects}}\" label=\"主题\" max-selected=\"2\">\n<option value=\"math\">数学</option>\n<option value=\"physics\">物理</option>\n<option value=\"chemistry\">化学</option>\n</multi-select>"
		},
		extended: !0
	},
	"range-slider": {
		title: {
			en: "Interval slider",
			zh: "区间滑块"
		},
		description: {
			en: "Choose the lower and upper bounds of an interval.",
			zh: "同时选择区间的起点和终点。"
		},
		category: "input",
		keywords: {
			en: [
				"range",
				"interval",
				"slider",
				"bounds"
			],
			zh: [
				"区间",
				"滑块",
				"上下限"
			]
		},
		insertText: {
			en: "<range-slider label=\"Interval\" bind-start=\"{{bind:low}}\" bind-end=\"{{bind:high}}\" initial-start=\"20\" initial-end=\"80\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<range-slider label=\"观察区间\" bind-start=\"{{bind:low}}\" bind-end=\"{{bind:high}}\" initial-start=\"20\" initial-end=\"80\" min=\"0\" max=\"100\" step=\"1\">"
		},
		extended: !0
	},
	coordinate: {
		title: {
			en: "Coordinate point",
			zh: "二维坐标"
		},
		description: {
			en: "Drag a point or change its two coordinates.",
			zh: "拖动坐标点，或直接修改两个坐标。"
		},
		category: "input",
		keywords: {
			en: [
				"coordinate",
				"point",
				"drag",
				"geometry"
			],
			zh: [
				"坐标",
				"拖动",
				"几何"
			]
		},
		insertText: {
			en: "<coordinate label=\"Point\" bind-x=\"{{bind:px}}\" bind-y=\"{{bind:py}}\" initial-x=\"1\" initial-y=\"2\" x-min=\"-5\" x-max=\"5\" y-min=\"-5\" y-max=\"5\">",
			zh: "<coordinate label=\"坐标点\" bind-x=\"{{bind:px}}\" bind-y=\"{{bind:py}}\" initial-x=\"1\" initial-y=\"2\" x-min=\"-5\" x-max=\"5\" y-min=\"-5\" y-max=\"5\">"
		},
		extended: !0
	},
	quiz: {
		title: {
			en: "Practice question",
			zh: "练习题"
		},
		description: {
			en: "Check an answer and read a short explanation.",
			zh: "检查答案并阅读简短解析。"
		},
		category: "action",
		keywords: {
			en: [
				"quiz",
				"practice",
				"answer",
				"learn"
			],
			zh: [
				"练习",
				"题目",
				"答案"
			]
		},
		insertText: {
			en: "<quiz type=\"choice\" label=\"What is 2 + 3?\" answer=\"b\" explanation=\"The sum is 5.\">\n<option value=\"a\">4</option>\n<option value=\"b\">5</option>\n</quiz>",
			zh: "<quiz type=\"choice\" label=\"2 + 3 等于多少？\" answer=\"b\" explanation=\"相加得到 5。\">\n<option value=\"a\">4</option>\n<option value=\"b\">5</option>\n</quiz>"
		},
		extended: !0
	},
	steps: {
		title: {
			en: "Guided steps",
			zh: "分步阅读"
		},
		description: {
			en: "Read instructions one step at a time.",
			zh: "按顺序阅读说明，内置上一步和下一步。"
		},
		category: "layout",
		keywords: {
			en: [
				"steps",
				"guide",
				"previous",
				"next"
			],
			zh: [
				"步骤",
				"引导",
				"下一步"
			]
		},
		insertText: {
			en: "<steps label=\"Learning path\" bind=\"{{bind:lesson}}\">\n<step label=\"Observe\">\nChange a parameter.\n</step>\n<step label=\"Practice\">\nCheck an answer.\n</step>\n</steps>",
			zh: "<steps label=\"学习路线\" bind=\"{{bind:lesson}}\">\n<step label=\"观察\">\n调整参数。\n</step>\n<step label=\"练习\">\n检查答案。\n</step>\n</steps>"
		},
		extended: !0
	},
	slider: {
		title: {
			en: "Slider",
			zh: "滑块"
		},
		description: {
			en: "Drag the slider to choose a number within a range.",
			zh: "拖动滑块在指定范围内选择一个数值。"
		},
		category: "input",
		keywords: {
			en: [
				"slider",
				"range",
				"number",
				"drag",
				"value"
			],
			zh: [
				"滑块",
				"范围",
				"数值",
				"拖动",
				"滑动"
			]
		},
		insertText: {
			en: "<slider bind=\"{{bind:amount}}\" label=\"Amount\" initial=\"10\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<slider bind=\"{{bind:amount}}\" label=\"数量\" initial=\"10\" min=\"0\" max=\"100\" step=\"1\">"
		}
	},
	number: {
		title: {
			en: "Number input",
			zh: "数字输入"
		},
		description: {
			en: "Enter an exact number with an optional range and step.",
			zh: "输入精确数字，可限制范围和步长。"
		},
		category: "input",
		keywords: {
			en: [
				"number",
				"numeric",
				"input",
				"step",
				"quantity"
			],
			zh: [
				"数字",
				"数值",
				"输入",
				"步长",
				"数量"
			]
		},
		insertText: {
			en: "<number bind=\"{{bind:quantity}}\" label=\"Quantity\" initial=\"1\" min=\"0\" max=\"100\" step=\"1\">",
			zh: "<number bind=\"{{bind:quantity}}\" label=\"数量\" initial=\"1\" min=\"0\" max=\"100\" step=\"1\">"
		}
	},
	input: {
		title: {
			en: "Single-line text",
			zh: "单行文本"
		},
		description: {
			en: "Enter a name, title or other single-line text.",
			zh: "输入姓名、标题等单行文本。"
		},
		category: "input",
		keywords: {
			en: [
				"input",
				"text",
				"single-line",
				"field",
				"name"
			],
			zh: [
				"文本",
				"单行",
				"输入框",
				"名称",
				"输入"
			]
		},
		insertText: {
			en: "<input bind=\"{{bind:name}}\" label=\"Name\" placeholder=\"Enter a name\">",
			zh: "<input bind=\"{{bind:name}}\" label=\"名称\" placeholder=\"请输入名称\">"
		}
	},
	textarea: {
		title: {
			en: "Multi-line text",
			zh: "多行文本"
		},
		description: {
			en: "Enter notes, descriptions or other multi-line text.",
			zh: "输入说明、备注等多行文字。"
		},
		category: "input",
		keywords: {
			en: [
				"textarea",
				"text area",
				"multi-line",
				"notes",
				"description"
			],
			zh: [
				"文本域",
				"多行",
				"说明",
				"备注",
				"详细"
			]
		},
		insertText: {
			en: "<textarea bind=\"{{bind:message}}\" label=\"Details\" placeholder=\"Enter details\" rows=\"4\">",
			zh: "<textarea bind=\"{{bind:message}}\" label=\"详细说明\" placeholder=\"请输入详细说明\" rows=\"4\">"
		}
	},
	toggle: {
		title: {
			en: "Toggle",
			zh: "开关"
		},
		description: {
			en: "Switch a boolean option on or off.",
			zh: "在开启与关闭之间切换一个布尔选项。"
		},
		category: "input",
		keywords: {
			en: [
				"toggle",
				"switch",
				"boolean",
				"enable",
				"on"
			],
			zh: [
				"开关",
				"布尔",
				"启用",
				"切换",
				"选项"
			]
		},
		insertText: {
			en: "<toggle bind=\"{{bind:enabled}}\" label=\"Enable option\">",
			zh: "<toggle bind=\"{{bind:enabled}}\" label=\"启用选项\">"
		}
	},
	checkbox: {
		title: {
			en: "Checkbox",
			zh: "复选框"
		},
		description: {
			en: "Check or uncheck a boolean option.",
			zh: "勾选或取消一个布尔选项。"
		},
		category: "input",
		keywords: {
			en: [
				"checkbox",
				"check",
				"boolean",
				"confirm",
				"option"
			],
			zh: [
				"复选",
				"勾选",
				"布尔",
				"确认",
				"选项"
			]
		},
		insertText: {
			en: "<checkbox bind=\"{{bind:confirmed}}\" label=\"Confirm option\">",
			zh: "<checkbox bind=\"{{bind:confirmed}}\" label=\"确认选项\">"
		}
	},
	date: {
		title: {
			en: "Date picker",
			zh: "日期选择"
		},
		description: {
			en: "Pick a date; the value stays empty until one is chosen.",
			zh: "选择一个日期，未选择时为空字符串。"
		},
		category: "input",
		keywords: {
			en: [
				"date",
				"calendar",
				"picker",
				"day"
			],
			zh: [
				"日期",
				"日历",
				"时间",
				"选择"
			]
		},
		insertText: {
			en: "<date bind=\"{{bind:date}}\" label=\"Pick a date\">",
			zh: "<date bind=\"{{bind:date}}\" label=\"选择日期\">"
		}
	},
	choices: {
		title: {
			en: "Choice cards",
			zh: "选项卡片"
		},
		description: {
			en: "Pick one option from a set of cards.",
			zh: "从多个选项卡中选择一项。"
		},
		category: "input",
		keywords: {
			en: [
				"choices",
				"options",
				"cards",
				"select",
				"radio"
			],
			zh: [
				"选项",
				"选择",
				"卡片",
				"单选",
				"方案"
			]
		},
		insertText: {
			en: "<choices bind=\"{{bind:plan}}\" label=\"Choose a plan\">\n<option value=\"basic\">Basic</option>\n<option value=\"pro\">Pro</option>\n</choices>",
			zh: "<choices bind=\"{{bind:plan}}\" label=\"选择方案\">\n<option value=\"basic\">基础版</option>\n<option value=\"pro\">专业版</option>\n</choices>"
		}
	},
	counter: {
		title: {
			en: "Counter",
			zh: "计数器"
		},
		description: {
			en: "Adjust an integer with plus and minus buttons, then reset it in one click.",
			zh: "通过加减按钮调整整数，并可一键重置。"
		},
		category: "action",
		keywords: {
			en: [
				"counter",
				"count",
				"plus",
				"minus",
				"integer"
			],
			zh: [
				"计数",
				"加减",
				"整数",
				"调整",
				"重置"
			]
		},
		insertText: {
			en: "<counter bind=\"{{bind:count}}\" label=\"Count\" initial=\"0\" min=\"0\" max=\"99\">",
			zh: "<counter bind=\"{{bind:count}}\" label=\"计数\" initial=\"0\" min=\"0\" max=\"99\">"
		}
	},
	timer: {
		title: {
			en: "Countdown timer",
			zh: "倒计时"
		},
		description: {
			en: "Start, pause and reset a focus timer.",
			zh: "启动、暂停和重置一段专注计时。"
		},
		category: "action",
		keywords: {
			en: [
				"timer",
				"countdown",
				"focus",
				"seconds",
				"pause"
			],
			zh: [
				"计时",
				"倒计时",
				"专注",
				"秒",
				"暂停"
			]
		},
		insertText: {
			en: "<timer bind=\"{{bind:remaining}}\" label=\"Focus timer\" duration=\"60\">",
			zh: "<timer bind=\"{{bind:remaining}}\" label=\"专注计时\" duration=\"60\">"
		}
	},
	checklist: {
		title: {
			en: "Checklist",
			zh: "任务清单"
		},
		description: {
			en: "Track completion with a checkable task list.",
			zh: "用可勾选的任务列表记录完成情况。"
		},
		category: "action",
		keywords: {
			en: [
				"checklist",
				"tasks",
				"todo",
				"check",
				"done"
			],
			zh: [
				"清单",
				"任务",
				"勾选",
				"待办",
				"完成"
			]
		},
		insertText: {
			en: "<checklist bind=\"{{bind:done}}\" label=\"Task checklist\">\n- [ ] First task\n- [ ] Second task\n- [ ] Third task\n</checklist>",
			zh: "<checklist bind=\"{{bind:done}}\" label=\"完成清单\">\n- [ ] 第一项任务\n- [ ] 第二项任务\n- [ ] 第三项任务\n</checklist>"
		}
	},
	progress: {
		title: {
			en: "Progress bar",
			zh: "进度条"
		},
		description: {
			en: "Show completion from 0 to 100.",
			zh: "展示 0 到 100 之间的完成进度。"
		},
		category: "action",
		keywords: {
			en: [
				"progress",
				"completion",
				"bar",
				"percent"
			],
			zh: [
				"进度",
				"完成度",
				"进度条",
				"百分比"
			]
		},
		insertText: {
			en: "<progress label=\"Progress\" value=\"{{ 40 }}\">",
			zh: "<progress label=\"完成进度\" value=\"{{ 40 }}\">"
		}
	},
	panel: {
		title: {
			en: "Parameter panel",
			zh: "参数面板"
		},
		description: {
			en: "Group controls in a panel with a restore-defaults button.",
			zh: "把一组控件包进面板，并附带恢复默认按钮。"
		},
		category: "layout",
		keywords: {
			en: [
				"panel",
				"parameters",
				"reset",
				"form",
				"group"
			],
			zh: [
				"面板",
				"参数",
				"重置",
				"表单",
				"控件"
			]
		},
		insertText: {
			en: "<panel title=\"Parameters\">\n{{selection:Sample content}}\n</panel>",
			zh: "<panel title=\"参数面板\">\n{{selection:示例内容}}\n</panel>"
		}
	},
	card: {
		title: {
			en: "Content card",
			zh: "内容卡片"
		},
		description: {
			en: "Organize a self-contained piece of content in a card.",
			zh: "用卡片组织一段独立内容。"
		},
		category: "layout",
		keywords: {
			en: [
				"card",
				"container",
				"content",
				"section"
			],
			zh: [
				"卡片",
				"容器",
				"内容",
				"区块"
			]
		},
		insertText: {
			en: "<card title=\"Content card\">\n{{selection:Sample content}}\n</card>",
			zh: "<card title=\"内容卡片\">\n{{selection:示例内容}}\n</card>"
		}
	},
	if: {
		title: {
			en: "Conditional section",
			zh: "条件区域"
		},
		description: {
			en: "Show the contents only when a condition is true.",
			zh: "只有条件为真时才显示其中内容。"
		},
		category: "layout",
		keywords: {
			en: [
				"if",
				"condition",
				"when",
				"show",
				"visible"
			],
			zh: [
				"条件",
				"判断",
				"显示",
				"当"
			]
		},
		insertText: {
			en: "<if when=\"{{ {{select:true}} }}\">\n{{selection:Sample content}}\n</if>",
			zh: "<if when=\"{{ {{select:true}} }}\">\n{{selection:示例内容}}\n</if>"
		}
	},
	tabs: {
		title: {
			en: "Tabs",
			zh: "标签页"
		},
		description: {
			en: "Split content across switchable tabs.",
			zh: "把内容分到多个可切换的标签页中。"
		},
		category: "layout",
		keywords: {
			en: [
				"tabs",
				"switch",
				"sections",
				"groups"
			],
			zh: [
				"标签页",
				"切换",
				"分组",
				"选项卡"
			]
		},
		insertText: {
			en: "<tabs label=\"Content tabs\">\n<tab label=\"Tab one\">\n{{selection:Sample content}}\n</tab>\n\n<tab label=\"Tab two\">\nContent for the second tab.\n</tab>\n</tabs>",
			zh: "<tabs label=\"内容标签页\">\n<tab label=\"标签一\">\n{{selection:示例内容}}\n</tab>\n\n<tab label=\"标签二\">\n第二个标签页的内容。\n</tab>\n</tabs>"
		}
	},
	accordion: {
		title: {
			en: "Accordion",
			zh: "折叠面板"
		},
		description: {
			en: "Put notes into items that expand and collapse.",
			zh: "把说明放进可展开和收起的条目。"
		},
		category: "layout",
		keywords: {
			en: [
				"accordion",
				"collapse",
				"expand",
				"faq",
				"disclosure"
			],
			zh: [
				"折叠",
				"展开",
				"问答",
				"手风琴",
				"条目"
			]
		},
		insertText: {
			en: "<accordion label=\"FAQ\">\n<disclosure label=\"Question one\">\n{{selection:Sample content}}\n</disclosure>\n\n<disclosure label=\"Question two\">\nDetails for the second item.\n</disclosure>\n</accordion>",
			zh: "<accordion label=\"常见问题\">\n<disclosure label=\"问题一\">\n{{selection:示例内容}}\n</disclosure>\n\n<disclosure label=\"问题二\">\n第二个条目的说明。\n</disclosure>\n</accordion>"
		}
	},
	chart: {
		title: {
			en: "Bar chart",
			zh: "柱状图"
		},
		description: {
			en: "Turn a Markdown table into a bar chart.",
			zh: "把 Markdown 表格转换成柱状图。"
		},
		category: "data",
		keywords: {
			en: [
				"chart",
				"bar",
				"graph",
				"table",
				"data"
			],
			zh: [
				"图表",
				"柱状图",
				"表格",
				"数据",
				"对比"
			]
		},
		insertText: {
			en: "<chart kind=\"bar\" title=\"Category comparison\" y-label=\"Value\">\n| Item | Value |\n| --- | ---: |\n| Item A | 20 |\n| Item B | 35 |\n</chart>",
			zh: "<chart kind=\"bar\" title=\"分类对比\" y-label=\"数值\">\n| 项目 | 数值 |\n| --- | ---: |\n| 项目甲 | 20 |\n| 项目乙 | 35 |\n</chart>"
		}
	},
	table: {
		title: {
			en: "Enhanced table",
			zh: "增强表格"
		},
		description: {
			en: "A Markdown table with search, sorting and paging.",
			zh: "带搜索、排序和分页的 Markdown 表格。"
		},
		category: "data",
		keywords: {
			en: [
				"table",
				"search",
				"sort",
				"paging",
				"data"
			],
			zh: [
				"表格",
				"搜索",
				"排序",
				"分页",
				"数据"
			]
		},
		insertText: {
			en: "<table label=\"Data table\" page-size=\"5\">\n| Name | Category | Value |\n| --- | --- | ---: |\n| Item A | Category one | 20 |\n| Item B | Category two | 35 |\n</table>",
			zh: "<table label=\"数据表格\" page-size=\"5\">\n| 名称 | 分类 | 数值 |\n| --- | --- | ---: |\n| 项目甲 | 分类一 | 20 |\n| 项目乙 | 分类二 | 35 |\n</table>"
		}
	},
	timeline: {
		title: {
			en: "Timeline",
			zh: "时间轴"
		},
		description: {
			en: "Show task start times and durations in a table.",
			zh: "用表格展示任务的开始时间与时长。"
		},
		category: "data",
		keywords: {
			en: [
				"timeline",
				"schedule",
				"plan",
				"duration",
				"gantt"
			],
			zh: [
				"时间轴",
				"计划",
				"时长",
				"日程",
				"任务"
			]
		},
		insertText: {
			en: "<timeline title=\"Task timeline\">\n| Task | Start | Duration | Notes |\n| --- | ---: | ---: | --- |\n| Prepare | 0 | 10 | List the materials |\n| Execute | 10 | 20 | Complete the main work |\n| Review | 30 | 5 | Check the results |\n</timeline>",
			zh: "<timeline title=\"任务时间轴\">\n| 事项 | 开始 | 时长 | 说明 |\n| --- | ---: | ---: | --- |\n| 准备 | 0 | 10 | 列出所需材料 |\n| 执行 | 10 | 20 | 完成主要内容 |\n| 检查 | 30 | 5 | 复核结果 |\n</timeline>"
		}
	},
	diagram: {
		title: {
			en: "Interactive diagram",
			zh: "交互图解"
		},
		description: {
			en: "Show a flow with nodes and edges; click a node to read its notes.",
			zh: "用节点和连线展示流程，可点击查看说明。"
		},
		category: "data",
		keywords: {
			en: [
				"diagram",
				"flow",
				"node",
				"edge",
				"graph"
			],
			zh: [
				"图解",
				"流程",
				"节点",
				"连线",
				"关系图"
			]
		},
		insertText: {
			en: "<diagram label=\"Flow overview\">\n<node id=\"start\" label=\"Start\">\nWhere the flow begins.\n</node>\n\n<node id=\"process\" label=\"Process\">\nPerform the main step.\n</node>\n\n<node id=\"end\" label=\"End\">\nReview the result.\n</node>\n\n<edge from=\"start\" to=\"process\" label=\"Proceed\">\n<edge from=\"process\" to=\"end\" label=\"Complete\">\n</diagram>",
			zh: "<diagram label=\"流程示意\">\n<node id=\"start\" label=\"开始\">\n流程起点。\n</node>\n\n<node id=\"process\" label=\"处理\">\n执行主要步骤。\n</node>\n\n<node id=\"end\" label=\"结束\">\n查看结果。\n</node>\n\n<edge from=\"start\" to=\"process\" label=\"进入\">\n<edge from=\"process\" to=\"end\" label=\"完成\">\n</diagram>"
		}
	},
	plot: {
		title: {
			en: "Function plot",
			zh: "函数曲线"
		},
		description: {
			en: "Plot explicit, parametric or implicit curves from LaTeX formulas.",
			zh: "用 LaTeX 公式绘制显式、参数方程或隐函数曲线。"
		},
		category: "data",
		keywords: {
			en: [
				"plot",
				"curve",
				"function",
				"parametric",
				"implicit",
				"formula",
				"latex",
				"math"
			],
			zh: [
				"曲线",
				"函数",
				"参数方程",
				"隐函数",
				"公式",
				"数学",
				"绘图"
			]
		},
		insertText: {
			en: "<plot min=\"-5\" max=\"5\" label=\"Function plot\">\n$$ y = x^2 $$\n</plot>",
			zh: "<plot min=\"-5\" max=\"5\" label=\"函数曲线\">\n$$ y = x^2 $$\n</plot>"
		}
	},
	alert: {
		title: {
			en: "Alert",
			zh: "提示框"
		},
		description: {
			en: "Highlight info, success or warning messages with different tones.",
			zh: "用不同语气突出普通、成功或警告信息。"
		},
		category: "hint",
		keywords: {
			en: [
				"alert",
				"notice",
				"warning",
				"info",
				"message"
			],
			zh: [
				"提示",
				"警告",
				"通知",
				"信息",
				"消息"
			]
		},
		insertText: {
			en: "<alert tone=\"info\" title=\"Notice\">\n{{selection:Sample content}}\n</alert>",
			zh: "<alert tone=\"info\" title=\"提示\">\n{{selection:示例内容}}\n</alert>"
		}
	},
	badge: {
		title: {
			en: "Badge",
			zh: "徽标"
		},
		description: {
			en: "Show a short status marker inside a sentence.",
			zh: "在句子里显示一个简短状态标记。"
		},
		category: "hint",
		keywords: {
			en: [
				"badge",
				"label",
				"status",
				"inline",
				"tag"
			],
			zh: [
				"徽标",
				"标签",
				"状态",
				"行内",
				"标记"
			]
		},
		inline: !0,
		insertText: {
			en: "<badge tone=\"success\">Badge</badge>",
			zh: "<badge tone=\"success\">标签</badge>"
		}
	},
	tooltip: {
		title: {
			en: "Tooltip",
			zh: "行内提示"
		},
		description: {
			en: "Attach a hover or focus note to a word in a sentence.",
			zh: "为句中的词语附加悬停或聚焦说明。"
		},
		category: "hint",
		keywords: {
			en: [
				"tooltip",
				"hint",
				"hover",
				"focus",
				"inline"
			],
			zh: [
				"提示",
				"悬停",
				"说明",
				"行内",
				"气泡"
			]
		},
		inline: !0,
		insertText: {
			en: "<tooltip text=\"Extra details appear here.\">Hover to view</tooltip>",
			zh: "<tooltip text=\"这里显示补充说明。\">悬停查看</tooltip>"
		}
	}
}), Lt = Object.freeze(Object.keys(B));
function V(e) {
	return Object.hasOwn(B, e) ? B[e] : void 0;
}
function Rt(e, t, n = "") {
	if (e === void 0) return n;
	for (let n of [
		t,
		"en",
		"zh"
	]) {
		let t = e[n];
		if (typeof t == "string" && t.trim() !== "") return t;
	}
	for (let t of Object.values(e)) if (typeof t == "string" && t.trim() !== "") return t;
	return n;
}
function zt(e, t) {
	let n = z.find((t) => t.id === e);
	return n ? Rt(n.title, t, n.id) : e;
}
function Bt(e) {
	let t = V(e);
	if (!t) return;
	let n = [];
	for (let e of [...t.keywords.en, ...t.keywords.zh]) {
		let t = e.toLowerCase();
		n.some((e) => e.toLowerCase() === t) || n.push(e);
	}
	return Object.freeze(n);
}
function Vt(e) {
	let t = V(e);
	if (!t) return;
	let n = t.insertText.en;
	if (typeof n == "string" && n.trim() !== "") return {
		title: t.title,
		description: t.description,
		category: It.has(t.category) ? t.category : void 0,
		insertText: n
	};
}
// src/presets/default-components.ts
var Ht = ee, H = {
	text: (e = {}) => ({
		kind: "string",
		coerce: "text",
		...e
	}),
	expressionText: (e = {}) => ({
		kind: "string",
		...e
	}),
	dynamicText: (e = {}) => ({
		kind: "string",
		dynamic: !0,
		...e
	}),
	staticText: (e = {}) => ({
		kind: "string",
		static: !0,
		...e
	}),
	number: (e = {}) => ({
		kind: "number",
		...e
	}),
	boolean: (e = {}) => ({
		kind: "boolean",
		...e
	}),
	choice: (e, t = {}) => ({
		kind: "enum",
		enum: e,
		...t
	})
}, U = (e = {}) => H.text(e), W = () => H.text(), G = () => H.text(), K = () => H.boolean({
	dynamic: !0,
	default: !1
}), q = () => H.staticText({ color: !0 });
function Ut() {
	return Object.freeze({
		interactive: !0,
		static: !0,
		ssr: !0,
		offline: !0
	});
}
function J(e, t, n, r = {}) {
	return Object.freeze({
		kind: e,
		family: t,
		bind: "bind",
		initial: "initial",
		initialRule: n,
		...r
	});
}
function Y(e, t, n = {}) {
	return Object.freeze({
		kind: "number",
		family: "number",
		bind: `bind-${e}`,
		initial: `initial-${e}`,
		initialRule: t,
		exclusive: !0,
		...n
	});
}
var X = (e, t, n = "step") => ({
	min: { prop: e },
	max: { prop: t },
	step: { prop: n }
});
function Z(e) {
	return Object.freeze(e);
}
function Q(...e) {
	return Object.freeze(e.map((e) => Object.freeze(e)));
}
function $(e, t, n) {
	let r = Vt(e);
	return wt({
		id: `reactive-md/${e}`,
		name: e,
		version: Ht,
		protocol: b,
		form: t,
		capabilities: Ut(),
		...n,
		...r ? { authoring: r } : {}
	});
}
var Wt = $("input", "leaf", {
	props: {
		label: U(),
		type: H.choice(["text", "email"], {
			static: !0,
			default: "text"
		}),
		placeholder: H.text(),
		required: H.boolean({
			dynamic: !0,
			default: !1
		}),
		"min-length": H.number({
			integer: !0,
			min: 0,
			default: 0
		}),
		"max-length": H.number({
			integer: !0,
			min: 0
		}),
		disabled: K()
	},
	bindings: { value: J("string", "text", "empty") },
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "text-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "dynamic-constraints",
		attributes: ["required"]
	}, {
		kind: "value-length",
		min: "min-length",
		max: "max-length",
		email: "type",
		emailType: "email"
	}, {
		kind: "value-required",
		required: "required"
	})
}), Gt = $("textarea", "leaf", {
	props: {
		label: U(),
		placeholder: H.text(),
		rows: H.number({
			integer: !0,
			positive: !0,
			default: 4
		}),
		required: H.boolean({
			dynamic: !0,
			default: !1
		}),
		"min-length": H.number({
			integer: !0,
			min: 0,
			default: 0
		}),
		"max-length": H.number({
			integer: !0,
			min: 0
		}),
		disabled: K()
	},
	bindings: { value: J("string", "text", "empty") },
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "text-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "dynamic-constraints",
		attributes: ["required"]
	}, {
		kind: "value-length",
		min: "min-length",
		max: "max-length"
	}, {
		kind: "value-required",
		required: "required"
	})
}), Kt = $("number", "leaf", {
	props: {
		label: U(),
		min: H.number({ dynamic: !0 }),
		max: H.number({ dynamic: !0 }),
		step: H.number({
			positive: !0,
			default: 1
		}),
		disabled: K()
	},
	bindings: { value: J("number", "number", "nearest-zero", { constraints: X("min", "max") }) },
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	}, {
		kind: "dynamic-constraints",
		attributes: ["min", "max"]
	})
}), qt = $("slider", "leaf", {
	props: {
		label: U(),
		min: H.number({
			dynamic: !0,
			default: 0
		}),
		max: H.number({
			dynamic: !0,
			default: 100
		}),
		step: H.number({
			positive: !0,
			default: 1
		}),
		disabled: K(),
		color: q()
	},
	bindings: { value: J("number", "number", "min", { constraints: X("min", "max") }) },
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	}, {
		kind: "dynamic-constraints",
		attributes: ["min", "max"]
	})
}), Jt = $("range-slider", "leaf", {
	props: {
		label: U(),
		min: H.number({ default: 0 }),
		max: H.number({ default: 100 }),
		step: H.number({
			positive: !0,
			default: 1
		}),
		disabled: K(),
		color: q()
	},
	bindings: {
		start: Y("start", "min", { constraints: X("min", "max") }),
		end: Y("end", "max-step", { constraints: X("min", "max") })
	},
	slotRelations: [{
		lower: "start",
		upper: "end"
	}],
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	})
}), Yt = $("coordinate", "leaf", {
	props: {
		label: U(),
		"x-min": H.number({ default: -5 }),
		"x-max": H.number({ default: 5 }),
		"y-min": H.number({ default: -5 }),
		"y-max": H.number({ default: 5 }),
		step: H.number({
			positive: !0,
			default: 1
		}),
		disabled: K(),
		color: q()
	},
	bindings: {
		x: Y("x", "nearest-zero", { constraints: {
			min: { prop: "x-min" },
			max: { prop: "x-max" },
			step: { prop: "step" }
		} }),
		y: Y("y", "nearest-zero", { constraints: {
			min: { prop: "y-min" },
			max: { prop: "y-max" },
			step: { prop: "step" }
		} })
	},
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "numeric-range",
		min: "x-min",
		max: "x-max",
		step: "step"
	}, {
		kind: "numeric-range",
		min: "y-min",
		max: "y-max"
	})
}), Xt = $("toggle", "leaf", {
	props: {
		label: U(),
		disabled: K(),
		color: q()
	},
	bindings: { value: J("boolean", "boolean", "false") },
	structure: Z({
		rule: "none",
		label: "required"
	})
}), Zt = $("checkbox", "leaf", {
	props: {
		label: U(),
		disabled: K(),
		color: q()
	},
	bindings: { value: J("boolean", "boolean", "false") },
	structure: Z({
		rule: "none",
		label: "required"
	})
}), Qt = $("date", "leaf", {
	props: {
		label: U(),
		min: H.dynamicText(),
		max: H.dynamicText(),
		required: H.boolean({
			dynamic: !0,
			default: !1
		}),
		disabled: K()
	},
	bindings: { value: J("string", "date", "empty") },
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "date-bounds",
		min: "min",
		max: "max"
	}, {
		kind: "dynamic-constraints",
		attributes: [
			"min",
			"max",
			"required"
		]
	}, {
		kind: "value-date",
		min: "min",
		max: "max",
		required: "required"
	})
});
Z({
	rule: "inline",
	label: "none",
	inlineOnly: !0,
	noComponents: !0
});
function $t(e, t = "container") {
	return $(e, t, {
		props: {
			label: U(),
			disabled: K(),
			color: q()
		},
		bindings: { value: J("string", "choice", "first-option") },
		structure: Z({
			rule: "options",
			label: "required",
			child: "option",
			children: ["option"],
			min: 1,
			max: a,
			valueAttribute: "value"
		}),
		rules: Q({
			kind: "options-body",
			child: "option",
			valueAttribute: "value",
			unique: !0,
			max: a
		})
	});
}
var en = $t("select"), tn = $t("choices"), nn = $t("radio-group"), rn = $("multi-select", "container", {
	props: {
		label: U(),
		"max-selected": H.number({
			integer: !0,
			min: 0
		}),
		disabled: K(),
		color: q()
	},
	bindings: { value: J("array", "multi-select", "empty-array", {
		exclusive: !0,
		maxItems: { prop: "max-selected" }
	}) },
	structure: Z({
		rule: "options",
		label: "required",
		child: "option",
		children: ["option"],
		min: 1,
		max: a,
		valueAttribute: "value",
		forbidSeparator: ","
	}),
	rules: Q({
		kind: "options-body",
		child: "option",
		valueAttribute: "value",
		unique: !0,
		max: a,
		forbidSeparator: ","
	}, {
		kind: "option-count",
		max: "max-selected"
	})
}), an = $("option", "container", {
	props: { value: H.staticText({ required: !0 }) },
	structure: Z({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: Q({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" })
}), on = $("counter", "leaf", {
	props: {
		label: U(),
		min: H.number({ default: 0 }),
		max: H.number(),
		step: H.number({
			positive: !0,
			default: 1
		}),
		disabled: K()
	},
	bindings: { value: J("number", "number", "nearest-zero", { constraints: X("min", "max") }) },
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "numeric-range",
		min: "min",
		max: "max",
		step: "step"
	})
}), sn = $("timer", "leaf", {
	props: {
		label: U(),
		duration: H.number({
			integer: !0,
			positive: !0,
			default: 60
		})
	},
	bindings: { value: J("number", "timer", "duration", {
		exclusive: !0,
		constraints: {
			min: { literal: 0 },
			max: { prop: "duration" },
			step: { literal: 1 }
		},
		retain: !1
	}) },
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "timer-duration",
		attribute: "duration",
		default: 60
	}, {
		kind: "retain",
		value: !1
	})
}), cn = $("checklist", "container", {
	props: {
		label: U(),
		disabled: K(),
		color: q()
	},
	bindings: { value: J("array", "checklist", "checked", {
		exclusive: !0,
		retain: !1
	}) },
	structure: Z({
		rule: "content",
		label: "required",
		noComponents: !0
	}),
	rules: Q({
		kind: "checklist-body",
		itemLimit: a
	}, {
		kind: "retain",
		value: !1
	})
}), ln = $("progress", "leaf", {
	props: {
		label: U(),
		value: H.number({
			dynamic: !0,
			required: !0
		}),
		max: H.number({
			positive: !0,
			default: 100
		}),
		color: q()
	},
	structure: Z({
		rule: "none",
		label: "required"
	}),
	rules: Q({
		kind: "progress-bounds",
		value: "value",
		max: "max",
		defaultMax: 100
	})
}), un = $("jump", "inline", {
	props: {
		to: H.staticText({ required: !0 }),
		appearance: H.choice(["link", "button"], {
			static: !0,
			default: "link"
		}),
		color: q()
	},
	structure: Z({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: Q({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" }, {
		kind: "navigation",
		target: "to"
	})
}), dn = $("anchor", "leaf", {
	props: { id: H.staticText({ required: !0 }) },
	structure: Z({
		rule: "none",
		label: "none"
	}),
	rules: Q({
		kind: "anchor",
		id: "id"
	})
}), fn = $("text", "inline", {
	props: { color: H.staticText({
		required: !0,
		color: !0
	}) },
	structure: Z({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: Q({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" })
}), pn = $("section", "container", {
	props: { color: H.staticText({
		required: !0,
		color: !0
	}) },
	structure: Z({
		rule: "any",
		label: "none"
	})
}), mn = $("quiz", "container", {
	props: {
		type: H.choice(["choice", "number"], {
			static: !0,
			default: "choice"
		}),
		label: U(),
		answer: H.staticText({ required: !0 }),
		explanation: H.text(),
		tolerance: H.number({
			min: 0,
			default: 0
		}),
		disabled: K()
	},
	structure: Z({
		rule: "quiz",
		label: "required",
		child: "option",
		children: ["option"],
		max: a,
		valueAttribute: "value"
	}),
	rules: Q({
		kind: "quiz-body",
		type: "type",
		answer: "answer",
		tolerance: "tolerance",
		child: "option",
		valueAttribute: "value",
		max: a
	}, {
		kind: "nonempty",
		attribute: "answer"
	})
}), hn = $("panel", "container", {
	props: {
		title: G(),
		reset: H.boolean({ default: !0 })
	},
	structure: Z({
		rule: "any",
		label: "none"
	}),
	rules: Q({
		kind: "self-binding-read",
		mode: "always"
	})
}), gn = $("card", "container", {
	props: { title: G() },
	structure: Z({
		rule: "any",
		label: "none"
	})
}), _n = $("grid", "container", {
	props: { columns: H.number({
		integer: !0,
		min: 1,
		max: 4,
		default: 2
	}) },
	structure: Z({
		rule: "components",
		label: "none",
		child: "card",
		children: ["card"],
		min: 1
	}),
	rules: Q({
		kind: "only-children",
		children: ["card"],
		min: 1
	})
}), vn = $("tabs", "container", {
	props: { label: W() },
	bindings: { value: J("string", "tabs", "first-tab", { exclusive: !0 }) },
	structure: Z({
		rule: "tabs",
		label: "optional",
		child: "tab",
		children: ["tab"],
		min: 1,
		valueAttribute: "value",
		generatedPrefix: "tab-"
	}),
	rules: Q({
		kind: "value-sequence",
		child: "tab",
		valueAttribute: "value",
		min: 1,
		generatedPrefix: "tab-",
		unique: !0
	})
}), yn = $("tab", "container", {
	props: {
		label: U(),
		value: H.staticText()
	},
	structure: Z({
		rule: "any",
		label: "required",
		parents: ["tabs"]
	})
}), bn = $("steps", "container", {
	props: { label: W() },
	bindings: { value: J("string", "steps", "first-step", { exclusive: !0 }) },
	structure: Z({
		rule: "steps",
		label: "optional",
		child: "step",
		children: ["step"],
		min: 1,
		valueAttribute: "value",
		generatedPrefix: "step-"
	}),
	rules: Q({
		kind: "value-sequence",
		child: "step",
		valueAttribute: "value",
		min: 1,
		generatedPrefix: "step-",
		unique: !0
	})
}), xn = $("step", "container", {
	props: {
		label: U(),
		value: H.staticText()
	},
	structure: Z({
		rule: "any",
		label: "required",
		parents: ["steps"]
	})
}), Sn = $("accordion", "container", {
	props: { label: W() },
	structure: Z({
		rule: "components",
		label: "optional",
		child: "disclosure",
		children: ["disclosure"],
		min: 1
	}),
	rules: Q({
		kind: "only-children",
		children: ["disclosure"],
		min: 1
	})
}), Cn = $("disclosure", "container", {
	props: {
		label: U(),
		open: H.boolean({ default: !1 })
	},
	structure: Z({
		rule: "any",
		label: "required",
		parents: ["accordion"]
	})
}), wn = $("if", "container", {
	props: { when: H.boolean({
		dynamic: !0,
		required: !0
	}) },
	structure: Z({
		rule: "any",
		label: "none"
	}),
	rules: Q({
		kind: "require-full-interpolation",
		attributes: ["when"]
	})
}), Tn = $("alert", "container", {
	props: {
		title: G(),
		tone: H.choice([
			"info",
			"success",
			"warning"
		], {
			dynamic: !0,
			default: "info"
		})
	},
	structure: Z({
		rule: "any",
		label: "none"
	})
}), En = $("badge", "inline", {
	props: {
		tone: H.choice([
			"neutral",
			"success",
			"warning"
		], {
			dynamic: !0,
			default: "neutral"
		}),
		color: q()
	},
	structure: Z({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: Q({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" })
}), Dn = $("tooltip", "inline", {
	props: { text: H.text({ required: !0 }) },
	structure: Z({
		rule: "inline",
		label: "none",
		inlineOnly: !0,
		noComponents: !0
	}),
	rules: Q({
		kind: "inline-body",
		strict: !0
	}, { kind: "no-components" })
}), On = $("validation", "leaf", {
	props: {
		when: H.boolean({
			dynamic: !0,
			required: !0
		}),
		message: H.text({ required: !0 }),
		fields: H.staticText({ required: !0 })
	},
	structure: Z({
		rule: "none",
		label: "none"
	}),
	rules: Q({
		kind: "validation-rule",
		when: "when",
		fields: "fields",
		message: "message",
		placement: "prose",
		max: 100
	}, {
		kind: "scoped-expressions",
		attributes: ["fields"],
		scope: "validation"
	})
}), kn = $("data-table", "container", {
	props: {
		label: H.staticText(),
		rows: H.expressionText({ required: !0 }),
		key: H.expressionText({ required: !0 }),
		"max-rows": H.number({
			integer: !0,
			positive: !0,
			max: d,
			default: 100
		})
	},
	structure: Z({
		rule: "components",
		label: "required",
		child: "column",
		children: ["column"],
		min: 1,
		max: 20
	}),
	rules: Q({
		kind: "data-table",
		rows: "rows",
		key: "key",
		child: "column",
		childValue: "value",
		label: "label",
		maxRows: "max-rows",
		defaultMaxRows: 100,
		documentRows: m,
		documentCells: h,
		maxColumns: 20
	}, {
		kind: "require-full-interpolation",
		attributes: ["rows", "key"]
	}, {
		kind: "scoped-expressions",
		attributes: ["key"],
		scope: "row"
	}, {
		kind: "row-values",
		rows: "rows",
		key: "key",
		child: "column",
		childValue: "value"
	})
}), An = $("column", "leaf", {
	props: {
		label: H.staticText({ required: !0 }),
		value: H.expressionText({ required: !0 })
	},
	structure: Z({
		rule: "none",
		label: "none",
		parents: ["data-table"]
	}),
	rules: Q({
		kind: "require-full-interpolation",
		attributes: ["value"]
	}, {
		kind: "scoped-expressions",
		attributes: ["value"],
		scope: "row"
	})
}), jn = $("table", "container", {
	props: {
		label: W(),
		searchable: H.boolean({ default: !0 }),
		sortable: H.boolean({ default: !0 }),
		"page-size": H.number({
			integer: !0,
			positive: !0,
			default: 10
		}),
		key: H.staticText()
	},
	bindings: { value: J("string", "selection", "none", { requiresAttributes: ["key"] }) },
	structure: Z({
		rule: "table",
		label: "optional"
	}),
	rules: Q({ kind: "single-table" }, {
		kind: "selection-requires",
		key: "key",
		attributes: ["bind", "initial"]
	}, {
		kind: "table-selection",
		key: "key",
		bindings: ["bind"]
	}, {
		kind: "self-binding-read",
		mode: "attribute",
		attribute: "key"
	})
}), Mn = $("chart", "container", {
	props: {
		kind: H.choice([
			"bar",
			"line",
			"area",
			"scatter",
			"donut"
		], {
			static: !0,
			default: "bar"
		}),
		title: G(),
		x: H.staticText(),
		y: H.staticText(),
		"x-label": H.text(),
		"y-label": H.text(),
		key: H.staticText()
	},
	bindings: { value: J("string", "selection", "none", { requiresAttributes: ["key"] }) },
	structure: Z({
		rule: "table",
		label: "none"
	}),
	rules: Q({ kind: "single-table" }, {
		kind: "chart-table",
		chartKind: "kind",
		x: "x",
		y: "y"
	}, {
		kind: "table-selection",
		key: "key",
		bindings: ["bind"]
	}, {
		kind: "selection-requires",
		key: "key",
		attributes: ["bind", "initial"]
	}, {
		kind: "self-binding-read",
		mode: "attribute",
		attribute: "key"
	})
}), Nn = $("plot", "container", {
	props: {
		label: W(),
		min: H.number({
			dynamic: !0,
			default: -10
		}),
		max: H.number({
			dynamic: !0,
			default: 10
		}),
		samples: H.number({
			integer: !0,
			min: 2,
			max: 2e3,
			static: !0,
			default: 200
		}),
		"x-label": H.text({ default: "x" }),
		"y-label": H.text({ default: "y" })
	},
	structure: Z({
		rule: "plot",
		label: "optional"
	}),
	rules: Q({ kind: "math-body" }, {
		kind: "numeric-range",
		min: "min",
		max: "max",
		order: "increasing"
	}, {
		kind: "plot-math",
		min: "min",
		max: "max",
		samples: "samples",
		curves: 16,
		points: l
	}, { kind: "inline-math-reads" })
}), Pn = $("timeline", "container", {
	props: {
		title: G(),
		unit: H.text({ default: "minutes" })
	},
	structure: Z({
		rule: "table",
		label: "none"
	}),
	rules: Q({ kind: "single-table" }, {
		kind: "timeline-table",
		headerSets: [[
			"Task",
			"Start",
			"Duration",
			"Notes"
		], [
			"事项",
			"开始",
			"时长",
			"说明"
		]]
	})
}), Fn = $("diagram", "container", {
	props: {
		label: W(),
		direction: H.choice(["right", "down"], {
			static: !0,
			default: "right"
		})
	},
	bindings: { value: J("string", "diagram", "first-node", { exclusive: !0 }) },
	structure: Z({
		rule: "diagram",
		label: "optional",
		child: "node",
		children: ["node", "edge"],
		min: 1
	}),
	rules: Q({
		kind: "diagram-body",
		node: "node",
		edge: "edge",
		id: "id",
		from: "from",
		to: "to",
		label: "label"
	}, {
		kind: "self-binding-read",
		mode: "always"
	})
}), In = $("node", "container", {
	props: {
		id: H.staticText({ required: !0 }),
		label: U(),
		tone: H.choice([
			"neutral",
			"success",
			"warning"
		], {
			dynamic: !0,
			default: "neutral"
		})
	},
	structure: Z({
		rule: "content",
		label: "required",
		noComponents: !0,
		parents: ["diagram"]
	}),
	rules: Q({ kind: "no-components" })
}), Ln = $("edge", "leaf", {
	props: {
		from: H.staticText({ required: !0 }),
		to: H.staticText({ required: !0 }),
		label: W()
	},
	structure: Z({
		rule: "none",
		label: "none",
		parents: ["diagram"]
	})
}), Rn = Object.freeze([
	Wt,
	Gt,
	Kt,
	qt,
	Jt,
	Yt,
	Xt,
	Zt,
	Qt,
	en,
	tn,
	nn,
	rn,
	an,
	on,
	sn,
	cn,
	ln,
	un,
	dn,
	fn,
	pn,
	mn,
	hn,
	gn,
	_n,
	vn,
	yn,
	bn,
	xn,
	Sn,
	Cn,
	wn,
	Tn,
	En,
	Dn,
	On,
	kn,
	An,
	jn,
	Mn,
	Nn,
	Pn,
	Fn,
	In,
	Ln
]), zn = Object.freeze(Rn.map((e) => e.name));
export { m as $, Nt as A, re as B, tt as C, jt as D, ve as E, b as F, y as G, pe as H, te as I, r as J, _ as K, ne as L, rt as M, st as N, wt as O, L as P, h as Q, ee as R, xe as S, we as T, fe as U, de as V, C as W, t as X, n as Y, a as Z, ge as _, B as a, l as at, $e as b, V as c, o as ct, Qe as d, p as et, me as f, Te as g, _e as h, Lt as i, c as it, Pt as j, Ft as k, Rt as l, g as lt, ye as m, zn as n, s as nt, zt as o, u as ot, Se as p, f as q, z as r, e as rt, Bt as s, i as st, Rn as t, d as tt, nt as u, be as v, Ce as w, et as x, he as y, ie as z };
