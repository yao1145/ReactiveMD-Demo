import { A as e, I as t, K as n, M as r, P as i, R as a, U as o, n as s, t as c } from "./default-components-qRt0E8bl.js";
import { o as l, p as u, r as d, t as f, u as p } from "./registry-core-BIJfeW7H.js";
import m from "./reactive-md-default-preset.js";
// src/local/theme/theme.ts
var h = "reactive-md-theme-1", g = Object.freeze({
	name: "default",
	protocol: h,
	colorSchemes: Object.freeze(["light", "dark"])
});
function ee(e, t) {
	let n = typeof t == "string" ? t.length : Infinity;
	if (!e || typeof e.start != "number" || typeof e.end != "number" || !Number.isFinite(e.start) || !Number.isFinite(e.end)) return {
		start: 0,
		end: 0
	};
	let r = Math.max(0, Math.min(n, Math.floor(e.start)));
	return {
		start: r,
		end: Math.max(r, Math.min(n, Math.floor(e.end)))
	};
}
function te(e, t) {
	if (typeof e != "string" || e.length === 0) return {
		line: 1,
		column: 1
	};
	let n = Math.min(t, e.length), r = 1, i = 0;
	for (let t = 0; t < n; t += 1) e[t] === "\n" && (r += 1, i = t + 1);
	return {
		line: r,
		column: t - i + 1
	};
}
function ne(e, t, n, r) {
	let i = ee(n, r), { line: a, column: o } = te(r, i.start);
	return {
		code: e,
		message: p(t),
		severity: "warning",
		range: i,
		line: a,
		column: o,
		messageKey: t.key,
		...t.params ? { params: t.params } : {}
	};
}
function re(e, t, n, r) {
	let i = (e, t) => ({
		name: g.name,
		diagnostics: [ne(e, t, n, r)]
	}), a = e;
	if (a == null || a === "") return {
		name: g.name,
		diagnostics: []
	};
	if (!d(a)) return i("local.theme.name", u("local.theme.name", {
		name: String(a),
		limit: 64
	}));
	let o = a;
	if (o === g.name) return {
		name: g.name,
		diagnostics: []
	};
	if (!Array.isArray(t)) return i("local.theme.missing", u("local.theme.missing", { name: o }));
	let s = 0, c = null;
	try {
		for (let e of t) typeof e == "object" && e && !Array.isArray(e) && e.name === o && (s += 1, c = e);
	} catch {
		return i("local.theme.manifest", u("local.theme.manifest.unreadable"));
	}
	if (s === 0) return i("local.theme.missing", u("local.theme.missing", { name: o }));
	if (s > 1) return i("local.theme.duplicate", u("local.theme.duplicate", { name: o }));
	try {
		let e = c;
		if (!e || typeof e != "object") return i("local.theme.manifest", u("local.theme.manifest.definition", { name: o }));
		if (e.protocol !== "reactive-md-theme-1") return i("local.theme.protocol", u("local.theme.protocol", {
			name: o,
			protocol: h
		}));
		let t = e.colorSchemes;
		if (!Array.isArray(t) || !t.includes("light") || !t.includes("dark")) return i("local.theme.modes", u("local.theme.modes", { name: o }));
	} catch {
		return i("local.theme.manifest", u("local.theme.manifest.selected", { name: o }));
	}
	return {
		name: o,
		diagnostics: []
	};
}
// src/sdk/theme.ts
var _ = 128, v = 32, y = 128, b = 262144, x = 524288, ie = /^[a-z][a-z0-9]*(?:[-./][a-z0-9]+)*$/, ae = /^[a-z][a-z0-9._/-]*$/, oe = /^\d+\.\d+\.\d+(?:[-+][0-9A-Za-z.-]+)?$/, S = /^\[\s*data-rmd-theme\s*=\s*(?:"[^"]*"|'[^']*'|[^\]]*?)\s*\]/, se = /^(?::root|html|body)(?![A-Za-z0-9_-])/i, ce = /* @__PURE__ */ new Set([
	"media",
	"supports",
	"layer",
	"container",
	"scope",
	"starting-style"
]);
function C(e, t) {
	return /* @__PURE__ */ Error(`Invalid local theme ${e}: ${t}`);
}
function w(e) {
	return typeof e == "object" && !!e && !Array.isArray(e);
}
function T(e, t) {
	if (!w(e)) throw C(t, "must be an object.");
	return e;
}
function E(e, t) {
	if (typeof e != "string" || e.length === 0) throw C(t, "must be a non-empty string.");
	if (e.length > _) throw C(t, `must not exceed ${_} characters.`);
	if (!ie.test(e)) throw C(t, `"${e}" must be lowercase, start with a letter and use "-", "." or "/" only as separators.`);
	return e;
}
function D(e, t) {
	if (!d(e)) throw C(t, "must be a lowercase kebab-case name that starts with a letter.");
	if (e === "default") throw C(t, "must not replace the reserved built-in \"default\" theme.");
	return e;
}
function O(e, t) {
	if (typeof e != "string" || !oe.test(e)) throw C(t, "must be a semantic version such as \"1.0.0\".");
	return e;
}
function k(e, t) {
	if (e === void 0) return Object.freeze(["light", "dark"]);
	if (!Array.isArray(e)) throw C(t, "must be an array of \"light\" and \"dark\".");
	let n = [];
	for (let r of e) {
		if (r !== "light" && r !== "dark") throw C(t, "may only contain \"light\" and \"dark\".");
		if (n.includes(r)) throw C(t, `must not repeat "${r}".`);
		n.push(r);
	}
	if (!n.includes("light") || !n.includes("dark")) throw C(t, "must declare both \"light\" and \"dark\".");
	return Object.freeze(n);
}
function A(e, t) {
	let n = e[t], r = t + 1;
	for (; r < e.length;) if (e[r] === "\\") r += 2;
	else {
		if (e[r] === n) return r + 1;
		r += 1;
	}
	return e.length;
}
function j(e, t, n, r) {
	let i = 0;
	for (let a = t; a < e.length; a += 1) {
		let t = e[a];
		if (t === "\"" || t === "'") a = A(e, a) - 1;
		else if (t === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === n) i += 1;
		else if (t === r && (--i, i === 0)) return a + 1;
	}
	return e.length;
}
function le(e, t, n) {
	let r = t + 3;
	for (; r < e.length && /\s/.test(e[r]);) r += 1;
	if (e[r] !== "(") throw C(n, "has a malformed url() value.");
	for (r += 1; r < e.length && /\s/.test(e[r]);) r += 1;
	let i = e[r];
	if (i === "\"" || i === "'") {
		let t = e.indexOf(i, r + 1);
		if (t < 0) throw C(n, "has an unterminated url() string.");
		let a = e.slice(r + 1, t);
		for (r = t + 1; r < e.length && /\s/.test(e[r]);) r += 1;
		if (e[r] !== ")") throw C(n, "has a malformed url() value.");
		return {
			value: a.trim(),
			end: r + 1
		};
	}
	let a = e.indexOf(")", r);
	if (a < 0) throw C(n, "has an unterminated url() value.");
	return {
		value: e.slice(r, a).trim(),
		end: a + 1
	};
}
function ue(e, t, n, r) {
	let i = t;
	for (; i < e.length && e[i] !== "(";) i += 1;
	if (i >= e.length) throw C(r, `has a malformed ${n}() value.`);
	let a = j(e, i, "(", ")");
	if (a <= i + 1 || e[a - 1] !== ")") throw C(r, `has an unterminated ${n}() value.`);
	return {
		body: e.slice(i + 1, a - 1),
		end: a
	};
}
function de(e, t) {
	let n = 0;
	for (; n < e.length;) {
		let r = e[n];
		if (r === "\"" || r === "'") {
			let i = A(e, n);
			if (i > e.length || e[i - 1] !== r) throw C(t, "has an unterminated image-set() string.");
			let a = e.slice(n + 1, i - 1).trim();
			if (!/^data:/i.test(a)) throw C(t, "image-set() entries must be inline data: URLs; network and file URLs are not allowed.");
			n = i;
		} else if (r === "/" && e[n + 1] === "*") {
			let t = e.indexOf("*/", n + 2);
			n = t < 0 ? e.length : t + 2;
		} else n += 1;
	}
}
function M(e, t, n = !1) {
	if (e.toLowerCase().includes("</style")) throw C(t, "must not contain a closing style tag.");
	let r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "\"" || i === "'") r = A(e, r);
		else if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = t < 0 ? e.length : t + 2;
		} else {
			if (i === "\\") throw C(t, "must not use CSS escapes outside strings; escaped tokens can disguise url() or @import.");
			if (i === "@" && /^@import\b/i.test(e.slice(r, r + 8))) throw C(t, "must not use @import; inline every resource.");
			if ((i === "i" || i === "I" || i === "-") && /^(?:-webkit-)?image-set\s*\(/i.test(e.slice(r, r + 24))) {
				let { body: n } = ue(e, r, "image-set", t);
				de(n, t), r += 1;
			} else if ((i === "u" || i === "U") && /^url\s*\(/i.test(e.slice(r, r + 12))) {
				let i = le(e, r, t);
				if (!/^data:/i.test(i.value) && !(n && i.value.startsWith("#"))) throw C(t, "may only reference data: URLs; network and file URLs are not allowed.");
				r = i.end;
			} else {
				if ((i === "e" || i === "E") && /^expression\s*\(/i.test(e.slice(r, r + 16))) throw C(t, "must not use CSS expression().");
				r += 1;
			}
		}
	}
}
function fe(e) {
	if (typeof e != "string" || e.length > 4194304) return !1;
	try {
		return M(e, "css", !0), !0;
	} catch {
		return !1;
	}
}
function N(e) {
	let t = [], n = 0, r = 0, i = 0;
	for (let a = 0; a < e.length; a += 1) {
		let o = e[a];
		if (o === "\"" || o === "'") a = A(e, a) - 1;
		else if (o === "/" && e[a + 1] === "*") {
			let t = e.indexOf("*/", a + 2);
			a = (t < 0 ? e.length : t + 2) - 1;
		} else o === "\\" ? a += 1 : o === "(" ? r += 1 : o === ")" ? r = Math.max(0, r - 1) : o === "[" ? i += 1 : o === "]" ? i = Math.max(0, i - 1) : o === "," && r === 0 && i === 0 && (t.push(e.slice(n, a)), n = a + 1);
	}
	return t.push(e.slice(n)), t;
}
function pe(e, t) {
	let n = e.trim(), r = `[data-rmd-theme="${t}"]`, i = S.exec(n);
	return i ? `${r}${n.slice(i[0].length)}` : `${r} ${n}`;
}
function me(e, t) {
	let n = t;
	for (; n < e.length;) if (/\s/.test(e[n])) n += 1;
	else if (e[n] === "/" && e[n + 1] === "*") {
		let t = e.indexOf("*/", n + 2);
		n = t < 0 ? e.length : t + 2;
	} else break;
	return n;
}
function he(e, t) {
	let n = e.toLowerCase(), r = /:has\s*\(/g;
	for (let i = r.exec(n); i; i = r.exec(n)) {
		if (r.lastIndex = i.index + 1, i.index >= t) continue;
		let n = i.index + i[0].length - 1, a = j(e, n, "(", ")"), o = e.slice(n + 1, Math.max(n + 1, a - 1));
		for (let t of N(o)) if (/^\s*[+~]/.test(t)) throw C("theme.css", `selector "${e.trim()}" uses :has() with a sibling combinator that can escape the theme root.`);
	}
}
function ge(e) {
	let t = e.trim();
	if (t === "") return;
	if (t[0] === "+" || t[0] === "~") throw C("theme.css", `selector "${t}" begins with a sibling combinator and cannot be scoped.`);
	let n = S.exec(t);
	if (n) {
		let e = n[0].length;
		for (; e < t.length;) {
			let n = t[e];
			if (/\s/.test(n) || n === "+" || n === "~" || n === ">" || n === ",") break;
			n === "[" ? e = j(t, e, "[", "]") : n === "(" ? e = j(t, e, "(", ")") : e += 1;
		}
		let r = me(t, e);
		if (t[r] === "+" || t[r] === "~") throw C("theme.css", `selector "${t}" uses a sibling combinator that can escape the theme root.`);
		he(t, e);
	}
}
function P(e, t) {
	let n = N(e).map((e) => e.trim()).filter(Boolean);
	if (n.length === 0) return e.trim();
	for (let e of n) {
		if (se.test(e)) throw C("theme.css", `selector "${e}" targets the host document; scope it under the theme root instead.`);
		ge(e);
	}
	return n.map((e) => pe(e, t)).join(", ");
}
function F(e, t) {
	let n = 1;
	for (let r = t; r < e.length; r += 1) {
		let t = e[r];
		if (t === "\"" || t === "'") r = A(e, r) - 1;
		else if (t === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2);
			r = (t < 0 ? e.length : t + 2) - 1;
		} else if (t === "{") n += 1;
		else if (t === "}" && (--n, n === 0)) return r;
	}
	return e.length;
}
function I(e, t) {
	let n = "", r = 0;
	for (; r < e.length;) {
		let i = e[r];
		if (i === "/" && e[r + 1] === "*") {
			let t = e.indexOf("*/", r + 2), i = t < 0 ? e.length : t + 2;
			n += e.slice(r, i), r = i;
			continue;
		}
		if (/\s/.test(i) || i === ";" || i === "}") {
			n += i, r += 1;
			continue;
		}
		let a = r, o = r;
		for (; o < e.length;) {
			let t = e[o];
			if (t === "\"" || t === "'") o = A(e, o);
			else if (t === "/" && e[o + 1] === "*") {
				let t = e.indexOf("*/", o + 2);
				o = t < 0 ? e.length : t + 2;
			} else if (t === "(") o = j(e, o, "(", ")");
			else if (t === "[") o = j(e, o, "[", "]");
			else {
				if (t === "{" || t === ";" || t === "}") break;
				o += 1;
			}
		}
		if (o >= e.length) {
			n += e.slice(a);
			break;
		}
		let s = e.slice(a, o), c = e[o];
		if (c === ";" || c === "}") {
			n += s + c, r = o + 1;
			continue;
		}
		let l = F(e, o + 1), u = e.slice(o + 1, l), d = s.trim();
		if (d.startsWith("@")) {
			let e = (/^@([A-Za-z-]+)/.exec(d)?.[1] ?? "").toLowerCase();
			if (e === "import") throw C("theme.css", "must not use @import.");
			if (e === "font-face" || e === "keyframes" || e.endsWith("-keyframes")) throw C("theme.css", `@${e} declares a global name; phase one only supports document-scoped CSS.`);
			let r = ce.has(e) ? I(u, t) : u;
			n += `${d} {${r}}`;
		} else n += `${P(d, t)} {${u}}`;
		r = Math.min(l + 1, e.length);
	}
	return n;
}
function L(e, t) {
	return I(e, t);
}
function R(e, t, n) {
	if (!Array.isArray(e)) throw C(t, "must be an array of { id, css } resources.");
	if (e.length > v) throw C(t, `may contain at most ${v} resources.`);
	let r = /* @__PURE__ */ new Set(), i = [], a = 0;
	for (let o = 0; o < e.length; o += 1) {
		let s = e[o], c = `${t}[${o}]`;
		if (!w(s)) throw C(c, "must be an object.");
		let l = s.id;
		if (typeof l != "string" || l.length === 0) throw C(`${c}.id`, "must be a non-empty string.");
		if (l.length > y) throw C(`${c}.id`, `must not exceed ${y} characters.`);
		if (!ae.test(l)) throw C(`${c}.id`, `"${l}" must start with a letter and use letters, digits, ".", "_", "-" or "/".`);
		if (r.has(l)) throw C(`${c}.id`, `"${l}" is declared more than once.`);
		r.add(l);
		let u = s.css;
		if (typeof u != "string") throw C(`${c}.css`, "must be a string.");
		if (u.length > b) throw C(`${c}.css`, `must not exceed ${b} characters.`);
		if (a += u.length, a > x) throw C(t, `must not exceed ${x} characters in total.`);
		M(u, `${c}.css`), i.push(Object.freeze({
			id: l,
			css: n === null ? u : L(u, n)
		}));
	}
	return {
		resources: Object.freeze(i),
		totalLength: a
	};
}
function z(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		version: e.version,
		protocol: e.protocol,
		colorSchemes: Object.freeze([...e.colorSchemes]),
		css: Object.freeze(e.css.map((e) => Object.freeze({
			id: e.id,
			css: e.css
		})))
	});
}
function _e(e, t) {
	let n = T(e, t), r = E(n.id, `${t}.id`), i = D(n.name, `${t}.name`), a = O(n.version, `${t}.version`);
	if (n.protocol !== "reactive-md-theme-1") throw C(`${t}.protocol`, `must be "${h}".`);
	let o = k(n.colorSchemes, `${t}.colorSchemes`), { resources: s } = R(n.css, `${t}.css`, null);
	return z({
		id: r,
		name: i,
		version: a,
		protocol: h,
		colorSchemes: o,
		css: s
	});
}
function B(e) {
	let t = T(e, "input"), n = E(t.id, "theme.id"), r = D(t.name, "theme.name"), i = O(t.version, "theme.version");
	if ((t.protocol === void 0 ? "reactive-md-theme-1" : t.protocol) !== "reactive-md-theme-1") throw C("theme.protocol", `must be "${h}".`);
	let a = k(t.colorSchemes, "theme.colorSchemes"), { resources: o } = R(t.css, "theme.css", r);
	return z({
		id: n,
		name: r,
		version: i,
		protocol: h,
		colorSchemes: a,
		css: o
	});
}
function ve(e) {
	let t = T(e, "input"), n = E(t.id, "theme.id"), r = D(t.name, "theme.name"), i = O(t.version, "theme.version"), a = _e(t.base, "theme.base"), o = R(t.overrides, "theme.overrides", r), s = new Set(a.css.map((e) => e.id));
	for (let e of o.resources) {
		if (s.has(e.id)) throw C("theme.overrides", `resource "${e.id}" is already declared by the base theme.`);
		s.add(e.id);
	}
	let c = [...a.css.map((e) => Object.freeze({
		id: e.id,
		css: L(e.css, r)
	})), ...o.resources], l = 0;
	for (let e of c) if (l += e.css.length, l > x) throw C("theme.css", `must not exceed ${x} characters in total.`);
	return z({
		id: n,
		name: r,
		version: i,
		protocol: a.protocol,
		colorSchemes: a.colorSchemes,
		css: c
	});
}
function ye(e) {
	let { resources: t } = R(T(e, "theme").css, "theme.css", null);
	return t.map((e) => e.css).join("\n");
}
// src/sdk/config.ts
var V = m.id, H = m.version, be = 16, U = 16777216, xe = /* @__PURE__ */ new Set([
	"__proto__",
	"constructor",
	"prototype"
]), Se = /* @__PURE__ */ new Set([
	"protocol",
	"key",
	"presets",
	"components",
	"registry",
	"themes"
]), Ce = /* @__PURE__ */ new Set([
	"presets",
	"components",
	"themes"
]), we = /* @__PURE__ */ new Set([
	"id",
	"name",
	"version",
	"protocol",
	"colorSchemes",
	"css"
]), W = /* @__PURE__ */ new WeakSet();
function G(e, t) {
	throw Error(`Invalid local SDK config (${e}): ${t}`);
}
function K(e) {
	if (typeof e != "object" || !e || Array.isArray(e)) return !1;
	let t = Object.getPrototypeOf(e);
	return t === Object.prototype || t === null;
}
function q(e, t, n) {
	for (let r of Object.keys(e)) xe.has(r) && G(n, `field "${r}" is not allowed.`), t.has(r) || G(n, `unknown field "${r}".`);
}
function Te(e) {
	K(e) || G("themes", "each theme must be an object."), q(e, we, "theme");
	try {
		return B(e);
	} catch (e) {
		G("theme", e instanceof Error ? e.message : String(e));
	}
}
function Ee() {
	return Object.freeze([Object.freeze({
		id: V,
		version: H
	})]);
}
function De(e) {
	if (e === void 0) return Ee();
	Array.isArray(e) || G("presets", "must be an array."), e.length === 0 && G("presets", "must select at least the default preset.");
	let t = /* @__PURE__ */ new Set(), n = [];
	for (let r = 0; r < e.length; r += 1) {
		let i = e[r], a, o;
		typeof i == "string" ? a = i : K(i) ? ((i.id === void 0 || typeof i.id != "string") && G(`presets[${r}].id`, "must be a string."), a = i.id, i.version !== void 0 && (typeof i.version != "string" && G(`presets[${r}].version`, "must be a string."), o = i.version)) : G(`presets[${r}]`, "must be a preset id or preset reference."), (a === "default" ? V : a) !== V && G(`presets[${r}]`, `unsupported preset "${a}"; phase one accepts only "${V}".`), o !== void 0 && o !== H && G(`presets[${r}].version`, `must be "${H}".`), t.has(V) && G("presets", `"${V}" is selected more than once.`), t.add(V), n.push(Object.freeze({
			id: V,
			version: H
		}));
	}
	return Object.freeze(n);
}
function Oe() {
	let e = /* @__PURE__ */ new Set();
	for (let t of m.components) e.add(t.name), e.add(t.id);
	return e;
}
function ke(e) {
	let t = new Map(e.map((e) => [e.id, e])), n = Oe();
	for (let r of e) {
		let e = r.requires?.kernel;
		e !== void 0 && !o("0.7.0", e) && G("requires", `component "${r.id}" requires kernel ${e}, but ${a} is installed.`);
		for (let e of r.dependencies ?? []) {
			let i = t.get(e.id)?.version ?? (n.has(e.id) ? "0.7.0" : null);
			i === null && G("dependencies", `component "${r.id}" requires missing component "${e.id}".`), e.version !== void 0 && !o(i, e.version) && G("dependencies", `component "${r.id}" requires "${e.id}" ${e.version}, but version ${i} is installed.`);
		}
	}
	let r = /* @__PURE__ */ new Map(), i = (e, n) => {
		let a = r.get(e);
		if (a === "done") return;
		a === "visiting" && G("dependencies", `dependency cycle: ${[...n, e].join(" -> ")}.`), r.set(e, "visiting");
		let o = t.get(e);
		for (let r of o?.dependencies ?? []) t.has(r.id) && i(r.id, [...n, e]);
		r.set(e, "done");
	};
	for (let e of t.keys()) i(e, []);
}
function Ae(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || G("components", "must be an array."), e.length > 64 && G("components", "accepts at most 64 external components.");
	let t = new Set([
		...s,
		"computed",
		"const",
		"external",
		...l
	].map((e) => e.toLowerCase()));
	t.add("theme");
	let n = new Set(m.components.map((e) => e.id)), r = /* @__PURE__ */ new Set(), a = [];
	for (let o = 0; o < e.length; o += 1) {
		let s = i(e[o]);
		t.has(s.name.toLowerCase()) && G(`components[${o}]`, `name "${s.name}" conflicts with a built-in component, HTML tag or theme declaration.`), n.has(s.id) && G("components", `component id "${s.id}" is declared more than once.`), r.has(s.name) && G("components", `component name "${s.name}" is declared more than once.`), n.add(s.id), r.add(s.name), a.push(s);
	}
	return ke(a), Object.freeze(a);
}
function je(e) {
	if (e === void 0) return Object.freeze([]);
	Array.isArray(e) || G("themes", "must be an array."), e.length > 16 && G("themes", "accepts at most 16 themes.");
	let t = /* @__PURE__ */ new Set(), n = /* @__PURE__ */ new Set(), r = [];
	for (let i of e) {
		let e = Te(i);
		t.has(e.id) && G("themes", `theme id "${e.id}" is declared more than once.`), n.has(e.name) && G("themes", `theme name "${e.name}" is declared more than once.`), t.add(e.id), n.add(e.name), r.push(e);
	}
	return Object.freeze(r);
}
function Me(e) {
	return [...e].map((e) => ({
		id: e.id,
		version: e.version
	})).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id));
}
function J(r, i) {
	let a = JSON.stringify({
		protocol: t,
		presets: Me(r),
		components: [...i].map((t) => ({
			id: t.id,
			version: t.version,
			digest: e(t)
		})).sort((e, t) => e.id < t.id ? -1 : +(e.id > t.id))
	});
	return n(a);
}
function Y(e, n) {
	K(e) || G(n, "must be an object."), q(e, Ce, n);
	let i = De(e.presets), a = Ae(e.components), o = je(e.themes);
	r({
		protocol: "reactive-md-config/v1",
		presets: i,
		components: a,
		themes: o
	}) > 16777216 && G(n, `serialized size exceeds the ${U}-byte budget.`);
	let s = Object.freeze({
		protocol: t,
		key: J(i, a),
		presets: i,
		components: a,
		registry: Object.freeze([...m.components, ...a]),
		themes: o
	});
	return W.add(s), s;
}
function X(e = {}) {
	return Y(e, "config");
}
var Ne;
function Z(e) {
	return e === void 0 ? Ne ??= X().key : Q(e).key;
}
function Pe(e, t) {
	return e.componentConfigKey === void 0 || e.componentConfigKey === Z(t) ? [] : [{
		code: "local.extension.config-mismatch",
		severity: "error",
		message: "The document compiler configuration differs from the installed renderer. Recompile with the same host.config used by host.reactConfig (including Worker requests).",
		range: {
			start: 0,
			end: 0
		},
		line: 1,
		column: 1
	}];
}
function Q(e) {
	return typeof e == "object" && e && W.has(e) ? e : (K(e) || G("config", "must be an object."), q(e, Se, "config"), e.protocol !== "reactive-md-config/v1" && G("config.protocol", `must be "${t}".`), Y({
		presets: e.presets,
		components: e.components,
		themes: e.themes
	}, "config"));
}
function Fe(e) {
	if (typeof e == "object" && e && W.has(e)) return e.key;
	try {
		return Q(e).key;
	} catch {
		try {
			return `invalid:${n(JSON.stringify(e))}`;
		} catch {
			return "invalid";
		}
	}
}
function Ie(e) {
	try {
		return Q(e);
	} catch {
		return e;
	}
}
// src/sdk/registry.ts
function Le() {
	return c;
}
function $(e) {
	return e ? Q(e).registry : Le();
}
function Re(e, t) {
	let n = $(t);
	for (let t of n) if (t.name === e) return t;
}
function ze(e) {
	let t = /* @__PURE__ */ new Map();
	for (let n of $(e)) t.set(n.name, f(n));
	return t;
}
export { fe as _, H as a, re as b, X as c, Q as d, Ie as f, B as g, ve as h, V as i, Z as l, ye as m, $ as n, U as o, Pe as p, ze as r, be as s, Re as t, Fe as u, g as v, h as y };
