import { n as e } from "./compiler-core-Fk6_fRXo.js";
// src/compiler/result.ts
var t = Object.freeze({ optional: Object.freeze([]) }), n = Object.freeze({ optional: Object.freeze([Object.freeze({
	id: "math-display",
	version: "1"
})]) });
function r(e) {
	let t = /* @__PURE__ */ new Set(), n = [e];
	for (; n.length > 0;) {
		let e = n.pop();
		if (typeof e != "object" || !e) continue;
		let r = e;
		if (!t.has(r)) {
			if (t.add(r), Object.freeze(r), Array.isArray(r)) for (let e = 0; e < r.length; e += 1) n.push(r[e]);
			else for (let e of Object.keys(r)) n.push(r[e]);
		}
	}
	return e;
}
function i(t) {
	return t ? e([...t]) : [];
}
function a(t, n) {
	let a = e(t), o = i(a.recoveries);
	if (!a.ok) return {
		ok: !1,
		status: "failed",
		diagnostics: a.diagnostics,
		recoveries: o
	};
	let s = a.document, c = r(e(s));
	return {
		ok: !0,
		status: o.length > 0 ? "recovered" : "valid",
		document: s,
		program: c,
		diagnostics: a.diagnostics,
		recoveries: o,
		checks: n
	};
}
// src/compiler/types.ts
var o = class extends Error {
	code;
	detail;
	constructor(e, t = {}) {
		super(e), this.name = "CompilerConfigurationError", this.code = t.code ?? "compiler.configuration", t.detail !== void 0 && (this.detail = t.detail);
	}
};
export { a as i, t as n, n as r, o as t };
