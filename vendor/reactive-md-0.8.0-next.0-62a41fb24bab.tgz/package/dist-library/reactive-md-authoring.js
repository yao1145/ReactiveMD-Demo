import { et as e, g as t } from "./html-DgECD9QC.js";
import { a as n, c as r, i, l as a, o, r as s, s as c } from "./default-components-qRt0E8bl.js";
import { t as l } from "./registry-core-BIJfeW7H.js";
import { d as u } from "./registry-DaHST1VN.js";
import { n as d, t as f } from "./options-Dre16Jby.js";
import { t as p } from "./compiler-C7S3EzsO.js";
import { a as m, c as h, i as ee, n as g, o as _, r as v, s as te, t as y } from "./schema-D8pyY5P9.js";
import { i as ne, n as re, r as ie, t as b } from "./authoring-D1tfQSeM.js";
// src/authoring/editor-i18n.ts
var x = {
	en: {
		boldPlaceholder: "bold text",
		italicPlaceholder: "italic text",
		strikePlaceholder: "strikethrough text",
		inlineCodePlaceholder: "code",
		linkText: "link text",
		imageAlt: "example image",
		codeBlockPlaceholder: "Write code here",
		tableHeaders: [
			"Column 1",
			"Column 2",
			"Column 3"
		],
		tableRows: [[
			"Example 1",
			"Example 2",
			"Example 3"
		], [
			"Example 4",
			"Example 5",
			"Example 6"
		]]
	},
	zh: {
		boldPlaceholder: "粗体文字",
		italicPlaceholder: "斜体文字",
		strikePlaceholder: "删除线文字",
		inlineCodePlaceholder: "代码",
		linkText: "链接文字",
		imageAlt: "示意图",
		codeBlockPlaceholder: "在这里写代码",
		tableHeaders: [
			"列 1",
			"列 2",
			"列 3"
		],
		tableRows: [[
			"示例 1",
			"示例 2",
			"示例 3"
		], [
			"示例 4",
			"示例 5",
			"示例 6"
		]]
	}
};
// src/authoring/editor-commands.ts
function ae(e, t) {
	return typeof e != "number" || Number.isNaN(e) ? 0 : Math.min(Math.max(Math.trunc(e), 0), t);
}
function S(e, t) {
	let n = ae(t.start, e.length), r = ae(t.end, e.length);
	return n <= r ? {
		start: n,
		end: r
	} : {
		start: r,
		end: n
	};
}
function C(e) {
	return x[e] ?? x.en;
}
function w(e, t) {
	return t <= 0 ? 0 : e.lastIndexOf("\n", t - 1) + 1;
}
function T(e, t) {
	let n = w(e, t.start), r = t.end > t.start && e[t.end - 1] === "\n" ? t.end - 1 : t.end, i = e.indexOf("\n", r), a = i === -1 ? e.length : i, o = [], s = n;
	for (;;) {
		let t = e.indexOf("\n", s), n = t === -1 || t > a ? a : t;
		if (o.push({
			start: s,
			end: n,
			text: e.slice(s, n)
		}), n >= a) break;
		s = n + 1;
	}
	return o;
}
function E(e, t, n) {
	if (n.length === 0) return {
		value: e,
		selection: t
	};
	let r = [...n].sort((e, t) => e.start - t.start), i = 0, a = r.map((e) => {
		let t = e.start + i, n = i;
		return i += e.text.length - (e.end - e.start), {
			edit: e,
			newStart: t,
			deltaBefore: n
		};
	}), o = "", s = 0;
	for (let t of a) o += e.slice(s, t.edit.start), o += t.edit.text, s = t.edit.end;
	o += e.slice(s);
	let c = (e) => {
		for (let t of a) {
			let { edit: n, newStart: r, deltaBefore: i } = t;
			if (e < n.start) return e + i;
			if (e <= n.end) {
				let t = e - n.start, i = t <= n.oldPrefixLength ? n.newPrefixLength : t + (n.newPrefixLength - n.oldPrefixLength);
				return r + Math.min(Math.max(i, 0), n.text.length);
			}
		}
		return e + i;
	};
	return {
		value: o,
		selection: {
			start: c(t.start),
			end: c(t.end)
		}
	};
}
function D(e, t, n, r) {
	return t === e.text ? null : {
		start: e.start,
		end: e.end,
		text: t,
		oldPrefixLength: n,
		newPrefixLength: r
	};
}
function oe(e, t, n, r) {
	return n === "*" ? r ? e[t.start - 1] !== "*" && e[t.end] !== "*" : e[t.start - n.length - 1] !== "*" && e[t.end + n.length] !== "*" : !0;
}
function O(e, t, n, r) {
	let i = S(e, t), a = n.length, { start: o, end: s } = i, c = e.slice(o, s);
	if (o !== s) {
		if (c.length >= a * 2 && c.startsWith(n) && c.endsWith(n) && (n !== "*" || !c.startsWith("**") && !c.endsWith("**")) && oe(e, i, n, !0)) {
			let t = c.slice(a, c.length - a);
			return {
				value: e.slice(0, o) + t + e.slice(s),
				selection: {
					start: o,
					end: o + t.length
				}
			};
		}
		let t = o - a, r = s + a;
		return t >= 0 && r <= e.length && e.slice(t, o) === n && e.slice(s, r) === n && oe(e, i, n, !1) ? {
			value: e.slice(0, t) + c + e.slice(r),
			selection: {
				start: t,
				end: t + c.length
			}
		} : {
			value: e.slice(0, o) + n + c + n + e.slice(s),
			selection: {
				start: o + a,
				end: s + a
			}
		};
	}
	let l = n + r + n;
	return {
		value: e.slice(0, o) + l + e.slice(s),
		selection: {
			start: o + a,
			end: o + a + r.length
		}
	};
}
function se(e, t, n = "en") {
	return O(e, t, "**", C(n).boldPlaceholder);
}
function ce(e, t, n = "en") {
	return O(e, t, "*", C(n).italicPlaceholder);
}
function le(e, t, n = "en") {
	return O(e, t, "~~", C(n).strikePlaceholder);
}
function k(e) {
	let t = 0;
	for (let n of e.match(/`+/g) ?? []) t = Math.max(t, n.length);
	return t;
}
function A(e, t, n) {
	let r = 0;
	for (; e[t] === "`";) r += 1, t += n;
	return r;
}
function ue(e, t) {
	let { start: n, end: r } = t, i = e.slice(n, r), a = A(e, n - 1, -1), o = A(e, r, 1), s = a > 0 && a === o ? {
		run: a,
		padding: 0
	} : null, c = A(e, n - 2, -1), l = A(e, r + 1, 1), u = e[n - 1] === " " && e[r] === " " && c > 0 && c === l ? {
		run: c,
		padding: 1
	} : null, d = s ?? u;
	return !d || k(i) >= d.run ? null : d;
}
function de(e, t, n = "en") {
	let r = S(e, t), { start: i, end: a } = r, o = e.slice(i, a);
	if (i === a) {
		let t = C(n).inlineCodePlaceholder, r = `\`${t}\``;
		return {
			value: e.slice(0, i) + r + e.slice(a),
			selection: {
				start: i + 1,
				end: i + 1 + t.length
			}
		};
	}
	let s = A(o, 0, 1), c = A(o, o.length - 1, -1);
	if (s > 0 && s === c && o.length >= s * 2 && k(o.slice(s, o.length - s)) < s) {
		let t = o.slice(s, o.length - s);
		return t.startsWith(" ") && t.endsWith(" ") && t.trim().length > 0 && (t = t.slice(1, -1)), {
			value: e.slice(0, i) + t + e.slice(a),
			selection: {
				start: i,
				end: i + t.length
			}
		};
	}
	let l = ue(e, r);
	if (l) {
		let t = l.run + l.padding;
		return {
			value: e.slice(0, i - t) + o + e.slice(a + t),
			selection: {
				start: i - t,
				end: i - t + o.length
			}
		};
	}
	let u = "`".repeat(k(o) + 1), d = /^[` ]|[` ]$/.test(o) ? " " : "", f = u + d;
	return {
		value: e.slice(0, i) + f + o + d + u + e.slice(a),
		selection: {
			start: i + f.length,
			end: i + f.length + o.length
		}
	};
}
var j = /^(#{1,6})[ \t]+/;
function fe(e, t, n) {
	let r = S(e, t), i = [];
	for (let t of T(e, r)) {
		let e = j.exec(t.text), r = e ? e[0].length : 0;
		if (n === 0 && !e) continue;
		let a = t.text.slice(r), o = n === 0 ? "" : `${"#".repeat(n)} `, s = D(t, o + a, r, o.length);
		s && i.push(s);
	}
	return E(e, r, i);
}
var M = /^([ \t]*)([-*+] )/, N = /^([ \t]*)(\d+[.)] )/, P = /^([ \t]*)([-*+] \[[ xX]\] )/, F = /^([ \t]*)(> ?)/;
function I(e, t) {
	let n = t.exec(e);
	if (!n) return null;
	let r = n[1] ?? "", i = n[2] ?? "";
	return {
		indent: r,
		prefix: i,
		prefixLength: r.length + i.length
	};
}
function pe(e) {
	let t = /^[ \t]*/.exec(e);
	return t ? t[0] : "";
}
function L(e, t, n, r) {
	let i = S(e, t), a = T(e, i), o = a.map((e) => n(e.text)), s = 0, c = !0;
	for (let e = 0; e < a.length; e += 1) {
		let t = a[e];
		(o[e] || t.text.trim().length > 0) && (s += 1, o[e] || (c = !1));
	}
	let l = s > 0 && c, u = [];
	for (let e = 0; e < a.length; e += 1) {
		let t = a[e], n = o[e] ?? null;
		if (l) {
			if (!n) continue;
			let e = D(t, n.indent + t.text.slice(n.prefixLength), n.prefixLength, n.indent.length);
			e && u.push(e);
			continue;
		}
		let i = n ? n.indent : pe(t.text), s = t.text.slice(n ? n.prefixLength : i.length), c = r(i, e + 1), d = D(t, i + c + s, n ? n.prefixLength : i.length, i.length + c.length);
		d && u.push(d);
	}
	return E(e, i, u);
}
function me(e, t) {
	return L(e, t, (e) => I(e, M), () => "- ");
}
function he(e, t) {
	return L(e, t, (e) => I(e, N), (e, t) => `${t}. `);
}
function ge(e, t) {
	return L(e, t, (e) => I(e, P), () => "- [ ] ");
}
function _e(e, t) {
	return L(e, t, (e) => I(e, F), () => "> ");
}
function ve(e, t) {
	let n = S(e, t);
	return E(e, n, T(e, n).map((e) => ({
		start: e.start,
		end: e.end,
		text: `  ${e.text}`,
		oldPrefixLength: 0,
		newPrefixLength: 2
	})));
}
function ye(e) {
	if (e.startsWith("	")) return {
		text: e.slice(1),
		removed: 1
	};
	let t = 0;
	for (; t < 2 && e[t] === " ";) t += 1;
	return {
		text: e.slice(t),
		removed: t
	};
}
function be(e, t) {
	let n = S(e, t), r = [];
	for (let t of T(e, n)) {
		let e = ye(t.text);
		if (e.removed === 0) continue;
		let n = D(t, e.text, e.removed, 0);
		n && r.push(n);
	}
	return E(e, n, r);
}
function xe(e, t, n = "en") {
	let { start: r, end: i } = S(e, t), a = e.slice(r, i), o = "https://example.com";
	if (a.length > 0) {
		let t = `[${a}](${o})`, n = r + 1 + a.length + 2;
		return {
			value: e.slice(0, r) + t + e.slice(i),
			selection: {
				start: n,
				end: n + 19
			}
		};
	}
	let s = C(n).linkText, c = `[${s}](${o})`;
	return {
		value: e.slice(0, r) + c + e.slice(i),
		selection: {
			start: r + 1,
			end: r + 1 + s.length
		}
	};
}
function Se(e, t, n = "en") {
	let { start: r, end: i } = S(e, t), a = e.slice(r, i), o = "images/example.png";
	if (a.length > 0) {
		let t = `![${a}](${o})`, n = r + 2 + a.length + 2;
		return {
			value: e.slice(0, r) + t + e.slice(i),
			selection: {
				start: n,
				end: n + 18
			}
		};
	}
	let s = C(n).imageAlt, c = `![${s}](${o})`;
	return {
		value: e.slice(0, r) + c + e.slice(i),
		selection: {
			start: r + 2,
			end: r + 2 + s.length
		}
	};
}
function Ce(e, t, n = "en") {
	let r = S(e, t), i = e.slice(r.start, r.end), a = i.length > 0 ? i : C(n).codeBlockPlaceholder, o = "`".repeat(Math.max(3, k(a) + 1)), s = `${o}text\n`;
	return R(e, r, `${s}${a}\n${o}`, {
		start: s.length,
		end: s.length + a.length
	});
}
function we(e) {
	return [
		`| ${e.tableHeaders.join(" | ")} |`,
		`| ${e.tableHeaders.map(() => "---").join(" | ")} |`,
		...e.tableRows.map((e) => `| ${e.join(" | ")} |`)
	].join("\n");
}
function Te(e, t) {
	let n = w(e, t.start), r = e.slice(n, t.start), i = e.indexOf("\n", t.end), a = i === -1 ? e.length : i, o = e.slice(t.end, a), s = "";
	if (/\S/.test(r)) s = "\n\n";
	else if (n > 0) {
		let t = w(e, n - 1);
		/\S/.test(e.slice(t, n - 1)) && (s = "\n");
	}
	return {
		prefix: s,
		suffix: /\S/.test(o) ? "\n\n" : ""
	};
}
function R(e, t, n, r) {
	let { prefix: i, suffix: a } = Te(e, t), o = t.start + i.length;
	return {
		value: e.slice(0, t.start) + i + n + a + e.slice(t.end),
		selection: {
			start: o + r.start,
			end: o + r.end
		}
	};
}
function Ee(e, t, n = "en") {
	let r = S(e, t), i = C(n), a = we(i), o = i.tableRows[0][0], s = a.indexOf(o);
	return R(e, r, a, {
		start: s,
		end: s + o.length
	});
}
function De(e, t) {
	return R(e, S(e, t), "---", {
		start: 3,
		end: 3
	});
}
function Oe(e, t, n) {
	let r = S(e, t), i = r.start + n.length;
	return {
		value: e.slice(0, r.start) + n + e.slice(r.end),
		selection: {
			start: i,
			end: i
		}
	};
}
var z = /\{\{(selection(?::[^{}]*)?|caret|select:[^{}]*)\}\}/g;
function ke(e, t) {
	let n = "", r = 0, i = null, a = null, o = null;
	z.lastIndex = 0;
	for (let s = z.exec(e); s; s = z.exec(e)) {
		let c = s.index;
		n += e.slice(r, c), r = c + s[0].length;
		let l = s[1] ?? "";
		if (l === "selection") n += t;
		else if (l.startsWith("selection:")) {
			let e = l.slice(10);
			if (t.length > 0) n += t;
			else {
				let t = n.length;
				n += e, a ||= {
					start: t,
					end: n.length
				};
			}
		} else if (l === "caret") o === null && (o = n.length);
		else if (l.startsWith("select:")) {
			let e = l.slice(7), t = n.length;
			n += e, i ||= {
				start: t,
				end: n.length
			};
		} else n += s[0];
	}
	return n += e.slice(r), {
		text: n,
		select: i,
		fallback: a,
		caret: o
	};
}
function B(e, t, n, r = {}) {
	let i = S(e, t), a = ke(n, e.slice(i.start, i.end)), o = r.block === !0 && a.text.length > 0 ? Te(e, i) : {
		prefix: "",
		suffix: ""
	}, s = i.start + o.prefix.length, c;
	return c = a.select ? {
		start: s + a.select.start,
		end: s + a.select.end
	} : a.fallback ? {
		start: s + a.fallback.start,
		end: s + a.fallback.end
	} : a.caret === null ? {
		start: s + a.text.length,
		end: s + a.text.length
	} : {
		start: s + a.caret,
		end: s + a.caret
	}, {
		value: e.slice(0, i.start) + o.prefix + a.text + o.suffix + e.slice(i.end),
		selection: c
	};
}
function Ae(e, t) {
	let n = [], r = 0;
	for (; r < e.length;) {
		if (e[r] !== t) {
			r += 1;
			continue;
		}
		let i = r;
		for (; e[r] === t;) r += 1;
		n.push({
			start: i,
			end: r,
			length: r - i
		});
	}
	return n;
}
function V(e, t) {
	if (t === "inlineCode") return Ae(e, "`");
	let n = Ae(e, t === "strike" ? "~" : "*");
	return t === "italic" ? n.filter((e) => e.length % 2 == 1) : n.filter((e) => e.length >= 2);
}
function je(e, t, n) {
	return e >= t ? !1 : n.some((r) => r.start === e && n.some((e) => e.end === t && e.length === r.length && e.start >= r.end));
}
function Me(e, t, n) {
	return e >= t ? !1 : n.some((r) => r.end === e && n.some((e) => e.start === t && e.length === r.length && e.start >= r.end));
}
function Ne(e, t) {
	let n = 0;
	for (; n < t.length;) {
		let r = t[n], i = n + 1;
		for (; i < t.length && t[i].length !== r.length;) i += 1;
		let a = t[i];
		if (!a) n += 1;
		else {
			if (e >= r.end && e <= a.start) return !0;
			n = i + 1;
		}
	}
	return !1;
}
function H(e, t, n, r) {
	if (t.start !== t.end) {
		let n = V(e, r);
		return je(t.start, t.end, n) || Me(t.start, t.end, n);
	}
	return Ne(Math.min(Math.max(t.start - n.start, 0), n.text.length), V(n.text, r).filter((e) => e.start >= Pe(n.text)));
}
function Pe(e) {
	let t = 0;
	for (;;) {
		let n = e.slice(t), r = I(n, P) ?? I(n, M) ?? I(n, N) ?? I(n, F);
		if (!r) return t;
		t += r.prefixLength;
	}
}
function Fe(e) {
	return I(e, P) ? "task" : I(e, M) ? "bullet" : I(e, N) ? "ordered" : null;
}
function Ie(e, t) {
	let n = S(e, t), r = T(e, {
		start: n.start,
		end: n.start
	})[0], i = r.text, a = j.exec(i);
	return {
		headingLevel: a ? a[1].length : 0,
		bold: H(e, n, r, "bold"),
		italic: H(e, n, r, "italic"),
		strike: H(e, n, r, "strike"),
		inlineCode: H(e, n, r, "inlineCode"),
		list: Fe(i),
		quote: I(i, F) !== null
	};
}
// src/authoring/native-components.ts
var U = Object.freeze(s.map((e) => ({
	id: e.id,
	label: a(e.title, "en", e.id)
})));
function W(e, t) {
	let r = n[e];
	return {
		id: e,
		label: a(r.title, t, e),
		description: a(r.description, t, e),
		group: r.category,
		keywords: [...c(e) ?? []],
		...r.inline === !0 ? { inline: !0 } : {},
		template: a(r.insertText, t, r.insertText.en ?? "")
	};
}
var G = i.map((e) => W(e, "en")), K = Object.freeze(s.map((e) => ({
	id: e.id,
	label: a(e.title, "zh", e.id)
}))), q = i.map((e) => W(e, "zh")), Le = G.filter((e) => n[e.id]?.extended === !0), Re = Object.freeze(Object.fromEntries(q.filter((e) => n[e.id]?.extended === !0).map((e) => [e.id, Object.freeze({
	label: e.label,
	description: e.description,
	keywords: Object.freeze([...e.keywords]),
	template: e.template
})])));
function ze(e = "en") {
	return e === "zh" ? {
		groups: K,
		components: q
	} : {
		groups: U,
		components: G
	};
}
function Be(e) {
	return new Set(e.match(/[A-Za-z_][A-Za-z0-9_]*/g) ?? []);
}
function Ve(e) {
	let t = e.trim().replace(/[^A-Za-z0-9_]/g, "_");
	return t ? /^[0-9]/.test(t) ? `_${t}` : t : "value";
}
function He(e, t) {
	if (!t.has(e)) return e;
	let n = 2;
	for (; t.has(`${e}${n}`);) n += 1;
	return `${e}${n}`;
}
function J(e, t, n) {
	let r = Be(t), i = /* @__PURE__ */ new Map();
	return e.template.replace(/\{\{bind:([^{}]+)\}\}/g, (e, t) => {
		let n = t.trim(), a = i.get(n);
		if (a) return a;
		let o = He(Ve(n), r);
		return r.add(o), i.set(n, o), o;
	});
}
// src/authoring/templates.ts
function Ue(e) {
	let t = {};
	for (let [n, r] of Object.entries(e.props)) t[n] = {
		kind: r.kind,
		required: r.required === !0,
		...r.enum ? { values: r.enum } : {},
		...r.default === void 0 ? {} : { defaultValue: r.default },
		...r.pattern === void 0 ? {} : { pattern: r.pattern },
		...r.min === void 0 ? {} : { min: r.min },
		...r.max === void 0 ? {} : { max: r.max },
		integer: r.integer === !0,
		color: r.color === !0
	};
	return t;
}
function We(e) {
	return e.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function Ge(e) {
	return e === null ? "" : We(String(e));
}
function Ke(t) {
	let n = t.replace(/[^A-Za-z0-9_]/g, "_"), r = /^[0-9]/.test(n) ? `_${n}` : n;
	return e.has(r) ? `${r}_value` : r;
}
function qe(e, t) {
	if (e.defaultValue !== void 0 && e.defaultValue !== null) return Ge(e.defaultValue);
	switch (e.kind) {
		case "boolean": return "false";
		case "enum":
			if (e.values?.length) return Ge(e.values[0]);
			throw Error(`${t} is a required enum without values; provide an authoring.insertText.`);
		case "number": {
			let n = e.min === void 0 ? void 0 : e.integer ? Math.ceil(e.min) : e.min, r = e.max === void 0 ? void 0 : e.integer ? Math.floor(e.max) : e.max;
			if (n !== void 0 && r !== void 0 && n > r) throw Error(`${t} has no integer inside its declared range; provide an authoring.insertText.`);
			let i = n !== void 0 && n > 0 ? n : r !== void 0 && r < 0 ? r : 0;
			if (n !== void 0 && i < n && (i = n), r !== void 0 && i > r && (i = r), !Number.isFinite(i)) throw Error(`${t} is a required number without a legal finite value; provide an authoring.insertText.`);
			return String(i);
		}
		case "string":
			if (e.color) return "#000000";
			if (e.pattern) throw Error(`${t} is a required pattern-constrained string; provide an authoring.insertText.`);
			return "";
		default: throw Error(`${t} has an unsupported property kind; provide an authoring.insertText.`);
	}
}
function Je(e) {
	if (e.structure && e.structure.rule !== "none" && e.structure.rule !== "any" && e.structure.rule !== "inline") return !0;
	let t = e.children;
	return Array.isArray(t) ? t.some((e) => typeof e == "object" && !!e && (e.required === !0 || typeof e.min == "number" && e.min > 0)) : typeof t == "object" && t ? t.required === !0 || typeof t.min == "number" && t.min > 0 : !1;
}
function Ye(e, t) {
	let n = e.name, r = e.form;
	if (r !== "leaf" && r !== "inline" && r !== "container") throw Error(`component "${n}" has an unsupported form; provide an authoring.insertText.`);
	if (Je(e)) throw Error(`component "${n}" requires children; provide an authoring.insertText.`);
	let i = Object.entries(e.bindings ?? {}), a = new Set(i.flatMap(([, e]) => [e.bind, e.initial])), o = [];
	for (let [e, t] of i) o.push(`${t.bind}="${Ke(e === "value" ? n : `${n}_${e}`)}"`);
	for (let [e, r] of Object.entries(t)) r.required && (a.has(e) || o.push(`${e}="${qe(r, `component "${n}" property "${e}"`)}"`));
	let s = `<${n}${o.length > 0 ? ` ${o.join(" ")}` : ""}`;
	return r === "leaf" ? `${s}>` : r === "inline" ? `${s}></${n}>` : `${s}>\n\n</${n}>`;
}
var Xe = {
	id: "authoring-template",
	label: "",
	description: "",
	group: "input",
	keywords: [],
	template: ""
};
function Y(e, t = "") {
	let n = J({
		...Xe,
		template: e
	}, t);
	return B(t, {
		start: t.length,
		end: t.length
	}, n).value.slice(t.length);
}
function Ze(e) {
	return e.diagnostics.map((e) => `${e.code}: ${e.message}`).join("; ");
}
function Qe(e, t) {
	let n = Y(t), r = `</${e}>`, i = n.lastIndexOf(r);
	if (!(i < 0)) return {
		before: `${n.slice(0, i)}\n`,
		after: `\n${n.slice(i)}`
	};
}
function $e(e, t, n, r) {
	let i = r === void 0 ? Y(e) : Y(e, r.before), a = r === void 0 ? i : `${r.before}${i}${r.after}`, o;
	try {
		o = p(a, t ?? {});
	} catch (e) {
		throw Error(`${n} authoring.insertText could not be compiled: ${e instanceof Error ? e.message : String(e)}.`);
	}
	if (o.ok) return;
	let s = Ze(o);
	throw Error(`${n} authoring.insertText does not compile with this configuration${s ? ` (${s})` : ""}.`);
}
function et(e, t, n, r) {
	let i = r === void 0 ? e : `${r.before}${e}${r.after}`, a;
	try {
		a = p(i, t ?? {});
	} catch (e) {
		throw Error(`${n} has no authoring.insertText and its synthesized template could not be compiled: ${e instanceof Error ? e.message : String(e)}. Provide authoring.insertText.`);
	}
	if (a.ok) return;
	let o = a.diagnostics.map((e) => `${e.code}: ${e.message}`).join("; ");
	throw Error(`${n} has no authoring.insertText and its synthesized template does not compile with this configuration${o ? ` (${o})` : ""}. Provide authoring.insertText.`);
}
// src/authoring/catalog.ts
function X(e) {
	return /* @__PURE__ */ Error(`Invalid local component catalog: ${e}`);
}
function Z(e, t, n) {
	return a(e, t, n);
}
function tt(e, t) {
	let n = Z(e, t, "");
	return n === "" ? void 0 : n;
}
function nt(e) {
	if (typeof e == "string" || typeof e == "number" || typeof e == "boolean") return e;
	if (e === null) return null;
}
function rt(e, t) {
	return Object.freeze({
		name: e,
		kind: t.kind,
		required: t.required === !0,
		static: t.static === !0,
		dynamic: t.dynamic === !0,
		...t.values ? { values: Object.freeze([...t.values]) } : {},
		...nt(t.default) === void 0 ? {} : { defaultValue: nt(t.default) }
	});
}
function it(e, t) {
	let n = {};
	for (let [t, r] of Object.entries(e)) n[t] = rt(t, r);
	return n;
}
function at(e, t, n) {
	for (let [r, i] of Object.entries(e.props)) {
		let e = tt(i.description, n);
		if (e === void 0) continue;
		let a = t[r];
		t[r] = Object.freeze({
			...a ?? {
				name: r,
				kind: i.kind,
				required: i.required === !0,
				static: i.static === !0,
				dynamic: i.dynamic === !0
			},
			description: e
		});
	}
	return t;
}
function ot(e) {
	return Object.freeze({
		id: e.id,
		name: e.name,
		title: e.title,
		description: e.description,
		category: e.category,
		categoryLabel: e.categoryLabel,
		insertText: e.insertText,
		form: e.form,
		paired: e.form !== "leaf",
		inline: e.inline ?? e.form === "inline",
		...e.parents === void 0 ? {} : { parents: Object.freeze([...e.parents]) },
		...e.allowedChildren === void 0 ? {} : { allowedChildren: Object.freeze([...e.allowedChildren]) },
		...e.keywords === void 0 ? {} : { keywords: Object.freeze([...e.keywords]) },
		props: Object.freeze({ ...e.props }),
		...e.styles === void 0 ? {} : { styles: Object.freeze([...e.styles]) },
		...e.requires === void 0 ? {} : { requires: Object.freeze({ ...e.requires }) }
	});
}
function st(e) {
	let t = e.structure;
	return {
		...t?.parents?.length ? { parents: t.parents } : {},
		...t?.children?.length ? { allowedChildren: t.children } : {}
	};
}
function Q(e, t) {
	let n = r(e.name);
	if (n) {
		let e = Z(n.insertText, t, n.insertText.en ?? "");
		return e === "" ? void 0 : e;
	}
	let i = e.authoring?.insertText;
	return i !== void 0 && i.trim() !== "" ? i : void 0;
}
function ct(e, t) {
	let n = Q(e, t);
	return n === void 0 ? Ye(e, Ue(e)) : n;
}
function lt(e, t, n) {
	let r = l(e).structure?.parents;
	if (r !== void 0 && r.length !== 0) for (let e of r) {
		let r = t.get(e);
		if (r === void 0 || r.form !== "container") continue;
		let i;
		try {
			i = ct(r, n);
		} catch {
			continue;
		}
		let a = Qe(e, i);
		if (a !== void 0) return a;
	}
}
function ut(e, t) {
	if (e.parents !== void 0 && e.parents.length !== 0) for (let n of e.parents) {
		let e = t.find((e) => e.name === n);
		if (e === void 0 || e.form !== "container") continue;
		let r = Qe(n, e.insertText);
		if (r !== void 0) return r;
	}
}
function dt(e, t, n, i, a) {
	let s = l(e), u = r(e.name), d = e.authoring, f = Z(u ? u.title : d?.title, t, e.name), p = Z(u ? u.description : d?.description, t, f), m = d?.category, h = u?.category ?? (m !== void 0 && m.trim() !== "" ? m : "extension"), ee = o(h, t), g = Q(e, t), _ = st(s), v;
	if (g !== void 0) {
		if (v = g, a) {
			let r = lt(e, i, t);
			try {
				$e(v, n, `component "${e.name}"`, r);
			} catch (e) {
				throw X(e instanceof Error ? e.message : String(e));
			}
		}
	} else {
		try {
			v = Ye(e, Ue(e));
		} catch (e) {
			throw X(e instanceof Error ? e.message : String(e));
		}
		if (a) try {
			et(v, n, `component "${e.name}"`, lt(e, i, t));
		} catch (e) {
			throw X(e instanceof Error ? e.message : String(e));
		}
	}
	let te = at(e, it(s.props, t), t), y = c(e.name);
	return ot({
		id: u ? e.name : e.id,
		name: e.name,
		title: f,
		description: p,
		category: h,
		categoryLabel: ee,
		insertText: v,
		form: e.form,
		inline: u ? u.inline === !0 : e.form === "inline",
		..._,
		...y === void 0 ? {} : { keywords: y },
		props: te,
		...e.styles === void 0 ? {} : { styles: e.styles },
		...e.requires === void 0 ? {} : { requires: e.requires }
	});
}
function ft(e, t, n, r, a) {
	let o = new Map(e.map((e) => [e.name, e])), s = [], c = /* @__PURE__ */ new Set();
	for (let e of i) {
		let t = o.get(e);
		t && t.authoring !== void 0 && (s.push(dt(t, n, r, o, !1)), c.add(e));
	}
	for (let i of e) c.has(i.name) || (i.authoring !== void 0 || t.has(i.name)) && (s.push(dt(i, n, r, o, a && t.has(i.name))), c.add(i.name));
	return s;
}
function pt(e, t) {
	let n = r(e.name), i = e.authoring, a = {};
	for (let [t, n] of Object.entries(e.props)) a[t] = n.description;
	return JSON.stringify({
		name: e.name,
		id: e.id,
		form: e.form,
		title: Z(n ? n.title : i?.title, t, e.name),
		description: Z(n ? n.description : i?.description, t, ""),
		category: n?.category ?? i?.category ?? "",
		categoryLabel: o(n?.category ?? i?.category ?? "extension", t),
		insertText: Q(e, t) ?? null,
		inline: n ? n.inline === !0 : e.form === "inline",
		keywords: c(e.name) ?? null,
		manifest: i ?? null,
		preset: n ?? null,
		propDescriptions: a,
		structure: l(e).structure ?? null,
		styles: e.styles ?? null,
		requires: e.requires ?? null
	});
}
function mt(e, t = "en") {
	let n = d(e);
	if (!n.ok) return `invalid|${t}`;
	let r = n.registry.map((e) => pt(e, t));
	return `${f(e)}|${t}|${r.join("\0")}`;
}
function $(e, t, n, r) {
	return Object.freeze(ft(e.registry, e.externalComponentNames, t, n, r));
}
function ht(e, t = "en") {
	let n = u(e), r = d({ config: n });
	if (!r.ok) throw X(r.message);
	return $(r, t, { config: n }, !0);
}
function gt(e, t = "en") {
	let n = u(e), r = d({ config: n });
	if (!r.ok) throw X(r.message);
	return $(r, t, { config: n }, !1);
}
function _t(e, t = "en") {
	let n = d(e);
	return n.ok ? $(n, t, e, !0) : Object.freeze([]);
}
function vt(e) {
	let t = new Map(s.map((e, t) => [e.id, t])), n = /* @__PURE__ */ new Map();
	for (let t of e) {
		let e = n.get(t.category);
		e ? e.entries.push(t) : n.set(t.category, {
			id: t.category,
			label: t.categoryLabel,
			entries: [t]
		});
	}
	return Object.freeze([...n.values()].map((e, n) => ({
		...e,
		index: n,
		rank: t.get(e.id) ?? 2 ** 53 - 1
	})).sort((e, t) => e.rank - t.rank || e.index - t.index).map((e) => Object.freeze({
		id: e.id,
		label: e.label,
		entries: Object.freeze([...e.entries])
	})));
}
function yt(e, t = {}) {
	let n = t.ancestors ?? [], r = n[n.length - 1], i = (r === void 0 ? void 0 : e.find((e) => e.name === r))?.allowedChildren, a = (t.query ?? "").trim().toLowerCase(), o = e.filter((e) => e.parents !== void 0 && e.parents.length > 0 && !e.parents.some((e) => n.includes(e)) || i !== void 0 && i.length > 0 && !i.includes(e.name) ? !1 : a === "" || [
		e.name,
		e.title,
		e.description,
		e.categoryLabel,
		...e.keywords ?? []
	].some((e) => e.toLowerCase().includes(a)));
	return Object.freeze(o);
}
function bt(e) {
	let t = [];
	e.description !== "" && t.push(e.description);
	for (let n of Object.values(e.props)) n.description !== void 0 && t.push(`${n.name}: ${n.description}`);
	return t.join("\n");
}
function xt(e, t, n) {
	if (typeof e != "string" || !Number.isFinite(t)) return Object.freeze([]);
	let r = d(n);
	if (!r.ok || r.htmlActive) return Object.freeze([]);
	let i = Math.max(0, Math.min(e.length, Math.floor(t))), a = Object.freeze([]), o;
	try {
		o = h(e, n);
	} catch {
		return a;
	}
	let s = (e, t) => {
		for (let n of e) if ((n.type === "component" || n.type === "hostComponent") && n.name !== void 0 && n.range.start <= i && i < n.range.end) {
			let e = Object.freeze([...t, n.name]);
			a = e, n.children && s(n.children, e);
		} else n.type !== "fallback" && n.children && s(n.children, t);
	};
	return s(o.nodes, Object.freeze([])), a;
}
function St(e) {
	let t = {};
	if (!e) return t;
	for (let [n, r] of Object.entries(e.props)) t[n] = Object.freeze({
		name: n,
		kind: r.kind,
		required: r.required === !0,
		static: r.static === !0,
		dynamic: r.dynamic === !0,
		...r.values ? { values: Object.freeze([...r.values]) } : {},
		...r.default === void 0 ? {} : { defaultValue: r.default }
	});
	return t;
}
function Ct(e) {
	return Object.freeze({
		name: e.name,
		form: e.form,
		paired: e.form !== "leaf",
		title: e.title,
		description: e.description,
		category: e.category,
		categoryLabel: e.categoryLabel,
		insertText: e.insertText,
		props: Object.freeze({ ...e.props }),
		...e.parents === void 0 ? {} : { parents: Object.freeze([...e.parents]) },
		...e.allowedChildren === void 0 ? {} : { allowedChildren: Object.freeze([...e.allowedChildren]) },
		...e.keywords === void 0 ? {} : { keywords: Object.freeze([...e.keywords]) },
		...e.styles === void 0 ? {} : { styles: Object.freeze([...e.styles]) },
		...e.requires === void 0 ? {} : { requires: Object.freeze({ ...e.requires }) }
	});
}
function wt(e) {
	let t = new Map(e.map((e) => [e.name, e])), n = Object.freeze([...e]);
	return Object.freeze({
		tags: n,
		tag(e) {
			return t.get(e);
		},
		attribute(e, n) {
			return t.get(e)?.props[n];
		}
	});
}
function Tt(e, t = "en") {
	let n = d(e);
	if (!n.ok) return wt([]);
	let r = [];
	try {
		r = $(n, t, e, !1);
	} catch {
		r = Object.freeze([]);
	}
	let i = new Map(r.map((e) => [e.name, e])), a = [];
	for (let [e, t] of n.schemaByName) {
		let n = i.get(e), r = St(t);
		for (let [e, t] of Object.entries(n?.props ?? {})) r[e] = Object.freeze({
			...r[e],
			...t
		});
		a.push(Ct({
			name: e,
			form: t.form,
			title: n?.title ?? e,
			description: n?.description ?? "",
			category: n?.category ?? "component",
			categoryLabel: n?.categoryLabel ?? "component",
			insertText: n?.insertText ?? "",
			props: r,
			...n?.parents === void 0 ? {} : { parents: n.parents },
			...n?.allowedChildren === void 0 ? {} : { allowedChildren: n.allowedChildren },
			...n?.keywords === void 0 ? {} : { keywords: n.keywords },
			...n?.styles === void 0 ? {} : { styles: n.styles },
			...n?.requires === void 0 ? {} : { requires: n.requires }
		}));
	}
	return wt(a);
}
// src/authoring/insert.ts
var Et = /[A-Za-z_][A-Za-z0-9_]*/g;
function Dt(t, n, r) {
	let i = new Set(r.match(Et) ?? []), a = b(t, n, { diagnostics: !1 }).bindings.filter((e) => e.declarations.length > 0).map((e) => e.name), o = new Set(a), s = t;
	for (let t of a) {
		let r = t, a = 2;
		for (; i.has(r) || e.has(r) || r !== t && o.has(r);) r = `${t}${a}`, a += 1;
		i.add(r), r !== t && (s = ne(s, t, r, n).source);
	}
	return s;
}
function Ot(e) {
	return {
		id: e.id,
		label: e.title,
		description: e.description,
		group: "input",
		keywords: [],
		template: e.insertText
	};
}
function kt(e, t, n, r) {
	return B(n, r, Dt(J(Ot(e), n), t, n), { block: !e.inline });
}
function At(e, t, n, r, i = "en") {
	if (typeof n != "string") throw TypeError("insertLocalComponent requires source text.");
	if (typeof t != "string" || t.length === 0) throw TypeError("insertLocalComponent requires a component id.");
	let a = d(e);
	if (!a.ok) throw Error(`Invalid compile options: ${a.message}`);
	let o = _t(e, i).find((e) => e.id === t || e.name === t);
	if (!o) throw Error(`Unknown local component "${t}".`);
	return kt(o, e, n, r);
}
function jt(e, t, n, r, i = "en") {
	return At({ config: u(e) }, t, n, r, i);
}
// src/authoring/conformance.ts
function Mt(e, t = "en") {
	let n = u(e), r = new Set(n.components.map((e) => e.name)), i = [], a = { config: n }, o = gt(n, t);
	for (let e of o) {
		if (!r.has(e.name)) continue;
		let t = kt(e, a, "", {
			start: 0,
			end: 0
		}).value, n = ut(e, o), s = n === void 0 ? t : `${n.before}${t}${n.after}`, c = p(s, a);
		c.ok || i.push(Object.freeze({
			id: e.id,
			name: e.name,
			message: `Insert template for <${e.name}> does not compile with this configuration.`,
			diagnostics: Object.freeze(c.diagnostics.map((e) => Object.freeze({
				code: e.code,
				message: e.message
			})))
		}));
	}
	return Object.freeze(i);
}
export { Le as EXTENDED_NATIVE_COMPONENTS, Re as EXTENDED_NATIVE_COMPONENT_COPY_ZH, y as LOCAL_COMPONENTS, g as LOCAL_COMPONENT_NAMES, G as NATIVE_COMPONENTS, q as NATIVE_COMPONENTS_ZH, U as NATIVE_COMPONENT_GROUPS, K as NATIVE_COMPONENT_GROUPS_ZH, b as analyzeLocalSource, t as closestName, re as completeLocalSource, Tt as createLocalAuthoringLookup, ht as createLocalComponentCatalog, _t as createLocalComponentCatalogForOptions, yt as filterLocalComponentCatalog, se as formatBold, me as formatBulletList, fe as formatHeading, de as formatInlineCode, ce as formatItalic, ie as formatLocalSource, he as formatOrderedList, _e as formatQuote, le as formatStrike, ge as formatTaskList, v as getLocalComponent, ze as getNativeComponentCatalog, ee as getPropDefault, ve as indentSelection, Ce as insertCodeBlock, De as insertDivider, Se as insertImage, xe as insertLink, jt as insertLocalComponent, At as insertLocalComponentFromOptions, Ee as insertTable, B as insertTemplate, Oe as insertText, xt as localCatalogAncestors, vt as localComponentCatalogGroups, mt as localComponentCatalogKey, bt as localComponentHelp, m as localComponentNames, be as outdentSelection, Ie as readFormatState, ne as renameLocalBinding, J as renderNativeSnippet, _ as suggestAttribute, te as suggestComponent, Mt as validateLocalComponentInsertTemplates };
