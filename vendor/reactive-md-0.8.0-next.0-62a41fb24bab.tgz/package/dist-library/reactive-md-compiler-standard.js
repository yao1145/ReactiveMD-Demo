import { t as e } from "./compiler-core-Fk6_fRXo.js";
import { p as t } from "./html-DgECD9QC.js";
import { n } from "./math-display-CwTpS1cA.js";
import r from "./reactive-md-default-preset.js";
import { i, r as a, t as o } from "./types-CMqKCmnF.js";
// src/compiler/standard.ts
function s(e) {
	let n = t(e, r.components);
	if (n.ok) return n;
	throw new o(n.message, {
		code: n.key,
		...n.detail === void 0 ? {} : { detail: n.detail }
	});
}
function c(e) {
	return e === void 0 ? void 0 : Object.freeze({ ...e });
}
function l(t) {
	let r = s(t), o = c(t), l = { display: n };
	return { compile(t) {
		return i(e(t, o, r, l), a);
	} };
}
export { o as CompilerConfigurationError, l as createStandardCompiler };
