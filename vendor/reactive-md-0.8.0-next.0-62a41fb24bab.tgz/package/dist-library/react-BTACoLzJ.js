import { F as e, O as t } from "./default-components-qRt0E8bl.js";
import { c as n } from "./registry-DaHST1VN.js";
import { t as r } from "./resources-Uw1NWO5K.js";
import { Z as i, i as a } from "./LocalDocumentView-DScHLV4y.js";
// src/react/package.ts
function o(e) {
	let t = r(e);
	if (t.diagnostics.length) throw TypeError(t.diagnostics.map((e) => `[${e.code}] ${e.message}`).join("\n"));
	return t.resources;
}
function s(n) {
	let { render: r, renderStatic: a, css: s, resources: c = [], ...l } = n, u = l.styles ?? [...new Set(s === void 0 ? c.map((e) => e.id) : [`${l.id}.css`, ...c.map((e) => e.id)])];
	if (s !== void 0 && u.length === 0) throw TypeError("Inline css requires a style resource identity.");
	let d = t({
		...l,
		protocol: l.protocol === void 0 ? e : l.protocol,
		form: l.form === void 0 ? "leaf" : l.form,
		props: l.props === void 0 ? {} : l.props,
		...u.length ? { styles: u } : {}
	});
	if (s !== void 0 && typeof s != "string") throw TypeError("Component css must be an inline string.");
	let f = o([...s === void 0 ? [] : [{
		id: u[0] ?? `${d.id}.css`,
		css: s
	}], ...c]);
	for (let e of d.styles ?? []) if (!f.some((t) => t.id === e)) throw TypeError(`Component ${d.id} is missing style resource ${e}.`);
	let p = i(d, {
		render: r,
		...a === void 0 ? {} : { renderStatic: a }
	});
	return Object.freeze({
		definition: d,
		components: Object.freeze([p]),
		resources: f
	});
}
function c(e = {}) {
	let t = e.packages ?? [], r = [...t.flatMap((e) => e.components), ...e.components ?? []], i = n({
		components: r.map((e) => e.definition),
		themes: [...t.flatMap((e) => e.themes ?? []), ...e.themes ?? []]
	}), s = a(i, { components: r }), c = o([
		...t.flatMap((e) => e.resources ?? []),
		...e.resources ?? [],
		...s.config.themes.flatMap((e) => e.css)
	]);
	for (let e of i.components) for (let t of e.styles ?? []) if (!c.some((e) => e.id === t)) throw TypeError(`Component ${e.id} is missing style resource ${t}.`);
	return Object.freeze({
		config: s.config,
		reactConfig: s,
		compileOptions: Object.freeze({ config: s.config }),
		resources: c,
		css: c.map((e) => e.css).join("\n"),
		notices: Object.freeze([...t.flatMap((e) => e.notices ?? []), ...e.notices ?? []])
	});
}
export { s as n, c as t };
