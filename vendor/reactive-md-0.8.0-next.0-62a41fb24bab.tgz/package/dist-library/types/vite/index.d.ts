import { type Plugin } from 'vite';
export interface ReactiveMdViteOptions {
    /** Local module exporting `host = createReactHost(...)`. Relative to Vite root. */
    readonly extensions: string;
}
/** Optional Node-only adapter. Registration and code execution stay explicit. */
export declare function reactiveMd(options: ReactiveMdViteOptions): Plugin;
export default reactiveMd;
