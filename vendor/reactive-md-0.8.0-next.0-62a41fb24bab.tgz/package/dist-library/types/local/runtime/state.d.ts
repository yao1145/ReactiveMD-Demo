import type { Diagnostic, LocalDocument, LocalRuntime, LocalValue } from '../contracts/types.js';
/** Version tag for the portable, shareable parameter state format. */
export declare const LOCAL_STATE_FORMAT: 'reactive-md-state/v1';
export interface LocalStateGenerator {
    name: string;
    version: string;
}
export interface LocalStateFile {
    format: typeof LOCAL_STATE_FORMAT;
    /** Syntax revision the state was produced for (currently `local-draft-3`). */
    syntax: string;
    /** Deterministic digest of the document source. */
    sourceDigest: string;
    /** Public binding name -> serializable value. */
    parameters: Record<string, LocalValue>;
    generator?: LocalStateGenerator;
}
export type LocalStateParseResult = {
    ok: true;
    file: LocalStateFile;
} | {
    ok: false;
    diagnostics: Diagnostic[];
};
export type LocalStateResolution = {
    ok: true;
    file: LocalStateFile;
    state: Readonly<Record<string, LocalValue>>;
} | {
    ok: false;
    diagnostics: Diagnostic[];
};
/** FNV-1a over the UTF-8 bytes of the source. */
export declare function localSourceDigest(source: string): string;
/**
 * Capture every public binding from a runtime state. Internal `@...` binding
 * keys and declared read-only values are ignored so a full snapshot can be passed in;
 * unknown keys, missing public keys and non-serializable values are rejected.
 */
export declare function createLocalStateFile(document: LocalDocument, state: Readonly<Record<string, LocalValue>>, generator?: LocalStateGenerator): LocalStateFile;
/**
 * Parse a serialized state file (or an already parsed value). Malformed input
 * never throws; it produces diagnostics under `local.state.*` at 1:1.
 */
export declare function parseLocalState(input: string | unknown, options?: {
    maxLength?: number;
}): LocalStateParseResult;
/**
 * Verify a state file against a compiled document and normalize its values
 * through a throwaway runtime. No live runtime is created or mutated.
 */
export declare function resolveLocalState(document: LocalDocument, input: string | unknown, options?: {
    maxLength?: number;
}): LocalStateResolution;
/**
 * Validate the file against the document (using the runtime's current state as
 * the baseline) and then write the normalized public values. Multi-slot
 * components are written atomically with `setMany`.
 */
export declare function applyLocalState(runtime: LocalRuntime, file: LocalStateFile, options?: {
    maxLength?: number;
}): Diagnostic[];
/**
 * Capture the live runtime's public parameters in the portable state format.
 * The runtime snapshot may contain internal bindings; the state file never does.
 */
export declare function exportLocalState(runtime: LocalRuntime, generator?: LocalStateGenerator): LocalStateFile;
/**
 * Parse a serialized or already-parsed state payload and apply it to a live
 * runtime. Returns diagnostics and never throws for malformed input; a failed
 * import leaves the runtime state untouched.
 */
export declare function importLocalState(runtime: LocalRuntime, input: string | unknown, options?: {
    maxLength?: number;
}): Diagnostic[];
/**
 * Produce stable JSON in a canonical key order. The CLI is responsible for
 * wrapping the result in an HTML/script context; no HTML escaping happens here.
 */
export declare function serializeLocalState(file: LocalStateFile): string;
