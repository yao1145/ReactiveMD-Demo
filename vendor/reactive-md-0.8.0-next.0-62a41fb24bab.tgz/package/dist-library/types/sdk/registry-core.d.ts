import type { LocalComponentSchema } from '../local/configuration/schema-core.js';
import type { LocalComponentDefinition } from './types.js';
/** Project a public manifest onto the legacy `LocalComponentSchema` view. */
export declare function componentSchemaFromDefinition(definition: LocalComponentDefinition): LocalComponentSchema;
/** Cached alias used by callers that already hold a manifest. */
export declare function localComponentSchema(definition: LocalComponentDefinition): LocalComponentSchema;
