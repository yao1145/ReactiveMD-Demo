import { type LocalComponentDefinition } from '../sdk/types.js';
/**
 * The 46 rendered/structural components of the default preset, in the original
 * declaration order. `computed`, `const` and `external` stay kernel grammar
 * metadata in `src/local/configuration/schema.ts`.
 */
export declare const DEFAULT_COMPONENT_DEFINITIONS: readonly LocalComponentDefinition[];
export declare const DEFAULT_COMPONENT_NAMES: readonly string[];
